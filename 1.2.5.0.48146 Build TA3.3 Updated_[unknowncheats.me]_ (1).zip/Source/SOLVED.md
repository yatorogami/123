# Solved Workstreams — TarkovAddonsReloaded

This document archives all completed workstreams from `Workstream_status_2026-09-24.md`. Do not edit — reference only.

---

## 1. Transit to forced-online locations while offline (ProfileStatus patch)
**Status: SOLVED** (v2 deployed 13:57; guard rework 20:06; cap fix 22:38)

- ISIL dump showed `<Run>d__201` creates closure *inside* MoveNext prologue — pre-call read always null
- Fix patches `profileStatus` parameter object (resolver field `profileStatus`, boxed 0x30 = raw sm+0x20)
- Raid-start guard in `always_on.h`: armed only for transit-patched sessions; `hk_local_raid_started` arms; `hk_local_game_matching/create` suppress while window open
- `transit_patched` flag records transit entry; arming deferred to `hk_local_raid_started`; `hk_local_game_stop` + `hk_local_raid_ended` disarm
- Cap reduced to 40 s (`kRaidStartGuardCapMs`); load-complete close + 6-min failsafe added (#15)

---

## 2. DEBUG log level + spam demotion + Menu resize
**Status: SOLVED** (15:58 build; menu fix 20:06)

- `logger::debug()` gated (default off); `logger::set_debug_enabled(bool)` at runtime
- Shape dumps, qword dumps, awaiter dumps, inheritance dumps, field scans, per-resume traces → `debug`
- `DebugLogModule` got persisted `DebugLogging` checkbox; log reader uses DLL-relative mirror path
- Menu default 840x560 → 950x700; resizable (min 720x520, max 1920x1080 scaled); log child 220→520 px with `TextWrapped`
- Resize layout: left nav rail fixed (158 * scale_factor); two content columns each half of remaining width

---

## 3. Magic (Mage) Hand — L1/L2/L3 pipeline fixed
**Status: SOLVED** (18:13 build; L3 rewrite 20:06; bindings migration 14:35)

- L1: `set_PerformPickUpValidation(false)` via metadata-resolved setter (no hardcoded offset); reapplies every frame
- L2a: `InventoryController.IsAtReachablePlace(Item)` → `true` (hooked)
- L2b: `WorldInteractiveObject.CanStartInteraction(EDoorState, bool)` → `true` (covers Door, KeycardDoor, ExfiltrationPoint, CardReader)
- L3: Rewritten to real game path — `ItemManipulator.Move(item, slot, controller, false)` + `InventoryController.FindSlotToPickUp`
- Migration to generated bindings: `generated::EFT::Interactive::LootItem::set_PerformPickUpValidation`, `generated::EFT::InventoryLogic::InventoryController::FindSlotToPickUp`, `generated::EFT::InventoryLogic::ItemManipulator::Move`

---

## 4. Ballistic penetration — field fallback + level gate fix
**Status: SOLVED** (18:13 build; level gate 20:06; deeper walk 15:54)

- ISIL dump lacks `get_PenetrationLevel/Chance` methods — values are plain fields on BaseBallistic at +0x40/+0x44
- `try_read_ballistic_penetration` now falls back to direct field read (silent resolve)
- `classify_blocker`: removed `PenetrationLevel < epsilon → blocked` shortcut (thin cover has Level==0 with real chance)
- Deeper component walk: hit transform + up to 3 ancestors for BallisticCollider (grates/fences sit 2–3 levels down)
- Combined-chance gate loosened: 0.05 → 0.01; diagnostics log GO name + transform class + hit distance

---

## 5. Items Chams — purple/pink after transit
**Status: SOLVED** (18:13 build; self-heal + watchdog 20:06)

- Root cause: shader cache as raw `Il2CppObject*` without GC root; scene unload destroys native objects
- `unity::is_unity_object_alive()` validates via `m_CachedPtr` + VirtualQuery
- `asset_bundles.h`: `request_reload()` / `consume_reload_request()` / `reset_bundle()`; reload from `hk_tarkov_application_update`
- `ChamsModule`: evicts dead shaders, clears `applied_items`, requests reload
- Self-heal: OFF→ON toggle clears `applied_items` + forces re-scan; 8 s cadence clears `applied_items`; 15 s watchdog restarts load if wedged

---

## 6. Loot Teleport — decoupled from ESP
**Status: SOLVED** (18:43 build; lock-out restored 20:06)

- Removed `EspModule*` dependency; duplicated `matches_filter` + helpers into LootTeleportModule
- Own settings: `ltp_selected_items_only_cb`, `ltp_item_search_txt`, `ltp_category_only_cb`, `ltp_category_sel`
- Wishlist refresh on demand from profile (no ESP gating)
- Lock-out restored: item search disabled until "selected items only" checked; category dropdown until "category only" checked
- `ItemSearchValue::draw()` now renders disabled state via `ImGui::BeginDisabled` + dimmed label

---

## 7. Optics — investigation only
**Status: DEFERRED** (per user request "look into that later")

- Docs describe full native lens-projection; current `optics_projection.cpp` is simplified radial-fit
- `lens_renderer` barely used; EspModule optics path doesn't follow either doc
- Proper implementation is feature-sized workstream

---

## 8. Skeleton ESP — wild red lines
**Status: SOLVED** (22:38 build)

- `draw_skeleton_entry` now validates bone world positions (finite + magnitude < 1e6) before projection
- Clamps projected screen coordinates (finite + `max_coord` = 10x display diagonal)
- Invalid bones silently skipped

---

## 9. Raid-start guard false positive (starvation)
**Verified solved in-game 2026-09-24 (test round 2)**

**Status: CLOSED** — resolved by create-passthrough rule

- Guard was treating destination raid's matching/create as duplicate of source raid's load window
- Passthrough rule in `always_on.h`: in-window matching suppressed, but create arriving WITHOUT suppressed matching is passed through
- 12:41-12:44 Streets trace confirms passthrough works end-to-end
- `transit_patched` sticky per session + arming per `hk_local_raid_started` is intended design

---

## 10. WebSocket console filter
**Verified solved in-game 2026-09-24 (test round 2)**

**Status: CLOSED** (15:54 build v2)

- Expanded filter patterns: `WebSocket.processPongFrame`, "A pong was received", "It has been signaled"
- Side effect: `logger::set_color()` targeted pipe handle after `SetStdHandle` → monochrome console
- Fix v2: `ConsoleFilter::start()` opens `CONOUT$` by name (`CreateFileW`); uses for logger colors + line forwarding
- Colors (INFO cyan / WARN yellow / ERROR red / DEBUG gray) restored

---

## 11. Magic Hand — interaction probe label
**Status: PARTIAL / ONGOING** (15:54 build)

- Doors partially work — game suggests required key (L2b `CanStartInteraction` bypass fires)
- Vehicles: no `CarController`/`VehicleInteractionPoint` in dump; BTR uses `BTRVehicle` + `BTRView`/`BtrController`
- Added probe label: `show_interaction_label` + `interaction_probe_range`; camera-forward raycast every ~150 ms
- Overlay shows: `Door · state · needs key: <KeyId>` / `Loot · <name>` / `Vehicle · <go>` / raw GO name

---

## 12. Ballistic penetration — grate/chain-link false blocked
**Status: SOLVED** (15:54 build)

- Root cause #1: NaN/IsUnsetup reader returned `false` before `classify_blocker`'s NaN→penetrable branch could run
- Root cause #2: BallisticCollider lookup walked only hit transform + direct parent (grates 2–3 levels down)
- Fixes: deeper walk (3 ancestors); combined-chance gate 0.05→0.01; upgraded diagnostics

---

## 13. Skeleton ESP — GC/pointer staleness hypothesis
**Status: OPEN (SPECULATIVE)** — 22:38 fix masks symptoms, root cause may be use-after-free

- Wild lines to screen border suggest stale pointers from:
  - `skeleton_store` reallocation invalidating render-frame pointers
  - `bone_ref` keys referencing moved `entry.bones` map
  - GC moving managed objects while native code caches pointers
  - Frame latency: bone positions collected frame N, drawn frame N+1, object destroyed in between
- Consider: copy to local POD array immediately; frame-id validation (discard >1 frame old)

---

## 14. Offline transit hang — Streets / Icebreaker
**Status: SOLVED** (2026-09-24 build)

- `IsLocalTransitHop()` = `TransitionStatus.Mode==1 || RaidMode==1`; neither controller sets Mode
- `LocalTransitController.Transit` evaluated `ForceOnlineRaidInPVE` before mod configured target
- Fixes: `hk_ta_is_local_transit_hop` returns true; `hk_transit` runs `setup_target_location` + `setup_local_player_object` BEFORE `o_transit`; `RaidMode=Local` on `g_last_ta`; `hk_start_online_transit_matching` suppresses original

---

## 15. Raid-start guard 40 s cap expiry on slow transit
**Verified solved in-game 2026-09-24 (test round 2)**

**Status: SOLVED** (load-complete close + 6-min failsafe)

- 40 s cap expired mid-load (Streets ~70 s) → matching re-run while loading → crash
- `raid_start_guard_load_complete()` closes window when destination raid loaded (from `hk_game_world_update`)
- Cap 40000 → 360000 as failsafe only; primary close is load-complete
- Guard still only arms for `transit_patched` sessions

---

## 16. IL2CPP Bindings Generator + Migration
**Status: COMPLETED** (2026-09-24 14:35)

- `generate_bindings.py` parses 15,605 ISIL dump files → 33 target classes
- `il2cpp/generated_bindings.h`: constexpr offsets + pattern-scanner fallback; ergonomic `generated::EFT::Namespace::Class::Method(args)`
- Handles: void returns, pointer types (nullptr), value types (default ctor), C++ keyword sanitization, nested types, generic filtering
- Manual fallbacks for critical methods not in ISIL dump: `LootItem.set_PerformPickUpValidation`, `InventoryController.FindSlotToPickUp`, `ItemManipulator.Move`
- PlayerModule.h migrated: Magic Hand L1/L3 use generated bindings
- Build: `Prod|x64` successful (0 errors); deployed with timestamped backup
- **Addendum 2026-09-24 evening**: extension attempt (RaycastHit fields, out/ref params, namespace reordering) made things worse in-game and was rolled back; subsequent Magical Hand rework removed the last `generated::` users. **Generated bindings are now unused by any module** — new IL2CPP access goes through manual `il2utils` resolution. Do not re-migrate.

---

## 17. Generated-bindings extension rollback + globals::verbose consolidation
**Status: SOLVED** (2026-09-24 evening; Prod|x64 clean)

- Rollback: `generate_bindings.py` + `il2cpp/generated_bindings.h` reset to committed state; `skeleton_visibility.h` reverted to manual `il2utils::resolve_method` / `unity::*` paths (kept unrelated #12/#20 improvements: classify_blocker 0.01f gate, enhanced env/terrain diagnostic with GO name/transform class/distance)
- Verbose: `globals::verbose` deleted from `util/globals.h`; every `if (globals::verbose) logger::info(...)` site → plain `logger::debug(...)` (ConfigModule ×3, DoorsModule, QuestModule ×2, ItemModule ×7, PlayerModule ×3, scan.h ×3, always_on.h ×2); HideoutModule helpers lost their `bool verbose` param; `logger::error("No Item Factory")` / `logger::warn("Skill not found: ...")` keep their levels unguarded
- Single diagnostic gate: `logger::debug` + Debug Log module toggle

---

## 18. Magical Hand — ISIL interaction-pipeline findings + L2b-only rework (sweep version, superseded by raycast)
**Status: SOLVED as a knowledge/rework item** (2026-09-24; in-game verification of the final raycast build tracked as workstream #11)

 ISIL findings (EFT/Interactive dumps, method bodies — not guesses):
- EDoorState: 1 = Locked (`Lock()`), 2 = Closed (`Close()`), 4 = Open (`Open()`), 8 = interaction-busy (`LockForInteractionAs(8)`); old probe mapping (0=Locked/2=Open) was wrong, user's "door status=1 = locked forever" was right
- `CanStartInteraction` is ONLY called from network-sync paths (`Door.SyncInteractState` et al.) — hooking it never gated the local F-press
- Local gate is `InteractionContextHelper.GetAvailableActions(GamePlayerOwner, WIO)`: DoorState==1 → key-unlock (else "Locked" error); other states → plain Open/Close actions
 Rework history:
- L2b-only per user ("everything else is already hooked"): L1 `PerformPickUpValidation`, L2a `IsAtReachablePlace`, L3 auto-pickup (cone + FindSlotToPickUp/ItemManipulator.Move) and their menu entries removed; last `generated::` users disappeared, include dropped from PlayerModule.h
- 1 Hz map-wide WIO sweep version superseded same day: user reported it stuttered the game each ~1 s AND objected to touching every door-type object → replaced by camera-forward raycast unlock (see workstream #11)
- Vehicle/BTR doors closed as not-an-option: BTR doors are neither `Door` nor `WorldInteractiveObject` (`BTRVehicle.InteractInternal` + BusyState; `EFT.Vehicles` absent from dumps); user confirmed Door Unlocker button misses them
- Probe kept as the Magic Hand label with corrected state names (1=Locked/2=Closed/4=Open); "needs key" hint only while still Locked; BTR branch removed; `skeleton_vis::is_ready()` force-init so Magical Hand works without ESP

---

## 19. Magical Hand L2b — raycast unlock verified; label removed; moved to Door Unlocker card
**Status: SOLVED** (verified in-game 2026-09-24, test round 2 — user: "doors are unlocked as I look at them, so that's cool")

- Final form: `DoorsModule::apply_interaction_unlock()` in `application_update` — camera-forward
  raycast at ~150 ms (range slider), hit GO + up to 2 ancestors checked for
  `WorldInteractiveObject`; `DoorState == 1` (Locked) → `set_DoorState(2)` (Closed); the game
  then offers the normal F Open (animation/sound/sync). get/set resolved per instance class.
- Per user: the map-wide sweep variant stuttered the game each ~1 s (per-second
  `FindObjectsOfType` over all WIOs) and touched too many objects — raycast only. Corroborated:
  the raycast build shows no such hitch with doors unlocking on look.
- **Interaction probe label removed** (uncontrolled flickering); the raycast unlock runs
  standalone. PlayerModule's whole Magical Hand block (L1/L2a/L2b/L3 remnants, probe struct,
  overlay draw, config values) deleted; `draw_overlay` override now empty.
- Toggle lives in the **Door Unlocker** card next to the bulk unlock button per user request;
  config keys unchanged (`bypass_interaction_check_cb`, `interaction_probe_range_itm`) so
  settings persist.
- Unlock logging: `logger::debug` `Door Unlocker L2b: unlocked '<go>' (Locked -> Closed)`.
- Out of scope (user-confirmed): BTR/vehicle doors — not `Door`, not `WorldInteractiveObject`.

---

## 20. Items Chams after transit — self-heal verified
**Status: SUPERSEDED by #22** (verified in-game 2026-09-24, test round 3 — user: "Items Chams seem to look fine after extract->raid and raid->transit, too")

- Self-heal cadence + watchdog work as designed; no further action.
- Later found to be insufficient: the cadence re-painted correctly but the *bundle reload*
  it depends on could not survive a transit at all. See #22.

---

## 21. UI consistency — editable sliders + full i18n coverage
**Status: SOLVED** (2026-09-24, test round 3; Prod|x64 clean)

- `item_chams_distance_sld` (ChamsModule): IntSliderValue → FloatSliderEditableValue.
- `interaction_probe_range_itm` (DoorsModule unlock ray): FloatSliderValue → FloatSliderEditableValue.
- Key audit across all sources vs all 19 locale files: every used config/display key now exists
  in every locale (was: 6 keys missing everywhere incl. en, 27 more missing per non-en locale,
  plus 38 labels hardcoded in i18n.cpp overriding the files).
- Hardcoded UI texts moved into translation files: 13 module display names converted to keys
  (`door_unlocker_mod`, `favorites_mod`, `hideout_mod`, `debug_log_mod`, `icebreaker_mod`,
  `gear_editor_mod`, `quest_reset_mod`, `item_spawner_mod`, `map_selector_mod`,
  `marked_rooms_mod`, `quest_completer_mod`, `bot_tp_sec`, `experience_editor_mod`); the
  i18n.cpp special-case if-chain deleted (its canonical texts synced into en.json first);
  en.json corrected to the texts the user actually saw.
- Config keys are namespaced by Module::name, not display key — saved settings unaffected.

---

## 22. Loot Chams — four defects, all confirmed in-game 2026-10-02
**Status: SOLVED** (log-verified 2026-10-02 21:06; builds `2c6bd4d8`, `ba98cdd4`, and
`2f1f50bf`. The third carries the transit fix under a "progress" title, so the chain and
the reasoning are recorded here — the code comments carry the *rationale*, this carries the
*evidence trail*.)

Reported as "items' chams stopped working — some items get the new texture, some don't".
Four separate causes. Three were unfindable by reading the code; only the log settled them.

### 22.1 Only material[0] was painted (`2c6bd4d8`)
`apply_chams_to_renderer` called `get_material` — Unity's singular `Renderer.material`,
which returns the **first** slot. A mesh with N submeshes has N slots, so slot 1..N-1 kept
their original shader and texture. Items rendered as a patchwork.

The log made this a fact rather than a hypothesis: on **every** full pass `materials >
renderers`, with `multi_slot` = 2–5. Multi-slot items were routine on that map, and each was
half-converted. It looked like "works on some items" because the split is per **submesh**.
Renderers and slots are now counted separately — while only slot 0 was painted the two
counts were identical, so the one number that could have revealed submeshes was the number
hiding them.

### 22.2 The un-paint was unreachable (`2c6bd4d8`)
Distance was a gate on *first paint only*, with no reverse path, which is why the slider
felt inert: lowering it did nothing, ever. Adding the un-paint did not work — `unpainted=0`
across all 127 log lines including 32 full passes with `oor=5..14`.

Cause was an **ordering** interaction: the re-paint cadence runs first and does
`applied_items.clear()`, and the only ticks that examine anything are the ones right after
it (the cursor is parked at the end in between). So `applied_items.contains()` was always
false by the time the out-of-range branch ran. Dead code. The gate is now
`original_item_materials`, deliberately *not* cleared by a repaint.

Restoring needed two non-obvious things. Originals must be captured with
`get_sharedMaterials` **before** the first paint, because `get_materials` instantiates and
afterwards the pristine values are gone — re-reading would capture our own chams as the
thing to restore. And `Renderer.SetMaterial(int, Material)` **does not exist** on the
IL2CPP `Renderer`; `set_material` is one-argument, so a two-argument call resolved through
`get_method`'s `allow_any_argc` fallback and would have passed the slot index in the register
read as `Material*`. It compiled clean and passed 139 tests, because no test calls into
IL2CPP. Verified against `GameDump/.../UnityEngine/Renderer.cs`; all new lookups now pass
`allow_any_argc=false`.

### 22.3 `List<T>._items.max_length` is CAPACITY, not population (`2c6bd4d8`)
Every pass read `loot=1000 examined=1000 null=945 applied=49`. The list had grown to 1000
slots and held ~55; two independent routes agreed on 55 (`applied+oor`, and `capacity-null`).
So the reported population was capacity, every ratio off that line was wrong ~18×, and the
cursor parked at 1000 having "seen" 55. `unity::list` gained `_size` + clamped `live_count()`
(additive, so the 15 existing call sites are unaffected). Verified in-game: `null=0` and
`loot` now tracking a live count.

The same pass printed `unaccounted=945`, exactly equal to `null=945` on every line — the
signature of one omission, not a mystery: `null_obj` was counted but not summed into
`accounted`. A diagnostic that cries wolf on every line is worse than none.

### 22.4 Saved materials outlived their items (`ba98cdd4`)
`original_item_materials` was only cleared on cache-clear and toggle-off, so an entry
survived the item it described. Harmless until the allocator reuses that address, at which
point `needs_save` is false for the new item, its own materials are never captured, and
leaving range restores the **dead** item's materials onto the live one.

Reachable, not theoretical: a pass reporting `examined=425 applied=0 oor=412 unpainted=411`
ended with `saved=34` — all 412 out-of-range items had just been restored, so those 34 could
only name departed items. 8% of the list.

`sweep_stale_materials()` erases entries whose key is absent from `applied_items`, and runs
**only when a pass completes**. That placement is the correctness argument: the per-tick cap
returns early with most of the list unvisited, and sweeping there would discard live items
that simply have not been repainted yet. Verified: 89 completed passes, all `saved ==
applied_set`.

### 22.5 The transit reload could never succeed (`2f1f50bf`)
This is what superseded #20. On 2026-10-01 22:57, after a transit killed the shader,
`reset_bundle()` nulled the pointer and **never called `Unload`**. Unity keeps a loaded
bundle registered against its file path, so the reload rewrote `ta\chams\tarkovutils` and
called `LoadFromFileAsync` on a path Unity still held — returning a request that completed
immediately with `assetBundle == null`, permanently, identically on all 17 watchdog
restarts. 11,903 ERROR lines at 46/s for 258 s: 85% of that session's log.

The bundle file was 18,806 bytes on disk, the exact embedded size — which is what ruled out
the write and pointed at the registry entry. `check_progress()` returning `bool` could not
distinguish "still loading" from "finished and failed", so a finished request was polled
every frame forever; it is now a tri-state and a failure backs off on the existing 5 s
timer.

Confirmed in-game 2026-10-02 21:06 — **identical trigger, opposite outcome**: shader dead →
`Reloading chams Asset Bundle (stale after transit)` → `Loaded Asset Bundle` 1.03 s later,
with `get_assetBundle returned null` at **0**. Chams repainted 67 ms later.

It took three sessions to trigger. Sessions on 10-01 (x2) and 10-02 (x2) had 4–7 transits and
**zero** shader deaths, so "no errors" in those logs was the fix being *absent*, not working.

### Still open
- **Restore burst is uncapped.** Painting is capped per tick (`max_item_chams_per_tick`);
  restoring is not, so walking away from a loot-dense spot concentrates the backlog into one
  frame. Measured peaks: 71, 141, 411 restores/tick. At the measured 34 µs each, 411 is
  ~14 ms — a dropped frame at 60 fps. Left uncapped deliberately: it trades one visible
  behaviour (items stay chams'd a few hundred ms longer) for another, so it is a decision,
  not a defect. The log's `unpainted=` counter verifies a cap without re-adding zones.
- Chams Tracy zones were removed after measuring **0.041%** (0.486 s of 1199 s), 189× smaller
  than `eft_api::is_readable_address`. Consequence: chams cost is now *unmeasurable* rather
  than measured-small.
