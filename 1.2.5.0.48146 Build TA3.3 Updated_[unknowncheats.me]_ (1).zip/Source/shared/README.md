# shared/

First-party code used by **both** DLL projects, at the repository root rather than
inside either one.

```
shared/
  module_paths.h    deployment-layout paths, resolved against the running DLL
```

This is the first-party counterpart to [`external/`](../external/README.md), which
holds shared *third-party* code on the same principle. The test for which one a
file belongs in is who uses it:

- used by `TarkovAddons` only -> `TarkovAddons/`
- used by `TarkovLauncherBypass` only -> `TarkovLauncherBypass/`
- used by both -> `shared/`, or `external/` if it is not ours

## Why `module_paths.h` moved

It was reached across project boundaries by a relative path
(`TarkovLauncherBypass/util/compat_profile.cpp` including
`"../../TarkovAddons/util/module_paths.h"`) and was **not declared in the bypass's
`.vcxproj` at all**. That is the worst of both: moving or renaming the file breaks
the other project with a misleading error, and nothing in its build says the
dependency exists. `external/README.md` records the same argument for SafetyHook
and nlohmann/json, which is why they were moved out in the first place.

`module_paths.h` is the last remaining instance of that, so this closes it rather
than documenting it.

The header is unchanged. Header-only, all `inline`, and it resolves paths against
**its own** DLL's location at runtime rather than against any compile-time project
constant — which is why it was safe to share before it was legal to, and why
nothing in it needed to change.

## How a project consumes it

Relative includes from the including file, resolved against its own directory:

```cpp
// TarkovAddons/module/minimap.h
#include "../../shared/module_paths.h"
```

Both `.vcxproj` files register it, so the dependency is declared on both sides:

```xml
<ClInclude Include="$(MSBuildThisFileDirectory)..\shared\module_paths.h" />
```

`$(MSBuildThisFileDirectory)` rather than `$(SolutionDir)`, for the reason
`external/README.md` gives: each project is built from its own solution, so
`$(SolutionDir)` does not point at the repository root in all cases.

## Trade-off, unchanged from `external/`

Neither project directory is self-contained. Copying `TarkovLauncherBypass/` alone
to another machine no longer builds, because it needs the repository root beside
it. That is the accepted cost of one copy instead of two, and it is already paid
for `external/` — this makes `shared/` the first-party half of the same trade
rather than a new one.

Verified after the move: every consuming header and both projects' `dllmain.cpp`
and `compat_profile.cpp` compile clean (mingw + `tools/verify/msvc-shim`,
signature count 0), with a negative control that fails when the header is moved
away.
