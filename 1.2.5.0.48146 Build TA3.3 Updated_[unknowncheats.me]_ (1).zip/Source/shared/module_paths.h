#pragma once

#include <climits>
#include <filesystem>
#include <string>
#include <Windows.h>

namespace module_paths {
    inline HMODULE& dll_handle() {
        static HMODULE handle = nullptr;
        return handle;
    }

    inline std::filesystem::path& cached_dll_directory() {
        static std::filesystem::path dir;
        return dir;
    }

    inline bool is_system_directory(const std::filesystem::path& dir) {
        if (dir.empty()) return true;

        const std::wstring w = dir.wstring();
        return w.find(L"\\System32") != std::wstring::npos
            || w.find(L"\\SysWOW64") != std::wstring::npos
            || w.find(L"\\WinSxS\\") != std::wstring::npos;
    }

    inline std::string wide_to_utf8(const std::wstring& wide) {
        if (wide.empty()) return {};
        if (wide.size() > static_cast<size_t>(INT_MAX)) return {};

        // Pass an explicit character count rather than -1. With -1 the API
        // reports the byte count INCLUDING the terminating NUL, and that is
        // what it then writes -- so the old code declared a buffer of size-1
        // and told the API it had `size` bytes, overflowing it by one.
        const int chars = static_cast<int>(wide.size());
        const int size = WideCharToMultiByte(CP_UTF8, 0, wide.data(), chars, nullptr, 0, nullptr, nullptr);
        if (size <= 0) return {};

        std::string out(static_cast<size_t>(size), '\0');
        if (WideCharToMultiByte(CP_UTF8, 0, wide.data(), chars, out.data(), size, nullptr, nullptr) <= 0)
            return {};
        return out;
    }

    inline std::filesystem::path resolve_from_module(const HMODULE module) {
        if (!module) return {};

        wchar_t path[MAX_PATH]{};
        if (GetModuleFileNameW(module, path, MAX_PATH) == 0)
            return {};

        const std::filesystem::path module_path(path);
        if (!module_path.has_parent_path())
            return {};

        const std::filesystem::path dir = module_path.parent_path();
        return is_system_directory(dir) ? std::filesystem::path{} : dir;
    }

    inline std::filesystem::path dll_directory_wide() {
        // Loaders that hide the DLL from the process' module list (manual
        // mapping, or LDR-entry unlinking done for anti-cheat evasion right
        // after LoadLibrary returns) make GetModuleFileNameW/GetModuleHandle*
        // permanently unable to resolve our own path. init() captures the
        // path synchronously during DLL_PROCESS_ATTACH, before any such
        // hiding can happen, so prefer that cached value.
        if (const std::filesystem::path& cached = cached_dll_directory(); !cached.empty())
            return cached;

        if (const std::filesystem::path from_init = resolve_from_module(dll_handle()); !from_init.empty())
            return from_init;

        if (const std::filesystem::path from_name = resolve_from_module(GetModuleHandleW(L"TarkovAddons.dll"));
            !from_name.empty())
            return from_name;

        HMODULE from_address = nullptr;
        if (GetModuleHandleExW(
                GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                reinterpret_cast<LPCWSTR>(&dll_directory_wide), &from_address))
        {
            if (const std::filesystem::path from_addr = resolve_from_module(from_address); !from_addr.empty())
                return from_addr;
        }

        return {};
    }

    inline void init(const HMODULE module) {
        dll_handle() = module;
        // Resolve and cache the on-disk directory now, while the module is
        // still a normal, LDR-registered module. See dll_directory_wide().
        cached_dll_directory() = resolve_from_module(module);
    }

    inline std::string dll_directory_utf8() {
        return wide_to_utf8(dll_directory_wide().wstring());
    }

    // ------------------------------------------------------------------------
    //  THE ta/ DATA DIRECTORY
    // ------------------------------------------------------------------------
    //  The deployment looks like this:
    //
    //      <deploy>\
    //          TarkovAddons.dll
    //          TarkovLauncherBypass.dll
    //          vk_swiftshader.dll
    //          ta\
    //              compatibility\profiles\...   per-build IL2CPP manifest
    //              launcher.cfg                 shared config
    //              offsets.cfg                  legacy IL2CPP fallback
    //              patterns.cfg                 signature overrides
    //              lang\*.json                  fallback translations
    //              maps\*.json|*.svg            fallback minimap assets
    //              configs\<config>             user settings
    //              tarkov_prices.json           item price cache
    //
    //  The three DLLs sit at the top and everything they read or write lives
    //  in ONE obvious folder. Uninstall is deleting the deployment folder, and
    //  the config is findable by anyone: it is next to the DLL.
    //
    //  WHY CONFIGS GET THEIR OWN SUBDIRECTORY: ta/ mixes shipped read-only
    //  data (launcher.cfg, offsets.cfg, patterns.cfg, the compatibility
    //  manifests) with data rewritten at runtime. The user's settings are the
    //  one file here a user may want to find, copy, diff or restore, and
    //  burying it among the shipped files makes it easy to mistake for
    //  something the mod owns and replaces on update. configs/ separates
    //  "yours" from "ours" the same way ta/ separates data from the DLLs, and
    //  it makes "back up your settings" a single folder.
    //
    //  WHY ta/ RATHER THAN THE DLL FOLDER ITSELF: keeping generated, user and
    //  read-only data out of the folder the launcher writes into means a
    //  re-deploy or repair that replaces the DLL does not have to guess which
    //  other files are the user's and must be preserved.
    //
    //  COMPATIBILITY: data_directory_wide() falls back to the DLL directory
    //  when ta/ does not exist, so an existing deployment that has never seen
    //  this layout keeps behaving exactly as before. `deploy.py install` creates
    //  ta/ and offers to move the old files in, so deployments converge without
    //  anyone reinstalling. It also offers to move a config that is already
    //  sitting directly in ta/ into ta/configs/, so a 3.2 install that has run
    //  once does not silently reset to defaults when this layout lands. That step
    //  is tools/migrate_legacy.py, and it asks before it acts.
    // ------------------------------------------------------------------------

    inline constexpr const wchar_t* kDataDirectoryName = L"ta";

    // Subdirectory of ta/ holding the user's own settings. See the layout note
    // above for why this is not just another file in ta/.
    inline constexpr const wchar_t* kConfigSubdirectoryName = L"configs";

    inline std::filesystem::path data_directory_wide() {
        const std::filesystem::path dll_dir = dll_directory_wide();
        if (dll_dir.empty())
            return {};

        const std::filesystem::path candidate = dll_dir / kDataDirectoryName;
        std::error_code ec;
        if (std::filesystem::is_directory(candidate, ec))
            return candidate;

        // No ta/ yet: behave exactly as the previous layout did.
        return dll_dir;
    }

    // For writes. Creates ta/ if it is missing.
    inline std::filesystem::path ensure_data_directory_wide() {
        const std::filesystem::path dll_dir = dll_directory_wide();
        if (dll_dir.empty())
            return {};

        const std::filesystem::path candidate = dll_dir / kDataDirectoryName;
        std::error_code ec;
        if (std::filesystem::is_directory(candidate, ec))
            return candidate;

        std::filesystem::create_directories(candidate, ec);
        if (ec)
            return dll_dir;  // not writable; fall back rather than lose the write
        return candidate;
    }

    // UTF-8 -> wide, for turning a runtime string into a filesystem::path.
    // This used to be a static inside i18n.cpp's anonymous namespace, so every
    // other translation unit that needed a path from a string had no way to
    // build one.
    inline std::filesystem::path path_from_utf8(const std::string& utf8) {
        if (utf8.empty())
            return {};

        const int wide_len = MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), -1, nullptr, 0);
        if (wide_len <= 1)
            return {};

        std::wstring wide(static_cast<size_t>(wide_len - 1), L'\0');
        MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), -1, wide.data(), wide_len);
        return std::filesystem::path(wide);
    }

    inline std::string data_directory_utf8() {
        return wide_to_utf8(data_directory_wide().wstring());
    }

    // Same, but creating ta/ if it is missing. Use this for anything WRITTEN.
    inline std::string ensure_data_directory_utf8() {
        return wide_to_utf8(ensure_data_directory_wide().wstring());
    }

    // ------------------------------------------------------------------------
    //  THE ta/configs/ DIRECTORY -- the user's own settings
    // ------------------------------------------------------------------------
    //  This creates the subdirectory, so it is the accessor to use for both
    //  reading and writing; there is deliberately no read-only variant. A
    //  separate non-creating getter would be misleading here: the whole point
    //  is that reads and writes agree on one location, and splitting them is
    //  how a save ends up somewhere the load does not look.
    //
    //  If ta/ itself could not be created, this returns ta/'s own fallback (the
    //  DLL directory) rather than scattering a configs/ next to the DLLs. That
    //  keeps the pre-3.2 flat behaviour, so the write still lands somewhere
    //  findable and ConfigModule's legacy path still finds the old file.
    // ------------------------------------------------------------------------
    inline std::filesystem::path ensure_config_directory_wide() {
        const std::filesystem::path data_dir = ensure_data_directory_wide();
        if (data_dir.empty())
            return {};

        const std::filesystem::path candidate = data_dir / kConfigSubdirectoryName;
        std::error_code ec;
        if (std::filesystem::is_directory(candidate, ec))
            return candidate;

        if (data_dir == dll_directory_wide())
            return data_dir;

        std::filesystem::create_directories(candidate, ec);
        if (ec)
            return data_dir;  // not writable; fall back rather than lose the write
        return candidate;
    }

    // ------------------------------------------------------------------------
    //  THE CHAMS ASSET BUNDLE
    // ------------------------------------------------------------------------
    //  Unity's AssetBundle.LoadFromFileAsync takes a PATH, so the bundle has to
    //  exist as a real file on disk before it is handed over, and it is deleted
    //  again once the load completes. It is therefore a transient working file,
    //  not user data -- but it did live at %APPDATA%\TarkovAddons\tarkovutils,
    //  which was the last remaining holdout on the pre-3.2 layout and the one
    //  piece of mod data that never moved into ta/.
    //
    //  It now lives at ta\chams\tarkovutils beside everything else. That matters
    //  beyond tidiness: the pre-3.2 import treats any file in the legacy
    //  %APPDATA% folder it does not recognise as a user CONFIG, so the bundle was
    //  being picked up and filed under ta\configs\ on the next launch. A transient
    //  binary the loader rewrites and deletes must never be mistaken for a
    //  settings file. That import now lives in tools/migrate_legacy.py, which
    //  carries the exclusion list and the reason it is a whitelist.
    //
    //  Returns empty when ta/ cannot be created; callers must treat that as
    //  "chams unavailable" rather than falling back to %APPDATA%, because
    //  writing to a profile folder is exactly the behaviour being removed.
    inline std::string chams_bundle_path() {
        const std::filesystem::path data_dir = ensure_data_directory_wide();
        if (data_dir.empty())
            return {};

        std::error_code ec;
        const std::filesystem::path dir = data_dir / "chams";
        std::filesystem::create_directories(dir, ec);

        return (dir / "tarkovutils").string();
    }
} // namespace module_paths