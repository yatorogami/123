#!/usr/bin/env python3
"""Audit: is every config-value pointer in a module header actually constructed?

    python tools/audit_config_pointers.py            # all modules
    python tools/audit_config_pointers.py Aimbot     # just matching headers

Exit 0 = clean, 1 = at least one uninitialised pointer.

WHY THIS EXISTS

On 2026-10-03 12:38:03 the game died with ACCESS_VIOLATION, READ of 0x50, at
AimbotModule::draw_overlay+0xCA on the render thread:

    mov  rax, qword ptr [rsi + 0xA0]   ; this->show_cone
    cmp  byte ptr [rax + 0x50], r13b   ; <-- fault: show_cone was never created

`show_cone` was declared in module/impl/AimbotModule.h, documented, dereferenced
in draw_overlay, and its i18n key was already in all 19 lang/*.json -- but the
constructor's member-init list never assigned it. With no default member
initializer it held INDETERMINATE memory, so this was undefined behaviour, not
merely a null check that was missing.

The reason it survived review is that nothing about it looks wrong in review. The
declaration is documented, the use site is two lines above a null-guarded helper,
the feature has a translation string, and the module logs "done: Aimbot" at boot.
The only evidence that it was ever wrong was a crash, and the crash probe had
been killing the process before it could report -- see AGENTS_TODO.md.

That is the same shape as the hook_method trap in AGENTS_TODO.md 0 and the
duplicate "Info" config id in 3.7: a mistake that is easy to make and invisible
until it is expensive. This is the cheap mechanical check for it.

WHAT IT CHECKS, AND WHAT IT DOES NOT

For each module/impl/*.h it collects the raw config-value pointers
(`SelectValue *`, `CheckboxValue *`, `SectionValue *`, ... - anything ending in
Value or Config) and asserts each one appears as `name(conf(` in the matching
.cpp, which is the shape every constructor in this codebase uses.

It is a text check, deliberately. It will not catch a value assigned somewhere
other than the init list, and it will not catch a value that is constructed but
later overwritten with something invalid. It catches the specific, twice-seen
failure of declaring one and forgetting it, across all 332 config pointers in
the 26 module headers.
"""

import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent / "TarkovAddons" / "module" / "impl"

# `Type *name;` or `Type *name = nullptr;` where Type looks like a config value.
MEMBER = re.compile(
    r"^\s*(?:static\s+)?(?:const\s+)?[A-Z]\w*(?:Value|Config)\s*\*\s*(\w+)\s*(?:=\s*nullptr\s*)?;\s*$"
)
# Every constructor in this codebase registers values as `name(conf(new T(...)))`.
CONSTRUCTED = re.compile(r"\b\w+\s*\(\s*conf\s*\(")


def main(argv):
    wanted = [a.lower() for a in argv[1:]]
    headers = sorted(ROOT.glob("*.h"))
    if not ROOT.is_dir():
        print(f"FAIL -- module/impl not found at {ROOT}", file=sys.stderr)
        return 2
    if wanted:
        headers = [h for h in headers if any(w in h.name.lower() for w in wanted)]
        if not headers:
            print(f"no module header matched {argv[1:]}", file=sys.stderr)
            return 2

    bad = []
    total = 0
    for header in headers:
        members = {
            m.group(1)
            for m in (MEMBER.match(line) for line in header.read_text(errors="replace").splitlines())
            if m
        }
        if not members:
            continue
        total += len(members)

        cpp = header.with_suffix(".cpp")
        if not cpp.exists():
            bad.append((header.name, sorted(members), "no matching .cpp to check"))
            continue

        text = cpp.read_text(errors="replace")
        missing = sorted(
            m for m in members
            if not re.search(r"\b" + re.escape(m) + r"\s*\(\s*conf\s*\(", text)
        )
        if missing:
            bad.append((header.name, missing, "not in the constructor init list"))

    print(f"checked {total} config pointer(s) across {len(headers)} module header(s)\n")

    if total == 0:
        # A checker that reports success because it looked at nothing is the
        # exact failure this file exists to prevent, so it is treated as an
        # error rather than a pass. It has already happened once: run from a
        # copied location, the resolved ROOT pointed somewhere empty and this
        # printed a clean bill of health for zero pointers.
        print("FAIL -- nothing was checked. The module/impl path did not resolve,\n"
              "       so this is not a pass.", file=sys.stderr)
        return 2

    if not bad:
        print("OK -- every config pointer in every module header is constructed")
        return 0

    print("FAIL -- declared but never constructed:\n")
    for name, members, why in bad:
        print(f"  {name}")
        for m in members:
            print(f"      {m}   ({why})")
        print()
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))