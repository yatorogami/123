"""Tests for tools/migrate_legacy.py -- the pre-3.2 import that used to run
inside the DLL.

The point of these tests is not coverage for its own sake. It is that the C++
version could only be tested by redirecting the **ambient** %APPDATA%, and
WORKFLOW.md records what that cost: a harness bug once moved 23 real user files,
because `_dupenv_s` reads the CRT's copy of the environment and
`SetEnvironmentVariableW` does not redirect it, so the harness read back the real
value, believed its redirect had worked, and migrated the user's real profile.

Every test here passes the roots in as arguments. There is no environment to
corrupt, so that entire class of accident is not possible rather than guarded
against. If someone later reintroduces an ambient lookup, these tests should be
the thing that notices.

Run: pytest tools/tests
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import migrate_legacy as ml  # noqa: E402


# ---------------------------------------------------------------------------
#  Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def roots(tmp_path: Path) -> tuple[Path, Path]:
    deploy = tmp_path / "BsgLauncher"
    legacy = tmp_path / "appdata" / "TarkovAddons"
    deploy.mkdir(parents=True)
    legacy.mkdir(parents=True)
    return legacy, deploy


def write(path: Path, body: str = "x") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(body, encoding="utf-8")
    return path


def names(plan: ml.Plan, kind: str) -> set[str]:
    return {a.src.name for a in plan.actions if a.kind == kind}


def dsts(plan: ml.Plan, kind: str) -> set[Path]:
    return {a.dst for a in plan.actions if a.kind == kind and a.dst is not None}


# ---------------------------------------------------------------------------
#  The two whitelists. These are load-bearing: a user's settings file mistaken
#  for shipped data is the failure this whole mechanism exists to prevent, so
#  every entry is pinned individually rather than by count.
# ---------------------------------------------------------------------------

class TestKnownTaRootData:
    @pytest.mark.parametrize("name", [
        "launcher.cfg",
        "offsets.cfg",
        "patterns.cfg",
        "tarkov_prices.json",
        "TarkovAddons Reloaded Background.png",
    ])
    def test_shipped_data_is_recognised(self, name: str) -> None:
        # The PNG is the one that is easy to drop: gui/menu/menu.cpp falls back to
        # data_directory_wide()/"TarkovAddons Reloaded Background.png", so moving
        # it into configs/ silently breaks the background.
        assert name in ml.KNOWN_TA_ROOT_DATA

    @pytest.mark.parametrize("name", [
        "config_1", "config_2", "my_profile", "anything.cfg", "notes.txt",
    ])
    def test_a_user_config_is_not_shipped_data(self, name: str) -> None:
        assert name not in ml.KNOWN_TA_ROOT_DATA

    def test_the_list_is_exactly_what_the_cpp_version_had(self) -> None:
        # Reproduced from util/data_migration.h. If this fails, the C++ and the
        # Python have diverged and a file could be classified differently by each.
        assert ml.KNOWN_TA_ROOT_DATA == frozenset({
            "launcher.cfg", "offsets.cfg", "patterns.cfg",
            "tarkov_prices.json", "TarkovAddons Reloaded Background.png",
        })


class TestKnownLegacyData:
    @pytest.mark.parametrize("name", ["tarkov_prices.json", "tarkovutils"])
    def test_recognised(self, name: str) -> None:
        assert name in ml.KNOWN_LEGACY_DATA

    @pytest.mark.parametrize("name", ["config_1", "my_profile", "settings.cfg"])
    def test_a_user_config_is_not_in_it(self, name: str) -> None:
        assert name not in ml.KNOWN_LEGACY_DATA

    def test_exactly_what_the_cpp_version_had(self) -> None:
        assert ml.KNOWN_LEGACY_DATA == frozenset({"tarkov_prices.json", "tarkovutils"})


# ---------------------------------------------------------------------------
#  survey: read-only, and correct about where things go
# ---------------------------------------------------------------------------

class TestSurveyIsReadOnly:
    def test_changes_nothing_on_disk(self, roots: tuple[Path, Path]) -> None:
        legacy, deploy = roots
        write(legacy / "config_1", "settings")
        write(legacy / "tarkov_prices.json", "{}")
        write(deploy / "ta" / "config_9", "already here")

        def snapshot() -> dict[str, tuple[int, float]]:
            out = {}
            for base in (legacy, deploy):
                for p in sorted(base.rglob("*")):
                    if p.is_file():
                        st = p.stat()
                        out[str(p)] = (st.st_size, st.st_mtime)
            return out

        before = snapshot()
        ml.survey(legacy, deploy)
        assert snapshot() == before


class TestSurveyClassification:
    def test_legacy_configs_go_to_configs_not_ta_root(self, roots: tuple[Path, Path]) -> None:
        legacy, deploy = roots
        write(legacy / "config_1")
        write(legacy / "config_2")
        plan = ml.survey(legacy, deploy)
        assert names(plan, "config") == {"config_1", "config_2"}
        assert dsts(plan, "config") == {
            deploy / "ta" / "configs" / "config_1",
            deploy / "ta" / "configs" / "config_2",
        }

    def test_price_cache_goes_to_ta_root_not_configs(self, roots: tuple[Path, Path]) -> None:
        # It is a cache, not a setting. Filing it under configs/ would leave a
        # machine-generated file among the user's settings.
        legacy, deploy = roots
        write(legacy / "tarkov_prices.json", '{"a":1}')
        plan = ml.survey(legacy, deploy)
        assert dsts(plan, "data") == {deploy / "ta" / "tarkov_prices.json"}

    def test_chams_bundle_is_debris_not_a_config(self, roots: tuple[Path, Path]) -> None:
        # The bug this fixes: tarkovutils was not on the whitelist, so the sweep
        # filed an 18 KB binary under ta\configs\ as if it were a settings file.
        legacy, deploy = roots
        write(legacy / "tarkovutils", "bundle")
        plan = ml.survey(legacy, deploy)
        assert names(plan, "config") == set()
        assert names(plan, "debris") == {"tarkovutils"}

    def test_json_and_svg_adopted_other_suffixes_left(self, roots: tuple[Path, Path]) -> None:
        legacy, deploy = roots
        for name in ("en.json", "de.json", "logo.svg", "notes.txt", "x.cfg", "y.dat"):
            write(legacy / "lang" / name)
        write(legacy / "lang" / "subdir", "")  # a directory, not a file
        plan = ml.survey(legacy, deploy)
        got = {a.src.name for a in plan.actions if a.src.parent.name == "lang"}
        assert got == {"en.json", "de.json", "logo.svg"}

    def test_shipped_config_beside_the_dll_is_imported(self, roots: tuple[Path, Path]) -> None:
        legacy, deploy = roots
        for name in ml.BESIDE_DLL:
            write(deploy / name)
        plan = ml.survey(legacy, deploy)
        assert dsts(plan, "data") == {deploy / "ta" / n for n in ml.BESIDE_DLL}

    def test_config_stranded_in_ta_root_is_rescued(self, roots: tuple[Path, Path]) -> None:
        # Without this the move to ta/configs/ looks like "no config found" and
        # silently resets the user to defaults -- the worst failure for a settings
        # file, because it looks like the mod losing your config.
        legacy, deploy = roots
        write(deploy / "ta" / "config_3")
        plan = ml.survey(legacy, deploy)
        assert names(plan, "ta-root-config") == {"config_3"}
        assert dsts(plan, "ta-root-config") == {deploy / "ta" / "configs" / "config_3"}

    def test_shipped_data_in_ta_root_is_not_rescued(self, roots: tuple[Path, Path]) -> None:
        legacy, deploy = roots
        for name in ml.KNOWN_TA_ROOT_DATA:
            write(deploy / "ta" / name)
        plan = ml.survey(legacy, deploy)
        assert names(plan, "ta-root-config") == set()
        for name in ml.KNOWN_TA_ROOT_DATA:
            assert name in {p.name for p, _ in plan.skipped}

    def test_never_overwrites_an_existing_target(self, roots: tuple[Path, Path]) -> None:
        # The C++ rationale: the stale legacy copy stays put so nothing is lost if
        # the ta/ copy turns out to be the damaged one.
        legacy, deploy = roots
        write(legacy / "config_1", "legacy")
        write(deploy / "ta" / "configs" / "config_1", "newer")
        plan = ml.survey(legacy, deploy)
        assert names(plan, "config") == set()
        assert any(p.name == "config_1" for p, _ in plan.skipped)

    def test_missing_roots_give_an_empty_plan_not_an_error(self, tmp_path: Path) -> None:
        plan = ml.survey(tmp_path / "nope", tmp_path / "also-nope")
        assert not plan
        assert plan.describe() == ["No pre-3.2 data found. Nothing to import."]

    def test_none_roots_give_an_empty_plan(self, roots: tuple[Path, Path]) -> None:
        assert not ml.survey(None, None)


# ---------------------------------------------------------------------------
#  apply: copy, verify, then delete
# ---------------------------------------------------------------------------

class TestApply:
    def test_moves_content_and_removes_the_source(self, roots: tuple[Path, Path]) -> None:
        legacy, deploy = roots
        write(legacy / "config_1", "my actual settings")
        plan = ml.survey(legacy, deploy)
        result = ml.apply(plan)
        assert result.ok(), result.failed
        assert (deploy / "ta" / "configs" / "config_1").read_text() == "my actual settings"
        assert not (legacy / "config_1").exists()

    def test_is_idempotent(self, roots: tuple[Path, Path]) -> None:
        legacy, deploy = roots
        write(legacy / "config_1", "settings")
        write(legacy / "tarkov_prices.json", "{}")
        write(legacy / "tarkovutils", "debris")
        first = ml.apply(ml.survey(legacy, deploy))
        assert first.ok(), first.failed
        second = ml.apply(ml.survey(legacy, deploy))
        assert not second.moved and not second.deleted

    def test_legacy_directory_is_never_deleted(self, roots: tuple[Path, Path]) -> None:
        legacy, deploy = roots
        write(legacy / "config_1")
        # A plain file in the legacy root IS swept -- "not known shipped data" is
        # the predicate, so a .txt counts as a user setting. A subdirectory is not
        # swept, so it is what proves the directory itself survives.
        (legacy / "some_dir").mkdir()
        ml.apply(ml.survey(legacy, deploy))
        assert legacy.is_dir()
        assert (legacy / "some_dir").is_dir()

    def test_debris_is_deleted_not_copied(self, roots: tuple[Path, Path]) -> None:
        legacy, deploy = roots
        write(legacy / "tarkovutils", "bundle")
        result = ml.apply(ml.survey(legacy, deploy))
        assert not (legacy / "tarkovutils").exists()
        # and specifically not anywhere under ta/
        assert not list((deploy / "ta").rglob("tarkovutils"))
        assert [p.name for p in result.deleted] == ["tarkovutils"]

    def test_dry_run_moves_nothing(self, roots: tuple[Path, Path]) -> None:
        legacy, deploy = roots
        write(legacy / "config_1", "settings")
        write(legacy / "tarkovutils", "debris")
        result = ml.apply(ml.survey(legacy, deploy), dry_run=True)
        assert not result.moved and not result.deleted
        assert (legacy / "config_1").exists()
        assert (legacy / "tarkovutils").exists()
        assert not (deploy / "ta").exists()

    def test_content_survives_a_copy_verbatim(self, roots: tuple[Path, Path]) -> None:
        # Binary and awkward bytes, not just text: a lossy copy here would silently
        # truncate a settings file or an asset.
        legacy, deploy = roots
        blob = bytes(range(256)) * 64
        (legacy / "lang").mkdir(parents=True, exist_ok=True)
        (legacy / "lang" / "blob.json").write_bytes(blob)
        result = ml.apply(ml.survey(legacy, deploy))
        assert result.ok(), result.failed
        assert (deploy / "ta" / "lang" / "blob.json").read_bytes() == blob

    def test_mtime_is_preserved(self, roots: tuple[Path, Path]) -> None:
        legacy, deploy = roots
        src = write(legacy / "config_1", "settings")
        os.utime(src, (1_600_000_000, 1_600_000_000))
        ml.apply(ml.survey(legacy, deploy))
        dst = deploy / "ta" / "configs" / "config_1"
        assert int(dst.stat().st_mtime) == 1_600_000_000

    def test_a_failed_delete_leaves_a_duplicate_not_a_loss(
        self, roots: tuple[Path, Path], monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # The ordering that matters: the copy is verified before the source is
        # removed, so the worst case is two copies rather than none.
        legacy, deploy = roots
        write(legacy / "config_1", "precious")

        real_unlink = Path.unlink

        def refuse_self(self: Path, *a, **k):
            if self.name == "config_1" and self.parent == legacy:
                raise PermissionError("held open by something")
            return real_unlink(self, *a, **k)

        monkeypatch.setattr(Path, "unlink", refuse_self)
        result = ml.apply(ml.survey(legacy, deploy))
        dst = deploy / "ta" / "configs" / "config_1"
        assert dst.exists() and dst.read_text() == "precious"
        assert (legacy / "config_1").read_text() == "precious"
        assert not result.ok()
        assert any("could not remove" in why for _, why in result.failed)

    def test_a_failed_copy_leaves_the_source_alone(
        self, roots: tuple[Path, Path], monkeypatch: pytest.MonkeyPatch
    ) -> None:
        legacy, deploy = roots
        write(legacy / "config_1", "precious")

        def boom(src, dst, **k):
            raise OSError("disk full")

        monkeypatch.setattr(ml.shutil, "copy2", boom)
        result = ml.apply(ml.survey(legacy, deploy))
        assert (legacy / "config_1").read_text() == "precious"
        assert not result.ok()


# ---------------------------------------------------------------------------
#  The scenario the C++ version could not test safely, now trivially testable
# ---------------------------------------------------------------------------

class TestFullScenario:
    def test_end_to_end_leaves_the_expected_tree(self, roots: tuple[Path, Path]) -> None:
        legacy, deploy = roots
        write(legacy / "config_1", "one")
        write(legacy / "config_2", "two")
        write(legacy / "tarkov_prices.json", '{"x":1}')
        write(legacy / "tarkovutils", "debris")
        write(legacy / "lang" / "en.json", "{}")
        write(legacy / "maps" / "tile.json", "{}")
        write(deploy / "launcher.cfg", "launcher")
        write(deploy / "offsets.cfg", "offsets")
        write(deploy / "patterns.cfg", "patterns")
        write(deploy / "lang" / "fr.json", "{}")
        write(deploy / "ta" / "config_3", "stranded")

        result = ml.apply(ml.survey(legacy, deploy))
        assert result.ok(), result.failed

        ta = deploy / "ta"
        for rel in ("configs/config_1", "configs/config_2", "configs/config_3",
                    "tarkov_prices.json", "lang/en.json", "lang/fr.json",
                    "maps/tile.json", "launcher.cfg", "offsets.cfg", "patterns.cfg"):
            assert (ta / rel).is_file(), f"missing {rel}"
        assert not (legacy / "tarkovutils").exists()
        assert not (ta / "configs" / "tarkovutils").exists()
        assert legacy.is_dir()

    def test_no_ambient_environment_is_consulted(self, roots: tuple[Path, Path],
                                                 monkeypatch: pytest.MonkeyPatch) -> None:
        """The regression guard for why this moved out of the DLL.

        The C++ version resolved the legacy folder from %APPDATA%, which is what
        made the 23-real-files incident possible. If anything in this module ever
        reads an environment variable to find a root, this fails -- and the fix is
        to make the root an argument again, not to add a guard.
        """
        legacy, deploy = roots
        write(legacy / "config_1", "settings")
        write(deploy / "ta" / "shipped.cfg", "data")

        def explode(name: str):
            real = os.environ.get

            def spy(key, default=None):
                if key.upper() in ("APPDATA", "LOCALAPPDATA", "USERPROFILE"):
                    raise AssertionError(
                        f"migrate_legacy read ${key}; the roots must stay arguments")
                return real(key, default)

            return spy

        for var in ("APPDATA", "LOCALAPPDATA", "USERPROFILE"):
            monkeypatch.setenv(var, str(legacy.parent))
        monkeypatch.setattr(os.environ, "get", staticmethod(explode("x")), raising=False)

        plan = ml.survey(legacy, deploy)
        assert names(plan, "config") == {"config_1"}
        assert ml.apply(plan).ok()


class TestDescribe:
    def test_empty_plan_says_so(self, roots: tuple[Path, Path]) -> None:
        legacy, deploy = roots
        assert ml.survey(legacy, deploy).describe() == [
            "No pre-3.2 data found. Nothing to import."]

    def test_debris_is_labelled_as_a_deletion(self, roots: tuple[Path, Path]) -> None:
        # "will be DELETED" has to be visible in the summary, because it is the one
        # irreversible thing here and the C++ version did it silently.
        legacy, deploy = roots
        write(legacy / "tarkovutils", "debris")
        text = "\n".join(ml.survey(legacy, deploy).describe())
        assert "DELETED" in text
        assert "tarkovutils" in text

    def test_counts_are_grouped_by_kind(self, roots: tuple[Path, Path]) -> None:
        legacy, deploy = roots
        write(legacy / "config_1")
        write(legacy / "config_2")
        write(deploy / "launcher.cfg")
        counts = ml.survey(legacy, deploy).counts()
        assert counts["config"] == 2
        assert counts["data"] == 1
