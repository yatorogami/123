"""tools/map_icf.py -- the ICF reader must classify, not just count.

The failure mode of this tool is not crashing. It is reporting a clean bill of
health because it parsed nothing, and -- worse -- reporting a confident number
computed from the wrong bucket. A first version of the std-library filter
matched `std@@` anywhere in the mangled name, which hid every first-party
method that merely TAKES a std::string. The tool still ran, still printed a
plausible total, and was wrong.

So every classification rule below is written as a pair: a name that must be
classified one way, and a name that differs only in the detail that matters and
must be classified the other way.
"""

import json
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import map_icf  # noqa: E402

REPO = Path(__file__).resolve().parents[2]


# ---------------------------------------------------------------------------
# classify() -- the entity/scope boundary
# ---------------------------------------------------------------------------


def test_first_party_method_taking_std_string_is_not_stdlib():
    """The regression that motivated the entity/scope split.

    This is real code from the real map: `IntSliderEditableValue::set` and
    `IntTextboxValue::set` are a `dup_scan` clone pair. `std@@` appears in the
    *parameter type*. Classifying this as stdlib deleted a genuine finding from
    the report while leaving the tool exit 0.
    """
    name = ("?set@IntSliderEditableValue@@UEAAXAEBV?$basic_string@DU?$char_traits"
            "@D@std@@V?$allocator@D@2@@std@@@Z")
    assert map_icf.classify(name) == "first_party", (
        "a first-party method taking a std::string was classified as library"
    )


def test_std_helper_is_stdlib():
    """Negative control for the case above: same `std@@`, library entity."""
    name = "?_Xlength@?$vector@DV?$allocator@D@std@@@std@@CAXXZ"
    assert map_icf.classify(name) == "stdlib"


def test_std_function_target_is_stdlib():
    """Negative control: library code, but the entity slot holds a struct name.

    `?_Get@?$_Func_impl_no_alloc@...std@@` -- splitting on the first `@` yields
    entity `_Get`, which is NOT a library pattern. Only the scope test catches
    it, which is why both rules exist.
    """
    name = ("?_Get@?$_Func_impl_no_alloc@P6A?AV?$basic_string@DU?$char_traits@D"
            "@std@@V?$allocator@D@2@@std@@AEBV1@Z@std@@@3@std@@@BEPBDXZ@std@@@3Q")
    assert map_icf.classify(name) == "stdlib"


def test_nlohmann_detail_is_stdlib():
    assert map_icf.classify(
        "??_Gexception@detail@json_abi_v3_12_0@nlohmann@@UEAAPEAXI@Z"
    ) == "stdlib"


def test_imgui_vendored_type_is_stdlib():
    assert map_icf.classify("??1?$ImVector@D@@QEAA@XZ") == "stdlib"


def test_plain_first_party_function_is_first_party():
    """Positive control -- the classifier is not simply saying 'stdlib'."""
    assert map_icf.classify(
        "?draw_menu_extra_before_values@ExperienceEditorModule@@UEBA_NXZ"
    ) == "first_party"
    assert map_icf.classify("DllMain") == "first_party"


def test_generated_symbols_are_generated():
    """Unwind records and compiler thunks are never human-written code.

    The largest single group in the real map is 1,201 `$unwind$` symbols. If
    these are not excluded the tool's headline is off by two orders of
    magnitude and means nothing.
    """
    for n in (
        "$unwind$?dtor$0@?0??build_route@lens@optics@@YA_NPEAUIl2CppObject@@",
        "?dtor$33@?0??init@AimbotModule@@UEAAXXZ@4HA",
        "??_R0?AV?$basic_string@DU?$char_traits@D@std@@@std@@@8",
        "??_7?AVFoo@@6B@",
        "$cppxdata$??$hook_method@P6APEAXPEAXE@ZP6APEAX0E@Z@il2utils@@YAXPEB",
        "$LN112",   # line-number label; not a function, must never be ranked
    ):
        assert map_icf.classify(n) == "generated", n


def test_a_first_party_name_starting_with_dtors_prefix_is_not_generated():
    """Boundary check: `?dtor` at the START is generated, elsewhere is not."""
    assert map_icf.classify("?dtor$0@?0??init@AimbotModule@@UEAAXXZ@4HA") == "generated"
    assert map_icf.classify("?cleanup_handler@SomeModule@@UEAAXXZ") == "first_party"


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------

MAP_HEADER = """ TarkovAddons

 Timestamp is 6ac9fc67 (Sat Oct 10 11:50:47 2026)

 Preferred load address is 0000000180000000

 Start         Length     Name                   Class
 0001:00000000 0003ddc0H .text$di                CODE

  Address         Publics by Value              Rva+Base               Lib:Object

 0000:00000000       __AbsoluteZero             0000000000000000     <absolute>
 0001:00059380       DllMain                    000000018005a380 f   dllmain.obj
 0001:0003ddc0       ?find_export@scan@@YA?AUEx@PEBD@Z 000000018003ddc0 f i  scan.obj
 0001:00065ea0       ??_R0?AVFoo@@6B@            0000000180065ea0 f i * CIL foo *:* CIL bar

 entry point at        0001:002a2760

 Static symbols

 0000:ff785000       .debug$S                   0000000180000000     ucrt:api-ms-win-crt-x.dll
 0001:0005a400       ?mine@EspModule@@UEAAXXZ   000000018005a400 f i  EspModule.obj
 0001:0005a400       ?twin@QuestModule@@UEAAXXZ 000000018005a400 f i  QuestModule.obj
 0001:0005a500       ?lonely@AimbotModule@@UEAAXXZ 000000018005a500 f i AimbotModule.obj
"""


def write_map(tmp_path, text=MAP_HEADER, name="x.map"):
    p = tmp_path / name
    p.write_text(text, encoding="utf-8")
    return p


def test_four_line_shapes_all_parse(tmp_path):
    """All four shapes measured in the real 44,936-line Prod map.

    The 12-field COMDAT row is the one that a "last field is the object" parser
    gets wrong: there the *library* precedes `*:*` and the object follows it.
    """
    syms, skipped = map_icf.parse_map(write_map(tmp_path))
    flat = {s["object"] for v in syms.values() for s in v}
    assert {"dllmain.obj", "scan.obj", "EspModule.obj", "QuestModule.obj",
            "AimbotModule.obj"} <= flat, flat
    # the COMDAT row's object is `bar` (the CIL module), not `foo` (the library)
    assert "bar" in flat, flat
    assert "foo" not in flat, flat


def test_unplaced_and_absolute_are_excluded(tmp_path):
    """Counting `<absolute>` would invent a fold group at address 0."""
    syms, skipped = map_icf.parse_map(write_map(tmp_path))
    names = {s["name"] for v in syms.values() for s in v}
    assert "__AbsoluteZero" not in names
    assert 0 not in syms, "address 0 must never become a fold group"
    assert skipped["unplaced / <absolute> (no code)"] >= 1


def test_crt_imports_are_skipped_and_counted(tmp_path):
    syms, skipped = map_icf.parse_map(write_map(tmp_path))
    assert any("ucrt" in r for r in skipped), skipped
    assert "api-ms-win-crt-x.dll" not in {s["name"] for v in syms.values() for s in v}


def test_symbol_in_two_sections_is_one_symbol(tmp_path):
    """The same (rva, name, object) appears in Publics and Static; it is one."""
    text = MAP_HEADER + " 0001:00059380       DllMain       000000018005a380 f i dllmain.obj\n"
    syms, _ = map_icf.parse_map(write_map(tmp_path, text))
    dllmain = [s for v in syms.values() for s in v if s["name"] == "DllMain"]
    assert len(dllmain) == 1, dllmain


def test_shared_address_is_detected_as_a_fold(tmp_path):
    syms, _ = map_icf.parse_map(write_map(tmp_path))
    groups = map_icf.build_groups(syms, 2, {"first_party"})
    rvas = {g["rva"] for g in groups}
    # 0x18005a400 holds ?mine@EspModule and ?twin@QuestModule
    assert "0x000000018005a400" in rvas, [g["rva"] for g in groups]


def test_a_lone_address_is_not_a_fold(tmp_path):
    """Negative control for the case above."""
    syms, _ = map_icf.parse_map(write_map(tmp_path))
    groups = map_icf.build_groups(syms, 2, {"first_party"})
    assert "0x000000018005a500" not in {g["rva"] for g in groups}


def test_filtering_cannot_manufacture_a_group(tmp_path):
    """Raising --min-symbols must never *create* a group.

    `build_groups` requires the surviving symbols alone to reach the
    threshold. A filter that removed symbols could otherwise leave a 2-symbol
    group reported at --min-symbols 5.
    """
    syms, _ = map_icf.parse_map(write_map(tmp_path))
    at2 = len(map_icf.build_groups(syms, 2, {"first_party"}))
    at5 = len(map_icf.build_groups(syms, 5, {"first_party"}))
    assert at5 <= at2, (at2, at5)
    for g in map_icf.build_groups(syms, 5, {"first_party"}):
        assert g["symbols"] >= 5, g


# ---------------------------------------------------------------------------
# Exit codes -- the "checked nothing" contract
# ---------------------------------------------------------------------------


def run(*args):
    return subprocess.run(
        [sys.executable, str(REPO / "tools" / "map_icf.py"), *[str(a) for a in args]],
        capture_output=True, text=True,
    )


def test_exit_2_when_no_map_exists(tmp_path):
    r = run("--map", tmp_path / "nope.map")
    assert r.returncode == 2, r.stdout + r.stderr
    assert "nothing was checked" in r.stderr.lower()


def test_exit_2_when_map_has_no_placed_symbols(tmp_path):
    """A map full of headers and `<absolute>` rows proves nothing."""
    p = write_map(tmp_path, " TarkovAddons\n\n Preferred load address is 0000000180000000\n")
    r = run("--map", p)
    assert r.returncode == 2, r.stdout + r.stderr
    assert "nothing was checked" in r.stderr.lower()


def test_exit_2_on_nonsense_min_symbols(tmp_path):
    p = write_map(tmp_path)
    r = run("--map", p, "--min-symbols", "1")
    assert r.returncode == 2, r.stdout + r.stderr


def test_exit_1_when_a_fold_is_found(tmp_path):
    r = run("--map", write_map(tmp_path))
    assert r.returncode == 1, r.stdout + r.stderr


def test_exit_0_when_nothing_folded(tmp_path):
    """A map where every symbol has its own address is clean, and must say so."""
    text = (" TarkovAddons\n\n 0001:0005a400       ?a@EspModule@@UEAAXXZ   "
            "000000018005a400 f i  EspModule.obj\n")
    r = run("--map", write_map(tmp_path, text))
    assert r.returncode == 0, r.stdout + r.stderr
    assert "OK" in r.stdout


def test_json_separates_the_kinds(tmp_path):
    r = run("--map", write_map(tmp_path), "--format", "json")
    assert r.returncode == 1, r.stdout + r.stderr
    payload = json.loads(r.stdout)
    assert payload["fold_groups"] >= 1
    assert payload["copies_saved"] >= 0
    assert set(payload["by_kind"]) <= {"generated", "stdlib", "first_party"}
    assert payload["filtered"] is True


def test_timestamp_header_is_reported(tmp_path):
    """A stale map beside a newer DLL is a real hazard; the header shows it."""
    p = write_map(tmp_path)
    assert "6ac9fc67" in map_icf.timestamp_of(p)


def test_the_intslider_clone_stays_visible_in_the_real_report():
    """The end-to-end version of the regression above.

    `IntSliderEditableValue::set` and `IntTextboxValue::set` are a real
    `dup_scan` clone pair that really does fold. Three separate filter bugs hid
    it during development -- a bare `std@@` match, an over-strict anchored
    scope, then an over-loose one. Asserting only on `classify()` would not
    have caught the last two, because they broke the *grouping*, not the label.
    """
    p = map_icf.find_default_map()
    if p is None:
        return
    syms, _ = map_icf.parse_map(p)
    target = None
    for rva, v in syms.items():
        objs = {s["object"] for s in v}
        if any("IntSliderEditableValue" in o for o in objs) and \
           any("IntTextboxValue" in o for o in objs):
            target = (rva, v)
            break
    assert target is not None, (
        "IntSliderEditableValue::set / IntTextboxValue::set no longer share an "
        "address -- either the map is from a different build or the parse broke"
    )
    assert all(s["kind"] == "first_party" for s in target[1]), [
        s["name"][:60] for s in target[1]
    ]
    reported = {g["rva"] for g in map_icf.build_groups(syms, 2, {"first_party"})}
    assert f"0x{target[0]:016x}" in reported, (
        "the clone folds but is absent from the default report -- a filter is "
        "hiding first-party code"
    )


# ---------------------------------------------------------------------------
# Agreement with the real tree
# ---------------------------------------------------------------------------


def test_it_agrees_with_a_real_map_when_one_exists():
    """Guards against the skip/classification rules quietly swallowing the tree.

    Skipped when no map is on disk -- the tool is allowed to be useless without
    a build, but it is not allowed to be wrong about what it did check.
    """
    p = map_icf.find_default_map()
    if p is None:
        return
    syms, skipped = map_icf.parse_map(p)
    total = sum(len(v) for v in syms.values())
    assert total > 10_000, f"only {total} placed symbols parsed from {p}"
    assert skipped, "nothing was skipped at all -- the skip rules are not applied"
    kinds = {s["kind"] for v in syms.values() for s in v}
    assert kinds == {"generated", "stdlib", "first_party"}, kinds


# ---------------------------------------------------------------------------
# The documented figures must be re-derivable, not remembered
# ---------------------------------------------------------------------------


def test_the_figures_quoted_in_the_docs_are_current():
    """A count printed in prose decays into a plausible lie.

    AGENTS.md and WORKFLOW.md both quote the folded-duplication totals, and
    during development they were wrong twice: first because the classification
    changed under them, then because `$LN<nnn>` line labels were being ranked
    as if they were functions. `test_doc_counts.py` exists for the same reason
    on the pytest count. This re-derives them from the tool instead.

    Skipped when no map is on disk.
    """
    p = map_icf.find_default_map()
    if p is None:
        return
    syms, _ = map_icf.parse_map(p)
    groups = map_icf.build_groups(syms, 2, {"first_party"})
    folded = sum(g["symbols"] for g in groups)
    saved = folded - len(groups)
    raw = map_icf.build_groups(syms, 2, {"generated", "stdlib", "first_party"})
    raw_folded = sum(g["symbols"] for g in raw)

    # Figures the tool actually produces, plus the two structural facts the
    # docs quote about the RAW view: the largest single group, and the count of
    # `$unwind$` symbols sharing one address (1,201 on this tree -- the fact
    # that motivates excluding them at all). Deriving rather than whitelisting
    # keeps the check honest when either changes.
    #
    # The `$unwind$` ADDRESS count is derived too, for a reason worth stating:
    # WORKFLOW.md used to say "across 277 addresses", and that figure was never
    # checked at all -- not because the check excluded it, but because NUMBER
    # below only matches comma-grouped integers and "277" has no comma, so it
    # sailed through every run. It was also wrong; the real count on this tree is
    # 1,992. Deriving it here rather than renumbering the prose below 1,000 is
    # what stops a figure from being true merely because of how it is formatted.
    unwind_syms = 0
    unwind_addrs = 0
    for v in syms.values():
        hits = len([s for s in v if s["name"].startswith("$unwind$")])
        if hits:
            unwind_syms += hits
            unwind_addrs += 1
    true_figures = {
        len(groups), folded, saved, raw_folded,
        len(raw), max((g["symbols"] for g in raw), default=0), unwind_syms,
        unwind_addrs,
    }

    # Scoped to the SENTENCES that make the claim. These docs legitimately
    # quote other comma-grouped counts -- test totals, file counts, skip counts
    # -- and a bare `**N,NNN**` sweep flagged three of them as stale
    # duplication figures. What must hold is that every number appearing in a
    # sentence naming a fold/duplication quantity is one the tool produces.
    #
    # Per-document and exact, because an earlier version searched all three as
    # a union and passed if a number appeared in ANY of them: corrupting
    # WORKFLOW.md's figure stayed green while AGENTS.md carried the same number.
    # That is what made the test unfailable, and the negative control found it.
    SENTENCE = re.compile(
        r"[^.]*?\b(?:fold(?:ed|ing|s)?|duplication|duplicated)\b[^.]*\.",
        re.IGNORECASE | re.DOTALL,
    )
    NUMBER = re.compile(r"\b(\d{1,3}(?:,\d{3})+)\b")

    for doc in ("WORKFLOW.md", "AGENTS.md", "tools/map_icf.py"):
        text = (REPO / doc).read_text(encoding="utf-8")
        claimed: set[int] = set()
        for sentence in SENTENCE.findall(text):
            claimed |= {int(m.group(1).replace(",", "")) for m in NUMBER.finditer(sentence)}
        # Also the tool's own docstring headline, which states the figures bare.
        if doc == "tools/map_icf.py":
            claimed |= {int(n) for n in re.findall(
                r"\*\*(\d{1,3}(?:,\d{3})+)[^*]*first-party", text)}
        stale = claimed - true_figures
        assert not stale, (
            f"{doc} states {sorted(stale)} in a sentence about duplication, but "
            f"the tool now produces groups={len(groups)} folded={folded} "
            f"saved={saved} raw_folded={raw_folded}"
        )

    # AND THE OTHER DIRECTION, which is the one that actually bites.
    #
    # A check that only validates figures it happens to find passes forever
    # while the figure is deleted outright -- which is exactly what the
    # negative control did: corrupting WORKFLOW.md to `999 groups` stayed green
    # because `999` never appeared in a matched sentence, so there was nothing
    # stale to find. The assertion has to be that the number is PRESENT.
    workflow = (REPO / "WORKFLOW.md").read_text(encoding="utf-8")
    assert f"**{len(groups)} groups, {folded} first-party symbols, {saved} copies the" \
        in workflow or f"{len(groups)} groups, {folded} first-party symbols" in workflow, (
        f"WORKFLOW.md no longer quotes the measured figures "
        f"({len(groups)} groups, {folded} first-party symbols, {saved} copies "
        f"the linker already removed). If the wording changed deliberately, "
        f"update this assertion -- do not just delete it."
    )
    # The raw half is NOT quoted as a figure, and that is now the claim to
    # defend. These three assertions used to require `raw_folded`, `unwind_syms`
    # and `unwind_addrs` to be PRESENT and CURRENT, which is the trap this
    # project has fallen into repeatedly: on 2026-10-15 the raw total read
    # 20,253, then 20,319, then 20,318 across three builds of near-identical
    # source, so the correct action after every build was to re-transcribe a
    # per-build reading into prose. It is a property of one `.map`, not of the
    # code -- the very thing the surrounding paragraph argues.
    #
    # What is worth pinning is the DECISION: the raw half is re-derived on demand
    # and never written down. A regression that re-quotes an exact raw total is
    # now caught here, which the old assertions could not do (they would have
    # demanded the number back).
    # Scoped to the PARAGRAPH, not the file. `map_icf.py --all` also appears in
    # the command listing a screen earlier, so a whole-file check for it passed
    # on an unrelated occurrence -- the negative control (delete the pointer from
    # this paragraph, leave the command list alone) stayed green, which is the
    # failure mode this suite exists to prevent.
    decision = re.search(
        r"\*\*The raw half is deliberately NOT quoted as a figure.*?(?=\n\n)",
        workflow,
        re.DOTALL,
    )
    assert decision, (
        "WORKFLOW.md no longer contains the paragraph that explains why the "
        "unfiltered total is described rather than quoted. Without it the "
        "omission reads as an oversight, and the numbers come back."
    )
    assert "map_icf.py --all" in decision.group(0), (
        "that paragraph must say how to re-derive the raw half "
        "(`map_icf.py --all`), or the reader is left with no way to get the "
        "number being argued about"
    )
    for banned in (f"{raw_folded:,}", f"{unwind_syms:,}"):
        assert banned not in workflow, (
            f"WORKFLOW.md quotes {banned} again. That is a reading of ONE .map "
            f"and it moves with every function added to the tree; the staleness "
            f"check above now produces raw_folded={raw_folded:,} and "
            f"unwind_syms={unwind_syms:,}, so this number is already a "
            f"different one from the last build. Describe it, do not transcribe "
            f"it."
        )


if __name__ == "__main__":  # pragma: no cover
    sys.exit(pytest_main())


def pytest_main():
    import pytest
    return pytest.main([__file__, "-v"])