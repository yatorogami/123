"""
Tests for tools/quest_condition_fields.py -- the checker that found the Quest ESP
place-POI bug on 2026-10-13 (tools/handoff_quest_place_pois.md).

Two things are under test, and they are different in kind:

  1. The PARSER, against synthetic dump.cs fragments. This is the part that can be
     wrong quietly. A parser that silently drops fields would report a clean tree
     over a real dump, which is the exact failure mode this file exists to stop.

  2. The EXIT-CODE CONTRACT (0 clean / 1 problem found / 2 checked nothing), which
     AGENTS.md requires to stay distinguishable. A tool that exits 0 when it read
     no dump is worse than no tool.

The real dumps are NOT used here. TarkovAddons/GameDump/ is gitignored, so a test
keyed on it would skip on every other machine and pass vacuously -- and a test that
can only pass is the thing this repo keeps warning about. The fixtures below are
verbatim excerpts whose line shapes come from dump.cs; the end-to-end agreement
between this parser and the real dumps is recorded in the memo and is re-derivable
with one command.

NEGATIVE CONTROLS, run at authoring time and re-runnable via
`python -m pytest tools/tests/test_quest_condition_fields.py -q`:

  * The SHIPPED tool now goes clean on the full fixture (exit 0), and the same
    tool with the pre-fix field list restored goes exit 1 with 3 unresolvable
    reads. So the tool still discriminates the bug from the fix -- the direction
    of the control inverted on 2026-10-13, when the fix landed and the shipped
    tree became the clean arm.
  * Dropping the parent declaration makes resolve() fall through to null, which is
    how the real bug manifests. Confirms the chain walk is what makes a field
    visible, and that the test would notice if it stopped.
"""

import importlib.util
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
TOOL = REPO / "tools" / "quest_condition_fields.py"

# Load the tool as a module so its parser can be tested directly, and drive its
# exit-code contract through a real subprocess (the way a CI step would).
_spec = importlib.util.spec_from_file_location("quest_condition_fields", TOOL)
qcf = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(qcf)

# The PRE-FIX place-gate field names, kept because the exact-match property they
# demonstrate is what caused the bug: none of the three resolves against the
# `zoneIds` the classes actually carry. The shipped tool and header now read
# `zoneIds`; see test_the_place_gate_reads_the_field_that_exists, which fails if
# the header ever goes back.
BUGGY_PLACE_FIELDS = ("zoneId", "zoneID", "ZoneId")
PLACE_FIELD_AS_FIXED = "zoneIds"


def run_tool(dump_text, extra_args=(), tool_source=None):
    """Run the tool as a subprocess against a temp dump, the way CI would.

    `tool_source` runs a MODIFIED copy instead of the shipped one -- how the
    negative control stands in for "what if quest_esp.h were fixed".
    """
    with tempfile.NamedTemporaryFile("w", suffix=".dump.cs", delete=False) as fh:
        fh.write(dump_text)
        dump = fh.name
    tool, temp_tool = TOOL, None
    try:
        if tool_source is not None:
            with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False) as fh:
                fh.write(tool_source)
                temp_tool = fh.name
            tool = Path(temp_tool)
        return subprocess.run(
            [sys.executable, str(tool), dump, *extra_args],
            capture_output=True, text=True, timeout=120,
        )
    finally:
        Path(dump).unlink(missing_ok=True)
        if temp_tool:
            Path(temp_tool).unlink(missing_ok=True)


def load(text):
    """qcf.load over a temp file. Returns (parent_of, fields_of)."""
    with tempfile.NamedTemporaryFile("w", suffix=".dump.cs", delete=False) as fh:
        fh.write(text)
        path = fh.name
    try:
        return qcf.load(path)
    finally:
        Path(path).unlink(missing_ok=True)


def dump_class(name, base, fields=()):
    """Render a class the way Il2CppDumper does: tab-indented fields, each
    carrying its own '// 0xNN' offset comment, a // Properties marker, braces.

    `fields` entries are the whole declaration INCLUDING the offset comment, so a
    fixture reads the same as the dump.cs line it stands in for.
    """
    body = "".join(f"\t{f}\n" for f in fields)
    base_part = f" : {base}" if base else ""
    return f"public class {name}{base_part}\n{{\n\t// Fields\n{body}\t// Properties\n}}\n\n"


# Every class the five gates can reach, with base classes and field names COPIED
# from TarkovAddons/GameDump/1.2.0.0.47965/dump.cs (offsets included, so a drift
# in the real dump is visible here rather than hidden). It reproduces the shipped
# bug exactly: every gate resolves its field except `place`, whose gate looks for
# zoneId/zoneID/ZoneId while the classes carry zoneIds.
FULL_DUMP = (
    dump_class("Condition", "", [])
    + dump_class("ConditionOneTarget", "Condition", ["public string target; // 0xE0"])
    + dump_class("ConditionVisitPlace", "ConditionOneTarget", [])
    + dump_class("ConditionLocationTrigger", "ConditionOneTarget", [])
    + dump_class("ConditionInZone", "Condition", ["public string[] zoneIds; // 0xE0"])
    + dump_class("ConditionMultipleTargets", "Condition",
                 ["public string[] target; // 0xE0"])
    + dump_class("ConditionFindItem", "ConditionMultipleTargets", [])
    + dump_class("ConditionZone", "ConditionMultipleTargets",
                 ["public string[] zoneIds; // 0xE8"])
    + dump_class("ConditionPlaceBeacon", "ConditionZone", [])
    + dump_class("ConditionLeaveItemAtLocation", "ConditionZone", [])
    + dump_class("ConditionTransitionLocation", "Condition",
                 ["private string[] <MapNames>k__BackingField; // 0xE0"])
)


class ParsesDumpCsShape(unittest.TestCase):
    """The parser, on the shapes it will actually meet."""

    def test_reads_field_name_type_and_offset(self):
        text = dump_class("ConditionZone", "ConditionMultipleTargets",
                          ["public string[] zoneIds; // 0xE8"])
        parent, fields = load(text)
        self.assertEqual(parent["ConditionZone"], "ConditionMultipleTargets")
        self.assertEqual(fields["ConditionZone"]["zoneIds"], ("0xE8", "string[]"))

    def test_resolves_a_field_declared_on_a_base_class(self):
        # ConditionVisitPlace declares no target of its own; it lives on
        # ConditionOneTarget. resolve() must walk up to find it, because that is
        # what il2utils::resolve_field does and what makes the visit gate work.
        text = (dump_class("ConditionOneTarget", "Condition",
                           ["public string target; // 0xE0"])
                + dump_class("ConditionVisitPlace", "ConditionOneTarget", []))
        parent, fields = load(text)
        self.assertEqual(qcf.resolve(parent, fields, "ConditionVisitPlace", "target"),
                         ("ConditionOneTarget", ("0xE0", "string")))

    def test_plural_name_does_not_resolve_against_a_singular_lookup(self):
        # THE BUG, in miniature. zoneIds != zoneId under an exact-name lookup.
        text = dump_class("ConditionZone", "Condition", ["public string[] zoneIds; // 0xE8"])
        parent, fields = load(text)
        for singular in BUGGY_PLACE_FIELDS:
            owner, _ = qcf.resolve(parent, fields, "ConditionZone", singular)
            self.assertIsNone(owner, f"{singular} must not resolve against zoneIds")

    def test_a_self_referencing_parent_chain_terminates(self):
        # dump.cs has nested types whose declared base loops back on itself. An
        # unguarded walk hangs forever, and a hanging checker is not a failing
        # one. NEGATIVE CONTROL: this test is only meaningful if the class is
        # actually PARSED -- without the assertion on the next line it used to
        # pass for the wrong reason, because an unparsed name has no parent and so
        # no cycle to walk.
        text = dump_class("Weird`1", "Weird`1", ["public string zoneIds; // 0x10"])
        parent, _ = load(text)
        self.assertEqual(parent.get("Weird`1"), "Weird`1",
                         "fixture not parsed; the cycle assertion below is vacuous")
        self.assertEqual(qcf.ancestors(parent, "Weird`1"), [])

    def test_generic_and_nested_names_are_parsed_whole(self):
        # re.match() needs only a PREFIX, so a charset without '.' or '`'
        # truncates the name instead of failing: the class lands in the table
        # under the wrong key with no parent recorded. Quiet, and it is what made
        # the cycle test above pass vacuously.
        text = (dump_class("Outer.Inner", "Base", ["public string zoneIds; // 0x10"])
                + dump_class("Base", "", []))
        parent, _ = load(text)
        self.assertIn("Outer.Inner", parent, "nested name was truncated")
        self.assertEqual(parent["Outer.Inner"], "Base")

    def test_abstract_base_classes_are_not_counted_as_conditions_themselves(self):
        # ConditionOneTarget and ConditionMultipleTargets are abstract and are in
        # dump.cs, but they never appear in a Conditions collection.
        text = (dump_class("Condition", "", [])
                + dump_class("ConditionOneTarget", "Condition",
                             ["public string target; // 0xE0"]))
        parent, _ = load(text)
        self.assertIn("Condition", qcf.ancestors(parent, "ConditionOneTarget"))


class GateTableIsFaithfulToTheHeader(unittest.TestCase):
    """The GATES table is the one hand-transcribed part of the tool. This holds it
    to the header so it cannot drift into reporting a clean tree over a gate that
    was renamed or deleted."""

    def setUp(self):
        self.header = (REPO / "TarkovAddons" / "module" / "quest_esp.h").read_text(
            encoding="utf-8", errors="replace")

    def test_the_place_gate_reads_the_field_that_exists(self):
        # The 2026-10-13 fix, asserted so a regression to the singular name
        # fails here instead of silently restoring "no place marker, ever".
        # The old form of this test asserted the opposite, and its direction of
        # failure was the point: the memo's headline claim expired the moment
        # the header learned the real name.
        place_body = self.header.split("process_place_condition")[1]
        self.assertIn(f'read_string_array_field(condition, "{PLACE_FIELD_AS_FIXED}")',
                      place_body)
        self.assertNotIn('"zoneId", "zoneID", "ZoneId"', self.header)
        self.assertNotIn("inline std::string get_zone_id", self.header,
                         "get_zone_id is defined again; the place gate regressed")

    def test_the_tools_gate_table_matches_the_header(self):
        # The durable version of the faithfulness guard: every field name in the
        # tool's GATES table must appear as a literal in the header, so a gate
        # that gains a field in one place and not the other cannot drift.
        for gate, match, names, reads in qcf.GATES:
            for name in names:
                self.assertIn(f'"{name}"', self.header,
                              f"{gate} reads {name} and the header does not")

    def test_the_place_gate_is_still_the_only_producer_of_place_pois(self):
        # quest_esp.h:1374 is the sole `poi_type::place` emission. If a second one
        # appears, the memo's "no place marker can be drawn" claim is wrong.
        producers = [i + 1 for i, ln in enumerate(self.header.splitlines())
                     if "poi_type::place" in ln]
        self.assertEqual(len(producers), 1, f"place POI producers moved: {producers}")

    def test_every_gate_named_in_the_tool_exists_in_the_header(self):
        for fn in ("process_visit_conditions", "process_inzone_conditions",
                   "process_place_condition", "register_find_condition",
                   "process_transition_conditions"):
            self.assertIn(fn, self.header, f"{fn} is gone; update the tool's GATES")


class ExitCodeContract(unittest.TestCase):
    """0 clean / 1 problem / 2 checked nothing. Never normalise 2 into 0."""

    def test_missing_dump_exits_two_not_zero(self):
        proc = subprocess.run([sys.executable, str(TOOL), "/nonexistent/dump.cs"],
                              capture_output=True, text=True, timeout=120)
        self.assertEqual(proc.returncode, 2, proc.stdout + proc.stderr)

    def test_a_dump_with_no_condition_classes_exits_two(self):
        proc = run_tool("public class Something\n{\n}\n")
        self.assertEqual(proc.returncode, 2, proc.stdout + proc.stderr)

    def test_a_gate_matching_nothing_exits_two_not_zero(self):
        # The hand-transcribed GATES table is stale, or the header lost a gate.
        # Reporting that as "clean" is the failure this guard exists for, so the
        # fixture below deliberately omits every visit-gate class.
        text = (dump_class("Condition", "", [])
                + dump_class("ConditionZone", "Condition",
                             ["public string[] zoneIds; // 0xE8"]))
        proc = run_tool(text)
        self.assertEqual(proc.returncode, 2, proc.stdout + proc.stderr)
        self.assertIn("matched NOTHING", proc.stdout)

    def test_the_fixed_place_gate_resolves_and_the_tool_exits_zero(self):
        # FULL_DUMP carries all five gates, with field names copied from the real
        # dump.cs. With the place gate reading `zoneIds`, every gate resolves and
        # the shipped tree is clean. If any gate starts failing, the fixture or
        # the header changed -- find out which before touching the tool.
        proc = run_tool(FULL_DUMP)
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        self.assertIn("TOTAL unresolvable field reads: 0", proc.stdout)
        for gate in ("visit", "inzone", "place", "find", "transit"):
            section = proc.stdout.split(f"=== {gate} ")[1].split("\n===")[0]
            self.assertIn("-> 0 of", section, f"{gate} is failing:\n{section}")

    def test_restoring_the_old_field_list_makes_it_fail_again(self):
        # NEGATIVE CONTROL, inverted on 2026-10-13. The discrimination property is
        # unchanged: a tool that reports the bug and the fix the same way is not
        # checking anything. With the pre-fix list restored in the PLACE gate
        # only, the same fixture must go exit 1 with exactly 3 unresolvable reads
        # (the three place classes). Two gates now read `zoneIds`, so the anchor
        # below is the place gate's own two lines -- a bare replace of the field
        # list would break inzone as well and the count would read 4.
        source = TOOL.read_text(encoding="utf-8")
        place_gate = (f'     ["{PLACE_FIELD_AS_FIXED}"],\n'
                      f'     "process_place_condition, read_string_array_field, read as string[]"),')
        self.assertIn(place_gate, source,
                      "the place gate's GATES entry moved; this control would "
                      "otherwise run unmodified and pass on nothing")
        buggy_tool = source.replace(
            place_gate,
            f'     {list(BUGGY_PLACE_FIELDS)!r}'.replace("'", '"')
            + ',\n     "get_zone_id, read as one Il2CppString*"),')
        proc = run_tool(FULL_DUMP, tool_source=buggy_tool)
        self.assertEqual(proc.returncode, 1, proc.stdout + proc.stderr)
        self.assertIn("TOTAL unresolvable field reads: 3", proc.stdout)
        section = proc.stdout.split("=== place ")[1].split("\n===")[0]
        self.assertIn("-> 3 of 3", section)
        for gate in ("visit", "inzone", "find", "transit"):
            section = proc.stdout.split(f"=== {gate} ")[1].split("\n===")[0]
            self.assertIn("-> 0 of", section, f"{gate} should not be failing:\n{section}")


if __name__ == "__main__":
    unittest.main()