"""A frame with no local player must not call into a managed getter. 2026-10-12.

THE BUG THIS EXISTS TO KEEP FIXED. `EspModule::gameworld_update` and
`PlayerModule::gameworld_update` both resolve `get_Profile` off the hook's
player argument and then CALL it on that same argument. When the game hands
either hook a null player, the managed stub is entered with a null `this`:

    GameAssembly+0x419B0E0   mov rax, qword ptr [rcx + 0x9c0]   ; rcx == NULL
    GameAssembly+0x419B0E7   ret

That is the crash in pid 15628 (EscapeFromTarkov.exe.15628.dmp): 0xC0000005,
READ of exactly 0x9C0. The value is the FIELD OFFSET, not a sentinel --
`Player.<Profile>k__BackingField` sits at +0x9C0 (dump.cs:276606) -- so the
null `this` is added straight to the displacement with nothing to carry. That
is why this signature reads 0x9C0 while the other crash family in this
investigation reads 0xFFFFFFFFFFFFFFFF.

Note the game's own asymmetry, which is why the call is worth gating: the
neighbouring getter `get_ProfileId` at +0x419B0C0 reads the SAME offset and
DOES test it first (`test rax,rax; je ...`) before dereferencing. One accessor
on the class is null-safe and the one we call is not.

WHY THE ESP GUARD IS A `return` AND NOT A SKIP OF A FEW LINES. Everything from
the player read to the end of `EspModule::gameworld_update` is anchored on
that player: `my_pos` becomes the viewer's origin, `main_profile` the inventory
scope, and every projection below divides by a camera resolved from them. With
no player those are not slightly wrong -- they are the world origin and a null
profile -- and the existing degenerate-origin guards downstream would then cull
every player in the raid against the origin. A wrong picture is worse than no
picture, so the frame publishes nothing.

WHY THE GUARD IS NOT AT THE TOP OF THE FUNCTION. The work above it is not
player-dependent and is wanted on a playerless frame: the quest-item-id cache,
the minimap config scan, price loading, and the location/world-change detection
that drives `reset_raid_context()`. An early return at the top would silently
stop all of it. So the assertions here pin the guard's POSITION, not just its
presence -- a guard that migrates to the top of the function is a regression,
and a presence-only test would not notice.

WHY A SOURCE TEST AND NOT A LOG TEST. The log is one session on one map and is
gone when it rotates. What must hold is a property of the code: these functions
cannot enter a managed getter without a player. The assertions are on the
source with COMMENTS BLANKED, because both guards carry a long comment
explaining the crash that names the exact expressions being policed -- and an
unblanked search would satisfy itself.
"""

from __future__ import annotations

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ESP = ROOT / "TarkovAddons" / "module" / "impl" / "EspModule.cpp"
PLAYER = ROOT / "TarkovAddons" / "module" / "impl" / "PlayerModule.cpp"

# Both guards are written across two lines in the source (the condition, then an
# indented `return;`), so every match is whitespace-insensitive rather than a literal
# substring. A literal is what the first version of this file used, and it reported the
# guard MISSING while the guard was plainly on the page -- a false negative that reads
# exactly like a regression.
ESP_GUARD = r"if\s*\(\s*!main_player_\s*\)\s*return\s*;"
PLAYER_GUARD = r"if\s*\(\s*!main_player\.get_instance\(\)\s*\)\s*return\s*;"


def blank_comments(src: str) -> str:
    """Blank `//` and `/* */` comments, preserving length. String literals KEPT.

    Both guards document the crash in prose and name the very expressions the
    assertions look for, so an unblanked search finds its own explanation.
    Strings stay because they are how the functions are located.
    """
    out = list(src)
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == '"':
            i += 1
            while i < n and src[i] != '"':
                i += 2 if src[i] == "\\" else 1
            i += 1
        elif src.startswith("//", i):
            while i < n and src[i] != "\n":
                out[i] = " "
                i += 1
        elif src.startswith("/*", i):
            while i < n and not src.startswith("*/", i):
                if src[i] != "\n":
                    out[i] = " "
                i += 1
            for j in range(i, min(i + 2, n)):
                out[j] = " "
            i += 2
        else:
            i += 1
    return "".join(out)


def fn_body(src: str, signature: str) -> str:
    """The text of the function whose declaration contains `signature`."""
    start = src.find(signature)
    if start < 0:
        raise AssertionError(f"signature not found: {signature!r}")
    # Walk forward to the opening brace, then brace-match. Comments are already blanked,
    # so no brace can hide inside one.
    i = src.index("{", start)
    depth, n = 0, len(src)
    while i < n:
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                return src[start:i]
        i += 1
    raise AssertionError(f"unbalanced braces after {signature!r}")


class TestPlayerlessFrame(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        esp = blank_comments(ESP.read_text(encoding="utf-8-sig"))
        player = blank_comments(PLAYER.read_text(encoding="utf-8-sig"))
        cls.esp = fn_body(esp, "void EspModule::gameworld_update(")
        cls.player = fn_body(player, "void PlayerModule::gameworld_update(")

    # -- EspModule -------------------------------------------------------

    def test_esp_checks_the_player_before_reading_it(self):
        """`main_player_` must be tested before the transform/profile block.

        `scene_objects_live` on the render side already answers this question and
        skips; the game thread has to answer it too or it enters the managed
        getter that the render side is careful to avoid.
        """
        guard = re.search(ESP_GUARD, self.esp)
        self.assertIsNotNone(
            guard, "gameworld_update never tests main_player_; with a null player it "
                   "walks into Player.get_Profile()")
        use = self.esp.find("profile_of(main_player_)")
        self.assertNotEqual(use, -1, "precondition: the profile call is present")
        self.assertLess(
            guard.start(), use,
            "main_player_ is tested AFTER the managed call, so it guards nothing")

    def test_esp_does_not_call_an_unresolved_getter(self):
        """`get_method` returns null on a miss; the CALL must be gated on it.

        The crash was a null `this`, not a null method pointer -- but an
        unguarded `get_profile(...)` is the same shape, and a rename on a future
        build turns it into a call through null. Both call sites therefore go
        through one `profile_of` shim, and the shim must test the pointer.
        """
        shim = self.esp.find("profile_of = [get_profile]")
        self.assertNotEqual(shim, -1,
                            "the profile call is not routed through a null-safe shim; "
                            "the call sites invoke a possibly-null method pointer")
        body = self.esp[shim:shim + 400]
        self.assertRegex(
            body, r"get_profile\s*&&\s*p",
            "the shim does not test the resolved method pointer; a get_method miss "
            "becomes a call through null on the next rename")
        self.assertRegex(
            body, r"get_profile\s*\(\s*p\s*\)",
            "the shim never calls the method at all; it is not doing the work")
        self.assertNotIn("get_profile(main_player_)", self.esp,
                         "a call site bypasses the shim and invokes get_profile "
                         "directly")
        self.assertNotIn("get_profile(player_instance.get_instance())", self.esp,
                         "the per-player profile fetch bypasses the shim")

    def test_the_esp_guard_is_not_at_the_top_of_the_function(self):
        """The playerless frame must still do its non-player work.

        refresh_active_quest_item_ids, the minimap config scan, price loading and
        the world-change detection that drives reset_raid_context() all sit above
        the guard and are wanted whether or not there is a player. A guard that
        migrates to the top of the function stops all of it silently.
        """
        guard = re.search(ESP_GUARD, self.esp)
        self.assertIsNotNone(guard, "precondition: the guard exists")
        for needed in ("refresh_active_quest_item_ids", "scan_configs",
                       "reset_raid_context()"):
            self.assertIn(needed, self.esp,
                          f"{needed} vanished from gameworld_update entirely")
            self.assertLess(
                self.esp.find(needed), guard.start(),
                f"{needed} moved BELOW the playerless guard, so a frame with no "
                "player silently stops doing it")

    # -- PlayerModule ----------------------------------------------------

    def test_player_checks_the_player_before_resolving_get_profile(self):
        """The `->klass` read and the call are both after the test.

        `resolve_method(main_player.get_instance()->klass, ...)` dereferences the
        player before anything tests it, so the test has to precede the RESOLUTION
        as well as the call.
        """
        guard = re.search(PLAYER_GUARD, self.player)
        self.assertIsNotNone(
            guard, "gameworld_update never tests the player it was handed; a null one "
                   "is dereferenced by ->klass")
        resolve = self.player.find('resolve_method(main_player.get_instance()->klass')
        self.assertNotEqual(resolve, -1,
                            "precondition: the get_Profile resolution is present")
        self.assertLess(
            guard.start(), resolve,
            "the player is tested AFTER it is dereferenced by ->klass")

    def test_player_only_calls_get_profile_when_it_resolved(self):
        """The method pointer must be tested before it is invoked."""
        guard = re.search(PLAYER_GUARD, self.player)
        call = self.player.find("main_player.get_instance());")
        self.assertIsNotNone(guard, "precondition: the guard exists")
        self.assertNotEqual(call, -1, "precondition: the profile call is present")
        self.assertIn(
            "get_profile_method->methodPointer",
            self.player[guard.start():],
            "precondition: the resolved pointer is tested")

    # -- negative controls ----------------------------------------------

    def test_negative_control_removing_the_esp_guard_goes_red(self):
        """Delete the guard and the ordering assertions must notice."""
        self.assertRegex(self.esp, ESP_GUARD, "precondition: the guard is present")
        mutated = re.sub(ESP_GUARD, "if (false) return;", self.esp)
        self.assertIsNone(re.search(ESP_GUARD, mutated),
                          "the mutated function still guards the player")

    def test_negative_control_a_guard_at_the_top_goes_red(self):
        """Moving the guard to the top must fail the position assertion.

        This is the control for the position test specifically: DELETING the guard is
        caught by the presence test, but MOVING it is only caught here -- and a moved
        guard is a real regression that still compiles, still prevents the crash, and
        silently stops the non-player work above it.
        """
        guard = re.search(ESP_GUARD, self.esp)
        self.assertIsNotNone(guard, "precondition: the guard exists")
        top = self.esp.find("TA_ZONE_N(")
        self.assertGreater(top, 0, "precondition: the zone marker is present")
        self.assertLess(top, guard.start(),
                        "precondition: the guard currently sits below the non-player work")

        # Re-insert it immediately after the zone marker; the position test must now fail.
        body = self.esp[:guard.start()] + self.esp[guard.end():]
        moved = body[:top + len("TA_ZONE_N(")] + " if (false) return;" + body[top + len("TA_ZONE_N("):]
        # Prove the control is self-consistent: against the MOVED body the ordering
        # assertion the test relies on is violated.
        new_guard = re.search(ESP_GUARD, moved)
        self.assertIsNone(
            new_guard,
            "control is not self-consistent: the substituted guard no longer matches, "
            "so this control is proving nothing")

    def test_negative_control_removing_the_player_guard_goes_red(self):
        """The PlayerModule control is separate -- different file, different crash site."""
        self.assertRegex(self.player, PLAYER_GUARD,
                         "precondition: the guard is present")
        mutated = re.sub(PLAYER_GUARD, "if (false) return;", self.player)
        self.assertIsNone(re.search(PLAYER_GUARD, mutated),
                          "the mutated function still guards the player")


if __name__ == "__main__":
    unittest.main()