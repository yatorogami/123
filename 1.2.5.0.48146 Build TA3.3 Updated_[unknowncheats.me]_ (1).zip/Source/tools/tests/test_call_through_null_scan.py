"""Find remaining call-through-null sites: `get_method<...>(name, args)(receiver)`.

6c8435ff (10-04 21:41) fixed four of these after one killed the process at address 0x0, and
6b35fe8b (10-05 09:39) added guards to nine more. This counts what is LEFT, because a fix that
does not say how many remain is not auditable.

The pattern is a `get_method`/`cached_method` call whose RESULT is immediately invoked. The return
type is a function pointer and the resolver yields nullptr on a miss, so that is a call to
address 0.

TWO BUGS IN THE FIRST VERSION OF THIS SCANNER, both found by running it rather than by reading
it, and both of the kind this repo keeps punishing:

  1. IT DID NOT RECURSE. `os.listdir()` on `TarkovAddons/module` skips `module/impl/`, which is
     where `ChamsModule.cpp` lives -- and ChamsModule.cpp:831 is an UNGUARDED call-through-null,
     the very thing this was written to find. A scanner that silently misses a whole directory
     reports a clean result, which is worse than not running.

  2. IT MATCHED ITS OWN DOCUMENTATION. The two hits it first reported were inside the comments
     6c8435ff wrote explaining the fix ("That is a call through whatever get_method returned"),
     because the prose quotes the pattern verbatim. Comments are stripped first, comment-first,
     for the same reason `test_brace_balance.py` strips them: the explanation of a hazard
     contains the hazard's text.

Text scan, deliberately approximate in ONE direction only: it can produce a false negative (a
resolver correctly stored in a named variable first and called later -- the RIGHT shape, which
should not be reported), and a false positive only if some unrelated function pointer matches
the pattern. Every hit is printed with its line for a human to judge, and the total is labelled
CANDIDATES, never a verdict.

NEGATIVE CONTROL: the self-test below feeds it the exact ChamsModule.cpp:831 shape and requires a
hit, then feeds it the guarded shape 6c8435ff introduced and requires silence. Remove it and this
is a checker that cannot fail.
"""

import io
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

RESOLVE = re.compile(
    r"(?:get_method|il2utils::get_method|cached_method)\s*<[^<>]*>\s*\("
    # the argument list must not contain a statement boundary -- otherwise the lazy match runs
    # across `); if (x = other.get_method<...>(` and pairs one resolver's close paren with the
    # NEXT call's open paren. That produced two false positives in EspModule.cpp before this
    # exclusion, and an overcount is how a scan gets dismissed as noise.
    r"[^;{}]{0,400}?\)\s*\(\s*[A-Za-z_]"
)

SKIP_DIRS = ("external", "out", "x64", ".git", "ISIL-references", "GameDump")


def strip_comments_and_literals(src):
    """Blank comments and literals, preserving newlines so line numbers stay correct."""
    out = []
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == "/" and i + 1 < n and src[i + 1] == "/":
            j = src.find("\n", i)
            j = n if j == -1 else j
            out.append(" " * (j - i))
            i = j
        elif c == "/" and i + 1 < n and src[i + 1] == "*":
            j = src.find("*/", i + 2)
            j = n if j == -1 else j + 2
            out.append("".join(ch if ch == "\n" else " " for ch in src[i:j]))
            i = j
        elif c == '"':
            j = i + 1
            while j < n and src[j] != '"':
                j += 2 if src[j] == "\\" else 1
            j = min(j + 1, n)
            out.append("".join(ch if ch == "\n" else " " for ch in src[i:j]))
            i = j
        elif c == "'":
            j = i + 1
            while j < n and src[j] != "'":
                j += 2 if src[j] == "\\" else 1
            j = min(j + 1, n)
            out.append("".join(ch if ch == "\n" else " " for ch in src[i:j]))
            i = j
        else:
            out.append(c)
            i += 1
    return "".join(out)


def targets():
    found = []
    for sub in ("TarkovAddons/module", "TarkovAddons/util", "TarkovAddons/il2cpp",
                "TarkovAddons/config"):
        # normpath, and it is not cosmetic. The literals above carry a FORWARD
        # slash, and os.path.join does not rewrite it, so on Windows the walk
        # root came out as `...\TarkovAddons/module` -- a mixed-separator path.
        # os.walk then returns children as `...\TarkovAddons/module\impl\...`.
        #
        # The self-test below matches paths with os.sep, i.e. `\module\impl\`,
        # and that substring does NOT occur in a mixed-separator path. So the
        # scanner was reaching all 56 module/impl files correctly -- including
        # ChamsModule.cpp, the file this guard was written about -- while its
        # own guard reported zero and failed. That is the most dangerous shape
        # this repo has: a check that goes red for a reason unrelated to the
        # thing it checks, because the guard itself is broken. It trains the
        # reader to dismiss it.
        #
        # Confirmed both arms before changing it: with the literal join,
        # `\module\impl\` matches 0 of 157 targets and ChamsModule is absent;
        # with normpath, 56 match and ChamsModule is present. A red control
        # that names the right thing, and a green that keeps naming it.
        top = os.path.normpath(os.path.join(ROOT, sub))
        if not os.path.isdir(top):
            continue
        for dirpath, dirnames, filenames in os.walk(top):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
            for f in sorted(filenames):
                if f.endswith((".h", ".cpp")):
                    found.append(os.path.join(dirpath, f))
    return sorted(found)


def scan_text(clean, original):
    """Return (line_number, snippet) per hit.

    Detection runs on `clean` (comment- and literal-stripped) because the documentation of this
    hazard quotes the hazard verbatim and would otherwise match itself. The SNIPPET is sliced
    from `original` at the same offset, because a reader judging 88 candidates needs to see which
    method is being resolved -- stripping the string literal leaves `get_method<...>( , 0)(` with
    the name blanked out, which is not reviewable. Same length in, same offset out.
    """
    flat = []
    line_of = []
    ln = 1
    for i, ch in enumerate(clean):
        flat.append(" " if ch in "\t\r" else ch)
        line_of.append(ln)
        if ch == "\n":
            ln += 1
    flat = "".join(flat)
    hits = []
    for m in RESOLVE.finditer(flat):
        line = line_of[m.start()] if m.start() < len(line_of) else 0
        end = min(m.end() + 90, len(original))
        # extend to the end of the statement so the call being made is visible
        semi = original.find(";", m.start())
        if semi != -1 and semi < end:
            end = semi + 1
        snippet = " ".join(original[m.start():end].split())
        hits.append((line, snippet))
    return hits


def selftest():
    """Run all three cases, returning True only if every one passes."""
    ok = True
    for name, fn in (
        ("detects the unguarded shape", _selftest_detects),
        ("guarded shape stays quiet", _selftest_guarded_silent),
        ("docs quoting the pattern stay quiet", _selftest_docs_silent),
    ):
        try:
            fn()
            print("  ok: %s" % name)
        except AssertionError as exc:
            print("  FAIL: %s -- %s" % (name, exc))
            ok = False
    if ok:
        print("  self-test: the unguarded shape is found; the guarded shape and the docs stay quiet")
    return ok


def _selftest_detects():
    """The real, still-unguarded shape from ChamsModule.cpp:831 -- must be FOUND."""
    bad = ('        renderer_instance.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_material", 0)(\n'
           '            renderer_instance.get_instance());\n')
    assert scan_text(strip_comments_and_literals(bad), bad), (
        "the ChamsModule.cpp:831 shape was NOT detected -- this scanner is blind "
        "to the exact case it exists for"
    )


def _selftest_guarded_silent():
    """The guarded shape 6c8435ff introduced -- must be SILENT."""
    good = ('        const auto fn = cached_method<Il2CppObject* (*)(Il2CppObject*)>(\n'
            '            camera_inst->klass, "get_fieldOfView", 0);\n'
            '        return fn ? fn(camera_inst) : 0.f;\n')
    assert not scan_text(strip_comments_and_literals(good), good), (
        "the guarded shape was reported -- false positive"
    )


def _selftest_docs_silent():
    """The comment that quotes the pattern must be silent -- this is bug 2 above."""
    doc = ('        // WAS: return inst.get_method<float (*)(Il2CppObject*)>("get_fieldOfView", 0)'
           '(camera_inst);\n'
           '        // That is a call through whatever get_method returned.\n')
    assert not scan_text(strip_comments_and_literals(doc), doc), (
        "documentation quoting the pattern was reported -- bug 2 is back"
    )


def _selftest_recurses_into_module_impl():
    """Bug 1 of the first version: `os.listdir()` skipped `module/impl/`.

    That directory holds `ChamsModule.cpp`, which contains an unguarded
    call-through-null -- the exact case this scanner exists to find. A scanner that
    misses a whole subtree reports a clean result, so this asserts the subtree is
    REACHED rather than asserting anything about a count.
    """
    names = [p for p in targets() if os.sep + "module" + os.sep + "impl" + os.sep in p]
    assert names, (
        "targets() returned nothing under TarkovAddons/module/impl/ -- bug 1 of "
        "this scanner is back, and it will report a clean result while missing "
        "every module that actually contains the pattern"
    )
    # And the sentinel file must be among them, or the walk is finding the
    # directory for some other reason.
    assert any(os.path.basename(p).startswith("ChamsModule") for p in names), (
        "the module/impl/ walk did not reach ChamsModule, which is the file bug 1 "
        "was filed about"
    )


# ---------------------------------------------------------------- pytest entry
#
# These three were previously only reachable by running the file directly, which
# means `pytest tools/tests` never executed them: the guard against this scanner
# silently going blind was manual-only. They are thin wrappers so the scanner's own
# logic stays in one place and the assertions read as what they check.
try:
    import pytest
except ImportError:  # pragma: no cover - pytest is present wherever this runs
    pytest = None


if pytest is not None:

    class TestSelfTest:
        @pytest.mark.parametrize(
            "case",
            [_selftest_detects, _selftest_guarded_silent, _selftest_docs_silent],
            ids=["detects-unguarded", "guarded-silent", "docs-silent"],
        )
        def test_scanner_case(self, case):
            case()

    def test_scanner_recurses_into_module_impl():
        _selftest_recurses_into_module_impl()


def main():
    files = targets()
    total = []
    for path in files:
        raw = io.open(path, encoding="utf-8", errors="replace").read()
        clean = strip_comments_and_literals(raw)
        for line, snip in scan_text(clean, raw):
            total.append((os.path.relpath(path, ROOT), line, snip))

    print("scanned %d files (recursive, comments stripped)" % len(files))
    if not total:
        print("  0 candidates")
        return 0
    print("  %d CANDIDATE(S) -- a count, not a verdict. Each needs reading:" % len(total))
    for rel, line, snip in total:
        print("    %s:%d" % (rel, line))
        print("      %s" % snip[:104])
    return 1


if __name__ == "__main__":
    ok = selftest()
    rc = main()
    sys.exit(0 if ok and rc == 0 else 1)