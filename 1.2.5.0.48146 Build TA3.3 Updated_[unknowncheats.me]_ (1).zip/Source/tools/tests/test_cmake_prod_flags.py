"""The Prod build must be optimized, and the PCH must really be in use.

`build.ninja` is the generated truth. `e605d6395` set
`CMAKE_BUILD_TYPE=Prod`, which is not one of CMake's four built-in types, so
`CMAKE_CXX_FLAGS_PROD` was empty: `LINK_FLAGS_PROD` was honoured (arbitrary
configuration names are allowed there) while no compile flag was, and every
Prod build linked `/LTCG /OPT:REF` over 82 TUs compiled at `/Od`.

Asserting on the build system's own output rather than on the CMakeLists text,
because the defect was precisely that the text looked configured.

Skips when there is no generated tree -- this suite never builds anything.
"""
import io
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
BUILD_NINJA = REPO / "build" / "Prod" / "x64" / "opencode" / "build.ninja"

# Vendored trees opt out of the PCH on purpose (see TarkovAddons/CMakeLists.txt),
# and the PCH generator itself is built by a different rule.
_EXEMPT = re.compile(r"safetyhook|tracy|imgui|cmake_pch")


def _prod_cxx_lines():
    if not BUILD_NINJA.exists():
        return None
    txt = io.open(BUILD_NINJA, encoding="utf-8", errors="replace").read()
    pairs = []
    obj = None
    for line in txt.splitlines():
        m = re.match(r"^build (\S+\.obj): (CXX|C)_COMPILER", line)
        if m:
            obj = (m.group(1), m.group(2))
            continue
        if obj is not None and line.startswith("  FLAGS = "):
            pairs.append((obj[0], obj[1], line[len("  FLAGS = "):]))
            obj = None
    return txt, pairs


def test_prod_cxx_tus_are_optimized():
    got = _prod_cxx_lines()
    if got is None:
        pytest.skip("no generated tree at %s" % BUILD_NINJA)
    _, pairs = got

    tas = [(o, f) for o, lang, f in pairs if "TarkovAddons.dir" in o and lang == "CXX"]
    assert tas, "no TarkovAddons.dir objects in build.ninja -- the grep is wrong"

    checked = 0
    missing = []
    for obj, flags in tas:
        if _EXEMPT.search(obj):
            continue
        checked += 1
        for flag, why in (
            ("/O2", "Optimization MaxSpeed in the vcxproj Prod|x64"),
            ("/GL", "WholeProgramOptimization; pairs with /LTCG at link"),
            ("/W3", "WarningLevel Level3; CMake adds no /W flag for MSVC"),
        ):
            if flag not in flags:
                missing.append("%s missing %s (%s)" % (obj, flag, why))

    assert checked >= 40, "only %d first-party TUs examined; grep is too narrow" % checked
    assert not missing, "Prod TUs compiled without optimization:\n  " + "\n  ".join(missing)


def test_pch_is_created_and_consumed():
    got = _prod_cxx_lines()
    if got is None:
        pytest.skip("no generated tree at %s" % BUILD_NINJA)
    txt, _ = got

    assert "/Yc" in txt, "no /Yc: target_precompile_headers made no PCH"
    assert re.search(r"/Yu", txt), "no /Yu: PCH created but nothing consumes it"


def test_no_c_pch():
    """A C PCH would force common.h into Zydis.c and die on STL1003."""
    got = _prod_cxx_lines()
    if got is None:
        pytest.skip("no generated tree at %s" % BUILD_NINJA)
    txt, _ = got
    assert not re.search(r"cmake_pch\.c\b", txt), (
        "a C PCH exists; common.h is C++ and Zydis.c would fail STL1003"
    )


import pytest  # noqa: E402  (after the skip-capable helpers, by design)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(pytest.main([__file__, "-v"]))