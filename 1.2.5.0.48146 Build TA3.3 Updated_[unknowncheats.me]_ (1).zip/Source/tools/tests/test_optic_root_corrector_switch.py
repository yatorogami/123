#!/usr/bin/env python3
"""The optic root-corrector A/B switch is wired correctly end to end.

This exists because the wiring has one silent failure mode. `optic_root_corrector`
reads as "filter ENABLED" and `game_state::optic_root_corrector_off` reads as
"filter DISABLED", so the publisher has to INVERT between them. Drop that `!`
and the switch still compiles, still draws, still logs `corrector=on`, and is
simply always on -- the menu would appear to work while the corrector kept
running.

Verified negative controls, each run against deliberately broken code and each
confirmed to go red BEFORE being believed:
  A. drop the `!`                      -> flags the inversion, 2 checks red
  B. move the read after the env var    -> flags the ordering
  C. stop reading game_state entirely   -> flags the wiring

Exit codes when run directly: 0 pass, 1 fail. Never 2 (nothing checked) -- a
pattern that stops matching is a FAIL, not a silent pass, per AGENTS.md.
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ESP_CPP = os.path.join(ROOT, "TarkovAddons", "module", "impl", "EspModule.cpp")
STATE_H = os.path.join(ROOT, "TarkovAddons", "module", "game_state.h")
PIPE_H = os.path.join(ROOT, "TarkovAddons", "module", "optics_lens_pipeline.h")


def read(path):
    with open(path, encoding="utf-8", errors="replace") as fh:
        return fh.read()


def norm(text):
    """Whitespace-free, so a wrapped call still matches."""
    return re.sub(r"\s+", "", text)


def evaluate():
    """Return (results, checks) where results is [(name, passed), ...]."""
    esp, state, pipe = read(ESP_CPP), read(STATE_H), read(PIPE_H)
    esp_n = norm(esp)

    store = re.search(r"optic_root_corrector_off\.store\(([^;]*?)\);", esp, re.S)
    stored = norm(store.group(1)) if store else ""

    # Ordering, scoped to the FUNCTION: GetEnvironmentVariableA is named in a
    # comment above the definition, so a file-global index() comparison reports
    # the ordering backwards when the code is correct.
    fn_start = pipe.find("inline bool root_corrector_disabled()")
    fn_end = pipe.find("root-frame", fn_start)
    fn = pipe[fn_start:fn_end if fn_end != -1 else fn_start + 4000]
    load, env = fn.find("game_state::optic_root_corrector_off.load"), fn.find("GetEnvironmentVariableA(")

    results = [
        ("checkbox is constructed on the optic card",
         'newCheckboxValue(true,"optic_root_corrector_cb")' in esp_n),
        ("checkbox defaults ON (filter applies, i.e. shipped behaviour)",
         'newCheckboxValue(true,"optic_root_corrector_cb")' in esp_n),
        ("EspModule publishes the flag into game_state", store is not None),
        ("published value is the INVERSION of the checkbox",
         stored.startswith("!optic_root_corrector->get_value()")),
        ("store is relaxed-ordered (a per-frame fence is not wanted here)",
         "memory_order_relaxed" in (store.group(1) if store else "")),
        ("game_state declares the flag as a shared inline atomic",
         "inlinestd::atomic<bool>optic_root_corrector_off{false};" in norm(state)),
        ("the flag's polarity is documented where it is declared", "true = OFF" in state),
        ("the pipeline reads that same game_state flag",
         "game_state::optic_root_corrector_off" in pipe),
        ("the checkbox is consulted before the cached env read",
         load != -1 and env != -1 and load < env),
        # Negative control: if this ever passes, the inversion check above is vacuous.
        ("NEGATIVE CONTROL: an un-inverted store is rejected",
         not stored.startswith("optic_root_corrector->get_value()")),
        ("NEGATIVE CONTROL: the checks are not trivially true",
         len(stored) > 0 and "optic_root_corrector" in stored),
    ]
    return results


def test_optic_root_corrector_switch_is_wired():
    """pytest entry point. No sys.exit here: that aborted collection for the
    whole suite when this file was first written."""
    failures = []
    for name, passed in evaluate():
        print(("  PASS  " if passed else "  FAIL  ") + name)
        if not passed:
            failures.append(name)
    assert not failures, "failed: " + ", ".join(failures)


def main():
    failures = [n for n, ok in evaluate() if not ok]
    print()
    if failures:
        print("FAILED %d check(s): %s" % (len(failures), ", ".join(failures)))
        return 1
    print("OK - switch wired: checkbox -> game_state (inverted) -> pipeline")
    return 0


if __name__ == "__main__":
    sys.exit(main())
