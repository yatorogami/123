"""Tests for the compatibility manifest tooling."""
