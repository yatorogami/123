#!/usr/bin/env python3
"""The suspicious-frame report in root_frame_summary() must actually name a bad frame.

Added 2026-10-05. The A/B run (checkbox on and off, corrector disabled for 95
consecutive windows, applied=0 in 93 of them) cleared the root corrector as the
cause of the optic shake.

It also produced a `move` reading of 56,557 mm that looked like proof the root
node was corrupt. It was not: `move` is a delta between consecutive samples and
that reading sits in a window whose longest gap is 45,360 ms, so it is the
difference between the last sample before the optic path stopped running and the
first one after. See f635d7f5 and tools/measure_move_vs_dt.py. The report exists
so that pairing is possible NEXT time rather than being reconstructed afterwards
from two different summary lines.

WHY IT IS A TEXT TEST AND NOT A COMPILED ONE. The obvious approach is a harness
case including the real header, and it does not work: optics_lens_pipeline.h
transitively pulls in safetyhook and the managed-object layer, which fail to link
(LNK2019 on safetyhook::InlineHook::~InlineHook and unity::vector3::vector3).
That is why test_probe_memo.cpp and test_native_memo.cpp RE-DECLARE their shapes
locally -- they test the algorithm, not the real header -- which is the wrong tool
here, because the thing under test IS the real header's output formatting.

So this asserts the wiring textually, and the cold compile is done separately with
cl /std:c++23preview and no PCH (the PCH supplies game_state.h transitively and
masks a missing include -- which is exactly how 94c8a8b6 shipped broken).

NEGATIVE CONTROLS, each run against deliberately broken source and each confirmed
to go red before being believed. Three of the five passed GREEN the first time,
which is the whole reason they are written down:
  A. drop the node-change COMPARISON -> must fail. Passed green first: the check
     was `"node_changed" in text`, which the format specifier alone satisfies, so
     it could not see a dead comparison. Now anchored on the comparison.
  B. delete the whole worst-frame append -> must fail
  C. narrow the caller buffer back to 512 -> must fail. Passed green first: the
     control was in this docstring and no check was ever written for it.
  D. emit "worst:" unconditionally -> must fail. Passed green first: nothing
     asserted the gate existed.
  E. collapse the three-component isfinite test to one always-true predicate
     -> must fail

Exit codes: 0 pass, 1 fail. Never 2 -- a pattern that stops matching is a FAIL,
not a silent pass (AGENTS.md).
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
PIPE_H = os.path.join(ROOT, "TarkovAddons", "module", "optics_lens_pipeline.h")
API_H = os.path.join(ROOT, "TarkovAddons", "module", "eft_api.h")


def read(path):
    with open(path, encoding="utf-8", errors="replace") as fh:
        return fh.read()


def norm(text):
    return re.sub(r"\s+", "", text)


def evaluate():
    pipe, api = read(PIPE_H), read(API_H)
    pn, an = norm(pipe), norm(api)

    # The ring must carry the four new fields, or there is nothing to report.
    fields = ["unsignedlonglongnode_ptr;", "unsignedintparent_depth;",
              "floatraw_len;", "unsignedcharfinite;"]
    results = [
        ("ring sample carries node identity",
         all(f in pn for f in fields[:2])),
        ("ring sample carries raw_len and finite",
         all(f in pn for f in fields[2:])),

        # The capture site must FILL identity/depth, not leave them zero forever.
        ("capture site records the node pointer",
         "hands_self_node_ptr=static_cast<unsignedlonglong>(node);" in pn),
        ("capture site records the chain depth",
         "hands_self_depth=static_cast<unsignedint>(chain_index);" in pn),

        # The writer must pass them through.
        ("recorder forwards node and depth",
         "hands_self_node_ptr,hands_self_depth" in pn),

        # The summary must detect and report the worst frame.
        ("summary tracks a worst frame",
         "kSuspiciousMoveMm" in pn and "worst_move_mm" in pn),
        # The GATE. Unasserted until now, and NEG D proved it: removing the
        # condition still left the test green, because nothing checked for it.
        # A permanently-present "worst:" is exactly the noise the comment above
        # the append warns about -- every window carrying a field trains the reader
        # to skip it -- so the gate is part of the contract, not an implementation
        # detail.
        ("worst-frame section is GATED on a real condition",
         "if(worst_idx>=0){" in pn),
        # ANCHORED ON THE COMPARISON, not on the identifier. The first version of
        # this check was `"node_changed" in pn`, and its negative control FAILED to
        # go red: renaming the declaration left the format string and the argument
        # list still containing the substring, so the check passed against code
        # whose comparison had been renamed away. A substring test cannot tell a
        # live comparison from a dead format specifier, so the check names the
        # expression that decides the answer.
        ("node-change verdict comes from a pointer comparison",
         "w.node_ptr!=worst_prev_ptr" in pn),
        ("depth-change verdict comes from a depth comparison",
         "w.parent_depth!=worst_prev_depth" in pn),
        ("both verdicts are passed to the format, not just named",
         re.search(r"node_changed\?1:0,\s*depth_changed\?1:0", pn) is not None),
        ("summary reports the non-finite count",
         "nonfinite_frames" in pn and "NONFINITE" in pn),

        # isfinite, not a threshold compare: a NaN fails every comparison, so
        # `len < kSaneLen` would classify it as fine.
        ("non-finite is detected with isfinite",
         "std::isfinite" in pn),
        # The TRAP this guards. A NaN fails every comparison, so the obvious
        # implementation -- `len < kSaneLen` -- classifies NaN as FINE and reports
        # the frame as clean. That is why the comment in the recorder says the flag
        # exists at all, and why replacing isfinite with an always-true predicate
        # has to be caught here rather than discovered on a capture that happens to
        # contain one.
        ("finite is a three-component isfinite test, not one flag",
         pn.count("std::isfinite") >= 3),

        # The threshold must not be the spec's 20 mm correction budget, or every
        # weapon-sway frame gets reported.
        ("suspicious threshold is distinct from the 20 mm budget",
         "kSuspiciousMoveMm=1000.f" in pn),

        # The caller's buffer must hold BOTH halves. 512 was the original value and
        # the distribution line alone filled most of it, so the appended worst-frame
        # report was being truncated -- i.e. the field that answers the question was
        # the part cut off. This check existed in the docstring from the start and
        # was never written, so its negative control passed too.
        ("caller buffer widened past the old 512",
         re.search(r"charbuf\[(\d+)\]", an) is not None
         and int(re.search(r"charbuf\[(\d+)\]", an).group(1)) >= 1024),
    ]
    return results


def test_optic_root_frame_report_is_wired():
    """pytest entry point. No sys.exit: that aborts collection for the suite."""
    failures = []
    for name, passed in evaluate():
        print(("  PASS  " if passed else "  FAIL  ") + name)
        if not passed:
            failures.append(name)
    assert not failures, "failed: " + ", ".join(failures)


def main():
    failures = [n for n, ok in evaluate() if not ok]
    print()
    if failures:
        print("FAILED %d check(s): %s" % (len(failures), ", ".join(failures)))
        return 1
    print("OK - suspicious-frame report wired and thresholds distinct")
    return 0


if __name__ == "__main__":
    sys.exit(main())