"""No runtime-built string may reach the metadata memoisation.

`il2utils::resolve_field` / `resolve_method` memoise on a key that copies the
name's CONTENT (il2cpp/meta_key.h). That makes a `.c_str()` safe as long as the
pointed-to string is alive for the duration of the call -- true for a named
local, and true for a temporary too, because nothing derived from the pointer
outlives the call.

What it does NOT make safe is a pointer that is stored, or a string that dies
before the call. So this checks the shapes that would break:

  * a name argument that is a chained call result -- `(std::string(a) + b).c_str()`,
    `make_name().c_str()` -- where the temporary's lifetime is the full-expression
    and the pointer is easy to hold past it;
  * a name argument that is not a literal and not a plain identifier, which is
    anything this file cannot reason about.

A named local is allowed and is the one pattern in the tree today:
PlayerModule.cpp:833-845 builds `trader_id_key` and passes `.c_str()`. It is
safe because the local outlives the call, and it is the reason the key had to be
content-based in the first place -- see meta_key.h for the full argument.

Deliberately does NOT try to prove lifetime correctness in general. It fails on
shapes it cannot classify, which is the conservative direction: a new call site
has to be obviously fine, not obviously fine to a regex.

The scanner has been wrong twice (it read a declaration's parameter list as an
argument list, and it read a comment as a call), so it is written to fail
closed: anything it cannot positively identify as a call is skipped, and the
first test asserts it found a plausible number of real ones.
"""
import io
import re
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
ROOT = REPO / "TarkovAddons"

CALL = re.compile(
    r"\b(?:il2utils::)?(?:resolve_field|resolve_method|get_method|get_field)\s*"
    r"(?:<[^<>]*>)?\s*\(",
    re.S,
)

def is_call(before: str) -> bool:
    """True when the text before a callee is a call rather than a declaration.

    `.` and `->` are the member forms, `::` the qualified free form, and the
    punctuation set below is statement/expression starts. The one ambiguous
    character is `*`: `FieldInfo* resolve_field(` is a declaration while
    `a * resolve_field(` is a call. Resolved by looking one token back -- an
    identifier, `>`, `]` or `_` before the star means a pointer in a type.

    Biased toward SKIP. A declaration read as a call is a false alarm that
    costs a review; a call read as a declaration is a hole.
    """
    b = before.rstrip()
    if not b:
        return True  # start of line
    c = b[-1]
    if c in ".=,:;!&|+-/<>^~?({[":
        return True
    if c == "*":
        j = len(b) - 1
        while j > 0 and b[j - 1] in " \t":
            j -= 1
        if j >= 1 and (b[j - 1].isalnum() or b[j - 1] in ">_]"):
            return False
        return True
    return False


def strip_comments(text: str) -> str:
    """Blank out // and /* */ comments, preserving offsets and newlines.

    Offsets matter: the scanner reports line numbers, and a comment stripped
    without preserving length would move every line after it.
    """
    out = list(text)
    i = 0
    n = len(text)
    while i < n:
        if text.startswith("//", i):
            j = text.find("\n", i)
            j = n if j == -1 else j
            for k in range(i, j):
                out[k] = " "
            i = j
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2)
            j = n if j == -1 else j + 2
            for k in range(i, j):
                if out[k] != "\n":
                    out[k] = " "
            i = j
        else:
            i += 1
    return "".join(out)


def split_args(text: str) -> list:
    """Split an argument list on top-level commas. `<` and `>` are deliberately
    NOT brackets: a template argument list is not a bracket pair here, and
    treating it as one is what made an earlier version of this check read the
    arity of a real call as its name argument."""
    args, depth, cur = [], 0, []
    for ch in text:
        if ch in "([":
            depth += 1
        elif ch in ")]":
            depth -= 1
        if ch == "," and depth == 0:
            args.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    args.append("".join(cur).strip())
    return args


def name_arg_index(callee: str, before: str) -> int:
    """Which argument holds the name.

      * free form   il2utils::resolve_field(clazz, name) /
                    il2utils::resolve_method(clazz, name, argc)   -- arg 1
      * member form instance.get_method<T>("Unload", 1, ...) and
                    loot_instance.get_field<T>("_item")            -- arg 0

    The member form is recognised by the `.` or `->` immediately before the
    callee.
    """
    is_member = before.rstrip().endswith(".") or before.rstrip().endswith("->")
    if callee in ("get_field", "get_method"):
        return 0 if is_member else 1
    return 1


def classify(arg: str) -> str:
    """'literal' | 'named' | a documented safe-runtime shape | 'other'.

    With a content-based key every one of these is safe, because the key copies
    the bytes during the call and nothing derived from the pointer outlives it.
    What would be unsafe is a pointer that is STORED, or a string that is
    already dead -- and neither is a property of the call site's shape. So the
    safe-runtime shapes are named explicitly rather than lumped into "other",
    which is what makes a new one visible instead of silently accepted:

      * `x.c_str()`        -- a named local, alive for the whole call. The one
                              in the tree is PlayerModule.cpp:845.
      * `ARR[i]`           -- a pointer into an array, static or live.
      * `x.name`           -- a member of a named variable.

    'other' is reserved for shapes that build a string: a chained call result,
    a concatenation, a parenthesised expression. Those are the ones that would
    break if the key ever went back to pointer identity.
    """
    a = arg.strip()
    if a.startswith('"'):
        return "literal"
    if re.fullmatch(r"[A-Za-z_]\w*(?:::\w+)*", a):
        return "named"
    if re.fullmatch(r"[A-Za-z_]\w*\.c_str\(\)", a):
        return "named_runtime_cstr"
    if re.fullmatch(r"[A-Za-z_]\w*\[[^\]]*\]", a):
        return "named_indexed"
    if re.fullmatch(r"[A-Za-z_]\w*\.\w+", a):
        return "named_member"
    return "other"


def scan():
    """Every memoising call site, with its name argument classified."""
    found = []
    for path in sorted(list(ROOT.rglob("*.h")) + list(ROOT.rglob("*.cpp"))):
        if "external" in path.parts:
            continue
        text = strip_comments(io.open(path, encoding="utf-8", errors="replace").read())
        for m in CALL.finditer(text):
            callee = m.group(0).split("<")[0].split("(")[0].strip()
            before = text[: m.start()]
            if not is_call(before):
                continue  # a declaration, not a call

            i = m.end() - 1
            depth = 0
            while i < len(text):
                if text[i] in "([":
                    depth += 1
                elif text[i] in ")]":
                    depth -= 1
                    if depth == 0:
                        break
                i += 1
            if i >= len(text):
                continue
            args = split_args(text[m.end():i])
            idx = name_arg_index(callee, before)
            if len(args) <= idx:
                continue
            found.append((path, text[: m.start()].count("\n") + 1,
                          callee, args[idx].strip(), classify(args[idx].strip())))
    return found


def test_the_scanner_finds_real_call_sites():
    """Guard the guard: a scanner that finds nothing makes the rest vacuous."""
    sites = scan()
    assert len(sites) >= 100, (
        "only %d memoising call sites found; the scanner is too narrow and the "
        "checks below are vacuous" % len(sites))
    literals = sum(1 for s in sites if s[4] == "literal")
    assert literals >= 50, (
        "only %d literal-name call sites; expected the bulk of them" % literals)


def test_memo_name_arguments_are_literals_or_named_variables():
    sites = scan()
    other = [(p, ln, c, a) for p, ln, c, a, k in sites if k == "other"]
    assert not other, (
        "these call sites pass a name this check cannot classify, and a "
        "runtime-built string reaching the metadata memo is exactly the "
        "hazard meta_key.h exists to prevent:\n  "
        + "\n  ".join(f"{p.relative_to(REPO)}:{ln}  {c}(..., {a})"
                     for p, ln, c, a in other)
    )


def _enclosing_function(path, line):
    """Name of the function whose body contains `line`, by scanning backwards
    for a PlayerModule:: definition.

    The pinned call site is identified by its enclosing FUNCTION, not its line
    number. The first version of this test pinned line 845 and my own edit to
    an unrelated block above it moved the call to 882 and turned the check red
    for no reason -- the test was asserting a line offset, which is a fact about
    the file's history rather than about safety. The function is the thing worth
    pinning.
    """
    lines = io.open(path, encoding="utf-8", errors="replace").read().splitlines()
    for i in range(line - 1, -1, -1):
        m = re.match(r"\s*(?:void|bool|int|float|double|char|std::string|auto)\s+"
                     r"PlayerModule::(\w+)\s*\(", lines[i])
        if m:
            return m.group(1)
    return None


def test_the_known_runtime_string_call_site_is_a_named_local():
    """The one .c_str() in the tree, and it is safe.

    Pinned so that if someone changes it to a temporary, or adds a second
    runtime-string site, this fails rather than the hazard arriving quietly.
    """
    sites = scan()
    cstr = [(p, ln, a) for p, ln, c, a, k in sites if ".c_str()" in a]
    assert len(cstr) == 1, (
        "expected exactly one .c_str() memoising call site, found "
        f"{len(cstr)}:\n  "
        + "\n  ".join(f"{p.relative_to(REPO)}:{ln} {a}" for p, ln, a in cstr))
    path, line, arg = cstr[0]
    assert path.name == "PlayerModule.cpp", (
        f"the single .c_str() site is no longer in PlayerModule.cpp: "
        f"{path.relative_to(REPO)}:{line}")
    owner = _enclosing_function(path, line)
    assert owner == "gameworld_update", (
        "the single .c_str() memoising site moved out of "
        f"PlayerModule::gameworld_update -- it is now in {owner!r} at "
        f"{path.relative_to(REPO)}:{line}. Re-check its lifetime by hand.")
    assert arg == "trader_id_key.c_str()", (
        f"the .c_str() argument changed shape: {arg!r}")


def test_the_memo_key_is_content_based_not_pointer_based():
    """The property the whole design rests on, asserted from the source.

    meta_key.h must copy the name's bytes. If it ever keys on the name POINTER
    the PlayerModule.cpp:845 pattern becomes a wrong-value bug, so this reads
    the header rather than trusting the comment.
    """
    src = (ROOT / "il2cpp" / "meta_key.h").read_text(encoding="utf-8")
    assert "std::memcpy(name, n, len + 1)" in src, (
        "meta_key.h no longer copies the name content into the key; the memo is "
        "no longer content-based and PlayerModule.cpp:845 is unsafe")
    assert "reinterpret_cast<std::uintptr_t>(clazz_ptr)" in src, (
        "meta_key.h must still key on the class address")
    assert "const char* name" not in src, (
        "meta_key.h stores a name pointer again -- that is the rejected design")


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))