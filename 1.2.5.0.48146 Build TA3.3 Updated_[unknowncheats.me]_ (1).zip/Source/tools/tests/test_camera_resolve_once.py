"""Text test for the aimbot's camera resolution: once per pass, not once per bone.

WHY A TEXT TEST, AND WHY THAT IS NOT A COMPROMISE
-------------------------------------------------
The thing being asserted is a *call-site placement*: that
`resolve_esp_camera_frame` is called outside the candidate loop and its result
passed in, rather than `world_to_screen_prefer_optic` being called per iteration.
There is no way to observe that without loading the DLL, standing up a Unity
camera list and racing the game thread -- which is flaky, needs the game, and
cannot distinguish the two shapes from outside anyway. The invariant is entirely
about where one statement sits relative to a loop, so reading the source is the
right tool. `test_tracy_start_order.py` in this directory does the same for the
same reason and states the argument at length.

WHAT MAKES IT HONEST
--------------------
  * comments and string literals are blanked before anything is matched, so this
    file's own prose -- which names every symbol -- cannot satisfy an assertion
    by being matched as text;
  * the anchor for "outside the loop" is the LOOP'S OWN BODY, found by brace
    matching from `for (const auto &target_object`, so a resolve call that merely
    appears earlier in the function but still inside some other loop cannot pass;
  * a negative control re-runs every assertion against a reverted copy. If the
    control passes, the test is vacuous and fails loudly.

THE NUMBER THAT PROMPTED IT
---------------------------
2026-10-04, `next_next_next_day+crash.tracy`:

    eft_api::w2s_prefer_optic:resolve_camera
        154,544 calls   6.33 s self   41.0 us mean   15.71 ms max
    aimbot::project_to_screen    153,725 calls   incl max 55.72 ms
    aimbot::candidate_pick        22,431 calls   incl 16.81 s

154,544 resolutions for 22,431 picks is 6.9x redundancy, and 15.52 s of
candidate_pick's 16.81 s inclusive -- 92% of the whole pick cost -- was camera
resolution. The two identical 55.72 ms maxima place that frame's stall inside a
single resolve call.

`pick_esp_fps_camera` is reached through `unity::find_camera_if_best`, which is
backed by Unity's `Camera.all`: a FRESH MANAGED ARRAY ALLOCATION per call plus a
GetName per camera in the scene. So the redundancy is an allocation per projected
bone, not a cheap redundant read.

And the resolution is not adaptive, so there is nothing to amortise:
`cam-choice: resolves=25696 named=25696 fallback=0 none=0 | named_multi=0 far=0
far_refused=0`. Every call succeeded by name.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

AIMBOT = (
    Path(__file__).resolve().parents[2]
    / "TarkovAddons"
    / "module"
    / "impl"
    / "AimbotModule.cpp"
)
API = (
    Path(__file__).resolve().parents[2]
    / "TarkovAddons"
    / "module"
    / "eft_api.h"
)

_COMMENTS_AND_LITERALS = re.compile(
    r'"(?:\\.|[^"\\])*"'
    r"|'(?:\\.|[^'\\])*'"
    r"|/\*.*?\*/"
    r"|//[^\n]*",
    re.DOTALL,
)


def code_only(text: str) -> str:
    out, pos = [], 0
    for m in _COMMENTS_AND_LITERALS.finditer(text):
        out.append(text[pos:m.start()])
        out.append(" " * (m.end() - m.start()))
        pos = m.end()
    out.append(text[pos:])
    return "".join(out)


def brace_body(code: str, anchor: str, opener: str = "{") -> tuple[str, int]:
    """Brace-matched body starting at `anchor`'s first `opener`.

    Returns (body_without_braces, line_of_opener). Fails loudly if the anchor is
    absent or the braces do not balance, rather than returning something a test
    could quietly assert against.
    """
    i = code.find(anchor)
    assert i != -1, f"anchor not found: {anchor!r}"
    start = code.index(opener, i)
    depth = 0
    for j in range(start, len(code)):
        if code[j] == "{":
            depth += 1
        elif code[j] == "}":
            depth -= 1
            if depth == 0:
                return code[start + 1:j], code.count("\n", 0, start) + 1
    pytest.fail(f"braces unbalanced after {anchor!r}")


def assert_camera_resolved_once(src: str, api_src: str) -> None:
    code = code_only(src)

    loop_body, _ = brace_body(code, "for (const auto &target_object")

    # 1. The per-bone path must NOT resolve. This is the assertion the whole change
    #    exists for, so it is checked first and phrased as the thing that regressed.
    assert "world_to_screen_prefer_optic" not in loop_body, (
        "the candidate loop projects with world_to_screen_prefer_optic again -- that "
        "wrapper resolves the camera internally, once per candidate"
    )
    assert not re.search(r"resolve_esp_camera\s*\(", loop_body), (
        "the candidate loop calls resolve_esp_camera directly again"
    )

    # 2. It must use the hoisted frame.
    assert "world_to_screen_with_frame" in loop_body, (
        "the loop does not project through world_to_screen_with_frame"
    )

    # 3. The resolve happens BEFORE the loop and is held in a variable.
    #    `before` is everything preceding the loop; this is what makes "once per
    #    pass" a claim about placement rather than about the loop body alone.
    before = code[: code.find("for (const auto &target_object")]
    assert "resolve_esp_camera_frame" in before, (
        "resolve_esp_camera_frame is not called before the candidate loop"
    )
    assert not re.search(r"resolve_esp_camera_frame", loop_body), (
        "resolve_esp_camera_frame is called INSIDE the loop -- that is per candidate "
        "again, which is the redundancy this was meant to remove"
    )
    # Held, not discarded: the value has to reach the projection.
    assert re.search(
        r"(?:const\s+)?(?:auto|eft_api::esp_camera_frame)\s+\w+\s*=\s*"
        r".*resolve_esp_camera_frame",
        before,
    ), "the resolved frame is not stored in a variable"

    # 4. The frame is passed, not reconstructed, at the projection site.
    m = re.search(
        r"world_to_screen_with_frame\s*\(\s*(\w+)\s*,\s*(\w+)", loop_body
    )
    assert m, "world_to_screen_with_frame is not called with two arguments"
    stored = re.search(
        r"(?:const\s+)?(?:auto|eft_api::esp_camera_frame)\s+(\w+)\s*=\s*"
        r".*resolve_esp_camera_frame",
        before,
    )
    assert stored, "could not identify the stored frame's name"
    assert m.group(2) == stored.group(1), (
        f"the projection is passed '{m.group(2)}' but the resolved frame is stored in "
        f"'{stored.group(1)}' -- the hoisted value is not the one being used"
    )

    # 5. The wrapper still exists and still resolves, because world_to_screen_aim_marker
    #    and the ESP call it. Deleting it would be a behaviour change, not a cleanup.
    api = code_only(api_src)
    assert "world_to_screen_prefer_optic" in api, (
        "world_to_screen_prefer_optic was removed -- it still has other callers"
    )

    # 6. The new helpers exist with the properties that make the hoist safe.
    assert re.search(r"struct\s+esp_camera_frame", api), "esp_camera_frame missing"
    assert re.search(r"resolve_esp_camera_frame\s*\(", api), (
        "resolve_esp_camera_frame missing"
    )
    assert re.search(r"world_to_screen_with_frame\s*\(", api), (
        "world_to_screen_with_frame missing"
    )

    # 7. scope_zoom is carried EXPLICITLY, because resolve_esp_camera rewrites its
    #    out_zoom to 1.f when the optic camera wins. Collapsing the two into one
    #    field would silently change the FPS projection path -- the kind of bug that
    #    shows up as "ESP is offset when not ADS" and nothing else.
    frame_body, _ = brace_body(api, "struct esp_camera_frame")
    assert "scope_zoom" in frame_body, (
        "esp_camera_frame does not carry scope_zoom; the projection cannot tell the "
        "calibration zoom from the mutated out_zoom without it"
    )

    # 8. A NEW zone name, not the old one. world_to_screen_prefer_optic keeps
    #    `w2s_prefer_optic:resolve_camera`, so sharing a name would merge
    #    "once per pass" with "once per point" -- exactly the averaging the split
    #    was added to prevent.
    assert 'TA_ZONE_N("eft_api::resolve_esp_camera_frame")' in api_src, (
        "resolve_esp_camera_frame has no zone, or shares the wrapper's -- the moved "
        "cost would be invisible or averaged with the per-call path"
    )


def test_camera_is_resolved_once_per_pass_not_once_per_candidate():
    assert_camera_resolved_once(
        AIMBOT.read_text(encoding="utf-8", errors="replace"),
        API.read_text(encoding="utf-8", errors="replace"),
    )


def test_negative_control_loop_resolve_fails():
    """Hoisting the resolve back INTO the loop must fail the test."""
    src = AIMBOT.read_text(encoding="utf-8", errors="replace")

    src = src.replace(
        """        const eft_api::esp_camera_frame cam_frame =
            eft_api::resolve_esp_camera_frame(true, game_state::current_zoom);

        for (const auto &target_object : target_objects)
        {
            unity::vector3 bone_pos{};""",
        """        for (const auto &target_object : target_objects)
        {
            const eft_api::esp_camera_frame cam_frame =
                eft_api::resolve_esp_camera_frame(true, game_state::current_zoom);
            unity::vector3 bone_pos{};""",
    )

    with pytest.raises(AssertionError):
        assert_camera_resolved_once(
            src, API.read_text(encoding="utf-8", errors="replace")
        )


def test_negative_control_reverting_to_the_wrapper_fails():
    """Going back to world_to_screen_prefer_optic per bone must fail the test."""
    src = AIMBOT.read_text(encoding="utf-8", errors="replace")
    src = src.replace(
        "eft_api::world_to_screen_with_frame(bone_pos, cam_frame)",
        "eft_api::world_to_screen_prefer_optic(\n"
        "                bone_pos, game_state::current_zoom)",
    )

    with pytest.raises(AssertionError):
        assert_camera_resolved_once(
            src, API.read_text(encoding="utf-8", errors="replace")
        )


def test_frame_carries_both_cameras_and_the_zoom():
    """The struct's fields, asserted individually.

    Each exists for a specific reason, and dropping one is a silent behaviour
    change rather than a compile error:
      cam          -- null means the pass projects nothing
      fps          -- the calibrator must not be handed the optic camera as its
                      own FPS reference
      scope_zoom   -- the calibration input, which is NOT resolve_esp_camera's
                      mutated out_zoom
      using_optic  -- selects the projection branch
    """
    api = code_only(API.read_text(encoding="utf-8", errors="replace"))
    body, _ = brace_body(api, "struct esp_camera_frame")
    for field in ("cam", "fps", "scope_zoom", "using_optic"):
        assert re.search(rf"\b{field}\b", body), f"esp_camera_frame lacks `{field}`"

    # The fps==cam normalisation must happen, or the calibrator self-calibrates.
    resolver, _ = brace_body(api, "resolve_esp_camera_frame")
    assert re.search(r"if\s*\(\s*f\.fps\s*==\s*f\.cam\s*\)\s*f\.fps\s*=\s*nullptr", resolver), (
        "resolve_esp_camera_frame does not null fps when it equals cam -- the optic "
        "calibrator would be handed the optic camera as its own FPS reference"
    )