"""Behavioural test for the pen walk's exit-face rule, and a text test for its wiring.

Two parts, because they check two different things and only one of them can be
checked by reading the source.

PART 1 -- the predicate itself, executed. `is_exit_face_normal` is pure arithmetic
over a normal and a direction, so it is ported 1:1 into Python below and run
against hand-built geometry. This is the part that actually decides whether a
pen-success is honest, and arithmetic is the right tool for arithmetic.

PART 2 -- the call site, as text. Whether the C++ actually *calls* that predicate
cannot be observed without a physics scene, so the wiring is asserted on the
source, with comments and string literals blanked first so that this file's own
explanatory comments -- which name every symbol involved -- cannot satisfy the
assertions by being matched as text. A negative control re-runs the same
assertions against a reverted copy; if the control passes, the test is vacuous
and says so.

THE BUG THIS EXISTS FOR
-----------------------
The exit-face rule skipped a re-hit when it merely SHARED AN ANCESTOR with the
previous layer (an eight-level climb) and sat within kExitFaceMaxDist (0.4 m) of
it. A metal cage with a cylinder inside it is one prefab, and the cylinder sits
within 0.4 m of the cage's inner face, so the cylinder was discarded as an "exit
face" and never graded. If the cage wall was penetrable the walk then reported
`clear` straight through a solid metal cylinder.

That failure is invisible from outside: a pen-success through a cylinder and a
correct pen-success produce the same verdict and the same tally. Which is why
part 1 below is about the *normal* -- the one piece of information that
distinguishes a surface being ENTERED from a surface being LEFT, and the only
part of the rule that is geometric rather than genealogical.
"""

from __future__ import annotations

import math
import re
from pathlib import Path

import pytest

VIS = (
    Path(__file__).resolve().parents[2]
    / "TarkovAddons"
    / "module"
    / "skeleton_visibility.h"
)

# kExitFaceMaxDist from skeleton_visibility.h. Duplicated rather than parsed: the
# test asserts the constant is still 0.4 separately, so a change to the header
# cannot silently move the bar the cases below were written against.
K_EXIT_FACE_MAX_DIST = 0.4


# --------------------------------------------------------------------------
# PART 1 -- the predicate, executed
# --------------------------------------------------------------------------

def is_exit_face_normal(n: tuple[float, float, float],
                        d: tuple[float, float, float],
                        deadband: float = 0.1) -> bool:
    """1:1 port of the lambda in skeleton_visibility.h.

    `len > 1e-3` is written as a negated comparison on purpose, mirroring the C++:
    `!(len > 1e-3)` is true for NaN, so a NaN normal returns False, which means
    "do not skip". Preserved deliberately -- it is the safe direction.
    """
    length = math.sqrt(n[0] ** 2 + n[1] ** 2 + n[2] ** 2)
    if not (length > 1e-3):
        return False
    dot = (n[0] * d[0] + n[1] * d[1] + n[2] * d[2]) / length
    return dot > deadband


def skips_as_exit_face(related: bool, distance: float,
                       normal: tuple[float, float, float],
                       direction: tuple[float, float, float] = (0.0, 0.0, 1.0),
                       ) -> bool:
    """The full skip condition, all three terms."""
    return (
        related
        and distance <= K_EXIT_FACE_MAX_DIST
        and is_exit_face_normal(normal, direction)
    )


# (name, normal, distance, related, expected_skip, why)
#
# "expected_skip" is the answer the GEOMETRY implies, derived from which way the
# surface faces -- not from what the old code did. Every `related=True` row is a
# surface belonging to the object just crossed or to something nested inside it.
CASES = [
    ("cage wall, first hit -- entering", (0, 0, -1), 0.05, True, False,
     "the entry face of the layer being classified is never an exit face"),
    ("cage wall, far side -- leaving", (0, 0, 1), 0.09, True, True,
     "the whole reason the rule exists: the bullet is exiting the same slab"),
    ("cylinder inside cage, entering", (0, 0, -1), 0.10, True, False,
     "THE BUG. Shares the cage's ancestor and sits 0.10 m inside it, so the old "
     "rule skipped it and reported clear through solid metal"),
    ("cylinder inside cage, leaving", (0, 0, 1), 0.10, True, True,
     "the cylinder's own far side, once genuinely exiting it"),
    ("thin shell, entering", (0, 0, -1), 0.02, True, False,
     "a 2 cm shell is thin enough that its two faces are trivially close together"),
    ("thin shell, leaving", (0, 0, 1), 0.02, True, True,
     "same shell, far side"),
    ("second surface 0.30 m on, entering", (0, 0, -1), 0.30, True, False,
     "close AND related but facing the ray: a genuinely separate surface"),
    ("second surface 0.30 m on, leaving", (0, 0, 1), 0.30, True, True,
     "close, related, and downstream"),
    ("far side of a thick slab, 0.90 m", (0, 0, 1), 0.90, True, False,
     "correctly downstream, but 0.90 m is past kExitFaceMaxDist so the distance "
     "bound still applies -- a thick object is not an exit face"),
    ("edge-on, normal perpendicular", (1, 0, 0), 0.05, True, False,
     "an edge-on normal carries no usable facing information, so do not skip"),
    ("degenerate, zero normal", (0, 0, 0), 0.05, True, False,
     "cannot measure the normal, so must not authorise discarding a layer"),
    ("non-unit normal, backward", (0, 0, -9), 0.05, True, False,
     "m_normal is not guaranteed unit length; sign after normalising is what counts"),
    ("non-unit normal, forward", (0, 0, 9), 0.05, True, True,
     "same, pointing downstream"),
    ("just inside the deadband", (1, 0, 0.05), 0.05, True, False,
     "0.05 downstream is inside the +/-0.1 band, so it is treated as edge-on"),
    ("just past the deadband", (1, 0, 0.15), 0.05, True, True,
     "0.15 downstream is past the band and counts as downstream"),
]


@pytest.mark.parametrize("name,normal,distance,related,expected,_why", CASES)
def test_skip_decision_matches_geometry(name, normal, distance, related,
                                         expected, _why):
    got = skips_as_exit_face(related, distance, normal)
    assert got is expected, (
        f"{name}: skip={got}, geometry says {expected}. "
        f"normal={normal} dist={distance:.2f} related={related}"
    )


def test_the_cylinder_case_is_the_one_that_changed():
    """The regression, stated on its own so a failure names the actual bug.

    Same relatedness and same distance as an ordinary exit face -- only the normal
    differs. Under the old rule both were skipped; now only the leaving one is.
    """
    entering = skips_as_exit_face(True, 0.10, (0, 0, -1))
    leaving = skips_as_exit_face(True, 0.10, (0, 0, 1))
    assert entering is False, (
        "a surface FACING the ray was discarded as an exit face -- this is the "
        "cylinder-inside-a-cage pen-success"
    )
    assert leaving is True, (
        "the genuine exit face was not skipped -- the rule stopped doing its job"
    )


def test_unrelated_is_never_skipped_regardless_of_normal():
    """A downstream normal alone must not authorise a skip on an unrelated object.

    Guards the opposite error: if the normal test were used *instead of* relatedness
    rather than in addition to it, any far-facing hit would vanish from the walk.
    """
    for normal in ((0, 0, 1), (0, 0, -1), (1, 0, 0)):
        assert skips_as_exit_face(False, 0.05, normal) is False


# --------------------------------------------------------------------------
# PART 1b -- the re-entry rule on the SAME collider
# --------------------------------------------------------------------------
#
# Different question from the above, and it was the second half of the same bug.
#
# `layer_ballistic == prev_ballistic` was the whole test for "the bullet is exiting
# a collider it already paid for". But that pointer equality cannot tell two cases
# apart, because BOTH return the same component:
#
#   (a) EXIT   -- the far side of a shell. One PenetrationLevel describes the whole
#                 component, so charging again would bill for material already crossed.
#   (b) RE-ENTRY -- the collider is compound (nested walls, a barrel, a double-skinned
#                 panel) and the ray has come back around into it. The single level
#                 does NOT describe that: the component has more surfaces than the
#                 one number.
#
# Identity-only assumed (a). The discriminator is the same normal used above, and it
# asks about the SURFACE rather than naming the OBJECT.

def skips_same_collider(same_collider: bool,
                        normal: tuple[float, float, float],
                        direction: tuple[float, float, float] = (0.0, 0.0, 1.0),
                        ) -> tuple[bool, bool]:
    """Returns (skipped, is_reentry) for the same-collider branch."""
    if not same_collider:
        return False, False
    exiting = is_exit_face_normal(normal, direction)
    if exiting:
        return True, False
    return False, True


def test_reentry_into_a_compound_shell_is_not_an_exit():
    """The core case: same collider, normal facing the ray, so it is a NEW layer."""
    skipped, reentry = skips_same_collider(True, (0, 0, -1))
    assert skipped is False, (
        "a re-entry was skipped as an exit -- the round passes through a second "
        "shell of a compound collider for free"
    )
    assert reentry is True, "the re-entry was not identified as one"


def test_genuine_exit_of_the_same_collider_is_still_skipped():
    """The rule's original purpose must survive: one level per component."""
    skipped, reentry = skips_same_collider(True, (0, 0, 1))
    assert skipped is True, (
        "a genuine exit face of an already-crossed collider was graded again -- "
        "one PenetrationLevel covers the component, so this double-bills"
    )
    assert reentry is False


def test_identity_alone_cannot_tell_them_apart():
    """States the reason the normal is needed, as an executable claim.

    Both cases are the same collider and therefore the same pointer. Any test built
    only on identity returns the same answer for both, which is the bug.
    """
    exit_skipped, _ = skips_same_collider(True, (0, 0, 1))
    reentry_skipped, _ = skips_same_collider(True, (0, 0, -1))
    assert exit_skipped != reentry_skipped, (
        "the two cases are indistinguishable, so the rule cannot be implemented "
        "without the normal"
    )


def test_reentry_with_a_degenerate_normal_counts_rather_than_skips():
    """Ambiguity resolves towards grading the layer.

    The two failure modes are not symmetric: over-counting a wall makes the wall
    check refuse a shot it should allow, while under-counting lets the round pass
    through material the game would stop it on. Only one of those is a cheat that
    does not work.
    """
    for normal in ((0, 0, 0), (1e-9, 0, 0), (0, -0.0, 1e-12)):
        skipped, reentry = skips_same_collider(True, normal)
        assert skipped is False
        assert reentry is True


def test_nan_normal_is_treated_as_unmeasurable_not_as_downstream():
    """`!(len > 1e-3)` is true for NaN, so a NaN normal returns False.

    Written as a test because that is the whole reason for the negated comparison.
    A plain `len < 1e-3` guard would let NaN through to the dot product, and NaN > 0.1
    is false, so it happens to land the same way -- but by accident, and the next
    edit to that line would not be so lucky.
    """
    nan = float("nan")
    assert is_exit_face_normal((nan, nan, nan), (0.0, 0.0, 1.0)) is False
    skipped, reentry = skips_same_collider(True, (nan, nan, nan))
    assert skipped is False and reentry is True


# --------------------------------------------------------------------------
# PART 2 -- the wiring, as text
# --------------------------------------------------------------------------

_COMMENTS_AND_LITERALS = re.compile(
    r'"(?:\\.|[^"\\])*"'
    r"|'(?:\\.|[^'\\])*'"
    r"|/\*.*?\*/"
    r"|//[^\n]*",
    re.DOTALL,
)


def code_only(text: str) -> str:
    out, pos = [], 0
    for m in _COMMENTS_AND_LITERALS.finditer(text):
        out.append(text[pos:m.start()])
        out.append(" " * (m.end() - m.start()))
        pos = m.end()
    out.append(text[pos:])
    return "".join(out)


def assert_wiring(src: str) -> None:
    code = code_only(src)
    body_start = code.find("is_target_visible_penetrating")
    assert body_start != -1, "is_target_visible_penetrating not found at all"
    body = code[body_start:]

    # 1. the three-term condition, all present in one `if`.
    #    Matched loosely on purpose: the assertion is that `exiting` is part of the
    #    skip decision, not that the expression is formatted a particular way.
    assert re.search(
        r"related\s*&&\s*just_behind\s*&&\s*exiting", body
    ), (
        "the skip condition no longer requires `exiting` -- the normal test is "
        "defined but not consulted, so a nested surface is discarded again"
    )

    # 2. the tightened relatedness: no multi-level ancestor climb.
    #    A loop that re-calls transform_get_parent inside same_object is the old
    #    eight-level walk. Exactly one call, outside any loop, is the fix.
    m = re.search(r"auto\s+same_object\s*=\s*\[.*?\]?\s*\(.*?\{", body, re.DOTALL)
    assert m, "same_object lambda not found"
    # brace-match the lambda body
    i = body.index("{", m.end() - 1)
    depth = 0
    for j in range(i, len(body)):
        if body[j] == "{":
            depth += 1
        elif body[j] == "}":
            depth -= 1
            if depth == 0:
                break
    lam = body[i:j]
    assert "for (" not in lam and "for(" not in lam, (
        "same_object climbs the hierarchy in a loop again -- that is the "
        "eight-level walk that made every object in a prefab 'related'"
    )
    assert lam.count("transform_get_parent") == 1, (
        "same_object must consult exactly ONE parent level; "
        f"found {lam.count('transform_get_parent')}"
    )

    # 3. both skip paths are counted. The tally is the only way to bound how often
    #    this fires, and an uncounted skip is how the bug stayed invisible.
    assert re.search(r"\+\+\s*g_pen_skip_hierarchy\s*\(\s*\)", body), (
        "the hierarchy skip is not counted -- skipped layers are invisible in the "
        "tally again, so a pen-success that dropped a layer cannot be told apart "
        "from a correct one"
    )
    assert re.search(r"\+\+\s*g_pen_skip_same_ballistic\s*\(\s*\)", body), (
        "the same-ballistic skip is not counted; the two paths are different tests "
        "and one number would hide which is over-firing"
    )
    # The RE-ENTRY counter is what makes the same-ballistic number mean something.
    # Without it, "sameBallistic=N" reads as "N layers were correctly skipped" when
    # some of those were re-entries that should have been graded.
    assert re.search(r"\+\+\s*g_pen_reentry\s*\(\s*\)", body), (
        "re-entries are not counted -- the same-ballistic figure cannot be read as "
        "'layers correctly skipped' without knowing how many were re-entries"
    )

    # 3b. THE RE-ENTRY RULE. `layer_ballistic == prev_ballistic` must NOT skip on
    #     its own. Identity cannot distinguish a collider's far side (already paid
    #     for, one PenetrationLevel covers the component) from a SECOND ENTRY into a
    #     compound shell (a real second layer the single level does not describe).
    #     Both return the same pointer, so identity-only assumes the benign case.
    m2 = re.search(r"if\s*\(\s*same_collider\s*&&\s*exiting\s*\)", body)
    assert m2, (
        "the same-collider skip does not require an exit-face normal -- a re-entry "
        "into a compound shell is being treated as an exit, which under-counts "
        "layers (the opposite error from the hierarchy skip, and the same mistake: "
        "a test that names a thing instead of the property being asked about)"
    )
    assert re.search(r"else\s+if\s*\(\s*same_collider\s*\)", body), (
        "there is no same-collider-but-not-exiting branch; a re-entry must fall "
        "through to be graded like any other layer"
    )
    assert "same_collider = (layer_ballistic == prev_ballistic)" in code.replace(" ", " ").replace(
        "same_collider=(layer_ballistic==prev_ballistic)", "same_collider = (layer_ballistic == prev_ballistic)"
    ) or re.search(r"same_collider\s*=\s*\(\s*layer_ballistic\s*==\s*prev_ballistic\s*\)", body), (
        "same_collider is not derived from layer_ballistic == prev_ballistic"
    )

    # 4. the counters are declared outside INCLUDE_AIMBOT, next to pen_stop, and
    #    reset with the rest. A counter that is never reset reads as a lifetime
    #    total and gets compared against a 30 s window by mistake.
    assert "g_pen_skip_hierarchy" in code, "counter storage missing"
    reset = code[code.find("reset") : ] if "reset" in code else code
    assert re.search(r"g_pen_skip_hierarchy\s*\(\s*\)\s*=\s*0", reset), (
        "the skip counters are never reset"
    )
    assert re.search(r"g_pen_skip_same_ballistic\s*\(\s*\)\s*=\s*0", reset), (
        "the same-ballistic counter is never reset"
    )

    # 5. reported, so the counts can be read against the verdicts they may have
    #    changed. Matched against RAW source, not code_only(): the reporter emits
    #    "skippedLayers=" inside a string literal, which the comment/literal stripper
    #    blanks by design. Blanking it here would make this assertion
    #    unsatisfiable, which is worse than not having it.
    raw = src
    assert "skippedLayers=" in raw, (
        "the skip counters are not reported -- collected and never printed is the "
        "same as not collected"
    )


def test_exit_face_rule_is_wired_as_intended():
    assert_wiring(VIS.read_text(encoding="utf-8", errors="replace"))


def test_negative_control_reverted_source_fails():
    """If a reverted copy passes, the test is vacuous and must say so.

    Reverts the three things the assertions above require: drops `&& exiting`,
    restores the ancestor loop, and removes both counters.
    """
    src = VIS.read_text(encoding="utf-8", errors="replace")

    src = src.replace("related && just_behind && exiting", "related && just_behind")

    # restore the loop form of same_object
    src = re.sub(
        r"(Il2CppObject\* up = unity::transform_get_parent\(ref_transform\);\s*"
        r"if \(!up\) return false;\s*"
        r"Il2CppObject\* anc_go = unity::component_get_game_object\(up\);\s*"
        r"return anc_go != nullptr && \(anc_go == prev_hit_go \|\| anc_go == prev_parent_go\);)",
        "Il2CppObject* up = unity::transform_get_parent(ref_transform);\n"
        "            for (int i = 0; i < 8 && up; ++i) {\n"
        "                Il2CppObject* anc_go = unity::component_get_game_object(up);\n"
        "                if (anc_go == prev_hit_go || anc_go == prev_parent_go) return true;\n"
        "                up = unity::transform_get_parent(up);\n"
        "            }\n"
        "            return false;",
        src,
    )

    src = re.sub(r"\+\+\s*g_pen_skip_hierarchy\s*\(\s*\)", "", src)
    src = re.sub(r"\+\+\s*g_pen_skip_same_ballistic\s*\(\s*\)", "", src)

    with pytest.raises(AssertionError):
        assert_wiring(src)


def test_negative_control_identity_only_same_collider_fails():
    """The pre-re-entry form -- skip on identity alone -- must fail.

    This is the shape the code actually shipped with, so it is the control that
    matters most: the other two reverts test assertions added alongside the fix,
    and this one tests the fix itself.
    """
    src = VIS.read_text(encoding="utf-8", errors="replace")

    # Collapse `same_collider && exiting` back to bare identity.
    src = src.replace("if (same_collider && exiting)", "if (same_collider)", 1)
    # And drop the re-entry branch, which is what absorbed the non-exiting case.
    src = re.sub(
        r"else\s+if\s*\(\s*same_collider\s*\)",
        "else if (false)",
        src,
    )
    src = re.sub(r"\+\+\s*g_pen_reentry\s*\(\s*\)", "", src)

    with pytest.raises(AssertionError):
        assert_wiring(src)


def test_exit_face_max_dist_unchanged():
    """The 0.4 m bound is load-bearing and the cases above are written against it."""
    src = VIS.read_text(encoding="utf-8", errors="replace")
    m = re.search(r"kExitFaceMaxDist\s*=\s*([0-9.]+)f", src)
    assert m, "kExitFaceMaxDist not found"
    assert float(m.group(1)) == K_EXIT_FACE_MAX_DIST, (
        f"kExitFaceMaxDist is {m.group(1)}, and the geometry cases in this file "
        f"assume {K_EXIT_FACE_MAX_DIST}. Update the cases or justify the change."
    )