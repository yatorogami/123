"""Text test for the UnityEngine class-resolve retry in `unity::init()`.

BACKGROUND
----------
The failure this protects against is real and was intermittent: two launches logged

    Loading Unity
    ERROR Unity init failed: required UnityEngine classes missing

and stopped the mod, with nothing else in the log. The cause is a race on
`il2cpp_class_from_name`'s per-image class hash map at `image + 0x30`, which that
function publishes BEFORE filling it and rebuilds only if the pointer is still null.
A reader that arrives in that window gets `xor eax, eax` -- null for EVERY name.

So the retry loop is load-bearing, and two things about WHERE its statements sit are
what make it correct. Both are invisible in review because the code reads as if the
guard were elsewhere:

  * the "resolved on attempt N" WARN must be gated on the loop SUCCEEDING. Inside the
    failure branch, `attempts_used > 0` means the exact opposite -- the retries ran
    and still came back null, which is the unrecoverable case and must not be
    announced as the race.
  * the failure report must pass the attempts ACTUALLY MADE. The `for` increments
    `attempts_used` on its way out, so the post-loop value is already the count, and
    `attempts_used + 1` prints "4 of 3".

WHY A TEXT TEST IS THE RIGHT TOOL HERE
--------------------------------------
Both are statements about where a statement sits relative to a guard, and neither is
observable without racing two threads against a real GameAssembly.dll. What the text
test protects is the fix surviving the next edit -- the same reasoning, and the same
negative-control discipline, as `test_unity_liveness_throttle.py` next to it.

Kept honest by:
  * comments and string literals blanked before matching, so this file's own prose --
    which names every symbol -- cannot satisfy an assertion as text;
  * negative controls that re-introduce each defect and MUST fail.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

UNITY = (
    Path(__file__).resolve().parents[2] / "TarkovAddons" / "il2cpp" / "unity.h"
)

_COMMENTS_AND_LITERALS = re.compile(
    r'"(?:\\.|[^"\\])*"'
    r"|'(?:\\.|[^'\\])*'"
    r"|/\*.*?\*/"
    r"|//[^\n]*",
    re.DOTALL,
)


def code_only(text: str) -> str:
    out, pos = [], 0
    for m in _COMMENTS_AND_LITERALS.finditer(text):
        out.append(text[pos:m.start()])
        out.append(" " * (m.end() - m.start()))
        pos = m.end()
    out.append(text[pos:])
    return "".join(out)


def function_body(src: str, name: str) -> str:
    code = code_only(src)
    m = re.search(r"\b" + re.escape(name) + r"\s*\([^;{]*\)\s*\{", code)
    if not m:
        pytest.fail(f"{name}() definition not found")
    start = m.end() - 1
    depth = 0
    for i in range(start, len(code)):
        if code[i] == "{":
            depth += 1
        elif code[i] == "}":
            depth -= 1
            if depth == 0:
                return code[start + 1:i]
    pytest.fail(f"{name}() braces unbalanced")


def block_of(src: str, opener: str) -> str:
    """Body of the first `opener { ... }` in code-only `src`."""
    code = code_only(src)
    i = code.find(opener)
    if i == -1:
        return ""
    start = code.index("{", i + len(opener) - 1)
    depth = 0
    for j in range(start, len(code)):
        if code[j] == "{":
            depth += 1
        elif code[j] == "}":
            depth -= 1
            if depth == 0:
                return code[start + 1:j]
    return ""


# --------------------------------------------------------------------------
# The five required classes must be ONE table, and re-resolved INSIDE the loop
# --------------------------------------------------------------------------

REQUIRED = ["Object", "GameObject", "Transform", "Component", "Camera"]

# `required[N] = { "Name", il2utils::resolve_class(...) }` -- matched on the RAW
# source, because code_only blanks string literals and this needs the name. A
# comment cannot satisfy it: prose in this file's own source would have to contain
# `required[0] = {` literally to match.
_ASSIGN = re.compile(r'required\[\s*(\d+)\s*\]\s*=\s*\{\s*"(\w+)"')


def assert_required_classes_retry(unity_src: str) -> None:
    body = function_body(unity_src, "init")

    # One table, not five locals. Five separate locals plus a combined
    # `if (!a || !b || ...)` is the shape that produced a failure line naming none
    # of them, and it is also a shape where the retry loop and the failure report
    # can disagree about what "required" means.
    count = re.search(r"kUnityRequiredClassCount\s*=\s*(\d+)", code_only(unity_src))
    assert count, "kUnityRequiredClassCount is missing"
    assert int(count.group(1)) == len(REQUIRED), (
        f"kUnityRequiredClassCount is {count.group(1)}, but the required set has "
        f"{len(REQUIRED)} members; the two must not be able to drift"
    )

    stray = re.findall(
        r"const Il2CppClass\*\s+\w+\s*=\s*il2utils::resolve_class\s*\(", body
    )
    assert not stray, (
        f"{len(stray)} required class(es) are still resolved straight into a local "
        "instead of the required-class table, so the failure report cannot name them"
    )

    loop = block_of(body, "for (; attempts_used")
    assert loop, "the bounded retry loop over attempts_used is gone"
    assert "Sleep" in loop, (
        "the retry loop does not wait between attempts -- three back-to-back "
        "lookups all land inside the same half-built map and learn nothing"
    )
    assert re.search(r"if\s*\(\s*all_required_resolved\s*\(", loop), (
        "the loop does not test all_required_resolved() before its next attempt"
    )
    assert re.search(r"\+\+\s*attempts_used|attempts_used\s*\+\+", body), (
        "attempts_used is never incremented, so the post-loop value is not the "
        "number of attempts made"
    )

    # The substantive one: the lookups must be INSIDE the loop. A retry that does
    # not re-run the failing lookups is not a retry, and the loop's exit condition
    # would then be testing a value that never changes.
    #
    # code_only is length-preserving, so an offset found in the blanked text is the
    # same offset in the raw source. That is how a raw match on the name -- which
    # code_only blanks away, being a string literal -- can still be tested for
    # being inside the loop. `body` itself cannot be located in the raw source: it
    # spans blanked comment regions, so it is located in the blanked text instead.
    blanked = code_only(unity_src)
    body_start = blanked.index(body)
    loop_start = body_start + body.index(loop)
    loop_end = loop_start + len(loop)

    assigns = _ASSIGN.findall(unity_src)
    assert len(assigns) == len(REQUIRED), (
        f"{len(assigns)} required-class assignment(s) found, expected "
        f"{len(REQUIRED)}; one per member, exactly once"
    )
    assert sorted(int(i) for i, _ in assigns) == list(range(len(REQUIRED))), (
        "the required-class table is not indexed 0..N-1 exactly once -- a repeated or "
        "skipped index means a member is never assigned and stays null forever"
    )
    assert {n for _, n in assigns} == set(REQUIRED), (
        f"the assigned names are {sorted({n for _, n in assigns})}, expected "
        f"{sorted(REQUIRED)} -- the failure report prints these names"
    )
    inside = [
        m for m in _ASSIGN.finditer(unity_src)
        if loop_start <= m.start() < loop_end
    ]
    assert len(inside) == len(REQUIRED), (
        f"only {len(inside)} of {len(REQUIRED)} required-class lookups are inside the "
        "retry loop; the rest are resolved once and never retried"
    )


def test_required_classes_are_resolved_by_a_bounded_retry():
    assert_required_classes_retry(UNITY.read_text(encoding="utf-8", errors="replace"))


def test_negative_control_lookup_outside_loop_fails():
    """Deleting one in-loop lookup must fail: a retry that stops re-running the
    failing lookups is not a retry. This is the shipped defect."""
    src = UNITY.read_text(encoding="utf-8", errors="replace")
    lines = src.split("\n")
    hits = [i for i, l in enumerate(lines) if _ASSIGN.search(l)]
    assert len(hits) == len(REQUIRED), "fixture changed; expected 5 assignments"
    del lines[hits[2]]
    with pytest.raises(AssertionError):
        assert_required_classes_retry("\n".join(lines))


def test_negative_control_loop_without_sleep_fails():
    """Three back-to-back attempts must fail."""
    src = UNITY.read_text(encoding="utf-8", errors="replace")
    src = re.sub(
        r"if\s*\(\s*attempts_used\s*\)\s*Sleep\s*\(\s*kRequiredClassDelayMs\s*\)\s*;",
        "",
        src,
    )
    with pytest.raises(AssertionError):
        assert_required_classes_retry(src)


# --------------------------------------------------------------------------
# The race WARN must be gated on SUCCESS, and outside the failure branch
# --------------------------------------------------------------------------

def assert_warn_is_gated_on_success(unity_src: str) -> None:
    body = function_body(unity_src, "init")

    failure = block_of(body, "if (!classes_ok")
    assert failure, (
        "the failure branch is no longer `if (!classes_ok)` -- if the condition was "
        "renamed the test cannot check that the WARN sits outside it"
    )
    assert "logger::warn" not in failure, (
        "the 'resolved on attempt N' WARN is INSIDE the failure branch, where "
        "`attempts_used > 0` means the retries ran and STILL returned null -- the "
        "unrecoverable case, which must not be announced as the race"
    )

    assert re.search(
        r"if\s*\(\s*classes_ok\s*&&\s*attempts_used\s*>\s*0\s*\)\s*logger::warn",
        body,
    ), (
        "the race WARN must be gated on `classes_ok && attempts_used > 0`; without "
        "the `classes_ok` conjunct it fires on the failure path too"
    )


def test_race_warn_is_gated_on_success():
    assert_warn_is_gated_on_success(UNITY.read_text(encoding="utf-8", errors="replace"))


def test_negative_control_warn_inside_failure_branch_fails():
    """Moving the WARN inside `if (!classes_ok)` must fail. This is the defect."""
    src = UNITY.read_text(encoding="utf-8", errors="replace")
    m = re.search(
        r"if\s*\(\s*classes_ok\s*&&\s*attempts_used\s*>\s*0\s*\)\s*(logger::warn\([^;]*?\);)",
        src,
        re.DOTALL,
    )
    assert m, "could not find the gated WARN to move"
    warn = m.group(1)
    src = src[: m.start()] + src[m.end():]
    src = src.replace(
        "        if (!classes_ok)\n        {\n",
        "        if (!classes_ok)\n        {\n            " + warn + "\n",
    )
    with pytest.raises(AssertionError):
        assert_warn_is_gated_on_success(src)


# --------------------------------------------------------------------------
# The attempt count reported on failure must be the count MADE
# --------------------------------------------------------------------------

def assert_attempt_count_is_not_off_by_one(unity_src: str) -> None:
    body = function_body(unity_src, "init")

    m = re.search(
        r"log_missing_unity_classes\s*\(\s*required\s*,\s*kUnityRequiredClassCount\s*,\s*([^)]*)\)",
        body,
    )
    assert m, "the failure branch does not report through log_missing_unity_classes()"
    arg = m.group(1).strip()
    assert arg == "attempts_used", (
        f"the failure report passes `{arg}`, but attempts_used is already the number "
        "of attempts MADE once the for-loop has exited (it increments on its way out). "
        "`attempts_used + 1` prints '4 of 3'."
    )


def test_attempt_count_is_not_off_by_one():
    assert_attempt_count_is_not_off_by_one(
        UNITY.read_text(encoding="utf-8", errors="replace")
    )


def test_negative_control_off_by_one_attempt_count_fails():
    """Passing `attempts_used + 1` must fail. This is the shipped defect."""
    src = UNITY.read_text(encoding="utf-8", errors="replace")
    src = src.replace(
        "log_missing_unity_classes(required, kUnityRequiredClassCount, attempts_used)",
        "log_missing_unity_classes(required, kUnityRequiredClassCount, attempts_used + 1)",
    )
    with pytest.raises(AssertionError):
        assert_attempt_count_is_not_off_by_one(src)