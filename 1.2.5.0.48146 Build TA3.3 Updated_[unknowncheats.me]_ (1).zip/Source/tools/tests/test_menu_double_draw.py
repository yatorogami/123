"""A value a card draws by hand must not also be in its automatic value list.

What this checks
----------------
`gui/menu/menu.cpp` draws every module card with this sequence:

    m->prepare_menu_draw();
    if (m->draw_menu_extra_before_values()) m->draw_menu_extra();
    m->apply([&](ConfigValue* c) {
        if (c->is_hidden_in_owner_menu())
            return;
        // (2026-10-12: the changed-from-default marker wraps this draw)
        c->draw();
    });
    if (!m->draw_menu_extra_before_values()) m->draw_menu_extra();

`Module::conf()` pushes a value into `config_values`, which is what `apply()`
walks. So a bridge card that draws one of its OWN `conf()`-registered values by
hand must call `set_hidden_in_owner_menu(true)` on it -- otherwise the same
`draw()` runs twice in the same frame and the control renders twice.

The duplication is not merely cosmetic. `ActionRowValue::draw()` passes
`get_imgui_title()` straight to `ImGui::Button`, and that title is
`tr(name) + "##" + module` -- identical on both passes, because both are the
same value of the same module. ImGui therefore sees one ID submitted twice and
reports an ID conflict; and the two copies share one hover/active state, so the
button under the cursor lights up in both places at once.

The defect this was written for
-------------------------------
`LootTeleportModule::draw_menu_extra()` draws its four teleport ActionRowValues
by hand (`teleport_quest_loot_` .. `teleport_selected_loot_`), and its
constructor hid only the three SelectValue/ItemSearchValue settings above them.
The four buttons -- added by commit e4593f6a2, which split the old combined
"Category/Wishlist" button in two -- were registered with `conf()` and never
hidden, so all four rendered a second time, from `apply()`, directly beneath
their own first copies.

Why a text test
---------------
The alternative is a runtime test, and there isn't one: rendering needs ImGui,
a live `WorldModule`, and the manual-mapped process. The class of bug is a
*structural* disagreement between three facts that are all in the source --
"this value is mine", "I draw it by hand", "the framework draws mine too" --
so the check reads those three facts and compares them. See the docstring in
`tools/verify/README.md` for the module-level reason a checker that compares
nothing must fail loudly rather than pass.

The negative control
--------------------
Dropping the four `set_hidden_in_owner_menu(true)` lines from
`LootTeleportModule.cpp` makes `test_own_values_drawn_by_hand_are_hidden` fail
and name them. `test_scanner_catches_a_planted_double_draw` is that control
run in-process, so the suite cannot go green by having stopped looking.

And the framework-draw guard itself was re-controlled on 2026-10-12, when the
changed-from-default marker wrapped the draw and the guard had to be re-pointed
at the new shape. Two mutations of the real menu.cpp were run and restored:
deleting the `c->draw();` line, and deleting the `is_hidden_in_owner_menu()`
early return. Both made the re-pointed regex fail. A guard that was widened
until it could no longer fail would be the same failure this file records, so
the control is recorded here rather than trusted.
"""

import re
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
IMPL = REPO / "TarkovAddons" / "module" / "impl"
MENU = REPO / "TarkovAddons" / "gui" / "menu" / "menu.cpp"

# `name_(conf(new T(...)))` -- the ctor initialiser form -- and `name = conf(...)`.
# Both keep the trailing underscore the member is spelled with in the source.
_REGISTERED = re.compile(r"\b([A-Za-z_]\w*_)\s*\(\s*conf\s*\(|\b([A-Za-z_]\w*)\s*=\s*conf\s*\(")
# `name->draw();` at the start of a line, optionally guarded by an `if`.
_DRAWN = re.compile(r"^[^\S\n]*([a-z_]\w*)\s*->\s*draw\(\)\s*;", re.MULTILINE)
# `name->set_hidden_in_owner_menu(true)` -- the direct form.
_HIDDEN_DIRECT = re.compile(r"([A-Za-z_]\w*)\s*->\s*set_hidden_in_owner_menu\(\s*true\s*\)")
# The two loop forms, which cover several values with one call:
#   ConfigValue* values[] = {a, b}; for (ConfigValue* v : values) v->set_hidden_in_owner_menu(true);
#   for (ConfigValue* v : {a, b})    v->set_hidden_in_owner_menu(true);
_HIDE_LOOP_BODY = r"[\w\s]*->\s*set_hidden_in_owner_menu\(\s*true\s*\)"
_LIST_DECL = re.compile(r"ConfigValue\s*\*\s*([A-Za-z_]\w*)\s*\[\s*\]\s*=\s*\{([^}]*)\}")
_LIST_HIDDEN = re.compile(r"for\s*\([^:;]*:\s*([A-Za-z_]\w*)\s*\)\s*" + _HIDE_LOOP_BODY)
_INLINE_LIST_HIDDEN = re.compile(r"for\s*\([^:;]*:\s*\{([^}]*)\}\s*\)\s*" + _HIDE_LOOP_BODY)
_IDENTIFIER = re.compile(r"\b([a-z_]\w*)\b")
# Words that appear inside such a braced list and name no control.
_STOPWORDS = frozenset(
    {
        "static_cast", "const", "unsigned", "char", "void", "int", "true", "false",
        "configvalue", "configvalue", "value", "values", "auto", "nullptr",
    }
)


def _norm(names) -> set[str]:
    """Member spelling is normalised: `foo_` in the declaration, `foo` at use.

    Without this the three sets are disjoint by construction -- registered names
    carry the trailing underscore, drawn and hidden ones do not -- and the
    intersection that is the whole point of the check is always empty.
    """
    return {n[:-1] if n.endswith("_") else n for n in names}


def _registered(source: str) -> set[str]:
    """Member names the module put into its own `config_values` via `conf()`."""
    return _norm(a or b for a, b in _REGISTERED.findall(source))


def _drawn(source: str) -> set[str]:
    """Identifiers submitted as `<id>->draw();` -- a hand-drawn control."""
    return _norm(_DRAWN.findall(source))


def _identifiers_in(block: str) -> set[str]:
    return _norm(i for i in _IDENTIFIER.findall(block) if i not in _STOPWORDS)


def _hidden(source: str) -> set[str]:
    """Identifiers the source hides from the framework's automatic pass."""
    names = set(_HIDDEN_DIRECT.findall(source))
    for block in _INLINE_LIST_HIDDEN.findall(source):
        names.update(_identifiers_in(block))
    for name, block in _LIST_DECL.findall(source):
        if any(name == iterated for iterated in _LIST_HIDDEN.findall(source)):
            names.update(_identifiers_in(block))
    return _norm(names)


def _double_draws(source: str) -> set[str]:
    """Own values this module draws by hand AND leaves to `apply()`."""
    return (_registered(source) & _drawn(source)) - _hidden(source)


def _sources() -> list[Path]:
    return sorted(p for p in IMPL.glob("*.cpp") if "conf(" in p.read_text(encoding="utf-8", errors="replace"))


def test_the_framework_draw_is_what_makes_this_a_double_draw():
    """The rule only bites because apply() draws non-hidden registered values.

    Without this, someone can "fix" a red test by deleting the apply() pass, and
    every card would quietly stop rendering its own settings.
    """
    menu = MENU.read_text(encoding="utf-8", errors="replace")
    assert "is_hidden_in_owner_menu" in menu, (
        f"{MENU} no longer consults is_hidden_in_owner_menu() in the card draw path. "
        "This test's whole premise is that apply() draws every registered value the "
        "owner menu has not hidden -- if that changed, re-derive the rule, do not "
        "weaken the assertion."
    )
    # The shape changed on 2026-10-12 when the changed-from-default marker
    # wrapped the draw. The guard is now that the apply() lambda still
    # consults is_hidden_in_owner_menu() AND still calls c->draw() -- both
    # from ONE regex on purpose: a separate check for 'the draw is somewhere
    # in the file' would pass with the draw outside the lambda, which is the
    # failure this guard exists to catch.
    assert re.search(
        r"m->apply\(\s*\[&\]\(\s*ConfigValue\*\s*c\s*\)\s*\{"
        r"[^{}]*?is_hidden_in_owner_menu[^{}]*?c->draw\(\)",
        menu,
    ), (
        f"{MENU} no longer has an apply() lambda that skips hidden values "
        "and draws the rest. The automatic pass must keep drawing the "
        "values that are NOT hidden -- if that changed, re-derive the rule, "
        "do not weaken the assertion."
    )


def test_scanner_sees_registration_draw_and_hide():
    """The three facts, read off a source with each present once.

    Uses all three hide spellings the tree actually uses: the direct call, the
    named-array loop, and the inline-braced-loop.
    """
    source = """
Widget::Widget() : Module("W"), a_(conf(new SelectValue(0, "k"))), b_(conf(new CheckboxValue("k2"))),
    c_(conf(new ActionRowValue([] {}, "k3"))) {
    a->set_hidden_in_owner_menu(true);
    ConfigValue* rest[] = {b};
    for (ConfigValue* v : rest)
        v->set_hidden_in_owner_menu(true);
    for (ConfigValue* v : {c})
        v->set_hidden_in_owner_menu(true);
}
void Widget::draw_menu_extra() {
    a->draw();
    b->draw();
    c->draw();
}
"""
    assert _registered(source) == {"a", "b", "c"}
    assert _drawn(source) == {"a", "b", "c"}
    # `>=`, not `==`: the loop forms also report their own iteration variable.
    assert _hidden(source) >= {"a", "b", "c"}
    assert _double_draws(source) == set()


def test_scanner_catches_a_planted_double_draw():
    """Negative control: drop one hide and the scanner must name that one value."""
    source = """
Widget::Widget() : Module("W"), a_(conf(new SelectValue(0, "k"))), b_(conf(new CheckboxValue("k2"))),
    c_(conf(new ActionRowValue([] {}, "k3"))) {
    a->set_hidden_in_owner_menu(true);
    ConfigValue* rest[] = {b};
    for (ConfigValue* v : rest)
        v->set_hidden_in_owner_menu(true);
    for (ConfigValue* v : {c})
        v->set_hidden_in_owner_menu(true);
}
void Widget::draw_menu_extra() {
    a->draw();
    b->draw();
    c->draw();
}
"""
    planted = source.replace(
        "    ConfigValue* rest[] = {b};\n    for (ConfigValue* v : rest)\n"
        "        v->set_hidden_in_owner_menu(true);\n",
        "",
    )
    assert planted != source, "negative control did not change the source"
    assert _double_draws(planted) == {"b"}


@pytest.mark.parametrize("path", _sources(), ids=lambda p: p.name)
def test_own_values_drawn_by_hand_are_hidden(path: Path):
    offenders = _double_draws(path.read_text(encoding="utf-8", errors="replace"))
    assert not offenders, (
        f"{path.name}: {sorted(offenders)} are registered with conf() and drawn by hand "
        "in draw_menu_extra(), but never set_hidden_in_owner_menu(true). menu.cpp's "
        "apply() then draws each of them a second time in the same frame, under the "
        "same ImGui ID. Add the hide next to the draw, and check the value still "
        "round-trips its config key -- hiding only removes it from the automatic pass."
    )


def test_loot_teleport_buttons_are_hidden():
    """The defect this file exists for, named individually.

    Kept separate from the scan above so a regression here reads as this bug
    rather than as one line of a list.
    """
    source = (IMPL / "LootTeleportModule.cpp").read_text(encoding="utf-8", errors="replace")
    for member in (
        "teleport_quest_loot",
        "teleport_category_loot",
        "teleport_wishlist_loot",
        "teleport_selected_loot",
        "loot_selected_item",
        "loot_category_filter",
        "loot_wl_filter",
    ):
        assert member in _registered(source), f"{member}_ is no longer conf()-registered in LootTeleportModule"
        assert member in _drawn(source), f"{member}_ is no longer drawn by hand in draw_menu_extra"
        assert member in _hidden(source), (
            f"{member}_ is registered and drawn by hand but not hidden -- it renders twice. "
            "This is the Loot Teleporter button duplication (commit e4593f6a2 added the "
            "draws and the hide lines together; the hide lines went missing)."
        )