"""The layer budget is 3, and the evidence for that is a log, not a preference.

`kMaxLayers` in `skeleton_visibility.h` bounds how many collider layers the
penetration walk will classify. It was 4 and is now 3, changed on the user's call
after they reported that the aimbot hitches when a target sits behind several
layers.

The hitches turned out not to be the pen walk -- see the note in the source. The
change is still right on its own terms, and this file exists so that two things
cannot quietly become true:

  1. the cap silently moving again, because it is a bare `constexpr int` with no
     test on it, and
  2. somebody re-deriving the "it is the layer count" story from the log without
     noticing that the log contradicts it.

PART 1 -- the cap itself, asserted on the source. Comments and string literals are
blanked first, so the long explanatory block at the walk's exit -- which mentions
"4 -> 3" in prose -- cannot satisfy a numeric assertion by being matched as text.

PART 2 -- the log evidence, re-derived from the session's own log rather than
trusted from a table in a changelog. If the log is absent (a fresh machine, a
rotated file) the test says so and skips rather than asserting a number it cannot
produce. A skipped test is honest; a test that pins a copied constant is not.
"""

from __future__ import annotations

import collections
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
VIS = ROOT / "TarkovAddons" / "module" / "skeleton_visibility.h"
LOGS = [
    Path(r"C:\Battlestate Games\BsgLauncher\tarkovaddons_log.txt"),
    Path(r"C:\Battlestate Games\BsgLauncher\tarkovaddons_log.1.txt"),
]


def strip_noise(src: str) -> str:
    """Blank comments and string literals, preserving length and newlines.

    Same helper shape as test_zone_scope.py, kept local rather than shared: the
    two files assert different things and a shared helper is how a test starts
    passing for the wrong reason.
    """
    out = list(src)
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == "/" and i + 1 < n and src[i + 1] == "/":
            j = src.find("\n", i)
            j = n if j < 0 else j
            for k in range(i, j):
                out[k] = " "
            i = j
        elif c == "/" and i + 1 < n and src[i + 1] == "*":
            j = src.find("*/", i + 2)
            j = n if j < 0 else j + 2
            for k in range(i, j):
                if out[k] != "\n":
                    out[k] = " "
            i = j
        elif c in ('"', "'"):
            quote = c
            j = i + 1
            while j < n:
                if src[j] == "\\":
                    j += 2
                    continue
                if src[j] == quote:
                    j += 1
                    break
                j += 1
            for k in range(i, min(j, n)):
                if out[k] != "\n":
                    out[k] = " "
            i = j
        else:
            i += 1
    return "".join(out)


def pen_records():
    """Every `pen-check:` record, with wrapped continuation lines rejoined.

    Log lines in this project wrap across physical lines, so a per-line grep
    undercounts and miscounts. A record starts at a line beginning with an ISO
    timestamp and runs until the next one.
    """
    for path in LOGS:
        if not path.exists():
            continue
        raw = path.read_text(encoding="utf-8", errors="replace")
        recs = []
        for line in raw.split("\n"):
            if re.match(r"^\[\d{4}-\d\d-\d\d \d\d:\d\d:\d\d", line):
                recs.append(line)
            elif recs:
                recs[-1] += " " + line.strip()
        pen = [r for r in recs if "pen-check:" in r]
        if pen:
            return pen
    return []


def penetrable(rec: str) -> bool:
    """True only if the record's HEADLINE verdict is PENETRABLE.

    THE REASON THIS HELPER EXISTS, and it is the same reason the source has a long
    comment above `finish()`: the headline is derived from the value being
    RETURNED, never from the caller's note. That comment records the bug -- 189
    records once printed "PENETRABLE" because every branch's note was written on
    the assumption that its own branch decided the outcome.

    Every exit calls `finish(stop_layer < 0, <note>)`, so a walk whose ray
    eventually reached the target can still be BLOCKED because an EARLIER layer
    stopped it, and it will still carry "clear line after N layer(s)" as the
    explanatory note.

    This file asserted on that note alone until 2026-10-04, when five such records
    appeared and the assertion failed with "a walk reported a clear line". Two of
    the five were DECISION: BLOCKED. That was the source's own warning being ignored
    a second time, in a test written specifically to protect the layer cap.
    """
    return "DECISION: PENETRABLE" in rec


def max_layers() -> int:
    """`kMaxLayers` as written in the source, so the assertions cannot drift from it."""
    m = re.search(r"kMaxLayers\s*=\s*(\d+)", VIS.read_text(encoding="utf-8", errors="replace"))
    if not m:
        raise AssertionError("kMaxLayers not found in skeleton_visibility.h")
    return int(m.group(1))


class TestLayerBudget(unittest.TestCase):
    def setUp(self):
        self.src = VIS.read_text(encoding="utf-8", errors="replace")
        self.code = strip_noise(self.src)

    def test_kmaxlayers_is_three(self):
        m = re.search(r"kMaxLayers\s*=\s*(\d+)", self.code)
        self.assertIsNotNone(m, "kMaxLayers not found in skeleton_visibility.h")
        self.assertEqual(
            m.group(1),
            "3",
            "kMaxLayers moved. The reduction to 3 was a deliberate, evidenced "
            "change on 2026-10-04; if this fires, either it was reverted by "
            "someone or someone raised it again. Both need a reason.",
        )

    def test_negative_control_cap_of_four_fails(self):
        """If the assertion above were vacuous this would pass, and the test
        would be worth nothing."""
        reverted = self.code.replace("kMaxLayers = 3", "kMaxLayers = 4")
        self.assertNotEqual(reverted, self.code, "control did not apply")
        m = re.search(r"kMaxLayers\s*=\s*(\d+)", reverted)
        self.assertEqual(m.group(1), "4")

    def test_cap_comment_cannot_satisfy_the_numeric_assertion(self):
        """The explanatory block at the walk's exit says '4 -> 3' in prose. If
        comments were not blanked, a regex over the raw source could match a
        number out of the comment instead of the declaration."""
        self.assertRegex(self.src, r"4 -> 3", "expected the prose to be present")
        self.assertNotRegex(
            self.code,
            r"4 -> 3",
            "strip_noise failed to blank the comment; the numeric assertion "
            "above could be satisfied by prose",
        )

    def test_budget_stop_is_recorded_with_the_real_blocking_layer(self):
        """`record_stop` must pass a set `stop_layer` through, or lowering the cap
        silently rewrites the tally -- every blocked walk would be attributed to
        `budget_layers` instead of the layer that actually stopped it. The `pen_stop`
        slots are load-bearing: they sum to the call count."""
        self.assertRegex(
            self.code,
            r"record_stop\s*\(\s*stop_layer\s*<\s*0\s*\?\s*kMaxLayers\s*:\s*stop_layer",
            "record_stop no longer preserves stop_layer; the cap change would "
            "corrupt the pen_stop tally",
        )

    def test_no_walk_in_the_log_needed_a_fourth_layer(self):
        pen = pen_records()
        if not pen:
            self.skipTest("no tarkovaddons log with pen-check: records found")
        # PENETRABLE only. A BLOCKED walk that reached the target after 4 layers did
        # not succeed and does not constrain the cap -- it is evidence the stop logic
        # works. See penetrable() for why the note cannot be used instead.
        reached = collections.Counter()
        for r in pen:
            if not penetrable(r):
                continue
            m = re.search(r"hit target after (\d+) layer", r)
            if m:
                reached[int(m.group(1))] += 1
        self.assertTrue(reached, "no PENETRABLE 'hit target after N layer(s)' in any record")
        self.assertLessEqual(
            max(reached),
            max_layers(),
            f"a PENETRABLE walk reached its target after {max(reached)} layers; the cap of "
            f"{max_layers()} would flip that PASS to BLOCKED. Full distribution: {dict(reached)}",
        )

    def test_no_walk_in_the_log_ever_cleared(self):
        """No PENETRABLE walk reported a clear line after exactly `kMaxLayers` layers.

        That is the case the cap change could flip, and it has never been observed --
        which is evidence of rarity, not of impossibility.

        TWO CORRECTIONS to what this asserted before, both from the 2026-10-04 log:

          1. It matched the phrase "clear line after N layer(s)" in ANY record. That
             phrase is a note, not a verdict -- see penetrable(). It fired on five
             records, two of them DECISION: BLOCKED.
          2. It asserted ZERO at any layer count. But 3 of the 5 penetrable ones are
             layer 0: a direct sight line with nothing to walk through. The cap is
             irrelevant at layer 0, and 23 of the 33 PENETRABLE walks in the log hit
             the target at layer 0, so asserting zero at any N would be asserting
             that direct shots never succeed. The assertion is now on the flip case
             specifically -- N == kMaxLayers -- with the distribution in the failure
             message so a move toward the cap is visible before it trips.
        """
        pen = pen_records()
        if not pen:
            self.skipTest("no tarkovaddons log with pen-check: records found")

        cap = max_layers()
        cleared = collections.Counter()
        for r in pen:
            if not penetrable(r):
                continue
            for m in re.finditer(r"clear line after (\d+) layer", r):
                cleared[int(m.group(1))] += 1

        at_cap = cleared.get(cap, 0)
        self.assertEqual(
            at_cap,
            0,
            f"{at_cap} PENETRABLE walk(s) reported a clear line after exactly the cap "
            f"of {cap} layers -- the case the cap would flip to BLOCKED. Read the "
            f"source comment at the walk's exit before changing kMaxLayers again. "
            f"Full distribution of clear-line layer counts: {dict(sorted(cleared.items()))}",
        )

    def test_decision_is_derived_from_the_return_value_not_the_note(self):
        """Guard the property that the two tests above were violating.

        `finish()` must build its headline from the boolean it returns, never from the
        caller's note. If someone rewrites it to trust the note, both log tests above
        go back to reading verdicts out of prose -- which is the bug the comment above
        `finish()` says it already fixed once, at the cost of 189 records claiming
        PENETRABLE through solid rock.
        """
        src = VIS.read_text(encoding="utf-8", errors="replace")
        # Matches the shape `diag + " | DECISION: " + (penetrable ? ... : ...)`.
        # Deliberately anchored on the DECISION literal and the `penetrable` ternary
        # rather than on the receiving variable's name, which is incidental.
        self.assertRegex(
            src,
            r'DECISION:[^"]*"\s*\+\s*\(\s*penetrable\s*\?',
            "finish() no longer derives DECISION from the returned value; the note is "
            "being trusted instead, which is the 2026-10-02 bug returning",
        )


if __name__ == "__main__":
    unittest.main()