"""Source-level regression test for the Tracy start-ordering bug that killed the game.

This is a text test, not a behavioural one. That is a deliberate choice and worth
stating, because a text test is exactly the kind of tool that reports success
because it did nothing -- `test_profile_path.py` in this directory was written
that way first and its negative control passed 10/10 against reverted code.

Two things keep it honest, and both are asserted here:

  * comments are stripped before anything is matched, so a fix's own explanatory
    comment (which names the symbols it moves) cannot satisfy the test;
  * there is a negative control that runs the same assertions against a
    deliberately reordered copy of the source in memory. If the control passes,
    the test is vacuous and says so.

What is being asserted, and why a text test is adequate for it:

`tracy::profiler::start()` must call StartupProfiler() *before* it publishes
g_started. Under TRACY_MANUAL_LIFETIME, all of Tracy's state lives behind a plain
non-atomic `ProfilerData* s_profilerData`, and GetProfilerData() dereferences it
with no null check (the TRACY_ASSERT compiles out under NDEBUG, which both Prod
configs define). g_started is the gate every tracy::profiler::Zone reads. Publish
the gate first and any instrumented call on any other thread builds a real
tracy::ScopedZone against a null s_profilerData. That killed the game on
2026-10-02 with a READ of 0x8 at rva +0x100B03.

The invariant is about the position of two statements in one function. There is no
way to observe it without either (a) loading Tracy and racing threads, which is
flaky and needs a debugger to observe the null, or (b) reading the source. So the
text test is not a compromise here; it is the right tool.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

BRIDGE = Path(__file__).resolve().parents[2] / "TarkovAddons" / "util" / "tracy_bridge.cpp"
HEADER = Path(__file__).resolve().parents[2] / "TarkovAddons" / "util" / "tracy_bridge.h"

# Matches /* */ and // comments and string/char literals. String literals matter:
# the negative control below builds a source whose comments claim the right
# order, and a naive regex would happily match text inside a literal.
_COMMENTS_AND_LITERALS = re.compile(
    r'"(?:\\.|[^"\\])*"'      # string literal
    r"|'(?:\\.|[^'\\])*'"     # char literal
    r"|/\*.*?\*/"             # block comment
    r"|//[^\n]*",             # line comment
    re.DOTALL,
)


def code_only(text: str) -> str:
    """Source with comments and string/char literals blanked out.

    Blanking (rather than deleting) keeps byte offsets stable, so a test can report
    a line number.
    """
    out = []
    pos = 0
    for m in _COMMENTS_AND_LITERALS.finditer(text):
        out.append(text[pos:m.start()])
        out.append(" " * (m.end() - m.start()))
        pos = m.end()
    out.append(text[pos:])
    return "".join(out)


def function_body(src: str, name: str) -> tuple[str, int]:
    """Return (body_without_braces, first_line_number) for `bool name(...) { ... }`.

    Deliberately a brace counter over comment-stripped source rather than a regex
    over the whole file: the same function name appears in tracy_bridge.h as a
    declaration, and a regex that matched the declaration would assert nothing.
    """
    src = code_only(src)
    m = re.search(r"\b" + re.escape(name) + r"\s*\([^;{]*\)\s*\{", src)
    if not m:
        pytest.fail(f"{name}() definition not found")
    start = m.end() - 1  # at the '{'
    depth = 0
    for i in range(start, len(src)):
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                line = src.count("\n", 0, start) + 1
                return src[start + 1:i], line
    pytest.fail(f"{name}() braces unbalanced")


def assert_start_order(src: str) -> None:
    body, line = function_body(src, "start")

    init_at = body.find("StartupProfiler")
    assert init_at != -1, "start() no longer calls StartupProfiler - the gate is now fiction"

    # g_started must be *published* (stored true), not merely read.
    # Check for the bad pattern first: the shipped bug used exchange(true), and the
    # "no store at all" assertion below fires first otherwise and reports the
    # downstream symptom ("running() can never become true") instead of the cause.
    assert not re.search(r"g_started\s*\.\s*exchange\s*\(\s*true", body), (
        "start() publishes g_started via exchange(true) *before* StartupProfiler(): "
        "exchange writes true, and only then is the profiler data allocated. That is "
        "the 2026-10-02 crash. Use store(true) AFTER StartupProfiler()."
    )

    pub = [m.start() for m in re.finditer(r"g_started\s*\.\s*store\s*\(\s*true", body)]
    assert pub, "start() never stores g_started = true; running() can never become true"

    assert init_at < min(pub), (
        f"start() publishes g_started before calling StartupProfiler() "
        f"(g_started at +{min(pub)}, StartupProfiler at +{init_at}, def near line {line}). "
        "Any TA_ZONE on another thread in that window dereferences a null "
        "tracy::s_profilerData."
    )


def assert_running_consults_tracy(src: str) -> None:
    body, _ = function_body(src, "running")
    assert "IsProfilerStarted" in body, (
        "running() trusts g_started alone. Tracy sets s_isProfilerStarted as the LAST "
        "statement of StartupProfiler(), so consulting it makes 'gate open implies "
        "s_profilerData is non-null' structural instead of positional."
    )


def assert_no_bare_deref_in_client_attached(src: str) -> None:
    body, _ = function_body(src, "client_attached")
    assert "running" in body, (
        "client_attached() must go through running() so this file has one gate, not two."
    )
    gpa = body.find("ProfilerAvailable")
    gate = body.find("running")
    assert gpa != -1, "client_attached() no longer consults ProfilerAvailable"
    assert gate < gpa, (
        "client_attached() calls ProfilerAvailable() before checking running(); "
        "ProfilerAvailable() touches the profiler queue and must stay behind the check."
    )


def test_start_publishes_after_init():
    assert_start_order(BRIDGE.read_text(encoding="utf-8", errors="replace"))


def test_running_consults_tracy_flag():
    assert_running_consults_tracy(BRIDGE.read_text(encoding="utf-8", errors="replace"))


def test_client_attached_gates_before_touching_profiler():
    assert_no_bare_deref_in_client_attached(BRIDGE.read_text(encoding="utf-8", errors="replace"))


def test_header_still_warns_about_manual_lifetime():
    """The header's warning is the thing a future reader trusts. Keep it real."""
    h = HEADER.read_text(encoding="utf-8", errors="replace")
    assert "TRACY_MANUAL_LIFETIME" in h
    assert "s_profilerData" in h, (
        "tracy_bridge.h no longer names s_profilerData; its comment explaining why the "
        "Zone wrapper exists has been edited away"
    )


# --------------------------------------------------------------------------
# Negative control. Runs the same assertions against a reordered copy of the
# real source, in memory. If these PASS, the test above is vacuous.
# --------------------------------------------------------------------------

REORDERED = """
bool start() {
    if (g_started.exchange(true, std::memory_order_acq_rel)) return true;
    StartupProfiler();
    return true;
}
"""


def test_negative_control_reordered_start_is_rejected():
    """A start() that publishes first, the way the bug did, must FAIL."""
    with pytest.raises(AssertionError):
        assert_start_order(REORDERED)


def test_negative_control_comment_only_claim_is_rejected():
    """A fix described in a comment, with the code still broken, must FAIL.

    This is the exact shape that made test_profile_path.py vacuous: a comment
    naming StartupProfiler() and g_started, with the statements in the wrong
    order. Comments are blanked before matching, so this must fail.
    """
    lying = """
bool start() {
    // StartupProfiler() runs first, then g_started.store(true). This comment
    // names both symbols, and the string "StartupProfiler" appears twice.
    if (g_started.store(true), g_started.exchange(true, std::memory_order_acq_rel)) return true;
    StartupProfiler();
    return true;
}
"""
    with pytest.raises(AssertionError):
        assert_start_order(lying)
