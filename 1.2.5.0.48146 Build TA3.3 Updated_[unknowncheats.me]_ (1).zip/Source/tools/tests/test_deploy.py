from __future__ import annotations

import contextlib
import ctypes
import io
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from tools import deploy

REPO = Path(__file__).resolve().parent.parent.parent


# ---------------------------------------------------------------------------
# Holding a file the way Windows actually holds one
# ---------------------------------------------------------------------------
#
# These two helpers exist because `open(path, "r+b")` is NOT a lock. CPython
# opens Windows files through _wopen with _SH_DENYNO, which shares read, write
# and delete, so the file stays fully available and any assertion made inside
# such a `with` block is vacuous -- it would also pass against a locked() that
# always returned True. Asserting a precondition was never established is the
# one failure a test suite cannot detect on its own, so the precondition is
# built from the Win32 calls that actually deny access.

if os.name == "nt":
    _k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _k32.CreateFileW.argtypes = [
        ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p,
        ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p,
    ]
    _k32.CreateFileW.restype = ctypes.c_void_p
    _k32.CloseHandle.argtypes = [ctypes.c_void_p]

    _GENERIC_RW = 0x80000000 | 0x40000000
    _OPEN_EXISTING = 3
    _INVALID_HANDLE = ctypes.c_void_p(-1).value


@contextlib.contextmanager
def exclusive(path: Path):
    """Hold `path` with a handle that denies everything, as a locked file is.

    dwShareMode=0. Any second open for read, write or delete fails, which is
    what a real lock looks like to the filesystem. Yields without doing
    anything off Windows, where the tests using it are skipped anyway.
    """
    if os.name != "nt":
        yield
        return
    handle = _k32.CreateFileW(
        str(path), _GENERIC_RW, 0, None, _OPEN_EXISTING, 0, None
    )
    if handle == _INVALID_HANDLE:
        raise OSError(
            f"could not take an exclusive handle on {path}: "
            f"winerr={ctypes.get_last_error()}"
        )
    try:
        yield
    finally:
        _k32.CloseHandle(ctypes.c_void_p(handle))


@contextlib.contextmanager
def mapped(path: Path):
    """Map `path` into this process, the way a loaded module is mapped.

    This is the case deploy.locked() exists for, so it is the control that
    matters. A section object backed by the file is exactly what LoadLibrary
    holds: delete and rename are refused, while an ordinary open for read/write
    still succeeds. LoadLibrary itself is not used because it validates a
    module's internal name and refuses KnownDLLs from any path but System32.
    """
    import mmap

    with open(path, "r+b") as handle:
        with mmap.mmap(handle.fileno(), 0, access=mmap.ACCESS_READ):
            yield


def make_build_tree(root: Path, *, omit_bypass: bool = False, omit_manifest: bool = False) -> Path:
    """A directory shaped like out/prod/with_aimbot after a Prod|x64 build."""
    source = root / "build"
    (source / "ta").mkdir(parents=True, exist_ok=True)

    (source / "TarkovAddons.dll").write_text("new")
    if not omit_bypass:
        (source / "TarkovLauncherBypass.dll").write_text("new")
    (source / "vk_swiftshader.dll").write_text("new")
    (source / "TarkovAddons.pdb").write_text("new")
    (source / "TarkovAddons.map").write_text("new")

    for name in deploy.DATA_FILES:
        (source / "ta" / name).write_text("new")

    if not omit_manifest:
        profile = source / "ta" / "compatibility" / "profiles" / "1.1.5.1.47510"
        profile.mkdir(parents=True, exist_ok=True)
        (profile / "manifest.json").write_text("{}")
    return source


def make_deployed(root: Path) -> Path:
    """A deployed folder: our files, the user's data, and Battlestate's files."""
    target = make_build_tree(root)
    (target / "ta" / "configs").mkdir(parents=True, exist_ok=True)
    (target / "ta" / "maps").mkdir(parents=True, exist_ok=True)
    (target / "ta" / "configs" / "tarkovaddons.cfg").write_text("MINE")
    (target / "ta" / "maps" / "tarkov.json").write_text("MINE")
    (target / "ta" / "tarkov_prices.json").write_text("MINE")
    (target / "tarkovaddons_log.txt").write_text("MINE")
    (target / "tarkovaddons_launcher_log.txt").write_text("MINE")
    (target / "BsgLauncher.exe").write_text("BSG")
    (target / "battlestate.dat").write_text("BSG")
    return target


class TempDirTest(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)


class InventoryTests(TempDirTest):
    def test_enumerates_every_artifact(self) -> None:
        source = make_build_tree(self.root)
        items = deploy.deploy_items(source)
        relative = {deploy.show(parts): kind for parts, kind in items}

        for name in deploy.DEPLOY_DLLS:
            self.assertEqual(relative.get(name), "dll", name)
        self.assertEqual(relative.get("TarkovAddons.pdb"), "symbol")
        self.assertEqual(relative.get("TarkovAddons.map"), "symbol")
        self.assertEqual(relative.get("ta\\launcher.cfg"), "data")
        self.assertEqual(
            relative.get("ta\\TarkovAddons Reloaded Background.png"), "data"
        )
        self.assertEqual(
            relative.get("ta\\compatibility\\profiles\\1.1.5.1.47510\\manifest.json"),
            "manifest",
        )

    def test_never_enumerates_lang_or_maps(self) -> None:
        # lang\ is compiled into the DLL as RCDATA and ta\maps\ is unpacked at
        # runtime. Neither is shipped, so installing either would be wrong.
        source = make_build_tree(self.root)
        relative = {deploy.show(parts) for parts, _ in deploy.deploy_items(source)}
        self.assertFalse([name for name in relative if "lang" in name])
        self.assertFalse([name for name in relative if "maps" in name])

    def test_a_build_with_no_ta_still_enumerates(self) -> None:
        bare = self.root / "bare"
        bare.mkdir()
        (bare / "TarkovAddons.dll").write_text("x")
        self.assertGreaterEqual(len(deploy.deploy_items(bare)), 4)

    def test_missing_dll_is_still_listed(self) -> None:
        # So install can name what a configuration failed to produce, rather
        # than copying two of three DLLs and reporting success.
        source = make_build_tree(self.root, omit_bypass=True)
        items = {deploy.show(p): k for p, k in deploy.deploy_items(source)}
        self.assertIn("TarkovLauncherBypass.dll", items)

    def test_only_the_newest_profile_ships(self) -> None:
        # The launcher-side selector ranks manifests by status, not game build,
        # and a tie resolves to directory-iteration order -- alphabetically, the
        # oldest version first. Shipping an older profile beside the new one is
        # how a stale manifest wins that selection, so only the newest deploys.
        source = make_build_tree(self.root)
        profiles = source / "ta" / "compatibility" / "profiles"
        fresh = profiles / "1.2.0.0.47888"
        fresh.mkdir(parents=True)
        (fresh / "manifest.json").write_text("{}")
        items = {deploy.show(parts): kind for parts, kind in deploy.deploy_items(source)}
        self.assertEqual(
            items.get("ta\\compatibility\\profiles\\1.2.0.0.47888\\manifest.json"),
            "manifest",
        )
        self.assertNotIn("ta\\compatibility\\profiles\\1.1.5.1.47510\\manifest.json", items)

    def test_profile_ordering_is_numeric_not_lexicographic(self) -> None:
        # "1.10" is newer than "1.9"; a string sort would say the opposite.
        source = make_build_tree(self.root)
        profiles = source / "ta" / "compatibility" / "profiles"
        for name in ("1.10.0.0.1", "1.9.0.0.1"):
            (profiles / name).mkdir()
            (profiles / name / "manifest.json").write_text("{}")
        relative = {deploy.show(parts) for parts, _ in deploy.deploy_items(source)}
        self.assertIn("ta\\compatibility\\profiles\\1.10.0.0.1\\manifest.json", relative)
        self.assertNotIn("ta\\compatibility\\profiles\\1.9.0.0.1\\manifest.json", relative)
        self.assertNotIn("ta\\compatibility\\profiles\\1.1.5.1.47510\\manifest.json", relative)

    def test_an_unrankable_profile_name_ships_everything(self) -> None:
        # A name that is not a version cannot be ranked, and dropping a profile
        # on a guess could cost a build its only one, so ambiguity ships all.
        source = make_build_tree(self.root)
        profiles = source / "ta" / "compatibility" / "profiles"
        (profiles / "beta").mkdir()
        (profiles / "beta" / "manifest.json").write_text("{}")
        relative = {deploy.show(parts) for parts, _ in deploy.deploy_items(source)}
        self.assertIn("ta\\compatibility\\profiles\\beta\\manifest.json", relative)
        self.assertIn("ta\\compatibility\\profiles\\1.1.5.1.47510\\manifest.json", relative)


class LockedTests(TempDirTest):
    def test_missing_file_is_not_locked(self) -> None:
        self.assertFalse(deploy.locked(self.root / "nope.dll"))

    def test_writable_file_is_not_locked(self) -> None:
        path = self.root / "free.dll"
        path.write_text("x")
        self.assertFalse(deploy.locked(path))

    @unittest.skipUnless(os.name == "nt", "file locking semantics differ off Windows")
    def test_locked_file_is_detected(self) -> None:
        path = self.root / "held.dll"
        path.write_text("x")
        with exclusive(path):
            self.assertTrue(deploy.locked(path))
        # ...and not because of a stale answer once the lock is gone.
        self.assertFalse(deploy.locked(path))

    @unittest.skipUnless(os.name == "nt", "a section object is a Windows concept")
    def test_mapped_module_is_detected(self) -> None:
        # The real scenario, and the one the previous implementation missed: a
        # mapped image can still be opened for read/write, so probing that said
        # "not locked" for a loaded DLL. See deploy.locked.
        path = self.root / "loaded.dll"
        path.write_text("x" * 64)
        with mapped(path):
            self.assertTrue(deploy.locked(path))
        self.assertFalse(deploy.locked(path))

    @unittest.skipUnless(os.name == "nt", "POSIX cannot make a file unwritable this way")
    def test_readonly_file_is_locked(self) -> None:
        path = self.root / "ro.dll"
        path.write_text("x")
        os.chmod(path, 0o444)
        self.addCleanup(os.chmod, path, 0o666)
        self.assertTrue(deploy.locked(path))


class FindTargetTests(TempDirTest):
    def test_explicit_existing_path_is_accepted(self) -> None:
        target = self.root / "BsgLauncher"
        target.mkdir()
        self.assertEqual(deploy.find_bsg_launcher(str(target)), target)

    def test_explicit_missing_path_raises(self) -> None:
        with self.assertRaises(deploy.DeployError) as caught:
            deploy.find_bsg_launcher(str(self.root / "ghost"))
        self.assertIn("does not exist", str(caught.exception))

    def test_explicit_path_without_marker_warns_but_proceeds(self) -> None:
        # An interrupted install looks exactly like this, and refusing would
        # make the folder impossible to install into.
        target = self.root / "NoMarker"
        target.mkdir()
        with mock.patch.object(deploy, "warn") as warning:
            self.assertEqual(deploy.find_bsg_launcher(str(target)), target)
        warning.assert_called_once()

    def test_nothing_found_raises_with_guidance(self) -> None:
        with self.assertRaises(deploy.DeployError) as caught:
            deploy.find_bsg_launcher(None, drives="ZY")
        message = str(caught.exception)
        self.assertIn("--path", message)
        self.assertIn("Z:", message)
        self.assertIn("Y:", message)

    def test_nothing_found_returns_none_when_not_required(self) -> None:
        # How uninstall says "nothing is installed" without calling it a failure.
        self.assertIsNone(deploy.find_bsg_launcher(None, drives="ZY", required=False))

    def test_several_candidates_refuses_to_guess(self) -> None:
        # Deploying into a folder the user does not read produces a mod that
        # appears to do nothing, which is the failure these scripts prevent.
        first = Path(r"C:\Battlestate Games\BsgLauncher")
        second = Path(r"D:\Battlestate Games\BsgLauncher")
        with self.assertRaises(deploy.DeployError) as caught:
            deploy.choose_bsg_launcher([first, second], [])
        message = str(caught.exception)
        self.assertIn("will not guess", message)
        self.assertIn(str(first), message)
        self.assertIn(str(second), message)


class ChooseTargetTests(unittest.TestCase):
    """The rule for picking between candidates, tested without a filesystem."""

    STRONG = Path(r"C:\Battlestate Games\BsgLauncher")
    OTHER = Path(r"D:\Battlestate Games\BsgLauncher")
    WEAK = Path(r"E:\Battlestate Games\BsgLauncher")

    def test_one_strong_candidate_wins(self) -> None:
        self.assertEqual(deploy.choose_bsg_launcher([self.STRONG], []), self.STRONG)

    def test_strong_beats_weak(self) -> None:
        # A real install is always preferred over a bare folder.
        self.assertEqual(
            deploy.choose_bsg_launcher([self.STRONG], [self.WEAK]), self.STRONG
        )

    def test_single_weak_candidate_is_accepted_with_a_warning(self) -> None:
        # An interrupted install looks exactly like this, and refusing would make
        # the folder impossible to install into.
        with mock.patch.object(deploy, "warn") as warning:
            self.assertEqual(deploy.choose_bsg_launcher([], [self.WEAK]), self.WEAK)
        warning.assert_called_once()

    def test_several_weak_candidates_still_refuse(self) -> None:
        with self.assertRaises(deploy.DeployError):
            deploy.choose_bsg_launcher([], [self.WEAK, self.OTHER])

    def test_no_candidates_is_none(self) -> None:
        self.assertIsNone(deploy.choose_bsg_launcher([], []))


class ConfirmTests(TempDirTest):
    SUMMARY = ["About to do a thing", "", "  2 files"]

    def test_yes_skips_the_question_but_still_prints(self) -> None:
        with mock.patch("builtins.input", side_effect=AssertionError("must not ask")):
            with mock.patch("builtins.print"):
                self.assertTrue(deploy.confirm(self.SUMMARY, yes=True, dry_run=False, hint=""))

    def test_dry_run_never_asks(self) -> None:
        with mock.patch("sys.stdin") as stdin:
            stdin.isatty.return_value = False
            with mock.patch("builtins.print"):
                self.assertTrue(deploy.confirm(self.SUMMARY, yes=False, dry_run=True, hint=""))

    def test_no_terminal_and_no_yes_refuses(self) -> None:
        # The whole point: no flag left alone, no quiet destructive path.
        with mock.patch("sys.stdin") as stdin:
            stdin.isatty.return_value = False
            with mock.patch("builtins.print"):
                with self.assertRaises(deploy.DeployError) as caught:
                    deploy.confirm(self.SUMMARY, yes=False, dry_run=False, hint="pass --yes")
        self.assertIn("--yes", str(caught.exception))

    def test_typing_yes_proceeds(self) -> None:
        with mock.patch("sys.stdin") as stdin:
            stdin.isatty.return_value = True
            with mock.patch("builtins.input", return_value="y"):
                with mock.patch("builtins.print"):
                    self.assertTrue(deploy.confirm(self.SUMMARY, False, False, ""))

    def test_eof_is_refusal_not_a_silent_no(self) -> None:
        # isatty() is not the defence, because on Windows it reports True for a
        # redirected stdin. When the prompt cannot actually be answered, that has
        # to fail the way the isatty() path does -- with the hint and a non-zero
        # exit -- rather than return False, which reads as "declined" and lets a
        # caller treat the command as having succeeded.
        with mock.patch("sys.stdin") as stdin:
            stdin.isatty.return_value = True          # the platform lies
            with mock.patch("builtins.input", side_effect=EOFError):
                with mock.patch("builtins.print"):
                    with self.assertRaises(deploy.DeployError) as caught:
                        deploy.confirm(self.SUMMARY, False, False, "pass --yes")
        self.assertIn("--yes", str(caught.exception))

    def test_ctrl_c_is_a_plain_no_not_a_failure(self) -> None:
        # A person pressing Ctrl+C has decided to stop. That is an answer, so it
        # stays an ordinary "no" rather than becoming an error about a broken
        # terminal.
        with mock.patch("sys.stdin") as stdin:
            stdin.isatty.return_value = True
            with mock.patch("builtins.input", side_effect=KeyboardInterrupt):
                with mock.patch("builtins.print"):
                    self.assertFalse(deploy.confirm(self.SUMMARY, False, False, ""))

    def test_typing_anything_else_is_a_no_not_a_failure(self) -> None:
        for answer in ("", "n", "no", "maybe"):
            with mock.patch("sys.stdin") as stdin:
                stdin.isatty.return_value = True
                with mock.patch("builtins.input", return_value=answer):
                    with mock.patch("builtins.print"):
                        self.assertFalse(
                            deploy.confirm(self.SUMMARY, False, False, ""), answer
                        )


class InstallTests(TempDirTest):
    def options(self, **overrides) -> dict:
        base = dict(deploy.DEFAULTS)
        base["flavor"] = "with_aimbot"
        base["source"] = None
        base["yes"] = True
        base["dry_run"] = False
        base.update(overrides)
        return base

    def run_install(self, **overrides) -> int:
        with mock.patch("builtins.print"), mock.patch.object(deploy, "warn"):
            return deploy.cmd_install(self.options(**overrides))

    def test_copies_the_whole_payload(self) -> None:
        source = make_build_tree(self.root)
        target = make_deployed(self.root / "t")
        self.assertEqual(self.run_install(source=str(source), path=str(target)), 0)

        for name in deploy.DEPLOY_DLLS:
            self.assertEqual((target / name).read_text(), "new", name)
        for name in ("TarkovAddons.pdb", "TarkovAddons.map"):
            self.assertEqual((target / name).read_text(), "new", name)
        for name in deploy.DATA_FILES:
            self.assertTrue((target / "ta" / name).is_file(), name)
        self.assertTrue(
            (target / "ta/compatibility/profiles/1.1.5.1.47510/manifest.json").is_file()
        )

    def test_preserves_user_data(self) -> None:
        # What makes re-running install to update safe.
        source = make_build_tree(self.root)
        target = make_deployed(self.root / "t")
        self.run_install(source=str(source), path=str(target))

        for relative in (
            "ta/configs/tarkovaddons.cfg",
            "ta/maps/tarkov.json",
            "ta/tarkov_prices.json",
            "tarkovaddons_log.txt",
            "tarkovaddons_launcher_log.txt",
        ):
            self.assertEqual((target / relative).read_text(), "MINE", relative)
        # Battlestate's own files must not be touched either.
        self.assertEqual((target / "battlestate.dat").read_text(), "BSG")

    def test_rerun_updates_in_place(self) -> None:
        source = make_build_tree(self.root)
        target = make_deployed(self.root / "t")
        self.run_install(source=str(source), path=str(target))
        (source / "TarkovAddons.dll").write_text("v2")
        self.run_install(source=str(source), path=str(target))
        self.assertEqual((target / "TarkovAddons.dll").read_text(), "v2")
        self.assertEqual((target / "ta/configs/tarkovaddons.cfg").read_text(), "MINE")

    def test_incomplete_build_is_refused_before_anything_is_written(self) -> None:
        source = make_build_tree(self.root, omit_bypass=True)
        target = make_deployed(self.root / "t")
        with self.assertRaises(deploy.DeployError) as caught:
            self.run_install(source=str(source), path=str(target))
        self.assertIn("TarkovLauncherBypass.dll", str(caught.exception))
        self.assertIn("breaks silently", str(caught.exception))
        self.assertTrue((target / "TarkovLauncherBypass.dll").is_file())

    def test_missing_build_tree_is_reported(self) -> None:
        with self.assertRaises(deploy.DeployError) as caught:
            self.run_install(source=str(self.root / "nope"), path=str(self.root))
        self.assertIn("build it first", str(caught.exception).lower())

    def test_dry_run_writes_nothing(self) -> None:
        source = make_build_tree(self.root)
        target = self.root / "t"
        target.mkdir()
        (target / "TarkovAddons.dll").write_text("OLD")
        self.assertEqual(
            self.run_install(source=str(source), path=str(target), dry_run=True), 0
        )
        self.assertEqual((target / "TarkovAddons.dll").read_text(), "OLD")

    @unittest.skipUnless(os.name == "nt", "file locking semantics differ off Windows")
    def test_locked_destination_is_refused_before_any_copy(self) -> None:
        source = make_build_tree(self.root)
        target = make_deployed(self.root / "t")
        with exclusive(target / "TarkovAddons.dll"):
            with self.assertRaises(deploy.DeployError) as caught:
                self.run_install(source=str(source), path=str(target))
        self.assertIn("in use", str(caught.exception))
        self.assertIn("--force", str(caught.exception))

    def test_install_removes_stale_profile_dirs(self) -> None:
        # The target here simulates an earlier install that shipped 1.1.5.1.47510;
        # this build ships only 1.2.0.0.47888. A copy without pruning leaves the
        # old manifest beside the new one, and the launcher's status-ordered
        # selection can then pick the stale one -- the failure this prevents.
        source = make_build_tree(self.root)
        fresh = source / "ta" / "compatibility" / "profiles" / "1.2.0.0.47888"
        fresh.mkdir(parents=True)
        (fresh / "manifest.json").write_text("{}")
        target = make_deployed(self.root / "t")
        stale = target / "ta" / "compatibility" / "profiles" / "1.1.5.1.47510"
        self.assertTrue(stale.is_dir(), "precondition: earlier install left a profile")

        self.assertEqual(self.run_install(source=str(source), path=str(target)), 0)

        self.assertFalse(stale.exists())
        self.assertTrue(
            (target / "ta/compatibility/profiles/1.2.0.0.47888/manifest.json").is_file()
        )

    def test_install_prunes_only_profiles_not_shipped(self) -> None:
        # A build that still ships the profile the target already has must not
        # delete it; pruning is keyed on what this build ships, not on age.
        source = make_build_tree(self.root)
        target = make_deployed(self.root / "t")
        self.run_install(source=str(source), path=str(target))
        self.assertTrue(
            (target / "ta/compatibility/profiles/1.1.5.1.47510/manifest.json").is_file()
        )

    def test_install_dry_run_removes_no_stale_profile(self) -> None:
        source = make_build_tree(self.root)
        fresh = source / "ta" / "compatibility" / "profiles" / "1.2.0.0.47888"
        fresh.mkdir(parents=True)
        (fresh / "manifest.json").write_text("{}")
        target = make_deployed(self.root / "t")
        stale = target / "ta" / "compatibility" / "profiles" / "1.1.5.1.47510"

        self.assertEqual(
            self.run_install(source=str(source), path=str(target), dry_run=True), 0
        )
        self.assertTrue(stale.is_dir())

    def test_install_without_manifests_leaves_deployed_profiles_alone(self) -> None:
        # A build with no manifest at all is a misconfiguration, not a request
        # to strip the target's only profile: prune only when something ships.
        source = make_build_tree(self.root, omit_manifest=True)
        target = make_deployed(self.root / "t")
        self.run_install(source=str(source), path=str(target))
        self.assertTrue(
            (target / "ta/compatibility/profiles/1.1.5.1.47510/manifest.json").is_file()
        )


class UninstallTests(TempDirTest):
    def options(self, **overrides) -> dict:
        base = dict(deploy.DEFAULTS)
        base["yes"] = True
        base["dry_run"] = False
        base.update(overrides)
        return base

    def run_uninstall(self, **overrides) -> int:
        with mock.patch("builtins.print"), mock.patch.object(deploy, "warn"):
            return deploy.cmd_uninstall(self.options(**overrides))

    def test_removes_ours_and_keeps_the_rest(self) -> None:
        target = make_deployed(self.root / "t")
        self.assertEqual(self.run_uninstall(path=str(target)), 0)

        for name in deploy.DEPLOY_DLLS + ("TarkovAddons.pdb", "TarkovAddons.map"):
            self.assertFalse((target / name).exists(), name)
        for name in deploy.DATA_FILES:
            self.assertFalse((target / "ta" / name).exists(), name)
        self.assertFalse((target / "ta" / "compatibility").exists())

        for relative in (
            "ta/configs/tarkovaddons.cfg",
            "ta/maps/tarkov.json",
            "ta/tarkov_prices.json",
            "tarkovaddons_log.txt",
            "tarkovaddons_launcher_log.txt",
            "BsgLauncher.exe",
            "battlestate.dat",
        ):
            self.assertTrue((target / relative).is_file(), relative)
        # ta\ survives because it still holds the user's data.
        self.assertTrue((target / "ta").is_dir())

    def test_purge_removes_everything_it_wrote(self) -> None:
        target = make_deployed(self.root / "t")
        self.assertEqual(self.run_uninstall(path=str(target), purge=True), 0)

        self.assertFalse((target / "ta").exists())
        self.assertFalse((target / "tarkovaddons_log.txt").exists())
        self.assertFalse((target / "tarkovaddons_launcher_log.txt").exists())
        self.assertTrue((target / "BsgLauncher.exe").is_file())
        self.assertTrue((target / "battlestate.dat").is_file())

    def test_prunes_ta_once_it_holds_nothing_of_the_users(self) -> None:
        target = make_deployed(self.root / "t")
        shutil.rmtree(target / "ta" / "configs")
        shutil.rmtree(target / "ta" / "maps")
        (target / "ta" / "tarkov_prices.json").unlink()
        self.run_uninstall(path=str(target))
        self.assertFalse((target / "ta").exists())

    def test_works_with_no_build_tree_present(self) -> None:
        # Uninstalling must not require out\ to still exist.
        target = make_deployed(self.root / "t")
        self.assertEqual(self.run_uninstall(path=str(target)), 0)
        self.assertFalse((target / "TarkovAddons.dll").exists())

    def test_nothing_installed_is_a_successful_no_op(self) -> None:
        target = self.root / "t"
        target.mkdir()
        self.assertEqual(self.run_uninstall(path=str(target)), 0)

    def test_explicit_missing_path_is_an_error(self) -> None:
        # A typo is not the same as an absence, so this must not exit 0.
        with self.assertRaises(deploy.DeployError):
            self.run_uninstall(path=str(self.root / "ghost"))

    def test_dry_run_removes_nothing(self) -> None:
        target = make_deployed(self.root / "t")
        self.assertEqual(self.run_uninstall(path=str(target), dry_run=True), 0)
        self.assertTrue((target / "TarkovAddons.dll").is_file())

    def test_does_not_hang_or_prompt_when_it_cannot_ask(self) -> None:
        # The safety property, end to end through main().
        target = make_deployed(self.root / "t")
        result = subprocess.run(
            [sys.executable, "-m", "tools.deploy", "uninstall", "--path", str(target)],
            cwd=REPO,
            capture_output=True,
            text=True,
            stdin=subprocess.DEVNULL,
            timeout=120,
        )
        self.assertEqual(result.returncode, 1, result.stderr)
        self.assertIn("--yes", result.stderr)
        self.assertTrue((target / "TarkovAddons.dll").is_file())


class ArgumentTests(unittest.TestCase):
    def test_no_arguments_prints_usage(self) -> None:
        self.assertEqual(deploy.parse_args([]), (None, {}, None))

    def test_help_is_not_an_error(self) -> None:
        for flag in ("-h", "--help", "help"):
            self.assertEqual(deploy.parse_args([flag]), (None, {}, None))

    def test_unknown_command_is_an_error(self) -> None:
        _, _, error = deploy.parse_args(["deploy"])
        self.assertIn("unknown command", error)

    def test_unknown_option_is_an_error(self) -> None:
        # Silently ignoring it could deploy the wrong thing.
        _, _, error = deploy.parse_args(["install", "--nope"])
        self.assertIn("unknown option", error)

    def test_option_needing_a_value_says_so(self) -> None:
        _, _, error = deploy.parse_args(["install", "--path"])
        self.assertIn("needs a value", error)

    def test_flag_not_meaning_for_the_command_is_an_error(self) -> None:
        _, _, error = deploy.parse_args(["uninstall", "--rebuild"])
        self.assertIn("does not take", error)

    def test_unknown_config_is_rejected(self) -> None:
        _, _, error = deploy.parse_args(["build", "--config", "Nope"])
        self.assertIn("unknown --config", error)

    def test_backend_parses_and_is_validated(self) -> None:
        _, options, error = deploy.parse_args(["build", "--backend", "cmake"])
        self.assertIsNone(error)
        self.assertEqual(options["backend"], "cmake")

        _, _, error = deploy.parse_args(["build", "--backend", "nope"])
        self.assertIn("unknown --backend", error)

    def test_backend_is_not_an_install_option(self) -> None:
        _, _, error = deploy.parse_args(["install", "--backend", "cmake"])
        self.assertIn("does not take", error)

    def test_values_and_switches_parse(self) -> None:
        command, options, error = deploy.parse_args(
            ["install", "--flavor", "no_aimbot", "--yes", "--dry-run", "--path", "D:/x"]
        )
        self.assertIsNone(error)
        self.assertEqual(command, "install")
        self.assertEqual(options["flavor"], "no_aimbot")
        self.assertTrue(options["yes"])
        self.assertTrue(options["dry_run"])
        self.assertEqual(options["path"], "D:/x")

    def test_flavor_with_spaces_survives(self) -> None:
        _, options, error = deploy.parse_args(["build", "--config", "Prod no aimbot"])
        self.assertIsNone(error)
        self.assertEqual(options["config"], "Prod no aimbot")

    def test_unknown_flavor_is_rejected(self) -> None:
        # Before any work: a typo found two minutes into a build is a bad
        # trade, and a KeyError instead of a message is worse.
        for argv in (["install", "--flavor", "bogus"], ["build", "--flavor", "bogus"]):
            _, _, error = deploy.parse_args(argv)
            self.assertIn("unknown --flavor", error, argv)

    def test_flavor_disagreeing_with_config_is_rejected(self) -> None:
        # --config decides what gets built, so this describes a deployment that
        # cannot happen.
        _, _, error = deploy.parse_args(
            ["build", "--config", "Prod no aimbot", "--flavor", "with_aimbot"]
        )
        self.assertIn("does not match", error)

    def test_flavor_agreeing_with_config_is_accepted(self) -> None:
        _, _, error = deploy.parse_args(
            ["build", "--config", "Prod no aimbot", "--flavor", "no_aimbot"]
        )
        self.assertIsNone(error)

    def test_config_with_no_flavor_is_fine(self) -> None:
        # Debug and Release have no flavor, so nothing to disagree with.
        _, _, error = deploy.parse_args(["build", "--config", "Debug"])
        self.assertIsNone(error)


class MsbuildTests(TempDirTest):
    def test_explicit_path_is_validated(self) -> None:
        with self.assertRaises(deploy.DeployError):
            deploy.find_msbuild(str(self.root / "not-msbuild.exe"))

    def test_missing_msbuild_explains_how_to_install_it(self) -> None:
        with mock.patch.object(deploy, "msbuild_candidates", return_value=[]):
            with self.assertRaises(deploy.DeployError) as caught:
                deploy.find_msbuild(None)
        message = str(caught.exception)
        self.assertIn(deploy.MSBUILD_DOWNLOAD, message)
        self.assertIn(deploy.CXX_WORKLOAD, message)
        self.assertIn(deploy.MSBUILD_DOC, message)
        self.assertIn(deploy.REQUIRED_TOOLSET, message)

    def test_a_candidate_that_does_not_run_is_not_believed(self) -> None:
        # A stale PATH entry is the usual reason a search turns up junk.
        fake = self.root / "MSBuild.exe"
        fake.write_text("not an executable")
        with mock.patch.object(deploy, "msbuild_candidates", return_value=[str(fake)]):
            with self.assertRaises(deploy.DeployError):
                deploy.find_msbuild(None)

    def test_msbuild_not_found_exits_1_through_main(self) -> None:
        # Through main(), so the exit code and the message are both covered.
        #
        # This used to patch msbuild_candidates and then shell out to
        # `python -m tools.deploy build`. The patch could not reach that
        # interpreter, which went on to find the real MSBuild, build the project
        # and exit 0 -- so the test passed only on a machine without MSBuild and
        # failed on every machine that has one, which is every machine that runs
        # this suite. main() takes argv, so the patch can be applied in-process
        # and actually mean something.
        #
        # --backend msbuild because the default for Prod is now CMake, which
        # never goes looking for MSBuild; the default path is covered by
        # CmakeBackendTests.test_default_build_is_cmake.
        captured = io.StringIO()
        with mock.patch.object(deploy, "msbuild_candidates", return_value=[]), \
                mock.patch.object(deploy, "usable_msbuild", return_value=False), \
                contextlib.redirect_stderr(captured):
            with mock.patch.object(sys, "argv", ["deploy.py"]):
                result = deploy.main(["build", "--backend", "msbuild"])

        self.assertEqual(result, 1)
        self.assertIn(deploy.MSBUILD_DOWNLOAD, captured.getvalue())

    def test_the_build_command_carries_the_configuration(self) -> None:
        # Executes the whole body offline -- find_msbuild and run_streaming
        # faked -- so a rename slip or a stray variable is caught here rather
        # than in a two-minute real build.
        solution = self.root / "solution"
        solution.mkdir()
        (solution / "TarkovAddons.sln").write_text("")
        options = dict(deploy.DEFAULTS, config="Prod no aimbot")

        with mock.patch.object(deploy, "find_msbuild", return_value=Path(r"C:\x\MSBuild.exe")), \
                mock.patch.object(deploy, "has_required_toolset", return_value=True), \
                mock.patch.object(deploy, "run_streaming", return_value=0) as run, \
                mock.patch.object(deploy, "SOLUTION_DIR", solution):
            result = deploy.build_with_msbuild("Prod no aimbot", options)

        self.assertEqual(result, 0)
        command = run.call_args.args[0]
        self.assertIn("/p:Configuration=Prod no aimbot", command)
        self.assertIn("/t:Build", command)


class BackendTests(unittest.TestCase):
    """Which build system each configuration resolves to."""

    def options(self, **overrides) -> dict:
        return dict(deploy.DEFAULTS, **overrides)

    def test_debug_and_prod_default_to_cmake(self) -> None:
        for configuration in ("Debug", "Prod"):
            with self.subTest(config=configuration):
                self.assertEqual(
                    deploy.resolve_backend(configuration, self.options()), "cmake"
                )

    def test_the_configurations_cmake_has_no_target_for_stay_on_msbuild(self) -> None:
        # CMAKE_CONFIGURATION_TYPES is "Debug;Prod": there is no Release or
        # "Prod no aimbot" target for CMake to build.
        for configuration in ("Release", "Prod no aimbot"):
            with self.subTest(config=configuration):
                self.assertEqual(
                    deploy.resolve_backend(configuration, self.options()), "msbuild"
                )

    def test_backend_msbuild_forces_msbuild_for_every_configuration(self) -> None:
        for configuration in deploy.CONFIGURATIONS:
            with self.subTest(config=configuration):
                self.assertEqual(
                    deploy.resolve_backend(
                        configuration, self.options(backend="msbuild")
                    ),
                    "msbuild",
                )

    def test_msbuild_path_forces_msbuild_too(self) -> None:
        # --msbuild PATH names an MSBuild.exe, so it cannot mean anything else.
        self.assertEqual(
            deploy.resolve_backend("Prod", self.options(msbuild=r"C:\x\MSBuild.exe")),
            "msbuild",
        )

    def test_backend_cmake_refuses_a_configuration_it_cannot_build(self) -> None:
        with self.assertRaises(deploy.DeployError) as caught:
            deploy.resolve_backend("Prod no aimbot", self.options(backend="cmake"))
        self.assertIn("Prod no aimbot", str(caught.exception))

    def test_backend_cmake_with_msbuild_path_is_a_conflict(self) -> None:
        with self.assertRaises(deploy.DeployError):
            deploy.resolve_backend("Prod", self.options(backend="cmake", msbuild="x"))

    def test_cmd_build_dispatches_to_the_resolved_backend(self) -> None:
        calls: list[tuple[str, str]] = []

        def record(backend):
            return lambda configuration, options: calls.append((backend, configuration)) or 0

        with mock.patch.object(deploy, "build_with_cmake", side_effect=record("cmake")), \
                mock.patch.object(deploy, "build_with_msbuild", side_effect=record("msbuild")):
            deploy.cmd_build(self.options(config="Prod"))
            self.assertEqual(calls, [("cmake", "Prod")])
            calls.clear()
            deploy.cmd_build(self.options(config="Release"))
            self.assertEqual(calls, [("msbuild", "Release")])

    def test_automatic_msbuild_choice_says_why(self) -> None:
        # Release silently building with a different toolchain than Prod would
        # be exactly the kind of surprise this file avoids elsewhere.
        captured = io.StringIO()
        with mock.patch.object(deploy, "build_with_msbuild", return_value=0), \
                contextlib.redirect_stdout(captured):
            deploy.cmd_build(self.options(config="Release"))
        self.assertIn("CMake builds only", captured.getvalue())
        self.assertIn("Release", captured.getvalue())

    def test_an_explicit_backend_is_not_explained_back_to_the_user(self) -> None:
        captured = io.StringIO()
        with mock.patch.object(deploy, "build_with_msbuild", return_value=0), \
                contextlib.redirect_stdout(captured):
            deploy.cmd_build(self.options(config="Prod", backend="msbuild"))
        self.assertEqual(captured.getvalue(), "")


class CmakeToolchainTests(TempDirTest):
    def test_slot_defaults_to_opencode_and_honours_the_variable(self) -> None:
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("SLOT", None)
            self.assertEqual(deploy.build_slot(), "opencode")
        with mock.patch.dict(os.environ, {"SLOT": "docs"}):
            self.assertEqual(deploy.build_slot(), "docs")

    def test_a_slot_that_cannot_name_a_directory_is_refused(self) -> None:
        # The slot is a whole path component of the build tree, and --rebuild
        # deletes that tree. Measured against the guard as it stood: a slot of
        # ..\..\..\TarkovAddons resolved the tree INTO the source tree, passed
        # the "is it under the repo" check, and left rmtree pointed at
        # TarkovAddons\ itself. build.ps1 never had the hole because its slot
        # is always a path suffix; here the name has to be restricted.
        for hostile in (
            r"..\..\..\TarkovAddons",
            "..",          # matches the pattern, but climbs a component
            ".",           # ditto, and names the tree's own directory
            "two words",
            "a/b",
            "x" * 33,
        ):
            with self.subTest(slot=hostile):
                with mock.patch.dict(os.environ, {"SLOT": hostile}):
                    with self.assertRaises(deploy.DeployError) as caught:
                        deploy.build_slot()
                self.assertIn("safe directory name", str(caught.exception))

    def test_an_empty_slot_falls_back_to_the_default(self) -> None:
        # SLOT="" is "not set", same as build_cmake.ps1 treats it; the
        # validation above must not have turned it fatal on the way past.
        with mock.patch.dict(os.environ, {"SLOT": ""}):
            self.assertEqual(deploy.build_slot(), "opencode")

    def test_tree_layout_matches_build_cmake_ps1(self) -> None:
        self.assertEqual(
            deploy.cmake_tree("Prod", "opencode"),
            deploy.REPO_ROOT / "build" / "Prod" / "x64" / "opencode",
        )

    def test_missing_cmake_explains_how_to_install_it(self) -> None:
        with mock.patch.object(deploy, "cmake_candidates", return_value=[]):
            with self.assertRaises(deploy.DeployError) as caught:
                deploy.find_cmake()
        message = str(caught.exception)
        self.assertIn(deploy.CMAKE_DOWNLOAD, message)
        self.assertIn("--backend msbuild", message)

    def test_a_cmake_candidate_that_does_not_run_is_not_believed(self) -> None:
        # Same reason as the MSBuild twin: a stale PATH entry is the usual
        # reason a search turns up junk.
        fake = self.root / "cmake.exe"
        fake.write_text("not an executable")
        with mock.patch.object(deploy, "cmake_candidates", return_value=[str(fake)]):
            with self.assertRaises(deploy.DeployError):
                deploy.find_cmake()

    def test_missing_vcvars_explains_how_to_get_one(self) -> None:
        with mock.patch.object(deploy, "vcvars_candidates", return_value=[]):
            with self.assertRaises(deploy.DeployError) as caught:
                deploy.find_vcvars()
        self.assertIn(deploy.CXX_WORKLOAD, str(caught.exception))

    def test_vcvars_environment_without_include_is_refused(self) -> None:
        # "call <missing.bat> && set" exits 1 without printing the environment.
        # Checking the parsed output rather than the process environment is the
        # point: run from a Developer Command Prompt, INCLUDE is inherited and
        # a failed capture would otherwise look like a success.
        result = subprocess.CompletedProcess(args=[], returncode=1, stdout="nope\n")
        with mock.patch.object(deploy.subprocess, "run", return_value=result), \
                mock.patch.dict(os.environ, {"INCLUDE": "inherited"}, clear=False):
            with self.assertRaises(deploy.DeployError):
                deploy.vcvars_environment(Path("vcvars64.bat"))


class CmakeBackendTests(unittest.TestCase):
    def test_default_build_is_cmake(self) -> None:
        # Through main(), so parse_args -> cmd_build -> find_cmake is covered
        # end to end. With CMake available this must choose CMake; the point of
        # this one is that nothing about the default depends on the machine.
        with mock.patch.object(deploy, "build_with_cmake", return_value=0) as cmake, \
                mock.patch.object(deploy, "build_with_msbuild", return_value=0) as msbuild:
            deploy.main(["build"])
        self.assertTrue(cmake.called, "default build did not use CMake")
        self.assertFalse(msbuild.called, "default build used MSBuild")

    def test_missing_cmake_falls_back_to_msbuild_and_announces_it(self) -> None:
        # The behaviour this whole area turns on. A machine with MSBuild and no
        # CMake must still be able to build, and must be told on stderr that the
        # artefact is NOT the one CMake would have produced.
        #
        # usable_msbuild is patched rather than mkdir'ing a fake exe, because
        # every real path runs `MSBuild.exe -version`; the established pattern
        # here (see test_msbuild_not_found_exits_1_through_main) is to make the
        # candidate list lie and the validator agree with it.
        #
        # announce_fallback is asserted through its own capture rather than by
        # checking stderr here, because build_with_msbuild is mocked out and
        # that is where the announcement would otherwise be printed. Calling
        # it directly is the one way to see it without a real build.
        captured = io.StringIO()
        with mock.patch.object(deploy, "cmake_candidates", return_value=[]), \
                mock.patch.object(deploy, "msbuild_candidates",
                                  return_value=[r"C:\fake\MSBuild.exe"]), \
                mock.patch.object(deploy, "usable_msbuild", return_value=True), \
                mock.patch.object(deploy, "build_with_msbuild", return_value=0), \
                mock.patch.object(deploy, "announce_fallback",
                                  side_effect=deploy.announce_fallback), \
                contextlib.redirect_stderr(captured):
            deploy.main(["build"])

        text = captured.getvalue()
        self.assertIn("TOOLCHAIN FALLBACK", text)
        self.assertIn("not the same artefact", text)
        # The remedy has to be in the message, or the operator cannot act on it.
        self.assertIn("--backend cmake", text)
        self.assertIn("--backend msbuild", text)

    def test_the_fallback_announcement_names_the_cost_and_the_remedy(self) -> None:
        # Called directly rather than through main(), so this test is about the
        # wording: an announcement that does not say the artefact differs and
        # how to get the other one is decoration, not a warning.
        captured = io.StringIO()
        cfg = "Prod no aimbot"
        with contextlib.redirect_stderr(captured):
            deploy.announce_fallback(
                cfg, "CMake was not found.", Path(r"C:\fake\MSBuild.exe")
            )
        text = captured.getvalue()
        self.assertIn("TOOLCHAIN FALLBACK", text)
        self.assertIn("Prod", text)
        self.assertIn(r"C:\fake\MSBuild.exe", text)
        # The cost, so the operator knows this is not a free swap.
        self.assertIn("not the same artefact", text)
        self.assertIn("map_icf", text)
        # Both remedies, so either intent can be made explicit.
        self.assertIn("--backend cmake", text)
        self.assertIn("--backend msbuild", text)
        # Loud, not a footnote.
        self.assertIn("=" * 72, text)
        # The remedy must name the configuration. An unsubstituted placeholder
        # would print `--config {configuration}`, which reads like a template and
        # cannot be copy-pasted -- and it is the sort of thing a warning nobody
        # reads keeps forever.
        self.assertIn(f"--config {cfg}", text)
        self.assertNotIn("{configuration}", text)

    def test_fallback_is_not_used_when_cmake_is_explicitly_requested(self) -> None:
        # --backend cmake means "CMake or fail". A silent swap here would be the
        # exact surprise the original no-fallback design guarded, and explicit
        # intent must survive the fallback mechanism.
        captured = io.StringIO()
        with mock.patch.object(deploy, "cmake_candidates", return_value=[]), \
                mock.patch.object(deploy, "build_with_msbuild", return_value=0), \
                contextlib.redirect_stderr(captured):
            result = deploy.main(["build", "--backend", "cmake"])
        self.assertEqual(result, 1, "explicit --backend cmake did not fail")
        self.assertIn(deploy.CMAKE_DOWNLOAD, captured.getvalue())
        self.assertNotIn("TOOLCHAIN FALLBACK", captured.getvalue())

    def test_both_toolchains_missing_names_both_remedies(self) -> None:
        # Falling back into a second "not found" would waste the operator's time
        # discovering them one at a time.
        captured = io.StringIO()
        with mock.patch.object(deploy, "cmake_candidates", return_value=[]), \
                mock.patch.object(deploy, "msbuild_candidates", return_value=[]), \
                mock.patch.object(deploy, "usable_msbuild", return_value=False), \
                contextlib.redirect_stderr(captured):
            result = deploy.main(["build"])
        self.assertEqual(result, 1)
        text = captured.getvalue()
        self.assertIn("Neither CMake nor MSBuild", text)
        self.assertIn(deploy.CMAKE_DOWNLOAD, text)
        self.assertIn(deploy.MSBUILD_DOWNLOAD, text)

    def _stage(self, report: list[str], code: int = 0) -> int:
        """Run stage_prod with the staging script's output faked."""

        def fake(command, env=None, lines=None, **kwargs):
            lines.extend(report)
            return code

        with mock.patch.object(deploy, "run_streaming", side_effect=fake):
            return deploy.stage_prod("opencode")

    def test_stage_prod_returns_the_count_it_was_told(self) -> None:
        self.assertEqual(self._stage(["copied 5 artefact(s) to D:\\somewhere\n"]), 5)

    def test_stage_prod_refuses_a_silent_zero(self) -> None:
        # The failure this exists for: the deploy folder quietly keeps the
        # previous build while every exit code says success.
        with self.assertRaises(deploy.DeployError) as caught:
            self._stage(["copied 0 artefact(s) to D:\\somewhere\n"])
        self.assertIn("incomplete", str(caught.exception))

    def test_stage_prod_refuses_an_unparseable_report(self) -> None:
        with self.assertRaises(deploy.DeployError):
            self._stage(["something else entirely\n"])

    def test_stage_prod_refuses_a_failed_script(self) -> None:
        with mock.patch.object(deploy, "run_streaming", return_value=1):
            with self.assertRaises(deploy.DeployError):
                deploy.stage_prod("opencode")

    def test_stage_prod_passes_the_slot_to_the_script(self) -> None:
        commands: list[list[str]] = []

        def fake(command, env=None, lines=None, **kwargs):
            commands.append(command)
            if lines is not None:
                lines.append("copied 5 artefact(s) to D:\\somewhere\n")
            return 0

        with mock.patch.object(deploy, "run_streaming", side_effect=fake):
            deploy.stage_prod("docs")
        self.assertTrue(any("copy_out.ps1" in part for part in commands[0]))
        self.assertEqual(commands[0][commands[0].index("-Slot") + 1], "docs")


class FlavorTests(unittest.TestCase):
    def test_flavors_match_the_vcxproj_outdirs(self) -> None:
        self.assertEqual(deploy.FLAVORS["with_aimbot"], ("out", "prod", "with_aimbot"))
        self.assertEqual(deploy.FLAVORS["no_aimbot"], ("out", "prod", "no_aimbot"))

    def test_configurations_map_to_flavors(self) -> None:
        self.assertEqual(deploy.CONFIG_FLAVOR["Prod"], "with_aimbot")
        self.assertEqual(deploy.CONFIG_FLAVOR["Prod no aimbot"], "no_aimbot")
        # Debug and Release use the toolset default under x64\ instead, which is
        # why they are deliberately absent and need --source.
        self.assertNotIn("Debug", deploy.CONFIG_FLAVOR)


if __name__ == "__main__":
    unittest.main()
