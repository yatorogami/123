from __future__ import annotations

import json
import struct
import tempfile
import unittest
from pathlib import Path

from tools.manifest_tool import (
    build_manifest,
    describe_module,
    find_pattern_matches,
    inspect_isil,
    inspect_pe,
    main as manifest_tool_main,
    parse_legacy_cfg,
    parse_pattern,
    parse_unsigned,
    rva_to_file_offset,
    validate_manifest,
)


class LegacyParserTests(unittest.TestCase):
    def test_parser_trims_comments_and_rejects_duplicates(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "offsets.cfg"
            path.write_text(
                "\n".join(
                    [
                        "# comment = ignored",
                        " first = 0x10 # inline comment",
                        "first = 0x20",
                        "empty=",
                        "malformed",
                    ]
                ),
                encoding="utf-8",
            )

            values, issues = parse_legacy_cfg(path)

        self.assertEqual(values, {"first": "0x10", "empty": ""})
        self.assertEqual(len(issues), 2)
        self.assertTrue(any(issue.path.endswith(":3") for issue in issues))
        self.assertTrue(any(issue.path.endswith(":5") for issue in issues))
        self.assertTrue(any("duplicate" in issue.message for issue in issues))

    def test_unsigned_parser_accepts_hex_and_decimal(self) -> None:
        self.assertEqual(parse_unsigned("0x20", "test"), 32)
        self.assertEqual(parse_unsigned("32", "test"), 32)
        self.assertIsNone(parse_unsigned("", "test"))
        with self.assertRaises(ValueError):
            parse_unsigned("-1", "test")
        with self.assertRaises(ValueError):
            parse_unsigned("0x10000000000000000", "test")


class IsilTests(unittest.TestCase):
    def test_isil_build_identity_is_detected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            build = root / "Assembly-CSharp" / "EFT" / "Build.txt"
            build.parent.mkdir(parents=True)
            build.write_text('Build id: 9.8.7.12345\n', encoding="utf-8")
            info = inspect_isil(root)

        self.assertEqual(info.build_version, "9.8.7.12345")
        self.assertEqual(info.build_evidence, (str(Path("Assembly-CSharp") / "EFT" / "Build.txt"),))

    def test_clear_rvas_keeps_patterns_for_new_profile(self) -> None:
        manifest, issues = build_manifest(
            {"il2cpp_domain_get": "0x1234"},
            {"il2cpp_domain_get": "48 83 ??"},
            profile_id="",
            game_version="9.8.7.12345",
            clear_rvas=True,
        )

        self.assertEqual(issues, [])
        self.assertEqual(manifest["profile"]["id"], "eft-9.8.7.12345")
        self.assertIsNone(manifest["symbols"][0]["rva"])
        self.assertEqual(manifest["symbols"][0]["patterns"], ["48 83 ?"])


    def test_launcher_entries_keep_their_native_module_mapping(self) -> None:
        manifest, issues = build_manifest(
            {
                "be_service_check": "",
                "load_be_client": "",
                "be_client_start": "",
                "be_client_init": "",
                "load_be_client_known_offset": "0x1000",
                "run_validation_movenext_offset": "0x2000",
            },
            {},
            profile_id="launcher-test",
            game_version="test",
            clear_rvas=True,
        )
        modules = {symbol["name"]: symbol["module"] for symbol in manifest["symbols"]}
        self.assertEqual(issues, [])
        self.assertEqual(modules["be_service_check"], "UnityPlayer.dll")
        self.assertEqual(modules["load_be_client"], "GameAssembly.dll")
        self.assertEqual(modules["be_client_start"], "GameAssembly.dll")
        self.assertEqual(modules["be_client_init"], "GameAssembly.dll")
        self.assertEqual(modules["load_be_client_known_offset"], "GameAssembly.dll")
        self.assertEqual(modules["run_validation_movenext_offset"], "GameAssembly.dll")

    def test_hwid_check_maps_to_gameassembly_regardless_of_default_module(self) -> None:
        # hwid_check matches no legacy prefix, so it used to be placed by the
        # --default-module fallback. A non-default default-module would have
        # misfiled it; the explicit mapping must win.
        manifest, issues = build_manifest(
            {"hwid_check": "0x1000"},
            {},
            profile_id="hwid-test",
            game_version="test",
            default_module="UnityPlayer.dll",
        )
        symbols = {symbol["name"]: symbol for symbol in manifest["symbols"]}
        self.assertEqual(issues, [])
        self.assertEqual(symbols["hwid_check"]["module"], "GameAssembly.dll")

    def test_hwid_check_is_tracked_but_never_required(self) -> None:
        # It is consumed by feature/spoofer.cpp only, so it must never become a
        # required symbol of the core profile.
        manifest, _ = build_manifest(
            {},
            {"hwid_check": ""},
            profile_id="hwid-test",
            game_version="test",
            clear_rvas=True,
        )
        symbols = {symbol["name"]: symbol for symbol in manifest["symbols"]}
        self.assertIn("hwid_check", symbols)
        self.assertFalse(symbols["hwid_check"]["required"])
        self.assertEqual(symbols["hwid_check"]["patterns"], [])
        self.assertIsNone(symbols["hwid_check"]["rva"])

    def test_shipped_patterns_cfg_exposes_hwid_check_slot(self) -> None:
        # Guards the regression: hwid_check was read by spoofer.cpp but existed in
        # no config file, making it an invisible compiled-in dependency.
        repo = Path(__file__).resolve().parents[2]
        values, truncated = parse_legacy_cfg(repo / "TarkovAddons" / "patterns.cfg")
        self.assertEqual(truncated, [])
        self.assertIn("hwid_check", values)
        self.assertEqual(values["hwid_check"], "")


class PatternTests(unittest.TestCase):
    def test_pattern_parser_preserves_literal_zero(self) -> None:
        pattern = parse_pattern("48 00 ? 89")
        self.assertEqual(pattern, (0x48, 0x00, None, 0x89))

    def test_legacy_pattern_can_be_built(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            offsets = root / "offsets.cfg"
            patterns = root / "patterns.cfg"
            offsets.write_text("il2cpp_domain_get=0x1000\n", encoding="utf-8")
            patterns.write_text("il2cpp_domain_get=48 83 ??\n", encoding="utf-8")
            offset_values, offset_issues = parse_legacy_cfg(offsets)
            pattern_values, pattern_issues = parse_legacy_cfg(patterns)

        manifest, issues = build_manifest(
            offset_values,
            pattern_values,
            profile_id="test-profile",
            game_version="test-build",
        )

        self.assertEqual(offset_issues, [])
        self.assertEqual(pattern_issues, [])
        self.assertEqual(issues, [])
        self.assertEqual(manifest["symbols"][0]["rva"], "0x1000")
        self.assertEqual(manifest["symbols"][0]["patterns"], ["48 83 ?"])


class PeTests(unittest.TestCase):
    @staticmethod
    def make_pe() -> bytes:
        # Minimal PE32+ image with one .text section at RVA 0x1000.
        pe_offset = 0x80
        optional_offset = pe_offset + 4 + 20
        optional_size = 0xF0
        section_offset = optional_offset + optional_size
        raw_offset = 0x200
        raw_size = 0x200
        data = bytearray(raw_offset + raw_size)

        data[0:2] = b"MZ"
        struct.pack_into("<I", data, 0x3C, pe_offset)
        data[pe_offset:pe_offset + 4] = b"PE\0\0"
        struct.pack_into("<H", data, pe_offset + 4, 0x8664)
        struct.pack_into("<H", data, pe_offset + 6, 1)
        struct.pack_into("<I", data, pe_offset + 8, 0x12345678)
        struct.pack_into("<H", data, pe_offset + 20, optional_size)
        struct.pack_into("<H", data, optional_offset, 0x20B)
        struct.pack_into("<I", data, optional_offset + 56, 0x2000)
        struct.pack_into("<I", data, optional_offset + 60, raw_offset)
        data[section_offset:section_offset + 5] = b".text"
        struct.pack_into("<I", data, section_offset + 8, 0x1000)
        struct.pack_into("<I", data, section_offset + 12, 0x1000)
        struct.pack_into("<I", data, section_offset + 16, raw_size)
        struct.pack_into("<I", data, section_offset + 20, raw_offset)
        data[raw_offset:raw_offset + 8] = bytes.fromhex("48 83 EC 28 90 90 90 90")
        return bytes(data)

    def test_pe_metadata_and_rva_conversion(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "GameAssembly.dll"
            path.write_bytes(self.make_pe())
            info = inspect_pe(path)
            descriptor = describe_module(path)

            self.assertEqual(info.size_of_image, 0x2000)
            self.assertEqual(info.timestamp, 0x12345678)
            self.assertEqual(descriptor["size"], 0x2000)
            self.assertEqual(descriptor["pe_timestamp"], "0x12345678")
            self.assertIsNotNone(descriptor["text_sha256"])
            self.assertEqual(rva_to_file_offset(info, 0x1000), 0x200)
            self.assertIsNone(rva_to_file_offset(info, 0x3000))

            manifest = {
                "schema_version": 1,
                "profile": {"id": "pe-test", "game_version": "test"},
                "modules": {"GameAssembly.dll": descriptor},
                "symbols": [
                    {
                        "name": "test_symbol",
                        "module": "GameAssembly.dll",
                        "kind": "function",
                        "rva": "0x1000",
                        "patterns": ["48 83 EC 28 ? ? ? ?"],
                        "required": True,
                    }
                ],
            }
            issues = validate_manifest(manifest, module_dir=Path(directory), strict=True)

        self.assertEqual(issues, [])

    def test_pattern_scan_and_manifest_mismatch(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "GameAssembly.dll"
            path.write_bytes(self.make_pe())
            info = inspect_pe(path)
            with path.open("rb") as stream:
                import mmap

                with mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data:
                    matches, truncated = find_pattern_matches(
                        data, info, parse_pattern("48 83 EC 28")
                    )
            self.assertEqual(matches, [0x1000])
            self.assertFalse(truncated)

            manifest = {
                "schema_version": 1,
                "profile": {"id": "pe-test", "game_version": "test"},
                "modules": {"GameAssembly.dll": describe_module(path)},
                "symbols": [
                    {
                        "name": "test_symbol",
                        "module": "GameAssembly.dll",
                        "kind": "function",
                        "rva": "0x1001",
                        "patterns": ["48 83 EC 28"],
                        "required": True,
                    }
                ],
            }
            issues = validate_manifest(manifest, module_dir=Path(directory))

        self.assertTrue(any("does not match" in issue.message for issue in issues))
        self.assertTrue(any("not among" in issue.message for issue in issues))


class ManifestValidationTests(unittest.TestCase):
    def test_schema_validation_rejects_unknown_fields(self) -> None:
        manifest = {
            "schema_version": 1,
            "profile": {"id": "test", "game_version": "test"},
            "modules": {"GameAssembly.dll": {}},
            "symbols": [
                {
                    "name": "test",
                    "module": "GameAssembly.dll",
                    "kind": "function",
                    "rva": None,
                    "patterns": [],
                    "required": True,
                }
            ],
            "unexpected": True,
        }
        issues = validate_manifest(manifest)
        self.assertTrue(any(issue.path == "unexpected" for issue in issues))

    def test_missing_required_symbol_field_is_rejected(self) -> None:
        manifest = {
            "schema_version": 1,
            "profile": {"id": "test", "game_version": "test"},
            "modules": {"GameAssembly.dll": {}},
            "symbols": [
                {
                    "name": "test",
                    "module": "GameAssembly.dll",
                    "kind": "function",
                    "patterns": [],
                    "required": True,
                }
            ],
        }
        issues = validate_manifest(manifest)
        self.assertTrue(any(issue.path == "symbols[0].rva" for issue in issues))

    def test_managed_resolver_requires_reference(self) -> None:
        manifest = {
            "schema_version": 1,
            "profile": {"id": "test", "game_version": "test"},
            "modules": {"Assembly-CSharp.dll": {}},
            "symbols": [
                {
                    "name": "managed",
                    "module": "Assembly-CSharp.dll",
                    "kind": "function",
                    "resolver": "managed",
                    "rva": None,
                    "patterns": [],
                    "required": True,
                }
            ],
        }
        issues = validate_manifest(manifest)
        self.assertTrue(any(issue.path == "symbols[0].managed" for issue in issues))

    def test_managed_resolver_accepts_reference(self) -> None:
        manifest = {
            "schema_version": 1,
            "profile": {"id": "test", "game_version": "test"},
            "modules": {"Assembly-CSharp.dll": {}},
            "symbols": [
                {
                    "name": "managed",
                    "module": "Assembly-CSharp.dll",
                    "kind": "data",
                    "resolver": "managed",
                    "rva": None,
                    "patterns": [],
                    "required": True,
                    "managed": {
                        "assembly": "Assembly-CSharp",
                        "namespace": "EFT.CameraControl",
                        "type": "CameraManager",
                        "member": "<OpticCameraManager>k__BackingField",
                        "member_kind": "field",
                    },
                }
            ],
        }
        self.assertEqual(validate_manifest(manifest), [])

    def test_schema_file_is_json(self) -> None:
        schema_path = Path(__file__).parents[1] / "manifest.schema.json"
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        self.assertEqual(schema["$schema"], "https://json-schema.org/draft/2020-12/schema")
        self.assertEqual(schema["properties"]["schema_version"]["const"], 1)


class UpdateRvasTests(unittest.TestCase):
    """`update-rvas` must not report success while dropping a requested symbol.

    Regression: `tools/README.md` documents an rvas.json containing
    `run_validation_movenext_offset`. Run verbatim against the shipped profile
    it printed `WARN skipping unknown symbol`, `Updated 1 symbol(s)` and
    exited 0 -- so 0x1B76260 ended up recorded nowhere in version control and
    nothing went red.
    """

    @staticmethod
    def make_manifest(names: list[str]) -> dict:
        return {
            "schema_version": 1,
            "profile": {"id": "t", "game_version": "t"},
            "modules": {"GameAssembly.dll": {}},
            "symbols": [
                {
                    "name": name,
                    "module": "GameAssembly.dll",
                    "kind": "function",
                    "resolver": "native",
                    "rva": None,
                    "patterns": [],
                    "required": False,
                }
                for name in names
            ],
        }

    def _run(self, manifest: dict, rvas: dict, *extra: str) -> tuple[int, dict, str]:
        argv = ["update-rvas"]
        with tempfile.TemporaryDirectory() as directory:
            manifest_path = Path(directory) / "manifest.json"
            rvas_path = Path(directory) / "rvas.json"
            manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
            rvas_path.write_text(json.dumps(rvas), encoding="utf-8")
            before = manifest_path.read_bytes()
            code = manifest_tool_main([*argv, str(manifest_path), "--rvas", str(rvas_path), *extra])
            after = manifest_path.read_bytes()
            written = json.loads(manifest_path.read_text(encoding="utf-8"))
        return code, written, "unchanged" if before == after else "written"

    def test_unknown_symbol_fails_and_writes_nothing(self) -> None:
        code, written, state = self._run(
            self.make_manifest(["load_be_client"]),
            {"load_be_client": "0xEE2660", "run_validation_movenext_offset": "0x1B76260"},
        )
        self.assertEqual(code, 1, "an unknown name must be an error, not a warning")
        self.assertEqual(state, "unchanged", "a partial update must not be written")
        # The known symbol must not have been applied either -- fail closed.
        self.assertIsNone(written["symbols"][0]["rva"])

    def test_every_unknown_name_is_reported(self) -> None:
        code, _, _ = self._run(self.make_manifest(["a"]), {"nope1": "0x1", "nope2": "0x2"})
        self.assertEqual(code, 1)

    def test_allow_unknown_records_the_known_subset(self) -> None:
        code, written, state = self._run(
            self.make_manifest(["load_be_client"]),
            {"load_be_client": "0xEE2660", "run_validation_movenext_offset": "0x1B76260"},
            "--allow-unknown",
        )
        self.assertEqual(code, 0)
        self.assertEqual(state, "written")
        self.assertEqual(written["symbols"][0]["rva"], "0xEE2660")
        self.assertEqual(len(written["symbols"]), 1)

    def test_all_known_succeeds(self) -> None:
        code, written, state = self._run(
            self.make_manifest(["load_be_client"]), {"load_be_client": "0xEE2660"}
        )
        self.assertEqual(code, 0)
        self.assertEqual(state, "written")
        self.assertEqual(written["symbols"][0]["rva"], "0xEE2660")

    def test_rvas_must_be_an_object(self) -> None:
        self.assertEqual(self._run(self.make_manifest(["a"]), ["nope"])[0], 2)


class ShippedProfileDriftTests(unittest.TestCase):
    """The checked-in profile must not silently diverge from its own inputs.

    `compatibility/profiles/<build>/manifest.json` is generated from
    `TarkovAddons/{offsets,patterns}.cfg`. Nothing read that file's contents:
    `test_deploy.py` only checks it is deployed to the right path and
    `test_manifest_tool.py` only exercised synthetic manifests -- so a
    hand-edit that dropped a symbol was invisible until the game silently
    stopped resolving it.

    Deliberately does NOT read `TarkovAddons/GameDump/`: it is gitignored
    ("regenerate locally"), so a test needing it would be unrunnable on a
    fresh clone. Module/RVA checking belongs to `manifest_tool.py validate`,
    which needs the PE files supplied.
    """

    REPO = Path(__file__).resolve().parents[2]
    PROFILE = REPO / "compatibility" / "profiles" / "1.1.5.1.47510" / "manifest.json"

    # BOTH were restored 2026-10-05, so this tuple is now empty and the test
    # requires it to STAY empty. Kept as an explicit tuple rather than deleted
    # so the assertion below reads as "nothing is dropped" instead of vanishing.
    #
    # Module placement of the two was MEASURED, not inferred from the prefix
    # rule in _module_for_legacy_name: both RVAs are inside BOTH modules'
    # SizeOfImage, so size cannot discriminate. Reading bytes does -- and IDA
    # independently named both as function starts in GameAssembly.dll
    # (sub_180EE2660, 192B; sub_181B76260, 1262B). In UnityPlayer.dll
    # 0x1B76260 is relocation data and 0xEE2660 is mid-function.
    KNOWN_MISSING_FROM_SHIPPED: tuple[str, ...] = ()

    def _imported_names(self) -> set[str]:
        offsets, offset_issues = parse_legacy_cfg(self.REPO / "TarkovAddons" / "offsets.cfg")
        patterns, pattern_issues = parse_legacy_cfg(self.REPO / "TarkovAddons" / "patterns.cfg")
        self.assertEqual(offset_issues, [])
        self.assertEqual(pattern_issues, [])
        manifest, issues = build_manifest(
            offsets,
            patterns,
            profile_id="eft-drift-check",
            game_version="1.1.5.1.47510",
        )
        self.assertEqual(issues, [])
        return {symbol["name"] for symbol in manifest["symbols"]}

    def _shipped_names(self) -> set[str]:
        self.assertTrue(self.PROFILE.is_file(), f"{self.PROFILE} is missing")
        manifest = json.loads(self.PROFILE.read_text(encoding="utf-8-sig"))
        self.assertEqual(manifest.get("schema_version"), 1)
        return {symbol["name"] for symbol in manifest["symbols"]}

    def test_shipped_profile_drops_no_imported_symbol(self) -> None:
        dropped = sorted(self._imported_names() - self._shipped_names())
        self.assertEqual(
            tuple(dropped),
            self.KNOWN_MISSING_FROM_SHIPPED,
            "symbols present in offsets.cfg/patterns.cfg but absent from the "
            "shipped profile. If this is an intentional change, update "
            "compatibility/README.md and PROFILE_GUIDE.md too; if the two "
            "known entries were restored, delete KNOWN_MISSING_FROM_SHIPPED.",
        )

    def test_shipped_profile_invents_no_symbol(self) -> None:
        extra = sorted(self._shipped_names() - self._imported_names())
        self.assertEqual(extra, [], f"shipped profile has symbols no cfg file defines: {extra}")

    def test_shipped_profile_reports_the_symbol_count_it_claims(self) -> None:
        # PROFILE_GUIDE.md:49 states this profile has 21 symbols. It ships 19.
        # Whichever is right, the two must agree; the doc fix is the next step.
        shipped = self._shipped_names()
        imported = self._imported_names()
        self.assertEqual(
            len(shipped),
            21 - len(self.KNOWN_MISSING_FROM_SHIPPED),
            f"shipped symbol count changed to {len(shipped)}; update PROFILE_GUIDE.md:49",
        )
        self.assertEqual(len(imported), 21)


if __name__ == "__main__":
    unittest.main()
