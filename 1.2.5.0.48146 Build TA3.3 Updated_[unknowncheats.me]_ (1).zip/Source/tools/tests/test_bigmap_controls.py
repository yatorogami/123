"""Guards for the big map's step 6/7 work (tools/plan_bigmap_and_minimap.md 4.3).

Everything here checks something a raid cannot: the member that was read but
never written, the source-order mistake that cost a build, the control that
silently does nothing, and the i18n keys in all nineteen locales. None of it
substitutes for playing the map -- these only mean the obvious regressions have
somewhere to fail.

The source-text checks strip comments and string literals before searching,
which is the rule the project already learned the hard way: a checker that can
match its own explanatory comment is not a checker.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
MINIMAP = REPO / "TarkovAddons" / "module" / "minimap.h"
MAP_CPP = REPO / "TarkovAddons" / "module" / "impl" / "MapModule.cpp"
MAP_H = REPO / "TarkovAddons" / "module" / "impl" / "MapModule.h"
ESP_CPP = REPO / "TarkovAddons" / "module" / "impl" / "EspModule.cpp"
ESP_H = REPO / "TarkovAddons" / "module" / "impl" / "EspModule.h"
MGR_H = REPO / "TarkovAddons" / "module" / "ModuleManager.h"
LANG = REPO / "TarkovAddons" / "lang"

LOCALES = [
    "br", "ch", "cs", "en", "es", "fr", "ge", "hu", "it", "jp",
    "kr", "pl", "po", "ro", "ru", "sk", "sr", "tu", "tw",
]

# The keys this work added. Named rather than derived from the source so that
# deleting a call site AND its keys still fails here -- a test that re-derives
# its own expectations from the code it is checking checks nothing.
BIG_MAP_KEYS = [
    "big_map_quest_cb",
    "big_map_exfils_cb",
    "big_map_players_cb",
    "big_map_static_cb",
    "big_map_loc_itm",
    "big_map_loc_current",
    "big_map_loc_raid_locked",
    "big_map_floor_prev",
    "big_map_floor_next",
    "big_map_floor_follow",
    "big_map_centre_me",
]


def _strip_comments_only(text: str) -> str:
    """Blank out // and /* */ comments, KEEPING string literal contents.

    This is the mode for checking that a key was passed to i18n::tr(): the
    literal is the thing under test, so blanking it would make the check pass on
    anything. Comments are still removed, which is the half that matters -- a
    checker that matches its own explanatory comment is not a checker.
    """
    out = list(text)
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c == "/" and i + 1 < n and text[i + 1] == "/":
            while i < n and text[i] != "\n":
                out[i] = " "
                i += 1
        elif c == "/" and i + 1 < n and text[i + 1] == "*":
            while i < n and not (text[i] == "*" and i + 1 < n and text[i + 1] == "/"):
                if text[i] != "\n":
                    out[i] = " "
                i += 1
            for _ in range(2):
                if i < n:
                    out[i] = " "
                    i += 1
        else:
            i += 1
    return "".join(out)


def _strip_comments(text: str) -> str:
    """Blank out // and /* */ comments AND string/char literal contents.

    Contents, not the quotes: a name must not be matchable from inside a literal,
    because a literal quoting a retired identifier is exactly the shape that
    makes a source-text check lie. Newlines are preserved so line numbers stay
    usable. Use _strip_comments_only() when the literal IS the subject.
    """
    out = list(text)
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c == "/" and i + 1 < n and text[i + 1] == "/":
            while i < n and text[i] != "\n":
                out[i] = " "
                i += 1
        elif c == "/" and i + 1 < n and text[i + 1] == "*":
            while i < n and not (text[i] == "*" and i + 1 < n and text[i + 1] == "/"):
                if text[i] != "\n":
                    out[i] = " "
                i += 1
            for _ in range(2):
                if i < n:
                    out[i] = " "
                    i += 1
        elif c in ('"', "'"):
            quote = c
            i += 1
            while i < n and text[i] != quote:
                if text[i] == "\\":
                    out[i] = " "
                    i += 1
                    if i < n:
                        out[i] = " "
                        i += 1
                    continue
                if text[i] != "\n":
                    out[i] = " "
                i += 1
            i += 1
        else:
            i += 1
    return "".join(out)


# ---------------------------------------------------------------------------
# The bug that started this: a member read every frame and written nowhere.
# ---------------------------------------------------------------------------


def test_the_big_map_writes_the_player_position_it_reads():
    """player_pos_ is read by draw_overlay and floor picking.

    It was declared, read in three places, and never assigned anywhere:
    gameworld_update took main_player as [[maybe_unused]]. The dot therefore
    rendered at world origin, which on Customs is INSIDE the playable area, so it
    looked like a position rather than like missing data.
    """
    clean = _strip_comments(MAP_CPP.read_text(encoding="utf-8"))
    body = clean[clean.index("MapModule::gameworld_update") :]

    assert "[[maybe_unused]] Il2CppObjectInstance main_player" not in body, (
        "gameworld_update is back to ignoring the player it must read the "
        "position from"
    )
    assert re.search(r"player_pos_\s*=", body), (
        "gameworld_update never assigns player_pos_ -- the map is reading a "
        "default-constructed vector"
    )
    assert "transform_get_pos" in body, (
        "player_pos_ is assigned, but not from a transform: it must come from "
        "unity::transform_get_pos on the player's transform"
    )
    assert re.search(r"has_player_pos_\s*=\s*true", body), (
        "player_pos_ is written without setting has_player_pos_, so the draw "
        "side cannot tell 'at the origin' from 'no position yet'"
    )


def test_the_zero_vector_is_not_used_as_a_missing_position_sentinel():
    """The guard is a bool, not a zero test. State why in the test's own terms:
    (0,0,0) is a legal position on Customs' map bounds, so `pos != {}` would be
    false for a real player standing there."""
    header = MAP_H.read_text(encoding="utf-8")
    assert "bool has_player_pos_ = false;" in header
    draw = _strip_comments(MAP_CPP.read_text(encoding="utf-8"))
    draw = draw[draw.index("MapModule::draw_overlay") :]
    assert "have_player_pos" in draw, "draw_overlay never reads has_player_pos_"


# ---------------------------------------------------------------------------
# Source order in minimap.h -- the mistake that cost a build.
# ---------------------------------------------------------------------------


def _define_before_use_scan(text: str) -> tuple[dict[str, int], dict[str, list[tuple[int, int]]]]:
    """(definitions, use-before-definition) over a header of inline functions.

    A definition is `inline ... name(` whose next `;`/`{` is a `{` -- i.e. a body,
    not a declaration. Templates and class/struct definitions are skipped: their
    bodies instantiate later, so a textual scan says nothing useful about them.
    """
    defined: dict[str, int] = {}
    for m in re.finditer(r"\binline\b(?![^\n;{]*\b(?:class|struct)\b)[^;{()]*?\b(\w+)\s*\(", text):
        name = m.group(1)
        tail = text[m.end() : m.end() + 600]
        semi = tail.find(";")
        brace = tail.find("{")
        if brace != -1 and (semi == -1 or brace < semi):
            defined.setdefault(name, text.count("\n", 0, m.start()) + 1)

    early: dict[str, list[tuple[int, int]]] = {}
    for m in re.finditer(r"(?<![\w:.>])(\w+)\s*\(", text):
        name = m.group(1)
        if name not in defined:
            continue
        line = text.count("\n", 0, m.start()) + 1
        if line < defined[name]:
            early.setdefault(name, []).append((line, defined[name]))
    return defined, early


def test_minimap_inline_functions_are_defined_before_they_are_called():
    """minimap.h is ~2800 lines of inline functions with NO forward declarations.

    That is legal C++ as long as nothing calls forward. One new helper that did
    (`floor_cycle_label` calling `format_overlay_floor_label`, which sat 2400
    lines below it) took a full rebuild to find out, and would have been a
    first-use surprise in every TU that includes the header.

    NEGATIVE CONTROL: the tree as of the failing build reported
    format_overlay_floor_label used at 320 and defined at 2735; this scan found
    143 definitions and 0 forward uses after the move, so a one-line revert makes
    this go red rather than merely making it feel covered.
    """
    clean = _strip_comments(MINIMAP.read_text(encoding="utf-8"))
    defined, early = _define_before_use_scan(clean)

    assert len(defined) >= 140, (
        f"the scan only found {len(defined)} inline definitions; it has stopped "
        f"recognising them and would pass on anything"
    )
    assert not early, (
        "these inline functions are called above their own definition in "
        "minimap.h (name: used at line N, defined at line M): "
        + "; ".join(f"{n}: {h[:3]}" for n, h in sorted(early.items()))
    )


def test_the_floor_override_block_is_self_contained():
    """The four helpers the big map needs, plus the one it borrows.

    Named rather than range-scanned: the block is identified by its first
    function so a comment above it cannot make the test vacuous.
    """
    clean = _strip_comments(MINIMAP.read_text(encoding="utf-8"))
    start = clean.index("inline int& manual_floor_index()")
    end = clean.index("inline void update_active_layers(")
    block = clean[start:end]
    for name in (
        "manual_floor_index",
        "has_floor_override",
        "floor_cycle_order",
        "floor_cycle_label",
        "cycle_manual_floor",
        "set_manual_floor",
        "clear_floor_override",
    ):
        assert name in block, f"the floor-override block lost {name}"


def test_the_override_beats_the_player_derived_floor():
    """update_active_layers recomputes the floor from the player every frame, so
    the override has to be consumed there or a keypress would be undone on the
    next frame.

    NEGATIVE CONTROL: the first version of this only asserted the NAME appeared
    in the body, and it stayed green through `if (false && has_floor_override())`
    -- the branch existed and did nothing, which is the same as not existing. It
    now requires the bare condition and rejects the two shapes that make it dead
    (short-circuit, negation).
    """
    clean = _strip_comments(MINIMAP.read_text(encoding="utf-8"))
    start = clean.index("inline void update_active_layers(")
    end = clean.find("\n    inline ", start)
    body = clean[start : end if end != -1 else len(clean)]

    # Bare, standing on its own: this is the live branch.
    assert re.search(r"^\s*if \(has_floor_override\(\)\)\s*$", body, re.M), (
        "update_active_layers does not test has_floor_override() as a live "
        "condition"
    )
    for dead_shape in ("&& has_floor_override()", "!has_floor_override()", "false && has_floor_override"):
        assert dead_shape not in body, (
            f"the override branch is dead: {dead_shape!r} appears in "
            f"update_active_layers, so a manual floor pick would be discarded"
        )
    assert "manual_floor_index()" in body
    # ...and the derived answer is still the fallback, not deleted.
    assert "pick_overlay_layer_index" in body, (
        "the player-derived floor was removed instead of being demoted to the "
        "fallback when there is no override"
    )


def test_a_location_change_clears_the_floor_override():
    """A stored override is an index into ONE map's overlay_layers. Carried across
    maps it either names an unrelated layer or lands out of range."""
    clean = _strip_comments(MINIMAP.read_text(encoding="utf-8"))
    body = clean[clean.index("inline void notify_location_changed(") :]
    body = body[: body.index("\n    inline ")]
    assert "clear_floor_override()" in body


# ---------------------------------------------------------------------------
# The shared renderer: the big map must not grow a second one.
# ---------------------------------------------------------------------------


def test_the_big_map_draws_its_markers_through_esp_module():
    """One renderer, two views. A second implementation in MapModule would be a
    second set of colours, glyph sizes and label anchors that could drift from
    the radar's without anything noticing."""
    esp_h = _strip_comments(ESP_H.read_text(encoding="utf-8"))
    assert "struct big_map_marker_context" in esp_h
    assert "void draw_big_map_markers(const big_map_marker_context" in esp_h

    esp_cpp = _strip_comments(ESP_CPP.read_text(encoding="utf-8"))
    assert "void EspModule::draw_big_map_markers(" in esp_cpp

    map_cpp = _strip_comments(MAP_CPP.read_text(encoding="utf-8"))
    assert "esp_->draw_big_map_markers(" in map_cpp
    # And MapModule draws no marker of its own.
    for helper in ("draw_minimap_symbol_marker", "draw_radar_marker_label", "quest_poi_color"):
        assert helper not in map_cpp, (
            f"MapModule calls {helper} directly -- that is the duplicated "
            f"renderer this test exists to stop"
        )


def test_the_constructor_pointer_is_not_a_global():
    """Constructor-injected, like AiLimitModule(world_module, player_module).
    A global would be reachable before EspModule's own constructor ran."""
    assert "class EspModule;" in MAP_H.read_text(encoding="utf-8")
    mgr = _strip_comments(MGR_H.read_text(encoding="utf-8"))
    assert "new MapModule(esp_module)" in mgr
    # Declared after esp_module, or the pointer is handed over before it exists.
    assert mgr.index("EspModule* esp_module") < mgr.index("new MapModule(esp_module)")


def test_the_picker_is_rebuilt_when_the_map_set_changes():
    """The picker stores INDICES, so a stale list is not an error -- it is a
    different map with the same index and nothing to complain about.

    scan_configs() and reload_map_configs_from_disk() each publish a NEW
    config_set shared_ptr, so pointer identity is the signal. A one-shot
    `location_options_built_` flag alone would survive a reload and quietly
    repoint the pick, which is the desync this project keeps paying for.
    """
    cpp = _strip_comments(MAP_CPP.read_text(encoding="utf-8"))
    start = cpp.index("void MapModule::refresh_location_options()")
    end = cpp.index("std::string MapModule::location_for_index(")
    body = cpp[start:end]

    assert "options_built_from_" in body, (
        "refresh_location_options does not remember which config set it built "
        "from, so it cannot tell a reload from a repeat"
    )
    guard = "if (location_options_built_ && options_built_from_ == configs)"
    assert guard in body, (
        "the rebuild guard does not compare the config set -- a reload would "
        "leave the stored index meaning a different map"
    )
    assert "options_built_from_ = configs;" in body, "the set is compared but never recorded"


def test_the_picker_is_disabled_in_a_raid_rather_than_ignored():
    """A control that silently does nothing reads as a bug. It is disabled, and
    there is a note row saying why."""
    cpp = _strip_comments(MAP_CPP.read_text(encoding="utf-8"))
    assert re.search(r"big_map_location->set_disabled\(!on \|\| in_raid\)", cpp), (
        "the picker is not disabled in a raid; it would accept a pick and ignore it"
    )
    # The key is a STRING LITERAL here, so this check runs against the
    # comment-stripped-but-literals-intact text. Matching it in the fully blanked
    # text can never succeed and would have "passed" a deleted note.
    assert 'i18n::tr("big_map_loc_raid_locked")' in _strip_comments_only(
        MAP_CPP.read_text(encoding="utf-8")
    ), "the note explaining the lock is gone"
    header = MAP_H.read_text(encoding="utf-8")
    assert "InfoDrawValue* big_map_loc_note;" in header


# ---------------------------------------------------------------------------
# i18n
# ---------------------------------------------------------------------------


def test_every_big_map_key_exists_in_every_locale():
    files = sorted(p.stem for p in LANG.glob("*.json"))
    assert files == sorted(LOCALES), (
        f"the locale set moved: on disk {files}, in the test {sorted(LOCALES)}. "
        f"Update BOTH -- the point is that no locale is quietly skipped."
    )
    for locale in LOCALES:
        data = json.loads((LANG / f"{locale}.json").read_text(encoding="utf-8"))
        for key in BIG_MAP_KEYS:
            assert key in data, f"{locale}.json is missing {key}"
            assert isinstance(data[key], str) and data[key].strip(), f"{locale}.json has an empty {key}"


def test_no_locale_is_left_showing_english_for_the_new_keys():
    """Each non-English locale must be MOSTLY different from English.

    Not "every key differs": "Auto", "Up", "Down" and "Map" are cognates that are
    correct translations in Portuguese, Czech, Slovak, Serbian, Italian and
    Hungarian, and a test that flags them would push the next translator into
    writing "Automático" where "Auto" is the word. The number that is meaningful
    is the bulk: a script that copied the English block wholesale leaves only the
    accidental-cognate keys matching, so requiring a majority to differ catches
    that and does not punish a correct cognate.
    """
    english = json.loads((LANG / "en.json").read_text(encoding="utf-8"))
    minimum_differing = 7  # of len(BIG_MAP_KEYS) == 11
    for locale in LOCALES:
        if locale == "en":
            continue
        data = json.loads((LANG / f"{locale}.json").read_text(encoding="utf-8"))
        identical = [k for k in BIG_MAP_KEYS if data[k] == english[k]]
        assert len(identical) <= len(BIG_MAP_KEYS) - minimum_differing, (
            f"{locale}.json has {len(identical)}/{len(BIG_MAP_KEYS)} of the new "
            f"keys byte-identical to English ({', '.join(identical)}) -- that is "
            f"a copied block, not a translation"
        )