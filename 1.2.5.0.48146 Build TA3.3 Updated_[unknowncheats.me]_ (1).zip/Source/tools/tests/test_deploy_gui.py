"""Tests for the deploy window.

These need a display. Under CI that means running them under Xvfb:

    xvfb-run -a python -m pytest tools/tests/test_deploy_gui.py

They are skipped when there is no display rather than failing, so a headless
checkout without Xvfb still runs the rest of the suite. The behaviours worth
pinning down here are the threading ones: a window that works by hand can still
deadlock or silently cancel, and neither shows up without a test.
"""

from __future__ import annotations

import os
import shutil
import sys
import tempfile
import threading
import traceback
import time
import unittest
from pathlib import Path
from unittest import mock

REPO = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(REPO))

from tools import deploy, deploy_gui  # noqa: E402
from tools.tests.test_deploy import make_build_tree, make_deployed  # noqa: E402

try:
    import tkinter as tk  # noqa: F401
    from tkinter import messagebox

    _CAN_DISPLAY = bool(os.environ.get("DISPLAY") or sys.platform == "win32")
    if _CAN_DISPLAY and sys.platform != "win32":
        tk.Tk().destroy()
except Exception:                                  # noqa: BLE001
    _CAN_DISPLAY = False


# One Tk interpreter for the whole module, with a Toplevel per test.
#
# A Tk() instance owns the interpreter, and destroying one deletes every pending
# after() command with it -- so a per-test Tk() root silently killed the previous
# test's drain loop and dropped whatever was still queued. That showed up as a
# missing traceback in one test and a 24 s stall in another, intermittently. A
# Toplevel on a shared root destroys without touching the interpreter, which is
# why the window takes its root as an argument.
_SHARED_ROOT = None


def _shared_root():
    global _SHARED_ROOT
    if _SHARED_ROOT is None:
        _SHARED_ROOT = tk.Tk()
        _SHARED_ROOT.withdraw()
    return _SHARED_ROOT


def tearDownModule() -> None:
    global _SHARED_ROOT
    if _SHARED_ROOT is not None:
        try:
            _SHARED_ROOT.destroy()
        except tk.TclError:
            pass
        _SHARED_ROOT = None


def _stacks_of_other_threads(limit: int = 6) -> list:
    """Stack of every non-main thread, for a hang diagnosis.

    Worth the noise: "it hung" is not a diagnosis, and the deadlock this was
    written for was only identifiable from the stack (a worker wedged inside
    traceback.format_exc, which turned out to be a garbage collection
    finalising a tkinter variable on the wrong thread).
    """
    main = threading.main_thread().ident
    out = []
    for ident, frame in sys._current_frames().items():
        if ident == main:
            continue
        stack = traceback.format_stack(frame)
        out.append(
            f"--- thread {ident} ---\n" + "".join(stack[-limit:])
        )
    return out


def _solution_with_build(root: Path) -> Path:
    """A solution root containing a real out\\prod\\with_aimbot tree."""
    solution = root / "solution"
    final = solution / "out" / "prod" / "with_aimbot"
    final.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(make_build_tree(root / "staging")), str(final))
    return solution


@unittest.skipUnless(_CAN_DISPLAY, "no display available")
class GuiTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)

        self.solution = _solution_with_build(self.root)
        self.target = make_deployed(self.root / "game")
        self.questions: list[str] = []

        patcher = mock.patch.object(deploy, "SOLUTION_DIR", self.solution)
        patcher.start()
        self.addCleanup(patcher.stop)

        self.window = deploy_gui.DeployWindow(root=tk.Toplevel(_shared_root()))
        self.addCleanup(self._on_close)
        self.window.target.set(str(self.target))

    def _on_close(self) -> None:
        try:
            self.window._on_close()
        except Exception:                          # noqa: BLE001
            pass

    # -- helpers -----------------------------------------------------------

    def _answer(self, reply: bool):
        def ask(*args, **kwargs):
            self.questions.append(args[1] if len(args) > 1 else "")
            return reply
        return ask

    def _pump(self, seconds: float = 0.3) -> None:
        deadline = time.time() + seconds
        while time.time() < deadline:
            self.window.root.update()
            time.sleep(0.01)

    def _wait_idle(self, timeout: float = 30.0) -> None:
        """Wait for the worker to finish, pumping the queue as we go.

        The window already drains its queue from a 100 ms after() tick, but
        relying on that timer under load proved flaky: the tick could be starved
        long enough for the test to time out with the log half-written. Calling
        _drain() directly as well makes the wait deterministic. It reschedules
        one more tick, which is harmless here.
        """
        deadline = time.time() + timeout
        while self.window.busy and time.time() < deadline:
            self.window.root.update()
            self.window._drain()
            time.sleep(0.005)
        self.window._drain()
        self._pump(0.2)
        # Assert rather than return quietly, and say what was still running: a
        # timeout here means a worker thread never finished, and "it hung" is
        # not a diagnosis.
        self.assertFalse(
            self.window.busy,
            "worker never finished; "
            f"threads={[t.name for t in threading.enumerate()]}, "
            f"queue={self.window._lines.qsize()}, "
            f"closed={self.window._closed}\n"
            + "\n".join(_stacks_of_other_threads()),
        )

    def _run(self, action, reply: bool = True, timeout: float = 30.0) -> None:
        with mock.patch.object(messagebox, "askyesno", side_effect=self._answer(reply)):
            action()
            self._wait_idle(timeout)

    def _log(self) -> str:
        return self.window.log.get("1.0", "end")

    # -- tests -------------------------------------------------------------

    def test_window_builds_and_finds_the_target(self) -> None:
        self.assertEqual(self.window.root.title(), deploy_gui.APP_TITLE)
        # Auto-detect cannot succeed here (no BsgLauncher on this host), but it
        # must not raise or leave the field in a broken state.
        self.assertIsInstance(self.window.target.get(), str)

    def test_install_copies_everything_after_confirming(self) -> None:
        self._run(self.window._do_install)
        self.assertTrue(self.questions, "no confirmation was asked for")
        for name in deploy.DEPLOY_DLLS:
            self.assertTrue((self.target / name).is_file(), name)
        self.assertIn("Copied", self._log())

    def test_declining_install_changes_nothing(self) -> None:
        (self.target / "TarkovAddons.dll").write_text("STALE")
        self._run(self.window._do_install, reply=False)
        self.assertTrue(self.questions)
        self.assertEqual((self.target / "TarkovAddons.dll").read_text(), "STALE")
        self.assertIn("cancelled", self._log())

    def test_install_preserves_user_data(self) -> None:
        self._run(self.window._do_install)
        self.assertEqual(
            (self.target / "ta" / "configs" / "tarkovaddons.cfg").read_text(), "MINE"
        )
        self.assertTrue((self.target / "BsgLauncher.exe").is_file())

    def test_uninstall_removes_ours_and_keeps_the_rest(self) -> None:
        self._run(self.window._do_uninstall)
        self.assertFalse((self.target / "TarkovAddons.dll").exists())
        self.assertTrue((self.target / "ta" / "configs" / "tarkovaddons.cfg").is_file())
        self.assertTrue((self.target / "BsgLauncher.exe").is_file())

    def test_declining_uninstall_removes_nothing(self) -> None:
        self._run(self.window._do_uninstall, reply=False)
        self.assertTrue(self.questions)
        self.assertTrue((self.target / "TarkovAddons.dll").is_file())

    def test_purge_question_says_it_cannot_be_undone(self) -> None:
        self.window.purge.set(True)
        self._run(self.window._do_uninstall, reply=False)
        self.assertTrue(self.questions)
        self.assertIn("cannot be undone", self.questions[0])

    def test_plain_uninstall_question_offers_purge(self) -> None:
        self.window.purge.set(False)
        self._run(self.window._do_uninstall, reply=False)
        self.assertNotIn("cannot be undone", self.questions[0])

    def test_buttons_are_disabled_while_working(self) -> None:
        # A second deploy started mid-flight would interleave two writers over
        # one folder, so every button is locked out for the duration. Sampled
        # from the UI thread while the worker is running.
        seen: list[str] = []
        with mock.patch.object(messagebox, "askyesno", return_value=False):
            self.window._do_install()
            deadline = time.time() + 15
            while self.window.busy and time.time() < deadline:
                seen.append(str(self.window._buttons[0]["state"]))
                self.window.root.update()
                time.sleep(0.01)
            self._wait_idle()
        self.assertTrue(seen, "the run finished before a sample could be taken")
        self.assertEqual(set(seen), {"disabled"}, set(seen))
        # Re-enabled once it is done.
        self.assertTrue(
            all(str(b["state"]) == "normal" for b in self.window._buttons),
            [str(b["state"]) for b in self.window._buttons],
        )

    def test_no_worker_thread_touches_a_widget(self) -> None:
        """The invariant the whole queue design exists to keep.

        Tk is not thread-safe. A worker that calls root.after() raises
        "main thread is not in main loop" or deadlocks depending on timing, so
        every widget call has to happen on the thread that owns them.
        """
        main_thread = threading.current_thread()
        offenders: list[str] = []
        real_after = self.window.root.after

        def guard(*args, **kwargs):
            if threading.current_thread() is not main_thread:
                offenders.append(f"after{args[:1]}")
            return real_after(*args, **kwargs)

        with mock.patch.object(self.window.root, "after", side_effect=guard):
            self._run(self.window._do_install)
        self.assertEqual(offenders, [], f"worker touched Tk: {offenders}")

    def test_error_is_shown_in_the_log_rather_than_raised(self) -> None:
        # A window started from pythonw.exe has no console, so an escaping
        # exception would leave the user with no explanation at all.
        self.window.target.set(str(self.root / "does-not-exist"))
        self._run(self.window._do_install, reply=False)
        self.assertIn("does not exist", self._log())

    def test_unexpected_error_is_reported_in_the_log(self) -> None:
        with mock.patch.object(
            deploy, "cmd_install", side_effect=RuntimeError("boom")
        ):
            self.window._do_install()
            self._wait_idle()
        self.assertIn("unexpected error", self._log())
        # The whole traceback, not just the header. This is the line a user has
        # to paste into a bug report, and it used to be lost whenever the drain
        # loop was interrupted part-way through a run.
        self.assertIn("boom", self._log())
        self.assertIn("RuntimeError", self._log())

    def test_drain_stops_cleanly_after_the_window_is_closed(self) -> None:
        # A pending after() fires against a destroyed root and raises TclError.
        # When that happened it killed the drain loop part-way, so anything
        # still queued was dropped -- including tracebacks.
        self.window._on_close()
        self.assertTrue(self.window._closed)
        self.window._drain()          # must return rather than raise
        self.window._append("after close")
        self.window._clear_log()
        self.window._set_buttons(enabled=True)

    def test_every_tkinter_variable_is_kept_alive(self) -> None:
        """Pins the fix for the bug that made this suite intermittently hang.

        tkinter.Variable.__del__ calls into Tcl, and Tcl serialises calls behind
        a lock the UI thread holds while running its event loop. A garbage
        collection triggered by an allocation on a worker thread will finalise a
        Variable there, and that call deadlocks against the UI thread. It hangs
        the app with no error, no traceback and nothing to click. It was found
        as a worker wedged inside traceback.format_exc(), whose allocations
        happened to trigger the collection.

        deploy_gui._keep_alive() holds every variable for the life of the
        process, so __del__ never runs. This asserts each variable the window
        creates is one of those held, which is the property that prevents it.

        Deliberately not a timing test: the deadlock needs a variable to already
        be garbage when the collection lands, which a live interpreter prevents,
        so a reproduction here would pass with or without the fix and prove
        nothing.
        """
        for name in ("flavor", "configuration", "rebuild", "purge", "target", "status"):
            with self.subTest(variable=name):
                variable = getattr(self.window, name)
                self.assertIn(
                    variable,
                    deploy_gui._TK_VARIABLES,
                    f"{name} is not held by _keep_alive, so it can be finalised on "
                    "a worker thread and deadlock against the UI thread",
                )

    def test_keeping_a_variable_alive_retains_it(self) -> None:
        # The helper itself, so the invariant above is testing something real.
        import tkinter as tk

        before = len(deploy_gui._TK_VARIABLES)
        variable = deploy_gui._keep_alive(tk.StringVar(value="held"))
        self.assertEqual(len(deploy_gui._TK_VARIABLES), before + 1)
        self.assertIs(deploy_gui._TK_VARIABLES[-1], variable)


class QueueWriterTests(unittest.TestCase):
    def test_lines_are_emitted_whole(self) -> None:
        import queue

        sink: "queue.Queue[object]" = queue.Queue()
        writer = deploy_gui.QueueWriter(sink)
        writer.write("one\ntw")
        self.assertEqual(sink.get_nowait(), "one")
        writer.write("o\n")
        self.assertEqual(sink.get_nowait(), "two")

    def test_partial_line_is_held_until_newline(self) -> None:
        # A build emits progress with carriage returns; emitting on those would
        # fill the pane with fragments.
        import queue

        sink: "queue.Queue[object]" = queue.Queue()
        writer = deploy_gui.QueueWriter(sink)
        writer.write("50%\r")
        with self.assertRaises(queue.Empty):
            sink.get_nowait()
        writer.flush()
        self.assertEqual(sink.get_nowait(), "50%\r")

    def test_reports_itself_as_not_a_terminal(self) -> None:
        # Otherwise deploy.confirm() would call input() on the worker thread.
        import queue

        self.assertFalse(deploy_gui.QueueWriter(queue.Queue()).isatty())


class QuestionTests(unittest.TestCase):
    def test_resolve_releases_the_waiter_exactly_once(self) -> None:
        # The bug this guards: resolving in a finally as well as with the real
        # answer made every confirmation come back as "no", which looks exactly
        # like the feature working, just quietly refusing.
        import queue

        sink: "queue.Queue[object]" = queue.Queue()
        question = deploy_gui.Question("go on?")
        result: list[bool] = []

        worker = threading.Thread(target=lambda: result.append(question.ask(sink)))
        worker.start()
        time.sleep(0.1)
        self.assertTrue(worker.is_alive(), "ask() returned before being answered")

        question.resolve(True)
        worker.join(timeout=5)
        self.assertFalse(worker.is_alive())
        self.assertEqual(result, [True])
        self.assertIs(sink.get_nowait(), question)


if __name__ == "__main__":
    unittest.main()
