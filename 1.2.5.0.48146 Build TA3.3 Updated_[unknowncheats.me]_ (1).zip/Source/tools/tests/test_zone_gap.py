"""Tests for tools/zone_gap.py.

The tool's whole purpose is to be believed, so the properties tested here are the
ones that make it believable rather than its arithmetic:

  * it FAILS CLOSED -- exit 2 when it looked at nothing, never 0;
  * its comment stripper removes a commented-out zone AND a doc example, because
    a checker that can match its own documentation is not a checker
    (test_profile_path.py exists for exactly this, and zone_gap.py reached it by a
    different route);
  * its function-definition matcher does not count call sites;
  * a known-unzoned hot body is actually reported, so it is not silently clean.

Every case here is itself negative-controlled -- see NEGATIVE CONTROL at the
bottom, which must exit 2.
"""
from __future__ import annotations

import importlib.util
import os
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
TOOL = REPO / "tools" / "zone_gap.py"

# The number of unzoned per-frame bodies over the default --min-lines 10, measured
# on the real tree. It is a RECORD, not a ceiling -- see
# FailClosedTests.test_gap_count_matches_the_recorded_number for what to do when it
# moves.
EXPECTED_GAPS = 4


def _load():
    spec = importlib.util.spec_from_file_location("zone_gap", TOOL)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


zg = _load()


class StripCommentsTests(unittest.TestCase):
    def test_line_comment_is_removed(self):
        out = zg.strip_comments('TA_ZONE_N("a");\n// TA_ZONE_N("b");\n')
        self.assertIn('TA_ZONE_N("a")', out)
        self.assertNotIn('"b"', out)

    def test_block_comment_is_removed(self):
        out = zg.strip_comments('/* TA_ZONE_N("x") */\nTA_ZONE_N("y");\n')
        self.assertNotIn('"x"', out)
        self.assertIn('"y"', out)

    def test_string_literal_is_preserved(self):
        # A zone name IS a string literal; eating it would empty the count.
        out = zg.strip_comments('TA_ZONE_N("keep::me");\n')
        self.assertIn('"keep::me"', out)

    def test_double_slash_inside_a_string_does_not_truncate(self):
        out = zg.strip_comments('TA_ZONE_N("a//b");\nTA_ZONE_N("after");\n')
        self.assertIn('"after"', out, "a // inside a string ate the rest of the file")

    def test_line_numbers_are_preserved(self):
        src = 'a\n// b\nc\nTA_ZONE_N("z");\n'
        self.assertEqual(len(zg.strip_comments(src).splitlines()), len(src.splitlines()))

    def test_real_tree_comment_does_not_count_as_a_zone(self):
        """The defect this tool was built to avoid, on the real tree.

        util/tracy_bridge.h:29 carries its own usage example inside a // comment,
        and module/impl/QuestModule.cpp:1142 carries a zone that was deliberately
        commented out. A scanner that reads either as live is wrong by two.
        """
        raw = (REPO / "TarkovAddons/util/tracy_bridge.h").read_text(encoding="utf-8")
        self.assertIn('TA_ZONE_N("item_db::build")', raw,
                      "the doc-comment fixture moved; update this test")
        self.assertNotIn('"item_db::build"', zg.strip_comments(raw))

        quest = (REPO / "TarkovAddons/module/impl/QuestModule.cpp").read_text(
            encoding="utf-8")
        self.assertIn('//TA_ZONE_N("quest_completer::list_walk")', quest,
                      "the disabled-zone fixture moved; update this test")
        self.assertNotIn('quest_completer::list_walk', zg.strip_comments(quest))


class DefinitionMatcherTests(unittest.TestCase):
    """The matcher must find DEFINITIONS and not call sites.

    The first version of this tool had no `Class::` requirement and reported a
    194-line 'function' plus thirty-odd phantoms, every one of them a call.
    """

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.p = Path(self.tmp.name) / "m.cpp"
        self.p.write_text(
            "void Widget::gameworld_update() {\n"      # 1-3  definition
            "  int a = 1;\n"
            "}\n"
            "void Widget::draw_overlay() { }\n"        # 4    short definition
            "void caller() {\n"                        # 5-7  not a hot method
            "  other->gameworld_update();\n"           #      a CALL SITE
            "}\n",
            encoding="utf-8")
        self.addCleanup(self.tmp.cleanup)

    def test_finds_the_definition_with_its_true_length(self):
        found = zg.hot_definitions(str(self.p))
        names = {m for m, _, _ in found}
        self.assertIn("gameworld_update", names)
        sizes = {m: n for m, _, n in found}
        self.assertEqual(sizes["gameworld_update"], 3)

    def test_ignores_the_call_site(self):
        found = zg.hot_definitions(str(self.p))
        self.assertEqual(len(found), 2, "the call site inside caller() was counted")

    def test_missing_file_is_empty_not_an_error(self):
        self.assertEqual(zg.hot_definitions("/nonexistent/nope.cpp"), [])


class RegistrationTests(unittest.TestCase):
    def test_reads_the_registration_list(self):
        mods = zg.registered_modules()
        self.assertIn("EspModule", mods)
        self.assertIn("AimbotModule", mods)
        # BotControlModule is registered but is not a Module subclass; it must
        # still appear, because registration is the ground truth.
        self.assertIn("BotControlModule", mods)

    def test_returns_empty_when_the_header_is_absent(self):
        original = zg.MANAGER_H
        zg.MANAGER_H = "/nonexistent/ModuleManager.h"
        self.addCleanup(setattr, zg, "MANAGER_H", original)
        self.assertEqual(zg.registered_modules(), [])


class FailClosedTests(unittest.TestCase):
    """Exit 2 means it checked nothing. It must never be reported as 0."""

    def _run(self, *args, env=None):
        e = dict(os.environ)
        if env:
            e.update(env)
        return subprocess.run([sys.executable, str(TOOL), *args],
                              capture_output=True, text=True, cwd=str(REPO), env=e)

    def test_real_tree_finds_the_known_unzoned_body(self):
        """The tool must not be silently clean on the real tree.

        It was originally written to assert on `WorldModule` specifically, because
        that was the largest unzoned body when this file was written. Zoning it on
        2026-10-12 then failed the test -- which is the right failure and the wrong
        shape: a test that breaks every time somebody fixes the thing it points at
        gets deleted rather than updated, and then it guards nothing.

        So the mechanism is asserted here (exit 1, at least one row, every row
        carrying a real file:line and a positive length), and the module count lives
        in the recorded number below, which is meant to be updated in the same change
        that closes a gap. Same contract as the harness case counts in
        test_doc_counts.py.
        """
        r = self._run()
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        rows = re.findall(r"^\s+(\d+) lines\s+(\S+)\s+(\S+)\s+(\S+):(\d+)$",
                          r.stdout, re.MULTILINE)
        self.assertTrue(rows, f"no gap rows parsed from:\n{r.stdout}")
        for length, module, method, path, line in rows:
            self.assertGreater(int(length), 0)
            self.assertTrue((REPO / path).exists(), f"{path} does not exist")
            self.assertTrue(1 <= int(line) <= 20000)

    def test_gap_count_matches_the_recorded_number(self):
        """A NUMBER, deliberately, so closing a gap forces a deliberate update.

        Measured 2026-10-12 after the WorldModule / MarkedRooms / WeaponBuilder
        zoning: 2 bodies over --min-lines 10, both in WeaponModule, which
        tools/analysis_tree.py cannot parse yet (find_hook takes function pointers
        through void*). Lower this when you close a gap, raise it when you add one,
        and say why in the commit -- the same "recount, never quote" rule as the rest
        of this repository.

        Raised 2 -> 4 on 2026-10-14: not a regression, and not a closure. The
        recorded 2 were the WeaponModule pair (`gameworld_update` 66,
        `application_update` 10), which tools/analysis_tree.py cannot parse
        (find_hook takes function pointers through void*); the 2 new ones are
        bigmap step 6's (`MapModule::draw_overlay` 81, `MapModule::gameworld_update`
        13, both from `8d7d62929`). MapModule is the easier pair to zone, and the
        largest unzoned body in the tree.
        """
        r = self._run()
        m = re.search(r"(\d+) unzoned body/bodies over 10 lines", r.stdout)
        self.assertIsNotNone(m, r.stdout)
        self.assertEqual(
            int(m.group(1)), EXPECTED_GAPS,
            f"the tree now has {m.group(1)} unzoned bodies and this test records "
            f"{EXPECTED_GAPS}. Closed one? Lower it. Added one? Raise it.")

    def test_no_manager_header_is_exit_2_not_0(self):
        stub = tempfile.TemporaryDirectory()
        self.addCleanup(stub.cleanup)
        # Point the tool at an empty tree by monkeypatching via a copy.
        import shutil
        copy = Path(stub.name) / "zone_gap.py"
        shutil.copy(TOOL, copy)
        r = subprocess.run([sys.executable, str(copy)],
                           capture_output=True, text=True, cwd=stub.name)
        # REPO resolves to the temp dir's parent, so nothing is found -> must be 2.
        self.assertEqual(r.returncode, 2,
                         f"a scan that looked at nothing must exit 2, not "
                         f"{r.returncode}: {r.stdout}{r.stderr}")

    def test_bad_min_lines_is_rejected(self):
        r = self._run("--min-lines", "0")
        self.assertEqual(r.returncode, 2)

    def test_list_zones_runs_and_reports_a_dynamic_site(self):
        r = self._run("--list-zones")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("m->name.data()", r.stdout,
                      "the one dynamically-named site is invisible without the "
                      "negative lookahead; if it vanished, the scan is broken")

    def test_list_zones_does_not_count_a_commented_out_zone(self):
        """INTEGRATION, and the reason the isolated stripper cases were not enough.

        StripCommentsTests proves strip_comments() works. It does not prove
        list_zones() CALLS it -- and when that wiring was removed as a mutation,
        every test still passed while the tool counted two dead zones again.
        A checker that can pass while the defect it exists for is reintroduced is
        not a checker.

        Asserting on --names output, not on the count lines: an earlier version of
        this test asserted the names were ABSENT from stdout, which passed trivially
        because the tool prints counts and no names at all. A negative assertion
        against output that never contains the thing is not a test.
        """
        r = self._run("--list-zones", "--names")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("live zone names:", r.stdout, "the name list is missing")
        body = r.stdout.split("live zone names:")[-1]
        # A zone deliberately commented out at QuestModule.cpp:1142.
        self.assertNotIn("quest_completer::list_walk", body)
        # A usage example inside a // comment at util/tracy_bridge.h:29.
        self.assertNotIn("item_db::build", body)

    def test_list_zones_reports_real_zones(self):
        """The other half of the pair: stripping must not eat live zones."""
        r = self._run("--list-zones", "--names")
        self.assertIn("live zone names:", r.stdout, "the name list is missing")
        body = r.stdout.split("live zone names:")[-1]
        self.assertIn("aimbot::fireport_resolve", body)
        self.assertIn("frame::ModuleManager::apply", body)
        self.assertIn("skeleton_vis::is_target_visible", body)


class InventoryAgreementTests(unittest.TestCase):
    def test_tool_and_rg_disagree_only_on_the_comment(self):
        """Cross-check the tool against an independent textual scan.

        They are SUPPOSED to differ by exactly the zones that live in comments --
        that difference is the tool finding something rg cannot.
        """
        if not shutil_which("rg"):
            self.skipTest("ripgrep not available")
        pattern = r'TA_ZONE_N\("([^"]+)"\)'
        raw = subprocess.run(
            ["rg", "--no-ignore", "-oP", pattern, "TarkovAddons",
             "-g", "!x64/**", "-r", "$1"],
            capture_output=True, text=True, cwd=str(REPO))
        rg_names = {ln.split(":", 1)[1] for ln in raw.stdout.splitlines() if ":" in ln}
        tool_names = set()
        import os as _os
        for dp, dns, fns in _os.walk(REPO / "TarkovAddons"):
            dns[:] = [d for d in dns if d not in ("x64", "out", "GameDump", "external")]
            for fn in fns:
                if fn.endswith((".h", ".cpp")):
                    p = Path(dp) / fn
                    rel = p.relative_to(REPO / "TarkovAddons").as_posix()
                    if rel.endswith("util/tracy_bridge.h"):
                        continue
                    text = zg.strip_comments(p.read_text(encoding="utf-8",
                                                         errors="replace"))
                    tool_names.update(re.findall(pattern, text))
        only_rg = rg_names - tool_names
        self.assertTrue(
            only_rg <= {"item_db::build", "quest_completer::list_walk"},
            f"rg found zones the tool does not, beyond the two known comment "
            f"artefacts: {sorted(only_rg)}")


def shutil_which(name):
    from shutil import which
    return which(name)


class NegativeControlTests(unittest.TestCase):
    """A test file that cannot fail is worse than no test.

    Run against a tree with no zones at all, --list-zones must exit 2 and must NOT
    print an inventory.
    """

    def test_empty_tree_exits_2_and_prints_no_inventory(self):
        stub = tempfile.TemporaryDirectory()
        self.addCleanup(stub.cleanup)
        import shutil
        tree = Path(stub.name) / "repo"
        (tree / "tools").mkdir(parents=True)
        (tree / "TarkovAddons").mkdir(parents=True)
        copy = tree / "tools" / "zone_gap.py"
        shutil.copy(TOOL, copy)
        r = subprocess.run([sys.executable, str(copy), "--list-zones"],
                           capture_output=True, text=True, cwd=str(tree))
        self.assertEqual(r.returncode, 2,
                         f"expected 2 (checked nothing), got {r.returncode}")
        self.assertNotIn("distinct literal zone names", r.stdout,
                         "it reported an inventory over an empty tree")


if __name__ == "__main__":
    unittest.main()