"""The loader's search root must be the directory the build writes to.

This is the regression test for a defect that shipped and was invisible: the
runtime looked for the per-build IL2CPP manifest under
`<dll dir>/compatibility/profiles` while the MSBuild `Content` item and
`deploy.py` both put it under `<dll dir>/ta/compatibility/profiles`. Every
launch therefore returned `LoadResult::NotFound`, which is the *designed*
legacy fallback, so no error was logged and nothing looked wrong. The profile
had never once been loaded in any build. Recorded as F15 in
`compatibility/PROFILE_GUIDE.md` and section 5.8 of `AGENTS_TODO.md`.

Why a text test and not a runtime one
--------------------------------------
`compatibility_profile.cpp` cannot be executed here: it includes `pch.h`
(Windows-only) and `external/safetyhook`, and `tools/harness/README.md` records
why a partial stub for that include graph would be the green stub worth
avoiding. What *is* testable, and is the actual class of bug, is that the three
literals that have to agree still agree:

  1. `TarkovAddons.vcxproj`   -- the `<Link>` the build copies to
  2. `tools/deploy.py`        -- the destination deploy writes to
  3. `compatibility_profile.cpp` -- the root the runtime reads

Two of the three are text and were silently edited apart. A test that reads all
three turns "somebody changed a path" from a defect found by reading a log
several sessions later into a red test at the moment of the edit.

The negative control is the point
---------------------------------
Reverting `compatibility_profile.cpp` to the `<dll dir>/compatibility` spelling
makes `test_loader_uses_the_data_directory_accessor` fail. That test is the one
that matters; the others are agreement checks that would notice a *future*
divergence. See the module docstring of `tools/verify/README.md` for why a
checker that compares nothing must exit non-zero rather than pass.
"""

import re
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]

VCXPROJ = REPO / "TarkovAddons" / "TarkovAddons.vcxproj"
DEPLOY = REPO / "tools" / "deploy.py"
PROFILE_CPP = REPO / "TarkovAddons" / "il2cpp" / "compatibility_profile.cpp"
LAUNCHER_CPP = REPO / "TarkovLauncherBypass" / "util" / "compat_profile.cpp"
MANIFEST_GUIDE = REPO / "compatibility" / "PROFILE_GUIDE.md"

# The manifest lives at <data dir>/compatibility/profiles. The data dir is ta/
# when it exists and the DLL directory otherwise, so the segment that matters
# for agreement is the part AFTER the root: compatibility/profiles.
PROFILE_SUBPATH = "compatibility/profiles"


def _vcxproj_link() -> str:
    """The <Link> the unconditional Content item copies the manifest to."""
    text = VCXPROJ.read_text(encoding="utf-8", errors="replace")
    links = re.findall(
        r"<Content Include=\"[^\"]*compatibility[^\"]*profiles[^\"]*manifest\.json\">\s*"
        r"<Link>([^<]+)</Link>",
        text,
        re.IGNORECASE,
    )
    assert links, (
        f"{VCXPROJ} has no <Content> item for compatibility/profiles/**/manifest.json. "
        "If it was removed, the manifest stops shipping in every configuration -- "
        "the F2 defect in compatibility/PROFILE_GUIDE.md."
    )
    # There is exactly one such item, outside every Condition, on purpose. More
    # than one means two roots and the loader would have to guess which.
    assert len(links) == 1, f"expected one profile Content item, found {len(links)}: {links}"
    return links[0]


def _deploy_profile_destination() -> str:
    """The path deploy.py writes the manifest to, as a posix-ish string."""
    text = DEPLOY.read_text(encoding="utf-8", errors="replace")
    hits = re.findall(r"ta[\\/]compatibility[\\/]profiles", text, re.IGNORECASE)
    assert hits, (
        f"{DEPLOY} no longer mentions ta/compatibility/profiles. If the manifest "
        "stopped being deployed, the runtime will silently take its legacy "
        "fallback -- which is what F15 looked like from the outside."
    )
    return hits[0].replace("\\", "/")


class TestBuildAndDeployAgree:
    def test_vcxproj_writes_under_the_data_directory(self):
        link = _vcxproj_link()
        normalized = link.replace("\\", "/")
        assert normalized.startswith("ta/"), (
            f"the Content item's <Link> is {link!r}, not under ta/. That is not "
            "automatically wrong -- but the runtime must then read the same place, "
            "and the accessor it uses is data_directory_wide(). If you moved this, "
            "move the reader in the same commit."
        )

    def test_deploy_matches_the_vcxproj(self):
        vcx = _vcxproj_link().replace("\\", "/")
        deployed = _deploy_profile_destination()
        assert deployed in vcx, (
            f"deploy.py writes {deployed!r} but the build's <Link> is {vcx!r}. "
            "The deployed layout and the build output must be the same tree, or a "
            "deployment is missing a file the build produced."
        )

    def test_both_put_the_manifest_under_compatibility_profiles(self):
        vcx = _vcxproj_link().replace("\\", "/")
        deployed = _deploy_profile_destination()
        for label, path in (("vcxproj", vcx), ("deploy.py", deployed)):
            assert PROFILE_SUBPATH in path.replace("//", "/"), (
                f"{label} path {path!r} does not contain {PROFILE_SUBPATH!r}. The "
                "layout is <data dir>/compatibility/profiles/<build>/manifest.json; "
                "if the subdirectory moved, load_for_identity's root must move too."
            )


class TestRuntimeReadsWhatTheBuildWrites:
    def test_loader_uses_the_data_directory_accessor(self):
        """The defect itself. A hardcoded <dll dir>/compatibility cannot work.

        This is the negative-controlled test: reverting the one-line fix makes it
        fail, which is what makes the three agreement tests above meaningful
        rather than decorative.
        """
        text = PROFILE_CPP.read_text(encoding="utf-8", errors="replace")
        body = _load_for_module_body(text)

        assert "data_directory_wide" in body, (
            "load_for_module no longer uses module_paths::data_directory_wide(). "
            "It must, because that is the accessor which resolves to <dll dir>/ta/ "
            "when ta/ exists -- which is where the build and deploy both put the "
            "manifest. Hardcoding a root is what made the profile dead on every "
            "launch (AGENTS_TODO.md 5.8)."
        )

    def test_loader_does_not_hardcode_the_deploy_root(self):
        text = PROFILE_CPP.read_text(encoding="utf-8", errors="replace")
        body = _load_for_module_body(text)
        # A literal L"compatibility" appended straight to dll_directory_wide() is
        # the shape that broke. data_directory_wide() / L"compatibility" is fine --
        # the / is the whole difference -- so look for the concatenation.
        assert not re.search(r'dll_directory_wide\(\)\s*/\s*L"compatibility"', body), (
            "load_for_module builds its root from dll_directory_wide() / "
            '"compatibility". That bypasses ta/, where the manifest is deployed.'
        )

    def test_launcher_and_game_dll_agree(self):
        """Two implementations, one root. They must not drift again.

        `AGENTS_TODO.md` 4.1 records that the two compat_profile implementations
        must not be MERGED -- they diverge deliberately and the launcher must
        never block the launch. They can still agree on where to look, and did
        not until 2026-10-01: the launcher used data_directory_wide() and was
        correct, the game DLL hardcoded the DLL directory and was not.
        """
        launcher = _strip_comments(
            LAUNCHER_CPP.read_text(encoding="utf-8", errors="replace")
        )
        assert "data_directory_wide" in launcher, (
            f"{LAUNCHER_CPP} stopped using data_directory_wide() for the manifest "
            "root. If this is deliberate, say so in a comment; otherwise the two "
            "processes are looking in different directories again."
        )

        game = PROFILE_CPP.read_text(encoding="utf-8", errors="replace")
        assert "data_directory_wide" in _load_for_module_body(game)


@pytest.mark.parametrize(
    "doc",
    [MANIFEST_GUIDE, REPO / "tools" / "README.md", REPO / "WORKFLOW.md"],
    ids=lambda p: p.name,
)
def test_docs_name_the_deployed_path(doc):
    text = doc.read_text(encoding="utf-8", errors="replace")
    assert "ta" in text and PROFILE_SUBPATH in text, (
        f"{doc.name} discusses the manifest layout but never names "
        f"ta/{PROFILE_SUBPATH}. A guide that documents <dll dir>/compatibility "
        "is exactly how F15 stayed undocumented: the guide was correct when "
        "written and the build moved underneath it."
    )


class TestDocumentationDoesNotLieAboutTheLayout:
    def test_guide_records_the_defect_and_its_fix(self):
        text = MANIFEST_GUIDE.read_text(encoding="utf-8", errors="replace")
        assert "F15" in text, (
            "compatibility/PROFILE_GUIDE.md no longer records F15 (the loader/build "
            "path mismatch). An audit record that loses its highest-severity entry "
            "is worse than one that never had it."
        )


def _strip_comments(text: str) -> str:
    """Remove // and /* */ comments, so an assertion cannot pass on prose.

    This is not a theoretical concern here -- it is exactly what happened on the
    first run of this file's negative control. The fix carries a comment that
    *names* `data_directory_wide()`, and a test that grepped the function body
    for that identifier passed on the comment while the code was reverted to the
    broken form. The test was vacuous and the control reported 10/10.

    `tools/verify/README.md` lists three tools that reported success because they
    silently did nothing. This would have been a fourth, and the only way to know
    was to run the control and notice that a deliberate break did not fail.
    """
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.DOTALL)
    text = re.sub(r"//[^\n]*", " ", text)
    return text


def _load_for_module_body(text: str) -> str:
    """The CODE of load_for_module: comments stripped, header excluded.

    Two things have to be excluded for a match to mean anything.

    The header repeats the literal in its own comment, and a test that read both
    files would pass on the header. And within the .cpp, the explanatory comment
    names the accessor by name -- which is what made the first negative control
    vacuous. `tools/verify/README.md` lists 'matching an include by bare filename
    removes the wrong line' as a known failure mode in tooling like this; this is
    the same class of mistake, one level in.
    """
    start = text.find("LoadResult Profile::load_for_module")
    assert start != -1, "load_for_module definition not found in compatibility_profile.cpp"
    # Walk to the next top-level definition rather than counting braces, which a
    # brace inside a string or a comment would break.
    end = text.find("LoadResult Profile::load_for_identity", start)
    assert end != -1, "load_for_identity definition not found after load_for_module"
    return _strip_comments(text[start:end])
