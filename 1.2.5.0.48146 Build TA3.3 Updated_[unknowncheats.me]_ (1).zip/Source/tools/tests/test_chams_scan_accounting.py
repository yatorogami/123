"""The chams scan's `accounted` sum must cover every scan-loop branch, exactly once.

This test exists to stop a well-meant bug.

What the documentation says
---------------------------
`AGENTS_TODO.md` and `tools/handoff_optics_memo.md` both carry an open item --
repeated across at least three documents and two sessions -- saying:

    "One residual, for whoever picks it up: `st.unpainted` is still missing from
     that sum, so a tick with unpainted items reports them as `unaccounted`."
    -- AGENTS_TODO.md, "answered since this list was written"
    "ChamsModule::report_item_chams_scan() sums corpse + already + no_game_object
     + no_transform + out_of_range + applied; `st.null_obj` was added at :153; a
     tick that examines items it cannot paint **reports them as `unaccounted` --
     the same class of reporting bug, one term short.**"

It reads as a known one-term omission, and it names the exact fix. It is wrong.

Why it is wrong
---------------
`st.unpainted` is not a scan-loop branch. It is a *sub-counter inside* the
`out_of_range` branch:

    682   if (!in_range) {
    684       ++st.out_of_range;          <- the branch counter
    ...
    711           ++st.unpainted;         <- a detail OF that branch
    713       continue;
         }

`out_of_range` already counts that item. Adding `st.unpainted` to the sum counts
it a second time, so `unaccounted = examined - accounted` goes negative on every
tick that restores anything -- and the field whose entire purpose is to report a
zero would report a negative number, which is a strictly worse failure than the
one the item claims to fix.

The sum has exactly seven terms and the loop has exactly seven `continue`
branches. It reconciles by construction. This test asserts both facts, so the
next person who reads the handoff cannot "fix" it.

The same trap, one branch over
------------------------------
`st.zero_renderer` looks identical and is also correctly excluded: it is the
`else` of the applied branch (`:737 ++st.applied` / `:748 else ++st.zero_renderer`),
so an item counted there is already counted as `applied`. `st.multi_slot` is an
attribute of a successful paint, not a branch. `st.hit_cap` records that the loop
exited early, not that an item fell into a bucket.

Why not just add a `static_assert`-style runtime check in the C++?
----------------------------------------------------------------
Because the invariant is about *which branches exist*, and that changes when
someone adds one. A source-level test is the right instrument here: it fails at
the moment of the edit rather than in a session, and it says which of the two
halves moved.
"""

from __future__ import annotations

import re
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
CHAMS = REPO / "TarkovAddons" / "module" / "impl" / "ChamsModule.cpp"

# The counters that make up `accounted` in report_item_chams_scan(). If the loop
# gains a branch, this is the list that must gain a term -- and this is the test
# that fails when it does not.
EXPECTED_SUM_TERMS = {
    "null_obj",
    "corpse",
    "already",
    "no_game_object",
    "no_transform",
    "out_of_range",
    "applied",
}

# Counters that must NOT appear in the sum, with the reason each is excluded.
# `unpainted` is the one three documents currently ask to add.
FORBIDDEN_IN_SUM = {
    "unpainted": "a sub-counter inside the out_of_range branch (:684 then :711), so "
    "adding it double-counts every restored item and drives `unaccounted` negative",
    "zero_renderer": "the `else` of the applied branch (:737/:748), so those items "
    "are already counted as `applied`",
    "multi_slot": "an attribute of a successful paint, not a branch of the loop",
    "hit_cap": "records that the loop exited early via the per-tick cap, not that "
    "an item fell into a bucket",
    "examined": "the total the sum is compared against; adding it is circular",
    "renderers": "an accumulator over renderers, not items",
    "materials": "an accumulator over material slots, not items",
}

# Where the loop starts and stops. Anchored on content rather than line numbers,
# because the file moves and a line-anchored locator is exactly the kind of
# fragile thing `tools/README.md` warns about.
LOOP_START = "++st.examined"
LOOP_END = "last_scanned_index = loot_count"


def _read() -> str:
    return CHAMS.read_text(encoding="utf-8", errors="replace")


def _scan_loop_lines() -> list[str]:
    lines = _read().splitlines()
    start = next((i for i, l in enumerate(lines) if LOOP_START in l), None)
    assert start is not None, (
        f"{CHAMS.name} no longer contains {LOOP_START!r}; this test is looking at "
        "the wrong loop or the loop was renamed. Fix the locator rather than "
        "deleting the assertion."
    )
    end = next(
        (i for i, l in enumerate(lines) if i > start and LOOP_END in l), None
    )
    assert end is not None, f"{CHAMS.name}: no {LOOP_END!r} after the scan loop"
    return lines[start:end]


def _accounted_terms() -> list[str]:
    """The counter names summed in `report_item_chams_scan`."""
    text = _read()
    m = re.search(
        r"const size_t accounted\s*=\s*(.*?);", text, re.DOTALL
    )
    assert m, f"{CHAMS.name}: no `const size_t accounted = ...` found"
    return re.findall(r"st\.(\w+)", m.group(1))


def _loop_branch_counters() -> dict[str, int]:
    """Which counters the scan loop increments, and how often.

    A branch counter is one incremented on a line whose statement also `continue`s,
    or that opens a block ending in `continue`. Anything else is a sub-counter.
    """
    counts: dict[str, int] = {}
    for line in _scan_loop_lines():
        for name in re.findall(r"\+\+st\.(\w+)", line):
            counts[name] = counts.get(name, 0) + 1
    return counts


class TestAccountedSumIsComplete:
    def test_sum_covers_every_branch(self):
        """The documented invariant, asserted rather than asserted-in-prose."""
        counted = _accounted_terms()
        assert len(counted) == len(set(counted)), f"a term is summed twice: {counted}"
        missing = EXPECTED_SUM_TERMS - set(counted)
        assert not missing, (
            f"the accounted sum is missing {sorted(missing)}. The scan loop's "
            "branches are " + f"{sorted(EXPECTED_SUM_TERMS)}; every one of them "
            "must appear in the sum or `unaccounted` will report a non-zero value "
            "on a healthy tick."
        )

    def test_sum_has_no_extras(self):
        """A term in the sum that is not a branch is the double-count bug."""
        counted = set(_accounted_terms())
        extra = counted - EXPECTED_SUM_TERMS
        assert not extra, (
            f"the accounted sum contains {sorted(extra)}, which is not a "
            "scan-loop branch. See FORBIDDEN_IN_SUM in this file for why "
            "unpainted / zero_renderer must not be summed: they are sub-counters "
            "of branches already counted, so summing them double-counts."
        )

    def test_unpainted_is_a_sub_counter_not_a_branch(self):
        """The specific claim in three documents, checked against the source.

        Asserted directly rather than only via the lists above, so that a future
        edit to EXPECTED_SUM_TERMS cannot quietly make the wrong fix look right.
        """
        lines = _scan_loop_lines()
        out_of_range_line = next(
            (i for i, l in enumerate(lines) if "++st.out_of_range" in l), None
        )
        unpainted_line = next(
            (i for i, l in enumerate(lines) if "++st.unpainted" in l), None
        )
        assert out_of_range_line is not None, "no ++st.out_of_range in the scan loop"
        assert unpainted_line is not None, "no ++st.unpainted in the scan loop"

        assert unpainted_line > out_of_range_line, (
            "st.unpainted is now incremented BEFORE st.out_of_range, so it is no "
            "longer a sub-counter of it. Re-read the loop before changing the "
            "accounted sum -- and re-read the three documents that ask for that "
            "change."
        )
        # The two must be in the same block: the `continue` that ends the
        # out_of_range branch closes before unpainted is reached, or they are
        # different branches and the accounting argument is void.
        between = lines[out_of_range_line:unpainted_line]
        assert not any(re.match(r"\s*\}\s*$", l) and "continue" in l for l in between) or \
            not any("continue;" in l for l in between), (
            "a `continue` now separates ++st.out_of_range from ++st.unpainted, so "
            "they are independent branches and `unaccounted` genuinely does need "
            "a term for unpainted. Verify by reading the loop, then update both "
            "this test and the three documents that say otherwise."
        )

    # What counts as PRESCRIBING the wrong fix. Deliberately two-sided.
    #
    # The first version of this required an action verb BEFORE `unpainted`
    # ("add ... unpainted"). It was written and then caught: it matched NONE of
    # the six ways the item was actually phrased across the documents, including
    # the literal sentence that was filed. Reason: the counter name nearly always
    # comes FIRST and the verb after it ("`st.unpainted` is still missing, so a
    # tick reports them as `unaccounted`"), or there is no verb at all and the
    # line is a bare statement of the symptom.
    #
    # So the trigger is now the COUNTER plus a defect word in either order, and
    # the exclusion is the same in both directions: a line that also says the
    # claim is wrong, retracted, or already counted is a correction, not a
    # prescription. `_prescribes_wrong_fix` is exercised directly by
    # `test_prescription_detector_fires_on_every_known_phrasing`, because a
    # detector that silently stops matching is the failure this whole file is
    # about.
    PRESCRIBES_RE = re.compile(
        # The gap must not exclude `.`, because `st.unpainted` contains one. Two
        # earlier versions did: the first required an action verb before the
        # counter (missing every real phrasing, because the counter comes first),
        # and the second used `[^.\n]` as the gap, which silently skipped every
        # sentence naming the field *qualified*. That is the same shape as
        # `audit.py` reporting "no content loss detected" on Windows while
        # comparing zero pairs: a pattern that looks right, matches the easy
        # case, and returns nothing for the inputs that mattered. Sentence
        # terminators are `!` and `.` followed by space/end, so the class
        # excludes `.!?` plus newline and nothing else.
        r"(?:add(?:ing|s)?|include[ds]?|includ\w* it|sum(?:med|s)?|into the sum"
        r"|in the sum|missing|omits|omitted|absent|not in|needs? to be"
        r"|should be|must be|unaccounted|reports? them as|one term short)"
        r"[^.!?\n]{0,60}?(?:st\.)?unpainted"
        r"|(?:st\.)?unpainted[^.!?\n]{0,140}?"
        r"(?:add(?:ing|s)?|include[ds]?|sum(?:med|s)?|into the sum|in the sum"
        r"|missing|omits|omitted|absent|not in|needs? to be|should be|must be"
        r"|unaccounted|reports? them as|one term short)",
        re.IGNORECASE,
    )
    CORRECTION_RE = re.compile(
        r"CORRECTED|RETRACT|not a defect|is wrong|do not add|must NOT be added"
        r"|already counted|sub-counter|nothing to fix|no term",
        re.IGNORECASE,
    )

    @classmethod
    def _prescribes_wrong_fix(cls, line: str) -> bool:
        """True if `line` tells a reader to add st.unpainted to the sum."""
        return bool(cls.PRESCRIBES_RE.search(line)) and not cls.CORRECTION_RE.search(line)

    # The phrasings that actually appear in these documents, plus two synthetic
    # ones. Kept as data so a future rewording gets added here rather than
    # silently falling out of the detector's coverage.
    KNOWN_PHRASINGS = [
        ("`st.unpainted` is still missing from that sum, so a tick with unpainted "
         "items reports them as `unaccounted`.", True),
        ("`st.unpainted` is still missing**, so a tick that examines items it "
         "cannot paint reports them as `unaccounted` -- the same class of reporting "
         "bug, one term short.", True),
        ("Add `+ st.unpainted` and `+ st.null_obj`.", True),
        ("A tick with unpainted items reports them as `unaccounted`.", True),
        ("The `accounted` sum omits `st.unpainted`, so add `+ st.unpainted`.", True),
        ("`st.unpainted` needs to be in the sum.", True),
        # Must NOT fire. These are the negatives that keep the detector from
        # becoming "any line mentioning unpainted", which is the other way this
        # check could rot into uselessness.
        ("`st.zero_renderer` should also be summed.", False),
        ("`st.unpainted` is a sub-counter of `out_of_range`.", False),
        ("`st.unpainted` is already counted by `out_of_range`.", False),
        ("> **RETRACTED** -- `st.unpainted` must NOT be added to the sum.", False),
        ("> nothing to fix: `unpainted` is a sub-counter, not a branch.", False),
        ("the scan loop increments `st.out_of_range` and `st.unpainted`", False),
        ("`unpainted=0` in every one of 127 scan lines", False),
        ("`st.unpainted > 0` means items left the radius and were restored.", False),
    ]

    def test_prescription_detector_fires_on_every_known_phrasing(self):
        """The detector is itself checked, so it cannot rot into a no-op.

        Every one of these phrasings appeared in this repository, or is a
        plausible rewording of one that did. A detector that matched none of them
        would let the original defect back in while reporting green -- the same
        shape as `audit.py` on Windows, which reported "no content loss detected"
        while comparing zero pairs.
        """
        wrong: list[str] = []
        for line, want in self.KNOWN_PHRASINGS:
            got = self._prescribes_wrong_fix(line)
            if got != want:
                wrong.append(
                    f"want={want} got={got}: {line[:90]}"
                )
        assert not wrong, (
            "the prescription detector no longer agrees with the phrasings it was "
            "written for:\n  " + "\n  ".join(wrong)
        )

    def test_documentation_does_not_prescribe_the_wrong_fix(self):
        """No document may keep telling a reader to add `+ st.unpainted`.

        This is what makes the retraction durable. The item was carried in at
        least three documents across two sessions, each time with the fix spelled
        out — and prose does not fail when it is wrong, so it survived being
        contradicted by the code.

        Blockquoted lines are skipped, because the retractions themselves are
        written as blockquotes and a check that failed on a document's own
        correction note would be deleted rather than fixed. The limit of that
        choice is recorded in the retraction.
        """
        offenders: list[str] = []
        checked = 0
        for path in (
            REPO / "AGENTS_TODO.md",
            REPO / "tools" / "handoff_optics_memo.md",
            REPO / "CLEANUP_AUDIT.md",
            REPO / "tools" / "premises_about_other_workstreams.md",
            REPO / "WORKFLOW.md",
        ):
            if not path.exists():
                continue
            for i, line in enumerate(
                path.read_text(encoding="utf-8", errors="replace").splitlines(), 1
            ):
                if line.lstrip().startswith(">"):
                    continue
                checked += 1
                if self._prescribes_wrong_fix(line):
                    offenders.append(f"{path.name}:{i}: {line.strip()[:110]}")
        assert checked > 500, (
            f"only {checked} live-prose lines were scanned; the files are not being "
            "read where this test thinks they are."
        )
        assert not offenders, (
            "these lines still prescribe adding st.unpainted to the accounted sum, "
            "which would double-count every restored item:\n  "
            + "\n  ".join(offenders)
        )