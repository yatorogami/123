"""Map asset integrity: every referenced SVG layer id must actually exist.

This is the regression test for a class of defect that shipped and was
invisible. Five overlay layers across two shipped maps reference SVG layer
ids that do not exist, or duplicate a sibling's layer. The failure mode is
silent: `rasterize_visible_layer` returns false when no shape matches the
layer name (`svg_raster_map.cpp:204-209`), and `draw_active_map` skips the
raster when that happens (`minimap.h:2471`). No log, no fallback -- the
floor simply has no background. A player standing on Customs 4th floor sees
the 3rd floor's art; a player on Reserve 4th floor sees nothing.

Why a text test and not a runtime one
--------------------------------------
`minimap.h` and `svg_raster_map.cpp` cannot be executed here: they include
`common.h` (Windows-only) and the DX12 headers. What *is* testable, and is
the actual class of bug, is the agreement between the JSON config and the
SVG file it references. A test that reads both turns "somebody edited a
layer name without checking the SVG" from a defect found by a player
reporting a blank map into a red test at the moment of the edit.

The negative control is the point
---------------------------------
Reverting a layer name to a bogus value makes the corresponding test fail.
A test that cannot fail is worse than no test -- this repo has been bitten
by checkers that reported success while comparing nothing, so each
assertion here names the exact file and layer it is checking.
"""

import json
import re
from pathlib import Path

import pytest

MAPS_DIR = Path(__file__).resolve().parents[2] / "TarkovAddons" / "assets" / "maps"
RC_FILE = Path(__file__).resolve().parents[2] / "TarkovAddons" / "assets" / "menu_background.rc"
MINIMAP_H = Path(__file__).resolve().parents[2] / "TarkovAddons" / "module" / "minimap.h"

# The categories the shipped static-marker data carries, matching both the
# DynamicMaps source (after normalising its "Locked Door" spelling) and the
# draw path's colour switch in EspModule.cpp.
KNOWN_MARKER_CATEGORIES = {"LockedDoor", "Switch", "Secret"}


def _svg_ids(svg_path: Path) -> set[str]:
    """Extract every id="..." from an SVG file."""
    text = svg_path.read_text(encoding="utf-8", errors="replace")
    return set(re.findall(r'id="([^"]*)"', text))


def _rc_embedded_maps() -> dict[str, int]:
    """{file name: resource id} for every map asset packed into the DLL.

    The .rc is the ONLY thing that puts a map in front of the game: the mod is
    manual-mapped into EscapeFromTarkov.exe and ships as a single DLL, so an
    asset that is not RCDATA does not exist at runtime no matter what is in the
    repository.
    """
    text = RC_FILE.read_text(encoding="utf-8", errors="replace")
    out: dict[str, int] = {}
    for rid, path in re.findall(
        r"^\s*(\d+)\s+RCDATA\s+\"assets\\\\+maps\\\\+([^\"]+)\"", text, re.MULTILINE
    ):
        out[path] = int(rid)
    return out


def _minimap_h_table() -> dict[str, int]:
    """{file name: resource id} from embedded_map_assets() in minimap.h.

    Parsed from the source rather than trusted: the unpack loop matches the two
    tables by resource id, so a disagreement between them is an asset that packs
    and then unpacks under the wrong name, which no amount of correct data
    fixes.
    """
    text = MINIMAP_H.read_text(encoding="utf-8", errors="replace")
    body = text.split("embedded_map_assets(size_t& count)")[-1].split("};", 1)[0]
    return {name: int(rid) for rid, name in re.findall(r"\{\s*(\d+)\s*,\s*\"([^\"]+)\"", body)}


def test_every_referenced_svg_is_embedded_in_the_dll():
    """A map that NAMES an svg must have that svg packed as RCDATA.

    WHY THIS TEST EXISTS. test_referenced_svg_exists below checks the svg is on
    DISK. That is a real check and it passed for laboratory.svg the entire time
    the file sat in the repository unembedded -- 122,485 bytes of asset that no
    build ever packed, so no run of the game ever saw it. On-disk and shipped are
    different questions and only the second one is the one a user experiences.

    The symptom read as design: minimap.h said "Two have no SVG (laboratory,
    labyrinth) ... that is by design, not a missing-asset error", which is
    exactly what a comment does when it describes a packaging bug as an
    intention. Laboratory therefore shipped as a marker-only radar.

    A json that names an svg is asking for it. The only honest resolutions are
    embed it or stop naming it, and this test is what makes the first one the
    only reachable one.
    """
    embedded = _rc_embedded_maps()
    assert embedded, f"no map assets parsed out of {RC_FILE.name} -- the regex is stale"

    missing = []
    for json_path in sorted(MAPS_DIR.glob("*.json")):
        data = json.loads(json_path.read_text(encoding="utf-8"))
        svg_name = data.get("svg")
        if svg_name and svg_name not in embedded:
            missing.append(f"{json_path.name} names {svg_name!r}, not embedded")
    assert not missing, (
        "map json names an SVG that is not embedded, so it can never be loaded: "
        + "; ".join(missing)
    )


def test_the_rc_and_the_cpp_table_agree():
    """menu_background.rc and embedded_map_assets() must pack the same assets.

    The unpack loop matches by resource id, so the two tables have to be the same
    table. If the .rc gains an entry and minimap.h does not, the asset is packed
    and never extracted; if minimap.h gains one and the .rc does not, the lookup
    finds an id nothing was packed at. Neither shows up as a failure at runtime --
    it shows up as a missing minimap, which is what this is for.
    """
    rc = _rc_embedded_maps()
    cpp = _minimap_h_table()
    assert rc == cpp, (
        "the .rc and embedded_map_assets() disagree: "
        f"only in .rc: {sorted(set(rc) - set(cpp))}; "
        f"only in minimap.h: {sorted(set(cpp) - set(rc))}; "
        f"id mismatches: {sorted(k for k in set(rc) & set(cpp) if rc[k] != cpp[k])}"
    )


def test_the_unpack_check_would_catch_an_unembedded_svg():
    """NEGATIVE CONTROL for the test above.

    Compiles the real assertion against a synthetic embedded-set that is missing
    laboratory.svg, and asserts it REJECTS it. Without this, the test above is a
    check that has never been observed to fail on the thing it was written for --
    which is how the previous generation of this check (on-disk) came to pass
    green over a 122 KB asset that shipped to nobody.
    """
    embedded = _rc_embedded_maps()
    assert "laboratory.svg" in embedded, (
        "premise broken: laboratory.svg should be embedded; if it is not, the "
        "negative control below is testing nothing"
    )

    gapped = {k: v for k, v in embedded.items() if k != "laboratory.svg"}
    data = json.loads((MAPS_DIR / "laboratory.json").read_text(encoding="utf-8"))
    assert data.get("svg") == "laboratory.svg"
    rejected = data["svg"] not in gapped
    assert rejected, "the assertion would pass with laboratory.svg missing -- it cannot fail"


def _load_configs():
    configs = []
    for json_path in sorted(MAPS_DIR.glob("*.json")):
        data = json.loads(json_path.read_text(encoding="utf-8"))
        svg_name = data.get("svg")
        svg_ids = None
        if svg_name:
            svg_path = MAPS_DIR / svg_name
            if svg_path.exists():
                svg_ids = _svg_ids(svg_path)
        configs.append((json_path, data, svg_ids))
    return configs


def test_every_map_json_is_parseable():
    """Each config file must parse and carry an id and bounds."""
    configs = _load_configs()
    assert len(configs) >= 12, f"expected at least 12 maps, found {len(configs)}"
    for json_path, data, _ in configs:
        assert data.get("id"), f"{json_path.name}: missing 'id'"
        bounds = data.get("bounds_corners")
        assert bounds, f"{json_path.name}: missing 'bounds_corners'"
        assert len(bounds) == 2, f"{json_path.name}: bounds_corners must be 2 points"
        (x0, z0), (x1, z1) = bounds
        assert x0 != x1 or z0 != z1, f"{json_path.name}: degenerate bounds"


def test_referenced_svg_exists():
    """Every config that names an svg must have that file on disk."""
    for json_path, data, svg_ids in _load_configs():
        svg_name = data.get("svg")
        if svg_name:
            assert svg_ids is not None, (
                f"{json_path.name}: references '{svg_name}' but file not found"
            )


def test_base_layer_resolves():
    """The base svg_layer, if set, must exist in the SVG."""
    for json_path, data, svg_ids in _load_configs():
        layer = data.get("svg_layer")
        if layer and svg_ids is not None:
            assert layer in svg_ids, (
                f"{json_path.name}: base svg_layer '{layer}' not in SVG"
            )


def test_first_floor_layer_resolves():
    """first_floor_layer, if set, must exist in the SVG."""
    for json_path, data, svg_ids in _load_configs():
        layer = data.get("first_floor_layer")
        if layer and svg_ids is not None:
            assert layer in svg_ids, (
                f"{json_path.name}: first_floor_layer '{layer}' not in SVG"
            )


def test_overlay_layers_resolve():
    """Every non-null overlay svg_layer must exist in the SVG."""
    for json_path, data, svg_ids in _load_configs():
        for overlay in data.get("overlay_layers", []):
            layer = overlay.get("svg_layer")
            if layer and svg_ids is not None:
                assert layer in svg_ids, (
                    f"{json_path.name}: overlay '{overlay.get('name')}' "
                    f"svg_layer '{layer}' not in SVG"
                )


def test_no_duplicate_overlay_layers():
    """No two overlay layers in one map may share the same svg_layer."""
    for json_path, data, _ in _load_configs():
        seen: dict[str, str] = {}
        for overlay in data.get("overlay_layers", []):
            layer = overlay.get("svg_layer")
            if not layer:
                continue
            name = overlay.get("name", "?")
            if layer in seen:
                pytest.fail(
                    f"{json_path.name}: overlay '{name}' duplicates "
                    f"svg_layer '{layer}' already used by '{seen[layer]}'"
                )
            seen[layer] = name


def test_every_overlay_has_svg_or_tile():
    """Each overlay must have either a resolvable svg_layer or a tile_path."""
    for json_path, data, _ in _load_configs():
        for overlay in data.get("overlay_layers", []):
            has_svg = bool(overlay.get("svg_layer"))
            has_tile = bool(overlay.get("tile_path"))
            assert has_svg or has_tile, (
                f"{json_path.name}: overlay '{overlay.get('name')}' "
                f"has neither svg_layer nor tile_path"
            )


# ---------------------------------------------------------------------------
# Static markers and labels (bigmap plan step 5, merged 2026-10-13).
#
# The failure mode these guard against is a coordinate mapping error, and it
# is silent: the DynamicMaps source writes `Position {x, y, z}` where x is
# world X, y is world Z and z is the altitude, and our space is
# {x, y = altitude, z}. Swapping the last two -- or forgetting that y is the
# altitude -- puts every marker a floor off and mirrored across the map, and
# the radar still draws, so nothing complains. The bounds check is what
# catches it: a marker mirrored out of its own map is outside every bound.
# ---------------------------------------------------------------------------

def _bounds(data):
    (x0, z0), (x1, z1) = data["bounds_corners"]
    return min(x0, x1), max(x0, x1), min(z0, z1), max(z0, z1)


def test_static_markers_are_well_formed():
    """Every marker needs a text, a known category and a position."""
    for json_path, data, _ in _load_configs():
        for marker in data.get("static_markers", []):
            where = f"{json_path.name}: marker {marker.get('text')!r}"
            assert marker.get("text"), f"{where}: empty text"
            assert marker.get("category") in KNOWN_MARKER_CATEGORIES, (
                f"{where}: category {marker.get('category')!r} is not one of "
                f"{sorted(KNOWN_MARKER_CATEGORIES)} -- the draw path colours by "
                f"category, so an unknown one would render white"
            )
            pos = marker.get("position")
            assert isinstance(pos, dict) and {"x", "y", "z"} <= set(pos), (
                f"{where}: position must carry x, y and z"
            )


def test_static_markers_land_inside_their_map_bounds():
    """A marker far outside its map's bounds is a coordinate-mapping error.

    HONEST LIMIT, measured at authoring time: this does NOT catch a y<->z swap.
    Swapping the generator's second and third components moves each marker's z
    to its altitude, and an altitude is a small number that lands inside almost
    every map's z range -- so the swapped data passed this very test, 12/12,
    during the negative control. The spread check below is what catches it.
    """
    for json_path, data, _ in _load_configs():
        min_x, max_x, min_z, max_z = _bounds(data)
        # Comfort margin in metres. Markers legitimately sit a little outside
        # the artwork bounds (a door on the map's edge), so this is a gross
        # error check, not an exact containment test.
        pad = 250.0
        for marker in data.get("static_markers", []):
            pos = marker["position"]
            where = f"{json_path.name}: marker {marker.get('text')!r} at {pos}"
            assert min_x - pad <= pos["x"] <= max_x + pad, (
                f"{where}: x is outside the map bounds "
                f"[{min_x}, {max_x}] -- the coordinate mapping is wrong"
            )
            assert min_z - pad <= pos["z"] <= max_z + pad, (
                f"{where}: z is outside the map bounds "
                f"[{min_z}, {max_z}] -- the coordinate mapping is wrong"
            )


def test_marker_z_spread_is_not_an_altitude_spread():
    """The y<->z swap detector, and the reason the bounds check is not enough.

    On every shipped map the markers' horizontal (z) spread is 10-60x their
    vertical (y) spread: doors are spread across the map and sit within a few
    floors. Swap the mapping's second and third components and that inverts --
    z collapses onto the altitude distribution while y takes over the map.
    Measured 2026-10-13 across the eleven maps with data: the smallest correct
    ratio is 10x (reserve), and the swapped data the negative control ran
    produced ratios below 0.1. The threshold is 2x, so it holds a 5x margin on
    the good arm and fails by 20x on the bad one.

    NEGATIVE CONTROL, run: swapping y<->z in bigmap.json made this test fail
    with "y<->z swap" in the message, while the bounds test above stayed green
    on the same swap -- which is why this test exists at all.
    """
    for json_path, data, _ in _load_configs():
        markers = data.get("static_markers", [])
        if len(markers) < 10:
            # Too few points to distinguish a distribution from a line; the
            # bounds check is all a small map gets.
            continue
        zs = [m["position"]["z"] for m in markers]
        ys = [m["position"]["y"] for m in markers]
        z_spread = max(zs) - min(zs)
        y_spread = max(ys) - min(ys)
        assert z_spread > 2.0 * y_spread, (
            f"{json_path.name}: markers' z spread ({z_spread:.1f} m) is not "
            f"larger than 2x their y spread ({y_spread:.1f} m). That is the "
            f"signature of a y<->z swap in the coordinate mapping: z has taken "
            f"the altitude distribution and y the map. See "
            f"assets/maps/static-markers-LICENSE.md for the mapping."
        )


def test_the_cpp_reader_does_not_swap_what_the_data_test_proves():
    """The half of the swap the test above cannot see: the CODE.

    test_marker_z_spread_is_not_an_altitude_spread reads the RAW JSON and
    proves the data's z is the ground axis and y the altitude. It says nothing
    about read_dynamic_maps_position in module/minimap.h -- and on 2026-10-14
    that function read `out_z = value("y")` / `out_y = value("z")`, a swap the
    data test could not see because the data was right. Its two symptoms both
    looked like other bugs: every marker's altitude became its ground
    coordinate, so the per-floor filter culled all 34 Customs markers and the
    radar drew NONE (looked like a draw-path or checkbox bug), and the
    marker-door probe measured 0 of 34 within 2 m of a door (looked like bad
    source data). Both were that one line.

    So this pins the function body: each output must be read from the SAME-named
    key, which is the identity mapping the data's convention requires. Written
    as a source assertion because the harness cannot compile minimap.h (it
    pulls in the whole PCH), and a checker that reads only the JSON is exactly
    the checker that let this ship green.
    """
    src = (
        Path(__file__).resolve().parents[2] / "TarkovAddons" / "module" / "minimap.h"
    ).read_text(encoding="utf-8", errors="replace")
    m = re.search(
        r"inline void read_dynamic_maps_position\((?:[^)]*)\)\s*\{(.*?)\}",
        src,
        re.DOTALL,
    )
    assert m, "read_dynamic_maps_position is gone from minimap.h"
    body = m.group(1)
    # Strip // comments so the swap cannot hide in prose the way the wrong
    # reasoning used to.
    code = re.sub(r"//[^\n]*", "", body)
    for out, key in (("out_x", "x"), ("out_y", "y"), ("out_z", "z")):
        got = re.search(rf"{out}\s*=\s*node\.value\(\s*\"(\w)\"", code)
        assert got, f"{out} is not assigned in read_dynamic_maps_position"
        assert got.group(1) == key, (
            f"read_dynamic_maps_position maps {out} from \"{got.group(1)}\" -- "
            f"the data's {key!r} axis. That is the y<->z swap that made the "
            f"radar draw no markers on 2026-10-14; the marker/label readers "
            f"must be the IDENTITY (out_x=x, out_y=y, out_z=z) because "
            f"DynamicMaps writes Position in Unity's own order."
        )


def test_labels_are_well_formed_and_inside_bounds():
    for json_path, data, _ in _load_configs():
        min_x, max_x, min_z, max_z = _bounds(data)
        for label in data.get("labels", []):
            where = f"{json_path.name}: label {label.get('text')!r}"
            assert label.get("text"), f"{where}: empty text"
            pos = label.get("position")
            assert isinstance(pos, dict) and {"x", "y", "z"} <= set(pos), (
                f"{where}: position must carry x, y and z"
            )
            pad = 250.0
            assert min_x - pad <= pos["x"] <= max_x + pad, (
                f"{where}: x is outside the map bounds [{min_x}, {max_x}]"
            )
            assert min_z - pad <= pos["z"] <= max_z + pad, (
                f"{where}: z is outside the map bounds [{min_z}, {max_z}]"
            )


def test_no_extract_or_transit_markers_are_shipped():
    """Extract/Transit are deliberately NOT in the static data.

    This project reads those live; a static copy desyncs from eligibility the
    first time a raid's state changes. If someone re-merges the upstream file
    wholesale, this is what fails.
    """
    for json_path, data, _ in _load_configs():
        for marker in data.get("static_markers", []):
            assert marker.get("category") not in ("Extract", "Transit"), (
                f"{json_path.name}: marker {marker.get('text')!r} is "
                f"{marker.get('category')}, which must stay live-only"
            )


def test_the_shipped_marker_and_label_counts_match_the_merge():
    """The merge's totals, re-derived rather than remembered.

    DynamicMaps at 4944764 (tag 1.2.1) carries 384 StaticMarkers and 270
    Labels; the included subset is 242 markers / 270 labels across the eleven
    maps that have data (terminal is the arena and carries none).
    """
    total_markers = total_labels = 0
    for _, data, _ in _load_configs():
        total_markers += len(data.get("static_markers", []))
        total_labels += len(data.get("labels", []))
    assert total_markers == 242, (
        f"expected 242 static markers, found {total_markers} -- re-derive from "
        f"the submodule before changing this figure"
    )
    assert total_labels == 270, (
        f"expected 270 labels, found {total_labels}"
    )
