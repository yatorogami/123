"""The pen-walk's two layer gates must keep ONE set of forensic strings.

History: `tools/handoff_skeleton_vis_clone_merge.md` (2026-10-10) found two
clones in `skeleton_visibility.h` -- the ancestor ballistic-walk's per-layer
gate and the sibling sweep's copy. They aimed identically and printed
differently, and the note deliberately reverted a merge because the divergent
wording was load-bearing for reading a log: a `stop_reason` starting
`sibling:` named which sweep stopped the round.

POLICY CHANGE, 2026-10-14 (the user's call): **unify.** The sibling path now
renders the ancestor's four strings exactly:

  | condition      | both paths, from 2026-10-14            |
  | dead stop      | "blocked at layer {} ({})"             |
  | stop reason    | bare `reason`                          |
  | ricochet tally | "ricochet {:.3f} >= {:.2f}"            |
  | ricochet verdict | "...; round likely skips off"        |

The cost is stated rather than hidden: historical logs keep matching only
through the old wording, and a new verdict no longer says WHICH sweep stopped
the round. The counted `pen_stop` buckets still split the two unreadable cases
(`sibling_unreadable` vs `unreadable`), so the tally keeps the distinction the
strings lost. The CHANGELOG entry for the change records that a diagnostic
string change once sent an investigation at the wrong subsystem, which is why
this file exists at all.

WHAT THIS PINS, in both directions:
  * the unified strings exist (a merge that drops one path's verdict fails);
  * the old sibling spellings are GONE (a re-divergence fails);
  * "; round likely skips off" is in BOTH deflection verdicts now -- exactly
    two, where it was exactly one;
  * each block still assigns ITS variable (`layer_is_ballistic` vs
    `layer_ballistic`), because the structural difference between the gates
    was never part of this decision and a merge that collapsed them would
    compile and quietly change behaviour.

Comments are blanked, strings are NOT, so the explanatory prose above either
block cannot satisfy an assertion made about it.
"""

from __future__ import annotations

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
VIS = ROOT / "TarkovAddons" / "module" / "skeleton_visibility.h"


def blank_comments_keep_strings(src: str):
    """Blank `//` and `/* */` comments, keep string literals, preserve length.

    Comments must go: the merge rationale sits directly above these blocks and its
    own text quotes the format strings. Strings stay because every assertion below
    is about a string literal.
    """
    out = list(src)
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == '"':  # skip the whole literal, honouring escapes
            i += 1
            while i < n and src[i] != '"':
                i += 2 if src[i] == "\\" else 1
            i += 1
            continue
        if c == "/" and i + 1 < n and src[i + 1] == "/":
            j = src.find("\n", i)
            j = n if j < 0 else j
            for k in range(i, j):
                out[k] = " "
            i = j
        elif c == "/" and i + 1 < n and src[i + 1] == "*":
            j = src.find("*/", i + 2)
            j = n if j < 0 else j + 2
            for k in range(i, j):
                out[k] = " "
            i = j
        else:
            i += 1
    return "".join(out)


def fuse_adjacent_literals(code):
    """Join adjacent string literals the way the C++ preprocessor does.

    The deflection verdict is written as two literals:

        "layer {} is a deflection candidate (ricochet risk "
        "{:.3f} >= {:.2f}); round likely skips off",

    so `real_literals` alone yields `"round likely skips off"` in a *separate*
    entry from `"layer {} is a deflection candidate"`, and an assertion that the
    verdict string contains the suffix fails on a source that is correct. Iterated
    to a fixed point so three-way splits are handled too.
    """
    prev = None
    while prev != code:
        prev = code
        code = re.sub(
            r'"((?:\\.|[^"\\])*)"\s+"((?:\\.|[^"\\])*)"',
            lambda m: '"' + m.group(1) + m.group(2) + '"',
            code,
        )
    return code


def real_literals(code):
    """The string literals actually in the code, in source order."""
    return re.findall(r'"((?:\\.|[^"\\])*)"', code)


class TestOneSetOfStrings(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = VIS.read_text(encoding="utf-8", errors="replace")
        cls.code = blank_comments_keep_strings(cls.raw)
        cls.lits = real_literals(fuse_adjacent_literals(cls.code))

    def assert_literal(self, needle, count=1):
        hits = [lit for lit in self.lits if needle in lit]
        self.assertEqual(
            len(hits), count,
            "expected the format string containing %r exactly %d time(s) in "
            "skeleton_visibility.h, found %d: %r" % (needle, count, len(hits), hits),
        )

    def assert_literal_absent(self, needle):
        hits = [lit for lit in self.lits if needle in lit]
        self.assertEqual(
            hits, [],
            "the retired sibling spelling %r is still a string literal (found %r). "
            "The two layer gates were unified on 2026-10-14; re-diverging them is "
            "a policy decision, not an accident." % (needle, hits),
        )

    # ------------------------------------------------ the unified four strings
    def test_dead_stop_string_is_the_ancestors(self):
        # Once per gate. Two because both gates render it now; a merge that
        # dropped either gate's verdict fails here.
        self.assert_literal("blocked at layer {} ({})", count=2)

    def test_ricochet_tally_string_is_shared(self):
        self.assert_literal("ricochet {:.3f} >= {:.2f}", count=2)

    def test_old_sibling_spellings_are_gone(self):
        self.assert_literal_absent("blocked at layer {} (sibling; {})")
        self.assert_literal_absent("sibling: {}")
        self.assert_literal_absent("sibling ricochet {:.3f} >= {:.2f}")
        self.assert_literal_absent("sibling layer {} is a deflection candidate")

    def test_the_suffix_is_now_in_both_verdicts(self):
        """"; round likely skips off" moved from exactly once to exactly twice.

        It was once on the ancestor verdict only -- the asymmetry the 2026-10-10
        handoff guarded. Unifying means BOTH deflection verdicts carry it, so
        exactly two is the pinned state and one means the sibling verdict lost it.
        """
        hits = [lit for lit in self.lits if "round likely skips off" in lit]
        self.assertEqual(
            len(hits), 2,
            "expected '; round likely skips off' in exactly TWO verdict strings "
            "(one per gate) after the 2026-10-14 unification, found %d: %r"
            % (len(hits), hits),
        )
        for hit in hits:
            self.assertIn("deflection candidate", hit)

    def test_the_two_deflection_verdicts_are_identical(self):
        """Paired with the suffix test so the count alone cannot pass.

        Two identical deflection verdicts is the unified state; two that differ
        is the old divergence wearing the same count.
        """
        hits = [lit for lit in self.lits if "deflection candidate" in lit]
        self.assertEqual(len(hits), 2, "expected 2 deflection-candidate verdict strings, got %r" % (hits,))
        self.assertEqual(hits[0], hits[1],
                         "the two deflection verdicts differ; they must render one "
                         "shared string since the 2026-10-14 unification")
        for hit in hits:
            self.assertNotIn("sibling", hit)

    # ------------------------------------------- the two variables, still not one
    def _block(self, marker, end_anchor, occurrence=0):
        """The region of one block, from a marker unique to it to past its tail.

        Region-anchored because the handoff's point is per-block. A file-wide
        check cannot tell a block's own assignment from the same name being
        assigned somewhere else -- `layer_is_ballistic` is also set by the
        exit-face path and `layer_ballistic` by the fallback walk, so a merge
        that dropped one block's assignment would pass a file-wide assertion and
        still be wrong.

        `occurrence` picks which match of the marker: the unified dead-stop
        string now appears in BOTH gates, so the ancestor's (first, in source
        order) and the sibling's own marker ("sibling BallisticCollider
        unreadable", unique to it) are chosen explicitly.
        """
        ms = list(re.finditer(re.escape(marker), self.code))
        self.assertTrue(ms, "marker %r not found" % marker)
        m = ms[min(occurrence, len(ms) - 1)]
        nxt = self.code.find(end_anchor, m.end())
        self.assertGreater(nxt, 0, "end anchor %r not found" % end_anchor)
        return self.code[m.start():nxt + 160]

    def test_ancestor_block_assigns_layer_is_ballistic(self):
        """`layer_is_ballistic` (bool) vs `layer_ballistic` (pointer), handoff 2.2.

        They are different variables with different downstream readers; the
        ancestor block must keep setting ITS one:

          * `layer_is_ballistic` gates `if (!layer_is_ballistic)`, i.e. whether
            the sibling sweep runs at all;
          * `layer_ballistic` is read by `same_collider` on the NEXT iteration.

        A merge that kept only one assignment compiles and changes behaviour.
        """
        block = self._block('"blocked at layer {} ({})"', "if (!layer_is_ballistic)",
                            occurrence=0)
        self.assertRegex(
            block, r"\blayer_is_ballistic\s*=\s*true\s*;",
            "the ancestor layer gate no longer assigns layer_is_ballistic inside "
            "its own block. It is also assigned at the exit-face path, so a "
            "file-wide check cannot see this; without it the sibling sweep no "
            "longer runs. See handoff_skeleton_vis_clone_merge.md 2.2.",
        )

    def test_sibling_block_assigns_layer_ballistic(self):
        block = self._block('"sibling BallisticCollider unreadable"',
                            "const float advance = hit.m_distance")
        self.assertRegex(
            block, r"\blayer_ballistic\s*=\s*ballistic\s*;",
            "the sibling layer gate no longer assigns layer_ballistic inside its "
            "own block. same_collider reads it on the next iteration, so without "
            "it the same-collider test silently degrades. See "
            "handoff_skeleton_vis_clone_merge.md 2.2.",
        )

    def test_the_ancestor_block_does_not_assign_the_pointer(self):
        """The complement: each block assigns ITS variable, not both.

        Without this, a merge that assigned both names in both blocks would pass
        the two assertions above and the surviving duplication would be
        invisible -- the exact outcome the merge was supposed to prevent.
        """
        block = self._block('"blocked at layer {} ({})"', "if (!layer_is_ballistic)",
                            occurrence=0)
        self.assertNotRegex(
            block, r"\blayer_ballistic\s*=\s*ballistic\s*;",
            "the ancestor block now assigns layer_ballistic too. The two gates "
            "assign different variables on purpose; a merged block that sets "
            "both is duplicated state with two readers and one of them stale.",
        )

    def test_the_sibling_block_does_not_assign_the_bool(self):
        """Complement of the previous one, the other way round."""
        block = self._block('"sibling BallisticCollider unreadable"',
                            "const float advance = hit.m_distance")
        self.assertNotRegex(
            block, r"\blayer_is_ballistic\s*=\s*true\s*;",
            "the sibling block now assigns layer_is_ballistic too. It sets the "
            "POINTER; the bool belongs to the ancestor block and gates the sweep "
            "this very code is inside.",
        )


if __name__ == "__main__":
    unittest.main()
