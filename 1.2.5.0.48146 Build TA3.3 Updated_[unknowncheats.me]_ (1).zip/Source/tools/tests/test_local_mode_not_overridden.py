"""Transit must not assign an ELocalMode at all.

`LocalRaidSettings.mode` and `LocalPlayer._playerInMode` are both
`EFT.ELocalMode` (GameDump/115147510/dump.cs:257034):

    TRAINING = 0, PVE_OFFLINE = 1, NARRATE = 2, TUTORIAL = 3

Two sites wrote a literal `1` into them on every transit. 1 is PVE_OFFLINE, and
the value being clobbered in the report that prompted this was **3, TUTORIAL** --
loading a tutorial came out as an offline local raid.

  * `dump_local_raid_settings()` opened with `set_field("mode", 1)` -- inside the
    function whose job is to PRINT the settings, immediately before printing them.
    So the overwrite was invisible: `local_raid_settings_dump:
    [mode-PVE_OFFLINE] ...` is what a TUTORIAL load prints, and it is
    byte-identical to what an offline load prints. The diagnostic that would have
    revealed the bug was produced by the bug.
  * `setup_local_player_object()` did `set_field<int>("_playerInMode", 1)`, called
    from `hk_transit` before `o_transit`.

Two further facts make both writes pure downside:

  * the game assigns the field itself. `LocalPlayer.Create(...)` takes an
    `ELocalMode localMode` parameter and does `_playerInMode = localMode`
    (`Create_d__0.txt:1666`).
  * `ELocalMode` does not decide the online/offline path. That is
    `ForceOnlineRaidInPVE` / `ForceOfflineRaidInPVE` on `LocationSettings` plus
    `ERaidMode`. So neither write ever steered the thing it appeared to steer.

An intermediate revision of the fix PROPAGATED the game's mode through
`setup_local_player_object(player, mode)` instead of writing a constant. That is
also rejected here: with no online/offline path to influence, keeping a write at
all is unjustified, and it leaves a live assignment to regress.

And the write is not cosmetic. `LocalPlayer.IsNonTrainingPlayer()` is, in raw
disassembly, `cmp dword ptr [rcx+0CB0h],0 ; seta al` -- `_playerInMode > 0`.

THE CHECKER STRIPS COMMENTS FIRST, and that is not incidental. Both writers are
retained as comments explaining what they did, so a naive search for that code
finds its own explanation and passes. That is the failure this repo has already
hit once: `test_profile_path.py` v1 "matched its own fix's explanatory comment and
passed 10/10 against deliberately reverted code".

The whole-file check is the one that carries the weight -- the two per-function
checks cannot see a third site.
"""

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ALWAYS_ON = ROOT / "TarkovAddons" / "module" / "always_on.h"


def strip_comments(src: str) -> str:
    """Blank out // and /* */ comments, preserving offsets.

    Length-preserving so a comment cannot shift a later match, and comment-free so
    a match can only be real code.
    """
    out = list(src)
    i, n, in_line, in_block, in_str, in_chr = 0, len(src), False, False, False, False
    while i < n:
        c = src[i]
        nxt = src[i + 1] if i + 1 < n else ""
        if in_line:
            if c == "\n":
                in_line = False
            else:
                out[i] = " "
            i += 1
            continue
        if in_block:
            if c == "*" and nxt == "/":
                out[i] = out[i + 1] = " "
                in_block = False
                i += 2
                continue
            if c != "\n":
                out[i] = " "
            i += 1
            continue
        if in_str or in_chr:
            quote = '"' if in_str else "'"
            if c == "\\":
                out[i] = " "
                if i + 1 < n and src[i + 1] != "\n":
                    out[i + 1] = " "
                i += 2
                continue
            if c == quote:
                in_str = in_chr = False
            i += 1
            continue
        if c == "/" and nxt == "/":
            in_line = True
            out[i] = out[i + 1] = " "
            i += 2
            continue
        if c == "/" and nxt == "*":
            in_block = True
            out[i] = out[i + 1] = " "
            i += 2
            continue
        if c == '"':
            in_str = True
        elif c == "'":
            in_chr = True
        i += 1
    return "".join(out)


def fn_body(code: str, signature: str) -> str:
    start = code.find(signature)
    if start < 0:
        raise AssertionError(f"signature not found in comment-stripped source: {signature!r}")
    open_at = code.find("{", start)
    depth, i, n = 0, open_at, len(code)
    while i < n:
        if code[i] == "{":
            depth += 1
        elif code[i] == "}":
            depth -= 1
            if depth == 0:
                return code[open_at: i + 1]
        i += 1
    raise AssertionError(f"unbalanced braces after {signature!r}")


class TestTransitDoesNotInventLocalMode(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = ALWAYS_ON.read_text(encoding="utf-8-sig")
        cls.code = strip_comments(cls.raw)

    # -- the two writers --------------------------------------------------

    def test_dump_local_raid_settings_writes_nothing(self):
        """It is a dump. A diagnostic that reports from a field it has just
        written cannot report anything, which is why this bug was invisible."""
        body = fn_body(self.code, "void dump_local_raid_settings(")
        self.assertNotIn("set_field", body,
                         "dump_local_raid_settings writes to the settings it is "
                         "meant to print. ELocalMode.mode is printed by "
                         "ToString() as [localMode:N], so a write here both "
                         "overrides TUTORIAL and hides that it did.")
        self.assertNotRegex(body, r"set_field\s*<[^>]*>\s*\(\s*\"\s*mode",
                            "dump_local_raid_settings assigns ELocalMode.mode")

    def test_setup_local_player_object_writes_nothing(self):
        """The replacement is commented out, so there is no live `set_field` in
        the body at all -- not even a propagating one.

        An earlier revision of this fix passed the mode through instead of
        dropping the write. That was wrong on the evidence: ELocalMode does not
        decide the online/offline path (ForceOnlineRaidInPVE /
        ForceOfflineRaidInPVE on LocationSettings, and ERaidMode, do), so there
        was never a path for this write to steer.
        """
        body = fn_body(self.code, "void setup_local_player_object(")
        self.assertNotIn("set_field", body,
                         "setup_local_player_object still assigns _playerInMode; "
                         "the ELocalMode replacement is meant to be commented out")
        self.assertNotIn("_playerInMode", body.replace("(void)player", ""),
                         "setup_local_player_object still names _playerInMode "
                         "outside the commented-out original")

    def test_no_live_elocalmode_write_anywhere_in_the_file(self):
        """The belt-and-braces check.

        Two sites were found once; a third would not be caught by the two tests
        above, which are per-function. This one is whole-file and comment-stripped,
        so it is the check that actually says "ELocalMode is never assigned by this
        module" rather than "two known places do not".
        """
        offenders = self.offenders(self.code)
        self.assertEqual(
            offenders, [],
            "ELocalMode is assigned at line(s) "
            + ", ".join(map(str, offenders))
            + " -- the replacement is meant to be commented out entirely. "
              "Note this check strips comments, so these are live assignments, "
              "not the documentation of the old ones.")

    def test_the_commented_out_original_is_still_visible(self):
        """The value that was there, and why it went, belong in the file. A
        comment that documents a removal is the record; deleting it loses the
        only place a future reader learns what 1 meant here.

        The rationale lives in the comment block ABOVE the function, so that is
        what gets searched. An earlier version of this test looked in the body and
        failed on correct code for exactly that reason.
        """
        body = fn_body(self.raw, "void setup_local_player_object(")
        sig_at = self.raw.index("void setup_local_player_object(")
        # Start at the beginning of the signature's LINE, not at the token.
        # Slicing to the token index leaves the partial line `    inline` as the
        # last element, which is not a comment, so the backward walk below stops
        # on the first iteration and finds nothing. It found nothing silently.
        line_start = self.raw.rfind("\n", 0, sig_at) + 1
        head = self.raw[:line_start].rstrip().splitlines()
        block = []
        for line in reversed(head):
            s = line.strip()
            if s.startswith("//"):
                block.append(s)
            elif not s:
                continue
            else:
                break
        rationale = "\n".join(reversed(block)) + "\n" + body

        self.assertIn("_playerInMode", rationale,
                      "the record of the removed write is gone, so the value 1 "
                      "and its meaning are lost")
        self.assertIn("PVE_OFFLINE", rationale,
                      "the record does not say what 1 was")
        for token in ("TUTORIAL", "ForceOnlineRaidInPVE", "ERaidMode"):
            self.assertIn(token, rationale,
                          f"the record does not mention {token}")

    def test_hk_transit_reads_the_mode_and_never_writes_it(self):
        body = fn_body(self.code, "hk_transit(")
        self.assertIn("try_read_local_mode", body,
                      "hk_transit no longer reads ELocalMode from the settings")
        self.assertIn("local_mode_name", body,
                      "hk_transit does not render the mode readably in the log")
        self.assertNotIn("setup_local_player_object", body,
                         "hk_transit still calls the (now inert) writer")
        self.assertNotIn("set_field", body,
                         "hk_transit assigns an ELocalMode field itself")

    # -- the enum is legible ----------------------------------------------

    def test_the_modes_are_named_rather_than_magic_numbers(self):
        for name in ("training", "pve_offline", "narrate", "tutorial"):
            self.assertRegex(self.code, rf"\b{name}\s*=\s*[0-3]\b",
                             f"ELocalMode value {name} is not declared in code")
        self.assertIn("local_mode_name", self.code,
                      "no helper turns a mode into a readable name, so log lines "
                      "will carry bare integers again")

    # -- negative control -------------------------------------------------

    def test_negative_control_reinserting_either_write_goes_red(self):
        """Two mutations, because there were two wrong fixes.

        The first wrong fix restored the constant `1`. The second -- the one this
        file's own history shipped in 0bf0f40b0 -- PROPAGATED the game's mode
        instead. Both are rejected, so both are the control.
        """
        # Precondition: the shipped source really is write-free.
        self.assertEqual(
            self.offenders(self.code), [],
            "precondition: the shipped tree already assigns an ELocalMode")

        constant = self.code.replace(
            "inline void setup_local_player_object(Il2CppObject* player) {",
            "inline void setup_local_player_object(Il2CppObject* player) {\n"
            '        local_player.set_field<int>("_playerInMode", 1);',
            1)
        self.assertNotEqual(constant, self.code, "could not build control #1")
        self.assertNotEqual(self.offenders(constant), [],
                            "control #1 (the original constant) was not detected")

        propagated = self.code.replace(
            "inline void setup_local_player_object(Il2CppObject* player) {",
            "inline void setup_local_player_object(Il2CppObject* player, int mode) {\n"
            '        local_player.set_field<int>("_playerInMode", mode);',
            1)
        self.assertNotEqual(propagated, self.code, "could not build control #2")
        self.assertNotEqual(self.offenders(propagated), [],
                            "control #2 (propagating the mode, the intermediate "
                            "fix) was not detected -- a write that propagates is "
                            "still a write, and with no online/offline path to "
                            "influence it is still unjustified")

    @staticmethod
    def offenders(code: str) -> list[int]:
        """1-based lines where an ELocalMode field is assigned in LIVE code."""
        return [code.count("\n", 0, m.start()) + 1
                for m in re.finditer(
                    r'set_field\s*<[^>]*>\s*\(\s*"\s*(?:mode|_playerInMode)\s*"',
                    code)]


if __name__ == "__main__":
    unittest.main()