"""A class-scope pointer member with no constructor and no initialiser is a bug.

THE BUG THIS EXISTS TO KEEP FIXED. `EspModule::main_player_` was declared

    Il2CppObject *main_player_;          // no initialiser

in a class that is HEAP allocated -- ModuleManager.h:122 is
`module(new EspModule())`, and `module()` only pushes the pointer, so the object
is DEFAULT-initialised, not value-initialised. `EspModule() = default` means an
initialiser-less pointer member holds whatever the allocator handed back.
`draw_overlay` then dereferenced it (`main_player_->klass`) on the render thread
on every presented frame, which starts before the first raid's first
gameworld_update. A global would have been zero-filled by the loader; a `new`
is not.

WHY THE RULE IS "NO CONSTRUCTOR" AND NOT "NO INITIALISER". The obvious rule --
every pointer member must be `= nullptr` -- is 289 false positives across
module/impl alone, because this codebase initialises config values in
OUT-OF-LINE constructors:

    AmmoHudModule::AmmoHudModule() : Module("Ammo HUD", ...),
                                     enabled(conf(new CheckboxValue(...))),
                                     font_size(conf(new IntSliderEditableValue(...))), ...

A member of a class that HAS a constructor may legitimately be initialised by
that constructor, and a regex cannot follow an init-list reliably enough to
prove otherwise -- an earlier version of this scanner tried, and missed 4 of 6
initialisers in a single constructor. So instead of guessing, the rule only
applies where the answer is unambiguous: a class with NO user-declared
constructor can only be initialised by a default member initialiser or by
aggregate initialisation at the point of use, and the first of those is what
this asserts. A class that cannot be shown to have a constructor is treated as
having one -- the check is biased toward silence rather than false alarms.

WHY THERE IS A BASELINE. 32 members already trip this rule and every one is a
plain data record -- `mongo_id`, `template_entry`, `timeline_data`, `bone_ref`,
`text_plan` -- aggregate-initialised where they are built, never `new`ed. They
are listed in `ptr_member_baseline.txt` rather than fixed here, because
rewriting 32 data structs to add `= nullptr` is a separate change from a crash
fix, and because a baseline is honest: it records known debt instead of hiding
it. The test fails on any NEW entry, which is the whole point -- the defect
class is closed going forward, and the debt is visible rather than forgotten.

THE BASELINE IS A RATCHET, NOT AN EXCUSE. Keyed on file + class + member, so a
genuinely new uninitialised member cannot hide behind an existing entry unless
it reuses all three. It is NOT keyed on line numbers, which drift on every edit.

THE CHECKER IS NEGATIVE-CONTROLLED. `test_negative_control_*` below injects an
uninitialised member into a real header and asserts the scanner reports it. A
scanner that silently matched nothing would pass every other test here, which
is the failure this repo has already paid for three times.
"""

from __future__ import annotations

import bisect
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASELINE = Path(__file__).with_name("ptr_member_baseline.txt")

# Only headers WE own and instantiate. `il2cpp/` is excluded deliberately: those
# structs MIRROR GAME MEMORY, so `Il2CppClass *klass;` is not a field we own and
# initialising it would be a claim about the game's layout rather than a fix.
# GameDump/ is vendored (a 94 MB il2cpp.h alone) and gitignored.
SCOPES = ("module", "gui", "util", "config")

TRAILING_PTR = re.compile(r"\*\s*([A-Za-z_]\w*)\s*$")
CLASS_KW = re.compile(r"\b(?:class|struct|union)\b")


def strip(src: str) -> str:
    """Blank comments and string/char literals, preserving offsets and newlines."""
    out = list(src)
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == '"' or c == "'":
            q = c
            i += 1
            while i < n and src[i] != q:
                if src[i] == "\\":
                    i += 1
                if i < n and src[i] != "\n":
                    out[i] = " "
                i += 1
            if i < n:
                out[i] = " "
            i += 1
        elif src.startswith("//", i):
            while i < n and src[i] != "\n":
                out[i] = " "
                i += 1
        elif src.startswith("/*", i):
            while i < n and not src.startswith("*/", i):
                if src[i] != "\n":
                    out[i] = " "
                i += 1
            for j in range(i, min(i + 2, n)):
                out[j] = " "
            i += 2
        else:
            i += 1
    return "".join(out)


def class_ranges(src: str):
    """(name, body_start, body_end) for every class/struct/union body.

    THE LAST class/struct/union keyword in the text between the previous brace and
    this one names the body being opened -- not the first. That is the C++ rule:
    the declarator immediately preceding `{` is the type whose body it is, and
    anything earlier in that gap is a separate declaration.

    Taking the FIRST keyword is wrong the moment a forward declaration sits above
    the class. It was, until MapModule.h added `class EspModule;` above
    `class MapModule : public Module`: the scan then called MapModule's members
    EspModule's, found no `EspModule(...)` constructor, and reported nine
    constructor-initialised pointers as uninitialised. A scanner that misnames the
    class it is scanning is worse than one that finds nothing, because its
    findings look real.
    """
    stack, last, out, i, n = [], 0, [], 0, len(src)
    while i < n:
        c = src[i]
        if c == "{":
            head = src[last:i]
            kws = list(CLASS_KW.finditer(head))
            km = kws[-1] if kws else None      # LAST, not first -- see the docstring
            name = None
            if km:
                nm = re.match(r"(?:class|struct|union)\s+([A-Za-z_]\w*)", head[km.start():])
                if nm:
                    name = nm.group(1)
            stack.append((bool(km), name, i + 1))
            last = i + 1
        elif c == "}":
            if stack:
                is_cls, name, start = stack.pop()
                if is_cls:
                    out.append((name, start, i))
            last = i + 1
        i += 1
    return out


def member_of(seg: str):
    """(name, text) if `seg` is a pointer DATA member with no initialiser."""
    flat = " ".join(seg.split()).rstrip(";").strip()
    if not flat or "(" in flat or "operator" in flat:
        return None
    if any(k in flat for k in ("static ", "constexpr ", "typedef ", "using ", "extern ")):
        return None
    if "* const" in flat or flat.startswith("return"):
        return None
    m = TRAILING_PTR.search(flat)
    if not m:
        return None
    if "=" in flat:            # has a default member initialiser
        return None
    return m.group(1), flat


def has_ctor(name, header_body: str, cpp_src: str) -> bool:
    """Whether the class declares/defines ANY constructor, inline or out-of-line."""
    if not name:
        return True                                   # unknown -> stay silent
    if re.search(r"\b" + re.escape(name) + r"\s*\(", header_body):
        return True
    if re.search(re.escape(name) + r"\s*::\s*~?\s*" + re.escape(name) + r"\s*\(", cpp_src):
        return True
    return False


def scan(path: Path):
    raw = path.read_text(encoding="utf-8-sig", errors="ignore")
    newlines = [i for i, ch in enumerate(raw) if ch == "\n"]
    src = strip(raw)
    cpp = path.with_suffix(".cpp")
    cpp_src = (strip(cpp.read_text(encoding="utf-8-sig", errors="ignore"))
               if cpp.exists() else "")
    hits = []
    for name, start, end in class_ranges(src):
        if has_ctor(name, src[start:end], cpp_src):
            continue
        depth, seg, i = 0, start, start
        while i < end:
            c = src[i]
            if c == "{":
                if depth == 0:
                    seg = i + 1
                depth += 1
            elif c == "}":
                depth -= 1
            elif c == ";" and depth == 0:
                got = member_of(src[seg:i + 1])
                if got:
                    line = bisect.bisect_right(newlines, seg) + 1
                    hits.append((str(path.relative_to(ROOT)).replace("\\", "/"),
                                 line, name, got[0], got[1]))
                seg = i + 1
            i += 1
    return hits


def headers():
    base = ROOT / "TarkovAddons"
    out = []
    for p in sorted(base.rglob("*.h")):
        rel = p.relative_to(base).parts
        # rel[0] is the scope directory. Indexing p.parts instead would pick up the
        # absolute path's segments and silently select NOTHING -- which is exactly
        # what happened the first time this ran.
        if "external" in rel or "GameDump" in rel or "il2cpp" in rel:
            continue
        if rel[0] in SCOPES:
            out.append(p)
    return out


def findings():
    out = {}
    for p in headers():
        for f in scan(p):
            out[f"{f[0]}|{f[2]}|{f[3]}"] = f
    return out


def baseline_keys():
    return {ln.strip() for ln in BASELINE.read_text(encoding="utf-8").splitlines() if ln.strip()}


class TestPointerMembersAreInitialised(unittest.TestCase):
    def test_no_new_uninitialised_pointer_members(self):
        """The gate. Anything not in the baseline is a NEW defect."""
        found = findings()
        new = sorted(set(found) - baseline_keys())
        self.assertEqual(
            new, [],
            "class-scope pointer member(s) with no constructor and no initialiser.\n"
            "A `new`-ed object of such a class holds an indeterminate pointer.\n"
            "Add `= nullptr`, or -- if the class genuinely has a constructor that\n"
            "initialises it -- say why the scanner could not see it.\n  "
            + "\n  ".join(f"{k}   {found[k][4]}   (line {found[k][1]})" for k in new))

    def test_the_baseline_is_not_stale_in_the_other_direction(self):
        """A baselined entry that no longer trips the scanner should be removed.

        Without this the baseline only ever grows, and a member fixed today is
        still excused tomorrow under a name nobody re-checks.

        This is what retired the twenty `ChamsModule.h|ColorpickerValue|*` lines
        in 2026-10-15. They were never defects: `class ColorpickerValue;` sits
        above `class ChamsModule : Module` in that header, the scanner took the
        first class keyword as the name of the body it was scanning, found no
        `ColorpickerValue(...)` constructor, and reported every one of ChamsModule's
        constructor-initialised config pointers as indeterminate -- which someone
        then correctly, if wrongly, baselined. Fixing the scanner made them stop
        tripping, and this test says a baselined name that no longer exists is not
        a thing that should be carried forward.
        """
        stale = sorted(baseline_keys() - set(findings()))
        self.assertEqual(
            stale, [],
            "baseline entries that no longer trip the scanner -- remove them, so "
            "the list stays the set of things actually outstanding:\n  "
            + "\n  ".join(stale))

    def test_the_baseline_and_the_scan_both_have_content(self):
        """Both sides must be non-empty, and the baseline well-formed.

        The two ways a ratchet rots: a vacuous one (allow everything) and a
        frozen one (the scan finds nothing, so the baseline records nothing).
        This asserts the scan and the baseline agree that debt exists and that
        every key is in the `file|Class|member` shape the gate compares on -- a
        key with a stray `|` would make `set(found) - baseline` permanently
        non-empty for a reason that has nothing to do with a defect.
        """
        found = findings()
        keys = baseline_keys()
        self.assertTrue(found, "the scanner found nothing at all -- it may be broken")
        self.assertTrue(keys, "the baseline is empty while the scan reports "
                              f"{len(found)}; one of them is wrong")
        for k in sorted(keys):
            parts = k.split("|")
            self.assertEqual(
                len(parts), 3,
                f"malformed baseline key {k!r}; expected file|Class|member")
            self.assertRegex(parts[0], r"\.h$", f"baseline key {k!r} has no header path")

    # -- negative controls ------------------------------------------------

    def test_negative_control_an_injected_member_is_caught(self):
        """The scanner must see a real uninitialised member, or it checks nothing.

        Injected into a CONSTRUCTORLESS class on purpose. `AmmoHudModule` has a
        constructor and is exempt, so a canary placed there proves nothing -- which
        is exactly what the first version of this test did, and it failed red for
        the right reason (the rule was right, the control was wrong).
        """
        target = ROOT / "TarkovAddons" / "module" / "impl" / "IcebreakerScenarioModule.h"
        original = target.read_text(encoding="utf-8-sig")
        anchor = "    Il2CppString *cutscene_id;"
        self.assertNotIn("CANARY_UNINITIALISED", original,
                         "precondition: the canary is not already in the source")
        self.assertIn(anchor, original, "precondition: the anchor member moved")
        try:
            patched = original.replace(
                anchor, anchor + "\n    void* CANARY_UNINITIALISED;")
            self.assertNotEqual(patched, original, "could not inject the canary")
            target.write_text(patched, encoding="utf-8")
            found = findings()
        finally:
            target.write_text(original, encoding="utf-8")
        keys = [k for k in found if "CANARY_UNINITIALISED" in k]
        self.assertTrue(keys, "the scanner did NOT report an injected uninitialised "
                              "pointer member -- it is not checking anything")
        self.assertNotIn(keys[0], baseline_keys(),
                         "the canary was excused by the baseline, so the gate cannot fail")

    def test_negative_control_an_initialised_member_is_not_reported(self):
        """The other direction: `= nullptr` must NOT be reported."""
        target = ROOT / "TarkovAddons" / "module" / "impl" / "IcebreakerScenarioModule.h"
        original = target.read_text(encoding="utf-8-sig")
        anchor = "    Il2CppString *cutscene_id;"
        try:
            patched = original.replace(
                anchor, anchor + "\n    void* CANARY_INITIALISED = nullptr;")
            target.write_text(patched, encoding="utf-8")
            found = findings()
        finally:
            target.write_text(original, encoding="utf-8")
        self.assertFalse([k for k in found if "CANARY_INITIALISED" in k],
                         "a properly initialised member was reported; the rule is "
                         "matching on `T*` alone rather than on the initialiser")

    def test_the_constructor_exemption_is_actually_applied(self):
        """Real constructor-bearing classes must NOT be reported.

        This is the control for the rule's only judgement call -- "if the class has
        no constructor, nothing can initialise the member but the declaration".
        It deliberately does NOT assert on every constructor-bearing class in the
        tree, because the scanner's class-NAME attribution is unreliable when a
        class is conditionally compiled or preceded by an unbalanced construct --
        `ChamsModule`'s members come back labelled `ColorpickerValue`. Asserting
        on names would then test the naming, not the exemption. So this is a PAIRED
        control on one injected canary: same member, reported without a
        constructor and silent with one. That isolates the exemption exactly.

        The anchor is asserted before use. The first version anchored on
        `struct timeline_data {` -- the real declaration puts the brace on the NEXT
        line -- so the injection silently matched nothing and the "control" proved
        nothing while appearing to work.
        """
        target = ROOT / "TarkovAddons" / "module" / "impl" / "IcebreakerScenarioModule.h"
        original = target.read_text(encoding="utf-8-sig")
        decl = "struct timeline_data\n"
        self.assertIn(decl, original, "precondition: the struct declaration moved")
        anchor = "    Il2CppString *cutscene_id;"
        self.assertIn(anchor, original, "precondition: the anchor member moved")

        try:
            target.write_text(
                original.replace(anchor, anchor + "\n    void* CANARY_NOCTOR;"),
                encoding="utf-8")
            without = [k for k in findings() if "CANARY_NOCTOR" in k]
        finally:
            target.write_text(original, encoding="utf-8")
        self.assertTrue(without, "precondition: the constructorless canary was not "
                                 "reported, so the exemption proves nothing")

        try:
            target.write_text(
                original.replace(anchor, anchor + "\n    void* CANARY_NOCTOR;")
                         .replace(decl, decl + "{\n    timeline_data() {}", 1),
                encoding="utf-8")
            with_ctor = [k for k in findings() if "CANARY_NOCTOR" in k]
        finally:
            target.write_text(original, encoding="utf-8")
        self.assertEqual(
            with_ctor, [],
            "a class WITH a constructor was still reported; the exemption is not "
            "being applied, so the rule would demand initialisers that the "
            "constructor already provides")


if __name__ == "__main__":
    unittest.main()