"""The debug string inside a DBG_PRINTEXCEPTION_C is collected but never read.

`fill_head()` copies `ExceptionInformation[0..3]` into `Event::param` -- four
stores, at head time, no extra cost in the vectored handler. For `0xE06D7363`
(C++ exception) `emit_thrown_type()` decodes `param[]`. For `0x40010006`
(DBG_PRINTEXCEPTION_C) the payload is the string's *length* in `param[0]` and a
*pointer to the string* in `param[1]`, and nothing read them.

That order is measured, not assumed (2026-10-10): kernel32 raises
`{length, pointer}`, and both the emitter's comment and the cases below said
`{pointer, length}` until then. The note in `emit_debug_string` records the
measurement; the cases below hand the emitter the measured order.

Cost of that, from the session that died at 2026-10-05 23:45:06:

    0x40010006 DBG_PRINTEXCEPTION_C   x5476     <- second largest code
    0xE06D7363 C++ exception          x381
    0xC0000005 ACCESS_VIOLATION       x4        <- the one that killed it

The second most frequent thing in the session, described only by a count. The
text was in the ring the whole time. `tracy_bridge.h:101-102` even asserts the
source is Tracy's symbolizer failing, which cannot be right in a build with
`TRACY_CALLSTACK=0` -- imgui's `DefaultLogHandler` (`imgui.cpp:18079`) and
`TracyProfiler.cpp:329` call `OutputDebugStringA` too.

So this reads the string in the REPORT path only. The properties that matter,
and which no regex can check, are about what happens with hostile payloads:

  * a length the game made up, which is only ever allowed to LOWER the cap
  * a buffer that has been freed since -- the read must fail, not fault
  * bytes that are not text
  * a null payload

Those are control flow around a `__try` block, so they are run rather than
pattern-matched: the emitter is compiled out of the header and executed against
payloads chosen to break it.

Run:  python -m pytest tools\\tests\\test_crash_probe_debug_string.py -q
"""

import subprocess
import tempfile
import unittest
from pathlib import Path

try:
    from tools.tests.test_zone_site_expansion import msvc_env, find_vcvars64, find_cl
except ImportError:  # pytest may put tools/tests on sys.path instead
    from test_zone_site_expansion import msvc_env, find_vcvars64, find_cl

ROOT = Path(__file__).resolve().parents[2]
PROBE = ROOT / "TarkovAddons" / "util" / "crash_probe.h"
CAP = 256

# Substituted for the real emitter by the negative control. Everything else is
# identical, so any assertion that passes with the shipped emitter and fails with
# this one is really testing the emitter.
NOOP_EMITTER = """
static void emit_debug_string(const Event&) { }
"""


def probe_source(safe_read_bytes: str, emit_debug_string: str) -> str:
    return r"""
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cstdarg>
#include <atomic>
#include <windows.h>

// The file's variadic emit(); here it goes to stdout so the test can read what a
// report would have contained.
static void emit(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt);
    std::vfprintf(stdout, fmt, ap);
    va_end(ap);
    std::fputc('\n', stdout);
}

struct Event {
    std::atomic<uint32_t> ready{ 0 };
    uint32_t seq = 0;
    uint32_t code = 0;
    uint32_t flags = 0;
    uint32_t tid = 0;
    uintptr_t site = 0;
    uintptr_t sp = 0;
    uintptr_t param[4] = {};
    uint8_t nframes = 0;
    uint8_t ndata = 0;
    uint8_t nout = 0;
};

static constexpr int kMaxDebugString = __CAP__;

__SAFE_READ_BYTES__

__EMIT_DEBUG_STRING__

int main() {
    Event e;

    std::printf("CASE ordinary\n");
    e.code = 0x40010006u;
    e.param[0] = std::strlen("hello from OutputDebugString");
    e.param[1] = (uintptr_t)"hello from OutputDebugString";
    emit_debug_string(e);

    std::printf("CASE huge_length\n");
    {
        static char big[kMaxDebugString + 64];
        std::memset(big, 'A', sizeof(big));
        big[sizeof(big) - 1] = '\0';
        e.param[0] = 0x7FFFFFFFull;          // asks for 2 GB
        e.param[1] = (uintptr_t)big;
        emit_debug_string(e);
    }

    std::printf("CASE short_length\n");
    e.param[0] = 4;                          // includes the NUL, per MSDN
    e.param[1] = (uintptr_t)"abcdefghij";
    emit_debug_string(e);

    std::printf("CASE zero_length\n");
    e.param[0] = 0;
    e.param[1] = (uintptr_t)"zero length payload";
    emit_debug_string(e);

    std::printf("CASE null_payload\n");
    e.param[0] = 0;
    e.param[1] = 0;
    emit_debug_string(e);

    std::printf("CASE freed_buffer\n");
    {
        char* page = (char*)VirtualAlloc(nullptr, 4096, MEM_COMMIT | MEM_RESERVE,
                                         PAGE_READWRITE);
        std::memcpy(page, "gone", 5);
        VirtualFree(page, 0, MEM_RELEASE);    // genuinely unmapped now
        e.param[0] = 5;
        e.param[1] = (uintptr_t)page;
        emit_debug_string(e);
    }

    std::printf("CASE not_text\n");
    {
        static char raw[8] = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x00 };
        e.param[0] = 8;
        e.param[1] = (uintptr_t)raw;
        emit_debug_string(e);
    }

    std::printf("CASE other_code\n");
    e.code = 0xC0000005u;
    e.param[0] = 14;
    e.param[1] = (uintptr_t)"must not appear";
    emit_debug_string(e);

    std::printf("END\n");
    return 0;
}
""".replace("__CAP__", str(CAP)) \
   .replace("__SAFE_READ_BYTES__", safe_read_bytes) \
   .replace("__EMIT_DEBUG_STRING__", emit_debug_string)


def extract_fn(src, signature):
    start = src.find(signature)
    if start < 0:
        raise AssertionError(f"not found in {PROBE}: {signature!r}")
    open_at = src.find("{", start)
    depth, i, n = 0, open_at, len(src)
    while i < n:
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                return src[start: i + 1]
        i += 1
    raise AssertionError(f"unbalanced braces after {signature!r}")


class TestDebugStringIsRead(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        src = PROBE.read_text(encoding="utf-8-sig")
        cls.safe_read_bytes = extract_fn(src, "inline bool safe_read_bytes(")
        cls.emit_debug_string = extract_fn(src, "inline void emit_debug_string(")

    def run_probe(self, emitter=None):
        vcvars = find_vcvars64()
        if not vcvars:
            self.skipTest("no MSVC toolchain")
        src = probe_source(self.safe_read_bytes, emitter or self.emit_debug_string)
        with tempfile.TemporaryDirectory() as tmp:
            exe = Path(tmp) / "dbg.exe"
            cpp = exe.with_suffix(".cpp")
            cpp.write_text(src, encoding="utf-8")
            built = subprocess.run(
                [find_cl(msvc_env(vcvars)), "/nologo", "/EHsc", "/std:c++17", "/W3",
                 f"/Fe:{exe}", f"/Fo{exe.with_suffix('.obj')}", str(cpp)],
                capture_output=True, text=True, timeout=180, env=msvc_env(vcvars))
            if built.returncode != 0 or not exe.exists():
                self.fail(f"probe failed to compile:\n{built.stdout}\n{built.stderr}")
            run = subprocess.run([str(exe)], capture_output=True, text=True, timeout=60)
            return run.stdout

    def case(self, out, name):
        """The lines a single case emitted, so an assertion cannot be satisfied
        by output from a different case."""
        start = out.index(f"CASE {name}\n") + len(f"CASE {name}\n")
        rest = out[start:]
        end = rest.find("\nCASE ")
        if end < 0:
            end = rest.find("\nEND")
        return rest[:end if end >= 0 else len(rest)]

    def test_emitter_survives_hostile_payloads(self):
        out = self.run_probe()
        print(out)
        text = "hello from OutputDebugString"
        self.assertIn("END", out, "the probe did not run to completion")
        self.assertIn(f"debug string ({len(text)} byte(s)): {text}",
                      self.case(out, "ordinary"))
        self.assertIn("none (null payload)", self.case(out, "null_payload"))
        self.assertIn("no longer readable", self.case(out, "freed_buffer"),
                      "a freed buffer must be reported unreadable, not read")
        self.assertIn("not printable", self.case(out, "not_text"))
        self.assertNotIn("debug string", self.case(out, "other_code"),
                         "a code other than DBG_PRINTEXCEPTION_C was touched")
        # Zero length must not mean "empty string": fall back to the cap.
        self.assertIn("debug string", self.case(out, "zero_length"))

    def test_a_hostile_length_cannot_raise_the_cap(self):
        out = self.run_probe()
        huge = self.case(out, "huge_length")
        # The claimed length is reported, but as a CLAIM, and never as the number
        # of bytes shown -- printing "2147483647 byte(s)" beside 256 characters
        # is the one conclusion a report must not permit.
        self.assertIn(
            f"debug string (game said 2147483647 byte(s), showing {CAP}): {'A' * CAP}",
            huge)
        self.assertNotIn(f"({0x7FFFFFFF} byte(s))", huge,
                         "the game's claimed length was presented as the shown count")
        self.assertNotIn("A" * (CAP + 1), huge,
                         "more than kMaxDebugString bytes were emitted")
        # A real, shorter length is honoured, so "abcd" and not the whole buffer.
        self.assertIn("debug string (4 byte(s)): abcd", self.case(out, "short_length"))

    def test_emit_event_calls_it_inside_the_detailed_window(self):
        """Static wiring: the string must ride along with the frames, so a flood
        cannot become the report."""
        body = extract_fn(self.src_text(), "inline void emit_event(")
        self.assertIn("emit_debug_string(e);", body)
        self.assertLess(
            body.index("if (!with_frames) return;"),
            body.index("emit_debug_string(e);"),
            "emit_debug_string is called before the with_frames early-return, so "
            "all 24 ring entries would print their string and a 5,476-event flood "
            "would become the report")

    def test_negative_control_a_dead_emitter_fails_the_assertions(self):
        """With the emitter stubbed out, the assertions above must all fail.

        Without this, they could be passing because the probe never reaches the
        emitter at all.
        """
        out = self.run_probe(emitter=NOOP_EMITTER)
        print(out)
        self.assertIn("END", out, "the control probe did not run to completion")
        for name in ("ordinary", "huge_length", "short_length",
                     "null_payload", "freed_buffer", "not_text", "zero_length"):
            self.assertNotIn(
                "debug string", self.case(out, name),
                f"case {name} produced a debug-string line even with the emitter "
                "stubbed out, so the assertions cannot detect a dead emitter")

    @staticmethod
    def src_text():
        return PROBE.read_text(encoding="utf-8-sig")


if __name__ == "__main__":
    unittest.main()
