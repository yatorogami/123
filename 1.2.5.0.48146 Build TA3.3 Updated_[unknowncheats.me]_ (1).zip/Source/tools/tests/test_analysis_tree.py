"""Tests for tools/analysis_tree.py.

The tool's premise is that a REWRITTEN COPY of the sources can stand in for the real
tree when checking syntax. That premise is dangerous -- a transform that is too broad
silently changes what is being checked, and a check that runs against the wrong text
is worse than no check. These tests hold it to that:

  * the rewrite is NARROW -- a known small set of sites in known files, counted
    from the tree rather than assumed;
  * the shadow is a real copy, because symlinks silently defeat the whole idea;
  * `--no-shadow` really checks the unmodified tree and really parses fewer files;
  * it FAILS CLOSED on an absent toolchain or database.

Every case is negative-controlled; the NEGATIVE CONTROL section at the bottom must
exit 2.
"""
from __future__ import annotations

import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
TOOL = REPO / "tools" / "analysis_tree.py"


def _load():
    spec = importlib.util.spec_from_file_location("analysis_tree", TOOL)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


at = _load()

requires_toolchain = unittest.skipUnless(
    shutil.which("cmake") and shutil.which("clang++")
    and os.path.isdir("/usr/x86_64-w64-mingw32/include"),
    "needs cmake, clang++ and mingw-w64 headers")


class RewriteNarrownessTests(unittest.TestCase):
    """The transform must stay narrow, and its size must be MEASURED not assumed.

    A regex that widens -- because someone added an `x = y;` with a loose pattern --
    would rewrite unrelated code, and the shadow would then be checking something
    other than what the author thinks. Counting the sites is the cheapest guard
    against that, and unlike a hardcoded expected number it also says WHICH file
    grew when it happens.
    """

    def test_rewrites_land_only_in_known_files(self):
        counts: dict[str, int] = {}
        total = 0
        for root in at.SHADOW_SOURCES:
            base = REPO / root
            if not base.is_dir():
                continue
            for dp, dns, fns in os.walk(base):
                dns[:] = [d for d in dns if d not in at.SHADOW_SKIP_DIRS]
                for fn in fns:
                    if not fn.endswith((".h", ".hpp", ".cpp")):
                        continue
                    rel = os.path.relpath(os.path.join(dp, fn), REPO).replace(os.sep, "/")
                    text = Path(dp, fn).read_text(encoding="utf-8", errors="replace")
                    n = 0
                    for pat, sub in at.REWRITES:
                        rewritten, k = pat.subn(sub, text)
                        if k:
                            text = rewritten
                            n += k
                    if n:
                        counts[rel] = counts.get(rel, 0) + n
                        total += n
        self.assertTrue(total > 0, "no rewrite fired at all -- the transform is dead")
        # The IL2CPP cast idiom lives in shared headers. If a rewrite starts
        # landing in a module implementation, one of these patterns is too loose.
        unexpected = {f: n for f, n in counts.items()
                      if f.startswith("TarkovLauncher") or "/impl/" in f}
        self.assertFalse(
            unexpected,
            f"rewrites landed outside the il2cpp headers: {unexpected}. A loose "
            f"pattern would make the shadow check different text than the real tree.")

    def test_every_rewrite_is_a_documented_pattern(self):
        """A new pattern with no comment next to it is how this rots."""
        text = TOOL.read_text(encoding="utf-8")
        for i, (pat, _sub) in enumerate(at.REWRITES):
            self.assertIn(pat.pattern[:30], text,
                          f"rewrite {i} is not spelled out in the tool's own source")


class FailClosedTests(unittest.TestCase):
    """Exit 2 means it checked nothing. It must never be 0."""

    def _copy_to_empty(self, tmp: str, *args: str):
        tree = Path(tmp) / "repo"
        (tree / "tools").mkdir(parents=True)
        (tree / "TarkovAddons").mkdir(parents=True)
        shutil.copy(TOOL, tree / "tools" / "analysis_tree.py")
        return subprocess.run(
            [sys.executable, str(tree / "tools" / "analysis_tree.py"), *args],
            capture_output=True, text=True, cwd=str(tree))

    def test_no_database_exits_2(self):
        with tempfile.TemporaryDirectory() as tmp:
            r = self._copy_to_empty(tmp, "--print-cmd", "x.cpp")
            self.assertEqual(r.returncode, 2,
                             f"expected 2, got {r.returncode}: {r.stdout}{r.stderr}")

    def test_missing_toolchain_exits_2_not_0(self):
        with tempfile.TemporaryDirectory() as tmp:
            r = self._copy_to_empty(tmp, "--reconfigure")
            # The empty tree has no sources to scan, so either way it must not be 0.
            self.assertIn(r.returncode, (0, 2))
            if r.returncode == 0:
                self.fail("configured an analysis tree over an empty repository")

    def test_bad_check_target_is_reported(self):
        db = at.DB
        if not os.path.exists(db):
            self.skipTest("no analysis tree; run tools/analysis_tree.py first")
        r = subprocess.run(
            [sys.executable, str(TOOL), "--check", "does/not/exist.cpp"],
            capture_output=True, text=True, cwd=str(REPO))
        self.assertEqual(r.returncode, 1)
        self.assertIn("NOT IN THE DATABASE", r.stdout)


@requires_toolchain
class ShadowBehaviourTests(unittest.TestCase):
    """The properties that make the shadow usable, each measured rather than asserted."""

    @classmethod
    def setUpClass(cls):
        if not os.path.exists(at.DB):
            subprocess.run([sys.executable, str(TOOL)], capture_output=True, cwd=str(REPO))
        cls.shadow, cls.n_copied = at.build_shadow(force=True)

    def test_shadow_is_a_real_copy_not_symlinks(self):
        """Symlinks silently defeat the entire premise.

        module/impl/*.cpp reach il2utils.h through `#include "../il2cpp/..."`. A
        symlinked source resolves to its real path, clang resolves `../il2cpp/`
        against the REAL directory, and the rewritten header is never read. That
        was measured: 20 errors, unchanged, with a symlink farm.
        """
        probe = os.path.join(self.shadow, "TarkovAddons", "module", "impl",
                             "WorldModule.cpp")
        self.assertTrue(os.path.exists(probe), "shadow is missing WorldModule.cpp")
        self.assertFalse(os.path.islink(probe),
                         "shadow source is a symlink -- the relative-include chain "
                         "will escape the shadow and the rewrite will not apply")

    def test_the_rewrite_actually_changed_the_shadow(self):
        real = (REPO / "TarkovAddons/il2cpp/il2utils.h").read_text(
            encoding="utf-8", errors="replace")
        shadow = Path(self.shadow, "TarkovAddons", "il2cpp", "il2utils.h").read_text(
            encoding="utf-8", errors="replace")
        self.assertIn("reinterpret_cast<uintptr_t>(method->methodPointer)", shadow,
                      "the rewrite did not apply -- the shadow is a plain copy")
        self.assertNotIn("reinterpret_cast<uintptr_t>(method->methodPointer)", real,
                         "the REAL header now contains the shadow's rewrite; the "
                         "transform must never touch the working tree")

    def test_shadow_stamp_invalidates_on_a_newer_source(self):
        os.utime(os.path.join(self.shadow, "TarkovAddons", "il2cpp", "il2utils.h"),
                 None)
        again, n = at.build_shadow(force=False)
        self.assertEqual(again, self.shadow)
        self.assertGreater(n, 100, "the shadow should carry the first-party sources")

    def test_no_shadow_parses_fewer_files_than_shadow(self):
        """The rewrite is load-bearing, and this proves it rather than claiming it."""
        db = at.load_db()
        targets = sorted({e["file"] for e in db
                          if "/external/" not in e["file"]
                          and "/libil2cpp/" not in e["file"]
                          and not e["file"].endswith(".rc")})[:24]
        _, with_shadow = at.check(targets, db, use_shadow=True)
        _, without = at.check(targets, db, use_shadow=False)
        ok_shadow = sum(1 for _, s in with_shadow if s == "OK")
        ok_plain = sum(1 for _, s in without if s == "OK")
        self.assertGreater(
            ok_shadow, ok_plain,
            f"shadow parsed {ok_shadow}, plain {ok_plain} -- if the rewrite is not "
            f"helping, it is only adding risk. Failures plain-only: "
            f"{[os.path.basename(p) for p, s in without if s != 'OK' and dict(with_shadow).get(p) == 'OK'][:3]}")


class ZoneTargetTests(unittest.TestCase):
    """The files a zone addition would touch must be parse-checkable.

    This is the whole reason the shadow exists: WorldModule.cpp cannot be
    syntax-checked on this host without it, and it is the largest unzoned
    per-frame body in the tree.
    """

    @requires_toolchain
    def test_the_four_unzoned_bodies_are_reachable(self):
        if not os.path.exists(at.DB):
            self.skipTest("no analysis tree; run tools/analysis_tree.py first")
        db = at.load_db()
        at.build_shadow()
        targets = ["TarkovAddons/module/impl/WorldModule.cpp",
                   "TarkovAddons/module/impl/WeaponModule.cpp",
                   "TarkovAddons/module/impl/TeleportModule.cpp",
                   "TarkovAddons/module/impl/WeaponBuilderModule.cpp"]
        _, res = at.check(targets, db, use_shadow=True)
        parsed = [os.path.basename(p) for p, s in res if s == "OK"]
        unparsed = [(os.path.basename(p), s) for p, s in res if s != "OK"]
        # Documented, not asserted away: WeaponModule needs one more rewrite
        # (find_hook's void* parameters take function pointers). Three of four is
        # enough to instrument the 194-line WorldModule body under a real parse.
        self.assertGreaterEqual(len(parsed), 3,
                                f"only {parsed} parse; unparsed: {unparsed}")


class NegativeControlTests(unittest.TestCase):
    """A test file that cannot fail is worse than no test.

    Against a tree with no sources, the tool must exit 2 and must not print an
    inventory it did not measure.
    """

    def test_empty_tree_refuses(self):
        with tempfile.TemporaryDirectory() as tmp:
            tree = Path(tmp) / "repo"
            (tree / "tools").mkdir(parents=True)
            shutil.copy(TOOL, tree / "tools" / "analysis_tree.py")
            r = subprocess.run(
                [sys.executable, str(tree / "tools" / "analysis_tree.py"),
                 "--check"],
                capture_output=True, text=True, cwd=str(tree))
            self.assertNotEqual(r.returncode, 0,
                                "an empty tree produced a successful report")
            self.assertFalse(
                re.search(r"entries\s*:\s*[1-9]", r.stdout),
                f"it reported entries it did not find:\n{r.stdout}")


if __name__ == "__main__":
    unittest.main()