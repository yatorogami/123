"""tools/dup_scan.py -- the clone detector must actually detect clones.

Every case here has a negative control in the same file, because the failure
mode this tool has is not crashing, it is reporting a clean bill of health
because it lexed nothing. `audit_config_pointers.py` exits 2 for exactly that
reason and so does this.

The controls are written as *pairs*: a near-identical pair that must match and
a pair that differs in one token and must not. If the normalizer ever gets
looser, the "must not match" case is what catches it, and if it gets stricter,
the "must match" case is.
"""

import json
import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import dup_scan  # noqa: E402

REPO = Path(__file__).resolve().parents[2]


def run(tmp_path, *args):
    """Invoke the CLI on `tmp_path`.

    tmp_path is bound as a named parameter and MUST be spliced back into the
    argument list. The first version of this helper took `tmp_path` and then
    built the command from `*args` alone, so every case silently scanned the
    REPOSITORY instead of its fixture -- and three of them still passed, one of
    them `test_exit_2_when_nothing_was_checked`, which was asserting "exit 2
    means I checked nothing" against a run that had checked 174 files and found
    365 clones. A test that passes for the wrong reason is worse than no test.
    """
    cmd = [
        sys.executable,
        str(REPO / "tools" / "dup_scan.py"),
        str(tmp_path),
        *[str(a) for a in args],
    ]
    return subprocess.run(cmd, capture_output=True, text=True)


# ---------------------------------------------------------------------------
# Tokenizer
# ---------------------------------------------------------------------------


def test_comments_are_dropped():
    a = dup_scan.tokenize("int x = 1; // trailing\n")
    b = dup_scan.tokenize("int /* inline */ x = 1; /* block\nspans lines */\n")
    assert [t for t, _ in a] == [t for t, _ in b]


def test_literals_normalize_but_identifiers_do_not():
    toks = [t for t, _ in dup_scan.tokenize('const char* s = "hello";')]
    assert "STR" in toks and "hello" not in toks
    assert "s" in toks


def test_numeric_literal_forms_collapse_together():
    forms = ["0x40", "64", "64.0f", "0b1000000"]
    sets = [[t for t, _ in dup_scan.tokenize(f"auto v = {f};")] for f in forms]
    assert all(s == sets[0] for s in sets), dict(zip(forms, sets))


def test_renamed_mode_erases_identifiers_but_keeps_keywords():
    a = [t for t, _ in dup_scan.tokenize("int alpha = 1; return alpha;", renamed=True)]
    b = [t for t, _ in dup_scan.tokenize("int beta = 1; return beta;", renamed=True)]
    c = [t for t, _ in dup_scan.tokenize("int alpha = 1; return alpha;", renamed=False)]
    assert a == b
    assert a.count("ID") == 2, a
    assert c != [t for t, _ in dup_scan.tokenize("int beta = 1; return beta;")]


def test_directive_condition_is_dropped_but_directive_name_kept():
    a = [t for t, _ in dup_scan.tokenize("#ifdef ALPHA\nint x;\n#endif\n")]
    b = [t for t, _ in dup_scan.tokenize("#ifdef BETA\nint x;\n#endif\n")]
    assert a == b, a
    assert a == ["#PP:IFDEF", "int", "x", ";", "#PP:ENDIF"], a


def test_multiline_directive_is_one_token():
    """`#define FOO(a) \\` + continuation must not leak the body as identifiers."""
    toks = [t for t, _ in dup_scan.tokenize("#define FOO(a) \\\n  do { a; } while (0)\nint y;\n")]
    assert toks == ["#PP:DEFINE", "int", "y", ";"], toks


def test_a_hash_that_does_not_open_a_line_is_not_a_directive():
    toks = [t for t, _ in dup_scan.tokenize("int x = 1; # 42\n")]
    assert "#PP:" not in "".join(toks)
    assert "#" in toks


# ---------------------------------------------------------------------------
# Detection -- each pair is a positive and its own negative control
# ---------------------------------------------------------------------------

BODY = """
    Il2CppObject* obj = list->m_p_list_array;
    if (!obj) { return 0; }
    int total = 0;
    for (int i = 0; i < static_cast<int>(obj->max_length); ++i) {
        Il2CppObject* e = reinterpret_cast<Il2CppObject**>(&obj->data)[i];
        if (!e) { continue; }
        Il2CppInstance inst(e);
        total += inst.get_field<int>("value");
    }
    return total;
"""


def write(tmp_path, name, text):
    p = tmp_path / name
    p.write_text(text, encoding="utf-8")
    return p


def _body_tokens(tmp_path):
    return {
        "a.cpp": dup_scan.tokenize(write(tmp_path, "a.cpp", "int f_a(){" + BODY + "}").read_text()),
        "b.cpp": dup_scan.tokenize(write(tmp_path, "b.cpp", "int f_b(){" + BODY + "}").read_text()),
    }


def test_identical_bodies_are_found(tmp_path):
    clones, oversized = dup_scan.find_clones(_body_tokens(tmp_path), window=25)
    assert clones, "identical bodies were not detected"
    assert oversized == []
    assert clones[0][4] >= 25


def test_one_changed_token_breaks_the_clone(tmp_path):
    """The negative control for the case above.

    A single `++i` -> `--i` must not be *inside* any reported run. Asserting
    "no clone at all" is the wrong control: the body is longer than the window,
    so the parts either side of the change legitimately still match. What must
    not happen is a reported run that spans the difference -- which is exactly
    what a matcher coarser than tokens, or a hash never verified, would produce.
    """
    a_src = "int f_a(){" + BODY + "}"
    b_src = "int f_b(){" + BODY.replace("++i", "--i") + "}"
    toks = {
        "a.cpp": dup_scan.tokenize(a_src),
        "b.cpp": dup_scan.tokenize(b_src),
    }
    changed_a = next(i for i, (t, _) in enumerate(toks["a.cpp"]) if t == "++")
    changed_b = next(i for i, (t, _) in enumerate(toks["b.cpp"]) if t == "--")

    clones, _ = dup_scan.find_clones(toks, window=25)
    assert clones, "positive control failed -- this test would pass vacuously"
    for fa, sa, fb, sb, ln in clones:
        if fa == "a.cpp":
            spans_a, spans_b = sa <= changed_a < sa + ln, sb <= changed_b < sb + ln
        else:
            spans_a, spans_b = sa <= changed_b < sa + ln, sb <= changed_a < sb + ln
        assert not (spans_a and spans_b), (
            "a reported clone covers the one token that differs; the matcher is "
            "coarser than tokens or the hash was never verified"
        )


def _recheck(per_file, clone):
    """Independently confirm a reported clone. Does not call the tool's own code."""
    fa, sa, fb, sb, ln = clone
    ta = [t for t, _ in per_file[fa]]
    tb = [t for t, _ in per_file[fb]]
    return ta[sa : sa + ln] == tb[sb : sb + ln]


def test_every_reported_clone_is_token_equal(tmp_path):
    """The invariant the whole tool rests on: nothing is reported that was not
    re-read and found equal.

    Verified here from the token lists directly rather than by calling the
    tool's comparison helper, so the check cannot be satisfied by the same
    buggy line it is meant to police.
    """
    per_file = _body_tokens(tmp_path)
    clones, _ = dup_scan.find_clones(per_file, window=25)
    assert clones, "positive control failed -- this would pass vacuously"
    for c in clones:
        assert _recheck(per_file, c), f"reported a clone that is not equal: {c}"


def test_forced_hash_collision_cannot_invent_a_clone(tmp_path):
    """A hash is a bucket key, never evidence.

    `_MASK` is shrunk to 2**8 so that nearly every window shares a bucket. With
    the exact re-check in place the result must be byte-identical to the
    un-collided run. An earlier version of this test asserted only that, and it
    PASSED with the verification deleted -- the spurious short clones were all
    absorbed by the overlap filter, so equality of the output proved nothing.
    This version asserts the property that actually distinguishes the two: the
    colliding run's clones must still all be genuinely token-equal.

    The fixture is deliberately arranged so spurious matches cannot hide
    behind the real one -- one short duplicated region, pushed to opposite
    ends of two files that differ everywhere else.
    """
    dup = "".join(f"int shared_{i} = value_{i} + {i};\n" for i in range(12))
    uniq_a = "".join(f"int only_in_alpha_{i} = alpha_{i} * 2;\n" for i in range(40))
    uniq_b = "".join(f"int only_in_beta_{i} = beta_{i} * 3;\n" for i in range(40))
    per_file = {
        "a.cpp": dup_scan.tokenize(write(tmp_path, "a.cpp", uniq_a + dup).read_text()),
        "b.cpp": dup_scan.tokenize(write(tmp_path, "b.cpp", uniq_b + dup).read_text()),
    }

    exact, _ = dup_scan.find_clones(per_file, window=25)
    assert exact, "positive control failed"

    saved_mask, saved_poly = dup_scan._MASK, dup_scan._POLY
    try:
        dup_scan._MASK = (1 << 8) - 1
        dup_scan._POLY = 3
        collided, _ = dup_scan.find_clones(per_file, window=25)
    finally:
        dup_scan._MASK, dup_scan._POLY = saved_mask, saved_poly

    assert collided, "the colliding run found nothing at all; the control is broken"
    for c in collided:
        assert _recheck(per_file, c), (
            "a clone invented by a hash collision was reported as a finding: %r" % (c,)
        )


# ---------------------------------------------------------------------------
# Data tables are separated from code
# ---------------------------------------------------------------------------


def test_numeric_table_is_classified_as_data_not_code(tmp_path):
    """The false positive that forced the classification to exist.

    WorldModule.h's 90-line `spawn_bot_roles_[]` was reported as the largest
    clone in the whole tree until this rule was added: every entry lexes to
    the same `NUM , } , { NUM ,` once comments are gone, so the array matches
    itself and wins.
    """
    table = "static constexpr int roles[] = {\n" + "".join(
        f"    {i}, // role\n" for i in range(60)
    ) + "};\n"
    toks = {"t.h": dup_scan.tokenize(table)}
    run_start = next(
        i for i, (t, _) in enumerate(toks["t.h"]) if t == "roles"
    )
    assert dup_scan._is_data_table(toks["t.h"], run_start, len(toks["t.h"]) - run_start)


def test_real_code_is_not_misclassified_as_data(tmp_path):
    toks = dup_scan.tokenize("int f(){ if (x) { return g(y); } return 0; }")
    assert not dup_scan._is_data_table(toks, 0, len(toks))


# ---------------------------------------------------------------------------
# Walk / skip rules
# ---------------------------------------------------------------------------


def test_vendored_and_data_files_are_skipped_and_counted(tmp_path):
    for rel in (
        "external/imgui/imgui.h",
        "il2cpp/libil2cpp/il2cpp-api-types.h",
        "include/common.h",
        "gui/menu/resources.h",
        "assets/asset_bundles.h",
        "module/impl/Real.cpp",
    ):
        p = tmp_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("int x;\n", encoding="utf-8")
    files, skipped = dup_scan.iter_sources([tmp_path])
    names = {p.name for p in files}
    assert names == {"Real.cpp"}, names
    reasons = " | ".join(skipped)
    for want in ("external", "libil2cpp", "include", "resources.h", "asset_bundles.h"):
        assert want in reasons, f"{want} was skipped but not reported: {reasons}"


def test_same_file_reached_by_two_roots_is_scanned_once(tmp_path):
    write(tmp_path, "a.cpp", BODY)
    files, _ = dup_scan.iter_sources([tmp_path, tmp_path / "a.cpp"])
    assert len(files) == 1, [f.name for f in files]


# ---------------------------------------------------------------------------
# Exit codes
# ---------------------------------------------------------------------------


def test_exit_1_on_duplication(tmp_path):
    write(tmp_path, "a.cpp", "int f_a(){" + BODY + "}")
    write(tmp_path, "b.cpp", "int f_b(){" + BODY + "}")
    r = run(tmp_path, "--min-lines", "5", "--window", "25")
    assert r.returncode == 1, r.stdout + r.stderr


def test_exit_0_when_clean(tmp_path):
    write(tmp_path, "a.cpp", "int f_a(){" + BODY + "}")
    write(tmp_path, "b.cpp", "int g(int z){ return z * 3 + 1; }")
    r = run(tmp_path, "--min-lines", "5", "--window", "25")
    assert r.returncode == 0, r.stdout + r.stderr


def test_exit_2_when_nothing_was_checked(tmp_path):
    """A checker that reports success because it looked at nothing.

    Same contract as audit_config_pointers.py: 2 is neither clean nor dirty,
    it is "this run proved nothing", and it must never be normalized to 0.
    """
    (tmp_path / "empty.cpp").write_text("", encoding="utf-8")
    r = run(tmp_path, "--window", "25")
    assert r.returncode == 2, r.stdout + r.stderr
    assert "nothing was checked" in r.stderr.lower()


def test_exit_2_on_a_root_that_does_not_exist(tmp_path):
    r = run(tmp_path, tmp_path / "no-such-dir")
    assert r.returncode == 2, r.stdout + r.stderr


def test_json_output_separates_code_from_data(tmp_path):
    write(tmp_path, "a.cpp", "int f_a(){" + BODY + "}")
    write(tmp_path, "b.cpp", "int f_b(){" + BODY + "}")
    r = run(tmp_path, "--min-lines", "5", "--window", "25", "--format", "json")
    assert r.returncode == 1
    payload = json.loads(r.stdout)
    assert payload["code_clones"] >= 1
    assert payload["files_scanned"] == 2
    assert payload["tokens"] > 0


# ---------------------------------------------------------------------------
# It agrees with the tree it is pointed at
# ---------------------------------------------------------------------------


def test_the_real_tree_is_scanned_at_a_meaningful_size():
    """Guards against the skip lists quietly swallowing the project.

    The token count is taken from the first 40 files *sorted by path*, which is
    what iter_sources returns. Those are the small ones -- config/*.cpp and
    friends -- and they lex to ~23k tokens. The whole first-party set is
    185 files / ~414k tokens, checked by the pytest below rather than here,
    because tokenizing all of it costs about 4 s and this suite has no
    business paying that on every run.
    """
    files, skipped = dup_scan.iter_sources([REPO / r for r in dup_scan.DEFAULT_ROOTS])
    assert len(files) >= 120, f"only {len(files)} first-party files survived the skip lists"
    assert skipped, "nothing was skipped at all -- the skip lists are not being applied"
    total = sum(len(dup_scan.tokenize(f.read_text(errors="replace"))) for f in files[:40])
    # The floor was 25,000 until 2026-10-12, when the menu quick-jump
    # work landed two headers that sort early enough to push larger
    # files out of the first 40; the measured total is now 23,350. A
    # floor nobody re-derives is the failure this file argues against,
    # so it now sits 15% under the measured figure -- still far above
    # "the lexer is dead", which is all it is for.
    assert total > 20_000, f"only {total} tokens in the first 40 files; the lexer may be dead"


@pytest.mark.slow
def test_the_whole_first_party_tree_meets_the_documented_scale():
    """The numbers quoted in dup_scan.py's docstring and WORKFLOW.md.

    A count nobody measured is an assertion, not evidence, so the ones in the
    documentation are re-derived here rather than trusted. Measured
    2026-10-10: 177 first-party files found, 399,627 tokens across all of
    them, and 399,331 across the 167 that are large enough to compare at the
    default 50-token window. Both figures are checked because WORKFLOW.md
    quotes the second and the first is what the skip lists produce.

    Re-measured 2026-10-10 after container chams landed: 405,781 / 405,481.
    Re-measured 2026-10-11 after util/text_fold.h landed: 178 / 168 files,
    407,929 / 407,629 tokens.
    Re-measured 2026-10-11 after the AI-limit card moved into its own module:
    180 / 170 files, and the token bands widened by one measurement below.
    Re-measured 2026-10-11 after the ESP group separators and the item search's
    multi-select landed: 182 / 172 files, the three first-party additions being
    config/SeparatorValue.{h,cpp} and util/text_fold.h.
    Re-measured 2026-10-12 after module/survival_clamp.h landed: 183 / 173 files,
    410,553 / 410,253 tokens.
    Re-measured 2026-10-12 after the menu quick-jump work landed: 185 / 175
    files, 414,709 / 414,409 tokens. The two first-party additions are
    gui/menu/quick_search.h and gui/menu/hotkey_conflicts.h; the harness cases
    that cover them are outside DEFAULT_ROOTS, so they add no tokens here.
    Re-measured 2026-10-13 after module/material_catalogue.h landed: 186 / 176
    files, 416,988 / 416,688 tokens, and the bands widened by 2,000 at the top
    because the measured figures crossed the old 416,000 ceiling. The
    2,279-token rise is 1,151 from the new header plus 1,128 from its call site
    and comment in module/impl/ChamsModule.cpp. NOTE the header is a PROTOTYPE
    (its own first line says so, and tools/material_catalogue_route.md has it as
    step 1) -- deleting it removes one file and the ChamsModule.cpp lines, which
    puts this count back where it was. Re-measure rather than assume.
    Re-measured 2026-10-14 after gui/menu/changed_marker_layout.h landed (the
    changed-from-default gutter dot's geometry, split into its own header so
    tools/harness can compile it): 187 / 177 files, 419,939 / 419,639 tokens --
    a 2,951-token rise, nearly all of it the header's explanatory prose rather
    than logic. The bands did NOT need widening, but read the headroom before
    assuming they will not need it again: 419,939 against the 420,000 ceiling
    is 61 tokens, so the next header of any size crosses it.
    Re-measured 2026-10-14 after the map step-6 module landed (MapModule.cpp
    + MapModule.h) and the shared raster helper (util/raster_draw_common.h):
    190 / 180 files. Re-measured again the same day after the chams
    shader-property probe, the material catalogue's phase split and the
    quest all-cap slider: unchanged at 190 / 180 files, 423,151 / 422,851
    tokens -- the growth is all inside existing headers (unions, quest_esp,
    skeleton_visibility), none of them new. Both totals are now ABOVE the old
    422,000 ceiling by ~1-2k, so the bands widened to 420,000-428,000 rather
    than tracking the number upward each time it moves.
    Re-measured 2026-10-15: 191 / 181 files, 428,009 / 427,691 tokens, and the
    bands widened once more to 420,000-430,000 -- 428,009 sat 9 tokens under the
    old 428,000 ceiling. The file count moved by one and the totals by ~4.9k,
    which is another session's work rather than anything in the changelog edit
    this measurement was taken for; the point of recording it here is that the
    ceiling was crossed again almost immediately, which is the argument for
    widening by 2,000 rather than to the nearest 1k above the measurement.
    Re-measured 2026-10-15 after module/footprint.h landed (the mod's own
    footprint reporter): 191 / 181 files. One new header, and the growth is
    in there rather than in existing headers -- which is the point of the
    check, since a reporter that has to name its own coverage will keep
    growing and a silent total would just absorb it.
    """
    files, _ = dup_scan.iter_sources([REPO / r for r in dup_scan.DEFAULT_ROOTS])
    assert len(files) == 191, f"first-party file count moved: {len(files)} (measured 191)"
    counts = [len(dup_scan.tokenize(f.read_text(errors="replace"))) for f in files]

    # WIDENED AGAIN 2026-10-15, by 2,000. The band has now been crossed three
    # times, each almost immediately, and to the nearest 1k above a measurement
    # it would sit 392 tokens above the tree -- one more edit from firing again.
    #
    # Measured 430,408 over 191 files. Split so the number is attributable rather
    # than plausible: the Loot Teleporter container work landed mid-flight in the
    # shared tree (+1,787 tokens across WorldModule/LootTeleportModule/eft_api) and
    # the Quest POI completed-sweep is +142 NET over quest_esp.h and
    # EspModule.cpp, net because that change also DELETED the sweep's quest-book
    # walk -- the expensive thing. The split is re-derivable from a git diff; only
    # the total is pinned here.
    assert 420_000 < sum(counts) < 432_000, f"token count moved to {sum(counts):,}"
    comparable = [c for c in counts if c >= dup_scan.DEFAULT_WINDOW]
    assert len(comparable) == 181, f"comparable-file count moved to {len(comparable)}"
    assert 420_000 < sum(comparable) < 432_000, f"comparable token count moved to {sum(comparable):,}"


if __name__ == "__main__":  # pragma: no cover
    sys.exit(pytest.main([__file__, "-v"]))
