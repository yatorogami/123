"""The degenerate-origin exit must never report PENETRABLE. 2026-10-04.

THE BUG THIS EXISTS TO KEEP FIXED. `is_target_visible_penetrating` has an exit for
"the ray origin is effectively inside a mesh":

    if (hit.m_distance < 0.05f || unity::length(hit.m_normal) < 0.1f)
        return finish(stop_layer < 0, "origin effectively inside a mesh (...)");

`stop_layer < 0` asks whether a *layer* blocked the walk. It did not ask whether the
walk learned anything. Being inside a mesh is not evidence of a clear line, so on a
walk that had graded a layer and passed, this returned PENETRABLE.

The 23:14 Factory log, 2026-10-04, counted:

    82  records reaching this exit
    76  of them PENETRABLE

and **70 of the 82 happened while a grenade was in hands**, because the wall check ran
anyway with no round chambered (fixed in AimbotModule.cpp by gating the call on
`!hands_not_firearm`). Two independent defects, both required the fix: the meaningless
question being asked, and the unanswerable one being reported as a pass.

This is the same shape as the 2026-10-02 bug the source comment above `finish()`
already records -- 189 records once printed PENETRABLE through solid rock because each
branch's note was written assuming its own branch decided the outcome -- and as the
test bug in test_pen_layer_budget.py (0.52), which read a verdict out of a log's prose.
The notes are not the verdict. Neither is `stop_layer`.

WHY A SOURCE TEST AND NOT A LOG TEST. The log evidence is a snapshot of one session on
one map, and it is gone when the log rotates. What must hold is a property of the code:
this exit cannot return a pass. So the assertions are on the source, with comments
blanked -- otherwise the long comment now sitting above this exit would satisfy any
assertion made against the surrounding prose.
"""

from __future__ import annotations

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
VIS = ROOT / "TarkovAddons" / "module" / "skeleton_visibility.h"


def blank_comments(src: str) -> str:
    """Blank `//` and `/* */` comments, preserving length. String literals are KEPT.

    Comments must go or the explanatory block above this exit satisfies the very
    assertions meant to police it. Strings must stay because the string literal is how
    the exit is located in the first place.
    """
    out = list(src)
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == '"':  # skip the whole literal, honouring backslash escapes
            i += 1
            while i < n and src[i] != '"':
                i += 2 if src[i] == "\\" else 1
            i += 1
            continue
        if c == "/" and i + 1 < n and src[i + 1] == "/":
            j = src.find("\n", i)
            j = n if j < 0 else j
            for k in range(i, j):
                out[k] = " "
            i = j
        elif c == "/" and i + 1 < n and src[i + 1] == "*":
            j = src.find("*/", i + 2)
            j = n if j < 0 else j + 2
            for k in range(i, j):
                out[k] = " "
            i = j
        else:
            i += 1
    return "".join(out)


def degenerate_exit_region(code: str) -> str:
    """The body of the PEN walk's `origin effectively inside a mesh` exit.

    Located by the string literal, then extended backwards to the enclosing `if`.

    NOT located by `if (hit.m_distance < 0.05f`, because that test appears TWICE in
    this header: once in `is_target_visible` (the occlusion walk, which does
    `++g_vis_exit_counts()[vis_exit::inside_hit]; return true;`) and once in
    `is_target_visible_penetrating` (this one). A regex anchored on the test grabbed
    the occlusion copy on the first attempt and spanned 300 lines to the pen walk's
    literal, which would have satisfied every assertion below with the wrong code.

    So the literal is the anchor and the last matching `if` before it is the start.
    """
    lit = code.find('"origin effectively inside a mesh')
    if lit < 0:
        raise AssertionError(
            "the degenerate-origin note string was not found. If the exit was renamed "
            "or removed, delete this test rather than loosening it -- a test that "
            "cannot find its subject is not a test."
        )
    starts = [m.start() for m in re.finditer(r"if\s*\(\s*hit\.m_distance\s*<\s*0\.05f", code[:lit])]
    if not starts:
        raise AssertionError(
            "found the degenerate-origin note but no enclosing `if (hit.m_distance < "
            "0.05f` before it; the exit was restructured and this test no longer knows "
            "which code it governs"
        )
    start = starts[-1]
    end = code.find(";", lit)
    return code[start : end + 1]


class TestDegenerateOriginCannotPass(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = VIS.read_text(encoding="utf-8", errors="replace")
        cls.code = blank_comments(cls.raw)
        cls.region = degenerate_exit_region(cls.code)

    def test_exit_records_a_stop_before_it_finishes(self):
        """The stop must be recorded, and recorded BEFORE the finish.

        Order matters as much as presence: `finish()` reads the current stop to build
        both the verdict and the tally, so a record_stop after it would be counted for
        the next call and never for this one.
        """
        self.assertRegex(
            self.region,
            r"record_stop\s*\([^;]*?pen_stop::origin_in_mesh",
            "the degenerate-origin exit no longer records pen_stop::origin_in_mesh, so "
            "stop_layer stays -1 and finish(stop_layer < 0, ...) reports PENETRABLE for "
            "a walk that never verified anything (76 of 82 uses on 2026-10-04)",
        )
        stop_at = self.region.index("record_stop")
        finish_at = self.region.index("finish")
        self.assertLess(
            stop_at,
            finish_at,
            "record_stop comes after finish() at the degenerate-origin exit; finish() "
            "reads the stop to build the verdict, so the stop must be recorded first",
        )

    def test_exit_cannot_return_penetrable(self):
        self.assertRegex(
            self.region,
            r"return\s+finish\s*\(\s*false\s*,",
            "the degenerate-origin exit returns something other than finish(false, ...). "
            "Being inside a mesh is not a clear line; if this passes on stop_layer < 0 "
            "again it will report a pass the walk never verified",
        )
        self.assertNotRegex(
            self.region,
            r"return\s+finish\s*\(\s*stop_layer",
            "the degenerate-origin exit derives its verdict from stop_layer again. That "
            "asks whether a LAYER blocked, which is not what stopped this walk",
        )

    def test_origin_in_mesh_is_in_the_closed_stop_set(self):
        """The tally is only trustworthy if the enum and its name table agree.

        `kPenStopCount` is derived from `pen_stop::COUNT`, and the report prints
        `pen_stop_name`. A code counted but not named prints as "?", which would hide
        exactly the bucket this change is meant to make visible.
        """
        enum = re.search(r"enum class pen_stop\s*:\s*int\s*\{(.*?)\}", self.code, re.S)
        self.assertIsNotNone(enum, "pen_stop enum not found")
        self.assertIn("origin_in_mesh", enum.group(1))
        self.assertLess(
            enum.group(1).index("origin_in_mesh"),
            enum.group(1).index("COUNT"),
            "origin_in_mesh must be declared BEFORE COUNT or the closed set is broken",
        )
        table = re.search(r"inline const char\* pen_stop_name\(pen_stop s\)\s*\{(.*?)\n    \}", self.code, re.S)
        self.assertIsNotNone(table, "pen_stop_name not found")
        self.assertRegex(table.group(1), r"case\s+pen_stop::origin_in_mesh\s*:\s*return")

    def test_every_enum_member_has_a_name(self):
        """Generalises the above: no code may be counted without a name.

        Cheaper to state once than to re-derive each time a bucket is added, and it is
        the property that makes the `[closed]` marker on the report line meaningful.
        """
        enum = re.search(r"enum class pen_stop\s*:\s*int\s*\{(.*?)\}", self.code, re.S)
        table = re.search(r"inline const char\* pen_stop_name\(pen_stop s\)\s*\{(.*?)\n    \}", self.code, re.S)
        members = [
            m.group(1)
            for m in re.finditer(r"^\s*(\w+)\s*,", enum.group(1), re.M)
            if m.group(1) not in ("COUNT",)
        ]
        self.assertTrue(members)
        for name in members:
            self.assertRegex(
                table.group(1),
                r"case\s+pen_stop::%s\s*:" % re.escape(name),
                f"pen_stop::{name} has no case in pen_stop_name, so it would be counted "
                f"in the tally and reported as '?'",
            )


if __name__ == "__main__":
    unittest.main()