"""Text test for the two counter-throttle defects the 2026-10-04 profile exposed.

Both are the same mistake in two places, and both are invisible in review because
the code LOOKS guarded:

  * `maybe_report_native_object_memo()` early-returns unless 30 s have elapsed, so a
    reader concludes it is cheap -- but it takes `std::format` ARGUMENTS, and those are
    evaluated at the call site on every invocation. The guard is inside the callee; the
    cost is at the caller.
  * `maybe_report_camera_choice()` reads three live counters with `.load()`, computes
    `sum` from them, and only clears them at the END of the function. On a second
    thread that is a torn read, so `[MISMATCH]` fires on a race in the reporter rather
    than on a missing count.

WHY A TEXT TEST IS THE RIGHT TOOL HERE
--------------------------------------
Both are statements about *where a statement sits relative to a guard*, and neither is
observable without attaching a profiler and racing two threads. The instrumented build
already told us the cost; what the text test protects is the fix surviving the next
edit. `test_tracy_start_order.py` in this directory does the same for the same reason.

Kept honest by:
  * comments and string literals blanked before matching, so this file's own prose --
    which names every symbol -- cannot satisfy an assertion as text;
  * negative controls that re-introduce each defect and MUST fail.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

UNITY = (
    Path(__file__).resolve().parents[2] / "TarkovAddons" / "il2cpp" / "unity.h"
)
API = (
    Path(__file__).resolve().parents[2] / "TarkovAddons" / "module" / "eft_api.h"
)

_COMMENTS_AND_LITERALS = re.compile(
    r'"(?:\\.|[^"\\])*"'
    r"|'(?:\\.|[^'\\])*'"
    r"|/\*.*?\*/"
    r"|//[^\n]*",
    re.DOTALL,
)


def code_only(text: str) -> str:
    out, pos = [], 0
    for m in _COMMENTS_AND_LITERALS.finditer(text):
        out.append(text[pos:m.start()])
        out.append(" " * (m.end() - m.start()))
        pos = m.end()
    out.append(text[pos:])
    return "".join(out)


def function_body(src: str, name: str) -> str:
    code = code_only(src)
    m = re.search(r"\b" + re.escape(name) + r"\s*\([^;{]*\)\s*\{", code)
    if not m:
        pytest.fail(f"{name}() definition not found")
    start = m.end() - 1
    depth = 0
    for i in range(start, len(code)):
        if code[i] == "{":
            depth += 1
        elif code[i] == "}":
            depth -= 1
            if depth == 0:
                return code[start + 1:i]
    pytest.fail(f"{name}() braces unbalanced")


# --------------------------------------------------------------------------
# PART 1 -- the liveness memo's reporting throttle
# --------------------------------------------------------------------------

def assert_liveness_throttle(unity_src: str) -> None:
    body = function_body(unity_src, "is_unity_object_alive")

    # Both return paths -- the memo HIT and the post-syscall store -- must gate the
    # report on a cheap counter. The hit path is the one that mattered: 140,875 calls
    # at a measured 460 us each, against a 98% memo hit rate.
    gated = re.findall(
        r"if\s*\(\s*\(\s*st\.(?:hits|misses)\s*%\s*kReportEvery\s*\)\s*==\s*0\s*\)\s*"
        r"maybe_report_native_object_memo\s*\(\s*\)",
        body,
    )
    assert len(gated) >= 2, (
        f"maybe_report_native_object_memo() is called from only {len(gated)} place(s); "
        "both the memo-hit and post-syscall paths need a caller-side counter gate. "
        "The callee's 30 s check does not help: std::format's arguments are evaluated "
        "at the call site, so the cost is paid on every call regardless."
    )

    # An UNGUARDED call is the specific regression. There must be no bare call left.
    bare = re.findall(r"^\s*maybe_report_native_object_memo\s*\(\s*\)\s*;", body, re.M)
    assert not bare, (
        "maybe_report_native_object_memo() is called unguarded -- this is the 460 us "
        "per call"
    )

    # The gate must be a MODULO on a counter already being incremented, not a clock
    # read: the whole point is that it costs no syscall and no chrono.
    assert re.search(r"kReportEvery\s*=\s*\d+", body), (
        "the gate modulus is not a named constant, so the cadence cannot be read "
        "without counting"
    )
    for mm in re.finditer(r"if\s*\(\s*\(\s*st\.(hits|misses)\s*%", body):
        counter = mm.group(1)
        assert re.search(rf"st\.{counter}\s*\+=\s*1", body), (
            f"the gate reads st.{counter} but nothing increments it, so the report "
            "would never fire"
        )


def test_liveness_report_is_counter_gated():
    assert_liveness_throttle(UNITY.read_text(encoding="utf-8", errors="replace"))


def test_negative_control_unguarded_report_fails():
    """Re-introducing the bare call must fail. This is the shipped defect."""
    src = UNITY.read_text(encoding="utf-8", errors="replace")
    src = re.sub(
        r"if\s*\(\s*\(\s*st\.(?:hits|misses)\s*%\s*kReportEvery\s*\)\s*==\s*0\s*\)\s*",
        "",
        src,
    )
    with pytest.raises(AssertionError):
        assert_liveness_throttle(src)


# --------------------------------------------------------------------------
# PART 2 -- the camera-choice reporter's torn read
# --------------------------------------------------------------------------

def assert_camera_snapshot(api_src: str) -> None:
    body = function_body(api_src, "maybe_report_camera_choice")

    # The buckets must be taken with exchange(), which reads AND clears in one step.
    # `.load()` for the printed value is what made the sum a torn read.
    bucket = re.search(r"bucket\[kCamSourceCount\]", body)
    assert bucket, "no snapshot array for the source buckets"

    exchanges = len(
        re.findall(r"bucket\[i\]\s*=\s*c\[i\]\.exchange\s*\(", body)
    )
    assert exchanges >= 1, (
        "the buckets are not exchange()d -- a `.load()` leaves the window open between "
        "reading and clearing, and the aimbot resolves cameras from the game thread "
        "while this reporter runs on the render thread"
    )

    # No trailing clear. Re-zeroing after the snapshot discards resolves that landed in
    # between, which makes sum > resolves for real rather than by race.
    assert not re.search(r"c\[i\]\.store\s*\(\s*0", body), (
        "the buckets are cleared again after the snapshot -- that re-opens the exact "
        "window the exchange() was meant to close"
    )

    # Every printed bucket value must come from the snapshot, not a fresh read.
    #
    # Checked by ABSENCE of a live read rather than presence of a snapshot read: the
    # enum spellings differ (`fallback` in the log string, `current_fallback` in the
    # enum), so matching the printed form would encode a cosmetic detail and break the
    # next time a label is reworded. What must not exist is ANY `.load()` off the live
    # buckets -- that is the defect, and it has one shape.
    live_reads = re.findall(
        r"c\[\s*static_cast<int>\(cam_source::[a-z_]+\s*\)\s*\]\s*\.\s*load", body
    )
    assert not live_reads, (
        f"{len(live_reads)} live .load() off the source buckets remain -- the printed "
        "line and the [closed] check are describing different instants"
    )
    # And the snapshot must actually be printed: at least one bucket read by index.
    assert len(re.findall(r"std::to_string\(\s*bucket\[", body)) >= 3, (
        "fewer than three buckets are printed from the snapshot"
    )

    # `sum` must be computed from the snapshot.
    assert re.search(r"sum\s*\+=\s*bucket\[i\]", body), (
        "sum is not accumulated from the snapshot"
    )


def test_camera_report_is_a_consistent_snapshot():
    assert_camera_snapshot(API.read_text(encoding="utf-8", errors="replace"))


def test_negative_control_live_load_fails():
    """Re-introducing the `.load()` + trailing clear must fail."""
    src = API.read_text(encoding="utf-8", errors="replace")
    src = src.replace(
        "bucket[i] = c[i].exchange(0, std::memory_order_relaxed);",
        "bucket[i] = c[i].load(std::memory_order_relaxed);",
    )
    src = src.replace(
        "// No trailing clear: the buckets were already zeroed by the exchange() snapshot",
        "for (int i = 0; i < kCamSourceCount; ++i) c[i].store(0, std::memory_order_relaxed);\n"
        "        // No trailing clear: the buckets were already zeroed by the exchange() snapshot",
    )
    with pytest.raises(AssertionError):
        assert_camera_snapshot(src)


def test_source_buckets_are_retracted_through_one_helper():
    """`fetch_sub` on a live bucket must not appear outside the helper.

    The refuse path counts tentatively and then takes it back. A raw `fetch_sub` at a
    call site is how a bucket can be retracted twice for one resolve, which is what
    produced `sum > resolves`.
    """
    src = API.read_text(encoding="utf-8", errors="replace")
    code = code_only(src)

    helper = function_body(src, "retract_cam_source")
    assert "fetch_sub" in helper, (
        "retract_cam_source does not actually retract -- the name is doing the work"
    )

    # Every fetch_sub in the file must be inside that helper.
    subs = [m.start() for m in re.finditer(r"fetch_sub", code)]
    h_start = code.find("retract_cam_source")
    assert h_start != -1, "retract_cam_source is missing"
    h_body_start = code.index("{", h_start)
    depth, h_end = 0, None
    for i in range(h_body_start, len(code)):
        if code[i] == "{":
            depth += 1
        elif code[i] == "}":
            depth -= 1
            if depth == 0:
                h_end = i
                break
    inside = {p for p in subs if h_body_start < p < h_end}
    outside = [p for p in subs if p not in inside]
    assert not outside, (
        f"{len(outside)} fetch_sub call(s) exist outside retract_cam_source -- a direct "
        "retraction is what allowed one resolve to be retracted twice"
    )