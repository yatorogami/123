"""TA_ZONE_SITE must not introduce control flow.

`TA_ZONE_SITE(name, site)` (`util/tracy_bridge.h`) used to expand to

    for (const char* ta_zn = ::ta_detail::compose_site((name), (site)),
              *ta_zkeep = (tracy::profiler::Zone(...), nullptr);
         ta_zkeep == nullptr; ta_zkeep = nullptr)

`ta_zkeep` starts `nullptr`, the condition is `ta_zkeep == nullptr`, and the
increment assigns `nullptr` again, so the condition is true forever. It is a
plain infinite loop: no stack growth, no log line, and it spins whether or not
Tracy is running.

`skeleton_visibility.h:355` put the macro directly in front of the managed
`get_position` call, so `get_bifacial_position` never returned,
`try_get_fireport_position` never returned, and
`AimbotModule::gameworld_update` never returned -- on the GAME's world-update
thread. The thread spun at 100% of a core and the raid never finished loading.
Both of the captures taken while it was live show the signature:
`skeleton_vis::fireport:get_position@...` at 20 ns (the discarded `Zone`
temporary) and one completed `frame::AimbotModule::gameworld_update` against
6,778 `frame::hk_tarkov_application_update`.

The bug is in the *expansion*, not in the text a regex can reason about, so
this test compiles the shipped macro and runs it. Three properties:

  1. it terminates                        <- the regression itself
  2. the statements after it run once     <- a loop that swallowed the body
  3. the Zone is still OPEN afterwards    <- the span covers what it claims

A negative control compiles the OLD expansion and asserts it does NOT
terminate, so a passing test means the probe can actually see this bug.

Skipped, not failed, when no MSVC compiler is present -- see setUpClass.
"""

import os
import re
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BRIDGE = ROOT / "TarkovAddons" / "util" / "tracy_bridge.h"

# The expansion as it shipped on 2026-10-04. Kept verbatim so the negative
# control cannot drift away from the thing it is a control for.
OLD_EXPANSION = r"""
#define TA_ZONE_SITE(name, site)                                                  \
    for (const char* ta_zn = ::ta_detail::compose_site((name), (site)),           \
              *ta_zkeep = (tracy::profiler::Zone(TracyLine, TracyFile,             \
                  TracyFunction, ta_zn, ::strlen(ta_zn)), nullptr);               \
         ta_zkeep == nullptr; ta_zkeep = nullptr)
"""

# A verbatim copy of compose_site. The drift guard below fails if this stops
# matching the header, so the probe cannot quietly test a different helper than
# the one that ships.
COMPOSE_SITE_COPY = r"""
inline const char* compose_site(const char* name, const char* site) {
    static thread_local std::string buf;
    static thread_local const char* last_name = nullptr;
    static thread_local const char* last_site = nullptr;
    if (name != last_name || site != last_site) {
        buf.assign(name ? name : "");
        if (site && *site) { buf += '@'; buf += site; }
        last_name = name;
        last_site = site;
    }
    return buf.c_str();
}
"""

PROBE = r"""
#include <cstdio>
#include <cstring>
#include <string>

#define TracyLine __LINE__
#define TracyFile "probe.cpp"
#define TracyFunction "probe"

// Stand-in for tracy::profiler::Zone: records nesting and the name it was
// given, which is all three assertions need.
static int g_depth = 0;
static int g_max_depth = 0;
static int g_zone_calls = 0;
static std::string g_last_name;

namespace tracy { namespace profiler {
struct Zone {
    Zone(int, const char*, const char*, const char* name, std::size_t size) {
        ++g_zone_calls;
        ++g_depth;
        if (g_depth > g_max_depth) g_max_depth = g_depth;
        g_last_name.assign(name, size);
        std::printf("ENTER %s\n", g_last_name.c_str());
    }
    ~Zone() {
        --g_depth;
        std::printf("LEAVE %s\n", g_last_name.c_str());
    }
};
}} // namespace tracy::profiler

namespace ta_detail {
__COMPOSE_SITE__
} // namespace ta_detail

__MACRO__

int main() {
    const char* site = "aimbot/gameworld_update";
    int body_runs = 0;

    std::printf("MARK before\n");
    TA_ZONE_SITE("skeleton_vis::fireport:get_position", site);
    // These three lines are the ones the macro is written to measure. If the
    // expansion is a loop they either never run, or run forever.
    ++body_runs;
    std::printf("MARK inside depth=%d name=%s body_runs=%d\n",
                g_depth, g_last_name.c_str(), body_runs);
    ++body_runs;
    ++body_runs;
    std::printf("MARK after depth=%d name=%s body_runs=%d max_depth=%d calls=%d\n",
                g_depth, g_last_name.c_str(), body_runs, g_max_depth, g_zone_calls);
    return 0;
}
"""

TIMEOUT_S = 25


def extract_macro(header_text, macro="TA_ZONE_SITE"):
    """Return the macro's expansion exactly as written, continuations joined.

    Deliberately textual: the point is to test the bytes that ship, not a
    re-derivation of them.
    """
    start = header_text.find(f"#define {macro}(name, site)")
    if start < 0:
        raise AssertionError(f"{macro} not found in {BRIDGE}")
    lines = []
    for raw in header_text[start:].splitlines():
        lines.append(raw)
        if not raw.rstrip().endswith("\\"):
            break
    return "\n".join(lines)


def find_vcvars64():
    """Path to vcvars64.bat, or None. Clang/gcc are not accepted on purpose:
    the shipped project is MSVC and the macro relies on MSVC's `__LINE__` and
    two-declarations-in-a-row behaviour."""
    vswhere = Path(
        r"C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe"
    )
    if not vswhere.exists():
        return None
    out = subprocess.run(
        [str(vswhere), "-latest", "-products", "*", "-find",
         r"VC\Auxiliary\Build\vcvars64.bat"],
        capture_output=True, text=True,
    )
    found = out.stdout.strip().splitlines()
    return found[0] if found else None


def msvc_env(vcvars):
    """Environment produced by vcvars64.bat, as a dict.

    vcvars is invoked through a generated .bat rather than `cmd /c "<string>"`:
    the path contains spaces, and handing a spaced string to `cmd /c` as its own
    argv element re-quotes it and breaks the call. Having the env also lets
    cl.exe be run directly, so compiler diagnostics arrive on a real pipe
    instead of inside a cmd string.
    """
    with tempfile.TemporaryDirectory() as tmp:
        bat = Path(tmp) / "vcenv.bat"
        bat.write_text(f'@call "{vcvars}" >nul\r\n@set\r\n', encoding="ascii")
        out = subprocess.run(["cmd", "/c", str(bat)], capture_output=True,
                             text=True, timeout=180)
    env = {}
    for line in out.stdout.splitlines():
        if "=" in line:
            key, _, value = line.partition("=")
            env[key.strip()] = value
    return env


def find_cl(env):
    """cl.exe from the vcvars environment, or None."""
    path = env.get("PATH", "")
    for entry in path.split(os.pathsep):
        candidate = Path(entry.strip()) / "cl.exe"
        if candidate.exists():
            return str(candidate)
    return None


def _toolchain():
    """(vcvars, cl) if an MSVC toolchain is reachable, else (None, None).

    Resolved once at import: vcvars64.bat is slow and only the two tests that
    actually compile need it.
    """
    vcvars = find_vcvars64()
    if not vcvars:
        return None, None
    try:
        return vcvars, find_cl(msvc_env(vcvars))
    except (subprocess.SubprocessError, OSError):
        return vcvars, None


VCVARS, CL = _toolchain()
CL_OK = CL is not None


class TestZoneSiteExpands(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.header = BRIDGE.read_text(encoding="utf-8-sig")
        cls.macro = extract_macro(cls.header)
        cls.vcvars = VCVARS

    def compile_and_run(self, macro_text, timeout=TIMEOUT_S):
        """Compile PROBE with `macro_text` as TA_ZONE_SITE and run it.

        Returns (completed, stdout). `completed` is False on timeout -- which
        for the current expansion means the process had to be killed, and that
        IS the assertion for the negative control.
        """
        src = (PROBE
               .replace("__COMPOSE_SITE__", COMPOSE_SITE_COPY)
               .replace("__MACRO__", macro_text))
        with tempfile.TemporaryDirectory() as tmp:
            cpp = Path(tmp) / "probe.cpp"
            cpp.write_text(src, encoding="utf-8")
            exe = Path(tmp) / "probe.exe"
            build = subprocess.run(
                [CL, "/nologo", "/EHsc", "/std:c++17", "/W3",
                 f"/Fe:{exe}", f"/Fo{Path(tmp) / 'probe.obj'}", str(cpp)],
                capture_output=True, text=True, cwd=tmp, timeout=180,
                env=msvc_env(self.vcvars),
            )
            if build.returncode != 0 or not exe.exists():
                self.fail(
                    "probe failed to compile -- the macro under test does not "
                    f"compile:\n{build.stdout}\n{build.stderr}"
                )
            try:
                run = subprocess.run([str(exe)], capture_output=True, text=True,
                                     timeout=timeout)
            except subprocess.TimeoutExpired:
                return False, ""
            return True, run.stdout

    # -- the properties that matter -------------------------------------

    @unittest.skipUnless(CL_OK, "no MSVC cl.exe")
    def test_current_expansion_terminates_and_measures_the_body(self):
        completed, out = self.compile_and_run(self.macro)
        self.assertTrue(
            completed,
            "TA_ZONE_SITE did not terminate: the process was still spinning "
            f"after {TIMEOUT_S}s. This is the 2026-10-04 raid-load freeze -- "
            "the macro expands to a `for` whose condition cannot become false.",
        )
        self.assertIn("MARK after", out, "the probe did not run to completion")
        marks = [l for l in out.splitlines() if l.startswith("MARK ")]
        self.assertEqual(len(marks), 3, f"expected 3 MARK lines, got {marks}")
        self.assertTrue(marks[0].endswith("before"), marks[0])
        self.assertIn("body_runs=1", marks[1],
                      "the statement after TA_ZONE_SITE did not run exactly once")
        self.assertIn(
            "body_runs=3", marks[2],
            "the statements after TA_ZONE_SITE did not run exactly once",
        )
        self.assertIn(
            "depth=1", marks[1],
            "the Zone was already closed when the measured statements ran, so "
            "the span covers nothing",
        )
        self.assertIn(
            "name=skeleton_vis::fireport:get_position@aimbot/gameworld_update",
            marks[1],
            "the composed name is not `name@site`",
        )
        self.assertIn("calls=1", marks[2], "the Zone was constructed more than once")

    # -- guards on the guards --------------------------------------------

    def test_expansion_contains_no_loop(self):
        """The cheap static check, so the failure is obvious in CI even where
        no compiler exists to run the real one."""
        body = "\n".join(
            l for l in self.macro.splitlines() if not l.lstrip().startswith("//")
        )
        self.assertNotRegex(
            body, r"\bfor\s*\(",
            "TA_ZONE_SITE expands to a `for` statement again. A zone is a "
            "scoped object; if this macro needs control flow it is not a zone "
            "any more. See the history block above the macro.",
        )

    def test_expansion_declares_the_zone_as_a_plain_local(self):
        self.assertRegex(
            self.macro, r"tracy::profiler::Zone\s+ta_zsite",
            "TA_ZONE_SITE no longer binds the Zone to a named local",
        )
        self.assertNotIn("ta_zone", self.macro,
                         "TA_ZONE_SITE must not declare `ta_zone`, or it stops "
                         "being legal next to a TA_ZONE_N in the same scope")

    def test_compose_site_copy_in_this_probe_matches_the_header(self):
        """Keeps the probe honest: if compose_site changes, this fails loudly
        instead of the probe testing a stale helper."""
        self.assertIn(
            COMPOSE_SITE_COPY.strip(),
            self.header,
            "the copy of compose_site embedded in this test no longer matches "
            "util/tracy_bridge.h -- update COMPOSE_SITE_COPY",
        )

    @unittest.skipUnless(CL_OK, "no MSVC cl.exe")
    def test_negative_control_the_old_expansion_does_terminate_proof(self):
        """Compiles the shipped-broken expansion and asserts it hangs.

        Without this, a passing test above could just mean the probe cannot
        detect the bug it is guarding.
        """
        completed, _ = self.compile_and_run(OLD_EXPANSION, timeout=8)
        self.assertFalse(
            completed,
            "the OLD TA_ZONE_SITE expansion terminated -- so this probe "
            "cannot detect the bug it is guarding, and the positive test "
            "above proves nothing",
        )


if __name__ == "__main__":
    unittest.main()
