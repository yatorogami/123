"""`build.ps1 -Wait` must actually watch the first-party tree.

The -Wait gate exists for one reason, quoted from the script: "two agents editing
one header is how a build compiles a half-written file, and the symptom is a
C2065 pointing at a line inside a comment." Its watch list used to name five
files, `eft_api.h` was not among them, and on 2026-10-06 a -Wait build sailed
through the quiet window and failed with 136 errors, all in `module/eft_api.h`
(a stray `}` left mid-edit by a parallel session).

So the list is now derived from the tree. That makes it correct by construction,
and introduces a new way to be wrong silently: the filter variable is assigned
with a trailing `| Out-Null`, which assigns `$null`, so `-notmatch $null`
matches nothing and **every file is filtered out**. `-Wait` still runs, still
succeeds, and never waits for anything. A gate that cannot fail is worse than no
gate -- which is the habit this repo keeps getting bitten by, so it is checked
here rather than trusted.

Run:  python -m pytest tools\\tests\\test_build_wait_watchlist.py -q
"""

import re
import shutil
import subprocess
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BUILD = ROOT / "tools" / "build.ps1"

# The enumeration lifted out of build.ps1, anchored on the two ends of the
# pipeline, and run for real rather than pattern-matched.
ANCHOR_START = re.compile(r"^\s*\$skip\s*=")
ANCHOR_END = "Select-Object -ExpandProperty FullName"

# Files -Wait must cover. Chosen because each was either missed by the old
# curated list or is the exact file from the failure it was widened for.
#
# BACKSLASHES, not forward slashes. PowerShell reports these paths with `\`, so a
# pattern written as `il2cpp/unity.h` matches nothing and the test passes
# vacuously -- which is what happened on the first run of this file, for the
# exclusions below as well as for this entry.
MUST_INCLUDE = [
    "eft_api.h",            # the 136 errors on 2026-10-06
    "crash_probe.h",
    "skeleton_visibility.h",
    "il2cpp\\unity.h",
    "module\\impl\\AimbotModule.cpp",
    "dllmain.cpp",
]

# Trees that must NOT be watched, and why. out/ and x64/ change as a SIDE EFFECT
# of building (x64/ holds every agent's private IntDir), so watching them can
# never converge -- it would restart the quiet window forever.
MUST_EXCLUDE = ["\\out\\", "\\x64\\", "\\external\\", "\\GameDump\\"]


def powershell() -> str | None:
    return shutil.which("powershell") or shutil.which("pwsh")


class TestBuildWaitWatchList(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.src = BUILD.read_text(encoding="utf-8-sig")
        lines = cls.src.splitlines()
        start = next((i for i, l in enumerate(lines) if ANCHOR_START.match(l)), None)
        if start is None:
            raise AssertionError("no `$skip =` assignment found in tools/build.ps1")
        end = next((i for i in range(start, len(lines)) if ANCHOR_END in lines[i]), None)
        if end is None:
            raise AssertionError(f"no `{ANCHOR_END}` found after the -Wait block")
        cls.enumeration = "\n".join(lines[start: end + 1])

    def run_enumeration(self, enumeration=None):
        ps = powershell()
        if not ps:
            self.skipTest("no powershell/pwsh available")
        # `$shared` is the name build.ps1 itself uses. An earlier version of this
        # test read `$watched`, which is always $null here -- so the count came
        # back 0 and the exclude test came back all-False, and BOTH passed without
        # having evaluated anything. The variable name is part of the contract.
        script = (
            "Set-Location -LiteralPath "
            + str(ROOT).replace("'", "''")
            + "\n"
            + (enumeration if enumeration is not None else self.enumeration)
            + "\n$shared.Count\n"
            + "\n".join(f"[bool]($shared -match '{re.escape(n)}$')" for n in MUST_INCLUDE)
            + "\n"
            + "\n".join(f"[bool]($shared -match '{re.escape(n)}')" for n in MUST_EXCLUDE)
        )
        r = subprocess.run([ps, "-NoProfile", "-Command", script],
                           capture_output=True, text=True, timeout=180)
        if r.returncode != 0:
            raise AssertionError(f"enumeration failed:\n{r.stdout}\n{r.stderr}")
        lines = [l.strip() for l in r.stdout.strip().splitlines() if l.strip()]
        want = 1 + len(MUST_INCLUDE) + len(MUST_EXCLUDE)
        self.assertGreaterEqual(
            len(lines), want,
            f"enumeration printed {len(lines)} lines, want >= {want}\n{r.stdout}")
        return (int(lines[0]),
                [v == "True" for v in lines[1:1 + len(MUST_INCLUDE)]],
                [v == "True" for v in lines[1 + len(MUST_INCLUDE):want]])

    def test_skip_filter_is_assigned_a_pattern_not_a_pipeline(self):
        """The bug this file exists for.

        `$skip = '...' | Out-Null` assigns $null. `-notmatch $null` matches
        nothing, so every file is filtered out and -Wait watches nothing while
        still appearing to work.
        """
        assign = next(l for l in self.src.splitlines() if ANCHOR_START.match(l))
        self.assertNotIn(
            "Out-Null", assign,
            "$skip is assigned the result of a pipeline, so it is not the regex "
            "`-notmatch $skip` is meant to test. $skip becomes $null, every file "
            "is filtered out, and -Wait silently stops waiting. Drop the "
            "`| Out-Null`.",
        )
        self.assertRegex(assign.strip(), r"^\$skip\s*=\s*'.*\\\\.*'$",
                         "the $skip assignment does not look like a regex literal")

    def test_watchlist_covers_the_first_party_tree(self):
        count, included, _ = self.run_enumeration()
        self.assertGreater(
            count, 50,
            f"only {count} files are watched. A -Wait that watches a handful of "
            "files is the curated list this replaced; it has to be derived from "
            "the tree. (0 or near-0 usually means the filter variable is null.)")
        for name, ok in zip(MUST_INCLUDE, included):
            self.assertTrue(ok, f"tools/build.ps1 -Wait does not watch {name}")

    def test_watchlist_excludes_generated_and_vendored_trees(self):
        _, _, excluded = self.run_enumeration()
        for tree, present in zip(MUST_EXCLUDE, excluded):
            self.assertFalse(
                present,
                f"tools/build.ps1 -Wait watches {tree}. out/ and x64/ change as a "
                "SIDE EFFECT of building -- x64/ is where every agent's private "
                "IntDir lands -- so watching them can never converge.")

    def test_the_exclusion_patterns_can_match_at_all(self):
        """A guard on this file's own patterns.

        `\\out\\` and `/out/` both look right in source. Only one of them matches
        a PowerShell path, and the wrong one makes the exclusion test pass
        vacuously -- it asserts False and gets False because nothing matched, not
        because nothing is watched. This asserts the patterns are live by asking
        the same question about a string that DOES contain each tree.
        """
        count, _, excluded = self.run_enumeration()
        self.assertGreater(count, 0, "enumeration is empty; the rest is vacuous")
        ps = powershell()
        # A path that genuinely contains each tree, so the pattern is asked a
        # question it can answer yes to. Built by concatenation rather than
        # f-string decoration so the separators are the ones PowerShell reports.
        probe = "\n".join(
            f"[bool]('C:\\proj{y}file.cpp' -match '{re.escape(y)}')"
            for y in MUST_EXCLUDE)
        r = subprocess.run([ps, "-NoProfile", "-Command", probe],
                           capture_output=True, text=True, timeout=60)
        for tree, line in zip(MUST_EXCLUDE, r.stdout.strip().splitlines()):
            self.assertEqual(
                line.strip(), "True",
                f"the exclusion pattern {tree!r} does not match a path that "
                "contains it, so test_watchlist_excludes_generated_and_vendored_trees "
                "cannot fail")

    def test_negative_control_a_broken_filter_is_detected(self):
        """Re-introduce the `| Out-Null` bug and confirm this file goes red.

        Without this, the three tests above could all be passing because the
        enumeration cannot be evaluated at all.
        """
        broken = self.enumeration.replace(
            "$skip = '", "$skip = '' | Out-Null; $broken = '", 1)
        self.assertNotEqual(broken, self.enumeration,
                            "could not build the negative control")
        count, included, _ = self.run_enumeration(broken)
        self.assertEqual(
            count, 0,
            "the broken filter still produced files, so this test's threshold "
            "would not catch the real bug")
        self.assertFalse(any(included),
                         "the broken filter still covered the required files")


if __name__ == "__main__":
    unittest.main()
