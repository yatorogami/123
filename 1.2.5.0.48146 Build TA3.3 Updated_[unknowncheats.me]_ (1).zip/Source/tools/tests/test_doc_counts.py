"""The documented test counts must match what the runners actually execute.

What this is for
----------------
On 2026-10-05 four files disagreed about the size of the test suite, and every one
of the numbers was wrong in the same direction:

  file                          claimed
  ----------------------------  --------------------------------------------------
  WORKFLOW.md                   11 native cases, 155 pytest
  tools/README.md               (no native count), 149 pytest
  tools/verify/README.md         7 native cases, 139 pytest
  tools/harness/README.md        9 native cases -- then "all eight" two lines
                                 later, then "the eight above", while omitting
                                 two cases its own runner compiles

The real figures, measured by running both runners and pytest on that day, were
**11 native cases, 3 portable, 220 pytest**. So the docs were not merely stale
with respect to each other: three of the four understated the suite, and the
suite had been growing silently past all of them for weeks.

Why a stale count is worse than none
------------------------------------
`WORKFLOW.md` states the rule itself, and `audit_config_pointers.py` exits 2 when
it checks nothing rather than reporting success -- both are this project's answer
to a checker that reports a verdict it cannot support. A count printed in prose
has exactly that problem and no exit code to catch it: it looks like evidence,
it is stable in a diff, and nobody re-runs it, so it decays into a plausible
lie. This test makes the prose re-derive from the runner instead.

What it does and does not check
-------------------------------
It checks the *native case count*, because that is countable from the repository
alone: the `call :portable` lines in `run_windows.bat` and the `run_case` lines
in `run.sh` are the ground truth, and they need no toolchain. It does NOT check
the pytest count -- that requires importing every test module and would either
duplicate pytest's own collection or shell out to it, which is a slower and
flakier way of asking pytest a question it already answers. Where a document
quotes a pytest count, `test_pytest_counts_agree_across_docs` at least requires
the documents to agree with *each other*, so the number cannot drift apart in
four places simultaneously; updating it stays a human action, and that is
recorded rather than papered over.

The negative control
--------------------
`test_native_case_count_matches_run_windows_bat` fails if a `:portable` line is
added or removed without the documented count following. That was verified by
deleting one line, and the failure names both the runner and the documents, so
the person editing knows which number to update.
"""

from __future__ import annotations

import re
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]

RUN_WINDOWS = REPO / "tools" / "harness" / "run_windows.bat"
RUN_SH = REPO / "tools" / "harness" / "run.sh"
HARNESS_DIR = REPO / "tools" / "harness"

# The documents that quote a native case count. Each is (path, note-for-failure).
COUNTING_DOCS = {
    "WORKFLOW.md": REPO / "WORKFLOW.md",
    "tools/harness/README.md": REPO / "tools" / "harness" / "README.md",
    "tools/verify/README.md": REPO / "tools" / "verify" / "README.md",
    "AGENTS_TODO.md": REPO / "AGENTS_TODO.md",
    # AGENTS.md is the file every agent is told to read first, and it quotes the
    # native and portable counts in its own command block -- but it was missing
    # from this set, so when the runner grew 18 -> 19 native cases the four
    # documents here were all updated and AGENTS.md was left at 18. The suite
    # stayed green throughout, which is the whole failure mode this file exists
    # for: a checked set that is complete on paper is not complete in practice,
    # and the one document nobody re-checked was the entry point.
    "AGENTS.md": REPO / "AGENTS.md",
}

# ------------------------------------------------------------ CHANGELOG numbering
#
# Two sessions numbered their own CHANGELOG series from 0.21, so 0.21 and 0.22 each
# appeared twice for as long as nobody noticed. The first report of it named the
# right remedy and the wrong arithmetic -- it predicted 17 headings would move, when
# in the end only two did -- so a fix applied now would not have been the fix
# described then. Either way the collision itself is checkable, and it is exactly
# the shape of defect that does not announce itself: every citation still resolves,
# three of them to the wrong entry.
CHANGELOG = REPO / "CHANGELOG.md"

# Only the `0.N` sub-sections under "## 0. Unreleased". The file also has
# top-level `## 1.`, `## 2.`, `## 3.` headings whose numbers legitimately recur at
# other depths (`### 1.1` under each), so an unanchored `(\d+(?:\.\d+)*)` reports
# those as collisions. Anchored on the dotted form and the level, which is the only
# shape the sub-series actually uses.
SECTION_HEADING_RE = re.compile(r"^#{3}\s+§?(0\.\d+)\b", re.MULTILINE)


class TestChangelogNumbering:
    def test_no_section_number_appears_twice(self):
        found = SECTION_HEADING_RE.findall(_read(CHANGELOG))
        assert len(found) > 20, (
            f"only parsed {len(found)} section headings from CHANGELOG.md; the "
            "pattern has probably stopped matching, and asserting on an empty "
            "list is how a check passes by comparing nothing"
        )
        counts: dict[str, int] = {}
        for number in found:
            counts[number] = counts.get(number, 0) + 1
        dupes = sorted(n for n, c in counts.items() if c > 1)
        assert not dupes, (
            f"CHANGELOG section numbers used more than once: {dupes}. Two sessions "
            "each started a series at 0.21 and every citation to those numbers "
            "resolves to whichever entry a reader happens to find first. Renumber "
            "one side and re-point the citations that named it."
        )

    def test_every_cited_changelog_section_exists(self):
        """A citation to a number with no matching heading is a dead cross-reference.

        This is the check that would have caught the collision's second half. The
        duplicate-heading test above catches two headings sharing a number; it
        cannot notice that a document cites `§0.21` and cannot say which one was
        meant. This one cannot disambiguate either -- but it catches the class
        where a renumber leaves a citation behind, which is how the collision
        would have spread if the headings had been fixed without the refs.
        """
        # Only citations that name the file, so prose like "~0.22 ms" is not read
        # as a section reference. 0.22 ms appears in several documents and means
        # milliseconds.
        cite = re.compile(r"CHANGELOG(?:\.md)?[^\n]{0,40}?§?\b(\d+\.\d+)\b")
        headings = set(SECTION_HEADING_RE.findall(_read(CHANGELOG)))
        assert headings, "parsed no CHANGELOG headings; refusing to check citations"
        dangling = []
        for path in sorted(REPO.glob("*.md")) + sorted((REPO / "tools").rglob("*.md")):
            for line in _live_text(_read(path)).splitlines():
                for number in cite.findall(line):
                    if number not in headings:
                        dangling.append(f"{path.name}: §{number}")
        assert not dangling, (
            "these cite a CHANGELOG section number that does not exist: "
            f"{'; '.join(dangling[:8])}. Either the heading was renumbered without "
            "the citation following it, or the number is a typo."
        )


# ---------------------------------------------------------------- config pointers
#
# `audit_config_pointers.py` is the other count in this repository that appears in
# prose, and it drifted the same way the harness counts did: three documents said
# "332 across 26 headers" while the tool reported 337 across 28, and one of the
# three (AGENTS.md) was a *correction note* quoting the stale figure as the thing
# being corrected -- so the note did not fix anything, it added a fourth instance.
#
# Unlike the harness counts this one IS derivable from the repository alone: the
# tool is pure-python, needs no toolchain, and prints "checked N config pointer(s)
# across M module header(s)" on every run. So it is checked the same way, by
# re-deriving rather than by re-measuring.
POINTER_AUDIT = REPO / "tools" / "audit_config_pointers.py"

POINTER_COUNTING_DOCS = [
    REPO / "WORKFLOW.md",
    REPO / "AGENTS.md",
    REPO / "AGENTS_TODO.md",
    REPO / "CHANGELOG.md",
]

# Anchored on the tool name, for the same reason PYTEST_COUNT_RE is anchored: a
# bare `(\d+) across (\d+) headers` also matches unrelated prose, and a check that
# cannot tell the subject apart is not a check.
POINTER_COUNT_RE = re.compile(
    r"audit_config_pointers\.py`?\s*(?:checks\s+|guards\s+|covers\s+)?"
    r"(?:all\s+)?(\d+)(?:\s+(?:raw\s+)?config\s+pointers?)?"
    r"(?:\s+across)?\D{0,24}?(\d+)\s+(?:module\s+)?headers?"
    r"|audit_config_pointers\.py`?\s*(?:checks\s+|guards\s+|covers\s+)?"
    r"(\d+)\s+(?:config\s+)?pointers?\s*/\s*(\d+)\s*(?:module\s+)?headers?",
    re.IGNORECASE,
)

# WORKFLOW.md states the count on the line AFTER the one naming the tool, so the
# anchored pattern above finds nothing there. Two shapes are missed by it, and
# both were confirmed by running the matcher rather than by reading:
#
#   "every `module/impl/*.h` is actually constructed -- currently 332 across 26
#    headers."                                  <- count is on the next line
#
#   "`WORKFLOW.md` says `audit_config_pointers.py` covers **332 pointers / 26
#    headers**"                                 <- a CORRECTION note quoting the
#                                                  stale figure as the thing being
#                                                  corrected
#
# The second is the interesting one. AGENTS.md is itself a "known-stale numbers"
# list, so its entry for this count is a correction NOTE -- and `_live_text` does
# not filter it, because it matches none of QUOTE_RE / CORRECTION_MARKERS /
# HISTORICAL_MARKERS. A correction note that quotes the wrong number on its way to
# stating the right one is still a live wrong number in prose, so it is checked
# rather than excused.
#
# `re.DOTALL` with a bounded gap: the gap stays bounded so the pattern cannot run
# from one mention to an unrelated number further down the document, which is how a
# count check turns into a false positive generator.
POINTER_COUNT_SPANNING_RE = re.compile(
    r"audit_config_pointers\.py`?[^0-9]{0,160}?"
    r"(?:currently\s+)?(\d+)(?:\s+(?:raw\s+)?config\s+pointers?)?\s*"
    r"(?:across|/)\s*(\d+)\s+(?:module\s+)?headers?",
    re.IGNORECASE | re.DOTALL,
)

# AGENTS.md is a "known-stale numbers" list, so its entry reads
#   "`WORKFLOW.md` says `audit_config_pointers.py` covers **332 pointers / 26
#    headers**; the tool now reports **336 / 28**."
# -- a stale claim followed by its own correction. The spanning pattern above
# cannot see it, because the FIRST number it reaches is the corrected one, and it
# is the stale figure that is quoted second.
#
# Matching "now reports N / M" would be the wrong fix: it would make the checker
# accept whatever the doc claims is correct, which is precisely the thing being
# checked. So this pattern captures the QUOTED stale claim specifically, and the
# test requires the quote to match the tool -- which is what makes AGENTS.md's own
# correction note fail until it stops quoting a wrong number, and it is right to:
# a "known-stale" list that names a stale figure is a live stale figure.
QUOTED_STALE_COUNT_RE = re.compile(
    r"says\s+`?audit_config_pointers\.py`?\s*(?:checks\s+|guards\s+|covers\s+)?"
    r"(\d+)(?:\s+(?:raw\s+)?config\s+pointers?)?\s*(?:across|/)\s*(\d+)\s*"
    r"(?:module\s+)?headers?",
    re.IGNORECASE | re.DOTALL,
)

# "all 11 native cases", "11 native cases", "(7 native cases, ...)"
NATIVE_COUNT_RE = re.compile(r"(\d+)\s+native\s+cases", re.IGNORECASE)
PORTABLE_COUNT_RE = re.compile(r"(\d+)\s+portable", re.IGNORECASE)

# Retrospective prose quotes the numbers being corrected ON PURPOSE. Applying this
# filter to every count check (not just the pytest one) is what stops the checker
# from failing on the very notes that record the fix.
QUOTE_RE = re.compile(r"^\s*>")
CORRECTION_MARKERS = re.compile(
    r"CORRECTED|was wrong|says otherwise|previously read|before it was corrected",
    re.IGNORECASE,
)
# A historical claim about the suite size at the time some work was done. "Suite:
# 149 passed, 6 subtests **at the time**" is not a stale count, it is a record,
# and the documents already use this phrasing ("was 33", "at the time").
HISTORICAL_MARKERS = re.compile(r"\bat the time\b|\bwas \d+\b|\bthen\b", re.IGNORECASE)


def _live_text(text: str) -> str:
    """Drop blockquoted and correction-marked lines.

    The asymmetry this creates is deliberate and worth stating: a document can
    therefore *escape* the check by putting a wrong number in a blockquote, or by
    writing "at the time" next to it. That is acceptable, because the
    alternative -- failing on your own correction notes -- trains people to delete
    the checker, which is the failure mode this whole file exists to prevent.
    Both escapes are auditable in a way a stale live number is not: a blockquote
    and a time marker are visible prose, whereas a live wrong number looks exactly
    like a right one.
    """
    kept = [
        line
        for line in text.splitlines()
        if not QUOTE_RE.match(line)
        and not CORRECTION_MARKERS.search(line)
        and not HISTORICAL_MARKERS.search(line)
    ]
    return "\n".join(kept)
# The suite-level pytest claim ONLY: "149 passed, 6 subtests", "155 passed",
# "139 pytest". Deliberately anchored.
#
# The first draft of this regex was `(\d+)\s+(?:passed|pytest)` and it matched 25
# distinct numbers across four documents -- because the harness tables print
# per-case figures like "25/25 passed" and "43/43 assertions" in the same
# documents. A count that cannot distinguish "the suite has 149 tests" from
# "this one case has 25 assertions" is not a check, so the claim must be
# qualified by `tools/tests`, `pytest tools/tests`, or a subtests tail.
PYTEST_COUNT_RE = re.compile(
    r"(?:tools/tests`?\s*(?:is|-)?\s*|pytest tools/tests\D{0,40})"
    r"(\d{2,4})\s+(?:passed|pytest)"
    r"|(\d{2,4})\s+passed,\s*\d+\s+subtests",
    re.IGNORECASE,
)


def _pytest_counts(text: str) -> set[int]:
    found: set[int] = set()
    for a, b in PYTEST_COUNT_RE.findall(text):
        if a:
            found.add(int(a))
        if b:
            found.add(int(b))
    return found


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def _windows_cases() -> list[str]:
    """Case names `run_windows.bat` compiles, from the runner itself.

    Matches every `:build` subcommand, not just `:portable`. `:native` was added
    2026-10-09 for il2cpp_call_abi, which compiles real project sources that
    need <windows.h> and so must not get shim\ first on the include path.
    Hardcoding `:portable` here made that case invisible to the unwired-file
    check, which then reported it as an orphan -- the checker was right and the
    runner was wrong.
    """
    text = _read(RUN_WINDOWS)
    names = re.findall(r"call\s+:(?:portable|native)\s+\S+\s+(\S+\.cpp)", text, re.IGNORECASE)
    # pe_resource_test.cpp is built by its own `cl` line rather than by :portable,
    # because it needs rc.exe for the RCDATA resource -- so it is counted from the
    # compile line instead of from the case list. Omitting it is how this count
    # previously came out as 9 or 7.
    if "pe_resource_test.cpp" in text and "pe_resource_test.cpp" not in names:
        names.append("pe_resource_test.cpp")
    return sorted(set(names))


def _sh_cases() -> list[str]:
    text = _read(RUN_SH)
    # `run_case() {` is the shell function DEFINITION and parses as a case under a
    # naive regex. Its argument list is empty, so requiring a .cpp argument is
    # what excludes it -- and it is the reason this function exists rather than
    # being inlined.
    return sorted(set(re.findall(r"^run_case\s+\S+\s+(\S+\.cpp)\s*$", text, re.MULTILINE | re.IGNORECASE)))


class TestNativeCaseCount:
    def test_run_windows_but_actually_compiles_cases(self):
        """Precondition: the two runners are parseable at all.

        Without this, a regex that silently stops matching would make every count
        below vacuous -- the same failure `audit_config_pointers.py` exits 2 to
        avoid, and the same one that made `audit.py` report "no content loss
        detected" on Windows while comparing zero pairs.
        """
        names = _windows_cases()
        assert len(names) >= 8, (
            f"only found {len(names)} cases in {RUN_WINDOWS.name}: {names}. "
            "Either the runner changed shape or the parsing is wrong. Refusing to "
            "assert a count derived from this."
        )
        assert "test_config.cpp" in names, (
            f"{RUN_WINDOWS.name} no longer appears to compile test_config.cpp; "
            f"parsed cases were {names}"
        )

    def test_native_case_count_matches_run_windows_bat(self):
        actual = len(_windows_cases())
        wrong = []
        for label, path in COUNTING_DOCS.items():
            if not path.exists():
                continue
            for claimed in NATIVE_COUNT_RE.findall(_live_text(_read(path))):
                if int(claimed) != actual:
                    wrong.append(f"{label} says {claimed}")
        assert not wrong, (
            f"the runners compile {actual} native cases but the documentation "
            f"says otherwise: {'; '.join(wrong)}. Update the count in each file, or "
            "delete the number and point at this test -- a count nobody re-derives "
            "is an assertion wearing evidence's clothes."
        )

    def test_measured_pytest_count_constant_appears_in_the_docs(self):
        """The constant at the top of this file must still be quoted somewhere.

        A *consistency* check between a Python literal and the prose, not a claim
        that 220 is correct: if the suite grows, the constant and every document
        can still agree while all being wrong. That is the honest limit of not
        running pytest from here, and the failure message says so rather than
        implying the number was verified.

        It exists because the failure it guards against is real and has happened
        here twice: a number in a source file drifting from the number in the
        prose beside it, with nothing to notice.
        """
        quoted = [
            label
            for label, path in COUNTING_DOCS.items()
            if path.exists() and str(MEASURED_PYTEST_COUNT) in _read(path)
        ]
        assert quoted, (
            f"no document mentions the measured count ({MEASURED_PYTEST_COUNT}); "
            "this constant has drifted from the documentation it describes. "
            f"Subtests: {MEASURED_SUBTESTS}."
        )

    def test_portable_count_matches_run_sh(self):
        actual = len(_sh_cases())
        assert actual >= 1, f"parsed no portable cases from {RUN_SH.name}"
        wrong = []
        for label, path in COUNTING_DOCS.items():
            if not path.exists():
                continue
            for claimed in PORTABLE_COUNT_RE.findall(_live_text(_read(path))):
                if int(claimed) != actual:
                    wrong.append(f"{label} says {claimed}")
        assert not wrong, (
            f"{RUN_SH.name} builds {actual} portable case(s) but the documentation "
            f"says otherwise: {'; '.join(wrong)}."
        )

    def test_unwired_cpp_files_are_documented_as_unwired(self):
        """A `.cpp` in the directory that no runner builds must be called out.

        `test_card_fold_realfile.cpp` is the standing example. This does not
        require it to be wired -- only that it not be silently counted. The
        original sin was a coverage claim that included a file no runner
        compiled.
        """
        compiled = set(_windows_cases()) | set(_sh_cases())
        on_disk = {p.name for p in HARNESS_DIR.glob("*.cpp")}
        # SUPPORT_TRANSLATION_UNITS, added 2026-10-06 for lenssize_stubs.cpp.
        #
        # `_windows_cases()` captures only the FIRST .cpp on a `call :portable` line
        # (see its regex), so a case built from two sources looks like the case alone
        # and the second file reads as an orphan. lenssize_stubs.cpp is a genuine
        # support TU -- it supplies the three out-of-line symbols the real
        # optics_lens_pipeline.h needs to link -- and it is named on the runner line
        # beside its case, so it is wired, just not a case of its own.
        #
        # Kept as an explicit allowlist rather than loosening the unwired check,
        # because the check is the thing worth keeping: it is what caught this file
        # in the first place, correctly, on the grounds that a support TU with no
        # trace of one anywhere reads exactly like an orphan. Every name here must
        # actually appear on a runner line, asserted below -- otherwise the
        # allowlist becomes the silent hole the check was written to prevent.
        SUPPORT_TRANSLATION_UNITS = {"stubs.cpp", "lenssize_stubs.cpp"}
        unwired = sorted(on_disk - compiled - SUPPORT_TRANSLATION_UNITS)
        assert "stubs.cpp" not in compiled, (
            "stubs.cpp is a shared support translation unit, not a case; if a "
            "runner now compiles it directly this test's exclusion needs revisiting."
        )
        # LIVE lines only. `_read` includes `rem` comments, and this file's own runner
        # entry documents lenssize_stubs.cpp in prose, so a raw substring search
        # stayed green after the runner reference was deleted -- the negative
        # control for this assertion passed against broken source, which is the
        # failure this whole test file exists to catch. A `rem` line is not a
        # build instruction.
        runner_text = "\n".join(
            line for line in (_read(RUN_WINDOWS) + "\n" + _read(RUN_SH)).splitlines()
            if not re.match(r"^\s*rem\b", line, re.IGNORECASE)
        )
        for name in SUPPORT_TRANSLATION_UNITS:
            assert name in runner_text, (
                f"{name} is allowlisted as a support translation unit but no runner "
                "names it any more. Either restore the runner reference or drop it "
                "from the allowlist -- an allowlist nothing checks is how this test "
                "becomes the coverage claim it was written against."
            )
        for name in unwired:
            mentioned = any(name in _read(p) for p in COUNTING_DOCS.values() if p.exists())
            assert mentioned, (
                f"{name} sits in tools/harness/ but no runner compiles it, and no "
                "document says so. Either wire it into run_windows.bat or name it "
                "as unwired -- an unmentioned orphan file is exactly what turns "
                "into a coverage claim that was never true."
            )


def _audit_pointer_counts() -> tuple[int, int]:
    """(pointers, headers) as `audit_config_pointers.py` itself reports them.

    Runs the tool rather than parsing its source, because the tool already has the
    exit-2 discipline this file is arguing for: it refuses to report a count it
    cannot support. Re-implementing its scan here would be a second implementation
    to drift.
    """
    import subprocess

    proc = subprocess.run(
        ["python", str(POINTER_AUDIT)],
        cwd=REPO, capture_output=True, text=True, errors="replace",
    )
    if proc.returncode not in (0, 1):
        raise AssertionError(
            f"{POINTER_AUDIT.name} exited {proc.returncode}; it exits 2 when it "
            "checked nothing, and that must not be read as a count of zero"
        )
    m = re.search(r"checked (\d+) config pointer\(s\) across (\d+) module header", proc.stdout)
    if not m:
        raise AssertionError(
            f"could not parse a count out of {POINTER_AUDIT.name}'s output:\n"
            f"{proc.stdout[:400]!r}\n"
            "The tool's summary line is the ground truth for this test; if it "
            "changed shape, update POINTER_COUNT_RE and this together."
        )
    return int(m.group(1)), int(m.group(2))


class TestConfigPointerCount:
    def test_pointer_audit_is_parseable_at_all(self):
        """Precondition, for the same reason the harness one exists.

        A regex that silently stops matching makes every count below vacuously
        true -- the check passes because it compared nothing, which is the exact
        failure this file was written against.
        """
        pointers, headers = _audit_pointer_counts()
        assert pointers > 100, (
            f"parsed {pointers} pointers from {POINTER_AUDIT.name}, which is "
            "implausibly low. Either the tree shrank drastically or the parse is "
            "wrong. Refusing to assert a count derived from this."
        )
        assert headers >= 20, (
            f"parsed {headers} headers from {POINTER_AUDIT.name}; the tool scans "
            "module/impl/*.h and there are more than that."
        )

    def test_documented_pointer_count_matches_the_tool(self):
        pointers, headers = _audit_pointer_counts()
        wrong = []
        # Per-PATTERN liveness, not a single aggregate `seen_any`.
        #
        # The aggregate version was vacuous and this is the control that found it:
        # breaking POINTER_COUNT_SPANNING_RE so it matches NOTHING still left the
        # test green, because three other documents supplied claims and satisfied
        # the aggregate. But WORKFLOW.md is matched ONLY by the spanning pattern, so
        # with it dead that document was silently unchecked -- one broken regex out
        # of three, and the test reported success the whole time.
        #
        # Each pattern now has to account for at least one mention on its own.
        patterns = {
            "POINTER_COUNT_RE": POINTER_COUNT_RE,
            "POINTER_COUNT_SPANNING_RE": POINTER_COUNT_SPANNING_RE,
            # QUOTED_STALE_COUNT_RE is exempt from the liveness rule below, and the
            # exemption is not a fudge. It matches the "X says N/M; the tool now
            # reports P/Q" shape, which exists ONLY as a known-stale-number entry --
            # and AGENTS.md's entry for this count has just been corrected, so there
            # is correctly nothing left for it to match.
            #
            # Requiring it to stay live would make the test demand that a stale
            # figure be reintroduced, which is the exact behaviour it exists to
            # prevent. It stays in the match set: if such a note ever reappears, the
            # stale number it quotes is checked like any other claim.
            "QUOTED_STALE_COUNT_RE": None,
        }
        hits: dict[str, list[tuple[int, int]]] = {name: [] for name in patterns}
        for path in POINTER_COUNTING_DOCS:
            if not path.exists():
                continue
            live = _live_text(_read(path))
            anchored = [
                (int(a or c), int(b or d)) for a, b, c, d in POINTER_COUNT_RE.findall(live)
            ]
            spanning = [(int(a), int(b)) for a, b in POINTER_COUNT_SPANNING_RE.findall(live)]
            quoted = [(int(a), int(b)) for a, b in QUOTED_STALE_COUNT_RE.findall(live)]
            for name, found in (
                ("POINTER_COUNT_RE", anchored),
                ("POINTER_COUNT_SPANNING_RE", spanning),
                ("QUOTED_STALE_COUNT_RE", quoted),
            ):
                hits[name] += found
            for claimed_p, claimed_h in anchored + spanning + quoted:
                if (claimed_p, claimed_h) != (pointers, headers):
                    # Two patterns can match one mention (the anchored and the
                    # spanning forms overlap), so dedupe per document -- otherwise
                    # the failure lists the same claim twice for one edit.
                    entry = f"{path.name} says {claimed_p}/{claimed_h}"
                    if entry not in wrong:
                        wrong.append(entry)

        dead = [
            name
            for name, pattern in patterns.items()
            if pattern is not None and not hits[name]
        ]
        assert not dead, (
            f"these patterns matched nothing across {len(POINTER_COUNTING_DOCS)} "
            f"documents: {dead}. A pattern that has stopped matching leaves its "
            "documents unchecked while the test still passes -- the aggregate "
            "'some document mentioned it' version of this check hid exactly that."
        )
        assert not wrong, (
            f"{POINTER_AUDIT.name} reports {pointers} pointers across {headers} "
            f"headers but the documentation says otherwise: {'; '.join(wrong)}. "
            "Update each number, or delete the number and point at this test."
        )


# The suite size at the time this file was written. Only the prose above and the
# test module docstring quote it; nothing enforces it, deliberately (see the
# NOT HERE block at the bottom). Named so that a future reader who greps for a
# stale count finds this and not the wrong number.
#
# UPDATED 2026-10-12 from 220 / 6. At 220 this constant was 260 behind the real
# figure, which made test_measured_pytest_count_constant_appears_in_the_docs pass
# VACUOUSLY: the string "220" survived in old prose nobody had cleaned up, so the
# test could not fail. A consistency check that cannot fail is not a consistency
# check, and this is not the first this repository has produced.
#
# It is PLATFORM-SCOPED. This is the LINUX figure. Three of the four failures are
# Windows-only (they spawn `cmd`, or compare backslash paths), so a Windows run
# reads ~483 passed / 1 failed. Neither number is derivable from the other; see
# AGENTS.md, which is where the figure is maintained and why the platform is part
# of the claim. If you measure on Windows, change it here and in the prose
# together.
MEASURED_PYTEST_COUNT = 480
MEASURED_SUBTESTS = 23

# ---------------------------------------------------------------------------
# NOT HERE, AND THE REASON IS WORTH RECORDING
#
# The obvious companion check -- "every document quoting a pytest count must
# quote the same one" -- was written, and then deleted. It does not work.
#
# `AGENTS_TODO.md` contains ~10 per-session records of the form "`tools/tests`
# is 155 passed", each inside a dated section describing work completed that
# day. Those are HISTORICAL claims and are correct as written: the suite really
# was 155 when that section was written. So a cross-document agreement check
# flags them all, and the only ways to make it pass are to edit a decade of
# accurate history or to delete the check.
#
# That is precisely the trap `tools/verify/README.md` opens with -- three of its
# four tools each produced a clean, confident, wrong answer -- and the trap
# `audit.py` fell into on Windows by reporting "no content loss detected" while
# comparing zero pairs. A check that cannot distinguish a live claim from a
# dated record does not support its own verdict, and a check whose only remedies
# are "delete it" or "rewrite history" should not be merged.
#
# So the pytest count stays a human-maintained figure, and the machine-checked
# half of the 2026-10-05 defect is the native case count above -- which IS
# derivable from the repository, because the runner's own `call :portable` lines
# are the ground truth and need no toolchain to read.
#
# If the pytest count is ever to be checked, the check has to run pytest. That
# is a separate piece of work with a real design question in it (invoking pytest
# from inside pytest, and what to do about the six subtests the unittest
# runner cannot see). Until then it is not here.
# ---------------------------------------------------------------------------