"""Prove tools/watch_client_exit.py works before trusting it on the game.

Three ways a process can end are spawned for real, so the watcher's own code path is
what is under test -- not the game, and not a mock:

    clean    ExitProcess(0)                 -> 0
    code42   ExitProcess(42)                -> 42
    abort    C abort()                      -> 0xC0000409

`abort` is the one that matters. 0xC0000409 is the fail-fast/CRT-abort code: it
bypasses structured exception handling, so a process that dies that way leaves no
vectored report, no unhandled-filter report and no terminate report. It is the same
shape as the deaths that made five of twelve launches on 2026-10-03 vanish with no
output, and it is the case the watcher exists to catch -- so if the watcher can read
that code, it can read theirs.

Two controls that would be nice are NOT here, because CPython will not produce them:
ctypes converts a raised NTSTATUS into an OSError, and an AV inside a WINFUNCTYPE
callback is caught and printed as "Exception ignored while calling ctypes callback".
Both were tried and both leave the process alive and exiting 0 or 99. Manufacturing
an unhandled AV from Python needs a compiled child, which is more machinery than this
is worth -- so the claim is not tested rather than tested and passing.

What is tested for those codes instead is describe(), since reading the number and
naming it are separate pieces and only the first one needs a real process.
"""
import importlib.util
import subprocess
import sys
import time
from pathlib import Path

TOOL = Path(__file__).resolve().parents[1] / "watch_client_exit.py"

CHILD = r"""
import os, sys, time
mode = sys.argv[1]
time.sleep(0.6)
if mode == "clean":
    sys.exit(0)
if mode == "code42":
    sys.exit(42)
if mode == "abort":
    os.abort()          # C abort(); nothing can catch this on the way out
sys.exit(99)
"""

EXPECT = {"clean": 0, "code42": 42, "abort": 0xC0000409}

# The codes whose MEANING is what changes what we do next. Checked against the real
# table, not against a copy of it, so a rename in the tool cannot leave this passing.
NAMES_CHECKED = {
    0: "ExitProcess(0)",
    0xC0000005: "STATUS_ACCESS_VIOLATION",
    0xC00000FD: "STACK_OVERFLOW",
    0xC0000409: "STACK_BUFFER_OVERRUN",
    0xC000070E: "THREADPOOL_FREE_LIBRARY_ON_COMPLETION_FAILED",
}


def load_tool():
    spec = importlib.util.spec_from_file_location("watch_client_exit", TOOL)
    mod = importlib.util.module_from_spec(spec)
    # main() only runs under __main__, so importing is safe and does not start watching.
    spec.loader.exec_module(mod)
    return mod


def main():
    import os
    child_py = Path(os.environ.get("TEMP", ".")) / "watch_child.py"
    child_py.write_text(CHILD, encoding="utf-8")

    failures = 0

    for mode, want in EXPECT.items():
        watcher = subprocess.Popen(
            [sys.executable, str(TOOL), "--once", "--no-csv", "--timeout", "40",
             "--process", "python.exe"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        time.sleep(1.2)
        victim = subprocess.Popen([sys.executable, str(child_py), mode])
        out, _ = watcher.communicate(timeout=60)
        victim.wait(timeout=10)

        got = None
        for line in out.splitlines():
            if "exit code 0x" in line:
                got = int(line.split("exit code 0x")[1].split()[0], 16)
        ok = got == want
        failures += 0 if ok else 1
        print(f"  {'PASS' if ok else 'FAIL'}  {mode:<7} want 0x{want:08X}  got "
              f"{'none' if got is None else f'0x{got:08X}'}")
        if not ok:
            for line in out.splitlines():
                print("          " + line)

    mod = load_tool()
    for code, token in NAMES_CHECKED.items():
        text = mod.describe(code)
        ok = token in text
        failures += 0 if ok else 1
        print(f"  {'PASS' if ok else 'FAIL'}  describe(0x{code:08X}) names {token}"
              + ("" if ok else f"  -- got {text!r}"))

    # And the negative that matters: an unrecognised code must be reported AS
    # unrecognised, not dressed up as one of the known ones. Two shapes, because the
    # table branches on the high bit and both have to be honest:
    #   0x1234     small  -> an explicit ExitProcess/TerminateProcess code
    #   0xDEADBEEF high bit set, unlisted -> "not a known code", explicitly not guessed
    for code, token in ((0x1234, "TerminateProcess"), (0xDEADBEEF, "not a known code")):
        text = mod.describe(code)
        ok = token in text and not any(t in text for t in NAMES_CHECKED.values()
                                        if t not in ("ExitProcess(0)",))
        failures += 0 if ok else 1
        print(f"  {'PASS' if ok else 'FAIL'}  describe(0x{code:08X}) stays honest -- got {text!r}")

    child_py.unlink(missing_ok=True)
    total = len(EXPECT) + len(NAMES_CHECKED) + 2
    print(f"  {total - failures}/{total} passed")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
