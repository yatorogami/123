"""invisible_to_bots must reach the bot-group hostility API, and must not fail silently.

WHAT THIS FEATURE IS. `PlayerModule::apply_invisible_to_bots` drops the local
player out of every bot group's enemy map so bots never acquire it. It is pure
runtime reflection -- no RVAs -- walking:

    GameWorld.AllAlivePlayersList
      -> per bot: get_IsYourPlayer (skip the local player)
      -> get_AIData -> get_BotOwner -> get_BotsGroup
      -> <hostility API>: remove the player from the enemy map, add it to the
         neutral/ally map

WHY IT BROKE ON 120047888. BSG moved hostility off `BotsGroup` into a new
`BotGroupHostility` object. Measured in the two ISIL trees:

    115147510   BotsGroup.RemoveEnemy(IPlayer, EBotEnemyCause = 1)
                BotsGroup.AddAlly(EFT.Player)
    120047888   BotsGroup.get_BotGroupHostility() -> BotGroupHostility
                BotGroupHostility.RemoveEnemyAction(IPlayer)
                BotGroupHostility.AddNeutralAction(IPlayer)

`RemoveEnemy` appears in 10 files in 115147510 and 1 in 120047888. `AddAlly` in
6 and 1. The surviving `AddAlly` in 120047888 is on `EFT/Player` and its entire
body is `ret 0` (EFT/Player.txt:158351) -- an interface stub, not the
implementation. So "AddAlly still exists" was never evidence the path worked.

WHY IT PRESENTED AS "BROKE" RATHER THAN CRASHING. Every `get_method` returns
null and the loop `continue`s. Best-effort with no logging. A rename is
indistinguishable from a no-op, which is the whole problem: the feature was
inert for a full build and nothing in the log said so.

THAT IS WHAT THE SECOND HALF OF THIS TEST GUARDS. The fix records each
unresolved link in a bitmask and reports it once per distinct pattern. The
load-bearing assertion is therefore not "the new names are present" -- that
would pass on a tree where the new names are present and the reporting is
missing, which is exactly the state that let this ship broken. It is "no
`continue` leaves the loop without recording why".

THE CHECKER STRIPS COMMENTS FIRST. The port documents the old chain in prose
(`BotsGroup.RemoveEnemy`, `AddAlly`), so a naive search finds its own
explanation and passes. Same trap as `test_profile_path.py` v1.

AddNeutralAction lands the player in the NEUTRAL map, not the ALLY map. That is
weaker than the old AddAlly -- neutral bots are not hostile but may still
investigate. The stronger follow-up is writing into the Allies dictionary
directly: `get_Allies` is `mov rax,[rcx+18h]` then `mov rax,[rax+38h]`, i.e.
BotGroupHostility field +0x38.
"""

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
AI_LIMIT_MODULE = ROOT / "TarkovAddons" / "module" / "impl" / "AiLimitModule.cpp"
AI_LIMIT_HEADER = ROOT / "TarkovAddons" / "module" / "impl" / "AiLimitModule.h"

# Gitignored, regenerated locally (AGENTS.md). Used only as corroboration: the
# code-shape assertions below are the ones that always run.
ISIL_NEW = ROOT / "TarkovAddons" / "ISIL-references" / "120047888"
ISIL_OLD = ROOT / "TarkovAddons" / "ISIL-references" / "115147510"


def strip_comments(src: str) -> str:
    """Blank out // and /* */ comments, preserving offsets.

    Length-preserving so a comment cannot shift a later match, and comment-free
    so a match can only be real code.
    """
    out = list(src)
    i, n = 0, len(src)
    in_line = in_block = in_str = in_chr = False
    while i < n:
        c = src[i]
        nxt = src[i + 1] if i + 1 < n else ""
        if in_line:
            if c == "\n":
                in_line = False
            i += 1
            continue
        if in_block:
            if c == "*" and nxt == "/":
                out[i] = out[i + 1] = " "
                in_block = False
                i += 2
                continue
            if c != "\n":
                out[i] = " "
            i += 1
            continue
        if in_str or in_chr:
            quote = '"' if in_str else "'"
            if c == "\\":
                out[i] = " "
                if i + 1 < n and src[i + 1] != "\n":
                    out[i + 1] = " "
                i += 2
                continue
            if c == quote:
                in_str = in_chr = False
            i += 1
            continue
        if c == "/" and nxt == "/":
            in_line = True
            out[i] = out[i + 1] = " "
            i += 2
            continue
        if c == "/" and nxt == "*":
            in_block = True
            out[i] = out[i + 1] = " "
            i += 2
            continue
        if c == '"':
            in_str = True
        elif c == "'":
            in_chr = True
        i += 1
    return "".join(out)


def fn_body(code: str, signature: str) -> str:
    start = code.find(signature)
    if start < 0:
        raise AssertionError(f"signature not found in comment-stripped source: {signature!r}")
    open_at = code.find("{", start)
    depth, i, n = 0, open_at, len(code)
    while i < n:
        if code[i] == "{":
            depth += 1
        elif code[i] == "}":
            depth -= 1
            if depth == 0:
                return code[open_at: i + 1]
        i += 1
    raise AssertionError(f"unbalanced braces after {signature!r}")


def continue_blocks(body: str) -> list[str]:
    """The innermost brace block enclosing each `continue;` in `body`.

    A `continue` at loop top level (no enclosing block) yields "".
    """
    out: list[str] = []
    stack: list[int] = []
    i, n = 0, len(body)
    while i < n:
        c = body[i]
        if c == "{":
            stack.append(i)
            i += 1
            continue
        if c == "}":
            if stack:
                stack.pop()
            i += 1
            continue
        if body.startswith("continue", i) and not _is_ident(body, i - 1) \
                and not _is_ident(body, i + 8):
            out.append(body[stack[-1]: i + 8] if stack else "")
            i += 8
            continue
        i += 1
    return out


def _is_ident(body: str, idx: int) -> bool:
    return 0 <= idx < len(body) and (body[idx].isalnum() or body[idx] == "_")


class TestInvisibleToBotsChain(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = AI_LIMIT_MODULE.read_text(encoding="utf-8-sig")
        cls.header = AI_LIMIT_HEADER.read_text(encoding="utf-8-sig")
        cls.code = strip_comments(cls.raw)
        cls.body = fn_body(cls.code, "void AiLimitModule::apply_invisible_to_bots(")
        cls.allies = fn_body(cls.code, "static bool add_player_to_allies(")
        # The summary line the lag fix was found under.
        cls.all_helpers = fn_body(cls.code, "static bool add_player_to_allies(")

    # -- the toggles must be drawn once, on top, and must unlock ----------

    def test_the_toggles_are_not_drawn_twice(self):
        """THE CARD RENDERED THE TWO TOGGLES TWICE.

        menu.cpp's `apply()` draws every conf()-registered value, and
        `draw_menu_extra()` drew `section_invisible_` and both checkboxes
        again. So the card showed the pair on top and the pair again at the
        bottom, in swapped order -- one ImGui ID per checkbox, shared by two
        widgets.

        The general rule, asserted here rather than remembered: a value that a
        hand-laid card draws itself must be hidden from the automatic list.
        `BotControlModule`, `LootTeleportModule` and `HideoutAutomationModule`
        all set that flag; this card did not, and had no test to say so.
        """
        extra = fn_body(self.code, "void AiLimitModule::draw_menu_extra(")
        ctor = self.code[self.code.index("AiLimitModule::AiLimitModule("):
                         self.code.index("void AiLimitModule::draw_overlay(")]

        drawn = [m for m in re.findall(r"(\w+)->draw\(\)", extra)]
        self.assertTrue(drawn, "draw_menu_extra() draws nothing; the overrides "
                               "that place the toggles are gone")
        for name in drawn:
            self.assertIn(f"{name}->set_hidden_in_owner_menu(true)", ctor,
                          f"{name} is drawn by draw_menu_extra() but is still in "
                          "the framework's value list, so it renders twice")

    def test_the_toggles_are_drawn_before_the_values(self):
        """The two toggles belong on top, and that has to be stated.

        They landed on top by accident: `conf()` pushes in DECLARATION order,
        the toggles are declared public because the hotkeys bind them, and
        everything else is private -- so the `public:` block happened to come
        first. Move one member across that boundary and the card silently
        reshuffles. `draw_menu_extra_before_values()` returning true is the
        explicit form of that position.
        """
        self.assertIn("bool AiLimitModule::draw_menu_extra_before_values() const { return true; }",
                      self.code,
                      "draw_menu_extra_before_values() is no longer true, so the "
                      "hand-drawn toggles have moved below the limit's sliders")

        extra = fn_body(self.code, "void AiLimitModule::draw_menu_extra(")
        for name in ("section_invisible_", "invisible_to_bots_ally",
                     "invisible_to_bots_neutral"):
            self.assertIn(f"{name}->draw();", extra,
                          f"{name} is no longer drawn by this card")

        # And the automatic list must be empty of them, or "before" is a lie.
        self.assertNotIn("invisible_to_bots_ally->draw", extra.replace(
            "invisible_to_bots_ally->draw();", ""),
            "invisible_to_bots_ally is drawn twice inside draw_menu_extra()")

    def test_the_exclusivity_is_not_gated_behind_is_active(self):
        """WHY TURNING ALLY OFF NEVER UNLOCKED NEUTRAL.

        `sync_invis_state()` ran only in `application_update()`, which
        ModuleManager::apply() gates on `is_active()`. And `is_active()` is
        exactly "one of these three toggles is on" -- so switching the LAST one
        off removed the module from the very loop that has to react to that
        switch. The peer stayed greyed out until the game restarted.

        Commit 601a79179 ("Properly reenable checkboxes") added the missing
        `else` branch to `sync_invis_state()` and changed nothing observable,
        because the branch was never reached. That is the part worth pinning:
        the logic was right and the PATH was wrong, so a correct fix read as a
        failed one.

        Same structural class as the bug one commit earlier (the ally chain
        behind the limit's early return): a feature whose only liveness check
        is one of the values it polices cannot observe that value going false.
        """
        # Precondition, or this test cannot fail for the right reason: the gate
        # has to actually exist, or "ungated" is vacuous. is_active() is inline
        # in the header, not the .cpp.
        self.assertIn("bool is_active() const override", self.header,
                      "is_active() is not overridden; the gate this defends "
                      "against no longer exists, so re-check the reasoning")
        self.assertIn("invisible_to_bots_ally->get_value()", self.header,
                      "is_active() no longer reads the toggles it polices; the "
                      "reasoning behind this test no longer applies")

        prepare = fn_body(self.code, "void AiLimitModule::prepare_menu_draw(")
        self.assertIn("sync_invis_state();", prepare,
                      "prepare_menu_draw() no longer enforces the mutual "
                      "exclusion; prepare_menu_draw runs from menu.cpp's "
                      "apply_all(), which is is_active()-independent, and it is "
                      "the only place disabled_ is observable")

    def test_the_unlocked_peer_is_actually_re_enabled(self):
        """The else branch, asserted directly -- it existed once and did nothing."""
        sync = fn_body(self.code, "void AiLimitModule::sync_invis_state()")
        self.assertIn("else", sync, "sync_invis_state() has no else branch, so "
                                    "the peer is never re-enabled")
        tail = sync[sync.rindex("else"):]
        for name in ("invisible_to_bots_neutral", "invisible_to_bots_ally"):
            self.assertIn(f"{name}->set_disabled(false)", tail,
                          f"{name} is never re-enabled once both toggles are off")

    # -- the ally path must not throw -------------------------------------

    def test_the_chain_is_not_gated_behind_the_limit_toggle(self):
        """THE BUG THE 2026-10-11 LOG CAUGHT.

        `invisible_to_bots_ally` was true for a whole 18-minute raid and the
        feature did nothing, silently, because the chain lived inside
        `gameworld_update` after the `if (!ai_limit_enabled) return;` early
        return. Two features sharing one per-frame entry point means any gate
        that RETURNS disables the other half.

        The fix separated it into its own method called before any limit gate.
        Asserted structurally, because that is the defect: not a wrong member
        name but a wrong PLACE.
        """
        # The chain must live in its own method, not inside the limit's method.
        chain_fn = fn_body(self.code, "void AiLimitModule::update_invisible_to_bots(")
        self.assertTrue(chain_fn, "update_invisible_to_bots() is gone; the chain "
                                  "has been folded back into the limit's path")
        self.assertIn("apply_invisible_to_bots(", chain_fn,
                      "the chain walk is not inside update_invisible_to_bots()")

        # And the limit's own method must not contain the chain at all.
        limit_fn = fn_body(self.code, "void AiLimitModule::gameworld_update(")
        self.assertNotIn("apply_invisible_to_bots(", limit_fn,
                         "gameworld_update() still calls the ally chain directly; "
                         "it is gated behind the limit toggle again")

        # The call must precede the limit's enable check in source order.
        idx_call = limit_fn.find("update_invisible_to_bots(game_world_instance")
        idx_gate = limit_fn.find("ai_limit_enabled->get_value()")
        self.assertNotEqual(idx_call, -1, "gameworld_update no longer calls the chain")
        self.assertNotEqual(idx_gate, -1, "gameworld_update no longer reads the limit toggle")
        self.assertLess(idx_call, idx_gate,
                        "the ally chain runs AFTER the limit's enable check, so "
                        "switching the limit off disables ally-ing again")

        # And there must be no `return` between the call and the gate.
        between = limit_fn[idx_call:idx_gate]
        self.assertNotIn("return;", between,
                        "an early return sits between the ally chain and the limit "
                        "gate; the chain is gated again")

    def test_the_allies_write_is_guarded_by_containskey(self):
        """THE LAG. `Dictionary.Add` throws on a duplicate key, and the ally path
        called it 4x a second per bot group, so every call after the first threw
        a managed exception (object + 24-frame stack capture) out through our
        native hook frames. ContainsKey is one call that cannot throw, so it has
        to be asked first.

        Proven from the game's own binary: `Dictionary`2.Add` begins `mov r9b,2`
        -- InsertionBehavior.ThrowOnExisting -- and then calls TryInsert.

        Asserted on the helper, because that is where the write lives.
        """
        self.assertIn("ContainsKey", self.allies,
                      "add_player_to_allies must ask ContainsKey before writing; "
                      "an unguarded Add throws ArgumentException on the second call")
        # And the Add must come AFTER the guard, in the same function.
        idx_contains = self.allies.find("ContainsKey")
        idx_add = self.allies.find('"Add"')
        self.assertNotEqual(idx_add, -1, "the Add call disappeared; the ally path is gone")
        self.assertLess(idx_contains, idx_add,
                        "ContainsKey must be resolved before Add -- the reverse "
                        "still throws on the second call")

    def test_the_guard_returns_true_when_already_present(self):
        """A bot group the player is already in must be a no-op, not a write.

        Asserted on the mask bit and the early return, both code rather than
        prose: `inv_already_ally` is set only on the already-present branch, and
        that branch must return true -- the caller treats false as "this bot was
        not handled" and re-reports it every cadence tick, which is a log-line
        treadmill rather than a lag, but still wrong.
        """
        self.assertIn("inv_already_ally", self.allies,
                      "the already-present branch of the guard is gone; without it "
                      "the dictionary write runs (and throws) on every tick")
        idx_bit = self.allies.find("inv_already_ally")
        idx_return = self.allies.find("return true;", idx_bit)
        self.assertNotEqual(idx_return, -1,
                            "the already-present branch does not return true, so the "
                            "caller reports it as unhandled on every cadence tick")

    def test_the_current_builds_hostility_api_is_used(self):
        """`BotGroupHostility` is the 120047888 shape and must be the one tried.

        Asserted on the RESOLVER, not on a call: `get_method` returning null is
        the failure mode, so the name being passed to it is the thing that has
        to be right.
        """
        for name in ("get_BotGroupHostility", "RemoveEnemyAction", "AddNeutralAction"):
            self.assertIn(name, self.body,
                          f"{name} is the 120047888 hostility API and is not "
                          f"referenced; the feature is inert on the current build")

    def test_the_legacy_build_is_not_supported(self):
        """115147510 put the methods on BotsGroup itself, but that build is no
        longer supported. The old chain is removed -- if a link stops resolving
        the feature is inert and the report says which link.
        """
        self.assertNotIn('"RemoveEnemy"', self.body,
                         "the 115147510 BotsGroup.RemoveEnemy fallback should be gone")
        self.assertNotIn('"AddAlly"', self.body,
                         "the 115147510 BotsGroup.AddAlly fallback should be gone")

    def test_ally_uses_dictionary_write_not_game_api(self):
        """There is no game API for Ally. BotGroupHostility has no AddAlly method
        and no OnAddAlly event. The surviving AddAlly on EFT/Player is an empty
        `ret 0` stub (EFT/Player.txt:158351). The method that would do it
        properly is private and takes a struct. So the Allies dictionary is
        written directly: get_Allies is at +0x38 on BotGroupHostility.
        """
        self.assertIn("Allies", self.code,
                      "Ally mode writes into the Allies dictionary, not via a game API")
        self.assertIn("BotGroupEnemyInfo", self.code,
                      "Ally mode constructs BotGroupEnemyInfo for the dictionary value")
        self.assertIn("Dictionary.Add", self.code,
                      "Ally mode calls Add on the Allies dictionary")

    def test_the_surviving_addally_is_documented_as_a_stub(self):
        """`EFT/Player.AddAlly` still exists in 120047888 and is an empty stub.

        Its whole body is `ret 0` (EFT/Player.txt:158351). Anyone auditing this
        later will find `AddAlly` in the dump and conclude the old path works.
        The code documents this and does not call it.
        """
        self.assertNotIn('"AddAlly"', self.body,
                         "AddAlly must not be called anywhere in the new chain")
        self.assertIn("ret 0", self.raw,
                      "the record that EFT/Player.AddAlly is a stub is gone; "
                      "without it the next reader concludes the old path works")

    # -- the part that actually prevents a recurrence -------------------

    def test_every_continue_records_why_it_skipped(self):
        """No `continue` may leave the loop without naming the link that failed.

        This is the assertion that carries the weight. "The new names are
        present" passes on a tree where the new names are present and the
        diagnostics are missing -- which is the state that let this ship inert
        for a whole build.

        ONE EXEMPTION, and it is not a hole: the skip predicate. An entry that is
        empty or is not a bot we should touch is not a failed link and has
        nothing to record. It is a named predicate (`is_not_a_bot`) precisely so
        this check can recognise it -- an inline `if (is_you(bot)) continue;` is
        indistinguishable from a silent failure, which is the failure mode this
        function exists to prevent.
        """
        blocks = continue_blocks(self.body)
        self.assertTrue(blocks, "precondition: the loop still has continue statements")

        silent = []
        for b in blocks:
            if "mask |=" in b:
                continue
            if "is_not_a_bot" in b:
                continue
            silent.append(b.strip().splitlines()[0].strip() if b.strip() else "<top level>")
        self.assertEqual(
            silent, [],
            "these `continue` statements skip a bot without recording which link "
            "failed, so a future rename is again a silent no-op:\n  "
            + "\n  ".join(silent))

    def test_the_report_is_gated_so_it_costs_nothing_per_frame(self):
        """`apply_invisible_to_bots` runs every frame while the toggle is on.

        AGENTS.md: "the argument to logger::debug() is still built by the caller
        every frame. Any per-frame trace must avoid string building or not
        exist." So the failing links are OR-ed into a bitmask (no allocation) and
        the message is assembled only when the pattern CHANGES -- which is also
        what lets a later improvement through, where a plain `static bool warned`
        would swallow it.
        """
        body = fn_body(self.code, "static void report_invisible_link_state(")
        self.assertRegex(body, r"static\s+unsigned\s+reported_mask",
                         "the report does not remember what it last said, so it "
                         "builds a string every frame")
        guard = body.find("if (!changed) return;")
        self.assertGreater(guard, 0,
                           "the report has no change guard, so it runs every frame")
        built = body.find("std::string detail")
        self.assertGreater(built, 0, "precondition: the report builds a message")
        self.assertLess(guard, built,
                        "the message is built BEFORE the change guard, so the "
                        "guard saves nothing -- this is the per-frame cost the "
                        "bitmask was meant to avoid")

    def test_an_unresolvable_chain_is_distinguished_from_a_partial_one(self):
        """`inv_no_methods` means "hostility found, but neither method for the mode
        resolved", not "one method missing".

        A missing method on a chain that exists is a rename we have seen. The
        hostility object existing but having no usable method for the selected mode
        is a rename we have not, and it is the case worth shouting about.
        """
        self.assertIn("inv_no_methods", self.body,
                      "there is no flag for 'hostility found, no method for mode', "
                      "so a totally-unknown API shape looks like a partial failure")
        # It must be SET (in the loop) and NAMED (in the table). A flag that is
        # only declared is a flag that can never be reported.
        self.assertRegex(self.body, r"mask\s*\|=\s*inv_no_methods",
                         "inv_no_methods is never assigned, so it can never be reported")
        names = fn_body(self.code, "static const char* invisible_flag_name(")
        self.assertIn("inv_no_methods", names,
                      "inv_no_methods has no name in the report table, so it would "
                      "print as '?'")

    # -- the Allies dictionary must be validated before a managed call -----
    #
    # THE CRASH THIS GUARDS. Four sessions (pid 27316, 10316, 22580 and the
    # one that produced no dump) faulted at the same GameAssembly RVA 0x5B1DA4
    # reading the all-ones sentinel 0xFFFFFFFFFFFFFFFF. That RVA is 4 bytes into
    # a shared generic-instantiation body that dump.cs attributes to
    # Dictionary<object,...>.ContainsKey, and the faulting instruction
    # `mov rax, [r8+0x20]` is a field read INSIDE the managed method -- i.e.
    # inside the `contains(allies, local_player)` call, not in our own code.
    #
    # The null check that was there could not see it. A non-null Il2CppObject*
    # from a field read is not a live dictionary: the GC recycles freed memory
    # instead of unmapping it, so a torn dictionary still reads as non-null and
    # its own m_p_entries can be stale. The gate below is the same shape
    # production_panel_probe.h:1915 uses for its dictionary walks.

    def test_the_allies_dictionary_is_validated_before_the_managed_call(self):
        """`ContainsKey` runs on our say-so, so the dictionary must be checked first.

        The load-bearing assertion is ORDER, not presence: a check placed after
        the call would be a comment rather than a guard. `contains(` is the
        managed invocation that faults, so both the object check and the
        m_p_entries check must sit before it.

        Deliberately NOT asserted against the literal `contains(allies, local_player)`
        -- since 2026-10-12 the call carries a third argument, the hidden trailing
        MethodInfo*, and an assertion pinned to the old two-argument spelling went
        red the moment the calling convention was fixed. The property (guards
        before the call) outlives the spelling.
        """
        call = self.allies.find("contains(allies, local_player")
        self.assertNotEqual(call, -1, "precondition: the managed call is present")
        obj = self.allies.find("is_il2cpp_object_likely_valid(allies)")
        self.assertNotEqual(obj, -1,
                            "the Allies dictionary is not validated before ContainsKey; "
                            "a torn dictionary still reads as non-null and the managed "
                            "call faults inside it")
        entries = self.allies.find("m_p_entries")
        self.assertNotEqual(entries, -1,
                            "m_p_entries is never checked; it is the field ContainsKey "
                            "indexes and the one that faults when stale")
        self.assertLess(obj, call,
                        "the object check runs AFTER the managed call, so it guards "
                        "nothing")
        self.assertLess(entries, call,
                        "the m_p_entries check runs AFTER the managed call, so it "
                        "guards nothing")

    def test_the_dictionary_gate_costs_no_managed_call(self):
        """The gate must be pointer tests only.

        is_il2cpp_object_strict memoises page readability, and its own comment
        records 289,255 calls costing 42.3 s on a per-frame path. This one runs
        on the 250 ms cadence, but the cheap form is the correct one here and a
        future edit that upgrades it should have to argue with this test.
        """
        obj = self.allies.find("is_il2cpp_object_likely_valid(allies)")
        self.assertNotEqual(obj, -1, "precondition: the gate exists")
        window = self.allies[obj:obj + 1200]
        self.assertNotIn("is_il2cpp_object_strict", window,
                         "the gate uses the strict (memoised page-readability) probe; "
                         "the cheap object test is what this path needs")
        self.assertIn("is_readable_address", window,
                      "precondition: the gate reads as a real validation")

    def test_the_gate_skips_instead_of_writing(self):
        """A dictionary that fails validation must set a bit and return false.

        Falling through to the managed call on a rejected dictionary would make
        the gate decorative. And it must reuse inv_allies_dict rather than
        inventing a flag: "the Allies dictionary is not usable" is the same
        finding as "there was no Allies dictionary", and one name means the
        report cannot grow a second spelling of one condition.
        """
        obj = self.allies.find("is_il2cpp_object_likely_valid(allies)")
        self.assertGreater(obj, 0, "precondition: the gate exists")
        window = self.allies[obj:obj + 1200]
        self.assertIn("mask |= inv_allies_dict", window,
                      "the rejection path does not record why it skipped")
        self.assertIn("return false", window,
                      "the rejection path does not return; it falls through into "
                      "the managed call it just rejected")

    def test_negative_control_removing_the_dictionary_gate_goes_red(self):
        """Delete the gate and the order assertions must notice.

        Without this, the three assertions above could all be satisfied by a
        check that lives in a comment or after the call.
        """
        self.assertIn("is_il2cpp_object_likely_valid", self.allies,
                      "precondition: the gate is present")
        mutated = re.sub(r"is_il2cpp_object_likely_valid\(allies\)", "true /*gone*/",
                         self.allies)
        self.assertNotEqual(mutated, self.allies, "could not build the control")
        self.assertNotIn("is_il2cpp_object_likely_valid(allies)", mutated,
                         "the mutated helper still validates the dictionary")

    # -- the hidden trailing MethodInfo* (fix of 2026-10-12 19:27) --------

    def test_every_managed_call_in_the_chain_carries_a_methodinfo(self):
        """THE CALLING-CONVENTION FIX, and the load-bearing assertion for it.

        The 19:27 crash (dump EscapeFromTarkov.exe.21808.dmp, build 0x6ACD08AE)
        faulted at GameAssembly+0x5B1DA4 reading 0xFFFFFFFFFFFFFFFF. That RVA is
        the FIRST instruction of a shared generic-instantiation body --
        `mov rax, [r8+0x20]` -- i.e. the body reads its hidden trailing
        MethodInfo* argument out of r8. A bare 2-argument methodPointer call
        never sets r8, so it held leftover resolver garbage and the read landed
        at the all-ones sentinel.

        This build also contained the dictionary validation added that morning,
        which RAN and PASSED, which is why the fix is the argument and not a
        pointer test: a shape check cannot see a calling-convention violation.

        Asserted structurally rather than by naming each site, because the chain
        has nine of them and a future addition would otherwise be missed. The
        check is that the two managed invocations in the ally write path both
        pass a MethodInfo* argument.
        """
        for call in ("contains(allies, local_player,", "add(allies, local_player, info,"):
            idx = self.allies.find(call)
            self.assertNotEqual(
                idx, -1,
                f"the managed call '{call}...' does not pass the hidden trailing "
                "MethodInfo*. A bare 2-argument call leaves r8 with leftover "
                "resolver garbage, which shared-generic bodies dereference -- "
                "that is the 2026-10-12 19:27 crash.")
            # The argument must be the resolved pointer, not a coincidental third.
            tail = self.allies[idx:idx + 60]
            self.assertRegex(tail, r",\s*(contains_mi|add_mi)\s*\)",
                             f"'{call}...' does not pass the resolved MethodInfo* as "
                             "its trailing argument")

    def test_the_methodinfo_pointers_are_actually_resolved(self):
        """A MethodInfo* argument is worthless unless it was RESOLVED.

        Passing an always-null trailing argument would reproduce the same fault
        more subtly. Asserted on the resolution site, so a refactor that drops
        the resolve_mi helper fails here.
        """
        self.assertIn("resolve_mi<bool (*)(Il2CppObject*, Il2CppObject*)>(",
                      self.allies,
                      "the ContainsKey MethodInfo* is not resolved through the "
                      "with_methodinfo helper; it is either missing or uninitialised")
        self.assertIn("resolve_mi<void (*)(Il2CppObject*, Il2CppObject*, Il2CppObject*)>(",
                      self.allies,
                      "the Add MethodInfo* is not resolved through the with_methodinfo "
                      "helper")
        # And the helper must actually acquire the pointer, not discard it.
        self.assertIn("get_method<il2utils::with_methodinfo_t<FP>>", self.code,
                      "resolve_mi no longer resolves through with_methodinfo_t; the "
                      "trailing MethodInfo* is not being obtained")

    def test_negative_control_dropping_the_methodinfo_goes_red(self):
        """Revert one call site to the bare form and the fix's test must go red.

        Without this control the assertion above could be satisfied by prose or
        by a site that happens to spell the argument name.
        """
        anchor = "contains(allies, local_player, contains_mi)"
        self.assertIn(anchor, self.allies, "precondition: the safe call is present")
        mutated = self.allies.replace(anchor, "contains(allies, local_player)")
        self.assertNotIn(anchor, mutated, "the mutated helper still passes it")

    # -- negative controls ------------------------------------------------

    def test_negative_control_dropping_the_new_chain_goes_red(self):
        """The port is the whole fix; removing it must fail."""
        self.assertIn("get_BotGroupHostility", self.body,
                      "precondition: the new chain is present")
        mutated = self.body.replace("get_BotGroupHostility", '"__gone__"')
        self.assertNotEqual(mutated, self.body, "could not build the control")
        self.assertNotIn("get_BotGroupHostility", mutated,
                         "the mutated body still references the new chain")

    def test_negative_control_a_silent_continue_goes_red(self):
        """Remove the bit from one failure path and the accounting must notice.

        Mutates the FIRST `continue` that currently records a reason, so the
        control is aimed at the assertion that matters rather than at a token.
        """
        blocks = continue_blocks(self.body)
        recorded = [b for b in blocks if "mask |=" in b]
        self.assertTrue(recorded, "precondition: some continue records a reason")

        victim = recorded[0]
        # The assignment must go, not be commented out. Commenting it leaves the
        # substring `mask |=` in place, and the check under test is a substring
        # test -- so the first version of this control mutated to
        # `/* mask |= */ inv_is_your_player;` and passed, having changed nothing.
        stripped = re.sub(r"mask \|=\s*inv_\w+\s*;", "", victim, count=1)
        self.assertNotIn("mask |=", stripped,
                         "the control did not actually remove the assignment")
        mutated = self.body.replace(victim, stripped, 1)
        self.assertNotEqual(mutated, self.body, "could not build the control")

        after = [b for b in continue_blocks(mutated)
                 if "mask |=" not in b and "is_not_a_bot" not in b]
        self.assertTrue(after,
                        "a `continue` that records nothing was NOT detected -- "
                        "the accounting check cannot fail")

    def test_negative_control_an_ungated_report_goes_red(self):
        """Remove the change guard and the per-frame-cost assertion must fire."""
        body = fn_body(self.code, "static void report_invisible_link_state(")
        self.assertIn("if (!changed) return;", body,
                      "precondition: the report is gated")
        mutated = body.replace("if (!changed) return;", "", 1)
        self.assertNotEqual(mutated, body, "could not build the control")
        self.assertNotIn("if (!changed) return;", mutated,
                         "the mutated report is still gated")

    # -- corroboration, only where the dumps exist -----------------------

    @unittest.skipUnless(ISIL_NEW.exists(),
                         "ISIL-references/120047888 is gitignored and absent")
    def test_corroboration_the_dumps_agree_with_the_port(self):
        """The names the code resolves are the names the current dump declares.

        Optional by construction: ISIL-references is gitignored and regenerated
        locally, so this cannot be a hard dependency. It is here because it is
        the only assertion that checks the code against the game rather than
        against itself.
        """
        hostility = ISIL_NEW / "IsilDump" / "Assembly-CSharp" / "BotGroupHostility.txt"
        self.assertTrue(hostility.exists(),
                        "120047888 has no BotGroupHostility.txt -- the port is "
                        "built on a type that does not exist")
        text = hostility.read_text(encoding="utf-8", errors="replace")
        for name in ("RemoveEnemyAction", "AddNeutralAction"):
            self.assertIn(f"Method: System.Void {name}(", text,
                          f"BotGroupHostility does not declare {name}")

        group = ISIL_NEW / "IsilDump" / "Assembly-CSharp" / "BotsGroup.txt"
        gtext = group.read_text(encoding="utf-8", errors="replace")
        self.assertIn("Method: BotGroupHostility get_BotGroupHostility()", gtext,
                      "BotsGroup no longer exposes get_BotGroupHostility")

        # Ally path: Allies dict and BotGroupEnemyInfo class
        self.assertIn("this.Allies (System.Collections.Generic.Dictionary`2<EFT.IPlayer, BotGroupEnemyInfo>)", text,
                      "BotGroupHostility has no Allies field")
        self.assertIn("BotGroupEnemyInfo", text,
                      "BotGroupHostility does not reference BotGroupEnemyInfo")


if __name__ == "__main__":
    unittest.main()
