"""The projection's per-POINT work must stay hoisted to per-PASS. 2026-10-05.

THE MEASUREMENT THAT PROMPTED THIS. `05.10_good.tracy` (186 MB, exported 21:25):

    aimbot::project_to_screen        147,706 calls   2.0386 s total
                                   self 0.5531 s   mean 3.744 us
                                   self MAX 39,695.575 us

The worst aimbot frame was `aimbot::candidate_pick` at 39,890.913 us -- 190 us from
that 39.7 ms -- so the frame *was* that call. And because self ~= total on the worst
call, nothing zoned inside it held any of the time.

Two things had to be established before this test could mean anything, and both were
initially got wrong:

  * `aimbot::project_to_screen` is NOT the projection. The zone opens at
    AimbotModule.cpp:859 and stays open to the end of the loop body, so its 2.0386 s
    includes `aimbot::wall_check_call`'s 1.1336 s. The projection's own cost is the
    0.5531 s self figure, and the *mean* of 3.744 us is unremarkable. Only the tail is.
  * "Self" here does not mean cheap arithmetic. The zone's body contained an
    UNZONED call, so that call's whole cost was self time -- which is why a 39.7 ms
    outlier had no explanation anywhere in the export: the function causing it was
    not a row.

That unzoned call was `calibrate_optic_radial_scale_impl`, invoked PER PROJECTED
POINT at `eft_api.h:4115`. It is a geometric solve, not a lookup: two managed
resolutions (get_forward, get_right), a transform read, two `camera_pixel_*`
`cached_method` lookups, and two probe projections -- every one of them repeated for
a result whose inputs (camera, FPS reference, zoom) are fixed for the pass.

So the fix is a hoist, and these assertions exist because a hoist is invisible to the
compiler: deleting the `f.cam_w` argument reverts the optimisation silently and
everything still builds, still passes, and still looks correct in the log.
"""

from __future__ import annotations

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
API = ROOT / "TarkovAddons" / "module" / "eft_api.h"
AIM = ROOT / "TarkovAddons" / "module" / "impl" / "AimbotModule.cpp"


def blank_comments(src: str) -> str:
    """Blank // and /* */ comments, keeping length. Strings are KEPT.

    Comments must go: the rationale for this change is long, sits directly above the
    code it constrains, and would otherwise satisfy every assertion below on its own.
    Strings stay so functions can be located by name.
    """
    out = list(src)
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == '"':
            i += 1
            while i < n and src[i] != '"':
                i += 2 if src[i] == "\\" else 1
            i += 1
            continue
        if c == "/" and i + 1 < n and src[i + 1] == "/":
            j = src.find("\n", i)
            j = n if j < 0 else j
            for k in range(i, j):
                out[k] = " "
            i = j
        elif c == "/" and i + 1 < n and src[i + 1] == "*":
            j = src.find("*/", i + 2)
            j = n if j < 0 else j + 2
            for k in range(i, j):
                out[k] = " "
            i = j
        else:
            i += 1
    return "".join(out)


def body(code: str, header: str) -> str:
    """The text of a function, from its signature to the brace that closes it.

    Brace-matched rather than regex-to-blank-line, because these are long functions
    with nested blocks and an assertion satisfied by the wrong one of them is worse
    than no assertion.
    """
    m = re.search(re.escape(header), code)
    if not m:
        raise AssertionError("could not find %r -- renamed or removed; fix this test "
                             "rather than loosening it" % header)
    i = code.index("{", m.end())
    depth = 0
    for j in range(i, len(code)):
        if code[j] == "{":
            depth += 1
        elif code[j] == "}":
            depth -= 1
            if depth == 0:
                return code[m.start(): j + 1]
    raise AssertionError("no closing brace for %r" % header)


class TestProjectionWorkIsHoistedToThePass(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = API.read_text(encoding="utf-8", errors="replace")
        cls.code = blank_comments(cls.raw)
        cls.with_frame = body(cls.code, "inline unity::vector3 world_to_screen_with_frame(")
        cls.resolver = body(cls.code, "inline esp_camera_frame resolve_esp_camera_frame(")
        cls.w2s_fps_sig = re.search(
            r"inline unity::vector3 world_to_screen_fps\([^)]*\)", cls.code, re.S)
        assert cls.w2s_fps_sig, "world_to_screen_fps signature not found"

    # ------------------------------------------------------------------ the fix
    def test_with_frame_does_not_calibrate_unconditionally(self):
        """The regression itself: a bare per-point calibrate call.

        Deliberately anchored on the ASSIGNMENT (`float k = `), not on the callee
        name. The fallback that recomputes when the frame carries no calibration is
        the point -- the name still has to appear, so a test matching the name would
        pass on the fallback alone and prove nothing.
        """
        self.assertNotRegex(
            self.with_frame,
            r"float\s+k\s*=\s*calibrate_optic_radial_scale_impl\s*\(",
            "world_to_screen_with_frame calls calibrate_optic_radial_scale_impl "
            "unconditionally again, i.e. once per projected point. That solve costs "
            "two managed resolutions, a transform read, two cached_method lookups and "
            "two probe projections, and it is what made aimbot::project_to_screen's "
            "SELF max 39,695.575 us with no zoned child to explain it",
        )

    def test_with_frame_reads_the_hoisted_calibration(self):
        self.assertRegex(
            self.with_frame,
            r"float\s+k\s*=\s*f\.optic_radial_k\s*>=?\s*0",
            "world_to_screen_with_frame must take the calibration from "
            "esp_camera_frame.optic_radial_k, with the recompute kept only as a "
            "fallback for a frame that was not built by resolve_esp_camera_frame",
        )

    def test_resolver_populates_all_three_fields(self):
        for field in ("cam_w", "cam_h", "optic_radial_k"):
            with self.subTest(field=field):
                self.assertRegex(
                    self.resolver,
                    r"f\.%s\s*=" % field,
                    "resolve_esp_camera_frame no longer populates f.%s, so the "
                    "per-pass hoist never happens and every projected point pays for "
                    "it again" % field,
                )

    def test_the_calibration_is_actually_computed_not_just_assigned(self):
        """The right-hand side, not the existence of an assignment.

        Found by negative control. Asserting `f.optic_radial_k =` is present is NOT
        enough: replacing the calibrate call with a constant `1.f` satisfies it and
        passes 8/8, while making every optic projection use k = 1 -- i.e. silently
        switching off magnification correction, a wrong picture rather than a slow
        one, and therefore invisible in any profile.

        This is the third time in this repo's history that an assertion on the
        presence of a token passed while the behaviour was gone: the pen-check test
        reading a verdict out of a log's prose, and the closed-set pen_stop bucket.
        The lesson generalises -- assert the VALUE, not the NAME.
        """
        self.assertRegex(
            self.resolver,
            r"f\.optic_radial_k\s*=\s*calibrate_optic_radial_scale_impl\s*\(",
            "f.optic_radial_k is assigned, but not from "
            "calibrate_optic_radial_scale_impl. If it is a constant the frame still "
            "looks populated and every optic projection gets a fabricated k",
        )

    def test_with_frame_passes_the_hoisted_dimensions(self):
        """Both, or the FPS branch keeps paying two cached_method lookups per point."""
        m = re.search(r"world_to_screen_fps\s*\(([^;]*?)\)\s*;", self.with_frame, re.S)
        self.assertIsNotNone(m, "world_to_screen_with_frame no longer calls world_to_screen_fps")
        args = m.group(1)
        self.assertIn("f.cam_w", args, "the hoisted cam_w is not being passed")
        self.assertIn("f.cam_h", args, "the hoisted cam_h is not being passed")

    def test_w2s_fps_defaults_preserve_every_other_caller(self):
        """The other nine call sites pass three arguments and must keep compiling.

        This is why the parameters are defaulted rather than required: a required
        parameter would have forced edits at ten call sites across the ESP and optics
        paths, which are other workstreams' surfaces.
        """
        self.assertRegex(
            self.w2s_fps_sig.group(0),
            r"pre_cam_w\s*=\s*-1",
            "pre_cam_w must default to -1 (\"resolve it here\") or the nine existing "
            "three-argument callers stop compiling",
        )
        self.assertRegex(self.w2s_fps_sig.group(0), r"pre_cam_h\s*=\s*-1")

    # ------------------------------------------- the constraint a compiler misses
    def test_populate_sits_below_the_fps_equals_cam_guard(self):
        """ORDER IS THE BEHAVIOURAL RISK and no compiler checks it.

        `resolve_esp_camera_frame` normalises `f.fps = nullptr` when the FPS reference
        IS the camera, because handing the calibrator the optic camera as its own
        reference is a self-calibration. `world_to_screen_with_frame` calibrated with
        the NORMALISED value. Populating optic_radial_k above that guard would pass
        the un-normalised pointer and silently change the calibration on every optic
        frame -- a wrong number, not a slow one, and therefore invisible in a profile.
        """
        guard = self.resolver.find("f.fps == f.cam")
        self.assertGreaterEqual(guard, 0, "the fps==cam normalisation is gone from "
                                          "resolve_esp_camera_frame")
        populate = self.resolver.find("f.optic_radial_k =")
        self.assertGreaterEqual(populate, 0)
        self.assertGreater(
            populate, guard,
            "f.optic_radial_k is assigned ABOVE the `f.fps == f.cam` normalisation. "
            "world_to_screen_with_frame calibrated with the normalised fps, so this "
            "would pass the optic camera as its own FPS reference -- the "
            "self-calibration that guard exists to prevent",
        )

    # ------------------------------------------------------ so it can be SEEN
    def test_the_calibration_is_zoned(self):
        """Without a row, the next capture cannot tell whether the hoist worked.

        This is the whole reason the 39.7 ms was unattributable: the function causing
        it was not a row, so its cost silently became its caller's self time.
        """
        cal = body(self.code, "inline float calibrate_optic_radial_scale_impl(")
        self.assertRegex(
            cal,
            r'TA_ZONE_N\(\s*"eft_api::calibrate_optic_radial_scale"',
            "calibrate_optic_radial_scale_impl is unzoned again. Its cost then lands "
            "in the caller's SELF time, which is precisely how a 39.7 ms outlier "
            "came to have no explanation in the export",
        )
        # Above the early return, so the cheap rejection is counted too. Otherwise
        # the row reads as "cost of calibrating" when most calls never calibrated.
        zone = cal.find("TA_ZONE_N(")
        self.assertLess(zone, cal.find("if (!optic) return 1.f;"))

    def test_the_aimbot_zone_still_wraps_the_loop_body(self):
        """Documents, rather than enforces, the misreading that cost time here.

        `aimbot::project_to_screen` opens at AimbotModule.cpp:859 and closes at the end
        of the candidate loop body, so it also covers `is_visible`, the cone gate and
        the WALL CHECK. Reading its 2.0386 s as "the projection" is wrong by 1.1336 s.

        Not changed here: narrowing the zone would be a behaviour-neutral refactor of
        the aimbot's hot loop, and this change is about a measured stall, not about
        tidiness. Recorded so the next reader does not repeat the inference.
        """
        self.assertRegex(
            blank_comments(AIM.read_text(encoding="utf-8", errors="replace")),
            r'TA_ZONE_N\(\s*"aimbot::project_to_screen"',
        )


if __name__ == "__main__":
    unittest.main()