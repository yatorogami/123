""".clang-tidy must keep saying what it was measured saying.

The check list in `.clang-tidy` is a curated list, and a curated list rots
silently: nobody notices when a suppression stops being needed, and nobody
notices when the header filter starts letting the Unity-generated tree back
in. The second one already happened once -- an allow-list that accepted
`.../TarkovAddons/module/...` also accepted the `libil2cpp/` two `..` away
from it, and 45 of 64 diagnostics in a probe run were vendored headers.

So this file does two things:

  * runs the actual HeaderFilterRegex against the paths clang-tidy really
    prints, including the `../..` reach-through form, and asserts both
    directions -- vendored excluded, first-party included
  * asserts that every disabled check carries a measured justification
    comment, so "turn it off because it is noisy" cannot become the default
    answer by repetition

It does not run clang-tidy. The full run is `tools/run_tidy.ps1` and takes
about 3.6 minutes; this is the part that must be fast enough to run on
every edit to the config.
"""

import re
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
CONFIG = REPO / ".clang-tidy"

# Paths exactly as clang-tidy printed them in the runs that produced the
# numbers in the config. The `../..` ones are the leak that motivated the
# negative lookaheads.
VENDORED_PATHS = [
    "D:/TarkovAddonsReloaded/TarkovAddons/external/imgui/imgui.h",
    "D:/TarkovAddonsReloaded/TarkovAddons/external/tracy/TracyClient.cpp",
    "D:/TarkovAddonsReloaded/TarkovAddons/module/impl/../../il2cpp/libil2cpp/il2cpp-api-types.h",
    "D:/TarkovAddonsReloaded/TarkovAddons/module/impl/..\\../il2cpp/../../external/safetyhook/safetyhook.hpp",
    "D:/TarkovAddonsReloaded/TarkovAddons/config/../module/../external/nlohmann/json.hpp",
    "D:/TarkovAddonsReloaded/TarkovAddons/include/common.h",
    # Not ours at all -- a different checkout on the same drive.
    "D:/SomeOtherProject/module/thing.h",
]

FIRST_PARTY_PATHS = [
    "D:/TarkovAddonsReloaded/TarkovAddons/util/scan.h",
    "D:/TarkovAddonsReloaded/TarkovAddons/module/impl/../eft_api.h",
    "D:/TarkovAddonsReloaded/TarkovAddons/module/impl/../../il2cpp/compatibility_profile.h",
    "D:/TarkovAddonsReloaded/TarkovAddons/config/CheckboxValue.cpp",
    "D:/TarkovAddonsReloaded/shared/module_paths.h",
    "D:/TarkovAddonsReloaded/TarkovLauncherBypass/feature/disabler.cpp",
]


def _config_text():
    assert CONFIG.exists(), f"no .clang-tidy at {CONFIG}"
    return CONFIG.read_text(encoding="utf-8", errors="replace")


def _yaml_scalar(key):
    """Pull one top-level scalar out of .clang-tidy without a YAML dependency.

    Only handles what this file actually contains: `Key: value`, or `Key: >`
    with indented continuation lines (a folded block scalar). That is enough
    for `Checks:` and `HeaderFilterRegex:`, and a real YAML parser is not
    worth a dependency the rest of tools/ does not have.
    """
    text = _config_text()
    m = re.search(rf"^{re.escape(key)}:\s*(.*)$", text, re.MULTILINE)
    assert m, f".clang-tidy has no `{key}`"
    first = m.group(1).strip()
    if first in (">", "|", ">-", "|-"):
        body = []
        for line in text[m.end():].splitlines():
            if line.strip() and not line.startswith((" ", "\t")):
                break
            body.append(line.strip())
        return " ".join(x for x in body if x)
    # Single-quoted YAML scalar: '' is a literal quote, everything else stands.
    assert first.startswith("'") and first.endswith("'"), f"{key} is quoted unexpectedly: {first}"
    return first[1:-1].replace("''", "'")


def _unescape(pattern: str) -> str:
    """`.clang-tidy` writes regex backslashes YAML-escaped: ``\\\\/`` -> ``\\/``."""
    return pattern.replace("\\\\", "\\")


# ---------------------------------------------------------------------------
# The header filter
# ---------------------------------------------------------------------------


def test_header_filter_excludes_vendored_and_foreign_paths():
    rx = re.compile(_unescape(_yaml_scalar("HeaderFilterRegex")))
    for path in VENDORED_PATHS:
        assert not rx.search(path), f"vendored/foreign path would be analysed: {path}"


def test_header_filter_keeps_first_party_paths():
    rx = re.compile(_unescape(_yaml_scalar("HeaderFilterRegex")))
    for path in FIRST_PARTY_PATHS:
        assert rx.search(path), f"first-party path would be silently dropped: {path}"
    # TarkovAddons/dllmain.cpp is deliberately absent from both lists. It is a
    # file directly under TarkovAddons/, so an alternation that requires a
    # trailing directory separator can never name it -- and it does not need
    # to be named, because HeaderFilterRegex governs headers only. An earlier
    # config listed it anyway, inside an unreachable branch.


def test_header_filter_agrees_with_the_real_tree():
    """Run it over every header actually on disk, not a hand-written sample.

    The failure this guards against is not a typo in a test fixture; it is
    someone adding a new vendored tree under a directory name the lookaheads
    do not know about.
    """
    rx = re.compile(_unescape(_yaml_scalar("HeaderFilterRegex")))
    vendored = ("external", "libil2cpp", "include", "build", "out", "x64", "GameDump")
    leaked, kept = [], 0
    for path in REPO.rglob("*"):
        if path.suffix.lower() not in (".h", ".hpp", ".c", ".cpp") or not path.is_file():
            continue
        rel = path.relative_to(REPO)
        if rel.parts[0] in ("build", "x64", "out", ".git"):
            continue
        posix = "D:/TarkovAddonsReloaded/" + rel.as_posix()
        hit = bool(rx.search(posix))
        if any(p in vendored for p in rel.parts[:-1]):
            if hit:
                leaked.append(posix)
        elif hit:
            kept += 1
    assert not leaked, "header filter lets vendored code back in:\n  " + "\n  ".join(leaked[:10])
    assert kept >= 40, f"only {kept} first-party headers match; the filter is too strict"


# ---------------------------------------------------------------------------
# The check list
# ---------------------------------------------------------------------------


def test_starts_from_a_clean_slate():
    """`-*` first, or the check list is additive and cannot be curated."""
    checks = _yaml_scalar("Checks")
    assert checks.startswith("-*"), checks[:60]


def test_every_disabled_check_has_a_measured_justification():
    """No suppression without a number attached to it.

    `.clang-tidy` disables six checks. Each one names a file and a hit count
    in the comment block below the check list. This asserts the comment block
    still mentions every disabled check, so a check added to the list without
    a reason fails here rather than accumulating silently.
    """
    checks = [c.strip() for c in _yaml_scalar("Checks").split(",")]
    disabled = [c[1:] for c in checks if c.startswith("-") and c != "-*"]
    assert disabled, "nothing is disabled; is the list still curated?"

    text = _config_text()
    for check in disabled:
        assert re.search(rf"^\s*#?\s*{re.escape(check)}\b", text, re.MULTILINE), (
            f"{check} is disabled but nothing in .clang-tidy explains why. "
            "Add a comment naming the file and the hit count."
        )


def test_analyzer_warnings_are_not_errors():
    """This is a report, not a gate. There is no test target in the build and
    turning a warning into an error here would only make people mute it."""
    assert "clang-tidy" in _config_text()
    assert _yaml_scalar("WarningsAsErrors").strip() == ""


# ---------------------------------------------------------------------------
# The analysis tree it depends on
# ---------------------------------------------------------------------------


def test_no_pch_is_opt_in_and_default_off():
    """TA_NO_PCH makes the tree several times slower and is never what ships."""
    top = (REPO / "CMakeLists.txt").read_text(encoding="utf-8", errors="replace")
    m = re.search(r"option\(TA_NO_PCH\s+\"[^\"]*\"\s+(ON|OFF)\)", top)
    assert m, "TA_NO_PCH is not declared as an option in the top-level CMakeLists"
    assert m.group(1) == "OFF", "TA_NO_PCH must default to OFF; it is not the shipping configuration"


def test_the_pch_is_still_gated_behind_that_option():
    sub = (REPO / "TarkovAddons" / "CMakeLists.txt").read_text(encoding="utf-8", errors="replace")
    assert "if(NOT TA_NO_PCH)" in sub, "target_precompile_headers is no longer conditional"
    assert "TA_NO_PCH=ON" in sub, "the option is not mentioned where it takes effect"


def test_run_tidy_uses_a_separate_tree():
    """It must not point clang-tidy at the shipping build tree.

    That tree's compile_commands.json references a cl.exe-produced .pch, and
    clang cannot read one:
        error: file '...cmake_pch.cxx.pch' is not a valid PCH file
    """
    script = (REPO / "tools" / "run_tidy.ps1").read_text(encoding="utf-8", errors="replace")
    assert "TA_NO_PCH=ON" in script, "the analysis tree is not configured without the PCH"
    assert "build\\analysis" in script or "build/analysis" in script, (
        "the analysis tree must not live under build/Prod -- that is the shipping tree"
    )
    assert "compile_commands.json" in script, "the script must fall back to the build tree"


if __name__ == "__main__":  # pragma: no cover
    sys.exit(pytest.main([__file__, "-v"]))
