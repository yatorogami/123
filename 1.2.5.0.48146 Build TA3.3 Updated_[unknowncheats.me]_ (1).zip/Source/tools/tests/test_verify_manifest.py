"""Tests for tools/verify/verify_manifest.py.

The real verification needs GameDump/, which is gitignored ("regenerate
locally"), so it cannot be part of the suite that must pass on a fresh clone.
These tests exercise the same code against a synthesized minimal PE.

The point of that arrangement is the failure mode this repo keeps being bitten
by: a checker that cannot fail. So the emphasis is on the negative controls --
each test asserts a specific defect IS caught, and `test_the_verifier_can_fail`
deliberately breaks the manifest and requires the run to go red.
"""
from __future__ import annotations

import json
import struct
import tempfile
import unittest
from pathlib import Path

from tools.verify.verify_manifest import (
    EXIT_NOTHING_CHECKED,
    EXIT_OK,
    EXIT_PROBLEM,
    PE,
    main,
    parse_pattern,
    verify,
)

REPO = Path(__file__).resolve().parents[2]


def make_pe(text_hex: str = "48 89 5C 24 08 57 48 83 EC 20 90 90 90 90",
            timestamp: int = 0x6AAD381A,
            image_size: int = 0x2000) -> bytes:
    """Minimal PE32+ with a single .text section at RVA 0x1000."""
    pe_offset = 0x80
    optional_offset = pe_offset + 4 + 20
    optional_size = 0xF0
    section_offset = optional_offset + optional_size
    raw_offset = 0x200
    raw_size = 0x200
    data = bytearray(raw_offset + raw_size)

    data[0:2] = b"MZ"
    struct.pack_into("<I", data, 0x3C, pe_offset)
    data[pe_offset:pe_offset + 4] = b"PE\0\0"
    struct.pack_into("<H", data, pe_offset + 4, 0x8664)
    struct.pack_into("<H", data, pe_offset + 6, 1)
    struct.pack_into("<I", data, pe_offset + 8, timestamp)
    struct.pack_into("<H", data, pe_offset + 20, optional_size)
    struct.pack_into("<H", data, optional_offset, 0x20B)
    struct.pack_into("<I", data, optional_offset + 56, image_size)
    struct.pack_into("<I", data, optional_offset + 60, raw_offset)
    data[section_offset:section_offset + 5] = b".text"
    struct.pack_into("<I", data, section_offset + 8, 0x1000)   # VirtualSize
    struct.pack_into("<I", data, section_offset + 12, 0x1000)  # RVA
    struct.pack_into("<I", data, section_offset + 16, raw_size)
    struct.pack_into("<I", data, section_offset + 20, raw_offset)
    data[raw_offset:raw_offset + len(bytes.fromhex(text_hex.replace(" ", "")))] = \
        bytes.fromhex(text_hex.replace(" ", ""))
    return bytes(data)


MODULE_PATTERN = "48 89 5C 24 08 57 48 83 EC 20"


def write_module(directory: Path, name: str = "GameAssembly.dll", **kw) -> Path:
    path = directory / name
    path.write_bytes(make_pe(**kw))
    return path


class ParserTests(unittest.TestCase):
    def test_pattern_parser_accepts_whole_byte_wildcards(self) -> None:
        self.assertEqual(parse_pattern("48 00 ? 89"), [0x48, 0x00, None, 0x89])
        self.assertEqual(parse_pattern("48 ?? 89"), [0x48, None, 0x89])
        with self.assertRaises(ValueError):
            parse_pattern("48 0 89")
        with self.assertRaises(ValueError):
            parse_pattern("48 GGGG")

    def test_pe_reads_identity_and_maps_rva(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            p = write_module(Path(d))
            pe = PE(p)
            self.assertEqual(pe.size_of_image, 0x2000)
            self.assertEqual(pe.timestamp, 0x6AAD381A)
            self.assertEqual(pe.machine, 0x8664)
            self.assertEqual(pe.file_offset(0x1000), 0x200)
            self.assertIsNone(pe.file_offset(0x3000))       # past SizeOfImage
            self.assertIsNone(pe.file_offset(0x1F00, 0x200))  # past the raw section
            self.assertIsNotNone(pe.text_sha256())
            self.assertEqual(pe.scan(parse_pattern(MODULE_PATTERN)), [0x1000])

    def test_non_pe_is_rejected_not_silently_accepted(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "GameAssembly.dll"
            p.write_bytes(b"not a PE at all" * 40)
            with self.assertRaises(ValueError):
                PE(p)


class VerifyTests(unittest.TestCase):
    def _run(self, manifest: dict, *, cfg_dir: str = "") -> tuple:
        """Verify twice: as a library, and through the CLI for its exit code."""
        d = Path(tempfile.mkdtemp())
        write_module(d)
        rep = verify(manifest, d, Path(cfg_dir) if cfg_dir else None, verbose=False)
        mp = d / "manifest.json"
        mp.write_text(json.dumps(manifest), encoding="utf-8")
        code = main([str(mp), str(d), "--cfg-dir", cfg_dir, "-q"])
        return rep, code

    def test_a_correct_manifest_passes(self) -> None:
        rep, code = self._run(self._manifest())
        self.assertEqual(rep.problems, [])
        self.assertEqual(rep.symbols_checked, 1)
        self.assertEqual(code, EXIT_OK)

    @staticmethod
    def _manifest(**kw) -> dict:
        tmp = tempfile.mkdtemp()
        p = write_module(Path(tmp))
        m = {
            "schema_version": 1,
            "profile": {"id": "t", "game_version": "t"},
            "modules": {"GameAssembly.dll": {
                "size": 0x2000,
                "pe_timestamp": "0x6AAD381A",
                "text_sha256": PE(p).text_sha256(),
            }},
            "symbols": [{
                "name": "test_symbol",
                "module": "GameAssembly.dll",
                "kind": "function",
                "resolver": "native",
                "rva": "0x1000",
                "patterns": [MODULE_PATTERN],
                "required": True,
            }],
        }
        m["symbols"][0].update(kw)
        return m

    # ---- the negative controls: each defect must be caught ----------------

    def test_wrong_text_sha256_is_caught(self) -> None:
        m = self._manifest()
        m["modules"]["GameAssembly.dll"]["text_sha256"] = "0" * 64
        rep, code = self._run(m)
        self.assertTrue(any("text_sha256" in p for p in rep.problems), rep.problems)
        self.assertEqual(code, EXIT_PROBLEM)

    def test_wrong_size_is_caught(self) -> None:
        m = self._manifest()
        m["modules"]["GameAssembly.dll"]["size"] = 0x1234
        rep, _ = self._run(m)
        self.assertTrue(any("size" in p for p in rep.problems), rep.problems)

    def test_wrong_timestamp_is_caught(self) -> None:
        m = self._manifest()
        m["modules"]["GameAssembly.dll"]["pe_timestamp"] = "0xDEADBEEF"
        rep, _ = self._run(m)
        self.assertTrue(any("pe_timestamp" in p for p in rep.problems), rep.problems)

    def test_pattern_that_matches_nothing_is_caught(self) -> None:
        rep, code = self._run(self._manifest(patterns=["FF FF FF FF FF FF"]))
        self.assertTrue(any("no match" in p for p in rep.problems), rep.problems)
        self.assertEqual(code, EXIT_PROBLEM)

    def test_ambiguous_pattern_is_caught(self) -> None:
        # Two identical sequences in .text -> the pattern is ambiguous.
        m = self._manifest(patterns=["90 90 90 90"])
        d = Path(tempfile.mkdtemp())
        blob = bytearray(make_pe())
        for off in (0x200, 0x280):
            blob[off:off + 4] = b"\x90\x90\x90\x90"
        (d / "GameAssembly.dll").write_bytes(bytes(blob))
        rep = verify(m, d, None, verbose=False)
        self.assertTrue(any("ambiguous" in p for p in rep.problems), rep.problems)

    def test_rva_not_among_pattern_matches_is_caught(self) -> None:
        rep, code = self._run(self._manifest(rva="0x1004"))
        self.assertTrue(any("not among" in p for p in rep.problems), rep.problems)
        self.assertEqual(code, EXIT_PROBLEM)

    def test_rva_past_the_image_is_caught(self) -> None:
        rep, _ = self._run(self._manifest(rva="0x9999"))
        self.assertTrue(any("outside SizeOfImage" in p for p in rep.problems), rep.problems)

    def test_missing_export_is_caught(self) -> None:
        rep, code = self._run(self._manifest(resolver="export", export_name="nope_not_here"))
        self.assertTrue(any("export" in p.lower() for p in rep.problems), rep.problems)
        self.assertEqual(code, EXIT_PROBLEM)

    def test_module_absent_from_the_directory_is_caught(self) -> None:
        m = self._manifest()
        m["modules"]["UnityPlayer.dll"] = {"size": 1}
        m["symbols"].append({
            "name": "other", "module": "UnityPlayer.dll", "kind": "function",
            "resolver": "native", "rva": None, "patterns": [], "required": False,
        })
        rep, code = self._run(m)
        self.assertTrue(any("UnityPlayer.dll" in p for p in rep.problems), rep.problems)
        self.assertEqual(code, EXIT_PROBLEM)

    # ---- "it cannot pass by comparing nothing" -----------------------------

    def test_missing_module_directory_exits_2_not_0(self) -> None:
        d = Path(tempfile.mkdtemp())
        mp = d / "manifest.json"
        mp.write_text(json.dumps(self._manifest()), encoding="utf-8")
        code = main([str(mp), str(d / "does_not_exist"), "--cfg-dir", "", "-q"])
        self.assertEqual(code, EXIT_NOTHING_CHECKED)

    def test_missing_manifest_exits_2_not_0(self) -> None:
        d = Path(tempfile.mkdtemp())
        write_module(d)
        code = main([str(d / "nope.json"), str(d), "--cfg-dir", "", "-q"])
        self.assertEqual(code, EXIT_NOTHING_CHECKED)

    def test_no_symbols_exits_2_not_0(self) -> None:
        m = self._manifest()
        m["symbols"] = []
        _, code = self._run(m)
        self.assertEqual(code, EXIT_NOTHING_CHECKED,
                         "a manifest with nothing to check must not report success")

    def test_no_modules_exits_2_not_0(self) -> None:
        m = self._manifest()
        m["modules"] = {}
        _, code = self._run(m)
        self.assertEqual(code, EXIT_NOTHING_CHECKED)

    def test_unparseable_module_exits_2_not_0(self) -> None:
        d = Path(tempfile.mkdtemp())
        (d / "GameAssembly.dll").write_bytes(b"garbage" * 100)
        mp = d / "manifest.json"
        mp.write_text(json.dumps(self._manifest()), encoding="utf-8")
        code = main([str(mp), str(d), "--cfg-dir", "", "-q"])
        self.assertEqual(code, EXIT_NOTHING_CHECKED)

    def test_pattern_export_disagreement_is_a_note_not_a_failure(self) -> None:
        """A pattern and the export of the same name are independent addresses.

        This tool has no oracle to adjudicate, so it must NOT call it a defect --
        inventing a failure here would send people chasing a non-bug. It reports
        a NOTE and stays at exit 0.
        """
        m = self._manifest()
        # name the symbol the same as a real export and point the pattern at the
        # one address while the export table is absent: no export -> no note.
        rep, code = self._run(m)
        self.assertEqual(code, EXIT_OK)
        self.assertFalse([n for n in rep.notes if "unresolved without an oracle" in n])

    def test_the_verifier_can_fail(self) -> None:
        """The blanket negative control: sabotage must turn the run red.

        If this passes while the defect is present, every other test in this
        file is decoration.
        """
        m = self._manifest()
        m["modules"]["GameAssembly.dll"]["text_sha256"] = "f" * 64
        m["symbols"][0]["patterns"] = ["DE AD BE EF"]
        _, code = self._run(m)
        self.assertEqual(code, EXIT_PROBLEM)


class ShippedProfileShapeTests(unittest.TestCase):
    """Structural facts about the checked-in profile that need no game files."""

    PROFILE = REPO / "compatibility" / "profiles" / "1.1.5.1.47510" / "manifest.json"

    def test_profile_is_present_and_parses(self) -> None:
        self.assertTrue(self.PROFILE.is_file())
        m = json.loads(self.PROFILE.read_text(encoding="utf-8-sig"))
        self.assertEqual(m["schema_version"], 1)
        self.assertIn(m["profile"]["status"],
                      {"unverified", "staged", "validated", "verified"})

    def test_every_symbol_names_a_declared_module(self) -> None:
        m = json.loads(self.PROFILE.read_text(encoding="utf-8-sig"))
        for s in m["symbols"]:
            self.assertIn(s["module"], m["modules"], s["name"])

    def test_export_resolver_symbols_declare_an_export_name(self) -> None:
        m = json.loads(self.PROFILE.read_text(encoding="utf-8-sig"))
        for s in m["symbols"]:
            if s.get("resolver") == "export":
                self.assertTrue(s.get("export_name"), s["name"])

    def test_required_il2cpp_symbols_are_present(self) -> None:
        m = json.loads(self.PROFILE.read_text(encoding="utf-8-sig"))
        required = {s["name"] for s in m["symbols"] if s.get("required")}
        self.assertEqual(len(required), 14, sorted(required))


if __name__ == "__main__":
    unittest.main()