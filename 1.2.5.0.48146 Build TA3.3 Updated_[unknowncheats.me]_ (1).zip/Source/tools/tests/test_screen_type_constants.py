"""The screen-type constants the minimap-hide check compares against.

On 2026-10-14 the user reported the minimap still drawing over an open
inventory. The gate (`query_ui_blocking_screen_open`, eft_api.h) was reading
the right screen type from the right controller and comparing it against
`constexpr int inventory_screen = 15`. Every dump on disk says Inventory = 16
and TransferItemsInRaid = 43; 15 is `HideoutCircleOfCultists`. So the check
compared against the cultist screen and nothing else, and could never have
fired for an inventory. `query_external_loot_inventory_open` carried the same
wrong pair.

What is under test:

  1. The PARSER against synthetic dump.cs fragments, including the exact trap
     that made the bug invisible: an enum whose entry at 15 is something else
     entirely. A hand-typed constant is an assertion about a moving target,
     and this is the part that keeps it honest on a machine with no dump.
  2. The SHIPPED constants, re-derived from the newest real dump when one is
     present. GameDump/ is gitignored, so this half skips elsewhere -- which
     is why half 1 exists and why the skip says so out loud rather than
     passing quietly.

NEGATIVE CONTROL: the synthetic trap (Inventory = 16, 15 taken by another
entry) fails against the pre-fix 15/42 pair and passes against 16/43; the
real-dump half failed against the shipped tree before 2026-10-14 and passes
after.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
EFT_API = REPO / "TarkovAddons" / "module" / "eft_api.h"
GAMEDUMP = REPO / "TarkovAddons" / "GameDump"

# dump.cs shape: the enum's fields are `public const EEftScreenType Name = N;`
# with `public int value__; // 0x0` first and any entry allowed to omit `= N`
# (implicit increment).
_CONST_RE = re.compile(r"public const EEftScreenType\s+(\w+)\s*=\s*(-?\d+)\s*;")


def parse_screen_types(text: str) -> dict[str, int]:
    m = re.search(r"public enum EEftScreenType[^\n]*\n\{(.*?)\n\}", text, re.DOTALL)
    if not m:
        return {}
    out: dict[str, int] = {}
    val = 0
    for raw in m.group(1).split("public const EEftScreenType")[1:]:
        hit = _CONST_RE.search("public const EEftScreenType" + raw)
        if not hit:
            # implicit-value entry: `public const EEftScreenType Name;` -- rare
            name = raw.split(";")[0].strip()
            if name:
                out[name] = val
                val += 1
            continue
        name, value = hit.group(1), int(hit.group(2))
        out[name] = value
        val = value + 1
    return out


# A fragment in the exact shape dump.cs emits, with the two values this codebase
# needs and -- critically -- a DIFFERENT entry sitting at 15.
SYNTHETIC = """\
// Namespace: EFT.UI.Screens
public enum EEftScreenType // TypeDefIndex: 15895
{
\t// Fields
\tpublic int value__; // 0x0
\tpublic const EEftScreenType None = 0;
\tpublic const EEftScreenType Login = 1;
\tpublic const EEftScreenType ValidateDeviceId = 2;
\tpublic const EEftScreenType Welcome = 3;
\tpublic const EEftScreenType SetNickname = 4;
\tpublic const EEftScreenType SelectPlayerSide = 5;
\tpublic const EEftScreenType CharacterSelection = 6;
\tpublic const EEftScreenType RestorePassword = 7;
\tpublic const EEftScreenType ProfileLoading = 8;
\tpublic const EEftScreenType MainMenu = 9;
\tpublic const EEftScreenType Reconnect = 10;
\tpublic const EEftScreenType BattleUI = 11;
\tpublic const EEftScreenType Hideout = 12;
\tpublic const EEftScreenType HideoutAreaItemsTransfer = 13;
\tpublic const EEftScreenType HideoutAreaMannequinEquipment = 14;
\tpublic const EEftScreenType HideoutCircleOfCultists = 15;
\tpublic const EEftScreenType Inventory = 16;
\tpublic const EEftScreenType TransferItemsInRaid = 43;
\tpublic const EEftScreenType Other = 44;
}
"""


def shipped_constants() -> dict[str, list[int]]:
    """Every `constexpr int <name> = N;` in eft_api.h, by name.

    A list, because the same pair is declared twice -- once inside
    query_external_loot_inventory_open and once inside
    query_ui_blocking_screen_open -- and a checker that reads only the first
    would keep guarding half the surface.
    """
    src = EFT_API.read_text(encoding="utf-8", errors="replace")
    found: dict[str, list[int]] = {}
    for name in ("inventory_screen", "transfer_items_in_raid"):
        found[name] = [
            int(m.group(1))
            for m in re.finditer(rf"constexpr int {name}\s*=\s*(\d+)\s*;", src)
        ]
    return found


def test_parser_reads_the_enum_and_the_trap_entry():
    kinds = parse_screen_types(SYNTHETIC)
    assert kinds.get("Inventory") == 16
    assert kinds.get("TransferItemsInRaid") == 43
    # The trap: whatever sits at 15 is NOT the inventory. If a future parse
    # confuses positions with names this is the line that fails.
    assert kinds.get("HideoutCircleOfCultists") == 15
    assert kinds.get("Inventory") != 15, "Inventory moved to 15; re-check which entry is which"


def test_shipped_constants_match_the_synthetic_dump_shape():
    """The 2026-10-14 bug, pinned: 15/42 vs 16/43.

    The synthetic fragment is the shape every real dump on disk emits, so this
    half runs everywhere -- no gitignored dump required -- and it is the half
    that would have caught the original constants.
    """
    kinds = parse_screen_types(SYNTHETIC)
    shipped = shipped_constants()
    for name, want in (
        ("inventory_screen", kinds["Inventory"]),
        ("transfer_items_in_raid", kinds["TransferItemsInRaid"]),
    ):
        values = shipped[name]
        assert values, f"{name} is no longer declared in eft_api.h"
        assert all(v == want for v in values), (
            f"eft_api.h declares {name} = {values}, but the screen-type enum "
            f"has {name} = {want}. Every declaration site must agree with the "
            f"enum -- a hand-typed constant is an assertion about a target that "
            f"moves, and 15/42 vs 16/43 is exactly how the minimap came to draw "
            f"over an open inventory."
        )


def test_both_functions_declare_the_pair():
    """Two call sites, two declarations -- the checker must see both."""
    shipped = shipped_constants()
    assert len(shipped["inventory_screen"]) == 2, (
        f"expected the pair in BOTH query_external_loot_inventory_open and "
        f"query_ui_blocking_screen_open, found {len(shipped['inventory_screen'])}"
    )
    assert len(shipped["transfer_items_in_raid"]) == 2


def test_real_dump_agrees_when_one_is_present():
    """Re-derive from the newest dump on disk and compare to the shipped code.

    Skips, loudly, when GameDump/ is absent -- a gitignored directory that is
    regenerated per machine. The skip names the reason so a green run on a
    machine with no dump is not mistaken for a checked one.
    """
    dumps = sorted(GAMEDUMP.glob("*/dump.cs")) if GAMEDUMP.is_dir() else []
    if not dumps:
        pytest.skip(
            "no GameDump/*/dump.cs on this machine (gitignored, regenerated "
            "locally) -- the synthetic half above is what runs everywhere"
        )
    kinds = parse_screen_types(dumps[-1].read_text(encoding="utf-8", errors="replace"))
    assert kinds, f"EEftScreenType not found in {dumps[-1]}"
    assert "Inventory" in kinds and "TransferItemsInRaid" in kinds
    shipped = shipped_constants()
    for name in ("inventory_screen", "transfer_items_in_raid"):
        want = kinds["Inventory" if name == "inventory_screen" else "TransferItemsInRaid"]
        assert all(v == want for v in shipped[name]), (
            f"{dumps[-1].parent.name} says {name} = {want}, but eft_api.h "
            f"declares {shipped[name]}. Re-derive from the dump, do not "
            f"carry the old number."
        )
