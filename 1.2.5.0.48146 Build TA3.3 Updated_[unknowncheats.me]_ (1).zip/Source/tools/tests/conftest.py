"""Shared pytest setup for tools/tests.

Puts `tools/` on sys.path so the test files can `import deploy`,
`import migrate_legacy` and friends by name.

This was added when `tools/migrate_legacy.py` appeared. `deploy.py` imports it as
a sibling, which works for the CLI because `python tools/deploy.py` puts tools/ at
sys.path[0] -- but pytest is invoked from the repository root, so tools/ is not on
the path and every test that imported `deploy` failed at collection with
`ModuleNotFoundError: No module named 'migrate_legacy'`.

A conftest is the right place for that rather than a `sys.path.insert` at the top
of each test file: it is applied once, to every test including ones written later,
so the next person adding a tools test does not have to rediscover this.
"""

import sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
if str(TOOLS) not in sys.path:
    sys.path.insert(0, str(TOOLS))


def pytest_configure(config):
    """Register the `slow` marker.

    Used by test_dup_scan.py's whole-tree scale check, which lexes every
    first-party file to re-derive the counts the documentation quotes. It runs
    by default -- it is the check that keeps those counts honest -- but it is
    worth being able to name.
    """
    config.addinivalue_line("markers", "slow: lexes or scans the whole first-party tree")
