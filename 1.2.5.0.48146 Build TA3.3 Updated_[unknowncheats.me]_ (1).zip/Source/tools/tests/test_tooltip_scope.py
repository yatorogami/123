"""A tooltip's padding push and its pop must move as ONE unit.

What this checks
----------------
`imgui_addons.h` exposes `push_tooltip_padding()` / `pop_tooltip_padding()` so
that every tooltip window gets a roomier frame than `theme()`'s (8, 8). The
pair has to wrap a single conditional block:

    if (hovered)
    {
        push_tooltip_padding();
        ImGui::SetTooltip(...);
        pop_tooltip_padding();
    }

Written the obvious-looking way -- three statements under a brace-less `if` --
the condition guards ONLY the first line. `SetTooltip()` then runs
unconditionally (on a null `tooltip` pointer for most rows), and `pop` runs
whether or not `push` did. Where the push is conditional and the pop is not, a
non-hovered row pops a style var an OUTER scope had pushed, which is what
breaks input: a corrupted style/ID stack makes hit-testing land on the wrong
item, and the menu stops responding to clicks at all. That is not a
hypothetical -- it shipped, was reported as "I couldn't click anything", and the
compiler was silent on all of it, because every line was well-formed.

So the invariant is not "it compiles" but "the two calls are inside one block",
and this is where it is enforced.

Why a text test
---------------
A compiler cannot see it: both spellings are valid C++ with identical types.
A runtime test would need a raid. The invariant is entirely in the source, so
the source is where it is checked -- the same argument `test_menu_double_draw`
makes.

The negative control
--------------------
`test_the_control_actually_detects_an_unbraced_push` feeds the regex the exact
defect sentinel and requires it to match. Without it this file could pass by
comparing nothing, which is the failure mode this repository keeps paying for.
"""

import re
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]

# The two files the tooltip wrappers live in. Both are listed explicitly so a
# rename that moves them fails here rather than silently shrinking the checked
# set to zero.
FILES = [
    REPO / "TarkovAddons" / "gui" / "menu" / "imgui_addons.cpp",
    REPO / "TarkovAddons" / "gui" / "menu" / "menu.cpp",
]

# `if (...)` whose body is a bare push on the next line -- no `{` on the
# condition's line, none on its own before the push.
UNBRACED_PUSH = re.compile(
    r"if \([^\n]*\)\n[ \t]*(?:imgui_addons::)?push_tooltip_padding\(\);"
)


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def test_the_files_under_test_exist():
    for path in FILES:
        assert path.exists(), f"{path} is gone -- move this test's FILES, don't delete the entry"


def test_every_tooltip_push_sits_inside_a_braced_block():
    offenders = []
    for path in FILES:
        text = _read(path)
        for m in UNBRACED_PUSH.finditer(text):
            line = text[: m.start()].count("\n") + 1
            offenders.append(f"{path.name}:{line}")
    assert not offenders, (
        "a push_tooltip_padding() is the first statement of a brace-less `if`, so the "
        "SetTooltip() and pop_tooltip_padding() below it run UNCONDITIONALLY -- the "
        "report was 'tooltips overlap' and 'I couldn't click anything'. Wrap all three "
        "in braces: "
        + "; ".join(offenders)
    )


def test_the_sites_are_still_there():
    """The checked set must not be empty, or the test above passes by comparing nothing."""
    total = sum(_read(p).count("push_tooltip_padding();") for p in FILES)
    assert total >= 6, (
        f"only {total} push_tooltip_padding() call sites remain across "
        f"{len(FILES)} files -- the wrappers were renamed or removed, and a checker "
        "that greps for a name that no longer exists is the failure this test exists "
        "to make impossible"
    )


def test_push_and_pop_are_paired_in_every_block():
    """Every push must be followed, within its own block, by exactly one pop."""
    for path in FILES:
        text = _read(path)
        lines = text.splitlines()
        for i, line in enumerate(lines):
            if "push_tooltip_padding();" not in line:
                continue
            window = lines[i : i + 3]
            assert any("pop_tooltip_padding();" in w for w in window), (
                f"{path.name}:{i + 1}: a push with no pop within three lines -- a "
                "style var left on the stack for every frame afterwards"
            )


def test_the_control_actually_detects_an_unbraced_push():
    """In-process control: the pattern must fire on the defect it was written for.

    This is the `test_scanner_catches_a_planted_double_draw` half of this
    file. Without it, a regex that silently stopped matching would leave the
    real check green against the very defect it exists to catch.
    """
    sentinel = (
        "        if (!disabled && ImGui::IsItemHovered())\n"
        "            push_tooltip_padding();\n"
        '            ImGui::SetTooltip("%s", tip);\n'
        "            pop_tooltip_padding();\n"
    )
    m = UNBRACED_PUSH.search(sentinel)
    assert m is not None, (
        "the pattern cannot detect an unbraced push -- this file would pass against "
        "the defect it was written for"
    )

    # And the braced spelling must NOT match, so the guard is not simply "any push".
    fixed = sentinel.replace(")\n", ")\n            {\n", 1) + "            }\n"
    assert UNBRACED_PUSH.search(fixed) is None, (
        "the pattern also matches the correct spelling -- it would fail a green tree"
    )
