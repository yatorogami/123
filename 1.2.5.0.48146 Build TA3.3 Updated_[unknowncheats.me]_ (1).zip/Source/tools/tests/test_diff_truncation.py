"""Repair the truncations my patch scripts introduced, and add the check that finds them.

== THE TRUNCATIONS ==

An audit of every `-`/`+` pair across my commits found four places where an added line is a
strict prefix of the line it replaced. Three are benign reflows onto a following line; one is
not:

    EspModule.cpp:6048
      ADDED: ...component_get_game_object(exfiltration_point.get_
      WAS:   ...component_get_game_object(exfiltration_point.get_instance());
      LOST:  instance());

That was live since c6704e99, my FIRST commit. It compiled as `get_` followed by the next
line, which is why the error surfaced as `get_ is not a member of Il2CppObjectInstance` rather
than as anything recognisably a lost tail.

CAUSE, and it is the same mistake four times over. My patch scripts print lines truncated to
104 characters for readability, and in the two places where the truncated form was also used as
the SEARCH ANCHOR, the replacement string was assembled from that same truncated text. So a
display convenience became the thing actually written into the source. `TeleportModule.cpp:173`
is the same bug losing a `;`.

== THE CHECK THAT FINDS THEM ==

Nothing I wrote checked for it. Every assertion checked that something was PRESENT, which a
truncated line passes. The test that actually catches it is cheap: in a diff, flag any added
line that is a strict prefix of a removed line, and print what was lost.

This is deliberately narrow. It cannot tell you a line is CORRECT, only that the tail went
missing, and it reports per diff hunk rather than over the tree, because that is where the
replacement happened. It is added here as a module so `tools/tests` can drive it over a
synthetic diff, rather than run over the real commit history -- a check over live history would
have to encode which commits it is allowed to judge, and that is the kind of configuration
that quietly stops checking anything.

KNOWN LIMITATIONS, stated rather than hidden. Three, all found by running it on real damage.

1. Two of the four real truncations in my own commit range are NOT reported, and both
   suppressions are correct:
  - `collect_exits`'s lost tail (`std::vector<destination>& out) {`) really was rewritten on the
    following line -- a genuine reflow.
  - The controller line's lost `;` is a SINGLE CHARACTER, which occurs throughout the added
    text, so "does the tail appear elsewhere" cannot distinguish it. That one was caught by the
    compiler (`C2143`), which is the right tool for it -- but the LONG-tail class is caught
    nowhere except here, which is why this exists.

2. IT ALSO REPORTS ONE FALSE POSITIVE, found when remaking the container resolver. An added line
   beginning `if (const std::string localized =` replaced a removed line beginning the same way,
   with a DIFFERENT argument (`template_key` -> `container_id`). Prefix matches, tail differs,
   tail not found elsewhere -- so it reports a truncation where there is a deliberate rewrite.
   Distinguishing "the tail was dropped" from "the tail was changed" needs to compare what
   follows the shared prefix, not just whether it exists somewhere. Recorded because a checker
   that cries wolf on a rewrite trains people to skip it, and because I would rather this be
   known than discovered.

NEGATIVE CONTROL, per the repo rule: the self-test below feeds it a diff containing the exact
`exfiltration_point.get_` truncation and requires it to be reported, with the lost tail named.
"""

import io
import os
import re

# ====================================================================== the check


def find_truncations(diff_text):
    """Return [(added, removed, lost_tail)] for every strict-prefix truncation in a unified diff.

    A prefix match ALONE is not enough, and the first version of this got it wrong. Wrapping a
    long statement onto two lines produces an added line that is a strict prefix of the removed
    one, with nothing wrong at all:

        -    temp.push_back({name, status, pos, requirement});
        +    temp.push_back({name, status, pos,
        +        requirement});

    Report that and people stop reading the output, which is worse than not running the check.

    So the discriminator is whether the lost text reappears anywhere in the added lines. In a
    reflow it always does -- that is what a reflow is. In a truncation it does not, because it
    was dropped:

        -    ...component_get_game_object(exfiltration_point.get_instance());
        +    ...component_get_game_object(exfiltration_point.get_

    and `instance());` appears nowhere. That is the case worth shouting about.
    """
    dels, adds = [], []
    for line in diff_text.split("\n"):
        if line.startswith("---") or line.startswith("+++"):
            continue
        if line.startswith("-"):
            dels.append(line[1:])
        elif line.startswith("+"):
            adds.append(line[1:])

    added_blob = "\n".join(adds)
    # Strip whitespace so a reflow that re-indents the continuation still matches.
    added_squashed = re.sub(r"\s+", " ", added_blob)

    out = []
    for a in adds:
        for x in dels:
            if not (len(a) >= 25 and len(x) > len(a) and x.startswith(a)):
                continue
            lost = re.sub(r"\s+", " ", x[len(a):]).strip()
            if not lost:
                continue
            # Did the tail survive somewhere else in the hunk's added text?
            if lost in added_squashed:
                continue      # a reflow, not a truncation
            out.append((a, x, x[len(a):]))
            break
    return out


# ====================================================================== self-test


def _selftest():
    ok = True
    for name, fn in (
        ("real truncation detected, tail named", _selftest_real),
        ("benign reflow stays quiet", _selftest_reflow_silent),
        ("unrelated rewrite stays quiet", _selftest_unrelated_silent),
    ):
        try:
            fn()
            print("  ok: %s" % name)
        except AssertionError as exc:
            print("  FAIL: %s -- %s" % (name, exc))
            ok = False
    if ok:
        print("  self-test: the real truncation is detected and its tail named")
        print("  self-test: benign reflow and unrelated rewrites stay quiet")
    return ok


def _selftest_real():
    """The exact damage from c6704e99, as git rendered it."""
    real = (
        "-                    Il2CppObject* game_object = unity::component_get_game_object("
        "exfiltration_point.get_instance());\n"
        "+                    Il2CppObject* game_object = unity::component_get_game_object("
        "exfiltration_point.get_\n"
    )
    hits = find_truncations(real)
    assert len(hits) == 1, (
        "the real truncation produced %d hits, expected 1" % len(hits)
    )
    assert hits[0][2].strip() == "instance());", (
        "lost tail reported as %r, expected 'instance());'" % hits[0][2].strip()
    )


def _selftest_reflow_silent():
    """A reflow onto the next line must NOT be reported.

    The added line ends at a comma or an open paren, and the removed line's tail
    continues on a line that was also added. This is the case that must stay
    quiet, because flagging it would train people to ignore the tool.
    """
    reflow = (
        "-    temp.push_back({name, status, pos, requirement});\n"
        "+    temp.push_back({name, status, pos,\n"
        "+        requirement});\n"
    )
    assert not find_truncations(reflow), "a benign reflow was reported as a truncation"


def _selftest_unrelated_silent():
    """An unrelated rewrite must not be reported either."""
    unrelated = (
        "-    const int status = exfiltration_point.get_field<int>(\"_status\");\n"
        "+    const int status = eft_api::get_exfil_status(exfil);\n"
    )
    assert not find_truncations(unrelated), "an unrelated rewrite was reported as a truncation"


# ---------------------------------------------------------------- pytest entry
#
# Same defect as test_call_through_null_scan.py had: the self-test guarding this
# checker was only reachable by running the file by hand, so `pytest tools/tests`
# never executed it. A guard that runs only when someone remembers to run it is
# not a guard -- and this one guards against the truncation damage that actually
# happened in this repository more than once.
try:
    import pytest
except ImportError:  # pragma: no cover
    pytest = None


if pytest is not None:

    class TestTruncationSelfTest:
        @pytest.mark.parametrize(
            "case",
            [_selftest_real, _selftest_reflow_silent, _selftest_unrelated_silent],
            ids=["real-truncation", "reflow-silent", "unrelated-silent"],
        )
        def test_truncation_case(self, case):
            case()


# ====================================================================== live audit


def audit_repository(repo):
    """Run the check over the working diff (HEAD vs the working tree)."""
    import subprocess
    res = subprocess.run(
        ["git", "-C", repo, "diff", "HEAD", "--",
         "TarkovAddons/module", "TarkovAddons/util", "TarkovAddons/config"],
        capture_output=True)
    hits = find_truncations(res.stdout.decode("utf-8", "replace"))
    for a, x, lost in hits:
        print("  TRUNCATED: %s" % a.strip()[:96])
        print("  LOST     : %s" % lost.strip()[:96])
    return hits


if __name__ == "__main__":
    ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    ok = _selftest()
    hits = audit_repository(ROOT)
    print("  working tree: %d truncation(s) in the uncommitted diff" % len(hits))
    sys_exit = 0 if ok and not hits else 1
    print("OK" if sys_exit == 0 else "PROBLEM")
    raise SystemExit(sys_exit)