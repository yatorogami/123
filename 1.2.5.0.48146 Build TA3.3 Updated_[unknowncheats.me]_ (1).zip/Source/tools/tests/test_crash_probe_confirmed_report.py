"""A confirmed crash report must never be suppressed by first-chance dedup.

`report_fatal()` in `util/crash_probe.h` is reached from two classes of caller:

  * the vectored handler, on FIRST-CHANCE exceptions -- it sees faults the game
    goes on to handle, and cannot know which
  * the unhandled-exception filter and the terminate handler, where "the process
    is going down" is known. These set `confirmed`.

Both used to be gated on one `already_reported()` latch keyed on
`(ExceptionCode, ExceptionAddress)`. That key cannot tell apart

  (a) the same fault seen twice by the SAME observer        -> a loop, suppress it
  (b) the same fault seen first-chance and then confirmed    -> NOT a duplicate

so (b) was collapsed into (a). Cost, 2026-10-05 23:45:06:

    0xC0000005 ACCESS_VIOLATION EXECUTE at 0x00000254C65C10A0, tid 27320

The vectored handler reported it. The process then died of it, the unhandled
filter ran, the latch matched, and `report_fatal` returned having printed
NOTHING -- no ring, no histogram, no frame list for the event that killed the
process. The frames were in the ring; they were never emitted.

The same file already states the rule this violates, on the first-chance cap:

    "Confirmed reports are NEVER subject to this cap. That asymmetry is the whole
     point: the cap exists to stop unverified noise from burying the one report
     that matters, so it must not be able to bury it."

The dedup was that same burying, one gate later.

The property under test is a control-flow property of the shipped gate, so this
compiles the gate TEXT out of the header and runs it. A regex cannot tell
whether `if (confirmed)` routes to a different latch; running it can.

    tools/tests/test_zone_site_expansion.py is the sibling of this file and is
    where the MSVC discovery helpers come from.
"""

import re
import subprocess
import tempfile
import unittest
from pathlib import Path

try:
    from tools.tests.test_zone_site_expansion import msvc_env, find_vcvars64, find_cl
except ImportError:  # pytest may put tools/tests on sys.path instead
    from test_zone_site_expansion import msvc_env, find_vcvars64, find_cl

ROOT = Path(__file__).resolve().parents[2]
PROBE = ROOT / "TarkovAddons" / "util" / "crash_probe.h"
TIMEOUT_S = 60

# The pre-fix gate, verbatim. Used as the negative control: with this text in
# place, scenario 2 below must FAIL, which is what proves the test can see the
# bug rather than passing vacuously.
OLD_GATE = "        if (already_reported(rec)) return;\n"

PROBE_SRC = r"""
#include <cstdio>
#include <cstdint>
#include <atomic>

struct EXCEPTION_RECORD {
    uint32_t ExceptionCode;
    uint32_t ExceptionFlags;
    void* ExceptionAddress;   // PVOID in windows.h, so the shipped
                              // reinterpret_cast is pointer -> integer
    uint32_t NumberParameters;
};

static std::atomic<uint32_t> g_reported_code{0};
static std::atomic<uintptr_t> g_reported_addr{0};
static std::atomic<uint32_t> g_confirmed_code{0};
static std::atomic<uintptr_t> g_confirmed_addr{0};

__ALREADY_REPORTED__

__CONFIRMED_ALREADY_REPORTED__

static bool g_printed = false;

// Wraps the gate exactly as extracted from report_fatal(), up to but not
// including the first-chance cap branch that follows it.
static void run(const EXCEPTION_RECORD* rec, bool confirmed) {
    g_printed = false;
__GATE__
    g_printed = true;
}

int main() {
    const uint32_t AV = 0xC0000005;
    const uintptr_t A = 0x254C65C10A0ull;
    const uintptr_t B = 0x7FFB00001234ull;
    // Positional, in the order of the struct above. Getting this order wrong
    // silently leaves ExceptionAddress null in BOTH records, every scenario
    // looks like the same fault site, and scenarios 5-6 fail for a reason that
    // has nothing to do with the gate.
    EXCEPTION_RECORD a{AV, 0, reinterpret_cast<void*>(A), 0};
    EXCEPTION_RECORD b{AV, 0, reinterpret_cast<void*>(B), 0};
    int fails = 0;

    // 1. A first-chance fault is reported. Unchanged behaviour.
    run(&a, false);
    std::printf("first_chance_reports            : %s (want yes)\n", g_printed ? "yes" : "no");
    if (!g_printed) ++fails;

    // 2. THE REGRESSION. The same fault, now confirmed: the process is dying.
    //    Must still print, even though scenario 1 just latched (code, address).
    run(&a, true);
    std::printf("confirmed_after_first_chance     : %s (want yes)\n", g_printed ? "yes" : "no");
    if (!g_printed) ++fails;

    // 3. Loop protection must survive the fix: the SAME dying fault reported
    //    again (terminate handler after the unhandled filter) stays suppressed.
    run(&a, true);
    std::printf("confirmed_repeat_suppressed     : %s (want no)\n", g_printed ? "no" : "yes");
    if (g_printed) ++fails;

    // 4. First-chance dedup must survive too: a fault looping at one site still
    //    cannot flood the log.
    run(&a, false);
    std::printf("first_chance_repeat_suppressed  : %s (want no)\n", g_printed ? "no" : "yes");
    if (g_printed) ++fails;

    // 5. A different site is a different fault and is reported either way.
    run(&b, false);
    std::printf("different_site_first_chance     : %s (want yes)\n", g_printed ? "yes" : "no");
    if (!g_printed) ++fails;
    run(&b, true);
    std::printf("different_site_confirmed        : %s (want yes)\n", g_printed ? "yes" : "no");
    if (!g_printed) ++fails;

    std::printf("FAILURES %d\n", fails);
    return fails == 0 ? 0 : 1;
}
"""


def extract_fn(src, signature):
    """Verbatim text of a function, from its signature to the line that closes it."""
    start = src.find(signature)
    if start < 0:
        raise AssertionError(f"not found in {PROBE}: {signature!r}")
    open_at = src.find("{", start)
    depth, i, n = 0, open_at, len(src)
    while i < n:
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                return src[start: i + 1]
        i += 1
    raise AssertionError(f"unbalanced braces after {signature!r}")


def extract_gate(src):
    """The dedup gate at the top of report_fatal(), verbatim.

    Taken as everything between the opening brace of report_fatal and the
    first-chance cap branch that follows it, so the text under test is the text
    that ships rather than a paraphrase of it."""
    start = src.find("inline void report_fatal(")
    if start < 0:
        raise AssertionError("report_fatal not found")
    open_at = src.find("{", src.find(")", start))
    tail = src.find("if (!confirmed) {", open_at)
    if tail < 0:
        raise AssertionError("the `if (!confirmed) {` cap branch not found after report_fatal")
    return src[open_at + 1: tail]


def build_and_run(gate, already, confirmed, label):
    src = (PROBE_SRC
           .replace("__ALREADY_REPORTED__", already)
           .replace("__CONFIRMED_ALREADY_REPORTED__", confirmed)
           .replace("__GATE__", gate))
    with tempfile.TemporaryDirectory() as tmp:
        cpp = Path(tmp) / "gate.cpp"
        cpp.write_text(src, encoding="utf-8")
        exe = Path(tmp) / "gate.exe"
        vcvars, cl = find_vcvars64(), find_cl(msvc_env(find_vcvars64()))
        build = subprocess.run(
            [cl, "/nologo", "/EHsc", "/std:c++17", "/W3",
             f"/Fe:{exe}", f"/Fo{Path(tmp) / 'gate.obj'}", str(cpp)],
            capture_output=True, text=True, cwd=tmp, timeout=180, env=msvc_env(vcvars),
        )
        if build.returncode != 0 or not exe.exists():
            raise AssertionError(
                f"[{label}] gate probe failed to compile:\n{build.stdout}\n{build.stderr}")
        try:
            run = subprocess.run([str(exe)], capture_output=True, text=True,
                                 timeout=TIMEOUT_S)
        except subprocess.TimeoutExpired:
            raise AssertionError(f"[{label}] gate probe did not terminate")
        return run.stdout, run.returncode


class TestConfirmedReportNotDeduped(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.src = PROBE.read_text(encoding="utf-8-sig")
        cls.already = extract_fn(cls.src, "inline bool already_reported(")
        cls.confirmed = extract_fn(cls.src, "inline bool confirmed_already_reported(")
        cls.gate = extract_gate(cls.src)

    def test_shipped_gate_lets_a_confirmed_report_through(self):
        out, code = build_and_run(self.gate, self.already, self.confirmed, "shipped")
        self.assertEqual(code, 0, f"the shipped gate fails a scenario:\n{out}")
        for line in out.splitlines():
            print("   ", line)

    def test_negative_control_the_old_gate_fails(self):
        """The pre-fix gate must FAIL scenario 2.

        Without this, `test_shipped_gate_lets_a_confirmed_report_through` could
        be passing because the probe cannot express the scenario at all.
        """
        out, code = build_and_run(OLD_GATE, self.already, self.confirmed, "old-gate")
        self.assertNotEqual(
            code, 0,
            "the PRE-FIX gate passed every scenario, so this probe cannot detect "
            f"the bug it guards against:\n{out}")
        self.assertIn("confirmed_after_first_chance     : no", out,
                      "the old gate failed for an unrelated reason; scenario 2 is "
                      f"the one that must break:\n{out}")
        for line in out.splitlines():
            print("   ", line)

    # -- static guards, so CI without a toolchain still sees the shape -------

    def test_gate_does_not_apply_one_latch_to_both_callers(self):
        body = re.sub(r"//[^\n]*", "", self.gate)
        self.assertNotRegex(
            body, r"^\s*if\s*\(\s*already_reported\s*\(\s*rec\s*\)\s*\)\s*return\s*;",
            "report_fatal's gate is the single-latch form again: a confirmed report "
            "is suppressed whenever the vectored handler saw the same fault first.",
        )
        self.assertIn("confirmed_already_reported", self.gate,
                      "the confirmed branch does not use its own latch")

    def test_confirmed_latch_exists_and_keys_on_code_and_address(self):
        self.assertIn("g_confirmed_code", self.src)
        self.assertIn("g_confirmed_addr", self.src)
        # Both halves of the key, or it degenerates into a process-lifetime
        # latch -- which is the shape that was already removed once (the note on
        # g_reported_code records what that cost). Order matters: the address is
        # read into `addr` first, then both halves are compared.
        self.assertRegex(
            self.confirmed,
            r"reinterpret_cast<uintptr_t>\s*\(\s*rec->ExceptionAddress\s*\)",
            "the confirmed latch does not read ExceptionAddress",
        )
        self.assertRegex(
            self.confirmed,
            r"ExceptionCode\s*==\s*g_confirmed_code[\s\S]*?addr\s*==\s*g_confirmed_addr",
            "the confirmed latch does not compare (code, address) as a pair",
        )

    def test_first_chance_dedup_is_untouched(self):
        """The fix must not have removed loop protection to buy the report."""
        self.assertRegex(self.already, r"g_reported_code", )
        self.assertIn("already_reported(rec)", self.gate,
                      "the first-chance branch no longer calls already_reported")


if __name__ == "__main__":
    unittest.main()
