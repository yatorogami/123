"""Guard against exactly the failure just fixed: a locally-plausible edit that unbalances a file.

TeleportModule.cpp shipped with a stray `}` for one commit because every assertion in the patch
script checked that something was PRESENT and none checked global structure. Both the C2059 and
the "no 4-argument overload" error came from that one character.

This is a static check, not a compile: it reads each header/source as text and balances braces
outside comments and string/char literals. It is cheap, it needs no compiler, and per AGENTS.md
it is immune to a concurrent build -- which matters, because the moment you most want to run it is
while someone else is building.

Deliberately NOT a correctness oracle. It cannot tell you a file is right, only that it is
STRUCTURALLY closed, which is the class of mistake that a compile reports as a confusing error far
from its cause (a brace at line 115 reported as a missing overload at line 143).

Negative control, because AGENTS.md requires one: with the stray brace reinserted this must go
red. That is asserted at the bottom of this file so a future edit cannot quietly remove it.
"""
import io
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Only files this project owns. external/ is vendored and deliberately not policed.
TARGETS = []
for sub in ("TarkovAddons/module", "TarkovAddons/util", "TarkovAddons/config",
            "TarkovAddons/il2cpp", "TarkovAddons/gui", "TarkovAddons/compatibility"):
    d = os.path.join(ROOT, sub)
    if not os.path.isdir(d):
        continue
    for f in sorted(os.listdir(d)):
        if f.endswith((".h", ".cpp")):
            TARGETS.append(os.path.join(d, f))

SKIP_DIR_PARTS = ("external", "out", "x64", ".git", "ISIL-references", "GameDump")


def strip_noise(src):
    """Blank out comments and literals, preserving every other character (and its newline).

    Order matters and it is load-bearing. An earlier version scanned char by char and treated an
    apostrophe inside a `//` comment as the start of a character literal -- there are 59 such
    lines in crash_probe.h alone ("the game's own"), so it swallowed the rest of the file and
    reported a balanced C++ header as closing three braces too many.

    A SECOND bug, found the same way. The "a quote after a word character is prose" rule was
    applied to BOTH quote characters, and `ConfigValue.cpp` contains:

        return "favorite##" + this->name_ + "##" + this->module_;

    The closing `"` of `"favorite##"` is preceded by `#`, which is not a word character, so the
    rule did not fire -- but the OPENING `"` of the following `"##"` is preceded by a space and
    was correctly treated as a new literal, which then ran to end-of-file and swallowed four
    functions. The result: a file the compiler accepts reported as one unclosed brace.

    So the rule is only ever applied to apostrophes, never to double quotes: a `"` always opens a
    literal, because that is true in C++ and the apostrophe carve-out is a prose heuristic.

    The lesson is the one this repo keeps teaching: a checker that reports a confident wrong
    answer is worse than no checker. This is deliberately NOT a C++ parser, and the negative
    control below is what keeps it honest. Raw strings (`R"(...)"`) are not handled; nothing in
    this tree uses them, and if that changes the negative control is what will say so.
    """
    out = []
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == "/" and i + 1 < n and src[i + 1] == "/":
            j = src.find("\n", i)
            j = n if j == -1 else j
            out.append(" " * (j - i))
            i = j
        elif c == "/" and i + 1 < n and src[i + 1] == "*":
            j = src.find("*/", i + 2)
            j = n if j == -1 else j + 2
            out.append("".join(ch if ch == "\n" else " " for ch in src[i:j]))
            i = j
        elif c == '"' or c == "'":
            # Only an APOSTROPHE can be prose. A `"` always opens a literal in C++, and treating
            # it otherwise is what broke `"favorite##" + x + "##" + y` -- see the docstring.
            # A `'` preceded by a word character is an apostrophe in prose ("the game's own").
            if c == "'":
                j = i - 1
                while j >= 0 and src[j] in " \t":
                    j -= 1
                if j >= 0 and (src[j].isalnum() or src[j] == "_"):
                    out.append(c)
                    i += 1
                    continue
            q = c
            j = i + 1
            while j < n:
                if src[j] == "\\":
                    j += 2
                    continue
                if src[j] == q:
                    j += 1
                    break
                if src[j] == "\n" and q == "'":
                    # An unterminated char literal cannot span lines; treat the quote as prose
                    # rather than eating the rest of the file.
                    break
                j += 1
            out.append("".join(ch if ch == "\n" else " " for ch in src[i:j]))
            i = j
        else:
            out.append(c)
            i += 1
    return "".join(out)


def balance(path):
    src = strip_noise(io.open(path, encoding="utf-8", errors="replace").read())
    depth = 0
    minimum = 0
    for ch in src:
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            minimum = min(minimum, depth)
    return depth, minimum


def main():
    bad = []
    for path in TARGETS:
        if any(p in path.split(os.sep) for p in SKIP_DIR_PARTS):
            continue
        depth, minimum = balance(path)
        if depth != 0 or minimum < 0:
            bad.append((os.path.relpath(path, ROOT), depth, minimum))

    print("checked %d files" % len(TARGETS))
    if bad:
        for rel, depth, minimum in bad:
            why = ("%d unclosed" % depth) if depth > 0 else ("closes %d too many" % -minimum)
            print("  FAIL %-56s %s" % (rel, why))
        return 1
    print("  all balanced")
    return 0


# ---- NEGATIVE CONTROL: prove this can fail, per AGENTS.md ----
def negative_control():
    """The exact bug just fixed must be detected. Remove this and the test is theatre.

    NOTE the ordering hazard this function carries: it edits a real source file in
    the working tree and restores it in a `finally`. Running it from pytest is
    safe only because of that restore, and the pytest version below does NOT edit
    the tree at all -- see `test_negative_control_detects_stray_brace`. A control
    that can corrupt a source file is not a good citizen of a test suite, however
    good its assertion is.
    """
    victim = os.path.join(ROOT, "TarkovAddons/module/impl/TeleportModule.cpp")
    src = io.open(victim, encoding="utf-8", newline="").read()
    # Newline-agnostic, and asserted. This anchored on a literal `\r\n` while
    # TeleportModule.cpp is LF, so `replace` matched nothing and the control
    # evaluated an UNMODIFIED file -- vacuous, and reporting on it for as long as
    # it existed. The assert is what stops that silently recurring. The anchor is
    # the line WITHOUT its terminator, so it holds whichever line ending
    # core.autocrlf leaves in the working tree.
    anchor = "    return status == static_cast<int>(eft_api::exfil_status::regular_mode);"
    if anchor not in src:
        print("negative control: *** STALE -- the injection anchor is gone from %s ***"
              % os.path.relpath(victim, ROOT))
        return False
    try:
        io.open(victim, "w", encoding="utf-8", newline="").write(
            src.replace(anchor, anchor + "}\n", 1))
        depth, minimum = balance(victim)
        detected = depth != 0 or minimum < 0
    finally:
        io.open(victim, "w", encoding="utf-8", newline="").write(src)
    after, _ = balance(victim)
    print("negative control: reinserting the stray brace -> %s (depth %d); file restored (depth %d)"
          % ("DETECTED" if detected else "*** NOT DETECTED ***", depth, after))
    return detected


def _stray_brace_detection_on_copy(tmpdir):
    """The negative control's ASSERTION, run against a copy instead of the tree.

    `negative_control()` above rewrites `TeleportModule.cpp` in place to
    demonstrate the check fires. That is fine for a manual run and wrong for a
    test suite: a suite that edits a source file is one interrupted run away from
    leaving a stray brace committed, which is the exact damage the control exists
    to detect.

    So the assertion lives here and works on a copy in tmpdir; the editing version
    stays available for `python tools/tests/test_brace_balance.py`.
    """
    import shutil

    victim = os.path.join(ROOT, "TarkovAddons/module/impl/TeleportModule.cpp")
    copy = os.path.join(str(tmpdir), "TeleportModule.cpp")
    shutil.copyfile(victim, copy)
    before_depth, _ = balance(copy)
    assert before_depth == 0, (
        "the copy of TeleportModule.cpp is already unbalanced (depth %d) before "
        "the control runs, so the control would prove nothing" % before_depth
    )

    src = io.open(copy, encoding="utf-8", newline="").read()
    # TERMINATOR-FREE, deliberately, and that is the whole point. The control's
    # first version anchored on a literal `\r\n`; TeleportModule.cpp is LF today
    # (core.autocrlf=true rewrites it on checkout, so it flips between the two),
    # so `str.replace` matched nothing, wrote IDENTICAL bytes, and then computed
    # "detected" from an UNMODIFIED file -- a vacuous control that reported on a
    # file it had never damaged, for as long as it existed. Anchoring on the line
    # WITHOUT its terminator is what makes it a control again, and the assert
    # below is what keeps it honest.
    anchor = "    return status == static_cast<int>(eft_api::exfil_status::regular_mode);"
    assert anchor in src, (
        "the anchor the negative control injects at no longer appears in "
        "TeleportModule.cpp -- the control is stale and cannot demonstrate anything"
    )
    sabotaged = src.replace(anchor, anchor + "}\n", 1)
    assert sabotaged != src, "the sabotage produced identical bytes; the control is a no-op"
    io.open(copy, "w", encoding="utf-8", newline="").write(sabotaged)

    depth, minimum = balance(copy)
    assert depth != 0 or minimum < 0, (
        "reinserting the stray brace was NOT detected (depth %d, minimum %d) -- "
        "this balance check cannot fail, which makes the clean result it reports "
        "worthless" % (depth, minimum)
    )
    # And the untouched original still balances, so the check is not simply
    # reporting everything as broken.
    assert balance(victim)[0] == 0, "the real TeleportModule.cpp should be balanced"


# ---------------------------------------------------------------- pytest entry
#
# This file is named test_*.py and was STILL not collected: it defines main(),
# negative_control() and an `if __name__ == "__main__"` block, and no function
# named test_*. pytest collects zero tests from it, so `pytest tools/tests` has
# never once run the negative control that guards this checker. Same defect as
# test_call_through_null_scan.py and test_diff_truncation.py, reached a third way:
# there the filename did not match the glob, here the contents did not.
try:
    import pytest
except ImportError:  # pragma: no cover
    pytest = None


if pytest is not None:

    def test_negative_control_detects_stray_brace(tmp_path):
        _stray_brace_detection_on_copy(tmp_path)

    def test_module_headers_are_balanced():
        bad = [p for p in TARGETS
               if not any(part in p.split(os.sep) for part in SKIP_DIR_PARTS)
               and balance(p)[0] != 0]
        assert not bad, (
            "unbalanced braces in: %s. This is the defect that shipped as a stray "
            "brace in TeleportModule.cpp." % ", ".join(bad)
        )


if __name__ == "__main__":
    rc = main()
    nc = negative_control()
    if rc == 0 and nc:
        print("OK")
        sys.exit(0)
    sys.exit(1 if rc else 2)