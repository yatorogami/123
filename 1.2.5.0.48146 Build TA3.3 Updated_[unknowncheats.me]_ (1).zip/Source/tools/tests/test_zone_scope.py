"""TA_ZONE_N scoping: one zone per block scope, or the build stops.

`TA_ZONE_N(name)` expands to a local variable literally named `ta_zone`
(`util/tracy_bridge.h`). Two of them in the same brace scope is C2374
(redefinition with multiple initialisation), and MSBuild reports it against a
line that has nothing wrong with it.

This has been hit four times in one session while adding zones to
`AimbotModule::gameworld_update`, each time on a line that had been correct a
moment earlier. It is mechanical, it is invisible until you compile, and a
compile is a slow way to discover that you have written the same mistake twice
in one function. So it is checked statically here.

Two negative controls, both verified to FAIL for the right reason:
  * two adjacent bare `TA_ZONE_N(...)` calls in one scope  -> reported
  * the same two calls, each wrapped in `{ }`             -> not reported
"""

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
AIMBOT = ROOT / "TarkovAddons" / "module" / "impl" / "AimbotModule.cpp"
BRIDGE = ROOT / "TarkovAddons" / "util" / "tracy_bridge.h"


def strip_noise(src):
    """Blank out comments and string literals, preserving length and newlines.

    Length preservation is the point: every index in the stripped text maps to
    the same index in the original, so brace arithmetic stays valid.
    """
    out = list(src)
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == "/" and i + 1 < n and src[i + 1] == "/":
            j = src.find("\n", i)
            j = n if j < 0 else j
            for k in range(i, j):
                out[k] = " "
            i = j
        elif c == "/" and i + 1 < n and src[i + 1] == "*":
            j = src.find("*/", i + 2)
            j = n if j < 0 else j + 2
            for k in range(i, j):
                if out[k] != "\n":
                    out[k] = " "
            i = j
        elif c in ('"', "'"):
            quote = c
            j = i + 1
            while j < n:
                if src[j] == "\\":
                    j += 2
                    continue
                if src[j] == quote:
                    j += 1
                    break
                j += 1
            for k in range(i, min(j, n)):
                if out[k] != "\n":
                    out[k] = " "
            i = j
        else:
            i += 1
    return "".join(out)


def function_body(src, signature):
    start = src.find(signature)
    if start < 0:
        raise AssertionError(f"signature not found: {signature!r}")
    open_at = src.find("{", start)
    if open_at < 0:
        raise AssertionError(f"no opening brace after {signature!r}")
    depth, i, n = 0, open_at, len(src)
    while i < n:
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                return src[open_at : i + 1], open_at
        i += 1
    raise AssertionError(f"unbalanced braces in {signature!r}")


ZONE_SITES = re.compile(r"TA_ZONE_N\s*\(")


def zones_per_scope(body, raw=None):
    """Return ({scope_id: [site offsets]}, {scope_id: [zone names]}).

    `body` must be comment/string-stripped (see strip_noise, which preserves
    length); `raw` is the same region unstripped and is used only to recover the
    zone names, because the stripped text has blanked out the string literals.
    Same length, same offsets.

    Scopes are tracked by IDENTITY, not depth. That distinction is the whole
    test: two sibling `if (x) { ... }` and `if (y) { ... }` blocks are at the
    same brace depth but are different scopes, and a zone in each is perfectly
    legal. Only two zones inside the *same* block are C2374.

    Each `{` pushes a fresh scope onto a stack, each `}` pops it, and a zone is
    attributed to whatever is on top.
    """
    source = raw if raw is not None else body
    sites = {}
    names = {}
    stack = [0]  # scope 0 is the function body itself
    next_id = 1
    i, n = 0, len(body)
    while i < n:
        c = body[i]
        if c == "{":
            stack.append(next_id)
            next_id += 1
            i += 1
            continue
        if c == "}":
            if len(stack) > 1:
                stack.pop()
            i += 1
            continue
        m = ZONE_SITES.match(body, i)
        if m:
            here = stack[-1]
            arg = source[m.end() :]
            close = arg.find(")")
            sites.setdefault(here, []).append(i)
            names.setdefault(here, []).append(arg[:close].strip())
            i = m.end() + close + 1
            continue
        i += 1
    return sites, names


class TestZoneScope(unittest.TestCase):
    def setUp(self):
        self.raw = AIMBOT.read_text(encoding="utf-8-sig")
        self.src = strip_noise(self.raw)

    def test_bridge_expands_to_a_bare_local(self):
        """The premise of the whole file. If TA_ZONE_N is ever changed to nest
        its own block, this check is what tells us the C2374 rule stopped
        applying -- and that the guard below would then be protecting against
        nothing."""
        text = BRIDGE.read_text(encoding="utf-8-sig")
        self.assertIn("#define TA_ZONE_N(name)", text)
        self.assertRegex(text, r"#define TA_ZONE_N\(name\)[^\n]*\\")

    def test_gameworld_update_has_no_two_zones_in_one_scope(self):
        raw_body, _ = function_body(
            self.raw, "void AimbotModule::gameworld_update"
        )
        body, _ = function_body(self.src, "void AimbotModule::gameworld_update")
        _, names = zones_per_scope(body, raw_body)
        clashes = {
            d: n for d, n in names.items() if len(n) > 1
        }
        self.assertEqual(
            clashes,
            {},
            "two TA_ZONE_N in one brace scope in "
            "AimbotModule::gameworld_update -- C2374. Wrap each in `{ }`: "
            + "; ".join(f"scope {s}: {', '.join(v)}" for s, v in sorted(clashes.items())),
        )

    def test_negative_control_two_bare_zones_are_caught(self):
        raw = (
            "void f() {\n"
            "    if (x) {\n"
            '        TA_ZONE_N("a");\n'
            '        TA_ZONE_N("b");\n'
            "    }\n"
            "}\n"
        )
        _, names = zones_per_scope(strip_noise(raw), raw)
        self.assertTrue(
            any(len(v) > 1 for v in names.values()),
            "the detector missed two bare zones in one scope",
        )

    def test_negative_control_braced_zones_pass(self):
        raw = (
            "void f() {\n"
            "    if (x) {\n"
            '        TA_ZONE_N("a");\n'
            "    }\n"
            "    if (y) {\n"
            '        TA_ZONE_N("b");\n'
            "    }\n"
            "}\n"
        )
        _, names = zones_per_scope(strip_noise(raw), raw)
        self.assertFalse(any(len(v) > 1 for v in names.values()))

    def test_negative_control_brace_zone_around_bare_zone(self):
        """A brace-wrapped zone opens a deeper scope, so a bare zone nested
        inside it is legal. This is the exact shape used for
        `aimbot::mode3_output` > `aimbot::mode3_projection`, and it must not be
        flagged -- otherwise the guard would force useless extra braces."""
        raw = (
            "void f() {\n"
            "    {\n"
            '        TA_ZONE_N("outer");\n'
            "        if (x) {\n"
            '            TA_ZONE_N("inner");\n'
            "        }\n"
            "    }\n"
            "}\n"
        )
        _, names = zones_per_scope(strip_noise(raw), raw)
        self.assertFalse(any(len(v) > 1 for v in names.values()))

    def test_gameworld_update_zone_names_are_unique(self):
        """Two sites with the same name aggregate into one row in a capture, so
        a duplicated name silently halves both numbers. Names here are chosen
        to be unique per region for exactly that reason."""
        body, _ = function_body(self.raw, "void AimbotModule::gameworld_update")
        found = re.findall(r'TA_ZONE_N\s*\(\s*"([^"]+)"\s*\)', body)
        dupes = {n for n in found if found.count(n) > 1}
        self.assertEqual(dupes, set(), f"duplicate zone names: {sorted(dupes)}")

    def test_every_new_region_is_zoned(self):
        """The reason this session's edits exist: 174.84 s self over 2,753 calls
        with 99.92% of it in code that had no zone. These names are the regions
        added to find it. If one is dropped from the source the instrumentation
        silently regresses to the 99.92% state and only a capture would show it.
        """
        expected = {
            "aimbot::local_player_transform",
            "aimbot::fireport_resolve",
            "aimbot::visibility_origin_resolve",
            # "aimbot::main_player_transform" was here until 2026-10-10. It was a
            # dead read -- assigned from gameobject_get_transform, never read -- and
            # its cost was measured over three captures (0.649 / 0.592 / 0.768 us
            # mean) before removal, which is exactly what the alibi in the source
            # was waiting for. Asserting it here would assert the presence of code
            # that has been deleted, and the suite would go red on a correct change.
            "aimbot::gather_phase",
            "aimbot::pick_phase",
            "aimbot::alive_players_fetch",
            "aimbot::wall_check_call",
            "aimbot::mode3_output",
            "aimbot::mode3_projection",
            "aimbot::mode3_mouse",
        }
        # Names come from the RAW body: the stripped copy has blanked the string
        # literals, so this is the only place a zone name survives.
        body, _ = function_body(self.raw, "void AimbotModule::gameworld_update")
        found = set(re.findall(r'TA_ZONE_N\s*\(\s*"([^"]+)"\s*\)', body))
        self.assertEqual(
            expected - found,
            set(),
            "zones added on 2026-10-04 to attribute the unattributed "
            "gameworld_update self time are no longer all present",
        )

    def test_the_dead_main_player_transform_read_stays_dead(self):
        """A retracted fix stays retracted -- the repo's own pattern.

        `main_player_transform` was assigned from
        `unity::gameobject_get_transform(local_player_store)` on every
        `gameworld_update` and never read. It was found on 2026-10-04 and
        deliberately left so a capture could measure it; the measurement was taken
        over three captures (0.649 / 0.592 / 0.768 us mean) and the code was removed
        on 2026-10-10.

        Two ways this could regress, both silent:

          * someone re-adds the local because the comment describing it sits right
            there and reads like an instruction;
          * someone re-adds it WITH a zone, which would make `expected` above fail
            for the wrong reason -- a missing zone rather than a resurrected dead
            read -- and the message would point at the wrong line.

        So this asserts the absence directly, on the stripped body, which is why it
        cannot be satisfied by the explanatory comment that now occupies the site.
        """
        body, _ = function_body(self.src, "void AimbotModule::gameworld_update")
        self.assertNotRegex(
            body,
            r"\bmain_player_transform\b\s*=",
            "main_player_transform is assigned again in gameworld_update. It was a "
            "dead read -- the only four matches in the tree were the declaration "
            "and its own zone -- removed on 2026-10-10 after three captures "
            "measured it at sub-microsecond mean. Re-adding it puts a managed "
            "call in the per-frame path that feeds nothing",
        )


if __name__ == "__main__":
    unittest.main()