"""Quest ESP must retire markers whose objective finished DURING the raid. 2026-10-15.

THE DEFECT, and it is not in the completion filter. `is_condition_completed`'s three
probes check out against the current dump: `QuestStatusData.CompletedConditions` is a
`HashSet<MongoID>` (QuestStatusData.cs:0x28), `Condition.id` is `<id>k__BackingField`
(Condition.cs:0x10), and `EQuestStatus` puts Started at 2 and AvailableForFinish at 3 --
which is what `quest_status_started` / `quest_status_available_for_finish` already said.

What was broken is WHEN the filter runs. `EspModule` gates the collect on
`force_esp_refresh || quest_esp_last_refresh_ms_ == 0`, and the comment above it says
"one full collect until cache clear / manual refresh (no periodic rescan)". So the
published marker set was the completion state as of raid entry, held for the whole raid:
clear a kill counter, place the beacon, find the item, hand the quest in at a trader --
and the marker stayed until extract or a manual refresh. `drop_completed_pois` re-asks,
on a 5 s clock.

WHAT IS ASSERTED HERE, and why it is source shape rather than behaviour. None of this is
observable without a raid: a marker that lingers five seconds after its objective is done
is a thing you see, not a thing a suite can be told about. What CAN be checked offline is
the invariant the whole design rests on and that no compiler enforces --

    the collect and the sweep must reach the SAME set of conditions.

A sweep that reaches LESS than the collect retires LIVE markers, every counter-creator
objective five seconds after it appears. That is the one direction this must not fail in,
and it is invisible in review because both halves read like correct code. So the two
halves are pinned to one shared descent, and the descent itself is pinned to actually
RECURSE rather than merely mention `ConditionCounterCreator` -- an assertion on the name
alone passes with the recursion deleted, which is the failure mode this repo has hit
three times (see test_projection_hoist's "assert the VALUE, not the NAME").

The cost premise is pinned too, because it is the only reason the sweep may be
periodic. The completion probes are up to three managed calls each, so they must
run only on conditions a published marker actually references -- and the sweep
must NOT walk the quest book at all, which was the 2026-10-15 mistake: the first
version re-walked it, `esp_scan::quest_poi_scan` had already measured 213 ms max,
and a comment claiming "the walk itself is field reads and a status filter"
covered it. The walk is a set of MANAGED getters. `test_the_sweep_does_not_walk_
the_quest_book` asserts on that absence, and its control re-inserts the walk to
prove the assertion can go red.

What is not claimed is that this suite observes the hang. A raid-2 log shows the
collect wedging inside `get_place_trigger_position` (last line `found=1`, then
silence on every thread, no dump, no crash probe, with 7 GB paged out); the sweep
never ran in that raid at all. The tests below pin the shape that makes the
onetime raid cost stay one time.
"""

from __future__ import annotations

import re
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from tools.tests.test_projection_hoist import blank_comments  # noqa: E402

QUEST_ESP = ROOT / "TarkovAddons" / "module" / "quest_esp.h"
ESP_MODULE = ROOT / "TarkovAddons" / "module" / "impl" / "EspModule.cpp"

MARKER_DESCENT = "inline void foreach_marker_condition("
QUEST_WALK = "inline bool foreach_outstanding_condition("
COLLECT = "inline void start_collect_cycle("
DISPATCH = "inline void process_condition_for_cycle("
SWEEP = "inline size_t drop_completed_pois("
OWNERS = "inline std::unordered_map<Il2CppObject*, condition_owner>& condition_owners()"
RECORD = "inline void record_condition_owner("


def func(code: str, header: str) -> str:
    """The text of a function, from its signature to the brace that closes it.

    Not `test_projection_hoist.body`, which takes the first `{` after the header.
    `start_collect_cycle`'s last parameter default is `const std::string& location_id
    = {}`, so that scan opens a brace-match on the default argument and returns the
    signature. Skipping the parameter list is the fix; the brace matching is unchanged.
    """
    m = re.search(re.escape(header), code)
    if not m:
        raise AssertionError("could not find %r -- renamed or removed; fix this test "
                             "rather than loosening it" % header)
    i = code.index("(", m.start())
    depth = 0
    while True:
        if code[i] == "(":
            depth += 1
        elif code[i] == ")":
            depth -= 1
            if depth == 0:
                break
        i += 1
    j = code.index("{", i)
    depth = 0
    for k in range(j, len(code)):
        if code[k] == "{":
            depth += 1
        elif code[k] == "}":
            depth -= 1
            if depth == 0:
                return code[m.start(): k + 1]
    raise AssertionError("no closing brace for %r" % header)


class TestQuestPoiCompletedSweep(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = QUEST_ESP.read_text(encoding="utf-8", errors="replace")
        # Comments go because the rationale for this change is long and sits directly
        # above the code -- it would satisfy half of these on its own. The sweep's own
        # comment even spells out the fail-open rule these assertions check.
        cls.code = blank_comments(cls.raw)
        cls.esp = blank_comments(ESP_MODULE.read_text(encoding="utf-8", errors="replace"))

    def fn(self, header):
        return func(self.code, header)

    # ------------------------------------------------------------ the sweep runs
    def test_esp_runs_the_sweep_and_publishes_what_it_drops(self):
        sweep = func(self.esp, "if (sweep_due && main_player_ && !quest_poi_store->empty())")
        self.assertIn(
            "quest_esp::drop_completed_pois(",
            sweep,
            "EspModule no longer calls quest_esp::drop_completed_pois. The collect is "
            "gated once per raid, so without this the marker set stays as it was at "
            "raid entry for the whole raid",
        )
        self.assertRegex(
            sweep,
            r"drop_completed_pois\s*\([^;]*\)\s*>\s*0\s*\)\s*"
            r"quest_poi_dirty\s*=\s*true\s*;",
            "the sweep's result is discarded. Dropping markers only matters if the "
            "publish is marked dirty, because quest_poi_store is published, never "
            "mutated in place",
        )

    def test_the_sweep_stages_into_the_publish_buffer_and_never_writes_the_store(self):
        sweep = func(self.esp, "if (sweep_due && main_player_ && !quest_poi_store->empty())")
        self.assertRegex(
            sweep,
            r"if\s*\(\s*temp_quest_poi\.empty\(\)\s*\)\s*\n?\s*"
            r"temp_quest_poi\s*=\s*\*\s*quest_poi_store\s*;",
            "the sweep must stage a copy of the live set into temp_quest_poi, which is "
            "the only buffer the publish reads. Writing quest_poi_store itself mutates "
            "a snapshot the render thread is reading with no lock held",
        )
        self.assertNotIn(
            "quest_poi_store =",
            sweep,
            "the sweep assigns quest_poi_store. That is the render thread's shared_ptr",
        )

    # ------------------------------- the invariant: collect and sweep reach alike
    def test_the_descent_has_exactly_the_two_callers_that_must_agree(self):
        """The assertion this whole file exists for.

        Two places enumerate marker-bearing conditions in the COLLECT: its own
        per-condition dispatch, and the quest walk that dispatch is driven by. If
        either walks Conditions directly, they have their own answer to "which
        conditions exist" -- and the owners table the sweep reads is recorded from
        the walk, so a dispatch that walks separately writes owners for conditions
        the sweep will then never associate back to a quest.
        """
        for header in (DISPATCH, QUEST_WALK):
            with self.subTest(caller=header):
                self.assertRegex(
                    self.fn(header),
                    r"foreach_marker_condition\s*\(",
                    "%s reaches conditions without going through foreach_marker_"
                    "condition, so the owners table and the emitted markers can "
                    "disagree about which conditions exist" % header,
                )

    def test_the_sweep_does_not_walk_the_quest_book(self):
        """The regression that a 2026-10-15 raid-2 hang turned into a real defect.

        `drop_completed_pois` used to walk the quest book itself. `foreach_
        outstanding_condition` is a MANAGED walk -- hundreds of get_* calls across
        a late-wipe profile -- and it was being run on a 5 s clock inside the zone
        that had already measured 213 ms max. The comment claimed "the walk itself
        is field reads and a status filter"; the log of the raid that hung shows
        the collect took that path, and the sweep was one more copy of it.

        It must now read the owners table instead, which means it must NOT contain
        the walk. Asserted on the ABSENCE, which is the only direction that fails
        silently: a present walk looks entirely reasonable and re-imposes the cost
        while every other assertion here still passes.
        """
        self.assertNotIn(
            "foreach_outstanding_condition",
            self.fn(SWEEP),
            "drop_completed_pois walks the quest book again. That is the full "
            "managed walk -- hundreds of managed calls on a 5 s clock inside "
            "esp_scan::quest_poi_scan's zone (213 ms max, already measured) -- and "
            "the owners table exists so it does not have to",
        )

    def test_the_collect_goes_through_that_walk(self):
        """The owners table is filled from the walk, so the walk is its source.

        Asserting the sweep does NOT walk without asserting the collect DOES would
        leave the table empty and the sweep a silent no-op forever -- a marker
        that is never retired, which is the original bug wearing a disguise.
        """
        self.assertRegex(
            self.fn(COLLECT),
            r"foreach_outstanding_condition\s*\(",
            "start_collect_cycle does not use the quest walk, so the owners table "
            "is never filled and the sweep retires nothing — the original defect "
            "with the sweep looking installed",
        )

    def test_the_descent_recurses_rather_than_only_naming_the_class(self):
        descent = self.fn(MARKER_DESCENT)
        self.assertRegex(
            descent,
            r'class_name_contains\s*\(\s*condition\s*,\s*"ConditionCounterCreator"\s*\)',
            "the ConditionCounterCreator test is gone from the descent",
        )
        self.assertRegex(
            descent,
            r"foreach_condition_in_collection\s*\(\s*nested\s*,",
            "the descent never reads the nested collection. ConditionCounterCreator's "
            "children (ConditionCounterCreator.Conditions, 0xE8) are ordinary "
            "conditions and a marker can name one",
        )
        self.assertRegex(
            descent,
            r"foreach_marker_condition\s*\(\s*sub\s*,\s*fn\s*\)",
            "the descent collects the nested conditions but does not RECURSE on them. "
            "Asserting the class name and the nested read both pass with this call "
            "removed -- which is exactly the assertion-that-checks-nothing shape this "
            "repo has shipped three times",
        )

    # ---------------------------------------------------------- fail-open, on paper
    def test_an_owners_table_that_never_filled_drops_nothing(self):
        """A no-table raid is not "no outstanding conditions".

        It means no collect has run this raid, so there is nothing to judge the
        markers against. Collapsing the two empties the marker set on any launch
        where the collect did not run -- a far worse symptom than the one this
        change fixes.
        """
        self.assertRegex(
            self.fn(SWEEP),
            r"owners\.empty\(\)\s*\)\s*return\s*0\s*;",
            "drop_completed_pois proceeds with an empty owners table. Every marker "
            "would be retired by a question nothing asked",
        )

    def test_a_conditionless_marker_is_never_retired(self):
        self.assertRegex(
            self.fn(SWEEP),
            r"if\s*\(\s*poi\.condition\s*&&\s*live\.find\s*\(\s*poi\.condition\s*\)",
            "the retention test lost its `poi.condition &&` guard, so a marker with no "
            "condition is dropped -- the sweep then deletes markers for a reason it "
            "cannot report",
        )

    def test_the_collect_also_stops_on_an_unreachable_quest_book(self):
        self.assertRegex(
            self.fn(COLLECT),
            r"if\s*\(\s*!\s*foreach_outstanding_condition\s*\(",
            "start_collect_cycle ignores the walk's return. It used to return to idle "
            "on its own, so the walk's bool has to keep that meaning for it too",
        )

    # ------------------------------------------- the premise that makes 5 s sane
    def test_completion_probes_run_only_for_conditions_the_table_names(self):
        """O(markers), not O(profile) -- and it now has to be true twice over.

        The membership test is the first half: `is_condition_completed` is up to
        three managed calls each, so it may only run on conditions the table names.
        The second half is that the sweep must not walk at all, which is
        `test_the_sweep_does_not_walk_the_quest_book` above. This assertion alone
        was enough to pass while the sweep still re-walked the whole book -- which
        is what it did, and the cost was real.
        """
        self.assertIn(
            "is_condition_completed(",
            self.fn(SWEEP),
            "the sweep no longer calls is_condition_completed at all, so it can "
            "never retire anything — the original bug with the sweep looking installed",
        )
        # The probe is inside the loop that keeps only table-named, still-open
        # conditions; an unconditional probe would call it for every marker.
        self.assertRegex(
            self.fn(SWEEP),
            r"owners\.find\s*\(\s*\*it\s*\)",
            "the sweep stopped looking each marker's condition up in the owners "
            "table, so it cannot tell a live objective from a retired one and "
            "retires all of them",
        )

    # -------------------------------------------------- the table that makes it cheap
    def test_the_owners_table_is_populated_on_the_collect_walk(self):
        sweep_fn = self.fn(COLLECT)
        self.assertRegex(
            sweep_fn,
            r"record_condition_owner\s*\(",
            "the collect records an owner for every condition it visits. Without "
            "this the sweep's lookup always misses and every marker is retired "
            "‘not in the table’ — which is the second deletion rule, so a marker "
            "that should have survived disappears instead",
        )

    def test_the_owners_table_is_cleared_at_the_raid_boundary_and_the_collect(self):
        """The table is raid-scoped and both clearings are load-bearing.

        One of them hanging alone is the bug: a table not cleared at the boundary
        holds a dead raid's Il2CppObject* and the sweep hands the game a pointer
        from the wrong generation. A table not cleared at the collect is worse —
        the second raid's collect repopulates a table that still has the first
        raid's conditions in it, so a marker that should be retired reads as
        "no owner" and is dropped.
        """
        clear = self.fn("inline void clear_caches()")
        self.assertIn(
            "condition_owners().clear()",
            clear,
            "clear_caches() no longer clears the owners table, so a table holding "
            "one raid's Il2CppObject* is read by the next raid's sweep",
        )
        collect = self.fn(COLLECT)
        self.assertIn(
            "condition_owners().clear()",
            collect,
            "start_collect_cycle no longer clears the owners table, so the second "
            "raid's collect repopulates a table still holding the first raid's "
            "conditions -- and a live marker then reads as 'no owner' and is dropped",
        )

    def test_the_owners_table_is_a_raid_scoped_static_not_a_rebuild_per_call(self):
        self.assertRegex(
            self.fn(OWNERS),
            r"static\s+std::unordered_map<Il2CppObject\*,\s*condition_owner>\s+owners",
            "condition_owners() no longer returns a static. A per-call table is "
            "always empty, which makes the sweep a permanent no-op -- the original "
            "bug with the sweep looking installed",
        )

    # ------------------------------------------------------------------ controls
    def test_control_the_descent_assertion_fails_without_the_recursion(self):
        """The control, run in-process: mutate the source and require the check to go red.

        `test_the_descent_recurses_rather_than_only_naming_the_class` asserts three
        things. Reverting just the recursion call has to be enough to fail it, or the
        first two are decoration.
        """
        mutated = self.code.replace(
            "foreach_marker_condition(sub, fn);", "/* reverted */", 1
        )
        self.assertNotIn(
            "foreach_marker_condition(sub, fn);",
            mutated,
            "the control did not apply -- the descent's call text moved, so this test "
            "would be pinning a string that no longer exists",
        )
        descent = func(mutated, MARKER_DESCENT)
        self.assertNotRegex(
            descent,
            r"foreach_marker_condition\s*\(\s*sub\s*,\s*fn\s*\)",
            "a descent with the recursion removed still satisfies the class-name and "
            "nested-read assertions",
        )

    def test_control_the_publish_assertion_fails_on_a_discarded_result(self):
        mutated = self.esp.replace(
            "if (quest_esp::drop_completed_pois(temp_quest_poi) > 0)",
            "quest_esp::drop_completed_pois(temp_quest_poi)", 1,
        )
        sweep = func(mutated, "if (sweep_due && main_player_ && !quest_poi_store->empty())")
        self.assertNotRegex(
            sweep,
            r"drop_completed_pois\s*\([^;]*\)\s*>\s*0\s*\)",
            "discarding the dropped count must fail the dirty assertion",
        )

    def test_control_the_walk_ban_fails_when_the_walk_comes_back(self):
        """And the ban on the walk has to be falsifiable too.

        The 2026-10-15 defect was a sweep that walked. Restoring the walk must
        make the sweep's body contain the walk, which is exactly what the ban
        rejects -- so the ban can go red, which is the property a control has to
        establish (a check that cannot fail is worse than no check).

        The anchor must be unique in the file. `pois.empty()` is not: it is also
        the first line of fill_poi_descriptions, earlier in the same header, and a
        control that mutates the wrong function passes while asserting nothing.
        """
        marker = "const auto& owners = condition_owners();"
        walk_call = (
            "\n        (void)foreach_outstanding_condition(nullptr, "
            "[](Il2CppObject*, const std::string&, Il2CppObject*, Il2CppObject*) {});"
        )
        restored = self.code.replace(marker, marker + walk_call, 1)
        self.assertIn(
            walk_call.strip(),
            restored,
            "the control did not apply -- the sweep's owners lookup moved, so this "
            "test would be pinning a string that no longer exists",
        )
        # The mutation landed in the sweep, and that is what makes it fair.
        self.assertIn(
            "foreach_outstanding_condition(nullptr",
            func(restored, SWEEP),
            "a sweep that re-inserts the walk still satisfies the ban — the ban is "
            "not doing its job",
        )
        # And the real body does not contain it.
        self.assertNotIn(
            "foreach_outstanding_condition",
            self.fn(SWEEP),
            "the live sweep contains the walk the ban exists to keep out",
        )


if __name__ == "__main__":
    unittest.main()