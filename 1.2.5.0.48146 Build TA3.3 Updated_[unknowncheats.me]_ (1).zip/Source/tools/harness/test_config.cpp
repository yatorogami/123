// Executable coverage for the configuration value layer.
//
// Why this exists
// ---------------
// WORKFLOW.md records that the project's only executable coverage -- the ta_tests
// harnesses, 46 assertions across 9 scenarios for the config migration, 19 for
// the parser, 15 and 16 for RCDATA -- lived in
// %LOCALAPPDATA%\Temp\opencode\ta_tests and was destroyed by temp cleanup. The
// results stand as evidence; the ability to re-run them did not. This file is
// the part of that coverage that can be rebuilt so it survives: the pieces that
// are standard-library only and therefore run anywhere.
//
// What is deliberately NOT here
// -----------------------------
// data_migration.h, module_paths.h and pe_resource.h still have no coverage.
// All three need WideCharToMultiByte, GetModuleHandleW or FindResourceW, so they
// only execute on Windows. Restoring those needs a Windows host, and pretending
// otherwise would be worse than the gap being visible.
//
// Assertions vs characterisation
// -----------------------------
// Assertions pin a contract. Characterisation prints what the code actually
// does for a case where pinning it would just enshrine an accident -- the
// exact format of a config key, say, which a user-facing file format depends on
// and which nobody should change by accident. A change in a characterised value
// shows up as a diff in the output, which is the point.

#include <cstdio>
#include <string>

#include "../../TarkovAddons/config/ConfigValue.h"

// Test state owned by stubs.cpp, and the reason the tooltip case can detect the
// defect it guards against. It models the real boot order: it starts FALSE,
// because a module CONSTRUCTOR runs before ModuleManager::init() and therefore
// before ConfigModule::init() calls i18n::init(). No translation is loaded yet,
// and tr() answers an unloaded key by returning the key.
namespace i18n { extern bool translations_loaded; }

namespace {

int g_pass = 0;
int g_fail = 0;

void check(bool ok, const std::string& what)
{
    if (ok) {
        ++g_pass;
    } else {
        ++g_fail;
        std::printf("  FAIL  %s\n", what.c_str());
    }
}

void section(const char* name)
{
    std::printf("\n-- %s\n", name);
}

// A concrete ConfigValue, since the base is abstract. Nothing here touches
// draw(), so the imgui layer is never entered.
struct Probe : ConfigValue {
    explicit Probe(const std::string& n)
        : ConfigValue(n)
    {
    }
    void draw() override {}
    void set(const std::string&) override {}
    std::string get() override { return {}; }
    std::string get_default() override { return {}; }
};

// ---------------------------------------------------------------------------

// Catching what the contract says cannot happen.
//
// config_parse::to_int / to_float must report failure and never throw -- that
// is the entire point of them, and ConfigValue.h says why: every set() is
// called from the loader's apply loop with nothing above it to catch, so a
// single throwing conversion looks like "the config did not load" while
// abandoning every value after it.
//
// Calling them bare means a regression to std::stoi kills this harness with an
// uncaught std::invalid_argument, and a process that dies by fastfail reports
// nothing at all: no output, no count, and no way to tell which of the inputs
// broke. So the parse result is tri-state, and a throw is a named failure of
// the assertion it happened in.
enum class Parsed { yes, no, threw };

template <typename Parse, typename T>
Parsed try_parse(Parse parse, const std::string& text, T& out)
{
    try {
        return parse(text, out) ? Parsed::yes : Parsed::no;
    } catch (...) {
        return Parsed::threw;
    }
}

void want_ok(Parsed parsed, const char* what)
{
    if (parsed == Parsed::threw) {
        check(false, std::string(what) + "  [THREW; must report failure, never throw]");
        return;
    }
    check(parsed == Parsed::yes, what);
}

void want_rejected(Parsed parsed, const char* what)
{
    if (parsed == Parsed::threw) {
        check(false, std::string(what) + "  [THREW; must report failure, never throw]");
        return;
    }
    check(parsed == Parsed::no, what);
}

void test_to_int()
{
    section("config_parse::to_int -- the contract is: report failure, never throw");
    int v = 0;

    want_ok(try_parse(config_parse::to_int, "42", v), "'42' parses");
    check(v == 42, "'42' is 42");
    want_ok(try_parse(config_parse::to_int, "0", v), "'0' parses");
    check(v == 0, "'0' is 0");
    want_ok(try_parse(config_parse::to_int, "-7", v), "'-7' parses");
    check(v == -7, "'-7' is -7");

    // The reason from_chars is used rather than stoi, per the comment in
    // ConfigValue.h: stoi would accept these silently.
    want_rejected(try_parse(config_parse::to_int, "3abc", v), "'3abc' rejected (stoi would give 3)");
    want_rejected(try_parse(config_parse::to_int, "", v), "'' rejected");
    want_rejected(try_parse(config_parse::to_int, "abc", v), "'abc' rejected");
    want_rejected(try_parse(config_parse::to_int, "3.5", v), "'3.5' rejected as an int");
    want_rejected(try_parse(config_parse::to_int, " 42", v), "' 42' rejected (no leading space)");
    want_rejected(try_parse(config_parse::to_int, "42 ", v), "'42 ' rejected (no trailing space)");
    want_rejected(try_parse(config_parse::to_int, "2147483648", v), "out-of-range int rejected");

    // Embedded NUL: a std::string can carry one, and a config file can.
    want_rejected(try_parse(config_parse::to_int, std::string("4\0 2", 4), v),
                  "embedded NUL rejected");

    // Everything above must not have thrown, and v must be untouched on failure.
    v = 12345;
    want_rejected(try_parse(config_parse::to_int, "nope", v), "'nope' rejected");
    check(v == 12345, "out is not written when parsing fails");
}

void test_to_float()
{
    section("config_parse::to_float");
    float f = 0.f;

    want_ok(try_parse(config_parse::to_float, "1.5", f), "'1.5' parses");
    check(f == 1.5f, "'1.5' is 1.5");
    want_ok(try_parse(config_parse::to_float, "0", f), "'0' parses as a float");
    check(f == 0.f, "'0' is 0.0");
    want_ok(try_parse(config_parse::to_float, "-2.25", f), "'-2.25' parses");
    check(f == -2.25f, "'-2.25' is -2.25");

    want_rejected(try_parse(config_parse::to_float, "", f), "'' rejected");
    want_rejected(try_parse(config_parse::to_float, "abc", f), "'abc' rejected");
    want_rejected(try_parse(config_parse::to_float, "1.5f", f), "'1.5f' rejected (trailing junk)");
    want_rejected(try_parse(config_parse::to_float, "1.5 ", f), "'1.5 ' rejected");

    f = 99.f;
    want_rejected(try_parse(config_parse::to_float, "nope", f), "'nope' rejected");
    check(f == 99.f, "out is not written when parsing fails");
}

void test_config_value_flags()
{
    section("ConfigValue flags round-trip");
    Probe p("mykey");

    check(!p.is_disabled(), "disabled defaults to false");
    p.set_disabled(true);
    check(p.is_disabled(), "set_disabled(true) takes");
    p.set_disabled(false);
    check(!p.is_disabled(), "set_disabled(false) takes");

    check(!p.is_hidden_in_owner_menu(), "hidden_in_owner_menu defaults to false");
    p.set_hidden_in_owner_menu(true);
    check(p.is_hidden_in_owner_menu(), "set_hidden_in_owner_menu(true) takes");

    check(!p.is_favorite(), "favorite defaults to false");
    p.set_favorite(true);
    check(p.is_favorite(), "set_favorite(true) takes");

    p.set_master_toggle(true);
    check(p.get_config_key().size() > 0, "a registered value still has a key");
}

void test_config_keys()
{
    section("ConfigValue keys -- asserted for structure, printed for format");
    Probe unregistered("lonely");
    Probe registered("cb");
    registered.reg("esp_mod");

    const std::string solo = unregistered.get_config_key();
    const std::string with_mod = registered.get_config_key();
    const std::string fav = registered.get_favorite_config_key();

    // Structure only: a key must be stable and must name the value, and adding a
    // module must change it. The separator itself is a file format.
    check(solo.find("lonely") != std::string::npos, "key contains the value name");
    check(with_mod.find("cb") != std::string::npos, "registered key contains the name");
    check(with_mod != solo, "registering a module changes the key");
    check(solo == unregistered.get_config_key(), "key is stable across calls");
    check(fav != with_mod, "the favourite key differs from the normal key");

    std::printf("     no module  : \"%s\"\n", solo.c_str());
    std::printf("     with module: \"%s\"\n", with_mod.c_str());
    std::printf("     favourite  : \"%s\"\n", fav.c_str());
    std::printf("     imgui title: \"%s\"\n", registered.get_imgui_title().c_str());
    std::printf("     (characterised: a change here is a file-format change, not a\n"
                "      refactor, and should be a deliberate one)\n");
}

// ---------------------------------------------------------------------------
// The tooltip is a KEY, resolved at draw time.
//
// This is the executable half of a defect that shipped. The three survival-mode
// tooltips were translated inside set_tooltip(), which runs in a module
// CONSTRUCTOR. i18n::init() does not run until ConfigModule::init(), inside
// ModuleManager::init() -- and `new ModuleManager()` has already built every
// module by then, so tr() answered an EMPTY map and returned the key itself.
// Those rows rendered "god_mode_tip", "god_mode2_tip" and "semi_god_mode_tip"
// literally, in every language.
//
// The case replays that ordering: set the tooltip while nothing is loaded, then
// load, then read. Deferring the translation is the only way the last read can
// be the translated string, so an eager tr() fails here BY NAME.
void test_tooltip_is_a_key_resolved_at_draw_time()
{
    section("tooltip -- stored as a key, resolved per frame");

    Probe p("some_value");
    check(p.get_tooltip().empty(), "no tooltip by default");

    // ---- the state a module constructor actually runs in -------------------
    check(!i18n::translations_loaded,
          "premise: the harness starts with translations NOT loaded");
    p.set_tooltip("god_mode_tip");
    check(p.get_tooltip() == "god_mode_tip",
          "while translations are unloaded, the key is what comes back (the "
          "fallback) -- so an early and a late read are DISTINGUISHABLE here");

    // ---- i18n::init() happens: ConfigModule::init(), after construction ----
    i18n::translations_loaded = true;
    check(p.get_tooltip() == "[tr]god_mode_tip",
          "after load, the tooltip IS translated -- resolution happened late");

    // The defect, stated as the assertion it breaks: had set_tooltip() baked
    // tr() in during construction, this would still read the frozen key.
    check(p.get_tooltip() != "god_mode_tip",
          "the stored answer is NOT frozen at what the empty map said during "
          "construction (an eager tr() regresses this)");

    // Repeatable, so the accessor is a query rather than a one-shot.
    check(p.get_tooltip() == p.get_tooltip() && p.get_tooltip() == "[tr]god_mode_tip",
          "the tooltip is stable across repeated reads");

    p.set_tooltip("semi_god_mode_tip");
    check(p.get_tooltip() == "[tr]semi_god_mode_tip", "set_tooltip() replaces the key");
    p.set_tooltip("god_mode_tip");
    check(p.get_tooltip() == "[tr]god_mode_tip", "re-setting the same key gives the same answer");

    // A language switch is the OTHER thing an eager cache gets wrong: the title
    // follows it, so the tooltip must too.
    i18n::translations_loaded = false;
    const std::string unloaded = p.get_tooltip();
    i18n::translations_loaded = true;
    check(unloaded == "god_mode_tip" && p.get_tooltip() == "[tr]god_mode_tip",
          "the tooltip follows a locale change rather than freezing on the first "
          "value seen");

    // Empty clears, and stays empty rather than becoming the empty key.
    p.set_tooltip("");
    check(p.get_tooltip().empty(), "an empty key means no tooltip at all");

    // Contrast with the title accessor beside it: same deferred shape, so under
    // the loaded state it must carry the wrapper too. This is what stops the
    // assertions above from passing on a stub that stopped wrapping.
    Probe titled("god_mode_cb");
    i18n::translations_loaded = true;
    check(titled.get_imgui_title() == "[tr]god_mode_cb##",
          "get_imgui_title() resolves per frame too, so it carries the wrapper");
    check(titled.get_tooltip().empty(),
          "and that title value has no tooltip, so it shows nothing extra");

    // Leave the state loaded for any case that runs after this one.
    i18n::translations_loaded = true;
}

} // namespace

int main()
{
    std::printf("TarkovAddons config harness\n");
    test_to_int();
    test_to_float();
    test_config_value_flags();
    test_config_keys();
    test_tooltip_is_a_key_resolved_at_draw_time();
    std::printf("\n%d passed, %d failed\n", g_pass, g_fail);
    return g_fail == 0 ? 0 : 1;
}
