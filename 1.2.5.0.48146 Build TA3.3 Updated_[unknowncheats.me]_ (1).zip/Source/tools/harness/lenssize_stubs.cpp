// Link-time stubs so a test can include the REAL optics_lens_pipeline.h.
//
// 2026-10-06. The first attempt at this test failed to link with
//   LNK2019 safetyhook::InlineHook::~InlineHook(void)
//   LNK2019 unity::vector3::vector3(void)
//   LNK1120 2 unresolved
// and I concluded from that that the real header could not be linked into the
// harness at all. That was a guess. The harness already solves this shape of
// problem for ConfigValue with stubs.cpp, so the same trick applies: define the
// two out-of-line symbols the header's inline globals reference.
//
// These are DEFINITIONS, not the real implementations. Nothing here tests safetyhook
// or the vector3 constructor -- what is under test is
// optics::lens::lens_size_frame_summary's output formatting, and it calls neither.

#include "../../TarkovAddons/il2cpp/unity.h"

namespace safetyhook {
    InlineHook::~InlineHook() {}
    // The third symbol, found by linking rather than by guessing. InlineHook owns
    // an Allocation by value, so destroying one destroys that too, and the
    // compiler emitted the call. One stub defused one LNK2019; the next link
    // named this one.
    Allocation::~Allocation() {}
} // namespace safetyhook

namespace unity {
    vector3::vector3() : x(0.f), y(0.f), z(0.f) {}
} // namespace unity
