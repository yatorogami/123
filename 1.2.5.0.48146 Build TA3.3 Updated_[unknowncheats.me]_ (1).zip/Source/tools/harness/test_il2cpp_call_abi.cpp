// Pins the il2cpp call-ABI signature transform that Il2CppObjectInstance's checked
// wrappers (call_or / call_or_void) are built on.
//
// WHY THIS CASE EXISTS. Every managed method's native signature ends in a hidden
// trailing MethodInfo*. Game code always supplies it; the mod used to call bare
// methodPointers without it, and on 2026-10-08 that crashed inside
// Dictionary<object,object>::Add's shared-generic wrapper (reached through BSG's
// tracked-store barrier from BotGroupEnemyInfo::.ctor): the wrapper read the
// leftover r9 as its MethodInfo*, got [r9+0x20]=0x1C, and AV'd reading 0xDC.
// The wrappers now resolve the MethodInfo* alongside the pointer and append it as
// the last argument, building the call type through il2utils::with_methodinfo.
//
// What can silently break here is the transform itself: someone "simplifies" the
// trait, puts the MethodInfo* somewhere else, or drops the const, and every call
// site still compiles -- it just resumes calling with a garbage trailing slot,
// because the call sites declare only the declared args (the trait appends the
// hidden one). The static_asserts below compile the REAL header and pin the exact
// expanded signatures for the shapes the call sites actually use. The runtime
// half exercises the wrappers' miss path on a null instance: call_or must return
// its on_miss value and call_or_void must not call through a null pointer.
//
// Windows-only (the header chain pulls Windows.h); needs only MSVC, like
// export_lookup. Nothing here needs the project, the game, or a deployed DLL.
//
// Windows.h must precede Il2CppObjectInstance.h: the latter opens with the
// vendored libil2cpp/il2cpp-class-internals.h, which uses PVOID and relies on
// the project's pch.h having pulled in Windows.h first. That is true of every
// project TU and untrue of this standalone case.

#include <cstdio>
#include <string>
#include <type_traits>

#include <Windows.h>

#include "../../TarkovAddons/il2cpp/Il2CppObjectInstance.h"

// Instantiating the wrappers' miss path pulls logger::warn (the resolve-failure
// branch of il2utils::get_method). The harness has no logger.cpp; the function's
// behaviour is irrelevant to what is being tested.
namespace logger {
    void warn(std::string) {}
}

namespace {

int g_pass = 0;
int g_fail = 0;

void check(bool ok, const char* what)
{
    if (ok) { ++g_pass; std::printf("  ok    %s\n", what); }
    else { ++g_fail; std::printf("  FAIL  %s\n", what); }
}

// The declared shapes below are the ones the real call sites use:
//   PlayerModule.cpp / ChamsModule.cpp .ctor and material setters (2 object args),
//   QuestModule.cpp quest setters (int, bool, bool),
//   QuestModule.cpp / WeaponModule.cpp getters returning float / object / string.
static_assert(std::is_same_v<
    il2utils::with_methodinfo_t<void(*)(Il2CppObject*, Il2CppObject*, Il2CppObject*)>,
    void(*)(Il2CppObject*, Il2CppObject*, Il2CppObject*, const MethodInfo*)>,
    "hidden MethodInfo* must be the LAST argument");

static_assert(std::is_same_v<
    il2utils::with_methodinfo_t<void(*)(Il2CppObject*, int, bool, bool)>,
    void(*)(Il2CppObject*, int, bool, bool, const MethodInfo*)>,
    "MethodInfo* lands on the stack when the declared args fill the registers");

static_assert(std::is_same_v<
    il2utils::with_methodinfo_t<float(*)(Il2CppObject*)>,
    float(*)(Il2CppObject*, const MethodInfo*)>,
    "non-void return must be preserved");

static_assert(std::is_same_v<
    il2utils::with_methodinfo_t<Il2CppObject*(*)(Il2CppObject*, Il2CppString*)>,
    Il2CppObject*(*)(Il2CppObject*, Il2CppString*, const MethodInfo*)>,
    "Il2CppString* argument must be preserved");

} // namespace

int main()
{
    // Miss path: null instance -> null class -> resolve never runs, no call
    // happens, call_or returns its on_miss value untouched.
    Il2CppObjectInstance inst(nullptr);

    inst.call_or_void<void(*)(Il2CppObject*, Il2CppObject*, Il2CppObject*)>(
        ".ctor", 2, nullptr, nullptr);

    const float zoom = inst.call_or<float>("get_CurrentZoom", 0, 1.0f);
    check(zoom == 1.0f, "call_or miss returns on_miss (fail-closed float)");

    Il2CppObject* const obj = inst.call_or<Il2CppObject*>("get_Item", 0, nullptr);
    check(obj == nullptr, "call_or miss returns on_miss (nullptr object)");

    std::printf("%d passed, %d failed\n", g_pass, g_fail);
    return g_fail == 0 ? 0 : 1;
}
