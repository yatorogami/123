#pragma once

// Portable subset of TarkovAddons/include/common.h, for the native harness
// only.
//
// TarkovAddons/include/common.h opens with <windows.h>, <psapi.h> and
// <shlobj.h> and then pulls in <nlohmann/json.hpp>. None of that is reachable
// on Linux, and none of it is needed by the logic under test -- ConfigValue and
// the config parsers are standard-library only. This file is the same idea as
// tools/verify/msvc-shim: put a narrower header first on the include path so
// the one source line `#include "common.h"` in ConfigValue.cpp resolves to
// something compilable here.
//
// Renamed from pch.h when the project moved to CMake (e605d6395 renamed the
// real header to include/common.h; this shim kept the old name, so the harness
// case that includes it stopped compiling with C1083 and the harness carried on
// reporting BUILD FAILED while still exiting 0).
//
// It is a harness shim and never ships into the DLL. If you are reading this
// wondering whether the project PCH could be slimmed: it could, but that is a
// build-time question with a measured answer, not a test fixture.

#include <charconv>
#include <climits>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <map>
#include <optional>
#include <string>
#include <string_view>
#include <system_error>
#include <vector>
