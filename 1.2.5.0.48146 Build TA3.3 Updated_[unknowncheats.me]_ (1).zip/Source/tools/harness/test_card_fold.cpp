// Card fold state and its config-file record.
//
// Unlike most of what this harness covers, the logic under test is INCLUDED from
// the tree rather than reimplemented here: TarkovAddons/gui/menu/card_fold_state.h
// is header-only, has no ImGui/Win32 dependency, and is linked for real. That is
// the point of it living in its own header -- a copy of a user-facing file format
// in a test is a copy that silently drifts.
//
// Two things ARE copies, and both are noted below: utils::split, and the shape
// of ConfigModule::load_config's key/value pairing. Neither is the thing under
// test; they are the loader's surroundings, which this has to reproduce to reach
// the records at all.

#include "../../TarkovAddons/gui/menu/card_fold_state.h"

#include <cstdio>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

namespace utils {
    // COPY of TarkovAddons/util/utils.cpp:12. utils.cpp itself cannot be linked
    // here: its other function needs <windows.h>. getline() with a delimiter
    // does NOT emit a trailing empty field, which is what makes the 2-field
    // pairing below line up -- that is the property under test, so it is worth
    // stating rather than assuming.
    std::vector<std::string> split(const std::string& s, char delim) {
        std::vector<std::string> result;
        std::stringstream ss(s);
        std::string item;

        while (getline(ss, item, delim)) {
            result.push_back(item);
        }

        return result;
    }
} // namespace utils

namespace {
    // COPY of the shape of ConfigModule::load_config's pairing loop
    // (TarkovAddons/module/impl/ConfigModule.cpp). Module records are 4 fields
    // wide (key, value, favourite-key, favourite) and hotkeys/CARD records are 2,
    // so every record type shares one key/value map and the loop steps by 2.
    std::unordered_map<std::string, std::string> parse(const std::string& blob) {
        const auto res = utils::split(blob, ';');
        std::unordered_map<std::string, std::string> values;
        for (size_t i = 0; i + 1 < res.size(); i += 2)
            values[res[i]] = res[i + 1];
        return values;
    }

    // COPY of the shape of ConfigModule::save_config + hotkeys::append_save: a
    // module's four-field records, then the 2-field records appended after them.
    std::string build_file(const std::string& module_records) {
        std::string value = module_records;
        for (const char* id : {"exploit.fly_up", "esp.players", "aim.aimbot"}) {
            value.append("HK:");
            value.append(id);
            value.append(";");
            value.append("32;");
        }
        card_fold::append_save(value);
        return value;
    }

    // Two real records from a real config, at their real widths.
    const std::string modules =
        "radar_cb##Minimap;true;fav##Minimap;false;"
        "show_target_cb##Aimbot;true;fav##Aimbot;false;"
        "aim_type_sel##Aimbot;2;fav2##Aimbot;false;"
        "menu_language_sec##Configs;3;fav3##Configs;true;";

    int checks = 0;
    int failures = 0;
} // namespace

#define CHECK(cond, what)                                                       \
    do {                                                                        \
        ++checks;                                                               \
        if (cond) { printf("  ok:   %s\n", what); }                              \
        else { ++failures; printf("  FAIL: %s\n", what); }                       \
    } while (0)

int main() {
    printf("card fold: nothing folded -> nothing written\n");
    {
        card_fold::clear();
        const std::string file = build_file(modules);
        CHECK(file.find("CARD:") == std::string::npos, "save writes no CARD: record");
        card_fold::load(parse(file));
        CHECK(!card_fold::get("Minimap"), "Minimap open");
        CHECK(!card_fold::get("Aimbot"), "Aimbot open");
        CHECK(!card_fold::get("Configs"), "Configs open");
    }

    printf("card fold: a folded card survives save -> load\n");
    {
        card_fold::load(parse("CARD:Aimbot;true;CARD:Minimap;true;"));
        const std::string file = build_file(modules);
        card_fold::clear();
        card_fold::load(parse(file));
        CHECK(card_fold::get("Aimbot"), "Aimbot still folded after reload");
        CHECK(card_fold::get("Minimap"), "Minimap still folded after reload");
        CHECK(!card_fold::get("ESP"), "never-folded card stays open");
    }

    printf("card fold: only the literal \"true\" means folded\n");
    {
        // A config can be hand-edited, truncated, or written by a build that
        // spelled these differently. Unrecognised has to resolve to OPEN, which
        // is the direction that fails harmlessly.
        card_fold::load(parse("CARD:Aimbot;1;CARD:ESP;yes;CARD:Chams;"));
        CHECK(!card_fold::get("Aimbot"), "\"1\" is not folded");
        CHECK(!card_fold::get("ESP"), "\"yes\" is not folded");
        CHECK(!card_fold::get("Chams"), "empty value is not folded");
        CHECK(build_file(modules).find("CARD:") == std::string::npos,
            "nothing bogus is written back out");
    }

    printf("card fold: a ConfigValue record can never be read as a card\n");
    {
        // The sharpest available edge: a favourite key whose value IS "true"
        // (ConfigModule writes exactly that for a starred control), sitting
        // right next to a real record.
        card_fold::load(parse(
            "CARD:Minimap;true;fav##Minimap;true;CARD:##Aimbot;true;aim_type_sel##Aimbot;true;"));
        CHECK(card_fold::get("Minimap"), "the real record folded");
        CHECK(!card_fold::get("fav"), "a favourite key did not fold a card named \"fav\"");
        CHECK(!card_fold::get("aim_type_sel"), "a value key did not fold a card of the same name");
    }

    printf("card fold: load replaces, clear resets\n");
    {
        card_fold::load(parse("CARD:Aimbot;true;CARD:ESP;true;"));
        card_fold::load(parse("CARD:World;true;"));
        CHECK(!card_fold::get("Aimbot"), "Aimbot opened: load replaces rather than merges");
        CHECK(!card_fold::get("ESP"), "ESP opened: load replaces rather than merges");
        CHECK(card_fold::get("World"), "World folded from the newly loaded config");

        card_fold::clear();
        CHECK(!card_fold::get("World"), "Reset Defaults opens everything");
    }

    printf("card fold: output is sorted and a stale id is inert\n");
    {
        card_fold::load(parse("CARD:Aimbot;true;CARD:Module Removed 3.1;true;CARD:ESP;true;"));
        const std::string file = build_file(modules);
        CHECK(file.find("CARD:Aimbot;true;CARD:ESP;true;CARD:Module Removed 3.1;true;")
                  != std::string::npos,
            "records written in sorted order, so two saves of one state are byte-identical");
        CHECK(file.find("Module Removed") != std::string::npos,
            "an id no card answers to is preserved, not silently dropped");
    }

    printf("card fold: ids containing spaces round-trip\n");
    {
        // Every module card id is a module name and most contain a space, so this
        // is the ordinary case, not an edge one.
        card_fold::load(parse("CARD:Door Unlocker;true;CARD:Debug Log;true;"));
        const std::string file = build_file(modules);
        card_fold::clear();
        card_fold::load(parse(file));
        CHECK(card_fold::get("Door Unlocker"), "\"Door Unlocker\" round-trips");
        CHECK(card_fold::get("Debug Log"), "\"Debug Log\" round-trips");
    }

    printf("card fold: a truncated or empty tail cannot throw\n");
    {
        card_fold::load(parse("CARD:Aimbot;tr"));
        CHECK(!card_fold::get("Aimbot"), "odd field count does not fold");
        card_fold::load(parse(""));
        CHECK(!card_fold::get("Aimbot"), "an empty config is not a folded card");
        card_fold::load(parse("CARD:"));
        CHECK(!card_fold::get(""), "a bare prefix with no id folds nothing reachable");
    }

    printf("\n%d/%d passed\n", checks - failures, checks);
    return failures == 0 ? 0 : 1;
}