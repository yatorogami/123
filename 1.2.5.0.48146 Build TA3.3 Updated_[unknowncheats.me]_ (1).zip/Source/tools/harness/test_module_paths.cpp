// Executable coverage for util/module_paths.h.
//
// SCOPE NOTE -- this used to cover module_paths.h AND data_migration.h. The
// second half is gone because data_migration.h is: the pre-3.2 import moved to
// tools/migrate_legacy.py, with its tests in tools/tests/test_migrate_legacy.py
// (42 of them). See that module's docstring for why.
//
// What that removal bought, and it is the interesting part: the ~150 lines of
// %APPDATA% redirect guards this file used to carry are ALL deleted. They existed
// only because data_migration.h resolved the legacy folder from the ambient
// environment -- WORKFLOW.md records that a harness bug in exactly that area once
// moved 23 real user files, because _dupenv_s reads the CRT's copy of the
// environment and SetEnvironmentVariableW does not redirect it, so a harness that
// redirected with the Win32 call read back the real value, believed it worked,
// and migrated the user's real profile.
//
// module_paths.h never had that problem. It resolves everything through
// dll_directory_wide(), which prefers cached_dll_directory() -- an accessor
// returning a reference to a function-local static. Assigning to it redirects the
// whole namespace at a throwaway directory. No environment variable, no
// production change, and no way to point this test at somebody's real profile by
// accident. probe_test.cpp:98 already uses the sibling module_paths::init().
//
// That is the strongest argument for the move, restated as a testing fact: the
// hazard did not get guarded, it stopped existing.
//
// WHAT IS COVERED: wide_to_utf8 (including the non-ASCII and embedded-NUL cases
// the old one-byte heap overflow lived in), is_system_directory,
// data_directory_wide's no-ta/ compatibility fallback, the three ensure_*
// accessors, chams_bundle_path, path_from_utf8, and the unwritable-deployment
// fallback.
//
// NOT COVERED HERE, stated rather than left to be discovered: a genuine
// ACL-denied deployment. The unwritable FALLBACK is covered, by making "ta" a
// regular file so create_directories fails with an error -- which is the same
// branch, reached by a different route. A permission denial is a different path
// through the filesystem and is not the same test.

#include "../../shared/module_paths.h"

#include <algorithm>
#include <cstdio>
#include <filesystem>
#include <string>
#include <vector>

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
//  Tiny check framework. A failure names itself and keeps going, because a
//  harness that aborts on the first failure reports one defect per run.
// ---------------------------------------------------------------------------

static int g_pass = 0;
static int g_fail = 0;
static std::string g_group;

static void group(const char* name)
{
    g_group = name;
    std::printf("\n--- %s\n", name);
}

static void check(bool ok, const char* what)
{
    if (ok) {
        ++g_pass;
        std::printf("  ok   %s\n", what);
    } else {
        ++g_fail;
        std::printf("  FAIL %s   [%s]\n", what, g_group.c_str());
    }
}

static void check_str(const std::string& got, const std::string& want, const char* what)
{
    if (got == want) {
        ++g_pass;
        std::printf("  ok   %s\n", what);
    } else {
        ++g_fail;
        std::printf("  FAIL %s\n       want: %s\n        got: %s\n       [%s]\n",
            what, want.c_str(), got.c_str(), g_group.c_str());
    }
}

// module_paths.h is entirely wide -- std::filesystem::path, MAX_PATH buffers, the
// lot -- so most of its results come back as std::wstring. Comparing those through
// the narrow overload above does not compile, and a conversion would hide exactly
// the kind of encoding mistake this file is here to catch. So there is a wide
// overload, and it prints the code units on failure rather than narrowing.
static std::string widen_for_display(const std::wstring& w)
{
    std::string out;
    for (wchar_t c : w) {
        if (c >= 0x20 && c < 0x7f) {
            out.push_back(static_cast<char>(c));
        } else {
            char buf[16];
            std::snprintf(buf, sizeof buf, "\\u%04X", static_cast<unsigned>(c));
            out += buf;
        }
    }
    return out;
}

static void check_wstr(const std::wstring& got, const std::wstring& want, const char* what)
{
    if (got == want) {
        ++g_pass;
        std::printf("  ok   %s\n", what);
    } else {
        ++g_fail;
        std::printf("  FAIL %s\n       want: %s\n        got: %s\n       [%s]\n",
            what, widen_for_display(want).c_str(), widen_for_display(got).c_str(),
            g_group.c_str());
    }
}

// ---------------------------------------------------------------------------
//  Sandbox
// ---------------------------------------------------------------------------

static fs::path g_root;

static fs::path fresh(const char* name)
{
    const fs::path dir = g_root / name;
    std::error_code ec;
    fs::remove_all(dir, ec);
    fs::create_directories(dir, ec);
    return dir;
}

static void write_file(const fs::path& p, const std::string& body)
{
    std::error_code ec;
    fs::create_directories(p.parent_path(), ec);
    FILE* f = nullptr;
    _wfopen_s(&f, p.c_str(), L"wb");
    if (!f) {
        std::printf("  FAIL could not create %s\n", p.string().c_str());
        ++g_fail;
        return;
    }
    if (!body.empty())
        std::fwrite(body.data(), 1, body.size(), f);
    std::fclose(f);
}

static bool has(const fs::path& p)
{
    std::error_code ec;
    return fs::is_regular_file(p, ec);
}

// Point module_paths at `dir` for the current group. This is the whole seam.
static void use_deploy(const fs::path& dir)
{
    module_paths::cached_dll_directory() = dir;
}

static void reset_deploy()
{
    module_paths::cached_dll_directory() = fs::path{};
}

// ---------------------------------------------------------------------------
//  wide_to_utf8
// ---------------------------------------------------------------------------

static void test_wide_to_utf8()
{
    group("wide_to_utf8");
    use_deploy(fresh("mp_wide"));

    check_str(module_paths::wide_to_utf8(L""), "", "empty in, empty out");
    check_str(module_paths::wide_to_utf8(L"plain"), "plain", "ascii round-trips");

    // Non-ASCII is the case the old one-byte heap overflow lived in, and the only
    // reason it is worth a test at all: with -1 the API reports the byte count
    // INCLUDING the terminating NUL, which is what it then writes, so a buffer
    // declared size-1 was told it had `size` bytes.
    //
    // The wide input is code points and the expected output is UTF-8 BYTES. An
    // earlier version of this test wrote the UTF-8 bytes into the wide literal as
    // well, i.e. double-encoded it, and then failed while asserting that a
    // correct round-trip was broken. U+00E9 in, 0xC3 0xA9 out.
    check_str(module_paths::wide_to_utf8(L"caf\xe9-\u4e2d\u6587"),
        "caf\xc3\xa9-\xe4\xb8\xad\xe6\x96\x87", "non-ascii round-trips byte for byte");

    // The API is called with an explicit character count, so an embedded NUL
    // survives rather than truncating. That is what the -1 fix bought.
    std::wstring with_nul = L"ab";
    with_nul.push_back(L'\0');
    with_nul += L"cd";
    check_str(module_paths::wide_to_utf8(with_nul), std::string("ab\0cd", 5),
        "an embedded NUL is preserved, not treated as a terminator");
}

// ---------------------------------------------------------------------------
//  is_system_directory
// ---------------------------------------------------------------------------

static void test_is_system_directory()
{
    group("is_system_directory");
    use_deploy(fresh("mp_sysdir"));

    check(module_paths::is_system_directory({}), "empty counts as system (unresolved)");
    check(module_paths::is_system_directory(L"C:\\Windows\\System32"), "System32 is system");
    check(module_paths::is_system_directory(L"C:\\Windows\\SysWOW64\\foo"), "SysWOW64 is system");
    check(module_paths::is_system_directory(L"C:\\Windows\\WinSxS\\amd64_x"), "WinSxS is system");
    check(!module_paths::is_system_directory(L"C:\\Battlestate Games\\BsgLauncher"),
        "a real deployment directory is not system");
}

// ---------------------------------------------------------------------------
//  The compatibility fallback: no ta/ means the old layout keeps working
// ---------------------------------------------------------------------------

static void test_data_directory_compat_fallback()
{
    group("data_directory_wide falls back when there is no ta/");
    const fs::path dep = fresh("mp_nodata");
    use_deploy(dep);

    check_wstr(module_paths::data_directory_wide().wstring(), dep.wstring(),
        "no ta/ -> the DLL directory, unchanged pre-3.2 behaviour");

    std::error_code ec;
    fs::create_directories(dep / L"ta", ec);
    check_wstr(module_paths::data_directory_wide().wstring(), (dep / L"ta").wstring(),
        "ta/ present -> ta/");
}

// ---------------------------------------------------------------------------
//  The ensure_* accessors
// ---------------------------------------------------------------------------

static void test_ensure_creates()
{
    group("the ensure_* accessors create what they promise");
    const fs::path dep = fresh("mp_ensure");
    use_deploy(dep);

    check_wstr(module_paths::ensure_data_directory_wide().wstring(), (dep / L"ta").wstring(),
        "ensure_data_directory_wide creates ta/ and returns it");
    check(fs::is_directory(dep / L"ta"), "ta/ really exists on disk afterwards");

    check_wstr(module_paths::ensure_config_directory_wide().wstring(),
        (dep / L"ta" / L"configs").wstring(),
        "ensure_config_directory_wide creates and returns ta/configs/");
    check(fs::is_directory(dep / L"ta" / L"configs"), "ta/configs/ really exists");

    // chams_bundle_path creates ta/chams/ itself, and the file must NOT exist yet
    // -- Unity needs a path it can write, not a file we pre-created.
    const std::string bundle = module_paths::chams_bundle_path();
    check_str(bundle, (dep / L"ta" / L"chams" / L"tarkovutils").string(),
        "chams_bundle_path points at ta/chams/tarkovutils");
    check(!has(fs::path(bundle)), "the bundle file is not pre-created");
    check(fs::is_directory(dep / L"ta" / L"chams"), "ta/chams/ was created for it");
}

// ---------------------------------------------------------------------------
//  The unwritable-deployment fallback
// ---------------------------------------------------------------------------

static void test_unwritable_fallback()
{
    group("the unwritable-deployment fallback");

    // AGENTS_TODO.md item 3 and 1.4 both record this path as "reasoned about but
    // never exercised -- it needs a genuinely read-only install to provoke". That
    // is true of a permission denial, but the fallback is reached by ANY
    // create_directories failure, and the cheapest reliable one is a regular FILE
    // named "ta": is_directory is then false and create_directories fails with an
    // error, which is the exact branch under test.
    const fs::path dep = fresh("mp_unwritable");
    write_file(dep / L"ta", "this is a file, not a directory");
    use_deploy(dep);

    check_wstr(module_paths::data_directory_wide().wstring(), dep.wstring(),
        "data_directory_wide: a file named ta/ -> falls back to the DLL directory");
    check_wstr(module_paths::ensure_data_directory_wide().wstring(), dep.wstring(),
        "ensure_data_directory_wide: falls back rather than losing the write");
    check_wstr(module_paths::ensure_config_directory_wide().wstring(), dep.wstring(),
        "ensure_config_directory_wide: returns ta/'s OWN fallback, not a configs/ beside the DLLs");

    // The reason that fallback is the documented one: ConfigModule's legacy path
    // still finds the old file, so a write still lands somewhere the read path
    // looks. A configs/ next to the DLLs would not be read back.
    check(!fs::is_directory(dep / L"configs"),
        "and it does NOT scatter a configs/ beside the DLLs");

    reset_deploy();

    // An earlier version of this asserted the directory came back EMPTY once the
    // cache was cleared, and it failed. The implementation was right and the test
    // was wrong: dll_directory_wide() has a fourth route, GetModuleHandleExW with
    // GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS pointed at the function itself, so
    // with no cache and no TarkovAddons.dll it still resolves -- to whatever
    // module the code is running in. Here, the harness.
    //
    // That is worth asserting rather than working around, because it is the
    // fallback that makes the path resolvable when a loader has hidden the DLL
    // from the module list. It is also why the seam above is necessary: this test
    // redirects the namespace by assignment precisely so it does not depend on
    // which of the four routes happens to fire.
    wchar_t self[MAX_PATH]{};
    const DWORD self_len = GetModuleFileNameW(nullptr, self, MAX_PATH);
    check(self_len > 0 && self_len <= MAX_PATH, "the harness can locate its own image");
    if (self_len > 0 && self_len <= MAX_PATH) {
        const fs::path self_dir = fs::path(std::wstring(self, self_len)).parent_path();
        check_wstr(module_paths::dll_directory_wide().wstring(), self_dir.wstring(),
            "with no cache and no TarkovAddons.dll, the from-address route resolves "
            "the module the code is running in");
    }
}

// ---------------------------------------------------------------------------

static void test_path_from_utf8()
{
    group("path_from_utf8");
    use_deploy(fresh("mp_path"));

    check_wstr(module_paths::path_from_utf8("").wstring(), L"", "empty in, empty out");
    check_wstr(module_paths::path_from_utf8("ta\\configs").wstring(), L"ta\\configs",
        "ascii becomes a path");
    // UTF-8 bytes in, code points out -- the mirror image of wide_to_utf8 above,
    // and double-encoded the same way in an earlier version of this test.
    check_wstr(module_paths::path_from_utf8("caf\xc3\xa9").wstring(), L"caf\xe9",
        "utf8 bytes become the right code points");
}

int main()
{
    std::error_code ec;
    g_root = fs::temp_directory_path(ec) / L"ta_harness_module_paths";
    if (ec) {
        std::printf("cannot determine a temp directory: %s\n", ec.message().c_str());
        return 2;
    }
    fs::remove_all(g_root, ec);
    fs::create_directories(g_root, ec);
    if (ec) {
        std::printf("cannot create %s: %s\n", g_root.string().c_str(), ec.message().c_str());
        return 2;
    }

    std::printf("module_paths.h harness (Windows-only)\n");
    std::printf("sandbox: %s\n", g_root.string().c_str());
    std::printf("no environment variable is read or written by this test\n");

    test_wide_to_utf8();
    test_is_system_directory();
    test_data_directory_compat_fallback();
    test_ensure_creates();
    test_unwritable_fallback();
    test_path_from_utf8();

    reset_deploy();
    ec.clear();
    fs::remove_all(g_root, ec);
    if (ec) {
        std::printf("\nnote: sandbox cleanup reported '%s' -- reported rather than\n"
            "      ignored, because a half-removed tree looks like a clean one.\n",
            ec.message().c_str());
    }

    std::printf("\n%d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
