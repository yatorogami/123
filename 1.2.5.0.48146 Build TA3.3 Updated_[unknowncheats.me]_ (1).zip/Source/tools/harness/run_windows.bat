@echo off
rem Build and run the Windows half of the native test harness.
rem
rem   tools\harness\run_windows.bat      (exit 0 = pass, 1 = fail)
rem
rem pe_resource.h is nothing but Win32 -- GetModuleHandleExW, VirtualQuery,
rem ReadProcessMemory, FindResourceW -- so run.sh cannot compile it. It does not
rem need the project build, the game, or a deployed DLL though: only an MSVC
rem toolchain and rc.exe. That is all this needs.
rem
rem The portable cases (test_config.cpp, test_card_fold.cpp) are ALSO built and
rem run here, with /std:c++latest, so this is a Windows-only way to run the whole
rem harness. They were run.sh-only until now, which made them unreachable on a
rem machine with MSVC but no compiler-for-Linux -- i.e. exactly this one, so
rem test_config.cpp could not be re-run here either and a new portable case would
rem have shipped unverified. run.sh remains the cross-platform entry point and
rem runs the same two.
rem
rem test_module_paths.cpp is the third case and is Windows-ONLY by nature: it covers
rem shared/module_paths.h, which is nothing but Win32. It is not portable and is not
rem expected to become so.
rem
rem It needs no shim and no stubs. It briefly did -- it also covered
rem util/data_migration.h, whose logger dependency needed a link-level stub because
rem MSVC resolves a quoted include against the including file's own directory first.
rem That header moved to tools/migrate_legacy.py, which is covered by pytest, so
rem both of those went away with it.

setlocal EnableDelayedExpansion

rem --- LINE ENDINGS ARE LOAD-BEARING -------------------------------------------
rem Keep this file CRLF. Measured 2026-10-10 with LF-only endings: cmd.exe
rem failed to find the :portable label for the native_memo call ("The system
rem cannot find the batch label specified - portable"), reproduced 3/3, 14 of
rem the 15 cases run, exit 1. The same content as CRLF ran 15/15. The failure
rem is position-sensitive -- the previous, 783-byte-shorter revision passed
rem either way -- so a green run at LF is not evidence, and an editor that
rem rewrites this file as LF can reintroduce it. `.gitattributes` (repo root)
rem pins *.bat to CRLF at checkout; check the endings if a case goes missing.

set "HERE=%~dp0"
set "OUT=%TEMP%\ta_harness"
if not exist "%OUT%" mkdir "%OUT%" || exit /b 1

rem --- locate MSVC ------------------------------------------------------------
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
  echo run_windows: vswhere.exe not found; cannot locate an MSVC toolchain.
  echo               Install "Desktop development with C++" or run this from a
  echo               "Developer Command Prompt".
  exit /b 1
)

set "VCVARS="
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do (
  if exist "%%i\VC\Auxiliary\Build\vcvars64.bat" set "VCVARS=%%i\VC\Auxiliary\Build\vcvars64.bat"
)
if not defined VCVARS (
  echo run_windows: found a Visual Studio install but no vcvars64.bat with the C++ tools.
  exit /b 1
)

call "%VCVARS%" >nul || (echo run_windows: vcvars64.bat failed & exit /b 1)
pushd "%HERE%" || exit /b 1

rem --- resources --------------------------------------------------------------
rem rc.exe is what gives the harness something real to read. Without real RCDATA
rem in the image, "the reader finds the payload" is not a test of anything.
echo === compiling resources
rc /nologo /fo "%OUT%\pe_resource_test.res" pe_resource_test.rc || (popd & exit /b 1)

rem --- portable cases (the ones run.sh runs) -----------------------------------
rem /std:c++latest because run.sh passes -std=c++23 and one of the cases uses
rem std::string::starts_with. Building them here at a lower standard than they
rem are developed against is how a case starts failing for a toolchain reason
rem and gets mistaken for a real regression.
set "RESULT=0"
call :portable config test_config.cpp stubs.cpp ..\..\TarkovAddons\config\ConfigValue.cpp || set "RESULT=1"
call :portable card_fold test_card_fold.cpp || set "RESULT=1"
rem module_paths is Windows-only and needs neither the shim nor a stub.
call :portable module_paths test_module_paths.cpp || set "RESULT=1"
rem probe_memo is Windows-only too: the table it covers answers "is this address inside
rem a committed VirtualQuery region", which is Win32. No shim, no stubs.
call :portable probe_memo test_probe_memo.cpp || set "RESULT=1"
rem native_memo is PORTABLE in the same way: the syscall is stubbed with a bool, because
rem what is under test is the TTL, the slot table and the "never cache a dead answer" rule.
rem Those are the parts that can be wrong; VirtualQuery itself is the OS's problem.
call :portable native_memo test_native_memo.cpp || set "RESULT=1"
rem range_slot_index is PORTABLE for the same reason: the optics table cannot be included
rem (it pulls in the whole lens pipeline), so the test copies the page-hash and slot-index
rem arithmetic and asserts the two properties that can actually be wrong -- the index
rem staying in range, which is what catches a missing mask, and consecutive pages not
rem collapsing onto one slot, which is what the >> 52 mis-edit does.
call :portable range_slot_index test_range_slot_index.cpp || set "RESULT=1"
rem export_lookup is Windows-only like probe_memo: it compiles the REAL scan.h, and it is
rem there because il2cpp_offsets.h grew a hand-rolled PE export reader that runs on the
rem GetProcAddress failure path. A parser that faults there turns a diagnosable startup
rem failure into a crash during diagnosis, so it is tested before anyone relies on it.
call :portable export_lookup test_export_lookup.cpp || set "RESULT=1"
rem il2cpp_call_abi is Windows-only like export_lookup: it compiles the REAL
rem il2cpp/Il2CppObjectInstance.h and pins il2utils::with_methodinfo -- the trait
rem that appends the hidden trailing MethodInfo* to every checked-wrapper call.
rem The static_asserts use the exact declared shapes the call sites use; a
rem "simplification" of the trait would still compile at every call site and
rem silently resume passing a garbage trailing slot, which is how the 2026-10-08
rem Dictionary<object,object>::Add crash happened. The runtime half exercises the
rem wrappers' miss path (null instance -> on_miss, no call through null).
rem The two extra sources are the link dependencies the case was missing when it
rem was added in 1e3e7c8f1: it includes the real Il2CppObjectInstance.h and calls
rem into it, so Il2CppObjectInstance.cpp has to be linked, and that in turn needs
rem safetyhook. Without them this case could only ever report LNK2019 -- it has
rem never passed since it was committed.
rem
rem NOT built via :portable, because that puts shim\ first on the include path
rem and Il2CppObjectInstance.cpp's own `#include "common.h"` would then resolve
rem to the portable stand-in -- which has no <windows.h>, so PVOID in
rem il2cpp-class-internals.h:605 is undefined (C3646/C4430). Here the real
rem TarkovAddons\include\ is what must win.
rem Zydis.c is safetyhook's own dependency; safetyhook.cpp references
rem ZydisDecoderInit/ZydisDecoderDecodeInstruction and cannot link without it.
rem meta_key is the allocation-free content-based memo key used by
rem resolve_field/resolve_method. Needs no shim and no Win32: meta_key.h includes
rem only <cstddef>/<cstdint>/<cstring>. The negative control is the point -- it
rem compiles the rejected pointer-keyed variant and asserts it returns the WRONG
rem entry when the allocator reuses an address.
call :native meta_key test_meta_key.cpp || set "RESULT=1"
rem The debugger gate. MEASURED 2026-10-10, by the matrix this case now runs
rem end-to-end: OutputDebugStringA raises 0x40010006 in-process on EVERY call,
rem debugger or not, and a debug port makes the kernel convert the print raises
rem into OUTPUT_DEBUG_STRING_EVENTs before any in-process delivery -- so a print
rem flood pays a VEH visit per event with or without a debugger (that is the
rem 2026-10-09 100% CPU; "attaching a debugger created the events" was backwards
rem and is retracted in the case's header). The per-event STACK WALK the flood
rem used to pay as well is the print_capture_policy case below -- it is gone as
rem of 2026-10-10. Since that date the print codes are also CONSUMED wherever
rem they are delivered: skipping left them unhandled, and on a classic-delivery
rem model the kernel's answer is a second-chance stop per call. The case asserts
rem the predicate matrix, calls the real handler, then debugs itself; the parent
rem DECIDES which measured delivery model the machine runs (classic: consume arm
rem zero second-chance stops, control arm at least one; converted, this machine:
rem no print exception delivered at all, >=4 string events per arm -- the
rem consume arm is dormant here and says so).
call :native debugger_gate test_debugger_gate.cpp || set "RESULT=1"
rem print_capture_policy: the cost half of the same 2026-10-10 work. A routine
rem OutputDebugString event is captured by HEAD ONLY now -- the string survives
rem (head-captured params), the walk that cost ~0.8-2.0 ms per event (measured,
rem figures in the case) does not run, and Event::walked lets the report say
rem "not scanned" instead of printing zeroes. The case also asserts a fatal
rem print still walks, the throw control still walks, and a negative control
rem proves the walk WOULD have found frames -- so the empty frame list cannot
rem pass vacuously.
call :native print_capture_policy test_print_capture_policy.cpp || set "RESULT=1"
call :native il2cpp_call_abi test_il2cpp_call_abi.cpp ^
    ..\..\TarkovAddons\il2cpp\Il2CppObjectInstance.cpp ^
    ..\..\external\safetyhook\safetyhook.cpp ^
    ..\..\external\safetyhook\Zydis.c || set "RESULT=1"
rem quest_objectives_text is PORTABLE and needs no shim and no stub: it compiles
rem TarkovAddons/module/quest_objective_text.h, which is header-only and has no
rem IL2CPP, no ImGui and no Win32 in it. That header is a separate file for
rem exactly this reason -- the objective text shaping (verb per condition class,
-- target joining, duplicate summing, ordering, UTF-8 truncation, ASCII folding)
rem is the part with decisions in it that a wrong answer would hide in the UI.
rem The other half of the objective summary, in quest_objectives.h, reads
rem Conditions off a live quest and is NOT covered here.
call :portable quest_objectives_text test_quest_objectives_text.cpp || set "RESULT=1"
rem text_fold is PORTABLE and needs no shim and no stub for the same reason: it
rem compiles TarkovAddons/util/text_fold.h, header-only with no IL2CPP, no ImGui
rem and no Win32. It covers the UTF-8 case folding the ITEM SEARCH uses -- the
rem mechanism that makes a Russian or Greek player's query match a localized name.
rem std::tolower is ASCII-only in the C locale (nothing here calls setlocale), and
rem 5947 of 6001 item names are localized, so the search silently matched nothing
rem for non-Latin scripts. It also pins the idempotence and malformed-input
rem behaviour the index build depends on.
call :portable text_fold test_text_fold.cpp || set "RESULT=1"
rem loot_categories is PORTABLE for the same reason: it compiles the REAL
rem TarkovAddons/module/item_categories.h, which needs nothing but <string> and
rem <unordered_set>. It covers the class-name -> loot-category table that replaced
rem substring matching over the item's display name. That table is the only place the
rem mapping decisions live (MedicalSuppliesTemplate is barter not medical, a MOD is
rem barter not a weapon, EquipmentTemplate is armor, containers are unclassified and
rem must say so), and every one of them is a judgement call that a later well-meaning
rem edit would silently flip. It does NOT cover reading tpl->klass->name, which needs a
rem live runtime and is reported by the class-tally log line in game_item_db.h.
call :portable loot_categories test_loot_categories.cpp || set "RESULT=1"
rem wishlist_groups is PORTABLE for the same reason as loot_categories above: it
rem compiles the REAL item_categories.h, and the wishlist half of that header is
rem pure functions over a struct of string sets -- no IL2CPP, no ImGui, no Win32.
rem It exists because llvm-cov over the portable set measured that header at 5 of 11
rem functions executed: loot_class_is_known, wishlist_all_mask, filter_sets::add,
rem filter_sets::in_group, classify_id and classify_group were never called by any
rem test, while the predicate they feed -- wishlist_allows -- was. That is the whole
rem chain that turns the game's EWishlistGroup dictionary into an answer, untested
rem except for its last step. Negative-controlled 2026-10-12: flipping
rem classify_id's hideout-priority order, dropping add()'s union write, and
rem ignoring in_group's !ready guard each fail it, and each name the right thing.
call :portable wishlist_groups test_wishlist_groups.cpp || set "RESULT=1"
rem column_layout is PORTABLE for the same reason: it compiles the REAL
rem TarkovAddons/gui/menu/column_layout.h, which needs nothing but <string_view>,
rem <vector> and module/ModuleCategory.h -- no ImGui, no IL2CPP, no Win32. That is
rem what lets the menu's two-column layout be asserted at all. The layout used to be
rem eleven `m->name == "..."` predicates inside the draw loop and cost three defects
rem in one afternoon (2026-10-03); the boundary is now resolved from the cards that
rem will actually be shown, before any of them is drawn. Its last case reads
rem ModuleManager.h as text and checks the table's names and the registration order,
rem because the table keys on module names and a rename would otherwise break the
rem layout with nothing failing.
call :portable column_layout test_column_layout.cpp || set "RESULT=1"
rem survival_clamp is PORTABLE for the same reason: it compiles the REAL
rem TarkovAddons/module/survival_clamp.h, which needs nothing but <cstdint>. That
rem header was lifted out of PlayerModule.h precisely so the decision table behind
rem the three survival modes -- god_mode, "Buddha Mode" (god_mode2) and semi_god --
rem could be checked without the game. The two hooks that CALL it live in
rem semi_god:: (PlayerModule.h) and are NOT covered here; what is covered is that
rem each mode clamps exactly the parts it claims to. The assertion that matters
rem most is the buddha-vs-semi difference, because both arms work and the failure
rem mode is a working feature that is simply the wrong one.
rem Negative-controlled 2026-10-12 -- six mutations each fail it by name, and one
rem mutation was claimed as a control, measured green, and removed from the list
rem because `>=` and `>` are the same function at the clamp's boundary. See the
rem long form at the head of test_survival_clamp.cpp.
call :portable survival_clamp test_survival_clamp.cpp || set "RESULT=1"

rem quick_search is the fuzzy ranking behind the menu's quick-jump palette
rem (Ctrl+K). Portable for the same reason column_layout is: the header is pure
rem functions over strings, with no ImGui, no IL2CPP and no Win32, because
rem menu.cpp needs the artwork, resources.h and the DX hook and can be linked
rem by nothing. The assertions that matter are the ORDERING ones -- a matcher
rem that finds the right row fourth is a palette nobody uses twice, and "it
rem matched something" would not catch that. Cyrillic folding is asserted
rem deliberately: std::tolower is ASCII-only in this project's C locale, which
rem is the measured defect util/text_fold.h was written for.
call :portable quick_search test_quick_search.cpp || set "RESULT=1"

rem hotkey_conflicts is the grouping behind the key-conflict report in the
rem hotkeys panel. Portable for the same reason: bookkeeping over
rem (key, label) rows, no ImGui and no Win32. The literal menu-toggle key it
rem uses is static_asserted against VK_INSERT in hotkeys.h and asserted again
rem inside the case, so the two cannot drift silently. The load-bearing rule is
rem that key 0 -- unbound -- never collides, or the default configuration
rem would open with a page of false conflicts.
call :portable hotkey_conflicts test_hotkey_conflicts.cpp || set "RESULT=1"

rem changed_marker_layout is where the changed-from-default gutter dot goes.
rem Portable for the same reason: arithmetic on four floats, no ImGui and no
rem Win32, because its call site in menu.cpp cannot be linked by anything.
rem Negative-controlled 2026-10-14 -- three mutations, one per position this
rem header exists to reject (row top, row centre, unbounded hit area), each of
rem which fails the case by name. The assertion that matters most is that the
rem dot does not MOVE when the row grows: in this menu the row height is content
rem (a two-line slider, a search row that grows with the number of results), and
rem both earlier positions were functions of it.
call :portable changed_marker_layout test_changed_marker_layout.cpp || set "RESULT=1"

rem lens_size_frame_summary: the lens-size gate's PER-FRAME decisions. This one
rem links the REAL optics_lens_pipeline.h rather than re-declaring the shape --
rem lenssize_stubs.cpp supplies the three out-of-line symbols its inline globals
rem need (InlineHook::~InlineHook, Allocation::~Allocation, vector3::vector3).
rem The discriminating case is alternating reject/accept, which must report
rem TIMER STARVED, against a long reject run plus a fired re-baseline, which must
rem not. A summary that always claimed starvation would be indistinguishable from
rem one that measured it.
call :portable lens_size_summary test_lens_size_summary.cpp lenssize_stubs.cpp || set "RESULT=1"
rem footprint_cost MEASURES rather than asserts: it fills a real
rem unordered_map<MetaKey, void*, MetaKeyHash> -- the actual key type -- and takes
rem the slope of GetProcessMemoryInfo to get bytes-per-node and the bucket array.
rem That constant is what the mod footprint reporter uses, so the "how much of the
rem game's 31 GB is ours" question rests on a measurement instead of sizeof()
rem arithmetic. The negative control frees the map and asserts the memory returns.
rem :native because it needs real <windows.h> and <psapi.h>.
call :native footprint_cost test_footprint_cost.cpp || set "RESULT=1"

rem --- build ------------------------------------------------------------------
echo === building pe_resource_test.exe
cl /nologo /std:c++20 /EHsc /W3 /O2 /MT ^
   pe_resource_test.cpp "%OUT%\pe_resource_test.res" ^
   /Fe:"%OUT%\pe_resource_test.exe" ^
   /Fo:"%OUT%\\" ^
   /link /SUBSYSTEM:CONSOLE || (popd & exit /b 1)

rem --- run --------------------------------------------------------------------
echo === running pe_resource_test
"%OUT%\pe_resource_test.exe" || set "RESULT=1"

popd
exit /b %RESULT%

rem ---------------------------------------------------------------------------
rem :portable <name> <src> [extra sources...]
rem   Builds and runs one run.sh case against shim\common.h. shim/ has to come
rem   first on the include path so the one `#include "common.h"` in
rem   ConfigValue.cpp resolves to the portable stand-in rather than the real
rem   TarkovAddons\include\common.h, which opens with <windows.h>.
:portable
echo === building %~1
cl /nologo /std:c++latest /EHsc /W3 /O2 /MT /I shim /I ..\.. ^
   /Fe:"%OUT%\%~1.exe" /Fo:"%OUT%\\" ^
   %~2 %3 %4 %5 || ( echo   BUILD FAILED & exit /b 1 )
echo === running %~1
"%OUT%\%~1.exe" || exit /b 1
exit /b 0

rem ---------------------------------------------------------------------------
rem :native <name> <src> [extra sources...]
rem   Same as :portable, but WITHOUT shim\ on the include path: these cases
rem   compile real project sources that legitimately need <windows.h>, so the
rem   real TarkovAddons\include\common.h must resolve instead of the stand-in.
rem   ..\..\external is for safetyhook/Zydis.h.
:native
echo === building %~1
cl /nologo /std:c++latest /EHsc /W3 /O2 /MT /I ..\..\TarkovAddons\include ^
   /I ..\.. /I ..\..\external ^
   /Fe:"%OUT%\%~1.exe" /Fo:"%OUT%\\" ^
   %~2 %3 %4 %5 || ( echo   BUILD FAILED & exit /b 1 )
echo === running %~1
"%OUT%\%~1.exe" || exit /b 1
exit /b 0
