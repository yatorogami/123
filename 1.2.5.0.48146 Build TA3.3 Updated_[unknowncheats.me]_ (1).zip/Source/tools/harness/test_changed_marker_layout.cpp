// Coverage for TarkovAddons/gui/menu/changed_marker_layout.h -- where the
// changed-from-default gutter dot goes.
//
// WHY THIS EXISTS
//
// The dot has been in the wrong place twice, for the same reason both times:
// each fix picked a function of the row's HEIGHT without asking what that
// height means. First it was pinned to the row's top edge, then re-centred on
// the row box. Neither survived contact with the menu, because row height here
// is CONTENT: a slider row is two lines, and ItemSearchValue's row grows with
// the number of search results, so a row-height-derived dot slides down while
// the user is reading the label. The header is its own file, and the harness
// compiles it, for the same reason quick_search.h and column_layout.h are:
// menu.cpp needs the artwork, resources.h and the DX hook and can be linked by
// nothing, so an inline test could only ever exercise a copy.
//
// The pixel values below are NOT measurements of this menu's theme -- they are
// ratios chosen so the assertions read as claims about geometry rather than
// about a font size. The load-bearing assertions are:
//
//   * THE DOT DOES NOT DEPEND ON THE ROW'S HEIGHT. Same label line, row grows
//     from one line to a 200px search result list, identical dot_y. This is
//     the whole point, and every other assertion here is a corollary.
//   * A one-line row is UNCHANGED from the row-centred formula, because for
//     row_h == label_line_h the two are the same expression. Most rows are one
//     line, so this is the "no visual regression on the common row" guard.
//   * The dot sits INSIDE the label line, and not flush to the row's top edge:
//     the second of the two rejected positions is only rejected if something
//     pins it. A marker half a line high reads as mis-registered, and a test
//     that cannot tell the two apart has not chosen between them.
//   * The HIT AREA never exceeds the label line, so a tall row does not turn
//     the gutter into a 200px invisible button whose tooltip appears next to
//     an empty results list.
//   * Degenerate input cannot produce an unclickable marker: row_h == 0 (a row
//     that drew nothing) and a max cap below the line both still leave a
//     positive-height button.
//
// Every one of these is negative-controlled in negctl.py: three mutations, one
// per rejected formula, each of which fails this case by name.

#include <iostream>

#include "../../TarkovAddons/gui/menu/changed_marker_layout.h"

namespace cml = changed_marker_layout;

static int g_pass = 0;
static int g_fail = 0;

static void check(const bool condition, const char* what) {
    if (condition) ++g_pass;
    else {
        ++g_fail;
        std::cout << "FAIL: " << what << "\n";
    }
}

static void check_near(const float a, const float b, const float tol, const char* what) {
    check((a > b ? a - b : b - a) <= tol, what);
}

int main() {
    // A plausible label line at sf == 1: ImGui::GetFrameHeight() is the text
    // height plus the frame's padding, and every label here is drawn with
    // AlignTextToFramePadding so its line box is exactly a frame.
    const float line = 21.f;
    const float cap = 18.f; // 18 * sf, as menu.cpp passes it

    // ---- 1. THE CLAIM: row height does not move the dot --------------------
    // The search row before and after the user types, with results: 1 line,
    // then 2, then a 200px list. Same label line, three rows.
    {
        const auto one = cml::compute(100.f, line, line, cap);
        const auto two = cml::compute(100.f, 2.f * line, line, cap);
        const auto tall = cml::compute(100.f, 200.f, line, cap);
        check_near(one.dot_y, 110.5f, 0.01f, "one-line row centres on the label line");
        check_near(two.dot_y, one.dot_y, 0.01f,
            "a two-line slider's dot does NOT move (row centre would)");
        check_near(tall.dot_y, one.dot_y, 0.01f,
            "a 200px search row's dot does NOT move (row centre would)");
        // And the rejected formula, stated as the arithmetic it replaces, so the
        // difference is a number rather than an adjective: on the tall row the
        // row-centred dot sits 89.5px below this one -- most of a screen of
        // result list between the dot and the label.
        const float row_centred = 100.f + 200.f * 0.5f;
        check(row_centred - tall.dot_y > 80.f,
            "the row-centred position would have been ~90px away from the label");
    }

    // ---- 2. A one-line row is untouched by the change ------------------------
    // For row_h == label_line_h the two formulas are the same expression, so
    // every checkbox/textbox row in the menu draws its dot exactly where it did.
    {
        const auto p = cml::compute(40.f, line, line, cap);
        check_near(p.dot_y, 40.f + line * 0.5f, 0.01f,
            "single-line row: label-centred == row-centred, no visual change");
    }

    // ---- 3. On the label line, and not flush to the row top ------------------
    // The second rejected position is only rejected if a test pins it.
    {
        const auto p = cml::compute(300.f, 200.f, line, cap);
        check(p.dot_y > 300.f + 1.f,
            "dot is NOT flush to the row's top edge (reads as mis-registered)");
        check(p.dot_y < 300.f + line - 1.f,
            "dot sits INSIDE the label line, above the control below it");
        check_near(p.dot_y, 300.f + line * 0.5f, 0.01f,
            "dot is centred on the label line");
    }

    // ---- 4. The hit area is badge-sized, whatever the row is -----------------
    // NOTE on which bound does what: with line (21) above the cap (18), it is
    // the CAP that binds on a tall row, and both give the same answer -- which
    // is why the row-height mutation below is caught only by the last case,
    // where the cap (400) exceeds the line (8). Both bounds are still asserted.
    {
        const auto tall = cml::compute(300.f, 200.f, line, cap);
        check_near(tall.button_h, cap, 0.01f,
            "tall row: hit area is capped at 18*sf, not the row's height");
        check(tall.button_h < 200.f / 4.f,
            "tall row: hit area is a small fraction of the widget");
        // Centred on the same line as the dot, so hovering the dot's own pixels
        // is what triggers it.
        check_near(tall.button_y + tall.button_h * 0.5f, tall.dot_y, 0.01f,
            "hit area is centred on the dot");
        // ...and it starts at the label, not halfway down the widget.
        check(tall.button_y < 300.f + line,
            "tall row: hit area starts on the label line");
    }

    // ---- 5. Degenerate input leaves a pressable marker -----------------------
    {
        // A row that drew nothing still reports a height; ImGui's own guard is
        // the empty rect, and a value that emits no widget (a hidden row measured
        // anyway) reports 0. Clamping the line to a zero-height row would make
        // the button zero-height: a dot the user can see and never press.
        const auto empty_row = cml::compute(50.f, 0.f, line, cap);
        check(empty_row.button_h > 0.f,
            "a zero-height row still gets a clickable button");
        check_near(empty_row.dot_y, 50.f + line * 0.5f, 0.01f,
            "a zero-height row still puts the dot on the label line");
        // A cap below the line: the button shrinks to the cap and stays centred,
        // rather than overflowing the line it is supposed to annotate.
        const auto small = cml::compute(50.f, 200.f, line, 6.f);
        check_near(small.button_h, 6.f, 0.01f, "a smaller cap is honoured");
        check_near(small.button_y + small.button_h * 0.5f, small.dot_y, 0.01f,
            "a smaller cap stays centred on the dot");
        // A cap LARGER than the line never inflates the hit area past it, which
        // is the same rule as the tall-row cap above, at a different scale.
        const auto huge = cml::compute(50.f, 200.f, 8.f, 400.f);
        check_near(huge.button_h, 8.f, 0.01f,
            "a cap above the line is clamped to the line, not honoured");
        // A label line taller than its row cannot happen in ImGui, and must not
        // put the dot outside what was drawn if it ever did.
        const auto impossible = cml::compute(50.f, 10.f, 40.f, cap);
        check(impossible.dot_y <= 50.f + 10.f,
            "an over-long label line is clamped to the row, not trusted");
    }

    // ---- 6. The cap never moves the dot -------------------------------------
    // The scale factor reaches this code only through max_button_h. If raising
    // the DPI scale nudged the dot as well as the hit area, every marker on the
    // screen would drift with the user's display settings.
    {
        const auto small = cml::compute(100.f, 200.f, line, 18.f);
        const auto large = cml::compute(100.f, 200.f, line, 36.f);
        check_near(small.dot_y, large.dot_y, 0.01f,
            "the DPI cap does not move the dot");
        check(large.button_h > small.button_h,
            "the DPI cap does grow the hit area");
    }

    std::cout << (g_fail ? "FAILED " : "ok ") << g_pass << " passed, " << g_fail
              << " failed\n";
    return g_fail ? 1 : 0;
}