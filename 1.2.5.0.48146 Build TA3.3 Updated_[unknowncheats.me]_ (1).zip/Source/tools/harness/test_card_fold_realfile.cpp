// End-to-end check of the card-fold LOAD path against the user's REAL config file.
//
// This includes the real TarkovAddons/gui/menu/card_fold_state.h -- the same
// header the DLL uses -- and reproduces the parse loop from
// ConfigModule::load_config verbatim. The only thing it cannot include is
// utils::split's real definition (util/utils.cpp needs <windows.h>), so that one
// function is a marked copy, exactly as in test_card_fold.cpp.
//
// The question being answered is not "does the format round-trip" (test_card_fold
// already asserts that 25 ways). It is: does the config file that is actually on
// disk produce folded cards whose ids match the ids menu.cpp hands to
// draw_card_frame?

#include "../../TarkovAddons/gui/menu/card_fold_state.h"

#include <cstdio>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

namespace utils {
    // COPY of TarkovAddons/util/utils.cpp:12 (its other function needs <windows.h>).
    std::vector<std::string> split(const std::string& s, char delim) {
        std::vector<std::string> result;
        std::stringstream ss(s);
        std::string item;
        while (getline(ss, item, delim)) result.push_back(item);
        return result;
    }
}

int main(int argc, char** argv) {
    const char* path = argc > 1 ? argv[1]
        : "C:\\Battlestate Games\\BsgLauncher\\ta\\configs\\legit_sel";

    std::ifstream in(path, std::ios::binary);
    if (!in) { std::printf("cannot open %s\n", path); return 1; }
    std::stringstream buffer;
    buffer << in.rdbuf();
    const std::string blob = buffer.str();
    in.close();

    std::printf("config: %s\n", path);
    std::printf("size:   %zu bytes\n", blob.size());

    // VERBATIM: ConfigModule::load_config's pairing loop.
    const auto res = utils::split(blob, ';');
    std::unordered_map<std::string, std::string> values;
    for (size_t i = 0; i + 1 < res.size(); i += 2) values[res[i]] = res[i + 1];
    std::printf("fields: %zu tokens -> %zu key/value pairs\n\n", res.size(), values.size());

    // The real header, via the real entry point ConfigModule calls.
    card_fold::load(values);

    std::printf("folded after card_fold::load():\n");
    int n = 0;
    for (const auto& [id, collapsed] : card_fold::state())
        if (collapsed) { std::printf("  [%s]\n", id.c_str()); ++n; }
    std::printf("  (%d folded)\n\n", n);

    // The ids menu.cpp actually passes, as a module card's draw_card() does.
    const char* card_ids[] = {
        "Aimbot", "Door Unlocker", "Weapon", "Player", "Minimap", "Chams", "ESP",
        "Map Editor", "Debug Log", "Raid Dashboard", "Favorites", "Configs",
        "Trader Editor", "Hideout", "Experience Editor", "Hideout Automation",
        "Weapon Builder", "Item Editor", "Teleport", "Quest Completer",
        "Bot Control", "Inventory Editor", "Ammo HUD", "Watermark",
        "credits", "hotkeys",
    };

    std::printf("would each card draw folded?\n");
    for (const char* id : card_ids)
        std::printf("  %-22s %s\n", id, card_fold::get(id) ? "FOLDED" : "open");

    std::printf("\nunknown ids in the file (no card answers to these): ");
    bool any = false;
    for (const char* id : card_ids) {
        (void)id;
    }
    for (const auto& [id, collapsed] : card_fold::state()) {
        if (!collapsed) continue;
        bool known = false;
        for (const char* k : card_ids) if (id == k) { known = true; break; }
        if (!known) { std::printf("[%s] ", id.c_str()); any = true; }
    }
    if (!any) std::printf("(none)\n");
    return 0;
}