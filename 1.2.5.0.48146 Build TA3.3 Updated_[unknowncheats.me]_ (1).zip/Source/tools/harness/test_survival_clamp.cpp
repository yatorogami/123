// Portable test for survival_clamp.h -- the damage clamp behind the three
// survival modes (god_mode, "Buddha Mode" / god_mode2, and semi_god_mode).
//
// This header has no IL2CPP, no Win32 and no ImGui, so it is included directly
// rather than copied -- the point of lifting it out of PlayerModule.h was that
// the decision table is the one part of the three modes that can be checked
// without the game. The hooks that call it are in semi_god (PlayerModule.h) and
// are NOT covered here; what is covered is "does each mode clamp the parts it
// claims to, and not the ones it does not".
//
// The three properties that actually matter, in the order they would bite:
//
//   1. The floor is real. A protected part hit hard enough to go negative must
//      come out at exactly 1 HP, not at 0 and not at some fraction.
//   2. The modes differ ONLY where they are supposed to. Buddha protects
//      Head..RightLeg; semi protects Head and Thorax only. A regression that
//      gives semi-god the buddha arm (or vice versa) is the single most likely
//      way this change breaks, because both still "work" -- one is just the
//      wrong feature.
//   3. Every guard fails OPEN. An unreadable part, an already-blackout part, a
//      heal: all must forward the game's own delta. A clamp that fires on a bad
//      read freezes a limb at a number nobody asked for, which is worse than
//      the damage it was preventing.
//
// NEGATIVE CONTROL, because a checker that cannot fail is worse than no checker
// (AGENTS.md). Each mutation below was applied to survival_clamp.h on 2026-10-12
// and the ones marked [fails] were observed to fail THIS case, by name:
//
//   [fails] re-add `if (current >= k_protected_floor_hp) return delta;` -- the
//           clamp becomes a no-op for every part not ALREADY at the floor, which
//           is nearly all of them. This one was not hypothetical: it is the guard
//           this file caught in the first draft of survival_clamp.h.
//   [fails] semi arm -> `body_part <= k_body_part_last` -- semi-god grows a
//           buddha arm and stops being "semi". Still a working feature, which is
//           what makes it the regression worth pinning.
//   [fails] `buddha` arm -> `body_part >= k_body_part_head` -- Common(7) gets
//           clamped against a per-limb floor.
//   [fails] `if (!(current > 0.0f)) return delta;` deleted -- an already-
//           destroyed part is healed back to 1 HP, and an unreadable one is
//           clamped off `k_unknown_hp`.
//   [fails] `delta >= 0.0f` -> `delta > 0.0f` -- caught ONLY by the below-the-
//           floor zero-delta case above. Every other healing assertion starts from
//           a part at or above 1 HP, where the two spellings agree; the first
//           draft of this file claimed the mutation was caught and it was not.
//   [fails] `k_protected_floor_hp` -> `0.0f` -- parts black out anyway, which is
//           the entire bug the feature was written to fix.
//
// NOT a control, and it is worth saying why: flipping the overshoot test from
// `>=` to `>` is UNOBSERVABLE here. At the boundary current + delta == floor, the
// clamp returns floor - current, which is exactly `delta`. `>=` and `>` are
// therefore the same function; the first draft listed it as a control and
// measured it green, which is a reminder that a mutation list is a set of claims
// and every one of them has to be run.

#include <cstdio>
#include <string_view>

#include "../../TarkovAddons/module/survival_clamp.h"

namespace {

using survival_clamp::apply;
using survival_clamp::k_protected_floor_hp;
using survival_clamp::k_unknown_hp;
using survival_clamp::mode;
using survival_clamp::part_is_protected;

// EBodyPart, dump.cs 1525196 (build 1.1.5.47510).
constexpr int head = 0;
constexpr int thorax = 1;
constexpr int stomach = 2;
constexpr int left_arm = 3;
constexpr int left_leg = 5;
constexpr int common = 7;

int failures = 0;

void check(const bool ok, const char* what) {
    if (!ok) { std::printf("  FAIL  %s\n", what); ++failures; }
    else     { std::printf("  ok    %s\n", what); }
}

void check_near(const float got, const float want, const char* what) {
    // Exact comparison would be right for the values chosen here: every arm of
    // apply() returns either the caller's delta verbatim or
    // k_protected_floor_hp - current, and the inputs are exactly representable.
    // A tolerance would let a clamp that is merely NEAR the floor pass.
    if (got == want) { std::printf("  ok    %s\n", what); }
    else { std::printf("  FAIL  %s (got %.6f, want %.6f)\n", what, got, want); ++failures; }
}

const char* mode_name(const mode m) { return survival_clamp::name(m); }

} // namespace

int main() {
    std::printf("survival_clamp tests (floor = %.1f HP)\n\n", k_protected_floor_hp);

    // ---- (1) the floor is real --------------------------------------------
    // A lethal hit on a protected part must land on exactly 1 HP, not below.
    {
        const float got = apply(mode::buddha, thorax, 100.0f, -500.0f);
        check_near(got, k_protected_floor_hp - 100.0f,
            "buddha: lethal hit on thorax stops at exactly 1 HP");
        check_near(got + 100.0f, k_protected_floor_hp,
            "buddha: thorax ends the event at 1 HP, not below it");
    }
    {
        // The boundary: current + delta == 1 exactly must NOT be clipped. Clipping
        // it would forward 0 and, worse, would make the clip fire on the most
        // common possible result.
        const float got = apply(mode::buddha, left_arm, 40.0f, -39.0f);
        check_near(got, -39.0f, "buddha: a hit landing exactly on 1 HP is not clipped");
    }
    {
        // A hit that stops short of the floor is forwarded whole.
        const float got = apply(mode::buddha, left_leg, 100.0f, -30.0f);
        check_near(got, -30.0f, "buddha: a hit that stays above 1 HP is untouched");
    }
    {
        // Repeated small bites converge to the floor instead of through it. This
        // is the realistic shape: bleed ticks, not one 500-damage nuke.
        float current = 100.0f;
        for (int i = 0; i < 200; ++i) {
            const float applied = apply(mode::semi, head, current, -5.0f);
            current += applied;
        }
        check_near(current, k_protected_floor_hp,
            "semi: 200 ticks of 5 damage leave the head at exactly 1 HP");
    }

    // ---- (2) the modes differ only where they should ----------------------
    {
        check(part_is_protected(mode::buddha, head), "buddha protects head");
        check(part_is_protected(mode::buddha, thorax), "buddha protects thorax");
        check(part_is_protected(mode::buddha, stomach), "buddha protects stomach");
        check(part_is_protected(mode::buddha, left_arm), "buddha protects left arm");
        check(part_is_protected(mode::buddha, left_leg), "buddha protects left leg");
        check(!part_is_protected(mode::buddha, common),
            "buddha does NOT protect Common(7) -- it is the whole-body aggregate");

        check(part_is_protected(mode::semi, head), "semi protects head");
        check(part_is_protected(mode::semi, thorax), "semi protects thorax");
        check(!part_is_protected(mode::semi, stomach), "semi does NOT protect stomach");
        check(!part_is_protected(mode::semi, left_arm), "semi does NOT protect left arm");
        check(!part_is_protected(mode::semi, left_leg), "semi does NOT protect left leg");
    }
    {
        // The behaviour, not just the predicate: a leg may black out under semi
        // and may not under buddha. This is the assertion that distinguishes the
        // two features, so it is stated on the float the hook forwards.
        check_near(apply(mode::semi, left_leg, 100.0f, -500.0f), -500.0f,
            "semi: a leg takes the full hit and blacks out");
        check_near(apply(mode::buddha, left_leg, 100.0f, -500.0f), -99.0f,
            "buddha: the same leg hit stops at 1 HP");
        check_near(apply(mode::semi, head, 100.0f, -500.0f), -99.0f,
            "semi: the head still stops at 1 HP");
    }
    {
        // god_mode clamps NOTHING. Its denial is done per frame by
        // SetDamageCoeff(-1)/RestoreFullHealth in PlayerModule.cpp, so if apply()
        // also clamped here the two would disagree and the game would see a delta
        // no mode asked for.
        check(!part_is_protected(mode::god, head), "god_mode protects nothing (head)");
        check(!part_is_protected(mode::god, thorax), "god_mode protects nothing (thorax)");
        check(!part_is_protected(mode::god, left_leg), "god_mode protects nothing (leg)");
        check_near(apply(mode::god, thorax, 100.0f, -500.0f), -500.0f,
            "god_mode: ChangeHealth is a pure passthrough");

        // off must be identical to god, or turning every toggle off would still
        // leave a clamp running.
        check_near(apply(mode::off, thorax, 100.0f, -500.0f), -500.0f,
            "off: ChangeHealth is a pure passthrough");
    }
    {
        // Mutually exclusive modes: exactly one of the three is ever non-off.
        int live = 0;
        for (const mode m : {mode::off, mode::god, mode::buddha, mode::semi})
            live += part_is_protected(m, thorax) ? 1 : 0;
        check(live == 2, "exactly two modes protect thorax (buddha + semi), not three");
    }

    // ---- (3) every guard fails open ---------------------------------------
    {
        // Unreadable part. k_unknown_hp is the sentinel the hook passes when the
        // _bodyState walk misses; clamping on it would divide the limb off at 1
        // HP for a reason that has nothing to do with the damage.
        check_near(apply(mode::buddha, head, k_unknown_hp, -500.0f), -500.0f,
            "buddha: an unreadable part is not clamped");
        check_near(apply(mode::semi, thorax, k_unknown_hp, -500.0f), -500.0f,
            "semi: an unreadable part is not clamped");
    }
    {
        // Already destroyed. 0 HP is a real, reachable value and it means the
        // game has flipped IsDestroyed; writing 1 HP back leaves the part at 1 HP
        // and still broken, so the damage must pass.
        check_near(apply(mode::buddha, head, 0.0f, -50.0f), -50.0f,
            "buddha: a part already at 0 HP is not healed back up");
    }
    {
        // Healing is never clamped, in any mode, at any health level -- including
        // a part sitting exactly at the floor, which is where buddha leaves it.
        check_near(apply(mode::buddha, head, 1.0f, 25.0f), 25.0f,
            "buddha: healing from the floor is not clamped");
        check_near(apply(mode::semi, thorax, 1.0f, 25.0f), 25.0f,
            "semi: healing from the floor is not clamped");
        check_near(apply(mode::semi, left_leg, 0.0f, 10.0f), 10.0f,
            "semi: healing a destroyed leg is not clamped");
        check_near(apply(mode::buddha, head, 100.0f, 0.0f), 0.0f,
            "buddha: a zero delta is forwarded as zero");
        // ...including on a part already BELOW the floor, which is reachable: the
        // clamp only holds parts at >= 1 from the moment it is enabled, so a limb
        // at 0.5 HP when the toggle goes on is a real state. A zero delta there
        // must stay zero; treating ">= 0" as "healing" and letting the sign test
        // fall through turns it into +0.5 and quietly heals the limb.
        check_near(apply(mode::buddha, head, 0.5f, 0.0f), 0.0f,
            "buddha: a zero delta below the floor is not turned into a heal");
    }
    {
        // A hit that undershoots the floor by a fraction is still an overshoot, so
        // it is clipped and the part lands on exactly 1. There is no "already at
        // the floor, pass it through" branch -- that would let a part sit below 1
        // HP, which is the state the whole feature exists to prevent.
        check_near(apply(mode::buddha, head, 1.0f, -0.5f), 0.0f,
            "buddha: a half-point chip at the floor is fully absorbed");
        check_near(apply(mode::semi, head, 200.0f, -199.5f), -199.0f,
            "semi: a hit that undershoots by 0.5 is clipped to land on 1");
        // The regression this pair exists for: an "already at/above the floor,
        // return delta" guard passes every other test in this file while making
        // the clamp a no-op. Both halves must therefore be hit from a part that is
        // nowhere near the floor.
        check_near(apply(mode::buddha, stomach, 100.0f, -100.0f), -99.0f,
            "buddha: a part at 100 HP hit for exactly its whole health lands on 1");
    }

    // ---- names, for the one log line that reports which mode installed ----
    check(std::string_view(mode_name(mode::god)) == "god_mode", "mode::god names itself god_mode");
    check(std::string_view(mode_name(mode::buddha)) == "buddha", "mode::buddha names itself buddha");
    check(std::string_view(mode_name(mode::semi)) == "semi_god", "mode::semi names itself semi_god");
    check(std::string_view(mode_name(mode::off)) == "off", "mode::off names itself off");

    std::printf("\n%s\n", failures == 0 ? "survival_clamp: OK" : "survival_clamp: FAILED");
    return failures == 0 ? 0 : 1;
}