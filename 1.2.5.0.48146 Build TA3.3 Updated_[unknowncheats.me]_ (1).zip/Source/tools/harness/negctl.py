#!/usr/bin/env python3
"""Negative controls for the two pure-logic harness cases.

For each mutation listed below: patch the header, rebuild and run the case,
record which assertions fail, restore the header. A control that leaves the
case green is a control that proves nothing, and is reported as such -- this
project has shipped three separate checkers that passed while comparing
nothing.

Run from tools/harness with the MSVC toolchain on PATH:
    python negctl.py
"""
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CL = ["cl", "/nologo", "/std:c++latest", "/EHsc", "/W3", "/O2", "/MT",
      "/I", "shim", "/I", "../..", "/Fe:negctl_test.exe", "/Fo:.\\"]

CASES = {
    "quick_search": "test_quick_search.cpp",
    "hotkey_conflicts": "test_hotkey_conflicts.cpp",
    "changed_marker_layout": "test_changed_marker_layout.cpp",
}


def run_case(case: str) -> str:
    exe = HERE / "negctl_test.exe"
    build = subprocess.run(CL + [case], cwd=HERE, capture_output=True, text=True)
    if build.returncode != 0:
        return "BUILD FAILED: " + (build.stderr.strip().splitlines() or [""])[-1]
    run = subprocess.run([str(exe)], cwd=HERE, capture_output=True, text=True)
    tail = [ln for ln in run.stdout.splitlines() if ln.strip()]
    if run.returncode == 0:
        return "GREEN (control proves nothing): " + (tail[-1] if tail else "no output")
    failures = [ln.strip() for ln in tail if "FAIL:" in ln]
    summary = tail[-1] if tail else "no summary"
    return f"{summary} :: " + " | ".join(failures) if failures else summary


def mutate(header: Path, old: str, new: str) -> bool:
    text = header.read_text(encoding="utf-8")
    if text.count(old) != 1:
        print(f"    (anchor not unique in {header.name}: {text.count(old)} matches)")
        return False
    header.write_text(text.replace(old, new), encoding="utf-8")
    return True


def restore(header: Path, backup: Path) -> None:
    # Write bytes and replace, not shutil.copy2: on this machine copy2 raised
    # PermissionError on a file the just-finished compile had touched, and a
    # control that cannot restore leaves a mutation in the tree -- which is
    # precisely the failure this whole script exists to make visible.
    data = backup.read_bytes()
    tmp = header.with_suffix(header.suffix + ".restore")
    tmp.write_bytes(data)
    last_exc: Exception | None = None
    for _ in range(10):
        try:
            tmp.replace(header)
            return
        except PermissionError as exc:  # pragma: no cover - timing dependent
            last_exc = exc
            time.sleep(0.25)
    if last_exc is not None:
        raise last_exc


MUTATIONS = [
    # ---- quick_search.h ---------------------------------------------------
    # NOTE ON THE FORM OF THESE: a mutation that DELETES a statement inside an
    # `if` body silently moves the `if` onto the next line and tests something
    # else entirely -- the first version of the label-bonus control did exactly
    # that and came back green for the wrong reason. Every mutation therefore
    # neutralises the line (`+= 0`) or replaces the whole statement, leaving the
    # parse identical.
    ("quick_search",
     "TarkovAddons/gui/menu/quick_search.h",
     "return k_substring_base - 2 * pos - static_cast<int>(hay.size() - needle.size());",
     "return 1; // CONTROL: substring branch flattened",
     "substring branch flattened to a constant"),
    ("quick_search",
     "TarkovAddons/gui/menu/quick_search.h",
     "if (prev_matched && gap_penalty < k_max_gap_penalty) {",
     "if (false && prev_matched && gap_penalty < k_max_gap_penalty) { // CONTROL: gap penalty removed",
     "gap penalty removed (the run-trade-off ladder collapses)"),
    ("quick_search",
     "TarkovAddons/gui/menu/quick_search.h",
     "if (i == 0 || is_boundary_char(hay[i - 1])) score += k_boundary_bonus;",
     "if (i == 0 || is_boundary_char(hay[i - 1])) score += 0; // CONTROL: boundary bonus removed",
     "word-boundary bonus removed"),
    ("quick_search",
     "TarkovAddons/gui/menu/quick_search.h",
     "total += k_label_bonus;",
     "total += 0; // CONTROL: label bonus removed",
     "label bonus removed (card flooding returns)"),
    ("quick_search",
     "TarkovAddons/gui/menu/quick_search.h",
     "            if (s < 0) return -1;",
     "            if (s < 0) continue; // CONTROL: term no longer required",
     "terms no longer all required"),
    ("quick_search",
     "TarkovAddons/gui/menu/quick_search.h",
     "std::stable_sort(out.begin(), out.end(),\n            [](const match& a, const match& b) { return a.score > b.score; });",
     "std::sort(out.begin(), out.end(),\n            [](const match& a, const match& b) { return a.score < b.score; }); // CONTROL: reversed",
     "ranking reversed"),
    # ---- hotkey_conflicts.h ------------------------------------------------
    ("hotkey_conflicts",
     "TarkovAddons/gui/menu/hotkey_conflicts.h",
     "            if (r.key == 0) continue;",
     "            // CONTROL: unbound rows collide",
     "unbound rows treated as collisions"),
    ("hotkey_conflicts",
     "TarkovAddons/gui/menu/hotkey_conflicts.h",
     "            if (kv.second.labels.size() >= 2 || kv.second.reserved)",
     "            if (kv.second.labels.size() >= 2)",
     "reserved-key rule dropped"),
    ("hotkey_conflicts",
     "TarkovAddons/gui/menu/hotkey_conflicts.h",
     "        std::sort(out.begin(), out.end(),\n            [](const group& a, const group& b) { return a.key < b.key; });",
     "        // CONTROL: no sort",
     "report left unsorted"),
    ("hotkey_conflicts",
     "TarkovAddons/gui/menu/hotkey_conflicts.h",
     "            if (it == acc.end())\n                acc.push_back({r.key, group{r.key, r.key == reserved_key, {r.label}}});\n            else {",
     "            if (true)\n                acc.push_back({r.key, group{r.key, r.key == reserved_key, {r.label}}});\n            else {",
     "no merging of same-key rows"),
    # ---- changed_marker_layout.h --------------------------------------------
    # One control per position this header exists to REJECT. Each is a real
    # version the dot was actually shipped at, not an invented strawman: the
    # first two commits pinned the dot to the row top and then to the row
    # centre, and the unbounded hit area is what shipped before the cap.
    ("changed_marker_layout",
     "TarkovAddons/gui/menu/changed_marker_layout.h",
     "out.dot_y = row_top_y + line * 0.5f;",
     "out.dot_y = row_top_y + height * 0.5f; // CONTROL: row centre, the version that shipped",
     "dot re-centred on the row box (moves with content again)"),
    ("changed_marker_layout",
     "TarkovAddons/gui/menu/changed_marker_layout.h",
     "        if (line > height) line = height;",
     "        // CONTROL: the over-long-label-line clamp removed",
     "an over-long label line is trusted (dot can land outside the row)"),
    ("changed_marker_layout",
     "TarkovAddons/gui/menu/changed_marker_layout.h",
     "out.button_h = (std::min)(max_button_h, line);",
     "out.button_h = (std::min)(max_button_h, height); // CONTROL: cap raised to the row",
     "hit area spans a tall row instead of staying badge-sized"),
]


def main() -> int:
    results = []
    for case, header_rel, old, new, label in MUTATIONS:
        header = HERE.parent.parent / header_rel
        backup = HERE / (header.name + ".ctl_backup")
        backup.write_bytes(header.read_bytes())
        try:
            if not mutate(header, old, new):
                results.append((label, "ANCHOR MISS -- control not run"))
                continue
            outcome = run_case(CASES[case])
        finally:
            restore(header, backup)
            backup.unlink(missing_ok=True)
        results.append((label, outcome))
        print(f"  {label:45s} {outcome}")

    greens = [l for l, o in results if o.startswith("GREEN")]
    print()
    print(f"{len(results)} controls run, {len(greens)} green")
    for label in greens:
        print(f"  GREEN (proves nothing): {label}")
    return 1 if greens else 0


if __name__ == "__main__":
    sys.exit(main())
