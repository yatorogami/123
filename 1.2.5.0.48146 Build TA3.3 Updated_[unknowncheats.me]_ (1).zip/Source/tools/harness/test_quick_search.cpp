// Coverage for TarkovAddons/gui/menu/quick_search.h -- the fuzzy ranking
// behind the menu's quick-jump palette (Ctrl+K).
//
// WHY THIS EXISTS
//
// The menu has 31 cards across ten tabs and there was no way to reach a card
// without knowing which of the ten it was on. The palette is that way in, and
// the feature is entirely in the RANKING: a matcher that finds the right row
// fourth is a palette nobody uses twice. menu.cpp cannot be linked here -- it
// needs ImGui, resources.h and the DX hook -- so the ranking was split into
// its own header for the same reason card_fold_state.h and column_layout.h
// were, and this compiles the real one.
//
// What is asserted, and why each matters:
//
//   * Substring beats scattered subsequence, and prefix beats buried. A palette
//     that ranks "aimbot fov" below "...contains those letters somewhere" is
//     worse than useless, because every row would look equally plausible.
//   * A subsequence still matches at all -- that is the entire premise
//     ("aimfov" -> "Aimbot FOV").
//   * Every term must match. "god noclip" matching "God Mode" alone would bury
//     the row the user meant under everything else the first term touches.
//   * A card's own entry outranks its value entries when the query names the
//     card. Without the label bonus, querying "esp" matches every ESP row
//     through the card text appended to its haystack and floods the list.
//   * Cyrillic folds. std::tolower is ASCII-only in this project's C locale
//     (nothing calls setlocale), and the labels are localized -- this is the
//     same measured defect util/text_fold.h was written for.
//   * The order is deterministic, and equal scores keep index order.
//
// ONE RULE HAS NO CONTROL, and the reason is recorded rather than hidden: the
// per-match run bonus (+10) trades directly against the gap penalty (-1 per
// skipped character), so with the matched letters and the skip count held
// equal the two terms cancel and no ordering can observe one alone. Pinning it
// would mean asserting an absolute score, which is a constant that breaks the
// first time anyone retunes the weights. negctl.py therefore pins the combined
// rule (the ladder in section 2) with the GAP penalty as its control.

#include <cstddef>
#include <iostream>
#include <string>
#include <vector>

#include "../../TarkovAddons/gui/menu/quick_search.h"

namespace qs = quick_search;

static int g_pass = 0;
static int g_fail = 0;

static void check(const bool condition, const char* what) {
    if (condition) ++g_pass;
    else {
        ++g_fail;
        std::cout << "  FAIL: " << what << "\n";
    }
}

static qs::entry make_entry(const char* label, const char* card, const char* tab_label,
                           const bool is_card = false) {
    qs::entry e;
    e.label = label;
    e.card = card;
    e.tab_label = tab_label;
    e.is_card = is_card;
    return e;
}

// The first result's label, or "<none>" -- printed by the callers so a failure
// shows the ranking rather than a count.
static std::string first_label(const std::vector<qs::match>& hits,
                               const std::vector<qs::entry>& index) {
    if (hits.empty()) return "<none>";
    return index[hits.front().index].label;
}

int main() {
    // ---- 1. degenerate queries ------------------------------------------------
    {
        const std::vector<qs::entry> index{make_entry("FOV", "Aimbot", "Exploit")};
        check(qs::rank("", index).empty(), "an empty query ranks nothing");
        check(qs::rank("   ", index).empty(), "a whitespace-only query ranks nothing");
        check(qs::rank("fov", {}).empty(), "an empty index ranks nothing");
    }

    // ---- 2. substring beats subsequence, prefix beats buried ------------------
    {
        check(qs::score_folded("fov", "fov") > qs::score_folded("fov", "fxoxv"),
            "a contiguous substring outscores a scattered subsequence");
        check(qs::score_folded("fov", "fov") > qs::score_folded("fov", "sprint follow up"),
            "a prefix outscores a match buried deep in a longer string");
        check(qs::score_folded("fov", "fxoxv") > 0,
            "a scattered subsequence still matches at all");
        check(qs::score_folded("fov", "vo") < 0,
            "an out-of-order needle does NOT match (subsequence, not anagram)");
        check(qs::score_folded("xyz", "fov") < 0,
            "an absent needle does not match");

        // The scoring trade-off, stated the way it actually behaves: a match
        // run is worth +10 per matched letter and each skipped character
        // costs -1, so the SAME letters score higher the fewer characters
        // are skipped between them. This is the ladder that decides which
        // fuzzy match wins, and it bundles the two terms deliberately -- a
        // negative control that removed only the run bonus could never be
        // observed by any ordering (the gap term would still decide), which
        // is why negctl.py pins this with the GAP penalty instead and says so.
        check(qs::score_folded("abc", "abxc") > qs::score_folded("abc", "abxyc"),
            "matched letters with fewer skipped characters in between score higher");
        check(qs::score_folded("abc", "ab c") > qs::score_folded("abc", "abxc"),
            "a match that starts a word scores above the same match mid-word");
    }

    // ---- 3. every term must match -------------------------------------------
    {
        const std::vector<qs::entry> index{
            make_entry("God Mode", "Player", "Exploit"),
            make_entry("Noclip", "Player", "Exploit"),
        };
        // "god noclip" matches neither row (no label contains both terms), which
        // is the point: it must not quietly rank "God Mode" first and let the
        // user believe it found the combined thing they typed.
        const auto both = qs::rank("god noclip", index);
        check(both.empty(), "no row satisfies BOTH terms");

        const auto one = qs::rank("god", index);
        check(one.size() == 1 && first_label(one, index) == "God Mode",
            "a single term matches exactly the row that has it");
    }

    // ---- 4. the card entry outranks its values ------------------------------
    {
        // Every value's haystack contains "esp" through the card text appended
        // after its label, so without the label bonus these would all tie with
        // (or beat) the card itself.
        const std::vector<qs::entry> index{
            make_entry("Show Loot Prices", "ESP", "Exploit"),
            make_entry("Show Player Names", "ESP", "Exploit"),
            make_entry("ESP", "ESP", "Exploit", true),
        };
        const auto hits = qs::rank("esp", index);
        check(!hits.empty() && first_label(hits, index) == "ESP",
            "naming a card ranks the CARD first, not its values");
        check(hits.size() == 3, "and still finds every row on it");
    }

    // ---- 4b. the same rule when the card's own haystack is LONGER ------------
    {
        // The label bonus is load-bearing, not decoration. Here the card's
        // haystack is the longer of the two, so on substring position alone
        // the VALUE would outrank it -- only the "the query hit this entry's
        // own label" bonus puts the card back on top. This is the fixture the
        // bonus was added for; the earlier block passes even without it.
        const std::vector<qs::entry> index{
            make_entry("zzz", "AAA", "T"),                          // value
            make_entry("AAA", "AAA", "A very long tab name", true), // the card
        };
        const auto hits = qs::rank("aaa", index);
        check(hits.size() == 2 && first_label(hits, index) == "AAA",
            "the card outranks its value even when its own haystack is longer");
    }

    // ---- 5. ordering across cards -------------------------------------------
    {
        const std::vector<qs::entry> index{
            make_entry("Smoothness", "Aimbot", "Exploit"),
            make_entry("Aimbot FOV", "Aimbot", "Exploit"),
            make_entry("FOV", "Camera", "Exploit"),
        };
        // "aimfov" is a subsequence of "Aimbot FOV" (a-i-m-f-o-v) and of nothing
        // else with the second term's help; with one term, "FOV" is a substring
        // but so is "aim...fov"'s run.
        const auto hits = qs::rank("aimfov", index);
        check(!hits.empty() && first_label(hits, index) == "Aimbot FOV",
            "the subsequence query finds 'Aimbot FOV'");
        const auto fov = qs::rank("fov", index);
        check(fov.size() == 2 && first_label(fov, index) == "FOV",
            "'fov' ranks the exact label above the label that contains it");
    }

    // ---- 6. folding: Cyrillic, like the item search --------------------------
    {
        const std::vector<qs::entry> index{
            make_entry("\xD0\xAD\xD0\xA1\xD0\x9F", "card", "tab"), // "ЭСП"
        };
        // "эсп" folded is the same bytes as "ЭСП" folded; a comparison built on
        // std::tolower would leave both sides untouched-but-different.
        const auto hits = qs::rank("\xD1\x8D\xD1\x81\xD0\xBF", index);
        check(!hits.empty(), "a lowercase Cyrillic query matches an uppercase Cyrillic label");
        const auto wrong = qs::rank("\xD1\x8D\xD1\x81\xD1\x80", index); // "эср"
        check(wrong.empty(), "the same query with one wrong letter does not");
        const auto ascii = qs::rank("ESP", index);
        check(ascii.empty(), "a Latin query does not match a Cyrillic label");
    }

    // ---- 7. determinism and the cap -----------------------------------------
    {
        std::vector<qs::entry> index;
        for (int i = 0; i < 40; ++i) {
            // Identical labels on purpose: every score ties, so the order below
            // is the input order or the test is right to fail.
            index.push_back(make_entry("row", "card", "tab"));
        }
        const auto a = qs::rank("row", index, 5);
        const auto b = qs::rank("row", index, 5);
        check(a.size() == 5, "max_results caps the list");
        bool same = a.size() == b.size();
        for (size_t i = 0; same && i < a.size(); ++i)
            same = a[i].index == b[i].index && a[i].score == b[i].score;
        check(same, "the same query twice produces the identical order");
        bool input_order = true;
        for (size_t i = 1; i < a.size(); ++i)
            if (a[i].index <= a[i - 1].index) input_order = false;
        check(input_order, "equal scores keep index order (stable_sort)");
    }

    // ---- 8. query with a typo still finds the row ----------------------------
    {
        const std::vector<qs::entry> index{
            make_entry("Smoothness", "Aimbot", "Exploit"),
            make_entry("Auto Switch", "Weapon", "Exploit"),
        };
        // "smthnss" skips the vowels -- the case a strict substring test fails.
        const auto hits = qs::rank("smthnss", index);
        check(!hits.empty() && first_label(hits, index) == "Smoothness",
            "missing letters still rank the right row");
    }

    std::cout << (g_fail ? "FAILED " : "ok ") << (g_pass + g_fail)
              << " assertions, " << g_fail << " failed\n";
    return g_fail ? 1 : 0;
}
