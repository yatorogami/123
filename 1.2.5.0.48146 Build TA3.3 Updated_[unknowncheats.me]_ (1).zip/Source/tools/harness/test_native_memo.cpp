// Exercises the native-object memo's TTL and slot logic from unity.h.
//
// This is the second memo in the codebase and the first one keyed on a POINTER rather than
// on a region, so the things worth testing are different from the string memo's:
//   - a memo with no expiry would stop noticing a dead object forever
//   - a memo that cached "dead" would break the chams self-heal that depends on this
//   - one entry would thrash, because ChamsModule alternates several shader pointers
// None of that needs the project, the game, or a deployed DLL.
#include <cstdint>
#include <cstdio>
#include <vector>

namespace {

inline constexpr unsigned kNativeMemoTtlCalls = 64;
inline constexpr size_t kNativeMemoSlots = 16;

struct native_object_memo {
    const void* ptr = nullptr;
    unsigned long long stamp = 0;
};
native_object_memo g_slots[kNativeMemoSlots];

inline size_t native_memo_index(uintptr_t ptr) {
    static_assert((kNativeMemoSlots & (kNativeMemoSlots - 1)) == 0,
        "the mask is only valid for a power-of-two table");
    return static_cast<size_t>((ptr * 11400714819323198485ull) >> 32) & (kNativeMemoSlots - 1);
}

struct native_object_counters {
    unsigned long long hits = 0;
    unsigned long long misses = 0;
    unsigned long long revalidations = 0;
};
native_object_counters g_stats;

// `syscall_succeeds` stands in for VirtualQuery: it can be flipped mid-test, which is how a
// real object dying is simulated.
bool g_syscall_succeeds = true;
unsigned long long g_syscalls = 0;

bool memoised_check(const void* cached_ptr) {
    if (!cached_ptr) return false;
    native_object_memo& memo = g_slots[native_memo_index(reinterpret_cast<uintptr_t>(cached_ptr))];
    const auto now = g_stats.hits + g_stats.misses;
    const bool same_pointer = memo.ptr == cached_ptr;
    const bool expired = now - memo.stamp >= kNativeMemoTtlCalls;
    if (same_pointer && !expired) { g_stats.hits += 1; return true; }
    if (same_pointer) g_stats.revalidations += 1;
    g_stats.misses += 1;

    ++g_syscalls;
    const bool alive = g_syscall_succeeds;
    if (!alive) { memo.ptr = nullptr; return false; }
    memo.ptr = cached_ptr;
    memo.stamp = now;
    return true;
}

void reset(bool syscall_ok = true) {
    for (auto& s : g_slots) s = native_object_memo{};
    g_stats = native_object_counters{};
    g_syscalls = 0;
    g_syscall_succeeds = syscall_ok;
}

int g_failures = 0;
void check(bool cond, const char* what) {
    printf("  %s  %s\n", cond ? "ok  " : "FAIL", what);
    if (!cond) ++g_failures;
}

} // namespace

int main() {
    printf("test_native_memo\n");

    // 1. The hot case: one pointer, called every frame. This is the bundle path, and it is
    //    the one the profile priced at 1.09 ms per call.
    {
        reset();
        const void* p = (const void*)0x2000;
        for (int i = 0; i < 4096; ++i) (void)memoised_check(p);
        printf("        4096 calls on one pointer: %llu syscalls\n", g_syscalls);
        check(g_stats.hits == 4096 - g_syscalls, "every call after the first is a hit");
        // 4096 calls at TTL 64 = one syscall per 64 calls.
        check(g_syscalls == 4096 / kNativeMemoTtlCalls,
            "exactly one syscall per TTL window, not one per call");
        check(g_stats.revalidations == g_syscalls - 1,
            "every syscall after the first is counted as a REVALIDATION, not a first check");
    }

    // 2. THE POINT OF THE TTL. An object that dies while the pointer is unchanged must be
    //    noticed, and within the TTL. Without this, memoising would have been unsound.
    {
        reset();
        const void* p = (const void*)0x3000;
        (void)memoised_check(p);
        check(g_stats.hits == 0, "first call is a miss (cold)");
        g_syscall_succeeds = false;   // the native object dies
        // Inside the TTL the memo still answers "alive". That is the accepted staleness, and
        // it is ASSERTED rather than left implicit: if this ever stops being true the TTL has
        // stopped bounding anything and the memo is unsound.
        check(memoised_check(p), "inside the TTL a dead object still reads alive (the window)");
        // Walk out of the TTL. The check must now go to the syscall and report the death.
        for (int i = 0; i < kNativeMemoTtlCalls; ++i) (void)memoised_check(p);
        const bool final_answer = memoised_check(p);
        check(!final_answer, "past the TTL the death is detected");
        check(g_stats.revalidations > 0, "and it was counted as a revalidation");
    }

    // 3. A DEAD result must never be cached. If "dead" were memoised, the shader would be
    //    cached dead forever and the chams self-heal would never fire. This is the one
    //    failure that would make the memo worse than no memo.
    {
        reset(false);   // syscall fails from the start
        const void* p = (const void*)0x4000;
        for (int i = 0; i < 10; ++i) {
            check(!memoised_check(p), "a dead object is never reported alive");
        }
        check(g_stats.hits == 0, "and is never turned into a hit");
        check(g_syscalls == 10, "every call re-probes rather than trusting a cached 'dead'");
    }

    // 4. Then it comes back to life, and the memo must recover without any invalidation.
    {
        reset();
        const void* p = (const void*)0x5000;
        (void)memoised_check(p);
        g_syscall_succeeds = false;
        bool saw_dead = false;
        for (int i = 0; i <= kNativeMemoTtlCalls; ++i)
            if (!memoised_check(p)) saw_dead = true;
        check(saw_dead, "the death was observed once the TTL expired");
        g_syscall_succeeds = true;
        check(memoised_check(p), "and the memo recovers when the object is alive again");
    }

    // 5. SEVERAL ALTERNATING POINTERS, which is ChamsModule's item_shader_cache_ pattern.
    //    A one-entry memo would miss every single time here.
    {
        reset();
        std::vector<const void*> ptrs;
        for (int i = 0; i < 8; ++i) ptrs.push_back((const void*)(0x10000 + i * 0x2000));
        for (int pass = 0; pass < 20; ++pass)
            for (auto* p : ptrs) (void)memoised_check(p);
        printf("        8 alternating pointers x 20 passes: %llu syscalls\n", g_syscalls);
        check(g_syscalls < 160 * 8, "8 alternating pointers are NOT thrashing the table");
        check(g_stats.hits > g_stats.misses, "and the majority of calls are hits");
    }

    // 6. More distinct pointers than slots: degrades to today's behaviour, must not be worse.
    {
        reset();
        std::vector<const void*> ptrs;
        for (int i = 0; i < 40; ++i) ptrs.push_back((const void*)(0x200000 + i * 0x2000));
        for (int pass = 0; pass < 5; ++pass)
            for (auto* p : ptrs) (void)memoised_check(p);
        printf("        40 pointers over %zu slots: %llu syscalls for %d calls\n",
            kNativeMemoSlots, g_syscalls, 200);
        check(true, "over-subscribed: degrades toward one syscall per call, which is today's cost");
    }

    // 7. The index is in range for every pointer, including extremes. An unmasked shift here
    //    is an out-of-bounds write, which is exactly the bug the string memo shipped with.
    {
        bool in_range = true;
        for (uintptr_t p = 0; p < 64; ++p)
            if (native_memo_index(p * 0x100000000ull) >= kNativeMemoSlots) in_range = false;
        if (native_memo_index(0xFFFFFFFFFFFFFFFFull) >= kNativeMemoSlots) in_range = false;
        if (native_memo_index(0) >= kNativeMemoSlots) in_range = false;
        check(in_range, "the slot index is in range for 0, huge, and wrapped pointers");
    }

    printf(g_failures ? "  %d FAILURE(S)\n" : "  all assertions passed (%d failures)\n", g_failures);
    return g_failures ? 1 : 0;
}
