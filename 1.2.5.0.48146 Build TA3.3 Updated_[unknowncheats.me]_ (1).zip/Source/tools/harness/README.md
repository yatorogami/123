# tools/harness

Executable coverage that runs anywhere, and lives in the repository.

```sh
tools/harness/run.sh            # exit 0 = pass, 1 = fail   (the 10 portable cases)
tools\harness\run_windows.bat    # exit 0 = pass, 1 = fail   (all 22 cases)
```

`run.sh` needs only a C++23 compiler: no MSVC, no mingw, no project build, no
game. `run_windows.bat` needs an MSVC toolchain and `rc.exe` - no project build,
no game, no deployed DLL - and runs **all twenty-two** cases, the portable ones
included. Neither needs a build of the project, so neither can be invalidated by
a concurrent agent's edit to the DLL.

**Last run 2026-10-14, `run_windows.bat` exit 0, all twenty-two cases:**

| case | over | reports |
|---|---|---|
| `test_config.cpp` | `config/ConfigValue.h` | 53 passed, 0 failed |
| `test_card_fold.cpp` | `gui/menu/card_fold_state.h` | 25/25 passed |
| `test_module_paths.cpp` | `shared/module_paths.h` | 27 passed, 0 failed |
| `test_probe_memo.cpp` | region-memo arithmetic | all assertions passed (0 failures) |
| `test_native_memo.cpp` | native-object memo | all assertions passed (0 failures) |
| `test_range_slot_index.cpp` | optics page-hash slot index | all passed |
| `test_export_lookup.cpp` | `scan::find_export_by_hand` | 43/43 passed |
| `test_meta_key.cpp` | `il2cpp/meta_key.h` | 14 checks, 0 failures |
| `test_debugger_gate.cpp` | `util/crash_probe.h` debugger gate | 47 passed, 0 failed (48 on a classic-delivery machine; the case spawns its own debuggee) |
| `test_print_capture_policy.cpp` | `util/crash_probe.h` print capture policy | 22 passed, 0 failed |
| `test_il2cpp_call_abi.cpp` | `il2cpp/Il2CppObjectInstance.h` | 2 passed, 0 failed |
| `test_lens_size_summary.cpp` | `module/lenssize_stubs.cpp` | all assertions passed |
| `test_quest_objectives_text.cpp` | `module/quest_objective_text.h` | 197 passed, 0 failed |
| `test_text_fold.cpp` | `util/text_fold.h` | 33 assertions, 0 failed |
| `test_loot_categories.cpp` | `module/item_categories.h` (taxonomy half) | 120 assertions, 0 failed |
| `test_wishlist_groups.cpp` | `module/item_categories.h` (wishlist half) | 43 passed, 0 failed |
| `test_column_layout.cpp` | `gui/menu/column_layout.h` | 51 assertions, 0 failed |
| `test_survival_clamp.cpp` | `module/survival_clamp.h` | 0 failures |
| `test_quick_search.cpp` | `gui/menu/quick_search.h` | 24 assertions, 0 failed |
| `test_hotkey_conflicts.cpp` | `gui/menu/hotkey_conflicts.h` | 19 assertions, 0 failed |
| `test_changed_marker_layout.cpp` | `gui/menu/changed_marker_layout.h` | 20 assertions, 0 failed |
| `pe_resource_test.cpp` | `util/pe_resource.h` + real RCDATA | 55/55 assertions |

> **Count the cases the runners execute, not the `.cpp` files in the directory.**
> This table previously read "9", then "eight" twice in the same sentence, and
> omitted `test_loot_categories.cpp` and `test_column_layout.cpp` — both of which
> `run_windows.bat` compiles. It then read "seventeen" while omitting
> `test_text_fold`, `test_wishlist_groups` and `test_survival_clamp`. Three
> different totals for one runner is the failure mode this section exists to
> prevent, and it is why the count is stated once and checked against
> `run_windows.bat` rather than remembered. `WORKFLOW.md` has the same table.

`run.sh` runs `test_config`, `test_card_fold`, `test_loot_categories`,
`test_quest_objectives_text`, `test_text_fold`, `test_wishlist_groups`,
`test_survival_clamp`, `test_quick_search` and `test_hotkey_conflicts`; the
other twelve need `WideCharToMultiByte`, `GetModuleHandleW` or `rc.exe`. The
Python side of the suite is separate and lives in `tools/tests` - see
`WORKFLOW.md`.

**A case that is present but not yet wired in.** `test_card_fold_realfile.cpp`
(untracked as of 2026-10-01, and not a case this README documents) is an
end-to-end check of the card-fold **load** path against the user's real config
file. It is not referenced by `run_windows.bat` or `run.sh`, so it does not run.
It is called out here because a `.cpp` sitting in this directory that no runner
builds is exactly the shape of thing that gets counted in a coverage claim and is
not: the eighteen above are the eighteen the runners execute. Whoever wires it in
should note that it reads the **real** `%APPDATA%` config, so it needs the
sandbox discipline `test_module_paths.cpp` uses rather than the ambient path.

## Why it exists

`WORKFLOW.md` records that this project's *only* executable coverage lived in
`%LOCALAPPDATA%\Temp\opencode\ta_tests` and was destroyed by temp cleanup. The
results stand as evidence — migration 46/46, parser 19/19, `wide_to_utf8` 8/8,
RCDATA 15/15, RCDATA bounds 16/16 — but the ability to re-run any of it did not
survive. The loss cost real re-derivation, and it happened because the coverage
could only be run by one person on one machine, in a temp directory.

This is the part of that coverage that can be rebuilt so it cannot be lost
twice. Of that lost set, the config parser and the RCDATA path are covered again
here; the migration is covered in `tools/tests/test_migrate_legacy.py`, because
`util/data_migration.h` moved to `tools/migrate_legacy.py` and no longer exists.

## The runners

**`run.sh`** - the ten portable cases, needs only a C++23 compiler.

**`run_windows.bat`** - all eighteen cases, needs an MSVC toolchain and `rc.exe`.
Until 2026-10-01 it ran only `pe_resource_test.cpp`, which made
`test_config.cpp` unrunnable on a machine with MSVC but no Linux compiler — that
is, this one — so its 41 assertions could not be re-run here either. It now
builds the portable cases as well, at `/std:c++latest`, so they are compiled at
the standard they are developed against rather than a lower one that happens to
work. `test_quest_objectives_text.cpp` joined that group on 2026-10-02 and went
into `run.sh` in the same change, so a new portable case does not land
Windows-only until someone notices — which is the failure mode the pair
originally had.

**If a case goes missing and the only clue is `The system cannot find the batch
label specified - portable` with exit 1, check `run_windows.bat`'s line
endings.** Measured 2026-10-10: with LF-only endings the file ran 14 of the 15
cases (`native_memo` missing) and exited 1; the same content as CRLF ran 15/15.
The failure is position-sensitive — a 783-byte-shorter revision passed either
way — so a green run at LF is not evidence. `.gitattributes` pins `*.bat` to
CRLF on checkout; keep edits to this file CRLF.

### Coverage: `run.sh --coverage`

```sh
sh tools/harness/run.sh --coverage
```

Clang only, opt-in. Adds `-fprofile-instr-generate -fcoverage-mapping` to every
case, merges the profiles and writes `tools/harness/coverage/report.txt` over the
**first-party files only** — the harness and the shim are excluded, because
coverage of the test is not coverage of the thing under test. With `CXX=g++` the
flag exits **2** and says why: g++ has no coverage *mapping*, and reporting gcno
line counts under the same name would be a different number wearing this one's
label.

Measured 2026-10-12, after `test_wishlist_groups.cpp` was added:

| file | lines | functions |
|---|---|---|
| `config/ConfigValue.cpp` | 22/22 — 100% | 12/12 |
| `config/ConfigValue.h` | 17/17 — 100% | 3/3 |
| `gui/menu/card_fold_state.h` | 31/34 — 91.2% | 5/6 |
| `module/item_categories.h` | 95/104 — **91.4%** | 9/11 |
| `module/quest_objective_text.h` | 113/113 — 100% | 12/12 |
| `util/text_fold.h` | 98/112 — 87.5% | 7/7 |
| **TOTAL** | **376/402 — 93.53%** | 48/51 |

`item_categories.h` was **63.8% / 5-of-11 functions** before that case existed.
The six functions it did not reach were the entire wishlist-classification half —
`loot_class_is_known`, `wishlist_all_mask`, `filter_sets::add`, `filter_sets::in_group`,
`classify_id`, `classify_group` — while `wishlist_allows`, the last step of the same
chain, was tested. See the case's header for why that is the dangerous shape.

**Two llvm-cov traps, both measured here, both of which produce a clean wrong
answer:**

1. **Several binaries need one `-object` each.** Without them `llvm-cov` uses
   *only the first binary's* coverage mapping and silently ignores the rest. The
   first run of this reported a flawless **100%** over **2 of the 6** files.
2. **The first binary must also be positional.** With only `-object` flags,
   llvm-cov treats the trailing source-filter paths as object files and fails
   with *"The file was not recognized as a valid object file"* — which is how the
   flag's first implementation died silently, reporting nothing at all.

`emit_coverage_report` in `run.sh` does both, and **fails closed**: it refuses to
print a report built from zero `.profraw` files. A `17 functions have mismatched
data` warning is expected and benign here — the same header is compiled into six
binaries with different inlining. Per-file figures were verified to agree between
the merged and per-binary reports; the **total** is the number to treat with care.

## The cases

### `test_card_fold.cpp` — 25 assertions over `gui/menu/card_fold_state.h`

The card-fold state the menu writes to the config file: which cards are folded,
and the `CARD:<card id>;true;` records that carry it across restarts. Written
first under `run_windows.bat` and never run through `run.sh` on the machine that
has MSVC but no `bash` or `g++`, so that path is unexecuted.

Like the pe_resource case, this compiles the **real** header. That is the reason
`card_fold_state.h` exists as a separate header at all: `menu.cpp` needs ImGui,
`resources.h` and the DX hook, so a test could otherwise only ever exercise a
*copy* of the format, and a copy is a copy that silently drifts from the code
that writes it. Nothing in `card_fold_state.h` touches ImGui or Win32, so it links
directly. The header is what `ConfigModule` calls and what `menu.cpp` draws from.

Two things in the test file are copies, both noted in place: `utils::split`
(`utils.cpp`'s other function needs `<windows.h>`) and the shape of
`ConfigModule::load_config`'s key/value pairing loop. Neither is what is under
test; they are the loader's surroundings, which the test has to reproduce to reach
the records at all. `getline()` with a delimiter emitting no trailing empty field
is load-bearing — it is what lines the 2-field records up with the 4-field
module records — so the copy says so rather than leaving it to be rediscovered.

What it asserts:

- **Nothing folded writes nothing.** Expanded is the default, so a record per card
  would be a line per card per config carrying no information.
- **A folded card survives save → load**, and a card nobody folded stays open.
- **Only the literal `"true"` means folded.** `1`, `yes` and an empty value all
  leave the card open, and nothing bogus is written back out. "Unrecognised means
  unfolded" is the direction that fails harmlessly: a card drawn open is a card
  whose controls are reachable.
- **A `ConfigValue` record can never be read as a card.** The sharpest case
  available: a favourite key whose value *is* `"true"` — `ConfigModule` writes
  exactly that for a starred control — sitting beside a real record.
- **`load()` replaces, `clear()` resets.** Deliberately unlike `hotkeys::load()`,
  which must not wipe because every binding has a meaningful in-memory default
  and a folded card does not. Loading a config that folds nothing has to open
  everything the previous config folded.
- **Output is sorted**, so two saves of one state are byte-identical and the file
  can be diffed; and a `CARD:` record naming a module that no longer exists is
  preserved verbatim rather than silently dropped.
- **Ids containing spaces round-trip.** Every module card's id is a module name
  and most contain a space, so this is the ordinary case rather than an edge one.
- **A truncated, empty or bare-prefix tail cannot throw** and folds nothing.

Negative control, run by patching the header and restoring it: making `load()`
merge instead of replace **and** making `append_save()` write `"1"` instead of
`"true"` gives **18/25, exit 1**, with 7 named failures — both round-trips, the
load-replaces pair, the sorted-output check, and both spaced ids. Those are
exactly the assertions the two changes should break.

### `test_config.cpp` — 53 assertions over `config/ConfigValue.h`

- **`config_parse::to_int` / `to_float`.** The contract is *report failure,
  never throw*, and the reason is documented in the header: every `set()` is
  called from the loader's apply loop, nothing above it catches, so the
  `std::sto*` family made one bad config field look like "the config did not
  load" while abandoning every value after it. The assertions cover the cases
  `from_chars` was chosen for and `stoi` would have accepted silently: trailing
  junk, leading and trailing space, out-of-range, and an embedded NUL. Each
  also asserts the output is *not* written on failure, so a caller that ignores
  the return value gets its default rather than a stale value.
- **`ConfigValue` flags** round-tripping: disabled, hidden-in-owner-menu,
  favourite, master toggle.
- **Config key structure.** Asserted for structure — the key names the value,
  registering a module changes it, and it is stable across calls — and the
  *format* is characterised rather than asserted:

  ```
  no module  : "lonely##"
  with module: "cb##esp_mod"
  favourite  : "favorite##cb##esp_mod"
  ```

  That is a user-facing file format. A change here is a deliberate act, not a
  refactor, and the harness shows it as a diff rather than failing so nobody
  "fixes" it by accident. It is also the format `AGENTS_TODO.md` §3.7 depends on
  for its `Info##Configs` shared-key claim.

Validated by negative control: reverting `to_int` to the `stoi` behaviour the
header says it avoids **fails 8 named assertions and exits 1**. The parse result
is tri-state (`yes` / `no` / `threw`), so a contract violation is reported as a
failure of the specific input that broke rather than as an uncaught exception.

That distinction is not cosmetic, and it was found the hard way. The first
version of this harness called `to_int` bare, so the `stoi` regression did not
fail 8 assertions — it **crashed** the process with `0xC0000409` before printing
anything at all. A non-zero exit is technically a signal, but a harness that
dies by fastfail names no assertion, so it cannot tell you which of the nine
rejection cases regressed. Any future case added here must go through
`try_parse` / `want_ok` / `want_rejected` for that reason; a bare
`config_parse::to_*` call is the bug this paragraph exists to prevent.

- **The tooltip is a KEY, resolved per frame.** Added after the survival-mode
  tooltips shipped rendering their raw i18n keys. `set_tooltip()` used to call
  `i18n::tr()` itself, which looked obviously right and was not: a module
  constructor runs while `ModuleManager` is still being built, and
  `i18n::init()` does not run until `ConfigModule::init()` inside
  `ModuleManager::init()` — strictly after every constructor has finished. tr()
  therefore answered an EMPTY map, and both types then cached the key forever.
  The assertion that matters is the ordering: set the tooltip with translations
  unloaded, then load, then read. Only a deferred translation can produce the
  translated string on that last read.

  **The stub could not have caught this, and that is the interesting part.** It
  was the identity function, so "the key was passed through and translated
  later" and "tr() was called during construction and returned the key" were the
  *same string* — the one test worth writing compared nothing. `stubs.cpp` now
  carries a `translations_loaded` flag, modelling the real boot order, and wraps
  the key while loaded so a caller can tell a translation from a bare key.

  The tooltip now lives on `ConfigValue` rather than being duplicated per widget,
  and `FloatSliderEditableValue` had the identical latent defect — its
  constructor took a tooltip key and translated it eagerly. It was unreachable
  (no call site passes one), which is exactly why it went unnoticed.

Note that the harness **cannot be sabotaged through `-I`**: `test_config.cpp`
includes `"../../TarkovAddons/config/ConfigValue.h"` by relative path, and a
quoted include searches the including file's own directory first, so the repo
copy always wins. A negative control has to mirror the include closure
(`ConfigValue.{h,cpp}`, `util/i18n.h`, the shim, and this file) into a scratch
tree and compile from there, not merely prepend a directory to the include path.

### `test_module_paths.cpp` - 27 assertions over `shared/module_paths.h`

Added 2026-10-01, on `run_windows.bat`. Windows-only, and it needs nothing but
MSVC: no project build, no game, no deployed DLL.

> **This file was `test_data_paths.cpp` and also covered
> `util/data_migration.h`. That header no longer exists** — it moved to
> `tools/migrate_legacy.py` (see `AGENTS_TODO.md` §5.6) and the single call at
> `dllmain.cpp:202` went with it. The migration's scenarios are now 42 pytest
> cases in `tools/tests/test_migrate_legacy.py`, the case was split to keep the
> `shared/module_paths.h` half, and `win_shim/logger_stub.cpp` was deleted with the
> header it existed to satisfy. The three-way `%APPDATA%` guard described below is
> gone for a reason that is worth stating: `migrate(legacy_root, deploy_root)`
> takes the roots as **arguments**, so there is no ambient environment to redirect
> incorrectly and the hazard does not get guarded, it ceases to exist. That was
> the decisive argument for moving it.

**The blocker was never the platform.** `shared/module_paths.h` needs
`WideCharToMultiByte` and `GetModuleHandleW`, so `run.sh` cannot run it - but it
was sandboxable the whole time. `module_paths::cached_dll_directory()` is an
accessor returning a reference to a function-local static, and
`dll_directory_wide()` prefers it over every `GetModuleHandle*` route. Assigning
to it redirects the entire namespace at a throwaway directory, so **no production
change and no environment variable were needed.** `tools/probe_test/probe_test.cpp`
already uses the sibling entry point `module_paths::init()`.

**It needs no shim and no stub.** The case it lost them with is gone. The reason
the stub had to be a `.cpp` rather than a header is still the sharpest lesson in
this directory and still applies to any future Windows-only case that pulls in a
first-party header with a sibling `logger.h`: the obvious approach — a no-op
`logger.h` in a directory placed first on the include path — **does not work.**
MSVC resolves a *quoted* include against the directory of the file containing the
directive **before** consulting any `-I` path, so a real `logger.h` sitting beside
the header under test always wins and an include shim is unreachable however the
path is ordered. (This is why the project's own `shim/common.h` *does* work:
`TarkovAddons/include/common.h` is not adjacent to the `.cpp` that includes
it.) When a stub
is unavoidable, satisfying the linker with real declarations is strictly better
for drift anyway: if `util/logger.h` changes a signature the stub stops matching
and the build breaks, instead of the stub quietly diverging from the interface it
stands in for.

**It closes `AGENTS_TODO.md` §1.4's unwritable-deployment path**, which that file
called unprovable without "a genuinely read-only install". The fallback is reached
by any `create_directories` failure, and the cheapest reliable one is a regular
*file* named `ta`: `is_directory` is then false and `create_directories` fails with
an error, which is the same branch. Being precise about what that does and does
not prove: it is a different failure mode from a permission denial, and the two are
not the same path through the filesystem.

**What it covers.** `wide_to_utf8` (including the non-ASCII and embedded-NUL cases
the old one-byte overflow lived in), `is_system_directory`,
`data_directory_wide`'s no-`ta/` compatibility fallback, the three `ensure_*`
accessors and `chams_bundle_path`, both name-list predicates, `adopt_file`
including never-overwrite and on-demand directory creation, and `adopt_json_dir`'s
extension filter. The `migrate_legacy_data_once()` end-to-end scenarios and its
idempotence moved to pytest with the code.

**Not covered here, stated plainly:** the i18n translation table (still uncovered
anywhere), and a genuine ACL-denied deployment.

### `test_probe_memo.cpp` - the region-memo arithmetic

`eft_api::is_readable_address_cached` is a correctness mechanism first and a
performance one second: a stale or mis-paired slot could report a range as
"readable" that no syscall ever approved, and that is the one failure it must not
have. This case covers the properties the shipped code relies on, without needing
the project, the game, or a deployed DLL.

**The table logic is duplicated, not included**, because the real function lives
in a header that pulls in the IL2CPP exports, the logger and Tracy. What is under
test is the arithmetic — the page hash, the slot index, the fill/evict accounting.

It asserts, among others: a 65,536-byte sequential walk costs at most one syscall
per page touched *and* at least one per occupied slot, so the memo cannot pass by
doing nothing; a two-probe string read costs **one** `VirtualQuery`, not two; a
refused address is never cached into a slot that would answer later; `clear` makes
the same address cost a syscall again; and 300 distinct regions over 20 passes
cost O(regions) rather than one per pass (thrashing would be ~6,000).

The slot-distribution gate is worth reading before changing the hash:

    consecutive pages    -> 2827/4096 distinct slots (69.0%, ideal random ~36.8%)

The **birthday bound** for 4096 keys into 4096 slots is ~36.8%, so the gate is
`>= 40%`, deliberately just above chance. Asserting 70% demands better than
random, which is not a property a hash has — and asserting it is what made this
confusing during the string-memo work. The measured 69.0% sitting just under 70%
is exactly the trap. Other strides are reported for information only.

### `test_native_memo.cpp` - the 16-slot native-object memo

`unity::is_unity_object_alive` keeps a small pointer-keyed memo with a 64-call
TTL. The test stubs the syscall with a bool, because what is under test is the
TTL, the slot table and the "never cache a dead answer" rule — those are the parts
that can be wrong; `VirtualQuery` itself is the OS's problem.

It asserts: 4,096 calls on one pointer cost 64 syscalls, one per TTL window, not
one per call; every syscall after the first is counted as a **revalidation**;
inside the TTL a dead object still reads alive (that is the window, stated
explicitly rather than left implicit); past the TTL the death is detected; and
**a dead object is never turned into a hit** — it re-probes every time. That last
one is the property that makes the memo safe to have at all.

It also covers the over-subscribed case honestly: 40 pointers over 16 slots costs
198 syscalls for 200 calls, i.e. it degrades toward today's un-memoised cost
rather than thrashing or failing.

### `test_range_slot_index.cpp` - the optics page-hash slot index

`optics::lens::range_readable`'s table cannot be included, because it pulls in the
whole lens pipeline, so this case copies the page-hash and slot-index arithmetic
and asserts the two properties that can actually be wrong:

- **the index stays in range** for 0, a huge address, and a wrapped one. This is
  what catches a missing mask. `>> 32` alone yields 32 bits and writes out of
  bounds against a 4,096-entry array; this was shipped by mistake once and caught
  only because the harness crashed with a `0xC0000005` and no output.
- **consecutive pages do not collapse onto one slot.** `((page * K) >> 52) & 4095`
  hashes consecutive pages to a *single* slot — the product advances by a constant
  per page, so the top 12 bits never move. `>> 20` was load-bearing at the old
  256-slot size, and the fix is a Fibonacci high-bits hash with the mask.

### `test_export_lookup.cpp` - 43 assertions over `scan::find_export_by_hand`

Added 2026-10-02. It exists because `il2cpp_offsets.h` grew a hand-rolled PE
export reader to answer one question a log cannot: when `GetProcAddress()`
returns null for a name the module's export table contains, is the table wrong
or is the API lying? The reader calls no Windows API at all, so it cannot be
intercepted - which is what makes it a diagnostic rather than another thing that
could be lying.

**It compiles the real `scan.h`, not a copy.** The risk is entirely in the
pointer arithmetic and the bounds checks, and a copy of the arithmetic is a copy
that can drift from the arithmetic that ships - the same argument this README
makes for `test_card_fold.cpp`.

What it asserts, all against synthetic PE images built in memory:

- **Ordinal indirection is two levels deep.** `name -> ordinal index -> function
  table`. A parser that reads `AddressOfNames` as if it were `AddressOfFunctions`
  returns the *name RVA* as the address, which looks entirely plausible and is
  wrong. Asserted by requiring two lookups to return **different** RVAs.
- **PE32 and PE32+ put `DataDirectory` 16 bytes apart** (96 vs 112), so the
  branch on the optional-header magic has to be real. A PE32 image is built with
  its export at the +96 offset, which only resolves if the branch is correct.
- **A forwarder is not an address.** It is an RVA pointing back into the export
  directory; returning it as a function pointer is the exact bug worth
  preventing, so it is detected and labelled.
- **Lookup is case-sensitive**, like `GetProcAddress`, and a prefix of a real
  name does not match. A case-insensitive parser resolves names the loader
  would not - the opposite failure, equally wrong.
- **Eleven malformed-image cases must be refused, not read past**: no MZ,
  `e_lfanew` past the end, no PE signature, unknown magic, export RVA outside the
  image, null data directory, an inflated `NumberOfNames`, an out-of-range
  ordinal, an all-zero image, and a zero base/size.

That last group is the one that matters most. The reader's only job is to produce
a verdict on a failure path inside a third-party process; if a corrupt image can
make it fault, it turns a diagnosable "could not resolve symbol" into an access
violation *during diagnosis*, which is strictly worse than not having it.

Five negative controls, all firing: removing the PE32 branch (3 failures),
removing forwarder detection (1), removing the ordinal range check (1), an
off-by-one in `contains()` (1), and removing the export-directory bounds check
(the case dies).

Two things this case caught while being written, both recorded in the file:

- **`far` is a `windows.h` keyword macro.** A local named `far` silently loses its
  identifier and MSVC reports a syntax error three lines later. Same family as
  the `std::min` trap in `WORKFLOW.md`; a new instance of it.
- **The test failed 2/43 on its first run because I forgot the NUL terminator**
  on a synthetic export name. An unterminated name walks into the fill byte and
  reads as "the export is missing" - which is precisely the symptom the test
  exists to distinguish from "the API lied". The test catching its own input is
  the intended behaviour; the file says so in place.

### `test_quest_objectives_text.cpp` - 197 assertions over `module/quest_objective_text.h`

The Quest Completer card's objective checklist. This header exists as its own
file for the same reason `card_fold_state.h` does: the logic worth testing cannot
be reached through a header that opens with the game's object model. It is
header-only, with no IL2CPP, no ImGui and no Win32 in it, so this case needs
neither the shim nor the i18n stub, and it runs in both runners.

What it asserts, and why each is load-bearing:

- **`plan_for()` — the condition-class to verb table.** The ordering is the test.
  `ConditionPlaceBeacon` and `ConditionLeaveItemAtLocation` both derive from
  `ConditionZone`, so a `Zone` test in front of them relabels every beacon and
  item-drop as "Reach an area". Each of those three is asserted separately for
  that reason. Also: every reachable class must return two non-empty strings,
  because `text_of()` concatenates `verb + " " + names` unconditionally on its
  fallback path and a null verb is a `std::string` from a null pointer — and a
  null *class name* has to be answered too, since `strstr(nullptr, …)` is
  undefined and that is also the fallback path.
- **`merge_duplicates()` — the sum.** Three conditions that mean the same thing
  are one row with the counts added, because that is the feature. `done` is the
  AND, not the OR: OR-ing reports a quest complete while one of its three
  objectives is outstanding. Non-adjacent duplicates merge, distinct labels never
  merge, and the first spelling is the one kept.
- **`order_by_outstanding()` — outstanding first, and stable.** Within a group the
  order is the quest's own, which is the journal's order. A non-stable sort would
  shuffle the checklist every scan.
- **`join_labels()` — the cap.** Exactly at the cap adds no `+0`; the overflow
  count is the real remainder, not a fixed `+1`.
- **`truncate_text()` — the UTF-8 boundary**, at 2-, 3- and 4-byte codepoints
  against a cap that is a multiple of none of them, plus a sequence *starting* at
  the cap index, which the walk has to move back rather than leave a dangling
  lead byte for ImGui to render as a replacement character.
- **`fold_ascii()` — ASCII only, and that is a measured limit.** See below.

**`same_label()` folds A-Z and nothing else, and the test asserts the limit
rather than a hope.** `std::tolower` is the C library's and nothing in this
project calls `setlocale`, so it is in the `C` locale: it folds A-Z and returns
every other byte unchanged. A Russian label is UTF-8, so its capital and
lower-case letters are *different bytes* — "Тест" is `D0 A2 D0 B5 D1 81 D1 82`
and "тест" is `D0 B2 D0 B5 D1 81 D1 82`. Measured: comparing that pair through
`std::tolower` returns **not equal**. The header documents this and the test holds
it there, because the alternative is a reader re-deriving it. Real Unicode folding
needs the game's casing tables or a Unicode data table, which is not worth
carrying here — and the requirement is narrower than it looks: two conditions of
the same quest render through the same locale lookup, so their descriptions are
byte-identical and plain equality merges them. The case fold is a bonus.

`fold_ascii()` is also pinned at the range boundary. `'@'` is `0x40`, one below
`'A'`, so it must NOT fold; the usual `(c | 0x20)` one-liner maps it to `` '`' ``
and would merge two different objectives into one row. That is a small but real
false merge, so it has its own assertion.

**What this case does not cover**, stated because the file was written against a
draft that claimed more: the other half of the summary. `quest_objectives.h` reads
Conditions off a live quest — `for_each_condition`, `is_done`, `current_value`,
`condition_value`, `is_necessary`, `progress_checkers`, `read_targets`,
`target_label` — and none of it is reachable here, because it needs the game. In
particular `quest_esp::write_condition_description_seh`, the SEH-guarded
description read that `text_of()` normally returns, is **not** covered here. The
first version of this file stubbed that out and asserted against the stubs; it was
rewritten to include only `quest_objective_text.h` instead, which is what makes
the claim true rather than merely convenient.

### `test_quick_search.cpp` - 24 assertions over `gui/menu/quick_search.h`

The fuzzy ranking behind the menu's quick-jump palette (Ctrl+K). The header is
its own file for the same reason `card_fold_state.h` is: menu.cpp needs ImGui,
resources.h and the DX hook, so a test could only ever exercise a copy of the
ranking, and a copy is a copy that drifts. Nothing here touches ImGui, IL2CPP
or Win32, so this case runs in both runners.

What it asserts, and why each matters:

- **Ordering is the feature.** Substring beats scattered subsequence, prefix
  beats buried, and a card's own entry outranks its values when the query names
  the card. A matcher that finds the right row fourth is a palette nobody uses
  twice, and no "it matched something" assertion would catch that.
- **Two fixtures isolate the two bonuses**, because the obvious ones are
  symmetric and prove nothing: `"abxc"` vs `"axbc"` has equal gaps and word
  starts, so only the run bonus can separate them; `"ab c"` vs `"abxc"` is the
  same comparison for the word-start bonus. The first version of both fixtures
  was symmetric and GREEN under its own negative control, which is the whole
  reason the pairs are spelled with those letters.
- **One rule has no control, and the file says so rather than hiding it:** the
  per-match run bonus trades against the gap penalty 10-to-1, so with the
  matched letters and the skip count held equal the two terms cancel and no
  ordering can observe one alone. `negctl.py` pins the combined rule with the
  GAP penalty instead.
- **Cyrillic folds.** `std::tolower` is ASCII-only in this project's C locale
  (nothing calls setlocale) and the labels are localized, so a Russian player's
  query against a capitalised Russian label would match nothing. This is the
  same measured defect `util/text_fold.h` was written for, asserted here so the
  ranking cannot quietly lose it.

Validated by negative control, `negctl.py`: six mutations of the header
(substring branch flattened, gap penalty removed, boundary bonus removed, label
bonus removed, terms made optional, ranking reversed) each fail it by name.

### `test_hotkey_conflicts.cpp` - 19 assertions over `gui/hotkey_conflicts.h`

Which keybinds share a key, and which one sits on the menu toggle. The registry
(`hotkeys::all()`) is one flat list nothing compares, so two features can land
on one key and the panel shows two identical buttons with no hint that pressing
the key fires both. Pure bookkeeping over `(key, label)` rows, no ImGui and no
Win32, which is also why the menu-toggle key is a literal here and a
`static_assert` in `hotkeys.h`.

The load-bearing rule is that **key 0 (unbound) never collides** -- two unbound
rows are two rows that do nothing, and treating them as a conflict would make
the default configuration open with a page of collisions and teach the user to
ignore the report. `negctl.py` pins it, along with the reserved-key rule, the
key-ascending sort, and the same-key merge.

### `test_changed_marker_layout.cpp` - 20 assertions over `gui/menu/changed_marker_layout.h`

Where the changed-from-default gutter dot goes. Arithmetic on four floats, no
ImGui and no Win32, because its call site in `menu.cpp` cannot be linked by
anything — the same split that produced `card_fold_state.h`, `column_layout.h`,
`quick_search.h` and `hotkey_conflicts.h`.

The dot has been in the wrong place twice, both times because each fix picked a
function of the row's **height** without asking what that height means. In this
menu the height is *content*: a slider row is two lines, and `ItemSearchValue`'s
row grows with the number of search results — so a height-derived dot slides
down while the user is reading the label. The header centres it on the **label
line** instead (`ImGui::GetFrameHeight()`, which is exactly a label's line box
because every one of them is drawn with `AlignTextToFramePadding`).

What the case pins:

- **The dot does not depend on the row's height.** Same label line, rows of 1
  line / 2 lines / 200px, identical `dot_y` — with the rejected row-centred
  formula's distance stated as a number (≈90px, most of a result list).
- **A one-line row is unchanged.** For `row_h == label_line_h` the two
  expressions are identical, so every checkbox and textbox row draws its dot
  where it always did.
- **On the line, and not flush to the row's top edge.** The second rejected
  position is only rejected if something pins it.
- **The hit area never exceeds the label line**, so a 200px search row does not
  turn the gutter into a 200px invisible button whose tooltip appears beside an
  empty results list.
- **Degenerate input stays pressable**: a row that drew nothing (`row_h == 0`)
  and a cap below the line both still leave a positive-height button.

`negctl.py` pins all three positions the header rejects — row centre (the version
that shipped), the over-long-label-line clamp, and the unbounded hit area — each
failing the case by name.

### `negctl.py` - the negative-control runner for the three cases above

Patches one guarded rule at a time in the real header, rebuilds and runs the
case, and requires the case to FAIL BY NAME. Thirteen controls, all firing; a GREEN
control is reported as proving nothing and the script exits 1, because this
project has shipped three separate checkers that passed while comparing
nothing. The file records the one mutation that was rewritten mid-run: deleting
a statement inside an `if` body silently moves the `if` onto the next line, so
the first label-bonus control tested something else entirely -- which is also
why every mutation now neutralises the line (`+= 0`) instead of removing it.
Run it from `tools/harness` with the MSVC toolchain on PATH.

### `pe_resource_test.cpp` - 55 assertions over `util/pe_resource.h`

The RCDATA reader that owns the menu background, all 19 locales and all 22 minimap
assets. It compiles the **real** header into the test executable and compiles real
`RCDATA` into it with `rc.exe`, so the assertions exercise the same call shape
the mod uses — a function handing its own address to the reader — against an
image the loader has genuinely registered.

This file was previously listed below under "no coverage", on the grounds that
it needs Windows. That was an excuse, not a fact: it needs a Windows *host*,
which this is. Coverage was added on 2026-09-30 after the 22/22 payload failure
described in `CHANGELOG.md` §5, and it exists mostly because that failure was so
hard to diagnose from logs alone.

What it asserts:

- **Payloads round-trip by content**, through both address shapes the mod uses —
  a `static` function in a `.cpp` and an `inline` one in a header. Content, not
  "some bytes came back": the regression this guards returned nothing at all, and
  the on-disk fallback made every feature looked fine.
- **`image_base_from()` resolves the image** from a code address and a data one.
- **`probe_readable()` is correct without `VirtualQuery`**, on committed,
  reserved-only, `PAGE_NOACCESS` and released memory.
- **The backward scan's containment guard.** Planted adjacent PE headers; a scan
  that stopped at the nearest header would walk a neighbouring `.rsrc`, so the
  assertion is that it returns *no base* when nothing contains the address.
- **Base recovery with both API sources dead.** A split image — header page and
  body page as separate adjacent allocations — is in no registered module, so
  `GetModuleHandleExW(FROM_ADDRESS)` fails and `VirtualQuery().AllocationBase`
  is not a PE header. Only the backward scan can answer.
- **The init-time captured base**, which is what actually fixed the bug. The
  decisive block captures a base, makes the header page `PAGE_NOACCESS` and
  blanks the body so all three query sources fail exactly as they did in the
  game, and asserts the captured base still answers.
- **`last_failure()` is per-thread**, with forced ordering so it cannot pass by
  accident.

### `test_quest_objectives_text.cpp` was validated by making it fail

This case is small and has no guarded-block table, so the record is which of its
assertions changed the code rather than only the comment.

**One assertion found a real defect.** `fold_ascii` was originally
`std::tolower`, the comment claimed case-insensitivity, and the code read
correctly. It is **not** case-insensitive for any non-ASCII label: the CRT is in
the `C` locale because nothing calls `setlocale`, and "Тест" and "тест" are
different UTF-8 bytes. An assertion that compared them through `same_label`
failed, which is the only reason the header now says what it does. `std::tolower`
looking obviously correct and being wrong for every label outside ASCII is not
something review catches and an executable assertion does, so the Cyrillic pair is
now a permanent assertion rather than a comment.

**One assertion was itself wrong, and the fix was to the test.** The two-pass
merge-then-order case asserted that `Eliminate Scavs` sorted ahead of the merged
`Find Intel` row. That is only true if `merge_duplicates` ORs its `done` flags,
and it ANDs them — correctly, since OR-ing reports a quest complete while one of
its objectives is outstanding. The merge already has a dedicated AND assertion, so
this case was asserting the merge behaviour a second time and wrongly. It now
asserts what is actually true: both rows end up outstanding, so the sort moves
nothing and the declaration order stands.

**One assertion was too vague to be about anything.** The first version of the
UTF-8 truncation test checked only that the string got shorter, which a naive
truncate passes. It now checks that the result is still whole codepoints at 2-, 3-
and 4-byte widths, and separately that a sequence *starting* at the cap index is
dropped whole rather than leaving a dangling lead byte.

### `pe_resource_test.cpp` blocks are validated by negative control

Deliberately reverting the guarded behaviour must make the harness fail. All
seven do, verified by patching `pe_resource.h`, running, and restoring:

| Reverted | Result |
| --- | --- |
| captured base dropped from `image_base_from()` | 54/55, exit 1 |
| cached base served without a containment test | 53/55, exit 1 |
| capture stores an unvalidated base | 51/55, exit 1 |
| containment guard removed | 41/43\*, exit 1 |
| third source (`scan_back_for_image_base`) removed | 42/43\*, exit 1 |
| `is_readable()` back to `VirtualQuery`-only | 41/43\*, exit 1 |
| `last_failure()` shared, not `thread_local` | 42/43\*, exit 1 |

\* counted against the 43-assertion file as it stood before the captured-base
block was added.

The first row matters most: dropping the cache from `image_base_from()`
reproduces the original bug and fails the harness.

Two of those controls caught tests that were passing for the wrong reason, and
the test file records both at the point they happened: the thread test read its
reason before the worker thread had been scheduled, and the "spans two regions"
assertion used two pages with the same protection, which `VirtualQuery` merges
into a single region, making the assertion vacuous. Both now have forcing
conditions. A test that cannot fail is worse than no test.

## What is not covered, and why

**An intercepted `VirtualQuery`.** It is an imported function, so interposing on
it from a test would mean redefining a `dllimport`, which is not a thing a test
may do. The specific claim "a blinded `VirtualQuery` cannot take the reader
down" is therefore *not* asserted directly. It is covered in two honest halves —
`probe_readable()` is correct on every memory state, and base recovery works with
both API sources failed — and `is_readable()`'s delegation to `probe_readable()`
is asserted through a range spanning two adjacent committed regions, which is
what the delegation makes readable. The composition itself is argued from the
source; it is not asserted end to end.

**The real DLL.** These tests compile the header against a purpose-built image.
They do not run against a deployed `TarkovAddons.dll`, so they would not catch a
packaging regression — a missing `assets/menu_background.rc` entry, say. That
check belongs to whatever validates the build output, not here. That is why the
compatibility-profile path bug (`AGENTS_TODO.md` §5.8) shipped: nothing in *this*
directory inspects the deployment layout. The replacement is a text test in
`tools/tests/test_profile_path.py` — it cannot run the loader either, but it can
assert that the reader, the build and `deploy.py` still name the same directory.

**The translation table is not covered.** `ConfigValue::get_imgui_title()` and
`ConfigValue::get_tooltip()` call `i18n::tr`, which is defined in the
Windows-only `i18n.cpp`, so `stubs.cpp` supplies it — no longer as the identity
function, but as a state-dependent wrapper with a `translations_loaded` flag.
That change is what makes the tooltip's deferred resolution testable at all; see
the `test_config.cpp` entry above. What is tested is that the key reaches the
translation layer with the right name, and at the right TIME. The table itself
has no coverage, here or anywhere.

**`il2utils.h`.** It includes `safetyhook.hpp` and reaches `Config.h` and
`globals.h` through `il2cpp_offsets.h`, whose offsets are mutable `inline PVOID`s`.
A stub layer is possible — point them at test functions — but that is a project
in itself, and a partial stub would be the green stub `AGENTS_TODO.md` warns
against elsewhere. The tri-state `get_static_field` and the `resolve_field` memo
are verified by build and by review of the call sites, not by execution.

**The quest objective summary's other half.** `test_quest_objectives_text.cpp`
covers the text shaping in `quest_objective_text.h` and nothing else. The
functions that read a quest's Conditions — the `get_Conditions` walk, the
`IsConditionDone` call, the progress checker's `CurrentValue`, the
`FormattedDescription` read through `quest_esp`'s SEH wrapper, and the target
field walk — all take an `Il2CppObject*` and need the game. They are the larger
half by call count and are covered by no executable assertion anywhere. What the
harness does give is that the *decision* in each is small and named, rather than
folded into the row that draws it.

**The per-frame module paths.** No harness reaches `EspModule`/`ChamsModule`,
by design: they are only meaningful inside the game process. Tracy is the
instrument for those, and `tools/tracy/README.md` is where the rules for reading
a capture live — including the three attribution traps, all three of which have
now fired on a real capture.

## shim/

`shim/common.h` is a portable stand-in for `TarkovAddons/include/common.h`
(was `pch.h`), which opens with
`<windows.h>`, `<psapi.h>`, `<shlobj.h>` and `<nlohmann/json.hpp>`. It is first
on the include path so the one line `#include "common.h"` in `ConfigValue.cpp`
resolves to something compilable off-Windows. Same idea as
`tools/verify/msvc-shim`, different purpose: that one makes MSVC-only source
*parse* on Linux, this one makes Windows-only source *run* on Linux.

It was renamed alongside the real header when the project moved to CMake
(`e605d6395`). Not renaming it left the `config` harness case unable to compile
at all — `C1083: cannot open include file: 'common.h'` — while the runner still
printed `BUILD FAILED` and exited 0 in the batch path, so the breakage was easy
to miss.

Cases that compile *real* project sources needing `<windows.h>` must not use
`:portable` at all, or `shim/` wins and `common.h` resolves to the stand-in
with no `PVOID` in it. `il2cpp_call_abi` uses the `:native` variant for that
reason.

`pe_resource_test.cpp` does not use the shim. It needs `<windows.h>` for real,
not as a stand-in, and it gets it by way of the header under test.

It is a harness fixture. It never ships into the DLL, and it is not a suggestion
that the project PCH should be slimmed — that is a build-time question with a
measured answer, not a test fixture.
