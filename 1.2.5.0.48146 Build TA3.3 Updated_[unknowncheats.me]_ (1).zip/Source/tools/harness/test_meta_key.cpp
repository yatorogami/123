// Content-based, allocation-free memo keys (il2cpp/meta_key.h).
//
// The point of this file is ONE property: two DIFFERENT string objects with the
// same CONTENT must produce the same key, and one with different content must
// not. That is what makes it safe for a call site to pass `temp.c_str()` --
// PlayerModule.cpp:845 does exactly that -- and it is the property a
// pointer-keyed memo would fail.
//
// The negative control at the bottom compiles the pointer-keyed variant that
// was considered and rejected, and asserts it does NOT have the property. A
// test that cannot fail is worse than no test, and this one is the check that
// the obvious optimisation stays rejected for a reason.

#include "../../TarkovAddons/il2cpp/meta_key.h"

#include <cstdio>
#include <cstring>
#include <string>
#include <unordered_map>
#include <vector>

using il2utils::detail::MetaKey;
using il2utils::detail::MetaKeyHash;

namespace {

int g_failures = 0;

void check(bool cond, const char *what) {
    if (!cond) {
        std::printf("  [FAIL] %s\n", what);
        ++g_failures;
    } else {
        std::printf("  [PASS] %s\n", what);
    }
}

// Same content, different buffers -- the case a pointer key gets wrong.
MetaKey key_for(const char *clazz_tag, int argc, const char *name) {
    MetaKey k;
    k.assign(clazz_tag, argc, name);
    return k;
}

} // namespace

int main() {
    std::printf("meta_key: content-based identity\n");

    // Two distinct std::strings, identical content. If the key captured the
    // POINTER these would differ.
    const std::string a = std::string("LIGHT_KEEPER_TRADER") + "_ID";
    const std::string b = std::string("LIGHT_KEEPER_TRADER") + "_ID";
    check(a.data() != b.data(), "the two test strings really are at different addresses");
    check(key_for("K", 0, a.c_str()) == key_for("K", 0, b.c_str()),
          "equal content from different buffers yields an equal key");

    // The PlayerModule.cpp:833 shape, at the length that defeats SSO.
    std::vector<std::string> traders = {
        "LIGHT_KEEPER_TRADER_ID", "RAGMAN_TRADER_ID", "ARENA_MANAGER_TRADER_ID",
        "PEACEKEEPER_ID",         "SKIER_ID",         "PRAPOR_TRADER_ID"};
    MetaKey first = key_for("T", 0, traders[0].c_str());
    bool all_differ = true;
    for (std::size_t i = 1; i < traders.size(); ++i)
        if (first == key_for("T", 0, traders[i].c_str()))
            all_differ = false;
    check(all_differ, "different traders yield different keys at SSO-defeating lengths");

    // Distinctness of the other two components.
    check(!(key_for("K", 0, "get_position") == key_for("K", 1, "get_position")),
          "arg_count participates in identity (overloads must not collide)");
    check(!(key_for("K", 0, "get_position") == key_for("J", 0, "get_position")),
          "the class pointer participates in identity");
    check(!(key_for("K", 0, "get_position") == key_for("K", 0, "get_rotation")),
          "different names on one class do not collide");

    // Fail-open on an overlong name, and specifically NOT truncation.
    char toolong[MetaKey::kInlineName + 40];
    std::memset(toolong, 'x', sizeof(toolong) - 1);
    toolong[sizeof(toolong) - 1] = '\0';
    check(!key_for("K", 0, toolong).cacheable,
          "a name past the inline buffer is marked not cacheable");
    std::string long_a = std::string(MetaKey::kInlineName + 40, 'a');
    std::string long_b = std::string(MetaKey::kInlineName + 40, 'b');
    check(!key_for("K", 0, long_a.c_str()).cacheable && !key_for("K", 0, long_b.c_str()).cacheable,
          "two different overlong names are both refused rather than truncated onto one entry");

    // Empty and null names.
    check(!key_for("K", 0, nullptr).cacheable, "a null name is not cacheable");
    check(key_for("K", 0, "").cacheable && key_for("K", 0, "") == key_for("K", 0, ""),
          "the empty name is a valid, stable key");

    // Usable as a real map key, which is what it has to be.
    std::unordered_map<MetaKey, int, MetaKeyHash> m;
    m[key_for("K", 0, "alpha")] = 1;
    m[key_for("K", 0, "beta")] = 2;
    const std::string alpha_copy = "alpha";
    check(m.find(key_for("K", 0, alpha_copy.c_str())) != m.end(),
          "a map lookup by an equal-content key hits the stored entry");

    // ---------------------------------------------------------------------
    // NEGATIVE CONTROL.
    //
    // The rejected alternative: key on the name POINTER. It is what makes the
    // memo allocation-free with no string handling at all, and it is wrong for
    // exactly the reason above -- two same-length strings from the same heap
    // bucket can share an address.
    // ---------------------------------------------------------------------
    struct PointerKey {
        const void *clazz;
        const char *name;
        int argc;
        bool operator==(const PointerKey &o) const {
            return clazz == o.clazz && name == o.name && argc == o.argc;
        }
    };
    struct PointerKeyHash {
        std::size_t operator()(const PointerKey &k) const {
            return std::hash<const void *>()(k.name) ^ std::hash<const void *>()(k.clazz);
        }
    };

    std::printf("meta_key: negative control (pointer-keyed must FAIL)\n");
    std::unordered_map<PointerKey, int, PointerKeyHash> pm;
    PointerKey pk1{"T", traders[0].c_str(), 0};
    PointerKey pk2{"T", traders[1].c_str(), 0};
    pm[pk1] = 100;
    const bool pointer_key_distinguishes = pm.find(pk2) == pm.end();
    check(pointer_key_distinguishes,
          "pointer key happens to differ here -- so the control is INCONCLUSIVE for this input");

    // The case that is NOT inconclusive, and does not depend on the allocator
    // cooperating. A pointer key stores the address and nothing else, so it
    // cannot tell that the bytes behind that address changed. Reproduce the
    // ABA directly: one buffer, filled with one name, looked up and cached,
    // then OVERWRITTEN with a different name and looked up again. That is
    // exactly what happens when a same-length temporary is freed and the next
    // one lands in the same bucket -- PlayerModule.cpp:833 builds one of those
    // per trader.
    char buf[64];
    std::memset(buf, 'a', sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = '\0';
    PointerKey p_a{"T", buf, 0};
    pm.clear();
    pm[p_a] = 100; // "aaaa..._ID" cached
    std::memset(buf, 'b', sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = '\0';
    const bool pointer_key_wrong = (pm.find(p_a) != pm.end());
    check(pointer_key_wrong,
          "NEGATIVE CONTROL FIRED: pointer key returns the entry for different content");

    // And the content key is right on the identical input.
    MetaKey before = key_for("T", 0, buf);
    std::memset(buf, 'c', sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = '\0';
    check(!(before == key_for("T", 0, buf)),
          "content key separates them on the identical input");

    std::printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "OK", g_failures);
    return g_failures ? 1 : 0;
}