// Exercises scan::find_export_by_hand -- the self-contained PE export reader.
//
// WHY THIS CASE EXISTS. Added 2026-10-02 because il2cpp_offsets.h grew a
// hand-rolled export lookup to answer one question: when GetProcAddress()
// returns null for a name the module's export table contains, is the table
// wrong or is the API lying? The parser runs on the *failure* path, inside a
// third-party process, and a parser that faults there would convert a
// diagnosable startup failure into a crash during diagnosis.
//
// That is precisely the shape of thing this project has been bitten by, in both
// directions: tools that fail silently (tools/verify/README.md records three)
// and tools that crash instead of reporting (the out-of-bounds slot index that
// was shipped by mistake and caught only because the harness died with no
// output). So the parser is tested before anyone relies on it.
//
// This case compiles the REAL header, not a copy. The whole risk is in the
// pointer arithmetic and the bounds checks, and a copy of the arithmetic is a
// copy that can drift from the arithmetic that ships -- the same argument
// tools/harness/README.md makes for test_card_fold.cpp.
//
// Nothing here needs the project, the game, or a deployed DLL: just MSVC.

#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "../../TarkovAddons/util/scan.h"

namespace {

int g_pass = 0;
int g_fail = 0;

void check(bool ok, const std::string& what)
{
    if (ok) { ++g_pass; std::printf("  ok    %s\n", what.c_str()); }
    else { ++g_fail; std::printf("  FAIL  %s\n", what.c_str()); }
}

void section(const char* name) { std::printf("\n%s\n", name); }

// ---------------------------------------------------------------------------
//  A synthetic but structurally valid PE32+ image with an export directory.
//
//  Real headers rather than a captured dump, because the properties under test
//  are the ones a hand parser gets wrong: the DataDirectory offset differs
//  between PE32 and PE32+, the ordinal indirection is two levels deep, and a
//  forwarder is an RVA that points back INTO the export directory rather than
//  at code.
// ---------------------------------------------------------------------------

struct FakePe {
    std::vector<unsigned char> bytes;

    static constexpr unsigned kImageSize = 0x4000;
    static constexpr unsigned kSectionCount = 1;
    static constexpr unsigned kTextRva = 0x1000;
    static constexpr unsigned kTextSize = 0x2000;   // covers through 0x3000
    static constexpr unsigned kExportRva = 0x2000;
    static constexpr unsigned kExportSize = 0x400;

    // Export table layout, as RVAs from the image base.
    static constexpr unsigned kFuncTableRva  = 0x2100;
    static constexpr unsigned kNameTableRva  = 0x2140;
    static constexpr unsigned kOrdTableRva   = 0x2180;
    static constexpr unsigned kNameStringRva = 0x2200;

    // Three exports, ordinals 0..2. Ordinal 1 is a forwarder.
    static constexpr unsigned kExportCount = 3;

    static const char* kNames[kExportCount];
    static constexpr unsigned kFuncRvas[kExportCount] = { 0x1500, 0x2050, 0x1600 };

    FakePe() : bytes(kImageSize, 0xCC) { build(); }

    void put(unsigned offset, const void* src, unsigned len)
    {
        if (offset + len <= bytes.size())
            std::memcpy(bytes.data() + offset, src, len);
    }

    void put32(unsigned offset, unsigned v)
    {
        const unsigned char b[4] = {
            static_cast<unsigned char>(v & 0xFF),
            static_cast<unsigned char>((v >> 8) & 0xFF),
            static_cast<unsigned char>((v >> 16) & 0xFF),
            static_cast<unsigned char>((v >> 24) & 0xFF) };
        put(offset, b, 4);
    }

    void put16(unsigned offset, unsigned short v)
    {
        const unsigned char b[2] = {
            static_cast<unsigned char>(v & 0xFF),
            static_cast<unsigned char>((v >> 8) & 0xFF) };
        put(offset, b, 2);
    }

    void build()
    {
        // --- DOS header ---
        put16(0x00, 0x5A4D);            // e_magic 'MZ'
        put32(0x3C, 0x80);              // e_lfanew -> NT headers at 0x80

        // --- NT headers at 0x80 ---
        put32(0x80, 0x00004550);        // 'PE\0\0'
        // FILE_HEADER at 0x84: Machine, NumberOfSections, ...
        put16(0x84, 0x8664);            // Machine = AMD64
        put16(0x86, static_cast<unsigned>(kSectionCount));
        put16(0x94, static_cast<unsigned>(sizeof(void*) * 8)); // SizeOfOptionalHeader

        // --- OPTIONAL_HEADER at 0x98, PE32+ ---
        // DataDirectory starts at optional_header + 112 for PE32+ and + 96 for
        // PE32. Getting that backwards is the classic way a hand parser reads
        // something that looks plausible, so the case asserts the PE32+ offset
        // is the one used.
        const unsigned opt = 0x98;
        put16(opt + 0, 0x020B);         // Magic = PE32+
        // DataDirectory[0] at opt + 112
        put32(opt + 112, kExportRva);
        put32(opt + 116, kExportSize);

        // --- section table, immediately after the optional header ---
        const unsigned sec = opt + sizeof(void*) * 8;
        put(sec + 0, ".text", 5);       // Name
        put32(sec + 8, kTextSize);      // VirtualSize
        put32(sec + 12, kTextRva);      // VirtualAddress
        put32(sec + 16, kTextSize);     // SizeOfRawData
        put32(sec + 20, 0);             // PointerToRawData (unused: in-memory view)

        // --- IMAGE_EXPORT_DIRECTORY at kExportRva ---
        const unsigned e = kExportRva;
        put32(e + 12, kNameStringRva - 0x300);  // Name (a string inside the dir; unused)
        put32(e + 16, 1);                        // Base
        put32(e + 20, kExportCount);             // NumberOfFunctions
        put32(e + 24, kExportCount);             // NumberOfNames
        put32(e + 28, kFuncTableRva);            // AddressOfFunctions
        put32(e + 32, kNameTableRva);            // AddressOfNames
        put32(e + 36, kOrdTableRva);             // AddressOfNameOrdinals

        for (unsigned i = 0; i < kExportCount; ++i)
        {
            put32(kFuncTableRva + i * 4, kFuncRvas[i]);
            put32(kNameTableRva + i * 4, kNameStringRva + i * 0x40);
            put16(kOrdTableRva + i * 2, i);      // ordinal == index
            put(kNameStringRva + i * 0x40, kNames[i],
                static_cast<unsigned>(std::strlen(kNames[i])) + 1);
        }
    }

    scan::PeImageView view() const
    {
        // The parser reads the image in place, exactly as it will read a mapped
        // DLL: base + RVA, no file mapping involved. Copying into an aligned
        // buffer is enough, and it keeps the case free of any real module.
        return scan::PeImageView{ reinterpret_cast<UINT64>(bytes.data()), bytes.size() };
    }
};

const char* FakePe::kNames[FakePe::kExportCount] = {
    "il2cpp_string_new",
    "il2cpp_forwarded_thing",
    "il2cpp_runtime_class_init",
};

// A copy of one image, for the mutation cases.
std::vector<unsigned char> g_copy;

scan::PeImageView live_view()
{
    return scan::PeImageView{ reinterpret_cast<UINT64>(g_copy.data()), g_copy.size() };
}

void test_happy_path()
{
    section("1. a well-formed image: every export is found, in order");

    FakePe pe;
    g_copy = pe.bytes;
    const auto v = live_view();

    const auto a = scan::find_export_by_hand(v, "il2cpp_string_new");
    check(a.parsed, "parsed the export directory");
    check(a.found, "il2cpp_string_new is found");
    check(a.ordinal == 0, "il2cpp_string_new maps to ordinal 0");
    check(a.rva == FakePe::kFuncRvas[0], "il2cpp_string_new resolves to the right RVA");
    check(a.address == v.base + FakePe::kFuncRvas[0], "address is base + rva");
    check(!a.forwarded, "a normal export is not reported as a forwarder");
    check(a.name_count == 3 && a.function_count == 3, "reports the table census");

    // Ordinal indirection is two levels: name -> ordinal index -> function
    // table. A parser that reads AddressOfNames as if it were AddressOfFunctions
    // finds the *name RVA* and reports it as the address, which looks plausible
    // and is wrong. This asserts the two are genuinely different numbers.
    const auto b = scan::find_export_by_hand(v, "il2cpp_runtime_class_init");
    check(b.found && b.ordinal == 2, "il2cpp_runtime_class_init maps to ordinal 2");
    check(b.rva == FakePe::kFuncRvas[2], "il2cpp_runtime_class_init resolves to the right RVA");
    check(b.rva != a.rva, "the two lookups are not returning the same address");
}

void test_forwarder()
{
    section("2. a forwarder is detected, not returned as an address");

    FakePe pe;
    g_copy = pe.bytes;
    const auto v = live_view();

    // kFuncRvas[1] = 0x2050, which is inside [kExportRva, kExportRva+kExportSize)
    // = [0x2000, 0x2400). So ordinal 1 is a forwarder by the PE definition.
    const auto f = scan::find_export_by_hand(v, "il2cpp_forwarded_thing");
    check(f.found, "the forwarder entry is still found");
    check(f.forwarded, "an RVA pointing back into the export dir is flagged FORWARDED");
    check(f.rva == 0x2050, "the forwarder keeps its RVA rather than inventing an address");
}

void test_absent_and_case_sensitivity()
{
    section("3. absent names, and case sensitivity");

    FakePe pe;
    g_copy = pe.bytes;
    const auto v = live_view();

    const auto miss = scan::find_export_by_hand(v, "il2cpp_not_a_real_symbol");
    check(miss.parsed, "the directory still parses when nothing matches");
    check(!miss.found, "an unknown name is not found");
    check(!miss.forwarded, "an unknown name is not 'forwarded'");

    // GetProcAddress is case-SENSITIVE. If this parser were case-insensitive it
    // would resolve names the loader would not, which is the opposite failure
    // and just as wrong.
    const auto wrong_case = scan::find_export_by_hand(v, "IL2CPP_STRING_NEW");
    check(!wrong_case.found, "lookup is case-SENSITIVE, like GetProcAddress");

    const auto prefix = scan::find_export_by_hand(v, "il2cpp_string");
    check(!prefix.found, "a prefix of a real name does not match");

    const auto empty = scan::find_export_by_hand(v, "");
    check(empty.parsed && !empty.found, "an empty name parses but matches nothing");

    const auto nul = scan::find_export_by_hand(v, nullptr);
    check(nul.parsed && !nul.found, "a null name parses but matches nothing");
}

void test_malformed_images_do_not_fault()
{
    section("4. a malformed image is refused, not crashed on");

    // This is the case that matters most. The parser's only job on the failure
    // path is to produce a verdict; if a corrupt image can make it fault, it
    // turns a diagnosable "could not resolve symbol" into an access violation
    // during diagnosis, which is strictly worse than not having it.

    {   // no MZ
        FakePe pe; g_copy = pe.bytes;
        g_copy[0] = 0x00; g_copy[1] = 0x00;
        const auto r = scan::find_export_by_hand(live_view(), "il2cpp_string_new");
        check(!r.parsed && r.failure, "a missing MZ signature is reported, not read past");
    }
    {   // e_lfanew pointing far outside the image
        FakePe pe; g_copy = pe.bytes;
        const unsigned char huge[4] = { 0xFF, 0xFF, 0xFF, 0x7F };
        std::memcpy(g_copy.data() + 0x3C, huge, 4);
        const auto r = scan::find_export_by_hand(live_view(), "il2cpp_string_new");
        check(!r.parsed && r.failure, "an e_lfanew past the end is refused");
    }
    {   // PE signature missing at a valid e_lfanew
        FakePe pe; g_copy = pe.bytes;
        g_copy[0x80] = 0x00; g_copy[0x81] = 0x00;
        const auto r = scan::find_export_by_hand(live_view(), "il2cpp_string_new");
        check(!r.parsed && r.failure, "a missing PE signature is refused");
    }
    {   // neither PE32 nor PE32+
        FakePe pe; g_copy = pe.bytes;
        g_copy[0x98] = 0xFF; g_copy[0x99] = 0xFF;
        const auto r = scan::find_export_by_hand(live_view(), "il2cpp_string_new");
        check(!r.parsed && r.failure, "an unknown optional-header magic is refused");
    }
    {   // export directory RVA outside the image
        FakePe pe; g_copy = pe.bytes;
        // NOT named `far`: windows.h defines `far` as an empty macro, so a local
        // so named silently loses its identifier and MSVC reports a syntax
        // error three lines later. Same family of trap as std::min/std::max,
        // which WORKFLOW.md already records; this is a new instance of it.
        const unsigned char outside[4] = { 0x00, 0x00, 0xFF, 0x00 };
        std::memcpy(g_copy.data() + 0x98 + 112, outside, 4);
        const auto r = scan::find_export_by_hand(live_view(), "il2cpp_string_new");
        check(!r.parsed && r.failure, "an export RVA outside the image is refused");
    }
    {   // no export directory at all -- the ordinary "this DLL exports nothing"
        FakePe pe; g_copy = pe.bytes;
        const unsigned char zero[8] = { 0,0,0,0, 0,0,0,0 };
        std::memcpy(g_copy.data() + 0x98 + 112, zero, 8);
        const auto r = scan::find_export_by_hand(live_view(), "il2cpp_string_new");
        check(!r.parsed && r.failure, "a null export data directory is reported");
    }
    {   // NumberOfNames claiming far more names than the image can hold
        FakePe pe; g_copy = pe.bytes;
        const unsigned char big[4] = { 0xFF, 0xFF, 0x00, 0x00 };
        std::memcpy(g_copy.data() + FakePe::kExportRva + 24, big, 4);
        const auto r = scan::find_export_by_hand(live_view(), "il2cpp_string_new");
        check(r.parsed, "an inflated NumberOfNames still parses");
        check(!r.found || r.ordinal <= 1, "an inflated count cannot produce a wild ordinal");
    }
    {   // ordinal index pointing past the function table
        FakePe pe; g_copy = pe.bytes;
        const unsigned char bad[2] = { 0xFF, 0x00 };
        std::memcpy(g_copy.data() + FakePe::kOrdTableRva, bad, 2);
        const auto r = scan::find_export_by_hand(live_view(), "il2cpp_string_new");
        check(!r.found || r.ordinal < FakePe::kExportCount,
            "an out-of-range ordinal does not index the function table");
    }
    {   // a zero image, and a zero size
        g_copy.assign(FakePe::kImageSize, 0);
        const auto r = scan::find_export_by_hand(live_view(), "il2cpp_string_new");
        check(!r.parsed && r.failure, "an all-zero image is refused");

        const scan::PeImageView empty{ 0, 0 };
        const auto z = scan::find_export_by_hand(empty, "il2cpp_string_new");
        check(!z.parsed && z.failure, "a zero base/size is refused");
        check(scan::describe_export_lookup(z, "x").find("FAILED") != std::string::npos,
            "the summary says the parse failed rather than claiming an answer");
    }
}

void test_pe32_uses_a_different_directory_offset()
{
    section("5. PE32 and PE32+ use different DataDirectory offsets");

    // Both magics are in the wild and the offsets differ by 16 bytes. A parser
    // that hardcodes one of them silently reads the wrong field on the other
    // and can produce a plausible-looking answer. Build a PE32 image whose
    // export directory sits at the PE32 offset and check it is found, which
    // only passes if the branch on the magic is real.
    std::vector<unsigned char> bytes(FakePe::kImageSize, 0xCC);
    auto put32 = [&](unsigned o, unsigned v) {
        const unsigned char b[4] = {
            static_cast<unsigned char>(v & 0xFF), static_cast<unsigned char>((v >> 8) & 0xFF),
            static_cast<unsigned char>((v >> 16) & 0xFF), static_cast<unsigned char>((v >> 24) & 0xFF) };
        if (o + 4 <= bytes.size()) std::memcpy(bytes.data() + o, b, 4); };
    auto put16 = [&](unsigned o, unsigned v) {
        const unsigned char b[2] = {
            static_cast<unsigned char>(v & 0xFF), static_cast<unsigned char>((v >> 8) & 0xFF) };
        if (o + 2 <= bytes.size()) std::memcpy(bytes.data() + o, b, 2); };

    put16(0x00, 0x5A4D);
    put32(0x3C, 0x80);
    put32(0x80, 0x00004550);
    put16(0x84, 0x014C);                  // Machine = i386
    put16(0x94, 0xE0);                   // SizeOfOptionalHeader = 224 (PE32)
    const unsigned opt = 0x98;
    put16(opt + 0, 0x010B);               // Magic = PE32  <-- the branch point
    put32(opt + 96, FakePe::kExportRva);  // DataDirectory[0] at +96 for PE32
    put32(opt + 100, FakePe::kExportSize);

    const unsigned sec = opt + 0xE0;
    std::memcpy(bytes.data() + sec, ".text", 5);
    put32(sec + 8, FakePe::kTextSize);
    put32(sec + 12, FakePe::kTextRva);
    put32(sec + 16, FakePe::kTextSize);
    put32(sec + 20, 0);

    const unsigned e = FakePe::kExportRva;
    put32(e + 16, 1);
    put32(e + 20, 1);
    put32(e + 24, 1);
    put32(e + 28, FakePe::kFuncTableRva);
    put32(e + 32, FakePe::kNameTableRva);
    put32(e + 36, FakePe::kOrdTableRva);
    put32(FakePe::kFuncTableRva, 0x1500);
    put32(FakePe::kNameTableRva, FakePe::kNameStringRva);
    put16(FakePe::kOrdTableRva, 0);
    // 16 characters PLUS the terminating NUL. Leaving it off is a real and
    // instructive mistake: the parser walks the name until it sees a NUL or a
    // mismatch, so an unterminated name runs into the 0xCC fill and simply is
    // not found -- which reads exactly like "the export is missing". The
    // first run of this case failed 2/43 for that reason, which is the test
    // doing its job rather than the parser being wrong.
    {
        const char* n = "pe32_only_export";
        const size_t len = std::strlen(n) + 1;
        std::memcpy(bytes.data() + FakePe::kNameStringRva, n, len);
    }

    g_copy = bytes;
    const auto r = scan::find_export_by_hand(live_view(), "pe32_only_export");
    check(r.parsed, "a PE32 image parses");
    check(r.found, "a PE32 image's export is found -- the +96 offset is used, not +112");
    check(r.rva == 0x1500, "the PE32 export resolves to the right RVA");
}

void test_bounds_helper()
{
    section("6. the bounds helper itself");

    scan::PeImageView v{ 0x1000, 0x100 };
    check(v.contains(0x1000, 1), "the first byte is inside");
    check(v.contains(0x10FF, 1), "the last byte is inside");
    check(!v.contains(0x1100, 1), "one past the end is outside");
    check(v.contains(0x1080, 0x80), "an access ending exactly at the end is inside");
    check(!v.contains(0x1081, 0x80), "an access overrunning the end is outside");
    check(!v.contains(0x0FFF, 1), "one before the base is outside");
    check(!v.contains(0x1080, 0x81), "an oversized access is outside");

    // The half-open tail case: len == 0 at the very end is legal and must not
    // underflow the "size - off" subtraction.
    check(v.contains(0x1100, 0), "a zero-length access exactly at the end is inside");
}

} // namespace

int main()
{
    std::printf("test_export_lookup -- scan::find_export_by_hand against synthetic PE images\n");

    test_happy_path();
    test_forwarder();
    test_absent_and_case_sensitivity();
    test_malformed_images_do_not_fault();
    test_pe32_uses_a_different_directory_offset();
    test_bounds_helper();

    std::printf("\n%d/%d passed", g_pass, g_pass + g_fail);
    if (g_fail) {
        std::printf(", %d FAILED\n", g_fail);
        return 1;
    }
    std::printf("\n");
    return 0;
}