// Coverage for TarkovAddons/module/item_categories.h -- the loot-category table that
// replaced substring matching over the item's LOCALIZED display name.
//
// GENERATED from GameDump/115147510/dump.cs: all 130 ItemTemplate subclasses,
// with their base class and the category the base-chain walk is expected to produce.
// Generating it rather than hand-listing names is the whole point. The hand-written
// first version of this file asserted 30 leaves, every one of which passed, while the
// table they covered matched 1953 of 5963 live entries (33%) -- because the misses
// were families with their own class name, which a leaf list structurally cannot see.
//
// The header is included directly so this compiles the REAL thing; the parent chain
// comes from the table above, not from a second copy of the logic.

#include <cstdint>
#include <cstring>
#include <iostream>
#include <iterator>
#include <map>
#include <memory>
#include <string>

#include "../../TarkovAddons/module/item_categories.h"

namespace ic = item_categories;

static int g_pass = 0;
static int g_fail = 0;

static void check(const bool condition, const char* what) {
    if (condition) ++g_pass;
    else {
        ++g_fail;
        std::cout << "  FAIL: " << what << "\n";
    }
}

struct row {
    const char* leaf;
    const char* base;
    ic::loot want;
};

// The full hierarchy, from the dump.
static const row kRows[] = {
    {"AmmoBoxTemplate", "ItemTemplate", ic::loot::ammo},
    {"AmmoTemplate", "StackableItemTemplate", ic::loot::ammo},
    {"AreaTemplate", "ItemTemplate", ic::loot::unknown},
    {"ArmBandTemplate", "EquipmentTemplate", ic::loot::armor},
    {"ArmorPlateTemplate", "ArmoredEquipmentTemplate", ic::loot::armor},
    {"ArmorTemplate", "ArmoredEquipmentTemplate", ic::loot::armor},
    {"ArmoredEquipmentTemplate", "EquipmentTemplate", ic::loot::armor},
    {"AssaultCarbineTemplate", "WeaponTemplate", ic::loot::weapons},
    {"AssaultRifleTemplate", "WeaponTemplate", ic::loot::weapons},
    {"AssaultScopeTemplate", "SightModTemplate", ic::loot::barter},
    {"AuxiliaryModTemplate", "ModTemplate", ic::loot::barter},
    {"BackpackTemplate", "SearchableItemTemplate", ic::loot::armor},
    {"BarrelTemplate", "MasterModTemplate", ic::loot::barter},
    {"BarterItemTemplate", "ItemTemplate", ic::loot::barter},
    {"BarterOtherTemplate", "BarterItemTemplate", ic::loot::barter},
    {"BatteryTemplate", "BarterItemTemplate", ic::loot::barter},
    {"BattlePassItemTemplate", "StackableItemTemplate", ic::loot::unknown},
    {"BipodTemplate", "FunctionalModTemplate", ic::loot::barter},
    {"BotDebugMenuItemTemplate", "ItemTemplate", ic::loot::unknown},
    {"BrokenWindowPieceTemplate", "ItemTemplate", ic::loot::unknown},
    {"BuildingMaterialTemplate", "BarterItemTemplate", ic::loot::barter},
    {"ChargeTemplate", "GearModTemplate", ic::loot::barter},
    {"ChemLightTemplate", "ItemTemplate", ic::loot::barter},
    {"CollimatorTemplate", "SightModTemplate", ic::loot::barter},
    {"CompactCollimatorTemplate", "SightModTemplate", ic::loot::barter},
    {"CompassTemplate", "SpecItemTemplate", ic::loot::barter},
    {"CompensatorTemplate", "MuzzleModTemplate", ic::loot::barter},
    {"CompletableTemplate", "ItemTemplate", ic::loot::unknown},
    {"CompoundItemTemplate", "ItemTemplate", ic::loot::unknown},
    {"CultistAmuletTemplate", "SpecItemTemplate", ic::loot::barter},
    {"CylinderMagazineTemplate", "MagazineTemplate", ic::loot::barter},
    {"DialogItemTemplate", "ItemTemplate", ic::loot::unknown},
    {"DrinkTemplate", "FoodDrinkTemplate", ic::loot::food},
    {"DrugsTemplate", "MedsTemplate", ic::loot::medical},
    {"ElectronicsTemplate", "BarterItemTemplate", ic::loot::valuables},
    {"EmptyHandsTemplate", "ItemTemplate", ic::loot::unknown},
    {"EquipmentTemplate", "CompoundItemTemplate", ic::loot::armor},
    {"FaceCoverTemplate", "ArmoredEquipmentTemplate", ic::loot::armor},
    {"FlashHiderTemplate", "MuzzleModTemplate", ic::loot::barter},
    {"FlashlightTemplate", "FunctionalModTemplate", ic::loot::barter},
    {"FlyerTemplate", "ItemTemplate", ic::loot::unknown},
    {"FoodDrinkTemplate", "ItemTemplate", ic::loot::food},
    {"FoodTemplate", "FoodDrinkTemplate", ic::loot::food},
    {"ForegripTemplate", "FunctionalModTemplate", ic::loot::barter},
    {"FuelTemplate", "BarterItemTemplate", ic::loot::barter},
    {"FunctionalModTemplate", "ModTemplate", ic::loot::barter},
    {"GasblockTemplate", "FunctionalModTemplate", ic::loot::barter},
    {"GearModTemplate", "ModTemplate", ic::loot::barter},
    {"GrenadeLauncherTemplate", "WeaponTemplate", ic::loot::weapons},
    {"HandguardTemplate", "MasterModTemplate", ic::loot::barter},
    {"HeadphonesTemplate", "EquipmentTemplate", ic::loot::armor},
    {"HeadwearTemplate", "ArmoredEquipmentTemplate", ic::loot::armor},
    {"HideoutAreaContainerTemplate", "CompoundItemTemplate", ic::loot::unknown},
    {"HouseholdGoodsTemplate", "BarterItemTemplate", ic::loot::barter},
    {"InfoTemplate", "ItemTemplate", ic::loot::unknown},
    {"InventoryEquipmentTemplate", "CompoundItemTemplate", ic::loot::unknown},
    {"IronSightTemplate", "SightModTemplate", ic::loot::barter},
    {"ItemTemplate", "ItemTemplate", ic::loot::unknown},
    {"JewelryTemplate", "BarterItemTemplate", ic::loot::valuables},
    {"KeyTemplate", "ItemTemplate", ic::loot::keys},
    {"KeycardTemplate", "KeyTemplate", ic::loot::keys},
    {"KnifeTemplate", "ItemTemplate", ic::loot::weapons},
    {"LauncherTemplate", "GearModTemplate", ic::loot::barter},
    {"LightLaserTemplate", "FunctionalModTemplate", ic::loot::barter},
    {"LockableContainerTemplate", "CompoundItemTemplate", ic::loot::unknown},
    {"LootContainerTemplate", "SearchableItemTemplate", ic::loot::unknown},
    {"LubricantTemplate", "BarterItemTemplate", ic::loot::barter},
    {"MachineGunTemplate", "WeaponTemplate", ic::loot::weapons},
    {"MagazineTemplate", "GearModTemplate", ic::loot::barter},
    {"MapTemplate", "ItemTemplate", ic::loot::unknown},
    {"MarkOfUnknownTemplate", "SpecItemTemplate", ic::loot::barter},
    {"MarksmanRifleTemplate", "WeaponTemplate", ic::loot::weapons},
    {"MasterModTemplate", "ModTemplate", ic::loot::barter},
    {"MedKitTemplate", "MedsTemplate", ic::loot::medical},
    {"MedicalSuppliesTemplate", "BarterItemTemplate", ic::loot::barter},
    {"MedicalTemplate", "MedsTemplate", ic::loot::medical},
    {"MedsTemplate", "ItemTemplate", ic::loot::medical},
    {"MobContainerTemplate", "SearchableItemTemplate", ic::loot::unknown},
    {"ModTemplate", "CompoundItemTemplate", ic::loot::barter},
    {"MoneyTemplate", "StackableItemTemplate", ic::loot::unknown},
    {"MountTemplate", "GearModTemplate", ic::loot::barter},
    {"MultiToolTemplate", "SpecItemTemplate", ic::loot::barter},
    {"MuzzleComboTemplate", "MuzzleModTemplate", ic::loot::barter},
    {"MuzzleModTemplate", "FunctionalModTemplate", ic::loot::barter},
    {"NightVisionTemplate", "SpecialScopeTemplate", ic::loot::barter},
    {"NoteItemTemplate", "CompletableTemplate", ic::loot::unknown},
    {"OpticScopeTemplate", "SightModTemplate", ic::loot::barter},
    {"PistolGripTemplate", "MasterModTemplate", ic::loot::barter},
    {"PistolTemplate", "WeaponTemplate", ic::loot::weapons},
    {"PlantingKitTemplate", "SpecItemTemplate", ic::loot::barter},
    {"PmsTemplate", "MuzzleModTemplate", ic::loot::barter},
    {"PocketsTemplate", "SearchableItemTemplate", ic::loot::unknown},
    {"PortableRangeFinderTemplate", "SpecItemTemplate", ic::loot::barter},
    {"RadioTransmitterTemplate", "SpecItemTemplate", ic::loot::barter},
    {"RailCoversTemplate", "FunctionalModTemplate", ic::loot::barter},
    {"ReceiverTemplate", "MasterModTemplate", ic::loot::barter},
    {"RecorderItemTemplate", "SpecItemTemplate", ic::loot::barter},
    {"RepairKitTemplate", "SpecItemTemplate", ic::loot::barter},
    {"RepeatableQuestTemplate", "QuestTemplate", ic::loot::unknown},
    {"RevolverTemplate", "WeaponTemplate", ic::loot::weapons},
    {"RocketLauncherTemplate", "WeaponTemplate", ic::loot::weapons},
    {"RocketTemplate", "AmmoTemplate", ic::loot::ammo},
    {"SearchableItemTemplate", "CompoundItemTemplate", ic::loot::unknown},
    {"ShaftTemplate", "GearModTemplate", ic::loot::barter},
    {"ShotgunTemplate", "WeaponTemplate", ic::loot::weapons},
    {"SightModTemplate", "FunctionalModTemplate", ic::loot::barter},
    {"SilencerTemplate", "MuzzleModTemplate", ic::loot::barter},
    {"SimpleContainerTemplate", "CompoundItemTemplate", ic::loot::unknown},
    {"SingleUseContainerTemplate", "CompoundItemTemplate", ic::loot::unknown},
    {"SmgTemplate", "WeaponTemplate", ic::loot::weapons},
    {"SniperRifleTemplate", "WeaponTemplate", ic::loot::weapons},
    {"SortingTableTemplate", "StashTemplate", ic::loot::unknown},
    {"SpecItemTemplate", "ItemTemplate", ic::loot::barter},
    {"SpecialScopeTemplate", "SightModTemplate", ic::loot::barter},
    {"SpecialWeaponTemplate", "WeaponTemplate", ic::loot::weapons},
    {"SpringDrivenCylinderTemplate", "CylinderMagazineTemplate", ic::loot::barter},
    {"StackableItemTemplate", "ItemTemplate", ic::loot::unknown},
    {"StashTemplate", "CompoundItemTemplate", ic::loot::unknown},
    {"StationaryContainerTemplate", "CompoundItemTemplate", ic::loot::unknown},
    {"StimulatorTemplate", "MedsTemplate", ic::loot::medical},
    {"StockTemplate", "GearModTemplate", ic::loot::barter},
    {"TacticalComboTemplate", "FunctionalModTemplate", ic::loot::barter},
    {"TapeItemTemplate", "CompletableTemplate", ic::loot::unknown},
    {"ThermalVisionTemplate", "SpecialScopeTemplate", ic::loot::barter},
    {"ThrowWeapTemplate", "ItemTemplate", ic::loot::weapons},
    {"ToolTemplate", "BarterItemTemplate", ic::loot::barter},
    {"VestTemplate", "SearchableItemTemplate", ic::loot::armor},
    {"VisorsTemplate", "ArmoredEquipmentTemplate", ic::loot::armor},
    {"VolumetricThrowWeapTemplate", "ThrowWeapTemplate", ic::loot::weapons},
    {"WeaponTemplate", "CompoundItemTemplate", ic::loot::weapons},
};

// The classes that must stay UNclassified: containers, rigs, stashes and the
// infrastructure roots. At file scope so the coverage figure computed in main() and
// this list cannot drift apart -- they are generated from the same walk.
static const char* const unclassified_names[] = {
    "AreaTemplate",
    "BattlePassItemTemplate",
    "BotDebugMenuItemTemplate",
    "BrokenWindowPieceTemplate",
    "CompletableTemplate",
    "CompoundItemTemplate",
    "DialogItemTemplate",
    "EmptyHandsTemplate",
    "FlyerTemplate",
    "HideoutAreaContainerTemplate",
    "InfoTemplate",
    "InventoryEquipmentTemplate",
    "ItemTemplate",
    "LockableContainerTemplate",
    "LootContainerTemplate",
    "MapTemplate",
    "MobContainerTemplate",
    "MoneyTemplate",
    "NoteItemTemplate",
    "PocketsTemplate",
    "RepeatableQuestTemplate",
    "SearchableItemTemplate",
    "SimpleContainerTemplate",
    "SingleUseContainerTemplate",
    "SortingTableTemplate",
    "StackableItemTemplate",
    "StashTemplate",
    "StationaryContainerTemplate",
    "TapeItemTemplate",
};

// Build the chain the mod builds: most-derived class name first, then each parent.
static ic::loot classify(const row& r) {
    static const std::map<std::string, const char*> by_name = [] {
        std::map<std::string, const char*> m;
        for (const auto& x : kRows) m.emplace(x.leaf, x.base);
        return m;
    }();
    const char* chain[24];
    size_t n = 0;
    for (const char* c = r.leaf; c && n < 24; c = by_name.count(c) ? by_name.at(c) : nullptr)
        chain[n++] = c;
    return ic::loot_from_ancestry(chain, n);
}

int main() {
    // ---- 1. every class in the hierarchy lands where expected ------------
    {
        int wrong = 0;
        for (const auto& r : kRows) {
            const ic::loot got = classify(r);
            if (got != r.want) {
                ++wrong;
                if (wrong <= 12)
                    std::cout << "  FAIL: " << r.leaf << " (base " << r.base
                              << ") -> got " << int(got) << ", want " << int(r.want) << "\n";
            }
        }
        check(wrong == 0, "every class maps to its expected category");

        // The taxonomy number is the assertion that matters. If a patch moves the
        // hierarchy, this is what notices -- not a hand-listed leaf going stale.
        //
        // NAMING, measured 2026-10-12: this used to print "  coverage: NN%", which is
        // a different quantity from code coverage and reads like it. Measured with
        // llvm-cov (clang -fprofile-instr-generate -fcoverage-mapping over the five
        // portable cases), this header is 67/105 lines = 63.8% covered with 5/11
        // functions executed -- while the line below printed 77%. Neither number was
        // wrong; they answer different questions, and "coverage" invited the reading
        // that this one was the other. It is the fraction of kRows that maps to a
        // non-unknown category, nothing more. Say so in the label.
        const int total = static_cast<int>(std::size(kRows));
        const int unclass = static_cast<int>(std::size(unclassified_names));
        int covered = 0;
        for (const auto& r : kRows)
            if (r.want != ic::loot::unknown) ++covered;
        check(total - covered == unclass,
            "the unclassified list and the non-unknown rows are the same set");
        std::cout << "  taxonomy mapped: " << (covered * 100 / total) << "% (" << covered << "/"
                  << total << " classes, " << unclass << " deliberately unclassified)\n";
        check(covered * 100 / total >= 75, "at least 75% of the hierarchy maps");
        std::cout << "  by category: barter=59, weapons=16, armor=11, medical=5, ammo=3, food=3, valuables=2, keys=2\n";
    }

    // ---- 2. the families the old leaf table missed ----------------------
    // These are the ones the live log named as unmapped, with their template counts
    // from 2026-10-03. Each must now be claimed, so a regression here is caught by
    // name rather than inferred from a total.
    {
        struct probe { const char* leaf; ic::loot want; const char* why; };
        static const probe probes[] = {
            {"ArmorPlateTemplate",     ic::loot::armor,
              "ArmorPlateTemplate=426: the largest loot family in the game"},
            {"SingleUseContainerTemplate", ic::loot::unknown,
              "=427 and still not loot: a container, so it must stay unknown"},
            {"HandguardTemplate",      ic::loot::barter,  "=288, under MasterModTemplate"},
            {"MountTemplate",          ic::loot::barter,  "=286"},
            {"MagazineTemplate",       ic::loot::barter,  "=230, under GearModTemplate"},
            {"FlashHiderTemplate",     ic::loot::barter,  "=165, under MuzzleModTemplate"},
            {"VestTemplate",           ic::loot::armor,
              "derives from SearchableItemTemplate, NOT ArmoredEquipmentTemplate"},
            {"BackpackTemplate",       ic::loot::armor,   "same trap as VestTemplate"},
            {"ArmBandTemplate",        ic::loot::armor,   "under EquipmentTemplate"},
            {"HeadphonesTemplate",     ic::loot::armor,   "under EquipmentTemplate"},
            {"AssaultCarbineTemplate", ic::loot::weapons,
              "no shared name token: only WeaponTemplate identifies it"},
            {"ShotgunTemplate",        ic::loot::weapons, "same -- a name table cannot work"},
            {"SmgTemplate",            ic::loot::weapons, "same"},
            {"SniperRifleTemplate",    ic::loot::weapons, "same"},
            {"DrinkTemplate",          ic::loot::food,    "under FoodDrinkTemplate"},
            {"FoodTemplate",           ic::loot::food,    "under FoodDrinkTemplate"},
            {"MedKitTemplate",         ic::loot::medical, "under MedsTemplate"},
            {"StimulatorTemplate",     ic::loot::medical, "under MedsTemplate"},
            {"DrugsTemplate",          ic::loot::medical, "under MedsTemplate"},
            {"KeycardTemplate",        ic::loot::keys,    "under KeyTemplate"},
            {"RocketTemplate",         ic::loot::ammo,
              "under StackableItemTemplate, NOT AmmoTemplate"},
            {"CultistAmuletTemplate",  ic::loot::barter,  "under SpecItemTemplate"},
            {"VisorsTemplate",         ic::loot::armor,   "under ArmoredEquipmentTemplate"},
            {"ChemLightTemplate",      ic::loot::barter,  "derives straight from ItemTemplate"},
            {"MedicalSuppliesTemplate", ic::loot::barter,
              "a BarterItemTemplate, NOT a MedsTemplate: the old substring bug"},
        };
        int found = 0;
        for (const auto& p : probes) {
            for (const auto& r : kRows) {
                if (std::strcmp(r.leaf, p.leaf) != 0) continue;
                ++found;
                check(r.want == p.want,
                  "the probe's expectation agrees with the generated row");
                check(classify(r) == p.want, p.why);
                break;
            }
        }
        check(found == static_cast<int>(std::size(probes)),
            "every named probe class exists in the dump's hierarchy");
    }

    // ---- 3. the five original defects must stay dead ---------------------
    {
        // Valuables must NOT be swallowed by Barter. JewelryTemplate and
        // ElectronicsTemplate both derive from BarterItemTemplate, so this is now
        // decided by the ORDER of the root table -- and the old defect reappears
        // through the hierarchy if that order ever flips.
        check(classify({"JewelryTemplate", "BarterItemTemplate", ic::loot::valuables})
                  != ic::loot::barter,
            "JewelryTemplate is not swallowed by BarterItemTemplate");
        check(classify({"ElectronicsTemplate", "BarterItemTemplate", ic::loot::valuables})
                  != ic::loot::barter,
            "ElectronicsTemplate is not swallowed by BarterItemTemplate");
        // Barter is a POSITIVE test. The earlier needle version had only exclusions,
        // so "Bolts and Duct tape" passed it for entirely the wrong reason.
        check(classify({"ToolTemplate", "BarterItemTemplate", ic::loot::barter})
                  == ic::loot::barter, "ToolTemplate is barter because the class says so");
        // Ammo is decided by the class, never by the display name or a calibre.
        check(classify({"AmmoTemplate", "StackableItemTemplate", ic::loot::ammo})
                  == ic::loot::ammo, "AmmoTemplate is ammo");
        // Buckets are exclusive -- an item lands in exactly one, which the single
        // `return` per chain level makes structural rather than tested.
        int valuables = 0, barter = 0;
        for (const auto& r : kRows) {
            if (classify(r) == ic::loot::valuables) ++valuables;
            if (classify(r) == ic::loot::barter) ++barter;
        }
        check(valuables == 2, "exactly the two valuables classes land in valuables");
        check(barter > valuables * 10,
            "barter is a big family, not a two-class bucket");
    }

    // ---- 4. unknown stays unknown ---------------------------------------
    // Containers and infrastructure are not loot. They have to say so rather than be
    // guessed into barter, because guessing is exactly how Valuables ended up inside
    // Barter the first time.
    {
        int still = 0;
        for (const char* leaf : unclassified_names) {
            for (const auto& r : kRows) {
                if (std::strcmp(r.leaf, leaf) != 0) continue;
                if (classify(r) != ic::loot::unknown) {
                    ++still;
                    std::cout << "  FAIL: " << leaf << " is no longer unknown: "
                              << int(classify(r)) << "\n";
                }
                break;
            }
        }
        check(still == 0, "the unclassified set is unchanged");
    }

    // ---- 5. the enum ordinals are a saved-config contract -----------------
    // SelectValue stores the index, so reordering silently re-labels every saved
    // setting in every user's config. Assert the numbers themselves.
    check(static_cast<int>(ic::loot::unknown)   == 0, "loot::unknown == 0");
    check(static_cast<int>(ic::loot::valuables) == 1, "loot::valuables == 1");
    check(static_cast<int>(ic::loot::barter)    == 2, "loot::barter == 2");
    check(static_cast<int>(ic::loot::medical)   == 3, "loot::medical == 3");
    check(static_cast<int>(ic::loot::food)      == 4, "loot::food == 4");
    check(static_cast<int>(ic::loot::ammo)      == 5, "loot::ammo == 5");
    check(static_cast<int>(ic::loot::weapons)   == 6, "loot::weapons == 6");
    check(static_cast<int>(ic::loot::armor)     == 7, "loot::armor == 7");
    check(static_cast<int>(ic::loot::keys)      == 8, "loot::keys == 8");
    check(static_cast<int>(ic::loot::count)     == 9, "loot::count == 9");

    // ---- 6. a chain that walks off the end is unknown, not a crash -------
    // A malformed image could hand us a cycle or a null name; both must terminate.
    {
        const char* nulls[1] = {nullptr};
        check(ic::loot_from_ancestry(nulls, 1) == ic::loot::unknown,
            "a null class name in the chain is skipped");
        check(ic::loot_from_ancestry(nullptr, 0) == ic::loot::unknown,
            "an empty chain is unknown");
        const char* cyclic[2] = {"LoopATemplate", "LoopATemplate"};
        check(ic::loot_from_ancestry(cyclic, 2) == ic::loot::unknown,
            "a self-referential chain does not loop forever");
    }

    // ---- 7. loot_category_allows: the predicate both modules now share ----
    // The five defects of the substring switch are recorded in
    // item_categories::loot_category_allows. Two of them are directly expressible
    // here and would have FAILED against the old needles, so they are worth pinning:
    //   * Barter was a negated match, so Valuables fell inside it (subset).
    //   * Barter had no positive requirement, so Bolts/Duct tape/Car Battery passed.
    check(ic::loot_category_allows(ic::loot::unknown, 5),
        "an unclassified item is ALLOWED, not silently hidden");
    check(!ic::loot_category_allows(ic::loot::valuables, 2),
        "Valuables is NOT a subset of Barter (was true under the negated needles)");
    check(ic::loot_category_allows(ic::loot::valuables, 1),
        "Valuables matches its own category");
    check(ic::loot_category_allows(ic::loot::barter, 2), "Barter matches its own category");
    check(ic::loot_category_allows(ic::loot::ammo, 5), "Ammo matches its own category");
    check(!ic::loot_category_allows(ic::loot::ammo, 3),
        "Ammo is not Medical (buckets do not overlap)");
    check(ic::loot_category_allows(ic::loot::ammo, 0),
        "category 0 (All Categories) allows everything");
    check(ic::loot_category_allows(ic::loot::unknown, 0),
        "category 0 allows even the unknown class");
    check(ic::loot_category_allows(ic::loot::keys, 8), "Keys matches its own category");
    check(!ic::loot_category_allows(ic::loot::keys, 7), "Keys is not Armor");

    // ---- 8. matches_teleport_filter: the four-option dropdown --------------
    {
        ic::teleport_filter_input in;
        in.template_id = "bandage";
        in.is_quest = true;
        in.wishlist = ic::kind::wishlist;
        in.category_kind = ic::loot::medical;
        in.category = 3;
        in.selected_id = "";

        check(ic::matches_teleport_filter(0, in), "filter 0 (All) allows");
        check(ic::matches_teleport_filter(1, in), "filter 1 (Quest) matches is_quest");

        // filter 2 is the combined Category/Wishlist option: an item in the
        // selected category OR on the wishlist passes, so the two axes never
        // overlap across filter options.
        check(ic::matches_teleport_filter(2, in), "filter 2 matches via the category");
        in.category = 5; // Ammo -- not this item's category
        check(ic::matches_teleport_filter(2, in), "filter 2 matches via the wishlist");
        in.wishlist = ic::kind::other;
        check(!ic::matches_teleport_filter(2, in),
            "filter 2 rejects an item in neither the category nor the wishlist");
        in.category = 0; // All Categories picked
        check(!ic::matches_teleport_filter(2, in),
            "filter 2 with All Categories matches nothing on the category half");
        in.category = 3;
        in.wishlist = ic::kind::wishlist;

        // filter 3 is the only one that looks at selected_id, and an empty
        // selection matches nothing rather than everything.
        check(!ic::matches_teleport_filter(3, in),
            "filter 3 with no item selected matches nothing");
        in.selected_id = "bandage";
        check(ic::matches_teleport_filter(3, in), "filter 3 matches the selected item");
        in.selected_id = "other_item";
        check(!ic::matches_teleport_filter(3, in), "filter 3 rejects a different item");
        in.selected_id = "";

        // Now that 4 and 5 are real filters (the split halves of option 2), the
        // "above the list" boundary has moved to 6.
        check(ic::matches_teleport_filter(6, in),
            "an out-of-range filter falls through to allow");

        // ---- 8b. filters 4 and 5: the two halves of the old option 2 ----------
        // Option 2 asked "category OR wishlist", so a caller that wanted only one
        // got the other's items too. Each half must now decide alone.

        // 4 = category ONLY. Wishlist state must not influence it.
        in.wl_mask = ic::group_bit(ic::wishlist_group::quests);
        in.wl_group = ic::wishlist_group::quests;
        in.category = 3;                                     // a specific category
        check(ic::matches_teleport_filter(4, in),
            "filter 4 matches on the category half");

        in.category_kind = ic::loot::valuables;
        check(!ic::matches_teleport_filter(4, in),
            "filter 4 rejects an item outside the chosen category");

        // "ignores the wishlist half" has to be proven by VARYING the wishlist state
        // and showing the answer does not move. Comparing the same call against
        // itself (the first version of this line) tests nothing.
        const bool category_only_answer = ic::matches_teleport_filter(4, in);
        in.wl_mask = 0;                                      // All groups
        check(ic::matches_teleport_filter(4, in) == category_only_answer,
            "filter 4 ignores the wishlist half entirely");
        in.wl_mask = ic::group_bit(ic::wishlist_group::trading);
        in.wl_group = ic::wishlist_group::trading;
        check(ic::matches_teleport_filter(4, in) == category_only_answer,
            "filter 4 still ignores a different wishlist group");
        // restore the quests state the block below expects
        in.wl_mask = ic::group_bit(ic::wishlist_group::quests);
        in.wl_group = ic::wishlist_group::quests;

        // An All category is a restriction-free category, so it matches nothing
        // rather than everything -- the same reading option 2 always had.
        in.category = 0;
        check(!ic::matches_teleport_filter(4, in),
            "filter 4 with All Categories matches nothing");

        // 5 = wishlist ONLY. Category state must not influence it.
        in.category = 3;
        in.category_kind = ic::loot::unknown;
        check(ic::matches_teleport_filter(5, in),
            "filter 5 matches on the wishlist half");

        in.wl_mask = 0;                                      // All groups
        check(!ic::matches_teleport_filter(5, in),
            "filter 5 rejects an item in no wishlist group");

        // ---- 8d. REGRESSION: the item search selects EVERY match, not one -----
        // The by-name filter asked a single `selected_id` and compared it to the
        // template id. A query with several results therefore matched only the
        // one the user clicked, which made a multi-result search useless as a
        // filter: it could label or teleport one item and drop the other four.
        //
        // A multi-select search box now supplies the whole matched set, and this
        // block pins the three properties that make that work:
        //   - each id in the set matches (not just the first or the last),
        //   - an id outside the set does not match,
        //   - an empty set matches NOTHING rather than everything.
        //
        // The set pointer is the switch: with it null the predicate keeps the old
        // single-id semantics, which is what the harness's other filter-3 lines
        // above assert, so the two paths are both covered.
        {
            ic::teleport_filter_input u;
            u.template_id = "matches_every_one";

            const std::unordered_set<std::string> matched = {
                "matches_every_one", "bandage", "cache_of_gold", "salewa"};
            // A shared_ptr snapshot, which is what the live code hands the
            // predicate: the render thread swaps the set while the game
            // thread reads it, so the predicate holds a reference rather
            // than a pointer into the box.
            u.selected_ids = std::make_shared<const std::unordered_set<std::string>>(matched);

            check(ic::matches_teleport_filter(3, u),
                "filter 3 matches the template id it was given");
            for (const std::string& id : matched)
            {
                u.template_id = id.c_str();
                check(ic::matches_teleport_filter(3, u),
                    "filter 3 matches every id in the matched set");
            }

            u.template_id = "a_thing_you_did_not_search_for";
            check(!ic::matches_teleport_filter(3, u),
                "filter 3 does not match an id outside the matched set");

            // Empty set, not empty string. The distinction matters: an empty
            // STRING selected_id already failed the `*in.selected_id` guard, but
            // an empty set has to fail on its own or "no query typed yet" would
            // teleport the whole map.
            const std::unordered_set<std::string> none;
            u.selected_ids = std::make_shared<const std::unordered_set<std::string>>(none);
            check(!ic::matches_teleport_filter(3, u),
                "filter 3 with no matched ids matches nothing, not everything");

            // And still nothing when there is no template id to match against.
            u.template_id = nullptr;
            check(!ic::matches_teleport_filter(3, u),
                "filter 3 with no matched ids and no template id matches nothing");

            // The single-id path must be untouched by the multi path existing.
            u.selected_ids = nullptr; // still null: the single-id path below
            u.selected_id = "bandage";
            u.template_id = "bandage";
            check(ic::matches_teleport_filter(3, u),
                "filter 3 still honours selected_id when no set is supplied");
            u.template_id = "salewa";
            check(!ic::matches_teleport_filter(3, u),
                "filter 3 still rejects a different id under selected_id");
        }

        // ---- 8c. REGRESSION: the teleporter must not grab unmapped loot --------
        // This is the split the user reported as "teleporting one specific category
        // grabs some of the player wishlist". loot_category_allows allows on
        // loot::unknown, because for a DISPLAY filter a permissive fallback beats a
        // filter that silently hides loot -- and that policy is unchanged for ESP.
        //
        // But a teleport is an ACTION. Measured on the live db (2026-10-11):
        //
        //    124 distinct template classes, 5012/6001 entries mapped to a category
        //    (989 unmapped) ... 24 of 124 classes unmapped:
        //    SingleUseContainerTemplate=427, InfoTemplate=180, NoteItemTemplate=84
        //
        // so one in six loot entries passes EVERY category the user picks, and it is
        // what makes a Category teleport drag wishlist items along with it. So each
        // caller now says which rule it wants, and this block pins BOTH of them.
        //
        // Prove it by VARYING only the flag and watching nothing else, rather than
        // by comparing a call against itself.
        {
            ic::teleport_filter_input u;
            u.template_id = "obscure_thing";
            u.category_kind = ic::loot::unknown;   // the 989/6001 population
            u.category = 3;                        // Medical, explicitly chosen

            check(u.allow_unknown_category,
                "premise: the default is permissive, so ESP is unchanged");
            check(ic::matches_teleport_filter(4, u),
                "filter 4 still allows an unmapped item under the default rule");

            u.allow_unknown_category = ic::kTeleportCategoryAllowsUnknown;
            check(!ic::matches_teleport_filter(4, u),
                "filter 4 with the teleport rule does NOT grab an unmapped item");
            // And the strictness must be about the CATEGORY half alone: an item
            // that genuinely is medical still matches, or the button would be dead.
            u.category_kind = ic::loot::medical;
            check(ic::matches_teleport_filter(4, u),
                "filter 4 still matches a real Medical item under the strict rule");
            // The two constants are named for opposite policies on purpose; a
            // copy that flips one without the other is what this pins.
            check(ic::kCategoryFilterPermitsUnknown != ic::kTeleportCategoryAllowsUnknown,
                "premise: the two policies are actually different");
        }

        // Filter 2 is the combined axis and must honour the same flag, or a
        // caller that reaches it through the teleport path keeps the leak.
        {
            ic::teleport_filter_input u;
            u.category_kind = ic::loot::unknown;
            u.category = 3;
            u.wishlist = ic::kind::other;
            check(ic::matches_teleport_filter(2, u),
                "filter 2 lets an unmapped item through under the default rule");
            u.allow_unknown_category = ic::kTeleportCategoryAllowsUnknown;
            check(!ic::matches_teleport_filter(2, u),
                "filter 2 with the teleport rule rejects an unmapped item");
        }
    }

    // ---- 9. REGRESSION: filter 2 must ignore which item is selected --------
    // Both copies of this switch used to answer the category question by calling
    // their module's loot_ui_filter_allowed, which applies the "selected items
    // only" gate BEFORE the category gate. So with both toggles on, "one
    // category" silently meant "the selected item, if it happens to be in that
    // category". Both toggles default off, so it was latent. This assertion FAILS
    // against that code.
    {
        ic::teleport_filter_input in;
        in.template_id = "bandage";
        in.category_kind = ic::loot::medical;
        in.category = 3;                 // Medical
        in.selected_id = "some_other_item"; // a DIFFERENT item is selected
        check(ic::matches_teleport_filter(2, in),
            "filter 2 asks about the category, not about the selected item");

        // ...and it must not be satisfied by the selection either.
        in.category_kind = ic::loot::keys;
        check(!ic::matches_teleport_filter(2, in),
            "filter 2 rejects a selected item that is in a different category");
    }

    std::cout << (g_fail ? "FAILED " : "ok ") << (g_pass + g_fail)
              << " assertions, " << g_fail << " failed\n";
    return g_fail ? 1 : 0;
}
