// BEHAVIOURAL test for optics::lens::lens_size_frame_summary().
//
// Added 2026-10-06. The gate's cumulative counters already proved 56 rejections
// and 0 re-baselines (tools/measure_lenssize_gate.py), which is consistent with
// accepts interleaved inside every reject burst -- but a cumulative counter cannot
// show ALTERNATION, which is the whole question. This drives the real summary with
// the two cases that discriminate:
//
//   1. reject/accept alternating  -> must print "TIMER STARVED"
//   2. one long reject run then accepts, with the re-baseline fired
//                                   -> must NOT print "TIMER STARVED"
//
// Case 2 is the inverse control. A summary that always says TIMER STARVED is
// indistinguishable from one that measured something, which is how
// tracy_bridge.h's ~60-lines-per-second habit started: an instrument nobody could
// tell was broken.
//
// It compiles the real header, so the link stubs are in lenssize_stubs.cpp.
//
// LINK STUBS, which is the part that was guessed and then found by linking.
// Including optics_lens_pipeline.h needs three out-of-line symbols its inline
// globals reference. Each was discovered one link at a time, NOT by reading the
// header:
//   LNK2019 safetyhook::InlineHook::~InlineHook
//   LNK2019 safetyhook::Allocation::~Allocation   <- InlineHook owns one by value
//   LNK2019 unity::vector3::vector3
// I previously concluded from the first LNK2019 that the real header could not be
// linked into the harness at all. That was a guess dressed as a finding; the
// harness already solves this shape of problem in stubs.cpp, and two more
// definitions was all it took. Consequence: this is a REAL behavioural test of
// the real formatting, not a text check.
//
// NAMES. `near` is unusable as a local here: like `far` (AGENTS.md, MSVC traps),
// it is an empty macro and the declaration vanishes, which MSVC reports as C2513
// "cannot be initialized; it is being redefined" -- an error that reads like a
// name collision, and sent me looking for duplicate declarations three times
// before I checked the trap list. Hence `near_edge_hit`.
//
// NEGATIVE CONTROLS, each run against deliberately broken source:
//   A. run-max tracking removed (reset before the max compare) -> caught, 3 asserts
//   B. the starved verdict hardcoded true                      -> caught, 2 asserts
//   C. reject recorded after the re-baseline branch instead of
//      before -> NOT CAUGHT. This is the honest result: the case that motivated
//      the ordering (a frame the escape hatch caught must not vanish) is not
//      asserted by anything here, because driving that branch needs a real
//      kRebaselineMs clock. The ordering is documented in the source instead.
//
// AND THE TRAP APPLIES TO THIS COMMENT. The first draft of this file wrote the
// sentence "`near` is unusable" in a comment, and the build broke with a wall of
// errors starting at the token AFTER it -- the macro is expanded in comments too,
// because the preprocessor runs before anything else. Documentation about the
// trap is not exempt from it. Both mentions above are therefore spelled out in
// prose rather than written as bare identifiers.
#include "../../TarkovAddons/il2cpp/unity.h"
#include "../../TarkovAddons/module/optics_lens_pipeline.h"

#include <cstdio>
#include <cstring>

namespace lens = optics::lens;

static void reset() {
    std::memset(lens::g_lens_ring, 0, sizeof(lens::g_lens_ring));
    std::memset(lens::g_lens_tick, 0, sizeof(lens::g_lens_tick));
    lens::g_lens_ring_head = 0;
    lens::g_lens_ring_filled = 0;
    lens::g_lens_reject_run = 0;
    lens::g_lens_accept_run = 0;
    lens::g_lens_reject_run_max = 0;
    lens::g_lens_accept_run_max = 0;
    lens::g_lens_size = lens::lens_image_size_gate{};
}

int main() {
    int rc = 0;
    char buf[768];

    // --- case 1: alternating reject/accept, never re-baselining ------------
    // 16 evaluations, every other one rejected. run_max stays at 1, so a
    // 500 ms continuous-rejection timer can never expire.
    reset();
    for (int i = 0; i < 16; ++i) {
        const bool rej = (i % 2) == 0;
        lens::record_lens_size_frame(0.70f, 1.0f, rej, rej, false, false);
    }
    lens::lens_size_frame_summary(buf, sizeof(buf));
    std::printf("case 1 (alternating):\n  %s\n\n", buf);
    {
        const bool starved = std::strstr(buf, "TIMER STARVED") != nullptr;
        const bool runs_ok = std::strstr(buf, "reject max=1") != nullptr;
        const bool cnt_ok = std::strstr(buf, "rejected=8") != nullptr;
        std::printf("  %-34s %s\n", "alternating -> TIMER STARVED",
            starved ? "PASS" : "FAIL");
        std::printf("  %-34s %s\n", "  and reject run max is 1",
            runs_ok ? "PASS" : "FAIL");
        std::printf("  %-34s %s\n", "  and 8 of 16 rejected",
            cnt_ok ? "PASS" : "FAIL");
        if (!starved || !runs_ok || !cnt_ok) rc = 1;
    }

    // --- case 2: the INVERSE. Long reject run, then accepts, and the
    //     re-baseline counter is nonzero -- the escape hatch worked.
    reset();
    for (int i = 0; i < 40; ++i) {
        lens::record_lens_size_frame(0.70f, 1.0f, true, true, false, false);
    }
    for (int i = 0; i < 8; ++i) {
        lens::record_lens_size_frame(0.70f, 1.0f, false, false, false, false);
    }
    lens::g_lens_size.rebaselines = 3;
    lens::lens_size_frame_summary(buf, sizeof(buf));
    std::printf("case 2 (long run, rebaselined):\n  %s\n\n", buf);
    {
        const bool not_starved = std::strstr(buf, "TIMER STARVED") == nullptr;
        const bool run_ok = std::strstr(buf, "reject max=40") != nullptr;
        const bool reb = std::strstr(buf, "rebaselines=3") != nullptr;
        std::printf("  %-34s %s\n", "rebaselined -> NOT starved",
            not_starved ? "PASS" : "FAIL");
        std::printf("  %-34s %s\n", "  and reject run max is 40",
            run_ok ? "PASS" : "FAIL");
        std::printf("  %-34s %s\n", "  and rebaselines=3 reported", reb ? "PASS" : "FAIL");
        if (!not_starved || !run_ok || !reb) rc = 1;
    }

    // --- case 3: clean. Nothing rejected, nothing near the edge ------------
    reset();
    for (int i = 0; i < 12; ++i) {
        lens::record_lens_size_frame(1.00f, 1.0f, false, false, false, false);
    }
    lens::lens_size_frame_summary(buf, sizeof(buf));
    std::printf("case 3 (clean):\n  %s\n\n", buf);
    {
        // `clean` and `not_starved` were both declared in case 1's block too, and
        // they are in the SAME function body, so case 3 failed to compile with
        // C2513 until they were renamed. Worth stating: the two blocks are
        // siblings, not nested, and a reader skimming for the assertion would
        // not have spotted the collision.
        const bool clean_word = std::strstr(buf, "clean") != nullptr;
        const bool clean_not_starved =
            std::strstr(buf, "TIMER STARVED") == nullptr;
        std::printf("  %-34s %s\n", "no rejects -> 'clean'",
            clean_word ? "PASS" : "FAIL");
        std::printf("  %-34s %s\n", "  and not starved",
            clean_not_starved ? "PASS" : "FAIL");
        if (!clean_word || !clean_not_starved) rc = 1;
    }

    // --- case 4: near-edge counting. ratio 0.70 against a 0.70 edge is
    //     exactly ON the edge, so all frames count as near-edge.
    reset();
    for (int i = 0; i < 5; ++i) {
        lens::record_lens_size_frame(0.7035f, 1.0f, false, false, false, false);
    }
    lens::lens_size_frame_summary(buf, sizeof(buf));
    std::printf("case 4 (near edge):\n  %s\n\n", buf);
    {
        // "%%" in the needle is a literal percent as printf sees it, but strstr does
        // not: the summary writes a bare "%". Written as "%%" here it never matches,
        // which is a test that passes for the wrong reason, so it is a plain "%".
        // The needle carries one '%' after "-1", because snprintf wrote a literal percent
        // there in the format string. Kept on one line deliberately: split across a
        // line continuation the '%' would be ambiguous to a reader scanning for the
        // printf conversion, which is how a needle gets "fixed" into not matching.
        const char needle[] = "near-edge(+-1%):5";
        // Named `near_edge_hit`, not `near`. `near` is one of the pair AGENTS.md warns
        // about -- a local named `far` loses its identifier to an empty macro, and
        // `near` behaves the same way here. C2513 "cannot be initialized; it is
        // being redefined" was this, not a duplicate declaration: I went looking
        // for a name collision three times before reading the trap in AGENTS.md.
        const bool near_edge_hit = std::strstr(buf, needle) != nullptr;
        // The needle above carries one '%' after "-1". snprintf wrote "%d" for the
        // near-edge count, so the rendered text is "+-1%):5" -- one percent, then
        // the closing paren. If the format ever gains a literal percent this fails,
        // which is correct: it would mean the printed text changed.
        std::printf("  %-34s %s\n", "all 5 frames counted near-edge",
            near_edge_hit ? "PASS" : "FAIL");
        if (!near_edge_hit) rc = 1;
    }

    // --- case 5: the summary must fail soft, not overflow, on a tiny buffer.
    //     The append path clamps twice; a tiny buffer is where that shows.
    reset();
    for (int i = 0; i < 8; ++i) {
        lens::record_lens_size_frame(0.70f, 1.0f, (i % 2) == 0, (i % 2) == 0,
            false, false);
    }
    char tiny[24];
    std::memset(tiny, 0x7f, sizeof(tiny));
    tiny[sizeof(tiny) - 1] = 0;
    const int n = lens::lens_size_frame_summary(tiny, sizeof(tiny));
    const bool clamped = n > 0 && n < (int)sizeof(tiny);
    std::printf("  %-34s %s (returned %d of %d)\n",
        "tiny buffer clamped, not overflowed", clamped ? "PASS" : "FAIL",
        n, (int)sizeof(tiny));
    if (!clamped) rc = 1;

    std::puts(rc ? "\nFAILED\n" : "\nOK\n");
    return rc;
}
