// The debugger gate on the crash probe.
//
// WHAT THIS ASSERTS, and why it is a test rather than an argument.
//
// FIRST, A RETRACTION, BECAUSE THIS FILE PREVIOUSLY ASSERTED SOMETHING THIS
// MACHINE DOES NOT DO. The 2026-10-09 note read as: without a debugger,
// OutputDebugStringA does not raise 0x40010006 at all; attaching one delivers
// every call as an exception to the VEH (63 -> 1,969 events) and the probe
// walked the stack for each. Measured 2026-10-10 with a live-debuggee matrix,
// both halves of that are backwards here:
//
//   * with NO debugger, kernel32!OutputDebugStringA/W raise 0x40010006 /
//     0x4001000A in-process on EVERY call, and a VEH sees each one. The
//     unhandled print raise is absorbed by kernel32's own frame handler; it
//     never reaches the unhandled-exception filter.
//   * with ANY debug port, the kernel converts each print raise into an
//     OUTPUT_DEBUG_STRING_EVENT before in-process delivery. The VEH never sees
//     these codes while a debugger is attached, and the debugger receives a
//     string event, not an exception -- nothing to stop on.
//   * every other code keeps the ordinary protocol in both modes; 0xE06D7363
//     is the calibration below and proves the debug loop sees exception events.
//
// So the 100%-CPU session is not "a debugger turned the prints into
// exceptions"; it is a print flood paying a VEH visit per event with or without
// a debugger. (The per-event STACK WALK it also paid until the same day is the
// other half of that session -- removed by the capture-policy change asserted
// in test_print_capture_policy.cpp, which captures a routine print by head only
// and records `walked` on the event. This file's subject is the disposition:
// what happens to a debugger-signalled code, not what the capture path costs.)
// The gate and its dispositions are still the right protection, and this test
// pins them.
//
// Two properties matter, and both are checked through the same predicate
// handler() calls:
//
//   1. The debugger codes ARE skipped when a debugger is present. If
//      0x40010006 ever leaves that set, handler() stops excluding it while
//      attached -- the events rejoin the ring and the histogram, and the
//      structural check below (consumed ⊆ skipped) goes red, because the two
//      decisions are supposed to stay consistent. The set is
//      five codes since 2026-10-10: the ANSI and WIDE print codes,
//      DBG_RIPEXCEPTION, BREAKPOINT and SINGLE_STEP. 0x4001000A was missing
//      before that, which left every OutputDebugStringW caller exposed.
//      (The per-event walk this set used to guard against is now handled a
//      level down, for prints only, by the capture policy -- see the paragraph
//      after property 2 and test_print_capture_policy.cpp.)
//   2. No real fault is ever skipped, debugger present or not. If
//      ACCESS_VIOLATION joined the list, then attaching a debugger during a
//      live crash would silently blind the probe -- the same "no evidence"
//      hole the probe exists to close, appearing exactly when someone is
//      investigating. Property 2 is what makes this a gate on the exception
//      code rather than "skip everything while debugging", and it is checked
//      name by name.
//
// AND SINCE 2026-10-10, THE SECOND HALF: on a delivery model where the print
// raises DO reach the debugger, skipping was not enough. A skipped event is
// unhandled, and the kernel's answer to "unhandled while a debugger is
// attached" is to ask the debugger a SECOND time -- a stop per
// OutputDebugString. The two print codes are therefore CONSUMED
// (EXCEPTION_CONTINUE_EXECUTION), and the break codes must NOT be (continuing
// execution on an int3 re-executes it forever). That is a different claim from
// "the code list", so it is asserted differently:
//
//   * the consume predicate's membership in both debugger states, plus the
//     structural property that consumes is a subset of skips;
//   * direct calls into the REAL handler with fabricated EXCEPTION_POINTERS,
//     to pin that it consults consuming BEFORE skipping -- the ordering is the
//     fix, and a predicate nobody calls is decoration;
//   * end-to-end, with this exe as its own debuggee under
//     DEBUG_ONLY_THIS_PROCESS. The child installs the arm's handler plus a
//     counting VEH, makes two OutputDebugStringA calls, one OutputDebugStringW
//     call and one manual 0x40010006 raise, and finishes with a 0xE06D7363
//     calibration throw. The parent counts string events and print exceptions
//     per arm, rereads the child's in-process counts from a side file, and
//     DECIDES WHICH MEASURED MODEL the machine is running, then asserts what
//     that model permits:
//
//       classic: >= 3 first-chance print exceptions per arm. The consume arm
//         must then end with ZERO second-chance stops (the fix), and the pass
//         arm -- a plain CONTINUE_SEARCH handler, the pre-fix behaviour -- must
//         DO stop at second chance (the control). Without the pass arm a count
//         that can only read 0 would prove nothing.
//       converted (this machine, measured): no print exception at the
//         debugger, no in-process sighting in the child's VEH, and >= 4 string
//         events per arm (measured 4 per arm: the two ANSI calls, the wide
//         call arriving as ONE ANSI-flagged event at length 37 -- its
//         character count plus NUL, not a separate wide event -- and the manual
//         raise). The consume arm is DORMANT here -- the kernel answered
//         first -- so nothing in a converted run claims to have exercised the
//         consumption, and the output says so.
//
//     If the machine matches NEITHER model this fails loudly with the counter
//     table, rather than passing while measuring something it did not expect.
//
// A NOTE ON THE FIRST VERSION OF THIS FILE. It only tested the code list. Its
// negative control changed the GATE, the test stayed green, and that is
// precisely the failure AGENTS.md is organised against -- a checker that cannot
// see the thing it claims to guard. debugger_gate_skips() exists so the test and
// the handler move together; the consume predicate, the real-handler calls and
// the live-debuggee arms extend the same discipline to the disposition.
//
// The end-to-end arm means this case spawns a process. It needs no project, no
// game and no deployed DLL -- only the exe this file was compiled into, which it
// launches as its own debuggee.

#include "../../TarkovAddons/util/crash_probe.h"

#include <cstdio>
#include <cstring>
#include <windows.h>

static int g_failures = 0;
static void check(bool cond, const char* what) {
    std::printf(cond ? "  [PASS] %s\n" : "  [FAIL] %s\n", what);
    if (!cond) ++g_failures;
}

// The child's actions, and the lowest event count each model can produce from
// them. Kept as named numbers so the model decision below reads as prose.
static constexpr int kMinStringEvents = 4;  // converted: 2 ANSI + wide call + manual raise
static constexpr int kMinPrintFirsts = 3;   // classic: 2 ODS-A + the manual raise

// ---------------------------------------------------------------------------
// The debuggee half. Reached only when this exe re-launches itself as the child
// of its own debug loop below.
// ---------------------------------------------------------------------------

static volatile LONG g_seen_06 = 0;
static volatile LONG g_seen_0A = 0;
static volatile LONG g_seen_calibration = 0;

// Registered AFTER the arm's handler, deliberately: vectored handlers are a
// stack (most-recently registered runs first), so this one sees every
// in-process delivery BEFORE the arm's handler decides anything about it. A
// counter registered first would miss exactly what a consuming handler eats.
static LONG CALLBACK count_handler(EXCEPTION_POINTERS* info) {
    if (!info || !info->ExceptionRecord) return EXCEPTION_CONTINUE_SEARCH;
    switch (info->ExceptionRecord->ExceptionCode) {
    case 0x40010006: InterlockedIncrement(&g_seen_06); break;
    case 0x4001000A: InterlockedIncrement(&g_seen_0A); break;
    case 0xE06D7363: InterlockedIncrement(&g_seen_calibration); break;
    default: break;
    }
    return EXCEPTION_CONTINUE_SEARCH;
}

static LONG CALLBACK passthrough_handler(EXCEPTION_POINTERS*) {
    // The pre-2026-10-10 disposition for the print codes: decide nothing,
    // consume nothing, let "unhandled" become the kernel's second ask. The
    // negative control's handler.
    return EXCEPTION_CONTINUE_SEARCH;
}

// Survives whether or not anything handles the raise, and logs which way it
// went, so one arm's surprise cannot truncate the rest of the run.
static void guarded_raise(DWORD code, ULONG_PTR* args, int nargs, const char* tag) {
    __try {
        RaiseException(code, 0, static_cast<DWORD>(nargs), args);
        std::printf("[debuggee] raise %s returned\n", tag);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        std::printf("[debuggee] raise %s handled in-process\n", tag);
    }
    std::fflush(stdout);
}

static int debuggee_main(const char* mode, const char* counts_path) {
    std::printf("[debuggee] IsDebuggerPresent=%d mode=%s\n",
                static_cast<int>(IsDebuggerPresent()), mode);
    std::fflush(stdout);

    // The arm's handler first, the counter second -- see count_handler.
    if (std::strcmp(mode, "consume") == 0)
        AddVectoredExceptionHandler(1, crash_probe::handler);
    else
        AddVectoredExceptionHandler(1, passthrough_handler);
    AddVectoredExceptionHandler(1, count_handler);

    // Two calls, so a "consumed once but not twice" defect cannot pass.
    OutputDebugStringA("ta_harness: debugger_gate, call 1");
    OutputDebugStringA("ta_harness: debugger_gate, call 2");
    // The wide entry point: 0x4001000A only joined the gate on 2026-10-10, and
    // its delivery differs (measured on the converted model: ONE string event,
    // unicode=0 with length 37 -- the wide string's character count plus NUL --
    // not a separate wide event).
    OutputDebugStringW(L"ta_harness: debugger_gate, wide call");

    // A raise that does not depend on what OutputDebugString's own path does
    // with these codes on this build. {length, pointer}: the measured order.
    const char* manual = "ta_harness manual raise";
    ULONG_PTR args[2] = { std::strlen(manual) + 1, reinterpret_cast<ULONG_PTR>(manual) };
    std::printf("[debuggee] manual 0x40010006 raise\n");
    guarded_raise(0x40010006u, args, 2, "manual 0x40010006");

    // The calibration: a non-print code must reach the debugger first-chance in
    // EVERY delivery model. If the parent's loop does not see this one, the
    // loop is broken and every zero in its table means nothing.
    ULONG_PTR cargs[1] = { 0x12345678u };
    std::printf("[debuggee] calibration 0xE06D7363 raise\n");
    guarded_raise(0xE06D7363u, cargs, 1, "calibration 0xE06D7363");

    std::printf("[debuggee] counts: 06=%ld 0A=%ld calibration=%ld\n",
                g_seen_06, g_seen_0A, g_seen_calibration);
    // The side file is the instrument the parent asserts on: the child's stdout
    // goes to the shared console and does not come back to the parent.
    FILE* counts_file = nullptr;
    if (fopen_s(&counts_file, counts_path, "w") == 0) {
        std::fprintf(counts_file, "%ld %ld %ld\n", g_seen_06, g_seen_0A, g_seen_calibration);
        std::fclose(counts_file);
    }
    std::printf("[debuggee] done\n");
    std::fflush(stdout);
    return 0;
}

// ---------------------------------------------------------------------------
// The debugger half.
// ---------------------------------------------------------------------------

struct ArmResult {
    bool  started = false;
    int   string_events = 0;          // OUTPUT_DEBUG_STRING_EVENT (event 8) count
    int   first_prints = 0;           // first-chance 0x40010006/0x4001000A
    int   second_prints = 0;          // ... and second-chance: a stopped debugger
    int   calibration_first = 0;      // 0xE06D7363 first-chance: the non-vacuity anchor
    int   calibration_second = 0;     // ... its second chance (continued by the loop)
    int   unexpected_second_chance = 0;
    DWORD exit_code = 0;
    bool  exited = false;
    bool  watchdog_fired = false;
    bool  has_child_counts = false;   // the child wrote its in-process counts file
    long  child_06 = 0;
    long  child_0A = 0;
    long  child_calibration = 0;
};

struct Watchdog {
    HANDLE process;
    volatile LONG* fired;
};

static DWORD WINAPI watchdog_proc(LPVOID param) {
    Watchdog* w = static_cast<Watchdog*>(param);
    if (WaitForSingleObject(w->process, 15000) == WAIT_TIMEOUT) {
        *w->fired = 1;
        TerminateProcess(w->process, 0xDEADu);
    }
    return 0;
}

static void child_counts_path(char* out, size_t cap, const char* exe, const char* mode) {
    char dir[MAX_PATH] = {};
    std::snprintf(dir, sizeof(dir), "%s", exe);
    if (char* slash = std::strrchr(dir, '\\'))
        *slash = '\0';
    else
        std::snprintf(dir, sizeof(dir), ".");
    std::snprintf(out, cap, "%s\\debugger_gate_child_%s.txt", dir, mode);
}

static void read_child_counts(ArmResult& r, const char* path) {
    FILE* f = nullptr;
    if (fopen_s(&f, path, "r") != 0) return;
    long a = 0, b = 0, c = 0;
    if (fscanf_s(f, "%ld %ld %ld", &a, &b, &c) == 3) {
        r.child_06 = a;
        r.child_0A = b;
        r.child_calibration = c;
        r.has_child_counts = true;
    }
    std::fclose(f);
}

// Spawn this exe under DEBUG_ONLY_THIS_PROCESS and play debugger for it.
//
// Print-code first chances are declined (DBG_EXCEPTION_NOT_HANDLED): that is
// what lets the debuggee's own vectored handlers see the event, which is the
// half under test -- DBG_CONTINUE there would handle the exception IN THE
// DEBUGGER, the child would never run its handler, and the arm would pass while
// testing nothing. Second chances are continued: on a classic-delivery machine
// that is the human pressing Continue in WinDbg, and the debuggee must survive
// it to write its counts.
static ArmResult run_debugger_arm(const char* mode) {
    ArmResult r;

    char exe[MAX_PATH] = {};
    if (GetModuleFileNameA(nullptr, exe, MAX_PATH) == 0) return r;
    char counts_path[MAX_PATH] = {};
    child_counts_path(counts_path, sizeof(counts_path), exe, mode);
    DeleteFileA(counts_path); // never read a previous run's file as this run's

    char cmd[MAX_PATH * 2 + 64] = {};
    std::snprintf(cmd, sizeof(cmd), "\"%s\" --debuggee %s \"%s\"", exe, mode, counts_path);

    STARTUPINFOA si{};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    if (!CreateProcessA(nullptr, cmd, nullptr, nullptr, FALSE,
                        DEBUG_ONLY_THIS_PROCESS, nullptr, nullptr, &si, &pi))
        return r;
    r.started = true;

    volatile LONG watchdog_fired = 0;
    Watchdog watchdog{ pi.hProcess, &watchdog_fired };
    HANDLE watchdog_thread =
        CreateThread(nullptr, 0, watchdog_proc, &watchdog, 0, nullptr);

    bool saw_loader_breakpoint = false;
    while (!r.exited) {
        DEBUG_EVENT de{};
        if (!WaitForDebugEvent(&de, 15000)) break; // no event, not even the exit
        // Every event is printed. When this arm fails its counters are the whole
        // story, and a count of zero has two very different causes -- the event
        // never arrived, or it arrived as something else (an
        // OUTPUT_DEBUG_STRING_EVENT is not an exception) -- which a summary
        // cannot tell apart.
        std::printf("      [debuggee %lu] event %lu", de.dwProcessId, de.dwDebugEventCode);
        if (de.dwDebugEventCode == EXCEPTION_DEBUG_EVENT)
            std::printf(" exception 0x%08lX first=%lu",
                        static_cast<unsigned long>(
                            de.u.Exception.ExceptionRecord.ExceptionCode),
                        static_cast<unsigned long>(de.u.Exception.dwFirstChance));
        else if (de.dwDebugEventCode == OUTPUT_DEBUG_STRING_EVENT)
            // len and unicode only: lpDebugStringData is not necessarily valid
            // in the debugger's address space, and dereferencing it was
            // measured to kill this process.
            std::printf(" string len=%u unicode=%u",
                        static_cast<unsigned>(de.u.DebugString.nDebugStringLength),
                        static_cast<unsigned>(de.u.DebugString.fUnicode));
        std::printf("\n");

        DWORD disposition = DBG_CONTINUE;
        switch (de.dwDebugEventCode) {
        case CREATE_PROCESS_DEBUG_EVENT:
            if (de.u.CreateProcessInfo.hFile) CloseHandle(de.u.CreateProcessInfo.hFile);
            break;
        case EXCEPTION_DEBUG_EVENT: {
            const DWORD code = de.u.Exception.ExceptionRecord.ExceptionCode;
            const bool first = de.u.Exception.dwFirstChance != 0;
            if (code == 0x40010006 || code == 0x4001000A) {
                if (first) {
                    ++r.first_prints;
                    disposition = DBG_EXCEPTION_NOT_HANDLED;
                } else {
                    ++r.second_prints;
                    disposition = DBG_CONTINUE;
                }
            } else if (code == 0xE06D7363) {
                if (first) ++r.calibration_first;
                else ++r.calibration_second;
                disposition = first ? DBG_EXCEPTION_NOT_HANDLED : DBG_CONTINUE;
            } else if (first && !saw_loader_breakpoint) {
                saw_loader_breakpoint = true; // ntdll's initial attach breakpoint
                disposition = DBG_CONTINUE;
            } else if (!first) {
                ++r.unexpected_second_chance;
                disposition = DBG_CONTINUE;
            } else {
                disposition = DBG_EXCEPTION_NOT_HANDLED;
            }
            break;
        }
        case OUTPUT_DEBUG_STRING_EVENT:
            ++r.string_events;
            break;
        case EXIT_PROCESS_DEBUG_EVENT:
            r.exit_code = de.u.ExitProcess.dwExitCode;
            r.exited = true;
            break;
        default:
            break; // threads, dll loads, rips: nothing to count
        }
        ContinueDebugEvent(de.dwProcessId, de.dwThreadId, disposition);
    }

    if (watchdog_thread) {
        // Wakes immediately once the child is gone; if it fired, it is already
        // done terminating the child, and the loop above has seen the exit.
        WaitForSingleObject(watchdog_thread, 20000);
        CloseHandle(watchdog_thread);
    }
    r.watchdog_fired = watchdog_fired != 0;
    if (!r.exited) {
        TerminateProcess(pi.hProcess, 0xDEADu);
        r.watchdog_fired = true;
    }
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    read_child_counts(r, counts_path);
    return r;
}

static void print_arm(const char* label, const ArmResult& r) {
    std::printf("    %s: strings=%d first_prints=%d second_prints=%d "
                "calibration=%d/%d unexpected_second=%d | child VEH saw "
                "06=%ld 0A=%ld calibration=%ld%s | exit=0x%08lX%s%s\n",
                label, r.string_events, r.first_prints, r.second_prints,
                r.calibration_first, r.calibration_second, r.unexpected_second_chance,
                r.child_06, r.child_0A, r.child_calibration,
                r.has_child_counts ? "" : " (NO COUNTS FILE)",
                static_cast<unsigned long>(r.exit_code),
                r.watchdog_fired ? " WATCHDOG" : "",
                r.exited ? "" : " NO EXIT EVENT");
}

// Call the REAL handler directly, with a fabricated record and a real stack
// pointer, and return its disposition.
//
// Safe for the codes this test passes because none of them reaches
// report_fatal(): the debugger codes stop at the gate, and 0xE06D7363 is
// captured but never reported. A fatal code would emit a crash report for a
// crash that did not happen, so the assertion for real faults stays on the
// predicates (checked name by name above) rather than down here.
static LONG call_handler(uint32_t code) {
    EXCEPTION_RECORD record{};
    record.ExceptionCode = code;
    CONTEXT context{};
    RtlCaptureContext(&context);
    EXCEPTION_POINTERS pointers{};
    pointers.ExceptionRecord = &record;
    pointers.ContextRecord = &context;
    return crash_probe::handler(&pointers);
}

int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IONBF, 0); // a crashing diagnostic must not eat its own trace
    if (argc >= 4 && std::strcmp(argv[1], "--debuggee") == 0)
        return debuggee_main(argv[2], argv[3]);

    std::printf("debugger gate\n");

    const bool attached = true;
    const bool detached = false;

    std::printf("  debugger attached => skip the debugger codes, all five:\n");
    check(crash_probe::debugger_gate_skips(0x40010006, attached),
          "0x40010006 DBG_PRINTEXCEPTION_C IS skipped");
    check(crash_probe::debugger_gate_skips(0x4001000A, attached),
          "0x4001000A DBG_PRINTEXCEPTION_WIDE_C IS skipped");
    check(crash_probe::debugger_gate_skips(0x40010007, attached),
          "0x40010007 DBG_RIPEXCEPTION IS skipped");
    check(crash_probe::debugger_gate_skips(0x80000003, attached),
          "0x80000003 BREAKPOINT IS skipped");
    check(crash_probe::debugger_gate_skips(0x80000004, attached),
          "0x80000004 SINGLE_STEP IS skipped");

    std::printf("  debugger attached => real faults still captured:\n");
    check(!crash_probe::debugger_gate_skips(0xC0000005, attached),
          "0xC0000005 ACCESS_VIOLATION is NOT skipped");
    check(!crash_probe::debugger_gate_skips(0xC0000006, attached),
          "0xC0000006 IN_PAGE_ERROR is NOT skipped");
    check(!crash_probe::debugger_gate_skips(0xC000001D, attached),
          "0xC000001D ILLEGAL_INSTRUCTION is NOT skipped");
    check(!crash_probe::debugger_gate_skips(0xC0000025, attached),
          "0xC0000025 NONCONTINUABLE_EXCEPTION is NOT skipped");
    check(!crash_probe::debugger_gate_skips(0xC00000FD, attached),
          "0xC00000FD STACK_OVERFLOW is NOT skipped");
    check(!crash_probe::debugger_gate_skips(0xC0000374, attached),
          "0xC0000374 HEAP_CORRUPTION is NOT skipped");
    check(!crash_probe::debugger_gate_skips(0xC0000409, attached),
          "0xC0000409 FAST_FAIL is NOT skipped");
    check(!crash_probe::debugger_gate_skips(0xC0000602, attached),
          "0xC0000602 FAIL_FAST_EXCEPTION is NOT skipped");
    check(!crash_probe::debugger_gate_skips(0xE06D7363, attached),
          "0xE06D7363 C++ exception is NOT skipped");
    check(!crash_probe::debugger_gate_skips(0xDEADBEEF, attached),
          "an unknown code is NOT skipped");

    std::printf("  no debugger => nothing is skipped:\n");
    check(!crash_probe::debugger_gate_skips(0x40010006, detached),
          "0x40010006 is still captured with no debugger");
    check(!crash_probe::debugger_gate_skips(0x4001000A, detached),
          "0x4001000A is still captured with no debugger");
    check(!crash_probe::debugger_gate_skips(0x40010007, detached),
          "0x40010007 is still captured with no debugger");
    check(!crash_probe::debugger_gate_skips(0x80000003, detached),
          "BREAKPOINT is still captured with no debugger");
    check(!crash_probe::debugger_gate_skips(0x80000004, detached),
          "SINGLE_STEP is still captured with no debugger");
    check(!crash_probe::debugger_gate_skips(0xC0000005, detached),
          "ACCESS_VIOLATION is still captured with no debugger");

    std::printf("  consume predicate: print codes only, and only while attached:\n");
    check(crash_probe::debugger_gate_consumes(0x40010006, attached),
          "0x40010006 IS consumed while attached");
    check(crash_probe::debugger_gate_consumes(0x4001000A, attached),
          "0x4001000A IS consumed while attached");
    check(!crash_probe::debugger_gate_consumes(0x40010007, attached),
          "0x40010007 is NOT consumed (it carries no string)");
    check(!crash_probe::debugger_gate_consumes(0x80000003, attached),
          "BREAKPOINT is NOT consumed (consuming an int3 would loop it)");
    check(!crash_probe::debugger_gate_consumes(0x80000004, attached),
          "SINGLE_STEP is NOT consumed");
    check(!crash_probe::debugger_gate_consumes(0xC0000005, attached),
          "ACCESS_VIOLATION is NOT consumed");
    check(!crash_probe::debugger_gate_consumes(0x40010006, detached),
          "0x40010006 is NOT consumed with no debugger");
    check(!crash_probe::debugger_gate_consumes(0x4001000A, detached),
          "0x4001000A is NOT consumed with no debugger");
    check(!crash_probe::debugger_gate_consumes(0x80000003, detached),
          "BREAKPOINT is NOT consumed with no debugger");
    {
        // Structural, not a reading of the handler: a consumed code that was not
        // skipped would be routed into the capture path by a skips()-first
        // handler, and consuming a fault would change what a crash does.
        bool subset = true;
        for (uint32_t code : { 0x40010006u, 0x4001000Au, 0x40010007u, 0x80000003u,
                               0x80000004u, 0xE06D7363u, 0xC0000005u, 0xDEADBEEFu }) {
            if (crash_probe::debugger_gate_consumes(code, attached) &&
                !crash_probe::debugger_gate_skips(code, attached))
                subset = false;
        }
        check(subset, "every consumed code is also skipped (consumes is a subset of skips)");
    }

    // The handler reads the REAL IsDebuggerPresent(), so this arm asserts
    // whichever state this process is actually in and says which one that was.
    // Either way it pins the ordering -- consuming is consulted before skipping
    // -- which no predicate-level assertion can see.
    const bool live_attached = IsDebuggerPresent() != 0;
    std::printf("  the real handler's disposition (this process: %s):\n",
                live_attached ? "a debugger IS attached" : "no debugger");
    if (live_attached) {
        check(call_handler(0x40010006) == EXCEPTION_CONTINUE_EXECUTION,
              "handler CONSUMED 0x40010006");
        check(call_handler(0x4001000A) == EXCEPTION_CONTINUE_EXECUTION,
              "handler CONSUMED 0x4001000A");
        check(call_handler(0x40010007) == EXCEPTION_CONTINUE_SEARCH,
              "handler searched 0x40010007 rather than consuming it");
        check(call_handler(0x80000003) == EXCEPTION_CONTINUE_SEARCH,
              "handler searched BREAKPOINT -- never consumed");
        check(call_handler(0x80000004) == EXCEPTION_CONTINUE_SEARCH,
              "handler searched SINGLE_STEP -- never consumed");
        check(call_handler(0xE06D7363) == EXCEPTION_CONTINUE_SEARCH,
              "handler searched a C++ throw after capturing it");
    } else {
        check(call_handler(0x40010006) == EXCEPTION_CONTINUE_SEARCH,
              "no debugger: 0x40010006 keeps EXCEPTION_CONTINUE_SEARCH");
        check(call_handler(0x4001000A) == EXCEPTION_CONTINUE_SEARCH,
              "no debugger: 0x4001000A keeps EXCEPTION_CONTINUE_SEARCH");
        check(call_handler(0x40010007) == EXCEPTION_CONTINUE_SEARCH,
              "no debugger: 0x40010007 keeps EXCEPTION_CONTINUE_SEARCH");
        check(call_handler(0x80000003) == EXCEPTION_CONTINUE_SEARCH,
              "no debugger: BREAKPOINT keeps EXCEPTION_CONTINUE_SEARCH");
        check(call_handler(0x80000004) == EXCEPTION_CONTINUE_SEARCH,
              "no debugger: SINGLE_STEP keeps EXCEPTION_CONTINUE_SEARCH");
        check(call_handler(0xE06D7363) == EXCEPTION_CONTINUE_SEARCH,
              "a real code is captured and still returns EXCEPTION_CONTINUE_SEARCH");
    }

    // -----------------------------------------------------------------------
    // End to end: this exe as its own debuggee. See the file header for the two
    // measured delivery models and what each arm asserts under each.
    // -----------------------------------------------------------------------
    std::printf("  end-to-end: this exe as its own debuggee under "
                "DEBUG_ONLY_THIS_PROCESS\n");

    const ArmResult consume = run_debugger_arm("consume");
    print_arm("consume arm (the real handler)", consume);
    const ArmResult pass = run_debugger_arm("pass");
    print_arm("pass arm (negative control, plain CONTINUE_SEARCH)", pass);

    check(consume.started && pass.started, "both debuggees started");
    check(consume.has_child_counts && pass.has_child_counts,
          "both debuggees wrote their in-process VEH counts");
    check(consume.exited && !consume.watchdog_fired && consume.exit_code == 0,
          "the consume debuggee finished normally");
    check(pass.exited && !pass.watchdog_fired && pass.exit_code == 0,
          "the pass debuggee finished normally");
    check(consume.calibration_first >= 1 && pass.calibration_first >= 1,
          "the calibration throw reached the debugger FIRST-chance in both arms "
          "(the loop demonstrably receives exception events, so its zeros mean "
          "something)");
    check(consume.child_calibration >= 1 && pass.child_calibration >= 1,
          "the calibration throw reached the debuggees' VEHs (the child's "
          "in-process instrumentation is live)");
    check(consume.unexpected_second_chance == 0 && pass.unexpected_second_chance == 0,
          "no second-chance exception other than the print codes and the "
          "calibration, in either arm");

    // Which delivery model is this machine running? Classic = the print raises
    // arrive at the debugger as exceptions. Converted = the kernel turns them
    // into string events first and no print exception is ever delivered.
    const bool classic_delivery =
        consume.first_prints >= kMinPrintFirsts && pass.first_prints >= kMinPrintFirsts;
    const bool converted_delivery =
        consume.first_prints == 0 && pass.first_prints == 0 &&
        consume.string_events >= kMinStringEvents && pass.string_events >= kMinStringEvents;
    check(classic_delivery || converted_delivery,
          "the live debuggee matched ONE of the two measured delivery models "
          "(see the counter table above: classic needs >=3 first-chance prints "
          "per arm; converted needs 0 print exceptions and >=4 string events "
          "per arm)");

    if (classic_delivery) {
        std::printf("    model: CLASSIC -- print raises are delivered as "
                    "exceptions; the disposition arms are live\n");
        check(consume.second_prints == 0,
              "CLASSIC model, THE FIX: the consuming handler ends the sequence "
              "in-process -- ZERO second-chance print stops");
        check(pass.second_prints >= 1,
              "CLASSIC model, THE CONTROL: the pre-fix disposition DOES stop at "
              "second chance, so the consume arm's zero is not vacuous");
        check(consume.child_06 >= 2,
              "CLASSIC model: the consume debuggee's VEH saw the print raises "
              "in-process (delivery is real, not only to the debugger)");
    } else if (converted_delivery) {
        std::printf("    model: CONVERTED (this machine) -- the kernel turns the "
                    "print raises into string events before in-process delivery, "
                    "so the consume arm is DORMANT here; the classic arms above "
                    "are where the consumption is observable\n");
        check(consume.child_06 == 0 && consume.child_0A == 0,
              "CONVERTED model: the consume debuggee's VEH never saw a print "
              "raise (converted before in-process delivery)");
        check(pass.child_06 == 0 && pass.child_0A == 0,
              "CONVERTED model: the pass debuggee's VEH never saw one either");
    }

    std::printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "OK", g_failures);
    return g_failures ? 1 : 0;
}
