// Coverage for TarkovAddons/module/quest_objective_text.h.
//
// SCOPE, stated precisely, because the repo has been bitten by coverage claims
// that were wider than the cases that ran (tools/harness/README.md: "count the
// cases the runners execute"). This compiles the REAL header -- no copy of the
// logic, no stubs -- and covers every function in it:
//
//   plan_for, split_token_list, join_labels, truncate_text, same_label,
//   merge_duplicates, order_by_outstanding
//
// The header is its own file precisely so this is possible: quest_objectives.h
// holds the other half of the objective summary, the part that reads Conditions
// off a live quest, and it opens with the game's object model. Nothing here can
// reach that half, and this file makes no claim about it.

#include <cctype>
#include <iostream>
#include <string>
#include <vector>

#include "../../TarkovAddons/module/quest_objective_text.h"

namespace obj = quest_objectives;

static int g_pass = 0;
static int g_fail = 0;

static void check(const bool condition, const char* what) {
    if (condition) ++g_pass;
    else {
        ++g_fail;
        std::cout << "FAIL: " << what << "\n";
    }
}

static void check_eq_str(const std::string& got, const std::string& want, const char* what) {
    if (got == want) {
        ++g_pass;
        return;
    }
    ++g_fail;
    std::cout << "FAIL: " << what << "\n  got:  \"" << got << "\"\n  want: \"" << want << "\"\n";
}

// plan_for: the class-name -> verb table.
//
// The load-bearing cases are the ordering ones. ConditionPlaceBeacon and
// ConditionLeaveItemAtLocation both derive from ConditionZone, so a Zone test
// placed in front of them would relabel every beacon and item-drop as "Reach an
// area" -- wrong, and invisible to a reader who does not know the hierarchy.
static void test_plan_for() {
    check_eq_str(obj::plan_for("ConditionPlaceBeacon").verb, "Place a beacon at", "beacon verb");
    check_eq_str(obj::plan_for("ConditionLeaveItemAtLocation").verb, "Place", "leave-item verb");
    check_eq_str(obj::plan_for("ConditionZone").verb, "Reach", "zone verb");
    check_eq_str(obj::plan_for("ConditionInZone").verb, "Reach", "in-zone verb");
    // The two above are asserted separately from the derived ones on purpose:
    // swapping their order in plan_for is the specific regression this guards.
    check_eq_str(obj::plan_for("ConditionPlaceBeacon").fallback, "Place a beacon", "beacon fallback");
    check_eq_str(obj::plan_for("ConditionZone").fallback, "Reach an area", "zone fallback");

    check_eq_str(obj::plan_for("ConditionVisitPlace").verb, "Reach", "visit-place verb");
    check_eq_str(obj::plan_for("ConditionLocationTrigger").verb, "Reach", "location-trigger verb");
    check_eq_str(obj::plan_for("ConditionTransitionLocation").verb, "Take the transit", "transit verb");

    check_eq_str(obj::plan_for("ConditionFindItem").verb, "Find", "find verb");
    check_eq_str(obj::plan_for("ConditionHandoverItem").verb, "Hand over", "handover verb");
    check_eq_str(obj::plan_for("ConditionSellItemToTrader").verb, "Sell", "sell verb");
    check_eq_str(obj::plan_for("ConditionItem").verb, "Obtain", "item verb");
    check_eq_str(obj::plan_for("ConditionHasItem").verb, "Obtain", "has-item verb");
    check_eq_str(obj::plan_for("ConditionCompletableItem").verb, "Obtain", "completable-item verb");

    check_eq_str(obj::plan_for("ConditionKills").verb, "Eliminate", "kills verb");
    check_eq_str(obj::plan_for("ConditionSearchAndDestroy").verb, "Eliminate", "s&d verb");
    check_eq_str(obj::plan_for("ConditionHit").verb, "Hit", "hit verb");
    check_eq_str(obj::plan_for("ConditionShots").verb, "Fire", "shots verb");

    check_eq_str(obj::plan_for("ConditionWeaponAssembly").verb, "Assemble", "assembly verb");
    check_eq_str(obj::plan_for("ConditionSkill").verb, "Improve", "skill verb");
    check_eq_str(obj::plan_for("ConditionExperience").verb, "Gain experience in", "xp verb");
    check_eq_str(obj::plan_for("ConditionTraderLoyalty").verb, "Raise standing with", "loyalty verb");
    check_eq_str(obj::plan_for("ConditionTraderStanding").verb, "Raise standing with", "standing verb");
    check_eq_str(obj::plan_for("ConditionLevel").verb, "Reach level", "level verb");
    check_eq_str(obj::plan_for("ConditionPrestigeLevel").verb, "Reach level", "prestige verb");
    check_eq_str(obj::plan_for("ConditionLeagueRank").verb, "Reach league rank", "rank verb");
    check_eq_str(obj::plan_for("ConditionExitName").verb, "Extract via", "exit-name verb");
    check_eq_str(obj::plan_for("ConditionExitStatus").verb, "Extract via", "exit-status verb");
    check_eq_str(obj::plan_for("ConditionQuestTime").verb, "Survive", "quest-time verb");
    check_eq_str(obj::plan_for("ConditionHealth").verb, "Keep health", "health verb");
    check_eq_str(obj::plan_for("ConditionLocation").verb, "Reach", "location verb");
    check_eq_str(obj::plan_for("ConditionArenaEnemyPreset").verb, "Eliminate", "arena verb");

    // Every plan must carry BOTH strings. text_of concatenates `verb + " " +
    // names` unconditionally on the fallback path, so a null verb is a
    // std::string built from a null pointer, not a cosmetic gap.
    const char* classes[] = {
        "ConditionPlaceBeacon", "ConditionLeaveItemAtLocation", "ConditionZone", "ConditionInZone",
        "ConditionVisitPlace", "ConditionLocationTrigger", "ConditionTransitionLocation",
        "ConditionFindItem", "ConditionHandoverItem", "ConditionSellItemToTrader", "ConditionItem",
        "ConditionHasItem", "ConditionCompletableItem", "ConditionKills", "ConditionSearchAndDestroy",
        "ConditionHit", "ConditionShots", "ConditionWeaponAssembly", "ConditionSkill",
        "ConditionExperience", "ConditionTraderLoyalty", "ConditionTraderStanding", "ConditionLevel",
        "ConditionPrestigeLevel", "ConditionLeagueRank", "ConditionExitName", "ConditionExitStatus",
        "ConditionQuestTime", "ConditionTime", "ConditionHealth", "ConditionLocation",
        "ConditionArenaEnemyPreset", "ConditionSomethingNobodyHasWrittenYet",
    };
    for (const char* name : classes) {
        const auto plan = obj::plan_for(name);
        check(plan.verb != nullptr && plan.verb[0] != '\0', "verb is a non-empty string");
        check(plan.fallback != nullptr && plan.fallback[0] != '\0', "fallback is a non-empty string");
    }

    // An unknown class and a null class name both have to come back with a pair,
    // because strstr(nullptr, ...) is undefined and this is on the fallback path.
    const auto unknown = obj::plan_for("ConditionFromAFuturePatch");
    check(unknown.verb != nullptr && unknown.fallback != nullptr, "unknown class answered");
    const auto none = obj::plan_for(nullptr);
    check(none.verb != nullptr && none.fallback != nullptr, "null class name answered");
}

// split_token_list: one condition's target can be a comma-separated list.
static void test_split_token_list() {
    std::vector<std::string> out;

    obj::split_token_list("Scavs,Usec", out);
    check(out.size() == 2 && out[0] == "Scavs" && out[1] == "Usec", "comma split");

    out.clear();
    obj::split_token_list("Scavs;Usec;Respawn", out);
    check(out.size() == 3 && out[2] == "Respawn", "semicolon split");

    out.clear();
    obj::split_token_list("Mixed,Separators;Here", out);
    check(out.size() == 3, "mixed separators");

    // Empty fields must not produce empty labels: a trailing comma is not a
    // target, and an empty string joins as "" and renders as a stray comma.
    out.clear();
    obj::split_token_list(",Scavs,,", out);
    check(out.size() == 1 && out[0] == "Scavs", "empty fields dropped");

    out.clear();
    obj::split_token_list("   ", out);
    // A whitespace-only field is a token, not an empty one -- only the separators
    // produce empties. Asserted so the whitespace decision is on the record.
    check(out.size() == 1 && out[0] == "   ", "whitespace-only token survives");

    out.clear();
    obj::split_token_list("", out);
    check(out.empty(), "empty input yields nothing");

    out.clear();
    obj::split_token_list("Solo", out);
    check(out.size() == 1 && out[0] == "Solo", "single target passes through");

    out.clear();
    obj::split_token_list(",,;;,", out);
    check(out.empty(), "separators only yields nothing");

    // Out is appended to, not cleared: the caller owns the vector and may be
    // accumulating across fields.
    out.clear();
    obj::split_token_list("a,b", out);
    obj::split_token_list("c", out);
    check(out.size() == 3 && out[2] == "c", "second call appends");
}

// join_labels: the cap and the overflow marker.
static void test_join_labels() {
    check_eq_str(obj::join_labels({}), "", "empty joins to empty");
    check_eq_str(obj::join_labels({"Gold Star Balalaika"}), "Gold Star Balalaika", "single label");
    check_eq_str(obj::join_labels({"Gold Star Balalaika", "Pied Piper"}),
                 "Gold Star Balalaika, Pied Piper", "two labels");
    check_eq_str(obj::join_labels({"Gold Star Balalaika", "Pied Piper", "Red Rebel"}),
                 "Gold Star Balalaika, Pied Piper, Red Rebel", "three labels is the default cap");
    check_eq_str(obj::join_labels({"Gold Star Balalaika", "Pied Piper", "Red Rebel"}, 2),
                 "Gold Star Balalaika, Pied Piper +1", "explicit cap adds an overflow count");

    // The overflow count is the real remainder, not a fixed "+1".
    check_eq_str(obj::join_labels({"a", "b", "c", "d", "e"}, 3), "a, b, c +2",
                 "overflow count is the remainder");

    // Exactly at the cap: no marker. This is the off-by-one that makes a list of
    // exactly three grow a "+0".
    check_eq_str(obj::join_labels({"a", "b", "c"}, 3), "a, b, c", "at the cap adds no marker");
    check_eq_str(obj::join_labels({"a", "b", "c", "d"}, 3), "a, b, c +1", "one past the cap");

    // A limit of 0 shows nothing and counts everything, which is the honest
    // reading rather than an empty row with no explanation.
    check_eq_str(obj::join_labels({"a", "b"}, 0), " +2", "zero limit marks all as overflow");
}

// merge_duplicates: "summed up" is the feature, so the sum must actually sum.
static void test_merge_duplicates() {
    {
        // Two handovers of the same item become one row of 3.
        std::vector<obj::objective> lines = {
            {"Hand over Golden Star Balalaika", 1, 1, false, true},
            {"Hand over Golden Star Balalaika", 0, 2, false, true},
        };
        obj::merge_duplicates(lines);
        check(lines.size() == 1, "duplicates merged into one row");
        check(lines[0].current == 1, "current summed");
        check(lines[0].target == 3, "target summed");
    }

    {
        // Case-insensitive: two conditions can differ only in case after
        // localization, and they are still the same row.
        std::vector<obj::objective> lines = {
            {"Eliminate SCAVS", 1, 2, false, true},
            {"Eliminate scavs", 1, 2, false, true},
        };
        obj::merge_duplicates(lines);
        check(lines.size() == 1, "merge is case-insensitive");
        check(lines[0].current == 2, "case-insensitive merge sums current");
        check(lines[0].target == 4, "case-insensitive merge sums target");
    }

    {
        // done is the AND. OR-ing would show a quest as complete while one of
        // its three identical objectives is still outstanding.
        std::vector<obj::objective> lines = {
            {"Find Intel", 1, 1, true, false},
            {"Find Intel", 0, 1, false, false},
        };
        obj::merge_duplicates(lines);
        check(lines.size() == 1, "mixed-done rows merged");
        check(!lines[0].done, "done is AND across merged rows");
    }

    {
        std::vector<obj::objective> lines = {
            {"Find Intel", 1, 1, true, false},
            {"Find Intel", 1, 1, true, false},
        };
        obj::merge_duplicates(lines);
        check(lines[0].done, "all-done rows stay done");
    }

    {
        // has_count is OR'd. If either condition carries a number, the merged row
        // must show the count or the summed total would be hidden.
        std::vector<obj::objective> lines = {
            {"Reach a location", 0, 0, false, false},
            {"Reach a location", 0, 2, false, true},
        };
        obj::merge_duplicates(lines);
        check(lines[0].has_count, "has_count survives a merge with a counted row");
        check(lines[0].target == 2, "target summed into a tick-box row");
    }

    {
        // has_count stays false when neither side had one, even though the merged
        // target is nonzero: "0/0" is not a thing.
        std::vector<obj::objective> lines = {
            {"Place a beacon", 0, 0, false, false},
            {"Place a beacon", 0, 0, false, false},
        };
        obj::merge_duplicates(lines);
        check(!lines[0].has_count, "has_count not invented by a merge");
    }

    {
        // Distinct labels stay separate. The obvious bad merge merges on anything
        // but the label.
        std::vector<obj::objective> lines = {
            {"Eliminate Scavs", 0, 3, false, true},
            {"Eliminate Usec", 0, 2, false, true},
        };
        obj::merge_duplicates(lines);
        check(lines.size() == 2, "distinct labels stay distinct");
    }

    {
        // One group of three, interleaved with a different label: the merge must
        // find the existing group rather than only comparing neighbours.
        std::vector<obj::objective> lines = {
            {"Eliminate Scavs", 1, 1, false, true},
            {"Eliminate Usec", 1, 1, false, true},
            {"Eliminate Scavs", 1, 1, false, true},
            {"Eliminate Scavs", 1, 1, false, true},
        };
        obj::merge_duplicates(lines);
        check(lines.size() == 2, "interleaved duplicates all merge");
        check(lines[0].text == "Eliminate Scavs" && lines[0].target == 3, "non-adjacent merge sums");
        check(lines[1].text == "Eliminate Usec" && lines[1].target == 1, "the other group untouched");
    }

    {
        // The first row's text is the one kept, so the merged row reads as the
        // quest declared it rather than as whichever copy came last.
        std::vector<obj::objective> lines = {
            {"Hand over Pied Piper", 0, 1, false, true},
            {"hand over pied piper", 0, 1, false, true},
        };
        obj::merge_duplicates(lines);
        check(lines[0].text == "Hand over Pied Piper", "the first spelling is kept");
    }

    {
        // Degenerate inputs must not crash or corrupt.
        std::vector<obj::objective> none;
        obj::merge_duplicates(none);
        check(none.empty(), "empty input stays empty");

        std::vector<obj::objective> one = {{"Only", 0, 1, false, true}};
        obj::merge_duplicates(one);
        check(one.size() == 1 && one[0].current == 0 && one[0].target == 1, "single row untouched");
    }
}

// order_by_outstanding: what is left to do comes first.
static void test_order_by_outstanding() {
    {
        std::vector<obj::objective> lines = {
            {"Done one", 1, 1, true, false},
            {"Outstanding", 0, 5, false, true},
            {"Done two", 1, 1, true, false},
            {"Also outstanding", 2, 5, false, true},
        };
        obj::order_by_outstanding(lines);
        check(!lines[0].done && !lines[1].done, "outstanding rows sort first");
        check(lines[2].done && lines[3].done, "done rows sort last");
        check(lines[0].text == "Outstanding" && lines[1].text == "Also outstanding",
              "order within the outstanding group is the quest's own");
        check(lines[2].text == "Done one" && lines[3].text == "Done two",
              "order within the done group is the quest's own");
    }

    {
        // All one or the other: the sort must be a no-op rather than a shuffle,
        // because the quest's declaration order IS the journal's order.
        std::vector<obj::objective> pending = {
            {"a", 0, 1, false, false}, {"b", 0, 1, false, false}, {"c", 0, 1, false, false},
        };
        obj::order_by_outstanding(pending);
        check(pending[0].text == "a" && pending[1].text == "b" && pending[2].text == "c",
              "uniform-pending input keeps declaration order");

        std::vector<obj::objective> done = {
            {"a", 1, 1, true, false}, {"b", 1, 1, true, false}, {"c", 1, 1, true, false},
        };
        obj::order_by_outstanding(done);
        check(done[0].text == "a" && done[1].text == "b" && done[2].text == "c",
              "uniform-done input keeps declaration order");
    }

    {
        std::vector<obj::objective> none;
        obj::order_by_outstanding(none);
        check(none.empty(), "empty input stays empty");

        std::vector<obj::objective> one = {{"a", 0, 1, false, false}};
        obj::order_by_outstanding(one);
        check(one.size() == 1, "single row stays one row");
    }

    {
        // The two passes in the order quest_objectives::collect runs them:
        // merge, then order. Asserted together because the order of those two
        // calls is a real decision -- sorting first then merging is equally valid
        // for a single pass, but the merge is what makes the sort cheap.
        //
        // The expected order here is "Find Intel" FIRST, and that is the point of
        // the assertion: both merged rows end up outstanding (the merge ANDs the
        // done flags, and only one of the two Find Intel conditions was done), so
        // the sort has nothing to move and stable order keeps the quest's own.
        // An earlier version of this test asserted the opposite -- that
        // Eliminate Scavs came first -- which is only true if the merge ORs the
        // done flags. It failed against the correct AND, and the fix was to the
        // test: merge_duplicates already had its own assertion for the AND case,
        // so this one was asserting the merge behaviour twice, wrongly.
        std::vector<obj::objective> lines = {
            {"Find Intel", 1, 1, true, false},
            {"Find Intel", 0, 2, false, true},
            {"Eliminate Scavs", 0, 3, false, true},
        };
        obj::merge_duplicates(lines);
        check(lines.size() == 2, "merged to two rows");
        check(lines[0].text == "Find Intel" && lines[0].target == 3 && !lines[0].done,
              "merged row summed and still outstanding");
        obj::order_by_outstanding(lines);
        check(lines[0].text == "Find Intel", "declaration order kept when both are outstanding");
        check(lines[1].text == "Eliminate Scavs", "second row unchanged by the sort");
    }
}

// truncate_text: the UTF-8 boundary.
//
// A description that is mostly one very long item name is the case. Cutting
// mid-codepoint leaves a dangling lead byte and ImGui renders the rest as
// replacement characters, so the assertion is that the result is still valid
// UTF-8 -- not merely that it got shorter.
static void test_truncate_text() {
    // 3-byte codepoints against a cap that is not a multiple of 3.
    std::string three_byte;
    for (int i = 0; i < 60; ++i) three_byte += "\xE2\x9C\x93";

    std::string text = three_byte;
    obj::truncate_text(text);
    check(text.size() <= obj::kMaxTextLen, "3-byte text capped");
    check(text.size() % 3 == 0, "3-byte text cut on a codepoint boundary");

    // 4-byte codepoints against a cap that is not a multiple of 4.
    std::string four_byte;
    for (int i = 0; i < 50; ++i) four_byte += "\xF0\x9F\x98\x80";
    text = four_byte;
    obj::truncate_text(text);
    check(text.size() <= obj::kMaxTextLen, "4-byte text capped");
    check(text.size() % 4 == 0, "4-byte text cut on a codepoint boundary");

    // 2-byte codepoints against a cap that IS a multiple of 2, so this one is
    // about not cutting at all rather than about the boundary walk.
    std::string two_byte;
    for (int i = 0; i < 90; ++i) two_byte += "\xC3\xA9";
    text = two_byte;
    obj::truncate_text(text);
    check(text.size() <= obj::kMaxTextLen, "2-byte text capped");
    check(text.size() % 2 == 0, "2-byte text cut on a codepoint boundary");

    // Nothing to do when already short, and nothing to do when exactly at the cap.
    text = "Short";
    obj::truncate_text(text);
    check(text == "Short", "short text untouched");

    text = std::string(obj::kMaxTextLen, 'x');
    obj::truncate_text(text);
    check(text.size() == obj::kMaxTextLen, "exact-cap text untouched");

    text = std::string(obj::kMaxTextLen + 1, 'x');
    obj::truncate_text(text);
    check(text.size() == obj::kMaxTextLen, "one over the cap is trimmed to it");

    // A multi-byte sequence that STARTS exactly at the cap index: the walk has to
    // move the cut back to the lead byte before it, not leave the lead behind.
    text = std::string(obj::kMaxTextLen - 1, 'x') + "\xE2\x9C\x93";
    obj::truncate_text(text);
    check(text.size() == obj::kMaxTextLen - 1, "a codepoint starting at the cap is dropped whole");

    // Empty input must not underflow the `cut > 0` loop.
    text.clear();
    obj::truncate_text(text);
    check(text.empty(), "empty text stays empty");
}

// same_label: the merge key.
static void test_same_label() {
    check(obj::same_label("Find Intel", "find intel"), "case-insensitive equal");
    check(obj::same_label("FIND INTEL", "find Intel"), "mixed-case equal");
    check(!obj::same_label("Find Intel", "Find Intel "), "trailing space differs");
    check(!obj::same_label("Find Intel", "Find Intek"), "one character differs");
    check(!obj::same_label("a", "A "), "different lengths differ");
    check(obj::same_label("", ""), "empty equals empty");
    check(!obj::same_label("", "x"), "empty is not equal to non-empty");

    // fold_ascii is ASCII-ONLY, and these two are what make that a recorded
    // property rather than an assumption.
    //
    // The Cyrillic pair is the measured case: "Тест" and "тест" differ in the
    // second byte (A2 vs B2) and the C locale's tolower leaves both alone, so a
    // compare built on std::tolower reports them unequal. That is now documented
    // in quest_objective_text.h and asserted here, so the limitation is a
    // regression test rather than something a reader has to re-derive.
    check(!obj::same_label("\xD0\xA2\xD0\xB5\xD1\x81\xD1\x82", "\xD0\xB2\xD0\xB5\xD1\x81\xD1\x82"),
          "Cyrillic case difference is NOT folded (documented limit)");
    check(obj::same_label("\xD0\xA2\xD0\xB5\xD1\x81\xD1\x82", "\xD0\xA2\xD0\xB5\xD1\x81\xD1\x82"),
          "identical non-ASCII still equal");
    check(!obj::same_label("\xD0\xA2", "\xD0\xB0"), "non-ASCII difference is still a difference");

    // The fold's range boundary is A-Z exactly (0x41-0x5A), and these are the
    // bytes where a cheaper implementation diverges:
    //
    //   - '@' is 0x40, one BELOW 'A', so it must NOT fold. The usual one-liner
    //     `(c | 0x20)` maps it to '`' (0x60), so same_label("@", "`") would be
    //     true under that fold and false here.
    //   - '[' is 0x5B, one ABOVE 'Z'. `c | 0x20` happens to leave it alone, so it
    //     is asserted anyway as the upper bound.
    //
    // Getting '@' wrong is a real, if small, false-merge: two different
    // objectives would share a row.
    check(obj::fold_ascii('@') == '@', "'@' (0x40) is below the range and does not fold");
    check(obj::fold_ascii('A') == 'a', "'A' folds");
    check(obj::fold_ascii('Z') == 'z', "'Z' folds");
    check(obj::fold_ascii('[') == '[', "'[' (0x5B) is above the range");
    check(obj::fold_ascii('`') == '`', "'`' is already lower case");
    check(obj::fold_ascii('{') == '{', "'{' is above the range");
    check(!obj::same_label("@", "`"), "the '@'-vs-'`' false merge does not happen");
    check(obj::same_label("A", "a"), "A and a are the same row");

    // Bytes at and above 0x80 must pass through untouched: a continuation byte,
    // a UTF-8 lead byte, and DEL all have no ASCII case.
    check(obj::fold_ascii('\x7F') == '\x7F', "DEL is left alone");
    check(obj::fold_ascii('\x80') == '\x80', "a continuation byte is left alone");
    check(obj::fold_ascii('\xD0') == '\xD0', "a UTF-8 lead byte is left alone");
    check(obj::fold_ascii('\0') == '\0', "NUL is left alone");
}

namespace view = quest_objectives;

// The All view's shortfall arithmetic decides how many of the player's own quests the card
// admits it is hiding. It lived in build_snapshot() -- behind IL2CPP headers, so nothing could
// compile it -- for as long as it was wrong, and the cases below are chosen so that EACH one
// fails against a different version of the expression that shipped:
//
//   v1  requested - (capped ? limit : requested) - shown     clamped to 0
//   v2  requested - (capped ? limit : 0) - shown             clamped to 0
//   v3  requested - shown - capped_away                     clamped to 0   <- correct
static void test_all_view_unreadable() {
    using quest_objectives::all_view_unreadable;

    // The identity the card depends on: every listed quest is shown, capped away, or
    // produced no rows. These three must sum to `requested` for the message to be honest.
    check(all_view_unreadable(8, 3, 0) == 5, "uncapped: 8 listed, 3 shown -> 5 unreadable");
    check(all_view_unreadable(36, 24, 12) == 0,
        "capped with nothing unreadable: 36 listed, 24 shown, 12 capped away -> 0");

    // THE DISCRIMINATING CASE. Four quests genuinely produced no rows while the cap dropped
    // twelve. v1 gives 36-24-20 = -8 -> 0 and v2 gives the same: both report "0 unreadable"
    // when the answer is 4, which is the count that tells the player four of their quests have
    // no checklist at all. Only v3 returns the truth.
    check(all_view_unreadable(36, 20, 12) == 4,
        "capped AND unreadable: 36 listed, 20 shown, 12 capped away -> 4 unreadable, not 0");

    // A cap that fired but dropped nothing (requested == shown, so capped_away == 0) must not
    // invent an unreadable count.
    check(all_view_unreadable(5, 5, 0) == 0, "nothing dropped and nothing unreadable -> 0");

    // Clamp. A negative answer is a bookkeeping bug, not a fact about the player, so it is
    // floored -- but the floor must not become the answer by default.
    check(all_view_unreadable(5, 10, 0) == 0, "over-reported shown count is clamped, not negative");
    check(all_view_unreadable(10, 3, 99) == 0, "an over-large capped_away is clamped");
}

static void test_all_view_rank() {
    using quest_objectives::all_view_rank;

    // The three buckets the card renders, and the only three: `known` false means the
    // conditions could not be walked, which is NOT the same answer as "not location-bound".
    check(all_view_rank(true, false) == quest_objectives::kAllViewAnywhere,
        "known and not zone-bound ranks as anywhere");
    check(all_view_rank(true, true) == quest_objectives::kAllViewZones,
        "known and zone-bound ranks as on-this-map");
    check(all_view_rank(false, false) == quest_objectives::kAllViewUnreadable,
        "unknown ranks as unreadable even with no zone");
    check(all_view_rank(false, true) == quest_objectives::kAllViewUnreadable,
        "unknown ranks as unreadable regardless of zone_bound");

    // THE PROPERTY THE CAP DEPENDS ON: lower rank is drawn first, so truncating by rank drops
    // from the BOTTOM of what the player reads. If this ordering is ever inverted the cap
    // starts eating the quests the card puts at the top, and nothing else notices.
    check(all_view_rank(true, false) < all_view_rank(true, true),
        "anywhere is drawn before zones");
    check(all_view_rank(true, true) < all_view_rank(false, false),
        "zones are drawn before unreadable");

    // !known must never outrank a known quest, whatever zone_bound says. Conflating "unknown"
    // with "not location-bound" claims an unreadable quest is doable anywhere.
    check(all_view_rank(false, true) > all_view_rank(true, true),
        "an unreadable quest never outranks a readable location-bound one");
    check(all_view_rank(false, false) > all_view_rank(true, false),
        "an unreadable quest never outranks a readable anywhere one");
}

int main() {
    test_plan_for();
    test_split_token_list();
    test_join_labels();
    test_merge_duplicates();
    test_order_by_outstanding();
    test_truncate_text();
    test_same_label();
    test_all_view_unreadable();
    test_all_view_rank();

    std::cout << (g_fail == 0 ? "PASS" : "FAIL") << ": " << g_pass << " passed, "
              << g_fail << " failed\n";
    return g_fail == 0 ? 0 : 1;
}