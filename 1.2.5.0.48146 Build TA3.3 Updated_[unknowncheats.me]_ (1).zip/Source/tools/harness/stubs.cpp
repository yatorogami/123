// Link-time stubs for the native harness.
//
// ConfigValue::get_imgui_title() and ConfigValue::get_tooltip() call i18n::tr,
// which is declared in util/i18n.h and defined in util/i18n.cpp. i18n.cpp is
// Windows-only, so the harness supplies the two definitions itself.
//
// The stub models the REAL ORDERING, not a convenient one.
// --------------------------------------------------------------------------
// i18n::tr() answers an unloaded translation map by returning the key, and the
// map is empty until i18n::init() runs. In the DLL that happens at
// ConfigModule::init(), inside ModuleManager::init() -- and `new
// ModuleManager()` has already constructed every module, tooltips included,
// before that point ever runs.
//
// `translations_loaded` is the flag that says whether we are before or after
// that. It starts FALSE, which is exactly the state a module constructor sees.
//
// This is why an identity stub cannot test the defect it guards against: under
// an identity stub, "the key was passed through and translated later" and
// "tr() was called during construction, found an empty map, and cached the key"
// produce the SAME string. The one test that mattered compared nothing.
// With a state-dependent stub the two are finally different, and the harness
// case can name the regression.
//
// When loaded, the stub wraps the key so a caller can tell a translation apart
// from a bare key.
//
// This still does NOT test the translation table -- there is no real table here.
// It tests that the key reaches the translation layer with the right name, and
// at the right TIME. The table remains uncovered anywhere; see
// tools/harness/README.md.

#include <string>

namespace i18n {
    // False until the harness case says otherwise. Defined here, declared extern
    // by the case that flips it -- it is test state, not part of the interface.
    bool translations_loaded = false;

    std::string tr(const char* key)
    {
        if (!key || !*key)
            return {};
        const std::string k(key);
        return translations_loaded ? "[tr]" + k : k;
    }

    std::string tr(const std::string& key)
    {
        if (key.empty())
            return key;
        return translations_loaded ? "[tr]" + key : key;
    }
} // namespace i18n
