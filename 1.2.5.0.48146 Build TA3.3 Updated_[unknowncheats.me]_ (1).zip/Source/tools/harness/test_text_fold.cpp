// Coverage for TarkovAddons/util/text_fold.h -- the UTF-8 case folding the item
// search needs.
//
// WHY THIS CASE EXISTS AND WHY IT IS NOT NOWHERE-CLOSE TO test_loot_categories
// -------------------------------------------------------------------------
// The item search matched with std::transform + std::tolower over both the stored
// name and the query. std::tolower is the C library's, and the C library sits in
// the "C" locale unless something calls setlocale -- nothing in this project does
// -- so it folds A-Z and returns EVERY OTHER BYTE UNCHANGED. 5947 of 6001 item
// names resolve to a LOCALIZED string, so for a Russian or Greek player the search
// matched nothing: the stored name is "Бинт", the typed query is "бинт", and the
// fold leaves both sides alone because Cyrillic bytes are outside A-Z.
//
// The project had already measured and documented this exact limitation, in
// quest_objective_text.h, where it was ACCEPTABLE: that merge key compares two
// rows the same locale already produced, so they are byte-identical and the fold
// is a bonus. A search is the opposite -- the two sides come from different
// sources and differ only by case -- so the fold is the mechanism. Same
// limitation, opposite consequence, which is why a second fold was needed rather
// than the first being widened.
//
// This header is header-only with no IL2CPP, no ImGui and no Win32, so this case
// needs neither the shim nor the i18n stub that config's case needs.

#include <cstdint>
#include <iostream>
#include <string>

#include "../../TarkovAddons/util/text_fold.h"

static int g_pass = 0;
static int g_fail = 0;

static void check(const bool condition, const char* what) {
    if (condition) ++g_pass;
    else {
        ++g_fail;
        std::cout << "  FAIL: " << what << "\n";
    }
}

static void eq(const std::string& got, const std::string& want, const char* what) {
    if (got == want) ++g_pass;
    else {
        ++g_fail;
        std::cout << "  FAIL: " << what << "\n    got  " << got << "\n    want " << want << "\n";
    }
}

int main() {
    namespace tf = text_fold;

    // ---- 1. ASCII -- the case that already worked, and must not regress -----
    eq(tf::folded("HELLO"), "hello", "ASCII uppercase folds");
    eq(tf::folded("hello"), "hello", "ASCII lowercase is unchanged");
    eq(tf::folded("Hello World 123"), "hello world 123", "mixed ASCII folds, digits kept");

    // ---- 2. Cyrillic -- the measured failure this whole header exists for ---
    // UTF-8 for the lowercase and uppercase forms. These are different byte
    // sequences, which is precisely why std::tolower cannot join them.
    eq(tf::folded("\xD0\x91\xD0\xB8\xD0\xBD\xD1\x82"),           // Бинт
       "\xD0\xB1\xD0\xB8\xD0\xBD\xD1\x82",                        // бинт
       "Cyrillic uppercase folds to lowercase");
    eq(tf::folded("\xD0\x91\xD0\x98\xD0\x9D\xD0\xA2"),           // БИНТ
       "\xD0\xB1\xD0\xB8\xD0\xBD\xD1\x82",                        // бинт
       "Cyrillic all-caps folds to the same lowercase");
    // Ё (D0 81) / ё (D1 91): the pair that straddles the main Cyrillic block, so
    // it needs its own offset rather than the block's +0x20.
    eq(tf::folded("\xD0\x81"), "\xD1\x91", "Cyrillic Yo folds");
    eq(tf::folded("\xD0\x81\xD0\x96"), "\xD1\x91\xD0\xB6", "Yo and Zh fold together");

    // ---- 3. Greek ------------------------------------------------------------
    eq(tf::folded("\xCE\x91\xCF\x83\xCE\xBA\xCF\x8C\xCF\x82"),   // Ασκός
       "\xCE\xB1\xCF\x83\xCE\xBA\xCF\x8C\xCF\x82",                // ασκός
       "Greek uppercase folds");
    // U+03A2-03AB is UNASSIGNED in the uppercase block. Folding the whole span
    // would map an unassigned slot onto a live lowercase letter and make two
    // different names compare equal; the two assigned islands are listed instead.
    eq(tf::folded("\xE2\x9F\xAF"), "\xE2\x9F\xAF",              // U+037F (unassigned)
       "an unassigned code point is left unchanged");

    // ---- 4. Latin-1 and Latin Extended-A -------------------------------------
    eq(tf::folded("\xC3\x80\xC3\x89\xC3\x8E"), "\xC3\xA0\xC3\xA9\xC3\xAE", // ÀÉÎ -> àéî
       "Latin-1 accented uppercase folds");
    eq(tf::folded("\xC5\x81\xC3\x93\xC5\x9A"), "\xC5\x82\xC3\xB3\xC5\x9B", // ŁÓŚ -> łóś
       "Latin Extended-A folds (the odd/even parity case)");
    // U+00D7 is the multiplication sign and U+00F7 the division sign. Both sit
    // inside the Latin-1 letter block, both are NOT letters.
    eq(tf::folded("\xC3\x97"), "\xC3\x97", "multiplication sign is not folded");
    eq(tf::folded("\xC3\xB7"), "\xC3\xB7", "division sign is not folded");

    // ---- 5. Idempotence and length -------------------------------------------
    // build_index() re-folds names a previous generation may already have folded,
    // so folding an already-folded string must be a no-op. If it were not, the
    // index would drift one generation per db republish.
    for (const std::string& s : {std::string("Hello"),
                                 std::string("\xD0\x91\xD0\xB8\xD0\xBD\xD1\x82"),
                                 std::string("\xCE\x91\xCF\x83\xCE\xBA\xCF\x8C\xCF\x82")}) {
        const std::string once = tf::folded(s);
        eq(tf::folded(once), once, "folding is idempotent");
    }
    // A fold must not change length for any covered range, or a caller comparing
    // folded strings would break on the mismatch.
    {
        const std::string mixed = "Ab cd \xD0\x91\xD1\x91 \xCE\xB1\xC3\x89";
        const std::string folded = tf::folded(mixed);
        check(folded.size() == mixed.size(),
              "folding covered scripts preserves byte length");
    }

    // ---- 6. Malformed input advances rather than looping -----------------------
    // A naive decoder that does not advance on a bad byte spins forever; the
    // search index is built from raw game bytes, so this must terminate.
    {
        const std::string bad = "\xC3";                       // truncated 2-byte lead
        eq(tf::folded(bad), bad, "a truncated sequence round-trips unchanged");
    }
    {
        // A lone continuation byte in the middle. These are not decodable, so the
        // fold must carry them through byte for byte -- an index that changed
        // length here would desynchronise every offset after it.
        const std::string bad2 = "a\x80\x80z";
        const std::string f2 = tf::folded(bad2);
        eq(f2, bad2, "stray continuation bytes are preserved byte for byte");
    }
    {
        // An over-long 4-byte lead with not enough bytes after it.
        const std::string bad3 = "\xF0\x9F";
        eq(tf::folded(bad3), bad3, "an unterminated 4-byte sequence round-trips");
    }

    // ---- 7. decode() contract -------------------------------------------------
    {
        char32_t cp = 0;
        std::size_t len = 0;
        tf::decode("abc", 0, cp, len);
        check(cp == U'a' && len == 1, "1-byte sequence: cp and length");
        tf::decode("x", 0, cp, len);
        check(cp == U'x' && len == 1, "1-byte at position 0");
        tf::decode("a\x07", 1, cp, len);
        check(cp == 7 && len == 1, "a second byte decodes standalone");
    }
    {
        char32_t cp = 0;
        std::size_t len = 0;
        tf::decode("\xD0\x91", 0, cp, len);                    // U+0411
        check(cp == 0x0411 && len == 2, "3-byte-encoded 2-byte Cyrillic: cp and length");
    }
    {
        char32_t cp = 0;
        std::size_t len = 0;
        tf::decode("\xE2\x9C\x93", 0, cp, len);                // U+2713, a 3-byte seq
        check(cp == 0x2713 && len == 3, "3-byte sequence: cp and length");
    }
    {
        char32_t cp = 0;
        std::size_t len = 0;
        tf::decode("\xF0\x9F\x98\x80", 0, cp, len);            // U+1F600
        check(cp == 0x1F600 && len == 4, "4-byte sequence: cp and length");
    }

    // ---- 8. contains_folded ---------------------------------------------------
    check(tf::contains_folded("loot case", "case"), "folded needle matches");
    check(tf::contains_folded("abc", "abc"), "needle at the end matches");
    check(!tf::contains_folded("abc", "abcd"), "a needle longer than the haystack does not match");
    check(tf::contains_folded("any", ""), "an empty needle matches everywhere");
    check(!tf::contains_folded("", "x"), "an empty haystack matches nothing");

    // ---- 9. The actual bug, end to end ----------------------------------------
    // Before text_fold: folded(query) != stored_name, because std::tolower only
    // folds A-Z. Assert the pair that used to fail.
    {
        const std::string stored = "\xD0\x91\xD0\xB8\xD0\xBD\xD1\x82";   // what the db holds
        const std::string typed = "\xD0\xB1\xD0\xB8\xD0\xBD\xD1\x82";    // what a player types
        check(!(stored == typed), "premise: the two forms really are different bytes");
        check(tf::folded(stored).find(typed) != std::string::npos,
              "the stored name now CONTAINS the folded query (the bug)");
    }

    std::cout << (g_fail ? "FAILED " : "ok ") << (g_pass + g_fail)
              << " assertions, " << g_fail << " failed\n";
    return g_fail ? 1 : 0;
}
