// Coverage for TarkovAddons/gui/menu/hotkey_conflicts.h -- which keybinds
// share a key, and which one sits on the menu toggle.
//
// WHY THIS EXISTS
//
// hotkeys::all() is one flat registry: every module pushes its bindings in
// and nothing compares them. Two features can end up on the same key and the
// panel shows two identical "[ F2 ]" buttons and no hint that pressing F2
// fires both. That is a silent failure of exactly the shape this project
// keeps paying for, and it is pure bookkeeping -- no ImGui, no game, no
// Win32 -- so the grouping lives in its own header and this compiles the real
// one, the same split as test_card_fold.cpp and test_column_layout.cpp.
//
// The one non-obvious rule, and the reason the case counts are what they are:
// key == 0 means UNBOUND and must never count as a collision. Two unbound rows
// are two rows that do nothing; treating them as a conflict would make the
// default configuration open with a page of collisions and teach the user to
// ignore the block.

#include <iostream>
#include <vector>

#include "../../TarkovAddons/gui/menu/hotkey_conflicts.h"

namespace hc = hotkey_conflicts;

static int g_pass = 0;
static int g_fail = 0;

static void check(const bool condition, const char* what) {
    if (condition) ++g_pass;
    else {
        ++g_fail;
        std::cout << "  FAIL: " << what << "\n";
    }
}

// Rows in the order the panel draws them, because that is the order the key
// fires them in and the report is expected to read the same way.
static std::vector<hc::row> rows(std::vector<std::tuple<int, const char*>> spec) {
    std::vector<hc::row> out;
    for (auto& [key, label] : spec)
        out.push_back({key, label, label});
    return out;
}

static std::string joined(const hc::group& g) {
    std::string s = std::to_string(g.key) + ":";
    for (const char* l : g.labels)
        s += std::string(" ") + l;
    return s;
}

int main() {
    // ---- 1. the shape of the thing ------------------------------------------
    // Premise, so nothing below can pass by parsing or grouping nothing.
    {
        const auto r = rows({{122, "God Mode"}, {122, "Noclip"}, {0, "Zoom"}});
        const auto conflicts = hc::find(r);
        check(conflicts.size() == 1, "two bindings on one key make exactly one group");
        if (!conflicts.empty()) {
            check(conflicts.front().key == 122, "the group names the key");
            check(joined(conflicts.front()) == "122: God Mode Noclip",
                "the group lists both actions, in panel order");
            check(!conflicts.front().reserved, "F11 is not the reserved menu key");
        }
    }

    // ---- 2. three on one key -------------------------------------------------
    {
        const auto conflicts = hc::find(rows({{122, "a"}, {122, "b"}, {122, "c"}}));
        check(conflicts.size() == 1 && conflicts.front().labels.size() == 3,
            "three bindings on one key are ONE group of three, not three groups");
    }

    // ---- 3. unbound never collides ------------------------------------------
    {
        // The default configuration: most bindings unbound. If 0 collided, this
        // would report one group per pair and the block would be noise.
        const auto conflicts = hc::find(rows({{0, "a"}, {0, "b"}, {0, "c"}}));
        check(conflicts.empty(), "unbound rows (key 0) do NOT conflict");
        const auto none = hc::find(rows({{122, "a"}, {123, "b"}}));
        check(none.empty(), "distinct keys do not conflict");
    }

    // ---- 4. the reserved menu toggle ----------------------------------------
    {
        // A single binding on INSERT is enough: menu::draw() reads INSERT
        // itself through GetAsyncKeyState, outside the binding system, so the
        // binding can never fire on its own terms.
        const auto conflicts = hc::find(rows({{hc::k_menu_toggle_key, "Rebind me"}}));
        check(conflicts.size() == 1, "one binding on the menu toggle IS a conflict");
        if (!conflicts.empty())
            check(conflicts.front().reserved, "and it is marked reserved");
        check(hc::k_menu_toggle_key == 0x2D,
            "the literal is the one hotkeys.h static_asserts against VK_INSERT");
    }

    // ---- 5. sorting, and mixed reserved/normal ------------------------------
    {
        const auto conflicts = hc::find(rows({
            {113, "F2 action"}, {122, "God Mode"}, {122, "Noclip"},
            {hc::k_menu_toggle_key, "Standalone"}, {112, "F1 A"}, {112, "F1 B"},
        }));
        // Expect: F1(112) two, F2(113) alone -> not a group, INSERT reserved,
        // F11(122) two. The F2 binding is unique, so it drops out entirely.
        check(conflicts.size() == 3, "only the keys with a collision or the reserved key survive");
        bool sorted = true;
        for (size_t i = 1; i < conflicts.size(); ++i)
            if (conflicts[i].key <= conflicts[i - 1].key) sorted = false;
        check(sorted, "groups are sorted by key ascending (a stable, scannable report)");
        if (conflicts.size() == 3) {
            // Sorted by key, and the reserved key is just a key: VK_INSERT is
            // 0x2D (45), which sorts BEFORE F1 (112) and F11 (122). That is
            // the arithmetic this test originally got wrong -- it assumed the
            // panel's visual order, but the report sorts by value, not by
            // where the key sits on the keyboard.
            check(conflicts[0].key == hc::k_menu_toggle_key, "INSERT first: it is key 45");
            check(conflicts[0].reserved && conflicts[0].labels.size() == 1,
                "the reserved group keeps its single label");
            check(conflicts[1].key == 112, "F1 second");
            check(conflicts[2].key == 122 && conflicts[2].labels.size() == 2, "F11 last, both actions");
        }
    }

    // ---- 6. empty input ------------------------------------------------------
    {
        const auto conflicts = hc::find({});
        check(conflicts.empty(), "no rows means no conflicts -- and the caller treats"
               " that as 'nothing to report', never as 'everything is fine'");
    }

    // ---- 7. the custom reserved key ------------------------------------------
    {
        // find() takes the reserved key as a parameter so the pure header needs
        // no <Windows.h>; a caller with a different menu key still works.
        const auto conflicts = hc::find(rows({{192, "tilde action"}}), /*reserved=*/192);
        check(conflicts.size() == 1 && conflicts.front().reserved,
            "a caller-supplied reserved key is honoured");
        const auto not_conflict = hc::find(rows({{192, "tilde action"}}), /*reserved=*/193);
        check(not_conflict.empty(), "and a non-matching reserved key does not flag it");
    }

    std::cout << (g_fail ? "FAILED " : "ok ") << (g_pass + g_fail)
              << " assertions, " << g_fail << " failed\n";
    return g_fail ? 1 : 0;
}
