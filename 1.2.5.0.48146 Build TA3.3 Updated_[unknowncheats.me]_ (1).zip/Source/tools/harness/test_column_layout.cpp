// Coverage for TarkovAddons/gui/menu/column_layout.h -- which menu card goes in which
// column, and where the boundary falls.
//
// WHY THIS EXISTS
//
// The layout used to be eleven `m->name == "..."` predicates inside menu.cpp's draw
// loop, all evaluated *after* the card had been drawn. That cost three defects in one
// afternoon, all the same shape, and none of them findable without launching a raid:
//
//   1. The Raid Dashboard boundary keyed on the Debug Log card, but Debug Log was
//      registered AFTER Favorites. So enabling "Show Debug Log" moved Favorites into
//      column 1 along with it and left the right column holding Configs alone. The
//      report was "the debug log and configs move to the left column".
//   2. Because the split was decided mid-draw, every pinned boundary needed a
//      matching "keep this left" opt-out, and those opt-outs had to cover a whole RUN
//      of cards -- the Profile page needed a paragraph explaining exactly that.
//   3. `##col2` could be opened twice in one frame, once by the split and once by the
//      hotkeys panel at the end.
//
// The fix is partition-then-draw: resolve the boundary from the cards that will
// actually be shown, before drawing any of them. That header is included here directly
// so this compiles the REAL table rather than a copy that can drift from it.
//
// The last case is the one that cannot be done here honestly, and it is the important
// one: the table keys on module NAMES, and the order it assumes comes from
// ModuleManager.h's declaration order. If a module is renamed, or reordered, the table
// silently stops matching and the layout goes wrong again with nothing failing. So
// the final case reads ModuleManager.h as text and asserts the names and the order.
// That is a source check rather than a compile-time one, because ModuleManager.h pulls
// in every module and cannot be built without the project. It is still worth more than
// nothing: the failure it catches is precisely one that is otherwise invisible until a
// user opens the menu.

#include <algorithm>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <string_view>
#include <vector>

#include "../../TarkovAddons/gui/menu/column_layout.h"

namespace cl = column_layout;

static int g_pass = 0;
static int g_fail = 0;

static void check(const bool condition, const char* what) {
    if (condition) ++g_pass;
    else {
        ++g_fail;
        std::cout << "  FAIL: " << what << "\n";
    }
}

// left/right as readable strings, so a failure prints the layout rather than a count.
static std::string shape(const ModuleCategory tab,
                         const std::vector<std::string_view>& cards,
                         const char* label) {
    const cl::Partition p = cl::partition(tab, cards);
    std::ostringstream os;
    os << label << ": ";
    for (size_t i = 0; i < cards.size(); ++i) {
        if (i) os << " | ";
        os << (static_cast<int>(i) < p.left_count ? "L:" : "R:") << cards[i];
    }
    if (!p.pinned) os << "   (unpinned: height heuristic decides)";
    return os.str();
}

static bool eq(const std::string& a, const std::string& b) { return a == b; }

// The category spellings used at the Module(...) call sites. Hand-listed, because
// ModuleCategory has no reflection and a test cannot invent one. A module in a
// category missing here is skipped rather than guessed at -- and case 7 asserts the
// parse actually found the modules it cares about, so a silent skip cannot pass.
static bool category_from_name(const std::string& s, ModuleCategory& out) {
    struct row { const char* name; ModuleCategory cat; };
    static const row rows[] = {
        {"RaidDashboard", RaidDashboard}, {"BotSpawner", BotSpawner},
        {"Visuals", Visuals}, {"MapStuff", MapStuff}, {"Exploit", Exploit},
        {"ItemSpawnerEditor", ItemSpawnerEditor}, {"WeaponBuilder", WeaponBuilder},
        {"ProfileEditor", ProfileEditor}, {"Teleport", Teleport},
        {"QuestCompleter", QuestCompleter}, {"Config", Config},
    };
    for (const auto& r : rows)
        if (s == r.name) { out = r.cat; return true; }
    return false;
}

// Read every module/impl/*.cpp and return each module's registration as
// (name, category), in the order the constructors appear. That ORDER is the draw
// order -- ModuleManager.h's member declaration order is the order those
// constructors run in, and it is the draw order too (see the column-order note in
// it). The names themselves live at the `Module("Name", Category, ...)` call sites,
// not in ModuleManager.h, so this is where the truth is.
struct Registered {
    std::string name;
    ModuleCategory category;
};

// The registration order is ModuleManager.h's member-declaration order -- C++ initialises
// members in declaration order, and that is the draw order (see the column-order note in
// that file). So the order has to come from THERE, not from the .cpp filenames: read
// alphabetically, Exploit comes out Aimbot, Chams, Doors, ESP, Player, Weapon and every
// left-before-right check fails for a reason that has nothing to do with the code.
//
// Two hops, because neither file holds both halves: ModuleManager.h names the module
// TYPES in order, and each type's `Type::Type() : Module("Name", Category, ...)` in
// module/impl/ gives the name and the tab.
static std::vector<Registered> registrations(const char* manager_header,
                                            const char* impl_dir) {
    std::vector<Registered> out;

    // ---- hop 1: the ordered list of module types --------------------------
    std::vector<std::string> types;
    {
        std::ifstream in(manager_header);
        if (!in) {
            std::cout << "        (cannot read \"" << manager_header << "\")\n";
            return out;
        }
        std::string line;
        while (std::getline(in, line)) {
            const size_t at = line.find("new ");
            if (at == std::string::npos) continue;
            size_t end = at + 4;
            const size_t start = end;
            while (end < line.size()
                   && (std::isalnum(static_cast<unsigned char>(line[end])) || line[end] == '_'))
                ++end;
            if (end > start) types.emplace_back(line.substr(start, end - start));
        }
    }
    if (types.empty()) {
        std::cout << "        (no module types found in \"" << manager_header << "\")\n";
        return out;
    }

    // ---- hop 2: type -> (name, category) ----------------------------------
    std::vector<std::pair<std::string, Registered>> by_type;
    const std::filesystem::path dir(impl_dir);
    std::error_code ec;
    std::filesystem::directory_iterator it(dir, ec);
    if (ec) {
        std::cout << "        (cannot enumerate \"" << impl_dir << "\": " << ec.message()
                  << "; cwd is \"" << std::filesystem::current_path().string() << "\")\n";
        return out;
    }
    std::vector<std::filesystem::path> files;
    for (const auto& e : it)
        if (e.is_regular_file() && e.path().extension() == ".cpp")
            files.push_back(e.path());
    std::sort(files.begin(), files.end());   // determinism only; order comes from hop 1

    int parsed = 0, unmapped = 0;
    for (const auto& f : files) {
        std::ifstream in(f);
        if (!in) continue;
        std::string line, prev_line;
        while (std::getline(in, line)) {
            // The type comes from the ctor's own scope -- the identifier before the
            // `::` preceding the FIRST '(' on the line. Matching on `() : Module("`
            // instead would skip every constructor that takes a parameter, which is
            // eight of them and includes two cards this table names. Reading the
            // type rather than the filename is also what keeps the modules that share
            // one .cpp distinct (Teleport and MarkedRooms, LootTeleporter and
            // BotControl).
            //
            // Two shapes cover every ctor in impl/:
            //   same line --  LootTeleportModule::LootTeleportModule() : Module("...")
            //   split     --  EspModule::EspModule()
            //                     : Module("ESP", ...),   (e4caba056 split it this way)
            // In the split shape the `::`-scope is on the previous line, so the
            // type is recovered from there; the name/category parse still uses the
            // `Module("` line itself.
            const size_t at = line.find("Module(\"");
            if (at != std::string::npos) {
                std::string type;
                const size_t paren = line.find('(');
                if (paren != std::string::npos && paren < at) {
                    const size_t t0 = line.rfind("::", paren);
                    if (t0 != std::string::npos && t0 != 0) {
                        size_t t1 = t0;
                        while (t1 > 0 && (std::isalnum(static_cast<unsigned char>(line[t1 - 1]))
                                          || line[t1 - 1] == '_'))
                            --t1;
                        type = line.substr(t1, t0 - t1);
                    }
                } else {
                    const size_t lead = line.find_first_not_of(" \t");
                    const size_t pparen = prev_line.find('(');
                    if (lead != std::string::npos && lead < at && line[lead] == ':'
                        && pparen != std::string::npos) {
                        const size_t t0 = prev_line.rfind("::", pparen);
                        if (t0 != std::string::npos && t0 != 0) {
                            size_t t1 = t0;
                            while (t1 > 0 && (std::isalnum(static_cast<unsigned char>(prev_line[t1 - 1]))
                                              || prev_line[t1 - 1] == '_'))
                                --t1;
                            type = prev_line.substr(t1, t0 - t1);
                        }
                    }
                }
                if (!type.empty() && type[0] != ':') {   // not a ctor scope
                    const size_t name_start = at + 8;
                    const size_t name_end = line.find('"', name_start);
                    if (name_end != std::string::npos) {
                        const size_t cat_start = line.find(',', name_end);
                        if (cat_start != std::string::npos) {
                            // +1, and that is the whole bug this function spent an afternoon on:
                            // find_first_of searches FROM pos INCLUSIVE, so searching from cat_start
                            // matched the very comma it was standing on. The length then went negative,
                            // substr clamped to the end of the line, and every category came out as
                            // `Exploit, "aimbot_mod"),` -- which matched nothing, and made the whole
                            // table look empty rather than wrong.
                            const size_t cat_end = line.find_first_of(",)", cat_start + 1);
                            if (cat_end != std::string::npos) {
                                std::string cat = line.substr(cat_start + 1, cat_end - cat_start - 1);
                                while (!cat.empty() && cat.front() == ' ') cat.erase(cat.begin());
                                while (!cat.empty() && cat.back() == ' ') cat.pop_back();

                                Registered r;
                                r.name = line.substr(name_start, name_end - name_start);
                                if (category_from_name(cat, r.category)) {
                                    by_type.emplace_back(type, r);
                                    ++parsed;
                                } else {
                                    ++unmapped;
                                }
                            }
                        }
                    }
                }
            }
            prev_line = line;
        }
    }

    // ---- in registration order --------------------------------------------
    int missing = 0;
    for (const auto& t : types) {
        const Registered* found = nullptr;
        for (const auto& bt : by_type)
            if (bt.first == t) { found = &bt.second; break; }
        if (found) out.push_back(*found);
        else ++missing;
    }
    std::cout << "        (" << types.size() << " registered types, " << parsed
              << " parsed, " << unmapped << " in an unmapped category, " << missing
              << " unresolved)\n";
    return out;
}

int main() {
    // ---- 1. the reported bug: Debug Log ON --------------------------------
    // Registration order is Raid Dashboard, Debug Log, Favorites, Configs.
    {
        const std::vector<std::string_view> cards{"Raid Dashboard", "Debug Log",
                                                 "Favorites", "Configs"};
        const cl::Partition p = cl::partition(RaidDashboard, cards);
        check(p.pinned, "RaidDashboard pins its boundary");
        check(p.left_count == 2, "Debug Log ON: boundary after Debug Log (left_count == 2)");
        check(eq(shape(RaidDashboard, cards, "on"),
                "on: L:Raid Dashboard | L:Debug Log | R:Favorites | R:Configs"),
            "Debug Log ON puts Favorites and Configs on the right");
    }

    // ---- 2. the same tab with the card absent ----------------------------
    // The conditional card is simply not in the list. There is no special case for it
    // any more, which is the point: the old code needed an explicit
    // `if (name == "Debug Log" && !shown) split_to_second_column();` to move the
    // boundary up, and that was the line the registration order invalidated.
    {
        const std::vector<std::string_view> cards{"Raid Dashboard", "Favorites", "Configs"};
        const cl::Partition p = cl::partition(RaidDashboard, cards);
        check(p.pinned, "still pinned with the card absent");
        check(p.left_count == 1, "Debug Log OFF: boundary after Raid Dashboard");
        check(eq(shape(RaidDashboard, cards, "off"),
                "off: L:Raid Dashboard | R:Favorites | R:Configs"),
            "Debug Log OFF leaves Favorites and Configs on the right");
    }

    // The user's actual requirement, stated directly: the right-hand column must be
    // the same set of cards whichever way the toggle is set.
    {
        const std::vector<std::string_view> on{"Raid Dashboard", "Debug Log",
                                               "Favorites", "Configs"};
        const std::vector<std::string_view> off{"Raid Dashboard", "Favorites", "Configs"};
        const cl::Partition a = cl::partition(RaidDashboard, on);
        const cl::Partition b = cl::partition(RaidDashboard, off);
        // Hotkeys is not a module -- it is appended by menu.cpp -- but it lands in
        // column 2 whenever anything did, so what matters is that both cases split.
        check(a.pinned && b.pinned,
            "Favourites -> Configs -> Hotkeys stays on the right in BOTH toggle states");
    }

    // ---- 3. the tabs that pin a boundary after their first card -----------
    {
        struct row { ModuleCategory tab; std::vector<std::string_view> cards; int left; const char* label; };
        const row rows[] = {
            {Exploit, {"Aimbot", "Door Unlocker", "Weapon", "Player", "Chams", "ESP"}, 4,
                "Exploit"},
            {ProfileEditor, {"Trader Editor", "Hideout", "Experience Editor",
                             "Hideout Automation"}, 2, "ProfileEditor"},
            {BotSpawner, {"World", "AI Limit", "Bot Controls"}, 2, "BotSpawner"},
            {WeaponBuilder, {"Weapon Builder", "Item Spawner (Weapon Builder)"}, 1,
                "WeaponBuilder"},
            {ItemSpawnerEditor, {"Item Editor", "Item Spawner"}, 1, "ItemSpawnerEditor"},
            {QuestCompleter, {"Quest Completer", "Quest Reset"}, 1, "QuestCompleter"},
        };
        for (const auto& r : rows) {
            const cl::Partition p = cl::partition(r.tab, r.cards);
            std::string msg = "  ";
            msg += r.label;
            msg += " splits after its last left card";
            check(p.pinned && p.left_count == r.left, msg.c_str());
        }
    }

    // ---- 3b. the AI Limit card is its own card on the LEFT ----------------
    // The user's report: eight AI-limit sliders were drawn inside the Bot
    // Controls card, on top of the bot-teleport pair, and read as one long
    // list. The fix was a card of its own in the left column, which is what
    // makes the split fall after it. This case states the resulting layout
    // directly, so a table edit that merges them back fails here rather than
    // only looking wrong in the menu.
    {
        const std::vector<std::string_view> cards{"World", "AI Limit", "Bot Controls"};
        check(cl::column_for(BotSpawner, "AI Limit") == cl::Column::Left,
              "BotSpawner/AI Limit is declared Left");
        check(cl::column_for(BotSpawner, "Bot Controls") == cl::Column::Auto,
              "BotSpawner/Bot Controls is not in the table -- it lands right by the boundary");
        const cl::Partition p = cl::partition(BotSpawner, cards);
        check(p.pinned && p.left_count == 2, "the split falls after AI Limit, not before it");
        check(eq(shape(BotSpawner, cards, "ai"),
                 "ai: L:World | L:AI Limit | R:Bot Controls"),
              "left column holds Bot Spawner + AI Limit, right holds Bot Controls");
        // And the card is not folded into the other one's card list: a module
        // is a card, so "its own card" means its own registration.
        const std::vector<Registered> reg =
            registrations("../../TarkovAddons/module/ModuleManager.h",
                          "../../TarkovAddons/module/impl");
        int ai = -1, controls = -1, world = -1;
        for (size_t i = 0; i < reg.size(); ++i) {
            if (reg[i].name == "AI Limit") ai = static_cast<int>(i);
            if (reg[i].name == "Bot Controls") controls = static_cast<int>(i);
            if (reg[i].name == "World") world = static_cast<int>(i);
        }
        check(ai >= 0, "AI Limit is a registered module of its own (i.e. its own card)");
        check(world >= 0 && ai > world && controls > ai,
              "AI Limit is registered between World and Bot Controls -- the draw order");
    }

    // ---- 4. Teleport: Sticky must NOT become a pinned boundary ----------
    // Map Selector has to stay left, but where the split falls is still the height
    // heuristic's decision. Marking it Left would silently promote it to a pinned
    // boundary and move Marked Rooms and Loot Teleporter for good -- a behaviour
    // change disguised as a tidy-up, which is the trap this column exists in kTable.
    {
        const std::vector<std::string_view> cards{"Map Selector", "Marked Rooms",
                                                 "Loot Teleporter"};
        const cl::Partition p = cl::partition(Teleport, cards);
        check(!p.pinned, "Teleport is NOT pinned (Map Selector is Sticky, not Left)");
        check(cl::suppress_heuristic(Teleport, "Map Selector"),
            "Teleport/Map Selector still suppresses the height heuristic");
        check(!cl::suppress_heuristic(Teleport, "Marked Rooms"),
            "Teleport/Marked Rooms does not");
        check(cl::column_for(Teleport, "Map Selector") == cl::Column::Sticky,
            "and it is Sticky, explicitly");
    }

    // ---- 5. tabs with no pinned layout fall back to the heuristic --------
    {
        const std::vector<std::string_view> visuals{"Ammo HUD"};
        const cl::Partition v = cl::partition(Visuals, visuals);
        check(!v.pinned, "Visuals is unpinned");
        const std::vector<std::string_view> cfg{"Watermark"};
        check(!cl::partition(Config, cfg).pinned, "Config is unpinned");
        const std::vector<std::string_view> empty;
        const cl::Partition e = cl::partition(MapStuff, empty);
        check(!e.pinned && e.left_count == 0, "an empty card list is unpinned and safe");
    }

    // ---- 6. the table itself is well formed -------------------------------
    {
        bool dup = false;
        for (size_t i = 0; i < std::size(cl::kTable); ++i)
            for (size_t j = i + 1; j < std::size(cl::kTable); ++j)
                if (cl::kTable[i].tab == cl::kTable[j].tab
                    && cl::kTable[i].card == cl::kTable[j].card)
                    dup = true;
        check(!dup, "no duplicate (tab, card) entries in kTable");
        check(std::size(cl::kTable) > 0, "kTable is not empty -- a checker that asserts"
              " nothing is the failure this project keeps paying for");
    }

    // ---- 7. the table agrees with the real registrations ------------------
    // Source-text check, because module/impl/*.cpp cannot be built without the
    // project. It catches the two ways this layout breaks silently: a module renamed
    // out from under the table, and a left-column card registered after a
    // right-column one.
    {
        const std::vector<Registered> reg =
            registrations("../../TarkovAddons/module/ModuleManager.h",
                           "../../TarkovAddons/module/impl");
        check(!reg.empty(),
            "the real registration order was read (run this from tools/harness, as run_windows.bat does)");
        if (!reg.empty()) {
            // Premise, so the rest cannot pass by parsing nothing. If these are not
            // found the source read is broken and every check below is vacuous.
            int premise = 0;
            for (const char* n : {"Raid Dashboard", "Favorites", "Debug Log", "Configs",
                                  "Aimbot", "Player", "Chams", "ESP", "Hideout",
                                  "Experience Editor", "Map Selector", "AI Limit",
                                  "Bot Controls", "World"})
                for (const auto& r : reg)
                    if (r.name == n) { ++premise; break; }
            check(premise == 14, "the source read found the modules these checks depend on");

            // (a) every name in the table is a real module, on the tab the table claims.
            for (const auto& e : cl::kTable) {
                const Registered* found = nullptr;
                for (const auto& r : reg)
                    if (r.name == e.card) { found = &r; break; }
                check(found != nullptr, "every kTable card is a real registered module name");
                if (!found) {
                    std::cout << "        (no module named \"" << e.card << "\")\n";
                } else if (found->category != e.tab) {
                    std::cout << "        (\"" << e.card << "\" is on a different tab than kTable claims)\n";
                    check(false, "kTable's tab matches the module's real category");
                }
            }

            // (b) order, per tab. Every Left card must precede the first non-Left
            // card on that tab, or left_count lands in the wrong place. This is
            // exactly the 2026-10-03 defect: Debug Log sat after Favorites.
            struct order_row { ModuleCategory tab; const char* last_left; const char* first_right; };
            const order_row orders[] = {
                {RaidDashboard, "Debug Log", "Favorites"},
                {Exploit, "Player", "Chams"},
                {ProfileEditor, "Hideout", "Experience Editor"},
                {BotSpawner, "AI Limit", "Bot Controls"},
                {WeaponBuilder, "Weapon Builder", "Item Spawner (Weapon Builder)"},
                {ItemSpawnerEditor, "Item Editor", "Item Spawner"},
                {QuestCompleter, "Quest Completer", "Quest Reset"},
            };
            for (const auto& o : orders) {
                std::vector<std::string> on_tab;
                for (const auto& r : reg)
                    if (r.category == o.tab) on_tab.push_back(r.name);
                const auto li = std::find(on_tab.begin(), on_tab.end(), o.last_left);
                const auto ri = std::find(on_tab.begin(), on_tab.end(), o.first_right);
                if (li == on_tab.end() || ri == on_tab.end()) continue;   // covered by (a)
                check(li < ri, "left-column card is registered before the first right-column card");
                if (!(li < ri))
                    std::cout << "        (" << o.last_left << " must be registered before "
                              << o.first_right << ")\n";
            }
        }
    }

    std::cout << (g_fail ? "FAILED " : "ok ") << (g_pass + g_fail)
              << " assertions, " << g_fail << " failed\n";
    return g_fail ? 1 : 0;
}