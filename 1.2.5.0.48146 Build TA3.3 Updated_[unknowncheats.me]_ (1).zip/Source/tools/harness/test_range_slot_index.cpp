// Portable test for the optics range_readable slot arithmetic.
//
// The memo is explicit that there is no cheap harness case for the optics table
// because it pulls in the whole pipeline, and that is correct. So this copies the
// ARITHMETIC -- page hash plus slot index -- rather than including the header, and
// asserts the two properties that actually matter:
//
//   1. the index is in range for 0, a huge address, and a wrapped one. This is the
//      test that catches a missing mask, which is the failure that shipped once and
//      only showed up as a 0xC0000005 with no output.
//   2. consecutive pages occupy a healthy fraction of distinct slots.
//
// On the threshold in (2): the memo says the birthday bound for 4096 keys into 4096
// slots is ~36.8% and to assert >= 40%. I measured it: for n = k the expected
// occupied fraction is 1 - (1 - 1/k)^n, which for 4096 is 63.2%, not 36.8%.
// 36.8% is the classic "two people share a birthday" coincidence and is unrelated.
// The measured spread of the shipped Fibonacci hash over 4096 consecutive pages is
// 2831 distinct slots = 69.1%. So this asserts >= 60%: comfortably above the true
// random bound of 63.2% is NOT the point -- the point is to catch a COLLAPSE, and a
// collapsed hash scores 1 slot = 0.02%. Asserting 70% (as the memo warns was tried)
// would demand better than random, which is not a property a hash has, and would fail
// on a correct implementation.

#include <cassert>
#include <cstdint>
#include <cstdio>
#include <set>

namespace {

constexpr size_t kRangeSlots = 4096;

size_t range_slot_index(uintptr_t page) {
    static_assert((kRangeSlots & (kRangeSlots - 1)) == 0,
        "kRangeSlots must be a power of two for the mask to be a valid index bound");
    return static_cast<size_t>((page * 11400714819323198485ull) >> 32) & (kRangeSlots - 1);
}

// The expression the memo warns against: widening the shift to match a 12-bit mask
// without changing the hash. Kept here so the test pins WHY the real one is different.
size_t naive_widened_shift(uintptr_t page) {
    return static_cast<size_t>(((page * 2654435761ull) >> 52) & (kRangeSlots - 1));
}

int failures = 0;

void check(bool ok, const char* what) {
    if (!ok) { std::printf("  FAIL  %s\n", what); ++failures; }
    else     { std::printf("  ok    %s\n", what); }
}

} // namespace

int main() {
    std::printf("range_slot_index tests (kRangeSlots=%zu)\n\n", kRangeSlots);

    // ---- (1) index stays in range ------------------------------------------
    // 0, a huge address, and a wrapped one (a high address whose product overflows
    // the 64-bit multiply, which is exactly the case a missing mask would miss).
    const uintptr_t probes[] = {
        0ull,
        0xFFFFFFFFFFFFF000ull,              // top of the address space
        0x7FFFFFFFFFFFF000ull,
        0x00007FFFFFFFF000ull,
        0xFFFFFFFFFFFFF001ull,              // deliberately not page-aligned
    };
    for (uintptr_t a : probes) {
        const size_t i = range_slot_index(a >> 12);
        check(i < kRangeSlots, "index in range for a non-trivial address");
    }

    // Sweep a wide spread of pages rather than trusting five samples.
    bool all_in_range = true;
    for (uintptr_t p = 0; p < 4000000; p += 9973) {
        if (range_slot_index(p) >= kRangeSlots) { all_in_range = false; break; }
    }
    for (uintptr_t p = 0xFFFFFFFFFFFFull; p > 0xFFFFFFFFFFF00000ull; p -= 9973) {
        if (range_slot_index(p) >= kRangeSlots) { all_in_range = false; break; }
    }
    check(all_in_range, "index in range across a 4M-page sweep and the top of the space");

    // ---- (2) consecutive pages spread over distinct slots --------------------
    std::set<size_t> distinct;
    for (uintptr_t p = 1000; p < 1000 + 4096; ++p) distinct.insert(range_slot_index(p));
    const double frac = 100.0 * static_cast<double>(distinct.size()) / 4096.0;
    std::printf("        4096 consecutive pages -> %zu distinct slots (%.1f%%)\n",
        distinct.size(), frac);
    check(frac >= 60.0, "consecutive pages occupy >= 60% of distinct slots");

    // The anti-test: the naive widened shift scores 1 slot, i.e. 0.02%. This is the
    // specific regression the memo documents, asserted so it cannot come back.
    std::set<size_t> collapsed;
    for (uintptr_t p = 1087; p < 1087 + 4096; ++p) collapsed.insert(naive_widened_shift(p));
    const double collapsed_frac = 100.0 * static_cast<double>(collapsed.size()) / 4096.0;
    std::printf("        naive >> 52 (anti-test)  -> %zu distinct slots (%.2f%%)\n",
        collapsed.size(), collapsed_frac);
    check(collapsed.size() == 1, "anti-test: naive >> 52 really does collapse to one slot");
    check(collapsed_frac < 1.0, "anti-test: collapse is distinguishable from a real hash");

    std::printf("\n%s\n", failures ? "FAILED" : "all range_slot_index tests passed");
    return failures ? 1 : 0;
}
