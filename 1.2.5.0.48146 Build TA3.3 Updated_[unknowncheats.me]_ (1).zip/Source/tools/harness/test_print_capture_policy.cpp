// The capture policy for the two string-carrying print codes.
//
// THE COST THIS EXISTS FOR, measured 2026-10-10 (build/scratch_dbg/
// crashprobe_cost.cpp, direct calls into the real handler, no debugger):
//
//     0x40010006   shallow stack    788 us per event, and 1985 us behind a
//                  game-shaped one (200 junk-filled frames) -- because the VEH
//                  path captured every print with a shallow 24-frame stack scan
//                  whose output no report reads. On this delivery model every
//                  OutputDebugString raises in-process (see the gate comment at
//                  crash_probe.h's is_debugger_signalled), so a print flood
//                  pays that per event. The 2026-10-09 100%-CPU session is a
//                  print flood doing exactly this.
//     0xE06D7363   the same two shapes stay at ~790 / ~1990 us -- the control.
//
// The fix is a capture policy, not a gate: routine prints are captured by HEAD
// ONLY (histogram + ring + the {length, pointer} params, where the string
// lives), and fill_frames() is not run. `Event::walked` records which of the
// two happened, so a report can say "not scanned" instead of printing zeroes
// that read as "scanned and found nothing".
//
// WHAT THIS CASE ASSERTS, and why each one can fail:
//
//   1. is_print_payload() is exactly the two string-carrying codes. If a
//      non-print code joins it, the walk silently disappears for a fault; if a
//      print leaves it, the flood cost comes back.
//   2. THE CROSS-LINK: what handler() CONSUMES while a debugger is attached is
//      exactly what this policy defers while none is. The two decisions hang
//      off the same predicate; a divergence between them would mean a print is
//      either consumed-but-walked or searched-but-not-captured, and this is the
//      only place the equality is asserted.
//   3. A routine print reads back from the ring as walked == false, frames == 0,
//      AND with its payload intact -- param[0]/param[1] are the string's length
//      and pointer, which is what emit_debug_string() later reads. A deferral
//      that lost the string would trade one blind spot for another.
//   4. The SAME print record, marked FATAL, DOES walk: the deferral covers
//      routine traffic only. `fatal` is what the unhandled filter passes, and
//      on a machine where kernel32's frame handler does not absorb the print
//      raise, that path is real.
//   5. A 0xE06D7363 control on the same stack still walks and still finds
//      frames -- and a direct guarded_enrich() call with the walk ENABLED does
//      the same for the print record itself. That last one is the negative
//      control: it proves `walked == false` in (3) is the policy suppressing
//      the walk, not a stack the walk could not read anyway.
//
// The ring is read directly (crash_probe::g_ring / g_seq / kRing are reachable
// through the header's anonymous namespace, the same way the gate case already
// reaches crash_probe::handler). Nothing here goes through the handler's
// disposition: capture_and_maybe_report is called directly, so this case means
// the same thing with or without a debugger attached to it.

#include "../../TarkovAddons/util/crash_probe.h"

#include <cstdio>
#include <cstring>
#include <windows.h>

static int g_failures = 0;
static void check(bool cond, const char* what) {
    std::printf(cond ? "  [PASS] %s\n" : "  [FAIL] %s\n", what);
    if (!cond) ++g_failures;
}

// The payload every print capture below carries. Static so the pointer stays
// valid for the whole run.
static const char kPayload[] = "print capture policy: this string must survive the walk";

// Capture through the REAL wiring -- capture_and_maybe_report is what both the
// VEH and the unhandled filter call, so the policy under test is the policy
// that ships, not a facsimile. `fatal=false` for routine codes is also what
// keeps this side-effect free for them; the fatal case below is documented
// where it is used.
static void capture_code(uint32_t code, bool with_payload, bool fatal) {
    EXCEPTION_RECORD rec{};
    rec.ExceptionCode = code;
    rec.ExceptionAddress = reinterpret_cast<void*>(&capture_code);
    if (with_payload) {
        rec.NumberParameters = 2;
        rec.ExceptionInformation[0] = sizeof(kPayload);  // {length, pointer}: measured order
        rec.ExceptionInformation[1] = reinterpret_cast<ULONG_PTR>(kPayload);
    }
    CONTEXT ctx{};
    RtlCaptureContext(&ctx);
    crash_probe::capture_and_maybe_report(&rec, static_cast<uintptr_t>(ctx.Rsp),
                                          "harness", fatal, /*confirmed=*/false);
}

// The event with sequence number `seq`, or null if the slot was reused before
// it could be read. Single-threaded here, so a null means the test itself is
// broken, which must fail rather than silently skip the assertions.
static const crash_probe::Event* ring_event(uint32_t seq) {
    const crash_probe::Event& e = crash_probe::g_ring[seq % crash_probe::kRing];
    if (e.ready.load(std::memory_order_acquire) != 2) return nullptr;
    if (e.seq != seq) return nullptr;
    return &e;
}

int main() {
    setvbuf(stdout, nullptr, _IONBF, 0);
    std::printf("print capture policy\n");

    std::printf("  is_print_payload: exactly the two string-carrying codes\n");
    check(crash_probe::is_print_payload(0x40010006u),
          "0x40010006 DBG_PRINTEXCEPTION_C IS a print payload");
    check(crash_probe::is_print_payload(0x4001000Au),
          "0x4001000A DBG_PRINTEXCEPTION_WIDE_C IS a print payload");
    check(!crash_probe::is_print_payload(0x40010007u),
          "0x40010007 DBG_RIPEXCEPTION is NOT (it carries no string)");
    check(!crash_probe::is_print_payload(0x80000003u),
          "0x80000003 BREAKPOINT is NOT");
    check(!crash_probe::is_print_payload(0xE06D7363u),
          "0xE06D7363 C++ throw is NOT");
    check(!crash_probe::is_print_payload(0xC0000005u),
          "0xC0000005 ACCESS_VIOLATION is NOT");

    {
        // The cross-link to the gate: consumed == attached && print payload. The
        // gate case asserts each disposition separately; THIS asserts they are
        // the same set, which is the property a later edit could break while
        // both individual tests stay green.
        bool linked = true;
        for (uint32_t code : { 0x40010006u, 0x4001000Au, 0x40010007u, 0x80000003u,
                               0x80000004u, 0xE06D7363u, 0xC0000005u, 0xDEADBEEFu }) {
            if (crash_probe::debugger_gate_consumes(code, /*attached=*/true) !=
                crash_probe::is_print_payload(code))
                linked = false;
        }
        check(linked, "the set handler() consumes while attached IS the set this "
                      "policy defers with no debugger");
    }

    std::printf("  a routine print: head-only, payload intact\n");
    const uint32_t seq_print = crash_probe::g_seq.load(std::memory_order_relaxed);
    capture_code(0x40010006u, /*with_payload=*/true, /*fatal=*/false);
    const crash_probe::Event* e = ring_event(seq_print);
    check(e != nullptr, "the print event was captured into the ring");
    if (e) {
        check(!e->walked, "print event: walked == false -- fill_frames did NOT run");
        check(e->nframes == 0 && e->ndata == 0 && e->nout == 0,
              "print event: no frame bookkeeping, so the report can say 'not scanned'");
        check(e->param[0] == sizeof(kPayload) &&
              e->param[1] == reinterpret_cast<uintptr_t>(kPayload),
              "print event: {length, pointer} captured at head time -- the string "
              "survives the deferral, which is where emit_debug_string reads it");
        check(e->tid == GetCurrentThreadId(), "print event: tid captured");
        check(e->code == 0x40010006u, "print event: code captured");
    }

    std::printf("  the control: a C++ throw still walks, on this very stack\n");
    const uint32_t seq_throw = crash_probe::g_seq.load(std::memory_order_relaxed);
    capture_code(0xE06D7363u, /*with_payload=*/false, /*fatal=*/false);
    const crash_probe::Event* t = ring_event(seq_throw);
    check(t != nullptr, "the throw event was captured into the ring");
    if (t) {
        check(t->walked, "0xE06D7363: walked == true -- the scan still runs for non-prints");
        check(t->nframes > 0,
              "0xE06D7363: the scan FOUND code frames on this stack (so a print's "
              "empty frame list is a policy outcome, not an empty stack)");
    }

    std::printf("  the same print, FATAL: walks (routine traffic only is deferred)\n");
    // fatal=true means "report this now": capture_and_maybe_report forwards that
    // to report_fatal(), which in this harness writes through emit() with no log
    // open -- a no-op, not a side effect. This is the disposition the unhandled
    // filter passes, and the assertion is that it wins over the print policy.
    const uint32_t seq_fatal = crash_probe::g_seq.load(std::memory_order_relaxed);
    capture_code(0x40010006u, /*with_payload=*/true, /*fatal=*/true);
    const crash_probe::Event* f = ring_event(seq_fatal);
    check(f != nullptr, "the fatal print event was captured into the ring");
    if (f) {
        check(f->walked, "FATAL print: walked == true -- the deferral covers routine traffic only");
        check(f->deep, "FATAL print: deep == true -- a reported event keeps the full walk");
        check(f->nframes > 0, "FATAL print: frames were collected for the report");
    }

    std::printf("  negative control: the walk, when asked for, DOES produce frames\n");
    {
        // The same print record, the same stack, but with_frames=true passed
        // straight into guarded_enrich -- the exact call capture_and_maybe_report
        // made before 2026-10-10. If this finds nothing, assertion (3)'s
        // walked==false proves nothing (an unreadable stack would also give
        // frames=0), and this case must fail rather than pass vacuously.
        crash_probe::Event control;
        EXCEPTION_RECORD rec{};
        rec.ExceptionCode = 0x40010006u;
        rec.ExceptionAddress = reinterpret_cast<void*>(&capture_code);
        rec.NumberParameters = 2;
        rec.ExceptionInformation[0] = sizeof(kPayload);
        rec.ExceptionInformation[1] = reinterpret_cast<ULONG_PTR>(kPayload);
        CONTEXT ctx{};
        RtlCaptureContext(&ctx);
        crash_probe::guarded_enrich(&rec, control, static_cast<uintptr_t>(ctx.Rsp),
                                    /*deep=*/false, /*with_frames=*/true);
        check(control.walked, "control: guarded_enrich(with_frames=true) marks the event walked");
        check(control.nframes > 0,
              "control: the SAME print record with the walk enabled yields frames -- "
              "so (3)'s empty frame list is the policy suppressing the walk");
    }

    std::printf("%s (%d failure(s))\n", g_failures ? "FAILED" : "OK", g_failures);
    return g_failures ? 1 : 0;
}
