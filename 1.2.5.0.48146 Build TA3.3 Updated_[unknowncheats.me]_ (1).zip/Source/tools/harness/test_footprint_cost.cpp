// MEASURES the real heap cost of our metadata caches, so the footprint
// reporter does not have to guess it.
//
// WHY THIS IS A HARNESS CASE AND NOT A CONSTANT IN A COMMENT. The question
// "how much of the game's 31 GB is ours" cannot be answered by multiplying
// element counts by sizeof(), because an unordered_map holds two things the
// type system does not report: a bucket array, and a per-node allocation with
// CRT header and alignment rounding. A figure written down from sizeof() would
// be an assertion nobody measured, and the project has a long list of what
// those cost.
//
// So: measure. GetProcessMemoryInfo before and after filling a real
// std::unordered_map<MetaKey, void*, MetaKeyHash> -- the ACTUAL key type from
// il2cpp/meta_key.h, not a stand-in -- and take the slope. Two-point
// difference is the whole design: one measurement cannot separate the bucket
// array from the nodes, and a single delta also carries whatever the process
// did in the background during the call.
//
// The negative control at the bottom is the point of the case. It fills the
// map and then destroys it and asserts the memory comes BACK. Without that,
// "the map grew by 6 MB" and "the process grew by 6 MB for an unrelated
// reason" are indistinguishable, and the number this file exists to produce
// would be exactly the kind of plausible figure that decays into a lie.
//
// Output is printed, not asserted against a golden value: the constants are
// consumed by the footprint reporter as a MEASURED result on the machine that
// measured them, and a golden value would just be a guess promoted to a test.
// What IS asserted is the shape: node cost must be positive, the bucket array
// must be positive, and the memory must actually be returned.

#include "../../TarkovAddons/il2cpp/meta_key.h"

#include <windows.h>
#include <psapi.h>

#include <atomic>
#include <chrono>
#include <cstdio>
#include <string>
#include <unordered_map>

using il2utils::detail::MetaKey;
using il2utils::detail::MetaKeyHash;

namespace {

int g_failures = 0;

void check(bool cond, const char* what) {
    if (!cond) {
        std::printf("  [FAIL] %s\n", what);
        ++g_failures;
    } else {
        std::printf("  [PASS] %s\n", what);
    }
}

// Resolved rather than linked: the K32* export lives in kernel32 on Windows 7+
// and this keeps the case from needing psapi.lib on the link line, which is
// the same reasoning crash_probe.h uses for the same two APIs.
using get_pmi_fn = BOOL(WINAPI*)(HANDLE, PROCESS_MEMORY_COUNTERS*, DWORD);

get_pmi_fn resolve_get_pmi() {
    if (HMODULE k32 = GetModuleHandleW(L"kernel32.dll"))
        if (get_pmi_fn p = reinterpret_cast<get_pmi_fn>(
                GetProcAddress(k32, "K32GetProcessMemoryInfo")))
            return p;
    if (HMODULE ps = GetModuleHandleW(L"psapi.dll"))
        return reinterpret_cast<get_pmi_fn>(GetProcAddress(ps, "GetProcessMemoryInfo"));
    return nullptr;
}

SIZE_T private_bytes() {
    static get_pmi_fn fn = resolve_get_pmi();
    if (!fn) return 0;
    PROCESS_MEMORY_COUNTERS_EX pmc{};
    pmc.cb = sizeof(pmc);
    if (!fn(GetCurrentProcess(),
            reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&pmc), sizeof(pmc)))
        return 0;
    return pmc.PrivateUsage;
}

// Force the heap to settle before a baseline, so the first touch of a new
// segment is not charged to the map.
void settle() {
    for (volatile int i = 0; i < 4000000; ++i) { }
}

using cache_t = std::unordered_map<MetaKey, void*, MetaKeyHash>;

MetaKey key_for(const void* tag, int argc, const char* name) {
    MetaKey k;
    k.assign(tag, argc, name);
    return k;
}

// Distinct keys: the tag varies per entry so MetaKey's content-based identity
// produces a unique key each time and the map really does grow. assign() takes
// the class as a `const void*` -- a stored address, never a dereference -- so
// a synthetic non-null tag is exactly what a live cache holds, and pulling in
// the whole IL2CPP type table to make it "real" would measure that instead.
void fill(cache_t& c, std::size_t from, std::size_t to) {
    for (std::size_t i = from; i < to; ++i) {
        char nm[64];
        std::snprintf(nm, sizeof(nm), "field_name_number_%llu",
                      static_cast<unsigned long long>(i));
        c.emplace(key_for(reinterpret_cast<const void*>(0x140000000ull + i),
                          static_cast<int>(i & 7), nm), nullptr);
    }
}

} // namespace

int main() {
    std::printf("footprint_cost: real heap cost of the metadata cache\n");

    // BOTH COUNTS MUST SIT INSIDE ONE BUCKET EPOCH, or the slope is not node cost
    // -- it is node cost plus a bucket array that doubled between them. MSVC's
    // unordered_map grows buckets by powers of two and rehashes once size passes
    // bucket_count, so the epochs are [0,1], (1,2], (2,4] ... bucket_count and
    // each epoch holds at most bucket_count elements. 150k and 250k both land in
    // the 262144-bucket epoch; the first attempt used 200k and 400k, which
    // straddles 262144 -> 524288 and reported 137 bytes/entry for what was
    // really nodes PLUS a doubled bucket array. That is the whole reason the
    // "no rehash" check exists -- the number was plausible and wrong.
    const std::size_t n1 = 150000, n2 = 250000;

    settle();
    const SIZE_T base = private_bytes();

    // --- node cost: slope across two counts -------------------------------
    SIZE_T at_n1 = 0, at_n2 = 0;
    std::size_t buckets1 = 0, buckets2 = 0;
    {
        cache_t c;
        fill(c, 0, n1);
        buckets1 = c.bucket_count();
        settle();
        at_n1 = private_bytes();

        fill(c, n1, n2);
        buckets2 = c.bucket_count();
        settle();
        at_n2 = private_bytes();

        check(buckets1 == buckets2,
              "no rehash between the two samples, so the slope is nodes alone");
    }

    const double node_bytes =
        (double(at_n2) - double(at_n1)) / double(n2 - n1);

    // total = buckets + n*node, so the residual after removing the nodes IS the
    // bucket array. This had a stray "/ 8.0" in the first version -- there is no
    // reason to divide a residual by anything -- which reported 614144 bytes for
    // 262144 buckets, i.e. 2.34 bytes per bucket. The real figure is 4915152,
    // about 18.75 bytes each, which is what MSVC's per-bucket node list costs on
    // x64 plus allocator slack. A measuring tool that reports a wrong number is
    // worse than no tool, so the division is gone and the per-bucket figure is
    // printed explicitly so it can be sanity-checked against sizeof by eye.
    const double total_at_n1 = double(at_n1 - base);
    const double bucket_bytes = total_at_n1 - double(n1) * node_bytes;
    const double bucket_each = buckets1 ? bucket_bytes / double(buckets1) : 0.0;

    std::printf("  nodes: %zu -> %zu, buckets %zu -> %zu\n", n1, n2, buckets1, buckets2);
    std::printf("  measured node cost      = %.1f bytes/entry\n", node_bytes);
    std::printf("  measured bucket array   = %.0f bytes (%zu buckets, %.2f each)\n",
                bucket_bytes, buckets1, bucket_each);
    std::printf("  measured total at %zu   = %.1f MB\n", n2,
                (total_at_n1 + (double(at_n2) - double(at_n1))) / (1024.0 * 1024.0));
    std::printf("  sizeof(MetaKey)         = %zu bytes (type-level floor)\n",
                sizeof(MetaKey));
    std::printf("  overhead vs sizeof      = %.1fx\n",
                node_bytes / double(sizeof(MetaKey)));

    check(node_bytes > double(sizeof(MetaKey)),
          "a heap node costs more than the key itself (header + rounding)");
    check(node_bytes < double(sizeof(MetaKey)) * 4.0,
          "and not absurdly more -- guards against measuring the wrong thing");
    check(bucket_bytes > 0.0, "a bucket array exists and costs something");

    // --- NEGATIVE CONTROL: destroy it and the memory must come back --------
    SIZE_T before_free = 0, after_free = 0;
    {
        cache_t c;
        fill(c, 0, n2);
        settle();
        before_free = private_bytes();
    }
    settle();
    after_free = private_bytes();

    const double released = double(before_free - after_free);
    const double held = double(before_free - base);
    std::printf("  held %.1f MB, released on destroy %.1f MB\n",
                held / (1024.0 * 1024.0), released / (1024.0 * 1024.0));
    check(released > held * 0.5,
          "destroying the map returns its memory -- so the delta above was the map, not background noise");

    // --- the CPU premise: what an inert zone costs -------------------------
    //
    // TA_ZONE_N expands to a tracy::profiler::Zone whose constructor opens with
    // `if (!running()) return;` -- one acquire load and a branch. That is the
    // entire per-call cost of the instrumentation when the profiler is NOT
    // started, and it is the number that decides whether shipping 200-odd zones
    // in Prod costs anything in normal play.
    //
    // What is measured is the gate, NOT the whole macro. The macro additionally
    // builds a std::optional<ScopedZone> and, for the 11 TA_ZONE_SITE sites, runs
    // compose_site() UNCONDITIONALLY before the constructor even runs -- those are
    // the sites where instrumentation is not free, and they are called out here
    // rather than folded into a flattering average.
    //
    // Deliberately NOT volatile: the point is what the compiler emits when the
    // flag is genuinely false and hoisting is legal. Marking it volatile would
    // force a load the shipping build does not need and inflate the answer.
    std::atomic<bool> g_running{ false };
    const int kGateIters = 20'000'000;
    auto t0 = std::chrono::steady_clock::now();
    std::size_t taken = 0;
    for (int i = 0; i < kGateIters; ++i) {
        if (!g_running.load(std::memory_order_acquire)) { taken++; continue; }
    }
    auto t1 = std::chrono::steady_clock::now();
    const double ns_per_gate =
        std::chrono::duration<double, std::nano>(t1 - t0).count() / double(kGateIters);

    // 169 live zone names is the count tools/zone_gap.py --list-zones reports for
    // this tree; 60 fps is a round frame rate. Both are inputs to the product
    // below, so both are named rather than buried in the arithmetic.
    constexpr int kLiveZones = 169;
    constexpr int kFps = 60;
    const double us_per_frame = ns_per_gate * double(kLiveZones) / 1000.0;

    std::printf("  inert zone gate          = %.3f ns/call (%zu of %d took the early-out)\n",
                ns_per_gate, taken, kGateIters);
    std::printf("  %d live zones @ %d fps    = %.4f us/frame = %.4f%% of one core\n",
                kLiveZones, kFps, us_per_frame, us_per_frame / 10000.0 * 100.0);

    check(taken == std::size_t(kGateIters),
          "the gate was actually taken every iteration -- an optimised-away loop measures nothing");
    check(ns_per_gate < 50.0,
          "an inert zone is nanoseconds, not something that can show up in a frame budget");

    if (g_failures) {
        std::printf("footprint_cost: %d check(s) FAILED\n", g_failures);
        return 1;
    }
    std::printf("footprint_cost: OK\n");
    return 0;
}