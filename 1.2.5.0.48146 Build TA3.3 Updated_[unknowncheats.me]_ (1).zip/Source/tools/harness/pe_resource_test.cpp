// Coverage for TarkovAddons/util/pe_resource.h -- the RCDATA reader.
//
//  tools/harness/run_windows.bat      (exit 0 = pass, 1 = fail)
//
// This is the Windows half of the harness. pe_resource.h cannot be covered by
// run.sh because it is nothing but Win32: GetModuleHandleExW, VirtualQuery,
// ReadProcessMemory, FindResourceW. It does not need the project build, the
// game, or a deployed DLL though -- only an MSVC toolchain and rc.exe. That is
// all this needs, and the excuse that it "has no coverage" was one.
//
// It compiles the real header into this executable with real RCDATA compiled in,
// which is what makes the assertions below meaningful: they exercise the same
// call shape the mod uses (a function handing its OWN address to the reader)
// against an image the loader has genuinely registered.
//
// Every block below is validated by negative control -- deliberately reverting
// the behaviour it guards, and confirming the harness fails. Two of these
// controls caught tests that were passing for the wrong reason, which is noted
// where it happened. A test that cannot fail is worse than no test.
//
// Exit code is the pass/fail signal; the assertion count is printed for the
// record.

#include "../../TarkovAddons/util/pe_resource.h"

#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <semaphore>
#include <string>
#include <thread>

namespace {

    int g_checks = 0;
    int g_failures = 0;

    void check(bool ok, const char* what) {
        ++g_checks;
        if (!ok) ++g_failures;
        std::printf("  [%s] %s\n", ok ? "PASS" : "FAIL", what);
    }

    // The two address shapes the mod actually uses. util/i18n.cpp and
    // gui/menu/menu.cpp pass the address of a static function in a .cpp;
    // module/minimap.h passes the address of an INLINE function in a header.
    // Both are exercised against both payload ids, because the 2026-09-30
    // minimap failure was diagnosed down to "which shape of address?", and a
    // test covering only one of them cannot answer it.
    const std::byte* static_reader(WORD resource_id, DWORD& out_size) {
        return pe_resource::rcdata(nullptr, &static_reader, resource_id, out_size);
    }

    inline const std::byte* inline_reader(WORD resource_id, DWORD& out_size) {
        return pe_resource::rcdata(nullptr, &inline_reader, resource_id, out_size);
    }

    std::string as_text(const std::byte* bytes, DWORD size) {
        if (!bytes || !size) return {};
        return std::string(reinterpret_cast<const char*>(bytes), size);
    }

    std::size_t page_size() {
        SYSTEM_INFO info{};
        GetSystemInfo(&info);
        return info.dwPageSize;
    }

    void write_pe_header(std::byte* base, std::size_t image_bytes) {
        auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
        dos->e_magic = IMAGE_DOS_SIGNATURE;
        dos->e_lfanew = 0x100;
        auto* nt = reinterpret_cast<IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
        nt->Signature = IMAGE_NT_SIGNATURE;
        nt->FileHeader.SizeOfOptionalHeader = sizeof(IMAGE_OPTIONAL_HEADER);
        nt->OptionalHeader.SizeOfImage = static_cast<DWORD>(image_bytes);
    }

    // ------------------------------------------------------------------------
    // 1. The payloads are actually read back, byte for byte.
    //
    // The regression this guards is the one from CHANGELOG 5: a caller that
    // resolves the wrong module returns nothing, and the on-disk fallback makes
    // every feature look fine anyway. So the assertion is on CONTENT, and on
    // both address shapes -- not merely "some bytes came back".
    // ------------------------------------------------------------------------
    void test_payloads_round_trip() {
        std::printf("\n1. RCDATA payloads round-trip through both address shapes\n");

        const std::string expected = "pe_resource harness payload\n";

        for (WORD id : { WORD(1200), WORD(1300) }) {
            DWORD size = 0;
            const std::byte* bytes = static_reader(id, size);
            const std::string text = as_text(bytes, size);
            char label[96];

            std::snprintf(label, sizeof(label), "static_reader(%u) returns the payload", id);
            check(bytes != nullptr && text == expected, label);
            std::snprintf(label, sizeof(label), "static_reader(%u) size is exact", id);
            check(size == expected.size(), label);

            DWORD size2 = 0;
            const std::byte* bytes2 = inline_reader(id, size2);
            std::snprintf(label, sizeof(label), "inline_reader(%u) returns the payload", id);
            check(bytes2 != nullptr && as_text(bytes2, size2) == expected, label);
            std::snprintf(label, sizeof(label),
                "static and inline readers agree byte for byte (%u)", id);
            check(bytes && bytes2 && size == size2 && std::memcmp(bytes, bytes2, size) == 0,
                label);
        }

        DWORD size = 0;
        check(static_reader(WORD(1201), size) == nullptr && size == 0,
            "an undeclared id fails and leaves out_size at 0");
        check(std::strstr(pe_resource::last_failure(), "RT_RCDATA") != nullptr,
            "and says the section was reached but the id was not there");
    }

    // ------------------------------------------------------------------------
    // 2. image_base_from() resolves this image, from code AND from data.
    //
    // The header accepts "any address inside our own module"; only the code
    // shape is used by any in-tree caller, so the data shape is asserted here
    // rather than assumed.
    // ------------------------------------------------------------------------
    void test_image_base_from_this_image() {
        std::printf("\n2. image_base_from() resolves this image\n");

        const auto* exe = reinterpret_cast<const std::byte*>(GetModuleHandleW(nullptr));

        const void* code = reinterpret_cast<const void*>(
            reinterpret_cast<std::uintptr_t>(&pe_resource::image_base_from));
        const void* data = static_cast<const void*>(&g_checks);

        check(pe_resource::image_base_from(code) == exe, "from a code address");
        check(pe_resource::image_base_from(data) == exe, "from a data address");
        check(pe_resource::scan_back_for_image_base(code) == exe,
            "scan_back_for_image_base() alone finds it from a code address");
        check(pe_resource::image_contains(exe, code), "image_contains(): we are inside");
        check(pe_resource::image_extent_at(nullptr) == 0, "image_extent_at(nullptr) is 0");
    }

    // ------------------------------------------------------------------------
    // 3. probe_readable() answers without VirtualQuery.
    //
    // One half of the load-bearing claim of the 2026-09-30 fix. is_readable()
    // used to begin with VirtualQuery and return false when it returned nothing,
    // which rejected a valid HMODULE and the AllocationBase in one stroke --
    // the one gate both image-base sources shared, and the reason 22/22
    // payloads were lost. probe_readable() is the escape hatch.
    //
    // What this CANNOT show is the blinded-VirtualQuery case itself:
    // VirtualQuery is an imported function, so interposing on it from a test
    // would mean redefining a dllimport, which is not a thing a test may do.
    // The claim is covered in two honest halves instead -- probe_readable() is
    // correct here, and test 5 shows the reader recovers a base with both API
    // sources dead. Asserting the composition would only assert the source.
    // ------------------------------------------------------------------------
    void test_probe_readable_without_virtualquery() {
        std::printf("\n3. probe_readable() answers without VirtualQuery\n");

        const std::size_t page = page_size();

        // Reserve, then commit ONE page. A reservation is rounded up to the
        // 64 KiB allocation granularity, so committing "one page" directly
        // leaves readable bytes past it and cannot test the boundary at all --
        // the first version of this test did exactly that and passed for the
        // wrong reason.
        void* reserved = VirtualAlloc(nullptr, 0x10000, MEM_RESERVE, PAGE_NOACCESS);
        void* committed = reserved
            ? VirtualAlloc(reserved, page, MEM_COMMIT, PAGE_READWRITE) : nullptr;
        if (committed) std::memset(committed, 0xCC, page);

        check(committed != nullptr && pe_resource::probe_readable(committed, 1),
            "a committed page is readable");
        check(committed != nullptr && pe_resource::probe_readable(committed, page),
            "a range covering exactly one committed page is readable");
        check(committed != nullptr && !pe_resource::probe_readable(
                static_cast<char*>(committed) + page + 8, 1),
            "reserved-but-not-committed past the end is not readable, and does not fault");

        // Two adjacent COMMITTED pages in one reservation, with DIFFERENT
        // protections. The differing protection is what makes VirtualQuery report
        // two regions rather than merging them into one -- same protection on both
        // pages and it merges, and the whole point of the test evaporates (which
        // is how the first attempt at this assertion passed with the fallback
        // removed). A range crossing the boundary then runs past "its" region
        // even though every byte is readable, so is_readable() must delegate to
        // probe_readable() rather than refuse and lose a legitimate read across a
        // section boundary. With a VirtualQuery-only is_readable() the first
        // assertion below fails -- that is how this coverage was verified.
        void* two_pages = VirtualAlloc(nullptr, 0x10000, MEM_RESERVE, PAGE_NOACCESS);
        const bool committed_pair = two_pages
            && VirtualAlloc(two_pages, page, MEM_COMMIT, PAGE_READWRITE)
            && VirtualAlloc(static_cast<char*>(two_pages) + page, page, MEM_COMMIT, PAGE_READONLY);
        if (committed_pair) {
            const auto* boundary = static_cast<const char*>(two_pages) + page - 1;
            check(pe_resource::is_readable(boundary, 2),
                "a range spanning two adjacent committed regions is readable");
            check(pe_resource::probe_readable(boundary, 2),
                "probe_readable() agrees that it is");
            check(!pe_resource::is_readable(boundary, page * 4),
                "a range reaching uncommitted memory beyond them is not");
        } else {
            check(false, "could not commit two adjacent pages");
        }
        VirtualFree(two_pages, 0, MEM_RELEASE);

        void* denied = VirtualAlloc(nullptr, 0x10000, MEM_COMMIT | MEM_RESERVE, PAGE_NOACCESS);
        check(denied != nullptr && !pe_resource::probe_readable(denied, 1),
            "PAGE_NOACCESS is not readable, and does not fault");
        check(denied != nullptr && !pe_resource::is_readable(denied, 1),
            "is_readable() agrees on PAGE_NOACCESS");
        VirtualFree(denied, 0, MEM_RELEASE);

        void* released = VirtualAlloc(nullptr, page, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
        VirtualFree(released, 0, MEM_RELEASE);
        check(!pe_resource::probe_readable(released, 1), "released memory is not readable");
        check(!pe_resource::probe_readable(nullptr, 1), "null is not readable");
        check(!pe_resource::probe_readable(committed, 0), "zero length is not readable");

        VirtualFree(reserved, 0, MEM_RELEASE);
    }

    // ------------------------------------------------------------------------
    // 4. The backward scan's containment guard.
    //
    // What makes the scan safe rather than merely different. Scanning down from
    // an arbitrary address reaches SOME other image's base if ours is missing or
    // unreadable, and accepting it walks a neighbouring .rsrc -- a silent wrong
    // answer, worse than the failure it was added to fix.
    //
    // Planted headers, adjacent and page-aligned:
    //
    //     page 0 : decoy, 1-page image
    //     page 1 : TARGET, 2-page image  <- contains pages 1 and 2
    //     page 2 : the probe address
    //     page 4 : decoy, 1-page image
    //
    // The discriminating assertion is the SECOND half. Once the target is shrunk
    // so nothing contains the probe, the only correct answer is "no base at
    // all". A scan that stops at the nearest header returns page 1, which is
    // exactly the bug. An earlier version asserted "!= the decoy below", which
    // passed with or without the guard -- confirmed by negative control.
    // ------------------------------------------------------------------------
    void test_scan_containment_guard() {
        std::printf("\n4. scan_back_for_image_base() only accepts a containing image\n");

        const std::size_t page = page_size();
        void* block = VirtualAlloc(nullptr, 8 * page, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
        if (!block) { check(false, "could not reserve the fixture block"); return; }
        std::memset(block, 0, 8 * page);

        auto at = [=] (std::size_t index) -> std::byte* {
            return reinterpret_cast<std::byte*>(block) + index * page;
        };

        write_pe_header(at(0), page);        // decoy below
        write_pe_header(at(1), 2 * page);    // the target
        write_pe_header(at(4), page);        // decoy above

        check(pe_resource::image_contains(at(1), at(2)),
            "image_contains(): the target does contain the address");
        check(!pe_resource::image_contains(at(0), at(2)),
            "image_contains(): the neighbour below does not");
        check(!pe_resource::image_contains(at(4), at(2)),
            "image_contains(): the neighbour above does not");
        check(pe_resource::scan_back_for_image_base(at(2)) == at(1),
            "the scan resolves to the image that contains the address");

        // Shrink the target: now NO planted image covers the probe, so the only
        // correct answer is no base whatsoever.
        write_pe_header(at(1), page);
        check(!pe_resource::image_contains(at(1), at(2)),
            "a header whose SizeOfImage stops short is refused");
        check(pe_resource::scan_back_for_image_base(at(2)) == nullptr,
            "with nothing containing the address the scan returns NO base, "
            "not the nearest header");

        std::memset(at(1), 0x41, page);
        check(!pe_resource::looks_like_pe_image(at(1)), "a page of 'A' is not an image");
        check(pe_resource::scan_back_for_image_base(at(2)) == nullptr,
            "and a garbage page does not become a base either");

        VirtualFree(block, 0, MEM_RELEASE);
    }

    // ------------------------------------------------------------------------
    // 5. image_base_from() recovers a base with BOTH API sources failing.
    //
    // The end-to-end claim, and the closest thing to the original failure a
    // test can build without the game. A split image -- header page and body
    // page as separate adjacent allocations -- is in no registered module, so
    // GetModuleHandleExW(FROM_ADDRESS) returns nothing, and
    // VirtualQuery().AllocationBase is the body, which is not a PE header. Only
    // the backward scan can answer.
    //
    // Before the fix, image_base_from() returned nullptr here, and that is what
    // lost the minimap's 22 payloads.
    // ------------------------------------------------------------------------
    void test_split_image_base_recovery() {
        std::printf("\n5. image_base_from() recovers a base when both API sources fail\n");

        const std::size_t page = page_size();

        // A reservation is rounded up to the allocation granularity, so two
        // ONE-page reservations cannot be placed one page apart -- the hint lands
        // inside the first one. Real images are granularity-aligned anyway
        // (0x10000 on x64), so the fixture reserves a full granularity each and
        // commits only its first page. That is also closer to what a loader
        // doing per-section allocation actually does.
        const std::size_t gran = 0x10000;
        std::byte* headers = nullptr;
        std::byte* body = nullptr;

        // The pair is placed with an upward-walking hint rather than asking for
        // the first allocation at null: the low heap hands back the same address
        // on every retry, so a null-first loop never finds a partner.
        for (int attempt = 0; attempt < 8 && !body; ++attempt) {
            void* first = VirtualAlloc(
                reinterpret_cast<void*>(0x10000000ull + (std::uintptr_t)attempt * 0x4000000ull),
                gran, MEM_RESERVE, PAGE_NOACCESS);
            if (!first) continue;
            void* second = VirtualAlloc(static_cast<std::byte*>(first) + gran, gran,
                MEM_RESERVE, PAGE_NOACCESS);
            if (second
                && VirtualAlloc(first, page, MEM_COMMIT, PAGE_READWRITE)
                && VirtualAlloc(second, page, MEM_COMMIT, PAGE_READWRITE)) {
                headers = static_cast<std::byte*>(first);
                body = static_cast<std::byte*>(second);
                break;
            }
            if (second) VirtualFree(second, 0, MEM_RELEASE);
            VirtualFree(first, 0, MEM_RELEASE);
        }

        if (!body) {
            // Reported, never silently skipped: a skipped test reads as a passed one.
            check(false, "could not obtain two adjacent allocations for a split image");
            return;
        }

        write_pe_header(headers, 2 * gran);  // SizeOfImage spans both reservations
        const void* address = body;

        // Confirm the premise before asserting the conclusion, so a later change
        // to the fixture cannot make the interesting assertion vacuous.
        check(pe_resource::hmodule_from_address(address) == nullptr,
            "premise: GetModuleHandleExW(FROM_ADDRESS) fails (no registered module)");

        MEMORY_BASIC_INFORMATION info{};
        const bool queried = VirtualQuery(address, &info, sizeof(info)) != 0;
        check(queried && info.AllocationBase == body,
            "premise: VirtualQuery().AllocationBase is the body, not the image base");
        check(!pe_resource::looks_like_pe_image(
                  static_cast<const std::byte*>(info.AllocationBase)),
            "premise: that AllocationBase is not a PE header, so source 2 fails too");

        check(pe_resource::scan_back_for_image_base(address) == headers,
            "the backward scan finds the header page");
        check(pe_resource::image_base_from(address) == headers,
            "image_base_from() returns the image base with both API sources dead");
        check(pe_resource::image_contains(headers, address),
            "and the recovered image does contain the code address");

        VirtualFree(body, 0, MEM_RELEASE);
        VirtualFree(headers, 0, MEM_RELEASE);
    }

    // ------------------------------------------------------------------------
    // 7. The init-time captured base, including the case that actually broke.
    //
    // The real failure, 2026-09-30: this reader worked at startup (i18n read 19
    // locale payloads) and every way of ASKING for the image base stopped
    // answering 3.5 minutes later -- the minimap's 22 map payloads were lost,
    // from the same image, through the same reader. So the fix is not a better
    // query, it is not needing a query: DllMain's hModule IS the base, at the
    // one moment its headers are guaranteed readable.
    //
    // The decisive assertion is the middle one. It reproduces the failure
    // directly: capture, then make the headers unreadable, then show that
    // captured_image_base_for() still answers while all three query sources are
    // dead. Verified by negative control -- dropping the cache from
    // image_base_from() fails it.
    // ------------------------------------------------------------------------
    void test_captured_image_base() {
        std::printf("\n7. the init-time captured base\n");

        const std::size_t page = page_size();
        std::byte* headers = nullptr;
        std::byte* body = nullptr;

        for (int attempt = 0; attempt < 8 && !body; ++attempt) {
            void* first = VirtualAlloc(
                reinterpret_cast<void*>(0x20000000ull + (std::uintptr_t)attempt * 0x4000000ull),
                0x10000, MEM_RESERVE, PAGE_NOACCESS);
            if (!first) continue;
            void* second = VirtualAlloc(static_cast<std::byte*>(first) + 0x10000, 0x10000,
                MEM_RESERVE, PAGE_NOACCESS);
            if (second
                && VirtualAlloc(first, page, MEM_COMMIT, PAGE_READWRITE)
                && VirtualAlloc(second, page, MEM_COMMIT, PAGE_READWRITE)) {
                headers = static_cast<std::byte*>(first);
                body = static_cast<std::byte*>(second);
                break;
            }
            if (second) VirtualFree(second, 0, MEM_RELEASE);
            VirtualFree(first, 0, MEM_RELEASE);
        }
        if (!headers) { check(false, "could not build a split-image fixture"); return; }

        write_pe_header(headers, 0x20000);

        // Before capture: the cache is empty and must not answer.
        check(pe_resource::captured_image_base_for(body) == nullptr,
            "an uncaptured base does not answer");

        pe_resource::remember_image_base(headers);
        check(pe_resource::captured_image_base_for(body) == headers,
            "after capture the base serves an address inside the image");
        check(pe_resource::captured_image_base_for(headers) == headers,
            "including the base address itself");
        check(pe_resource::captured_image_base_for(headers + 0x20000) == nullptr,
            "but not one past SizeOfImage");
        check(pe_resource::captured_image_base_for(headers - page) == nullptr,
            "and not one below the base");

        // Idempotent: a later bad capture must not replace a good one.
        pe_resource::remember_image_base(reinterpret_cast<std::byte*>(0x1234));
        check(pe_resource::captured_image_base_for(body) == headers,
            "a rejected later capture leaves the good one in place");

        // THE REGRESSION. Blank the headers and make the page inaccessible, so
        // every query source -- GetModuleHandleExW, AllocationBase, backward
        // scan -- now fails, exactly as it did in the game. The captured base
        // must still answer, because serving it reads no headers at all.
        DWORD old_protect = 0;
        const bool locked = VirtualProtect(headers, page, PAGE_NOACCESS, &old_protect) != 0;
        check(locked, "the header page can be made inaccessible");
        std::memset(body, 0x41, page);

        check(!pe_resource::looks_like_pe_image(headers),
            "premise: the headers no longer validate");
        check(!pe_resource::image_contains(headers, body),
            "premise: so containment by a fresh read fails too");
        check(pe_resource::scan_back_for_image_base(body) == nullptr,
            "premise: and the backward scan finds nothing");

        check(pe_resource::captured_image_base_for(body) == headers,
            "the captured base STILL answers with the headers unreadable");
        check(pe_resource::image_base_from(body) == headers,
            "so image_base_from() succeeds where all three query sources fail");

        if (locked) VirtualProtect(headers, page, old_protect, &old_protect);
        VirtualFree(body, 0, MEM_RELEASE);
        VirtualFree(headers, 0, MEM_RELEASE);
    }

    // ------------------------------------------------------------------------
    // 6. last_failure() is per-thread.
    //
    // It used to be one shared const char*, written by the failing lookup and
    // read once afterwards -- from a render thread running the reader 22 times
    // while i18n.cpp and menu.cpp call it from other threads. The header
    // documented that race as benign; it was not, because that string was the
    // only evidence of why a total failure happened. Assert it, or it decays
    // back into a shared pointer without anyone noticing.
    //
    // The ordering has to be forced. An earlier version read main's reason
    // straight after constructing the thread, which the worker may not have been
    // scheduled for yet -- so it passed with the buffer deliberately NOT
    // thread_local. Negative control is what found that.
    // ------------------------------------------------------------------------
    void test_last_failure_is_thread_local() {
        std::printf("\n6. last_failure() is per-thread\n");

        std::string from_main;
        std::string from_worker;

        pe_resource::set_failure("main-thread reason");

        std::binary_semaphore worker_wrote(0);
        std::binary_semaphore main_checked(0);

        std::thread worker([&] {
            pe_resource::set_failure("worker-thread reason");
            worker_wrote.release();
            main_checked.acquire();
            from_worker = pe_resource::last_failure();
        });

        worker_wrote.acquire();
        from_main = pe_resource::last_failure();
        main_checked.release();
        worker.join();

        check(from_main == "main-thread reason",
            "the writing thread keeps its own reason after another thread overwrote it");
        check(from_worker == "worker-thread reason",
            "the other thread keeps its own reason after the first thread wrote again");
        check(std::strlen(pe_resource::last_failure()) < 512,
            "the reason buffer is bounded");
    }

} // namespace

int main() {
    std::printf("pe_resource harness -- assertions against the real util/pe_resource.h\n");

    test_payloads_round_trip();
    test_image_base_from_this_image();
    test_probe_readable_without_virtualquery();
    test_scan_containment_guard();
    test_split_image_base_recovery();
    test_captured_image_base();
    test_last_failure_is_thread_local();

    std::printf("\n%d/%d assertions passed\n", g_checks - g_failures, g_checks);
    if (g_failures) {
        std::printf("pe_resource harness: FAILED\n");
        return 1;
    }
    std::printf("pe_resource harness: OK\n");
    return 0;
}
