// Coverage for the WISHLIST half of TarkovAddons/module/item_categories.h.
//
// WHY THIS FILE EXISTS, measured 2026-10-12. `test_loot_categories.cpp` covers the
// loot taxonomy, and `llvm-cov` over the five portable cases said this header was
// 67/105 lines = 63.8% covered with only 5 of 11 functions executed. The six it
// never called were the wishlist classification half:
//
//     loot_class_is_known   wishlist_all_mask   filter_sets::add
//     filter_sets::in_group classify_id         classify_group
//
// That is the whole of the code that turns the game's EWishlistGroup dictionary into
// an answer. `wishlist_allows` -- the predicate the other test exercises -- is the
// LAST step of that chain and was tested while the four steps that produce its
// argument were not. A change to `classify_id`'s hideout-priority rule, or to
// `add`'s promise that it fills the per-group set and the union together, would
// have passed every test in the suite.
//
// The measurement is reproducible; see tools/harness/README.md for the command.
//
// NOT TESTED HERE, on purpose: nothing that needs IL2CPP, ImGui or Win32. These six
// are pure functions over a struct of string sets, which is why they belong in the
// portable set and not only in run_windows.bat.

#include <cstdint>
#include <iostream>
#include <string>

#include "../../TarkovAddons/module/item_categories.h"

namespace ic = item_categories;
// wishlist_group is a scoped ENUM, not a namespace -- `using` is the alias, and
// wl::quests still resolves because the enumerators are scoped to the enum type.
using wl = ic::wishlist_group;

static int g_pass = 0;
static int g_fail = 0;

static void check(const bool condition, const char* what) {
    if (condition) ++g_pass;
    else {
        ++g_fail;
        std::cout << "  FAIL: " << what << "\n";
    }
}

// A ready-to-query set with one id in one group.
static ic::filter_sets make_set() {
    ic::filter_sets s;
    s.ready = true;
    return s;
}

int main() {
    std::cout << "=== wishlist_all_mask and group_bit ===\n";

    // group_bit is derived from the enum's VALUE, so this pins the bit layout too.
    check(ic::group_bit(wl::quests) == 1u << 0, "quests is bit 0");
    check(ic::group_bit(wl::hideout) == 1u << 1, "hideout is bit 1");
    check(ic::group_bit(wl::trading) == 1u << 2, "trading is bit 2");
    check(ic::group_bit(wl::equipment) == 1u << 3, "equipment is bit 3");
    check(ic::group_bit(wl::other) == 1u << 4, "other is bit 4");

    // `none` is NOT on the wishlist, so it has no bit. This is the case that would
    // otherwise shift bit 8 into a uint8_t mask and look like a selection.
    check(ic::group_bit(wl::none) == 0, "none has no bit");

    const ic::wishlist_mask all = ic::wishlist_all_mask();
    check(all == 0x1F, "all-mask is five bits set");
    check(all == static_cast<ic::wishlist_mask>((1u << ic::kWishlistGroupCount) - 1),
        "all-mask is derived from the group count, not hardcoded");

    // Every real group is inside the all-mask. If someone appends a sixth enum value
    // without touching kWishlistGroupCount, this is what notices.
    for (int g = 0; g < ic::kWishlistGroupCount; ++g) {
        const auto grp = static_cast<wl>(g);
        check((all & ic::group_bit(grp)) != 0, "all-mask contains every group value");
    }

    std::cout << "=== filter_sets::add fills the per-group set AND the union ===\n";

    auto s = make_set();
    s.add("tpl_quest", wl::quests);
    s.add("tpl_hide", wl::hideout);
    s.add("tpl_trade", wl::trading);

    // The invariant the comment claims: one call, both sets. Checking each half
    // separately is the only way a future edit that drops the union write is caught.
    check(s.by_group[0].count("tpl_quest") == 1, "quests landed in by_group[0]");
    check(s.wishlist.count("tpl_quest") == 1, "quests landed in the wishlist union");
    check(s.hideout.count("tpl_quest") == 0, "quests did NOT leak into hideout");

    check(s.by_group[1].count("tpl_hide") == 1, "hideout landed in by_group[1]");
    check(s.hideout.count("tpl_hide") == 1, "hideout landed in the hideout union");
    check(s.wishlist.count("tpl_hide") == 0,
        "hideout does NOT also land in the wishlist union -- these are exclusive");

    // add() is documented as refusing two things.
    s.add("", wl::quests);
    check(s.wishlist.empty() == false && s.by_group[0].size() == 1,
        "an empty tid inserts nothing");
    s.add("tpl_none", wl::none);
    check(s.wishlist.count("tpl_none") == 0, "group none inserts nothing");
    check(s.by_group[0].size() == 1, "group none did not land in by_group[0] either");

    std::cout << "=== filter_sets::in_group ===\n";

    check(s.in_group("tpl_quest", wl::quests), "in_group finds its own group");
    check(!s.in_group("tpl_quest", wl::trading), "in_group does not cross groups");
    check(!s.in_group("", wl::quests), "an empty tid is never in a group");
    check(!s.in_group("tpl_none", wl::none), "group none is never in a group");

    // not-ready is a different refusal from empty-tid, and it is the one that
    // matters: the dictionary walk has not run yet.
    ic::filter_sets not_ready;
    not_ready.add("tpl_quest", wl::quests);
    check(!not_ready.in_group("tpl_quest", wl::quests),
        "a set that is not ready reports nothing, even with the id inserted");

    std::cout << "=== classify_id ===\n";

    check(ic::classify_id("tpl_quest", s) == ic::kind::wishlist, "an id in wishlist classifies as wishlist");
    check(ic::classify_id("tpl_hide", s) == ic::kind::hideout, "an id in hideout classifies as hideout");
    check(ic::classify_id("tpl_nope", s) == ic::kind::other, "an absent id classifies as other");
    check(ic::classify_id("", s) == ic::kind::other, "an empty id classifies as other");
    check(ic::classify_id("tpl_quest", not_ready) == ic::kind::other,
        "an unready set classifies everything as other");

    // Hideout takes priority when BOTH apply. To build that state I have to write
    // the same tid into both unions directly -- add() will not do it, which is the
    // point: the priority rule is unreachable through the normal path and would
    // therefore never be exercised if this case did not force it.
    {
        auto both = make_set();
        both.wishlist.insert("tpl_both");
        both.hideout.insert("tpl_both");
        check(ic::classify_id("tpl_both", both) == ic::kind::hideout,
            "hideout wins when an id is in both unions");
    }

    std::cout << "=== classify_group ===\n";

    check(ic::classify_group("tpl_quest", s) == wl::quests, "classify_group returns the group, not a kind");
    check(ic::classify_group("tpl_hide", s) == wl::hideout, "hideout id reports hideout");
    check(ic::classify_group("tpl_trade", s) == wl::trading, "trading id reports trading");
    check(ic::classify_group("tpl_nope", s) == wl::none, "an absent id is in no group");
    check(ic::classify_group("", s) == wl::none, "an empty id is in no group");
    check(ic::classify_group("tpl_quest", not_ready) == wl::none,
        "an unready set puts nothing in any group");

    // "Returns on the FIRST group that matches ... Lowest value wins there, which is
    // arbitrary and harmless." That is a documented choice, so it is worth pinning --
    // otherwise a well-meaning reordering looks like a fix.
    {
        auto dup = make_set();
        dup.by_group[0].insert("tpl_dup");
        dup.by_group[3].insert("tpl_dup");
        check(ic::classify_group("tpl_dup", dup) == wl::quests,
            "an id in two groups resolves to the lowest value, as documented");
    }

    std::cout << "=== the chain, end to end ===\n";

    // The four untested steps feeding the one already-tested step. If this is the
    // only test that ever runs them, then it is the only place a break in the
    // dictionary-walk -> group -> mask -> predicate chain can be caught.
    {
        auto chain = make_set();
        chain.add("tpl_gear", wl::equipment);
        const wl g = ic::classify_group("tpl_gear", chain);
        check(g == wl::equipment, "step 1-3: add -> in_group -> classify_group");
        const ic::wishlist_mask selected = ic::group_bit(g);
        check(ic::wishlist_allows(g, selected), "step 4: the user's own group is allowed");
        check(!ic::wishlist_allows(g, ic::group_bit(wl::trading)),
            "step 4: a group the user did not select is refused");
    }

    std::cout << "\n";
    if (g_fail == 0) std::cout << "PASS: " << g_pass << " passed, 0 failed\n";
    else std::cout << "FAIL: " << g_pass << " passed, " << g_fail << " failed\n";
    return g_fail == 0 ? 0 : 1;
}