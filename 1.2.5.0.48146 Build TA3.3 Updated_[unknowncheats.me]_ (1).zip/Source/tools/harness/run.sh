#!/usr/bin/env bash
# Build and run the native test harness.
#
#   tools/harness/run.sh              # build + run every case
#   tools/harness/run.sh --coverage   # the same, instrumented, and report it
#
# Runs on Linux or Windows-hosted Linux, needs only a C++23 compiler -- no MSVC,
# no mingw, no project build, no game. That is the whole point: the coverage
# WORKFLOW.md records as lost was lost because it could only be run by one person
# on one machine, in a temp directory. This runs anywhere and lives in the repo.
#
# Case count here and in run_windows.bat are deliberately different: this file is
# the portable subset, that one is the full native set. loot_categories was already
# built by run_windows.bat's :portable helper and is only new HERE -- the point is
# that the loot taxonomy is now the shared predicate for two modules (see
# item_categories::loot_category_allows), so its table should be checked by
# everyone, not only by whoever is on Windows.
#
# --coverage adds clang's source-based coverage (-fprofile-instr-generate
# -fcoverage-mapping) and writes a merged report to tools/harness/coverage/.
# It is OPT-IN and clang-only: g++ has no equivalent of the coverage *mapping*, so
# with CXX=g++ the flag exits 2 and says so rather than reporting gcno line counts
# and calling them the same thing. Needs llvm-profdata and llvm-cov on PATH.
#
# This is the ONLY executable coverage of real code in this repository. Every other
# candidate needs the game, which is why the harness exists at all.
#
# A TRAP this flag exists to make hard to hit by accident, measured 2026-10-12:
# `llvm-cov report a b c -instr-profile=merged` uses ONLY THE FIRST BINARY's
# coverage mapping and silently ignores the rest. It reported a flawless 100% over
# 2 of the 6 first-party files. With several binaries you must pass one -object per
# binary; emit_coverage_report below does. Do not hand-roll this.
set -uo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
REPO=$(cd "$HERE/../.." && pwd)
CXX=${CXX:-g++}
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT

COVERAGE=0
for arg in "$@"; do
  case "$arg" in
    --coverage) COVERAGE=1 ;;
    -h|--help) sed -n '2,30p' "$0"; exit 0 ;;
    *) echo "unknown option: $arg (try --help)" >&2; exit 2 ;;
  esac
done

if [ "$COVERAGE" = 1 ]; then
  case "$(basename "$CXX")" in
    clang|clang++|clang-*) ;;
    *) echo "--coverage needs clang (CXX=$CXX). g++ has no coverage mapping." >&2
       exit 2 ;;
  esac
fi

# The first-party files these cases actually compile. Listed explicitly so the
# report can exclude the harness itself and the shim: coverage of the test is not
# coverage of the thing under test, and a total mixing the two reads as a bigger
# number than it is. quick_search.h and hotkey_conflicts.h joined on 2026-10-12
# with the menu quick-jump work. survival_clamp.h was MISSING until the same
# change, even though test_survival_clamp.cpp has compiled it since it landed --
# an absent file silently drops out of the report, which is the same failure the
# exclusion list was written for. changed_marker_layout.h joined 2026-10-14, the
# day the gutter dot's position moved off the row height and onto the label line.
# column_layout.h is correctly absent: its case
# is Windows-only, so no portable case compiles it.
FIRST_PARTY=(
  "$REPO/TarkovAddons/config/ConfigValue.cpp"
  "$REPO/TarkovAddons/config/ConfigValue.h"
  "$REPO/TarkovAddons/gui/menu/card_fold_state.h"
  "$REPO/TarkovAddons/gui/menu/changed_marker_layout.h"
  "$REPO/TarkovAddons/gui/menu/hotkey_conflicts.h"
  "$REPO/TarkovAddons/gui/menu/quick_search.h"
  "$REPO/TarkovAddons/module/item_categories.h"
  "$REPO/TarkovAddons/module/quest_objective_text.h"
  "$REPO/TarkovAddons/module/survival_clamp.h"
  "$REPO/TarkovAddons/util/text_fold.h"
)

emit_coverage_report() {
  command -v llvm-profdata >/dev/null || { echo "llvm-profdata not on PATH" >&2; return 2; }
  command -v llvm-cov      >/dev/null || { echo "llvm-cov not on PATH" >&2; return 2; }
  # Fail closed FIRST. A report built from zero profiles is a table of nans.
  compgen -G "$OUT/*.profraw" >/dev/null || {
    echo "no .profraw produced -- the binaries were not instrumented" >&2; return 2; }

  local dest="$HERE/coverage"
  mkdir -p "$dest"
  # llvm-cov needs the FIRST binary POSITIONALLY as well as one -object per binary.
  # Passing only -object flags makes it treat the trailing source-filter paths as
  # objects and it fails with "The file was not recognized as a valid object file".
  local first="" objects=() bin
  for bin in "$OUT"/*; do
    case "$bin" in *.profraw|*.profdata|*.log) continue ;; esac
    [ -x "$bin" ] || continue
    if [ -z "$first" ]; then first="$bin"; else objects+=(-object "$bin"); fi
  done
  [ -n "$first" ] || { echo "no instrumented binaries in $OUT" >&2; return 2; }

  llvm-profdata merge -sparse "$OUT"/*.profraw -o "$OUT/merged.profdata" || return 2
  llvm-cov report "$first" "${objects[@]}" -instr-profile="$OUT/merged.profdata" \
      "${FIRST_PARTY[@]}" > "$dest/report.txt" 2>"$dest/report.stderr" || {
    echo "llvm-cov failed:" >&2; cat "$dest/report.stderr" >&2; return 2; }

  echo ""
  echo "coverage, first-party files only -- $dest/report.txt"
  cat "$dest/report.txt"
  if [ -s "$dest/report.stderr" ]; then
    echo ""
    echo "llvm-cov stderr. 'functions have mismatched data' means two binaries compiled"
    echo "the same header differently; per-file figures still agree (verified), but"
    echo "check this before quoting a TOTAL:"
    cat "$dest/report.stderr"
  fi
}

status=0
run_case() {
  local name=$1 src=$2; shift 2
  printf '\n=== %s\n' "$name"
  local extra=()
  [ "$COVERAGE" = 1 ] && extra=(-fprofile-instr-generate -fcoverage-mapping)
  if ! "$CXX" -std=c++23 "${extra[@]}" -I "$HERE/shim" -I "$REPO" "$@" \
       "$HERE/$src" "$HERE/stubs.cpp" "$REPO/TarkovAddons/config/ConfigValue.cpp" \
       -o "$OUT/$name" 2>"$OUT/$name.log"; then
    echo "  BUILD FAILED"
    head -20 "$OUT/$name.log"
    status=1
    return
  fi
  if [ "$COVERAGE" = 1 ]; then
    LLVM_PROFILE_FILE="$OUT/$name.profraw" "$OUT/$name" || status=1
  else
    "$OUT/$name" || status=1
  fi
}

run_case config test_config.cpp
run_case card_fold test_card_fold.cpp
run_case loot_categories test_loot_categories.cpp
# quest_objective_text.h is header-only with no IL2CPP, no ImGui and no Win32, so
# this case needs neither the shim nor the i18n stub that config's case needs --
# run_case links stubs.cpp unconditionally, and stubs.cpp only defines i18n::tr,
# so an extra definition here is harmless rather than a duplicate.
run_case quest_objectives_text test_quest_objectives_text.cpp
# text_fold.h is header-only with no IL2CPP, no ImGui and no Win32, for the same
# reason quest_objectives_text needs neither shim nor i18n stub -- see the comment
# above that case. It covers the UTF-8 case folding the ITEM SEARCH uses, which
# is the mechanism that makes a Russian or Greek player's query match a localized
# name. std::tolower (ASCII-only in the C locale) is the behaviour it replaced.
run_case text_fold test_text_fold.cpp
# wishlist_groups covers the wishlist half of item_categories.h -- the part the
# loot_categories case above does not reach. It exists because llvm-cov over these
# cases measured that header at 5 of 11 functions executed, with the entire
# dictionary-walk -> group -> mask -> predicate chain untested except its last step.
# Portable for the same reason as the two above: pure functions over string sets.
# Negative-controlled 2026-10-12 -- three mutations of item_categories.h each fail
# it by name. See run_windows.bat for the long form.
run_case wishlist_groups test_wishlist_groups.cpp
# survival_clamp is the damage clamp behind the three survival modes (god_mode,
# "Buddha Mode"/god_mode2, semi_god_mode). Header-only with no IL2CPP, no ImGui and
# no Win32 -- it was lifted out of PlayerModule.h precisely so the decision table
# could be checked without the game. Negative-controlled 2026-10-12: five mutations
# of survival_clamp.h each fail it by name. See run_windows.bat for the long form.
run_case survival_clamp test_survival_clamp.cpp

# quick_search is the fuzzy ranking behind the menu's quick-jump palette
# (Ctrl+K). Portable for the same reason column_layout needs nothing: the
# header is pure functions over strings -- no ImGui, no IL2CPP, no Win32 --
# because menu.cpp itself cannot be linked by any test that does not have the
# game's headers, the artwork and the DX hook. The assertions that matter are
# the ordering ones: a matcher that finds the right row fourth is a feature
# nobody uses twice, and no amount of "it matched something" would catch that.
# Cyrillic folding is asserted on purpose -- std::tolower is ASCII-only in this
# project's C locale, which is the defect util/text_fold.h exists for.
run_case quick_search test_quick_search.cpp

# hotkey_conflicts is the grouping behind the key-conflict report in the
# hotkeys panel. Portable for the same reason: it is bookkeeping over
# (key, label) rows with no ImGui and no Win32 -- the literal for the menu
# toggle key is asserted here and again in hotkeys.h against VK_INSERT, which
# is what lets the header stay compilable off-Windows. The load-bearing rule
# is that key 0 (unbound) never collides.
run_case hotkey_conflicts test_hotkey_conflicts.cpp

# changed_marker_layout is where the changed-from-default gutter dot goes.
# Portable for the same reason: it is arithmetic on four floats, with no ImGui
# and no Win32, because the call site in menu.cpp cannot be linked by anything.
# What matters is that the answer does not DEPEND ON THE ROW'S HEIGHT -- in this
# menu the row height is content (a two-line slider, and a search row that grows
# with the number of results), so a height-derived position slides while the user
# reads the label. That is what the two earlier versions did.
run_case changed_marker_layout test_changed_marker_layout.cpp

printf '\n'
if [ "$status" -eq 0 ]; then
  echo "harness: OK"
else
  echo "harness: FAILED"
fi

# The report runs even when a case failed, because a partial run still says which
# lines were reached -- but it cannot rescue the exit status.
if [ "$COVERAGE" = 1 ]; then
  emit_coverage_report || echo "coverage report FAILED -- see above" >&2
fi

exit "$status"
