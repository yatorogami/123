param([string]$Slot = "opencode")

# Derived from this script's own location, not hardcoded: deploy.py drives
# this through its CMake backend, and that works from any checkout path.
$root  = Split-Path -Parent $PSScriptRoot
$build = "$root\build\Prod\x64\$Slot"
$src   = "$build\out\prod\with_aimbot"
$dst   = "$root\TarkovAddons\out\prod\with_aimbot"

# ---------------------------------------------------------------------------
# Mirror the build tree's out/prod/with_aimbot/ into the deploy folder.
#
# The vcxproj's PostBuildEvent copied DLL + map + config files from $(IntDir)
# to $(OutDir) = TarkovAddons\out\prod\with_aimbot\ after every build. CMake's
# RUNTIME_OUTPUT_DIRECTORY_PROD points the linker at the build tree instead,
# so nothing reaches the deploy folder and deploy.py reads a manifest from an
# empty directory. This script closes that gap.
#
#   TarkovAddons.dll/.pdb/.map   always produced (Link block: /DEBUG /MAP)
#   TarkovLauncherBypass.dll     produced, no pdb/map (its vcxproj has neither)
#   vk_swiftshader.dll           produced, no pdb/map
# ---------------------------------------------------------------------------
$files = @(
    "TarkovAddons.dll",         "TarkovAddons.pdb",         "TarkovAddons.map",
    "TarkovLauncherBypass.dll", "TarkovLauncherBypass.pdb", "TarkovLauncherBypass.map",
    "vk_swiftshader.dll",       "vk_swiftshader.pdb",       "vk_swiftshader.map"
)

New-Item -ItemType Directory -Force $dst > $null
New-Item -ItemType Directory -Force "$dst\ta" > $null

$copied = 0
foreach ($f in $files) {
    $s = "$src\$f"
    if (Test-Path $s) {
        Copy-Item $s "$dst\$f" -Force
        $copied++
    }
}

# ---------------------------------------------------------------------------
# Compatibility profiles. The CMakeLists file(GLOB) writes them into every
# target's ta/ tree; they are identical, so copy from TarkovAddons' copy.
# ---------------------------------------------------------------------------
$profilesSrc = "$build\TarkovAddons\ta\compatibility\profiles"
if (Test-Path $profilesSrc) {
    $profilesDst = "$dst\ta\compatibility\profiles"
    New-Item -ItemType Directory -Force $profilesDst > $null
    Get-ChildItem $profilesSrc -Directory | ForEach-Object {
        $d = "$profilesDst\$($_.Name)"
        New-Item -ItemType Directory -Force $d > $null
        Copy-Item "$($_.FullName)\manifest.json" "$d\manifest.json" -Force
    }
}

# ---------------------------------------------------------------------------
# Menu background image.
#
# The vcxproj's PostBuildEvent copied this into $(OutDir)ta\. Nothing in the
# CMake build touches it -- it is not a source of any target -- so without
# this line it simply stops being refreshed, and the copy already sitting in
# the deploy folder is a leftover from the last MSBuild build.
# ---------------------------------------------------------------------------
$pngSrc = "$root\TarkovAddons\assets\TarkovAddons Reloaded Background.png"
if (Test-Path $pngSrc) {
    Copy-Item $pngSrc "$dst\ta\TarkovAddons Reloaded Background.png" -Force
}

# ---------------------------------------------------------------------------
# Config files. The vcxproj copied these with `if exist`, so skip when absent
# rather than failing the build.
# ---------------------------------------------------------------------------
foreach ($cfg in "launcher", "offsets", "patterns") {
    $s = "$root\TarkovAddons\$cfg.cfg"
    if (Test-Path $s) {
        Copy-Item $s "$dst\ta\$cfg.cfg" -Force
    }
}

Write-Host "copied $copied artefact(s) to $dst" -ForegroundColor Green