#!/usr/bin/env python3
"""
quest_condition_fields.py -- does the Quest ESP read field names that exist?

Cross-references the condition-field names `TarkovAddons/module/quest_esp.h` reads
against a real Il2CppDumper `dump.cs`, and reports every condition class each POI
gate can reach whose field does not resolve.

    python tools/quest_condition_fields.py TarkovAddons/GameDump/<build>/dump.cs
    [--list-uncovered]

WHY THIS EXISTS. On 2026-10-13 the Quest ESP was found to emit
`poi_type::place` markers for nothing at all, on any quest, in any raid.
`get_zone_id()` looked for a field named `zoneId`/`zoneID`/`ZoneId`, and the
class that carries the objective has a field named `zoneIds` -- plural, and a
`string[]`. `il2cpp_class_get_field_from_name` is an exact `strcmp`, and
`il2utils::resolve_field` walks the inheritance chain upward only, so the
lookup returned null for all three classes that route to that gate. The visit,
inzone, find and transit gates read names that do exist, which is exactly why it
looked like "quest areas work but place objectives do not".

FIXED 2026-10-13, in the same session, once the freeze on `quest_esp.h` was
lifted: `process_place_condition` now reads the array with
`read_string_array_field(condition, "zoneIds")` and emits one POI per id, the
way `process_inzone_conditions` already did, and `get_zone_id` was deleted.
This tool is what proved the field defect against both real dumps (3
unresolvable reads, exit 1) and what proved the fix (0, exit 0); the GATES
table below carries the fixed read. Its job now is the regression: if a future
edit renames any gate's field, drops a gate, or adds one without updating this
table, the tool says so instead of reporting a clean tree.

The bug was invisible because every test that names `ConditionPlaceBeacon` or
`ConditionLeaveItemAtLocation` tests `plan_for()` in
`quest_objective_text.h` -- the checklist's fallback LABEL. `quest_esp.h` opens
with the game's object model and cannot be compiled standalone, so the field
reads have had no coverage at all until now. This tool is that coverage, and it
needs no compiler, no game and no PDB.

EXIT CODES -- deliberate, and not normalisable into each other:
    0  every gate's field resolved
    1  at least one gate read a field that does not exist on any class it matched
    2  read nothing: dump.cs missing, unreadable, or no EFT.Quests Condition
       subclass parsed out of it

2 is distinct from 0 on purpose. A checker that exits 0 when it checked nothing
is the failure mode this repo has shipped from three separate tools; see
AGENTS.md. Treat 2 as a stop.
"""

import argparse
import re
import sys

# dump.cs class declaration. The parent is the single base after ':'; interfaces
# in the base list are not tracked, which is fine because the ancestor walk only
# ever needs to answer "does this chain reach Condition".
#
# The name charset covers '.' and '`' on purpose. dump.cs writes nested types as
# `Outer.Inner` and generic instantiations as `List`1`; excluding them makes
# re.match() stop at the '.', which is NOT an error -- re.match only needs a
# prefix -- so those classes enter the table under a truncated name with no
# parent recorded, and two generic instantiations then collide on one key.
DECL = re.compile(
    r'^public (?:sealed |abstract |static |readonly |unsafe )*class '
    r'([A-Za-z0-9_.`]+)(?:<[^>]*>)?(?:\s*:\s*([A-Za-z0-9_.`]+))?'
)

# dump.cs field declaration. The trailing "// 0xNN" is the field OFFSET, and
# requiring it is what keeps method signatures and local declarations out.
FIELD = re.compile(
    r'^\t(?:public|private|protected|internal)'
    r'(?:\s+(?:readonly|static|volatile|const|new))*'
    r'\s+(.+?)\s+([A-Za-z0-9_<>`\[\]]+)\s*;\s*//\s*(0x[0-9A-Fa-f]+)'
)


def load(path):
    """Return (parent_of, fields_of) parsed from a dump.cs.

    Fields are keyed by their OWNING class name. dump.cs nests generic and
    closure types (`Outer.Inner`), and those names are not unique across the file;
    first declaration wins, which is the same choice il2cpp's own type table
    effectively makes for the classes this tool looks at.
    """
    parent, fields = {}, {}
    cur, cur_fields = None, {}
    with open(path, encoding='utf-8', errors='replace') as handle:
        for line in handle:
            if line.startswith('public ') and ' class ' in line:
                if cur:
                    fields[cur] = cur_fields
                m = DECL.match(line)
                if m:
                    cur = m.group(1)
                    cur_fields = {}
                    if m.group(2):
                        parent.setdefault(cur, m.group(2))
                else:
                    cur, cur_fields = None, {}
                continue
            if cur:
                m = FIELD.match(line)
                if m:
                    cur_fields[m.group(2)] = (m.group(3), m.group(1).strip())
    if cur:
        fields[cur] = cur_fields
    return parent, fields


def ancestors(parent, cls):
    """Base chain, leaf first. Guarded: dump.cs has nested types whose declared
    base loops back on itself, and an unguarded walk never terminates."""
    out, seen, cur = [], {cls}, parent.get(cls)
    while cur and cur not in seen:
        seen.add(cur)
        out.append(cur)
        cur = parent.get(cur)
    return out


def resolve(parent, fields, cls, name):
    """What il2utils::resolve_field does: walk the chain, exact name, return the
    owning class and the field's (offset, type). None when it would return null."""
    cur, seen = cls, set()
    while cur and cur not in seen:
        seen.add(cur)
        if name in fields.get(cur, {}):
            return cur, fields[cur][name]
        cur = parent.get(cur)
    return None, None


# The five gates process_condition_for_cycle installs, and the field each one then
# reads off the matched condition.
#
# THE MATCH PREDICATES AND THE FIELD NAMES ARE HAND-TRANSCRIBED from
# TarkovAddons/module/quest_esp.h. They are the one thing this tool does not
# derive, so re-read them against the header when it changes -- if the header
# gains a gate, this table gains a row, and the tool should fail loudly (exit 2)
# rather than report a clean tree over a stale table.
#
# Each predicate mirrors the code: three are substrings of the LEAF class name
# (class_name_contains), one is a parent-chain test (is_place_condition_type's
# class_inherits_from tail), and the find gate is a substring too.
GATES = [
    ("visit",
     lambda p, c: 'ConditionVisitPlace' in c or 'ConditionLocationTrigger' in c,
     ["target"],
     "get_condition_target_string, read as one Il2CppString*"),
    ("inzone",
     lambda p, c: 'ConditionInZone' in c,
     ["zoneIds"],
     "read_string_array_field, read as string[]"),
    ("place",
     lambda p, c: ('ConditionZone' in c or 'ConditionLeaveItemAtLocation' in c
                   or 'ConditionPlaceBeacon' in c
                   or 'ConditionZone' in ancestors(p, c)),
     ["zoneIds"],
     "process_place_condition, read_string_array_field, read as string[]"),
    ("find",
     lambda p, c: 'ConditionFindItem' in c,
     ["target"],
     "target_array_contains_template, read as string[]"),
    # A COMPILER-GENERATED backing field, not a JsonProperty. Named separately
    # because it is fragile for a different reason: a C++/CLI or language-version
    # change renames backing fields without renaming the property.
    ("transit",
     lambda p, c: 'ConditionTransitionLocation' in c,
     ["<MapNames>k__BackingField"],
     "read_string_array_field, read as string[]"),
]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("dump_cs")
    ap.add_argument("--list-uncovered", action="store_true",
                    help="also print the condition classes no gate reaches")
    args = ap.parse_args(argv)

    try:
        parent, fields = load(args.dump_cs)
    except OSError as exc:
        print(f"ERROR: cannot read {args.dump_cs}: {exc}", file=sys.stderr)
        return 2

    conds = sorted(c for c in parent
                   if c.startswith('Condition') and 'Condition' in ancestors(parent, c))
    if not conds:
        print(f"ERROR: parsed 0 EFT.Quests Condition subclasses out of {args.dump_cs}.\n"
              f"       That is a parse failure, not a clean result.", file=sys.stderr)
        return 2

    print(f"dump: {args.dump_cs}")
    print(f"EFT.Quests Condition subclasses: {len(conds)}\n")

    total_bad = 0
    reached = set()
    for gate, match, names, reads in GATES:
        hit = [c for c in conds if match(parent, c)]
        reached.update(hit)
        bad = 0
        print(f"=== {gate} ({len(hit)} classes matched) ===")
        print(f"    reads: {' | '.join(names)}   [{reads}]")
        if not hit:
            print("    !! the hand-transcribed predicate matched NOTHING. Either the"
                  " gate was renamed in quest_esp.h or this table is stale.\n")
            return 2
        for cls in hit:
            found = [(n, resolve(parent, fields, cls, n)[1])
                     for n in names]
            found = [(n, m) for n, m in found if m]
            if found:
                print(f"    OK   {cls:36s} "
                      + ", ".join(f"{n} {m[0]} {m[1]}" for n, m in found))
            else:
                bad += 1
                zoneish = sorted(
                    f for k in [cls] + ancestors(parent, cls)
                    for f in fields.get(k, {})
                    if 'zone' in f.lower())
                chain = "/".join([cls] + ancestors(parent, cls)[:3])
                print(f"    MISS {cls:36s} none of {names} on {chain}")
                if zoneish:
                    print(f"         zone-ish fields that DO exist: {zoneish}")
        total_bad += bad
        print(f"    -> {bad} of {len(hit)} matched classes resolve no field\n")

    if args.list_uncovered:
        print("=== classes no gate reaches ===")
        for cls in conds:
            if cls not in reached:
                own = ", ".join(fields.get(cls, {})) or "(no fields)"
                print(f"    --   {cls:36s} {own}")

    print(f"TOTAL unresolvable field reads: {total_bad}")
    if total_bad:
        print("A gate reading a field that exists on NO class it matched cannot emit "
              "a POI. See tools/handoff_quest_place_pois.md.")
    return 1 if total_bad else 0


if __name__ == "__main__":
    sys.exit(main())