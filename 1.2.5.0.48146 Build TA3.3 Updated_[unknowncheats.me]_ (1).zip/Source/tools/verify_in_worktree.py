#!/usr/bin/env python3
"""One-shot: verify the item-search change in a sibling worktree.

The main tree's build is blocked by another session's *uncommitted*
quest_esp.h edit (logger::debug called with 5 args where the project's logger
takes one std::string). Editing their file is not acceptable, so this mirrors
the five files this change touches into a worktree at the committed HEAD --
where the tree is green -- and builds there.

A per-TU compile cannot see LNK2005 and is not what ships; this runs the real
deploy.py build, with its own SLOT so it does not share a build tree.
"""
import os
import shutil
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
WT = Path("D:/ta-verify-itemsearch")

FILES = [
    "TarkovAddons/config/ItemSearchValue.cpp",
    "TarkovAddons/config/ItemSearchValue.h",
    "TarkovAddons/module/item_categories.h",
    "TarkovAddons/module/impl/EspModule.cpp",
    "TarkovAddons/module/impl/LootTeleportModule.cpp",
]

for rel in FILES:
    src, dst = REPO / rel, WT / rel
    assert src.exists() and dst.exists(), rel
    shutil.copy2(src, dst)
    print(f"  mirrored {rel}")

# The committed tree is green, so a green build here is about THIS change.
env = dict(os.environ, SLOT="verify-itemsearch")
proc = subprocess.run(
    ["python", "tools/deploy.py", "build"],
    cwd=WT, capture_output=True, text=True, env=env,
)
out = proc.stdout + proc.stderr
Path(REPO / "_wtverify.txt").write_text(out, encoding="utf-8", errors="replace")

succeeded = "Build succeeded" in out
warnings = [l for l in out.splitlines() if "warning" in l.lower()]
errors = [l for l in out.splitlines() if "error" in l.lower()]
print(f"\nexit={proc.returncode}  succeeded={succeeded}  "
      f"errors={len(errors)}  warnings={len(warnings)}")
for l in (errors + warnings)[:6]:
    print("  ", l.strip()[:170])
sys.exit(0 if succeeded and not errors and not warnings else 1)