"""Measure the mask fit's OUTPUT side from the existing log, and expose its sampling bias.

2026-10-06. tools/optics_status.md sec 7 claims the fitted mask "breathes between
17.4% and 33.1% of the lens radius, median frame-to-frame change 1.20 pp, worst
11.00 pp". The first optic-region line in the log says `cover=12.1%`, which is
outside that range. One of the two is wrong and it is cheaper to measure than to
argue.

The structural facts, from reading the code:
  - the subject polygon is a FIXED 48-gon (optics_lens_pipeline.h:3935)
  - clip_polygon is Sutherland-Hodgman, and each boundary edge adds AT MOST ONE
    vertex (util/linalg.h:151-169)
  - boundary is the image quad (4 edges) then the screen (4 edges)
  so mask.size() lies in [0, 48+4+4] = [0, 56], and 48 is inside that range, not
  a suspicious maximum.

So `fitted_pts` swinging is STRUCTURAL, and the quantity that would actually make
the aperture breathe is `cover`, the area. That is what this measures.

SAMPLING BIAS, and it matters: optic-maskgate: prints only when mode, pts or half
CHANGED (eft_api.h:2155, a `s_last_*` guard). So its lines are change-events, and
the distribution of values it reports is the distribution *at changes* -- not the
distribution over frames. optic-region: has no such guard and is a plain cadence
sample. Both are counted separately so the difference is not hidden.

Exit 0 = measured. Exit 2 = matched nothing.
"""
import re
import statistics
import sys

LOG = r"C:\Battlestate Games\BsgLauncher\tarkovaddons_log.txt"
if len(sys.argv) > 1:
    LOG = sys.argv[1]

REGION = re.compile(
    r"optic-region: inside=(\d+) outside=(\d+) no_mask=(\d+) "
    r"cover=([\d.]+)% max_outside=(\d+)px")
GATE = re.compile(r"optic-maskgate: mode=(\d+) half=(-?[\d.]+) fitted_pts=(\d+)")


def describe(label, vals):
    if not vals:
        print("  %-22s (no values)" % label)
        return
    s = sorted(vals)
    n = len(s)
    print("  %-22s n=%3d  min %8.2f  p25 %8.2f  p50 %8.2f  p75 %8.2f  "
          "p90 %8.2f  max %8.2f  mean %8.2f  distinct %d"
          % (label, n, s[0], s[n // 4], s[n // 2], s[3 * n // 4],
             s[min(n - 1, int(n * 0.90))], s[-1], statistics.mean(s),
             len(set(s))))


def main():
    with open(LOG, encoding="utf-8", errors="replace") as fh:
        raw = fh.read().splitlines()

    covers, insides, outsides, nomask, pts, modes, halves = [], [], [], [], [], [], []
    for line in raw:
        m = REGION.search(line)
        if m:
            covers.append(float(m.group(4)))
            insides.append(int(m.group(1)))
            outsides.append(int(m.group(2)))
            nomask.append(int(m.group(3)))
        g = GATE.search(line)
        if g:
            modes.append(int(g.group(1)))
            halves.append(float(g.group(2)))
            pts.append(int(g.group(3)))

    if not covers and not pts:
        print("\nFATAL: matched no optic-region: or optic-maskgate: lines in %s" % LOG)
        return 2

    print("=== optic-region: (plain cadence sample, NO change-guard) ===")
    print("  %d line(s)" % len(covers))
    describe("cover %", covers)
    describe("inside", insides)
    describe("outside", outsides)
    describe("no_mask", nomask)
    if nomask:
        print("  frames reporting no_mask>0 : %d of %d"
              % (sum(1 for v in nomask if v > 0), len(nomask)))
    if covers:
        print("  cover below 17.4%% (the doc's claimed minimum): %d of %d"
              % (sum(1 for v in covers if v < 17.4), len(covers)))
        print("  cover above 33.1%% (the doc's claimed maximum): %d of %d"
              % (sum(1 for v in covers if v > 33.1), len(covers)))
        # Consecutive-sample deltas. NOT frame-to-frame -- these lines are ~600 ms
        # apart (retraction 7), so this is a drift rate, and it is labelled as such.
        d = [abs(covers[i] - covers[i - 1]) for i in range(1, len(covers))]
        if d:
            describe("|delta cover| pp", d)
            print("  ^ NOT frame-to-frame. optic-region: is ~600 ms apart, so this is the")
            print("    drift over 600 ms and CANNOT answer whether the aperture flickers.")

    print("\n=== optic-maskgate: (prints ONLY on change -- biased sample) ===")
    print("  %d change-event(s)" % len(pts))
    describe("fitted_pts", pts)
    describe("half", halves)
    print("  distinct modes: %s" % sorted(set(modes)))
    if pts:
        print("  fitted_pts in [0, 56] as the geometry allows : %d of %d"
              % (sum(1 for v in pts if 0 <= v <= 56), len(pts)))
        print("  fitted_pts < 3 (would be an empty/degenerate mask): %d"
              % sum(1 for v in pts if v < 3))
        print("  fitted_pts == 0: %d" % sum(1 for v in pts if v == 0))
        print("  NOTE: this line fires only when fitted_pts CHANGED, so a count that is")
        print("    stable for a long stretch is invisible here. The absence of lines is")
        print("    not evidence of stability.")

    # The two series share a clock (both carry a timestamp), so they can be joined.
    # For each maskgate change-event, take the nearest optic-region sample in time
    # and report the pair. If cover tracks pts, the aperture breathes with the
    # vertex count; if not, they move independently and pts is not the signal.
    print("\n=== do cover and fitted_pts co-vary? (nearest-in-time join) ===")
    region_ts = []
    for line in raw:
        m = REGION.search(line)
        if m:
            region_ts.append((line[1:23], float(m.group(4))))
    gate_ts = []
    for line in raw:
        g = GATE.search(line)
        if g:
            gate_ts.append((line[1:23], int(g.group(3)), float(g.group(2))))

    def to_sec(ts):
        # "2026-10-05 23:40:48.699"
        return (int(ts[11:13]) * 3600 + int(ts[14:16]) * 60 + int(ts[17:19])
                + float(ts[20:23]) / 1000.0)

    if region_ts and gate_ts:
        rs = [(to_sec(t), c) for t, c in region_ts]
        joined = []
        for t, p, h in gate_ts:
            sec = to_sec(t)
            near = min(rs, key=lambda rc: abs(rc[0] - sec))
            if abs(near[0] - sec) <= 0.7:      # within one 600 ms sample interval
                joined.append((p, near[1]))
        if joined:
            describe("cover %% at pts", [c for _, c in joined])
            xs = [p for p, _ in joined]
            ys = [c for _, c in joined]
            if len(set(xs)) > 1 and len(set(ys)) > 1:
                mx, my = statistics.mean(xs), statistics.mean(ys)
                num = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
                dx = sum((a - mx) ** 2 for a in xs) ** 0.5
                dy = sum((b - my) ** 2 for b in ys) ** 0.5
                print("  Pearson r(fitted_pts, cover) = %.4f over %d joined pair(s)"
                      % (num / (dx * dy), len(joined)))
                print("  READ THIS WITH THE SAMPLE BIAS IN MIND: pts events are, by")
                print("  construction, the frames where pts CHANGED.")
            else:
                print("  only %d pair(s) within 0.7 s; no correlation attempted" % len(joined))
        else:
            print("  no maskgate event within 0.7 s of any optic-region sample")
    else:
        print("  one of the two series is empty; nothing to join")

    # ---- THE THING THE 600 ms CADENCE CANNOT SEE ----------------------------
    # 5 change-events reported fitted_pts == 0, i.e. no mask published at all. On
    # such a frame the section 7 clip has nothing to clip against and everything
    # draws (eft_api.h:2166 prints "ABSENT (draws unclipped)").
    #
    # 5 EVENTS IS A LOWER BOUND AND NOT A COUNT OF FRAMES. Both lines print on a
    # ~600 ms cadence and the maskgate one only fires on change, so a mask that is
    # absent for ONE frame and present again by the next sample produces no
    # observable trace at all. The real dropout rate is unknown and is exactly what
    # the per-frame instrumentation has to measure.
    print("\n=== mask DROP-OUTS (fitted_pts == 0) and their neighbourhood ===")
    zero_events = []
    for line in raw:
        g = GATE.search(line)
        if g and int(g.group(3)) == 0:
            zero_events.append(line[1:23])
    print("  fitted_pts==0 change-events: %d  at %s"
          % (len(zero_events), ", ".join(zero_events) if zero_events else "-"))
    if zero_events:
        # What does optic-packet: say around each one? The stage name is the reason
        # the packet was refused, which is what distinguishes a dropout cause.
        stages = []
        for zt in zero_events:
            sec = to_sec(zt)
            near = []
            for line in raw:
                if "optic-packet:" not in line:
                    continue
                d = abs(to_sec(line[1:23]) - sec)
                if d <= 1.0:
                    near.append((d, line.strip()[:150]))
            near.sort()
            for d, txt in near[:2]:
                stages.append(txt)
        print("  nearest optic-packet: lines within 1.0 s:")
        for s in dict.fromkeys(stages):
            print("    " + s)
        if not stages:
            print("    (none -- so the packet line was not being emitted at all)")

    print("\n=== cover == 0 samples in optic-region: ===")
    zeros = [t for t, c in region_ts if c == 0.0]
    print("  %d of %d sample(s)  at %s"
          % (len(zeros), len(region_ts), ", ".join(zeros) if zeros else "-"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
