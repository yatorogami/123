"""Disassemble one RVA out of a PE, and resolve what an indirect call targets.

Written 2026-10-04 while working a boot-time crash whose two reported frames both
symbolised to clean function names in `dxhook` and both turned out to be stale
stack words. The `.map` names the nearest preceding SYMBOL, which is a guess
about attribution; this asks the bytes instead.

The distinction that mattered, twice:

  * `lea r11,[rsp+0xc0]` in an epilogue is a RETURN ADDRESS. A stack word holding
    it is a call site that already ran -- it is residue, and reading it as
    "we were called from here" invents a frame.
  * an instruction immediately after `call rax` is a return address too, but the
    load above it says what was called. Chasing that load to a global, then
    reading the global's value out of a dump, is what turned a call through a
    cached pointer into `UnityEngine.Component.get_gameObject()`.

`call qword ptr [rip+X]` is resolved to its import and, if the IAT slot is zero,
flagged as a call through null -- which is worth checking first in any
"ACCESS_VIOLATION EXECUTE at 0x0" crash.

Usage:
  python tools/pe_disasm.py <pe> <rva> [back_bytes] [count_bytes]
  python tools/pe_disasm.py "C:\\...\\TarkovAddons.dll" 0x1A75EF 0x50 0x20
"""
import re
import struct
import sys

import capstone

IMAGE_DIRECTORY_ENTRY_IMPORT = 1
IMAGE_SCN_MEM_EXECUTE = 0x20000000


def sections(d):
    e = struct.unpack_from("<I", d, 0x3C)[0]
    coff = e + 4
    nsec = struct.unpack_from("<H", d, coff + 2)[0]
    optsz = struct.unpack_from("<H", d, coff + 16)[0]
    opt = coff + 20
    magic = struct.unpack_from("<H", d, opt)[0]
    dd = opt + (112 if magic == 0x20B else 96)
    imp_rva = struct.unpack_from("<I", d, dd + 8 * IMAGE_DIRECTORY_ENTRY_IMPORT)[0]
    image_base = struct.unpack_from("<Q", d, opt + 24)[0]
    out = []
    base = opt + optsz
    for i in range(nsec):
        b = base + 40 * i
        name = d[b:b + 8].rstrip(b"\0").decode("ascii", "replace")
        vsize, vaddr, rsize, raddr = struct.unpack_from("<IIII", d, b + 8)
        chars = struct.unpack_from("<I", d, b + 36)[0]
        out.append((name, vaddr, vsize, raddr, rsize, chars))
    return image_base, imp_rva, out


def rva_to_off(secs, rva):
    for name, vaddr, vsize, raddr, rsize, _ in secs:
        if vaddr <= rva < vaddr + max(vsize, rsize):
            return raddr + (rva - vaddr)
    return None


def import_name(d, secs, rva):
    off = rva_to_off(secs, rva)
    if off is None or off + 2 > len(d):
        return None
    end = d.find(b"\0", off + 2, off + 258)
    if end < 0:
        return None
    return d[off + 2:end].decode("ascii", "replace"), struct.unpack_from("<H", d, off)[0]


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    path = sys.argv[1]
    target = int(sys.argv[2], 16)
    back = int(sys.argv[3], 16) if len(sys.argv) > 3 else 0x40
    count = int(sys.argv[4], 16) if len(sys.argv) > 4 else 0x40

    d = open(path, "rb").read()
    image_base, imp_rva, secs = sections(d)
    execs = [s for s in secs if s[5] & IMAGE_SCN_MEM_EXECUTE]
    if not any(v <= target < v + max(vs, rs) for _, v, vs, _, rs, _ in execs):
        print("rva 0x%X is not inside an executable section" % target)
        return 1

    cs = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
    start = max(0, target - back)
    off = rva_to_off(secs, start)
    print("image base 0x%X   import dir rva 0x%X   showing rva 0x%X..0x%X\n"
          % (image_base, imp_rva, start, start + back + count))
    for ins in cs.disasm(d[off:off + back + count], image_base + start):
        mark = "  <== " if ins.address == image_base + target else "      "
        extra = ""
        op = ins.op_str
        if ins.mnemonic in ("call", "jmp") and op.startswith("qword ptr [rip"):
            m = re.search(r"\[rip\s*([+-])\s*(0x[0-9A-Fa-f]+)\]", op)
            if m:
                disp = int(m.group(2), 16) * (1 if m.group(1) == "+" else -1)
                slot = ins.address + ins.size + disp
                soff = rva_to_off(secs, slot - image_base)
                raw = struct.unpack_from("<Q", d, soff)[0] if soff is not None else 0
                if raw == 0:
                    extra = "   <== IAT SLOT IS ZERO: call through null"
                elif raw & 0x8000000000000000:
                    extra = "   <== ORDINAL %d" % (raw & 0xFFFF)
                else:
                    nm = import_name(d, secs, raw)
                    extra = "   -> %s" % (("%s!%s (hint %d)" % (nm[0], nm[0], nm[1]))
                                          if nm else "IAT holds 0x%X" % raw)
        elif ins.mnemonic == "call" and re.match(r"^(r|e)?[a-z0-9]+$", op.strip()):
            extra = "   (call through a REGISTER -- the target is a runtime value;"
            extra += " tools/xref_global.py finds what fills it)"
        print("%s0x%012X  %-8s %s%s" % (mark, ins.address, ins.mnemonic, op, extra))
    return 0


if __name__ == "__main__":
    sys.exit(main())