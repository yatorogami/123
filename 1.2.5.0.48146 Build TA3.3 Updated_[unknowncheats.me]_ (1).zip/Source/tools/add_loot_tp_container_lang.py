"""Insert the two loot-teleport container i18n keys into every lang/*.json.

Same contract as tools/add_double_search_lang.py, which is the precedent for this
kind of edit, but with one correction to that script's assumption. It documents
"every language file carries every key in ASCII alphabetical order at 2-space
indent". The indent half is right and KEY_LINE depends on it; the order half is
false, and it is false in a way that matters here: en.json has an appended block, so
`map_static_markers_cb` is followed by `bot_names_cb`. Running the inherited
sorted-insertion put both keys beside `hk_double_search_act` at line 70, 330 lines
away from the five other `ltp_*` keys. Functionally harmless -- `i18n::tr()` is a
JSON lookup, not a positional one -- but it splits a key family across the file and
makes the next diff to that family harder to read.

So these keys are anchored beside their siblings instead: both go immediately before
`ltp_item_search_txt`, which lands them between `ltp_category_sel` and
`ltp_item_search_txt` -- exactly where a globally-sorted file would put them, and
inside the `ltp_*` block in a file that is not. `lang_fixes/hu.json` has no
`ltp_item_search_txt` (it is a partial override), and falls back to sorted insertion.
Measured: 19 of 19 `TarkovAddons/lang/*.json` carry the anchor, 0 of 1 `lang_fixes`
file does.

A `git diff` should still show two added lines per file and nothing else. Returns 1
and writes nothing for a language it has no translation for, rather than inserting
an English string into a locale.

Run from the repository root:  python tools/add_loot_tp_container_lang.py

Written 2026-10-15 for the loot teleporter's container support:
`ltp_from_containers_cb` is the "also pull items out of placed LootableContainers"
toggle (default off) and `ltp_container_cap_itm` is the per-press item limit that
bounds how much one click may move. These are translations of the addon's own
labels, NOT taken from the client's locale strings.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
LANG_DIR = REPO / "TarkovAddons" / "lang"
# The Hungarian override at the repo root carries the same key set.
EXTRA = [REPO / "lang_fixes" / "hu.json"]

KEY_LINE = re.compile(r'^  "([A-Za-z0-9_.]+)":')

NEW_KEYS = ("ltp_container_cap_itm", "ltp_from_containers_cb")

# The sibling both new keys sort immediately before. Present in every full language
# file; absent from lang_fixes/hu.json, which is a partial override.
ANCHOR_KEY = "ltp_item_search_txt"

TRANSLATIONS: dict[str, dict[str, str]] = {
    "br": {
        "ltp_container_cap_itm": "Limite de itens de contêineres",
        "ltp_from_containers_cb": "Também puxar espólio dos contêineres",
    },
    "ch": {
        "ltp_container_cap_itm": "容器物品上限",
        "ltp_from_containers_cb": "同时从容器中拉取战利品",
    },
    "cs": {
        "ltp_container_cap_itm": "Limit předmětů z kontejnerů",
        "ltp_from_containers_cb": "Táhnout kořist také z kontejnerů",
    },
    "en": {
        "ltp_container_cap_itm": "Container Item Limit",
        "ltp_from_containers_cb": "Also Pull Loot From Containers",
    },
    "es": {
        "ltp_container_cap_itm": "Límite de objetos de contenedores",
        "ltp_from_containers_cb": "Traer también el botín de los contenedores",
    },
    "fr": {
        "ltp_container_cap_itm": "Limite d'objets des conteneurs",
        "ltp_from_containers_cb": "Tirer aussi le butin des conteneurs",
    },
    "ge": {
        "ltp_container_cap_itm": "Behälter-Gegenstandslimit",
        "ltp_from_containers_cb": "Beute auch aus Behältern ziehen",
    },
    "hu": {
        "ltp_container_cap_itm": "Tárolótárgyak korlátja",
        "ltp_from_containers_cb": "Zsákmány kihúzása a tárolókból is",
    },
    "it": {
        "ltp_container_cap_itm": "Limite oggetti dai contenitori",
        "ltp_from_containers_cb": "Prendi il bottino anche dai contenitori",
    },
    "jp": {
        "ltp_container_cap_itm": "コンテナ内アイテムの上限",
        "ltp_from_containers_cb": "コンテナからもルートを引き寄せる",
    },
    "kr": {
        "ltp_container_cap_itm": "컨테이너 아이템 제한",
        "ltp_from_containers_cb": "컨테이너에서도 전리품 끌어오기",
    },
    "pl": {
        "ltp_container_cap_itm": "Limit przedmiotów z kontenerów",
        "ltp_from_containers_cb": "Przyciągaj też łupy z kontenerów",
    },
    "po": {
        "ltp_container_cap_itm": "Limite de itens de contêineres",
        "ltp_from_containers_cb": "Também puxar espólio dos contêineres",
    },
    "ro": {
        "ltp_container_cap_itm": "Limită obiecte din containere",
        "ltp_from_containers_cb": "Extrage pradă și din containere",
    },
    "ru": {
        "ltp_container_cap_itm": "Лимит предметов из контейнеров",
        "ltp_from_containers_cb": "Также тянуть лут из контейнеров",
    },
    "sk": {
        "ltp_container_cap_itm": "Limit predmetov z kontajnerov",
        "ltp_from_containers_cb": "Ťahať korisť aj z kontajnerov",
    },
    "sr": {
        "ltp_container_cap_itm": "Лимит предмета из контејнера",
        "ltp_from_containers_cb": "Извлачи плен и из контејнера",
    },
    "tu": {
        "ltp_container_cap_itm": "Konteyner eşya sınırı",
        "ltp_from_containers_cb": "Ganimeti konteynerlerden de çek",
    },
    "tw": {
        "ltp_container_cap_itm": "容器物品上限",
        "ltp_from_containers_cb": "同時從容器中拉取戰利品",
    },
}


def insert_before_anchor(lines: list[str], key: str, value: str) -> list[str]:
    """Insert `key` immediately before ANCHOR_KEY, keeping NEW_KEYS' own order.

    Raises if the anchor is absent, so the caller can decide whether the fallback is
    appropriate for this file rather than silently misplacing the key.
    """
    for i, line in enumerate(lines):
        m = KEY_LINE.match(line)
        if m and m.group(1) == ANCHOR_KEY:
            lines.insert(i, f'  "{key}": {json.dumps(value, ensure_ascii=False)},')
            return lines
    raise RuntimeError(f"anchor {ANCHOR_KEY!r} not found")


def insert_sorted(lines: list[str], key: str, value: str) -> list[str]:
    """Insert `key` in front of the first existing key that sorts after it."""
    for i, line in enumerate(lines):
        m = KEY_LINE.match(line)
        if m and m.group(1) > key:
            break
    else:
        raise RuntimeError(f"no insertion point found for {key}")
    lines.insert(i, f'  "{key}": {json.dumps(value, ensure_ascii=False)},')
    return lines


def add_to(path: Path, failures: list[str]) -> None:
    code = path.stem
    if code not in TRANSLATIONS:
        failures.append(f"{path.name}: no translation for language {code!r}")
        return
    table = TRANSLATIONS[code]

    raw = path.read_bytes()
    # Keep whatever line ending and encoding the file already uses.
    newline = "\r\n" if b"\r\n" in raw else "\n"
    lines = raw.decode("utf-8-sig").split(newline)

    present = {m.group(1) for line in lines if (m := KEY_LINE.match(line))}
    if present.intersection(NEW_KEYS):
        failures.append(f"{path.name}: a loot-teleport container key is already present")
        return

    # Anchor beside the sibling when the file has one; the two fallbacks differ, so
    # say which was used -- the whole point of anchoring is that sorted insertion is
    # wrong in a file with an appended block, and a silent fallback would hide that.
    if ANCHOR_KEY in present:
        insert = insert_before_anchor
    else:
        insert = insert_sorted
        print(f"{path.name}: no {ANCHOR_KEY!r}, falling back to sorted insertion")

    try:
        for key in NEW_KEYS:
            lines = insert(lines, key, table[key])
    except (RuntimeError, KeyError) as exc:
        failures.append(f"{path.name}: {exc}")
        return

    out = newline.join(lines)
    try:
        data = json.loads(out)
    except json.JSONDecodeError as exc:
        failures.append(f"{path.name}: result does not parse as JSON: {exc}")
        return

    missing = [k for k in NEW_KEYS if k not in data]
    if missing:
        failures.append(f"{path.name}: keys missing after write: {missing}")
        return

    path.write_bytes(out.encode("utf-8"))
    print(f"{path.name}: added {NEW_KEYS[0]} and {NEW_KEYS[1]}")


def main() -> int:
    failures: list[str] = []
    targets = sorted(LANG_DIR.glob("*.json")) + [p for p in EXTRA if p.is_file()]
    for path in targets:
        add_to(path, failures)

    if failures:
        print("\nFAILED:\n" + "\n".join(failures), file=sys.stderr)
        return 1
    print(f"\n{len(targets)} files, {len(targets) * len(NEW_KEYS)} keys added")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
