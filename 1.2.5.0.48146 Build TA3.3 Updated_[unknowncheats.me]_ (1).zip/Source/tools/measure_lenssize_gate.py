"""The lens-size gate's reject pattern: bursts, and why it never re-baselines.

2026-10-06. `tools/measure_mask_fit.py` found 4 mask drop-outs in the ~2 minute
capture, and the nearest `optic-packet:` line named the cause for three of them:
"lens image size out of family with baseline". The gate is
optics_lens_pipeline.h:4099-4171 and `optic-lenssize:` already reports it.

The eight `optic-lenssize:` lines from the capture (baseline=ref_w x ref_h,
last_bad=seen_w x seen_h, confirmed from the format string at eft_api.h:2339):

    23:40:48.699  baseline=0.5908x1.0513  rej=0
    23:40:58.286  baseline=0.8464x1.5047  rej=1   last_bad=0.3850x0.6851
    23:40:58.889  baseline=0.8395x1.4925  rej=15  last_bad=0.5826x1.0358
    23:41:15.354  baseline=0.8441x1.5007  rej=16  last_bad=0.4246x0.7525
    23:41:15.958  baseline=0.8361x1.4863  rej=30  last_bad=0.5824x1.0357
    23:41:44.428  baseline=0.8493x1.5099  rej=31  last_bad=0.4479x0.7963
    23:41:45.031  baseline=0.8421x1.4971  rej=40  last_bad=0.5933x1.0547
    23:42:54.627  baseline=0.8385x1.4907  rej=56  last_bad=0.5845x1.0392

Two things fall out, and the second is the interesting one:

  1. `rebase=0` throughout, after 56 rejections. The escape hatch never fired.

  2. Rejections arrive in BURSTS: +1, then +14 within 603 ms, then quiet for
     16 s, then +14 within 604 ms, then 28 s quiet, +9 within 603 ms, ...

WHY IT NEVER RE-BASELINES. Line 4146 re-baselines only when
`now - reject_since >= kRebaselineMs` (500 ms), and line 4170 sets
`reject_since = 0` on every ACCEPT. So the timer measures CONTINUOUS rejection.
A size oscillating across the band edge produces accepts inside every burst,
each accept resets the timer, and 500 ms of unbroken rejection never accumulates.
The gate can therefore reject indefinitely and still never re-baseline. `rebase=0`
after 56 rejects is the proof, not an absence of evidence.

WHY THAT IS VISIBLE. A rejected packet publishes no polygon, so
`game_state::esp_lens_mask_count` goes to 0 (eft_api.h:2629) and the section 7
clip has nothing to clip against -- every draw goes unclipped for that frame,
and the ESP switches to the radial fallback. A frame that alternates between
"clipped by the fitted polygon" and "no clip at all" is a pop, and the burst
duty cycle says these are ~14 rejects inside ~36 frames at 60 fps, so they
alternate rather than drop out wholesale.

WHAT THIS CANNOT SAY. The 603 ms is the gap between two printed lines, so the 14
rejects happened somewhere inside that window -- this establishes the BURST
STRUCTURE, not the per-frame period. Whether the oscillation is 2 Hz or 60 Hz
needs per-frame instrumentation. That is the measurement this points at.

Exit 0 = measured, 2 = matched nothing.
"""
import re
import sys

LOG = r"C:\Battlestate Games\BsgLauncher\tarkovaddons_log.txt"
if len(sys.argv) > 1:
    LOG = sys.argv[1]

K_MIN, K_MAX, K_REBASE = 0.70, 1.45, 500.0

GATE = re.compile(
    r"optic-lenssize: baseline=([\d.]+)x([\d.]+) ndc rej=(\d+) degen=(\d+) "
    r"rebase=(\d+) last_bad=([\d.]+)x([\d.]+)")

# TIMESTAMP BUG, and it invalidated every rate in the first run of this script.
# The timestamp was taken as line[1:23], which is 22 characters and cuts the
# millisecond field from three digits to two: 23:40:48.699 became 23:40:48.69.
# Every dt came out ~10x wrong and the reject rates with it (it printed 233 rej/s
# for a burst that spans 603 ms). The timestamp is now CAPTURED BY THE REGEX, so
# it cannot drift from the text it came from again.
TS = re.compile(r"\[(\d{4}-\d\d-\d\d) (\d\d):(\d\d):(\d\d)\.(\d{3})")


def to_sec(line):
    m = TS.search(line)
    if not m:
        return None
    return (int(m.group(2)) * 3600 + int(m.group(3)) * 60 + int(m.group(4))
            + int(m.group(5)) / 1000.0)


def stamp(line):
    m = TS.search(line)
    return m.group(2) + ":" + m.group(3) + ":" + m.group(4) + "." + m.group(5)


def main():
    with open(LOG, encoding="utf-8", errors="replace") as fh:
        raw = fh.read().splitlines()

    rows = []
    for line in raw:
        m = GATE.search(line)
        if not m:
            continue
        rw, rh = float(m.group(1)), float(m.group(2))
        sw, sh = float(m.group(6)), float(m.group(7))
        rows.append({
            "ts": stamp(line), "sec": to_sec(line),
            "B": max(rw, rh), "rw": rw, "rh": rh,
            "S": max(sw, sh), "sw": sw, "sh": sh,
            "rej": int(m.group(3)), "deg": int(m.group(4)),
            "rebase": int(m.group(5))})

    if not rows:
        print("\nFATAL: no optic-lenssize: lines in %s" % LOG)
        return 2
    if any(r["sec"] is None for r in rows):
        print("\nFATAL: a timestamp failed to parse -- refusing to report rates.")
        return 2

    print("=== band arithmetic, per line (size=max(w,h), B=max(ref_w,ref_h)) ===")
    print("  %-14s %8s %8s %8s %9s %9s  %s"
          % ("time", "B", "lo_edge", "hi_edge", "last_bad", "S/B", "verdict"))
    for r in rows:
        lo, hi = K_MIN * r["B"], K_MAX * r["B"]
        if r["S"] == 0.0:
            verdict = "no reject recorded yet"
        elif r["S"] < lo:
            verdict = "LO (%.2f%% under edge)" % (100.0 * (lo - r["S"]) / lo)
        elif r["S"] > hi:
            verdict = "HI (%.2f%% over edge)" % (100.0 * (r["S"] - hi) / hi)
        else:
            verdict = "INSIDE the band -- should NOT have rejected"
        print("  %-14s %8.4f %8.4f %8.4f %9.4f %9.4f  %s"
              % (r["ts"], r["B"], lo, hi, r["S"],
                 r["S"] / r["B"] if r["B"] else 0.0, verdict))

    print("\n=== reject increments between consecutive printed lines ===")
    print("  %-14s %8s %8s %10s %12s"
          % ("from", "d_rej", "dt_s", "rej/s", "vs kRebaseline"))
    prev = None
    bursts = 0
    for r in rows:
        if prev is None:
            print("  %-14s %8d %8s %10s" % (r["ts"], r["rej"], "-", "-"))
            prev = r
            continue
        d = r["rej"] - prev["rej"]
        dt = r["sec"] - prev["sec"]
        rate = d / dt if dt > 0 else 0.0
        tag = ""
        if d >= 5:
            bursts += 1
            if dt * 1000.0 >= K_REBASE:
                tag = "dt >= 500 ms, yet still no rebase"
        print("  %-14s %8d %8.3f %10.2f  %s"
              % (r["ts"], d, dt, rate, tag))
        prev = r

    print("\n=== the re-baseline timer, reconstructed ===")
    print("  kRebaselineMs            = %d ms" % K_REBASE)
    print("  condition (line 4146)    : now - reject_since >= kRebaselineMs")
    print("  reset on accept (4170)   : reject_since = 0")
    print("  => the timer measures CONTINUOUS rejection, not cumulative.")
    print("  rebase count at end      : %d  (total rejects: %d)"
          % (rows[-1]["rebase"], rows[-1]["rej"]))
    if rows[-1]["rebase"] == 0 and rows[-1]["rej"] > 0:
        print("  => %d rejections and ZERO re-baselines: the escape hatch never fired."
              % rows[-1]["rej"])
        print("     Consistent with accepts interleaved inside every burst, each one")
        print("     resetting reject_since before it can reach 500 ms.")
    print("  bursts with d_rej>=5     : %d" % bursts)
    print("\n  NOT established here: the per-frame period of the oscillation. The 603 ms")
    print("  figures are gaps between printed lines, so they bound where the rejects")
    print("  happened, not how they were spaced within that window.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
