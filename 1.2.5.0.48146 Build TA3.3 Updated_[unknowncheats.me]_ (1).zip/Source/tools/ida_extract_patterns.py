"""
IDA pattern scanner — tries all known patterns for launcher-target symbols
against a GameAssembly.dll or UnityPlayer.dll .i64 database.

Usage (IDA batch mode):
    idat.exe -A -Sida_extract_patterns.py <database.i64> --patterns patterns.json

Output: rvas.json mapping symbol names to confirmed RVAs.
"""

import ida_auto
import ida_nalt
import ida_bytes
import ida_segment
import idautils
import ida_name
import idaapi
import idc
import json
import sys
import os

ida_auto.auto_wait()

input_file = ida_nalt.get_input_file_path()
print(f"Loaded: {input_file}")

image_base = ida_nalt.get_imagebase()
print(f"Image base: 0x{image_base:X}")

# Load patterns database
patterns_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "patterns.json")
if "--patterns" in sys.argv:
    idx = sys.argv.index("--patterns")
    if idx + 1 < len(sys.argv):
        patterns_path = sys.argv[idx + 1]

if not os.path.exists(patterns_path):
    print(f"ERROR: patterns file not found: {patterns_path}")
    idc.qexit(2)

with open(patterns_path, "r") as f:
    patterns_db = json.load(f)

print(f"Loaded patterns from: {patterns_path}")


def parse_pattern(pattern_str):
    parts = pattern_str.split()
    result = []
    for p in parts:
        if p == "?":
            result.append(None)
        else:
            result.append(int(p, 16))
    return result


def search_pattern(data, pattern):
    matches = []
    pat_len = len(pattern)
    for i in range(len(data) - pat_len + 1):
        match = True
        for j, pb in enumerate(pattern):
            if pb is not None and data[i + j] != pb:
                match = False
                break
        if match:
            matches.append(i)
    return matches


results = {}

for symbol, entries in patterns_db.get("symbols", {}).items():
    print(f"\nSearching for {symbol} ({len(entries)} pattern(s))...")
    symbol_matches = []

    for entry in entries:
        pattern_str = entry["pattern"]
        pattern_build = entry.get("build", "unknown")
        pattern = parse_pattern(pattern_str)

        # Search in all segments
        for seg_ea in idautils.Segments():
            seg = ida_segment.getseg(seg_ea)
            seg_name = ida_segment.get_segm_name(seg)
            seg_start = seg.start_ea
            seg_end = seg.end_ea
            seg_size = seg_end - seg_start

            seg_bytes = ida_bytes.get_bytes(seg_start, seg_size)
            if not seg_bytes:
                continue

            found = search_pattern(seg_bytes, pattern)
            for offset in found:
                ea = seg_start + offset
                rva = ea - image_base
                func_name = ida_name.get_name(ea)
                symbol_matches.append({
                    "pattern_build": pattern_build,
                    "rva": f"0x{rva:X}",
                    "segment": seg_name,
                    "name": func_name if func_name else "unnamed"
                })
                print(f"  Matched pattern from build {pattern_build} at 0x{ea:X} (RVA: 0x{rva:X}) in {seg_name} [{func_name or 'unnamed'}]")

    if symbol_matches:
        # Prefer the pattern from the matching build, or use the first match
        results[symbol] = symbol_matches[0]["rva"]
        if len(symbol_matches) > 1:
            print(f"  WARNING: {len(symbol_matches)} matches for {symbol}, using first")
    else:
        print(f"  No matches found")

# Save results
output_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "rvas.json")
with open(output_file, "w") as f:
    json.dump(results, f, indent=2)

print(f"\nResults saved to: {output_file}")
print(f"Matched {len(results)}/{len(patterns_db.get('symbols', {}))} symbols")

idc.qexit(0)
