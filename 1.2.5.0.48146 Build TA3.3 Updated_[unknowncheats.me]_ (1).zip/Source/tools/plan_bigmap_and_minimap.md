# Plan: keybound full-screen map + minimap show/hide

Status: **steps 1–7 implemented.** What step 6/7 still do NOT do is listed under
"Known limits" below, and the biggest of them is structural, not a missing feature.
Submodule `dynamicmaps` at `4944764` (tag `1.2.1`), checked out and read.
Attribution resolved by the user: open-source, credit where due. Working tree clean.

Supersedes `tools/plan_bigmap_and_minimap.md` (which superseded `tools/plan_dynamicmaps_minimap.md`).

> **2026-10-15 — steps 6 and 7 landed, and one live bug went with them.**
>
> **The bug first, because it was there all along:** `MapModule::player_pos_` was
> declared, read in three places (floor pick, player dot, and the view centre) and
> **written nowhere**. `gameworld_update` took `main_player` as
> `[[maybe_unused]]`. So the dot rendered at world origin — and (0,0,0) is inside
> Customs' playable area, so it looked like a position rather than like no data.
> It is now read from the player's transform, and a bool `has_player_pos_` rides
> alongside so "at the origin" and "not known yet" are distinguishable.
> `tools/tests/test_bigmap_controls.py` pins the assignment, and its control
> (the `[[maybe_unused]]` restored) goes red.
>
> **4.3, all four items:** wheel zoom (multiplies the slider, so the slider stays
> the per-raid baseline), drag pan (left-drag over the map; the window is
> `NoMove` so a drag cannot be confused with moving the window), and **level
> switching** — `,`/`.` to cycle `active_overlay_index`, `\` to go back to
> "follow the player", plus three buttons. The override lives in `minimap.h`
> beside the state it overrides and is consumed by `update_active_layers`, so it
> survives the per-frame re-derivation that would otherwise undo it.
> `notify_location_changed` clears it: a stored index is into ONE map's
> `overlay_layers`.
>
> **The markers are EspModule's, not MapModule's.** `draw_big_map_markers` sits
> next to `draw_radar_overlay` and reuses the same snapshots, helpers, glyphs and
> fonts. A second renderer in `MapModule` would be a second set of colours, sizes
> and label anchors that could drift from the radar's with nothing noticing.
> `MapModule` holds an injected `EspModule*` for exactly that one call.
> Four layer checkboxes (`big_map_quest_cb` / `_exfils_cb` / `_players_cb` /
> `_static_cb`) gate the layers independently of the radar's.
> No distance cull on the big map: a whole-map view exists to show what the
> 75 m radar cannot.
>
> **Step 7's drop-down exists and is inert in a raid, on purpose.**
> `minimap::active_map()` is ONE global loaded map and
> `EspModule::draw_radar_overlay()` re-requests the player's own location every
> frame. A second map cannot be loaded alongside it, so honouring a mid-raid pick
> would draw Woods' terrain with Customs' extracts on it — confidently wrong.
> So the picker is **disabled** in a raid (with an info row saying why) and
> works out of raid, which is where "browse a map you are not in" is the whole
> point. Loading a second map means giving `active_map()` per-view state plus the
> SVG/tile caches and the reload handshake. That is its own piece of work and is
> listed as the first known limit.

### Known limits (not missing features — measured decisions)

1. **One loaded map at a time.** See above. Fixing it is the largest remaining
   item on this plan.
2. **Quest POIs only appear on the current location's map**, because
   `poi_entry.pos` is world-space. Out of raid the map is terrain, layers and
   static markers only.
3. **Wheel zoom is not a zoom *level*.** It is a continuous multiplier clamped to
   the slider's 1–8. There is no integer zoom step, so no tile-level LOD change
   beyond what `build_map_view` already does.
4. **`get_active_floor` re-derives from `player_pos_` every frame** even with a
   manual override set; the override wins inside `update_active_layers`, so the
   result is right, but the derivation still costs what it cost before.

> **2026-10-13 — step 5 landed.** `static_markers[]` and `labels[]` now parse in
> `minimap.h` and draw on the radar behind two MinimapModule checkboxes
> (`radar_minimap_static_markers`, `radar_minimap_labels`, both default off,
> i18n keys in all 19 locales). 242 markers + 270 labels across the eleven maps
> that have DynamicMaps data (terminal is the arena and carries none). Extract
> and Transit markers were deliberately **not** merged — this project reads
> those live. Provenance and the coordinate mapping are in
> `TarkovAddons/assets/maps/static-markers-LICENSE.md`, and
> `tools/tests/test_map_asset_integrity.py` gained five cases, one of which
> exists because the obvious bounds check could NOT catch the mapping error it
> was written for. Full record in `tools/handoff_bigmap_progress.md`.

## 0. The goal

1. **A keybind (M) that opens a full-screen, opaque map** with markers from the
   DynamicMaps project. Entirely internal to our process — **no hooking of or
   interaction with the game's own map screen.**
2. **The map shows current quest objectives**, following the existing quest/ESP
   behaviour. Map chosen from a drop-down list.
3. **The minimap hides when it should** — currently only out of raid; it stays
   visible over the player's own inventory.

Build order: **1 → 3 → 2** (minimap fix → asset harvest → big map), escalating
change surface.

## 1. Quest integration — the key dependency (investigated)

This was the unknown. It turns out to be a short path, because **the minimap
already does exactly this.**

`quest_esp::poi_entry` (`quest_esp.h:44-52`):

| field | type | render-thread safe? | use |
|---|---|---|---|
| `pos` | `unity::vector3` | yes | world metres — the projection input |
| `quest_name` | `std::string` | yes | marker label |
| `description` | `std::string` | yes | marker tooltip |
| `type` | `poi_type` (`visit`/`find`/`place`) | yes | colour via `quest_poi_color()` |
| `distance` | `float` | yes | label |
| `condition` | `Il2CppObject*` | **no** | not needed |

Cross-thread path (verified):
- `quest_poi_snapshot` = `std::shared_ptr<const std::vector<poi_entry>>`
  (`EspModule.h:1664`) — immutable snapshot, safe to read any frame.
- Published on the **game thread** in `gameworld_update` (`EspModule.cpp:7669`,
  under `data_mutex`).
- Copied to `local_quest_poi` on the **render thread** at the top of
  `draw_overlay` (`EspModule.cpp:4937`, same lock).
- The minimap already iterates it at `EspModule.cpp:2264` and projects each
  `poi.pos` through `minimap::world_to_uv`.

**So the big map does not need a new data source.** It reads the same
`quest_poi_store` snapshot, projects `poi.pos` the same way, and draws with
`quest_poi_color(poi.type)`. The only genuinely new work is the larger view,
the level switching, and the drop-down.

### 1.1 The two scopes the user offered

- **Minimum (in-raid point objectives):** read `quest_poi_store`, project
  `poi.pos`. This works today, in raid, with no new acquisition.
- **Ideal (drop-down map + quest objectives on any selected map):** the drop-down
  implies viewing a map you are not currently in. But `poi_entry.pos` is a
  *world* coordinate in the *current* location's space — it is meaningless on a
  different map. So quest objectives can only ever show on the **current**
  location's map. The drop-down is still useful (pick any known map to view), but
  quest markers will only appear on the map matching the current `LocationId`.

  **Recommendation:** build the minimum now; add the drop-down knowing that
  quest markers are current-location-only. This is an honest limitation to
  surface to the user, not a hidden one.

## 2. Part 1 — Minimap show/hide (build first)

### 2.1 The bug

`eft_api::query_external_loot_inventory_open()` (`eft_api.h:6427-6472`) returns
true only for `TransferItemsInRaid` (42), or `Inventory` (15) **with** `LootItem`
set / `ShowAsGridContent` true (looting a container). Opening your own backpack is
type 15 with no `LootItem` → **false** → the minimap stays full-size over the
inventory. It is only ever used to *shrink* to 120 px (`EspModule.cpp:1982`),
never to hide.

### 2.2 The fix

Add `eft_api::is_ui_blocking_screen_open_cached()` — same atomic-cache pattern,
wired into the existing per-frame update at `EspModule.cpp:5916`. Return true
for `Inventory` (15) and `TransferItemsInRaid` (42) regardless of `LootItem`/
grid. Then in `EspModule::draw_overlay`, after the existing `is_in_raid` gate
(`EspModule.cpp:4881`):

```
if (eft_api::is_ui_blocking_screen_open_cached()) return;
```

Keeps out-of-raid behaviour identical; adds the inventory case.

### 2.3 Unknown (hand-off)

We know only two `EEftScreenType` values (15, 42). We do not know the
"no screen / gameplay" value, so "any blocking screen" is not yet expressible.
See §6.1.

## 3. Part 3 — Asset harvest (build second)

With attribution resolved and order 1→3→2, the harvest lands before the big map
so the map has content to show.

1. **Labs + Labyrinth SVGs** — the only two maps with no abstract art today
   (`laboratory.json`/`labyrinth.json` have `svg: null`). Drop into
   `TarkovAddons/assets/maps/`, add RCDATA ids in `menu_background.rc`.
2. **Static markers (384) + labels (270)** — new `map_config` fields + a draw
   path. `LockedDoor` first: `DoorsModule` already scans `Door`/`KeycardDoor`
   (`EspModule.cpp:3859-3861`), so it is presentation-only. Skip static
   Extract/Transit markers — they duplicate live reads and desync from
   eligibility.
3. **Fix the five broken overlays** (see §5) — the fix data is DynamicMaps'.
4. **Marker icons (17 PNGs)** — atlas-pack; 17 loose descriptors against the
   63-slot SRV heap (`dxhook.cpp:219`) is affordable but not free.

Attribution files go alongside the assets, credited to Shebuka / acidphantasm /
TarkovTracker / TarkovDev / game-icons.net as marked in
`dynamicmaps/Plugin/Resources/**`.

## 4. Part 2 — The full-screen map (build last)

### 4.1 Open mechanism

**Our own M keybind, no game hooking.** Register `hotkeys::add_toggle` against a
`CheckboxValue` on the new module; `hotkeys::tick()` already polls
`GetAsyncKeyState` on the game thread (`hotkeys.h:158-200`). M is safe precisely
because we are *not* suppressing BSG's map — ours is an independent ImGui window.

This is the one place we deliberately diverge from DynamicMaps (which hijacks
`MapScreen.Show`). The user was explicit: no hooking the original game's
behaviour.

### 4.2 Module

New `MapModule` (`module/impl/MapModule.h/.cpp`), registered in `ModuleManager.h`
beside `MinimapModule`. Its `draw_overlay` must **not** be gated on `is_in_raid`
(the map should work in the stash/menu too), so it cannot live in `EspModule`
whose `draw_overlay` early-returns on `!is_in_raid` (`EspModule.cpp:4881`).
`MapEditorModule` sets the precedent: a map-adjacent module with an empty
`draw_overlay` sharing the `minimap::` singleton.

The overlay dispatch (`menu.cpp:1440-1444`) runs every frame, is **not**
raid-gated, and uses `ImGui::GetBackgroundDrawList()` — a new module's
`draw_overlay` is called every frame and may open a window.

### 4.3 The view

A centred, opaque ImGui window sized to ~90 % of the smaller screen dimension
(`ImGuiCond_Once`), reusing existing machinery:

- `minimap::request_active_map(current_location_id)` + `get_active_floor(...)`
  — as `draw_radar_overlay` does (`EspModule.cpp:5163-5180`).
- `minimap::build_map_view(...)` for projection, then `svg_raster_map::draw_layer`
  / `tile_raster_map::draw_layer` for base + overlay layers.
- **Quest objectives:** iterate `quest_poi_store`, project each `poi.pos` via
  `minimap::world_to_uv`, draw with `quest_poi_color(poi.type)` — the same call
  the minimap makes at `EspModule.cpp:2264`.
- Existing marker vectors (`local_players`, `local_exfils`, `local_transits`,
  `local_bot_corpses`) + `resolve_minimap_marker_point`.

New versus the radar: **zoom** (wheel), **pan** (drag), **level switching**
(`.`/`,` + Shift+wheel, cycling `active.active_overlay_index` — the feature the
radar cannot do at all), and the **map drop-down**.

### 4.4 The drop-down, and its honest limit

**Default behaviour (decided):** the map opens showing the map list. Until the
drop-down is ready, the view is **active in-raid only** (where a current
location and quest data exist). Game does **not** pause on map open — live
player position is available.

A `##maps` combo listing every config in `minimap::config_set`. Selecting one
calls `request_active_map(id)` and the view shows it. Per §1.1: quest markers
appear **only** when the selected map is the current location, because
`poi_entry.pos` is in the current location's world space. Static markers and
labels from DynamicMaps are per-map and will show for any selected map.

### 4.5 Input routing

Keybind flips a `bool` on the game thread (the `waiting_for_key` atomic join,
`hotkeys.h:56-60`); `draw_overlay` reads it. Drag/scroll/`.`,` are
render-thread `ImGui` reads in the same frame — no cross-thread state.

## 5. Latent bugs in current assets (independent of the harvest)

Measured across all 12 shipped `.json`. Failure mode confirmed: an unmatched
`svg_layer` makes `rasterize_visible_layer` return false (`svg_raster_map.cpp:204-209`)
and `draw_active_map` skip it (`minimap.h:2471`) — a **silent blank**, no log.

| map | overlay | problem |
|---|---|---|
| `bigmap` | 4th Floor | `svg_layer: "Third_Floor"` — duplicate; draws 3rd-floor art on the 4th |
| `reserve` | 4th Floor | `svg_layer: "Third_Floor"` — no such id in `reserve.svg`; blank |
| `reserve` | 1st Floor | `svg_layer: "Bunkers"` — duplicate of the Bunkers layer |
| `reserve` | 2nd/3rd/5th | `svg_layer: null` — satellite-only |
| `laboratory` | both | `svg_layer: null` — satellite-only |

`reserve.svg` contains exactly one layer id (`Ground_Level`); five of six
overlays cannot draw in abstract mode.

**No test would catch this.** Add `tools/tests/test_map_asset_integrity.py`
asserting every non-null `svg_layer` resolves to an `id` in its `.svg` and no
two overlays in one map share a layer. It fails today, on 5 overlays across 2
maps. That is the point.

## 6. Hand-off notes — unreachable on this machine

No gamedump, no ISIL references, no live process. These are **unknown**, not
missing. Each needs a Windows box with the game and a dump.

### 6.1 `EEftScreenType` — full enum values
Known: `Inventory = 15`, `TransferItemsInRaid = 42` (`eft_api.h:6454-6455`).
Needed: the **"no screen"/gameplay** value (to express "any blocking screen is
open"), the **MapScreen** value, and whether traders/stash/hideout have their
own. Get it by dumping `EFT.UI.Screens.EEftScreenType` from `Assembly-CSharp.dll`.

### 6.2 Does the game pause while BSG's map is open?
If it keeps simulating, our overlay draws over a live game; if it pauses,
`gameworld_update` may stop and the per-frame cache updates (`EspModule.cpp:5916`)
stall. Affects whether the full-screen map can rely on live player position.
**Measure on a live client**, not from source.

### 6.3 `current_location_id` out of raid
`scan_configs()` runs out of raid, but `current_location_id` is cleared by
`reset_raid_context()` (`EspModule.cpp:5877-5884`). The full-screen map in the
menu may have configs but no active location. Decide: show the last location's
map, or default to the drop-down's first entry.

## 7. Build order

| # | step | blocked on |
|---|---|---|
| 1 | `test_map_asset_integrity.py` (fails today) | — |
| 2 | Fix the 5 broken overlays | — |
| 3 | `is_ui_blocking_screen_open_cached()` + hide minimap | — |
| 4 | Labs + Labyrinth SVGs + attribution | — |
| 5 | Static markers + labels (LockedDoor first) | — |
| 6 | `MapModule` + M keybind + full-screen view + quest objectives | 1–5 |
| 7 | Map drop-down (current-location quest limitation documented) | 6 |

Steps 1–5 are buildable now. 6 is the big map. 7 is the drop-down.
