# Optics / projection — current implementation status

**As of 2026-10-06 21:30.** Measured on build `6AC53108`, session pid 8960
(20:43:40 → 20:47:03), ~62 s of optic activity, threads tid=17796 (main) and
tid=11220 (render).

This is the standing page for "is the optic pipeline healthy right now". History,
retractions and dead ends live in `TarkovAddons/Workstream_status_2026-09-24.md`;
the 21:24:50 crash is written up in `tools/handoff_call_through_null_crash.md`.

**Every rate below is summed over all 103 windows of one session.** Single windows
in this pipeline swing between 1 µs and 42 ms, and I have twice this session read
one window as the whole thing. Do not quote a window.

---

## 1. Verdict

**Functionally healthy, materially improved, with one number that got worse and one
instrument that is inert.**

| | prior | now | |
|---|---|---|---|
| `ensure_failed` | 62.4% | **5.7%** | 28,456 / 499,730 attempts |
| `fail_closed` | = `ensure_failed` | **= `ensure_failed`, exactly** | invariant holds |
| `scoped` | 28.6% | **47.6%** | 238,060 / 499,730 |
| `nonfinite` | 0 | **0** | 617,340 projections |
| `bad_packet` | 0 | **0** | |
| fallback geometry DRAWN | 0.0118% | **0.1033%** | **worse — see §4** |

One thing outside the projection path: the **violent-shake report (§7) is still open**,
and the current suspect is cross-thread contamination of the lens-size gate's rebaseline
timer. Fixed in commit `d3aa22fd` by making the gate state thread-local.

## 2. Cost

```
optic-perf, 103 windows, 5,223 route calls
  weighted mean      43 us/call     <- total_ns / total_calls
  median of windows  40 us/call
  range              32 .. 11,793 us/call   (max is the cold-start window)
  breakdown          meta 4-6 · matrix 1 · pose 2-3 · chain 4-6 · mask 20-28
```

**Do not use the unweighted mean of the per-window figures.** It gives 166 µs/call,
3.9x too high, because one window carries 11,793 µs/call and the rest sit at 32-44.
That is the same mean-versus-distribution trap as `is_unity_object_alive` earlier;
I walked into it here first and corrected it before publishing.

Range readability is essentially free now: `hit=689,923 miss=123` (**0.018%** miss),
`vq=246` visibility queries, 223 mask clears.

## 3. Why almost half of all projections are refused — and why that is correct

```
proj ok            617,340
  behind_optic     240,035  (38.9%)   outside the lens; refused, as specified
  behind_main        389    (0.06%)
nonfinite                0
bad_packet               0
```

`behind_optic` at 38.9% is the documented outside-the-lens refusal, not a failure
path. Attempts split `scoped 47.6% / fell_back 52.4%`, and **89% of the fallbacks
are `pointwise`** (233,106 of 261,670) — the legitimate per-point radial path, not a
failure. `no_packet 14,160` and `proj_failed 14,404` are 2.8% / 2.9% of attempts.

Conformance still holds: `optic-corner: agreement=1.33e-07 ndc` — the four optic-NDC
corners match `imageQuad` to 1.3e-7. No leakage: `optic-region: outside=0
max_outside=0px`. `optic-rejectcycle: 0% fail`.

## 4. OPEN: fallback geometry DRAWN went up ~9x

```
earlier   29 drawn / 245,381 attempts / 120 windows  =  0.0118%
now      516 drawn / 499,730 attempts / 103 windows  =  0.1033%
```

Absolute count is up because attempts doubled, but the **rate** is ~8.7x worse.

**I am not claiming this is a regression.** Two reasons not to:

1. It may be the same false counter as the `NO PACKET` warning below, which I proved
   false in 27 of 27 cases — the geometry it reports as drawn unclipped was in fact
   clipped. `drawn` and `NO PACKET` both come from the section-7 path.
2. The two figures may not be the same metric on the same basis. That has to be
   checked before either number means anything.

## 5. OPEN: `NO PACKET` warning still firing, still believed false

Five occurrences in the session:

```
23:15:51  4662/4662 calls (100%)   optic-s7
23:16:03   693/2898 calls ( 24%)
23:24:41    42/168  calls ( 25%)
23:24:43   420/1680 calls ( 25%)
23:24:43   252/1176 calls ( 21%)
```

The warning says the section-7 split did not run and the geometry "was drawn
UNCLIPPED, so it crosses the lens glass boundary uncorrected." Established 2026-10-04
17:15: **false in 27 of 27 cases** — the geometry was clipped. So this line has been
asserting a defect that does not exist, every session, and it is still ungated.
**Still unfixed.** Worth deleting or downgrading to DEBUG rather than leaving a
standing false alarm in a log people read under time pressure.

## 6. INERT: the cull path did not run at all this session

```
optic-cull:     mode=0 checks=0 rejected=0 (0%)  fitted_mask_used=0
optic-maskgate: mode=0 -> esp_ads_mask_allows=ALWAYS-TRUE (never culls)
```

In `mode=0` the mask gate short-circuits, so **`esp_ads_mask_allows` did nothing in
this capture** — the fitted polygon is the only live clip. That is why
`max_outside=0px` despite the gate being inert: the other mechanism is doing the work.

**Consequence: nothing can be concluded about culling from this capture.** If culling
is a question, the session needs `mode != 0`. I would rather say that than report a
healthy `rejected=0%` as if it were evidence.

## 7. ACTIVE INVESTIGATION: violent shake when the optic centre is off screen centre

**Status: both named candidates measured and cleared. Cause still unattributed.** Reported
2026-10-05. Nothing has been changed about behaviour except one opt-out switch.

**Numbering warning, before anything below is cited.** This section's retractions are numbered
7, 8, 9, but **retractions 1–6 do not exist in any revision of this file** — checked with
`git rev-list --all -- tools/optics_status.md`. They were referenced in prose here and in
`optics_lens_pipeline.h` as though they were on record, and they are not. That is the same
decay AGENTS.md warns about: a plausible number in prose outliving the record behind it. Cite
7/8/9 and no lower number; if you need the earlier ones, they have to be written first.

**Where this stands as of 2026-10-06 (f635d7f5):** the root corrector is exonerated — the
shake persisted with it switched off. The root *node* is now also effectively cleared as the
cause. What is left is not a matter of tuning either of them; something not yet instrumented
is moving the picture. Read the rest of this section before proposing a fix.

### The two candidates from the original report

**Root corrector** (`optic-root:`, `optic_lens_pipeline.h:3342`). Spec section 6/line 476
assumes the `HandsHierarchy.Self` node is rigidly attached to the camera, so its camera-local
position is near-constant and a filter is only needed when it jumps. It also **drops to zero**
on 9 of 102 frames (`no trusted sample within 50 ms`) — a hard discontinuity, not a smooth
handover.

**Lens-mask refit** (`optic-maskgate:`, `optic-region:`). The fitted mask is rebuilt every
frame: `fitted_pts` took **34 distinct values from 4 to 48** across 93 samples, and was
**0 on 3 frames** (no fitted mask at all). Its area breathes between **17.4% and 33.1%**
of the lens radius, median frame-to-frame change 1.20 pp, worst 11.00 pp, and hits
`cover=0.0%` on 3 frames. A polygon whose vertex count and area both move every frame is
not a stable aperture.

**Two of those numbers are wrong and one inference does not survive — see RETRACTION 10 below.**
The vertex-count swing is arithmetic, not instability. The *drop-outs* are real and are now
the strongest remaining candidate, but the mechanism is not the mask geometry: it is the
**lens-size gate that refuses the packet before the mask is ever published**, which is
section "the lens-size gate's escape hatch never fires" below. The `fitted_pts == 0` events
and that gate are the same event seen from two sides.

**Not the cause:** `optic-mat` produced exactly **one** distinct `(scales, shifts)` tuple
for the entire session — `scales=(40.00,0.94,100.00,100.00) shifts=(-0.150,0.039,0,0)`. The
affine correction never moves. Note the constant `shifts.x = -0.150`: the lens genuinely
is off-centre, which is the reported precondition.

### The A/B result: the corrector is EXONERATED

Checkbox flipped at **23:41:15**. Measured over the 114 windows in the capture:

| | corrector=on | corrector=DISABLED |
|---|---|---|
| windows | 19 | 95 |
| windows with `applied=0` | 0 | 93 |
| median of per-window frame medians | 3.86 mm | 0.065 mm |
| median of per-window maxima | 115.3 mm | 155.4 mm |

The shake was visible and unchanged throughout the 95 disabled windows, 93 of which applied
nothing at all. **A filter that is switched off and writes nothing cannot be what you saw.**
That conclusion rests on the visible artefact, not on any statistic above it.

Reproduce: `python tools\measure_move_vs_dt.py` (exits 2 if the log format has moved out
from under it).

### RETRACTION 7: my "frame-to-frame" figures were 600 ms apart

`optic-root:` is printed on `kOpticDumpMs = 600`, and consecutive lines measured a median
**611 ms** apart. So "frame-to-frame |delta| mean 4.25 mm, median 2.93, max 19.39" is the
drift over **600 ms windows**, not per frame. **The per-frame series has never been
observed** from that line, and the diagnostic is structurally incapable of showing it.

### RETRACTION 8: "local move med=0.19 mm — near-constant, premise holds"

The median did say that, and it was right about the median. It was wrong to read it as
settling the question, because the same capture held a frame at **56,557 mm**. I then
reported that as proof the premise was "catastrophically violated, not merely strained".

**It was a 45-second gap.** `move` is a delta between consecutive samples; `dt` is the
interval between those same samples; I quoted the first without the second.

```
2026-10-05 23:42:54.024  move_max=56556.8 mm  dt_max=45360 ms
```

The optic path only runs while the scope is up, so that is the last sample before
un-scoping and the first one after scoping again 45 seconds later. Not corruption, not a
violated premise.

Stated carefully, because the coefficient flatters it: Pearson r between window `move_max`
and window `dt_max` is **0.955**, but Spearman is **0.275** — one point out of 114 windows
owns nearly all the linear figure. So do not cite the correlation. The defensible claim is
categorical: **all eight** of the largest `move_max` readings came from windows containing a
gap of at least 312 ms (56,557 mm at 45,360 ms; 1,087.6 mm at 718 ms; 333.2 mm at 360 ms;
313.9 mm at 312 ms; 289.6 mm at 422 ms).

Restricted to the **94 windows with no gap over 250 ms**, which are the only ones where
`move` means anything per-frame:

| | value |
|---|---|
| largest `move` in any valid window | 245.6 mm |
| p50 of per-window maxima | 68.8 mm |
| p90 of per-window maxima | 204.1 mm |
| median of per-window frame medians | 0.33 mm |

So: per-frame the node moves 0.33 mm typically and never more than 245.6 mm. **The premise
is strained — 245 mm in a 16 ms frame is a lot for a rigidly attached node, and that part
remains unexplained — but it is not violated, and I claimed it was.** A 0.33 mm median does
not shake a screen, so the root node is not the cause of the shake either.

### RETRACTION 9: `dt` is NOT a steady 16 ms

I previously recorded `dt` as a constant 16 ms and used that to rule out irregular sampling.
**The median is 16 ms in every one of the 114 windows. The maximum is not.** 35% of windows
contain a gap over 100 ms, 18% over 250 ms, 5% over a second, and two windows contain gaps of
13.6 s and 45.4 s. Same error as retractions 7 and 8: the median standing in for the
distribution.

### What is now instrumented

**A per-frame ring** (`root_frame_sample`, `kRootRing = 96`) records, every frame on every
exit path: the camera-local root position in mm, the correction actually written, the sample
interval `dt`, whether anything was applied, plus `node_ptr` / `parent_depth` (identity of
the node the position came from) and `raw_len` / `finite`. `root_frame_summary()` collapses
it at the existing 600 ms cadence into one `root-frame:` line, appending a **gated** report
on the single worst frame of the window:

```
root-frame: 96 frames, applied=0 | local move mm med=0.26 max=56556.84 (>1mm:24 >5mm:6 of
  95, sign-reversals:2) | corr mm med=-1.00 max=0.00 | dt ms med=16 max=45360 |
  applied->dropped:0 | corrector=DISABLED
  | worst: move=56556.0mm local=(...) |pos|=...mm dt=45360ms node=.../2 prev=.../2
           node_changed=0 depth_changed=0 finite=1
```

`dt` is in the report because of retraction 8: `move` alone cannot tell a step from a hole in
the sampling, and that is the exact ambiguity that cost this investigation a day. The section
is gated so a permanently-present field does not train the reader to skip it.
`kSuspiciousMoveMm = 1000` mm fires on 0 of the 94 valid windows and 3 of 114 overall — see
the comment at that constant, which records that its original justification ("weapon sway
peaked at 216 mm/frame") was false: 6 of the 19 `corrector=on` windows exceeded 216 mm.

A ring rather than per-frame lines because ~60 lines/s is the mistake `tracy_bridge.h`
documents; four stores per frame, one summary line per 600 ms.

**An opt-out switch: `TA_OPTIC_ROOT_CORRECTOR_OFF=1`**, now also an `esp_optic_sec` checkbox
(`game_state::optic_root_corrector_off`, inverted per frame in `EspModule.cpp`; the env var
still wins if set). Needed to attribute a *visible* artefact between candidates.

### What each column decides

| observation | conclusion |
|---|---|
| `move` smooth and oscillating, `corr` tracking it | the game's weapon sway, faithfully passed through. Compensating it is intended — **smooth it, don't remove it** |
| `move` jagged, `sign-reversals` high | noise in how we *sample* it — ours |
| `dt max` far above `dt med` | **this is the null case, not a rare event.** `move` on such a frame is a delta across the gap and means nothing. Measured, not assumed |
| `node_changed=1` | the node was re-resolved, destroyed or recreated — the stale-read candidate, and a different bug from a bad read of the same node |
| `node_changed=0` and `dt` large | not a read fault at all: a hole in the sampling |
| `applied->dropped` > 0 on visible pops | the snap-to-zero discontinuity is a cause |

Genuine sway at 60 Hz reverses every half cycle (~30 frames), so `sign-reversals` is the
cheap discriminator: a flip every few frames is noise, not sway. Measured `sign-reversals`
was 0–22 per window, so both populations are present and this column does not separate them.

### FIXED: cross-thread contamination of the rebaseline timer (d3aa22fd)

**As of the 2026-10-05 capture this looked like starvation.** The gate reported 56
rejections and 0 re-baselines, in bursts of +14 in 603 ms, +14 in 604 ms, +9 in 603 ms.
The accept path sets `reject_since = 0`, so the 500 ms timer measures *continuous*
rejection, and a measurement that oscillates across the band edge resets it before it can
expire. `rebase=0` after 56 rejects was proof that accepts were interleaved.

**The 2026-10-06 capture shows the same gate doing the opposite.** Thread 17796 (main)
measures 0.3863x0.6862 and rejects 53 frames with rebase=0. Thread 11220 (render) measures
0.8521x1.5149 and rejects 55 frames with rebase=1. The two measurements differ by 2.2x.
They are different threads on different game frames, and the rebaseline adopted whichever
thread held the mutex when the timer expired.

**Root cause:** `g_lens_size` is global state, but two threads evaluate it on different
frames. The mutex serialises the call; the state mixes the timelines. When the timer
expires the winner writes its own measurement as the new baseline, which is exactly the
frame the other thread was rejecting.

**Fix:** `g_lens_size`, the ring buffer, and all run-length counters are now `thread_local`.
Each thread maintains its own baseline and timer. The mutex still serialises the refresh
work, but the state no longer crosses timelines. A scope swap affects both threads, so both
will rebaseline independently within 500 ms.

**What this means for the previous capture's diagnosis.** The 56-reject/0-rebaseline
finding was real, but its cause was cross-thread contamination, not necessarily timer
starvation from interleaved accepts. The two mechanisms look identical from the outside
(same rebase=0 outcome) and only the per-frame ring can separate them. The current code
records that ring; whether starvation ever actually occurred is now a question for a
single-thread capture.

### RETRACTION 10: `fitted_pts` 4→48 is structural, not a defect

I listed the fitted-mask vertex swing as evidence of an unstable aperture. It is arithmetic.
The subject polygon is a **fixed 48-gon** (`:3935`), `clip_polygon` is Sutherland-Hodgman where
each boundary edge adds **at most one** vertex (`util/linalg.h:151-169`), and the boundaries
are the image quad (4 edges) then the screen (4 edges). So `mask.size() ∈ [0, 48+4+4] = [0, 56]`.
All 84 readings are inside it and **48 is an ordinary value, not a suspicious maximum**. What
varies is how much of the ellipse survives both clips, which is expected to change as the
optic moves.

Also worth knowing before anyone counts those lines: `optic-maskgate:` prints **only when
`fitted_pts` changed** (`eft_api.h:2155`), so its 84 lines are **change-events, not samples**.
The distribution it reports is the distribution *at changes*. Absence of lines is not evidence
of stability.

### Still not instrumented — the next thing to add

Nothing in the mask *geometry* is left uninstrumented; the vertex count is settled above. The
lens-size gate cross-thread contamination is fixed (commit `d3aa22fd`). What is still missing
is the **input side of the lens-size gate**: how many candidate points the bbox offers before
the band test runs, and the shape of the quad that produces the near-edge ratios.
`near-edge(+-1%)` in `lenssize-frame:` is the first cut at that — it will say whether the
measurement hugs its own threshold, which is the signature of a value oscillating rather than
a value that is simply too small.

Also unexplained: the 245.6 mm per-frame maximum in an otherwise 0.33 mm-median series, and
whether the `applied->dropped` discontinuities land on the visible pops.


## 8. The 21:24:50 crash was in this path

`unity::camera_fov`, called through a null method pointer — `0xC0000005`,
**operation 8 EXECUTE, faulting address 0x0**, thread 26620, unwinding
`draw_imgui → menu::draw → EspModule::draw_overlay → setup_esp_optic_frame →
resolve_esp_camera → optic_lens_ensure_frame → unity::camera_fov`.

Fixed upstream in `6c8435ff`. `6AC2B1F3` additionally carries **nine more** of the
same shape in `eft_api.h`, five of them in `get_scope_zoom` — the optic scope-zoom
path, same file, same feature, same thread. See `tools/handoff_call_through_null_crash.md`.

**Those guards are shipped but unexercised.** This session had zero `get_method FAILED`
lines, so no resolve missed and no null was ever tested. The crash is fixed in the
sense that the code can no longer call through a null; it is *not* verified in anger.

## 9. Open items, in the order I would take them

0. **The violent-shake investigation (§7)** is active, and the lead has moved twice. The root
   corrector is exonerated (A/B: 95 windows disabled, `applied=0` in 93, shake unchanged) and
   the root node is effectively cleared (0.33 mm median per frame). **The lens-size gate
   cross-thread contamination is fixed** (commit `d3aa22fd`): the rebaseline timer was shared
   across two threads evaluating different frames, so it could adopt the wrong thread's
   measurement. Made thread-local; each thread now maintains its own baseline. **Until a
   capture with the fix in place proves otherwise, assume the shake cause is still unknown.**
   `lenssize-frame:` now reports the per-frame decisions, so the next capture answers whether
   the remaining rejections alternate (39% duty) or arrive in solid runs.

A capture makes this decisive. Look for, on each `lenssize-frame:` line:

| reading | conclusion |
|---|---|
| `reject max=1` with `rejected` about half of `evals` | **alternating.** The measurement is oscillating across its own threshold, the timer is starved, and the fix belongs in the gate's escape condition |
| `reject max` equal to most of `evals` | **solid runs.** Then `kRebaselineMs` *should* have expired and `rebase` should be nonzero — so if it still reads 0 with solid runs, the bug is in the timer, not in interleaving |
| `near-edge(+-1%)` close to `evals` | the measurement is hugging the threshold, which is the signature of an oscillation rather than a value that is merely too small |

The second row is the one that would overturn the starvation diagnosis, and it is why this is
instrumented rather than fixed.
1. **`NO PACKET` false alarm** (§5) — delete or demote to DEBUG. Cheapest, and it stops
   costing every future reader time.
2. **`drawn` rate** (§4) — establish whether `drawn` and `NO PACKET` share a false-counter
   bug. Same investigation, same files.
3. ~~**Mask fit input counters** (§7) — `fitted_pts` swings 4→48 with nothing explaining it.~~
   **Done and the premise withdrawn:** the swing is structural, not a defect (RETRACTION 10),
   and the mask drop-outs that do matter trace to the lens-size gate, not the fit. Superseded
   by item 0.
4. **Exercise the guards** (§8) — the call-through-null fixes need one session where a
   resolve actually misses before they are worth anything beyond code review.
5. **A capture with `optic-cull mode != 0`** (§6) before anyone asks about culling.
6. **`is_unity_object_alive` per-caller attribution** — committed in `a4239619`, needs a
   capture with the new rows. Unrelated to projection but it is the next-largest owned
   cost: 40.1 s with a 110 ns median, i.e. a tail, and the tail is unattributed.s_unity_object_alive` per-caller attribution** — committed in `a4239619`, needs a
   capture with the new rows. Unrelated to projection but it is the next-largest owned
   cost: 40.1 s with a 110 ns median, i.e. a tail, and the tail is unattributed.on but it is the next-largest owned
   cost: 40.1 s with a 110 ns median, i.e. a tail, and the tail is unattributed.