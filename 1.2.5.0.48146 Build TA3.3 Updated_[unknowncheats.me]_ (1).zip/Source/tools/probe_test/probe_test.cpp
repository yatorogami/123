// Windows-only proof that the crash probe does the two things it was rewritten for.
//
//   tools/probe_test/probe_test.cpp
//
// 2026-09-30 23:24:06: three crashes, all 0xE06D7363, and the probe printed nothing,
// because it classified a C++ throw as routine and discarded it. The rewrite splits
// capture from report. This asserts both halves of that split, which is the only way
// to know the fix works without waiting for the game to crash again:
//
//   CAUGHT   a throw that is handled  -> captured, but NO report. This is the flood
//            guard. If this regresses, every routine throw in the game prints a
//            report and the log becomes unreadable.
//   UNCAUGHT a throw that is not      -> reported, with the thrown type named. This
//            handled                          is the case that was invisible before.
//
// The test runs each case in a child process, because the uncaught case ends in
// std::terminate -> abort. The parent asserts on the child's exit code and on what
// the probe wrote to the log.
//
// It lives outside tools/harness on purpose: that harness is portable and
// deliberately has no <windows.h>. This needs a real Windows process, a real VEH
// and a real abort.

#include <cstdio>
#include <cstring>
#include <string>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "../../TarkovAddons/util/crash_probe.h"

namespace {

const char* log_path() {
    static std::string cached = [] {
        char buf[MAX_PATH] = {};
        GetModuleFileNameA(nullptr, buf, MAX_PATH);
        std::string p(buf);
        const size_t slash = p.find_last_of("\\/");
        if (slash != std::string::npos) p.resize(slash + 1);
        return p + "tarkovaddons_log.txt";
    }();
    return cached.c_str();
}

// The probe appends to the SAME file the logger uses, so that is what the test
// reads. Pointing it somewhere else would test a configuration the shipped DLL
// never runs in.
//
// module_paths resolves the directory from the handle it is given at init, and
// in a DLL that is captured during DLL_PROCESS_ATTACH before any anti-cheat
// hiding. Here the equivalent is the exe's own handle, which puts the log
// beside probe_test.exe -- the same relationship TarkovAddons.dll has with
// tarkovaddons_log.txt in BsgLauncher.
void clear_log() {
    DeleteFileA(log_path());
}

std::string read_log() {
    HANDLE h = CreateFileA(log_path(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
        nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return {};
    std::string out;
    char buf[4096];
    DWORD got = 0;
    while (ReadFile(h, buf, sizeof(buf), &got, nullptr) && got) out.append(buf, got);
    CloseHandle(h);
    return out;
}

// A polymorphic exception, so it HAS RTTI and its type name is recoverable.
// Deriving from std::exception is what gives it a vtable; that vtable's [-1]
// entry is the route the probe uses when the _ThrowInfo walk does not apply.
struct CustomError : std::exception {
    int code;
    explicit CustomError(int c) : code(c) {}
    const char* what() const noexcept override { return "probe_test"; }
};

// Deliberately NOT polymorphic: no vtable, therefore no RTTI, therefore no type
// name is recoverable by any means. For this one, "UNRESOLVED" is the correct
// answer, and the test asserts we say so rather than inventing a name.
struct PlainError { int code; };

int failures = 0;

void expect(bool ok, const char* what) {
    std::printf("  %s  %s\n", ok ? "PASS" : "FAIL", what);
    if (!ok) ++failures;
}

// The line of `log` that starts at `at`, or a marker if there is no such line.
// Never throws.
//
// This exists because the two call sites below indexed substr() with a position
// that find() can return npos for, and a harness that dies of an unhandled
// std::out_of_range reports "the test crashed" rather than "the test failed".
// That is not a cosmetic difference: on 2026-10-03 the probe wrote NOTHING (its
// frame walk faulted inside the VEH and killed the child), so this harness threw
// on the empty log and the whole suite was reported as an abort. The actual
// failure -- an access violation in the probe's own unwind lookup -- was never
// displayed. A diagnostic must not be the thing that hides a diagnostic.
std::string line_at(const std::string& log, size_t at) {
    if (at == std::string::npos) return "<no such line in the log>";
    const size_t eol = log.find('\n', at);
    return log.substr(at, (eol == std::string::npos ? log.size() : eol) - at);
}

// The 2026-10-03 10:35:14 shape, reproduced deliberately.
//
// That crash was an access violation on the process MAIN thread with under 160
// bytes of stack left, and it was fatal HERE rather than in the game: this
// header's own vectored handler ran a 152-byte prologue and an IAT call before
// it reached its report, and a fault inside a VEH kills the process outright.
// Nothing in the suite above covers that, because every other case has a healthy
// stack -- which is exactly why it survived a month of shipping.
//
// Run a thread out of stack and then fault on it. Deep recursion the optimiser
// cannot turn into a loop is the reliable way to consume a stack; the volatile
// pad keeps each frame real, and the volatile sink keeps the fault.
// Real recursion, not a tail call: the recursive result is NOT returned, so the
// optimiser cannot turn this into a loop, and each frame really does consume
// 8 KB of stack. With a 64 KB reserve that is roughly eight frames before the
// guard page is hit.
__declspec(noinline) void starve(volatile int* bad, int depth) {
    volatile char pad[8192];
    pad[0] = static_cast<char>(depth);
    if (depth >= (1 << 20)) {
        *bad = 1;                 // fault on the deepest frame we reach
        return;
    }
    starve(bad, depth + 1);
    (void)pad[0];
}

DWORD WINAPI starve_thread(LPVOID) {
    volatile int* bad = nullptr;
    starve(bad, 0);
    return 0;
}

// Two foreign handlers, standing in for whatever IL2CPP / BsgLauncher installs.
//
// They each write a marker of their own to the log and nothing else. That is the
// whole point: a foreign handler that merely "is still installed" proves nothing,
// because the probe could displace it and leave a dead pointer in g_prev_uef. The
// only way to show the displaced reporter still RUNS is to have it announce itself
// at the moment it runs.
//
// They do NOT use crash_probe::emit, because that is the code under test.
void append_marker(const char* text) {
    HANDLE h = CreateFileA(log_path(), FILE_APPEND_DATA,
        FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS,
        FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return;
    DWORD written = 0;
    WriteFile(h, text, (DWORD)std::strlen(text), &written, nullptr);
    CloseHandle(h);
}

LONG WINAPI foreign_uef(EXCEPTION_POINTERS*) {
    append_marker("probe_test: FOREIGN UEF RAN\n");
    return EXCEPTION_CONTINUE_SEARCH;
}
void foreign_terminate() {
    append_marker("probe_test: FOREIGN TERMINATE RAN\n");
    std::abort();
}

int run_child(const char* mode) {
    // Resolve our own directory first: the probe opens its log handle from
    // module_paths, and without this the fallback chain finds nothing and the
    // reports would be written nowhere. install() logs which handle it got, and
    // says so plainly when there is none.
    module_paths::init(GetModuleHandleA(nullptr));

    clear_log();
    crash_probe::install();
    std::printf("  child: mode=%s\n", mode);
    std::fflush(stdout);

    if (std::strcmp(mode, "caught") == 0) {
        // Handled. Must be captured, must NOT be reported.
        for (int i = 0; i < 3; ++i) {
            try {
                throw CustomError{7};
            } catch (const CustomError& e) {
                (void)e.code;
            }
        }
        // Also a std:: type, since that is what the real crash threw.
        try {
            throw std::length_error("probe_test");
        } catch (const std::length_error&) {
        }
        std::printf("  child: caught throws done, exiting 0\n");
        return 0;
    }

    if (std::strcmp(mode, "flood") == 0) {
        // More handled throws than the ring has slots, then a fault. This is the
        // 00:18:37 shape: a throw loop that ends in an access violation.
        //
        // Two properties, and the second is the one that was actually broken.
        // The first is that a deep burst still reports its TAIL -- the events
        // nearest the fault, which is where the answer is. The second is that
        // the FIRST event of the run survives, because a last-N ring necessarily
        // loses it: 24 throws into 24 slots left the first one alive only by
        // arithmetic luck, and one more event would have taken it.
        //
        // The fault is a genuine null write in this process, which is the point:
        // the vectored handler must report it, and the report must still be
        // readable after the process dies.
        for (int i = 0; i < 200; ++i) {
            try {
                throw CustomError{i};
            } catch (const CustomError& e) {
                (void)e.code;
            }
        }
        std::printf("  child: 200 handled throws done, faulting now\n");
        std::fflush(stdout);
        volatile int* bad = nullptr;
        return *bad;
    }

    if (std::strcmp(mode, "smallstack") == 0) {
        // Small reserve, then recursion, then a fault on a thread that has no
        // stack left. The probe must REPORT it. The process must then survive,
        // because the faulting thread is not the process and a diagnostic that
        // cannot tell the difference between "this thread is dying" and "we are
        // all dying" is the bug this case exists to catch.
        HANDLE t = CreateThread(nullptr, 64 * 1024, starve_thread, nullptr, 0, nullptr);
        if (!t) {
            std::printf("  child: could not create the thread (%lu)\n", GetLastError());
            return 3;
        }
        WaitForSingleObject(t, 30000);
        DWORD tcode = 0;
        GetExitCodeThread(t, &tcode);
        CloseHandle(t);
        std::printf("  child: starved thread exited 0x%08lX, parent still alive\n", tcode);
        std::fflush(stdout);
        return 0;
    }

    if (std::strcmp(mode, "displaced") == 0) {
        // The 2026-10-03 13:26:54 shape: the game died of an unhandled C++
        // exception and the probe said nothing. Cause (a) is that our two report
        // doors were taken -- each is ONE global slot, and unlike the VEH list
        // there is no way back in. Cause (b) is that the game's handler caught it
        // legitimately. Nothing on disk could tell them apart, so the check that
        // tells them apart has to exist.
        const bool ok_before = crash_probe::verify_handlers("before");
        expect(ok_before, "handlers are ours immediately after install");

        // Now something else claims both slots, exactly as a game's crash
        // reporter would some minutes into a session.
        SetUnhandledExceptionFilter(foreign_uef);
        std::set_terminate(foreign_terminate);

        const bool ok_after = crash_probe::verify_handlers("raid entry");
        expect(!ok_after, "verify_handlers reports that both doors had to be repaired");

        // THE INVERTED ASSERTION, and it is worth being explicit about why.
        //
        // This used to read:
        //     expect(cur == foreign_uef, "the foreign filter was left installed
        //                                 (probe did not steal it)");
        // i.e. it asserted that a lost report door STAYED LOST. That was a real
        // negative control, not decoration -- it is the reason 0xE06D7363 stayed
        // invisible for a month of crashes. But the property it protected was
        // wrong, because it treated the slot as a swap.
        //
        // It is not a swap. The correct invariant is "the process's own crash
        // reporting must still run", and chaining satisfies that without giving
        // the slot up. So both halves are asserted now: ours is installed, AND
        // the foreign handler is remembered -- because g_prev_uef holding the
        // foreign pointer is precisely what makes on_unhandled() chain to it
        // instead of replacing it. A slot-only assertion would pass even if the
        // chain input were null, which is the failure that would actually
        // suppress Battlestate's reporter.
        LPTOP_LEVEL_EXCEPTION_FILTER cur = SetUnhandledExceptionFilter(nullptr);
        SetUnhandledExceptionFilter(cur);
        expect(cur == crash_probe::on_unhandled,
               "our unhandled filter is installed again (probe re-asserted the slot)");
        expect(crash_probe::g_prev_uef == foreign_uef,
               "and the foreign filter is remembered, so it will still be called");
        const std::terminate_handler cur_t = std::set_terminate(crash_probe::on_terminate);
        expect(cur_t == crash_probe::on_terminate,
               "our terminate handler is installed again (probe re-asserted the slot)");
        expect(crash_probe::g_prev_terminate == foreign_terminate,
               "and the foreign terminate handler is remembered, so it will still be called");

        std::printf("  child: displaced check done, exiting 0\n");
        std::fflush(stdout);
        return 0;
    }

    if (std::strcmp(mode, "displaced_veh") == 0) {
        // The same displacement, but detected the way it would actually be in the
        // game: with no cooperation from anything. An exception has to arrive for
        // the vectored handler to run, so throw one -- caught, so the child lives
        // and the log can be read.
        SetUnhandledExceptionFilter(foreign_uef);
        std::set_terminate(foreign_terminate);
        for (int i = 0; i < 3; ++i) {
            try {
                throw CustomError{i};
            } catch (const CustomError& e) {
                (void)e.code;
            }
        }
        std::printf("  child: 3 caught throws past a foreign handler, exiting 0\n");
        std::fflush(stdout);
        return 0;
    }

    if (std::strcmp(mode, "chained_terminate") == 0) {
        // The terminate door, driven DIRECTLY -- and the reason is a measured fact,
        // not a preference.
        //
        // The obvious test here is "throw an uncaught exception and see if
        // terminate is reached". It does not work, and that is worth writing down.
        // Measured 2026-10-03: for an uncaught C++ throw the UNHANDLED EXCEPTION
        // FILTER fires FIRST and std::terminate fires SECOND. With nothing in the
        // filter slot both run, and the process exits 0xC0000409 (abort). With a
        // foreign filter chained ahead of ours that declines, terminate is NEVER
        // reached and the process exits 0xE06D7363.
        //
        // So the two doors are not interchangeable, and for the 0xE06D7363 shape --
        // the two crashes on 2026-10-03 that produced no artefact at all -- the
        // filter is the door that actually opens. chained_uef covers that one end
        // to end. This case covers the other door in isolation, by calling it, so
        // the assertion does not depend on which door Windows chooses to open.
        SetUnhandledExceptionFilter(foreign_uef);
        std::set_terminate(foreign_terminate);
        crash_probe::verify_handlers("mid-raid");        // the repair

        // Populate the ring first, the way the game does: hundreds of handled
        // throws, then the fatal one. This is also what makes the thrown-type
        // assertion below meaningful -- with an empty ring there is no type.
        for (int i = 0; i < 3; ++i) {
            try {
                throw CustomError{i};
            } catch (const CustomError& e) {
                (void)e.code;
            }
        }
        crash_probe::on_terminate();                     // reports, chains, aborts
        return 0;                                        // not reached
    }

    if (std::strcmp(mode, "chained_uef") == 0) {
        // The same for the other door, and reached the way Windows actually
        // consults an unhandled exception filter: a fault on a thread with no
        // handler to find. A throw would go to terminate instead, which is why
        // this cannot reuse chained_terminate.
        SetUnhandledExceptionFilter(foreign_uef);
        std::set_terminate(foreign_terminate);
        crash_probe::verify_handlers("mid-raid");

        volatile int* bad = nullptr;
        DWORD tid = 0;
        HANDLE t = CreateThread(nullptr, 0, starve_thread, nullptr, 0, &tid);
        if (!t) {
            std::printf("  child: could not create the faulting thread (%lu)\n", GetLastError());
            return 3;
        }
        // Not joined on purpose: this thread is going to take the process with it.
        // Sleep long enough that the process is gone before this returns.
        Sleep(30000);
        CloseHandle(t);
        return 0;
    }

    if (std::strcmp(mode, "imgname") == 0) {
        // A NON-CRASHING test of the module resolver, which is otherwise only
        // reachable by causing a fault at the right moment. This is the cheap
        // half of covering new code that runs on the capture path: it needs no
        // crash to prove that a known-good module is identified correctly.
        const char* names[] = { "KERNELBASE.dll", "ntdll.dll", "kernel32.dll" };
        for (const char* n : names) {
            HMODULE h = GetModuleHandleA(n);
            crash_probe::ImageInfo info;
            const bool ok = h && crash_probe::image_info(
                reinterpret_cast<uintptr_t>(h), info);
            char resolved[crash_probe::kModNameMax] = {};
            const bool named = h && crash_probe::image_name(
                reinterpret_cast<uintptr_t>(h), resolved, sizeof(resolved));
            std::printf("  %-18s base=%p ok=%d size=0x%llX ours=%d named=%d name='%s'\n",
                n, h, ok ? 1 : 0, static_cast<unsigned long long>(info.size),
                info.ours ? 1 : 0, named ? 1 : 0, resolved);
        }
        std::printf("  child: imgname done, exiting 0\n");
        std::fflush(stdout);
        return 0;
    }

    if (std::strcmp(mode, "uncaught") == 0) {
        // Not handled, and polymorphic so the name is recoverable.
        // std::terminate -> our handler -> report -> abort.
        throw CustomError{42};
    }

    if (std::strcmp(mode, "uncaught_plain") == 0) {
        // Not handled, and NOT polymorphic. No RTTI exists, so the type cannot
        // be named. Reporting UNRESOLVED is the honest outcome.
        throw PlainError{42};
    }

    if (std::strcmp(mode, "uncaught_std") == 0) {
        throw std::length_error("probe_test");
    }

    return 2;
}

} // namespace

int main(int argc, char** argv) {
    // `probe_test child <mode>` is the crashing child; no args is the parent,
    // which starts the children and asserts on what they left behind.
    if (argc >= 3 && std::strcmp(argv[1], "child") == 0) return run_child(argv[2]);
    if (argc >= 2) {
        std::printf("usage: probe_test            (run the suite)\n"
                    "       probe_test child <caught|flood|smallstack|displaced|"
                    "displaced_veh|chained_terminate|chained_uef|uncaught|"
                    "uncaught_std|uncaught_plain>\n");
        return 2;
    }

    std::printf("probe_test: log = %s\n\n", log_path());

    // ---- CAUGHT: no report, and the process survives -----------------------
    {
        std::printf("[case] caught throws must NOT be reported\n");
        std::string cmd = "\"";
        cmd += argv[0];
        cmd += "\" child caught";
        STARTUPINFOA si{}; si.cb = sizeof(si);
        PROCESS_INFORMATION pi{};
        if (!CreateProcessA(nullptr, cmd.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
            std::printf("  FAIL  could not start child (%lu)\n", GetLastError());
            return 1;
        }
        WaitForSingleObject(pi.hProcess, 30000);
        DWORD code = 1;
        GetExitCodeProcess(pi.hProcess, &code);
        CloseHandle(pi.hThread); CloseHandle(pi.hProcess);

        const std::string log = read_log();
        expect(code == 0, "child exited 0 (throws were handled)");
        expect(log.find("FATAL") == std::string::npos, "no FATAL report for a caught throw");
        expect(log.find("UNHANDLED C++ EXCEPTION") == std::string::npos,
               "no terminate report for a caught throw");
        std::printf("\n");
    }

    // ---- UNCAUGHT: reported, type named, process dies ---------------------
    // `uncaught` and `uncaught_std` are polymorphic, so the name is recoverable
    // and must be. `uncaught_plain` is not, so UNRESOLVED is correct there and
    // asserting a name for it would be asserting a lie.
    for (const char* mode : {"uncaught", "uncaught_std", "uncaught_plain"}) {
        const bool polymorphic = std::strcmp(mode, "uncaught_plain") != 0;
        // The exact substring the recovered name must contain. Asserting the real
        // name, not merely "something was printed", is the point: a walk that
        // returns ")" or a blank passes any weaker check while being useless.
        const char* want = std::strcmp(mode, "uncaught") == 0 ? "CustomError"
                         : (std::strcmp(mode, "uncaught_std") == 0 ? "length_error" : nullptr);
        std::printf("[case] %s throw (%s)\n", mode,
            want ? (std::string("polymorphic: name must contain ") + want).c_str()
                 : "not polymorphic: UNRESOLVED is correct");
        std::string cmd = "\"";
        cmd += argv[0];
        cmd += "\" child ";
        cmd += mode;
        STARTUPINFOA si{}; si.cb = sizeof(si);
        PROCESS_INFORMATION pi{};
        if (!CreateProcessA(nullptr, cmd.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
            std::printf("  FAIL  could not start child (%lu)\n", GetLastError());
            return 1;
        }
        WaitForSingleObject(pi.hProcess, 30000);
        DWORD code = 0;
        GetExitCodeProcess(pi.hProcess, &code);
        CloseHandle(pi.hThread); CloseHandle(pi.hProcess);

        const std::string log = read_log();
        expect(log.find("UNHANDLED C++ EXCEPTION") != std::string::npos,
               "terminate handler reported it");
        // Which door opens FIRST is a measured fact, not an obvious one, and the
        // two doors are not interchangeable: for an uncaught C++ throw the
        // unhandled-exception filter fires before std::terminate. That is why
        // repairing the filter is the load-bearing half of verify_handlers() --
        // and why a probe that watched only the terminate handler would be
        // watching the door that opens second. Measured 2026-10-03; see the
        // `chained_terminate` child mode for the consequence when a chained
        // filter declines.
        expect(log.find("FATAL (unhandled exception filter)") != std::string::npos,
               "the unhandled-exception filter reported it FIRST");
        expect(log.find("captured #") != std::string::npos,
               "the ring shows the captured throw");
        // Assert the NAME, not just the words "thrown type". The first version of
        // the walk emitted "thrown type: unknown" for every real exception, and a
        // test that only greps for the label passes happily on that -- which is
        // the whole failure this directory exists to prevent, one level up.
        // A name that is present but EMPTY counts as unresolved too: that is what
        // the "printable characters" filter returned when it accepted a run of
        // spaces, and it is worse than saying nothing because it looks answered.
        const size_t at = log.find("thrown type:");
        const bool named = at != std::string::npos &&
            log.find("thrown type: UNRESOLVED", at) == std::string::npos &&
            log.find("thrown type: unknown", at) == std::string::npos;
        if (want) {
            const std::string line = line_at(log, at);
            expect(line.find(want) != std::string::npos, "the recovered name contains the real type");
            std::printf("        -> %s\n", line.c_str());
        } else {
            expect(!named, "no type invented for a type with no RTTI");
        }
        // The process must still die. A probe that prevented the crash would be
        // a probe that destroyed the evidence it exists to collect.
        expect(code != 0, "the process still died (probe did not alter the failure)");
        std::printf("\n");
    }

    // ---- FLOOD: a deep burst must still report both ends -------------------
    {
        std::printf("[case] 200 handled throws then a fault (the 00:18:37 shape)\n");
        std::string cmd = "\"";
        cmd += argv[0];
        cmd += "\" child flood";
        STARTUPINFOA si{}; si.cb = sizeof(si);
        PROCESS_INFORMATION pi{};
        if (!CreateProcessA(nullptr, cmd.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
            std::printf("  FAIL  could not start child (%lu)\n", GetLastError());
            return 1;
        }
        WaitForSingleObject(pi.hProcess, 30000);
        DWORD code = 0;
        GetExitCodeProcess(pi.hProcess, &code);
        CloseHandle(pi.hThread); CloseHandle(pi.hProcess);

        const std::string log = read_log();
        expect(log.find("FATAL (vectored handler)") != std::string::npos,
               "the access violation was reported");
        expect(log.find("ACCESS_VIOLATION") != std::string::npos,
               "the fault is identified as an access violation");

        // The TAIL: the events nearest the fault. These must be the last ones
        // recorded, and they must be the ones carrying full frame listings.
        const size_t atCaptured = log.find("captured #");
        const size_t atFrames = log.find("frame 0");
        expect(atCaptured != std::string::npos, "the burst is in the report");
        expect(atFrames != std::string::npos && atFrames > atCaptured,
               "frames are listed, not just counted");

        // The HEAD: a last-N ring over 200 events has certainly discarded the
        // first, so its absence is the failure this case exists to catch.
        expect(log.find("pinned #0 ") != std::string::npos,
               "the FIRST event of the run survived the wrap (pinned #0)");
        expect(code != 0, "the process still died");
        std::printf("\n");
    }

    // ---- SMALL STACK: a fault on a thread with no stack left ---------------
    {
        std::printf("[case] fault on a stack-starved thread (the 2026-10-03 shape)\n");
        std::string cmd = "\"";
        cmd += argv[0];
        cmd += "\" child smallstack";
        STARTUPINFOA si{}; si.cb = sizeof(si);
        PROCESS_INFORMATION pi{};
        if (!CreateProcessA(nullptr, cmd.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
            std::printf("  FAIL  could not start child (%lu)\n", GetLastError());
            return 1;
        }
        WaitForSingleObject(pi.hProcess, 30000);
        DWORD code = 0;
        GetExitCodeProcess(pi.hProcess, &code);
        CloseHandle(pi.hThread); CloseHandle(pi.hProcess);

        const std::string log = read_log();
        // The two that matter, and both failed on 2026-10-03: the probe ran a
        // 152-byte frame plus an IAT call ahead of its report, faulted, and took
        // the process with it, so nothing at all reached the log.
        expect(log.find("FATAL") != std::string::npos,
               "the fault on a starved thread was still reported");
        expect(log.find("STACK_OVERFLOW") != std::string::npos,
               "the report names the starvation rather than blaming the probe's own fault");

        // Windows terminates the process when a thread's stack overflow cannot be
        // delivered to a handler, so exiting non-zero here is CORRECT and is not
        // the probe's doing. What must hold is that the process died of the
        // ORIGINAL fault: before the fix this handler died inside itself and the
        // process went down 0xC0000005 instead, which is the whole failure -- the
        // diagnostic had replaced the evidence with itself.
        expect(code == 0xC00000FD,
               "the process died of the original stack overflow, not of the probe");
        std::printf("        -> child exit code 0x%08lX\n", code);
        std::printf("\n");
    }

    // ---- DISPLACED: the 13:26:54 shape --------------------------------------
    {
        std::printf("[case] our two report doors get taken (the 2026-10-03 shape)\n");
        std::string cmd = "\"";
        cmd += argv[0];
        cmd += "\" child displaced";
        STARTUPINFOA si{}; si.cb = sizeof(si);
        PROCESS_INFORMATION pi{};
        if (!CreateProcessA(nullptr, cmd.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
            std::printf("  FAIL  could not start child (%lu)\n", GetLastError());
            return 1;
        }
        WaitForSingleObject(pi.hProcess, 30000);
        DWORD code = 0;
        GetExitCodeProcess(pi.hProcess, &code);
        CloseHandle(pi.hThread); CloseHandle(pi.hProcess);

        const std::string log = read_log();
        expect(code == 0, "child exited 0 (repair is not itself fatal)");
        // The point of the whole case: the silence must become a line in the log.
        expect(log.find("REPAIRED") != std::string::npos,
               "the repair is reported");
        expect(log.find("unhandled-exception filter had been") != std::string::npos,
               "the lost unhandled-exception filter is named and re-installed");
        expect(log.find("terminate handler had been") != std::string::npos,
               "the lost terminate handler is named and re-installed (0xE06D7363)");
        // The line that used to be here asserted the warning said why it did NOT
        // reclaim the slot. The warning now has to say the opposite -- that it
        // chained -- because that sentence is what tells a reader the game's
        // reporter still runs. A reader who saw the old text would conclude the
        // opposite of what happens.
        expect(log.find("chained to") != std::string::npos,
               "the repair says it chained rather than displaced");
        expect(log.find("minidump is unaffected") != std::string::npos,
               "and says so explicitly, so nobody stops looking for their dumps");
        std::printf("\n");
    }

    // ---- MODULE RESOLUTION: covered without arranging a crash ----------------
    {
        std::printf("[case] modules are identified and named, with no fault involved\n");
        std::string cmd = "\"";
        cmd += argv[0];
        cmd += "\" child imgname";
        STARTUPINFOA si{}; si.cb = sizeof(si);
        PROCESS_INFORMATION pi{};
        if (!CreateProcessA(nullptr, cmd.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
            std::printf("  FAIL  could not start child (%lu)\n", GetLastError());
            return 1;
        }
        WaitForSingleObject(pi.hProcess, 30000);
        DWORD code = 0;
        GetExitCodeProcess(pi.hProcess, &code);
        CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
        // The property that matters is not "a name came back" but "asking for a
        // name did not kill the process". The first version of image_name() read
        // the PE export directory on this path and took the suite from 45/45 to
        // 22/45, because a __except does not fire for a fault raised inside a
        // vectored handler. So this asserts survival, not text.
        expect(code == 0, "child exited 0 (resolving module names is not itself fatal)");
        std::printf("\n");
    }

    // ---- CHAINED, terminate: the 13:26:54 / 19:55:41 shape, repaired ---------
    {
        std::printf("[case] an unhandled C++ exception reaches BOTH reporters\n");
        std::string cmd = "\"";
        cmd += argv[0];
        cmd += "\" child chained_terminate";
        STARTUPINFOA si{}; si.cb = sizeof(si);
        PROCESS_INFORMATION pi{};
        if (!CreateProcessA(nullptr, cmd.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
            std::printf("  FAIL  could not start child (%lu)\n", GetLastError());
            return 1;
        }
        WaitForSingleObject(pi.hProcess, 30000);
        DWORD code = 0;
        GetExitCodeProcess(pi.hProcess, &code);
        CloseHandle(pi.hThread); CloseHandle(pi.hProcess);

        const std::string log = read_log();
        // Both halves, and the ORDER matters: ours runs first, theirs second.
        const size_t ours = log.find("UNHANDLED C++ EXCEPTION");
        const size_t theirs = log.find("FOREIGN TERMINATE RAN");
        expect(ours != std::string::npos,
               "the probe reported the throw it would previously have missed");
        expect(theirs != std::string::npos,
               "AND the game's handler still ran (chained, not displaced)");
        expect(ours != std::string::npos && theirs != std::string::npos && ours < theirs,
               "in that order: our report first, the process's own reporter behind it");
        // Deliberately NOT asserting a thrown-type name here, and the reason is worth
        // recording. emit_thrown_type() recovers the name from the thrown object's
        // vtable, so it can only do so while that object is still alive -- true
        // during a real std::terminate, false for a throw whose catch block has
        // already completed. This case seeds the ring with caught throws in order
        // to make the ring assertion below meaningful, so those objects are gone
        // and there is honestly nothing to name. The `uncaught` cases are where
        // the type name is asserted, and they pass.
        expect(log.find("captured #") != std::string::npos,
               "the terminate report printed the ring it was handed");
        std::printf("\n");
    }

    // ---- CHAINED, unhandled exception filter: the other door -----------------
    {
        std::printf("[case] an unhandled SEH fault reaches BOTH reporters\n");
        std::string cmd = "\"";
        cmd += argv[0];
        cmd += "\" child chained_uef";
        STARTUPINFOA si{}; si.cb = sizeof(si);
        PROCESS_INFORMATION pi{};
        if (!CreateProcessA(nullptr, cmd.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
            std::printf("  FAIL  could not start child (%lu)\n", GetLastError());
            return 1;
        }
        WaitForSingleObject(pi.hProcess, 30000);
        DWORD code = 0;
        GetExitCodeProcess(pi.hProcess, &code);
        CloseHandle(pi.hThread); CloseHandle(pi.hProcess);

        const std::string log = read_log();
        const size_t ours = log.find("FATAL");
        const size_t theirs = log.find("FOREIGN UEF RAN");
        expect(ours != std::string::npos,
               "the probe reported the fault through the unhandled-exception filter");
        expect(theirs != std::string::npos,
               "AND the game's filter still ran (chained, not displaced)");
        expect(ours != std::string::npos && theirs != std::string::npos && ours < theirs,
               "in that order: our report first, the process's own reporter behind it");
        std::printf("\n");
    }

    // ---- DISPLACED, detected with no cooperation: the VEH path ---------------
    {
        std::printf("[case] displacement noticed from the vectored handler alone\n");
        std::string cmd = "\"";
        cmd += argv[0];
        cmd += "\" child displaced_veh";
        STARTUPINFOA si{}; si.cb = sizeof(si);
        PROCESS_INFORMATION pi{};
        if (!CreateProcessA(nullptr, cmd.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
            std::printf("  FAIL  could not start child (%lu)\n", GetLastError());
            return 1;
        }
        WaitForSingleObject(pi.hProcess, 30000);
        DWORD code = 0;
        GetExitCodeProcess(pi.hProcess, &code);
        CloseHandle(pi.hThread); CloseHandle(pi.hProcess);

        const std::string log = read_log();
        expect(code == 0, "child exited 0");
        expect(log.find("terminate handler had been") != std::string::npos,
               "a routine caught throw was enough to notice and repair the lost terminate handler");
        expect(log.find("FATAL") == std::string::npos,
               "and it was only a repair notice -- no false crash report");
        std::printf("\n");
    }

    std::printf("%d check(s) failed\n", failures);
    return failures == 0 ? 0 : 1;
}
