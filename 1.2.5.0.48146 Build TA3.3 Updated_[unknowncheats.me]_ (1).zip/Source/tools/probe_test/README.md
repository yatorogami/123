# tools/probe_test

Executable proof that the crash probe does the two things it was rewritten for.

```sh
tools/probe_test/run.sh        # exit 0 = pass, 1 = fail
```

Windows-host only, and deliberately so. `tools/harness/` is portable because
what it tests is standard-library only; this tests a vectored exception handler,
a terminate handler and an `abort`, none of which exist on Linux. A portable
version of this test would be a test of nothing.

## Why it exists

The probe was rewritten on 2026-09-30 after the 23:24:06 crash. That build
classified `0xE06D7363` — an unhandled MSVC C++ exception, the exact code that
killed the game three times — as "routine, do not report", counted it, printed
nothing, and let the process die. The safety net that was supposed to reveal
suppressed exceptions could not fire: it was only printed from *inside* the
fatal branch, so a suppressed exception that was itself the crash was
structurally unreportable.

The rewrite splits **capture** (every exception, always, into a lock-free ring)
from **report** (only where the outcome is already known). Those are two
separate claims, and this asserts both:

| case | must |
|---|---|
| a throw that is **caught** | be captured, and produce **no** report |
| a throw that is **uncaught** | be reported, with the thrown type named |
| any case | leave the process dying exactly as it would have |

That first row is the flood guard, and it is the reason the old design existed:
an earlier version spent its one-shot report on a throw the game handled two
seconds later and then stayed silent through the fault that killed the process.
If the flood guard regresses, every routine throw in a raid prints a report and
the log becomes unreadable.

The last row matters just as much. A probe that *prevented* the crash would be a
probe that destroyed the evidence it exists to collect, so every path either
returns `EXCEPTION_CONTINUE_SEARCH` or chains to the handler it displaced.

## The three throw cases, and why they differ

```
caught         std::exception-derived, handled          no report
uncaught       std::exception-derived, not handled      type named
uncaught_std   std::length_error, not handled           type named
uncaught_plain a struct with no base class, unhandled    UNRESOLVED -- correctly
```

`uncaught_plain` is the interesting one. A type that does not derive from
`std::exception` has no vtable, so it has no RTTI, so **no type name is
recoverable by any means**. The test asserts we say `UNRESOLVED` rather than
inventing one, because a wrong type name is worse than an absent one: it looks
like an answer.

## Assertions vs "it printed something"

The test asserts the recovered name **contains the real type name** —
`CustomError`, `length_error` — not merely that the words `thrown type` appear.
That distinction is the whole point, and it was learned the hard way while
building this: an early version of the walk emitted `thrown type: unknown` for
every real exception, and a test grepping for the label passed happily on that.
A later version emitted `)` — a single stray byte that had passed a
"printable characters" test. Both are the same failure as a checker that
reports success because it did nothing, one level up.

For the same reason a name is only accepted if it contains `@`. Every
MSVC-mangled name does — `?AVlength_error@std@@`, `.?AUCustomError@?A0x777e1ae0@@`
— and nothing else at that address does.

## The stack-starved case, added 2026-10-03

```
smallstack     fault on a thread with no stack left     reported, and the
                                                          process still dies of
                                                          the ORIGINAL fault
```

This is the case that was missing, and it is the one that mattered, because it is
the shape of the crash that actually happened.

On 2026-10-03 10:35:14 the game died with `0xC0000005` at
`TarkovAddons.dll+0x50DA1`. That RVA is `crash_probe::fill_event+0x41`, and the
six bytes there are `call qword ptr [rip+0x266319]` resolving to
`__imp_GetCurrentThreadId`. So the probe killed the process while observing it:
`handler()` ran the capture before it ran the report, `fill_event`'s prologue
costs 152 bytes, and the thread had under 160 bytes left. A fault inside a VEH
is not catchable — Windows does not fall through to another handler, an
`__except`, the unhandled filter or `std::terminate` — so the process died with
nothing written. That is why "crash_probe never triggers" for a month of
`0xC0000005` crashes.

Every other case in this file faults on a thread with a healthy stack, which is
exactly why they all passed while the shipped DLL was broken. The suite was
green and the probe was fatal. Hence `smallstack`: a 64 KB reserve, real
recursion to consume it, then a fault on a thread that has none.

The exit-code assertion is the interesting one. The process **must** die with
`0xC00000FD`, because Windows terminates the process when a stack overflow cannot
be delivered to a handler — that is correct and is not the probe's doing. What
the assertion pins down is that the process dies of the *original* fault. Before
the fix, the handler died inside itself and took the process down `0xC0000005`
instead: the diagnostic had replaced the evidence with itself.

Two bugs were found by writing this case, both of which had been shipping:

- `handler()` captured before it reported (fixed by splitting the capture into a
  cheap head and a guarded tail).
- `in_executable_section()` called `RtlLookupFunctionEntry` with a **null**
  `ImageBase`, which makes it walk the PEB loader list to find our own module.
  That walk faults from inside a VEH — measured, not reasoned: this case fails
  `0xC0000005` and passes the instant `g_base` is passed instead. It could not
  have worked anyway, since a manual-mapped image is not in the loader lists at
  all, so every one of our return addresses was being counted as a data word
  instead of a frame.

The harness had a bug of its own here. It indexed `substr()` with a `find()`
result that can be `npos`, so when the probe wrote nothing at all the *test* died
of an unhandled `std::out_of_range` and the suite was reported as an abort rather
than a failure. The actual fault was never displayed. That is fixed too
(`line_at()`), because a diagnostic that hides the diagnostic is the same bug one
level up.

## The displaced-handler cases, added 2026-10-03 (second pass)

```
displaced       both report doors are taken by something else   detected, and the
                                                                  thief is left alone
displaced_veh   the same, noticed from the VEH alone             a routine CAUGHT
                                                                  throw is enough
```

Earlier the same day the probe was rewritten after it turned out to be killing the
process. Then at 13:26:54 it failed the other way: the game died of an unhandled
C++ exception — `0xE06D7363`, raised in `KERNELBASE.dll+0xc41ca`, main thread,
during transit — and the probe printed **nothing**, having produced a complete
report for an access violation eight hours earlier.

That asymmetry is the whole finding. An access violation is reported by the
vectored handler, and `AddVectoredExceptionHandler` is a **list** — a later
registrant cannot displace an earlier one. An unhandled C++ exception is reported
by `std::terminate` or `SetUnhandledExceptionFilter`, and **each of those is ONE
global slot where the last writer wins**. The probe installs both at
`13:17:54.692`, on its own injected thread; the game then initialises for nine
more minutes, and IL2CPP, BsgLauncher or Battlestate's own reporter can take
either slot at any point. After that, the probe is blind to a whole class of
crash with nothing in the log to say so.

There were two candidate causes and nothing on disk could separate them:

- **(a)** our handlers were taken, or
- **(b)** the game's own handler caught the exception and exited, in which case no
  unhandled filter is ever consulted and the crash was never ours to see.

`crash_probe::verify_handlers()` answers that, and **(a) is confirmed**: the
warning fired within the hour of the check being added, and in every session since.

### It repairs, by chaining. It does not displace.

This is the second half of the story, and the first half of it was wrong.

The check originally detected and deliberately did **not** repair, on this
reasoning: *"Re-asserting our handlers would mean displacing the game's crash
reporter — suppressing the Battlestate dialog and its minidump — which changes
how the process dies. That is the one property this probe must never violate."*

That treats the slot as a swap. It is not one. `on_unhandled()` and
`on_terminate()` both call `g_prev_uef` / `g_prev_terminate` **after** writing
their report, so a displaced handler is not removed — it is demoted to running
second. The correct form of the invariant is *"the process's own crash reporting
must still run"*, and chaining satisfies that without giving the slot up.

So the probe now re-asserts both slots unconditionally. There is no switch,
because there is no behaviour trade-off to gate: the process dies the same way
whether the repair happens or not, and a config flag would only be a way to ship
the blindness on purpose.

Two things were already true and made this cheap:

- The reporting code was never untested. `on_unhandled()` has always called the
  same guarded capture path the vectored handler uses. It had simply never been
  **reached**, because the game took the door first.
- The old read-modify-restore had a window the repair does not:
  `SetUnhandledExceptionFilter` has no getter, so asking meant passing `nullptr`,
  which *clears* the slot. Asking and setting are now the same call.

### Which door actually opens, and why that was worth measuring

The obvious way to test the terminate door — throw something uncaught and see if
terminate is reached — does not work. Measured 2026-10-03:

- for an uncaught C++ throw the **unhandled-exception filter fires first** and
  `std::terminate` fires second;
- terminate is reached **only because we chain** to the filter installed before
  us (the CRT puts one there by default). Remove the chain and terminate is never
  reached at all — the process dies at the filter with `0xE06D7363`.

So the two doors are not interchangeable, the filter is the one that matters for
the `0xE06D7363` shape, and this coupling was found by breaking the chain on
purpose and watching what failed.

### The cases, and what each one is negative-controlled against

| case | asserts |
|---|---|
| `displaced` | both slots re-asserted, **and** the foreign handlers remembered in `g_prev_*` |
| `chained_uef` | an unhandled fault reaches **both** reporters, ours first, theirs behind it |
| `chained_terminate` | the terminate door chains, driven directly so it does not depend on which door Windows picks |
| `uncaught` (×3) | both doors fire, and the filter fires *first* |

`displaced` used to assert the exact opposite — that a lost report door **stayed
lost**. It was a real negative control, not decoration; it is the reason
`0xE06D7363` stayed invisible for a month. The property it protected was simply
wrong, so it is now inverted, and it asserts *two* things rather than one: ours is
installed, and `g_prev_uef` holds the foreign pointer. A slot-only assertion would
pass even with a null chain input, which is the failure that would actually
suppress Battlestate's reporter.

The foreign handlers in this file write a marker of their own to the log and
nothing else. A foreign handler that merely *is still installed* proves nothing —
the probe could displace it and leave a dead pointer behind. The only way to show
the displaced reporter still **runs** is to have it announce itself when it does.

Negative control, run 2026-10-03: disabling the `g_prev_uef` call makes
`chained_uef` fail on exactly the two assertions that exist for it, and also fails
the three pre-existing `uncaught` cases — which is how the coupling above was
found.

### Wiring, and why it needed no game file

`verify_handlers_throttled()` is called from the vectored handler, rate-limited
to once a minute. That location is not arbitrary: exceptions arrive on their own,
so the check needs no cooperation, no raid hook, and no edit to a file the optics
and hideout workstreams also have open. The `displaced_veh` case proves the
runtime path rather than the function — a *caught* throw is enough to notice,
and it stays a warning rather than becoming a false crash report.

## The frame walk, rewritten 2026-10-03 (third pass)

The frame list used to keep **only stack words inside our own image**. That is
the change that lost a crash.

At 22:39:37, boot + 260 ms, on the injection thread: an execute fault at address
`0` — `ExceptionInformation[0] == 8`, a call through a null pointer — inside
`dxhook::init()`. The probe reported it. The two frames it returned were
`dxhook::create_window+0xE2` and `dxhook::dx11_setup+0x2B6`, and disassembly
showed **both were stale words from code that had already run**: one sat in
`create_window`'s epilogue after it had returned, the other in the middle of an
inlined `memcpy` loop.

The caller — in `d3d11`/`dxgi`/`ntdll`, where a call through a null pointer
across a COM/D3D boundary actually lives — was dropped without a word, and a
deeper word of *ours* was printed in its place as `frame 0`. The filter was not
merely lossy; it **renumbered what survived**.

So the walk now keeps every stack word that is a code address in *any* mapped
image, resolved with one `VirtualQuery` plus a validated PE header read, and
prints each one with:

- its **slot offset from RSP** — the field that would have exposed the stale
  frames, since a residue word and a live return address look identical otherwise;
- the **module name and RVA**, from the loader, at emit time;
- **`<this module>`** on frames that resolve against our `.map`, so
  `tools/symbolize.py` is never pointed at an address it cannot name.

And it states plainly what it is:

```
captured #0 code=0xE06D7363 ... frames=11 (scan of stack words, not an unwound
  stack; 8 in-image non-code and 235 out-of-image word(s) skipped)
   #0 frame 0 [rsp+0x030] 00007FF88EA341CA KERNELBASE.dll+0xC41CA
   #0 frame 1 [rsp+0x198] 00007FF891805AD8 ntdll.dll+0x125AD8
   #0 frame 5 [rsp+0x940] 00007FF6F4E6E000 probe_test.exe+0x2E000 <this module>
```

This is still **not** an unwound stack. Words that are data, spilled registers,
or outside any image are skipped, and the counts say how many.

### A discriminator that was tried and removed

The obvious way to tell a live return address from residue is to check whether a
`CALL` ends at it. It was implemented and measured against the 22:39:37 frames:
`0x124542` genuinely **is** the return address of a `call __security_check_cookie`,
so the test would have labelled the stale word as a live frame and made the
report *more* confident, not less. It is not in the code. Depth is the honest
signal, and a gap in depth is visible in a way a heuristic verdict is not.

### Two traps this walked into, both recorded in the header

1. **`__except` does not fire for a fault raised inside a VEH.** The first
   version read foreign PE headers through `safe_read16/32`, which are
   `__try`/`__except`. An uncommitted header page therefore did not become a
   false "not an image" — it became a dead process, and `tools/probe_test` went
   from 45/45 to **22/45**, with the benign `caught` child dying `0xC0000005` on
   a *handled* throw and writing nothing at all. On the capture path
   `VirtualQuery` is now the only thing permitted to decide whether a read is
   safe, because it cannot fault.
2. **The PE export directory's `Name` field is not the module name.** Reading it
   produced mojibake: on `ntdll` it resolved to an RVA about 44 bytes *before*
   the real string. Names now come from the loader at emit time — which is not
   the VEH path, so a PEB walk is safe there — and `image_name()` is covered by
   the `imgname` child mode, which asserts the process **survives** asking.

## What it does not cover

**It does not test the DLL, the game, or a manual map.** This runs in a normal
console process where the module is LDR-registered and its PE headers are
present. The probe's `mapped_extent()` fallback — for a manually-mapped image
whose DOS/NT headers were never copied — is therefore *not* exercised here, and
neither is the `loader names this base` path that exists because a manual map
makes `GetModuleFileNameW` return the wrong module entirely.

That is now also why a frame in our own image prints as `<unnamed image>` with
`<this module>` beside it in the real game: `GetModuleFileNameA` cannot name a
manual-mapped image, and the probe says so rather than borrowing a neighbour's
name. The `.map` still resolves the RVA, which is the part that matters.

Those paths are only reachable inside a real raid, which is the situation the
probe exists for and the situation this project cannot build a harness for. The
test covers the decision logic, not the deployment.

**It does not test the AV / fastfail branch's stack unwinding**, only that the
terminate path reports. The VEH's capture is exercised (every throw passes
through it), but no test deliberately faults the stack.

**It does not test a foreign frame surviving the trip through the report.**
`chained_uef` proves both reporters run; it does not prove that a `d3d11` frame
is still resolvable at emit time. Only a real crash in the game shows that.

## Files

- `probe_test.cpp` — the cases and the assertions (11 child modes, 46 assertions)
- `stubs.cpp` — `logger::info` only. The probe reports through its own
  pre-opened handle and touches the logger just for the install banner, so
  linking `logger.cpp` would drag in console colours and the shared
  `std::ofstream` — the latter being the very thing the rewrite stopped calling
  from a fault context after `logger.cpp` recorded the 20:56:06 access violation
  faulting inside `basic_filebuf<char>::_Endwrite`.
- `run.sh` — locates `vcvars64.bat`, builds, runs. Needs MSVC; no game, no
  deployed DLL, no project build.
