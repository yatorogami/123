#!/usr/bin/env bash
# Build and run the crash-probe test.
#
#   tools/probe_test/run.sh
#
# Windows-host only, and deliberately so. tools/harness/ is portable because
# what it tests is standard-library only; this tests a vectored exception
# handler, a terminate handler and an abort, none of which exist on Linux. A
# portable version of this test would be a test of nothing.
#
# Needs MSVC. Nothing here touches the game or the deployed DLL.
set -uo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
REPO=$(cd "$HERE/../.." && pwd)
OUT=${OUT:-$(mktemp -d)}
trap 'rm -rf "$OUT"' EXIT

# Locate vcvars64 so the same script works from any shell that can run bash.
vcvars=""
for c in \
    "${VCToolsInstallDir:-}/Auxiliary/Build/vcvars64.bat" \
    "C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/VC/Auxiliary/Build/vcvars64.bat" \
    "C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/VC/Auxiliary/Build/vcvars64.bat" \
    "C:/Program Files/Microsoft Visual Studio/2022/Community/VC/Auxiliary/Build/vcvars64.bat"
do
    [ -f "$c" ] && { vcvars="$c"; break; }
done
if [ -z "$vcvars" ]; then
    echo "no vcvars64.bat found; set VCToolsInstallDir" >&2
    exit 2
fi

echo "=== building probe_test ==="
cmd //c "\"$vcvars\" >nul 2>&1 && cl /nologo /std:c++latest /EHsc /W3 \
    /I \"$HERE\" /I \"$REPO/TarkovAddons/util\" \
    \"$HERE/probe_test.cpp\" \"$HERE/stubs.cpp\" \
    /Fe:\"$OUT/probe_test.exe\" /Fo:\"$OUT/\""
if [ ! -f "$OUT/probe_test.exe" ]; then
    echo "build failed" >&2
    exit 1
fi

echo "=== running probe_test ==="
"$OUT/probe_test.exe"
status=$?
echo
if [ $status -eq 0 ]; then
    echo "PASS"
else
    echo "FAIL (exit $status)"
fi
exit $status
