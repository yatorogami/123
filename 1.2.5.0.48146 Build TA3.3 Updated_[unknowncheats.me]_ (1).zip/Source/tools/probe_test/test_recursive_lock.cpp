// Reproduction for the recursive-lock deadlock behind the 09:01 crash.
//
// The probe named the type: `.?AVsystem_error@std@@`, thrown 5900+ times from
// tid=13688, in a chain of
//
//     hk_game_world_update -> ModuleManager::apply -> refresh_passcode_labels
//
// and EspModule.cpp:5261 holds `data_mutex` when it calls
// refresh_passcode_labels(), which locks `data_mutex` again at line 3200 and
// again at 3234. std::mutex is not recursive, so this is a self-deadlock.
//
// What makes it a THROW rather than a hang is worth being precise about,
// because it decides whether this harness asserts the right thing.
//
// MSVC's std::mutex is a CriticalSection, and the C++ standard requires
// std::mutex::lock to throw std::system_error when the thread already owns it.
// MSVC implements that check with an inline _Is_owned() that only ever returns
// true for the current thread, so the recursive case does throw on Windows.
// A hang is what you get from a raw SRWLOCK/CriticalSection; this is the
// standard-mandated wrapper on top of one.
//
// So the harness asserts the THROW. If a future STL makes this a hang instead,
// the harness will fail by timing out rather than passing, which is the correct
// direction to fail in: the bug is still there.
//
// Also asserted, because it is the other half of the same defect: the outer
// lock must still be released when the inner one throws. std::lock_guard unwinds
// correctly, so the mutex must not be left owned -- otherwise the next frame
// would deadlock on a lock nobody can ever release, and this would stop being a
// fast crash and become a permanent hang.

#include <cstdio>
#include <mutex>
#include <stdexcept>
#include <string>

namespace {

int failures = 0;

void expect(bool ok, const char* what) {
    std::printf("  %s  %s\n", ok ? "PASS" : "FAIL", what);
    if (!ok) ++failures;
}

std::mutex g_mutex;
bool g_locked = false;

void try_lock() {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_locked = true;
}

// The exact shape of EspModule.cpp:5261 -> refresh_passcode_labels().
void recursive_lock() {
    std::lock_guard<std::mutex> lock(g_mutex);   // the caller's lock, line 5261
    try_lock();                                    // the callee's lock, line 3200
}

} // namespace

int main() {
    std::printf("recursive-lock reproduction (std::system_error on re-lock)\n\n");

    std::printf("[case] re-locking a std::mutex the same thread already holds\n");
    bool threwSystemError = false;
    try {
        recursive_lock();
    } catch (const std::system_error&) {
        threwSystemError = true;
    } catch (...) {
        // A different exception type would mean the diagnosis is wrong and the
        // report should say so rather than quietly pass.
        std::printf("  FAIL  threw something that is not std::system_error\n");
        ++failures;
        std::printf("\n%d check(s) failed\n", failures);
        return 1;
    }
    expect(threwSystemError, "recursive lock throws std::system_error");

    // The lock_guard unwinds on the exception, so the mutex is free again.
    // Prove it by taking it -- if the lock leaked, this would deadlock or throw.
    bool reacquirable = true;
    try {
        std::lock_guard<std::mutex> lock(g_mutex);
    } catch (...) {
        reacquirable = false;
    }
    expect(reacquirable, "the mutex is released by lock_guard during the unwind");

    (void)g_locked;
    std::printf("\n%d check(s) failed\n", failures);
    return failures == 0 ? 0 : 1;
}