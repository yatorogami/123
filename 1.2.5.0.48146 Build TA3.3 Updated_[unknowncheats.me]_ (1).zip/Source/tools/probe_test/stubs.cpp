// Link-time stubs for tools/probe_test.
//
// crash_probe.h now reports through its own pre-opened handle and uses the logger
// only for the install-time banner, so logger::info is the single symbol needed.
// It is defined here rather than linking logger.cpp because logger.cpp pulls in
// module_paths, console colour handling and a per-call ofstream -- none of which
// a probe test wants, and one of which (the shared ofstream) is itself the thing
// the rewrite stopped calling from a fault context.

#include <cstdio>
#include <string>

namespace logger {
    void info(std::string msg) {
        std::printf("  [logger] %s\n", msg.c_str());
    }
}
