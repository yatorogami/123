"""Insert the two new Double Search i18n keys into every lang/*.json.

Same contract as tools/add_night_vision_lang.py, which is the precedent for this
kind of edit: every language file carries every key in ASCII alphabetical order at
2-space indent, so the keys go where they belong and a `git diff` shows two added
lines per file and nothing else. Returns 1 and writes nothing for a language it
has no translation for, rather than inserting an English string into a locale.

Run from the repository root:  python tools/add_double_search_lang.py

Written 2026-10-14 for the Search skill's Elite sub-perk (SkillManager.
SearchDouble), the checkbox that sits beside Lucky Search.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
LANG_DIR = REPO / "TarkovAddons" / "lang"
# The Hungarian override at the repo root carries the same key set.
EXTRA = [REPO / "lang_fixes" / "hu.json"]

KEY_LINE = re.compile(r'^  "([A-Za-z0-9_.]+)":')

# "Double Search", after the game's own field name SkillManager.SearchDouble --
# the same reasoning that named Lucky Search after AttentionEliteLuckySearch.
# These are translations, NOT taken from the client's own locale strings.
TRANSLATIONS = {
    "br": "Busca Dupla",
    "ch": "双重搜索",
    "cs": "Dvojite hledani",
    "en": "Double Search",
    "es": "Busqueda doble",
    "fr": "Recherche double",
    "ge": "Doppelsuche",
    "hu": "Kétszeres keresés",
    "it": "Ricerca doppia",
    "jp": "ダブル検索",
    "kr": "이중 검색",
    "pl": "Podwójne wyszukiwanie",
    "po": "Busca dupla",
    "ro": "Căutare dublă",
    "ru": "Двойной поиск",
    "sk": "Dvojite hladanie",
    "sr": "Двоструко претраживање",
    "tu": "Çift Arama",
    "tw": "雙重搜索",
}

NEW_KEYS = ("double_search_cb", "hk_double_search_act")


def insert_sorted(lines: list[str], key: str, value: str) -> list[str]:
    """Insert `key` in front of the first existing key that sorts after it."""
    for i, line in enumerate(lines):
        m = KEY_LINE.match(line)
        if m and m.group(1) > key:
            break
    else:
        raise RuntimeError(f"no insertion point found for {key}")
    lines.insert(i, f'  "{key}": {json.dumps(value, ensure_ascii=False)},')
    return lines


def add_to(path: Path, failures: list[str]) -> None:
    code = path.stem
    if code not in TRANSLATIONS:
        failures.append(f"{path.name}: no translation for language {code!r}")
        return

    raw = path.read_bytes()
    # Keep whatever line ending and encoding the file already uses.
    newline = "\r\n" if b"\r\n" in raw else "\n"
    lines = raw.decode("utf-8-sig").split(newline)

    present = {m.group(1) for line in lines if (m := KEY_LINE.match(line))}
    if present.intersection(NEW_KEYS):
        failures.append(f"{path.name}: a double-search key is already present")
        return

    try:
        for key in NEW_KEYS:
            lines = insert_sorted(lines, key, TRANSLATIONS[code])
    except RuntimeError as exc:
        failures.append(f"{path.name}: {exc}")
        return

    out = newline.join(lines)
    try:
        data = json.loads(out)
    except json.JSONDecodeError as exc:
        failures.append(f"{path.name}: result does not parse as JSON: {exc}")
        return

    missing = [k for k in NEW_KEYS if k not in data]
    if missing:
        failures.append(f"{path.name}: keys missing after write: {missing}")
        return

    path.write_bytes(out.encode("utf-8"))
    print(f"{path.name}: added {NEW_KEYS[0]} and {NEW_KEYS[1]}")


def main() -> int:
    failures: list[str] = []
    targets = sorted(LANG_DIR.glob("*.json")) + [p for p in EXTRA if p.is_file()]
    for path in targets:
        add_to(path, failures)

    if failures:
        print("\nFAILED:\n" + "\n".join(failures), file=sys.stderr)
        return 1
    print(f"\n{len(targets)} files, {len(targets) * len(NEW_KEYS)} keys added")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
