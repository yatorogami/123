"""Find every instruction in a PE that reads or writes one absolute address.

The crash probe's report gave us a return address whose call target is a
function pointer loaded from a fixed global (`mov rax,[rip+X]; ...; call rax`).
The `.map` cannot name that global: it sits in an unnamed .data blob, and
symbolize.py's nearest-preceding-symbol rule then attributes it to whatever
symbol happens to be lowest, which is an invention rather than an answer.

So this searches the code instead. For every instruction with a RIP-relative
memory operand it computes the absolute target and compares. A WRITE to the
global is the instruction that populates the cache, and the function containing
that instruction is the one worth reading.

Usage: xref_global.py <pe> <rva> [--reads]
"""
import re
import struct
import sys

import capstone

# "qword ptr [rip + 0x4113c4]", "dword ptr [rip - 0x1a]", "[rip + 0x4113c4]"
RIP_OPERAND = re.compile(r"\[rip\s*([+-])\s*(0x[0-9A-Fa-f]+)\]")

# Opcodes that can WRITE their RIP-relative memory operand. Matched against the
# mnemonic alone -- no trailing \s, because capstone's `insn.mnemonic` has none,
# and requiring one silently classified every store as a read. That bug made the
# first run report "0 writes" while the very instruction being looked for sat in
# the read list.
WRITE_RE = re.compile(
    r"^(mov|movq|movd|movaps|movups|movss|movsd|vmov\w*|stos\w*|xchg|cmpxchg|"
    r"add|adc|sub|sbb|and|or|xor|inc|dec|neg|not|shl|shr|sal|sar|rol|ror|"
    r"set\w+|cmpxchg\w*|movzx|movsxd)"
)
# A store whose FIRST operand is memory. `mov qword ptr [rip+X], rax` stores;
# `mov rax, qword ptr [rip+X]` loads. The regex above cannot tell them apart, so
# the operand text does.
def is_store(op_str: str) -> bool:
    body = op_str.split(",", 1)
    return len(body) > 1 and "[" in body[0]


def sections(d):
    e = struct.unpack_from("<I", d, 0x3C)[0]
    coff = e + 4
    nsec = struct.unpack_from("<H", d, coff + 2)[0]
    optsz = struct.unpack_from("<H", d, coff + 16)[0]
    opt = coff + 20
    image_base = struct.unpack_from("<Q", d, opt + 24)[0]
    out = []
    base = opt + optsz
    for i in range(nsec):
        b = base + 40 * i
        name = d[b:b + 8].rstrip(b"\0").decode("ascii", "replace")
        vsize, vaddr, rsize, raddr = struct.unpack_from("<IIII", d, b + 8)
        chars = struct.unpack_from("<I", d, b + 36)[0]
        out.append((name, vaddr, vsize, raddr, rsize, chars))
    return image_base, out


def main():
    path = sys.argv[1]
    target_rva = int(sys.argv[2], 16)
    show_reads = "--reads" in sys.argv

    d = open(path, "rb").read()
    image_base, secs = sections(d)
    want = image_base + target_rva
    print("image base 0x%X   target rva 0x%X  ->  absolute 0x%X" % (image_base, target_rva, want))

    cs = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
    stores, loads = [], []
    total = 0
    for name, vaddr, vsize, raddr, rsize, chars in secs:
        if not chars & 0x20000000:      # IMAGE_SCN_MEM_EXECUTE
            continue
        print("scanning section %-8s rva 0x%X  size 0x%X" % (name, vaddr, vsize))
        code = d[raddr:raddr + max(vsize, rsize)]
        # A linear sweep, NOT cs.disasm() over the whole buffer.
        #
        # cs.disasm() stops at the first byte it cannot decode, and .text is full
        # of embedded data (jump tables, string literals, il2cpp trampolines). The
        # first version of this script used it and reported "0 writes, 0 reads"
        # after covering 84k instructions of a 179 KB section -- a clean-looking
        # negative produced by stopping early, which is the most dangerous kind of
        # wrong. Advance one byte and retry instead.
        pos = 0
        n = len(code)
        while pos < n:
            decoded = next(cs.disasm(code[pos:pos + 16], image_base + vaddr + pos, count=1), None)
            if decoded is None:
                pos += 1
                continue
            ins = decoded
            total += 1
            m = RIP_OPERAND.search(ins.op_str)
            if m:
                disp = int(m.group(2), 16) * (1 if m.group(1) == "+" else -1)
                if ins.address + ins.size + disp == want:
                    rec = (ins.address, ins.mnemonic, ins.op_str)
                    (stores if (WRITE_RE.match(ins.mnemonic) and is_store(ins.op_str))
                     else loads).append(rec)
            pos += ins.size

    print("\ninstructions disassembled: %d" % total)
    print("WRITES to the target: %d" % len(stores))
    for a, mn, ops in stores:
        print("  0x%012X  %-8s %s" % (a, mn, ops))
    if show_reads:
        print("READS of the target: %d" % len(loads))
        for a, mn, ops in loads:
            print("  0x%012X  %-8s %s" % (a, mn, ops))
    return 0


if __name__ == "__main__":
    sys.exit(main())