param(
    [ValidateSet("Prod", "Debug")]
    [string]$Configuration = "Prod",
    [switch]$Rebuild
)

$root = "D:\TarkovAddonsReloaded"
$slot = if ($env:SLOT) { $env:SLOT } else { "opencode" }
$build = "$root\build\$Configuration\x64\$slot"
$vcvars = "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat"

if ($Rebuild) {
    Remove-Item -Recurse -Force $build -ErrorAction SilentlyContinue
    # Reconfigure rather than exiting: -Rebuild deletes the very tree this
    # script then refused to build. First use of a slot is a full build.
    Write-Host "Rebuild: removed $build -- reconfiguring" -ForegroundColor Yellow
    & "$PSScriptRoot\configure_cmake.ps1" -Configuration $Configuration
    if (-not (Test-Path "$build\build.ninja")) {
        Write-Host "Configure failed; no build.ninja at $build" -ForegroundColor Red
        exit 2
    }
}

if (-not (Test-Path "$build\build.ninja")) {
    Write-Host "No build tree at $build -- run tools\configure_cmake.ps1 first" -ForegroundColor Red
    exit 2
}

# vcvars64.bat must run in the same shell as the compiler: it sets INCLUDE/LIB,
# without which cl.exe cannot find windows.h. The configure step ran it in a
# separate cmd process, so this build step starts clean.
$inner = "`"$vcvars`" && ninja"
Push-Location $build
try {
    $raw = cmd /c $inner 2>&1
    $rc = $LASTEXITCODE
} finally {
    Pop-Location
}
$raw | Select-Object -Last 20 | ForEach-Object { Write-Host $_ }

if ($rc -ne 0) {
    throw "build failed: $rc"
}

if ($Configuration -eq "Prod") {
    & "$PSScriptRoot\copy_out.ps1" -Slot $slot
    $dll = "$root\TarkovAddons\out\prod\with_aimbot\TarkovAddons.dll"
} else {
    $dll = "$root\TarkovAddons\x64\Debug\TarkovAddons.dll"
}
if (Test-Path $dll) {
    Write-Host "DLL: $dll" -ForegroundColor Green
} else {
    Write-Host "DLL NOT FOUND at $dll" -ForegroundColor Red
    Get-ChildItem (Split-Path $dll) -ErrorAction SilentlyContinue
}