#!/usr/bin/env python3
"""Audit for call-through-null resolvers.

A `get_method` miss returns nullptr. Anywhere its result is INVOKED rather than
assigned to a local and tested, a method-table miss becomes a call to address
0x0 -- which is exactly how the 2026-10-04 21:24:50 crash killed the process
(`0xC0000005`, operation 8 = execute, faulting address 0x0, in
`unity::camera_fov`).

Line-based grep is not sufficient: a call split across lines by the formatter
(`get_method<...>(\n    "name", 0)(\n    inst)`) is invisible to a per-line
pattern and was missed the first time this audit was run. So this walks the
whole file text.

    usage: python tools/audit_call_through.py [--csv out.csv]
"""
import argparse
import csv
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKIP_DIRS = {"out", "x64", "obj", ".git", "node_modules"}

# `get_method<...>( "name", N )` immediately followed by `(` -- the `(` after
# the resolver's own argument list is what distinguishes an INVOCATION from a
# resolve. Assigned-to-a-local sites do not have it.
CALL = re.compile(
    r'(?<![\w])get_method<[^;{}]{0,240}?>\s*\(\s*"([^"]+)"\s*,\s*-?\d+\s*\)\s*\(',
    re.S,
)
# Same shape but assigned: `auto x = obj.get_method<...>(...);`
RESOLVE_ONLY = re.compile(
    r'(?<![\w])get_method<[^;{}]{0,240}?>\s*\(\s*"([^"]+)"\s*,\s*-?\d+\s*\)\s*(?![\(])',
    re.S,
)
FUNC_HEAD = re.compile(
    r'^([ \t]{0,4})(?:(?:inline|static|constexpr|virtual|explicit)[ \t]+)*'
    r'[A-Za-z_][\w:<>,\*&]*?[ \t\*&]+([A-Za-z_]\w*)[ \t]*\(',
    re.M,
)
# Names that look like definitions to the regex above but are not.
NOT_A_FUNCTION = {
    'if', 'for', 'while', 'switch', 'return', 'else', 'catch', 'do',
    'sizeof', 'alignof', 'decltype', 'static_cast', 'reinterpret_cast',
    'const_cast', 'dynamic_cast', 'and', 'or', 'not',
}


def strip_comments(text):
    """Blank out comments, preserving offsets and newlines.

    String literals are deliberately LEFT ALONE. The pattern being searched for
    is itself quoted -- `get_method<...>("name", 0)(` -- so masking literal
    contents (a natural-looking refinement) makes every match invisible and the
    tool reports 0. That is not hypothetical: it is what the first two runs of
    this script did, and the "81" that went into the write-up came from a
    line-based grep with the same blind spot for split calls.
    """
    out = list(text)
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c == '/' and i + 1 < n and text[i + 1] == '/':
            while i < n and text[i] != '\n':
                out[i] = ' '
                i += 1
        elif c == '/' and i + 1 < n and text[i + 1] == '*':
            while i < n and not (text[i] == '*' and i + 1 < n and text[i + 1] == '/'):
                if text[i] != '\n':
                    out[i] = ' '
                i += 1
            for _ in range(2):
                if i < n:
                    out[i] = ' '
                    i += 1
        else:
            i += 1
    return ''.join(out)


def line_of(text, idx):
    return text.count('\n', 0, idx) + 1


def enclosing_fn(clean, idx):
    """Last function-definition-looking line before `idx`.

    Approximate by design: it is a label for triage, not a parser. Two guards
    keep it honest -- a keyword blacklist (`if`/`for`/`while` read as
    definitions otherwise) and an indent ceiling, since real definitions sit at
    namespace scope while control flow is nested deeper.
    """
    best = '?'
    for m in FUNC_HEAD.finditer(clean, 0, idx):
        name = m.group(2)
        if name in NOT_A_FUNCTION or len(m.group(1)) > 4:
            continue
        line_start = m.start()
        line_end = clean.find('\n', m.start())
        line = clean[line_start:line_end if line_end != -1 else len(clean)]
        if '=' in line.split('(')[0]:
            continue
        best = name
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--csv')
    args = ap.parse_args()

    rows, resolved_only = [], 0
    for dirpath, dirnames, filenames in os.walk(os.path.join(ROOT, 'TarkovAddons')):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            if not fn.endswith(('.h', '.cpp')):
                continue
            path = os.path.join(dirpath, fn)
            try:
                raw = open(path, 'r', encoding='utf-8', errors='replace').read()
            except OSError:
                continue
            if 'get_method' not in raw:
                continue
            clean = strip_comments(raw)
            for m in CALL.finditer(clean):
                rows.append({
                    'file': os.path.relpath(path, ROOT).replace('\\', '/'),
                    'line': line_of(raw, m.start()),
                    'method': m.group(1),
                    'function': enclosing_fn(clean, m.start()),
                })
            resolved_only += len(RESOLVE_ONLY.findall(clean))

    rows.sort(key=lambda r: (r['file'], r['line']))

    by_file = {}
    for r in rows:
        by_file.setdefault(r['file'], []).append(r)

    print(f'UNGUARDED (resolver result invoked inline): {len(rows)}')
    print(f'resolve-only (assigned to a local, then must be tested): {resolved_only}')
    print()
    for f in sorted(by_file, key=lambda k: -len(by_file[k])):
        print(f'### {f}  ({len(by_file[f])})')
        for r in by_file[f]:
            print(f"  {r['line']:>6}  {r['method']:<32} in {r['function']}")
        print()

    if args.csv:
        with open(args.csv, 'w', newline='', encoding='utf-8') as fh:
            w = csv.DictWriter(fh, fieldnames=['file', 'line', 'method', 'function'])
            w.writeheader()
            w.writerows(rows)
        print(f'csv -> {args.csv}')
    return 0


if __name__ == '__main__':
    sys.exit(main())