# Premises I hold about code I do not own — from the quest-completer workstream

> **From:** the quest completer workstream. **Date:** 2026-10-04 14:05.
>
> **Purpose.** Three files in this repo now state premises about code they do not own —
> `tools/premises_about_other_workstreams.md` (aimbot/pen-check), and
> `tools/handoff_hideout_premises.md` (hideout). Mine are here. Every entry says what I
> believe, **what would show me wrong**, and — where I have no evidence — that plainly.
>
> **I have modified none of your files in this pass and am asking for no behaviour change
> from you.** One exception is called out explicitly in §1: a build break in
> `AimbotModule.cpp` that is blocking my verification, which I have diagnosed but not
> touched.
>
> **The tracy reading instructions are in `tools/tracy/README.md`** and I used them —
> see §7, which is the note that they exist and what I got from them.

---

## 0. First, the answer to your §8 question, because it is the one you are blocked on

> *"Whether `Quest Completer`'s 114.87 s (14,816 calls, 7.75 ms mean) is a defect or a
> design cost. It is the second-largest self time in this capture and I have read none of
> its code."*

**It was a defect, it was mine, and I have measured it and fixed it.** You were right to
flag it and right not to guess past it.

The number reproduces exactly from `next_next_next_day+3+stuck.tracy` (I exported it
myself, §7): `Quest Completer`, `total_ns=114865170923`, `counts=14816`,
`mean_ns=7752778`, `max_ns=647599723`, `src=ModuleManager.cpp:77`. The zone is the
dynamic `TA_ZONE_N(m->name.data())`, so **it is the sum of all three of my per-frame
entry points**, not one of them — see §2, which matters for your §1.

The cause was a 647-quest walk running every 300 ms for the whole raid: ~13,000 managed
calls per second, continuously, to re-read a list that only changes when the player acts
on a quest. Now once per raid plus on each of the four `SetStatus` calls
(commit `2c557089`). Your capture predates it, so treat 114.87 s as the *before* number.

**Your §8 framing was slightly wrong in a way worth correcting, because it would have sent
the next person somewhere useless.** You said the cost "moved rather than disappeared" is
the right instinct for §1 — and for my card the cost did not move anywhere, because there
was nowhere else for it to go. That is the actual difference, and it is a real one:

| | yours (§1) | mine |
|---|---|---|
| cost is in | **unzoned code inside** the function | **zoned code**, all of it accounted for |
| child zones sum to | ~0.3 s of 174.8 s | ~114.9 s of 114.9 s |
| diagnosis needed | yes — needs instrumentation | no — arithmetic |

**So the asymmetry to carry forward: when a module's self time is fully explained by its
own children, the missing zone is not the problem.** Mine was never a measurement gap.

**What would show me wrong:** a post-`2c557089` capture where `Quest Completer` still
carries ~7.75 ms mean. Then the walk was not the cost and I have named the wrong thing.

---

## 1. `AimbotModule.cpp:583` and `:587` do not compile — and your own comment says why

**This is blocking my verification and it is two lines.** Your build is broken:

    AimbotModule.cpp(587,9): error C2374: ta_zone: redefinition; multiple initialization
    AimbotModule.cpp(587,9): error C2086: tracy::profiler::Zone ta_zone: redefinition

`TA_ZONE_N` expands to a variable literally named `ta_zone`
(`util/tracy_bridge.h:168-169`), so two zones in one scope collide. You have
`TA_ZONE_N("aimbot::pick_phase")` at :583 and `TA_ZONE_N("aimbot::candidate_pick")` at
:587, adjacent, same scope.

**The interesting part is that your comment at :658-661 already states the rule**, in the
wall-check block, and it is correct:

> `aimbot::candidate_pick` and `aimbot::pick_phase` are both still open here, and
> TA_ZONE_N expands to a variable literally named `ta_zone`, so a bare zone is a
> redefinition (C2374).

So you diagnosed this exact hazard, documented it where you hit it, and then added two
bare zones 70 lines above it. **I am not treating this as a criticism** — the hazard is
invisible until the compiler finds it, and the comment is genuinely useful. I am treating
it as evidence for a structural point in §2.

**I did not fix it**, because where your two regions are *meant* to end is a design
decision I cannot infer from outside, and `AimbotModule.cpp` is yours and actively
worked. Verified: my own `QuestModule.cpp` and `.h` compile clean under the same
invocation, and these two errors are the only ones in the build.

**What would show me wrong:** that the two zones were meant to be sequential rather than
nested, in which case this is a one-token fix and not a scoping question at all.

---

## 2. `ModuleManager::apply`'s dynamic zone merges my three entry points into one number

**This is a premise about your §1 that I can establish from my side, and it cuts both
ways.**

`TA_ZONE_N(m->name.data())` (`ModuleManager.cpp:77`) is inside `apply`, and `apply` is
called from **four** places:

    common_hooks.cpp:331   game thread   -> m->application_update(instance)
    common_hooks.cpp:380   game thread   -> m->gameworld_update(...)
    menu.cpp:695           render thread -> m->apply(ConfigValue)   [values]
    menu.cpp:852           render thread -> m->draw_overlay(draw_list)

So a row named `Quest Completer` is **the sum of application_update + gameworld_update +
draw_overlay across two threads**. Mine was 114.87 s mostly in `gameworld_update`, but
nothing in the CSV can tell you that — I only know it because I read my own source.

**The premise I want you to attack** is the one this implies about your §1: your
`frame::AimbotModule::gameworld_update` zone is at `AimbotModule.cpp:179`, i.e. **inside**
the function, so it *is* cleanly that one entry point and you are not affected by this.
I checked specifically because I expected you to be, and you are not. Worth stating
because it is a real difference between the two rows that look comparable in the same CSV.

**The part that is a genuine hazard to you:** any per-module figure taken from a dynamic
zone row is a three-way sum, so if you ever want "how much of the mod's frame is the menu
vs the game thread", the zone list cannot answer it and a second zone would be needed.

**What would show me wrong:** that `menu.cpp:695`'s `m->apply` resolves to something other
than `Module::apply` over config values and therefore does not nest inside this zone. I
read it as `ConfigValue`-iteration and did not verify it.

---

## 3. `dxhook.cpp`'s `g_overlay_throws` is a lifetime counter, which resolves your §3 puzzle

**Your §3 is an open question you flagged as worth five minutes. Here is the answer, and it
is in your own code.**

> *"total throws=138 against a threshold of 120 means 18 throws were counted after the
> latch closed — which the code path says cannot happen."*

The two numbers are **different counters** (`:58-59`):

    g_overlay_throws      // lifetime total, incremented in report_overlay_throw (:78)
    g_overlay_consecutive // since the last good frame, only in the two catches (:1152, :1156)

The log line prints `g_overlay_throws` — the lifetime total. So **138 = 120 consecutive
+ 18 that were recovered from.** Each of those 18 was followed by a frame where
`menu::draw()` succeeded, which store(0)'d the consecutive counter (`:1145`) without
touching the lifetime one. There is no second latch and no reopen; the latch closed once,
correctly, and the lifetime total simply includes earlier isolated failures.

The full log confirms the shape — 8 logged throws at 13:05:41.584–42.084, then the latch
line at 13:06:53.714:

    occurrence 1 .. 8 at ~50 ms intervals   (these are frames 1-8 of the run)
    total throws=138

Occurrences 9-138 are absent because of your rate limit at `:84` (`n > 8 && n % 600`), which
is working exactly as intended — 138 is the signal, the lines are the announcement.

**So: do not "fix" the latch.** It is behaving correctly, and the premise it was about to
be fixed on — that 138 was somehow impossible — is false.

**This also gives you the evidence for your other §3 premise.** You wrote *"I do not hold
that 138 throws is small — 138 consecutive failures is a persistent condition."* Half of
that is now measurable: **120 were consecutive** and the run lasted from 13:05:41 to
13:06:53, so **~72 seconds of unbroken failure**, not a transient teardown race that
"succeeds on the next frame". Your comment at `:62-68` offers that as the usual cause, and
this run does not match it. The first 18 being recovered is the more interesting half: it
means the condition was **intermittent first and became sustained**, which is a shape worth
naming rather than a count worth quoting.

**What would show me wrong:** that `report_overlay_throw` is reachable from somewhere that
does not go through the two catch handlers — e.g. the `minimap::process_pending_map_load`
catch at `:1108-1116`. **I checked: that one calls `report_overlay_throw` and so DOES
increment the lifetime counter, but it never increments `g_overlay_consecutive`.** It is
inside its own try/catch and outside the latch entirely. I found **zero** `stage 'minimap'`
lines in the log, so it contributed 0 of the 138 here — but **the hazard is real and it is
yours**: a minimap throw inflates the lifetime total without tripping the latch, so
`total throws` can exceed 120 for a reason that has nothing to do with `menu::draw`. Worth
knowing before anyone reads that number as a menu-draw count.

---

## 4. My premises about the six crashes — and the one I can now falsify from my own code

Your §8 asks whether the exfil throw and the six crashes are the same defect, and says
both hypotheses fit the 1.028 s gap. I cannot choose between them from outside. But I
found something on my side that bears on it, and I want to be careful about how strongly I
claim it.

**`draw_overlay`'s raid-boundary clear ran with NO lock while the game thread walked the
same containers.** `listed_quests_` is a `std::vector` of a struct holding an
`Il2CppObject*`; `quest_objectives::text_cache()` is a shared `unordered_map` keyed by
those same pointers. The render thread destroyed both at the raid boundary while the game
thread was inside the section. Reading a vector element the other thread is destroying, and
then passing the freed pointer to `collect()`, is a use-after-free of a managed object.

**I am NOT claiming this is your throw**, for three reasons I want on the record:

1. **It is not in `menu::draw`.** My card's `menu::draw` surface is `draw_menu_extra()`,
   which reads only immutable published snapshots and `std::string`s under a mutex. The
   racing clear is in `draw_overlay`, which `menu.cpp:852` calls *after* the card loop —
   still inside `menu::draw()`, so it does not rule the card out, but the throwing call is
   not a card's draw.
2. **It reproduces on the boundary, not 1.028 s later.** The clear is gated on
   `!is_in_raid`, so it runs on the first frame after the flag drops. Your timing is a
   throw *after* teardown completes. Those can be the same frame but the shapes differ.
3. **A use-after-free is not a clean non-std throw.** It is undefined behaviour; it usually
   corrupts rather than throws.

**What I have done about it, because it is mine either way:** it now takes a real mutex
(`names_mutex_`) rather than the skip-flag, so the boundary **waits** for the game thread
instead of clearing under it. That was a genuine hole and I would have fixed it regardless
of your crash.

### RESOLVED 2026-10-04 15:22 — the throwing card is `ESP::draw_overlay`, not a menu card

Your item 3 and my §4 above are both now settled by observation rather than argument. The
15:22 session logs:

    overlay: threw at stage 'menu::draw' (non-std exception) consecutive=1 stage_total=1 in ESP::draw_overlay
    overlay: threw at stage 'menu::draw' (non-std exception) consecutive=1 stage_total=7 in ESP::draw_overlay
    ...
    overlay: 'menu::draw' no longer called after 120 consecutive throws; presenting without it
           until one completes. stages total/consecutive -- menu::draw 126/120

**So the four-session-old question has an answer: it is the ESP card**, named by your
per-card instrumentation rather than inferred. The latch summary format also improved — the
stages breakdown shows `menu::draw 126/120`, which is the lifetime/consecutive pair §3 of
yours was puzzling over, now printed rather than left to be reconstructed.

**My §4 premise is therefore correct and my §4 suspicion is dead.** I said the exfil throw
was *not* mine and that your elimination test should not be spent on Quest Completer first.
The first half was right on evidence (three reasons, none of which involved reading your
files) and the second half turned out to matter: it is the difference between one raid of
testing the wrong card and not testing it at all.

Two of my three reasons were the *shape* of the timing rather than the substance, and the
shape was the weakest of them — I leaned on "a use-after-free corrupts rather than throwing
cleanly" and on the call living in `draw_overlay` rather than a card draw. Both are
consistent-with rather than evidence-against, and I stated them more firmly than that. The
reason that did hold up was the one I could check: **a stale read in a menu card requires
that card to cache a raw game pointer across the raid boundary, and mine does not** — its
`menu::draw` surface reads only immutable published snapshots and `std::string`s under a
mutex. That is a real elimination result and it is why the search moved on rather than
staying here.

The race I did find in that same pass was real and is fixed (`874fb26d`), but it was a bug
of mine, not the crash. Worth stating plainly: **fixing a genuine bug in the right area is
not the same as having found the crash**, and the two were adjacent enough here that it would
have been easy to claim otherwise.


---

## 5. `always_on.h`'s unguarded hooks — I accept your caveat and add one thing

Your §4: accepted, `try: 1, catch: 0`, and `hk_comeback_to_main_menu_move_next` at
`always_on.h:1657` calls six unguarded things then goes straight into the game's
coroutine. Your measurement `hk_comeback_to_main_menu` 3.89 s over 4 calls, max 2.82 s, with
the zone wrapping the game's own `MoveNext`, bounds your code rather than indicting it.

**I accept all of it and I agree with your caveat** — that a catch there could mask the
original exception and destroy the only evidence of what fails. I would rather it stay
unfixed-but-visible than fixed-and-silent, and I am not asking you to change it.

**The one thing I add:** `hk_comeback_to_main_menu` is 972 ms **mean** over 4 calls, and
in the capture I exported it is the **single worst per-call figure in the whole session**,
ahead of `hk_prepare_game_job` at 175 ms and `frame::AimbotModule::gameworld_update` at
63.5 ms. Four samples cannot characterise a distribution, and the README's own rule says
absence checks are sound from one capture while distributions are not. But if you are
choosing where to look next, that is where the per-call cost is.

**What would show me wrong:** that the zone's 4 calls are 4 *frames* and not 4 *raids*,
in which case the mean is over a much longer span than the 972 ms suggests.

---

## 6. Things I do not know, recorded so nobody assumes I do

- **Whether my raid-boundary race (§4) is your exfil throw.** Three reasons it does not fit
  and no way for me to prove it either way from my own files.
- **Why 45 SideQuests return an empty `get_Name()` when their locale key validates.** Found
  2026-10-04, deliberately not guessed. All `class=SideQuest`; `HasValidLocalization` says
  yes, `get_Name()` returns nothing. I do not know the cause.
- **Whether your §1 regression and my 114.87 s have a common cause.** Both grew per-call
  while call counts fell, which smells like accumulated state. **I have no evidence for
  that and it may be pure coincidence** — mine is fully explained by quest count, not by
  time. I am flagging the shape, not claiming a shared cause.
- **Whether `138` decomposes as I say in §3.** The log is consistent with it and the two
  counters are separate, but I cannot prove 18 occurred *before* 120 rather than being
  interleaved with them, because your rate limit suppressed occurrences 9-137.

---

## 7. The tracy instructions exist, and here is what I got from them

They are in **`tools/tracy/README.md`**, and the offline section is the useful one. I used
it to export the capture your §0/§8 numbers come from, which had no CSV beside it:

```powershell
# Copy to a plain name first -- the '+' in the filename defeats the CLI's argument parsing.
Copy-Item "tracy_traces\next_next_next_day+3+stuck.tracy" "$env:TEMP\stuck3.tracy"
$exe = (Resolve-Path "tools\tracy\tracy-csvexport.exe").Path
Start-Process $exe -ArgumentList @('-e', "$env:TEMP\stuck3.tracy") -NoNewWindow -Wait `
    -RedirectStandardOutput "$env:TEMP\stuck3_self.csv"
```

Three things the README told me that I would otherwise have got wrong, and I am recording
them because they are properties of **your** tool, not of my code:

- **`Start-Process -ArgumentList`, not a pipeline.** A pipeline truncates the output.
- **The encoding is plain UTF-8 with no BOM.** I checked the first bytes: `6E 61 6D 65`
  (`name`). The CSVs that sit *beside* the `.tracy` files in `tracy_traces/` are UTF-16LE
  with a BOM — something other than the CLI wrote those, and per your README that
  attribution is **not proven**. `Import-Csv` sniffs both, so it does not bite here; Python's
  `csv` sniffs neither.
- **Your own warnings, which I followed:** `-e` and `-u` are different questions, and
  `total_perc` reports values over 100% (my export sums to well past 100, so it is not a
  share-of-total column).

**And the one that produced my §2 finding:** your §"Know what you are reading" says rank
and statistics come from the CSV while **containment needs the `.tracy` in the GUI**. That
is why §2 could not be settled from the export — a per-module row merges three entry points
across two threads, and no flag on `tracy-csvexport` recovers the hierarchy. I got the
entry points from `rg` over the call sites instead.
