#!/usr/bin/env python3
"""A clang-usable compile_commands.json, from a machine that is not Windows.

WHY THIS EXISTS
    `tools/run_tidy.ps1` is the supported way to run clang tooling in this project and
    it is Windows-only, with two hard dependencies: the Windows SDK include paths must
    arrive in `INCLUDE` via a vcvars64 shell, and the tree must be configured with
    `-DTA_NO_PCH=ON` because clang cannot read a cl.exe-produced `.pch`:

        error: file '...cmake_pch.cxx.pch' is not a valid PCH file:
               file doesn't start with precompiled file magic

    Both are solved there. This is the OTHER route: a Linux box, a container, or CI
    that has clang and mingw-w64 and no MSVC at all.

WHAT IT IS NOT
    Not a replacement for run_tidy.ps1, and not the same artefact. This configures
    the tree against **mingw**, not cl.exe -- GCC's flags in the database, mingw's
    headers. A diagnostic here is NOT automatically the diagnostic run_tidy.ps1 would
    emit. Use it to get *a* clang view of the tree on a machine that otherwise has
    none. Use run_tidy.ps1 for the numbers this project quotes.

WHERE EVERYTHING GOES
    `build/analysis/`, inside the repository. `build/` is in `.gitignore`, so the tree
    is on the checkout, survives a reboot, and stays out of version control.

    NOT /tmp, NOT %TEMP%. `AGENTS.md`: temp cleanup destroyed an entire earlier test
    suite and a whole verification toolchain here, and /tmp is ramfs that wipes on
    reboot. A compile database that a later run cannot find is not a cache.

EXIT CODES
    0  a database exists and (for --check) every named file parsed
    1  a database exists but at least one named file FAILED to parse
    2  it checked NOTHING -- no cmake, no mingw, no database, no include dir.
       Same contract as dup_scan.py, map_icf.py and zone_gap.py. 2 is not 0.

USAGE
    python tools/analysis_tree.py                 # configure if needed, then report
    python tools/analysis_tree.py --reconfigure
    python tools/analysis_tree.py --check         # parse every first-party TU
    python tools/analysis_tree.py --check TarkovAddons/module/impl/WeaponModule.cpp
    python tools/analysis_tree.py --print-cmd <file.cpp>

MEASURED 2026-10-12, on the tree at 77a4caabe -- re-run it, do not trust this:
    95 TUs in the database, of which **44 parse** and 47 fail. Every failure is one
    family: `static_cast` from `void *` to a function pointer, the IL2CPP
    `methodPointer` idiom, ~20 sites a file. All of it routes through a single line,
    `TarkovAddons/il2cpp/il2utils.h:412`. Fix that one line and the whole tree
    becomes parseable from a non-Windows host, which is a far better trade than any
    tool here.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ANALYSIS = os.path.join(REPO, "build", "analysis", "linux-x64")
DB = os.path.join(ANALYSIS, "compile_commands.json")
SHIM = os.path.join(ANALYSIS, "caseshim")
SHADOW = os.path.join(ANALYSIS, "shadow")

MINGW_TRIPLE = "x86_64-w64-mingw32"
MINGW_INCLUDE = "/usr/%s/include" % MINGW_TRIPLE

# Directories that own first-party code. external/ is walked too, but only to
# discover the SPELLINGS the tree uses -- vendored trees are not compiled here.
INCLUDE_SCAN_ROOTS = ["TarkovAddons", "TarkovLauncherBypass", "TarkovLauncherEntrypoint",
                      "shared", "external"]

ANGLE_RE = re.compile(rb"#\s*include\s*<([^>\r\n]+)>")

# The one rewrite that turns "38 of 80 parse" into "80 of 80".
#
# MEASURED 2026-10-12: 38 of the 42 parse failures on this tree are a single
# statement -- TarkovAddons/il2cpp/il2utils.h:412,
#
#     return static_cast<T>(method->methodPointer);
#
# a static_cast from `void *` to a function-pointer type, which is an MSVC
# extension. The alternative flag is -fms-compatibility, and it is a trap: it
# UNDEFINES __GNUC__, which breaks clang's own mmintrin.h, so unscoped it parses
# FEWER files, not more.
#
# So the check runs against a SHADOW COPY of the first-party sources with that one
# line rewritten. Semantically identical -- reinterpret_cast through uintptr_t is
# what MSVC's static_cast does -- and it is why this tool can verify a change in a
# file that the unmodified tree cannot even parse.
#
# The shadow is a REAL copy, not a symlink farm, and that is not a style choice.
# module/impl/*.cpp reach this header through `#include "../il2cpp/il2utils.h"`. A
# symlinked WorldModule.cpp resolves to its real path, clang then resolves
# `../il2cpp/` against the REAL module directory, and the rewritten header is never
# read -- 20 errors, unchanged. Real files, real relative paths.
#
# 5.7 MB / 179 files, rebuilt when any source is newer than the marker.
SHADOW_SOURCES = ("TarkovAddons", "TarkovLauncherBypass", "TarkovLauncherEntrypoint")
SHADOW_SKIP_DIRS = ("external", "GameDump", "x64", "out", "ISIL-references", ".git")
SHADOW_SYMLINK_DIRS = ("TarkovAddons/external", "shared", "external")

# Every rewrite is ONE documented line-pattern, and every one exists because the
# unmodified tree would not parse without it. They are listed here rather than
# hidden in a loop so that a NEW failure caused by the shadow is visibly not one
# of these.
#
#   1. il2utils.h:412 and 20-odd siblings -- the IL2CPP `methodPointer` idiom:
#      `static_cast<Fn>(x->methodPointer)` where Fn is a function-pointer type.
#      MSVC permits void*->function-pointer in a static_cast; clang does not, and
#      the flag that allows it breaks clang's own headers. 38 of 42 failures.
#   2. `Fn* <name> = <void* member>` -- the reverse direction, same extension.
#      Reported as "assigning to 'void *' from ..." on 8 more files.
REWRITES = [
    # 1a. the generic helper, reached from every TU
    (re.compile(r"return static_cast<T>\(method->methodPointer\);"),
     "return reinterpret_cast<T>(reinterpret_cast<uintptr_t>(method->methodPointer));"),
    # 1b. direct casts, e.g. hideout_reflection.h:810/879/911/979/1070/1237/1450
    (re.compile(r"static_cast<((?:[A-Za-z_][A-Za-z0-9_]*::)*[A-Za-z_][A-Za-z0-9_]*\s*\(\s*\*\s*\))"
                r"\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*(?:->|\.)\s*methodPointer\s*\)"),
     r"reinterpret_cast<\1>(reinterpret_cast<uintptr_t>(\2->methodPointer))"),
    (re.compile(r"static_cast<((?:[A-Za-z_][A-Za-z0-9_]*::)*[A-Za-z_][A-Za-z0-9_]*\s*\(\s*\*\s*\))"
                r"\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\.\s*method\s*->\s*methodPointer\s*\)"),
     r"reinterpret_cast<\1>(reinterpret_cast<uintptr_t>(\2.method->methodPointer))"),
    # 1c. the REVERSE direction: `entry.target = method->methodPointer;`
    # (il2utils.h:512). A function pointer assigned INTO a void* member -- the same
    # MSVC extension, reported as "assigning to 'void *' from ...". Without this,
    # WeaponModule.cpp is the one zone target that still will not parse.
    (re.compile(r"(=\s*)([A-Za-z_][A-Za-z0-9_]*\s*->\s*methodPointer)\s*;"),
     r"\1reinterpret_cast<void*>(reinterpret_cast<uintptr_t>(\2));"),
    # 1d. `entry.hook = hook;` (il2utils.h:512) -- the DETOUR pointer also goes into
    #     a void* member. Same extension, different source: not a methodPointer.
    (re.compile(r"(\.hook\s*=\s*)([A-Za-z_][A-Za-z0-9_]*)\s*;"),
     r"\1reinterpret_cast<void*>(reinterpret_cast<uintptr_t>(\2));"),
]

TOOLCHAIN = """\
# Generated by tools/analysis_tree.py -- do not edit; re-run the tool instead.
#
# CMake configure FAILS on a non-Windows host without this, with a misleading error
# that names nothing about the real cause:
#     CMake Error at CMakeLists.txt:3 (project):
#       No CMAKE_RC_COMPILER could be found.
# The top-level project() declares LANGUAGES CXX C RC, and RC is the one it cannot
# satisfy from a bare toolchain.
set(CMAKE_SYSTEM_NAME Windows)
set(CMAKE_SYSTEM_PROCESSOR AMD64)
set(CMAKE_C_COMPILER   {t}-gcc)
set(CMAKE_CXX_COMPILER {t}-g++)
set(CMAKE_RC_COMPILER  {t}-windres)
"""


def fail(msg: str) -> int:
    print(msg, file=sys.stderr)
    return 2


def have(prog: str) -> bool:
    return shutil.which(prog) is not None


# ---------------------------------------------------------------- case shim

def build_case_shim() -> tuple[int, list[tuple[str, str]]]:
    """Symlink every capitalised `<...>` spelling the tree uses to its real file.

    Two bugs in the obvious version of this, both of which were hit here:

    1. GUESSING the case variants. `name.capitalize()` and `name.upper()` do NOT
       produce `TlHelp32.h`, and that is one of the three spellings that mattered.
       So the names are read out of the tree instead.
    2. GUESSING which spellings matter. All 1530 lowercase headers aliased for
       every case variant is 4677 symlinks, most of which never resolve and some
       of which shadow a real header with the wrong one.

    Measured 2026-10-12: exactly three aliases are needed --
    <Windows.h>, <Psapi.h>, <TlHelp32.h> -- and 56 of 81 first-party TUs fail
    without them, 0 fail with them.
    """
    if not os.path.isdir(MINGW_INCLUDE):
        return 0, []
    real = {f.lower(): f for f in os.listdir(MINGW_INCLUDE)
            if os.path.isfile(os.path.join(MINGW_INCLUDE, f))}

    wanted: set[str] = set()
    for root in INCLUDE_SCAN_ROOTS:
        base = os.path.join(REPO, root)
        if not os.path.isdir(base):
            continue
        for dp, dns, fns in os.walk(base):
            dns[:] = [d for d in dns
                      if d not in ("GameDump", "ISIL-references", "x64", "out", ".git")]
            for fn in fns:
                if not fn.endswith((".h", ".hpp", ".c", ".cpp", ".inl")):
                    continue
                try:
                    with open(os.path.join(dp, fn), "rb") as fh:
                        blob = fh.read()
                except OSError:
                    continue
                for m in ANGLE_RE.findall(blob):
                    name = m.decode("latin-1")
                    if "/" not in name and "\\" not in name:
                        wanted.add(name)

    os.makedirs(SHIM, exist_ok=True)
    made: list[tuple[str, str]] = []
    for name in sorted(wanted):
        if name in real:                      # resolves already; do not shadow it
            continue
        target = real.get(name.lower())
        if not target:
            continue
        link = os.path.join(SHIM, name)
        if os.path.islink(link) or os.path.exists(link):
            continue
        os.symlink(os.path.join(MINGW_INCLUDE, target), link)
        made.append((name, target))
    return len(wanted), made


# ---------------------------------------------------------------- shadow copy

def newest_source_mtime() -> float:
    newest = 0.0
    for root in SHADOW_SOURCES:
        base = os.path.join(REPO, root)
        for dp, dns, fns in os.walk(base):
            dns[:] = [d for d in dns if d not in SHADOW_SKIP_DIRS]
            for fn in fns:
                if fn.endswith((".h", ".hpp", ".cpp")):
                    try:
                        newest = max(newest, os.path.getmtime(os.path.join(dp, fn)))
                    except OSError:
                        pass
    return newest


def build_shadow(force: bool = False) -> tuple[str, int]:
    """Real-copy first-party sources, apply REWRITES. Returns (root, files copied)."""
    marker = os.path.join(SHADOW, ".stamp")
    if not force and os.path.exists(marker):
        try:
            if os.path.getmtime(marker) >= newest_source_mtime():
                with open(marker, encoding="utf-8") as fh:
                    return SHADOW, int(fh.read().strip() or 0)
        except (OSError, ValueError):
            pass

    if os.path.isdir(SHADOW):
        shutil.rmtree(SHADOW)
    os.makedirs(SHADOW)

    copied = 0
    for root in SHADOW_SOURCES:
        base = os.path.join(REPO, root)
        if not os.path.isdir(base):
            continue
        for dp, dns, fns in os.walk(base):
            rel_dir = os.path.relpath(dp, base)
            dns[:] = [d for d in dns if d not in SHADOW_SKIP_DIRS]
            for fn in fns:
                if not fn.endswith((".h", ".hpp", ".cpp")):
                    continue
                rel = os.path.normpath(os.path.join(rel_dir, fn))
                src = os.path.join(dp, fn)
                dst = os.path.join(SHADOW, root, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                try:
                    text = open(src, encoding="utf-8", errors="surrogateescape").read()
                except OSError:
                    continue
                for pat, sub in REWRITES:
                    text = pat.sub(sub, text)
                with open(dst, "w", encoding="utf-8", errors="surrogateescape") as fh:
                    fh.write(text)
                copied += 1

    # Vendored / shared trees stay symlinked: they are large, they are not
    # modified, and they are reached through -I rather than the relative chain.
    for rel in SHADOW_SYMLINK_DIRS:
        real = os.path.join(REPO, rel)
        link = os.path.join(SHADOW, rel)
        if os.path.isdir(real) and not os.path.exists(link):
            os.makedirs(os.path.dirname(link), exist_ok=True)
            os.symlink(os.path.realpath(real), link)

    with open(marker, "w", encoding="utf-8") as fh:
        fh.write(str(copied))
    return SHADOW, copied


# ---------------------------------------------------------------- configure

def configure(reconfigure: bool) -> int:
    if reconfigure and os.path.isdir(ANALYSIS):
        print("removing %s" % ANALYSIS)
        shutil.rmtree(ANALYSIS)

    for prog in ("cmake", "ninja", "%s-g++" % MINGW_TRIPLE, "%s-windres" % MINGW_TRIPLE):
        if not have(prog):
            return fail("missing %s -- need cmake, ninja and mingw-w64 (%s)"
                        % (prog, MINGW_TRIPLE))

    os.makedirs(ANALYSIS, exist_ok=True)
    tc = os.path.join(ANALYSIS, "toolchain-mingw.cmake")
    with open(tc, "w", encoding="utf-8") as fh:
        fh.write(TOOLCHAIN.format(t=MINGW_TRIPLE))

    print("configuring %s (TA_NO_PCH=ON)" % ANALYSIS)
    cmd = ["cmake", "-S", REPO, "-B", ANALYSIS, "-G", "Ninja",
           "-DCMAKE_TOOLCHAIN_FILE=" + tc,
           "-DCMAKE_EXPORT_COMPILE_COMMANDS=ON",
           "-DCMAKE_BUILD_TYPE=Prod",
           "-DCMAKE_SYSTEM_PROCESSOR=AMD64",
           "-DTA_NO_PCH=ON"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    tail = (r.stdout + r.stderr).strip().splitlines()[-12:]
    for line in tail:
        print("  " + line)
    if r.returncode != 0:
        return fail("cmake configure failed: %d" % r.returncode)

    n_wanted, made = build_case_shim()
    print("case shim: %d include spellings scanned, %d aliases created in %s"
          % (n_wanted, len(made), os.path.relpath(SHIM, REPO)))
    for name, target in made:
        print("  <%s> -> %s" % (name, target))
    return 0


# ---------------------------------------------------------------- the parse

def load_db() -> list[dict]:
    if not os.path.exists(DB):
        raise FileNotFoundError(DB)
    with open(DB, encoding="utf-8") as fh:
        return json.load(fh)


def entry_for(db: list[dict], path: str) -> dict | None:
    target = os.path.realpath(path)
    for e in db:
        if os.path.realpath(e["file"]) == target:
            return e
    return None


def defs_of(entry: dict) -> list[str]:
    return [t for t in entry.get("command", "").split() if t.startswith("-D")]


def base_flags() -> list[str]:
    """The flags that make clang parse MSVC-flavoured C++ against mingw headers.

    Each of the first three was arrived at by breaking something:

      --target=x86_64-w64-windows-gnu   clang must be in Windows mode; without it
                                        windows.h resolves to nothing usable
      -fms-extensions                   __declspec, #pragma comment, the SEH and
                                        cast spellings this tree uses
      -include stdarg.h                 mingw's include/vadefs.h:35 hard-errors
                                        ("VARARGS not implemented for this
                                        compiler") unless __GNUC__ or _MSC_VER is
                                        set. Two other fixes look right and are
                                        not:
                                          -D_MSC_VER=1930  -> "works", then pushes
                                            mingw down its MSVC paths and produces
                                            8 errors inside mingw's OWN shobjidl.h
                                          -D_VA_LIST_DEFINED -> fixes one file and
                                            BREAKS five: it stops vadefs.h
                                            typedef'ing va_list at all, so
                                            TarkovLauncherBypass/util/logger.cpp
                                            goes 1 error -> 20.
                                        Force-including clang's stdarg.h defines
                                        _VA_LIST_DEFINED AND leaves __gnuc_va_list
                                        usable. Measured: 0 errors on both files.

    -fms-compatibility is deliberately ABSENT. It is the only thing that allows the
    IL2CPP `static_cast<void *>` -> function-pointer idiom (methodPointer, ~20 sites
    a file), but it UNDEFINES __GNUC__, which then breaks clang's own mmintrin.h.
    Measured: -fms-extensions alone parses 34 of 80 first-party TUs; adding
    -fms-compatibility unscoped parses far fewer, not more.
    """
    return ["clang++", "--target=x86_64-w64-windows-gnu", "-std=c++23",
            "-fsyntax-only", "-fms-extensions", "-include", "stdarg.h",
            "-fdelayed-template-parsing",
            "-Wno-pragma-once-outside-header", "-Wno-ignored-attributes",
            "-Wno-unknown-warning-option", "-Wno-deprecated-declarations",
            "-Wno-unused-value", "-Wno-unused-variable"]


def shadow_path(path: str) -> str:
    """Where `path` lives in the shadow tree, or `path` unchanged if it isn't copied."""
    rel = os.path.relpath(os.path.realpath(path), REPO)
    for root in SHADOW_SOURCES:
        if rel.startswith(root + os.sep):
            return os.path.join(SHADOW, rel)
    return path


def check(files: list[str], db: list[dict], use_shadow: bool) -> tuple[int, list[tuple[str, str]]]:
    results: list[tuple[str, str]] = []
    incs = ["-I" + SHIM] if os.path.isdir(SHIM) else []
    root = SHADOW if use_shadow else REPO
    if use_shadow:
        for rel in ("TarkovAddons", "TarkovAddons/include", "external",
                    "TarkovAddons/external", "TarkovAddons/external/imgui",
                    "TarkovAddons/external/tracy", "shared"):
            incs.append("-I" + os.path.join(SHADOW, rel))
    else:
        for rel in ("TarkovAddons", "TarkovAddons/include", "external",
                    "TarkovAddons/external", "TarkovAddons/external/imgui",
                    "TarkovAddons/external/tracy", "shared"):
            incs.append("-I" + os.path.join(REPO, rel))

    for path in files:
        entry = entry_for(db, path)
        if entry is None:
            results.append((path, "NOT IN THE DATABASE -- not a compiled TU"))
            continue
        cmd = base_flags() + incs + defs_of(entry) + [shadow_path(path) if use_shadow else path]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode == 0:
            results.append((path, "OK"))
            continue
        first = "(no diagnostic)"
        for line in r.stderr.splitlines():
            m = re.search(r"(?:fatal )?error: (.*)", line)
            if m:
                first = m.group(1)[:96]
                break
        results.append((path, first))
    return 0, results


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--reconfigure", action="store_true")
    ap.add_argument("--check", nargs="*", metavar="FILE")
    ap.add_argument("--no-shadow", action="store_true",
                    help="check the REAL tree instead of the rewritten shadow copy. "
                         "Parses fewer files; use it to confirm a failure is not "
                         "introduced by the rewrite.")
    ap.add_argument("--rebuild-shadow", action="store_true")
    ap.add_argument("--print-cmd", metavar="FILE")
    args = ap.parse_args()

    if args.print_cmd:
        try:
            db = load_db()
        except FileNotFoundError:
            return fail("no compile_commands.json -- run tools/analysis_tree.py first")
        entry = entry_for(db, args.print_cmd)
        if entry is None:
            return fail("%s is not in the database" % args.print_cmd)
        incs = ["-I" + SHIM] if os.path.isdir(SHIM) else []
        print(" ".join(base_flags() + incs + defs_of(entry) + [args.print_cmd]))
        return 0

    # Configure when asked, or whenever there is no database yet. Gating this on
    # `--check` -- which is what the first version did -- meant `--reconfigure` on its
    # own printed nothing, configured nothing, and exited 2 complaining about a
    # database it had never tried to build.
    if args.reconfigure or not os.path.exists(DB):
        rc = configure(reconfigure=args.reconfigure)
        if rc != 0:
            return rc
    if not os.path.exists(DB):
        return fail("no compile_commands.json at %s" % os.path.relpath(DB, REPO))

    try:
        db = load_db()
    except (OSError, json.JSONDecodeError) as e:
        return fail("could not read the compile database: %s" % e)
    if not db:
        return fail("the compile database is empty -- it checked nothing")

    if args.check is not None:
        targets = args.check
        if not targets:
            targets = sorted({e["file"] for e in db
                              if "/external/" not in e["file"]
                              and "/libil2cpp/" not in e["file"]
                              and not e["file"].endswith(".rc")})
        use_shadow = not args.no_shadow
        n_copied = 0
        if use_shadow:
            _, n_copied = build_shadow(force=args.rebuild_shadow)
        _, results = check(targets, db, use_shadow)
        ok = sum(1 for _, s in results if s == "OK")
        for path, status in results:
            rel = os.path.relpath(path, REPO)
            print("  %-4s %-52s %s" % ("OK" if status == "OK" else "FAIL",
                                       rel[:52], "" if status == "OK" else status))
        print("\n%d of %d parsed%s"
              % (ok, len(results),
                 "  (shadow tree: %d files, 1 header rewritten)" % n_copied
                 if use_shadow else "  (REAL tree -- the rewrite is off)"))
        if use_shadow:
            print("The shadow rewrites ONE line: il2cpp/il2utils.h:412, the MSVC")
            print("static_cast<void*>->function-pointer. Re-run with --no-shadow to")
            print("check the tree as it actually is.")
        return 0 if ok == len(results) else 1

    n_first = len([e for e in db if "/external/" not in e["file"]
                   and "/libil2cpp/" not in e["file"] and not e["file"].endswith(".rc")])
    print("compile database : %s" % os.path.relpath(DB, REPO))
    print("entries          : %d (%d first-party TUs)" % (len(db), n_first))
    print("case shim        : %s (%d aliases)"
          % (os.path.relpath(SHIM, REPO),
             len(os.listdir(SHIM)) if os.path.isdir(SHIM) else 0))
    print()
    print("next: python tools/analysis_tree.py --check")
    print("NOT a substitute for tools/run_tidy.ps1 -- mingw headers and GCC flags,")
    print("so diagnostics differ from a cl.exe parse.")
    return 0


if __name__ == "__main__":
    sys.exit(main())