# Compatibility manifest tooling — how `manifest_tool.py` works

> For the full workflow (new-build procedure, manifest field reference, runtime
> behaviour, audit record) see
> [`compatibility/PROFILE_GUIDE.md`](../compatibility/PROFILE_GUIDE.md).
> This file explains the tool itself: what it does, how to run it, and how a
> legacy `offsets.cfg` / `patterns.cfg` pair becomes a validated, versioned
> manifest — with worked examples at every step.

---

## 1. What this tool is

`tools/manifest_tool.py` is a **file-only** migration and validation utility
for the compatibility data that lives in
`TarkovAddons/offsets.cfg` and `TarkovAddons/patterns.cfg`.

It requires **Python 3.10+** and uses only the standard library. It has four
subcommands:

| Subcommand | Purpose |
|---|---|
| `import` | Convert legacy `key=value` cfg files into a JSON manifest |
| `inspect-isil` | Report build identity from an ISIL reference tree |
| `validate` | Check a manifest's structure and, optionally, its PE metadata and byte patterns against real module files |
| `update-rvas` | Inject confirmed RVAs into an existing manifest from a JSON mapping |

Three sibling scripts acquire the RVAs that `update-rvas` injects — see §4.5:

| Script | Input | Purpose |
|---|---|---|
| `parse_pdb.py` | `GameAssembly.pdb` | Extract launcher-target symbol RVAs from the PDB symbol table (needs `pip install purelypdb`) |
| `parse_dump_cs.py` | `dump.cs` | Extract the same RVAs from an Il2CppDumper dump |
| `ida_extract_patterns.py` | `.i64` + `patterns.json` | Confirm RVAs by pattern-scanning an IDA database |

It deliberately does **not** attach to a process, inject a DLL, patch memory,
or discover anti-cheat targets. It reads text files and (when you point it at
them) PE files, then reports whether the declared metadata and byte patterns
are self-consistent. Everything it does can be reproduced offline.

---

## 2. Why this tool exists

The legacy runtime located IL2CPP entry points with two loose `key=value` files
plus hardcoded fallbacks. That had three problems:

1. **Nothing was checked.** A stale or wrong address in `offsets.cfg` was
   trusted blindly (the old files themselves warn: *"the IL2CPP values are
   taken at face value … a wrong value here crashes the game instantly"*).
2. **One global file for all builds.** When the game updated, you hand-edited
   the same file — there was no per-build record and no rollback.
3. **Offsets and signatures could drift apart** because they lived in two
   different files with no linkage.

The manifest system replaces that with one JSON file **per game build**:

```text
compatibility/profiles/<game-build>/manifest.json
```

Each manifest bundles the module identity (`SizeOfImage`, PE timestamp, `.text`
SHA-256), every symbol's RVA + byte patterns + expected match count + fallback
strategy in a single record, and a `status` that records how far it has been
validated. `manifest_tool.py` is the only thing that produces and checks those
files.

The three governing rules:

1. **Profiles are per build.** Never copy an RVA from one build's profile into
   another's — `--clear-rvas` exists for this.
2. **ISIL references are authoritative for build identity and semantics**, but
   are not a complete PE image and cannot produce reliable raw byte patterns.
3. **The tooling is file-only** (see §1).

---

## 3. Quick start

From the repository root (PowerShell — note the backtick continuations):

```powershell
# 1. See what build the ISIL references identify
python tools/manifest_tool.py inspect-isil TarkovAddons/ISIL-references/IsilDump

# 2. Import the legacy cfg files into a manifest
python tools/manifest_tool.py import `
  --offsets TarkovAddons/offsets.cfg `
  --patterns TarkovAddons/patterns.cfg `
  --profile-id legacy-seed `
  --game-version unknown `
  --output compatibility/profiles/legacy-seed/manifest.json

# 3. Validate the manifest (syntax-only, no module files)
python tools/manifest_tool.py validate compatibility/profiles/legacy-seed/manifest.json
```

The rest of this document explains every flag, shows every command in detail,
and then walks through exactly how a manifest is generated.

---

## 4. Commands

### 4.1 `import` — convert legacy cfg files into a manifest

```
python tools/manifest_tool.py import --offsets <file> --patterns <file> --output <manifest.json> [options]
```

#### Flags

| Flag | Required | Default | Meaning |
|---|---|---|---|
| `--offsets` | yes | — | Path to the legacy `offsets.cfg` |
| `--patterns` | yes | — | Path to the legacy `patterns.cfg` |
| `--output` | yes | — | Where to write the manifest (parent dirs are created) |
| `--profile-id` | no | derived from build | Profile identifier; `^[A-Za-z0-9._-]+$` |
| `--game-version` | no | `unknown` | Human-readable game build; overwritten by the ISIL build id when `unknown` |
| `--source-commit` | no | — | Source commit recorded in the profile |
| `--isil-root` | no | — | ISIL reference tree; supplies build identity + provenance |
| `--clear-rvas` | no | off | Emit every `rva` as `null`; keep patterns as candidates only |
| `--architecture` | no | `x64` | `x64` or `x86` |
| `--module-dir` | no | — | Directory with `GameAssembly.dll` / `UnityPlayer.dll`; collects PE metadata and validates against them |
| `--default-module` | no | `GameAssembly.dll` | Module used for unknown legacy keys (don't rely on this for known keys — see §6.2) |
| `--strict` | no | off | Treat validation warnings as errors |

#### Example A — minimal import (no module files)

```powershell
python tools/manifest_tool.py import `
  --offsets TarkovAddons/offsets.cfg `
  --patterns TarkovAddons/patterns.cfg `
  --profile-id legacy-seed `
  --game-version unknown `
  --output compatibility/profiles/legacy-seed/manifest.json
```

Result: a syntactically valid, `unverified` manifest. Legacy RVAs are copied
in, module entries say *"Module metadata was not collected during import."*,
and every symbol keeps `source: "legacy-cfg-import"`. Because no `--module-dir`
was supplied, validation can only check syntax — each symbol with an RVA or
pattern produces a `not statically verified; supply --module-dir` warning, and
the profile stays `unverified`.

#### Example B — import with real module files

Point `--module-dir` at a directory containing the modules named by the manifest
(typically `GameAssembly.dll` and `UnityPlayer.dll`; in this repo the dumps live
under `TarkovAddons/GameDump/<build>_tarkov-dump`, which is gitignored — the
files are local input, never committed):

```powershell
python tools/manifest_tool.py import `
  --offsets TarkovAddons/offsets.cfg `
  --patterns TarkovAddons/patterns.cfg `
  --profile-id local-build `
  --game-version 1.1.5.1 `
  --module-dir TarkovAddons/GameDump/115147510_tarkov-dump `
  --output compatibility/profiles/1.1.5.1/manifest.json
```

The tool now also:

- fills each `modules.<name>` entry with `size` (`SizeOfImage`), `pe_timestamp`
  (a `0x`-prefixed string), and `text_sha256` (SHA-256 of the `.text` section);
- checks every declared pattern against the real module bytes;
- promotes `profile.status` to `validated` (no errors, no warnings) or `staged`
  (warnings only).

The module files are opened read-only and never modified.

#### Example C — the new-build workflow (recommended)

When a new game build lands, do **not** reuse the old RVAs. Import the legacy
files as a *pattern seed*, take the build identity from the ISIL references,
and validate against the new modules:

```powershell
python tools/manifest_tool.py import `
  --offsets TarkovAddons/offsets.cfg `
  --patterns TarkovAddons/patterns.cfg `
  --isil-root TarkovAddons/ISIL-references/IsilDump `
  --clear-rvas `
  --module-dir TarkovAddons/GameDump/115147510_tarkov-dump `
  --output compatibility/profiles/1.1.5.1.47510/manifest.json
```

What each extra flag does:

- `--isil-root` reads `Build.txt` (preferring paths containing `EFT`) for the
  build id — here `1.1.5.1.47510` — and records it in `profile.provenance`
  together with the evidence file. Because `--game-version` was omitted (or
  left `unknown`), the ISIL build id becomes the game version.
- `--clear-rvas` sets every `rva` to `null`. The patterns come along as
  candidates; the importer makes no claim that they still match.
- Without `--profile-id`, the id is derived: non `[A-Za-z0-9._-]` characters in
  the build become `-`, prefixed with `eft-` → `eft-1.1.5.1.47510`.

The new profile starts at `unverified` and is only promoted by the module-backed
validation that runs as part of the same command. Old patterns are *retained as
candidates* — they must not be treated as valid merely because they came from
an older profile.

#### Example D — pinning provenance

```powershell
python tools/manifest_tool.py import `
  --offsets TarkovAddons/offsets.cfg `
  --patterns TarkovAddons/patterns.cfg `
  --profile-id eft-1.1.5.1.47510 `
  --game-version 1.1.5.1.47510 `
  --source-commit 3f79d343 `
  --isil-root TarkovAddons/ISIL-references/IsilDump `
  --clear-rvas `
  --module-dir TarkovAddons/GameDump/115147510_tarkov-dump `
  --output compatibility/profiles/1.1.5.1.47510/manifest.json
```

This is exactly how the checked-in profile
`compatibility/profiles/1.1.5.1.47510/manifest.json` was seeded. Add
`--strict` to fail the import if any warning remains (see §11 before using it
on a profile that still has known-unresolved entries).

#### What the importer does with the cfg files

`offsets.cfg` and `patterns.cfg` are parsed with deliberately strict rules
(the old runtime parser accepted almost anything containing `=`):

- blank lines and lines starting with `#` are ignored;
- whitespace around keys/values is trimmed;
- `#` after a value starts an inline comment (`key=0x10 # note` → `0x10`);
- a line with no `=` is an **error**;
- an empty key is an **error**;
- a **duplicate key** is an **error** (last-wins is not allowed);
- values may be blank (meaning "no address / use the built-in signature").

Numeric offsets are accepted as `0x...` or decimal, must fit in an unsigned
64-bit value, and are canonicalized to uppercase `0x...` strings. A key that
appears in only one of the two files is still imported (names are the union of
both files) — this is how a pattern-only slot like `hwid_check` gets tracked.

---

### 4.2 `inspect-isil` — report build identity from an ISIL tree

```
python tools/manifest_tool.py inspect-isil <isil_root> [--output report.json] [--no-count]
```

ISIL text is a semantic/disassembly reference (type and method listings with
signatures), not a raw PE image. This command reports what can be established
from the text alone.

```powershell
python tools/manifest_tool.py inspect-isil TarkovAddons/ISIL-references/IsilDump
```

Example output:

```json
{
  "root": "D:\\TarkovAddonsReloaded\\TarkovAddons\\ISIL-references\\IsilDump",
  "build_version": "1.1.5.1.47510",
  "build_evidence": ["Assembly-CSharp\\EFT\\Build.txt"],
  "type_count": 24976,
  "method_count": 108422,
  "limitations": [
    "ISIL text identifies semantic types/methods and build metadata.",
    "It does not provide a complete raw PE image for byte-pattern generation."
  ]
}
```

Notes:

- Build identity comes from `Build.txt` (regex `Build id: "<version>"`),
  preferring files whose path contains `EFT`; if none match, `Version.txt`
  is tried. `build_evidence` names the file the version came from.
- The checked-in references now hold two builds: `115147510` and `120047888`,
  each rooted at `TarkovAddons/ISIL-references/<build>/IsilDump` (the path in
  the example above predates the per-build layout). Point `inspect-isil` at the
  build directory you are refreshing.
- `--no-count` skips the `Type:`/`Method:` census (much faster; useful for a
  quick check). `--output report.json` saves the report instead of printing it.
- Exit code is `1` if no build version could be determined.

Use this command first in any new-build workflow: it tells you what
`--game-version` / `--profile-id` should be, and gives the importer its build
identity via `--isil-root`.

---

### 4.3 `validate` — check a manifest

```
python tools/manifest_tool.py validate <manifest.json> [--module-dir <dir>] [--strict]
```

#### Example A — syntax-only

```powershell
python tools/manifest_tool.py validate compatibility/profiles/legacy-seed/manifest.json
```

Checks structure only: the four top-level fields, profile shape, module
metadata types, RVA syntax, pattern syntax, `expected_matches`, managed
references, duplicate symbols, and module declarations. Because no module files
are supplied, every symbol that declares an RVA or pattern also yields a
`not statically verified; supply --module-dir to check the PE file` warning —
so a syntax-only run over a populated manifest reports warnings by design.
In `--strict` mode those warnings become errors.

#### Example B — static validation against module files

```powershell
python tools/manifest_tool.py validate `
  compatibility/profiles/1.1.5.1.47510/manifest.json `
  --module-dir TarkovAddons/GameDump/115147510_tarkov-dump
```

This is the real check. In addition to the syntax checks, for every module the
tool reads the PE headers and compares:

- `size` against `SizeOfImage`,
- `pe_timestamp` against the PE timestamp (must match exactly, as a
  `0x`-prefixed string),
- `text_sha256` against a fresh SHA-256 of the `.text` section.

And for every symbol:

- the RVA (when present) must lie inside `SizeOfImage`;
- the bytes at the RVA must match the symbol's first declared pattern;
- each pattern is scanned for across the module's sections:
  - **zero matches** → error (`no pattern match found in the supplied module`),
  - **more matches than `expected_matches`** → warning (error with `--strict`),
  - matches are capped by a safety limit; hitting it → warning;
- the configured RVA must be among the pattern matches.

Expected clean output for the current checked-in profile is **no diagnostics at
all** — it passes `--strict` (see §8 for why an import differs):

```text
Manifest validation passed
```

#### Example C — strict validation (CI / pre-commit)

```powershell
python tools/manifest_tool.py validate `
  compatibility/profiles/1.1.5.1.47510/manifest.json `
  --module-dir TarkovAddons/GameDump/115147510_tarkov-dump `
  --strict
```

`--strict` promotes every warning to an error, and additionally requires every
declared module to carry `SizeOfImage` metadata. Appropriate in CI, or once a
profile's known-unresolved entries have explicit resolvers — not while it still
has entries that are unresolved by design.

---

### 4.4 `update-rvas` — inject confirmed RVAs

```
python tools/manifest_tool.py update-rvas <manifest.json> --rvas <rvas.json> [--source <label>] [--allow-unknown]
```

After a pattern has been resolved (e.g. by a scanner such as the
`ida-pattern-scan` flow used for the current profile), record the confirmed RVA
in the manifest. `--rvas` is a JSON object mapping symbol names to hex RVA
strings:

```json
{
  "be_client_init": "0x30B0AA0",
  "be_client_start": "0x10E0950",
  "hwid_check": "0x162CF83",
  "load_be_client": "0xEE2660"
}
```

```powershell
python tools/manifest_tool.py update-rvas `
  compatibility/profiles/1.1.5.1.47510/manifest.json `
  --rvas confirmed-rvas.json `
  --source ida-pattern-scan
```

For each mapped symbol this rewrites:

- `rva` — canonical `0x...` string (decimal input is accepted too),
- `source` — the `--source` label,
- `notes` — `RVA confirmed by <source> against <module>.`

An unknown name in the mapping is an **error**: every such name is listed and
**nothing is written**, exit `1`. This is deliberate — the previous behaviour
skipped unknown names with a warning, applied the rest, printed `Updated N
symbol(s)` and exited `0`, so a confirmed address could be dropped from the
manifest while the command reported success. Use `--allow-unknown` to record
only the known subset anyway. If nothing was updated the command also exits `1`.

The manifest is rewritten in place — back it up or keep it in version control,
because this is a hand-applied edit. The generator remains the source of truth:
if you later re-run `import`, re-apply the update-rvas result (see §5.3).

---

### 4.5 Acquiring RVAs: PDB, dump.cs, and IDA pattern scanning

The four launcher-target symbols (`be_client_init`, `be_client_start`,
`load_be_client`, `run_validation_movenext_offset`) live in `GameAssembly.dll`
and have no IL2CPP export names — they must be located by scanning. Three
tools in this directory do that scanning, each from a different source, and
all three emit the same `rvas.json` format that `update-rvas` consumes:

| Tool | Input | External dependency |
|---|---|---|
| `parse_pdb.py` | `GameAssembly.pdb` (symbol file) | `purelypdb` (pip) |
| `parse_dump_cs.py` | `dump.cs` (Il2CppDumper output) | none |
| `ida_extract_patterns.py` | `.i64` database + `patterns.json` | IDA Pro (batch mode) |

#### Example A — extract RVAs from a PDB file

A PDB shipped with the game contains the full symbol table with section
offsets, so the exact RVA of each launcher-target function can be read
directly — no disassembly scanning required:

```powershell
python -m pip install purelypdb
python tools/parse_pdb.py GameAssembly.pdb --output rvas.json
```

Example output:

```text
Parsing: GameAssembly.pdb
  Total symbols in PDB: 343233
  be_client_init: 0x30B0AA0 (from BattlEye.BEClient::Init)
  be_client_start: 0x10E0950 (from BattlEye.BEClient::Start)
  run_validation_movenext_offset: 0x1B76260 (from EFT.AnticheatValidationOperation+<RunValidation>d__10::MoveNext)
  be_service_check: NOT FOUND

Results saved to: rvas.json
Matched 3 symbols
```

Verified by running it, not reconstructed. `be_client_init` resolving through the
`BEClient`/`Init` pair is unambiguous *on this build* — exactly one of the
343,233 global symbols has method `Init` with `BEClient` in the class — but the
matcher no longer relies on that: it collects every candidate and reports
`AMBIGUOUS` with a count if more than one matches, resolving nothing. That
matters because nested types repeat method names, so the same pair that is clean
today can stop being clean after a game update.

> **Two defects were found in this section's example output on 2026-10-06, and
> the old text had both wrong.** It claimed `load_be_client: 0xEE2660 (from
> BattlEye.BEClient::CreateInstance)` and
> `run_validation_movenext_offset: ... ::RunValidation`, with `Matched 4/4`.
> Neither name exists in the PDB. Checked directly against the 343,233 global
> func symbols of `GameAssembly.pdb`:
>
> | address | PDB symbol |
> |---|---|
> | `0x30B0AA0` | `BattlEye.BEClient::Init` — exact |
> | `0x10E0950` | `BattlEye.BEClient::Start` — exact |
> | `0x1B76260` | `EFT.AnticheatValidationOperation+<RunValidation>d__10::MoveNext` — exact |
> | `0xEE2660` | **no symbol.** Nearest is `EFT.MovementContext::get_MoveDiagonalInertia` at `0xEE2630`, `0x30` earlier |
>
> `BEClient::CreateInstance` does not exist; the name came from
> `CreateInstanceResult`, the *return type* of `BEClient::Start` — and
> `load_be_client` is a *correct* name for `0xEE2660`, not a misnomer: patching
> it stops `MoveNext` from running, and `MoveNext` is what calls
> `BEClient.Start(...)`. See `compatibility/REFRESH_RUNBOOK.md`. And the state
> machine's method is `MoveNext`, not `RunValidation` — the matcher compares
> exactly on the substring after the last `::`, so `("AnticheatValidationOperation", "RunValidation")`
> matched nothing. `0xEE2660` is a compiler-emitted generic instantiation
> (`AsyncTaskMethodBuilder.Start<AnticheatValidationOperation.<RunValidation>d__10>`),
> which never gets a global symbol; its identity comes from `dump.cs`'s
> `GenericInstMethod` table, the ISIL call site (`rcx=builder`, `rdx=stateMachine`)
> and IDA (`sub_180EE2660`, a 192-byte function start).
>
> `parse_pdb.py` no longer asks for either unresolvable name, so it reports a
> miss instead of inventing an attribution. `be_service_check` lives in
> `UnityPlayer.dll`, which ships no PDB at all.

How it works: `purelypdb` parses the PDB streams; the tool builds a
section-base map from the section header stream (PDB section numbers are
1-based indices), then walks the global symbol stream collecting
`section_base + offset` for every function symbol. It matches each manifest
symbol name against a `(class, method)` pair — e.g. `be_client_init` →
(`BEClient`, `Init`) — taking the method name after the last `::` and
requiring the class pattern and `BECLIENT` (case-insensitive) in the full
symbol name. `run_validation_movenext_offset` falls back to a broader
`RunValidation` + `Anticheat`/`Validation` search if the exact match fails.

#### Example B — extract RVAs from a dump.cs file

If you have an Il2CppDumper `dump.cs` instead of a PDB, the same four
symbols can be extracted from the RVA comments Il2CppDumper emits above each
method declaration:

```powershell
python tools/parse_dump_cs.py dump.cs --output rvas.json
```

The dump.cs format places the RVA on the comment line *before* the method:

```csharp
// RVA: 0x30B0AA0 Offset: 0x30AFCA0 VA: 0x1830B0AA0
private BEClient.EInstanceStatus Init(string email, string password) { }
```

The tool finds the declaration line containing the class and method name,
then reads the `// RVA: 0x...` comment from the preceding line.

#### Example C — confirm RVAs by pattern-scanning an IDA database

When neither a PDB nor a dump.cs is available, scan an IDA database for the
known byte patterns. `tools/patterns.json` holds the pattern database
(build-tagged patterns and the RVA each was confirmed at):

```json
{
  "symbols": {
    "be_client_init": [
      {
        "build": "1.1.5.1.47510",
        "pattern": "48 89 6C 24 20 56 57 41 56 48 83 EC 30 80 3D ? ? ? ? ? 41 0F B7",
        "rva": "0x30B0AA0"
      }
    ]
  }
}
```

Run it in IDA batch mode against a `.i64` database:

```bat
idat.exe -A -S"tools\ida_extract_patterns.py" --patterns tools\patterns.json <database.i64>
```

The script searches every segment for each pattern, converts matches to RVAs
(effective address minus image base), and writes `rvas.json` next to the
script. When multiple patterns match, it prefers the first match and prints
a warning — review those cases manually.

#### Feeding the results into the manifest

All three tools write the same JSON shape — a flat mapping of manifest symbol
names to hex RVA strings:

```json
{
  "be_client_init": "0x30B0AA0",
  "be_client_start": "0x10E0950",
  "load_be_client": "0xEE2660",
  "run_validation_movenext_offset": "0x1B76260"
}
```

> **This example now runs clean against the shipped profile.**
> `run_validation_movenext_offset` was restored 2026-10-06, so all four names
> exist and `update-rvas` exits `0` having recorded all four. It used to warn
> about that name, update the other three, print `Updated 3 symbol(s)` and exit
> `0` — leaving `0x1B76260` recorded nowhere in version control.

That file is exactly what `update-rvas` expects:

```powershell
python tools/manifest_tool.py update-rvas `
  compatibility/profiles/1.1.5.1.47510/manifest.json `
  --rvas rvas.json `
  --source pdb-symbol-table
```

Afterwards, re-run `validate --module-dir <dir>` to confirm each injected
RVA against the real module bytes (the validator checks that the bytes at the
RVA match the symbol's first declared pattern, and that the RVA is among the
pattern matches). A PDB-derived RVA that disagrees with the declared pattern
is a signal that the pattern is stale — investigate before trusting either.

---

## 5. How manifest generation works, step by step

Understanding the pipeline makes every flag obvious. `import` runs these stages
in order:

### 5.1 Stage 1 — parse the legacy cfg files

Both files are parsed with the strict rules from §4.1. The result is two
dictionaries: `offsets` (name → address string) and `patterns` (name → pattern
string). Any parse error aborts the import with exit code `2` — malformed
profiles are never silently converted.

### 5.2 Stage 2 — assign each symbol to a module

The importer maps every legacy key to a native module by name
(`_module_for_legacy_name`):

| Legacy key | Module |
|---|---|
| `be_service_check` | `UnityPlayer.dll` |
| `hwid_check` | `GameAssembly.dll` (explicit — ignores `--default-module`) |
| `il2cpp_*` | `GameAssembly.dll` |
| `be_*`, `load_be_*`, `run_validation*` | `GameAssembly.dll` |
| anything else | whatever `--default-module` says (default `GameAssembly.dll`) |

The `hwid_check` row deserves a note: it is consumed by `feature/spoofer.cpp`
but appeared in no cfg file for a long time, so it silently fell through to a
signature compiled into the DLL. It is now a blank slot in `patterns.cfg` (that
file's own rule: *"blank means use the signature built into the DLL"*), and the
importer lists it as a tracked, non-required `GameAssembly.dll` symbol. The
explicit mapping means a non-default `--default-module` cannot silently
misfile it. **Do not let a new key rely on the `--default-module` fallback** —
if you add a key, it should match one of the documented prefixes.

### 5.3 Stage 3 — infer kind, required-ness, and resolution strategy

For each symbol name:

- **kind** — names ending in `_offset` or `_rva` become `"data"`; everything
  else becomes `"function"`.
- **required** — `il2cpp_*` symbols are required (the 14 IL2CPP API entries the
  main DLL cannot start without); launcher-side symbols are not, so they can
  never block main-DLL startup.
- **resolver / resolution_order / fallback** — derived from what data exists:

  | Symbol has | `resolver` | `resolution_order` | `fallback` |
  |---|---|---|---|
  | pattern(s), `il2cpp_*` | `pattern` | `[pattern, export]` | `pattern` |
  | no pattern, `il2cpp_*` | `export` | `[export]` | `export` (+ `export_name`) |
  | pattern(s), other | `pattern` | `[pattern]` | `pattern` |
  | no pattern, other | `native` | `[native]` | `none` |

  An `il2cpp_*` symbol with no pattern becomes an **export** lookup
  (`GetProcAddress`, thunk-following) — the current profile uses this for 6 of
  its 14 required symbols; the other 8 use byte patterns.

### 5.4 Stage 4 — canonicalize patterns

- Tokens are whitespace-separated hex bytes; `?` and `??` are both wildcards
  (either spelling is accepted; output normalizes to a single `?`).
- Each token must be exactly two hex characters — anything else is an error.
- `||` separates **alternative** patterns; each alternative is parsed and
  reformatted independently, so `48 83 ?? || 48 83 EC` becomes
  `["48 83 ?", "48 83 EC"]`.
- Output is uppercase hex, one space between bytes:
  `48 83 EC 28 48 8B 05 ? ? ? ? 48 85 C0 75 39`.

### 5.5 Stage 5 — collect module identity (only with `--module-dir`)

For each referenced module, `inspect_pe` reads the PE headers directly:
`SizeOfImage`, the PE timestamp, the section table, and — if a `.text` section
exists — its SHA-256. These become the `modules` entry (see §7). The runtime
uses `size` + `pe_timestamp` to decide whether a profile matches the loaded
game; `text_sha256` is an offline-only stronger check (the runtime does not
hash the loaded image).

### 5.6 Stage 6 — validate and set the status

The freshly built manifest is run through the same validator as §4.3, and the
profile status is decided:

| Condition (with `--module-dir`) | Status |
|---|---|
| no errors, no warnings | `validated` (provenance notes static validation passed) |
| warnings only | `staged` |
| any error | stays `unverified` — the file is still written, but the command exits `1` |

Without `--module-dir` the status stays `unverified` (syntax checks only).

---

## 6. Worked example: from cfg files to manifest

Given these inputs (abridged from the real files):

```ini
# offsets.cfg
il2cpp_domain_get=
load_be_client_known_offset=0xEE2660
```

```ini
# patterns.cfg
il2cpp_domain_get=48 83 EC 28 48 8B 05 ? ? ? ? 48 85 C0 75 39
load_be_client=48 89 5C 24 08 57 48 83 EC 60 49 8B D8
```

and running:

```powershell
python tools/manifest_tool.py import `
  --offsets TarkovAddons/offsets.cfg `
  --patterns TarkovAddons/patterns.cfg `
  --profile-id worked-example `
  --game-version 1.1.5.1.47510 `
  --clear-rvas `
  --output compatibility/profiles/worked-example/manifest.json
```

the generated symbols look like:

```json
[
  {
    "name": "il2cpp_domain_get",
    "module": "GameAssembly.dll",
    "kind": "function",
    "resolver": "pattern",
    "rva": null,
    "patterns": ["48 83 EC 28 48 8B 05 ? ? ? ? 48 85 C0 75 39"],
    "required": true,
    "fallback": "pattern",
    "resolution_order": ["pattern", "export"],
    "source": "legacy-cfg-import",
    "notes": "Imported from offsets.cfg/patterns.cfg; validate against the intended module build."
  },
  {
    "name": "load_be_client_known_offset",
    "module": "GameAssembly.dll",
    "kind": "data",
    "resolver": "native",
    "rva": null,
    "patterns": [],
    "required": false,
    "fallback": "none",
    "resolution_order": ["native"],
    "source": "legacy-cfg-import",
    "notes": "Imported from offsets.cfg/patterns.cfg; validate against the intended module build."
  }
]
```

Note how the inference rules play out:

- `il2cpp_domain_get` → `GameAssembly.dll`, required, pattern resolver with an
  export fallback; `--clear-rvas` kept its (already blank) RVA as `null`.
- `load_be_client_known_offset` → `GameAssembly.dll` (via the `load_be_`
  prefix), `kind: "data"` (via the `_offset` suffix), not required, and — having
  no pattern — a `native` resolver with `fallback: "none"`. Its RVA would have
  been `0xEE2660`, but `--clear-rvas` set it to `null` on purpose.

---

## 7. Manifest anatomy

A manifest has exactly four top-level fields (`additionalProperties: false`
everywhere in the schema — `tools/manifest.schema.json`):

```jsonc
{
  "schema_version": 1,          // always 1
  "profile": {                  // identity + lifecycle
    "id": "eft-1.1.5.1.47510", // ^[A-Za-z0-9._-]+$
    "game_version": "1.1.5.1.47510",
    "architecture": "x64",      // x64 | x86 (runtime refuses non-x64)
    "status": "staged",         // unverified | staged | validated | verified
    "source_commit": "3f79d343",// optional
    "provenance": {             // optional, written by the importer
      "source_kind": "legacy-cfg+isil",
      "isil_reference": "IsilDump",
      "notes": "…"
    },
    "notes": "…"               // optional free text
  },
  "modules": {
    "GameAssembly.dll": {       // native PE identity — runtime selection keys
      "size": 107925504,        // SizeOfImage; mandatory for selection
      "pe_timestamp": "0x6AAD381A", // string! mandatory for selection
      "text_sha256": "827a8463a9c0cbf0…" // 64 hex chars; offline-only check
    },
    "UnityPlayer.dll": { "…": "…" }
  },
  "symbols": [
    {
      // required fields
      "name": "il2cpp_domain_get",
      "module": "GameAssembly.dll",   // must be declared in modules
      "kind": "function",             // function | data | unknown
      "rva": null,                    // null, or "0x…" / decimal string
      "patterns": ["48 83 … 75 39"],  // each min length 3
      "required": true,               // gates runtime startup

      // strategy
      "resolver": "pattern",          // native | pattern | export | managed
      "resolution_order": ["pattern", "export"], // tried in order
      "fallback": "pattern",          // pattern | export | none
      "export_name": "il2cpp_string_new", // defaults to name; export resolver
      "expected_matches": 1,          // int >= 1; runtime wants exactly 1 for pattern symbols

      // managed (only with resolver "managed")
      "managed": {
        "assembly": "Assembly-CSharp",
        "namespace": "EFT.CameraControl",
        "type": "CameraManager",
        "member": "<OpticCameraManager>k__BackingField",
        "member_kind": "field",       // field | method | property
        "argument_count": 0,          // optional
        "declaring_type": "…"         // optional
      },

      // provenance
      "source": "legacy-cfg-import",  // legacy-cfg-import | ida-pattern-scan | …
      "notes": "…"
    }
  ]
}
```

Why one record per symbol: it keeps an offset and its validation pattern in
the same place, so the two can never drift apart the way they could when they
lived in `offsets.cfg` and `patterns.cfg` separately.

A `managed` symbol is the most resilient option: when a build relocates native
code but preserves the IL2CPP type/member name, the entry still resolves. A
`managed` resolver without a full managed reference is rejected by validation.

---

## 8. Status lifecycle

| Status | Meaning | Runtime behaviour |
|---|---|---|
| `unverified` | imported or edited without module-backed validation | refused outright |
| `staged` | module data collected, warnings remain | eligible |
| `validated` | PE identity, RVAs and declared patterns passed static checks | eligible |
| `verified` | additionally runtime-tested | eligible (highest rank) |

The loader ranks `verified` > `validated` > `staged`; two candidates at the
same rank is an error. `validated` is explicitly **not** a claim that every
optional feature was exercised in a live game session — promote to `verified`
only after runtime testing.

The checked-in profile currently validates with **zero** diagnostics, with and
without `--strict`: all five optional native symbols have both a manifest RVA
and a pattern. It is nonetheless left at `staged`; the justification originally
recorded for that — unresolved entries — no longer holds, so the promotion to
`validated` is an open decision (see `compatibility/README.md`).

A *fresh import* from the legacy cfg files does produce tracked-but-unresolved
entries — two, not four:

| Symbol | Module | Why unresolved |
|---|---|---|
| `be_service_check` | `UnityPlayer.dll` | built-in resolver; blank slot in `patterns.cfg` |
| `hwid_check` | `GameAssembly.dll` | signature compiled into the launcher DLL; blank slot in `patterns.cfg` |

This is the *tracked-but-unresolved* convention: a symbol the code genuinely
consumes but which has no manifest RVA or pattern is **imported, left empty,
`required: false`** — never omitted — so a future breakage surfaces in
validation instead of failing silently at runtime.

Both are now present in the shipped profile — `load_be_client_known_offset` and
`run_validation_movenext_offset` were restored 2026-10-06, and
`ShippedProfileDriftTests` now requires that **no** cfg key is missing from the
manifest. Note that `update-rvas` refuses (exit 1, writes nothing) if asked to
record an RVA for a symbol the manifest does not contain, so an absent symbol
cannot be papered over by a successful-looking command. Pass `--allow-unknown`
to override deliberately.

---

## 9. Exit codes

| Code | Meaning |
|---|---|
| `0` | success (for `inspect-isil`: a build version was found; for `update-rvas`: at least one symbol was updated **and** every requested name existed, or `--allow-unknown` was passed) |
| `1` | validation errors found (`import`, `validate`); or no build version (`inspect-isil`); or nothing updated (`update-rvas`); or a requested `update-rvas` symbol is not in the manifest (nothing written, every unknown name listed) |
| `2` | usage or input error: unreadable/invalid cfg or JSON, missing module files, bad `--isil-root`, non-object manifest root, symbol with no string `name` |

`import` **always writes the output file**, even when validation then fails
(exit `1`) — inspect the warnings, fix the inputs, and re-run; never promote a
failing profile by hand-editing `status`.

`update-rvas` is the opposite: it writes **nothing** when a requested symbol is
unknown. There is no traceback path that could be mistaken for exit `1` — a
malformed manifest exits `2`.

---

## 10. Common failures and how to read them

| Message | Cause | Fix |
|---|---|---|
| `ERROR <file>:<line>: duplicate key 'x'` | cfg lists a key twice | remove one entry — the importer never silently picks a winner |
| `ERROR <file>:<line>: expected key=value` | line without `=` | the old runtime tolerated this; the importer does not |
| `ERROR modules.GameAssembly.dll: cannot inspect <path>: …` | module file missing or not a PE | point `--module-dir` at the directory that actually contains the module files |
| `ERROR symbols[3].patterns: no pattern match found in the supplied module` | pattern does not exist in this build's module | the function's code changed — find a new pattern or clear the slot |
| `WARNING symbols[3].patterns: found 4 matches; expected at most 1` | pattern is ambiguous | add bytes to the pattern until it matches uniquely, or raise `expected_matches` deliberately |
| `ERROR symbols[3].rva: RVA is not among the pattern matches` | stale RVA | re-resolve the address (then `update-rvas`) or drop it with `--clear-rvas` |
| `ERROR symbols[3].rva: configured RVA does not match its first pattern` | the bytes at the RVA differ from the pattern | RVA and pattern disagree — one of them is wrong |
| `WARNING symbols[3]: native symbol has no manifest RVA or pattern; it depends on an external/built-in resolver` | tracked-but-unresolved entry | expected for the two known entries (`be_service_check`, `hwid_check`) on a **fresh import**; the shipped profile resolves both, so validating it emits nothing |
| `WARNING symbols[3]: not statically verified; supply --module-dir…` | validated without module files | run again with `--module-dir` |

---

## 11. When to use `--strict`

`--strict` turns warnings into errors and requires `SizeOfImage` metadata on
every declared module. Use it:

- in CI, over every committed manifest;
- locally, once a profile has **no** known-unresolved entries left.

Do not use it on a **freshly imported** profile: `be_service_check` and
`hwid_check` are blank in `patterns.cfg` by design and warn on every import, so
strict mode would fail that run. The shipped profile has both resolved and
passes `--strict` clean today.

---

## 12. Tests

The tooling is covered by an offline test suite (no game files needed — the PE
tests synthesize a minimal image):

```powershell
python -m pytest tools/tests -q      # 480 passed, 23 subtests, 15 skipped, 4 failed  (measured 2026-10-12 on LINUX)
```

`python -m unittest discover -s tools/tests` also passes, and exits 0, but reports
**120** — it does not count subtests, nor tests written in the pytest idioms
(parametrisation, fixtures) that have no unittest spelling. Prefer pytest; the
120 is not a different suite, just a narrower count of the same one.

> **This number has been wrong in three files at once** — 149 here, 155 in
> `WORKFLOW.md`, 139 in `tools/verify/README.md` — while the real count was
> quietly climbing past all of them. All four files were corrected on 2026-10-05
> against a measured run. **Recount rather than edit a number you have not run:**
> the suite grows silently, and a stale count is worse than no count because it
> reads as verified. The same pass added `tools/tests/test_doc_counts.py`, which
> checks the *native case* count against the runners on every run — that half is
> machine-checkable, because `run_windows.bat` is the ground truth and needs no
> toolchain to read. This pytest figure is not machine-checked, and that is
> recorded in the test's own comments rather than left to look covered.

Coverage includes legacy parsing strictness, ISIL build detection, pattern
parsing (including literal-zero wildcards), PE inspection and RVA→file-offset
conversion, schema validation, module mapping (including the non-default
`--default-module` regression), the `hwid_check` tracking invariant, `deploy.py`
(including the lock probes and the no-terminal guard), the pre-3.2 legacy import
in `migrate_legacy.py` (42 cases), and `test_profile_path.py` (10 cases).

`test_profile_path.py` is the one that is not about `manifest_tool.py` at all: it
asserts that the reader, the build and `deploy.py` still name the same directory.
That check exists because they once did not — the profile shipped valid and was
never loaded, with no error anywhere (`PROFILE_GUIDE.md` F15/F16). It is a text
test by necessity, since `compatibility_profile.cpp` pulls in `pch.h` and
`safetyhook` and cannot be executed here, but it is negative-controlled: four
deliberate breaks all fail it.

Read it for *how* it matches, not for what it asserts. It strips comments before
searching the loader's body, because the first version matched the fix's own
explanatory comment and its negative control passed 10/10 against deliberately
reverted code. **A checker that can pass on a comment is not a checker** — the
same failure this directory's three own tools each produced once.

---

## 13. How the rest of the project consumes manifests

```text
legacy offsets.cfg / patterns.cfg
        │  manifest_tool.py import
        ▼
compatibility/profiles/<build>/manifest.json   ← validated, committed
        │  MSBuild Content item (all x64 configs)
        ▼
<output>\ta\compatibility\profiles\<build>\manifest.json
        │  compatibility_profile::load_for_module()  (TarkovAddons.dll)
        │                                        ← reads data_directory_wide()/compatibility/profiles
        ▼
profile selected by SizeOfImage + PE timestamp of the loaded GameAssembly.dll
```

- `TarkovAddons/il2cpp/compatibility_profile.{h,cpp}` discovers manifests under
  `module_paths::data_directory_wide()/compatibility/profiles` — i.e.
  `<dll dir>/ta/compatibility/profiles` when `ta/` exists, else
  `<dll dir>/compatibility/profiles` — matches them against the loaded module's
  identity, enforces the 14 required IL2CPP symbols, and fails closed (refuses
  to start) if a packaged profile exists but none matches.
- If no `compatibility/profiles` directory is shipped at all, startup falls
  back to the legacy cfg files for migration compatibility.
- `TarkovLauncherBypass` consumes the same manifests out-of-process via its
  own `compat_profile` module, and uses the same `data_directory_wide()` root.
  The two implementations must not be *merged* (`AGENTS_TODO.md` §4.1) but they
  must agree on the directory, and `tools/tests/test_profile_path.py` holds them
  to it.

> **The two `→` above did not line up until 2026-10-01.** The build wrote under
> `ta\` and the reader looked without it, so the profile was deployed, valid, and
> never loaded — silently, via the designed `NotFound` fallback. That is
> `PROFILE_GUIDE.md` F15, and it is why the reader now goes through an accessor
> rather than a literal.

For the full field-by-field reference, the new-build procedure, runtime
resolver semantics, and the audit record, see
[`compatibility/PROFILE_GUIDE.md`](../compatibility/PROFILE_GUIDE.md).

### Sibling diagnostic tools

These read already-produced artefacts:

| Tool | Input | Purpose |
|---|---|---|
| `TarkovAddons/tools/symbolize.py` | crash log + `symbols/<stamp>/TarkovAddons.map` | RVA→function, using the map the install archived for that build |
| `TarkovAddons/tools/tracy_parser.py` | Tracy profile (ZSTD/ZIP/SQLite) | top CPU stacks, largest frames, event counts without materializing 9 GB CSVs |
| `TarkovAddons/tools/audit_config_pointers.py` | the DLL | verify every config-value pointer is actually referenced by code |
| `tools/zone_gap.py` | the source tree | per-frame module bodies with **no** Tracy zone, ranked by size; and the zone inventory with comments stripped. Exit 0/1/**2** |
| `tools/quest_condition_fields.py` | `GameDump/<build>/dump.cs` | every condition-field name the Quest ESP POI pipeline reads, checked against the fields those classes actually declare. Exit 0/1/**2**; the place-POI bug it was built for is fixed (2026-10-13) and its hand-off is archived in `.opencode/handoff-archive/` |
