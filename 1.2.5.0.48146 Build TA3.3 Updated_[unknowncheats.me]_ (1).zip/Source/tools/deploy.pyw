"""Double-clickable launcher for the deploy window.

A .pyw file is associated with pythonw.exe, which has no console attached, so
double-clicking this opens the window without a black terminal flashing behind
it. The GUI writes everything to its own log pane, so nothing is lost by having
no console -- and deploy_gui.main() falls back to printing the usage text if the
window cannot start at all.

For scripting, use tools/deploy.py directly; it takes the same options without a
window.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from tools import deploy_gui  # noqa: E402  (needs the path set up first)

if __name__ == "__main__":
    sys.exit(deploy_gui.main())
