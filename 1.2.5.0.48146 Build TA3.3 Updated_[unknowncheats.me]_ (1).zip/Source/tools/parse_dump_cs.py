"""
dump.cs parser — extracts launcher-target symbol RVAs directly from an
Il2CppDumper dump.cs file. No IDA required.

Usage:
    python tools/parse_dump_cs.py <dump.cs> [--output rvas.json]

The dump.cs format places the RVA comment on the line BEFORE the method:
    // RVA: 0x30B0AA0 Offset: 0x30AFCA0 VA: 0x1830B0AA0
    private BEClient.EInstanceStatus Init(...) { }

Output: JSON mapping manifest symbol names to hex RVA strings.
"""

import argparse
import json
import re
import sys
from pathlib import Path


# Maps manifest symbol names to the dump.cs method signatures to search for.
# Each entry is a list of (class_pattern, method_name) tuples tried in order.
SYMBOL_SIGNATURES = {
    "be_client_init": [
        ("BEClient", "Init"),
    ],
    "be_client_start": [
        ("BEClient", "Start"),
    ],
    # 0xEE2660 is AsyncTaskMethodBuilder.Start<AnticheatValidationOperation.<RunValidation>d__NN>
    # -- a generic instantiation, which dump.cs records in a GenericInstMethod
    # block rather than as a normal type/method pair, so there is nothing here
    # to match it against. It was previously ("BEClient", "CreateInstance"),
    # and there is no BEClient::CreateInstance in the game: that name came from
    # CreateInstanceResult, the return type of BEClient::Start.
    #
    # The symbol is named for its effect, and the effect is real: MoveNext calls
    # BEClient.Start(...) with the game version string, then BEClient.Update()
    # and BEClient.Stop(). Patching 0xEE2660 prevents MoveNext running, so
    # BEClient.Start is never called. See compatibility/REFRESH_RUNBOOK.md.
    "load_be_client": [],
    # The state machine's method is MoveNext, not RunValidation -- RunValidation
    # is the async method that *starts* it and returns Task.
    "run_validation_movenext_offset": [
        ("AnticheatValidationOperation+<RunValidation>", "MoveNext"),
    ],
}


def parse_dump_cs(path: Path) -> dict[str, str]:
    """Extract symbol RVAs from a dump.cs file."""
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()

    results = {}

    for symbol, signatures in SYMBOL_SIGNATURES.items():
        found = False
        for class_pattern, method_name in signatures:
            # Simple approach: find lines containing the class and method name
            # The dump.cs format is:
            #   // RVA: 0x30B0AA0 Offset: 0x30AFCA0 VA: 0x1830B0AA0
            #   private BEClient.EInstanceStatus Init(string ...) { }

            for i, line in enumerate(lines):
                # Check if this line contains the method declaration
                if (class_pattern in line
                    and method_name in line
                    and "(" in line
                    and ")" in line
                    and "{" in line
                    and not line.strip().startswith("//")):

                    # Look at the preceding line for the RVA comment
                    if i > 0:
                        prev_line = lines[i - 1]
                        rva_match = re.search(r"//\s*RVA:\s*(0x[0-9A-Fa-f]+)", prev_line)
                        if rva_match:
                            rva = rva_match.group(1).upper()
                            results[symbol] = rva
                            found = True
                            print(f"  {symbol}: {rva} (from {class_pattern}.{method_name})")
                            break

            if found:
                break

        if not found:
            print(f"  {symbol}: NOT FOUND")

    return results


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dump_cs", help="path to dump.cs")
    parser.add_argument("--output", default="rvas.json", help="output JSON path")
    args = parser.parse_args()

    dump_path = Path(args.dump_cs)
    if not dump_path.exists():
        print(f"ERROR: file not found: {dump_path}")
        return 2

    print(f"Parsing: {dump_path}")
    results = parse_dump_cs(dump_path)

    if not results:
        print("ERROR: no symbols found")
        return 1

    output_path = Path(args.output)
    output_path.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(f"\nResults saved to: {output_path}")
    print(f"Matched {len(results)}/{len(SYMBOL_SIGNATURES)} symbols")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
