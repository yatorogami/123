#!/usr/bin/env python3
"""Import and statically validate TarkovAddons compatibility manifests.

This tool deliberately works on files only. It does not attach to a process,
inject a DLL, patch memory, or discover anti-cheat targets. It converts the
legacy key/value files into a deterministic JSON manifest and can verify the
manifest against PE image files when those files are supplied.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import mmap
import re
import struct
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence


SCHEMA_VERSION = 1
HEX_BYTE_RE = re.compile(r"^[0-9A-Fa-f]{2}$")
RVA_RE = re.compile(r"^(?:0[xX][0-9A-Fa-f]+|[0-9]+)$")
SHA256_RE = re.compile(r"^[0-9A-Fa-f]{64}$")
PROFILE_ID_RE = re.compile(r"^[A-Za-z0-9._-]+$")
ISIL_BUILD_RE = re.compile(r"Build id:\s*\"?([^\"\s]+)\"?")
ISIL_VERSION_RE = re.compile(r"Move\s+\S+\.Major[^\n]*?\"([^\"]+)\"")
MAX_U64 = (1 << 64) - 1

LEGACY_IL2CPP_PREFIX = "il2cpp_"
LEGACY_LAUNCHER_PREFIXES = ("be_", "load_be_", "run_validation")
# Legacy keys that do not match a prefix above but are known to belong to a
# specific native module. hwid_check is consumed by feature/spoofer.cpp and is
# absent from the legacy .cfg files, so without this it would be an invisible
# compiled-in dependency instead of a tracked symbol.
LEGACY_GAME_ASSEMBLY_KEYS = frozenset({"hwid_check"})
UNITY_PLAYER_MODULE = "UnityPlayer.dll"
GAME_ASSEMBLY_MODULE = "GameAssembly.dll"


@dataclass(frozen=True)
class Issue:
    severity: str
    path: str
    message: str

    def format(self) -> str:
        return f"{self.severity.upper():5} {self.path}: {self.message}"


@dataclass(frozen=True)
class PeSection:
    name: str
    virtual_size: int
    virtual_address: int
    raw_size: int
    raw_pointer: int


@dataclass(frozen=True)
class PeInfo:
    path: Path
    file_size: int
    size_of_image: int
    size_of_headers: int
    timestamp: int
    machine: int
    sections: tuple[PeSection, ...]
    text_sha256: str | None


@dataclass(frozen=True)
class IsilInfo:
    root: Path
    build_version: str | None
    build_evidence: tuple[str, ...]
    type_count: int
    method_count: int


def issue(severity: str, path: str, message: str) -> Issue:
    return Issue(severity=severity, path=path, message=message)


def _read_u16(data: mmap.mmap | bytes, offset: int, label: str) -> int:
    if offset < 0 or offset + 2 > len(data):
        raise ValueError(f"truncated PE while reading {label}")
    return struct.unpack_from("<H", data, offset)[0]


def _read_u32(data: mmap.mmap | bytes, offset: int, label: str) -> int:
    if offset < 0 or offset + 4 > len(data):
        raise ValueError(f"truncated PE while reading {label}")
    return struct.unpack_from("<I", data, offset)[0]


def _read_u64(data: mmap.mmap | bytes, offset: int, label: str) -> int:
    if offset < 0 or offset + 8 > len(data):
        raise ValueError(f"truncated PE while reading {label}")
    return struct.unpack_from("<Q", data, offset)[0]


def _slice(data: mmap.mmap | bytes, start: int, length: int, label: str) -> bytes:
    if start < 0 or length < 0 or start + length > len(data):
        raise ValueError(f"truncated PE while reading {label}")
    return bytes(data[start:start + length])


def inspect_pe(path: Path) -> PeInfo:
    """Read PE identity and section metadata from a file without loading it fully."""

    file_size = path.stat().st_size
    if file_size < 0x40:
        raise ValueError("file is too small to be a PE image")

    with path.open("rb") as stream:
        with mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data:
            if _slice(data, 0, 2, "DOS signature") != b"MZ":
                raise ValueError("missing MZ signature")

            pe_offset = _read_u32(data, 0x3C, "e_lfanew")
            if pe_offset + 4 + 20 > len(data):
                raise ValueError("e_lfanew points outside the file")
            if _slice(data, pe_offset, 4, "PE signature") != b"PE\0\0":
                raise ValueError("missing PE signature")

            file_header = pe_offset + 4
            machine = _read_u16(data, file_header, "machine")
            section_count = _read_u16(data, file_header + 2, "section count")
            timestamp = _read_u32(data, file_header + 4, "timestamp")
            optional_size = _read_u16(data, file_header + 16, "optional header size")
            optional = file_header + 20
            if optional + optional_size > len(data):
                raise ValueError("optional header extends outside the file")

            magic = _read_u16(data, optional, "optional header magic")
            if magic not in (0x10B, 0x20B):
                raise ValueError(f"unsupported optional header magic 0x{magic:X}")
            size_of_image = _read_u32(data, optional + 56, "SizeOfImage")
            size_of_headers = _read_u32(data, optional + 60, "SizeOfHeaders")
            if size_of_image == 0 or size_of_headers == 0:
                raise ValueError("PE image/header sizes must be non-zero")

            section_table = optional + optional_size
            sections: list[PeSection] = []
            for index in range(section_count):
                entry = section_table + index * 40
                if entry + 40 > len(data):
                    raise ValueError("section table extends outside the file")
                raw_name = _slice(data, entry, 8, "section name")
                name = raw_name.split(b"\0", 1)[0].decode("ascii", errors="replace")
                virtual_size = _read_u32(data, entry + 8, "section virtual size")
                virtual_address = _read_u32(data, entry + 12, "section RVA")
                raw_size = _read_u32(data, entry + 16, "section raw size")
                raw_pointer = _read_u32(data, entry + 20, "section raw pointer")
                if raw_pointer + raw_size > len(data):
                    raise ValueError(f"section {name!r} extends outside the file")
                sections.append(
                    PeSection(
                        name=name,
                        virtual_size=virtual_size,
                        virtual_address=virtual_address,
                        raw_size=raw_size,
                        raw_pointer=raw_pointer,
                    )
                )

            text_hash: str | None = None
            for section in sections:
                if section.name.lower() == ".text" and section.raw_size:
                    text_hash = hashlib.sha256(
                        _slice(
                            data,
                            section.raw_pointer,
                            section.raw_size,
                            ".text section",
                        )
                    ).hexdigest()
                    break

            return PeInfo(
                path=path,
                file_size=file_size,
                size_of_image=size_of_image,
                size_of_headers=size_of_headers,
                timestamp=timestamp,
                machine=machine,
                sections=tuple(sections),
                text_sha256=text_hash,
            )


def describe_module(path: Path) -> dict[str, Any]:
    """Return the portable identity fields used by a manifest module entry."""

    info = inspect_pe(path)
    result: dict[str, Any] = {
        "size": info.size_of_image,
        "pe_timestamp": f"0x{info.timestamp:08X}",
    }
    if info.text_sha256:
        result["text_sha256"] = info.text_sha256
    return result


def inspect_isil(root: Path, *, count_entries: bool = False) -> IsilInfo:
    """Inspect an ISIL reference tree for build identity and optional indexes.

    ISIL text is a semantic/disassembly reference, not a raw PE image. This
    routine therefore reports what can be established from the text and leaves
    byte-pattern generation to the separate module-backed validator.
    """

    root = root.resolve()
    if not root.is_dir():
        raise ValueError(f"ISIL root is not a directory: {root}")

    build_files = sorted(
        path for path in root.rglob("Build.txt") if "EFT" in path.parts
    )
    if not build_files:
        build_files = sorted(root.rglob("Build.txt"))
    version_files = sorted(
        path for path in root.rglob("Version.txt") if "EFT" in path.parts
    )
    if not version_files:
        version_files = sorted(root.rglob("Version.txt"))

    build_version: str | None = None
    evidence: list[str] = []
    for path in build_files:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        match = ISIL_BUILD_RE.search(text)
        if match:
            build_version = match.group(1)
            evidence.append(str(path.relative_to(root)))
            break

    if build_version is None:
        for path in version_files:
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            match = ISIL_VERSION_RE.search(text)
            if match:
                build_version = match.group(1)
                evidence.append(str(path.relative_to(root)))
                break

    type_count = 0
    method_count = 0
    if count_entries:
        for path in root.rglob("*.txt"):
            try:
                with path.open("r", encoding="utf-8", errors="replace") as stream:
                    for line in stream:
                        if line.startswith("Type:"):
                            type_count += 1
                        elif line.startswith("Method:"):
                            method_count += 1
            except OSError:
                continue

    return IsilInfo(
        root=root,
        build_version=build_version,
        build_evidence=tuple(evidence),
        type_count=type_count,
        method_count=method_count,
    )


def parse_legacy_cfg(path: Path) -> tuple[dict[str, str], list[Issue]]:
    """Parse a legacy key=value file with useful diagnostics.

    The old runtime parser accepted almost anything containing '='. This
    importer is intentionally stricter so malformed profiles are not silently
    converted into a manifest.
    """

    values: dict[str, str] = {}
    issues: list[Issue] = []
    try:
        lines = path.read_text(encoding="utf-8-sig").splitlines()
    except OSError as exc:
        return {}, [issue("error", str(path), f"cannot read file: {exc}")]

    for line_number, raw_line in enumerate(lines, 1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            issues.append(issue("error", f"{path}:{line_number}", "expected key=value"))
            continue

        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if "#" in value:
            value = value.split("#", 1)[0].rstrip()
        if not key:
            issues.append(issue("error", f"{path}:{line_number}", "empty key"))
            continue
        if key in values:
            issues.append(issue("error", f"{path}:{line_number}", f"duplicate key {key!r}"))
            continue
        values[key] = value

    return values, issues


def parse_unsigned(value: str, field: str) -> int | None:
    value = value.strip()
    if not value:
        return None
    if not RVA_RE.fullmatch(value):
        raise ValueError(f"{field} must be a non-negative decimal or 0x value")
    parsed = int(value, 0)
    if parsed < 0 or parsed > MAX_U64:
        raise ValueError(f"{field} does not fit in an unsigned 64-bit value")
    return parsed


def canonical_rva(value: int | None) -> str | None:
    return None if value is None else f"0x{value:X}"


def parse_pattern(pattern: str) -> tuple[int | None, ...]:
    """Parse whole-byte wildcards (`?` or `??`) into a mask-independent tuple."""

    tokens = pattern.strip().split()
    if not tokens:
        raise ValueError("pattern is empty")

    result: list[int | None] = []
    for token in tokens:
        if token in ("?", "??"):
            result.append(None)
            continue
        if not HEX_BYTE_RE.fullmatch(token):
            raise ValueError(f"invalid pattern token {token!r}")
        result.append(int(token, 16))
    return tuple(result)


def format_pattern(pattern: Sequence[int | None]) -> str:
    return " ".join("?" if value is None else f"{value:02X}" for value in pattern)


def _pattern_matches_at(data: mmap.mmap | bytes, offset: int, pattern: Sequence[int | None]) -> bool:
    if offset < 0 or offset + len(pattern) > len(data):
        return False
    for index, expected in enumerate(pattern):
        if expected is not None and data[offset + index] != expected:
            return False
    return True


def rva_to_file_offset(info: PeInfo, rva: int, length: int = 1) -> int | None:
    if rva < 0 or length < 0 or rva + length > info.size_of_image:
        return None

    if rva < info.size_of_headers:
        return rva if rva + length <= info.file_size else None

    for section in info.sections:
        span = max(section.virtual_size, section.raw_size)
        if not span or not (section.virtual_address <= rva < section.virtual_address + span):
            continue
        delta = rva - section.virtual_address
        if delta + length > section.raw_size:
            return None
        file_offset = section.raw_pointer + delta
        if file_offset + length <= info.file_size:
            return file_offset
    return None


def read_rva(data: mmap.mmap, info: PeInfo, rva: int, length: int) -> bytes | None:
    file_offset = rva_to_file_offset(info, rva, length)
    if file_offset is None:
        return None
    return _slice(data, file_offset, length, "RVA data")


def find_pattern_matches(
    data: mmap.mmap,
    info: PeInfo,
    pattern: Sequence[int | None],
    limit: int = 10000,
) -> tuple[list[int], bool]:
    """Return matching RVAs and whether the result hit the safety limit."""

    if not pattern or limit <= 0:
        return [], False

    matches: list[int] = []
    truncated = False
    for section in info.sections:
        if section.raw_size < len(pattern):
            continue
        start = section.raw_pointer
        end = start + section.raw_size
        anchor_index = next((i for i, value in enumerate(pattern) if value is not None), None)

        if anchor_index is None:
            candidates: Iterable[int] = range(start, end - len(pattern) + 1)
            for candidate in candidates:
                if _pattern_matches_at(data, candidate, pattern):
                    matches.append(section.virtual_address + candidate - start)
                    if len(matches) >= limit:
                        truncated = True
                        break
        else:
            anchor = bytes([pattern[anchor_index] or 0])
            candidate = data.find(anchor, start, end)
            while candidate != -1:
                match_start = candidate - anchor_index
                if (
                    match_start >= start
                    and match_start + len(pattern) <= end
                    and _pattern_matches_at(data, match_start, pattern)
                ):
                    matches.append(section.virtual_address + match_start - start)
                    if len(matches) >= limit:
                        truncated = True
                        break
                candidate = data.find(anchor, candidate + 1, end)

        if truncated:
            break

    return matches, truncated


def _module_for_legacy_name(name: str, default_module: str) -> str:
    if name == "be_service_check":
        return UNITY_PLAYER_MODULE
    if name in LEGACY_GAME_ASSEMBLY_KEYS:
        # hwid_check is read by feature/spoofer.cpp via globals::get_offset()
        # and pattern_cfg.get(), and the result is scanned against a dumped
        # GameAssembly image, so it belongs to GameAssembly.dll. It is listed
        # explicitly rather than relying on the --default-module fallback so a
        # non-default default-module cannot silently misplace it.
        return GAME_ASSEMBLY_MODULE
    if name.startswith(LEGACY_IL2CPP_PREFIX):
        return GAME_ASSEMBLY_MODULE
    if name.startswith(LEGACY_LAUNCHER_PREFIXES):
        return GAME_ASSEMBLY_MODULE
    return default_module


def _kind_for_legacy_name(name: str) -> str:
    if name.endswith("_offset") or name.endswith("_rva"):
        return "data"
    return "function"


def _required_for_legacy_name(name: str) -> bool:
    # The legacy launcher entries are optional for the core profile. A caller
    # that enables a launcher-only feature can promote them to required after
    # supplying a resolver and validation data.
    return name.startswith(LEGACY_IL2CPP_PREFIX)


def _default_profile_id(game_version: str) -> str:
    normalized = re.sub(r"[^A-Za-z0-9._-]+", "-", game_version.strip()).strip("-.")
    return f"eft-{normalized}" if normalized else ""


def build_manifest(
    offsets: dict[str, str],
    patterns: dict[str, str],
    *,
    profile_id: str,
    game_version: str,
    source_commit: str = "",
    default_module: str = GAME_ASSEMBLY_MODULE,
    isil_info: IsilInfo | None = None,
    clear_rvas: bool = False,
    architecture: str = "x64",
    status: str = "unverified",
) -> tuple[dict[str, Any], list[Issue]]:
    """Build a manifest from already parsed legacy values."""

    issues: list[Issue] = []
    if isil_info and isil_info.build_version and game_version == "unknown":
        game_version = isil_info.build_version
    if not profile_id:
        profile_id = _default_profile_id(game_version)
    if not PROFILE_ID_RE.fullmatch(profile_id):
        issues.append(issue("error", "profile.id", "must contain only letters, digits, '.', '_' or '-'"))
    if not game_version.strip():
        issues.append(issue("error", "profile.game_version", "must not be empty"))
    if architecture not in {"x64", "x86"}:
        issues.append(issue("error", "profile.architecture", "must be x64 or x86"))
    if status not in {"unverified", "staged", "validated", "verified"}:
        issues.append(issue("error", "profile.status", "invalid profile status"))

    names = sorted(set(offsets) | set(patterns))
    symbols: list[dict[str, Any]] = []
    referenced_modules: set[str] = set()

    for name in names:
        module = _module_for_legacy_name(name, default_module)
        referenced_modules.add(module)
        try:
            rva = parse_unsigned(offsets.get(name, ""), f"offsets.{name}")
        except ValueError as exc:
            issues.append(issue("error", f"offsets.{name}", str(exc)))
            rva = None

        raw_pattern = patterns.get(name, "").strip()
        parsed_patterns: list[str] = []
        if raw_pattern:
            for candidate in raw_pattern.split("||"):
                candidate = candidate.strip()
                if not candidate:
                    continue
                try:
                    parse_pattern(candidate)
                except ValueError as exc:
                    issues.append(issue("error", f"patterns.{name}", str(exc)))
                    continue
                parsed_patterns.append(format_pattern(parse_pattern(candidate)))

        if name.startswith(LEGACY_IL2CPP_PREFIX):
            fallback = "pattern" if parsed_patterns else "export"
            resolver = "pattern" if parsed_patterns else "export"
            resolution_order = ["pattern", "export"] if parsed_patterns else ["export"]
        else:
            fallback = "pattern" if parsed_patterns else "none"
            resolver = "pattern" if parsed_patterns else "native"
            resolution_order = ["pattern"] if parsed_patterns else ["native"]

        symbol: dict[str, Any] = {
            "name": name,
            "module": module,
            "kind": _kind_for_legacy_name(name),
            "resolver": resolver,
            "rva": None if clear_rvas else canonical_rva(rva),
            "patterns": parsed_patterns,
            "required": _required_for_legacy_name(name),
            "fallback": fallback,
            "resolution_order": resolution_order,
            "source": "legacy-cfg-import",
            "notes": "Imported from offsets.cfg/patterns.cfg; validate against the intended module build.",
        }
        if resolver == "export":
            symbol["export_name"] = name
        symbols.append(symbol)

    manifest: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "profile": {
            "id": profile_id,
            "game_version": game_version,
            "architecture": architecture,
            "status": status,
        },
        "modules": {
            module: {"notes": "Module metadata was not collected during import."}
            for module in sorted(referenced_modules)
        },
        "symbols": symbols,
    }
    if source_commit:
        manifest["profile"]["source_commit"] = source_commit
    if isil_info:
        manifest["profile"]["provenance"] = {
            "source_kind": "legacy-cfg+isil",
            "isil_reference": isil_info.root.name,
            "notes": "Build identity and semantic references were read from the ISIL tree; native bytes still require module validation.",
        }
        if isil_info.build_evidence:
            manifest["profile"]["provenance"]["notes"] += " Evidence: " + ", ".join(isil_info.build_evidence) + "."
    return manifest, issues


def _module_path(module_dir: Path | None, module: str) -> Path:
    path = Path(module)
    return path if path.is_absolute() or module_dir is None else module_dir / path


def _compare_module_metadata(
    issues: list[Issue],
    path: str,
    descriptor: dict[str, Any],
    info: PeInfo,
) -> None:
    expected_size = descriptor.get("size")
    if expected_size is not None and expected_size != info.size_of_image:
        issues.append(
            issue(
                "error",
                f"{path}.size",
                f"expected SizeOfImage {expected_size}, found {info.size_of_image}",
            )
        )

    expected_timestamp = descriptor.get("pe_timestamp")
    if expected_timestamp is not None:
        actual_timestamp = f"0x{info.timestamp:08X}"
        if expected_timestamp.lower() != actual_timestamp.lower():
            issues.append(
                issue(
                    "error",
                    f"{path}.pe_timestamp",
                    f"expected {expected_timestamp}, found {actual_timestamp}",
                )
            )

    expected_hash = descriptor.get("text_sha256")
    if expected_hash is not None and info.text_sha256 is not None:
        if expected_hash.lower() != info.text_sha256.lower():
            issues.append(
                issue(
                    "error",
                    f"{path}.text_sha256",
                    "the .text section hash does not match",
                )
            )


def validate_manifest(
    manifest: Any,
    *,
    module_dir: Path | None = None,
    strict: bool = False,
) -> list[Issue]:
    """Validate structure and, when module files are available, PE metadata."""

    issues: list[Issue] = []
    if not isinstance(manifest, dict):
        return [issue("error", "$", "manifest root must be an object")]

    allowed_top = {"schema_version", "profile", "modules", "symbols"}
    unknown_top = set(manifest) - allowed_top
    for key in sorted(unknown_top):
        issues.append(issue("error", key, "unknown top-level field"))
    for key in ("schema_version", "profile", "modules", "symbols"):
        if key not in manifest:
            issues.append(issue("error", key, "required field is missing"))

    if manifest.get("schema_version") != SCHEMA_VERSION:
        issues.append(issue("error", "schema_version", f"expected {SCHEMA_VERSION}"))

    profile = manifest.get("profile")
    if not isinstance(profile, dict):
        issues.append(issue("error", "profile", "must be an object"))
    else:
        allowed_profile = {
            "id",
            "game_version",
            "architecture",
            "status",
            "source_commit",
            "provenance",
            "notes",
        }
        for key in sorted(set(profile) - allowed_profile):
            issues.append(issue("error", f"profile.{key}", "unknown field"))
        profile_id = profile.get("id")
        if not isinstance(profile_id, str) or not PROFILE_ID_RE.fullmatch(profile_id):
            issues.append(issue("error", "profile.id", "invalid profile id"))
        if not isinstance(profile.get("game_version"), str) or not profile["game_version"].strip():
            issues.append(issue("error", "profile.game_version", "must be a non-empty string"))
        architecture = profile.get("architecture", "x64")
        if architecture not in {"x64", "x86"}:
            issues.append(issue("error", "profile.architecture", "must be x64 or x86"))
        status = profile.get("status", "unverified")
        if status not in {"unverified", "staged", "validated", "verified"}:
            issues.append(issue("error", "profile.status", "invalid profile status"))
        provenance = profile.get("provenance")
        if provenance is not None:
            if not isinstance(provenance, dict):
                issues.append(issue("error", "profile.provenance", "must be an object"))
            else:
                allowed_provenance = {"source_kind", "isil_reference", "verified_at", "notes"}
                for key in sorted(set(provenance) - allowed_provenance):
                    issues.append(issue("error", f"profile.provenance.{key}", "unknown field"))
                for key in ("source_kind", "isil_reference", "verified_at", "notes"):
                    if key in provenance and not isinstance(provenance[key], str):
                        issues.append(issue("error", f"profile.provenance.{key}", "must be a string"))

    modules = manifest.get("modules")
    module_names: set[str] = set()
    if not isinstance(modules, dict):
        issues.append(issue("error", "modules", "must be an object"))
        modules = {}
    else:
        allowed_module = {"size", "pe_timestamp", "text_sha256", "notes"}
        for module_name, descriptor in modules.items():
            path = f"modules.{module_name}"
            module_names.add(module_name)
            if not isinstance(module_name, str) or not module_name:
                issues.append(issue("error", path, "module name must be non-empty"))
            if not isinstance(descriptor, dict):
                issues.append(issue("error", path, "module descriptor must be an object"))
                continue
            for key in sorted(set(descriptor) - allowed_module):
                issues.append(issue("error", f"{path}.{key}", "unknown field"))
            size = descriptor.get("size")
            if size is not None and (not isinstance(size, int) or isinstance(size, bool) or size <= 0):
                issues.append(issue("error", f"{path}.size", "must be a positive integer"))
            timestamp = descriptor.get("pe_timestamp")
            if timestamp is not None and (
                not isinstance(timestamp, str) or not re.fullmatch(r"0x[0-9A-Fa-f]+", timestamp)
            ):
                issues.append(issue("error", f"{path}.pe_timestamp", "must be a 0x-prefixed string"))
            text_hash = descriptor.get("text_sha256")
            if text_hash is not None and (
                not isinstance(text_hash, str) or not SHA256_RE.fullmatch(text_hash)
            ):
                issues.append(issue("error", f"{path}.text_sha256", "must be a 64-character hex hash"))

    symbols = manifest.get("symbols")
    seen_names: set[str] = set()
    if not isinstance(symbols, list):
        issues.append(issue("error", "symbols", "must be an array"))
        symbols = []

    module_info_cache: dict[str, PeInfo | None] = {}
    module_data: dict[str, mmap.mmap] = {}
    try:
        for index, symbol in enumerate(symbols):
            path = f"symbols[{index}]"
            if not isinstance(symbol, dict):
                issues.append(issue("error", path, "symbol must be an object"))
                continue
            allowed_symbol = {
                "name",
                "module",
                "kind",
                "resolver",
                "export_name",
                "managed",
                "resolution_order",
                "rva",
                "patterns",
                "required",
                "expected_matches",
                "fallback",
                "source",
                "notes",
            }
            for key in sorted(set(symbol) - allowed_symbol):
                issues.append(issue("error", f"{path}.{key}", "unknown field"))
            for required_key in ("name", "module", "kind", "rva", "patterns", "required"):
                if required_key not in symbol:
                    issues.append(issue("error", f"{path}.{required_key}", "required field is missing"))

            name = symbol.get("name")
            if not isinstance(name, str) or not name:
                issues.append(issue("error", f"{path}.name", "must be a non-empty string"))
            elif name in seen_names:
                issues.append(issue("error", f"{path}.name", f"duplicate symbol {name!r}"))
            else:
                seen_names.add(name)

            module = symbol.get("module")
            if not isinstance(module, str) or not module:
                issues.append(issue("error", f"{path}.module", "must be a non-empty string"))
                module = ""
            elif module not in module_names:
                issues.append(issue("error", f"{path}.module", f"module {module!r} is not declared"))

            if symbol.get("kind") not in {"function", "data", "unknown"}:
                issues.append(issue("error", f"{path}.kind", "must be function, data, or unknown"))
            resolver = symbol.get("resolver", "native")
            if resolver not in {"native", "pattern", "export", "managed"}:
                issues.append(issue("error", f"{path}.resolver", "must be native, pattern, export, or managed"))
            if "export_name" in symbol and (
                not isinstance(symbol["export_name"], str) or not symbol["export_name"]
            ):
                issues.append(issue("error", f"{path}.export_name", "must be a non-empty string"))
            managed = symbol.get("managed")
            if resolver == "managed":
                if not isinstance(managed, dict):
                    issues.append(issue("error", f"{path}.managed", "managed resolver requires a managed reference"))
                else:
                    allowed_managed = {
                        "assembly",
                        "namespace",
                        "type",
                        "member",
                        "member_kind",
                        "argument_count",
                        "declaring_type",
                    }
                    for key in sorted(set(managed) - allowed_managed):
                        issues.append(issue("error", f"{path}.managed.{key}", "unknown field"))
                    for key in ("assembly", "namespace", "type", "member", "member_kind"):
                        if key not in managed:
                            issues.append(issue("error", f"{path}.managed.{key}", "required field is missing"))
                        elif not isinstance(managed[key], str):
                            issues.append(issue("error", f"{path}.managed.{key}", "must be a string"))
                    if managed.get("member_kind") not in {"field", "method", "property"}:
                        issues.append(issue("error", f"{path}.managed.member_kind", "must be field, method, or property"))
                    argument_count = managed.get("argument_count")
                    if argument_count is not None and (
                        not isinstance(argument_count, int)
                        or isinstance(argument_count, bool)
                        or argument_count < 0
                    ):
                        issues.append(issue("error", f"{path}.managed.argument_count", "must be an integer >= 0"))
            elif managed is not None:
                issues.append(issue("error", f"{path}.managed", "managed reference requires resolver=managed"))
            resolution_order = symbol.get("resolution_order")
            if resolution_order is not None:
                if not isinstance(resolution_order, list):
                    issues.append(issue("error", f"{path}.resolution_order", "must be an array"))
                else:
                    for order_index, order in enumerate(resolution_order):
                        if order not in {"rva", "pattern", "export", "managed", "native"}:
                            issues.append(issue("error", f"{path}.resolution_order[{order_index}]", "invalid resolver"))
            if not isinstance(symbol.get("required"), bool):
                issues.append(issue("error", f"{path}.required", "must be boolean"))
            fallback = symbol.get("fallback")
            if fallback is not None and fallback not in {"pattern", "export", "none"}:
                issues.append(issue("error", f"{path}.fallback", "must be pattern, export, or none"))

            rva: int | None = None
            raw_rva = symbol.get("rva")
            if raw_rva is not None:
                if not isinstance(raw_rva, str) or not RVA_RE.fullmatch(raw_rva):
                    issues.append(issue("error", f"{path}.rva", "must be null or an unsigned numeric string"))
                else:
                    try:
                        rva = parse_unsigned(raw_rva, f"{path}.rva")
                    except ValueError as exc:
                        issues.append(issue("error", f"{path}.rva", str(exc)))

            parsed_patterns: list[tuple[int | None, ...]] = []
            raw_patterns = symbol.get("patterns")
            if not isinstance(raw_patterns, list):
                issues.append(issue("error", f"{path}.patterns", "must be an array"))
            else:
                for pattern_index, raw_pattern in enumerate(raw_patterns):
                    if not isinstance(raw_pattern, str):
                        issues.append(issue("error", f"{path}.patterns[{pattern_index}]", "must be a string"))
                        continue
                    try:
                        parsed_patterns.append(parse_pattern(raw_pattern))
                    except ValueError as exc:
                        issues.append(issue("error", f"{path}.patterns[{pattern_index}]", str(exc)))

            expected_matches = symbol.get("expected_matches", 1)
            if not isinstance(expected_matches, int) or isinstance(expected_matches, bool) or expected_matches < 1:
                issues.append(issue("error", f"{path}.expected_matches", "must be an integer >= 1"))
            if resolver == "native" and rva is None and not parsed_patterns:
                issues.append(
                    issue(
                        "warning",
                        path,
                        "native symbol has no manifest RVA or pattern; it depends on an external/built-in resolver",
                    )
                )

            if not module or module not in module_names:
                continue
            descriptor = modules.get(module, {})
            if not isinstance(descriptor, dict):
                continue
            if not descriptor.get("size") and strict:
                issues.append(issue("error", f"modules.{module}", "strict validation requires SizeOfImage metadata"))
            if module_dir is None:
                if rva is not None or parsed_patterns:
                    issues.append(
                        issue(
                            "warning",
                            path,
                            "not statically verified; supply --module-dir to check the PE file",
                        )
                    )
                continue

            if module not in module_info_cache:
                module_path = _module_path(module_dir, module)
                try:
                    module_info_cache[module] = inspect_pe(module_path)
                    with module_path.open("rb") as stream:
                        module_data[module] = mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ)
                except (OSError, ValueError) as exc:
                    module_info_cache[module] = None
                    issues.append(issue("error", f"modules.{module}", f"cannot inspect {module_path}: {exc}"))
            info = module_info_cache[module]
            if info is None:
                continue
            _compare_module_metadata(issues, f"modules.{module}", descriptor, info)
            data = module_data[module]

            if rva is not None:
                if rva >= info.size_of_image:
                    issues.append(issue("error", f"{path}.rva", "RVA is outside SizeOfImage"))
                elif parsed_patterns:
                    primary = parsed_patterns[0]
                    if read_rva(data, info, rva, len(primary)) is None or not _pattern_matches_at(
                        data,
                        rva_to_file_offset(info, rva, len(primary)) or 0,
                        primary,
                    ):
                        issues.append(issue("error", f"{path}.rva", "configured RVA does not match its first pattern"))

            if parsed_patterns:
                all_matches: set[int] = set()
                for pattern in parsed_patterns:
                    matches, truncated = find_pattern_matches(data, info, pattern, limit=expected_matches + 1)
                    all_matches.update(matches)
                    if truncated:
                        issues.append(issue("warning", f"{path}.patterns", "pattern match search hit its safety limit"))
                if not all_matches:
                    issues.append(issue("error", f"{path}.patterns", "no pattern match found in the supplied module"))
                elif len(all_matches) > expected_matches:
                    message = f"found {len(all_matches)} matches; expected at most {expected_matches}"
                    issues.append(issue("error" if strict else "warning", f"{path}.patterns", message))
                if rva is not None and rva not in all_matches:
                    issues.append(issue("error", f"{path}.rva", "RVA is not among the pattern matches"))
    finally:
        for data in module_data.values():
            data.close()

    if strict:
        issues = [
            issue("error", item.path, item.message) if item.severity == "warning" else item
            for item in issues
        ]

    return issues


def _load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except OSError as exc:
        raise ValueError(f"cannot read {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON in {path}: {exc}") from exc


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _print_issues(issues: Sequence[Issue]) -> None:
    for item in issues:
        print(item.format())


def _import_command(args: argparse.Namespace) -> int:
    offsets, offset_issues = parse_legacy_cfg(Path(args.offsets))
    patterns, pattern_issues = parse_legacy_cfg(Path(args.patterns))
    issues = [*offset_issues, *pattern_issues]
    if issues:
        _print_issues(issues)
        return 2

    isil_info: IsilInfo | None = None
    if args.isil_root:
        try:
            isil_info = inspect_isil(Path(args.isil_root))
        except (OSError, ValueError) as exc:
            print(f"ERROR --isil-root: {exc}")
            return 2

    manifest, build_issues = build_manifest(
        offsets,
        patterns,
        profile_id=args.profile_id,
        game_version=args.game_version,
        source_commit=args.source_commit,
        default_module=args.default_module,
        isil_info=isil_info,
        clear_rvas=args.clear_rvas,
        architecture=args.architecture,
    )
    issues.extend(build_issues)
    if issues:
        _print_issues(issues)
        return 2

    module_dir = Path(args.module_dir) if args.module_dir else None
    if module_dir:
        for module in list(manifest["modules"]):
            module_path = _module_path(module_dir, module)
            try:
                manifest["modules"][module] = describe_module(module_path)
            except (OSError, ValueError) as exc:
                print(f"ERROR modules.{module}: cannot inspect {module_path}: {exc}")
                return 2

    output = Path(args.output)
    validation_issues = validate_manifest(manifest, module_dir=module_dir, strict=args.strict)
    has_errors = any(item.severity == "error" for item in validation_issues)
    has_warnings = any(item.severity == "warning" for item in validation_issues)
    if module_dir and not has_errors and not has_warnings:
        manifest["profile"]["status"] = "validated"
        if "provenance" in manifest["profile"]:
            manifest["profile"]["provenance"]["notes"] += " Static PE/pattern validation passed."
    elif module_dir and not has_errors:
        manifest["profile"]["status"] = "staged"
    _write_json(output, manifest)
    _print_issues(validation_issues)
    if has_errors:
        return 1
    print(f"Wrote {output} ({len(manifest['symbols'])} symbols; status={manifest['profile']['status']})")
    return 0


def _inspect_isil_command(args: argparse.Namespace) -> int:
    try:
        info = inspect_isil(Path(args.isil_root), count_entries=not args.no_count)
    except (OSError, ValueError) as exc:
        print(f"ERROR {exc}")
        return 2

    result = {
        "root": str(info.root),
        "build_version": info.build_version,
        "build_evidence": list(info.build_evidence),
        "type_count": info.type_count,
        "method_count": info.method_count,
        "limitations": [
            "ISIL text identifies semantic types/methods and build metadata.",
            "It does not provide a complete raw PE image for byte-pattern generation.",
        ],
    }
    if args.output:
        _write_json(Path(args.output), result)
        print(f"Wrote {args.output}")
    else:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if info.build_version else 1


def _validate_command(args: argparse.Namespace) -> int:
    try:
        manifest = _load_json(Path(args.manifest))
    except ValueError as exc:
        print(f"ERROR {exc}")
        return 2

    issues = validate_manifest(
        manifest,
        module_dir=Path(args.module_dir) if args.module_dir else None,
        strict=args.strict,
    )
    _print_issues(issues)
    if any(item.severity == "error" for item in issues):
        return 1
    print("Manifest validation passed")
    return 0


def _update_rvas_command(args: argparse.Namespace) -> int:
    try:
        manifest_path = Path(args.manifest)
        manifest = _load_json(manifest_path)
        rvas = _load_json(Path(args.rvas))
    except ValueError as exc:
        print(f"ERROR {exc}")
        return 2

    if not isinstance(rvas, dict):
        print("ERROR --rvas must be a JSON object mapping symbol names to hex RVA strings")
        return 2
    if not isinstance(manifest, dict):
        print(f"ERROR {manifest_path}: manifest root must be an object")
        return 2

    symbols: dict[str, Any] = {}
    for entry in manifest.get("symbols", []):
        if not isinstance(entry, dict) or not isinstance(entry.get("name"), str):
            print(f"ERROR {manifest_path}: every symbol needs a string 'name'; fix the manifest first")
            return 2
        symbols[entry["name"]] = entry

    # An unknown name means the manifest under-records what the caller just
    # confirmed, so the file must not be written: a partial update that still
    # prints "Updated N symbol(s)" and exits 0 is how a confirmed address ends
    # up recorded nowhere. The names are reported all at once because the usual
    # cause is a stale list rather than a single typo.
    unknown = sorted(name for name in rvas if name not in symbols)
    if unknown and not args.allow_unknown:
        print(f"ERROR {len(unknown)} requested symbol(s) are not in {manifest_path.name}:")
        for name in unknown:
            print(f"  - {name}")
        print(
            "Nothing was written. Either re-import the manifest from the legacy cfg files "
            "(so the symbol exists) or pass --allow-unknown to record only the known subset."
        )
        return 1

    updated = 0
    for name, rva_str in rvas.items():
        if name not in symbols:
            print(f"WARN skipping unknown symbol {name!r} (--allow-unknown)")
            continue
        rva = parse_unsigned(rva_str, f"rvas.{name}")
        symbols[name]["rva"] = canonical_rva(rva)
        symbols[name]["source"] = args.source
        symbols[name]["notes"] = f"RVA confirmed by {args.source} against {symbols[name]['module']}."
        updated += 1

    if updated == 0:
        print("WARNING no symbols were updated")
        return 1

    manifest["symbols"] = list(symbols.values())
    # Same writer as `import`: json.dumps without ensure_ascii=False would escape
    # non-ASCII that `import` writes through verbatim, so the two commands would
    # disagree byte-for-byte about the same manifest.
    _write_json(manifest_path, manifest)
    print(f"Updated {updated} symbol(s) in {manifest_path}")
    return 0


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    importer = subparsers.add_parser("import", help="convert legacy cfg files to a manifest")
    importer.add_argument("--offsets", required=True, help="path to offsets.cfg")
    importer.add_argument("--patterns", required=True, help="path to patterns.cfg")
    importer.add_argument("--output", required=True, help="output manifest path")
    importer.add_argument(
        "--profile-id",
        default="",
        help="profile identifier; derived from --game-version/ISIL build when omitted",
    )
    importer.add_argument("--game-version", default="unknown", help="human-readable game build")
    importer.add_argument("--source-commit", default="", help="optional source commit recorded in the profile")
    importer.add_argument(
        "--isil-root",
        help="optional ISIL reference root used to detect build identity and record provenance",
    )
    importer.add_argument(
        "--clear-rvas",
        action="store_true",
        help="do not copy legacy RVAs into a new profile; retain patterns as candidates only",
    )
    importer.add_argument(
        "--architecture",
        choices=("x64", "x86"),
        default="x64",
        help="target architecture for the profile",
    )
    importer.add_argument(
        "--module-dir",
        help="optional directory containing GameAssembly.dll/UnityPlayer.dll for metadata",
    )
    importer.add_argument(
        "--default-module",
        default=GAME_ASSEMBLY_MODULE,
        help="module used for unknown legacy keys",
    )
    importer.add_argument(
        "--strict",
        action="store_true",
        help="treat validation warnings and missing module metadata as errors",
    )
    importer.set_defaults(handler=_import_command)

    isil = subparsers.add_parser("inspect-isil", help="report build identity and ISIL coverage")
    isil.add_argument("isil_root", help="ISIL reference root")
    isil.add_argument("--output", help="optional JSON report path")
    isil.add_argument(
        "--no-count",
        action="store_true",
        help="skip counting Type:/Method: entries across the reference tree",
    )
    isil.set_defaults(handler=_inspect_isil_command)

    validator = subparsers.add_parser("validate", help="validate a manifest and optional PE files")
    validator.add_argument("manifest", help="manifest JSON path")
    validator.add_argument(
        "--module-dir",
        help="directory containing the modules referenced by the manifest",
    )
    validator.add_argument(
        "--strict",
        action="store_true",
        help="treat warnings and missing module metadata as errors",
    )
    validator.set_defaults(handler=_validate_command)

    updater = subparsers.add_parser("update-rvas", help="inject confirmed RVAs into a manifest from a JSON mapping")
    updater.add_argument("manifest", help="manifest JSON path")
    updater.add_argument("--rvas", required=True, help="JSON file mapping symbol names to hex RVA strings")
    updater.add_argument("--source", default="ida-pattern-scan", help="provenance source label to record")
    updater.add_argument(
        "--allow-unknown",
        action="store_true",
        help=(
            "record the known subset instead of failing when a requested symbol is absent "
            "from the manifest (it will be reported on stderr-style output and skipped)"
        ),
    )
    updater.set_defaults(handler=_update_rvas_command)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = make_parser()
    args = parser.parse_args(argv)
    return int(args.handler(args))


if __name__ == "__main__":
    raise SystemExit(main())
