#!/usr/bin/env python3
"""Parse Tracy profiling archives without materializing giant CSVs.

TracyClient saves profiles as ZIP archives containing an SQLite database
plus per-sample CSVs. The CSVs are redundant: columnar SQLite queries are
faster and use orders of magnitude less memory.

Usage:
    python tracy_parser.py archive.tracy
    python tracy_parser.py --zip path/to/tracy.zip
    python tracy_parser.py --out reports/ input.tracy

Supports:
    SQLite-based Tracy profiles (default)
    ZSTD-compressed archives
    Plain ZIP archives
"""

import argparse
import gzip
import hashlib
import io
import json
import os
import sqlite3
import sys
import zipfile
from pathlib import Path

try:
    import zstandard as zstd
    HAS_ZSTD = True
except ImportError:
    HAS_ZSTD = False


def detect_archive(path):
    """Detect archive format from magic bytes."""
    with open(path, "rb") as f:
        magic = f.read(8)
    if magic[:2] == b"FD\nS":
        return "zstd"
    if magic == b"PK\x03\x04":
        return "zip"
    return "unknown"


def open_archive(path):
    """Open archive and yield (zipfile, close_zip)."""
    arch = detect_archive(path)
    if arch == "zstd":
        if not HAS_ZSTD:
            print("zstd archives need: pip install zstandard", file=sys.stderr)
            sys.exit(1)
        dctx = zstd.ZstdDecompressor()
        with open(path, "rb") as f:
            dz = dctx.stream_reader(f)
            return zipfile.ZipFile(dz, "r"), True
    elif arch == "zip":
        return zipfile.ZipFile(path, "r"), False
    else:
        print(f"unsupported archive: {arch}", file=sys.stderr)
        sys.exit(1)


def find_tracy_sqlite(zip):
    """Find tracy.sqlite3 inside the archive."""
    names = [n for n in zip.namelist() if n.endswith(".sqlite3")]
    if not names:
        # Older Tracy may name it differently
        names = [n for n in zip.namelist() if "tracy" in n.lower() and n.endswith((".db",".sqlite"))]
    if not names:
        return None
    return names[0]


def parse_sample_columns(cur):
    """Inspect the samples table and return useful column names."""
    cur.execute("PRAGMA table_info(samples)")
    cols = [{k: v for k, v in enumerate(info[1])} for info in cur.fetchall()]
    return cols


def query_cpu_profile(cur, limit=50):
    """Top CPU-consuming stacks."""
    sql = """
    SELECT s.function, s.line, s.source,
           COUNT(*) as samples,
           ROUND(100.0*COUNT(*)/ (SELECT COUNT(*) FROM samples),1) as share_pct
    FROM samples s
    GROUP BY s.function,s.line,s.source
    ORDER BY samples DESC
    LIMIT {lim}
    """.format(lim=limit)
    return cur.execute(sql).fetchall()


def query_frames(cur, limit=20):
    """Largest frame stacks by sample count."""
    sql = """
    SELECT f.name, f.line, f.column,
           COUNT(*) as samples
    FROM frames f
    GROUP BY f.name,f.line,f.column
    ORDER BY samples DESC
    LIMIT {lim}
    """.format(lim=limit)
    return cur.execute(sql).fetchall()


def query_events(cur, limit=30):
    """Event names and counts."""
    sql = "SELECT name, COUNT(*) as n FROM events GROUP BY name ORDER BY n DESC LIMIT ?"
    return cur.execute(sql, (limit,)).fetchall()


def report_archive_info(path, zip, sqlite_path):
    print(f"archive: {path}")
    print(f"format: {detect_archive(path)}")
    info = zip.get_info(sqlite_path)
    print(f"sqlite: {sqlite_path} ({info.file_size/1e6:.1f} MB)")
    print(f"total entries: {len(zip.namelist())}")
    big = sorted(
        [(n, info.file_size) for n, info in zip.infolist()],
        key=lambda x: x[1],
        reverse=True,
    )[:10]
    print("largest entries:")
    for n, sz in big:
        print(f"  {n[:60]:60} {sz/1e6:.1f} MB")


def main():
    parser = argparse.ArgumentParser(description="Parse Tracy profiling archives.")
    parser.add_argument("path", nargs="?", help="tracy file or zip")
    parser.add_argument("--zip", help="path to tracy.zip extracted from archive")
    parser.add_argument(
        "--query",
        choices=[
            "cpu",
            "frames",
            "events",
            "columns",
            "info",
        ],
        default="cpu",
    )
    parser.add_argument("--limit", type=int, default=50)
    parser.add_argument("--out", help="output JSON/CSV directory")
    args = parser.parse_args()

    if args.path and args.zip:
        sqlite_path = args.zip
        close_zip = False
    else:
        sqlite_path = find_tracy_sqlite(open_archive(args.path)[0])
        if not sqlite_path:
            print("could not locate tracy.sqlite3", file=sys.stderr)
            sys.exit(1)

    if args.query == "info":
        archive_path = args.path if args.path else sqlite_path
        zip_obj, close_zip = open_archive(archive_path)
        if sqlite_path.endswith(".zip"):
            spath = find_tracy_sqlite(zip_obj) or ""
        else:
            spath = sqlite_path
        report_archive_info(archive_path, zip_obj, spath)
        return

    cur = sqlite3.connect(":memory:")
    cur.execute(f"ATTACH DATABASE '{sqlite_path}' AS tracy")
    cur.execute("SELECT name FROM tracy.sqlite_master WHERE type='table'")
    tables = {row[0] for row in cur.fetchall()}

    if "samples" not in tables:
        print("samples table missing — may be a non-standard Tracy profile", file=sys.stderr)
        sys.exit(1)

    if args.query == "cpu":
        rows = query_cpu_profile(cur, args.limit)
        label = "Top CPU stacks"
    elif args.query == "frames":
        rows = query_frames(cur, args.limit)
        label = "Largest frames"
    elif args.query == "events":
        rows = query_events(cur, args.limit)
        label = "Event counts"
    elif args.query == "columns":
        cols = parse_sample_columns(cur)
        names = [c["name"] for c in cols]
        print("\n".join(names))
        return
    else:
        print(f"unknown query: {args.query}", file=sys.stderr)
        return

    if args.out:
        os.makedirs(args.out, exist_ok=True)
        path = Path(args.out) / f"tracy_{args.query}.csv"
        with open(path, "w", newline="", encoding="utf-8") as f:
            import csv
            w = csv.writer(f)
            w.writerow([r[i] for r in rows[0]] if rows else [])
            w.writerows(rows)
        print(f"wrote {path}")

    lines = ["{label} (top {limit}):".format(label=label, limit=args.limit), ""]
    for r in rows:
        lines.append("  " + " | ".join(str(x) for x in r))
    print("\n".join(lines))


if __name__ == "__main__":
    main()
