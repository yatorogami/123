#!/usr/bin/env python3
"""Audit i18n key HYGIENE -- the naming layer, not the embedding layer.

    python tools/verify/verify_i18n_keys.py

verify_lang_embedded.py answers "are the translations in the DLL the ones on
disk". This answers the question underneath it: "are the keys themselves
sane", which stays true no matter how faithfully the DLL embeds them.

FOUR CHECKS

  1. RAW-ENGLISH KEYS. A key of "Search" instead of "search_txt" can never be
     translated: tr() looks it up, misses, and returns the key -- so the label
     is English in all 19 locales. Measured 2026-10-11: 16 such keys at 17
     sites, none of them present in ANY locale.

  2. PROPER-NAMED KEYS MISSING FROM en.json. The inverse, and the one that
     shows up as a raw config key in the menu. Measured 2026-10-11: 8
     (cone_color_clr, target_opacity_itm, ltp_item_search_txt,
     menu_language_sec_hdr, optic_root_corrector_cb, skeleton_vis_distance_tip,
     spawn_queue_info, cone_opacity_itm).

  3. Select option lists of raw English WITHOUT translate_options=false.
     Deliberately-excluded: WorldModule's 73 bot names (proper nouns) and its
     Easy/Normal/Hard/Impossible scale both pass /*translate_options=*/false.
     A raw-English option list is only a finding when that flag is absent --
     otherwise tr() would be asked to translate a proper noun and would simply
     return it. The flag is read from the RAW text, because it is written as a
     /*translate_options=*/false comment marker and a comment-stripping pass
     would report both legitimate sites as defects.

  4. DEAD LANGUAGE LINES. Keys in en.json that no source site references.

EXIT CODES

  0  clean (or only check 4 findings, which are reported but not fatal)
  1  at least one naming defect in checks 1-3
  2  nothing could be checked -- this is NOT a pass

Check 4 is non-fatal by design: en.json legitimately accumulates lines for UI
that is compiled out of some configurations, and a dead line is untidy rather
than user-visible. Checks 1-3 are all user-visible, so they fail the run.
"""

import argparse
import collections
import json
import pathlib
import re
import sys

REPO = pathlib.Path(__file__).resolve().parents[2]
TA = REPO / "TarkovAddons"
SKIP_DIRS = {"external", "out", "build", "GameDump", "ISIL-references"}
SOURCE_EXTS = {".cpp", ".h", ".hpp", ".c"}

STRING = re.compile(r'"((?:[^"\\]|\\.)*)"')
BRACED = re.compile(r"\{([^{}]*)\}")
CTOR = re.compile(r"new\s+\w*(?:Value|Config)\s*\(")
SELECT_CTOR = re.compile(r"new\s+SelectValue\s*\(")
MODULE_CTOR = re.compile(r'Module\(\s*"[^"]*"\s*,\s*\w+\s*,\s*"([^"]+)"')


def strip_comments(text):
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    return re.sub(r"//[^\n]*", "", text)


def balanced_args(text, open_index):
    depth = 0
    index = open_index
    while index < len(text):
        if text[index] == "(":
            depth += 1
        elif text[index] == ")":
            depth -= 1
            if depth == 0:
                return text[open_index + 1:index]
        index += 1
    return ""


def is_proper_name(key):
    """snake_case, at least one underscore: the shape every real key uses."""
    return bool(re.fullmatch(r"[a-z][a-z0-9]*(?:_[a-z0-9]+)+", key))


def looks_raw_english(key):
    """A space, or any capital, means display text rather than a key."""
    return (" " in key) or bool(re.search(r"[A-Z]", key))


def source_files(lang_dir):
    for path in sorted(TA.rglob("*")):
        if path.suffix.lower() not in SOURCE_EXTS:
            continue
        rel = path.relative_to(TA)
        if rel.parts and rel.parts[0] in SKIP_DIRS:
            continue
        yield path, rel


def collect():
    """Return (name_keys, select_option_sites) over the first-party tree."""
    name_keys = collections.defaultdict(set)
    option_sites = []          # (relpath, lineno, opts, translate_options)
    for path, rel in source_files(None):
        raw = path.read_text(errors="replace")
        text = strip_comments(raw)
        relname = str(path.relative_to(REPO))

        for match in MODULE_CTOR.finditer(text):
            line = text[:match.start()].count("\n") + 1
            name_keys[match.group(1)].add(f"{relname}:{line}")

        for match in CTOR.finditer(text):
            args = balanced_args(text, match.end() - 1)
            line = text[:match.start()].count("\n") + 1
            # The NAME is the last top-level string literal; one inside a brace
            # list belongs to a SelectValue's options, not to this value.
            top_level = BRACED.sub("\x00", args)
            literals = STRING.findall(top_level)
            if literals:
                name_keys[literals[-1]].add(f"{relname}:{line}")

        # translate_options is written as /*translate_options=*/false, so it
        # lives in a COMMENT and is absent from `text`. It has to be read from
        # the raw source -- but the offsets cannot be shared between the two,
        # because comment-stripping changes the length of everything ahead of
        # the match. So find the SelectValue sites in the RAW text too and keep
        # the two passes aligned by argument position rather than offset.
        raw_select_args = []
        for raw_match in SELECT_CTOR.finditer(raw):
            raw_select_args.append(
                balanced_args(raw, raw.find("(", raw_match.start())))

        select_index = 0
        for match in SELECT_CTOR.finditer(text):
            args = balanced_args(text, match.end() - 1)
            line = text[:match.start()].count("\n") + 1
            opts = []
            for block in BRACED.finditer(args):
                opts = STRING.findall(block.group(1))
            if not opts:
                select_index += 1
                continue
            raw_args = raw_select_args[select_index] if select_index < len(raw_select_args) else ""
            select_index += 1
            # The argument-marker form is /*translate_options=*/false, so the
            # closing */ sits between the = and the false. A pattern that does
            # not allow for it reads both legitimate WorldModule sites as
            # defects -- which is exactly what the first version of this did.
            disabled = re.search(r"translate_options\s*=\s*\*/?\s*false", raw_args) is not None
            option_sites.append((relname, line, opts, disabled))

    return name_keys, option_sites


def main(argv):
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--lang-dir", default=str(TA / "lang"))
    args = ap.parse_args(argv[1:])

    lang_dir = pathlib.Path(args.lang_dir)
    if not lang_dir.is_dir():
        print(f"FAIL -- no lang directory at {lang_dir}", file=sys.stderr)
        return 2
    en_path = lang_dir / "en.json"
    if not en_path.is_file():
        print(f"FAIL -- no en.json in {lang_dir}; this is not a pass", file=sys.stderr)
        return 2
    try:
        en = json.loads(en_path.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        print(f"FAIL -- en.json is not valid JSON: {exc}", file=sys.stderr)
        return 2
    if not en:
        print("FAIL -- en.json is empty; this is not a pass", file=sys.stderr)
        return 2

    name_keys, option_sites = collect()
    if not name_keys and not option_sites:
        print("FAIL -- no source keys or option lists found; this is not a pass",
              file=sys.stderr)
        print("       (a wrong source root looks exactly like a clean tree)",
              file=sys.stderr)
        return 2

    defects = []

    # 1. raw-English keys
    raw_keys = sorted(k for k in name_keys
                      if looks_raw_english(k) and not is_proper_name(k))
    if raw_keys:
        print(f"[1] RAW-ENGLISH KEYS -- never translated in any locale ({len(raw_keys)})")
        for key in raw_keys:
            sites = sorted(name_keys[key])
            where = next(iter(lang_dir.glob("*.json")), None)
            present = key in json.loads(where.read_text(encoding="utf-8")) if where else False
            print(f"    {key!r}")
            print(f"        used at {len(sites)} site(s): {', '.join(sites[:3])}")
            print(f"        present in a locale: {'yes' if present else 'NO'}"
                  f"  -> renders as English for every non-English user")
        defects.append(("raw-English keys", len(raw_keys)))

    # 2. proper-named keys missing from en.json
    missing = sorted(k for k in name_keys if is_proper_name(k) and k not in en)
    if missing:
        print(f"\n[2] PROPER-NAMED KEYS MISSING FROM en.json ({len(missing)})")
        for key in missing:
            print(f"    {key:32s} {sorted(name_keys[key])[0]}")
            print(f"        -> tr() returns the key, so the menu shows {key!r}")
        defects.append(("keys missing from en.json", len(missing)))

    # 3. raw-English option lists with translation NOT disabled
    unflagged = [(rel, line, opts)
                 for rel, line, opts, disabled in option_sites
                 if not disabled and any(looks_raw_english(o) for o in opts)]
    if unflagged:
        print(f"\n[3] RAW-ENGLISH OPTION LISTS WITHOUT translate_options=false "
              f"({len(unflagged)})")
        for rel, line, opts in unflagged:
            print(f"    {rel}:{line}  ({len(opts)} options)")
            print(f"        {', '.join(repr(o) for o in opts[:6])}")
        defects.append(("unflagged option lists", len(unflagged)))

    # 4. dead language lines (reported, not fatal)
    #
    # NOT measured with name_keys. That set only knows three shapes -- config
    # value constructors, Module() display keys, and tr() -- so a key held in a
    # table (PlayerModule.h's 72 option strings, hotkeys_register.cpp's 52,
    # menu.cpp's nav_def array) reads as dead while being very much alive. The
    # first version of this reported 385 of 696 as dead on that basis; a corpus
    # sweep over every quoted literal in 204 first-party files found 0.
    #
    # So deadness is decided by APPEARANCE as a literal anywhere, which needs no
    # understanding of how the key is used and cannot miss a shape.
    literals = set()
    for path, _rel in source_files(None):
        literals |= set(STRING.findall(strip_comments(path.read_text(errors="replace"))))
    dead = sorted(k for k in en if k not in literals)
    if dead:
        print(f"\n[4] DEAD LANGUAGE LINES -- in en.json, not a literal anywhere in "
              f"the first-party tree ({len(dead)} of {len(en)})")
        for key in dead[:20]:
            print(f"    {key}")
        if len(dead) > 20:
            print(f"    ... and {len(dead) - 20} more")
        # Fatal, unlike the first version. A dead line is untidy on its own, but
        # it is also how the 63 superseded keys went unnoticed: nav_* and cat_*
        # were the translated names of rows menu.cpp stopped translating in the
        # base commit, and nothing reported them.
        defects.append(("dead language lines", len(dead)))

    print()
    if defects:
        print(f"FAIL -- {sum(n for _, n in defects)} naming defect(s):")
        for label, count in defects:
            print(f"    {count:4d}  {label}")
        return 1

    print(f"OK -- {len(name_keys)} key(s) and {len(option_sites)} option list(s) "
          f"checked, all properly named")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))