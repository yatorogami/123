// Case bridge *and* umbrella. Two jobs, both load-bearing.
//
// 1. The project writes these capitalised, as MSVC's headers are named on a
//    case-insensitive filesystem. mingw-w64 ships them lower-case and this
//    filesystem is case-sensitive, so `#include <Windows.h>` finds nothing.
//
// 2. MSVC's <windows.h> is an umbrella: it pulls in the whole Win32 API
//    surface, so project code that includes only <Windows.h> can still call
//    GetTickCount64, GetLastError, CreatePipe and so on. mingw-w64's <windows.h>
//    is a much smaller subset and does not include processthreadsapi.h,
//    fileapi.h, synchapi.h, wincon.h and the rest -- those symbols are simply
//    undeclared. The list below was derived by compiling the tree and mapping
//    each undeclared symbol to the header that declares it, not guessed.
//
// This is a modelling shim, not a port: everything the project uses comes from
// the real mingw-w64 headers behind it. See tools/verify/README.md.
#pragma once

#include <windows.h>

// mingw-w64 header bug, worked around rather than patched.
//
// <windows.h> reaches minwinbase.h, which defines struct _SECURITY_ATTRIBUTES
// unconditionally. wtypesbase.h -- reached through <shlobj.h> -- defines the
// same struct again, guarded by a macro spelled `_SECURITY_ATTRIBUTES_` (trailing
// underscore), which minwinbase.h never sets. Including the two in that order
// therefore produces "conflicting declaration SECURITY_ATTRIBUTES" and a
// redefinition error, and the shim headers are exactly what puts them in that
// order.
//
// The definition is already in hand from minwinbase.h, and the two are
// identical, so claiming wtypesbase.h's guard here suppresses a redundant
// redefinition and changes nothing. Defining the macro *before* <windows.h>
// would be wrong: it would suppress the only real definition.
//
// This define is ALSO passed on the compiler command line, and that is the copy
// that actually matters: pch.h includes <windows.h> in lower case, so it reaches
// mingw's header without passing through this file at all.
#define _SECURITY_ATTRIBUTES_

// Win32 API groups MSVC's umbrella provides and mingw's does not.
#include <consoleapi.h>        // console helpers
#include <errhandlingapi.h>    // GetLastError, SetLastError
#include <fileapi.h>           // CreateDirectoryW, DeleteFileA, GetFullPathNameA
#include <handleapi.h>         // CloseHandle
#include <libloaderapi.h>      // GetModuleHandleW, GetProcAddress
#include <memoryapi.h>         // VirtualQuery
#include <namedpipeapi.h>      // CreatePipe
#include <processenv.h>        // GetEnvironmentVariableW
#include <processthreadsapi.h> // GetCurrentProcess
#include <profileapi.h>        // QueryPerformanceCounter / QueryPerformanceFrequency
#include <synchapi.h>          // Sleep, CreateEventW, WaitForSingleObject
#include <sysinfoapi.h>        // GetTickCount, GetTickCount64
#include <timezoneapi.h>       // FileTimeToSystemTime
#include <winbase.h>           // STD_INPUT_HANDLE, STD_OUTPUT_HANDLE, STD_ERROR_HANDLE
#include <wincon.h>            // GetConsoleMode, SetConsoleCtrlHandler and friends
