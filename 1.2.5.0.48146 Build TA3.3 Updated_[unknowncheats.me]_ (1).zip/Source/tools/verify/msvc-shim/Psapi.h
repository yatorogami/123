// Case bridge only. mingw-w64 ships this lower-case; MSVC ships it capitalised,
// and this filesystem is case-sensitive. It is named differently from the real
// header, so this cannot resolve back to itself.
//
// There is deliberately no shim for <shlobj.h> or <winbase.h>: their names are
// already the real spelling, so a same-named file in this directory would
// include *itself* and silently become empty.
#pragma once
#include <psapi.h>
