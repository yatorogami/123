#!/usr/bin/env python3
"""Link-stage oracle. Compiles every translation unit to an object and compares
symbol tables.

Why this exists when check.sh already exists
--------------------------------------------
check.sh answers "does this still compile". That is not enough for anything that
gives a *free* function external linkage. A member function's name is scoped by
its class, so defining one out of class cannot collide with anything. A free
function's name is not: give `static void find_pattern(...)` in util/scan.h
external linkage and define it in a .cpp, and if any other translation unit
already defines a global `find_pattern` the DLL stops linking -- while
-fsyntax-only reports nothing at all.

The two defects this caught in practice, both of which a syntax pass cannot see:
`inline` on a declaration whose body had moved to one .cpp (an ODR violation that
leaves mat4::at and two siblings resolvable nowhere), and the void*-to-function-
pointer casts that stop GCC emitting an object at all.

Invariants
----------
  duplicate     a symbol with a real definition in two or more objects. This is
                an absolute zero, not a comparison: it needs no baseline and
                cannot rot.
  unresolved    a symbol referenced but defined by no object in the project.
                Some are legitimately external -- Win32, the CRT, libstdc++ --
                so this is reported, not asserted, and reviewed by eye.

Modelling MSVC
--------------
The project casts void* to a function pointer with static_cast. MSVC accepts it;
GCC rejects it outright, so 46 casts across 5 files stop those translation units
producing any object. Rather than touch the tree, objects are built from a
*shadow* copy in which those casts read reinterpret_cast -- the same conversion
in the form both compilers accept, which changes no symbol table. `-fpermissive`
is also needed, and only for codegen: -fsyntax-only never instantiates a function
template for emission, so the implicit function-pointer-to-void* conversions
surface at a different time than the explicit ones and -fpermissive covers
those. The shadow is keyed on mtime; unchanged files are never recopied.
"""
import concurrent.futures
import os
import re
import shutil
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

REPO = Path(os.environ.get('REPO', Path(__file__).resolve().parent.parent.parent))
SHADOW = Path(os.environ.get('SHADOW', '/tmp/tarkovaddons-linkcheck/shadow'))
OBJ = Path(os.environ.get('OBJ', '/tmp/tarkovaddons-linkcheck/obj'))
JOBS = int(os.environ.get('JOBS', '8'))
SOURCE_SUFFIXES = {'.h', '.hpp', '.hh', '.inl', '.ipp', '.cpp', '.cc', '.cxx', '.c'}

FLAGS = [
    '-std=c++23', '-O0', '-c', '-w', '-fpermissive',
    '-DINCLUDE_AIMBOT', '-DNDEBUG', '-D_CRT_SECURE_NO_WARNINGS',
    '-DWIN32_LEAN_AND_MEAN', '-DUNICODE', '-D_UNICODE',
    '-D_SECURITY_ATTRIBUTES_',
    '-D__try=try', '-D__except(x)=catch(...)',
]

# static_cast<T>(x) where x is a `void*` method pointer. Keyed on the argument
# rather than the target type, because that covers both spellings: the ones that
# write the function-pointer type out, and il2utils::get_method<T>'s
# `static_cast<T>(method->methodPointer)` where T is only a template
# parameter until instantiation.
# Requiring a `methodPointer` argument is the whole discriminator, and it is
# enough alone. An earlier version added a lookahead requiring `;` or end of
# line after the cast, to avoid rewriting a function *declaration* whose
# parameter happened to match -- and that silently skipped the commonest real
# case, `static_cast<FnPtr>(p->methodPointer)(args)`, which is a call and so is
# followed by `(`. Twelve translation units then produced no object at all, a
# failure that looks like a source problem rather than a harness one.
FN_CAST = re.compile(
    r'static_cast<([^<>]{0,120})>\(([^(){};]{0,120}methodPointer[^(){};]{0,40})\)')

# The other direction. Casting *to* void* from a function pointer is an MSVC
# extension; portable C++ wants reinterpret_cast, and GCC rejects the static_cast
# spelling outright -- so a translation unit containing one produces no object at
# all, and this oracle's "zero duplicate definitions" quietly covers fewer
# translation units than it appears to. crash_probe.h grew this construct in
# October 2026 (report_handler_owners passing on_unhandled/on_terminate) and two
# TUs silently stopped linking in the check.
#
# Safe to apply blanket to any `static_cast<void*>`: reinterpret_cast to void* is
# valid for every source type, object pointer or function pointer.
TO_VOID_CAST = re.compile(r'static_cast<\s*\(?\s*void\s*\*\s*\)?\s*>')

OBJDUMP = 'x86_64-w64-mingw32-objdump'
# A COFF symbol-table row. objdump right-pads the index to width 5, so "[ 52]"
# and "[21093]" are both normal -- without the leading \s* every row whose index
# is under five digits is silently skipped and its symbols vanish.
SYM_ROW = re.compile(r'^\[\s*\d+\]\(sec\s+(\d+)\)\(fl 0x[0-9a-f]+\)'
                     r'\(ty\s+\d+\)\(scl\s+(\d+)\)')
# A section-header row: "  1517 .text$_Zfoo 00000020  0000 0000  0000  2**4"
SECT_ROW = re.compile(r'^\s*(\d+)\s+(\S+)\s+[0-9a-f]{8}\s')
# nm reports a section's address as a bare hex symbol. Not a code symbol.
SECTION_SYM = re.compile(r'^[0-9a-fA-F]+$')


def project_translation_units():
    """Every translation unit TarkovAddons.vcxproj compiles, first-party and vendored.

    ClCompile paths are relative to the project directory, so
    `module\\Module.cpp` is TarkovAddons/module/Module.cpp and
    `external\\imgui\\imgui.cpp` is TarkovAddons/external/imgui/imgui.cpp. The two
    safetyhook entries are spelled `$(MSBuildThisFileDirectory)..\\external\\...`,
    which resolves *outside* the project directory to the repository root -- a
    different external/ tree, shared with the launcher projects.
    """
    vcx = (REPO / 'TarkovAddons/TarkovAddons.vcxproj').read_text()
    out, prefix = [], '$(MSBuildThisFileDirectory)..'
    for entry in re.findall(r'<ClCompile Include="([^"]+)"', vcx):
        if entry.startswith(prefix):
            out.append(entry[len(prefix):].replace('\\', '/').lstrip('/'))
        else:
            out.append('TarkovAddons/' + entry.replace('\\', '/'))
    return out


def build_shadow():
    """Mirror the project's sources into the shadow, rewriting the MSVC-only casts."""
    for base in ('TarkovAddons', 'external'):
        for path in (REPO / base).rglob('*'):
            if not (path.is_file() and path.suffix in SOURCE_SUFFIXES):
                continue
            dst = SHADOW / path.relative_to(REPO)
            if dst.exists() and dst.stat().st_mtime >= path.stat().st_mtime:
                continue
            dst.parent.mkdir(parents=True, exist_ok=True)
            if path.suffix == '.c':
                dst.write_bytes(path.read_bytes())
            else:
                text = path.read_text(errors='replace')
                text = FN_CAST.sub(r'reinterpret_cast<\1>(\2)', text)
                dst.write_text(TO_VOID_CAST.sub('reinterpret_cast<void*>', text))


def compile_one(rel, log):
    src = SHADOW / rel
    obj = OBJ / (rel.replace('/', '_') + '.o')
    if obj.exists() and obj.stat().st_mtime >= src.stat().st_mtime:
        return True
    cc = ('x86_64-w64-mingw32-gcc' if rel.endswith('.c')
          else 'x86_64-w64-mingw32-g++')
    argv = [cc, *FLAGS]
    # MSVC's /Yu: first-party TUs force-include the PCH. The vendored ones opt
    # out via NotUsing.
    if rel.startswith('TarkovAddons/') and not rel.startswith('TarkovAddons/external/'):
        # The PCH is TarkovAddons/include/common.h (was pch.h). Try both, so
        # this does not depend on the rename having happened.
        for cand in ('TarkovAddons/include/common.h', 'TarkovAddons/pch.h'):
            pch = SHADOW / cand
            if pch.exists():
                if rel != 'TarkovAddons/pch.cpp':
                    argv += ['-include', str(pch)]
                break
    argv += [f'-I{d}' for d in (
        REPO / 'tools/verify/msvc-shim',
        REPO / 'TarkovAddons',          # $(ProjectDir): a bare "common.h" needs it
        REPO / 'TarkovAddons/include',  # where common.h actually lives
        SHADOW / 'external', SHADOW / 'TarkovAddons/external',
        SHADOW / 'TarkovAddons/external/imgui', SHADOW / 'TarkovAddons/external/tracy')]
    argv += ['-o', str(obj), str(src)]
    proc = subprocess.run(argv, capture_output=True, text=True, timeout=3600)
    if proc.returncode != 0 or not obj.exists():
        log.append((rel, proc.stderr))
        return False
    return True


def read_symbols(obj):
    """(strong definitions, link-once definitions, undefined references).

    Link-once (COMDAT) is separated from strong. An `inline` function or a
    template instantiation defined in a header lands in a LINK_ONCE_DISCARD
    section: the linker legitimately keeps one copy and discards the rest, so
    appearing in twenty objects is correct, not a collision. But it still
    *defines* the symbol, so it has to count as a definition or every reference
    to it would look unresolved.
    """
    comdat = set()
    for line in subprocess.run([OBJDUMP, '-h', str(obj)], capture_output=True,
                               text=True).stdout.splitlines():
        found = SECT_ROW.match(line)
        if found and '$' in found.group(2):
            # Two spellings, both "link once, dedupe by name":
            #   .text$_Z5ImAbsf   -> suffix is _Z5ImAbsf
            #   .tls$$_ZZN7...    -> the doubled $$ means the suffix *is* the
            #                       symbol, so strip both dollars
            comdat.add(re.sub(r'^\.[^$]*\$+', '', found.group(2)))
        elif 'COMDAT' in line:
            named = re.search(r'COMDAT\s+(\S+)', line)
            if named:
                comdat.add(named.group(1))

    strong, once, undef = [], [], []
    table = subprocess.run([OBJDUMP, '-t', str(obj)], capture_output=True,
                           text=True).stdout
    for line in table.splitlines():
        found = SYM_ROW.match(line)
        if not found:
            continue
        sec, storage = int(found.group(1)), int(found.group(2))
        name = line.split()[-1]
        if name.startswith('.') or SECTION_SYM.match(name):
            continue
        if sec == 0:
            if storage == 2:
                undef.append(name)
            continue
        if storage != 2:                    # not external
            continue
        (once if name in comdat else strong).append(name)
    return strong, once, undef


def main():
    build_shadow()
    OBJ.mkdir(parents=True, exist_ok=True)
    tus = project_translation_units()
    missing = [t for t in tus if not (SHADOW / t).exists()]
    for t in missing:
        print(f'{t}: MISSING_TU', file=sys.stderr)

    # Prune objects whose translation unit no longer exists. Without this a
    # deleted .cpp leaves its object behind and the symbol tables keep counting
    # it as a definition -- so removing a source silently stops being able to
    # fail this check.
    expected = {t.replace('/', '_') + '.o' for t in tus}
    for obj in OBJ.glob('*.o'):
        if obj.name not in expected:
            obj.unlink()
            print(f'pruned stale object: {obj.name}', file=sys.stderr)

    log = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=JOBS) as pool:
        results = list(pool.map(lambda t: compile_one(t, log), tus))

    defined = defaultdict(set)      # every definition, link-once included
    strong = defaultdict(set)       # definitions that genuinely collide
    undefined = set()
    for obj in sorted(OBJ.glob('*.o')):
        s_here, o_here, u = read_symbols(obj)
        for name in set(s_here):
            defined[name].add(obj.name)
            strong[name].add(obj.name)
        for name in set(o_here):
            defined[name].add(obj.name)
        undefined.update(u)

    duplicates = sorted(n for n, o in strong.items() if len(o) > 1)
    unresolved = sorted(undefined - set(defined))
    objects = len(list(OBJ.glob('*.o')))

    print(f'objects {objects}  failed {sum(1 for r in results if not r)}  '
          f'missing {len(missing)}', file=sys.stderr)
    for rel, text in log:
        print(f'COMPILE_FAILED: {rel}\n' + '\n'.join(text.splitlines()[:6]),
              file=sys.stderr)
    print(f'\nduplicate definitions: {len(duplicates)}   '
          f'  (invariant: 0)')
    for name in duplicates:
        print(f'  duplicate: {name}')
    print(f'\nunresolved symbols: {len(unresolved)}   '
          f'  (expected: external only -- Win32, CRT, libstdc++)')
    for name in unresolved:
        print(f'  unresolved: {name}')

    if duplicates:
        print('\nFAIL: a duplicate definition will not link.', file=sys.stderr)
        return 1
    return 1 if (log or missing) else 0


if __name__ == '__main__':
    sys.exit(main())
