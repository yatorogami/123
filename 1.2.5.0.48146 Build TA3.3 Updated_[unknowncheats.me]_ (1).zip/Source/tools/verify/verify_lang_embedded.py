#!/usr/bin/env python3
"""Verify the lang\\*.json translations are actually the ones embedded in the DLL.

    python tools/verify/verify_lang_embedded.py                 # newest build DLL
    python tools/verify/verify_lang_embedded.py <path-to-dll>

WHY THIS EXISTS

The .rc file embeds lang\\*.json as RCDATA 1300-1318 (assets/menu_background.rc)
and i18n::tr() falls back to `return key` for anything it cannot find -- so a
translation that is missing from the EMBEDDED copy renders in the menu as the raw
config key, e.g. "container_chams_cb". Editing lang\\en.json is not enough to fix
that: rc.exe reports no dependency on the files it embeds, so the resource step is
not re-run and the stale .res is linked into a newer DLL.

Measured 2026-10-11 on the DLL in build\\Prod\\x64\\opencode:

    lang\\*.json last edited   2026-10-10 17:57
    menu_background.rc.res     2026-10-09 14:56   <- older than its own inputs
    TarkovAddons.dll linked    2026-10-11 09:32   <- newer, and still stale
    embedded en.json           712 keys == commit e4caba056a (2026-10-08)
    lang\\en.json on disk      735 keys

The 23 missing keys included container_chams_cb, all four sibling container chams
keys, the whole AI-Limit set, and loot_tp_category_btn / loot_tp_wishlist_btn.
The fix for the staleness is OBJECT_DEPENDS in TarkovAddons/CMakeLists.txt and
AdditionalDependencies on the ResourceCompile item in TarkovAddons.vcxproj; this
tool is what notices if either is lost, because the resource step failing to
re-run is invisible in every other check this project has.

WHAT IT COMPARES

Each of the 19 RCDATA ids against the lang file of the same name, semantically
rather than byte-wise: rc.exe normalises line endings, so a CRLF/LF difference is
not a defect and must not be reported as one. A key present on disk but absent
from the DLL is the failure that matters, and it is reported per key.

EXIT CODES

    0  every embedded locale matches lang\\ on disk
    1  at least one embedded locale is stale or absent
    2  nothing could be checked -- this is NOT a pass

The exit-2 paths matter more than usual here. A PE parser that finds no .rsrc
directory, or a build tree that does not exist, would otherwise "pass" by finding
no differences, which is precisely the failure this project has been bitten by
three times in tools/ (see tools/README.md).
"""

import argparse
import json
import pathlib
import struct
import sys

REPO = pathlib.Path(__file__).resolve().parents[2]

# assets/menu_background.rc: id -> locale file stem. i18n.cpp's
# embedded_locale_resource_id() repeats this table, so the two can drift; this
# one is checked against the DLL's own resource directory below, which is the
# only source that cannot drift silently.
RCDATA_IDS = {
    1300: "en", 1301: "ru", 1302: "ge", 1303: "fr", 1304: "es",
    1305: "it", 1306: "pl", 1307: "cs", 1308: "po", 1309: "br",
    1310: "tu", 1311: "ch", 1312: "tw", 1313: "jp", 1314: "kr",
    1315: "sr", 1316: "ro", 1317: "hu", 1318: "sk",
}

RT_RCDATA = 10
DEFAULT_GLOBS = (
    "build/*/x64/*/out/prod/with_aimbot/TarkovAddons.dll",
    "TarkovAddons/out/prod/with_aimbot/TarkovAddons.dll",
)


class PeError(Exception):
    pass


def read_rsrc(path):
    """Return {rdata_id: (offset, size)} for RT_RCDATA leaves in a PE file."""
    data = path.read_bytes()
    if data[:2] != b"MZ":
        raise PeError(f"{path} is not a PE file (no MZ signature)")
    pe_off = struct.unpack_from("<I", data, 0x3C)[0]
    if data[pe_off:pe_off + 4] != b"PE\0\0":
        raise PeError(f"{path} has no PE signature at the offset e_lfanew names")

    nsec = struct.unpack_from("<H", data, pe_off + 6)[0]
    opt_size = struct.unpack_from("<H", data, pe_off + 20)[0]
    opt_off = pe_off + 24
    magic = struct.unpack_from("<H", data, opt_off)[0]
    if magic == 0x20B:
        dd_off = opt_off + 112
    elif magic == 0x10B:
        dd_off = opt_off + 96
    else:
        raise PeError(f"{path} has unrecognised optional-header magic 0x{magic:X}")

    sections = []
    sec_off = opt_off + opt_size
    for i in range(nsec):
        o = sec_off + i * 40
        vsize, vaddr, rsize, raddr = struct.unpack_from("<IIII", data, o + 8)
        sections.append((vaddr, max(vsize, rsize), raddr))

    def rva_to_offset(rva):
        for vaddr, span, raddr in sections:
            if vaddr <= rva < vaddr + span:
                return raddr + (rva - vaddr)
        return None

    # DataDirectory[2] is IMAGE_DIRECTORY_ENTRY_RESOURCE.
    rsrc_rva = struct.unpack_from("<I", data, dd_off + 2 * 8)[0]
    if not rsrc_rva:
        raise PeError(f"{path} has no resource directory (DataDirectory[2] is zero)")
    rsrc_off = rva_to_offset(rsrc_rva)
    if rsrc_off is None:
        raise PeError(f"{path}: .rsrc RVA 0x{rsrc_rva:X} is outside every section")

    found = {}

    def walk(dir_off, ids):
        # IMAGE_RESOURCE_DIRECTORY is 16 bytes and NumberOfNamedEntries /
        # NumberOfIdEntries sit at +12, not at 0. Getting this wrong reads
        # Characteristics as the entry count and finds nothing.
        if dir_off + 16 > len(data):
            raise PeError(f"{path}: resource directory runs past end of file")
        named, by_id = struct.unpack_from("<HH", data, dir_off + 12)
        for i in range(named + by_id):
            entry = dir_off + 16 + i * 8
            if entry + 8 > len(data):
                raise PeError(f"{path}: resource directory entry runs past end of file")
            name_id, sub = struct.unpack_from("<II", data, entry)
            child = rsrc_off + (sub & 0x7FFFFFFF)
            if sub & 0x80000000:                      # points at a subdirectory
                walk(child, ids + [name_id & 0x7FFFFFFF])
            else:                                     # points at a data entry
                # The leaf's own name field is the LANGUAGE id; the full path is
                # Type -> ID -> Language -> Data.
                drva, dsize = struct.unpack_from("<II", data, child)
                off = rva_to_offset(drva)
                if off is None:
                    continue
                found[tuple(ids) + (name_id & 0x7FFFFFFF,)] = (off, dsize)

    walk(rsrc_off, [])

    by_resource = {}
    for key, val in found.items():
        if len(key) == 3 and key[0] == RT_RCDATA:
            by_resource[key[1]] = val
    return by_resource, len(found)


def newest_default_dll():
    """Newest build DLL, or None. Reported rather than guessed at."""
    candidates = []
    for pattern in DEFAULT_GLOBS:
        candidates.extend(REPO.glob(pattern))
    candidates = [c for c in candidates if c.is_file()]
    if not candidates:
        return None
    return max(candidates, key=lambda p: p.stat().st_mtime)


def main(argv):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("dll", nargs="?", help="the DLL to check; default is the newest build")
    ap.add_argument("--lang-dir", default=str(REPO / "TarkovAddons" / "lang"))
    args = ap.parse_args(argv[1:])

    lang_dir = pathlib.Path(args.lang_dir)
    if not lang_dir.is_dir():
        print(f"FAIL -- no lang directory at {lang_dir}", file=sys.stderr)
        return 2
    disk_files = sorted(lang_dir.glob("*.json"))
    if not disk_files:
        print(f"FAIL -- {lang_dir} holds no .json files; this is not a pass",
              file=sys.stderr)
        return 2

    if args.dll:
        dll = pathlib.Path(args.dll)
    else:
        dll = newest_default_dll()
        if dll is None:
            print("FAIL -- no DLL found. Looked for:\n  " + "\n  ".join(DEFAULT_GLOBS),
                  file=sys.stderr)
            print("       Build first, or pass the path explicitly.", file=sys.stderr)
            return 2
    if not dll.is_file():
        print(f"FAIL -- {dll} does not exist", file=sys.stderr)
        return 2

    try:
        resources, total_leaves = read_rsrc(dll)
    except (PeError, struct.error, OSError) as exc:
        print(f"FAIL -- could not read resources from {dll}:\n       {exc}", file=sys.stderr)
        return 2

    if total_leaves == 0:
        print(f"FAIL -- {dll} yielded 0 resource leaves; this is not a pass", file=sys.stderr)
        return 2
    if not resources:
        print(f"FAIL -- {dll} has {total_leaves} resource leaves but none of type "
              f"RT_RCDATA ({RT_RCDATA}); this is not a pass", file=sys.stderr)
        return 2

    checked = 0
    failures = []

    for rid, code in sorted(RCDATA_IDS.items()):
        on_disk_path = lang_dir / f"{code}.json"
        if rid not in resources:
            failures.append((rid, code, ["<the whole resource>"], "absent from the DLL"))
            continue
        if not on_disk_path.is_file():
            failures.append((rid, code, ["<the whole resource>"],
                             f"{on_disk_path.name} is missing from the source tree"))
            continue

        off, size = resources[rid]
        blob = dll.read_bytes()[off:off + size]
        try:
            embedded = json.loads(blob.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            failures.append((rid, code, ["<the whole resource>"],
                             f"embedded copy is not valid JSON: {exc}"))
            continue
        try:
            disk = json.loads(on_disk_path.read_text(encoding="utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            failures.append((rid, code, ["<the whole resource>"],
                             f"{on_disk_path.name} is not valid JSON: {exc}"))
            continue

        checked += 1
        # Semantic, not byte-wise: rc.exe rewrites line endings, so a CRLF/LF
        # difference is not a defect.
        missing = sorted(set(disk) - set(embedded))
        if missing:
            failures.append((rid, code, missing,
                             f"embedded {len(embedded)} keys, {on_disk_path.name} has {len(disk)}"))

    if checked == 0:
        print(f"FAIL -- no locale could be compared for {dll}; this is not a pass",
              file=sys.stderr)
        return 2

    if not failures:
        print(f"OK -- {checked}/{len(RCDATA_IDS)} locale(s) embedded in")
        print(f"       {dll}")
        print(f"     match {lang_dir} exactly ({len(json.loads((lang_dir / 'en.json').read_text(encoding='utf-8')))} keys in en.json)")
        return 0

    print(f"FAIL -- the DLL embeds translations that do not match {lang_dir}:\n")
    total_keys = 0
    for rid, code, missing, why in failures:
        print(f"  RCDATA {rid} ({code}.json): {why}")
        for key in missing:
            print(f"      {key}")
            total_keys += 1
        print()
    print(f"  {total_keys} key(s) missing across {len(failures)} locale(s).")
    print("  i18n::tr() returns the key itself for anything it cannot find, so each")
    print("  one of these renders in the menu as a raw config key.")
    print("\n  Cause: rc.exe reports no dependency on the files it embeds, so editing")
    print("  a translation does not re-run the resource step. Confirm with:")
    print("      Get-Item build\\Prod\\x64\\*\\TarkovAddons\\CMakeFiles\\TarkovAddons.dir\\assets\\menu_background.rc.res")
    print("  -- if it is older than lang\\*.json, the .res is stale.")
    print("  Fix the dependencies (CMakeLists.txt OBJECT_DEPENDS, vcxproj")
    print("  AdditionalDependencies), then rebuild -- a normal incremental build is")
    print("  not enough, because the resource step is exactly what is not re-running.")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))