#!/usr/bin/env python3
"""Name every address in a compatibility manifest, using an IDA database.

Why this exists
---------------
`verify_manifest.py` proves the manifest's bytes are the bytes on disk. It cannot
prove they are the *right* function, because a unique byte sequence does not name
anything. This does, using IDA's own analysis -- the only oracle in the repo that
turns an RVA into a function identity.

The finding that forced it: on build 1.1.5.1.47510 all 8 `il2cpp_*` pattern
symbols resolve to a different address than the module's export of the same name.
Byte-checking cannot tell a broken pattern from a legitimate unwrapped-body
reference. IDA can, by walking the export's call chain: where the export `jmp`s
to the pattern's target the pattern is correct; where it `call`s it, also correct;
where the two are unrelated functions, the pattern is unproven.

Three gates before any name is printed. Each was learned by getting it wrong.

1. **The database must describe these exact bytes.** IDA records the sha256 of
   the file it was built from. If it differs from the DLL being verified, every
   name below is about a different build, so the tool refuses rather than
   printing something plausible.
2. **The image base is `ida_nalt.get_imagebase()`.** `ida_ida.inf_get_start_ea()`
   returns something else entirely (0x180519F18 in the GameAssembly database here
   against a true base of 0x180000000). Using it placed every lookup in the wrong
   segment and reported `<unnamed>` for all 19 symbols -- indistinguishable from
   "IDA has no names", which is exactly how it went unnoticed.
3. **Never write to the database.** `close_database(save=False)`, unconditionally.

Exit codes: `0` ran and every gate passed, `1` a gate failed, `2` could not run
(IDA absent or unlicensed, database missing, idalib unimportable) -- distinct on
purpose, so "IDA was unavailable" can never read as "everything checks out".

Requires IDA Professional 9.x with `idalib`, plus a `.i64` beside each module.
Deliberately not in `pytest tools/tests`: the licence is not on every machine and
the databases are gitignored, so a suite depending on this would fail on a fresh
clone. `verify_manifest.py` is the offline half and covers the byte-level claims;
this adds the semantic ones.

Usage:
    python tools/verify/ida_manifest.py
    python tools/verify/ida_manifest.py <manifest.json> <module-dir>
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Sequence

sys.path.insert(0, str(Path(__file__).resolve().parent))
from verify_manifest import PE, parse_pattern, sha256_of  # noqa: E402

REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_MANIFEST = REPO_ROOT / "compatibility" / "profiles" / "1.1.5.1.47510" / "manifest.json"
DEFAULT_MODULE_DIR = REPO_ROOT / "TarkovAddons" / "GameDump" / "115147510_tarkov-dump"
EXIT_OK, EXIT_PROBLEM, EXIT_CANNOT_RUN = 0, 1, 2


def find_ida() -> tuple[str, str]:
    """Locate the IDA install directory and its idalib python package."""
    roots: list[str] = []
    if os.environ.get("IDADIR"):
        roots.append(os.environ["IDADIR"])
    for base in ("C:\\Program Files", "C:\\Program Files (x86)", "C:\\", "D:\\"):
        if not os.path.isdir(base):
            continue
        try:
            roots += [e.path for e in os.scandir(base)
                      if e.is_dir() and e.name.upper().startswith("IDA")]
        except OSError:
            pass
    for base in roots:
        lib = os.path.join(base, "idalib", "python")
        if os.path.isdir(lib):
            return base, lib
    raise FileNotFoundError(
        "IDA idalib not found. Set IDADIR to the IDA Professional 9.x install "
        "directory (the one containing idalib/python).")


def main(argv: Sequence[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("manifest", nargs="?", default=str(DEFAULT_MANIFEST))
    ap.add_argument("module_dir", nargs="?", default=str(DEFAULT_MODULE_DIR))
    args = ap.parse_args(argv)

    manifest_path, module_dir = Path(args.manifest), Path(args.module_dir)
    if not manifest_path.is_file():
        print(f"ERROR manifest not found: {manifest_path}")
        return EXIT_CANNOT_RUN
    if not module_dir.is_dir():
        print(f"ERROR module dir not found: {module_dir}")
        return EXIT_CANNOT_RUN

    try:
        ida_dir, idalib = find_ida()
    except FileNotFoundError as exc:
        print(f"ERROR {exc}")
        return EXIT_CANNOT_RUN
    os.environ.setdefault("IDADIR", ida_dir)
    sys.path.insert(0, idalib)

    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    symbols: list[dict[str, Any]] = manifest["symbols"]
    modules: dict[str, Any] = manifest["modules"]

    try:
        import idapro
    except Exception as exc:  # noqa: BLE001 - idalib raises its own ImportErrors
        print(f"ERROR cannot import idapro from {idalib}: {exc}")
        print("       IDA is normally installed but unlicensed; a licence "
              "failure surfaces at this import.")
        return EXIT_CANNOT_RUN

    print(f"manifest : {manifest_path}")
    print(f"modules  : {module_dir}")
    print(f"IDA      : {ida_dir}   library version {idapro.get_library_version()}")
    print()

    idapro.enable_console_messages(True)
    problems: list[str] = []

    for module in modules:
        dll = module_dir / module
        db = module_dir / f"{module}.i64"
        if not dll.is_file():
            problems.append(f"{module}: DLL absent from {module_dir}")
            continue
        if not db.is_file():
            problems.append(f"{module}: no .i64 beside it ({db.name} missing)")
            continue

        rc = idapro.open_database(str(db), run_auto_analysis=False)
        if rc != 0:
            problems.append(f"{module}: idalib could not open {db.name} (rc={rc}). "
                           f"An unlicensed IDA returns here.")
            print(f"  {module}: open_database returned {rc} -- skipping")
            continue
        try:
            import ida_funcs
            import ida_name
            import ida_segment
            import ida_nalt
            import idautils
            import idc

            # -- gate 1: is this database about these bytes? --
            recorded = ""
            getter = getattr(ida_nalt, "retrieve_input_file_sha256", None)
            if getter:
                try:
                    recorded = getter().hex()
                except Exception as e:  # noqa: BLE001
                    problems.append(f"{module}: recorded input hash unreadable "
                                    f"({type(e).__name__}: {e})")
            actual = sha256_of(dll)
            print("=" * 104)
            print(f"{module}")
            if not recorded:
                print("  NO RECORDED INPUT HASH -- refusing to name anything "
                      "from this database")
                problems.append(f"{module}: database records no input hash")
                continue
            if recorded != actual:
                print("  INPUT HASH MISMATCH -- this database describes a "
                      "different build, so no name from it is trustworthy")
                print(f"      built from : {ida_nalt.get_input_file_path()}")
                print(f"      recorded   : {recorded}")
                print(f"      on disk    : {actual}")
                problems.append(f"{module}: database describes a different build")
                continue
            print(f"  input sha256 {actual[:16]}... MATCHES, so names below are "
                  f"about these exact bytes")

            # -- gate 2: the real image base --
            base = ida_nalt.get_imagebase()
            print(f"  imagebase {base:#x}   functions {ida_funcs.get_func_qty()}")

            # Executable ranges, by permission rather than by name. The
            # GameAssembly database splits code across two segments -- `.text`
            # and one named `il2cpp` -- so a name-based ".text" test reports
            # most of the module's code as not-in-.text, which is a false
            # alarm. IDA's perm bit 0 is execute.
            exec_ranges: list[tuple[int, int, str]] = []
            for i in range(ida_segment.get_segm_qty()):
                s = ida_segment.getnseg(i)
                if s.perm & 1:
                    exec_ranges.append((s.start_ea, s.end_ea,
                                        ida_segment.get_segm_name(s)))

            def executable(ea: int) -> tuple[bool, str]:
                for lo, hi, nm_ in exec_ranges:
                    if lo <= ea < hi:
                        return True, nm_
                return False, ida_segment.get_segm_name(ea) or "?"

            # offline facts we need to ask the right question of IDA
            pe = PE(dll)
            exports = pe.export_table()

            print()
            print(f"  {'symbol':34} {'rva':11} {'location':22} {'size':>7}  name")
            for sym in symbols:
                if sym.get("module") != module:
                    continue
                name = sym["name"]
                rva = sym.get("rva")
                if rva is None:
                    pats = sym.get("patterns") or []
                    if not pats:
                        print(f"  {name:34} {'-':11} "
                              f"{'(resolved by export name)':22} {'-':>7}  -")
                        continue
                    else:
                        hits = pe.scan(parse_pattern(pats[0]))
                        if len(hits) == 1:
                            rva = hex(hits[0])
                        else:
                            print(f"  {name:34} {'-':11} "
                                  f"{f'({len(hits)} pattern matches)':22} {'-':>7}  -")
                            continue
                ea = base + int(str(rva), 0)
                is_exec, seg = executable(ea)
                f = ida_funcs.get_func(ea)
                if f:
                    loc = ("FUNCTION START" if f.start_ea == ea
                           else f"inside +{ea - f.start_ea:#x}")
                    size = f"{f.end_ea - f.start_ea}B"
                else:
                    loc, size = "not in a function", "-"
                nm = ida_name.get_name(ea)
                flag = "" if is_exec else f"  [segment {seg!r} is not executable]"
                print(f"  {name:34} {str(rva):11} {loc:22} {size:>7}  "
                      f"{nm or '<unnamed>'}{flag}")
                if not is_exec:
                    problems.append(f"{module}/{name}: rva {rva} is in "
                                    f"non-executable segment {seg!r}")

            # -- classification: does the export reach the pattern's target? --
            print()
            print(f"  pattern-vs-export classification ({module}):")
            print(f"  {'symbol':34} {'pattern':11} {'export':11} relationship")
            print(f"  {'':34} {'':11} {'':11} {'-' * 34}")
            for sym in symbols:
                if sym.get("module") != module:
                    continue
                name = sym["name"]
                pats = sym.get("patterns") or []
                if not pats:
                    continue
                hits = pe.scan(parse_pattern(pats[0]))
                if len(hits) != 1:
                    print(f"  {name:34} {'':11} {'':11} "
                          f"pattern does not resolve uniquely ({len(hits)})")
                    continue
                pat_ea = base + hits[0]
                exp_rva = exports.get(name)
                if exp_rva is None:
                    print(f"  {name:34} {hex(hits[0]):11} {'(unexported)':11} "
                          f"no same-named export to compare")
                    continue
                exp_ea = base + exp_rva
                if pat_ea == exp_ea:
                    rel = "same address"
                else:
                    rel = classify_relationship(ida_funcs, idautils, idc,
                                                ida_name, exp_ea, pat_ea)
                print(f"  {name:34} {hex(hits[0]):11} {hex(exp_rva):11} {rel}")
        finally:
            idapro.close_database(save=False)
        print()

    if problems:
        print(f"GATE FAILURES ({len(problems)}) -- treat as a problem, not a pass:")
        for p in problems:
            print(f"  - {p}")
        return EXIT_PROBLEM
    print("All gates passed: each database matched the module it was asked about, "
          "and every resolved address lies in an executable segment.")
    return EXIT_OK


def classify_relationship(ida_funcs, idautils, idc, ida_name,
                          export_ea: int, target_ea: int) -> str:
    """How does the exported function relate to the pattern's target?

    Returns one of: the export jumps straight to it, the export calls it, the
    export reaches it indirectly at depth N, or they are unrelated.
    """
    ef = ida_funcs.get_func(export_ea)
    tf = ida_funcs.get_func(target_ea)
    if not ef or not tf:
        return "cannot classify (no function bounds)"
    size = ef.end_ea - ef.start_ea
    esize = tf.end_ea - tf.start_ea

    if size <= 8:
        return f"export is a {size}B thunk -> pattern target ({esize}B body)"

    # direct: does the export itself jmp/call the target?
    for ins in idautils.FuncItems(export_ea):
        m = (idc.print_insn_mnem(ins) or "").lower()
        if m in ("jmp", "call") and idc.get_operand_value(ins, 0) == target_ea:
            return f"export {m}s the pattern target directly ({esize}B body)"

    # indirect: breadth-first, bounded
    seen: set[int] = set()
    frontier = [(ef.start_ea, 0)]
    while frontier:
        cur, depth = frontier.pop(0)
        if cur in seen or depth >= 3:
            continue
        seen.add(cur)
        for ins in idautils.FuncItems(cur):
            m = (idc.print_insn_mnem(ins) or "").lower()
            if m in ("call", "jmp"):
                t = idc.get_operand_value(ins, 0)
                if t == target_ea:
                    return (f"export reaches the pattern target indirectly at "
                            f"depth {depth + 1} ({esize}B body)")
                nxt = ida_funcs.get_func(t)
                if nxt and nxt.start_ea == t and t not in seen:
                    frontier.append((t, depth + 1))
    return (f"UNRELATED: export {size}B does not reach the {esize}B pattern "
            f"target within 3 levels -- pattern unproven")


if __name__ == "__main__":
    raise SystemExit(main())
