#!/usr/bin/env python3
"""Independent verification of a compatibility manifest against real PE files.

Why this exists
---------------
`tools/manifest_tool.py validate` is the generator checking its own output.
It answers "is this manifest internally consistent with these bytes?" It does
not, and structurally cannot, answer "is this manifest the *right* bytes?" --
its only semantic assertion is that a declared pattern occurs at least once,
and a unique byte sequence says nothing about whether it is the intended
function. Two functions sharing a prologue differ in byte 9.

That gap is not hypothetical. Cross-checking the shipped profile against the
live module's own export table showed all 8 il2cpp_* pattern symbols resolving
to addresses that differ from the export of the same name. Three turned out to
be correct (the export is a `jmp` thunk whose target *is* the pattern's RVA).
The other five are export wrappers around a distinct internal implementation,
and the ISIL reference shows managed code calling *both* addresses -- so both
are real il2cpp functions and nothing is broken. But the tool cannot tell you
that, and could not tell you if it were.

So this re-derives everything from the raw bytes, importing nothing from
`manifest_tool`:

  * module identity  -- SizeOfImage, PE timestamp, and sha256 of the raw
    on-disk `.text` bytes (raw, not VirtualSize -- see AGENTS.md)
  * patterns         -- scanned across the WHOLE file, which is a strict
    superset of a per-section scan: a match inside a section gap would show up
    here and not there
  * declared RVAs    -- in range, mappable to file bytes, and a member of the
    pattern match set
  * export symbols   -- the export name must actually exist in the module's
    export table, which `validate` never checks

It does NOT re-judge naming, and it cannot tell a correct pattern from a
plausible one. Attributing an address to a function is a semantic call, not a
byte-level one -- that is `dump.cs` / ISIL / IDA territory, and where a pattern
and the module's own export of the same name disagree this tool emits a NOTE and
leaves it open. `load_be_client` is the worked example of why that matters: it is
really `AsyncTaskMethodBuilder.Start<...<RunValidation>d__NN>`, but it is named
for what patching it *does* (MoveNext would have called `BEClient.Start`), and
that name is correct. See `compatibility/REFRESH_RUNBOOK.md`.

It cannot pass by comparing nothing
-----------------------------------
Exit 2 is distinct from 0 and 1 and means *nothing was checked*: no manifest,
no module directory, no symbols, or no module that could be parsed. A verifier
that reports success because it read no files is the failure mode this repo
keeps being bitten by, so "checked 0 symbols" is an error here, not a pass.

It needs the game binaries, which are gitignored (`GameDump/`) -- so this is
not part of `pytest tools/tests`, which must pass on a fresh clone. The
pytest that covers this file runs it against a synthesized minimal PE instead,
and the GameDump-backed run is the manual confirmation.

Usage:
    verify_manifest.py                          # shipped profile, default module dir
    verify_manifest.py <manifest.json> <module-dir>
    verify_manifest.py --cfg-dir TarkovAddons    # cross-check cfg key coverage

Runtime: scans ~105 MB per pattern, so expect a couple of minutes against the
real GameAssembly.dll. `--module-dir` is a local input, never part of the
manifest.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import struct
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Sequence

REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_MANIFEST = REPO_ROOT / "compatibility" / "profiles" / "1.1.5.1.47510" / "manifest.json"
DEFAULT_MODULE_DIR = REPO_ROOT / "TarkovAddons" / "GameDump" / "115147510_tarkov-dump"
DEFAULT_CFG_DIR = REPO_ROOT / "TarkovAddons"

EXIT_OK = 0
EXIT_PROBLEM = 1
EXIT_NOTHING_CHECKED = 2


@dataclass
class Section:
    name: str
    virtual_size: int
    virtual_address: int
    raw_size: int
    raw_pointer: int


class PE:
    """Minimal PE32+ reader. Struct offsets are hardcoded per the spec.

    Not a general parser: it reads exactly what the manifest schema asserts
    (x64 image, section table, .text, export directory) and refuses anything
    else loudly rather than guessing.
    """

    def __init__(self, path: Path) -> None:
        self.path = path
        self.data = path.read_bytes()
        d = self.data
        if len(d) < 0x40 or d[:2] != b"MZ":
            raise ValueError(f"{path}: not an MZ image")
        self.pe_offset = struct.unpack_from("<I", d, 0x3C)[0]
        if self.pe_offset + 4 + 20 > len(d) or d[self.pe_offset:self.pe_offset + 4] != b"PE\0\0":
            raise ValueError(f"{path}: no PE signature")
        fh = self.pe_offset + 4
        self.machine, self.section_count, self.timestamp = struct.unpack_from("<HHI", d, fh)
        optional_size = struct.unpack_from("<H", d, fh + 16)[0]
        opt = fh + 20
        if opt + optional_size > len(d):
            raise ValueError(f"{path}: optional header runs past EOF")
        magic = struct.unpack_from("<H", d, opt)[0]
        if magic != 0x20B:
            raise ValueError(f"{path}: not PE32+ (optional header magic {magic:#x})")
        self.size_of_image = struct.unpack_from("<I", d, opt + 56)[0]
        self.size_of_headers = struct.unpack_from("<I", d, opt + 60)[0]
        if not self.size_of_image or not self.size_of_headers:
            raise ValueError(f"{path}: SizeOfImage/SizeOfHeaders is zero")
        self.image_base = struct.unpack_from("<Q", d, opt + 24)[0]
        self.data_directories = opt + 112
        self.sections: list[Section] = []
        table = opt + optional_size
        for i in range(self.section_count):
            e = table + i * 40
            if e + 40 > len(d):
                raise ValueError(f"{path}: section table runs past EOF")
            name = d[e:e + 8].split(b"\0", 1)[0].decode("ascii", errors="replace")
            vs, va, rs, rp = struct.unpack_from("<IIII", d, e + 8)
            self.sections.append(Section(name, vs, va, rs, rp))

    def text_sha256(self) -> str | None:
        """sha256 of the RAW on-disk .text bytes, not VirtualSize."""
        for s in self.sections:
            if s.name.lower() == ".text" and s.raw_size:
                return sha256_of(self.path, s.raw_pointer, s.raw_size)
        return None

    def file_offset(self, rva: int, length: int = 1) -> int | None:
        if rva < 0 or length < 0 or rva + length > self.size_of_image:
            return None
        if rva < self.size_of_headers:
            return rva if rva + length <= len(self.data) else None
        for s in self.sections:
            span = max(s.virtual_size, s.raw_size)
            if not span or not (s.virtual_address <= rva < s.virtual_address + span):
                continue
            delta = rva - s.virtual_address
            if delta + length > s.raw_size:
                return None
            off = s.raw_pointer + delta
            return off if off + length <= len(self.data) else None
        return None

    def rva_at_file_offset(self, offset: int) -> int | None:
        for s in self.sections:
            if s.raw_pointer <= offset < s.raw_pointer + s.raw_size:
                return s.virtual_address + (offset - s.raw_pointer)
        return None

    def export_table(self) -> dict[str, int]:
        """name -> RVA for every named export. Empty if there is no export dir."""
        exp_rva, _ = struct.unpack_from("<II", self.data, self.data_directories)
        if not exp_rva:
            return {}
        base = self.file_offset(exp_rva, 40)
        if base is None:
            return {}
        (_c, _t, _m, _s, _n, _ob, nfunc, nnames, afunc, anames,
         aords) = struct.unpack_from("<IIHHIIIIIII", self.data, base)
        nb = self.file_offset(anames, nnames * 4)
        ob = self.file_offset(aords, nnames * 2)
        fb = self.file_offset(afunc, nfunc * 4)
        if None in (nb, ob, fb):
            return {}
        out: dict[str, int] = {}
        for i in range(nnames):
            name_rva = struct.unpack_from("<I", self.data, nb + i * 4)[0]
            ordinal = struct.unpack_from("<H", self.data, ob + i * 2)[0]
            if ordinal >= nfunc:
                continue
            func_rva = struct.unpack_from("<I", self.data, fb + ordinal * 4)[0]
            no = self.file_offset(name_rva)
            if no is None:
                continue
            end = self.data.find(b"\0", no)
            if end < 0:
                continue
            out[self.data[no:end].decode("ascii", errors="replace")] = func_rva
        return out

    def scan(self, pattern: Sequence[int | None]) -> list[int]:
        """Match RVAs anywhere in the file (not per-section), anchored."""
        if not pattern:
            return []
        anchor_index = next((i for i, v in enumerate(pattern) if v is not None), None)
        n = len(pattern)
        if anchor_index is None:
            return []
        anchor = bytes([pattern[anchor_index] or 0])
        hits: list[int] = []
        pos = self.data.find(anchor)
        while pos != -1:
            start = pos - anchor_index
            if start >= 0 and start + n <= len(self.data) and all(
                v is None or self.data[start + j] == v for j, v in enumerate(pattern)
            ):
                rva = self.rva_at_file_offset(start)
                if rva is not None:
                    hits.append(rva)
            pos = self.data.find(anchor, pos + 1)
        return hits


def parse_pattern(text: str) -> list[int | None]:
    out: list[int | None] = []
    for token in text.split():
        if token in ("?", "??"):
            out.append(None)
        elif re.fullmatch(r"[0-9A-Fa-f]{2}", token):
            out.append(int(token, 16))
        else:
            raise ValueError(f"invalid pattern token {token!r}")
    return out


def format_bytes(chunk: Iterable[int]) -> str:
    return " ".join(f"{b:02X}" for b in chunk)


def sha256_of(path: Path, offset: int = 0, length: int | None = None) -> str:
    """Streamed sha256 of a file, or of a byte range within it."""
    h = hashlib.sha256()
    remaining = length
    with path.open("rb") as fh:
        if offset:
            fh.seek(offset)
        for chunk in iter(lambda: fh.read(1 << 22), b""):
            if remaining is not None:
                chunk = chunk[:remaining]
                remaining -= len(chunk)
                if not chunk:
                    break
            h.update(chunk)
    return h.hexdigest()


@dataclass
class Report:
    problems: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    symbols_checked: int = 0
    modules_checked: int = 0

    def problem(self, msg: str) -> None:
        self.problems.append(msg)

    def note(self, msg: str) -> None:
        self.notes.append(msg)


def verify(manifest: Any, module_dir: Path, cfg_dir: Path | None = None,
           verbose: bool = True) -> Report:
    rep = Report()
    if not isinstance(manifest, dict):
        rep.problem("$: manifest root must be an object")
        return rep
    symbols = manifest.get("symbols")
    modules = manifest.get("modules")
    if not isinstance(symbols, list) or not symbols:
        rep.problem("symbols: manifest declares no symbols -- nothing to verify")
        return rep
    if not isinstance(modules, dict) or not modules:
        rep.problem("modules: manifest declares no modules -- cannot check identity")
        return rep

    pes: dict[str, PE] = {}
    exports: dict[str, dict[str, int]] = {}

    for name, desc in modules.items():
        path = module_dir / name
        if not path.is_file():
            rep.problem(f"modules.{name}: not present in {module_dir}")
            continue
        try:
            pe = PE(path)
        except (ValueError, OSError) as exc:
            rep.problem(f"modules.{name}: {exc}")
            continue
        pes[name] = pe
        rep.modules_checked += 1
        exports[name] = pe.export_table()
        if verbose:
            print(f"  module {name}: SizeOfImage={pe.size_of_image} "
                  f"timestamp=0x{pe.timestamp:08X} machine=0x{pe.machine:04X} "
                  f"sections={pe.section_count} exports={len(exports[name])}")
        if not isinstance(desc, dict):
            rep.problem(f"modules.{name}: descriptor must be an object")
            continue
        for field_name, actual in (("size", pe.size_of_image),
                                   ("pe_timestamp", f"0x{pe.timestamp:08X}"),
                                   ("text_sha256", pe.text_sha256())):
            want = desc.get(field_name)
            if want is None:
                rep.note(f"modules.{name}.{field_name} not declared; not checked")
            elif str(want).lower() != str(actual).lower():
                rep.problem(f"modules.{name}.{field_name}: manifest {want!r} != module {actual!r}")
        if pe.text_sha256 is None:
            rep.problem(f"modules.{name}: no .text section to hash")

    if not pes:
        rep.problem(f"no module could be parsed from {module_dir}")
        return rep

    for index, sym in enumerate(symbols):
        if not isinstance(sym, dict):
            rep.problem(f"symbols[{index}]: not an object")
            continue
        name = sym.get("name")
        module = sym.get("module")
        if not isinstance(name, str) or not name:
            rep.problem(f"symbols[{index}].name: must be a non-empty string")
            continue
        pe = pes.get(module)
        if pe is None:
            rep.problem(f"symbols[{index}] {name}: module {module!r} unavailable")
            continue
        resolver = sym.get("resolver", "native")
        rva_raw = sym.get("rva")
        rva = None
        if rva_raw is not None:
            try:
                rva = int(str(rva_raw), 0)
            except ValueError:
                rep.problem(f"symbols[{name}].rva: {rva_raw!r} is not numeric")

        patterns = sym.get("patterns") or []
        if not isinstance(patterns, list):
            rep.problem(f"symbols[{name}].patterns: must be an array")
            patterns = []

        all_hits: set[int] = set()
        unique = True
        for pi, ptext in enumerate(patterns):
            if not isinstance(ptext, str):
                rep.problem(f"symbols[{name}].patterns[{pi}]: must be a string")
                continue
            try:
                parsed = parse_pattern(ptext)
            except ValueError as exc:
                rep.problem(f"symbols[{name}].patterns[{pi}]: {exc}")
                continue
            hits = pe.scan(parsed)
            if not hits:
                rep.problem(f"symbols[{name}].patterns[{pi}]: no match anywhere in {module}")
            elif len(hits) > 1:
                unique = False
                rep.problem(f"symbols[{name}].patterns[{pi}]: {len(hits)} matches "
                            f"(ambiguous -- the first few: "
                            f"{', '.join(hex(h) for h in hits[:4])})")
            all_hits.update(hits)

        if resolver == "export":
            want = sym.get("export_name") or name
            if want not in exports[module]:
                rep.problem(f"symbols[{name}]: export {want!r} is absent from "
                            f"{module} ({len(exports[module])} named exports)")
            if rva is not None:
                rep.note(f"symbols[{name}]: resolver=export but an rva is also set")

        # A pattern-resolver symbol whose name is also exported: the two are
        # independent addresses, and this tool cannot adjudicate between them.
        # Measured on 1.1.5.1.47510 with IDA, the outcome falls in three classes:
        #   * the export is a 5-byte `jmp` thunk to the pattern's RVA
        #     (il2cpp_type_get_object, il2cpp_field_static_set_value)
        #   * the export `call`s or `jmp`s the pattern's target
        #     (il2cpp_class_get_nested_types, il2cpp_class_get_field_from_name)
        #     -- the pattern found the implementation the export wraps
        #   * the export is an independent function that reaches the pattern's
        #     target only indirectly
        # Only IDA or a live run can tell the third class apart from a wrong
        # pattern, so this is a NOTE, never a failure.
        if patterns and resolver != "export" and name in exports.get(module, {}):
            exp_rva = exports[module][name]
            if all_hits and exp_rva not in all_hits:
                rep.note(f"symbols[{name}]: pattern resolves to "
                         f"{', '.join(hex(h) for h in sorted(all_hits))} but the "
                         f"{module} export of the same name is {hex(exp_rva)}; "
                         f"unresolved without an oracle -- see the note on "
                         f"semantic checks in this file's header")

        if rva is not None:
            if rva >= pe.size_of_image:
                rep.problem(f"symbols[{name}].rva: {hex(rva)} is outside "
                            f"SizeOfImage {pe.size_of_image}")
            else:
                off = pe.file_offset(rva, 1)
                if off is None:
                    rep.problem(f"symbols[{name}].rva: {hex(rva)} does not map to file bytes "
                                f"(unbacked virtual range)")
                else:
                    head = format_bytes(pe.data[off:off + 8])
                    if verbose:
                        print(f"    {name}: rva {hex(rva)} -> {head}")
            if patterns and rva not in all_hits:
                rep.problem(f"symbols[{name}].rva: {hex(rva)} is not among the pattern matches "
                            f"({', '.join(hex(h) for h in sorted(all_hits)[:4])})")

        if resolver == "native" and rva is None and not patterns:
            rep.note(f"symbols[{name}]: no rva and no pattern; depends on an "
                     f"external/built-in resolver")
        if patterns and unique and all_hits and verbose:
            rep.note(f"symbols[{name}]: {len(patterns)} pattern(s), each unique")
        rep.symbols_checked += 1

    # cfg coverage: a key declared in the legacy files with no manifest symbol is
    # an invisible dependency, which is exactly how hwid_check went missing once.
    if cfg_dir:
        shipped = {s.get("name") for s in symbols if isinstance(s, dict)}
        for cfg_name in ("offsets.cfg", "patterns.cfg"):
            cfg = cfg_dir / cfg_name
            if not cfg.is_file():
                rep.note(f"{cfg_name}: not found at {cfg}")
                continue
            keys = set()
            for line in cfg.read_text(encoding="utf-8-sig").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key = line.split("=", 1)[0].strip()
                if key:
                    keys.add(key)
            missing = sorted(keys - shipped)
            if verbose:
                print(f"  cfg {cfg_name}: {len(keys)} keys, "
                      f"{len(keys & shipped)} present in the manifest, "
                      f"{len(missing)} absent")
            for key in missing:
                rep.note(f"{cfg_name} key {key!r} has no manifest symbol")

    return rep


def main(argv: Sequence[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("manifest", nargs="?", default=str(DEFAULT_MANIFEST),
                    help=f"manifest JSON (default: {DEFAULT_MANIFEST})")
    ap.add_argument("module_dir", nargs="?", default=str(DEFAULT_MODULE_DIR),
                    help=f"directory holding the modules (default: {DEFAULT_MODULE_DIR})")
    ap.add_argument("--cfg-dir", default=str(DEFAULT_CFG_DIR),
                    help="directory holding offsets.cfg/patterns.cfg, or '' to skip")
    ap.add_argument("-q", "--quiet", action="store_true", help="only print problems")
    args = ap.parse_args(argv)

    manifest_path = Path(args.manifest)
    module_dir = Path(args.module_dir)
    cfg_dir = Path(args.cfg_dir) if args.cfg_dir else None

    if not manifest_path.is_file():
        print(f"ERROR manifest not found: {manifest_path}")
        return EXIT_NOTHING_CHECKED
    if not module_dir.is_dir():
        print(f"ERROR module directory not found: {module_dir}")
        print("       GameDump/ is gitignored -- restore it locally before verifying.")
        return EXIT_NOTHING_CHECKED
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR cannot read {manifest_path}: {exc}")
        return EXIT_NOTHING_CHECKED

    if not args.quiet:
        print(f"manifest : {manifest_path}")
        print(f"modules  : {module_dir}\n")
    rep = verify(manifest, module_dir, cfg_dir, verbose=not args.quiet)

    if not args.quiet:
        print()
    for note in rep.notes:
        print(f"NOTE {note}")
    if rep.notes:
        print()

    if rep.symbols_checked == 0 or rep.modules_checked == 0:
        print("ERROR nothing was verified -- treat this as a tooling failure, "
              "not a pass")
        for p in rep.problems:
            print(f"  - {p}")
        return EXIT_NOTHING_CHECKED
    if rep.problems:
        print(f"FAIL {len(rep.problems)} problem(s) across "
              f"{rep.symbols_checked} symbol(s):")
        for p in rep.problems:
            print(f"  - {p}")
        return EXIT_PROBLEM
    print(f"PASS {rep.symbols_checked} symbol(s) verified against "
          f"{rep.modules_checked} module(s) in {module_dir}")
    return EXIT_OK


if __name__ == "__main__":
    raise SystemExit(main())