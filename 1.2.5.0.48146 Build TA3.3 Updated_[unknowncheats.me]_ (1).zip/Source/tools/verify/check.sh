#!/usr/bin/env bash
# Syntax-stage verification oracle for TarkovAddons.
#
# The real build is MSVC. This is not a build: it is a -fsyntax-only pass with
# mingw-w64 g++, plus a fingerprint of whatever survives, so that a large
# mechanical refactor cannot silently regress. It cannot link (linkcheck.py
# does that) and it cannot prove runtime behaviour.
#
# THE INVARIANT
# -------------
# The fingerprint must be EMPTY. Not "no worse than before" -- empty. The
# pre-split tree was verified to produce zero residual signatures, so anything
# at all is a regression. That is a stronger and simpler criterion than a
# stored baseline, and it cannot rot when the toolchain moves.
#
# Modelling MSVC
# --------------
# Four command-line definitions exist only so that MSVC-only source parses,
# and real errors are not buried under cascades:
#
#   -DUNICODE -D_UNICODE   The project sets <CharacterSet>Unicode</CharacterSet>;
#                          MSBuild injects these. Without them
#                          GetModuleHandle(L"d3d11.dll") resolves to the A form
#                          and reports a type error in every TU.
#   -D_SECURITY_ATTRIBUTES_  Works around a mingw-w64 header bug: minwinbase.h
#                          defines SECURITY_ATTRIBUTES unconditionally while
#                          wtypesbase.h re-defines it behind a differently-spelled
#                          guard. See msvc-shim/Windows.h for the full story.
#   -D__try=try            SEH. GCC has no __try/__except, and a single
#   -D'__except(x)=catch(...)'  unparsed frame derails the rest of its header.
#
# A fifth accommodation cannot be expressed as a flag and is why linkcheck.py
# needs a shadow tree: the project casts void* to a function pointer with
# static_cast. MSVC accepts it; C++ only conditionally supports it and GCC
# rejects it outright, so 46 casts stop translation units producing any output
# at all. linkcheck.py rewrites those to reinterpret_cast in a throwaway copy.
# Here it does not matter, because the affected diagnostics are filtered anyway
# and the pass only has to parse.
#
# Usage:
#   ./check.sh                    -> print the fingerprint
#   OUT=/path ./check.sh          -> also write it there
#   REPO=/path ./check.sh         -> run against another checkout/worktree
set -uo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
REPO=${REPO:-$(cd "$HERE/../.." && pwd)}
SHIM=${SHIM:-$REPO/tools/verify/msvc-shim}
OUT=${OUT:-}
RAW=$(mktemp)
trap 'rm -f "$RAW"' EXIT
cd "$REPO" || exit 1

if [ ! -d "$SHIM" ]; then
  echo "msvc-shim directory missing: $SHIM" >&2
  echo "It supplies the Win32 headers mingw-w64 does not ship (Windows.h," >&2
  echo "Psapi.h, shlobj.h). See tools/verify/README.md." >&2
  exit 2
fi

FLAGS=(
  -std=c++23 -fsyntax-only
  -DINCLUDE_AIMBOT -DNDEBUG -D_CRT_SECURE_NO_WARNINGS -DWIN32_LEAN_AND_MEAN
  -DUNICODE -D_UNICODE
  -D_SECURITY_ATTRIBUTES_
  -D__try=try
  '-D__except(x)=catch(...)'
  -I "$SHIM"
  # $(ProjectDir) is first in the project's AdditionalIncludeDirectories, and it
  # is load-bearing: 71 of the 82 translation units say #include "pch.h" with no
  # directory, so without this the bare name cannot resolve from config/ or
  # module/impl/. See WORKFLOW.md, "The precompiled header -- a trap".
  -I TarkovAddons
  -I external
  -I TarkovAddons/external
  -I TarkovAddons/external/imgui
  -I TarkovAddons/external/tracy
)

# Every first-party translation unit in TarkovAddons.vcxproj.
TUS=$(grep -oE '<ClCompile Include="[^"]+"' TarkovAddons/TarkovAddons.vcxproj \
        | sed 's/.*Include="//; s/"$//' \
        | grep -vE 'external|libil2cpp' \
        | sed 's|\\|/|g; s|^|TarkovAddons/|')

: > "$RAW"
for tu in $TUS; do
  if [ ! -f "$tu" ]; then
    echo "$tu:1:1: error: MISSING_TU" >> "$RAW"
    continue
  fi
  # Model MSVC's /Yu: every first-party TU force-includes the PCH, when one is
  # configured. Vendored TUs opt out via NotUsing and are excluded above.
  pch=()
  # The PCH is TarkovAddons/include/common.h (was pch.h). The [ -f ] guard keeps
  # this working either way rather than assuming the rename.
  for _pch in TarkovAddons/include/common.h TarkovAddons/pch.h; do
    if [ -f "$_pch" ]; then
      [ "$tu" != "TarkovAddons/pch.cpp" ] && pch=(-include "$_pch")
      break
    fi
  done
  timeout 900 x86_64-w64-mingw32-g++ "${FLAGS[@]}" "${pch[@]}" "$tu" >> "$RAW" 2>&1
done

FINGERPRINT=$(python3 "$HERE/signatures.py" "$RAW" "$REPO")
COUNT=$(printf '%s' "$FINGERPRINT" | grep -c . || true)
echo "$FINGERPRINT"
[ -n "$OUT" ] && printf '%s\n' "$FINGERPRINT" > "$OUT"
echo "fingerprint: $COUNT residual error signature(s) across $(echo "$TUS" | wc -w) translation units" >&2
[ "$COUNT" -eq 0 ]
