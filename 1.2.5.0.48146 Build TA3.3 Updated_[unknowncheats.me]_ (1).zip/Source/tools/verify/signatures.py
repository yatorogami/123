#!/usr/bin/env python3
"""Fold compiler output into a fingerprint of residual errors.

Why a fingerprint and not an error count
----------------------------------------
The obvious measure -- how many errors -- is useless for this refactor, and
worse than useless: it moves for reasons that have nothing to do with the code.
Splitting one header into a header plus a .cpp adds a translation unit that
includes the header, so an error that was already inside that header is now
reported a second time, and the count rises with no new defect. A sweep of 64
files looked like a growing bug count for exactly this reason.

So the unit of measurement is a signature, not a diagnostic. Two properties make
the set stable:

  * the *file* is kept, because that is what distinguishes an error in
    hideout_reflection.h from a genuinely new one in hideout_reflection.cpp --
    exactly the pair the split was about;
  * line and column are dropped, because the same defect moves when code moves,
    and it is reported by every translation unit that reaches the header, so
    with line numbers retained no header defect would ever collapse to one entry.

On top of that, paths are resolved. GCC echoes the spelling used in the
#include directive, so quest_esp.h arrives as module/quest_esp.h from one
translation unit and as module/impl/../quest_esp.h from another; without
normpath the same single error counts several times.

Filtered as MSVC-only noise
---------------------------
  invalid «X» from type «X» to type «X»   void* -> function pointer, MSVC-legal
  invalid conversion from                   the reverse
Both are the same construct check.sh's preamble describes; see linkcheck.py,
which cannot filter them because it needs real objects.

Usage:  signatures.py <raw-output-file> <repo-root>
"""
import os
import re
import sys

DIAG = re.compile(r'^(?P<file>[^:]+):(?P<line>\d+):(?P<col>\d+):\s*'
                  r'(?:fatal error|error):\s*(?P<msg>.*)$')

# `invalid «void* const» to «int (*)(...)»` and `invalid conversion from`:
# the void*/function-pointer conversion, accepted by MSVC.
BENIGN = re.compile(r'invalid «[^»]*» from type|invalid conversion from')

# Quoted names and bare numbers vary between translation units for reasons that
# do not affect the defect, so they are collapsed -- but the delimiters are kept,
# because they are part of the diagnostic's shape. GCC quotes with guillemets,
# and "expected unqualified-id before «,» token" collapsing to "... before X
# token" would read as a different defect from the one it stands for.
QUOTED = (('«[^»]*»', '«X»'),
          ('`[^`]*`', '`X`'),
          ('"[^"\n]*"', '"X"'))
NUMBER = re.compile(r'\b\d+\b')


def normalise(msg):
    for pattern, replacement in QUOTED:
        msg = re.sub(pattern, replacement, msg)
    return NUMBER.sub('N', msg).strip()


def main():
    if len(sys.argv) != 3:
        print(__doc__.strip().splitlines()[-1], file=sys.stderr)
        return 2
    raw, repo = sys.argv[1], os.path.abspath(sys.argv[2])

    with open(raw, errors='replace') as handle:
        lines = handle.read().splitlines()
    signatures = set()
    for line in lines:
        # A diagnostic inside an #include expansion is prefixed with "In file
        # included from ...:", and the path is on its own line. Only lines that
        # actually carry file:line:col are diagnostics in their own right.
        found = DIAG.match(line.strip())
        if not found:
            continue
        msg = found.group('msg')
        if BENIGN.search(msg):
            continue
        path = found.group('file')
        if not os.path.isabs(path):
            path = os.path.normpath(os.path.join(repo, path))
        signatures.add(f'{os.path.relpath(path, repo)}: error: {normalise(msg)}')

    for sig in sorted(signatures):
        print(sig)
    return 0


if __name__ == '__main__':
    sys.exit(main())
