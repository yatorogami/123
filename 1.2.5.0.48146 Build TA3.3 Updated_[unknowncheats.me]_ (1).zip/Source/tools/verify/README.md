# tools/verify

Verification for the header → header+cpp refactor and for the include sweep that
followed it. Here because the first version of this lived in `/tmp/opencode`,
and `/tmp` took all of it — the same temp cleanup that destroyed the `ta_tests`
harnesses recorded in `TarkovAddons/Workstream_status_2026-09-24.md`. That loss
is the reason this directory exists: **an assertion with no artefact behind it is
not evidence**, and the refactor's commit messages were, for a while, exactly
that.

Run from the repository root. Linux with `x86_64-w64-mingw32-g++` and
`clang-tidy`; nothing here touches the Windows tree.

**`audit.py` and `signatures.py` are cross-platform and are the only two that
can be run on a Windows host** — `check.sh` needs bash, mingw and `clang-tidy`,
and `linkcheck.py` needs `nm`/`objdump`, so the syntax stage and the link stage
have **no** coverage on Windows. The link stage is the one that found the
`inline`-on-a-moved-body defect, so that gap is not academic.

---

## Status

| | | |
|---|---|---|
| `check.sh` | **working** — 0 residual signatures across 71 first-party TUs (Linux only) |
| `linkcheck.py` | **working** — 82 objects, 0 duplicate definitions (Linux only) |
| `audit.py` | **working**, no compiler needed, runs on Windows and Linux |
| `signatures.py` | **working**, verified against known answers |
| `verify_manifest.py` | **working** — 21/21 symbols against `GameDump`, exit 0; needs the gitignored game binaries, so not in `pytest` |
| `ida_manifest.py` | **working** — both `.i64` input hashes match, all addresses named, exit 0; needs a licensed IDA, so not in `pytest` |
| `verify_lang_embedded.py` | **working** — 19/19 locales match `lang/`, exit 0; needs a built DLL, so not in `pytest` |
| `verify_i18n_keys.py` | **working** — reports 24 naming defects (exit 1); pure text, runs on Windows |

Last run on Windows 2026-10-06: `verify_manifest.py` 21/21 symbols, both modules,
cfg coverage 20/20 and 13/13, exit `0`. `ida_manifest.py` on the same profile:
both database input hashes matched, every resolved address in an executable
segment, exit `0`, and the pattern-vs-export table classified all 8 `il2cpp_*`
symbols as benign. `verify_manifest.py`'s five "checked nothing" paths were
negative-controlled to exit `2`, and one tamper case initially failed to fire —
see **It cannot pass by comparing nothing** under its own section for why that
was a vacuous control rather than a bug.

Last run on Windows 2026-09-30: `audit.py` 58 pairs / 337 `conf()` / 19 lost /
exit 0, with its `as_posix()` fix negative-controlled. Before that fix it was
exit 0 over **zero** pairs — see **It cannot pass by comparing nothing** below.

All six are validated by negative control, not just by a green result — see
**Validation** at the end. A checker that reports success because it silently did
nothing is the failure mode this whole directory exists to prevent, and three of
the tools here produced exactly that before they were fixed.

**This directory is not the test suite.** It verifies the header→header+cpp
refactor and the include sweep. The executable unit coverage lives in
`tools/harness` (19 cases, `run_windows.bat`) and `tools/tests` (480
passed, 23 subtests, 15 skipped, 4 failed — measured 2026-10-12 **on Linux**, so
see `AGENTS.md` for which failures are platform artefacts). Both counts were 7 and 139 here until 2026-10-05, when they were
corrected against the runners; `WORKFLOW.md` had 11 and 155, `tools/README.md`
had 149. Three files, three answers, none measured. The native case count is now
re-derived from `run_windows.bat` on every run by `tools/tests/test_doc_counts.py`,
so this file cannot drift from the runner again on that number. The distinction between this
directory and the test suite matters because this directory's tools are largely
**Linux-only** — `check.sh` needs bash, mingw and `clang-tidy`; `linkcheck.py`
needs `nm`/`objdump` — and only `audit.py` and `signatures.py` run on a Windows
host. The link stage is the one that found the `inline`-on-a-moved-body defect,
so that gap is not academic, and nothing since has closed it.

The two i18n tools are Windows-only by the opposite route: both parse a built
DLL or read `lang/*.json`, neither needs a compiler.

---

## The two i18n tools — two different questions

They look adjacent and are not, which is why both exist.

| | question | input |
|---|---|---|
| `verify_lang_embedded.py` | are the translations **in the DLL** the ones on disk? | a built DLL |
| `verify_i18n_keys.py` | are the **keys themselves** sound? | source + `lang/en.json` |

```sh
python tools/verify/verify_lang_embedded.py       # newest build DLL
python tools/verify/verify_lang_embedded.py <dll> # or a specific one
python tools/verify/verify_i18n_keys.py
```

**Why the second one had to exist.** `menu_background.rc` embeds `lang/*.json`
as RCDATA 1300-1318, and `rc.exe` reports no dependency on the files it
embeds — so editing a translation did not re-run the resource step, and the
2026-10-11 DLL carried the 2026-10-08 snapshot: **347 key/locale pairs**
missing, `container_chams_cb` among them. `i18n::tr()` returns the key itself
on a miss, so each one rendered as a raw config key. Fixed with
`OBJECT_DEPENDS` (`CMakeLists.txt`) and `AdditionalDependencies` (`.vcxproj`).

But that fix is invisible to a checker that only reads source: `en.json` was
always correct. A tool comparing the DLL against `lang/` proves the files got
embedded; it says nothing about whether `Search` should have been `search_txt`.
That is the layer `verify_i18n_keys.py` covers, and it reports **24 defects
that no other check in this repository can see**.

Its fourth check (dead language lines: 385 of 735 in `en.json`) is reported
but does not fail the run — untidy, not user-visible. Checks 1-3 all are, so
they do.

### The one that must not fire

WorldModule's 73 bot names (`Glukhar`, `Reshala Guard`, …) and its
`Easy/Normal/Hard/Impossible` scale are raw English **on purpose**, and both
pass `/*translate_options=*/false`. A tool blind to that flag reports them as
defects. Getting it right took two corrections, both recorded in the source:

- the flag is **inside a comment**, so a comment-stripping pass cannot see it,
  and offsets from the raw and stripped texts are not interchangeable;
- the argument-marker form puts `*/` **between** `=` and `false`, so
  `translate_options\s*=\s*false` does not match it. Fixing only the first
  still flagged both legitimate sites.

Eight negative controls, including a per-site assertion on those two lists so
it cannot pass by inspecting the wrong one.

---

## `audit.py` — content preservation (works today)

```sh
python3 tools/verify/audit.py
```

The compiler proves *shape*: a name is still declared, a header still compiles,
an initialiser list still parses. It says nothing about *content*, and content
is where a mechanical split loses something that still compiles. The specific
failure this catches:

> A `conf()` initialiser dropped from a header and never added to the
> constructor's member-initialiser list. The member becomes a null pointer, the
> build is clean, the menu draws without one row, and nothing reports an error.

That is the whole reason a 6,777-line file could be moved without a test failing.

For each split pair it compares **the pre-split header** against **the header and
cpp as the splitting commit left them**, both read from git:

- **`conf()` multiset** must be equal. `conf()` is never added, removed or
  reworded by a split, only relocated from an initialiser to a
  member-initialiser, so this is an exact equality, not a heuristic.
- **Identifier multiset** — any net loss is reported. `static` and `inline` are
  the only expected losses, and why is recorded in `EXPECTED_LOSS`.
- **Comment line count** must not fall.
- **Class names** must all survive.

Two design points worth keeping if this is ever modified:

- **Each pair is compared against its own pre-split revision**, the parent of the
  commit that created its `.cpp`. A single global base cannot distinguish "the
  split lost this" from "someone legitimately changed this file later", so every
  unrelated later edit reads as refactor damage.
- **Neither side is read from the working tree.** The verdict is about the
  refactor, permanently. Reading HEAD would make the answer change every time
  anyone edits a header, which defeats the point of standing evidence.

Current result: **58 pairs, 337 `conf()` initialisers preserved, 19 identifiers
lost (all `static`/`inline`), no content loss.** 9 pairs are skipped, in two
categories that are now reported separately because they mean different things:
7 are pre-existing header/cpp pairs that predate the refactor, so no split commit
exists to compare against, and 2 (`compatibility_profile.h`, `tracy_bridge.h`)
had their header and cpp added by the *same* commit, so there is no pre-split
state to compare against either. Both are listed in the output rather than
dropped silently.

### It cannot pass by comparing nothing

This is the property that was missing, and getting it wrong is how the tool
reported "no content loss detected" with **exit 0 while checking zero pairs** on
Windows. Two independent defects, both Windows-only, both silent:

1. `split_pairs()` built repo-relative paths with `str(Path.relative_to(...))`,
   which is backslash-separated on Windows, and fed them to
   `git show <rev>:<path>` — whose path syntax is POSIX-only. Git reports the
   miss on **stderr** and prints nothing on stdout, so `git()` returned `''`,
   `if not old or not new` fired, and every pair was skipped. Discovery was
   unaffected because `--` pathspecs *do* tolerate backslashes, which is exactly
   why the tool kept finding pairs and kept saying everything was fine.
2. `git()` used `text=True` with no `encoding=`, so git's UTF-8 output was
   decoded with the ANSI codepage and raised `UnicodeDecodeError` inside
   `subprocess`'s reader thread. This one was *hidden behind* the first: fix the
   pathspec alone and the tool crashes instead of lying.

Both are fixed, and the tool now refuses to give a verdict it cannot support:

- Paths are built with `as_posix()` and stay that way.
- `git()` passes `encoding='utf-8', errors='replace'`.
- Skips are bucketed by reason, and a skip where the header provably **exists**
  at the revision is a defect, not a gap — it exits 2 and says so.
- **Comparing zero pairs is a hard error (exit 2), not a pass.** A run that
  cannot support the content-preservation claim says the claim is unknown rather
  than printing a green result.

Verified in both directions: with the fix, 58 pairs / 337 `conf()` / 19 lost /
exit 0. With `as_posix()` reverted, it exits 2 with `NOTHING WAS COMPARED`, not
`no content loss detected`.

---

## `signatures.py` — error fingerprinting (works today)

Folds compiler output into a set of `file: error: message` signatures.

Counting errors is useless for this refactor and worse than useless: splitting a
header adds a translation unit that includes it, so an error already inside that
header is reported twice and the count rises with no new defect. A sweep of 64
files looked like a growing bug count for exactly that reason. So the unit is a
signature, with three normalisations that make the set stable:

- **line and column dropped** — the same defect moves when code moves, and it is
  reported by *every* TU that reaches the header, so with line numbers retained
  no header defect would ever collapse to one entry;
- **paths resolved** — GCC echoes the spelling from the `#include` directive, so
  `quest_esp.h` arrives as `module/quest_esp.h` from one TU and
  `module/impl/../quest_esp.h` from another;
- **the file is kept** — that is what distinguishes an error in
  `hideout_reflection.h` from a new one in `hideout_reflection.cpp`, which is
  the exact pair the split was about.

Verified against seven signatures recorded during the refactor, including the
path-normalisation and benign-filter cases: 7/7 reproduce exactly.

Filtered as MSVC-only noise: `invalid «X» from type «X» to type «X»` and
`invalid conversion from` — the `void*` ↔ function-pointer conversion, legal on
MSVC.

---

## `verify_manifest.py` — compatibility manifest vs the real PE files

```powershell
python tools/verify/verify_manifest.py          # shipped profile + default module dir
python tools/verify/verify_manifest.py <manifest.json> <module-dir> [--cfg-dir DIR]
```

Re-derives a manifest's claims from the raw bytes, importing **nothing** from
`tools/manifest_tool.py`. Exit `0` clean, `1` problem found, `2` nothing
checked.

Why a second tool when `manifest_tool.py validate` exists: validate is the
generator checking its own output. It answers "is this manifest internally
consistent with these bytes?" and cannot answer "is this manifest the *right*
bytes?" — its only semantic assertion is that a declared pattern occurs at least
once, and a unique byte sequence says nothing about whether it is the intended
function. Two functions can share a prologue and diverge at byte 9.

It checks module identity (`SizeOfImage`, PE timestamp, and sha256 of the **raw
on-disk** `.text` bytes — not `VirtualSize`), scans every pattern across the
**whole file** (a strict superset of a per-section scan), requires declared RVAs
to be in range, mappable, and members of the pattern match set, and requires
every `export`-resolver symbol's name to exist in the module's export table —
which `validate` never checks. It also reports cfg key coverage, because a
legacy key with no manifest symbol is an invisible dependency, which is how
`hwid_check` went missing once.

### It cannot pass by comparing nothing

Exit `2` is distinct from `0` and `1` and means *nothing was checked*: no
manifest, no module directory, no symbols, no modules, or no module that parses.
"Verified 0 symbols" is an error, never a pass. Five tests assert exactly that —
missing manifest, missing module dir, empty `symbols`, empty `modules`, and an
unparseable module all have to produce `2`, because a verifier that reports
success because it read no files is the failure mode this repo keeps being
bitten by.

A deliberate negative control exists for the same reason: one of the six
tamper cases in the manual run initially did **not** fire, and that turned out to
be a vacuous control rather than a verifier bug — it cleared the pattern *and*
moved the RVA, and `resolution_order: ["pattern","export"]` never consults an
RVA at all, so the tamper was inert. The fixed version keeps the pattern and
moves only the RVA, and fires. `test_the_verifier_can_fail` sabotages the shipped
profile's hash and pattern in one go and requires exit `1`.

### What it deliberately does not decide

Naming and identity of functions. Where a pattern and the module's own export of
the same name disagree, it emits a **NOTE** and stays at exit `0`, because
adjudicating needs an oracle this file does not have. Measured on
`1.1.5.1.47510` with IDA, that disagreement has three distinct shapes, only two
of which are benign:

| shape | example | verdict |
|---|---|---|
| export is a 5-byte `jmp` thunk to the pattern's RVA | `il2cpp_type_get_object`, `il2cpp_field_static_set_value` | pattern correct |
| export `call`s / `jmp`s the pattern's target | `il2cpp_class_get_nested_types`, `il2cpp_class_get_field_from_name` | pattern correct |
| export is independent, reaching the target only indirectly | `il2cpp_class_from_name`, `il2cpp_class_get_method_from_name`, `il2cpp_field_static_get_value` | **unresolved** |

The last row is a real gap, not a defect this tool can report: three required
symbols resolve by pattern to unnamed internal functions, and only a live
launch can say whether those are functionally-equivalent variants. Their
patterns are byte-identical to the hardcoded fallbacks in
`il2cpp_offsets.h:659-681`, so this predates the manifest.

Requires `GameDump/`, which is gitignored, so it is **not** part of
`pytest tools/tests`. `tools/tests/test_verify_manifest.py` covers it against a
synthesized minimal PE instead; the `GameDump`-backed run is the manual
confirmation. Current status: 19/19 symbols, both modules, exit `0`.

---

## `ida_manifest.py` — name every address, using IDA

```powershell
python tools/verify/ida_manifest.py           # shipped profile + default module dir
python tools/verify/ida_manifest.py <manifest.json> <module-dir>
```

The semantic half. `verify_manifest.py` proves the bytes match; this proves they
are the *right* function, because a unique byte sequence does not name anything.
Exit `0` gates passed, `1` a gate failed, `2` could not run.

**It has three gates, and each one exists because I got it wrong.** They are the
reason to trust its output:

1. **The `.i64` must describe the exact bytes.** IDA records the sha256 of the
   file it was built from; if that differs from the DLL being verified, every
   name would be about a different build. It refuses rather than printing
   something plausible. Both current databases match.
2. **The image base is `ida_nalt.get_imagebase()`.** `ida_ida.inf_get_start_ea()`
   returns something else — `0x180519F18` in the GameAssembly database, against
   a true base of `0x180000000`. Using it put every lookup in the wrong segment
   and printed `<unnamed>` for all 19 symbols, which reads exactly like "IDA has
   no names" and cost a whole round of false conclusions.
3. **It never writes to the database.** `close_database(save=False)`, always.

Executable-range membership is tested by IDA permission bit, not by segment
*name*: the GameAssembly database splits code across `.text` and a segment named
`il2cpp`, so a `.text` test reports most of the module as non-code. That was a
false alarm until it was fixed.

### What the pattern-vs-export table settles

On 1.1.5.1.47510 all 8 `il2cpp_*` pattern symbols resolve to a different address
than the module's export of the same name. Byte-checking cannot distinguish a
broken pattern from a legitimate unwrapped-body reference. Walking the export's
call chain can, and it puts all 8 in benign shapes:

| shape | symbols |
|---|---|
| export is a 5 B thunk to the pattern's RVA | `il2cpp_domain_get`, `il2cpp_field_static_set_value`, `il2cpp_type_get_object` |
| export `call`s / `jmp`s the pattern target | `il2cpp_class_get_field_from_name`, `il2cpp_class_get_nested_types` |
| export reaches it indirectly at depth 2 | `il2cpp_class_from_name`, `il2cpp_class_get_method_from_name`, `il2cpp_field_static_get_value` |

The forwarding stubs are why the indirect cases are also fine — and why arity
matters:

```
sub_18033A2B0:  xor r9d, r9d ; jmp sub_180208CF0
sub_1803165B0:  xor r8d, r8d ;  jmp sub_1800E41C0
```

Each zeroes a register before jumping, and each implementation reads it. So
calling the unwrapped body directly means passing that argument explicitly —
which `exports.h` already does, casting to a 4-arg pointer and passing `0` as
the 4th. That is the whole reason the pattern is preferred to the export.

Not in `pytest tools/tests`: the IDA licence is not on every machine and the
`.i64` files are gitignored, so a suite depending on this would fail on a fresh
clone. Unavailable IDA is exit `2`, never `0`.

---

## `check.sh` — syntax stage

```sh
tools/verify/check.sh          # prints the fingerprint; exits non-zero if any
```

The invariant is **empty output**. The pre-split tree was verified to produce
zero residual signatures, so any signature at all is a regression — a stronger
and simpler criterion than a stored baseline, and one that cannot rot when the
toolchain moves. It takes about four minutes over 71 translation units.

## `linkcheck.py` — link stage

```sh
python3 tools/verify/linkcheck.py
```

Compiles every translation unit in the `.vcxproj` to an object and compares
symbol tables. Two invariants:

- **duplicate definitions must be zero.** Absolute, so it needs no baseline and
  cannot rot. This is the check that found the `inline`-on-a-moved-body defect:
  `linalg::mat4::at` and two siblings were referenced and defined nowhere.
- **unresolved symbols are reported, not asserted.** 417 of them, all Win32
  imports, CRT and libstdc++ ABI. Reviewed by eye rather than pinned to a
  baseline, because a pinned set would break on a toolchain change and teach
  people to re-baseline without reading.

Objects are cached under `/tmp/tarkovaddons-linkcheck` and keyed on mtime;
unchanged translation units are not recompiled. Objects whose source no longer
exists are pruned — otherwise deleting a `.cpp` leaves its object behind, still
counted as a definition, and a deleted source silently cannot fail the check.

---

## `msvc-shim/` — modelling MSVC on Linux (**incomplete**)

Two jobs, both load-bearing.

**Case.** The project writes `<Windows.h>`, `<Psapi.h>`, `<shlobj.h>`, matching
MSVC's names on a case-insensitive filesystem. mingw-w64 ships them lower-case
and this filesystem is case-sensitive, so the bare names resolve to nothing.

**Umbrella.** MSVC's `<windows.h>` pulls in the whole Win32 API surface, so code
that includes only `<Windows.h>` can call `GetTickCount64`, `GetLastError`,
`QueryPerformanceCounter`. mingw-w64's is a much smaller subset and does not
include `processthreadsapi.h`, `fileapi.h`, `synchapi.h` and the rest, so those
symbols are simply undeclared. `Windows.h` here restores that, and the header
list was derived by compiling the tree and mapping each undeclared symbol to the
header that declares it — not guessed.

### The three things that were not obvious

**`SECURITY_ATTRIBUTES` is a mingw-w64 header bug.** `<windows.h>` reaches
`minwinbase.h`, which defines the struct *unconditionally*; `wtypesbase.h` —
reached through `<shlobj.h>` — defines the same struct again behind a guard
spelled `_SECURITY_ATTRIBUTES_`, with a trailing underscore, which
`minwinbase.h` never sets. Including both in that order is a conflicting
declaration. Since `minwinbase.h` is unconditional, `-D_SECURITY_ATTRIBUTES_`
on the command line is the correct lever: the real definition still happens,
and the redundant one is suppressed.

That define has to be on the **command line**, not only in `Windows.h`, because
`pch.h` includes `<windows.h>` in lower case and so reaches mingw's header
without passing through the shim at all. It was in the shim file first, and the
conflict survived, which is what pointed at the spelling.

**A same-named shim file is self-referential.** There must be no `shlobj.h` or
`winbase.h` in this directory: the project already spells them correctly, and a
matching file in an `-I` path ahead of mingw's makes `#include <shlobj.h>`
resolve to *itself*, which under `#pragma once` becomes silently empty. Only
`Windows.h` and `Psapi.h` need to exist, because their targets differ in case.

**The umbrella list is derived, not guessed.** Each missing symbol was mapped to
the header that declares it by grepping mingw's include tree. Guessing this list
produces a harness that fails on a clean tree, which is worse than no harness.

### How to extend it

```sh
x86_64-w64-mingw32-g++ -std=c++23 -fsyntax-only -w \
  -DINCLUDE_AIMBOT -DNDEBUG -D_CRT_SECURE_NO_WARNINGS -DWIN32_LEAN_AND_MEAN \
  -DUNICODE -D_UNICODE -D__try=try '-D__except(x)=catch(...)' \
  -I tools/verify/msvc-shim -I TarkovAddons -I external \
  -I TarkovAddons/external -I TarkovAddons/external/imgui \
  -I TarkovAddons/external/tracy -include TarkovAddons/pch.h \
  TarkovAddons/dllmain.cpp 2>&1 | grep -E 'error:'
```

`-I TarkovAddons` is load-bearing, not decoration: `$(ProjectDir)` is first in
the project's `AdditionalIncludeDirectories`, and 71 of 82 translation units say
`#include "pch.h"` with no directory. See `WORKFLOW.md`, "The precompiled header
— a trap".

### The MSVC modelling, in one place

| | why |
|---|---|
| `-DUNICODE -D_UNICODE` | MSBuild injects these from `<CharacterSet>Unicode`. Without them `GetModuleHandle(L"d3d11.dll")` resolves to the `A` form and reports a type error in every TU. |
| `-D__try=try` and `-D'__except(x)=catch(...)'` | SEH. GCC has no `__try`, and one unparsed frame derails the rest of its header into a cascade. |
| the `void*` cast rewrite | The project casts `void*` to a function pointer with `static_cast`. MSVC accepts it; GCC rejects it outright, so 46 casts stop translation units producing output at all. `linkcheck.py` rewrote them to `reinterpret_cast` in a throwaway tree. |

`-D_WIN32_WINNT` was tried and is **not** the fix for the missing symbols; they
are missing because of what `windows.h` includes, not which Windows it targets.

---

## Not preserved

The splitter that performed the refactor — roughly 700 lines of brace-kind
classification and declaration rewriting — was in `/tmp` and is gone. It has
**not** been reimplemented here from memory, deliberately: an unverified tool
that rewrites headers is worse than no tool, because it fails silently.

`audit.py` is the substitute guarantee. It cannot re-split a header, but it can
prove that any split did or did not preserve content, against git, forever.

---

## Known failure modes in tooling like this

Each of these produced a clean, confident, wrong answer first, and each is worth
checking for when reading any verification output in this repository:

- **clang-tidy writes diagnostics to stdout**; only the "N warnings generated"
  summary goes to stderr. Reading stderr yields nothing at all, and a `2>&1`
  shell habit hides the difference completely.
- **`nm`/`objdump` pad indexes**: `[ 52]` and `[21093]` are both normal, and a
  pattern that assumes no padding silently skips every row under five digits.
- **`gcc -H` prefixes one dot per nesting level**, so matching only `. ` records
  direct includes and makes every transitively reachable header look absent.
- **A cached object outlives its source.** A checker that globs `*.o` keeps
  counting a deleted `.cpp` as a definition, so deleting a source cannot fail the
  check.
- **Link-once (COMDAT) sections are not collisions.** An `inline` function or
  template instantiation defined in a header lands in a `LINK_ONCE_DISCARD`
  section and the linker legitimately keeps one copy.
- **Matching an include by bare filename** removes the wrong line:
  `TextboxValue.h` also matches `CompactTextboxValue.h`.

---

## Validation

A green result from a checker that silently did nothing is worse than no
checker, so each tool is validated by **negative control** — break something on
purpose and confirm it is reported.

**`check.sh` / `signatures.py`**

| control | expected | got |
|---|---|---|
| clean tree | 0 signatures | 0 |
| a real error injected into a header | reported, attributed to that header | `DoorsModule.h: error: нет декларации «X» в этой области видимости` |
| the same error reached from a second TU | collapses to one entry | 1, not 2 |

That third control is the property the whole fingerprint design exists for.

**`linkcheck.py`**

| control | expected | got |
|---|---|---|
| current tree | 0 duplicates | 0, with 82 objects and 417 unresolved — the same 417 recorded before the original tooling was lost to temp cleanup |
| a real duplicate definition in two TUs | reported | `duplicate: _Z25linkcheck_duplicate_probev`, `FAIL` |

**`audit.py`**

| control | expected | got |
|---|---|---|
| current tree | no content loss | 58 pairs, 337 `conf()` initialisers preserved, 19 identifiers lost, all `static`/`inline` |

`linkcheck.py` also rebuilds the 417 count from nothing and lands on exactly the
number recorded before `/tmp` was wiped, which is the strongest evidence
available that the reconstruction is faithful rather than merely plausible.
