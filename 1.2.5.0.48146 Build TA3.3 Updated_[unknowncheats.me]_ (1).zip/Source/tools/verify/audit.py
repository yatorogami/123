#!/usr/bin/env python3
"""Content audit for the header -> header+cpp refactor.

Why this exists
---------------
The compiler proves *shape*: a name is still declared, a header is still
self-contained, an initialiser list still parses. It says nothing about
*content*, and content is exactly where a mechanical split can quietly lose
something that still compiles.

The failure this is built to catch, concretely: a `conf()` initialiser dropped
from a header and never added to the constructor's member-initialiser list. The
member becomes a null pointer, the build is clean, the menu draws without one
row, and nothing anywhere reports an error. That is the whole reason a
5770-line file could be moved without a test failing.

What it compares
----------------
Each split header against its pre-refactor revision, by content rather than by
structure:

  conf()      the multiset of conf(argument) argument texts, original versus
              header + cpp combined. conf() is never added, removed or reworded
              by the split, only relocated from an initialiser to a member-
              initialiser, so the two multisets must be equal exactly. This is
              the strong check, and it needs no compiler.
  identifiers the multiset of every identifier token, so any net loss shows up.
              What *should* be lost is known: `static`, when a namespace-scope
              statics sweep turned it to inline, and `static`/`inline` removed
              from a declaration whose body moved. Anything else is a defect.
  comments    the number of comment lines, which must not fall. A comment
              explaining a config value is often the only documentation of what
              it does.
  classes     every class in the original must still exist.

Usage:
    audit.py [base-revision]        default: the pre-refactor commit below
    audit.py <rev> --pairs          list the split pairs only
"""
import re
import subprocess
import sys
from collections import Counter
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent.parent

# The commit before any refactor work. Everything the refactor asserts is
# relative to this.
DEFAULT_BASE = 'a29b754de6eace7dce0da3a4d1568d2f613997c5'

# Identifiers whose disappearance is expected and accounted for.
EXPECTED_LOSS = {'static', 'inline'}

IDENT = re.compile(r'[A-Za-z_]\w*')
CLASS = re.compile(r'^\s*(?:class|struct)\s+([A-Za-z_]\w*)', re.M)


def git(*args):
    """stdout of a git command, or '' if it failed.

    `encoding` is not optional. Without it Python decodes with the ANSI
    codepage, and the first non-ASCII byte in a source file -- an em dash, a
    Cyrillic string literal -- raises UnicodeDecodeError inside subprocess's
    reader thread. The thread dies, the result is None, and the caller fails
    somewhere unrelated with a confusing TypeError. `errors='replace'` as well,
    so a file that is genuinely not decodable degrades to a diff this tool
    would have reported anyway rather than taking the process down.
    """
    return subprocess.run(['git', '-C', str(REPO), *args],
                          capture_output=True, text=True,
                          encoding='utf-8', errors='replace').stdout


def git_ok(*args):
    """True if the git command succeeded. `cat-file -e` prints nothing on
    success, so its exit status is the only signal there is."""
    return subprocess.run(['git', '-C', str(REPO), *args],
                          capture_output=True, text=True,
                          encoding='utf-8', errors='replace').returncode == 0


def conf_args(text):
    """Every conf(...) argument, balanced-paren, in source order.

    Balanced rather than regex, because the arguments contain commas, braces and
    string literals: `conf(new SelectValue(0, {"a", "b"}, "k"))`.
    """
    out = []
    for m in re.finditer(r'\bconf\s*\(', text):
        i, depth, start = m.end(), 1, m.end()
        while i < len(text) and depth:
            if text[i] == '(':
                depth += 1
            elif text[i] == ')':
                depth -= 1
            i += 1
        if depth == 0:
            out.append(re.sub(r'\s+', '', text[start:i - 1]))
    return out


def comment_lines(text):
    """Lines containing a // comment, ignoring /* */ blocks entirely."""
    stripped = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    return sum(1 for line in stripped.splitlines() if '//' in line)


def split_pairs():
    """[(header, cpp)] for every first-party header with a cpp sibling.

    Paths are built with as_posix() and must stay that way. They are fed to
    `git show <rev>:<path>`, whose path syntax is POSIX-only: a backslash makes
    git treat the whole thing as a path that is not in the tree, and it reports
    that on *stderr*, so git() comes back with '' and the pair is silently
    skipped. On Windows `str(Path.relative_to(...))` is backslash-separated, so
    the un-posix'd version of this function compared zero pairs and reported
    "no content loss" with exit 0. The `--` pathspecs elsewhere tolerate
    backslashes, which is exactly why discovery kept working and hid this.
    """
    pairs = []
    for header in sorted((REPO / 'TarkovAddons').rglob('*.h')):
        rel = header.relative_to(REPO).as_posix()
        if any(part in rel for part in ('external', 'libil2cpp', 'ISIL-references',
                                        'GameDump')):
            continue
        if header.name in ('pch.h', 'resources.h', 'always_on_deprecated.h'):
            continue
        cpp = header.with_suffix('.cpp')
        if cpp.exists():
            pairs.append((rel, cpp.relative_to(REPO).as_posix()))
    return pairs


def pre_split_base(cpp_rel):
    """(base_rev, split_rev): the state before a pair was split, and the commit
    that performed the split.

    Both sides are read from git, never from the working tree, and that is the
    whole point. Comparing against one global base is wrong in a way that looks
    like a defect: it cannot tell "the split lost this" from "someone changed
    this file legitimately afterwards", so every unrelated later edit is
    reported as refactor damage. And reading the *current* tree would mean the
    verdict changes every time anyone edits a header, which makes the tool
    useless as standing evidence.

    The parent of the commit that created the .cpp is that header's pre-split
    state, and that same commit is the refactor's own output. So the question
    answered is exactly "did the split preserve content", permanently.
    """
    added = git('log', '--diff-filter=A', '--format=%H', '--', cpp_rel).split()
    if not added:
        return None
    split = added[-1]
    parent = git('rev-parse', '--verify', f'{split}^').strip()
    return (parent, split) if parent else None


def main():
    if not git_ok('cat-file', '-e', f'{DEFAULT_BASE}^{{commit}}'):
        print(f'fallback base not found: {DEFAULT_BASE}', file=sys.stderr)
        return 2

    pairs = split_pairs()
    problems, rows, skipped, broken = [], [], {}, []
    for header, cpp in pairs:
        found = pre_split_base(cpp)
        if not found:
            # A genuine gap: this header/cpp pair predates the refactor, so the
            # state before "the split" is not in history and there is nothing to
            # compare. Fine, as long as it is counted.
            skipped.setdefault('no split commit in history', []).append(header)
            continue
        base, split = found
        old = git('show', f'{base}:{header}')
        new = git('show', f'{split}:{header}') + git('show', f'{split}:{cpp}')
        if not old or not new:
            # Two very different reasons land here, and conflating them is what
            # hid the Windows bug for so long: every pair was skipped for a
            # *mechanical* reason and the run still printed "no content loss
            # detected" and exited 0. They must not share a label.
            if git_ok('cat-file', '-e', f'{base}:{header}'):
                # The header is at that revision, so git show returning nothing
                # can only mean we asked for it wrongly. A defect, always.
                broken.append(header)
                skipped.setdefault('git show returned nothing for a header that '
                                   'EXISTS at that revision -- wrong pathspec',
                                   []).append(header)
            else:
                # The header and its cpp were added by the same commit, so there
                # is no pre-split state to compare against. A real gap.
                skipped.setdefault('header first appeared in the same commit as '
                                   'its cpp, so there is no pre-split state',
                                   []).append(header)
            continue

        old_conf, new_conf = Counter(conf_args(old)), Counter(conf_args(new))
        if old_conf != new_conf:
            problems.append(
                f'{header}: conf() multiset changed\n'
                f'      lost : {sorted((old_conf - new_conf).elements())}\n'
                f'      added: {sorted((new_conf - old_conf).elements())}')

        old_id, new_id = Counter(IDENT.findall(old)), Counter(IDENT.findall(new))
        lost = {k: v for k, v in (old_id - new_id).items()
                if k not in EXPECTED_LOSS}
        gained = new_id - old_id
        if lost:
            problems.append(f'{header}: identifiers lost that the split does not '
                            f'account for: {lost}')

        oc, nc = comment_lines(old), comment_lines(new)
        if nc < oc:
            problems.append(f'{header}: comment lines fell {oc} -> {nc}')

        gone = set(CLASS.findall(old)) - set(CLASS.findall(new))
        if gone:
            problems.append(f'{header}: class(es) disappeared: {sorted(gone)}')

        rows.append((header, base[:9], sum(old_conf.values()),
                     sum((old_id - new_id).values()),
                     sum(gained.values())))

    width = max(len(r[0]) for r in rows) if rows else 20
    print(f'{"header":<{width}}  {"base":<10}  {"conf()":>7}  {"lost":>6}  {"gained":>7}')
    for name, base, conf, lost, gained in rows:
        print(f'{name:<{width}}  {base:<10}  {conf:>7}  {lost:>6}  {gained:>7}')
    print(f'\n{len(rows)} split pairs, each against its own pre-split revision')
    for reason, names in skipped.items():
        print(f'{len(names)} pair(s) skipped -- {reason}:')
        for name in names:
            print(f'  {name}')

    # Anti-vacuity guard. This tool's whole value is the content-preservation
    # claim, and a run that compares nothing cannot support it. It reported
    # "no content loss detected" with exit 0 while checking zero pairs, which is
    # the single most expensive kind of green: it looked like evidence for a
    # guarantee nobody had actually checked. Comparing nothing is now an error.
    if not rows:
        print(f'\nNOTHING WAS COMPARED. {len(pairs)} pair(s) were found and every '
              f'one was skipped, so\nthis run proves nothing about content '
              f'preservation. Treat the verdict as unknown,\nnot as a pass.',
              file=sys.stderr)
        return 2
    if broken:
        print(f'\n{len(broken)} pair(s) could not be read back from git at a '
              f'revision where the\nfile provably exists, so they were not '
              f'checked. That is a defect in this tool,\nnot a gap in the '
              f'refactor:', file=sys.stderr)
        for name in broken:
            print(f'  {name}', file=sys.stderr)
        return 2

    total_conf = sum(r[2] for r in rows)
    total_lost = sum(r[3] for r in rows)
    print(f'conf() initialisers preserved: {total_conf}')
    print(f'identifiers lost across all pairs: {total_lost} '
          f'(all "static"/"inline", which the split accounts for)')

    if problems:
        print(f'\n{len(problems)} PROBLEMS:')
        for p in problems:
            print('  ' + p)
        return 1
    print('\nno content loss detected')
    return 0


if __name__ == '__main__':
    sys.exit(main())
