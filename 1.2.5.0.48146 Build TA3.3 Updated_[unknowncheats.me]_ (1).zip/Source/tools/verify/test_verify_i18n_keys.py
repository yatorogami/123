"""Negative controls for verify_i18n_keys.py.

Three things must be demonstrated, because each has already gone wrong once
during development of this tool:

  1. It goes RED on a planted raw-English key and on a planted missing key.
  2. It does NOT fire on the two legitimate WorldModule option lists, which
     pass /*translate_options=*/false. Those are proper nouns and a
     difficulty scale; flagging them would be a false positive that makes the
     tool noise rather than signal.
  3. It exits 2 when it checks nothing.
"""
import importlib.util
import json
import pathlib
import shutil
import sys
import tempfile

REPO = pathlib.Path(__file__).resolve().parents[2]
TOOL = REPO / "tools" / "verify" / "verify_i18n_keys.py"

spec = importlib.util.spec_from_file_location("verify_i18n_keys", TOOL)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def run(lang_dir):
    return mod.main(["verify_i18n_keys.py", "--lang-dir", str(lang_dir)])


class Tree:
    """A throwaway copy of TarkovAddons/lang.

    Only the lang directory is copied. The module sources are read from the
    REAL tree, so a control that plants a key must not have to reproduce the
    whole repo -- with_patched_module below edits a real file and restores it.
    """

    def __init__(self, root):
        self.root = pathlib.Path(root)
        self.lang = self.root / "lang"
        shutil.copytree(REPO / "TarkovAddons" / "lang", self.lang)


def with_patched_module(filename, transform, lang_dir):
    """Patch one module .cpp, run the tool, always restore it."""
    target = mod.TA / "module" / "impl" / filename
    backup = target.read_text(encoding="utf-8")
    try:
        target.write_text(transform(backup), encoding="utf-8")
        return run(lang_dir)
    finally:
        target.write_text(backup, encoding="utf-8")


def test_clean_tree_passes_and_has_no_check3(tmp):
    """The real tree is clean, and check 3 stays silent on it.

    This asserted the opposite while the 24 defects were still present -- that
    the tool reported exit 1 -- which meant it would have started failing the
    moment the tree was fixed. It now asserts what actually matters and was
    never asserted before: a clean tree is exit 0.
    """
    t = Tree(tmp)
    rc = run(t.lang)
    assert rc == 0, f"the fixed tree must pass cleanly, got {rc}"


def test_dead_line_is_detected(tmp):
    """Check 4 must fire on a line nothing references.

    Sweeps the whole first-party tree for quoted literals, so it needs a real
    orphan rather than a missing one: a key present in en.json and in no source
    file at all.
    """
    t = Tree(tmp)
    en_path = t.lang / "en.json"
    table = json.loads(en_path.read_text(encoding="utf-8"))
    table["orphan_key_nobody_uses_cb"] = "Orphan"
    en_path.write_text(json.dumps(table, ensure_ascii=False, indent=2),
                       encoding="utf-8")
    rc = run(t.lang)
    assert rc == 1, f"a dead language line must fail the run, got {rc}"


def test_worldmodule_option_lists_are_not_flagged(tmp):
    """The false-positive control.

    WorldModule.cpp holds two raw-English option lists -- 73 bot names and a
    4-entry difficulty scale -- both passed with /*translate_options=*/false.
    A tool that cannot see that flag reports them as defects; this asserts it
    does not. Asserted per-site on the raw-English lists specifically: a third
    list in the same constructor (tp_one_mode, line 129) uses proper *_sel
    keys and is correctly not a finding for an unrelated reason, so counting
    every WorldModule site would pass for the wrong cause.
    """
    t = Tree(tmp)
    _, option_sites = mod.collect()
    raw_sites = [s for s in option_sites
                 if "WorldModule" in s[0]
                 and any(mod.looks_raw_english(o) for o in s[2])]
    assert len(raw_sites) == 2, (
        f"expected the 2 raw-English WorldModule lists, found {len(raw_sites)}: "
        f"{[(s[0], s[1], len(s[2])) for s in raw_sites]}"
    )
    unflagged = [s for s in raw_sites if not s[3]]
    assert not unflagged, (
        "WorldModule passes translate_options=false but the tool read it as "
        f"absent at: {[s[:2] for s in unflagged]}"
    )
    # And the counts must be the ones the tool was measured at.
    assert sorted(len(s[2]) for s in raw_sites) == [4, 73], (
        "the two raw-English lists are 73 bot names and 4 difficulties"
    )


def test_planted_raw_english_key_is_detected(tmp):
    """A key of 'Planted Label' must be reported."""
    t = Tree(tmp)

    def transform(text):
        return text.replace(
            'show_game_delayed(conf(new CheckboxValue(false, "show_game_delayed_cb")))',
            'show_game_delayed(conf(new CheckboxValue(false, "Planted Label")))',
            1,
        )

    rc = with_patched_module("WorldModule.cpp", transform, t.lang)
    assert rc == 1, f"a planted raw-English key must fail the run, got {rc}"


def test_planted_missing_key_is_detected(tmp):
    """A proper-named key with no en.json line must be reported."""
    t = Tree(tmp)

    def transform(text):
        return text.replace(
            '"show_game_delayed_cb"', '"planted_missing_key_cb"', 1)

    rc = with_patched_module("WorldModule.cpp", transform, t.lang)
    assert rc == 1, f"a missing key must fail the run, got {rc}"


def test_missing_lang_dir_exits_2(tmp):
    rc = run(pathlib.Path(tmp) / "does_not_exist")
    assert rc == 2, f"a missing lang dir must exit 2, not 0 -- got {rc}"


def test_empty_lang_dir_exits_2(tmp):
    empty = pathlib.Path(tmp) / "empty"
    empty.mkdir()
    rc = run(empty)
    assert rc == 2, f"an empty lang dir must exit 2, not 0 -- got {rc}"


def test_malformed_en_json_exits_2(tmp):
    t = Tree(tmp)
    (t.lang / "en.json").write_text("{ this is not json", encoding="utf-8")
    rc = run(t.lang)
    assert rc == 2, f"malformed en.json must exit 2, not 0 -- got {rc}"


def test_empty_en_json_exits_2(tmp):
    t = Tree(tmp)
    (t.lang / "en.json").write_text("{}", encoding="utf-8")
    rc = run(t.lang)
    assert rc == 2, f"an empty en.json must exit 2, not 0 -- got {rc}"


if __name__ == "__main__":
    import contextlib
    import io
    failures = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("test_"):
            continue
        with tempfile.TemporaryDirectory() as td:
            buf = io.StringIO()
            try:
                with contextlib.redirect_stdout(buf):
                    fn(td)
                print(f"PASS {name}")
            except AssertionError as exc:
                failures += 1
                print(f"FAIL {name}: {exc}")
    print(f"\n{failures} failure(s)")
    sys.exit(1 if failures else 0)