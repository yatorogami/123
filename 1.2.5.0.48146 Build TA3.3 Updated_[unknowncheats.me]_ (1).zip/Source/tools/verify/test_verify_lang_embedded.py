"""Negative controls for verify_lang_embedded.py.

A checker that cannot go red is not a checker. These assert the tool FAILS on a
deliberately stale artifact, and that it exits 2 (not 0) when it can check
nothing -- the exit-2 discipline the rest of tools/verify/ follows.
"""
import importlib.util
import json
import pathlib
import struct
import sys

REPO = pathlib.Path(__file__).resolve().parents[2]
TOOL = REPO / "tools" / "verify" / "verify_lang_embedded.py"

spec = importlib.util.spec_from_file_location("verify_lang_embedded", TOOL)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def build_stale_dll(tmp_path, disk_tables, embedded_tables):
    """A minimal but structurally valid PE carrying RT_RCDATA 1300-1318.

    Every locale the tool knows about is present, so a pass means the tool
    genuinely compared the two tables rather than passing on a fixture that
    happened to be missing what it looks for. The resource tree is built
    level-by-level in the real layout (Type -> ID -> Language -> Data).
    """
    rsrc_rva = 0x2000
    rsrc_off = 0x400
    LANG_ID = 1033
    ids = sorted(mod.RCDATA_IDS)

    # Blobs first; their RVAs are assigned after the directory size is known.
    blobs = {rid: json.dumps(embedded_tables[code]).encode("utf-8")
             for rid, code in mod.RCDATA_IDS.items()}

    DIR_HDR = 16
    ENTRY = 8
    DATA_ENTRY = 16

    n_ids = len(ids)
    l0_size = DIR_HDR + ENTRY                           # RT_RCDATA -> level 1
    l1_size = DIR_HDR + ENTRY * n_ids                   # ids -> level 2
    # Each id gets its OWN level-2 directory holding exactly one entry (the
    # language). That is 19 directories of 24 bytes, not one directory of 168.
    one_dir = DIR_HDR + ENTRY
    l2_size = one_dir * n_ids
    data_size = DATA_ENTRY * n_ids

    l0_off = 0
    l1_off = l0_off + l0_size
    l2_off = l1_off + l1_size
    data_off = l2_off + l2_size
    blob_off = data_off + data_size

    dir_bytes = bytearray()
    # level 0: RT_RCDATA
    dir_bytes += struct.pack("<IIHHHH", 0, 0, 0, 0, 0, 1)
    dir_bytes += struct.pack("<II", 10, 0x80000000 | l1_off)
    # level 1: the 19 ids
    dir_bytes += struct.pack("<IIHHHH", 0, 0, 0, 0, 0, n_ids)
    for i, rid in enumerate(ids):
        dir_bytes += struct.pack("<II", rid, 0x80000000 | (l2_off + i * one_dir))
    # level 2: one directory per id, each with a single language entry
    for i, rid in enumerate(ids):
        dir_bytes += struct.pack("<IIHHHH", 0, 0, 0, 0, 0, 1)
        dir_bytes += struct.pack("<II", LANG_ID, data_off + i * DATA_ENTRY)
    assert len(dir_bytes) == data_off, (len(dir_bytes), data_off)

    data_bytes = bytearray()
    blob_rvas = {}
    cursor = blob_off
    for rid in ids:
        blob_rvas[rid] = rsrc_rva + cursor
        cursor += len(blobs[rid])
    for rid in ids:
        data_bytes += struct.pack("<IIII", blob_rvas[rid], len(blobs[rid]), 0, 0)
    assert len(data_bytes) == blob_off - data_off

    rsrc = bytearray(bytes(dir_bytes) + bytes(data_bytes))
    for rid in ids:
        rsrc += blobs[rid]
    rsrc += b"\0" * (rsrc_rva - rsrc_off - len(rsrc))  # pad so RVAs line up

    headers = bytearray(0x400)
    headers[0:2] = b"MZ"
    # Every offset below is derived from e_lfanew rather than hardcoded, because
    # the optional header and the section table move with it.
    pe_off = 0x80
    opt_off = pe_off + 24
    sec_table = opt_off + 0xF0                     # SizeOfOptionalHeader for PE32+
    headers[0:2] = b"MZ"
    struct.pack_into("<I", headers, 0x3C, pe_off)
    struct.pack_into("<I", headers, pe_off, 0x00004550)          # PE\0\0
    struct.pack_into("<H", headers, pe_off + 4, 0x8664)          # machine
    struct.pack_into("<H", headers, pe_off + 6, 1)               # 1 section
    struct.pack_into("<H", headers, pe_off + 20, 0xF0)           # SizeOfOptionalHeader
    struct.pack_into("<H", headers, opt_off, 0x20B)               # PE32+ magic
    struct.pack_into("<I", headers, opt_off + 60, 0x400)          # SizeOfHeaders
    # DataDirectory[2] = resource directory
    struct.pack_into("<I", headers, opt_off + 112 + 2 * 8, rsrc_rva)

    sec = sec_table
    headers[sec:sec + 8] = b".rsrc\0\0\0"
    struct.pack_into("<IIII", headers, sec + 8, len(rsrc), rsrc_rva, len(rsrc), rsrc_off)

    dll = tmp_path / "TarkovAddons.dll"
    dll.write_bytes(bytes(headers) + bytes(rsrc))
    return dll


def all_locales(mapping_for_en):
    """A complete {code: table} set, so no locale is accidentally absent."""
    return {code: dict(mapping_for_en) for code in mod.RCDATA_IDS.values()}


def write_lang(tmp_path, tables):
    d = tmp_path / "lang"
    d.mkdir(exist_ok=True)
    for code, table in tables.items():
        (d / f"{code}.json").write_text(json.dumps(table), encoding="utf-8")
    return d


def run(argv):
    return mod.main(["verify_lang_embedded.py"] + argv)


def test_detects_stale(tmp_path):
    """The control that matters: a DLL missing keys the source has exits 1.

    Named for the real defect -- this is the container_chams_cb shape, where
    lang/en.json has the key and the embedded copy does not.
    """
    disk = all_locales({"a": "1", "container_chams_cb": "Container Chams"})
    embedded = all_locales({"a": "1"})          # the key never made it in
    lang = write_lang(tmp_path, disk)
    dll = build_stale_dll(tmp_path, disk, embedded)
    rc = run([str(dll), "--lang-dir", str(lang)])
    assert rc == 1, f"a stale DLL must exit 1, got {rc}"


def test_passes_when_fresh(tmp_path):
    disk = all_locales({"a": "1", "container_chams_cb": "Container Chams"})
    lang = write_lang(tmp_path, disk)
    dll = build_stale_dll(tmp_path, disk, dict(disk))   # embedded == disk
    rc = run([str(dll), "--lang-dir", str(lang)])
    assert rc == 0, f"a fresh DLL must exit 0, got {rc}"


def test_line_endings_are_not_a_defect(tmp_path):
    """rc.exe rewrites CRLF; a byte difference with equal content must pass."""
    disk = all_locales({"a": "1", "b": "2"})
    lang = write_lang(tmp_path, disk)
    dll = build_stale_dll(tmp_path, disk, dict(disk))
    # rewrite the lang files with CRLF so the bytes differ but the JSON does not
    for code in disk:
        p = lang / f"{code}.json"
        p.write_bytes(json.dumps(disk[code], indent=2).replace("\n", "\r\n").encode("utf-8"))
    rc = run([str(dll), "--lang-dir", str(lang)])
    assert rc == 0, f"line-ending differences must not fail, got {rc}"


def test_missing_file_exits_2(tmp_path):
    disk = all_locales({"a": "1"})
    lang = write_lang(tmp_path, disk)
    rc = run([str(tmp_path / "nope.dll"), "--lang-dir", str(lang)])
    assert rc == 2, f"a missing DLL must exit 2, not 0 -- got {rc}"


def test_non_pe_exits_2(tmp_path):
    disk = all_locales({"a": "1"})
    lang = write_lang(tmp_path, disk)
    junk = tmp_path / "junk.dll"
    junk.write_bytes(b"this is not a PE file at all, not even close")
    rc = run([str(junk), "--lang-dir", str(lang)])
    assert rc == 2, f"a non-PE must exit 2, not 0 -- got {rc}"


def test_empty_lang_dir_exits_2(tmp_path):
    """The exit-2 discipline: nothing to compare is not a pass."""
    empty = tmp_path / "lang"
    empty.mkdir()
    disk = all_locales({})
    dll = build_stale_dll(tmp_path, disk, dict(disk))
    rc = run([str(dll), "--lang-dir", str(empty)])
    assert rc == 2, f"an empty lang dir must exit 2, not 0 -- got {rc}"


def test_empty_embedded_locale_exits_1(tmp_path):
    """A DLL whose locales carry no keys while disk has some is stale."""
    disk = all_locales({"a": "1"})
    lang = write_lang(tmp_path, disk)
    dll = build_stale_dll(tmp_path, disk, all_locales({}))
    rc = run([str(dll), "--lang-dir", str(lang)])
    assert rc == 1, f"an empty embedded locale must exit 1, got {rc}"


def test_removed_resource_id_exits_1(tmp_path):
    """A locale dropped from the DLL entirely must be reported, not ignored."""
    disk = all_locales({"a": "1"})
    lang = write_lang(tmp_path, disk)
    dll = build_stale_dll(tmp_path, disk, dict(disk))
    # corrupt the level-1 entry for id 1300 into a non-directory leaf
    raw = bytearray(dll.read_bytes())
    rsrc_off = 0x400
    n_ids = len(mod.RCDATA_IDS)
    l0_size = 16 + 8
    l1_size = 16 + 8 * n_ids
    l1_off = rsrc_off + l0_size
    first_entry = l1_off + 16
    # point the first id straight at its data entry instead of a subdirectory
    l2_off = l1_off + l1_size
    struct.pack_into("<II", raw, first_entry, min(mod.RCDATA_IDS),
                     (l2_off + 16 * 0 + 16 + 8 * 0) - rsrc_off)   # leaf, not dir
    dll.write_bytes(bytes(raw))
    rc = run([str(dll), "--lang-dir", str(lang)])
    assert rc == 1, f"a malformed resource path must not exit 0, got {rc}"


if __name__ == "__main__":
    import tempfile
    failures = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("test_"):
            continue
        with tempfile.TemporaryDirectory() as td:
            try:
                fn(pathlib.Path(td))
                print(f"PASS {name}")
            except AssertionError as exc:
                failures += 1
                print(f"FAIL {name}: {exc}")
    print(f"\n{failures} failure(s)")
    sys.exit(1 if failures else 0)