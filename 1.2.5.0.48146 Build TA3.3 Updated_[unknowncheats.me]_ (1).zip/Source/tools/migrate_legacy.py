"""One-time import of pre-3.2 mod data into the `ta/` layout. Replaces
`TarkovAddons/util/data_migration.h`, which the DLL ran on every process start.

WHY IT MOVED OUT OF THE DLL
===========================

`ConfigModule.cpp:263-267` documents the read path as

    ta/configs/<config>  ->  ta/<config> (3.2)  ->  %APPDATA%\\TarkovAddons\\<config>

and says the middle one is "still read so that a **failed or skipped** migration
cannot present as 'no config found'". So the migration is not load-bearing: the
worst outcome of not running it is untidy data, not lost settings. That is what
makes it safe to move it to a tool, and it is why a user who updates without
running `deploy.py` is merely untidy rather than broken.

The decisive reason is narrower. The C++ version called
`legacy_appdata_dir()`, which reads the **ambient** `%APPDATA%` out of the
environment. `WORKFLOW.md` records the cost of that: `_dupenv_s` reads the CRT's
copy of the environment and `SetEnvironmentVariableW` does not redirect it, so a
test harness that redirected with the Win32 call and read back with `_dupenv_s`
saw the real value, believed the redirect had worked, and ran the migration
against the user's real profile -- **moving 23 real user files**.

Every bit of machinery that hazard required -- `_wputenv_s`, a read-back through
the same accessor the code used, a three-way guard, a post-hoc fingerprint of the
real profile -- exists only because the roots had to be discovered from the
environment.

Here they are arguments:

    migrate(legacy_root, deploy_root)

so there is no ambient environment to get wrong. The hazard does not get guarded;
it ceases to exist. That is the whole argument for the move, and it is not
available to the C++ version no matter how carefully it is written.

WHAT DID NOT MOVE
=================

`util/module_paths.h` stays, entirely. `chams_bundle_path()` creates
`ta\\chams\\` on demand *during a raid*, and `dll_directory_wide()` has to work
after manual mapping or LDR hiding has made `GetModuleHandle*` permanently
unable to resolve our own path. The game process is the only thing that can do
that. This is "move the legacy import", not "move the paths".

BEHAVIOUR PRESERVED FROM THE C++ VERSION
========================================

These lists are load-bearing. A user's settings file that gets mistaken for
shipped data is the failure this whole mechanism exists to prevent, so they are
reproduced exactly and `test_migrate_legacy.py` pins every entry.

ONE IMPROVEMENT, and it is the reason the ordering changed
==========================================================

The C++ `adopt_file()` tried `std::filesystem::rename` first and only fell back
to copy-then-remove. On one volume -- the normal case, since the profile and the
deployment are both on C: -- that means **rename, with no verification at all**.
Here it is always copy, verify the bytes, then delete the source. Same result,
and the one case where it matters (a full disk, a permissions change, an
antivirus holding a handle) now leaves the original in place instead of losing
it.
"""

from __future__ import annotations

import filecmp
import os
import shutil
from dataclasses import dataclass, field
from pathlib import Path

# ---------------------------------------------------------------------------
#  The two name lists, reproduced from util/data_migration.h
# ---------------------------------------------------------------------------

#: Files that legitimately sit directly in `ta/` and must never be mistaken for a
#: user config. Anything else that is a regular file in `ta/` is treated as a
#: config, because the config set is user-extensible (ConfigModule offers
#: config_1..config_5 and users rename them) and a whitelist here would strand
#: real settings.
#:
#: The background PNG is in this list on purpose: `gui/menu/menu.cpp` looks for it
#: at `data_directory_wide()/"TarkovAddons Reloaded Background.png"` as its
#: last-resort texture fallback, so moving it into `configs/` would silently break
#: that path.
KNOWN_TA_ROOT_DATA = frozenset({
    "launcher.cfg",
    "offsets.cfg",
    "patterns.cfg",
    "tarkov_prices.json",
    "TarkovAddons Reloaded Background.png",
})

#: Files in the **legacy** `%APPDATA%` folder that are not user configs and must
#: be left alone by the config sweep.
#:
#: This list is the opposite trade-off to the one above, and deliberately so: the
#: legacy folder is a known, fixed, mod-owned directory, so unlike `ta/` -- which
#: holds user-renamed configs and therefore has to be a not-a-known-file
#: predicate -- everything in it can be enumerated. A whitelist is the safer
#: choice here.
#:
#: "tarkovutils" is the chams AssetBundle that Unity's `LoadFromFileAsync` needs
#: as a real file. It was NOT on this list, so the sweep filed it under
#: `ta\\configs\\` as if it were a settings file -- which meant a crashed load left
#: an 18 KB binary sitting among the user's configs. It now lives at
#: `ta\\chams\\tarkovutils` (`module_paths::chams_bundle_path()`).
KNOWN_LEGACY_DATA = frozenset({
    "tarkov_prices.json",
    "tarkovutils",
})

#: Shared config older versions kept beside the DLL, imported into `ta/`.
BESIDE_DLL = ("launcher.cfg", "offsets.cfg", "patterns.cfg")

#: Extensions adopted wholesale from a directory. Anything else is left.
ADOPTED_SUFFIXES = frozenset({".json", ".svg"})

#: The chams bundle, when found loose in the legacy folder. Transient load
#: debris: the loader writes it before each load and deletes it once the load
#: completes, so whatever is there is the wreckage of a load that crashed or was
#: interrupted. There is nothing to preserve -- it is 18 KB of the same embedded
#: bytes every time -- so it is removed rather than migrated. Moving it to
#: `ta\\chams\\` would only relocate something the next `start_load()` overwrites
#: and the next successful load deletes.
CHAMS_DEBRIS = "tarkovutils"

DATA_DIR = "ta"
CONFIG_SUBDIR = "configs"


@dataclass
class Action:
    """One thing to do, with enough context to print a line a person can read."""
    kind: str            # "config" | "data" | "dir" | "debris" | "ta-root-config"
    src: Path
    dst: Path | None
    note: str = ""


@dataclass
class Plan:
    actions: list[Action] = field(default_factory=list)
    skipped: list[tuple[Path, str]] = field(default_factory=list)
    legacy_root: Path | None = None
    deploy_root: Path | None = None

    def __bool__(self) -> bool:
        return bool(self.actions)

    def counts(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for a in self.actions:
            out[a.kind] = out.get(a.kind, 0) + 1
        return out

    def describe(self) -> list[str]:
        """Human-readable summary, grouped so the shape is visible at a glance."""
        if not self.actions:
            return ["No pre-3.2 data found. Nothing to import."]
        lines = []
        groups = [
            ("config", "user settings", "ta\\configs\\"),
            ("ta-root-config", "settings stranded in ta\\ root", "ta\\configs\\"),
            ("data", "shared data", "ta\\"),
            ("dir", "assets", "ta\\"),
            ("debris", "load debris, will be DELETED", "(gone)"),
        ]
        for kind, what, dest in groups:
            items = [a for a in self.actions if a.kind == kind]
            if not items:
                continue
            names = ", ".join(a.src.name for a in items[:6])
            if len(items) > 6:
                names += f", +{len(items) - 6} more"
            lines.append(f"{len(items):>3} {what} -> {dest}")
            lines.append(f"      {names}")
        if self.skipped:
            lines.append("")
            lines.append(f"  {len(self.skipped)} file(s) left where they are:")
            for path, why in self.skipped[:6]:
                lines.append(f"      {path.name}: {why}")
            if len(self.skipped) > 6:
                lines.append(f"      +{len(self.skipped) - 6} more")
        return lines


# ---------------------------------------------------------------------------
#  survey -- pure, read-only, no mutation whatsoever
# ---------------------------------------------------------------------------

def survey(legacy_root: Path | None, deploy_root: Path | None) -> Plan:
    """Work out what would be imported. Touches nothing.

    `deploy_root` is where the DLLs live; `ta\\` is inside it. `legacy_root` is
    the pre-3.2 profile directory, i.e. what `%APPDATA%\\TarkovAddons` used to be.
    Either may be None or missing, which is the normal case and produces an empty
    plan rather than an error.
    """
    plan = Plan(legacy_root=legacy_root, deploy_root=deploy_root)

    if deploy_root is None or not deploy_root.is_dir():
        return plan
    ta = deploy_root / DATA_DIR

    # 1. The user's config(s) from the legacy profile folder. Any file directly in
    #    it that is not known shipped data. These go to ta/configs/, NOT ta/ --
    #    see the layout note in module_paths.h.
    if legacy_root is not None and legacy_root.is_dir():
        configs = ta / CONFIG_SUBDIR
        for entry in sorted(legacy_root.iterdir()):
            if not entry.is_file():
                continue
            if entry.name in KNOWN_LEGACY_DATA:
                plan.skipped.append((entry, "known shipped data, not a setting"))
                continue
            dst = configs / entry.name
            if dst.exists():
                plan.skipped.append((entry, f"{show_path(dst)} already exists; the newer copy wins"))
                continue
            plan.actions.append(Action("config", entry, dst))

        # 2. The price cache. Goes to ta/, not ta/configs/ -- it is not a setting.
        cache = legacy_root / "tarkov_prices.json"
        dst = ta / cache.name
        if cache.is_file():
            if dst.exists():
                plan.skipped.append((cache, f"{show_path(dst)} already exists"))
            else:
                plan.actions.append(Action("data", cache, dst))

        # 2b. A chams bundle left behind by a build that predates ta/chams/.
        debris = legacy_root / CHAMS_DEBRIS
        if debris.is_file():
            plan.actions.append(
                Action("debris", debris, None,
                       "transient load debris; the live copy is embedded in the DLL"))

        # 3. Minimap assets and any tile cache the user already had.
        plan.actions.extend(_adopt_dir(legacy_root / "maps", ta / "maps", "assets"))
        plan.actions.extend(_adopt_dir(legacy_root / "lang", ta / "lang", "assets"))
        tile = legacy_root / "tile_cache"
        if tile.is_dir() and not (ta / "tile_cache").exists():
            plan.actions.append(Action("dir", tile, ta / "tile_cache", "tile cache"))

    # 4. Config and data that older versions kept beside the DLL or in the game
    #    folder. Only when ta/ has no copy yet, so the deployment is never made
    #    worse.
    for name in BESIDE_DLL:
        src = deploy_root / name
        if src.is_file():
            dst = ta / name
            if dst.exists():
                plan.skipped.append((src, f"{show_path(dst)} already exists"))
            else:
                plan.actions.append(Action("data", src, dst))
    plan.actions.extend(_adopt_dir(deploy_root / "lang", ta / "lang", "assets"))
    plan.actions.extend(_adopt_dir(deploy_root / "maps", ta / "maps", "assets"))

    # 5. A config that a 3.2 install already put directly in ta/. Without this the
    #    move to ta/configs/ would look like "no config found" and silently reset
    #    the user to defaults, which is the worst possible failure for a settings
    #    file. Never overwrite, so if both copies somehow exist the ta/configs/ one
    #    wins and the old one is left in place rather than deleted.
    if ta.is_dir():
        configs = ta / CONFIG_SUBDIR
        for entry in sorted(ta.iterdir()):
            if not entry.is_file():
                continue
            if entry.name in KNOWN_TA_ROOT_DATA:
                plan.skipped.append((entry, "shipped data that lives in ta\\ root"))
                continue
            dst = configs / entry.name
            if dst.exists():
                plan.skipped.append((entry, f"{show_path(dst)} already exists"))
                continue
            plan.actions.append(Action("ta-root-config", entry, dst))

    return plan


def _adopt_dir(src_dir: Path, dst_dir: Path, kind: str) -> list[Action]:
    """Import every .json/.svg from a directory. Returns [] for a missing source."""
    if not src_dir.is_dir():
        return []
    out = []
    for entry in sorted(src_dir.iterdir()):
        if not entry.is_file():
            continue
        if entry.suffix.lower() not in ADOPTED_SUFFIXES:
            continue
        dst = dst_dir / entry.name
        if dst.exists():
            continue
        out.append(Action(kind, entry, dst))
    return out


def show_path(path: Path) -> str:
    """Render a path relative to its root where that is shorter and clearer."""
    parts = path.parts
    for anchor in (DATA_DIR, "TarkovAddons"):
        if anchor in parts:
            i = len(parts) - 1 - parts[::-1].index(anchor)
            return "\\".join(parts[i:])
    return str(path)


# ---------------------------------------------------------------------------
#  apply -- copy, verify, then delete. Never rename.
# ---------------------------------------------------------------------------

@dataclass
class Result:
    moved: list[tuple[Path, Path]] = field(default_factory=list)
    deleted: list[Path] = field(default_factory=list)
    failed: list[tuple[Path, str]] = field(default_factory=list)

    def ok(self) -> bool:
        return not self.failed


def apply(plan: Plan, dry_run: bool = False) -> Result:
    """Carry out a plan. See the module docstring for why this is copy-verify-delete
    rather than the rename the C++ version attempted first."""
    result = Result()
    for action in plan.actions:
        if action.kind == "debris":
            if dry_run:
                print(f"  would delete  {show_path(action.src)}  ({action.note})")
            else:
                try:
                    action.src.unlink()
                    result.deleted.append(action.src)
                    print(f"  deleted       {show_path(action.src)}  ({action.note})")
                except OSError as exc:
                    result.failed.append((action.src, str(exc)))
                    print(f"  FAILED        {show_path(action.src)}: {exc}")
            continue

        assert action.dst is not None
        if dry_run:
            print(f"  would copy    {show_path(action.src)}\n"
                  f"            -> {show_path(action.dst)}")
            continue

        try:
            action.dst.parent.mkdir(parents=True, exist_ok=True)
            # copy2 preserves mtime, which matters because these are settings the
            # user may want to reason about chronologically, and because a future
            # migration might use mtime to decide what is newer.
            shutil.copy2(action.src, action.dst)
        except OSError as exc:
            result.failed.append((action.src, str(exc)))
            print(f"  FAILED        {show_path(action.src)}: {exc}")
            continue

        # Verify before deleting the original. This is the step the rename-first
        # version never did on the common same-volume path.
        try:
            same = filecmp.cmp(action.src, action.dst, shallow=False)
        except OSError as exc:
            result.failed.append((action.src, f"verify: {exc}"))
            print(f"  FAILED        {show_path(action.src)}: verify error {exc}")
            continue
        if not same:
            result.failed.append((action.src, "copy did not match the source"))
            print(f"  FAILED        {show_path(action.src)}: copy did not match; "
                  f"source left in place")
            continue

        try:
            if action.src.is_dir():
                shutil.rmtree(action.src)
            else:
                action.src.unlink()
        except OSError as exc:
            # The copy is verified and in place, so a failed delete leaves a
            # duplicate rather than a loss. That is the right way round.
            result.failed.append((action.src, f"copied but could not remove: {exc}"))
            print(f"  copied, but   {show_path(action.src)} could not be removed: {exc}")
            print(f"                (the copy at {show_path(action.dst)} is verified; "
                  f"this is a duplicate, not data loss)")
            continue

        result.moved.append((action.src, action.dst))
        print(f"  imported      {show_path(action.src)}\n"
              f"            -> {show_path(action.dst)}")
    return result
