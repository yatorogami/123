"""Insert the four Big Map i18n keys into every lang/*.json.

Same contract as tools/add_night_vision_lang.py: alphabetical insertion at
2-space indent, per-file line endings preserved, JSON re-parsed before write, and
exit 1 rather than dropping an English string into a locale it has no translation
for.

Run from the repository root:  python tools/add_big_map_lang.py
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
LANG_DIR = REPO / "TarkovAddons" / "lang"
EXTRA = [REPO / "lang_fixes" / "hu.json"]

KEY_LINE = re.compile(r'^  "([A-Za-z0-9_.]+)":')

# "Big Map". `big_map_mod` is the MODULE CARD title, so it is a noun phrase,
# while the other three are the label the toggle actually shows.
TRANSLATIONS = {
    "br": "Mapa Grande",
    "ch": "大地图",
    "cs": "Velka mapa",
    "en": "Big Map",
    "es": "Mapa grande",
    "fr": "Grande carte",
    "ge": "Große Karte",
    "hu": "Nagy térkép",
    "it": "Mappa grande",
    "jp": "ビッグマップ",
    "kr": "큰 지도",
    "pl": "Duża mapa",
    "po": "Mapa grande",
    "ro": "Hartă mare",
    "ru": "Большая карта",
    "sk": "Veľká mapa",
    "sr": "Велика мапа",
    "tu": "Büyük harita",
    "tw": "大地圖",
}

NEW_KEYS = ("big_map_cb", "big_map_mod", "big_map_zoom_itm", "hk_big_map_act")


def insert_sorted(lines: list[str], key: str, value: str) -> list[str]:
    for i, line in enumerate(lines):
        m = KEY_LINE.match(line)
        if m and m.group(1) > key:
            break
    else:
        raise RuntimeError(f"no insertion point found for {key}")
    lines.insert(i, f'  "{key}": {json.dumps(value, ensure_ascii=False)},')
    return lines


def main() -> int:
    failures: list[str] = []
    targets = sorted(LANG_DIR.glob("*.json")) + [p for p in EXTRA if p.is_file()]
    for path in targets:
        code = path.stem
        if code not in TRANSLATIONS:
            failures.append(f"{path.name}: no translation for language {code!r}")
            continue
        raw = path.read_bytes()
        newline = "\r\n" if b"\r\n" in raw else "\n"
        lines = raw.decode("utf-8-sig").split(newline)
        present = {m.group(1) for line in lines if (m := KEY_LINE.match(line))}
        clash = present.intersection(NEW_KEYS)
        if clash:
            failures.append(f"{path.name}: already has {sorted(clash)}")
            continue
        try:
            for key in NEW_KEYS:
                lines = insert_sorted(lines, key, TRANSLATIONS[code])
        except RuntimeError as exc:
            failures.append(f"{path.name}: {exc}")
            continue
        out = newline.join(lines)
        try:
            data = json.loads(out)
        except json.JSONDecodeError as exc:
            failures.append(f"{path.name}: result does not parse as JSON: {exc}")
            continue
        missing = [k for k in NEW_KEYS if k not in data]
        if missing:
            failures.append(f"{path.name}: keys missing after write: {missing}")
            continue
        path.write_bytes(out.encode("utf-8"))
        print(f"{path.name}: added {', '.join(NEW_KEYS)}")

    if failures:
        print("\nFAILED:\n" + "\n".join(failures), file=sys.stderr)
        return 1
    print(f"\n{len(targets)} files, {len(targets) * len(NEW_KEYS)} keys added")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
