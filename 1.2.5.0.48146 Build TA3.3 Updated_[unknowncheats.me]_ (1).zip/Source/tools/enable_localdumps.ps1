# Enable WER local dumps for EscapeFromTarkov.exe.
#
#   Right-click -> Run with PowerShell  (as Administrator), or:
#     powershell -ExecutionPolicy Bypass -File tools\enable_localdumps.ps1
#
# WHY THIS EXISTS
#
# WER was re-enabled on 2026-10-03 and immediately identified a crash that
# util/crash_probe.h had been swallowing for a month: on 2026-10-03 10:35:14 the
# process died with 0xC0000005 at TarkovAddons.dll+0x50DA1, which is
# crash_probe::fill_event+0x41 -- i.e. the crash probe killed the process while
# trying to observe it, and then reported nothing. That is fixed in the probe now
# (see the 2026-10-03 note at the top of util/crash_probe.h).
#
# But WER's report still does not settle what killed the ORIGINAL fault, and the
# reason is structural: WER reports the faulting module, the fault OFFSET and the
# thread -- it does not carry EXCEPTION_RECORD::ExceptionInformation[1], the
# address that was actually unreadable or unwritable. That one field is the
# difference between "somewhere in here" and a diagnosis, and it is why the probe
# still earns its keep now that WER is back.
#
# A minidump does carry it, in the exception stream. This script turns that on so
# the next launch produces something that can be read with a debugger instead of
# inferred from a log line. It needs Administrator because LocalDumps lives under
# HKLM; nothing here changes how the game or the DLL behave, only what is written
# to disk after a crash.
#
# DumpType is 1 (minidump): small, fast, and enough for the exception record.
# If the next crash turns out to be the stack exhaustion the 10:35:14 evidence
# points at, switch DumpType to 2 for a full dump -- minidumps capture only a
# limited stack, which is exactly the thing that case needs and does not have.
#
# Remove it again with:
#     Remove-Item -Recurse -Force 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps\EscapeFromTarkov.exe'

$ErrorActionPreference = 'Stop'

$id = [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not ([Security.Principal.WindowsPrincipal]$id).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "This needs Administrator. Right-click the script -> Run with PowerShell, or use the -Command form above."
}

$dumpDir = Join-Path $env:LOCALAPPDATA 'CrashDumps'
New-Item -ItemType Directory -Force -Path $dumpDir | Out-Null

# Per-application so nothing else on the machine starts producing dumps.
$key = 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps\EscapeFromTarkov.exe'
New-Item -Path $key -Force | Out-Null
New-ItemProperty -Path $key -Name DumpFolder -Value $dumpDir -PropertyType ExpandString -Force | Out-Null
New-ItemProperty -Path $key -Name DumpType   -Value 1 -PropertyType DWord -Force | Out-Null
New-ItemProperty -Path $key -Name DumpCount  -Value 10 -PropertyType DWord -Force | Out-Null

Write-Host "LocalDumps enabled for EscapeFromTarkov.exe" -ForegroundColor Green
Get-ItemProperty -Path $key | Select-Object DumpFolder, DumpType, DumpCount | Format-List
Write-Host "Dumps will appear in: $dumpDir"