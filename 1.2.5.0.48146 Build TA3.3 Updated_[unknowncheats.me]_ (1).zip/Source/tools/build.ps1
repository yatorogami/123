<#
.SYNOPSIS
    Build TarkovAddons into a private intermediate directory, then verify the result.

.DESCRIPTION
    WHY THIS EXISTS. Four agents build this project from one tree. The vcxproj pins

        <IntDir>$(Platform)\$(Configuration)\</IntDir>

    so every Prod build by every agent writes the SAME directory, and three things in
    it are single shared files:

        TarkovAddons.pch   249 MB, opened by EVERY cl.exe, rewritten whenever any
                           header changes. Two compilers, one 249 MB rewrite target.
        *.obj              identical names, so two agents building the same TU write
                           the same file.
        *.tlog             MSBuild's "I compiled this source" ledger, read and written
                           non-atomically.

    The first two fail loudly (C1083 "Permission denied" / "Invalid argument",
    MSB6003 on File.Delete). The third does NOT -- it can leave the ledger asserting a
    compile that never happened, which makes a LATER incremental build skip work it
    owes. That is the dangerous one, because it is silent.

    `/FS` is already in AdditionalOptions and covers the PDB. It does not cover the
    PCH, the .obj files or the .tlog files, which is why the contention survived it.

    THE FIX IS ONE PROPERTY. IntDir is an MSBuild property, so it can be overridden on
    the command line without editing the vcxproj. Each agent gets its own intermediates
    and the whole collision class disappears.

    WHY IT IS SAFE. Nothing downstream reads $(IntDir) except the post-build event,
    which copies $(IntDir)$(TargetFileName) and $(IntDir)$(TargetName).map into
    $(OutDir) (vcxproj:407-418). OutDir is NOT overridden, so the deploy folder keeps
    receiving the DLL, the .pdb and the .map exactly as before. tools/deploy.py and
    tools/symbolize.py read from OutDir and are unaffected.

    TargetDir was ASSUMED to follow IntDir, because vcxproj:114 pins it to
    $(IntDir). Measured 2026-10-04 with /v:diag and an overridden IntDir: TargetDir
    resolves to $(OutDir), not the private one, so the PDB lands in the deploy folder
    either way. Recorded because the assumption pointed the wrong way, and shipping it
    unchecked would have been a claim nobody had tested.

    WHAT IT COSTS. One full rebuild the first time a given slot is used, because that
    slot's IntDir is empty. After that it is incremental like any other build. The
    first run is therefore SLOW, and that is not a regression -- the script says so.

.PARAMETER Slot
    Private intermediates are named after this. Defaults to $env:USERNAME, falling
    back to $env:TA_BUILD_SLOT and then to "default". Two agents passing the same slot
    reintroduces exactly the contention this removes, so the default is per-user.

.PARAMETER Configuration
    Prod by default. Per standing instruction, Prod is the only configuration worth
    building: `Prod no aimbot` had a real break from a parallel session's uncommitted
    work that Prod-only reporting would not have caught, and Debug costs far more for
    the same signal.

.PARAMETER Wait
    Wait for a quiet window before building: no MSBuild/cl/link processes AND no recent
    writes to the shared headers, sustained. Process-quiet alone is NOT enough -- two
    agents editing one header is how a build compiles a half-written file, and the
    symptom is a C2065 pointing at a line inside a comment.

.PARAMETER QuietSeconds
    How long the window must hold. 80 s by default. A momentary gap loses the race; the
    first attempt this replaced lost it four times out of five.

.EXAMPLE
    tools\build.ps1
    tools\build.ps1 -Slot quest -Wait
    tools\build.ps1 -Configuration "Prod no aimbot"
#>
[CmdletBinding()]
param(
    [string] $Slot = $(if ($env:TA_BUILD_SLOT) { $env:TA_BUILD_SLOT } elseif ($env:USERNAME) { $env:USERNAME } else { 'default' }),
    [string] $Configuration = 'Prod',
    [switch] $Wait,
    [int]    $QuietSeconds = 80
)

$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')

$proj     = 'TarkovAddons\TarkovAddons.vcxproj'
$projDir  = 'TarkovAddons'
$msb      = 'C:\Program Files\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\MSBuild.exe'
if (-not (Test-Path $msb)) {
    $msb = (Get-ChildItem 'C:\Program Files\Microsoft Visual Studio' -Recurse -Filter MSBuild.exe -ErrorAction SilentlyContinue |
            Where-Object { $_.FullName -match '\\18\\' } | Select-Object -First 1).FullName
}
if (-not $msb) { throw "MSBuild.exe not found" }

# The slot name goes into a path, so it must not be able to escape it.
if ($Slot -notmatch '^[A-Za-z0-9._-]{1,32}$') {
    throw "Slot '$Slot' is not a safe directory name. Use letters, digits, dot, dash or underscore."
}

$intDir = "x64\${Configuration}_$Slot\"
$outDir = switch ($Configuration) {
    'Prod'            { 'out\prod\with_aimbot\' }
    'Prod no aimbot'  { 'out\prod\no_aimbot\' }
    default           { "x64\$Configuration\" }
}
# $outDir above is what the vcxproj's OutDir SAYS, and it is relative to
# $(ProjectDir), not to the repo root this script cd's into. Joining it against
# the repo root produced 'out\prod\with_aimbot\TarkovAddons.dll', which does not
# exist, so a build that had just produced the DLL reported
#   MISSING: out\prod\with_aimbot\TarkovAddons.dll was not produced.
# on exit 0. Prefix the project directory so the check looks where MSBuild wrote
# -- confirmed against MSBuild's own line:
#   TarkovAddons.vcxproj -> ...\TarkovAddons\out\prod\with_aimbot\TarkovAddons.dll
$dll     = Join-Path $projDir ($outDir + 'TarkovAddons.dll')

Write-Host "slot          : $Slot"
Write-Host "configuration : $Configuration"
Write-Host "IntDir        : $intDir   (private -- this is the whole point)"
Write-Host ('OutDir        : $(ProjectDir)' + $outDir + '   (unchanged; the deploy folder still gets dll/pdb/map)')

# ---------------------------------------------------------------------------
# Wait, if asked. Both conditions, sustained.
# ---------------------------------------------------------------------------
if ($Wait) {
    # Every first-party translation unit and header, minus generated and vendored
    # trees. Derived from the tree rather than from a list, because a curated list
    # only ever contains what somebody remembered to add.
    #
    # 2026-10-06 is what that cost. The list this replaces named five files --
    # skeleton_visibility.h, tracy_bridge.h, EspModule.cpp, common_hooks.cpp,
    # AimbotModule.cpp -- and eft_api.h was not on it, so a -Wait build sailed
    # through the quiet window and then failed with 136 errors, all in
    # module\eft_api.h:
    #
    #   eft_api.h(3289,14): error C2270: modifiers invalid on a non-member function
    #   eft_api.h(3396,22): error C2039: "answered" is not a member of
    #                                    eft_api::exfil_eligibility_snapshot
    #
    # which is the exact failure -Wait documents: "two agents editing one header is
    # how a build compiles a half-written file, and the symptom is a C2065
    # pointing at a line inside a comment."
    #
    # Excluded: out\ and x64\ are build output (and x64\ is where every agent's
    # private IntDir lands, so its files change as a side effect of BUILDING),
    # external\ is vendored, GameDump\ is a decrypted game image. Including any of
    # them would restart the quiet window on our own build and never converge.
    $skip = '\\(out|x64|external|GameDump|obj|\.vs)\\'
    $shared = Get-ChildItem 'TarkovAddons' -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in '.h', '.hpp', '.cpp' } |
        Where-Object { $_.FullName -notmatch $skip } |
        Select-Object -ExpandProperty FullName
    Write-Host "`nwaiting for a ${QuietSeconds}s quiet window (no build processes AND no writes to shared files)..."
    $since = $null
    while ($true) {
        $busy = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -in 'MSBuild.exe', 'cl.exe', 'link.exe' }
        $recent = Get-ChildItem $shared -ErrorAction SilentlyContinue |
                  Where-Object { ((Get-Date) - $_.LastWriteTime).TotalSeconds -lt 120 }
        if ($busy -or $recent) { $since = $null }
        elseif (-not $since) { $since = Get-Date }
        if ($since -and ((Get-Date) - $since).TotalSeconds -ge $QuietSeconds) { break }
        Start-Sleep -Seconds 12
    }
    Write-Host "  quiet since $($since.ToString('HH:mm:ss'))"
}

# ---------------------------------------------------------------------------
# Note a cold slot BEFORE building, so a slow first run is expected rather than
# read as a regression.
# ---------------------------------------------------------------------------
$cold = -not (Test-Path $intDir)
if ($cold) {
    Write-Host "`nNOTE: $intDir does not exist yet. The first build for a slot is a FULL"
    Write-Host "      rebuild, not an incremental one. Slow is expected; nothing is wrong."
}

# ---------------------------------------------------------------------------
# Build.
# ---------------------------------------------------------------------------
# /FS is already in AdditionalOptions for the PDB. This adds the isolation the PCH,
# the .obj files and the .tlog ledger never had.
$log = Join-Path $env:TEMP ("opencode\build_{0}_{1}.txt" -f $Configuration.Replace(' ', '_'), $Slot)
& $msb $proj /t:Build /p:Configuration="$Configuration" /p:Platform=x64 "/p:IntDir=$intDir" /v:minimal /nologo > $log 2>&1
$code = $LASTEXITCODE

Write-Host "`n=== exit $code ==="
Select-String -Path $log -Pattern 'error C|error LNK|error MSB|warning C' |
    Select-Object -First 12 | ForEach-Object { '  ' + $_.Line.Trim() }

# ---------------------------------------------------------------------------
# VERIFY. Exit 0 is not evidence that the binary contains the source you just
# edited: MSBuild snapshots timestamps when the task starts, so an edit that lands
# mid-build produces a clean build of the PREVIOUS source. That happened on
# 2026-10-04 -- a build started at 19:19:58, an edit at 19:20:04, exit 0, and a DLL
# without the change in it. Timestamps are the only thing that catches it.
# ---------------------------------------------------------------------------
if ($code -eq 0) {
    $newest = Get-ChildItem 'TarkovAddons' -Recurse -Include *.cpp,*.h -File -ErrorAction SilentlyContinue |
              Sort-Object LastWriteTime -Descending | Select-Object -First 1
    $built  = Get-Item $dll -ErrorAction SilentlyContinue
    Write-Host "`n--- verification ---"
    if (-not $built) {
        Write-Host "  MISSING: $dll was not produced."
    } else {
        Write-Host "  newest source : $($newest.LastWriteTime.ToString('HH:mm:ss.fff'))  $($newest.Name)"
        Write-Host "  dll           : $($built.LastWriteTime.ToString('HH:mm:ss.fff'))  $dll"
        if ($built.LastWriteTime -lt $newest.LastWriteTime) {
            Write-Warning "STALE: the DLL predates the newest source. The build did not include that change."
            $code = 2
        } else {
            Write-Host "  FRESH: the DLL postdates every source file."
        }
    }
    Write-Host "  log           : $log"
}

exit $code