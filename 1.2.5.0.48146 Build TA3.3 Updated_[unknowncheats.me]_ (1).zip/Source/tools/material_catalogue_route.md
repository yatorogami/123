# Sketch: a managed Material catalogue, and what it would and would not buy ChamsModule

> **STATUS: step 1 IMPLEMENTED as a prototype, 2026-10-13. The rest of this
> document is still a sketch.**
>
> `TarkovAddons/module/material_catalogue.h` now exists and is called once per
> process from `ChamsModule::gameworld_update`. See "Step 1 as built" at the
> bottom for exactly what it does and, more importantly, **what is still
> unverified about it** — it has never run inside the game, and it has never been
> through an MSVC build.
>
> Every number-shaped claim below is either measured from the tree or marked as
> needing measurement. There are no counts here, deliberately — see "What is NOT
> measured" at the bottom, which is the part a reviewer should read first.

## What the dumper actually produces, stripped of its machinery

Four output files. Three are presentation. One is the reusable artefact:

    materials_unique.txt   <name> <instance_id>      <- the payload

plus `materials.hpp`, which is that same data cut down to five hardcoded
favourites the author was personally interested in (`Glow_Red`,
`emissive_laser_blue_colourblind`, `manpad_crt_hdr`, `SolidWhite`, `chameleon`)
and the `cham_material` struct the drop-in header emits. The names are ordinary
EFT/Unity asset names — readable, stable, and the only part that would survive a
game update. The instance IDs are per-session and worthless outside it.

So the question this project actually faces is: **can it enumerate live Material
objects by name, in-process, on every build?** Not "can this file be ported".

## Why the dumper's own route does not apply

Four independent reasons, any one of them sufficient:

1. **It cannot compile here.** It includes `api.hpp`, `memory.hpp`, `xor.hpp` and
   calls `svm::hyper_call_api` throughout. Measured: none of those three headers
   exist anywhere in the tree, and `grep -rln "hyper_call\|svm::"` over all
   `.h`/`.cpp`/`.vcxproj` returns nothing outside the dumper itself. It is also a
   `wmain()` console program; this tree builds a DLL manual-mapped into the game.
2. **It is a different process model.** Every read goes through a hypervisor
   (`attach_to_process`, `get_module_base`, `read_memory`). This project is
   injected in-process and needs no external reader — that is the whole
   architectural premise, and `TarkovLauncherBypass` exists to make the injected
   path the only path. Adding an out-of-process driver-backed reader means
   answering how the two coexist, which is a larger question than the feature.
3. **Its own offsets are unverified by its own admission.** Lines 273-314 are a
   `[probe]` pass whose entire purpose is to *discover* where the name pointer and
   the `0xDEADBEEF` word live, because the hardcoded `material_t` beside it
   (`:62-73`, name at `+0x58`, words at `+0xB0`/`+0xB4`) is a guess. Worse, the
   guess contradicts this tree's own measurements: `optics_lens_pipeline.h:1808`
   reads the shader instance ID at `material + 0x60` and `:1299` reads the
   property sheet at `material + 0x108`. A `material_t` ending at `0xB8` cannot
   hold a `+0x108` field. One of the two is describing a different Unity build,
   and the file that says so in its own comments is the one with the probe block.
4. **The filter is load-bearing and unexplained.** `has_sig` at `:329` rejects any
   material without `0xDEADBEEF` at `+0xB0` or `+0xB4`. There is no such
   invariant in Unity 2022.3 native `Material`; if the guess is off by one field
   the dumper silently emits zero rows and still exits 0.

And underneath all four: unknowncheats.me forum snippet, no author, no licence,
no version stamp. This tree vendors third-party code (imgui, nlohmann,
safetyhook, stb, tracy) and `AGENTS.md` requires recording archive URL, commit
and date **in the committing commit** when it does. A forum post supplies none of
those, so there is no provenance to record and nothing to re-derive against.

## The route that does fit: managed, name-resolved, zero RVAs

Everything needed already exists in this tree except one genuinely new piece.

    // 1. System.Type for UnityEngine.Material — pattern already in the codebase
    //    (ChamsModule.cpp:239 for Shader, :1276 for Renderer)
    Il2CppObject* material_type =
        il2utils::get_system_type(unity_image, "UnityEngine", "Material");

    // 2. UnityEngine.Resources.FindObjectsOfTypeAll(Type) -> Object[]
    //    THIS IS THE NEW PIECE, and it is the only one: it is a STATIC method
    //    and this codebase has no static-call path today. Measured: grep for
    //    static_call/call_static/is_static over first-party .h/.cpp returns only
    //    two hits, both `is_static` on a *field* flag in skeleton_visibility.h.
    using find_all_t = Il2CppArray* (*)(Il2CppObject* type, const MethodInfo*);
    const MethodInfo* mi = nullptr;
    const auto find_all = il2utils::get_method<find_all_t>(
        il2utils::resolve_class(unity_image, "UnityEngine", "Resources"),
        "FindObjectsOfTypeAll", 1, /*log_fail=*/true, /*allow_any_argc=*/false, &mi);
    Il2CppArray* all = find_all ? find_all(material_type, mi) : nullptr;

    // 3. Per object: name and id, both name-resolved
    for (size_t i = 0; i < all->max_length; ++i) {
        Il2CppObject* m = reinterpret_cast<Il2CppObject**>(&all->data)[i];
        if (!m || !unity::is_unity_object_alive(m, "chams/catalogue")) continue;
        std::string name = unity::get_name(m);                    // bound, unity.h:823
        uint32_t id = /* GetInstanceID, see the coupling note below */;
    }

Notes that matter:

- `get_method` returns `method->methodPointer` and does not care whether the
  method is static (`il2utils.h:412`), so a static resolves through it unchanged.
  A static's C signature has no `this` — hence the explicit trailing `mi`. Use
  `il2utils::with_methodinfo_t<...>` (`il2utils.h:367-373`) rather than
  hand-writing the signature, so the convention stays in one place.
- `allow_any_argc=false` is deliberate and matches the house rule at
  `ChamsModule.cpp:326-329`: "Exact arity or nothing", because the
  two-argument `set_material` mistake reached a shipped DLL.
- **Coupling warning.** `managed_instance_id()` already exists at
  `optics_lens_pipeline.h:639-649` and is exactly step 3's id read. Do **not**
  call it from the chams side without the optics owner's say-so. That file was
  under `[CLEANUP-PENDING:OPTICS]` — a freeze lifted 2026-10-13 when the rework
  finished — and the reason the prototype duplicates the eight lines instead is
  that a chams feature inheriting another workstream's churn is a bad trade
  whether or not the freeze is formally in place. See the optics memo's own note
  that merging a clone does not make the DLL smaller.
- `unity::is_unity_object_alive` per entry is not optional. The managed wrapper
  outlives the native object across a transit (`unity.h:1151-1160`), and a
  catalogue is built exactly when the scene churns most. Its native memo is
  pointer-keyed with a 64-call TTL, so a one-shot sweep costs one VirtualQuery per
  distinct pointer — acceptable off the per-frame path, which is the only place
  this is allowed to run.

## Where it would plug in — and why it is NOT a drop-in

The paint primitive is `apply_chams_to_material()`
(`ChamsModule.cpp:252-268`): `set_shader`, then `SetColor("_Color_Visible")` and
`SetColor("_Color_Occluded")`, then `set_mainTexture(nullptr)`. Every one of
those is a **Shader-level** operation.

A game Material is not a Shader. So "use a game material instead of a bundled
shader" is **not** a change to what gets passed as `shader` — it is a different
operation: swap the whole material into the renderer slot, via
`set_material(index, game_material)` against the array `get_materials()` returns
(`:330-350`).

That part is clean and save/restore is unaffected, because the pre-paint
originals are captured from `get_sharedMaterials` *before* `get_materials`
instantiates anything (`:288-303`), and `restore_renderer_list` (`:430`) puts
those back. Referencing a shared game material does not mutate it — the hazard
the code avoids at `:352-355` is mutating a shared asset via `get_material`, and
a swap never does that.

**But three of the existing controls stop working, and this is the honest cost:**

| Control | Why it dies on a game material |
|---|---|
| visible / occluded colour pickers | `_Color_Visible` / `_Color_Occluded` are properties of *our* bundled shaders. A game material's shader does not declare them. `SetColor` on an undeclared property is a no-op, so both colours become inert. |
| through-wall rendering | depends entirely on the game shader's own `ZTest`. Nothing in this route sets it. |
| `get_shader_name` / bundle reload path | bypassed — no bundle asset is involved, so the `asset_bundles` recovery path and the `item_shader_cache_` transit-eviction logic do not apply to these entries. |

On through-wall rendering specifically, **I could not verify what the bundled
shaders do.** The `.shader` sources are not in the tree — `assets/` holds only
`asset_bundles.h`, `fonts/`, `maps/`, `menu_background.rc` and one PNG, and the
bundle is a prebuilt 18,806-byte blob embedded in the binary. The two-colour
property naming is
*evidence* of a depth-comparing design, not a measurement of `ZTest`. Treat
"chams currently renders through walls" as unverified.

Which makes this feature **different, not better**: a game material gives you the
game's authored look (emissive, HDR, hideout-lit) on loot you would rather not
retexture. It is a cosmetic option alongside bundled chams, not a replacement —
unless someone finds a game material whose shader happens to be see-through, which
is exactly what the dumper author's `chameleon` favourite was hunting for.

## The real cost is the UI, not the memory read

A catalogue is hundreds to thousands of names. `SelectValue` cannot carry that:
it renders one dropdown. The dynamic-option path itself is fine and **is
exercised today** — measured, `set_options` has three real callers
(`QuestModule.cpp:964`, `QuestResetModule.cpp:52`, `QuestModule.cpp:737`) — but
`SelectValue::set_options` (`SelectValue.h:35`) is the wrong widget at this
scale. The work is a searchable/filterable combo plus persistence of the chosen
name across sessions (instance IDs do not survive a restart; the *name* does).

Cadence: mirror the container-discovery clock already in this module —
2 s during the 30 s ramp, 15 s after (`kContainerChamsRampIntervalMs`,
`kContainerChamsSteadyIntervalMs`, `ChamsModule.h:249-250`). Never per frame,
and never inside `gameworld_update`'s paint path.
`Resources.FindObjectsOfTypeAll` allocates an array of *everything loaded*; its
cost is unmeasured and must be, before it goes anywhere near a clock.

## What is NOT measured

Stated plainly because this repo has been bitten by unmeasured numbers repeatedly:

- **The catalogue size.** Not one count here. Unknown until run.
- **Coverage.** Whether `FindObjectsOfTypeAll` sees materials that exist purely
  on the native side and never got a managed wrapper. If it does not, this route
  returns a strict *subset* of what the dumper's native type-manager walk would,
  and the subset is the thing that decides whether the feature is worth anything.
  This is the single most important unknown and it is cheap to settle: call it,
  print the names, and check whether the expected EFT material names are in there.
- **`FindObjectsOfTypeAll` cost.** Array-of-everything, on a game thread, off the
  paint path.
- **Whether the bundled shaders are see-through** (above).

## The negative control this sketch owes its reviewer

Before any of it is built: call `FindObjectsOfTypeAll(typeof(Material))` and
print the result. Then confirm the names are real material names and not, say,
12 entries or 400,000 of something else. A catalogue that returns an empty array
and a `logger::info` line still exits 0 and still looks like a working feature —
which is precisely the failure this repo has shipped three times. If the route
cannot be made to go red, it is not ready to build.

## Verdict

Worth building, in this form, as a **chams-side cosmetic option** — not as a
port of the dumper, and not as a replacement for bundled chams. The catalogue
idea is sound and the machinery is 90% present. The static-method call is the one
real gap. The honest framing for the menu is "game material look", because the
colour pickers and through-wall behaviour do not survive the swap.

If the goal was x-ray chams off real game materials, that is a different and
harder question — it needs a see-through game shader identified by name, and
finding one is a search, not a port.

---

# Step 1 as built

`TarkovAddons/module/material_catalogue.h`, called from
`ChamsModule::gameworld_update` immediately after the Unity image is resolved
(`ChamsModule.cpp:1414`) — before any paint state is touched, so it cannot
interact with the chams caches. The call site is two lines; deleting the header
and that call removes the prototype entirely.

**What it does.** One `FindObjectsOfTypeAll(typeof(Material))` per process, then
for each entry: native-liveness check, `get_name()`, distinct-name set, needle
counts. It logs a tri-state verdict with the same meaning as
`audit_config_pointers.py` and `tools/verify/audit.py`: **0 = ok, 1 = failed,
2 = checked nothing**. Every count is named (`rows` / `alive` / `dead` /
`unnamed` / `distinct_names`), `elapsed_ms` is logged, and the verdict word
leads the line so a reader who greps one line cannot mistake "ran" for
"worked".

## What the build of it settled

Two things that a sketch would have left as assumptions:

1. **`UnityEngine` declares `FindObjectsOfTypeAll(Type)` on TWO classes** —
   `Resources` (TypeDefIndex 23198, the public sealed one) and `ResourcesAPI`
   (23197), with identical static signatures. Resolving the wrong one yields a
   valid `MethodInfo` for a class the game never calls and an empty array that
   reads exactly like "no materials loaded". Caught by reading
   `GameDump/1.2.0.0.47965/dump.cs`, not by reasoning.
2. **Arity is exactly 1**, `dump.cs:1159760` — so `allow_any_argc=false`, per the
   house rule that the wrong-overload mistake already reached a shipped DLL.

Also: the first compile attempt was **wrong**, and the parse caught it —
`find_all` took `const Il2CppObject*` while the IL2CPP static takes a mutable
`System.Type*`. Fixed before it ever reached a compiler.

## What is still NOT verified about step 1

Stated plainly, because this is the whole risk surface:

- **It has never run inside the game.** Every count in "What is NOT measured"
  above is still open. The first real run is the whole point of the exercise.
- **It has never been through an MSVC build.** `tools/analysis_tree.py` parses it
  (mingw + clang, `-fsyntax-only`), which is a different artefact from
  `Prod|x64` per `AGENTS.md`. By the project's own definition, **nothing here is
  build-verified.**
- **The tri-state is only as good as its first real outcome.** If the verdict
  comes back `INDETERMINATE` on a live raid, that is the checker working, not
  failing — do not "fix" it by widening the class choice to `ResourcesAPI`.

## A tool gotcha worth knowing, because it nearly produced a fake green

`tools/analysis_tree.py` checks a **shadow copy** under
`build/analysis/linux-x64/shadow/`, and the shadow can lag the real tree. While
verifying this prototype the shadow held a *previous* version of the new header
and `--check` reported `OK` against code that was no longer in the file. Two
mistakes compounded it: `--rebuild-shadow >/dev/null 2>&1` swallowed a failure,
and reading the shadow immediately after a rebuild races it.

Working practice, used here:

    python3 tools/analysis_tree.py --rebuild-shadow          # output NOT suppressed
    diff TarkovAddons/module/material_catalogue.h \
         build/analysis/linux-x64/shadow/TarkovAddons/module/material_catalogue.h
    python3 tools/analysis_tree.py --check TarkovAddons/module/impl/ChamsModule.cpp

`--check` does re-sync the shadow before checking, so the `diff` is belt-and-braces
rather than required — but the suppression that hid the failure is the part worth
not repeating. A green that was never compared to the file under test is the
failure mode this repository keeps meeting.

The negative control for the checker itself was run and passes: injecting
`int NEGCTRL_MARKER = undefined_symbol_here;` turns the check
`FAIL ... use of undeclared identifier 'undefined_symbol_here'`, `0 of 1 parsed`,
and reverting returns it to `OK`. Note what it does **not** catch: a wrong method
*name* or a wrong *class* is a runtime failure through `get_method`, so a typo
like `"FindObjectsOfTypeAllTYPO"` stays green here and is caught only by the
in-game tri-state. That is precisely why the verdict is a log line and not a
compile-time assertion.

## Knock-on: the dup_scan scale moved

Adding a first-party file moved `tools/tests/test_dup_scan.py`'s measured
figures, which is the repo's designed tripwire rather than a surprise. Re-measured
and widened per the convention in that test's own docstring: **186 / 176 files,
416,988 / 416,688 tokens** (from 185 / 175 and 414,709 / 414,409). The 2,279-token
rise is 1,151 from the new header plus 1,128 from the call site and its comment.
**SUPERSEDED 2026-10-14**: `gui/menu/changed_marker_layout.h` has since added a
file, so the baseline is now **187 / 177 files, 419,939 / 419,639 tokens**.
Deleting the prototype puts the count back — the docstring says so at the point
someone will be looking.
