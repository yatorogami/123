"""Insert the two new night-vision i18n keys into every lang/*.json.

The repository has 19 language files that each carry every key, in ASCII
alphabetical order by key, one key per line at 2-space indent. This script puts
`hk_night_vision_act` and `night_vision_cb` where they belong in each file so a
`git diff` shows two added lines per file and nothing else.

Run from the repository root:  python tools/add_night_vision_lang.py
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

LANG_DIR = Path(__file__).resolve().parents[1] / "TarkovAddons" / "lang"

KEY_LINE = re.compile(r'^  "([A-Za-z0-9_.]+)":')

# The checkbox label doubles as the hotkey label, exactly as thermal does
# (hk_thermal_act and thermal_vision_cb carry the same string in en.json).
TRANSLATIONS = {
    "br": "Visão noturna",
    "ch": "夜视",
    "cs": "Noční vidění",
    "en": "Night Vision",
    "es": "Visión nocturna",
    "fr": "Vision nocturne",
    "ge": "Nachtsicht",
    "hu": "Éjjellátó",
    "it": "Visione notturna",
    "jp": "ナイトビジョン",
    "kr": "야간투시",
    "pl": "Noktowizja",
    "po": "Visão noturna",
    "ro": "Viziune nocturnă",
    "ru": "Прибор ночного видения",
    "sk": "Nočné videnie",
    "sr": "Ноћни вид",
    "tu": "Gece görüşü",
    "tw": "夜視",
}

NEW_KEYS = ("hk_night_vision_act", "night_vision_cb")


def insert_sorted(lines: list[str], key: str, value: str) -> list[str]:
    """Insert `key` in front of the first existing key that sorts after it."""
    for i, line in enumerate(lines):
        m = KEY_LINE.match(line)
        if m and m.group(1) > key:
            break
    else:
        raise RuntimeError(f"no insertion point found for {key}")
    lines.insert(i, f'  "{key}": {json.dumps(value, ensure_ascii=False)},')
    return lines


def main() -> int:
    failures: list[str] = []
    for path in sorted(LANG_DIR.glob("*.json")):
        code = path.stem
        if code not in TRANSLATIONS:
            failures.append(f"{path.name}: no translation for language {code!r}")
            continue
        raw = path.read_bytes()
        # Keep whatever line ending and encoding the file already uses.
        newline = "\r\n" if b"\r\n" in raw else "\n"
        text = raw.decode("utf-8-sig")
        lines = text.split(newline)

        if any(KEY_LINE.match(line) and KEY_LINE.match(line).group(1) in NEW_KEYS for line in lines):
            failures.append(f"{path.name}: a night-vision key is already present")
            continue

        try:
            for key in NEW_KEYS:
                lines = insert_sorted(lines, key, TRANSLATIONS[code])
        except RuntimeError as exc:
            failures.append(f"{path.name}: {exc}")
            continue

        out = newline.join(lines)
        try:
            data = json.loads(out)
        except json.JSONDecodeError as exc:
            failures.append(f"{path.name}: result does not parse as JSON: {exc}")
            continue

        missing = [k for k in NEW_KEYS if k not in data]
        if missing:
            failures.append(f"{path.name}: keys missing after write: {missing}")
            continue

        path.write_bytes(out.encode("utf-8"))
        print(f"{path.name}: added {NEW_KEYS[0]} and {NEW_KEYS[1]}")

    if failures:
        print("\nFAILED:\n" + "\n".join(failures), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
