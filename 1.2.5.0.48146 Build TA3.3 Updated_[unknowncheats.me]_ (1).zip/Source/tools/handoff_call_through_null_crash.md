# Crash 2026-10-04 21:24:50 — `0xC0000005`, execute at `0x0`, in the optic camera path

**Status:** root cause identified, fix already committed upstream (`6c8435ff`). **The bug class is
still open: 48 unguarded call-throughs remain**, all in other owners' files — none in
`optics_lens_pipeline.h`, `eft_api.h`, or `game_state.h`, which is the part this
workstream owns. Re-measured 2026-10-10; the figure in this file's summary table said
87 and was already stale when it was written, because 9 of my own were fixed in the
same pass that wrote it.

The nine in `eft_api.h` — including all five in the optic scope-zoom path, the closest neighbour to
this crash — are **fixed**; see section 6.

Current breakdown, from `python tools\audit_call_through.py` (exit 0):

```
## TarkovAddons/module/impl/ItemModule.cpp  (22)
## TarkovAddons/module/impl/PlayerModule.cpp  (13)
## TarkovAddons/module/impl/ItemModule.h     (9)
## TarkovAddons/module/impl/PlayerModule.h    (3)
## TarkovAddons/module/impl/EspModule.cpp     (1)     <- get_Nickname, :6274, in the FROZEN file
```

The single `EspModule.cpp` site is inside `[CLEANUP-PENDING:OPTICS]` territory but is
still the ESP workstream's call site, not this workstream's; it is listed here so its
owner can see it, not so I can fix it.

Written by the optics/projection workstream. Cross-workstream: the audit table at the bottom lists
sites in other owners' files. **I have not changed any of those** — they are listed so their owners
can decide.

---

## 1. Verdict

The process died calling a **null function pointer** through `unity::camera_fov`, reached from the
ESP optic frame setup on the DXGI present thread.

The last thing the process logged, in the same millisecond on the same thread, was a failed
managed-method resolve — and the old `camera_fov` called through that resolve's result without
testing it. **The warning in the log was the mechanism, not a coincidence.**

This was raised against me as being an optics-side crash. It was.

## 2. The evidence

The log stops dead at the crash and contains no crash block. The dump is what settles it.

```
C:\Users\Xeon\AppData\Local\CrashDumps\EscapeFromTarkov.exe.27516.dmp
30,060,588 bytes, written 2026-10-04 21:25:00   (10 s after the log's last line)
session pid 27516, build 6AC29545, image base 0x7FFB97E70000
```

### Exception record

```
code            0xC0000005
operation       8            <- EXECUTE
faulting addr   0x0
thread          26620 (0x67FC)
```

**Execute at null.** Not a read, not a write, not a bad pointer into a freed object — a call
through a null function pointer. That single fact narrows the search to one shape of bug in this
codebase: `get_method<...>(...)(obj)`, where the resolver returned `nullptr` and the result was
invoked immediately.

### Thread identity

`26620` is the **exact tid** that logged the last three lines before the process stopped:

```
21:24:50.453  tid=26620  optic-route: accepted
21:24:50.458  tid=26620  optic-packet: invalid at [lens mask polygon empty after clip]
21:24:50.458  tid=26620  WARN  get_method FAILED: Int32::get_fieldOfView args=0
```

It is a dedicated optics thread: of 2,036 lines in that session, `26620` accounts for 120 and
**every one of them is an optic/camera diagnostic**. The main game thread (`31112`, 1,794 lines)
logged nothing optic.

### Stack

The faulting thread's stack unwinds coherently. Outermost first:

```
safetyhook::TrapManager::trap_handler   +0x255
crash_probe::handler                    +0x631      <- our probe, and see section 6
dxhook::dxPresent11                     +0x1DC8
dxhook::draw_imgui                      +0x25D
menu::draw                              +0x2641
ModuleManager::apply                    +0xE1
  AimbotModule::draw_overlay            +0xB09
  EspModule::draw_overlay               +0x600
    EspModule::draw_optic_region_debug  +0x8A
      eft_api::setup_esp_optic_frame    +0x4EA
      eft_api::resolve_esp_camera       +0x732
        eft_api::optic_lens_ensure_frame +0x7DD
          unity::camera_fov             +0x3F       <- deepest of ours
```

Two string literals from the final log line are present **as data words on the stack**, which
independently corroborates the frame above them:

```
rdata+0x3CA200  "lens mask polygon empty after clip"
rdata+0x3CA8F0  "optic-packet: invalid at [%s:%s:%d]"
```

## 3. Root cause

`TarkovAddons/il2cpp/unity.h`, before `6c8435ff`:

```cpp
inline float camera_fov(Il2CppObject* camera_inst) {
    return inst.get_method<float (*)(Il2CppObject*)>("get_fieldOfView", 0)(camera_inst);
}
```

`il2utils::get_method` returns `nullptr` when the method is not found. Invoking that result is a
call to address `0x0` — which is exactly `operation 8, faulting address 0x0`.

The omission is visible from its neighbours. `camera_pixel_height` and `camera_aspect`, written
the same way, both resolve into a local and test it:

```cpp
const auto fn = cached_method<float (*)(Il2CppObject*)>(camera_inst->klass, "get_fieldOfView", 0);
return fn ? fn(camera_inst) : 0.f;
```

`6c8435ff` ("unity: four call-through-null resolvers, one of which killed the process") made
`camera_fov` match its two siblings. **That fix is correct and is already in the tree.**

## 4. Why the log hid this

Two independent reasons, both of which cost real time.

**(a) The probe's report latch had already been spent — by a crash that was not a crash.**

There is no block of any kind for 21:24:50. The cause is in the code, not in the formatter:

```cpp
std::atomic<bool> g_fatal_reported{ false };   // set once, never reset
...
if (!g_fatal_reported.compare_exchange_strong(expected, true)) return;   // report_fatal
```

`immediately_fatal(0xC0000005)` is **true**, so the *vectored* path reports every access
violation — including the ones the game handles and continues from. This session's first one, at
**21:14:37**, printed `FATAL (vectored handler)` and consumed the latch. **Ten minutes later the
process actually died**, and `report_fatal()` returned without a word.

So the same log holds two blocks for a process that did not die, and no block for the one that
did. The comment above that latch states its intent — *"They are per-path rather than global
because a VEH report and a terminate report are different events"* — and the code does the
opposite: one bool shared by both paths it was meant to separate.

**Correction to my own first explanation.** I initially wrote that the probe "ate the report",
destroyed by its own formatter on a stack-starved thread. I inferred that from
`crash_probe::handler`, `guarded_enrich`, `to_chars` and `vformat` sitting on the dump's stack,
and **that inference was wrong**: `guarded_enrich` runs on *every* capture, before the latch is
ever consulted, so its presence says nothing about a formatter dying. The spent latch is
sufficient to explain the silence by itself and is provable from the source, so I have stopped
looking for a second cause. I cannot fully exclude that the VEH also failed to run at 21:24:50 —
both produce silence, and it does not change the fix.

Fixed in `crash_probe.h`: suppression is keyed on `(code, address)` instead of a single
process-lifetime bool; first-chance reports are labelled `EXCEPTION ... FIRST CHANCE`, not
`FATAL`; first-chance reports are capped at 8 per session **with the cap announced rather than
silent**; confirmed reports are exempt from that cap; and the unhandled filter now emits an
unconditional `######## PROCESS DYING ########` marker before anything gated can run.

**(b) `FATAL (vectored handler)` does not mean the process died.** A vectored handler is called on
**first-chance** exceptions, before the unhandled-exception filter. Both `FATAL` blocks in this log
are handled first-chance faults; the pid-27516 one at 21:14:37 was followed by **727 further log
lines over ten minutes**. Anyone reading this log for "the crash" finds the wrong one — which is
what happened to me.

The two blocks, for reference:

| line | session | time | what followed |
|---|---|---|---|
| 189 | pid 30460 | 20:00:34 | session ended within ~33 s (ambiguous — no marker either way) |
| 3124 | pid 27516 | 21:14:37 | **727 further log lines over the next 10 minutes** |

**(c) A full dump existed the whole time, and this file's header said none did.**
`LocalDumps` is set for `EscapeFromTarkov.exe` (`DumpType=1`, `DumpCount=10`), and there are seven
game dumps on disk from 2026-10-03 onward — while `crash_probe.h` asserted "no LocalDumps key is
set, so `%LOCALAPPDATA%\CrashDumps` does not even exist." Corrected in that file's header.

A dump carries every thread's registers and stack, the module list, and the process's live globals
at fault time. This probe cannot print a register, cannot see another thread, and cannot resolve a
pointer cached in `.bss`. The diagnosis in section 2 came out of
`EscapeFromTarkov.exe.27516.dmp` in one command; nothing in the log could have produced it.

**For the next crash: read the dump first.** Use the probe for what only it can do — naming a
fault the game's own logging never mentions, and covering the cases where no dump is written.

## 5. What is NOT established

Stated explicitly, because the temptation to round this off is the failure mode being documented
elsewhere in this repo.

- **Why `get_fieldOfView` failed to resolve.** The camera in the final frames is
  `'BaseOpticCamera(Clone)'` — a derived class, not `Camera`. Candidates: the derived class's
  method table, or teardown of the optic camera while its packet was being rebuilt. I have not
  distinguished these and am not guessing.
- **Whether `cached_method` returning null is common.** It keys on `klass` pointer + name and
  **deliberately does not cache a null** (`unity.h:957-971`), so a persistently-missing method
  re-walks the method table on *every* call, per frame. That is a performance hazard, not a crash
  hazard, and I have not measured how often it fires.
- **Whether the other 87 sites have ever missed.** No evidence either way. The 96 are a *shape*
  match, not a list of known faults.

## 6. The open bug class — 96 found, 9 fixed, 87 open

Pattern: `get_method<...>(...)(obj)` — resolver result invoked inline, never tested.

**A note on the count, because I got it wrong first.** A line-based grep reports **81**. That is
wrong, and undercounts by 15. The formatter splits calls across lines:

```cpp
const auto mod_ptr = procedural_weapon_animation.get_method<Il2CppObject* (*)(Il2CppObject*)>(
    "get_CurrentAimingMod", 0)(
    procedural_weapon_animation.get_instance());
```

The resolver's `(` lands on the line *after* the assignment, so a per-line pattern sees only a
harmless-looking assignment. `tools/audit_call_through.py` walks whole-file text and finds **96**.
It is in the tree; use it rather than re-deriving the grep.

Owner files, **87 open**:

| file | open | note |
|---|---|---|
| `ItemModule.cpp` | 22 | transfer + inventory flow |
| `QuestModule.cpp` | 20 | `quest_book` / `quest_raid_items` |
| `PlayerModule.cpp` | 13 | health, skills, loyalty |
| `ChamsModule.cpp` | 11 | per-item render path |
| `ItemModule.h` | 9 | |
| `WeaponModule.cpp` | 8 | includes `get_HandsController` — same method as the crash path |
| `PlayerModule.h` | 3 | `get_velocity` / `Move` |
| `EspModule.cpp` | 1 | `get_Nickname` |
| **`eft_api.h`** | **0** | **9 fixed, below** |

By enclosing function across the whole set:

| enclosing function | sites | nature |
|---|---|---|
| `quest_book` | 19 | cached template lookup |
| `transfer_grid` | 16 | transfer flow |
| `loot_hydra` | 8 | per-item display |
| `health_controller` | 7 | per-read health access |
| `quest_raid_items`, `skill_manager` | 12 | quest / skill |
| `hk_player_camera_controller_fixed_u…` | 3 | **camera path — see below** |
| `get_scope_zoom` | 5 | **fixed** |

**I could not measure which of these are per-frame.** The `6ac29545` capture has no Tracy zones
on `PlayerModule`, `ChamsModule`, `WeaponModule` or `ItemModule` — only
`frame::EspModule::draw_overlay` (50,267) and `aimbot::ammo_cache` (41,992) appear. The hot/cold
split above is inferred from function names only.

Two things worth your attention specifically:

- **`hk_player_camera_controller_fixed_u…` (3 sites)** is a *camera* path — the same subsystem
  that produced this crash. Highest relevance if you own it.
- **`character_controller`** (`PlayerModule.h`, `get_velocity` / `Move`) is read every frame for the
  player box.

### Fixed in `eft_api.h` — all nine, mine

| function | line (pre-fix) | methods |
|---|---|---|
| `get_scope_zoom` | 4075, 4081, 4085, 4088, 4097 | `get_HandsController`, `get_IsAiming`, `get_ProceduralWeaponAnimation`, `get_CurrentAimingMod`, `get_AdjustableOpticData` |
| `try_is_btr_by_weapon` | 4602, 4627 | `get_HandsController`, `get_Template` |
| `try_read_weapon_ammo` | 6583, 6596 | `get_HandsController`, `get_Item` |

All now resolve into a local and test it, matching the idiom already used elsewhere in the same
file (`try_read_weapon_ammo`'s own magazine reads at `:6602`).

Fail-closed value is the function's own existing "no information" answer: **`1`** for
`get_scope_zoom` (already what it returned for "not scoped"), **`false`** for the two `try_*`
functions. No projection behaviour changes.

Two latent null-derefs went with them, both a line *before* a managed call this crash had already
proven fatal:

- `get_scope_zoom` read `hands_controller_object->klass->name` while only testing the wrapper, not
  `->klass`. `try_is_btr_by_weapon` and `try_read_weapon_ammo` already had that test.
- `get_scope_zoom` read `MinMaxFov` through `adjustable_data` with no null test at all, so a null
  return from a *successful* `get_AdjustableOpticData` resolve was a null deref too.

One deliberate non-change: `try_read_weapon_ammo` leaves `*hands_not_firearm = false` when the
`get_HandsController` resolve misses. Setting it true would steer the Aimbot away from fireport
reads, which is the cheap direction, but it changes Aimbot targeting semantics and that is not a
decision this fix should make silently.

## 7. Recommended fix

Resolve into a local, test it, and fail closed — the pattern `camera_pixel_height` and
`camera_aspect` already use:

```cpp
const auto fn = get_method<Il2CppObject* (*)(Il2CppObject*)>("get_HandsController", 0);
if (!fn) return 1;                       // or {} / nullptr / false, per the return type
Il2CppObject* hands = fn(player.get_instance());
```

Two things worth deciding once, centrally, rather than 87 times:

- **Fail-closed return value per signature.** `1` for a zoom factor, `{}` for a vector,
  `nullptr` for an object, `false` for a predicate, and **no call at all** for `void` returns
  (`set_shader`, `PlaceItem`, `Move`, `RestoreFullHealth` …) where there is nothing to fail to.
- **Whether `get_method` should stop returning a bare `T`.** Every one of these sites is the same
  mistake because the API permitted it. See §7a — a checked accessor now exists.

## 7a. DONE IN PART — a checked accessor, so the dedup pass cannot break working code

**Why this shape rather than 87 hand-edits.** The instruction to fix the sites one at a time is
what broke working code before: each edit is a behaviour change to a live draw path, the 87 files
belong to six other workstreams, and a reviewer cannot see the intended fail-closed value in a
diff that only adds an `if`. So the *decision* moves into a signature and the call sites become
mechanical.

**Landed in `TarkovAddons/il2cpp/Il2CppObjectInstance.h`** (2026-10-06), uncommitted, unused at
every existing call site — nothing in the tree calls it yet, so this is additive and cannot regress
anything:

```cpp
template <typename R, typename... Args>
auto call_or(const char* name, int args, std::invoke_result_t<R, Il2CppObject*, Args...> on_miss,
             Args... call_args);

template <typename R, typename... Args>
void call_or_void(const char* name, int args, Args... call_args);
```

```cpp
// before — resolves, then calls through whatever came back
auto* slot = equipment.get_method<Il2CppObject* (*)(Il2CppObject*, int)>("GetSlot", 1)
                (equipment.get_instance(), slots[i]);

// after — one expression; nothing left to write that can call through null
auto* slot = equipment.call_or<Il2CppObject* (*)(Il2CppObject*, int)>("GetSlot", 1, nullptr, slots[i]);
```

**`on_miss` has no default, and that is the load-bearing part.** The fail-closed value is *not*
deducible from the return type. A float meaning "scope zoom" wants `1.0` (= not magnified); a float
meaning "alpha" wants `0.0`. A deduced `T{}` is silently wrong for one of them, and silently wrong
is how a crash becomes a feature that quietly does nothing — which is exactly what §5.7ad already
records happening to three earlier null guards. Forcing the value at every call site makes the
decision reviewable instead of inferred.

**Verified by compilation**, not by argument. A scratch probe exercised the five return shapes
actually present in the tree (object pointer, `bool` predicate, `float`, extra managed argument,
`void` with and without arguments) through mingw with the `msvc-shim`, filtered with the repo's own
`signatures.py`: **0 signatures**. **Negative control**: renaming `call_or` away makes the same probe
emit **4** signatures, so the check can detect its own absence rather than passing on nothing.

Two bugs the compiler caught that reading would not have:

- `decltype(R(nullptr))` types `on_miss` as the **function-pointer type**, not the return type, so
  `auto` deduces to the pointer and the `return` fails to compile. Needs
  `std::invoke_result_t<R, Il2CppObject*, Args...>` and a `<type_traits>` include.
- The probe needs `-D_SECURITY_ATTRIBUTES_` and the shim on the command line, or
  `il2cpp-class-internals.h:605` fails on `PVOID`. Already documented in
  `tools/verify/README.md`; recorded here because it is not obvious from the error.

**What is deliberately NOT done.** No call site was migrated. §3.2 freezes the ESP/optics surface,
the 87 sites are owned by other workstreams, and `AGENTS.md` records that a previous agent broke
working code on exactly this kind of sweep. The accessor is available; adopting it per file is a
decision for each owner, and `tools/audit_call_through.py` will show the count falling as they do.

**One correction to this file's own audit.** `audit_call_through.py` reports a **second population
the section-6 table does not mention**:

```
UNGUARDED (resolver result invoked inline): 87
resolve-only (assigned to a local, then must be tested): 80
```

So 167 sites are candidates, not 87, and the extra 80 need a *review* (is the local actually tested?)
rather than a mechanical rewrite. Section 6's owner table counts only the first group. Both numbers
should be re-derived with the tool, not quoted from here.

## 8. For owners of the other 87

The search pattern, and the signature to look for in the log/dump:

```
log:   get_method FAILED: <Type>::<method> args=<n>
dump:  0xC0000005, operation 8 (execute), faulting address 0x0
       thread == the tid that logged the get_method FAILED line
```

If a dump ever shows an execute-at-null, symbolise the deepest `TarkovAddons.dll` frame against
the **archived** map for that build's stamp (`C:\Battlestate Games\BsgLauncher\symbols\<stamp>\`)
— not the working tree's, which is a different build and will invent plausible frames.

Full inventory, with enclosing function, as CSV:

```
python tools\audit_call_through.py --csv sites.csv
```

It walks whole-file text rather than line by line, which is what makes the difference between 81
and 96 (section 6). It strips comments first, and deliberately does **not** mask string literals —
the pattern it searches for is itself quoted, so masking literal contents makes every match
invisible and the tool reports zero. That is not hypothetical; it is what the first two runs did.

Note a filter trap that has bitten this codebase before: a per-prefix regex like `\]\s+(\S+)` skips
every `ERROR`/`WARN` line, because the level precedes the bracket.

---

## Provenance

| artefact | value |
|---|---|
| dump | `%LOCALAPPDATA%\CrashDumps\EscapeFromTarkov.exe.27516.dmp` |
| log | `C:\Battlestate Games\BsgLauncher\tarkovaddons_log.txt`, last line 3919 |
| build | `6AC29545` (map archived at `symbols\6AC29545\TarkovAddons.map`) |
| image base | `0x7FFB97E70000` (matches `SESSION BEGIN`) |
| faulting | `0xC0000005` execute at `0x0`, tid 26620 |
| root cause | `unity::camera_fov`, call-through-null — **fixed in `6c8435ff`** |
| audit tool | `tools/audit_call_through.py` (added 2026-10-04; the line-based grep it replaces undercounted 96 as 81) |
| still open | **48** unguarded call-throughs, all in other owners' files (`ItemModule` 31, `PlayerModule` 16, `EspModule.cpp` 1); **none in this workstream's files**; probe still destroys the report for stack-starved faults |
| fixed here | 9 in `eft_api.h` — 5 in `get_scope_zoom`, 2 in `try_is_btr_by_weapon`, 2 in `try_read_weapon_ammo` |