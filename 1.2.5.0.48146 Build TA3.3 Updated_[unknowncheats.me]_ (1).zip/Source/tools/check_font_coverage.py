#!/usr/bin/env python3
"""One-shot: report each vendored UI font's real cmap coverage against the
ranges menu.cpp's build_unicode_glyph_ranges() asks for.

The question this answers is "would switching the menu face to Inter leave a
locale rendering tofu", and it is answered by reading the font, not by trusting
a font's marketing page."""
import pathlib
import struct

REPO = pathlib.Path(__file__).resolve().parent.parent
FONTS = REPO / "TarkovAddons" / "assets" / "fonts"


def cmap_codepoints(path: pathlib.Path) -> set:
    data = path.read_bytes()
    num_tables = struct.unpack(">H", data[4:6])[0]
    tables = {}
    for i in range(num_tables):
        off = 12 + i * 16
        tag = data[off:off + 4].decode("latin-1")
        toff, _tlen = struct.unpack(">II", data[off + 8:off + 16])
        tables[tag] = toff
    coff = tables["cmap"]
    n_sub = struct.unpack(">H", data[coff + 2:coff + 4])[0]
    best = None
    for i in range(n_sub):
        off = coff + 4 + i * 8
        pid, eid, soff = struct.unpack(">HHI", data[off:off + 8])
        fmt = struct.unpack(">H", data[coff + soff:coff + soff + 2])[0]
        if fmt in (4, 12):
            rank = (2 if fmt == 12 else 1, 1 if (pid, eid) in ((3, 10), (0, 4), (0, 6)) else 0)
            if best is None or rank > best[0]:
                best = (rank, coff + soff, fmt)
    _, soff, fmt = best
    cps = set()
    if fmt == 4:
        seg_x2 = struct.unpack(">H", data[soff + 6:soff + 8])[0]
        seg = seg_x2 // 2
        ends = struct.unpack(">" + "H" * seg, data[soff + 14:soff + 14 + seg_x2])
        starts = struct.unpack(">" + "H" * seg, data[soff + 16 + seg_x2:soff + 16 + 2 * seg_x2])
        for s, e in zip(starts, ends):
            if s != 0xFFFF:
                cps.update(range(s, min(e, 0xFFFE) + 1))
    else:
        n = struct.unpack(">I", data[soff + 12:soff + 16])[0]
        for i in range(n):
            g = soff + 16 + i * 12
            s, e, _ = struct.unpack(">III", data[g:g + 12])
            cps.update(range(s, min(e, s + 0x20000) + 1))
    return cps


# Exactly what build_unicode_glyph_ranges() in gui/menu/menu.cpp asks for, and
# what the 19 shipped locales actually need.
PROBES = [
    ("Latin basic", range(0x20, 0x7F)),
    ("Latin-1 supplement", range(0xA0, 0x100)),
    ("Latin Ext-A", range(0x100, 0x180)),
    ("Latin Ext-B (ro/sk/hu)", list(range(0x180, 0x250))),
    ("Greek", list(range(0x386, 0x3D0)) + [0x3CA, 0x3CB, 0x3CC]),
    ("Cyrillic", range(0x400, 0x460)),
    ("Cyrillic supplement", range(0x480, 0x530)),
    ("Vietnamese marks", list(range(0x1EA0, 0x1EF0)) + [0x20AB, 0x20AD]),
    ("Thai (tu)", range(0xE01, 0xE5B)),
    ("CJK unified (ch)", range(0x4E00, 0x4E00 + 400)),
    ("Kana (jp)", list(range(0x3040, 0x30A0))),
    ("Hangul (kr)", list(range(0xAC00, 0xAC00 + 400))),
]

MENU_KEY_SAMPLE = (
    "Gunpowder Tea Recipe Grenade"
    "Выход из рейда"
    "Поле зрения"
    "Позиция"
    "Έξοδος από την εισβολή"
    "_latın_çğıöşü"
)

for name in ("Inter-Regular.ttf", "Inter-SemiBold.ttf", "JetBrainsMono-Regular.ttf"):
    path = FONTS / name
    cps = cmap_codepoints(path)
    print(f"{name}  ({path.stat().st_size:,} bytes, {len(cps):,} code points)")
    for probe, rng in PROBES:
        gaps = [c for c in rng if c not in cps]
        pct = 100.0 * (len(rng) - len(gaps)) / len(rng)
        flag = "ok  " if pct >= 99.0 else "MISS"
        extra = f"  first missing: U+{gaps[0]:04X}" if gaps else ""
        print(f"   {flag} {probe:28s} {pct:6.1f}%{extra}")
    missing_chars = sorted({c for c in MENU_KEY_SAMPLE if ord(c) not in cps})
    print(f"   {'ok  ' if not missing_chars else 'MISS'} sample UI string: "
          f"{'all present' if not missing_chars else 'missing ' + repr(''.join(missing_chars))}")
    print()