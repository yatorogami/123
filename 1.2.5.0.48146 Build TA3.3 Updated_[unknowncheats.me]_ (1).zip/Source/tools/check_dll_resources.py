#!/usr/bin/env python3
"""One-shot: list the RCDATA ids and sizes the shipped DLL actually carries.

This exists because a .rc entry that silently fails to compile is invisible
from the menu: the font loader would fall back to a system face, the UI would
look perfectly normal, and the embedded Inter would simply not be there. The
only way to know is to read the resource directory of the artefact."""
import struct
import sys
from pathlib import Path

RT_RCDATA = 10
dll = Path(sys.argv[1] if len(sys.argv) > 1
           else r"TarkovAddons\out\prod\with_aimbot\TarkovAddons.dll")
data = dll.read_bytes()

pe = struct.unpack("<I", data[0x3C:0x40])[0]
assert data[pe:pe + 4] == b"PE\0\0", "not a PE image"
n_sections = struct.unpack("<H", data[pe + 6:pe + 8])[0]
opt_size = struct.unpack("<H", data[pe + 20:pe + 22])[0]
opt = pe + 24
magic = struct.unpack("<H", data[opt:opt + 2])[0]
dd = opt + (112 if magic == 0x20B else 96)
rsrc_rva, rsrc_size = struct.unpack("<II", data[dd + 2 * 8:dd + 2 * 8 + 8])

sections = []
for i in range(n_sections):
    off = pe + 24 + opt_size + i * 40
    name = data[off:off + 8].rstrip(b"\0").decode("latin-1")
    vsize, vaddr, rsize, raddr = struct.unpack("<IIII", data[off + 8:off + 24])
    sections.append((name, vaddr, vsize, raddr))


def rva_to_off(rva):
    for _n, vaddr, vsize, raddr in sections:
        if vaddr <= rva < vaddr + max(vsize, rsize):
            return raddr + (rva - vaddr)
    raise ValueError(f"RVA {rva:#x} is in no section")


base = rva_to_off(rsrc_rva)


def walk(dir_off, level, path):
    named, ids = struct.unpack("<HH", data[dir_off + 12:dir_off + 16])
    entries = []
    for i in range(named + ids):
        off = dir_off + 16 + i * 8
        name_or_id, child = struct.unpack("<II", data[off:off + 8])
        is_name = bool(name_or_id & 0x80000000)
        is_dir = bool(child & 0x80000000)
        key = name_or_id & 0x7FFFFFFF
        entries.append((key, is_name, is_dir, child))
    out = []
    for key, is_name, is_dir, child in entries:
        label = ("name@" + str(key)) if is_name else str(key)
        here = path + [label]
        if is_dir:
            out += walk(base + (child & 0x7FFFFFFF), level + 1, here)
        else:
            leaf = base + child
            rva, size = struct.unpack("<II", data[leaf:leaf + 8])
            out.append((here, rva_to_off(rva), size))
    return out


leaves = walk(base, 0, [])
rcdata = [(p, o, s) for p, o, s in leaves if p and p[0] == str(RT_RCDATA)]
print(f"{dll}: {len(rcdata)} RCDATA entries, {rsrc_size:,} byte resource section\n")

# The three menu faces, by the id assets/menu_background.rc gives them.
FONT_SOURCES = {
    "1400": "assets/fonts/Inter-Regular.ttf",
    "1401": "assets/fonts/Inter-SemiBold.ttf",
    "1402": "assets/fonts/JetBrainsMono-Regular.ttf",
}
ROOT = Path(__file__).resolve().parent.parent / "TarkovAddons"

for path, off, size in sorted(rcdata, key=lambda t: int(t[0][-2]) if t[0][-2].isdigit() else 0):
    # The walk's path is [type, id, language]; the id is the MIDDLE leaf, and
    # printing the language instead (1033 for en-US) reads like 45 identical
    # entries and answers none of the question.
    ident = path[-2]
    kind = ""
    if ident in FONT_SOURCES:
        # Byte-identity against the vendored file, NOT a name-table read: the
        # question is "is the face the build embedded the one in the tree", and
        # a checksum answers it without parsing a format I could get wrong.
        # The first version tried to decode the family name and printed x86
        # bytes, which is exactly what a wrong name-table offset looks like.
        src = ROOT / FONT_SOURCES[ident]
        want = src.read_bytes()
        got = data[off:off + size]
        same = got == want
        kind = ("  <- " + FONT_SOURCES[ident].rsplit("/", 1)[1]
                + ("  IDENTICAL to the vendored file" if same
                   else f"  *** MISMATCH ({len(got):,} read, {len(want):,} expected) ***"))
        if not same:
            sys.exit(2)
    print(f"  {ident:>6}  {size:>10,} bytes{kind}")
