"""Read a Windows minidump the way a crash investigation actually needs it.

Written 2026-10-04 after a fourth `0xE06D7363` crash produced no usable evidence
for two weeks. What was missing was not a log parser but a way to look at the one
artefact that had everything: the dump carries the exception record, every
thread's registers and stack, the module list with full paths, AND -- the part
that decided the case -- a memory list that still holds the process's live
globals. A pointer cached in .bss at crash time is in there.

Subcommands
-----------
  exception              the exception record, and the faulting thread's registers
  frames                 every stack word of the faulting thread that lands inside a
                         mapped image, with its slot offset
  global <rva>           read a global out of OUR image (by RVA) from the dump's
                         memory list, and say which module the value points into
  modules / threads      the raw tables

Why a frame list has to be built this way
-----------------------------------------
The crash probe scans 4 KB of stack from RSP for words that are code addresses.
A dump typically holds 20+ KB, and the difference is the whole case: on
2026-10-04 the probe's 4 KB scan produced twelve frames, none of them ours, and
the dump's full stack contained three of ours at rsp+0x0EE0 -- including the
function that turned out to be throwing. Four more kilobytes of stack is the
difference between "our code is not involved" and a named call.

Slot offsets are printed because they are the only signal that separates a live
return address from residue. See the note in tools/probe_test/README.md.

Usage:
  python tools/minidump_read.py <dump> exception
  python tools/minidump_read.py <dump> frames [--ours]
  python tools/minidump_read.py <dump> global 0x5B89A8
"""
import struct
import sys

EXCEPTION_STREAM = 6
THREAD_LIST_STREAM = 3
MEMORY_LIST_STREAM = 5
MODULE_LIST_STREAM = 4

# AMD64 CONTEXT field offsets.
CTX = [("rax", 0x78), ("rcx", 0x80), ("rdx", 0x88), ("rbx", 0x90), ("rsp", 0x98),
       ("rbp", 0xA0), ("rsi", 0xA8), ("rdi", 0xB0), ("r8", 0xB8), ("r9", 0xC0),
       ("r10", 0xC8), ("r11", 0xD0), ("r12", 0xD8), ("r13", 0xE0), ("r14", 0xE8),
       ("r15", 0xF0), ("rip", 0xF8)]


class Dump:
    def __init__(self, path):
        self.d = bytearray(open(path, "rb").read())
        if self.d[:4] != b"MDMP":
            raise ValueError("not a minidump: bad signature %r" % bytes(self.d[:4]))
        (self.n, self.dir_rva, _, self.ts, self.flags) = struct.unpack_from("<IIIII", self.d, 8)
        self.streams = {}
        for i in range(self.n):
            t, size, rva = struct.unpack_from("<III", self.d, self.dir_rva + 12 * i)
            self.streams.setdefault(t, (size, rva))
        for need, name in ((EXCEPTION_STREAM, "exception"), (THREAD_LIST_STREAM, "thread list"),
                           (MEMORY_LIST_STREAM, "memory list"), (MODULE_LIST_STREAM, "module list")):
            if need not in self.streams:
                raise ValueError("dump has no %s stream -- it is probably a triage dump" % name)

    def u16(self, o): return struct.unpack_from("<H", self.d, o)[0]
    def u32(self, o): return struct.unpack_from("<I", self.d, o)[0]
    def u64(self, o): return struct.unpack_from("<Q", self.d, o)[0]

    def modules(self):
        _, rva = self.streams[MODULE_LIST_STREAM]
        out = []
        for i in range(self.u32(rva)):
            b = rva + 4 + 108 * i
            # ModuleNameRva points at a MINIDUMP_STRING: a ULONG32 byte length,
            # then UTF-16LE. Reading it as a bare UTF-16 string yields
            # plausible-looking garbage, which is worse than nothing because it
            # looks like a module name.
            nr = self.u32(b + 20)
            n = self.u32(nr)
            out.append((self.u64(b), self.u32(b + 8),
                        bytes(self.d[nr + 4:nr + 4 + n]).decode("utf-16-le", "replace")))
        return out

    def threads(self):
        _, rva = self.streams[THREAD_LIST_STREAM]
        out = []
        for i in range(self.u32(rva)):
            b = rva + 4 + 48 * i
            out.append(dict(tid=self.u32(b),
                            stack=(self.u64(b + 24), self.u32(b + 32), self.u32(b + 36)),
                            ctx=self.u32(b + 44)))
        return out

    def ctx(self, t):
        rva = t["ctx"]
        return {name: self.u64(rva + off) for name, off in CTX}

    def exception(self):
        _, o = self.streams[EXCEPTION_STREAM]
        n = self.u32(o + 32)
        return dict(tid=self.u32(o), code=self.u32(o + 8), flags=self.u32(o + 12),
                    address=self.u64(o + 24), nparams=n,
                    info=[self.u64(o + 40 + 8 * i) for i in range(min(n, 4))])

    def memory_regions(self):
        _, rva = self.streams[MEMORY_LIST_STREAM]
        return [(self.u64(rva + 4 + 16 * i), self.u32(rva + 4 + 16 * i + 8),
                 self.u32(rva + 4 + 16 * i + 12)) for i in range(self.u32(rva))]

    def read_at(self, addr, size):
        """Bytes at a virtual address, or None if no captured region covers it."""
        for start, size_, data in self.memory_regions():
            if start <= addr and addr + size <= start + size_:
                off = data + (addr - start)
                return bytes(self.d[off:off + size])
        return None

    def stack(self, t):
        start, size, data = t["stack"]
        return bytes(self.d[data:data + size]), start

    def module_of(self, value, mods=None):
        mods = mods if mods is not None else self.modules()
        for base, size, name in mods:
            if base <= value < base + size:
                return name, value - base
        return None, None


def cmd_exception(dm):
    e = dm.exception()
    print("=== exception ===")
    print("  thread            %d (0x%X)" % (e["tid"], e["tid"]))
    print("  code              0x%08X" % e["code"])
    print("  flags             0x%08X" % e["flags"])
    print("  address           0x%016X" % e["address"])
    if e["code"] == 0xC0000005 and e["nparams"] >= 2:
        # For an ACCESS_VIOLATION this pair is (operation, address): 0=read,
        # 1=write, 8=execute. WER does not carry it; it is the field that
        # distinguishes "read through a bad pointer" from "called a null one".
        print("  operation         %d  (0=read 1=write 8=execute)" % e["info"][0])
        print("  faulting address  0x%X" % e["info"][1])
    else:
        # For 0xE06D7363 ExceptionInformation[0] is the _ThrowInfo*, which is
        # what the probe's type recovery walks. A low value like 0x19930520 is
        # not a pointer, which is why the thrown type reads UNRESOLVED for this
        # class -- that is correct, not a failure of the probe.
        print("  ExceptionInfo[0]  0x%X   (for 0xE06D7363: the _ThrowInfo*)" % e["info"][0]
              if e["info"] else "  (no parameters)")
        for i, v in enumerate(e["info"][1:], 1):
            print("  ExceptionInfo[%d]  0x%X" % (i, v))

    for t in dm.threads():
        if t["tid"] != e["tid"]:
            continue
        g = dm.ctx(t)
        print("\n=== faulting thread 0x%X registers ===" % t["tid"])
        for name, _ in CTX:
            print("  %-4s 0x%016X" % (name, g[name]))
        print()
        if g["rip"] == 0:
            print("  RIP IS ZERO: the faulting instruction was a call/jmp through a null\n"
                  "  or near-null pointer, and the CALLER is the return address it pushed.")
        else:
            n, off = dm.module_of(g["rip"])
            print("  RIP is inside %s+0x%s" % (n or "?", ("%X" % off) if off is not None else "?"))
            print("  NOTE: if this is inside a crash-reporting DLL rather than the\n"
                  "  faulting module, the context was taken while the process was dying\n"
                  "  and no longer describes the fault. Check before trusting it.")


def cmd_frames(dm, ours_only=False):
    e = dm.exception()
    mods = dm.modules()
    ours = [(b, s, n) for b, s, n in mods if "TarkovAddons" in n]
    for t in dm.threads():
        if t["tid"] != e["tid"]:
            continue
        raw, base = dm.stack(t)
        g = dm.ctx(t)
        print("stack region 0x%X..0x%X (%d bytes captured), context RSP 0x%X"
              % (base, base + len(raw), len(raw), g["rsp"]))
        print("\n=== stack words inside a mapped image ===")
        n = 0
        for off in range(0, len(raw) - 8, 8):
            v = struct.unpack_from("<Q", raw, off)[0]
            name, mo = dm.module_of(v, mods)
            if not name:
                continue
            if ours_only and "TarkovAddons" not in name:
                continue
            tag = "  <-- OURS" if "TarkovAddons" in name else ""
            print("  [rsp+0x%04X] 0x%016X  %s+0x%s%s"
                  % (off, v, name.split("\\")[-1], ("%X" % mo) if mo is not None else "?", tag))
            n += 1
        print("  -> %d word(s)%s" % (n, " in our image" if ours_only else ""))
        if ours:
            b, s, nm = ours[0]
            print("\n  our image in this dump: base 0x%X  size 0x%X  (%s)"
                  % (b, s, nm.split("\\")[-1]))


def cmd_global(dm, rva):
    ours = [(b, s, n) for b, s, n in dm.modules() if "TarkovAddons" in n]
    if not ours:
        print("our image is not in this dump's module list")
        return
    base = ours[0][0]
    addr = base + rva
    print("our image 0x%X   rva 0x%X -> absolute 0x%X" % (base, rva, addr))
    raw = dm.read_at(addr, 8)
    if raw is None:
        print("  NOT CAPTURED. The memory list holds the stacks and whatever else WER\n"
              "  chose; a global outside those regions simply is not in the dump.\n"
              "  Absence here is not evidence the value was zero.")
        return
    val = struct.unpack_from("<Q", raw)[0]
    print("  value = 0x%016X" % val)
    name, off = dm.module_of(val)
    if name:
        print("  -> %s+0x%s" % (name, ("%X" % off) if off is not None else "?"))
        print("  A pointer into GameAssembly.dll here is an il2cpp-compiled MANAGED\n"
              "  method. Look its RVA up in a dump.cs from a byte-identical\n"
              "  GameAssembly.dll and the callee is named.")
    else:
        print("  -> not inside any module in the dump")


def main(argv):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    if len(argv) < 3:
        print(__doc__)
        return 2
    dm = Dump(argv[1])
    cmd = argv[2]
    if cmd == "exception":
        cmd_exception(dm)
    elif cmd == "frames":
        cmd_frames(dm, "--ours" in argv[3:])
    elif cmd == "global":
        if len(argv) < 4:
            print("global needs an RVA, e.g. `global 0x5B89A8`")
            return 2
        cmd_global(dm, int(argv[3], 0))
    elif cmd == "modules":
        for b, s, n in dm.modules():
            print("  0x%012X %10d  %s" % (b, s, n))
    elif cmd == "threads":
        for t in dm.threads():
            g = dm.ctx(t)
            print("  tid %-6d rip 0x%016X rsp 0x%016X" % (t["tid"], g["rip"], g["rsp"]))
    else:
        print(__doc__)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))