"""Build, install and uninstall TarkovAddons Reloaded on Windows.

One script, three commands:

    python tools/deploy.py build      [--rebuild] [--backend cmake|msbuild] [--config NAME]
    python tools/deploy.py install    [--flavor NAME] [--path DIR] [--source DIR]
    python tools/deploy.py uninstall  [--path DIR] [--purge]

Requires Python 3.10+ and nothing outside the standard library, matching
tools/manifest_tool.py. `build` prefers CMake for the two configurations CMake
defines (Debug and Prod) and finds cmake.exe and vcvars64.bat itself, saying how
to install them if they are missing. If cmake.exe is absent but MSBuild is
present, the build falls back to MSBuild and says so, at length, on stderr --
because the two backends are not the same artefact and a silent swap is how they
drifted apart before. Asking for CMake explicitly with --backend cmake disables
that fallback, so automation can treat a missing toolchain as a stop. Release
and "Prod no aimbot" have no CMake target and stay on MSBuild; --backend msbuild
forces MSBuild for any configuration.

Paths between us and the game are built with pathlib parts rather than embedded
backslashes, so a relative path is a tuple like ("ta", "launcher.cfg") and
joinpath does the separator. That is the one piece of Windows-specific care
this needs, and removing it would have reintroduced a class of bug the
PowerShell version spent a lot of lines on.

Deploy layout, which the runtime expects and which install/uninstall mirror:

    <drive>:\\Battlestate Games\\BsgLauncher\\
        TarkovAddons.dll  TarkovLauncherBypass.dll  vk_swiftshader.dll
        *.pdb  *.map      symbols, so a crash can be read on this machine
        ta\\
            compatibility\\profiles\\<version>\\manifest.json
            launcher.cfg  offsets.cfg  patterns.cfg
            "TarkovAddons Reloaded Background.png"

Only the files above are touched. ta\\configs\\, ta\\maps\\,
ta\\tarkov_prices.json and the two log files next to the DLL are written by the
mod at runtime and belong to the user, which is what makes re-running install
to update a safe thing to do.
"""

from __future__ import annotations

import glob
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

# The pre-3.2 import lives beside this script. See migrate_legacy.py's module
# docstring for why it is here rather than in the DLL.
#
# The sys.path line is not defensive noise -- it is required. This file is launched
# three different ways and each puts a different directory at sys.path[0]:
#
#     python tools/deploy.py          -> tools/     (script directory)
#     python -m tools.deploy          -> repo root  (working directory)
#     pytest tools/tests              -> repo root, plus tools/ via conftest
#
# A bare `import migrate_legacy` works in the first case and fails in the other two,
# which is how `test_does_not_hang_or_prompt_when_it_cannot_ask` started failing:
# it spawns `python -m tools.deploy`, so the import blew up before main() and the
# test saw a traceback instead of the "--yes" hint it was asserting on.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import migrate_legacy

# ---------------------------------------------------------------------------
#  What we own
# ---------------------------------------------------------------------------

# The three DLLs, in load order. launcher.cfg names the first two explicitly
# (stage1/stage2); vk_swiftshader.dll is the injection stub the launcher loads
# before either of them.
DEPLOY_DLLS = (
    "TarkovAddons.dll",
    "TarkovLauncherBypass.dll",
    "vk_swiftshader.dll",
)

# Shipped read-only data, copied on install and removed on uninstall.
#
# The subdirectories of ta\ that are NOT here are written by the mod at runtime
# and belong to the user, so they are never read, moved or deleted. lang\ is
# absent on purpose: all 19 locales are compiled into every configuration as
# RCDATA 1300-1318 by menu_background.rc and the compiled copy is read first,
# so the folder is never needed on disk.
DATA_FILES = (
    "launcher.cfg",
    "offsets.cfg",
    "patterns.cfg",
    "TarkovAddons Reloaded Background.png",
)

# Deleted only by --purge. The logs are worth keeping: they are the evidence for
# any crash report, and "send me the log next to TarkovAddons.dll" is a request
# anyone can act on.
LOG_FILES = (
    "tarkovaddons_log.txt",
    "tarkovaddons_launcher_log.txt",
)

RUNTIME_DATA_FILES = (("ta", "tarkov_prices.json"),)

# Symbols ship next to the DLL because Prod is the build that reaches a machine
# where nobody rebuilds, and the .map is the only symbol source readable there:
# no llvm-pdbutil, no cvdump, no DIA SDK. Matched by glob so a new project in
# the solution is carried along without editing this list.
SYMBOL_GLOBS = ("*.pdb", "*.map")

# Where per-build symbols are archived, so a later crash can still be symbolized.
#
# 2026-10-02. Installing already shipped TarkovAddons.map beside the DLL, and that
# almost worked: a crash at 22:0x reported build stamp 0x6AC00784, and the map sitting
# next to the DLL was 0x6AC0093E -- a LATER build, because install had been re-run
# between the crash and the read. Every symbol name was wrong: 10 of 11 frames landed
# mid-instruction under the newer map (measurable -- a function entry starts with a
# push/sub/endbr64, and 10 of 11 decoded to things like "and ah, byte ptr [rdx+0x79]").
# crash_probe.h's build stamp DETECTED the mismatch, which is exactly why it exists,
# but detecting it does not name the crash.
#
# So: keep the plain .map/.pdb for tools/symbolize.py's default path, and ALSO archive
# a copy keyed by the build's PE TimeDateStamp. A crash log then carries the stamp and
# the matching map is one directory listing away, for as many builds as are retained.
#
# Only TarkovAddons.dll is archived, not all three DLLs. The mod is the only one whose
# crash is reported, and the .map is ~7.7 MB and the .pdb ~36 MB each; archiving every
# project would triple the cost of a diagnostic nobody reads for the other two.
SYMBOL_ARCHIVE_STAMPS = 8
SYMBOL_ARCHIVE_DIR = "symbols"

# Per-build IL2CPP manifests. The vcxproj Content item copies
# compatibility/profiles/**/manifest.json to ta\compatibility\profiles\ with
# CopyToOutputDirectory=PreserveNewest, so a built OutDir is already laid out.
MANIFEST_DIR = ("ta", "compatibility", "profiles")
MANIFEST_NAME = "manifest.json"

# Only the NEWEST profile ships, and install prunes the others from the target.
# The launcher-side selector (TarkovLauncherBypass/util/compat_profile.cpp)
# ranks manifests by status, not by game build, and a status tie resolves to
# directory-iteration order -- alphabetically, the OLDEST version first. So a
# stale profile left beside a fresh one by an earlier install can keep winning
# after a game update, and every one of its byte checks then rejects against
# the live module, skipping the anti-cheat patches with only a log warning.
# One deployed profile removes the choice. An older game build is not harmed:
# the in-game DLL matches profiles by module identity and falls back to
# signature scan when none matches.

# ---------------------------------------------------------------------------
#  Layout
# ---------------------------------------------------------------------------

# The checkout root. tools/deploy.py sits two levels below it, and both build
# systems place their trees under it (build\<cfg>\x64\<slot> for CMake).
REPO_ROOT = Path(__file__).resolve().parent.parent

SOLUTION_DIR = REPO_ROOT / "TarkovAddons"

# Read off the Prod|x64 and Prod no aimbot|x64 OutDir in the .vcxproj files.
# Only the two Prod flavors are here: Debug and Release fall back to the
# toolset default under x64\, so deploy those with --source instead. Only a
# Prod build is meant to reach a game box anyway.
FLAVORS = {
    "with_aimbot": ("out", "prod", "with_aimbot"),
    "no_aimbot": ("out", "prod", "no_aimbot"),
}

CONFIG_FLAVOR = {"Prod": "with_aimbot", "Prod no aimbot": "no_aimbot"}

CONFIGURATIONS = ("Debug", "Release", "Prod", "Prod no aimbot")

# What the top-level CMakeLists.txt defines (CMAKE_CONFIGURATION_TYPES). CMake
# has no target for the other two configurations at all, which is why they are
# MSBuild's job whichever backend was asked for.
CMAKE_CONFIGURATIONS = ("Debug", "Prod")

# Where the Battlestate client installs by default. It can be pointed at another
# drive, so the search covers a range rather than assuming C:.
BSG_RELATIVE = ("Battlestate Games", "BsgLauncher")

# Presence of this is what makes a candidate strong. The injector derives the
# DLL directory from GetModuleFileNameW and truncates at this name
# (TarkovLauncherBypass/feature/injector.cpp), so a folder without it is not a
# BsgLauncher folder by that code's own definition.
BSG_MARKER = "BsgLauncher.exe"

DRIVE_LETTERS = "CDEF"

# Every configuration in all three .vcxproj files pins this with no fallback, so
# a missing toolset fails the build as MSB8020 after a long toolset search.
REQUIRED_TOOLSET = "v145"

RUNNING_PROCESSES = ("EscapeFromTarkov", "BsgLauncher")

MSBUILD_DOWNLOAD = "https://visualstudio.microsoft.com/vs/"
MSBUILD_DOC = (
    "https://learn.microsoft.com/cpp/build/"
    "tao-minimum-vs-build-tools-vs-build-tools-validation"
)

CMAKE_DOWNLOAD = "https://cmake.org/download/"

CXX_WORKLOAD = "Desktop development with C++"


# ---------------------------------------------------------------------------
#  Small helpers
# ---------------------------------------------------------------------------


class DeployError(Exception):
    """A failure with a message meant for the person running this.

    Raised rather than returned so the command bodies can stay linear: an
    expected failure aborts the command the same way an unexpected one does,
    and main() turns it into a printed message and an exit code.
    """


def die(message: str, code: int = 1) -> int:
    """Print a user-facing failure to stderr and return the process exit code.

    Every error in this script is aimed at whoever is setting the project up or
    operating the install, so they are printed as plain text. Raising instead
    would bury the useful part under a traceback pointing into this file.
    """
    print(f"\nerror: {message}\n", file=sys.stderr)
    return code


def show(parts: tuple[str, ...]) -> str:
    """Render a relative path the way it will be named on disk (Windows)."""
    return "\\".join(parts)


def target_of(root: Path, parts: tuple[str, ...]) -> Path:
    return root.joinpath(*parts)


def locked(path: Path) -> bool:
    """True when a deploy could not put its own file here.

    Two different things stop a copy, and neither probe below finds both:

    * A DLL loaded into the launcher or the game is mapped. A mapped image
      refuses delete and rename, but it can still be *opened* for read/write --
      the image section permits it. So an open-for-write probe answers "not
      locked" for precisely the case this function exists to catch, and the
      deploy then fails partway through the copy and leaves a half-updated
      folder behind, which is the outcome the docstring used to promise.
    * A read-only file refuses to be opened for writing, but can still be
      renamed onto itself, so a delete/rename probe misses it entirely.

    Hence both, and either is enough. Neither probe writes: opening `r+b` does
    not truncate, and renaming a file onto itself leaves content, length, mtime
    and hash identical (verified), so this is safe against a real deploy tree.

    The resulting OSError names only the file, not the process holding it, which
    is why the caller also runs running_processes() to say who to close.
    """
    if not path.is_file():
        return False

    try:
        with open(path, "r+b"):
            pass
    except OSError:
        return True

    try:
        os.replace(path, path)
    except OSError:
        return True

    return False


def running_processes() -> list[str]:
    """Names of launcher/game processes currently up, best effort.

    Advisory only. locked() is the ground truth; this exists to name the process
    to close instead of leaving the copy to fail on its own.
    """
    found = set()
    for name in RUNNING_PROCESSES:
        # tasklist is the one thing guaranteed present on a Windows box that can
        # build this. Failure here is not worth reporting.
        try:
            out = subprocess.run(
                ["tasklist", "/FI", f"IMAGENAME eq {name}.exe", "/NH"],
                capture_output=True,
                text=True,
                timeout=10,
            ).stdout
        except (OSError, subprocess.SubprocessError):
            return []
        if name.lower() in out.lower():
            found.add(name)
    return sorted(found)


# ---------------------------------------------------------------------------
#  Confirmation
# ---------------------------------------------------------------------------


def confirm(summary: list[str], yes: bool, dry_run: bool, hint: str) -> bool:
    """Print what is about to happen and get agreement before doing it.

    Installing over a live install, and deleting a user's settings, are both
    things nobody expects to happen because a flag was left at its default. So
    both ask first, and neither has a quiet path: with no --yes and no terminal
    to ask on, this stops and says which flag to pass rather than assuming.

    A dry run is never in a position to need permission, so it is not asked for.

    Returns True to proceed. An explicit "no" returns False, because that is an
    answer rather than a failure. Having no terminal to ask on raises
    DeployError: the caller did nothing wrong, but cannot continue either.
    """
    print()
    for line in summary:
        print(f"  {line}" if line else "")
    print()

    if yes or dry_run:
        return True

    if not sys.stdin.isatty():
        raise DeployError(
            "not going to act without confirmation, and there is no terminal to ask on.\n\n"
            f"{hint}"
        )

    # isatty() is a fast path, not the defence. On Windows it reports True for a
    # redirected stdin -- `< nul`, or a pipe -- so the check above passes and the
    # prompt is printed to someone who cannot answer it. The read below is what
    # actually establishes whether there is anyone there, so its failure has to
    # be treated the same way the isatty() failure is.
    try:
        answer = input("Proceed? [y/N] ").strip().lower()
    except EOFError:
        print()
        raise DeployError(
            "not going to act without confirmation, and stdin reached end-of-file "
            "instead of an answer.\n\n"
            f"{hint}"
        ) from None
    except KeyboardInterrupt:
        # An actual person pressing Ctrl+C is a decision to stop, not a broken
        # terminal, so this stays an ordinary "no" rather than an error.
        print()
        return False

    return answer in ("y", "yes")


# ---------------------------------------------------------------------------
#  Finding the target folder
# ---------------------------------------------------------------------------


def choose_bsg_launcher(strong: list[Path], weak: list[Path]) -> Path | None:
    """Pick the single folder to deploy into, or raise if that is not possible.

    Split out from find_bsg_launcher so the rule is testable on its own: it is
    the decision that matters, and the drive search around it is just plumbing
    that cannot be exercised off Windows.
    """
    found = strong or weak
    if not found:
        return None

    if len(found) > 1:
        listed = "\n".join(f"  {path}" for path in found)
        raise DeployError(
            "more than one BsgLauncher folder found, so this will not guess:\n\n"
            f"{listed}\n\nRe-run with the one you want:\n"
            "    python tools/deploy.py install --path '<path>'"
        )

    if not strong:
        warn(
            f"found {show(BSG_RELATIVE)} but no {BSG_MARKER} in it. Continuing; "
            "launch the game once through the Battlestate client to finish the "
            "install."
        )

    return found[0]


def find_bsg_launcher(
    target: str | None,
    drives: str = DRIVE_LETTERS,
    required: bool = True,
) -> Path | None:
    """Locate the BsgLauncher folder, or raise with an explanation.

    A folder containing BsgLauncher.exe is a strong candidate; one without is
    still accepted if it is the only one, because an interrupted install and a
    game that has not been launched yet both look like that, and refusing would
    make the folder impossible to install into.

    Never guesses between several strong candidates. Deploying into a folder
    the user does not read produces a mod that appears to do nothing at all,
    which is exactly the silent failure these scripts exist to remove.

    required=False returns None instead of raising when the drive search finds
    nothing, which is how uninstall reports "nothing is installed" as a
    successful no-op. An explicit target that does not exist is an error either
    way: that is a typo, not an absence.
    """
    if target:
        path = Path(target).expanduser()
        if not path.is_dir():
            raise DeployError(f"target path does not exist or is not a folder: {path}")
        if not (path / BSG_MARKER).is_file():
            warn(
                f"{BSG_MARKER} not found in {path}. Continuing because the path "
                "was given explicitly."
            )

        return path

    strong: list[Path] = []
    weak: list[Path] = []

    for letter in drives:
        root = Path(f"{letter}:\\")
        if not root.is_dir():
            continue
        candidate = root.joinpath(*BSG_RELATIVE)
        if not candidate.is_dir():
            continue
        (strong if (candidate / BSG_MARKER).is_file() else weak).append(candidate)

    chosen = choose_bsg_launcher(strong, weak)
    if chosen is not None:
        return chosen
    if not required:
        return None

    searched = ", ".join(f"{letter}:" for letter in drives)
    raise DeployError(
        f"BsgLauncher folder not found.\n\n"
        f"Searched for <drive>:\\{show(BSG_RELATIVE)} on: {searched}\n"
        "The Battlestate client installs to C:\\Battlestate Games by default, "
        "but it can be pointed at another drive.\n\n"
        "  * Start the Battlestate client once so the game is installed, then re-run.\n"
        "  * If it is installed somewhere this did not look, pass it explicitly:\n"
        "        python tools/deploy.py install --path 'G:\\Somewhere\\BsgLauncher'"
    )

# ---------------------------------------------------------------------------
#  Finding the toolchain
# ---------------------------------------------------------------------------


def warn(message: str) -> None:
    print(f"warning: {message}", file=sys.stderr)


def usable_msbuild(path: str) -> bool:
    """True when the path is an MSBuild.exe that actually runs.

    A stale entry on PATH or a leftover registry path is the usual reason a
    search turns up something that cannot build, so every candidate is run with
    -version before it is believed.
    """
    if not path or not os.path.isfile(path):
        return False
    try:
        result = subprocess.run(
            [path, "-version", "-nologo"],
            capture_output=True,
            text=True,
            timeout=60,
        )

    except (OSError, subprocess.SubprocessError):
        return False
    return result.returncode == 0


def msbuild_candidates() -> list[str]:
    """Every MSBuild.exe worth trying, most authoritative first."""
    found: list[str] = []

    # 1. On PATH: a Developer Command Prompt, or a machine where the Visual
    #    Studio Installer has refreshed it.
    on_path = shutil.which("msbuild.exe")
    if on_path:
        found.append(on_path)

    # 2. vswhere, Microsoft's supported enumeration API. The only thing that
    #    survives a custom install root, so it goes before the fixed locations.
    program_files = os.environ.get("ProgramFiles")
    if program_files:
        vswhere = os.path.join(
            program_files, "Microsoft Visual Studio", "Installer", "vswhere.exe"
        )

        if os.path.isfile(vswhere):
            try:
                out = subprocess.run(
                    [
                        vswhere,
                        "-latest",
                        "-products", "*",
                        "-requires", "Microsoft.Component.MSBuild",
                        "-find", r"MSBuild\**\Bin\MSBuild.exe",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=60,
                ).stdout
                found.extend(line.strip() for line in out.splitlines() if line.strip())
            except (OSError, subprocess.SubprocessError):
                pass

    # 3. Default locations, globbed so the Visual Studio version does not have
    #    to be known here. VS 18 at the time of writing, but this is what makes a
    #    newer install work without editing this file.
    #
    # Visual Studio has always installed under Program Files (x86) even when it
    # is a 64-bit product, so neither root is wrong to check.
    for variable in ("ProgramFiles", "ProgramFiles(x86)"):
        root = os.environ.get(variable)
        if not root:
            continue
        pattern = os.path.join(
            root, "Microsoft Visual Studio", "*", "*", "MSBuild", "Current", "Bin",
            "MSBuild.exe",
        )

        found.extend(glob.glob(pattern))

    return found


def msbuild_not_found_reason() -> str:
    """The "MSBuild was not found" message, one source of truth.

    Shared by find_msbuild's own error and by the both-toolchains-missing error
    in cmd_build, so a change to the install instructions cannot leave the two
    disagreeing about what to install.
    """
    roots = "\n".join(
        "  %ProgramFiles%\\Microsoft Visual Studio\\<version>\\<edition>\\MSBuild\\Current\\Bin"
        "  %ProgramFiles(x86)%\\Microsoft Visual Studio\\<version>\\<edition>\\MSBuild\\Current\\Bin"
    )

    return (
        "MSBuild was not found.\n\n"
        "Looked for MSBuild.exe on PATH, via vswhere, and under:\n"
        f"{roots}\n\n"
        "Install it, then re-run:\n\n"
        "  1. Download Visual Studio, or the free \"Build Tools for Visual Studio\":\n"
        f"       {MSBUILD_DOWNLOAD}\n"
        f"  2. In the installer, select the \"{CXX_WORKLOAD}\" workload. This\n"
        f"     solution needs MSVC toolset {REQUIRED_TOOLSET} (all four\n"
        "     configurations pin <PlatformToolset>v145</PlatformToolset>), x64\n"
        "     targeting, and the Windows SDK. All three are in that workload.\n"
        "  3. Official instructions, including the offline layout route if the\n"
        "     installer cannot reach the internet:\n"
        f"       {MSBUILD_DOC}\n\n"
        "Already installed it? Either open a Developer Command Prompt so it reaches\n"
        "PATH, or point at it directly:\n\n"
        "    python tools/deploy.py build --msbuild \"C:\\Program Files (x86)\\"
        "Microsoft Visual Studio\\18\\BuildTools\\MSBuild\\Current\\Bin\\MSBuild.exe\""
    )


def find_msbuild(explicit: str | None) -> Path:
    """Return a working MSBuild.exe, or raise with how to install one."""
    if explicit:
        if usable_msbuild(explicit):
            return Path(explicit)
        raise DeployError(
            f"--msbuild was given as {explicit!r}, which is not an MSBuild.exe that runs."
        )

    for candidate in msbuild_candidates():
        if usable_msbuild(candidate):
            return Path(candidate)

    raise DeployError(msbuild_not_found_reason())

def has_required_toolset(msbuild: Path) -> bool:
    """Whether MSVC toolset v145 is present next to this MSBuild.

    Deliberately a warning and not a failure. MSVC can be installed in a layout
    this does not model, and refusing to build on a guess would be worse than
    letting MSBuild try; the build's own MSB8020 is the authority.
    """
    # .../<edition>/MSBuild/Current/Bin/MSBuild.exe -> .../<edition>/MSBuild
    msbuild_root = msbuild.parent.parent
    vc_root = msbuild_root / "Microsoft" / "VC"
    if not vc_root.is_dir():
        return False

    for version in vc_root.iterdir():
        if not version.is_dir():
            continue
        toolset = version / "Platforms" / "x64" / "PlatformToolsets" / REQUIRED_TOOLSET
        if toolset.is_dir():
            return True
    return False


# ---------------------------------------------------------------------------
#  CMake toolchain
# ---------------------------------------------------------------------------


# The slot names a whole path component (build\<config>\x64\<slot>), and a
# build configured into it can be deleted by --rebuild, so the name is
# restricted rather than trusted. Same pattern as tools/build.ps1, which needs
# it for the same reason; "." and ".." match the pattern and are rejected
# separately because build.ps1's slot is only ever a path suffix while this
# one is a component of its own.
SLOT_NAME = re.compile(r"^[A-Za-z0-9._-]{1,32}$")


def build_slot() -> str:
    """The name of the build tree to use: $env:SLOT, defaulting to opencode.

    Same contract as tools/build_cmake.ps1 and configure_cmake.bat. The
    variable exists so two agents do not share one build directory; it is read
    at call time, so a test can patch the environment.
    """
    slot = os.environ.get("SLOT") or "opencode"
    if slot in (".", "..") or not SLOT_NAME.match(slot):
        raise DeployError(
            f"SLOT {slot!r} is not a safe directory name. Use letters, digits, "
            "dot, dash or underscore, at most 32 characters. The slot names "
            "the build tree, and --rebuild deletes it."
        )
    return slot


def cmake_tree(configuration: str, slot: str) -> Path:
    """Where the CMake build tree for a configuration lives."""
    return REPO_ROOT / "build" / configuration / "x64" / slot


def cmake_candidates() -> list[str]:
    """Every cmake.exe worth trying, most authoritative first."""
    found: list[str] = []

    on_path = shutil.which("cmake")
    if on_path:
        found.append(on_path)

    # Default locations. configure_cmake.bat pins the first of these, so it is
    # the one this project's machines actually have; the installer's per-user
    # default is checked too rather than assumed away.
    for variable in ("ProgramFiles", "ProgramFiles(x86)"):
        root = os.environ.get(variable)
        if root:
            found.append(os.path.join(root, "CMake", "bin", "cmake.exe"))

    local = os.environ.get("LocalAppData")
    if local:
        found.append(
            os.path.join(local, "Programs", "CMake", "bin", "cmake.exe")
        )
    return found


def usable_cmake(path: str) -> bool:
    """True when the path is a cmake.exe that actually runs.

    Same reason as usable_msbuild: a stale PATH entry is the usual reason a
    search turns up something that cannot configure anything.
    """
    if not path or not os.path.isfile(path):
        return False
    try:
        result = subprocess.run(
            [path, "--version"],
            capture_output=True,
            text=True,
            timeout=60,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return result.returncode == 0


def indent(text: str, prefix: str = "  ") -> str:
    """Prefix continuation lines of a wrapped message.

    Used when one error is embedded inside another, so the embedded one is
    visibly nested rather than reading as more lines of the same complaint.
    """
    return "\n".join(prefix + line if line else line for line in text.splitlines())


def find_cmake() -> Path:
    """Return a working cmake.exe, or raise with how to install one."""
    for candidate in cmake_candidates():
        if usable_cmake(candidate):
            return Path(candidate)

    raise DeployError(
        "CMake was not found.\n\n"
        "Looked for cmake.exe on PATH and under:\n"
        "  %ProgramFiles%\\CMake\\bin\n"
        "  %ProgramFiles(x86)%\\CMake\\bin\n"
        "  %LocalAppData%\\Programs\\CMake\\bin\n\n"
        "Install it:\n"
        f"    {CMAKE_DOWNLOAD}\n\n"
        "Or build with MSBuild instead, which handles every configuration:\n\n"
        "    python tools/deploy.py build --backend msbuild"
    )


def cmake_missing_reason() -> str | None:
    """Why CMake cannot be used, or None when it can.

    A reason rather than a bool, because the caller's whole job is to say which
    toolchain was skipped and why -- "cmake.exe was not found" is the first half
    of that sentence and it is not recoverable from a True/False.
    """
    try:
        find_cmake()
    except DeployError as failure:
        return str(failure)
    return None


def msbuild_is_usable() -> bool:
    """True when MSBuild could take over if asked.

    Checked rather than assumed, so the fallback cannot end in the MSBuild
    "not found" error below with the CMake one having already been explained --
    two failures in a row, where the second is the one that matters.
    """
    try:
        find_msbuild(None)
    except DeployError:
        return False
    return True


# What is known to differ between the two backends, as measured on this tree
# and not as suspected. The fallback is allowed because a machine without
# cmake.exe is otherwise stuck, but silently swapping toolchains is how the
# original decision against a fallback was made -- so the warning below states
# the cost rather than hiding it. Extend this list rather than shortening it,
# and only from a measurement.
FALLBACK_CAVEATS = (
    "the two are not the same artefact. Measured on 2026-10-12 against the same",
    "source: the .map files disagree, so tools/map_icf.py reads different",
    "fold figures from the two builds, and MSBuild passes /SUBSYSTEM:WINDOWS",
    "plus /sdl /Oi /GS /Gy /Zc:forScope /Zc:inline /Zc:wchar_t /external:W3",
    "/diagnostics:column at link and compile, which the CMake build does not.",
)


def announce_fallback(
    configuration: str, reason: str, msbuild: Path
) -> None:
    """Say, loudly and on stderr, that the toolchain was swapped.

    Loud because the original design refused this outright: the same command
    producing a different build system per machine is how the backends drifted
    apart, and three of those differences (/Zi, /permissive-, the UNICODE
    spelling) carried comments insisting they were deliberate. A fallback that
    did not announce itself would recreate that situation invisibly, so this is
    on stderr, it is long, and it names the remedy.
    """
    lines = [
        "",
        "=" * 72,
        "TOOLCHAIN FALLBACK: CMake was wanted and MSBuild was used instead",
        "=" * 72,
        "",
        f"{configuration} normally builds with CMake (Ninja). On this machine",
        "cmake.exe could not be found, so the build fell back to MSBuild:",
        "",
        f"    {msbuild}",
        "",
        "Why CMake was skipped:",
    ]
    lines += [f"    {line}" for line in reason.strip().splitlines()]
    lines += [
        "",
        "This is NOT a warning you can safely ignore:",
    ]
    lines += [f"  {bullet}" for bullet in FALLBACK_CAVEATS]
    lines += [
        "",
        "To get the CMake build, install CMake and re-run. To make this choice",
        "explicit and stop relying on what is installed, either works:",
        "",
        f"    python tools/deploy.py build --config {configuration} --backend msbuild",
        f"    python tools/deploy.py build --config {configuration} --backend cmake",
        "",
        "The second errors rather than falling back, which is the right choice",
        "in automation where a silent swap is worse than a stop.",
        "=" * 72,
        "",
    ]
    print("\n".join(lines), file=sys.stderr)


def vcvars_candidates() -> list[str]:
    """Every vcvars64.bat worth trying, most authoritative first.

    The CMake build cannot run without it: Ninja has no toolchain of its own,
    and configure_cmake.bat runs it for the same reason -- cl.exe does not find
    windows.h without the INCLUDE/LIB it sets.
    """
    found: list[str] = []

    program_files = os.environ.get("ProgramFiles")
    if program_files:
        vswhere = os.path.join(
            program_files, "Microsoft Visual Studio", "Installer", "vswhere.exe"
        )
        if os.path.isfile(vswhere):
            try:
                out = subprocess.run(
                    [
                        vswhere,
                        "-latest",
                        "-products", "*",
                        "-find", r"VC\Auxiliary\Build\vcvars64.bat",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=60,
                ).stdout
                found.extend(line.strip() for line in out.splitlines() if line.strip())
            except (OSError, subprocess.SubprocessError):
                pass

    # Default locations, globbed so the Visual Studio version and edition do
    # not have to be known here. Same layout build_cmake.ps1 hardcodes for one
    # machine; this finds it on any of them.
    for variable in ("ProgramFiles", "ProgramFiles(x86)"):
        root = os.environ.get(variable)
        if not root:
            continue
        pattern = os.path.join(
            root, "Microsoft Visual Studio", "*", "*", "VC", "Auxiliary", "Build",
            "vcvars64.bat",
        )
        found.extend(glob.glob(pattern))

    return found


def find_vcvars() -> Path:
    """Return a vcvars64.bat that exists, or raise with how to get one."""
    for candidate in vcvars_candidates():
        if os.path.isfile(candidate):
            return Path(candidate)

    raise DeployError(
        "vcvars64.bat was not found.\n\n"
        "Looked via vswhere and under:\n"
        "  %ProgramFiles%\\Microsoft Visual Studio\\<version>\\<edition>\\VC\\Auxiliary\\Build\n"
        "  %ProgramFiles(x86)%\\Microsoft Visual Studio\\<version>\\<edition>\\VC\\Auxiliary\\Build\n\n"
        "It ships with the MSVC toolset. Install it with the\n"
        f"\"{CXX_WORKLOAD}\" workload:\n"
        f"    {MSBUILD_DOWNLOAD}\n\n"
        "Or build with MSBuild instead:\n\n"
        "    python tools/deploy.py build --backend msbuild"
    )


def vcvars_environment(vcvars: Path) -> dict[str, str]:
    """The environment vcvars64.bat leaves behind, captured as a dict.

    Read once and passed to both cmake invocations, rather than re-running the
    batch file around every command: composing "call C:\\Program Files\\... &&
    cmake ..." as a single cmd line is where the quoting goes wrong, and a
    captured environment keeps every real command a plain argv list.

    The check that it worked is INCLUDE appearing in the parsed output -- not
    merely in the parent's environment, which already has it when deploy.py is
    run from a Developer Command Prompt.
    """
    result = subprocess.run(
        ["cmd", "/c", "call", str(vcvars), "&&", "set"],
        capture_output=True,
        text=True,
        errors="replace",
        timeout=300,
    )

    env = os.environ.copy()
    saw_include = False
    for line in result.stdout.splitlines():
        name, sep, value = line.partition("=")
        # Windows carries odd entries like "=C:=C:\..."; they are not variables.
        if not sep or not name or name.startswith("="):
            continue
        env[name] = value
        if name == "INCLUDE":
            saw_include = True

    if result.returncode != 0 or not saw_include:
        raise DeployError(
            f"could not read the environment out of {vcvars} "
            f"(exit code {result.returncode}, INCLUDE seen: {saw_include})."
        )
    return env


# ---------------------------------------------------------------------------
#  The file inventory
# ---------------------------------------------------------------------------


def profile_version(name: str) -> tuple[int, ...] | None:
    """A profile directory name as a version tuple, or None when it is not one.

    Profile directories are named after the game build they describe
    (1.2.0.0.47888), so component-wise numeric comparison orders them by age.
    """
    parts = name.split(".")
    if not parts or not all(part.isascii() and part.isdigit() for part in parts):
        return None
    return tuple(int(part) for part in parts)


def shipped_profile_dirs(hits: list[Path], root: Path) -> set[str] | None:
    """Which profile directory names under `root` should ship, or None for all.

    None means the layout cannot be ranked -- a name is not a version, or a
    manifest sits somewhere other than one directory below the root -- and the
    caller ships every candidate. Shipping a stale profile costs a wrong
    runtime selection; dropping one on a guess costs a build its only profile,
    so ambiguity resolves to keeping everything.
    """
    names: set[str] = set()
    for hit in hits:
        inside = hit.relative_to(root)
        if len(inside.parts) != 2:
            return None
        names.add(inside.parts[0])
    if not names:
        return None
    versions: dict[str, tuple[int, ...]] = {}
    for name in sorted(names):
        version = profile_version(name)
        if version is None:
            return None
        versions[name] = version
    newest = max(versions.values())
    return {name for name, version in versions.items() if version == newest}


def deploy_items(source: Path) -> list[tuple[tuple[str, ...], str]]:
    """Every artifact a build tree contributes, as (relative parts, kind).

    Entries are returned whether or not the file exists, so install can report
    which of the three DLLs a configuration failed to produce instead of
    copying two of three and reporting success.
    """
    items: list[tuple[tuple[str, ...], str]] = []

    for name in DEPLOY_DLLS:
        items.append(((name,), "dll"))

    for pattern in SYMBOL_GLOBS:
        for hit in sorted(source.glob(pattern)):
            if hit.is_file():
                items.append(((hit.name,), "symbol"))

    for name in DATA_FILES:
        items.append((("ta", name), "data"))

    manifest_root = source.joinpath(*MANIFEST_DIR)
    if manifest_root.is_dir():
        hits = sorted(hit for hit in manifest_root.rglob(MANIFEST_NAME)
                      if hit.is_file())
        keep = shipped_profile_dirs(hits, manifest_root)
        for hit in hits:
            inside = hit.relative_to(manifest_root)
            if keep is not None and inside.parts[0] not in keep:
                continue
            items.append((MANIFEST_DIR + tuple(inside.parts), "manifest"))

    return items


def build_stamp(dll: Path) -> str | None:
    """The PE TimeDateStamp of `dll`, as 8 hex digits, or None if unreadable.

    This is the same field crash_probe.h prints as "build stamp", read from the same
    place. The two MUST agree: a crash log is only useful against a symbol file whose
    stamp matches, and that check is only meaningful if both sides read one field.
    """
    try:
        with dll.open("rb") as handle:
            header = handle.read(0x40)
            if len(header) < 0x40 or header[:2] != b"MZ":
                return None
            pe_offset = int.from_bytes(header[0x3C:0x40], "little")
            handle.seek(pe_offset + 8)
            stamp = handle.read(4)
    except OSError:
        return None
    if len(stamp) != 4:
        return None
    return f"{int.from_bytes(stamp, 'little'):08X}"


def archive_symbols(target: Path, source: Path) -> int:
    """Copy this build's TarkovAddons .map/.pdb into symbols\\<stamp>\\, keeping N.

    Returns the number of builds retained. Pruning keeps only the newest
    SYMBOL_ARCHIVE_STAMPS directories, so the folder cannot grow without bound: each
    build is roughly 44 MB of symbols and nothing here is worth more than a few
    crashes' worth of history.

    Re-installing the SAME stamp overwrites in place rather than consuming a slot, which
    is the common case -- rebuild, install, rebuild, install -- and would otherwise
    evict a build that was never actually distinct.
    """
    dll = source / "TarkovAddons.dll"
    if not dll.is_file():
        return 0
    stamp = build_stamp(dll)
    if not stamp:
        raise OSError(
            f"could not read the PE timestamp from {dll.name}; symbols not archived. "
            "A crash log names its build with this same field, so without it the "
            "archive cannot be matched to a crash."
        )

    root = target / SYMBOL_ARCHIVE_DIR
    slot = root / stamp
    slot.mkdir(parents=True, exist_ok=True)
    for suffix in (".map", ".pdb"):
        src = source / f"TarkovAddons{suffix}"
        if src.is_file():
            shutil.copy2(src, slot / src.name)

    # Newest first, then drop anything past the retention count. The current stamp is
    # always kept, so it is never a prune candidate.
    dirs = sorted((d for d in root.iterdir() if d.is_dir()),
                  key=lambda d: d.stat().st_mtime, reverse=True)
    for stale in dirs[SYMBOL_ARCHIVE_STAMPS:]:
        for f in stale.iterdir():
            f.unlink()
        stale.rmdir()
    return len(dirs[:SYMBOL_ARCHIVE_STAMPS])


def soften_console_errors() -> None:
    """Stop a legacy console codepage from killing a build mid-report.

    Build tools print UTF-8, and a console set to a non-UTF-8 codepage (cp1251
    on the machine this was found on) raises UnicodeEncodeError on the first
    character it cannot represent -- one glyph in ninja's output killed the
    build process here, leaving the real build running with no one reading it.
    Replacing the offending character is always better than that; the streams
    are also replaced wholesale by the GUI and by pytest, so a stream without
    reconfigure() is expected rather than an error.
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass


def run_streaming(
    command: list[str],
    env: dict[str, str] | None = None,
    lines: list[str] | None = None,
) -> int:
    """Run a build tool, echoing its output line by line as it arrives.

    Deliberately not subprocess.run with inherited stdout. A parent that
    redirects Python-level print -- which is how the GUI captures everything
    into its log pane -- does not redirect a child process's file descriptor, so
    the build would print straight past the window and the user would see
    nothing. Piping and re-printing works for both front-ends, and it also means
    the CLI's output is flushed per line rather than per process.

    `env` replaces the child's environment wholesale (used for the vcvars64
    environment CMake needs). `lines` collects the text as it streams, for the
    one caller that has to read a number out of a helper script's output.
    """
    soften_console_errors()

    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
        env=env,
    )

    assert process.stdout is not None
    with process.stdout:
        for line in process.stdout:
            print(line, end="", flush=True)
            if lines is not None:
                lines.append(line)
    return process.wait()


# ---------------------------------------------------------------------------
#  Commands
# ---------------------------------------------------------------------------


def resolve_backend(configuration: str, options: dict) -> str:
    """Which build system builds this configuration.

    CMake is the default for the two configurations it defines
    (CMAKE_CONFIGURATION_TYPES in the top-level CMakeLists.txt). MSBuild takes
    the other two, which have no CMake target at all, and any configuration
    when --backend msbuild or --msbuild PATH asks for it.

    Keyed on the configuration and on what was asked for -- deliberately NOT on
    what happens to be installed. This function never looks at the filesystem,
    so it stays pure and testable. The cmake.exe check lives in cmd_build, which
    is what turns "CMake is the preferred backend here" into "MSBuild built it
    this time"; keeping the two apart is why a test can assert on the mapping
    without any toolchain present.

    An explicit --backend cmake means "CMake or nothing" and is never fallen
    back from; that is also this function's only cmake path.
    """
    requested = options.get("backend")
    if requested == "cmake":
        if options.get("msbuild"):
            raise DeployError(
                "--backend cmake and --msbuild disagree; give only one of them."
            )
        if configuration not in CMAKE_CONFIGURATIONS:
            raise DeployError(
                f"--backend cmake cannot build {configuration!r}. CMake defines only "
                f"{' and '.join(CMAKE_CONFIGURATIONS)} (CMAKE_CONFIGURATION_TYPES in "
                "the top-level CMakeLists.txt); the other configurations are built by\n"
                "MSBuild alone. Either pick a CMake configuration, or:\n\n"
                f"    python tools/deploy.py build --config \"{configuration}\" "
                "--backend msbuild"
            )
        return "cmake"

    if requested == "msbuild" or options.get("msbuild"):
        return "msbuild"

    if configuration in CMAKE_CONFIGURATIONS:
        return "cmake"
    return "msbuild"


def cmd_build(options: dict) -> int:
    """Build with the backend that fits the configuration."""
    configuration = options["config"]
    requested = options.get("backend")
    backend = resolve_backend(configuration, options)
    fallback_reason: str | None = None

    if backend == "cmake" and requested is None and not options.get("msbuild"):
        # The automatic CMake choice, and only that. An explicit --backend
        # cmake is the user saying "I want CMake, fail if you cannot", so it
        # must not be silently swapped away from them.
        fallback_reason = cmake_missing_reason()
        if fallback_reason:
            if not msbuild_is_usable():
                raise DeployError(
                    "Neither CMake nor MSBuild could be used.\n\n"
                    f"CMake, which {configuration} normally builds with:\n"
                    f"{indent(fallback_reason)}\n\n"
                    "MSBuild, which would otherwise build every configuration:\n"
                    f"{indent(msbuild_not_found_reason())}"
                )
            backend = "msbuild"
            # Announced here, at the decision point, rather than inside
            # build_with_msbuild: it is a statement about what this run is
            # doing, and it must be said even if the MSBuild build that follows
            # then fails. It also means the announcement cannot be bypassed by
            # whatever the backend function chooses to do first.
            announce_fallback(
                configuration, fallback_reason, find_msbuild(options.get("msbuild"))
            )

    if backend == "msbuild" and requested is None and not options.get("msbuild"):
        # Only said when it was the automatic choice, so it explains rather
        # than repeats what the user just asked for. True for both reasons
        # MSBuild can be automatic: the configuration has no CMake target, and
        # cmake.exe was missing and the fallback took over (which has already
        # announced itself, and louder, above).
        if fallback_reason is None:
            print(
                f"Note      CMake builds only {', '.join(CMAKE_CONFIGURATIONS)}; "
                f"using MSBuild for {configuration}."
            )
            print()

    if backend == "cmake":
        return build_with_cmake(configuration, options)
    return build_with_msbuild(configuration, options)


def build_with_cmake(configuration: str, options: dict) -> int:
    """Configure if needed, build with Ninja, and stage the Prod output.

    Mirrors tools/build_cmake.ps1 step for step -- same tree layout, same
    configure arguments as configure_cmake.bat -- with two differences: a
    missing tree configures itself instead of stopping with "run
    configure_cmake.ps1 first", and every line is echoed as it arrives rather
    than the last 20 when the build is over.
    """
    cmake = find_cmake()
    vcvars = find_vcvars()
    slot = build_slot()
    tree = cmake_tree(configuration, slot)

    print(f"Backend   CMake (Ninja)")
    print(f"CMake     {cmake}")
    print(f"vcvars64  {vcvars}")
    print(f"Tree      {tree}")

    env = vcvars_environment(vcvars)

    if options.get("rebuild") and tree.exists():
        # Rebuild means what it means under MSBuild: start clean. The tree is
        # regenerable, but deleting a directory warrants a look at the path
        # first. build_slot() has already restricted the name; this guard is
        # the backstop that keeps --rebuild inside the checkout no matter
        # what else produced the path.
        if REPO_ROOT not in tree.resolve().parents:
            raise DeployError(
                f"refusing to delete {tree.resolve()}: not under {REPO_ROOT}"
            )
        print(f"Rebuild   removing {tree}")
        shutil.rmtree(tree)

    if not (tree / "build.ninja").is_file():
        print(f"Configure {configuration}")
        print()
        code = run_streaming(
            [
                str(cmake),
                "-S", str(REPO_ROOT),
                "-B", str(tree),
                "-G", "Ninja",
                f"-DCMAKE_BUILD_TYPE={configuration}",
                "-DCMAKE_EXPORT_COMPILE_COMMANDS=ON",
                "-DCMAKE_SYSTEM_PROCESSOR=AMD64",
            ],
            env=env,
        )
        if code != 0:
            raise DeployError(
                f"CMake configure failed with exit code {code}. Nothing was built."
            )
        if not (tree / "build.ninja").is_file():
            # The pair of facts that once configured the wrong tree and still
            # reported success (see WORKFLOW.md on the SLOT forwarding bug).
            raise DeployError(
                f"CMake configure exited 0 but there is no build.ninja at {tree}."
            )

    print(f"Build     {configuration}|x64")
    print()
    code = run_streaming([str(cmake), "--build", str(tree)], env=env)

    if code != 0:
        raise DeployError(f"CMake build failed with exit code {code}. Nothing was installed.")

    print("\nBuild succeeded.")

    if configuration == "Prod":
        copied = stage_prod(slot)
        print(f"Output    {SOLUTION_DIR.joinpath(*FLAVORS['with_aimbot'])}  ({copied} artefacts)")
    else:
        dll = SOLUTION_DIR / "x64" / "Debug" / "TarkovAddons.dll"
        if dll.is_file():
            print(f"DLL       {dll}")
        else:
            warn(f"expected {dll} after a successful build; it is not there")

    print()
    print("To install into the BsgLauncher folder:  python tools/deploy.py install")
    return 0


def stage_prod(slot: str) -> int:
    """Mirror the Prod build tree into the deploy folder; return how many files.

    copy_out.ps1 closes the gap between where CMake puts the artefacts (the
    build tree) and where install reads them from (TarkovAddons\\out\\prod\\
    with_aimbot). It is called rather than reimplemented so the artefact list
    lives in one place -- and its count is checked, because "copied 0
    artefacts" and success look identical from an exit code alone: install
    would quietly keep deploying the previous build.
    """
    script = Path(__file__).resolve().parent / "copy_out.ps1"

    lines: list[str] = []
    code = run_streaming(
        [
            "powershell",
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-File", str(script),
            "-Slot", slot,
        ],
        lines=lines,
    )
    if code != 0:
        raise DeployError(
            f"staging failed with exit code {code}; the deploy folder was not updated."
        )

    copied = None
    for line in lines:
        match = re.search(r"copied (\d+) artefact", line)
        if match:
            copied = int(match.group(1))
    if copied is None:
        raise DeployError(
            "staging did not say how many artefacts it copied; "
            "the deploy folder's contents cannot be vouched for."
        )
    if copied < len(DEPLOY_DLLS):
        raise DeployError(
            f"staging copied {copied} of the {len(DEPLOY_DLLS)} DLLs the deploy "
            "folder needs; install would deploy an incomplete build. "
            "Rebuild with --rebuild if the build tree is stale."
        )
    return copied


def build_with_msbuild(configuration: str, options: dict) -> int:
    """Locate the toolchain, check it can build this solution, then build.

    Takes no fallback reason: the swap, if any, was announced where it was
    decided (cmd_build). Carrying it here as well would mean two places can
    print it, and the second one would be skipped by anything that mocked or
    reordered the first.
    """
    msbuild = find_msbuild(options.get("msbuild"))

    print(f"MSBuild   {msbuild}")

    if has_required_toolset(msbuild):
        print(f"Toolset   {REQUIRED_TOOLSET}")
    else:
        warn(
            f"MSVC toolset {REQUIRED_TOOLSET} not found under {msbuild.parent.parent}.\n"
            "All four configurations pin <PlatformToolset>v145</PlatformToolset> with\n"
            f"no fallback, so the build is about to fail with MSB8020. Add the\n"
            f"\"{CXX_WORKLOAD}\" workload through the Visual Studio Installer:\n"
            f"    {MSBUILD_DOWNLOAD}"
        )

    solution = SOLUTION_DIR / "TarkovAddons.sln"
    if not solution.is_file():
        raise DeployError(f"solution not found: {solution}")

    target = "Rebuild" if options.get("rebuild") else "Build"
    command = [
        str(msbuild),
        str(solution),
        f"/p:Configuration={configuration}",
        "/p:Platform=x64",
        f"/t:{target}",
        "/m",           # parallel
        "/v:minimal",
        "/nologo",
    ]

    print(f"Build     {configuration}|x64 /t:{target}")
    print()
    code = run_streaming(command)

    if code != 0:
        raise DeployError(f"MSBuild failed with exit code {code}. Nothing was installed.")

    # MSB8012 (TargetPath vs Link.OutputFile) is expected once per project here
    # and is benign: the project deliberately redirects output to out\<flavor>\.
    # It is not a compiler warning, so it does not appear in a 0-warning count.
    print("\nBuild succeeded.")

    flavor = options.get("flavor")
    if flavor is None:
        flavor = CONFIG_FLAVOR.get(configuration)
    if flavor:
        print(f"Output    {SOLUTION_DIR.joinpath(*FLAVORS[flavor])}")

    print()
    print("To install into the BsgLauncher folder:  python tools/deploy.py install")
    return 0


def cmd_install(options: dict) -> int:
    """Copy a build tree into the BsgLauncher folder."""
    flavor = options.get("flavor") or "with_aimbot"
    if flavor not in FLAVORS:
        raise DeployError(f"unknown flavor {flavor!r}; expected one of {', '.join(FLAVORS)}")

    if options.get("source"):
        source = Path(options["source"]).expanduser().resolve()
    else:
        source = SOLUTION_DIR.joinpath(*FLAVORS[flavor])

    if not source.is_dir():
        raise DeployError(
            f"build output not found: {source}\n\n"
            "Build it first:\n"
            "    python tools/deploy.py build\n"
            "or, for a different flavor:\n"
            "    python tools/deploy.py build --config 'Prod no aimbot'"
        )

    items = deploy_items(source)
    missing = [show(parts) for parts, kind in items if kind == "dll"
               and not source.joinpath(*parts).is_file()]
    if missing:
        raise DeployError(
            f"{source} is not a complete build: missing {', '.join(missing)}\n\n"
            "All three DLLs are needed. The launcher loads vk_swiftshader.dll first,\n"
            "then TarkovLauncherBypass.dll, then TarkovAddons.dll, so a partial copy\n"
            "produces a chain that breaks silently. Build the whole solution rather\n"
            "than one project:\n"
            "    python tools/deploy.py build"
        )

    target = find_bsg_launcher(options.get("path"), options.get("drives", DRIVE_LETTERS))

    print(f"Install  {source}")
    print(f"     ->  {target}")

    up = running_processes()
    if up:
        warn(
            f"still running: {', '.join(up)}. Files loaded by those processes cannot be\n"
            "replaced. Close the game and the Battlestate client, then re-run, or pass\n"
            "--force to try anyway."
        )

    present = [(parts, kind) for parts, kind in items if source.joinpath(*parts).is_file()]

    # Check every destination before copying any of them, so a locked DLL cannot
    # leave a half-updated folder behind. A file that is not there yet cannot be
    # locked, so only existing destinations matter.
    locked_names = [show(parts) for parts, _ in present if locked(target_of(target, parts))]
    if locked_names and not options.get("force"):
        raise DeployError(
            f"cannot replace, in use: {', '.join(locked_names)}\n\n"
            "A loaded DLL cannot be overwritten. Close Escape from Tarkov and the\n"
            "Battlestate client, then re-run. To attempt the copy anyway:\n"
            "    python tools/deploy.py install --force"
        )

    by_kind: dict[str, list[tuple[str, ...]]] = {}
    for parts, kind in present:
        by_kind.setdefault(kind, []).append(parts)
    existing = sum(1 for parts, _ in present if target_of(target, parts).is_file())

    # Profile directories this build does not ship but an earlier install may
    # have left in the target. Only subdirectories are considered: uninstall
    # treats the whole of ta\compatibility\profiles\ as ours, but a stray file
    # at the top level is not ours to judge.
    shipped_profiles = {
        parts[len(MANIFEST_DIR)]
        for parts, kind in present
        if kind == "manifest" and len(parts) == len(MANIFEST_DIR) + 2
    }
    stale_profiles: list[str] = []
    if shipped_profiles:
        try:
            stale_profiles = sorted(
                child.name
                for child in target_of(target, MANIFEST_DIR).iterdir()
                if child.is_dir() and child.name not in shipped_profiles
            )
        except OSError:
            stale_profiles = []

    summary = [
        f"About to install into {target}",
        f"               from {source}",
        "",
        f"  {len(by_kind.get('dll', []))} DLLs          {', '.join(show(p) for p in by_kind.get('dll', []))}",
        f"  {len(by_kind.get('symbol', []))} symbol files   .pdb/.map, so a crash can be read on this machine",
        f"  {len(by_kind.get('data', []))} data files     under ta\\ (launcher.cfg, offsets.cfg, patterns.cfg, background)",
        f"  {len(by_kind.get('manifest', []))} IL2CPP manifest(s) under {show(MANIFEST_DIR)}\\",
    ]
    if stale_profiles:
        summary.append(
            f"  stale profile(s) removed: {', '.join(stale_profiles)}"
        )
    summary += [
        "",
        f"  {existing} of these already exist and will be overwritten.",
        "  Your settings, minimap assets, price cache and logs are not touched by",
        "  the copy. If any pre-3.2 data is found afterwards it is reported and",
        "  imported only if you agree.",
    ]
    if not confirm(summary, options["yes"], options["dry_run"],
                   "Re-run with --yes to install without prompting."):
        return 0

    copied = failed = 0
    for parts, _ in present:
        destination = target_of(target, parts)
        if options["dry_run"]:
            print(f"What if: write {destination}")
            continue
        try:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source.joinpath(*parts), destination)
            copied += 1
        except OSError as error:
            warn(f"{show(parts)}: {error}")
            failed += 1

    # Remove profile directories the build no longer ships (see the comment at
    # MANIFEST_DIR), after the copy, so a failed copy never leaves the target
    # without any profile at all.
    if options["dry_run"]:
        for name in stale_profiles:
            print(f"What if: remove {target_of(target, MANIFEST_DIR + (name,))}")
    else:
        removed_profiles = []
        for name in stale_profiles:
            try:
                shutil.rmtree(target_of(target, MANIFEST_DIR + (name,)))
                removed_profiles.append(name)
            except OSError as error:
                warn(f"could not remove stale profile "
                     f"{show(MANIFEST_DIR + (name,))}: {error}")
        if removed_profiles:
            print(f"  stale profiles removed: {', '.join(removed_profiles)}")

    # Archive this build's symbols under its own timestamp. Failure here is a warning,
    # not an install failure: the DLL and its data are already in place, and losing the
    # archive costs a future crash its name, not the user their mod.
    if not options["dry_run"] and by_kind.get("symbol"):
        try:
            kept = archive_symbols(target, source)
            print(f"  symbols archived: {kept} build(s) under "
                  f"{SYMBOL_ARCHIVE_DIR}\\\\ (newest first)")
        except OSError as error:
            warn(f"could not archive symbols: {error}")

    print()
    if options["dry_run"]:
        print(f"WhatIf: {len(present)} file(s) would be written to {target}. Nothing was installed.")
        return 0

    print(f"Copied {copied} file(s) to {target}")
    if by_kind.get("manifest"):
        print(f"  IL2CPP manifests: {len(by_kind['manifest'])} profile(s)")

    # The pre-3.2 import, AFTER the copy rather than before it.
    #
    # Ordering is load-bearing, not stylistic: step 5 rescues a config that a 3.2
    # install left directly in ta\, so ta\ has to exist. It may only just have been
    # created by the copy above. Surveying before the copy would report a different
    # plan from the one that gets applied.
    #
    # This used to run inside the DLL on every process start, silently, including an
    # irreversible delete. See migrate_legacy.py for why it moved.
    offer_legacy_import(target, options)

    absent = [show(parts) for parts, _ in items if not source.joinpath(*parts).is_file()]
    for name in absent:
        print(f"  not in this build: {name}")

    if failed:
        raise DeployError(f"{failed} file(s) could not be copied. The folder is now inconsistent; fix the cause above and re-run.")

    print("\nLaunch through BsgLauncher.exe. Starting EscapeFromTarkov.exe directly will not load the DLL.")
    return 0


def legacy_profile_dir() -> Path | None:
    """The pre-3.2 profile folder, i.e. what `%APPDATA%\\TarkovAddons` was.

    Read from os.environ rather than the Win32 block deliberately: this is a tool a
    person runs, not code injected into the game, and the whole reason the C++ version
    of this migration was hazardous is that IT read the ambient value and then
    mutated real files. Here the read is harmless because survey() only reads and
    apply() is behind a prompt. Returns None rather than a path if it is unset or
    does not exist, which is the normal case on a machine that never had a pre-3.2
    install.
    """
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    candidate = Path(appdata) / "TarkovAddons"
    return candidate if candidate.is_dir() else None


def offer_legacy_import(target: Path, options: dict) -> None:
    """Report any pre-3.2 data, and import it if that is agreed.

    Silent when there is nothing to do, which is almost always. The C++ version
    printed one `migrate:` line into a log nobody opens and deleted a file with no
    prompt at all; both of those are the reason this exists as a visible step.
    """
    legacy = legacy_profile_dir()
    plan = migrate_legacy.survey(legacy, target)
    if not plan:
        return

    print()
    print("Pre-3.2 data found")
    print("=" * 70)
    for line in migrate_legacy.survey(legacy, target).describe():
        print(f"  {line}")
    print()
    print("  The mod reads the old locations too, so nothing is lost by leaving this")
    print("  alone -- importing only tidies it up. The one irreversible item is the")
    print("  DELETED line above: that is a stale chams bundle, and the live copy is")
    print("  embedded in the DLL.")

    if not confirm(
        ["About to import the files listed above."],
        options["yes"], options["dry_run"],
        "Re-run with --yes to import without prompting.",
    ):
        print("  Left the pre-3.2 data where it is. The mod still reads it.")
        return

    result = migrate_legacy.apply(plan, dry_run=options["dry_run"])
    if options["dry_run"]:
        print()
        print("WhatIf: nothing was imported.")
        return
    print()
    if result.ok():
        print(f"Imported {len(result.moved)} file(s), removed {len(result.deleted)} debris item(s).")
    else:
        # Partial success is reported, not rounded up to success. Every failure
        # above left the source in place, so this is untidy rather than broken.
        warn(f"{len(result.failed)} item(s) did not import; each was left in place:")
        for path, why in result.failed:
            print(f"    {path.name}: {why}")


def cmd_uninstall(options: dict) -> int:
    """Remove what install put there, and nothing else.

    Works from a fixed list of names rather than reading out\\, so uninstalling
    still works after a clean, a fresh clone, or on a machine that never had
    this project. Someone who does not rebuild must still be able to uninstall.
    """
    target = find_bsg_launcher(
        options.get("path"), options.get("drives", DRIVE_LETTERS), required=False
    )

    if target is None:
        # Nothing installed anywhere is a successful no-op, not a failure.
        # find_bsg_launcher still raises for an explicit --path that does not
        # exist, so a typo here is not mistaken for an absence.
        print("No BsgLauncher folder found on the drives searched, so there is nothing to uninstall.")
        return 0

    print(f"Uninstall  {target}")

    up = running_processes()
    if up:
        warn(
            f"still running: {', '.join(up)}. Files loaded by those processes cannot be\n"
            "removed. Close the game and the Battlestate client, then re-run, or pass\n"
            "--force to try anyway."
        )

    purge = options.get("purge")
    files = [((name,), "dll") for name in DEPLOY_DLLS]
    for pattern in SYMBOL_GLOBS:
        for hit in sorted(target.glob(pattern)):
            if hit.is_file():
                files.append(((hit.name,), "symbol"))
    files += [ (("ta", name), "data") for name in DATA_FILES ]
    if purge:
        files += [((name,), "log") for name in LOG_FILES]
        files += [(parts, "runtime") for parts in RUNTIME_DATA_FILES]

    # Directories we own outright, removed whole rather than file by file. Every
    # file under ta\compatibility\profiles\ comes from this repository's
    # compatibility/profiles\ via the vcxproj Content item, so there is nothing in
    # there that is the user's.
    #
    # symbols\ is ours but NOT removed here, on purpose. It is the only thing that can
    # name a crash that happened against an older build (see archive_symbols): a plain
    # uninstall removes the DLL, so there is nothing left to crash, but a user who
    # reports a crash from LAST week needs that week's symbols and this is the only
    # copy. It is bounded at SYMBOL_ARCHIVE_STAMPS builds, so it cannot grow forever.
    # --purge removes it, for someone who wants the folder genuinely empty.
    directories = [MANIFEST_DIR]
    if purge:
        directories += [("ta", "configs"), ("ta", "maps"), (SYMBOL_ARCHIVE_DIR,)]

    existing_files = [parts for parts, _ in files if target_of(target, parts).is_file()]
    existing_dirs = [parts for parts in directories if target_of(target, parts).is_dir()]

    if not existing_files and not existing_dirs:
        print("\nNothing to remove: that folder does not contain a TarkovAddons Reloaded install.")
        return 0

    locked_names = [show(parts) for parts in existing_files if locked(target_of(target, parts))]
    if locked_names and not options.get("force"):
        raise DeployError(
            f"cannot delete, in use: {', '.join(locked_names)}\n\n"
            "A loaded DLL cannot be removed while the launcher or game holds it. Close\n"
            "Escape from Tarkov and the Battlestate client, then re-run. To attempt\n"
            "the delete anyway:\n"
            "    python tools/deploy.py uninstall --force"
        )

    summary = [
        f"About to remove TarkovAddons Reloaded from {target}",
        "",
        f"  {len(existing_files)} file(s):",
        f"      {', '.join(show(parts) for parts in existing_files)}",
    ]
    if existing_dirs:
        summary += [
            f"  {len(existing_dirs)} directory(ies), recursively:",
            f"      {', '.join(show(parts) for parts in existing_dirs)}",
        ]
    summary.append("")
    if purge:
        # Called out separately and last, because this is the irreversible part.
        summary += [
            "  --purge ALSO DELETES, and this cannot be undone:",
            "      ta\\configs\\        your settings",
            "      ta\\maps\\           minimap assets unpacked at first run",
            "      ta\\tarkov_prices.json the item price cache",
            "      tarkovaddons_log.txt, tarkovaddons_launcher_log.txt",
        ]
    else:
        summary.append(
            "  Your settings, minimap assets, price cache and logs are KEPT. "
            "Add --purge to delete those too."
        )

    summary.append("  Anything else in that folder is left alone.")

    if not confirm(summary, options["yes"], options["dry_run"],
                   "Re-run with --yes to uninstall without prompting."):
        return 0

    removed = removed_dirs = failed = 0
    for parts in existing_files:
        path = target_of(target, parts)
        if options["dry_run"]:
            print(f"What if: remove {path}")
            continue
        try:
            path.unlink()
            removed += 1
        except OSError as error:
            warn(f"{show(parts)}: {error}")
            failed += 1

    for parts in existing_dirs:
        path = target_of(target, parts)
        if options["dry_run"]:
            print(f"What if: remove {path} (recursive)")
            continue
        try:
            shutil.rmtree(path)
            removed_dirs += 1
        except OSError as error:
            warn(f"{show(parts)}: {error}")
            failed += 1

    # Take away ta\ and its parents only if nothing of the user's is left in
    # them. Runs on both paths and needs no --purge special case: without it the
    # user's ta\configs\ is still there, so ta\ tests as non-empty and is kept.
    # With --purge that data is already gone and the same walk clears the rest.
    #
    # ta\configs\ and ta\maps\ are deliberately absent from this list: they are
    # the user's, and an empty one is still theirs to keep.
    for parts in (MANIFEST_DIR, ("ta", "compatibility"), ("ta",)):
        path = target_of(target, parts)
        if not path.is_dir():
            continue
        if any(path.iterdir()):
            print(f"  Kept {show(parts)}\\ - it still holds your data.")
            continue
        if options["dry_run"]:
            print(f"What if: remove empty {path}")
            continue
        try:
            path.rmdir()
            removed_dirs += 1
        except OSError:
            pass

    # symbols\, under --purge only. The empty-directory walk above will not touch it
    # (it is not in that tuple, and it is never empty by design), so removing it is
    # explicit here.
    #
    # A plain uninstall deliberately leaves it: it is the only thing that can name a
    # crash that happened against an older build, and a user reporting last week's
    # crash needs last week's symbols. --purge is "leave nothing of ours behind", and
    # silently keeping ~44 MB per build there would be that command not doing its job.
    if purge:
        archive = target / SYMBOL_ARCHIVE_DIR
        if archive.is_dir():
            if options["dry_run"]:
                print(f"What if: remove {archive} and everything under it")
            else:
                try:
                    for f in sorted(archive.rglob("*"), reverse=True):
                        f.rmdir() if f.is_dir() else f.unlink()
                    archive.rmdir()
                    removed_dirs += 1
                    print(f"Removed {SYMBOL_ARCHIVE_DIR}\\ and its archived symbols.")
                except OSError as error:
                    warn(f"could not remove {SYMBOL_ARCHIVE_DIR}\\: {error}")

    print()
    if options["dry_run"]:
        print(f"WhatIf: {len(existing_files) + len(existing_dirs)} item(s) would be removed from {target}. Nothing was removed.")
        return 0

    print(f"Removed {removed} file(s) and {removed_dirs} directory(ies) from {target}")
    if not purge:
        print("Settings, minimap assets, price cache and logs were left in place. Use --purge to remove those too.")
    print("\nUninstalled. The Battlestate client files in that folder were not touched.")

    if failed:
        raise DeployError(f"{failed} item(s) could not be removed; see the warnings above.")
    return 0


# ---------------------------------------------------------------------------
#  Entry point
# ---------------------------------------------------------------------------

USAGE = """usage: python tools/deploy.py <command> [options]

  build      build the solution (CMake by default; MSBuild for what it cannot)
  install    copy a build tree into the BsgLauncher folder
  uninstall  remove it again

build options:
  --config NAME     Debug | Release | Prod | Prod no aimbot   (default Prod)
  --rebuild         clean rebuild instead of an incremental build
  --backend NAME    cmake | msbuild        (default: cmake for Debug and Prod,
                    msbuild for the other two, which CMake does not build)
  --msbuild PATH    build with this MSBuild.exe instead of searching for one

CMake builds Debug and Prod (CMAKE_CONFIGURATION_TYPES in CMakeLists.txt) and
stages the Prod output into TarkovAddons\\out\\prod\\with_aimbot, which is
where install reads from. It needs cmake.exe and a Visual Studio vcvars64.bat;
both are searched for the same way MSBuild is. $env:SLOT selects the build tree
under build\\<config>\\x64\\, defaulting to opencode.

install options:
  --flavor NAME     with_aimbot | no_aimbot          (default with_aimbot)
  --path DIR        BsgLauncher folder; skips the drive search
  --source DIR      build tree to install from, instead of --flavor
  --drives CDEF     drives to search                 (default CDEF)

uninstall options:
  --path DIR        BsgLauncher folder; skips the drive search
  --purge           also delete settings, caches and logs
  --drives CDEF     drives to search                 (default CDEF)

both:
  --dry-run         list every file that would change, and change nothing
  --yes             do not prompt
  --force           overwrite read-only files, and try past a file in use

install and uninstall ask before they write, because deploying over a live
install and deleting a user's settings are both things nobody expects to happen
because a flag was left alone. --yes skips that; so does --dry-run, which cannot
do harm. With no terminal to ask on and neither flag, both stop and say so.
"""

COMMANDS = {"build": cmd_build, "install": cmd_install, "uninstall": cmd_uninstall}

# Which flags take a value, and which are simple switches. Kept explicit rather
# than inferred so an unknown flag is an error instead of a silently ignored
# argument that then deploys the wrong thing.
VALUE_FLAGS = {
    "--config", "--backend", "--msbuild", "--flavor", "--path", "--source", "--drives",
}
SWITCH_FLAGS = {
    "--rebuild", "--purge", "--dry-run", "--yes", "--force",
}

DEFAULTS = {
    "config": "Prod",
    "backend": None,
    "flavor": None,
    "msbuild": None,
    "path": None,
    "source": None,
    "drives": DRIVE_LETTERS,
    "rebuild": False,
    "purge": False,
    "dry_run": False,
    "yes": False,
    "force": False,
}

# Options each command understands, so `uninstall --rebuild` is an error rather
# than a rebuild that was never going to happen.
ALLOWED = {
    "build": {"config", "rebuild", "backend", "msbuild", "flavor"},
    "install": {"flavor", "path", "source", "drives", "dry_run", "yes", "force"},
    "uninstall": {"path", "purge", "drives", "dry_run", "yes", "force"},
}


def parse_args(argv: list[str]) -> tuple[str | None, dict, str | None]:
    """Return (command, options, error). Minimal on purpose."""
    if not argv or argv[0] in ("-h", "--help", "help"):
        return None, {}, None

    command = argv[0]
    if command not in COMMANDS:
        return None, {}, f"unknown command {command!r}; expected one of {', '.join(COMMANDS)}"

    options = dict(DEFAULTS)
    index = 1
    while index < len(argv):
        flag = argv[index]
        # Flags are spelled with hyphens and stored with underscores, so
        # --dry-run has to land on the "dry_run" key the rest of the code reads.
        name = flag.lstrip("-").replace("-", "_")
        if flag in VALUE_FLAGS:
            if index + 1 >= len(argv):
                return None, {}, f"{flag} needs a value"
            options[name] = argv[index + 1]
            index += 2
        elif flag in SWITCH_FLAGS:
            options[name] = True
            index += 1
        else:
            return None, {}, f"unknown option {flag!r}"

    # Only a flag actually given counts as given, so a default that happens to
    # match another command's flag is not mistaken for one that was passed.
    unknown = {name for name, value in options.items() if value != DEFAULTS[name]}
    unknown -= ALLOWED[command]
    if unknown:
        return None, {}, f"{command} does not take --{sorted(unknown)[0]}"

    if command == "build" and options["config"] not in CONFIGURATIONS:
        return None, {}, (
            f"unknown --config {options['config']!r}; expected one of "
            f"{', '.join(CONFIGURATIONS)}"
        )

    if command == "build" and options["backend"] not in (None, "cmake", "msbuild"):
        return None, {}, (
            f"unknown --backend {options['backend']!r}; expected cmake or msbuild"
        )

    # Flavor is checked here rather than where it is used, so a typo is a
    # one-line error immediately instead of a traceback after a two-minute build
    # that has already happened.
    flavor = options.get("flavor")
    if flavor is not None:
        if flavor not in FLAVORS:
            return None, {}, (
                f"unknown --flavor {flavor!r}; expected one of {', '.join(FLAVORS)}"
            )

        if command == "build":
            # --config decides what is actually built, so a --flavor that
            # disagrees describes a deployment that cannot happen.
            implied = CONFIG_FLAVOR.get(options["config"])
            if implied and implied != flavor:
                return None, {}, (
                    f"--flavor {flavor} does not match --config {options['config']}, "
                    f"which builds to {implied}. Set only one of them."
                )

    return command, options, None


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)

    # --gui is handled before the subcommand parser because it is a front-end,
    # not a command. Imported here rather than at module scope so the headless
    # path never touches tkinter: this file has to keep working on a machine
    # with no display, which is the whole point of having flags at all.
    if argv and argv[0] == "--gui":
        from tools import deploy_gui

        return deploy_gui.main()

    try:
        command, options, error = parse_args(argv)
        if error:
            raise DeployError(f"{error}\n\n{USAGE}")
        if command is None:
            print(USAGE)
            return 0
        return COMMANDS[command](options)
    except DeployError as failure:
        return die(str(failure))
    except KeyboardInterrupt:
        print()
        return die("interrupted")


if __name__ == "__main__":
    sys.exit(main())
