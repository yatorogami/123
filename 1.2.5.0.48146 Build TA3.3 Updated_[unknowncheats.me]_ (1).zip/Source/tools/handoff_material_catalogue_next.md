# Handoff: run the Material catalogue probe, then decide what ChamsModule does with it

> **2026-10-13 18:31 — STEP 2 HAS RUN. The verdict is `OK` (0).** Recorded here
> because it is the measurement this whole handoff was waiting for, taken from
> the shipped log of pid 20612 (build `0x6ACE4D48`, entered a raid at ~18:31):
>
>     material-catalog: OK rows=2597 alive=2597 dead=0 unnamed=1 distinct_names=2179
>       sampled=40 cap_skipped=2139 elapsed_ms=1016
>       needles[emissive=8 chameleon=0 manpad=0 Hidden/=119 Glow_Red=0]
>     material-catalog: first 40 distinct names, sorted: CW FX/CollimatorDLSS,
>       City_leakage_decal_yellow_projector, Custom/GradingPostFX, Graffiti6_*
>       ..., Hidden/BlitCopyDepth, Hidden/ScopeMask, Hidden/OpticCullingMask,
>       Hidden/NightVision, MuzzleFlashTest, usec_GarminTactix (Instance), ...
>
> Reading it against this handoff's own step 3: **(1) yes, the names are real
> material names** — genuine Unity/EFT asset names, including
> `Hidden/OpticCullingMask` and `Hidden/ScopeMask`, which are the
> optic-adjacent ones; **(2) 2,597 rows / 2,179 distinct names** answers the
> "is it 12 entries or 400,000" question — a catalogue in the thousands, so the
> searchable-combo UI cost in step 4 is real, and `SelectValue` remains the
> wrong widget; **(3) `elapsed_ms=1016` is the finding that changes the plan** —
> the handoff says "if it is hundreds of ms it is a visible hitch on the game
> thread and must move to a slow clock", and 1,016 ms on one `gameworld_update`
> is that. It fired once, as designed, and this raid appears to have survived
> it, but no future version may run it per-frame or at the container-chams
> 2 s ramp cadence until the cost is broken down (the liveness `VirtualQuery`
> per entry is the obvious suspect, and `dead=0` says the check is cheap per
> *hit*, which points at the 2,597-entry sweep itself). **Coverage is still
> unmeasured** — whether native-only materials without a managed wrapper are
> missing from these 2,597 is exactly what a native type-manager walk would
> answer, and this route says nothing about it.

> **2026-10-13 — the freeze referenced in step 5 is lifted.** The
> `[CLEANUP-PENDING:OPTICS]` markers were removed this day at the user's
> instruction; `unity.h` is ordinary first-party code again, and the coupling
> warning below (do not call `managed_instance_id()` from a frozen file) no
> longer describes a live constraint — though the prototype was written the way
> it was for good reason and should not be re-pointed at
> `optics_lens_pipeline.h` just because it may now be edited. Everything else in
> this handoff stands unchanged; **the probe's first real outcome is still the
> gate**, and as of tonight a build containing it is deployed and the game is
> running with no raid entered yet, so `material-catalog:` has not been logged.

> **STATUS: OPEN. The code is written; the number does not exist yet.**
>
> For whoever picks this up on a Windows box with the game. Written 2026-10-13.
> Commits: `5c2563221` (assessment + handoff notes), `4621ba28f` (the prototype).
>
> **The prototype has never been built by MSVC and has never run in game.** By
> this repository's own definition in `AGENTS.md`, nothing about it is verified
> yet. Your first job is the build; your second is one raid and one log.

## What exists

`TarkovAddons/module/material_catalogue.h` — once per process, called from
`ChamsModule::gameworld_update` at `ChamsModule.cpp:1414`, immediately after the
Unity image is resolved and before any paint state is touched.

It answers one question: **can this process enumerate live `UnityEngine.Material`
objects by name, through the managed ABI, with no hardcoded RVAs?**

Two lines in the log:

    material-catalog: OK rows=N alive=N dead=N unnamed=N distinct_names=N sampled=N cap_skipped=N elapsed_ms=N needles[...]
    material-catalog: first 40 distinct names, sorted: ...

The verdict is tri-state on the same convention as `audit_config_pointers.py` and
`tools/verify/audit.py`:

| verdict | meaning |
|---|---|
| **0 `OK`** | resolved, and returned usable names |
| **1 `FAILED`** | ran, and the answer is no |
| **2 `INDETERMINATE`** | **could not check anything.** Deliberately not 0 |

## Step 1 — the build this commit is still owed

The commit message says NOT build-verified and that is not a formality. Only a
mingw+clang `-fsyntax-only` parse has run (`tools/analysis_tree.py`, 58 of 80
TUs — the documented baseline). Per `AGENTS.md`, **"verified" means a full
`Prod|x64` build and link, exit 0, 0 errors, 0 warnings.**

This change touches `TarkovAddons` only — no Bypass, no swiftshader — so
`tools\build.ps1` covers it and you do **not** need the solution build. (That
trap is called out in `AGENTS.md`: `build.ps1` compiles only
`TarkovAddons.vcxproj` and will cheerfully report `FRESH` for a change it never
saw. Not this one.)

**Other agents share this tree and this branch.** Before you build:

- `edit → verify what needs no compiler → commit → build`. A commit made before
  the build is not build-verified and its message must not imply otherwise; if
  the build then fails, the fix is a **new** commit.
- Do not amend, rebase, reset, or `git checkout --` anything. Do not `git add -A`.
- If other agents are active, use `tools\build.ps1 -Slot <name>` (private
  `IntDir` per slot) rather than raw MSBuild, and set `$env:SLOT` so you do not
  share an `IntDir`. First use of a slot is a full rebuild; that is expected.

```powershell
python tools\deploy.py build          # CMake (Ninja), Prod|x64 default
python tools\deploy.py install
# launch C:\Battlestate Games\BsgLauncher\BsgLauncher.exe
```

Launch through `BsgLauncher.exe`. Starting `EscapeFromTarkov.exe` directly does
not load the DLL — no log, no mod, looks like a clean launch.

## Step 2 — one raid, then read the log file

Quote the log **file**, never the console copy:

    C:\Battlestate Games\BsgLauncher\tarkovaddons_log.txt

It is flushed per line, so a crash leaves the last statement on disk. **Copy it
aside before relaunching** — it gets truncated by hand and it is the only
artefact that reliably survives. More than one process writes it by design: group
by `pid=` first, then order by time; `tid` alone is recycled.

Enter a raid. The probe fires on the first `gameworld_update` after that, so it
will not appear at all if you only sit in the menu. Then:

```powershell
Select-String -Path <your copy> 'material-catalog'
```

## Step 3 — what each outcome means, and what to do about it

### `INDETERMINATE` (2) — the most likely first outcome, and it is not a failure of the checker

Read the `get_method` / `resolve_class` warning lines printed *above* the verdict;
they name which gate failed. The three gates:

1. `UnityEngine.Material` did not resolve to a `System.Type`
2. `UnityEngine.Resources` did not resolve
3. `FindObjectsOfTypeAll` resolved but returned null

**Do not "fix" a 2 by switching the class to `ResourcesAPI`.** That class exists
in the dump with an identical static signature, but it is not the one the game
calls — it is the exact trap the header comment documents, and switching to it
converts a loud indeterminate into a silent empty array.

Note also that the parse check **cannot** catch a wrong method *name* or wrong
*class*; both are runtime failures through `get_method`. That is why the verdict
is a log line and not a compile-time assertion.

### `FAILED` (1) — three genuinely different problems, and the log separates them

Read which count collapsed; they mean different things:

| what collapsed | what it probably means | what to do |
|---|---|---|
| `rows=0` | nothing loaded **yet**, or the wrong class | the probe fires at first in-raid entry, which may simply be too early for materials to exist. Re-probe on a clock instead of once — see the cadence note in Step 4. |
| `rows>0 alive=0` | every wrapper failed the native-liveness check | this is `unity::is_unity_object_alive` (`unity.h:1151-1160`), **not** the enumeration. Suspect the memo/VirtualQuery path, not `FindObjectsOfTypeAll`. |
| `alive>0 distinct_names=0` | names came back empty | `unity::get_name` is bound once against `UnityEngine.Object` (`unity.h:743-745`), so this would mean `Object.get_name` is not reaching a `Material`. |

`rows` above 500,000 is also `FAILED` — that is the wrong-shape signal.

### `OK` (0) — now the interesting question

Before building anything on it, check three things the log gives you:

1. **Are the names real material names?** Read the sorted sample. If they look
   like EFT/Unity asset names, the managed route works. This is the one question
   the sketch could not answer and it is the whole point of the exercise.
2. **Coverage.** `Resources.FindObjectsOfTypeAll` sees loaded objects; whether it
   sees materials that exist only on the native side and never got a managed
   wrapper is **unmeasured**. If it does not, this route returns a strict subset
   of what a native type-manager walk would, and that subset decides whether the
   feature is worth anything.
3. **`elapsed_ms`.** This is `is_unity_object_alive`'s VirtualQuery cost across
   every entry, once. If it is hundreds of ms it is a visible hitch on the game
   thread and must move to a slow clock.

The `needles[...]` counts are **corroboration only, never a gate.** They come
from the unverified third-party dumper's favourite names. A zero on `emissive` is
not a failure — this code does not know the game's material vocabulary, and
guessing at it is the error the dumper made.

## Step 4 — if it works, what "improve ChamsModule" actually means

You said "improve Chams module, I guess?" — here is the concrete shape, because
the obvious version of it does not work.

**A game `Material` is not a `Shader`, so this is not a drop-in.**
`ChamsModule::apply_chams_to_material` (`ChamsModule.cpp:252-268`) does
`set_shader` + `SetColor("_Color_Visible")` + `SetColor("_Color_Occluded")` +
`set_mainTexture(nullptr)`. Every one of those is a shader-level operation.
Using a game material means a different operation: swap the whole material into
the slot via `set_material(index, game_material)` against the array
`get_materials()` returns (`:330-350`).

The good news: **save/restore is unaffected.** The pre-paint originals are
captured from `get_sharedMaterials` *before* `get_materials` instantiates
anything (`:288-303`), and `restore_renderer_list` (`:430`) puts those back.
Referencing a shared game material does not mutate it — the hazard the code
avoids at `:352-355` is *mutating* a shared asset, and a swap never does that.

The bad news, and it is the reason this is a **different feature and not a better
one**: three existing controls stop working.

| control | why it dies on a game material |
|---|---|
| visible / occluded colour pickers | `_Color_Visible` / `_Color_Occluded` are properties of *our* bundled shaders. A game material's shader does not declare them, so `SetColor` is a no-op and both pickers go inert. |
| through-wall rendering | depends entirely on the game shader's own `ZTest`. Nothing in this route sets it. |
| `get_shader_name` / bundle-reload recovery | bypassed — no bundle asset is involved, so `asset_bundles`' recovery path and `item_shader_cache_`'s transit eviction do not apply to these entries. |

On through-wall rendering: **nobody has verified what the bundled shaders do.** The
`.shader` sources are not in the tree (`assets/` holds only `asset_bundles.h`,
fonts, maps, `menu_background.rc` and one PNG; the bundle is a prebuilt
18,806-byte blob). The two-colour property naming is *evidence* of a
depth-comparing design, not a measurement of `ZTest`. Do not build a menu that
promises see-through on the back of that inference.

**The real cost is the picker, not the memory read.** A catalogue is hundreds to
thousands of names. `SelectValue` cannot carry that — it renders one dropdown.
The dynamic-option mechanism itself is fine and exercised (`set_options` has
three live callers: `QuestModule.cpp:964`, `QuestResetModule.cpp:52`,
`QuestModule.cpp:737`), but it is the wrong widget at this scale. You need a
searchable combo, and the selection must persist **by name**, because an instance
ID does not survive a restart.

**Cadence.** Mirror the container-discovery clock already in the module — 2 s
during the 30 s ramp, 15 s after (`kContainerChamsRampIntervalMs` /
`kContainerChamsSteadyIntervalMs`, `ChamsModule.h:249-250`). Never per frame, and
never inside the paint path.

### One decision, deliberately left open

**Does choosing a game material REPLACE the bundled chams shader, or is it a
separate mode alongside it?** Replacement is simpler UI and loses the colour
pickers and (possibly) through-wall rendering. A separate mode costs a seventh
select per surface — there are already four surfaces (`chams_type`,
`weapon_chams_type`, `item_chams_type`, `container_chams_type`) — and needs a
"none / bundled shader / game material" tri-state.

This is a product call, not a technical one. Whoever owns the chams menu should
make it before any of it is written, because the option-list shape differs.

## Step 5 — do not touch

- **`[CLEANUP-PENDING:OPTICS]` files**: `optics_lens_pipeline.h`, `unity.h`,
  `esp_text.h`, `skeleton_visibility.h`, `quest_esp.h`, `EspModule.*`. The optics
  rework is live on another machine. That is also why the prototype deliberately
  does **not** call `managed_instance_id()` (`optics_lens_pipeline.h:639-649`)
  even though it is exactly the id read it needs — eight duplicated lines are
  cheaper than a chams feature inheriting churn in a frozen file. Keep it that
  way.
- `tools/verify/ida_manifest.py` is manifest-driven; it will not help with an
  ad-hoc RVA. For the separate `0x1A237F8` question, read
  `tools/handoff_optics_instance_table_rva.md` — and note its cheapest falsifier
  is a log grep, not IDA.

## If you delete the prototype

Remove `material_catalogue.h` and the two lines at `ChamsModule.cpp:1414`. Then
**re-measure** `tools/tests/test_dup_scan.py`: adding the header moved that
test's scale to 186 / 176 files and 416,988 / 416,688 tokens, and its docstring
says so at the point you will be looking. (Superseded 2026-10-14 by
`gui/menu/changed_marker_layout.h`: the current baseline is 187 / 177 files and
419,939 / 419,639 tokens.) Deleting it puts the count back — do not assume,
re-run the tool.

## The honest summary

One unmeasured question is now one line of code away from being answered, and the
code is deliberately built so that the answer cannot be mistaken for a success
that did not happen. Everything past that — the picker, the swap path, the dead
colour pickers, the mode decision — is real work that should not start until the
number exists.

The failure mode to watch for is the one this repository keeps meeting: a probe
that runs, logs an INFO line, and gets read as a working feature. The tri-state
exists to make that reading impossible. If you change the verdict handling, you
are removing the only thing this prototype is for.
