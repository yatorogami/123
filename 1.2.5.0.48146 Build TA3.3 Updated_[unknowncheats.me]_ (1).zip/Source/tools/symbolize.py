#!/usr/bin/env python3
"""Symbolize crash addresses against a Microsoft linker .map file.

Built because the crash probe reports frames as "address +rva" and nothing in the
tree could turn those into names. Every so often a fault finally lands inside this
module, and those are the frames worth reading.

The .map's VA column already carries the preferred image base, so RVA = VA - base;
no section table is needed and the ".text$mn" contribution lines can be ignored.

Usage:
    tools/symbolize.py 0x44E57 0x3C3368 ...            # RVAs
    tools/symbolize.py --base 0x7FFCCD0C0000 0x7FFCCD104E57 ...   # absolute addrs
    tools/symbolize.py --file log.txt                    # pull the probe's frames out

Names come out MSVC-mangled. If undname.exe is on PATH (it ships with VS) each
unique name is piped through it; otherwise the mangled form is printed as-is,
which is still searchable.
"""

import argparse
import re
import subprocess
import sys
from pathlib import Path

# " 0001:0003cb30       ?name@@... 000000018003db30 f i dllmain.obj"
# The name may itself contain spaces, so anchor on the trailing 16-hex-digit VA
# and take everything between the segment:offset and the VA.
# The type column after the VA is not a single letter: it is "f", "f i", "?",
# "Abs", and "<absolute>" for the 0000-segment pseudo-symbols. Requiring exactly
# one alphabetic char silently dropped 26,363 of 43,619 symbols and left three
# crash frames resolving into a gap -- attributing them 0x1107C8 past a
# four-byte function, which reads as a wild pointer but is really a hole in the
# table. \S+ and then drop the absolutes by their zero VA.
SYM = re.compile(
    r"^[ \t]*[0-9A-Fa-f]{4}:[0-9A-Fa-f]{8}[ \t]+"
    r"(?P<name>\S.*?)[ \t]+"
    r"(?P<va>[0-9A-Fa-f]{16})[ \t]+"
    r"\S+",
    re.M,
)

# "crash probe: armed, this module at 0x7FFCCD0C0000 mapped extent 0x9D6000"
BASE_RE = re.compile(r"this module at\s+(0x[0-9A-Fa-f]+)")
# Two shapes, and missing the second is how a whole stack silently vanishes:
#   "... code=0x... at 00007FFCCD1C0B03+0x100B03 frames=7"   (the fault)
#   "...      #9 frame 0 00007FFCCD104E57 +0x44E57"          (the frames -- NO "at")
# The frame lines have no "at", so a single \bat\s pattern finds the fault and none
# of the frames, and the output looks complete.
ADDR_RE = re.compile(r"\bat\s+([0-9A-Fa-f]{16})\s*(?:\+\s*(0x[0-9A-Fa-f]+))?")

# Frame lines come in TWO formats, because the probe changed on 2026-10-03 and
# tarkovaddons_log.txt is append-mode, so any log on disk contains both. Matching
# only one silently drops the other's frames, which is worse than failing: it looks
# like a report with nothing in it.
#
#   old: "#9 frame 0 00007FFCCD104E57 +0x44E57"          (ours only)
#   new: "#9 frame 0 [rsp+0x030] 00007FFC029241CA KERNELBASE.dll+0xC41CA"
#   new: "#9 frame 5 [rsp+0x268] 00007FFBFE79654C d3d11.dll+0x16654C <foreign>"
#
# Groups: (frame_no, slot_offset_or_None, address, module_or_None, module_offset_or_None,
#          ours_flag)
#
# The new format exists because the old one dropped every frame outside our image,
# and on 2026-10-04 07:00:50 that meant ALL TWELVE of them -- the throw site in
# KERNELBASE and a call chain through UnityPlayer and d3d11 -- were invisible. The
# probe now records any mapped image, so this must parse all of them. The ones with
# no module of ours are reported with their module name and offset rather than
# symbolised, because there are no symbols for them here and pretending otherwise
# would invent a name.
FRAME_RE = re.compile(
    r"\bframe\s+(\d+)\s+"
    r"(?:\[rsp\+(0x[0-9A-Fa-f]+)\]\s+)?"
    r"([0-9A-Fa-f]{16})\s+"
    r"(?:([^\s+]+)\+(0x[0-9A-Fa-f]+))?"
)
OURS_RE = re.compile(r"<this module>")
PROBE_LINE = re.compile(r"crash probe:")


def load_symbols(map_path: Path):
    """Return (symbols, image_base). symbols is a list of (rva, name), unsorted."""
    text = map_path.read_text(encoding="latin-1", errors="replace")
    base_m = re.search(r"Preferred load address is ([0-9A-Fa-f]{16})", text)
    if not base_m:
        raise SystemExit(f"{map_path}: no 'Preferred load address' line; not a linker map")
    image_base = int(base_m.group(1), 16)
    out = []
    for m in SYM.finditer(text):
        rva = int(m.group("va"), 16) - image_base
        if rva >= 0:
            out.append((rva, m.group("name").strip()))
    if not out:
        raise SystemExit(f"{map_path}: zero symbols parsed -- wrong file, or parser broke")
    out.sort()
    return out, image_base


def resolve(symbols, rva):
    """Nearest preceding symbol. Linear scan is fine: ~40k symbols, few queries."""
    lo, hi, best = 0, len(symbols) - 1, None
    while lo <= hi:
        mid = (lo + hi) // 2
        if symbols[mid][0] <= rva:
            best = symbols[mid]
            lo = mid + 1
        else:
            hi = mid - 1
    return best


def demangle(names):
    """Pipe unique names through undname.exe if it exists; else leave them alone."""
    exe = None
    for c in (r"C:\Program Files\Microsoft Visual Studio\2022",
              r"C:\Program Files (x86)\Microsoft Visual Studio\2022"):
        for p in Path(c).glob("*/VC/Tools/MSVC/*/bin/Hostx64/x64/undname.exe"):
            exe = p
            break
    if exe is None:
        return {}
    out = {}
    for n in names:
        try:
            r = subprocess.run([str(exe), n], capture_output=True, text=True, timeout=10)
            s = (r.stdout or "").strip()
            if s and s != n:
                out[n] = s
        except Exception:
            pass
    return out


def queries_from_log(path: Path):
    """Pull the fault address and every captured frame out of a crash-probe block.

    Returns (base_or_None, [(kind, rva, note)]).

    A frame is only symbolised against our .map when the probe says it is ours --
    "<this module>", or, in the old format, an explicit "+0x..." RVA. Everything
    else is passed through with its module name and offset in `note`, because a
    frame in KERNELBASE or UnityPlayer has no symbol for us to look up and
    substituting the nearest one from OUR map would be inventing an answer.

    The slot offset is carried into `note` because it is the only signal that
    separates a live return address from residue: on 2026-10-03 22:39:37 two frames
    symbolised to plausible dxhook functions and disassembly showed both had
    already run, and nothing else in the report would have revealed that.

    This is the second bug in this file. The first version treated every 16-hex
    number on a "crash probe:" line as an RVA, so system-dll addresses came back as
    nonsense offsets and the fault address was symbolized as itself. It printed a
    full, confident, wrong table.
    """
    base = None
    out = []
    for line in path.read_text(encoding="latin-1", errors="replace").splitlines():
        if not PROBE_LINE.search(line):
            continue
        m = BASE_RE.search(line)
        if m:
            base = int(m.group(1), 16)
            continue
        f = FRAME_RE.search(line)
        if f:
            slot, module, moff = f.group(2), f.group(4), f.group(5)
            ours = OURS_RE.search(line) is not None
            note_bits = []
            if slot:
                note_bits.append("rsp+%s" % slot)
            if not ours:
                # Not ours: report where it is, symbolise nothing.
                if module:
                    note_bits.append("%s+%s" % (module, moff))
                else:
                    note_bits.append("outside our module")
                out.append(("frame", None, "  (%s)" % " ".join(note_bits)))
                continue
            if not note_bits:
                note_bits = ["ours"]
            out.append(("frame", int(moff, 16), "  (%s)" % " ".join(note_bits)))
            continue
        if "<outside this module>" in line:
            continue
        a = ADDR_RE.search(line)
        if not a:
            continue
        addr = int(a.group(1), 16)
        rva = int(a.group(2), 16) if a.group(2) else None
        note = ""
        if rva is None:
            if base is None:
                note = "  (no module base in this log and no +rva; skipped)"
                continue
            rva = addr - base
            if rva < 0:
                note = "  (address is below the module base; skipped)"
                continue
        kind = "frame" if "frame " in line else "fault"
        out.append((kind, rva, note))
    return base, out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("rvas", nargs="*", help="RVAs or absolute addresses")
    ap.add_argument("--base", help="module base; query addresses are then abs-base")
    ap.add_argument("--map", help="path to .map (default: next to --dll, or out/prod/with_aimbot)")
    ap.add_argument("--dll", help="path to the deployed .dll, to pick the matching .map")
    ap.add_argument("--file", help="a log file; extract the crash probe's frames from it")
    ap.add_argument("--build-stamp", help="PE TimeDateStamp of the build that crashed, "
                                           "e.g. 0x6AC00784. With --archive-dir this "
                                           "picks the matching archived .map by name, "
                                           "which is what makes an old crash "
                                           "symbolizable after out/ has moved on.")
    ap.add_argument("--archive-dir",
                    default=r"C:\Battlestate Games\BsgLauncher\symbols",
                    help="where deploy.py install archives symbols/<stamp>/ (default: %(default)s)")
    args = ap.parse_args()

    if args.build_stamp:
        stamp = args.build_stamp.upper().removeprefix("0X").zfill(8)
        if not args.map:
            hit = Path(args.archive_dir) / stamp / "TarkovAddons.map"
            if not hit.is_file():
                root = Path(args.archive_dir)
                have = sorted(p.name for p in root.iterdir()) if root.is_dir() else []
                raise SystemExit(
                    f"no archived map for build {stamp} at {hit}\n"
                    f"  archived builds: {', '.join(have) or '(none)'}\n"
                    "  deploy.py install archives the .map/.pdb of every build it "
                    "installs; a crash older than the oldest archived build cannot be "
                    "named.")
            args.map = str(hit)
            print(f"build   {stamp} -> {args.map}")

    if args.map:
        map_path = Path(args.map)
    else:
        dll = Path(args.dll) if args.dll else Path(
            r"TarkovAddons\out\prod\with_aimbot\TarkovAddons.dll")
        map_path = dll.with_suffix(".map")
    if not map_path.exists():
        raise SystemExit(f"no map at {map_path}; pass --map or --dll")

    symbols, image_base = load_symbols(map_path)

    base = int(args.base, 16) if args.base else None
    log_base = None

    items = []
    if args.file:
        log_base, from_log = queries_from_log(Path(args.file))
        if base is None:
            base = log_base
        items += from_log
    for tok in args.rvas:
        v = int(tok, 16) if tok.lower().startswith("0x") else int(tok)
        if base is not None and v >= base:
            v -= base
        items.append(("addr", v, ""))

    if not items:
        ap.error("nothing to symbolize: pass RVAs or --file")

    print(f"map     {map_path}")
    print(f"image   base 0x{image_base:X}   {len(symbols):,} symbols"
          + (f"   module base 0x{base:X}" if base else ""))
    span_lo = symbols[0][0]
    span_hi = symbols[-1][0]

    hits = {}
    for kind, rva, note in items:
        if note:
            print(f"\n  [{kind}] {note}")
            continue
        if rva is None:
            # A frame in someone else's image. There is no symbol for it here, and
            # the nearest one from OUR map would be an invention, so it is
            # reported and left alone. Since 2026-10-04 this is most of what a
            # real crash produces: the 07:00:50 throw had twelve frames and not
            # one of them was ours.
            print(f"\n  [{kind}] {note}  (not ours -- no symbols for it here)")
            continue
        if not (span_lo <= rva <= span_hi + 0x100000):
            # A hole, not a function. This is the check whose absence made the
            # parser bug above look like three wild function pointers.
            print(f"\n  [{kind}] rva 0x{rva:X}  OUTSIDE the symbol span "
                  f"0x{span_lo:X}..0x{span_hi:X} -- not in this image, skipped")
            continue
        sym = resolve(symbols, rva)
        if sym is None:
            print(f"\n  [{kind}] rva 0x{rva:X}  (below the first symbol)")
            continue
        off = rva - sym[0]
        hits.setdefault(sym[1], None)
        warn = "   <-- implausible offset, a hole not a function" if off > 0x20000 else ""
        print(f"\n  [{kind}] rva 0x{rva:X}  ->  {sym[1]}  +0x{off:X}{warn}")

    if hits and len(hits) < 200:
        d = demangle(hits.keys())
        if d:
            print("\n=== demangled ===")
            for _, pretty in sorted(d.items(), key=lambda kv: kv[1]):
                print(f"  {pretty}")


if __name__ == "__main__":
    main()
