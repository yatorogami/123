@echo off
setlocal
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul

REM Two arguments arrive here, because configure_cmake.ps1 forwards the whole
REM named-parameter pair:  configure_cmake.bat -Configuration Prod
REM so the configuration is in %1 OR %2, never reliably in %1. The old
REM `if "%1"=="Debug"` therefore never fired and every configure was Prod.
set CONFIG=Prod
if "%~1"=="Debug" set CONFIG=Debug
if "%~2"=="Debug" set CONFIG=Debug
if "%CONFIG%"=="Debug" goto :have_config

:have_config

REM SLOT picks the build tree, defaulting to "opencode". build_cmake.ps1 has
REM always read $env:SLOT for its -Build path, but this file hardcoded
REM "opencode", so a first use of any other slot deleted build\Prod\x64\<slot>
REM and then failed with "Configure failed; no build.ninja at ..." -- while
REM having quietly configured the opencode tree instead. AGENTS.md documents
REM that $env:SLOT selects the build tree "for both" build systems; this makes
REM that true, and it is the whole point of the variable, which is to keep two
REM agents off one IntDir.
REM
REM %SLOT% is expanded before the set on a single line, so this reads the
REM inherited value and only falls back when there is none.
if "%SLOT%"=="" set SLOT=opencode

"C:\Program Files\CMake\bin\cmake.exe" -S "D:\TarkovAddonsReloaded" -B "D:\TarkovAddonsReloaded\build\%CONFIG%\x64\%SLOT%" -G Ninja -DCMAKE_BUILD_TYPE=%CONFIG% -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DCMAKE_SYSTEM_PROCESSOR=AMD64 2>&1
echo EXITCODE=%ERRORLEVEL%
