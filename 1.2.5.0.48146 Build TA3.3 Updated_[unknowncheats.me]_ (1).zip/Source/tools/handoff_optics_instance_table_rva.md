# Handoff: `optics_lens_pipeline.h:565` reads a bare `0x1A237F8` that nobody has ever named

> **2026-10-13 — the "off-limits" premise is gone, but the status is not.** The
> `[CLEANUP-PENDING:OPTICS]` markers were removed this day at the user's
> instruction (the rework finished), so the ownership restriction quoted below
> no longer binds. What still binds is everything else in this file: the literal
> remains guarded-unverified, the dumper remains a non-oracle, and the cheap
> falsifier remains a log grep. **A grep was run tonight on the 2026-10-12 raid
> (pid 11736): zero occurrences of all three `why =` strings, alongside 9
> `optic-route: accepted` and 9 `optic-route: mesh id=<nonzero>` lines — the
> route resolved instance IDs throughout that raid.** One healthy session is not
> proof the literal is right, and per this file's own warning a grep with no
> hit is only evidence if the strings are known to appear when the route fails;
> it is one data point, on one build.

> **STATUS: OPEN, nothing attempted.** The optics rework is live on another
> machine and every file carrying `[CLEANUP-PENDING:OPTICS]` is off-limits to
> anyone else (`AGENTS.md`, "Do not touch"). This note exists so the lead is not
> lost, and so the next person does not re-derive it from scratch.
>
> Filed 2026-10-13 by the session that assessed
> `eft_material_dumper_[unknowncheats.me]_.cpp`. That file is NOT the fix and
> NOT an oracle — see "The lead, and how little it is worth" below.

## The thing being handed over

`optics_lens_pipeline.h:561-591`, `instance_from_id()`:

    const uintptr_t u = unity_player_base();
    uintptr_t root = 0;
    if (!read_ptr(u + 0x1A237F8, root) || !root) return false;   // <-- the literal
    uintptr_t table = 0;
    if (!read_ptr(root, table) || !table) return false;           // +0x buckets
    uint32_t mask = 0;
    if (!read_u32(root + 8, mask)) return false;                  // +8  mask

`0x1A237F8` is a **bare magic constant** — no symbol, no profile entry, no
comment saying what it is or how it was found. It is the last one on the
optics fragile list, which `Workstream_status_2026-09-24.md:406-409` already
names in prose:

> it still reads raw native field offsets with no class verification behind
> them (+0x60 materials, +0x170/+0x180 material ids, +0xE8 bounds, +0x122
> static batch, **+0x68 instance-id root, +0x1A237F8 type table**). Those are
> the remaining fragile surface, and each is guarded but unverified.

The guards are real and worth keeping: `mask` bounds (`mask < 8 || mask > 1<<27
|| (mask & 7) != 0`), a power-of-two check on `mask/8`, and a 512-byte bounded
probe. So a wrong table degrades to `instance_from_id()` returning false rather
than to a wild read. **Guarded, not verified** is the accurate description and it
is the reason this is still open.

## What is measured about it today

Everything below was read or computed from this tree on 2026-10-13. Nothing is
inferred.

| Fact | Value | Source |
|---|---|---|
| Image size of `UnityPlayer.dll`, build `1.2.0.0.47965` | `0x1C57000` (29,716,480) | `compatibility/profiles/1.2.0.0.47965/manifest.json` |
| Where `0x1A237F8` lands | **inside** the image, at 92.2% depth (`.data` territory) | computed |
| UnityPlayer RVAs the profile tracks | exactly **one**: `be_service_check` = `0x491E60` | `manifest.json` symbols |
| Named symbols anywhere near `0x1A2xxxx` | **none** | same |
| Struct the code assumes at `root` | `{u64 buckets @+0, u32 mask @+8}`, entries stride 24 = `{u32 hash, u32 id, u64 ptr}`, empty marker `0xFFFFFFFF`, probe step +8 up to 512 | `:561-591` |

The "inside the image" row is the **weakest** check available and should not be
mistaken for corroboration: a random offset in `.data` passes it too. It rules
out a grossly wrong build and nothing else.

The route has a second hardcoded constant of the same class at `:1876`
(`lens_native - unity_player_base() == 0x17B1100`), a static self-check written
as a literal. Same fragility, different file location.

## The lead, and how little it is worth

The unknowncheats.me dumper claims two globals in the same module:

    k_rva_type_to_object_set = 0x1A236F8   // "ms_TypeToObjectSet"
    k_rva_type_manager       = 0x1A242C8   // "TypeManager::ms_Instance"

Relative geometry, computed: `0x1A236F8` is **0x100 before** our literal, and
`0x1A242C8` is 0xBD0 (3024 bytes) after the first. All three are inside this
build's image.

Two things follow, and the second is the one that matters:

1. **No contradiction.** The dumper *dereferences* its own slot (reads a pointer
   at `0x1A236F8`, then indexes `base + 32 * (type_id & 0x7FF)`); the project
   dereferences its own. Two adjacent `.data` globals 0x100 apart is unremarkable
   — plausibly two fields of the same owning Unity structure. And the *shapes
   agree*: the dumper's `object_set_t` is `{u64 buckets @0, u32 mask @+8, u32
   count @+0xC, tail[0x10]}` and the project's reader assumes `{+0 buckets, +8
   mask}` at the address it lands on. Two different globals, same family, same
   header layout. That is *weak* corroboration of the shape.
2. **No name for our literal.** The dumper names `0x1A236F8`, which is not the
   address this project reads. Its comment is therefore **not** a candidate
   identification for `0x1A237F8`. Treating it as one would be the exact error
   `Workstream_status_2026-09-24.md:415-434` records four times over in the
   optics log — "a build-specific address where a name lookup belonged",
   "Il2CppClass* passed to a function needing a native type descriptor".

And the claim's own standing is weak: an unknown Unity version, no author, no
verification, and its *sibling* offsets in the same file are demonstrably wrong
for this build (its `material_t` ends at `0xB8` while this tree reads
`material + 0x108`, `optics_lens_pipeline.h:1299`). Do not promote it.

## The cheap falsifier — no IDA required

This is the part worth acting on first, because it needs only a log.

`instance_from_id()` has exactly three call sites (`:1741`, `:1787`, `:1808`),
and both failure paths already write a distinctive `why =` string:

    :1737   why = "mesh GetInstanceID() == 0"
    :1783   why = "no material id"
    :1789   why = "material instance missing"

So **grep the shipped log for those three strings.** If the optics route is
working, they should be rare-to-absent on a healthy raid; a run that produces them
in volume is a run where the instance-ID table is not resolving, and `0x1A237F8`
is the first thing to suspect. This costs one grep and distinguishes "the literal
is fine" from "the literal has silently rotted" — which is the entire question,
and which nobody has answered by measurement.

Run the negative control on the check too: confirm the strings actually appear
when the route fails, by looking at a log where optics *was* visibly broken.
A grep that has never returned a hit is not evidence of health.

## If the log says it is broken: the IDA route

- `UnityPlayer.dll` is readable at `D:\Games\Tarkov\UnityPlayer.dll` (per
  `AGENTS.md`; it is unobfuscated). This is a Windows-machine task — the local
  `TarkovAddons/GameDump/1.2.0.0.47965/` holds `GameAssembly.pdb`,
  `global-metadata.dat` and `dump.cs`, **none of which describe UnityPlayer's
  data section**.
- Note `tools/verify/ida_manifest.py` will **not** help here: it is
  manifest-driven and validates profile symbols, not an ad-hoc RVA.
- Determine which of `0x1A236F8` / `0x1A237F8` / `0x1A242C8` is which by
  xref. The dumper's claim for the first is `Object::RegisterInstanceID`
  (pattern `40 53 48 83 EC ? 48 8B D9 E8 ? ? ? ? 8B 43`) indexing
  `+ 32 * (type_id & 0x7FF)`. If `RegisterInstanceID` is found and it indexes
  that global by type id, the identification is real and ours is the *neighbour*
  — then find the owner struct and name our field from it.
- Whatever the answer, the deliverable is a **named profile symbol with a
  `patterns` entry and a `notes` field**, per `compatibility/REFRESH_RUNBOOK.md`
  — not another bare literal, and not a copy-pasted forum RVA. A name that
  survives a game update is the only version of this worth having.

## Do not

- Do not edit `optics_lens_pipeline.h`, `unity.h`, `esp_text.h`,
  `skeleton_visibility.h`, `quest_esp.h` or `EspModule.*`. Frozen, another
  workstream, live right now.
- Do not "fix" the literal by adopting the dumper's RVAs. Different global,
  unverified source, and it would convert a guarded-unverified surface into an
  unverified one with a worse paper trail.
- Do not add these to `patterns.cfg` / the profile on the strength of the forum
  post. `tools/tests/test_manifest_tool.py` treats profile contents as claims
  with derivations; a claim with no oracle behind it is the thing that toolchain
  exists to prevent.

## One-line summary for the optics owner

`instance_from_id()`'s `0x1A237F8` is the last unnamed magic constant in that
route; it is guarded but unverified; the observable symptom of it rotting is
already logged as three `why =` strings; **grep the log first**, and only reach
for IDA if the grep says the route is failing.
