"""Watch EscapeFromTarkov.exe and record its exit code.

Why this exists
---------------
Seven of twelve launches on 2026-10-03 ended with the crash probe printing a fatal.
Five ended with nothing at all -- no vectored report, no unhandled-filter report, no
std::terminate report. Those five produced no Windows Application Error event either,
because Windows Error Reporting is switched off on this machine:

    HKLM\\SOFTWARE\\Microsoft\\Windows\\Windows Error Reporting
        Disabled = 1
        LoggingDisabled = 1

So for those five there is no evidence anywhere: not in the mod's log, not in the
event log. The one number that is still available is the process exit code, and it is
enough to tell the cases apart:

    0xC0000005  a real access violation
    0xC00000FD  stack overflow -- the handler cannot run, so nothing is reported
    0xC0000409  __fastfail / abort -- bypasses SEH, so nothing is reported
    0xC0000374  heap corruption
    0xC000070E  the threadpool status the probe does catch
    0           a clean ExitProcess(0) -- not a crash at all
    <small>     somebody called TerminateProcess with that code

An exit code has to be read from a handle opened *while the process is alive*; once
it is gone the code is unrecoverable. That is the whole reason this is a watcher that
attaches, rather than something that inspects the corpse afterwards.

Usage
-----
    python tools/watch_client_exit.py                 # watch, print, append to CSV
    python tools/watch_client_exit.py --once          # watch a single launch and exit
    python tools/watch_client_exit.py --no-csv        # print only

Run it BEFORE launching the game. It attaches to the first EscapeFromTarkov.exe it
sees, waits, prints, and keeps going.
"""

import argparse
import csv
import ctypes
import ctypes.wintypes as wt
import os
import sys
import time
from datetime import datetime
from pathlib import Path

PROCESS_NAME = "EscapeFromTarkov.exe"
SYNCHRONIZE = 0x00100000
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
STILL_ACTIVE = 259
WAIT_INFINITE = 0xFFFFFFFF
TIMEOUT = 60 * 60 * 8

REPO = Path(__file__).resolve().parent.parent
CSV_PATH = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "TarkovAddons" / "client_exit_codes.csv"

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
kernel32.OpenProcess.argtypes = [wt.DWORD, wt.BOOL, wt.DWORD]
kernel32.OpenProcess.restype = wt.HANDLE
kernel32.WaitForSingleObject.argtypes = [wt.HANDLE, wt.DWORD]
kernel32.WaitForSingleObject.restype = wt.DWORD
kernel32.GetExitCodeProcess.argtypes = [wt.HANDLE, ctypes.POINTER(wt.DWORD)]
kernel32.GetExitCodeProcess.restype = wt.BOOL
kernel32.CloseHandle.argtypes = [wt.HANDLE]
kernel32.CloseHandle.restype = wt.BOOL

# Only the codes that change what we do next. Anything unlisted is printed raw.
NAMES = {
    0xC0000005: "STATUS_ACCESS_VIOLATION   a real memory fault",
    0xC000001D: "STATUS_ILLEGAL_INSTRUCTION",
    0xC0000025: "STATUS_NONCONTINUABLE_EXCEPTION",
    0xC00000FD: "STATUS_STACK_OVERFLOW      the handler cannot run, so nothing is logged",
    0xC0000374: "STATUS_HEAP_CORRUPTION",
    0xC0000409: "STATUS_STACK_BUFFER_OVERRUN  __fastfail/abort, bypasses SEH",
    0xC000041D: "STATUS_FATAL_USER_CALLBACK",
    0xC0000602: "STATUS_FAIL_FAST_EXCEPTION",
    0xC000070E: "THREADPOOL_FREE_LIBRARY_ON_COMPLETION_FAILED  the one the probe catches",
    0x80000003: "STATUS_BREAKPOINT",
}


def find_pid(name=PROCESS_NAME):
    """PIDs of every live process called `name`, via the toolhelp snapshot.

    Deliberately not EnumProcesses + QueryFullProcessImageName: that is two calls per
    process on a machine with hundreds of them, every quarter-second, for a watcher.
    The snapshot is one call and carries the name.
    """
    TH32CS_SNAPPROCESS = 0x2
    kernel32.CreateToolhelp32Snapshot.restype = wt.HANDLE
    snap = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if snap == wt.HANDLE(-1).value or snap is None:
        return []
    try:
        class ENTRY(ctypes.Structure):
            _fields_ = [
                ("dwSize", wt.DWORD), ("cntUsage", wt.DWORD), ("th32ProcessID", wt.DWORD),
                ("th32DefaultHeapID", ctypes.c_size_t), ("th32ModuleID", wt.DWORD),
                ("cntThreads", wt.DWORD), ("th32ParentProcessID", wt.DWORD),
                ("pcPriClassBase", ctypes.c_long), ("dwFlags", wt.DWORD),
                ("szExeFile", ctypes.c_char * 260),
            ]
        e = ENTRY()
        e.dwSize = ctypes.sizeof(ENTRY)
        want = name.lower()
        pids = []
        ok = kernel32.Process32First(snap, ctypes.byref(e))
        while ok:
            if e.szExeFile.decode("ascii", "replace").lower() == want:
                pids.append(e.th32ProcessID)
            ok = kernel32.Process32Next(snap, ctypes.byref(e))
        return pids
    finally:
        kernel32.CloseHandle(snap)


def describe(code):
    if code in NAMES:
        return NAMES[code]
    if code == 0:
        return ("ExitProcess(0) -- a clean shutdown, not a crash. If the user saw this "
                "as a crash, the client exited itself.")
    if code < 0x10000:
        return (f"TerminateProcess/ExitProcess with {code} -- not a structured exception. "
                f"Nobody raised anything, so no in-process handler could have seen it.")
    if code & 0x80000000:
        return "an NTSTATUS with the high bit set but not a known code -- print it raw"
    return "unknown"


def watch_once(timeout_s=TIMEOUT, name=PROCESS_NAME):
    """Attach to the next `name` that appears. Returns the exit code."""
    seen = set(find_pid(name))
    deadline = time.time() + timeout_s
    attached = None
    while time.time() < deadline:
        for pid in find_pid(name):
            if pid not in seen:
                attached = (pid, kernel32.OpenProcess(
                    SYNCHRONIZE | PROCESS_QUERY_LIMITED_INFORMATION, False, pid))
                break
        if attached:
            break
        time.sleep(0.25)
    if not attached:
        return None

    pid, handle = attached
    if not handle:
        print(f"  pid={pid} appeared but OpenProcess failed "
              f"(error {ctypes.get_last_error()}) -- cannot read its exit code", flush=True)
        return None

    started = datetime.now()
    print(f"  attached to pid={pid} at {started:%H:%M:%S}; waiting for it to end", flush=True)
    kernel32.WaitForSingleObject(handle, WAIT_INFINITE)
    code = wt.DWORD()
    kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
    kernel32.CloseHandle(handle)
    ended = datetime.now()
    return pid, code.value, started, ended


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true", help="stop after the first launch")
    ap.add_argument("--no-csv", action="store_true")
    ap.add_argument("--timeout", type=int, default=TIMEOUT)
    ap.add_argument("--process", default=PROCESS_NAME,
                    help="watch a different executable; this is how the selftest below "
                         "runs the same code path against a process it controls")
    args = ap.parse_args()

    if os.name != "nt":
        sys.exit("  this only runs on Windows")

    print(f"  watching for {args.process}. Launch it now.")
    if args.process == PROCESS_NAME:
        print(f"  csv: {CSV_PATH}")
    n = 0
    while True:
        got = watch_once(args.timeout, args.process)
        if got is None:
            print("  timed out waiting for the client to start")
            return 1
        pid, code, started, ended = got
        alive = (ended - started).total_seconds()
        print()
        print(f"  === pid={pid} ended after {alive:.1f}s ===")
        print(f"      exit code 0x{code:08X}  ({code})")
        print(f"      {describe(code)}")
        print()

        if not args.no_csv:
            try:
                CSV_PATH.parent.mkdir(parents=True, exist_ok=True)
                new = not CSV_PATH.exists()
                with CSV_PATH.open("a", newline="", encoding="utf-8") as fh:
                    w = csv.writer(fh)
                    if new:
                        w.writerow(["started", "ended", "seconds", "pid",
                                    "exit_code_hex", "exit_code", "meaning"])
                    w.writerow([started.isoformat(timespec="seconds"),
                                ended.isoformat(timespec="seconds"),
                                f"{alive:.1f}", pid, f"0x{code:08X}", code,
                                describe(code)])
                print(f"      appended to {CSV_PATH}")
            except OSError as exc:
                print(f"      could not write the csv: {exc}")
        n += 1
        if args.once:
            return 0
        print("  waiting for the next launch")


if __name__ == "__main__":
    sys.exit(main())
