# Tracy client

> **This file is the reference. The procedure is
> [`PERFORMANCE_WORKFLOW.md`](PERFORMANCE_WORKFLOW.md).**
> Everything below explains *what a number means* — the capture CLI, the attribution
> traps, the zone inventory, and what fifteen captures actually found. The workflow
> document is the **iterative loop** built on top of it: name a suspect from a log
> counter, capture, rank, decide whether the cost is even measured, classify its
> shape, fix, then verify knowing that a two-capture A/B cannot carry the claim.
>
> They also disagree once, deliberately: §"Operating a capture" below puts the
> `.tracy` in `$env:TEMP`, and `AGENTS.md` forbids scratch in `TEMP` outright
> because temp cleanup destroyed a test suite and a verification toolchain. **Save
> captures into `tracy_traces/`.** The workflow document carries the corrected
> guidance and the rest of the reasoning.

`tracy-profiler.exe` — the Qt front-end that visualises a capture. Pinned to
**v0.14.1**, matching the vendored library in `TarkovAddons/external/tracy`.

The binary is **git-ignored** (`.gitignore:4` is `*.exe`), so it is not
committed. Fetch it once:

```powershell
$dst = "$PWD\tools\tracy"
New-Item -ItemType Directory -Force -Path $dst | Out-Null
Invoke-WebRequest `
  -Uri "https://github.com/wolfpld/tracy/releases/download/v0.14.1/windows-0.14.1.zip" `
  -OutFile "$env:TEMP\tracy.zip"
Expand-Archive "$env:TEMP\tracy.zip" "$env:TEMP\tracy-client" -Force
Copy-Item "$env:TEMP\tracy-client\tracy-profiler.exe" $dst
```

The release zip also carries `tracy-capture.exe`, `tracy-merge.exe` and
`tracy-csvexport.exe` if you ever want to capture or merge sessions from disk.
Only `tracy-profiler.exe` is needed to attach to a live one.

## Operating a capture

### 1. Pick the configuration deliberately

| Configuration | `TRACY_ENABLE` | Zone for |
|---|---|---|
| `Debug\|x64` | yes | iterating on instrumentation |
| `Release\|x64` | yes | optimised, with assertions off |
| **`Prod\|x64`** | **yes — deliberately; restored 2026-10-10** | **the shipping build** |
| **`Prod no aimbot\|x64`** | **yes** | shipping build, aimbot compiled out |

All four, re-confirmed 2026-10-10 by reading the five `TRACY_*` defines out of
each `ItemDefinitionGroup` (or just `grep TRACY_ENABLE TarkovAddons\TarkovAddons.vcxproj`)
and by finding `Start Profiler` in the built Prod DLL.

This table has now been wrong in **both directions**. An earlier revision said
"the `Prod` configs contain no profiler at all — build Debug or Release"; the
override then landed (2026-10-03), was reverted on 2026-10-08 (dropping it from
both `Prod` configs while this table still said "yes"), and was restored on
2026-10-10. So the profiler is in the binary you actually ship, on purpose, and
it comes back out the same way it went in: delete the five `TRACY_*` defines
from both `Prod` configs of `TarkovAddons.vcxproj`, where the comment now
carries the whole round-trip. **Confirm the artefact rather than trusting this
file or the `.vcxproj` comment** — both have been wrong. The old claim that
`Prod no aimbot|x64` "still has `TRACY_ENABLE` absent" was false even then;
that config omits `INCLUDE_AIMBOT`, not `TRACY_ENABLE`. Check the artefact:

```powershell
$s = [System.Text.Encoding]::ASCII.GetString(
  [System.IO.File]::ReadAllBytes("TarkovAddons\out\prod\with_aimbot\TarkovAddons.dll"))
$s.Contains("Start Profiler")   # True  -> profiler is compiled in
```

A Debug/Release profile is **not comparable** to a Prod profile. Different
optimisation, different inlining, different `_ITERATOR_DEBUG_LEVEL`. If a
claim crosses that boundary it is not an A/B result.

### 2. Start it

1. Deploy the DLL. In game, open the **Debug Log** card; it has a
   *Profiler (Tracy)* section at the top. Press **Start Profiler**.
2. Run `tracy-profiler.exe`, then **Connect** to `127.0.0.1:8086`.
3. Reproduce the thing you are measuring.

There is no console path — profiling is deliberately not started at load:

```
# nothing to do — profiling is deliberately not started at load
```

`TRACY_MANUAL_LIFETIME` means zones are **inert until the button is pressed**:
`tracy::profiler::Zone`'s constructor returns on a `running()` check before
touching anything. So a `Prod` build with the profiler in it costs a predictable
branch per zone when you are not profiling, and **you must still press the
button** or your capture is empty. An empty capture is the expected result of
forgetting, not a broken build.

Starting it opens a listening socket and a sampling thread, which is why it is
an explicit per-session act rather than a build default.

### 3. Save it

`tracy-profiler.exe` → **Save** writes a `.tracy` file. Keep it: **the CSV is
derived from it and the hierarchy only exists in it.** See "The export has no
call tree" below before you throw the original away.

Name captures with the build and a serial — `next_next_day+6+crash.tracy` —
and treat `+crash` as a claim, not a description. Three different captures in
this repo carry it; at least one had no crash in it.

### 4. Export it

```powershell
$exe = (Resolve-Path "tools/tracy/tracy-csvexport.exe").Path
# `-e` self time per zone; `-t 90` a truncated mean that ignores the spikes
Start-Process $exe -ArgumentList @('-e', "$env:TEMP\c5.tracy") -NoNewWindow -Wait `
  -RedirectStandardOutput "$env:TEMP\c5_self.csv"
```

`-e` and `-u` are **different questions, not two views of one** — see the third
trap below. Read one at a time.

### 5. Know what you are reading

- **Rank and statistics → CSV.** Containment and hierarchy → the `.tracy` in
  the GUI.
- **`mean_ns`, never `total_ns`,** for A/B. Totals mostly measure how long you
  played.
- **Ignore `total_perc`** — it reports values over 100%.
- **Absence checks are sound from one capture.** A distribution is not.

Sections below expand on each of those.

## Reading a saved `.tracy` offline

`tracy-csvexport.exe` gives per-zone statistics without the Qt front-end. Three
things about its CLI are not what the usage text implies:

- **There is no `extract` subcommand**, even though `-h` prints
  `Usage: extract [OPTION...] <trace file>`. Passing `extract` makes it print the
  usage block and exit 1 — and the literal string `extract` does not even exist
  in the binary, so it is not a dispatch token. The real form is
  `tracy-csvexport.exe [OPTION...] <trace file>`, with the file **last**.
- **A `+` in the capture filename breaks plain `&` invocation.** PowerShell
  hands `tracy_traces\current+5.tracy` through in a way that fails to parse.
  Use `Start-Process -ArgumentList` (which also avoids a pipeline truncating
  the output), or copy the trace to a plain name first.
- **The encoding is not fixed, and it is not the CLI's choice.** Verified by
  byte inspection: `tracy-csvexport.exe` writes **plain UTF-8, no BOM** (two
  runs, same result, and it has no encoding flag — `-f -s -c -e -u -g -m -p
  -t` only). The CSVs sitting beside the `.tracy` in `tracy_traces/` are
  **UTF-16LE with a BOM**. Something other than the CLI wrote those; the GUI's
  statistics export is the likely candidate but that is **not proven** — read
  the bytes rather than trusting the attribution. PowerShell's `Import-Csv`
  sniffs both; Python's `csv` sniffs neither:

  ```python
  raw = open(path, "rb").read()
  enc = "utf-16" if raw[:2] == b"\xff\xfe" else "utf-8"
  rows = list(csv.DictReader(io.open(path, encoding=enc)))
  ```

  Both failure modes read as corruption. Wrong encoding on the UTF-16 file gives
  `KeyError: 'name'` with a header that arrives as `'\x00n\x00a\x00m\x00e'`.
  Forcing `utf-16` on the UTF-8 file gives `UnicodeDecodeError: truncated data`
  at byte 0, because the length is **odd** — that oddness is the tell.

```powershell
$exe = (Resolve-Path "tools/tracy/tracy-csvexport.exe").Path
# self time per zone, and a truncated mean that ignores the spikes
Start-Process $exe -ArgumentList @('-e', "$env:TEMP\c5.tracy") -NoNewWindow -Wait `
  -RedirectStandardOutput "$env:TEMP\c5_self.csv"
Start-Process $exe -ArgumentList @('-t', '90', "$env:TEMP\c5.tracy") -NoNewWindow -Wait `
  -RedirectStandardOutput "$env:TEMP\c5_trunc.csv"
```

Columns: `name, total_ns, total_perc, counts, mean_ns, min_ns, max_ns, std_ns`
(plus `percentile_ns, truncated_mean_ns` with `-t`).

**Compare `mean_ns`, not `total_ns`.** Session length and player count vary a
lot between captures, so totals mostly measure how long you played. See
"Reading the numbers honestly" below.

~~Two zones can deliberately share a name to aggregate into one bucket.~~
**That was true, it was a mistake, and both instances are now split.** This
file recommended it; the first trap under "Four attribution traps" says what it
cost. The current state:

| Zone | Scope |
|---|---|
| `skeleton_vis::is_target_visible` | the ESP per-bone occlusion raycast only |
| `skeleton_vis::is_target_visible_penetrating` | the aimbot penetration walk only |

They measured **10.9 µs and 130.6 µs per call** — 12× apart, same raycast
helper — and as one row the export reported a single meaningless 10.9 µs mean
and a call count that was the sum of two unrelated workloads.

## The export has no call tree, so containment must be inferred

`tracy-csvexport` emits **one flat row per zone name** with aggregate totals. It
does not record who called whom. Every "is X inside Y" question therefore has to
be answered some other way, and `-e`/`-u` only change whether a row's `total_ns`
includes that zone's own children — they do not add structure.

Two workable substitutes, in order of reliability:

**1. Exact `max_ns` equality proves containment.** If a child's `max_ns` equals
its parent's `max_ns` to the nanosecond, that single worst instance is inside
the parent, and the parent did nothing else during it. From
`next_next_day+6`:

| child max | parent max | conclusion |
|---|---|---|
| `aimbot::project_to_screen` 54.12 ms | `aimbot::candidate_pick` 54.12 ms | the 54 ms is *entirely* inside the projection |
| `aimbot::project_to_screen` 54.12 ms | `frame::AimbotModule::draw_overlay` 54.14 ms | same frame, one event, three zones |

That third row is the useful shape: **one 54 ms frame appearing in three
unrelated functions is the signature of something global on that frame**, not
three coincidences. You cannot name the cause from the CSV — you can only
narrow it to "not three separate problems" and then go instrument.

**2. Subtract known children to get a self time, but only when containment is
established first.** Do not do this blind. `EspModule::collect_skeleton` =
34.97 s, `collect_skeleton_bones` = 5.57 s, `is_target_visible` = 27.68 s, so
~1.7 s is unattributed — but that subtraction is only valid because those two
are visibly its children. Aimed at an unrelated pair it produces confident
nonsense, which is the subject of the next section.

**When the answer needs the real hierarchy, use the `.tracy` file in
`tracy-profiler.exe`.** That has the tree. The CSV is for ranking and
per-zone statistics; the GUI is for containment. Do not try to reconstruct
parentage from totals — see "Reading the numbers honestly" for what that
produces.

## Reading the numbers honestly

Cross-capture variance is large enough to swamp most single changes. Measured
across the 2026-10-01 captures (`current+3/+4/+5`), with no relevant code
change between `+3` and `+4`:

| Zone | `+3` | `+4` | `+5` |
|---|---|---|---|
| `aimbot::project_to_screen` mean | 17.81 µs | 11.18 µs | 14.62 µs |
| `skeleton_vis::is_target_visible` count | 2,358,258 | 28,358 | 901,005 |

An 83× spread in call count and a 59% spread in per-call mean, from the same
binary. So **a two-capture A/B cannot support a "N% faster" claim** — the
effect has to be visible against that band, or it needs many more samples, or a
deterministic in-process measurement instead of a cross-session one.

**Ignore the exported CSV's `total_perc` column.** In `nextday+2.csv` it reports
`1080.03%` for `frame::hk_tarkov_application_update` and `889.13%` for
`frame::ModuleManager::apply`, which is arithmetically impossible for a share of a
total. The `total_ns` column is fine; divide it by the sum yourself. A percentage
column wrong by an order of magnitude is worse than no column, because it looks
authoritative and someone will quote it.

What *is* sound from a log: absence checks. "No line carries a negative
`penLevel`" is a statement about a set, not a distribution, so it does not need
repeats. Note that the log **appends across sessions** — filter by timestamp
before counting, or you will measure the previous run.

## Four attribution traps

**Sharing a zone name is not free, and this file recommended it for months.**
Tracy aggregates custom-named zones **by name**. `TA_ZONE_TEXT` attaches a
string to a single call's payload and never reaches the zone statistics at all.
So a shared name plus the module name as text is *not* a cheap way to get
per-module detail — it is a way to **lose** it, leaving one row that every
module contributes to and that can be split only by eye in the GUI.

This is not hypothetical. `frame::module` was
`TA_ZONE_N("frame::module")` + `TA_ZONE_TEXT(m->name)`, added on 2026-01
*specifically to answer "which module is expensive"*. It carried 2,577,013
calls and 70.03 s, and the CSV export showed one row with no way to divide it.
The question survived three capture cycles.

The fix is one token — `TA_ZONE_N(m->name.data())` — because `m->name` is a
`std::string`, so `.data()` is NUL-terminated and the macro's `strlen` is safe.
Now one call site emits ~30 rows. **If two sites measure different things, give
them different names**; aggregating is something the reader does in a
spreadsheet, and it does not require destroying the source data.

**Use `total_perc`, never the sum of zone times.** Zones nest, so summing every
zone's `total_ns` double-counts parents. In `current+6` that made a 9.26% cost
look like 40.5%. `total_perc` is self-consistent — every zone in a capture
implies the same capture length, which is the check that it is a true share.

**A child's inclusive total cannot exceed its parent's, but its *self* total
legitimately can — and `--self` reports self.** This is the trap that costs the
most time, because the two numbers come out of the same CSV and are not the same
kind of thing. `--self`'s `total_ns` excludes a zone's children; `-u`'s includes
them. In `current+6`, `skeleton_vis::is_target_visible` was 69.3 s and
`frame::module` 29.0 s from the **`--self`** table, and `frame::module` is
supposed to enclose it. That is not a broken call graph — the parent's 29.0 s is
its own body, with the child's time excluded, and ESP's inclusive share was
107.7 s.

So: a self total exceeding its parent's self total is **not** evidence that the
call graph is wrong. Evidence for that is a child's *inclusive* total exceeding
its parent's *inclusive* total. Two habits keep this straight — read one table at
a time, and use the per-module split (`-u -f frame::module`, aggregating the
`value` column) when you need to know who owns a cost rather than who spends it.

**The source you are reading may not be the source that was built.** A capture
taken at 23:02 and a file last edited at 23:06 disagree. Before attributing a
number to a line of code, compare `LastWriteTime` on the `.cpp` against the
capture's `LastWriteTime`, and against the build output's:

```powershell
Get-ChildItem TarkovAddons -Recurse -Filter '*.dll' | Select-Object LastWriteTime
```

Uncommitted edits by a concurrent agent invalidate both code-level attribution
and any before/after claim, because the two binaries are not the same program.

**A log that is flooding is a log you cannot audit.** The same session that
produced the 5.5 M-call capture also wrote 11,903 lines of one `ERROR` message
at 48/second for the last 4m19s — the entire error surface, so every other
conclusion drawn from that log is drawn from a file that is 96% one repeated
line. Check the per-prefix and per-minute distribution *before* reading a log
for anything:

```powershell
$l = [System.IO.File]::ReadAllLines($log)
$l | ForEach-Object { if ($_ -match '\]\s+(\S+)') { $matches[1] } } |
  Group-Object | Sort-Object Count -Descending | Select-Object -First 12
```

**That snippet is the trap, not the fix — read the rest of this paragraph before
trusting its output.** Our log has two record shapes:

    [13:10:22][ERROR] quest objectives: ...      <- level AFTER the bracket, 2 brackets
    ERROR] quest objectives: ...                  <- level BEFORE, 1 bracket

`'\]\s+(\S+)'` matches the FIRST `]` that is followed by whitespace, so:

| line | captured group |
|---|---|
| `[13:10:22][ERROR] quest ...` | `[ERROR]` — a bracket, not the level |
| `ERROR] quest ...` | `quest` — the first word of the message, not the level |

Neither is the level. On a two-bracket line you get a constant; on a one-bracket
line you get whatever message text happens to follow. The distribution is
therefore **shaped correctly and labelled wrongly**, which is worse than being
obviously broken: it ranks by message text, every line of one severity collapses
together for no reason, and nothing in the output says so.

Extract the level explicitly. This cannot be blind in either shape:

```powershell
$l | ForEach-Object {
  if ($_ -match '^\[[^\]]*\]\s*(?<lvl>TRACE|DEBUG|INFO|WARN|WARNING|ERROR|FATAL)\b') { $matches.lvl }
  elseif ($_ -match '\b(?<lvl>TRACE|DEBUG|INFO|WARN|WARNING|ERROR|FATAL)\]')            { $matches.lvl }
  else { '<no-level>' }
} | Group-Object | Sort-Object Count -Descending | Select-Object -First 12
```

Then **cross-check the extraction against a fact you already know before
concluding anything from it**: count `FATAL` on its own and compare it with how
many crashes you know happened. A distribution whose `FATAL` row is empty, in a
session that crashed, is a broken extraction and not a quiet log. That check
costs one command and would have caught both this version and the one that
reported "the flood was the only problem" in a file that also held the
second-largest thing in the session.

`logger::error` is ungated by design, so a persistent failure condition logged
per frame is unbounded by anything a user can turn off. A rate-limited
`[transitdbg]` with a suppression count is the shape to prefer: a diagnostic that
silently under-reports is worse than none, and so is one that drowns everything
else.

The `<no-level>` bucket above is **not** noise to be discarded — it is where
continuation lines and writes that never went through the logger's formatter
land, and it is the bucket that surfaces an un-prefixed flood. In the 2026-10-04
13:02 session it held **13,561 of 15,274 lines, 13,547 of them the identical
`crash probe: handler-owner (raid-boundary)` string**. A per-level ranking looks
perfectly healthy on that file (11 ERROR, 12 WARN) and tells you nothing at all.

---

## Trap 5: `TA_ZONE_N` is a bare local, so two in one scope is a compile error

```cpp
// util/tracy_bridge.h:168
#define TA_ZONE_N(name) ... tracy::profiler::Zone ta_zone{ name, ... }; ...
```

Every `TA_ZONE_N` in a scope declares a variable literally named `ta_zone`.
Two of them in the same brace scope is **C2374 (redefinition with multiple
initialisation)**, and MSBuild reports it against a line that has nothing wrong
with it.

This is not a style note. Adding zones to `AimbotModule::gameworld_update` on
2026-10-04 hit it three times in a row — `pick_phase`+`candidate_pick`, then
`gather_phase`+`pick_phase`, then `mode3_output`+`mode3_mouse` — each on a line
that had compiled a moment earlier. The fix is always `{ }` around each zone.

`tools/tests/test_zone_scope.py` checks this statically. It tracks scope
**identity**, not brace depth: two sibling `if` blocks are at the same depth and
are different scopes, and a depth-keyed checker flags 11 false positives on the
shipped code. If you add a zone, run the test before you start a build.

```powershell
python -m pytest tools\tests\test_zone_scope.py -q -p no:cacheprovider
```

**Corollary, and the reason zone counts decay silently: a name that stops
appearing is indistinguishable from a name that was deleted.** Nothing warns
you. Recount rather than trusting a number carried from an earlier session, and
remember the dynamic site — a literal-name regex cannot see it:

```powershell
rg --no-ignore -oP 'TA_ZONE_N\("([^"]+)"\)' TarkovAddons -g '!x64/**' -r '$1'
rg --no-ignore -n -P 'TA_ZONE_N\((?!")' TarkovAddons -g '!x64/**'   # the dynamic one
```

As of 2026-10-04: **116 sites, 113 literal names, 16 files.** The gap of 3 is the
dynamic site at `ModuleManager.cpp:77` (`TA_ZONE_N(m->name.data())`, one
`frame::module` row per module instead of one shared bucket) plus the macro
definition and its no-op twin in `tracy_bridge.h`.


## What is instrumented

Zones are placed at boundaries where the interesting questions live, not per
function. The load-bearing ones, and what each answers:

| Zone | Answers |
|---|---|
| `frame::hk_tarkov_application_update` | the mod's per-frame cost, with the game's own Update split out below it |
| `game::tarkov_application_update` | the game's Update, which is **not** our cost — it was charged to us until it was zoned separately |
| `frame::module` → **the module's own name** | per-module dispatch. The zone name is now `m->name.data()`, so the export emits one row per module instead of one bucket for all of them — see the first trap under "Four attribution traps" |
| `frame::ModuleManager::apply` / `apply_all` | the two callers, which is why an inclusive total can legitimately exceed either |
| `eft_api::is_readable_address` | the `VirtualQuery` guard in front of every read |
| `eft_api::try_read_il2cpp_string` | IL2CPP string reads; a wide band = reflection churn |
| `optics::lens::range_readable` | the **4096-slot** region memo — hit rate and probe cost |
| `unity::is_unity_object_alive` | the 16-slot native-object memo and its 64-call TTL |
| `il2utils::resolve_{image,class,field,method}` | the four memoised resolvers; combined they are 0.28% |
| `skeleton_vis::readable_range` | a **raw** `VirtualQuery` that appears in neither the probe counter nor `probe_scoped` |
| `skeleton_vis::is_target_visible` | the per-bone occlusion raycast. The penetrating variant is a **separate** zone, not a second site under this name |
| `EspModule::collect_skeleton:{vis_memo_hit,vis_rays,limb_health}` | splits the ESP body's largest function into the memo hit, the ray batch that replaced it, and the limb read |
| `aimbot::initiate_shot` (+ `:player_field`, `:fireport`, `:direction`, `:stale_direction`, `:tp_bullet`, `:game_call`) | the SHOT path, which had no zone at all until 2026-10-04. It is the only aimbot code that runs on the game's shot rather than on our frame, so a capture could not distinguish "the aimbot did not cause the hitch" from "the aimbot caused it there". `:fireport` is the one call NOT covered by `gameworld_update`'s `hands_not_firearm` gate |
| `aimbot::lpt:{game_object,transform,pos}` | the three hops of `local_player_transform`, split because the whole read measured 118.75 us mean / **51.24 ms max** in `+7` while reading ~1 us in `+5`, and only one of the three can force Unity to bring a transform hierarchy up to date |
| `skeleton_vis::pen:{resolve_ballistic,read_penetration}` | the walk's two per-layer MANAGED reads, split from `occlusion_linecast` so "is the pen check expensive because of the rays or because of the collider" is answerable. `resolve_ballistic` is the game's own `Shot.TryGetBallisticCollider`, i.e. a `GetComponentInParent` we do not control |
| `skeleton_vis::occlusion_linecast`, `is_player_transform` | the parts of that raycast, split so a regression is attributable |
| `esp_bones::*` (8 zones) | bone-name resolution: `bone_key`, `managed_string_equals_leaf`, `lookup_bone_in_skeleton_dict` / `_lists`, and the four field/array readers |
| `aimbot::*` (36 zones) | per-stage aimbot cost: `alive_player_scan` (+ `:profile_fetch`, `:transform_walk`, `:candidate_insert`), `alive_players_fetch`, `ammo_cache`, `ammo_diagnostic`, `role_check`, `btr_check`, `candidate_pick`, `project_to_screen`, `resolve_aim_bone`, `get_skeleton_suffix_pos`, `main_player_method_resolve`, `velocity_prediction`, `wall_check_call` — plus the 2026-10-04 decomposition of `gameworld_update` itself, below |
| `eft_api::resolve_esp_camera_frame` | camera resolution, **once per pick pass**. Its own name, not the wrapper's `w2s_prefer_optic:resolve_camera` — sharing one would merge "once per pass" with "once per point" into the meaningless average the split exists to prevent |
| `eft_api::w2s_prefer_optic:resolve_camera` | camera resolution split out of `world_to_screen_prefer_optic`, so a stall in the projection can be attributed to the resolver or the arithmetic |
| `always_on::*` (8 zones) | the episodic transit hooks. They fire 1-14 times a session but cost 45 ms to 937 ms **each**; `read_guarded` buckets all 35 template call sites |
| `hideout::*` (12 zones) | the menu-side hideout path, 8 of them in `production_panel_probe.h` |
| `frame::{Esp,Aimbot}Module::{draw_overlay,gameworld_update}` | the two per-frame module entry points |
| `EspModule::{collect_skeleton,draw_skeleton_entry,draw_skeleton_entry_optic,is_player_any_part_visible}` | the ESP body work |
| `item_db::build`, `game_item_db::localize_snapshot` | the once-per-process snapshot build and the 5,963-entry localization loop |
| `world::loot_to_me` + `:scan` / `:sort` / `:place` / `:quest` | the loot teleporter's gated block, split four ways. **`:sort` is the one to watch**: its comparator calls `get_template_id` twice per comparison, two IL2CPP crossings each, on an O(n log n) walk — re-deriving ids `matches_filter` read one loop earlier. If it dominates, the fix is carrying the id alongside the pointer, not a faster comparator |
| `world::loot_teleport_preview` | a full-map pass gated on `menu::is_active()`. The zone sits **before** the gate deliberately: after it the row would read cheap forever and prove nothing |
| `world::refresh_active_quest_item_ids` | self-throttled to 10 s, and zoned at the **callee** because `WorldModule` and `EspModule` both call it |
| `marked_rooms::scan` / `:location_id` | split because the scan runs only when the world object changes identity while the location read runs every tick. One zone over the body reports the mean of a free tick and a whole-map scan |
| `weapon_builder::pull_editor_results` / `:refresh_weapons` / `:inspect_slots` / `:install_selected_item` | four independent actions, three of them `.take()`-gated to once per request, zoned separately so a one-shot cost is never averaged with the per-tick call |

**113 distinct static zone names across 16 files, 116 `TA_ZONE_N` sites**, plus one
dynamically-named site (`ModuleManager.cpp:77`, `TA_ZONE_N(m->name.data())`).

> **Both figures are stale, and the correction is not a bigger number.**
> Recounted 2026-10-12 with `tools/zone_gap.py --list-zones --names`: **169 names /
> 170 literal sites / 171 call sites / 33 files.** The growth is real — thirteen
> zones were added the same day to close the largest unzoned per-frame bodies. What
> is *also* real is that the original counting method was wrong in two ways, and
> both inflate the number:
>
> 1. **A comment was counted as a zone.** `util/tracy_bridge.h:29` carries the
>    header's own usage example, `// TA_ZONE_N("item_db::build");`
> 2. **A commented-out zone was counted as live.**
>    `module/impl/QuestModule.cpp:1142` is `//TA_ZONE_N("quest_completer::list_walk");`
>    — switched off deliberately, which is why it produces no row in any capture.
>
> And the `rg` recipe below counts distinct **locations**, not distinct **names**,
> because `rg -o` prints `file:match`; without the `sed` the two differ whenever a
> name is used twice (`chams::weapon` is). This is the same defect
> `tools/tests/test_profile_path.py` exists to prevent — a checker that can pass on
> a comment is not a checker — reached by a different route.
>
> **`tools/zone_gap.py --list-zones --names` does this correctly** and is the thing to
> run. Its `--names` output is what makes the difference *visible* rather than
> inferred: the two dead names are absent from it, and `aimbot::fireport_resolve` is
> present.

Recounted 2026-10-04 with the method below:

```powershell
rg --no-ignore -oP 'TA_ZONE_N\("\K[^"]+' TarkovAddons -g '!x64/**' |
  sed 's/^[^:]*://' | Sort-Object -Unique | Measure-Object   # distinct NAMES
rg --no-ignore -c 'TA_ZONE_N\(' TarkovAddons -g '!x64/**'   # per-file counts
rg --no-ignore -n -P 'TA_ZONE_N\((?!")' TarkovAddons -g '!x64/**'   # the dynamic site
```

**Recount rather than trust any number in this paragraph.** This file said 65
zones / 66 sites "counted 2026-10-01", which was already wrong when written — it
sat unmaintained while `skeleton_visibility.h` grew by ~950 lines. Two revisions
later the real figures were 79, then 82, then 93, then 113. Each revision also had to
restate the method, because the count is the one number here that decays
silently: nothing fails when a zone is added, so the inventory is only as current
as the last time somebody remembered to run it. (It also has to be counted in one
pass over the whole tree. Counting directory-by-directory undercounted by 3 on the
same tree in the same minute, which is a good illustration of how easy the number is
to get wrong while still looking checked.)

**`-g '!x64/**'` is not optional.** Without it the search walks the build output,
and `TarkovAddons.dll` / `.pdb` are *locked* while the game has them mapped — so
`rg` either prints "the process cannot access the file because it is being used
by another process" or hangs until it times out. Both look like a tooling
failure and neither is one.

Note the last `rg` needs `-P`. Without it the negative lookahead is a literal and
the dynamic site is missed, which is the same failure as counting 65 when there
were 79 — a number that looks checked but was not.

`game_item_db::prewarm` is **no longer a zone** — an earlier version of this file
listed it, and the 10 s it was written to explain is accounted for by
`game_item_db::localize_snapshot` inside it.

Tracy's sampling profiler also produces call graphs through code with **no**
zones at all, so an un-instrumented hot path still shows up. The zones above
just give the graph readable names. The zones that find the most are not
necessarily the ones worth keeping: 8 of the 12 `hideout::` zones are 0.148% of a
session combined, and `il2utils`' four are 0.28%. Zone count is not a quality
metric — the reason there are not twenty hand-written per-module zones is that
one **dynamically**-named site now produces all twenty rows for free, and costs
less than the twenty would.

## Reading the next capture: `gameworld_update` — SOLVED, one line deeper

`frame::AimbotModule::gameworld_update` measured **174.84 s self / 63,509 µs
mean / 2,753 calls** in `next_next_next_day+3+stuck.tracy`, with **99.92% of it
inside regions that had no zone at all** (every zoned child summed to 0.146 s).
Eleven zones were added; the answer arrived in the very next capture.

    aimbot::fireport_resolve   310.59 s   22,129 calls   14,035 us mean   246.03 ms max   39.96%
    frame::EspModule::draw_overlay   9.44 s   24,099 calls      391.6 us mean

**33× the next most expensive zone in the capture.** The enclosing function now
reads `self = 0.0132 s, incl = 314.31 s` — so the "unattributed 174.84 s" was
this one call being charged to its parent. A zone that is 40% of the capture is
not a mystery, it is a missing measurement.

**What the next capture has to decide — it is now one question, not five:**

1. **`skeleton_vis::fireport:get_Fireport` vs `:get_position`.** Two managed
   calls inside `try_get_fireport_position`, split for exactly this. Whichever
   carries the 14 ms is the finding.

**Four things this capture settled that are worth not re-deriving:**

- **The uncached-`resolve_method` theory was wrong.** Its two
  `il2utils::resolve_method` children measured **1 us and 570 ns out of 130.12 ms
  -- 0.001%**. A zone-info window on one instance answers that in one click, and I
  had written the opposite into a source comment with a quotation from the file
  itself supporting it. The file's note was about *whether the walk is cached*,
  not about what it costs.
- **The cost is BIMODAL, and an aggregate mean hides it.** `csvexport -u` emits
  **one row per event** with `ns_since_start`, which the aggregate table does not
  have. Bucketed by 30 s, `fireport_resolve` runs at **1.44 us/call for 3.5
  minutes and 37,343 us/call for 6 minutes** -- a factor of 25,873. The headline
  "14,035 us mean over 22,129 calls" is two populations averaged.
- **A call rate is not a cost.** "22,129 calls on 78% of frames" says how often,
  not how much. I used it to rule out the loading screen and was wrong; the
  screenshot came from the loading screen and the user was right.
- **It is not the thread being descheduled.** Split every sibling zone by the two
  regimes: `gather_phase` goes 20.6 -> 23.1 us and `ammo_cache` 27.2 -> 13.3 us,
  flat, while `fireport_resolve` goes 1.44 -> 37,343 us. **A blocked thread shows
  up in all the siblings or none.** That is the check to run before believing any
  "the OS stalled us" reading -- one sibling zone, same frames, unchanged.

**The remaining unknown is which regime is which**, and the capture cannot say it:
the log's last line is one record before the capture window opens, so there is no
timeline to label the buckets. `try_get_fireport_position` now accumulates into
plain counters and prints, **into the log every 30 s**:

    fireport-cost: calls=N total_ms=X mean_us=Y max_ms=Z rate_hz=R

Deliberately not a zone -- see `report_fireport_window()`. The gate is a clock
comparison evaluated before any string is built, which is the `unity.h` lesson
from the same day.

**Generalisable, because both halves have now bitten:** when a function's self
time is large and its children are not, the answer is not a better hypothesis
about the children -- it is that the expensive region has no zone. And once it
has one, **check whether the mean is one population or two before quoting it.**
The 47x-climb-with-falling-call-count shape read like state accumulation across
five captures; it was one call that is free for three minutes and ruinous for six.


## What the zones have actually found

Fifteen captures. The five results worth keeping, because four of them are
counter-intuitive:

**1. The `VirtualQuery` guard was the most expensive thing in the project, and
it was a guard.** `eft_api::is_readable_address` was 91.6 s / 2,493,902 calls —
8% of wall clock spent *checking whether a read was safe* rather than reading.

| capture | self | calls | per call |
|---|---|---|---|
| `current+3` | 91.621 s | 2,493,902 | 36.7 µs |
| `current+4` | 0.091 s | 2,897 | 31.4 µs |
| `current+5` | 0.149 s | 3,990 | 37.3 µs |
| `current+6` | 0.119 s | 2,029 | 58.6 µs |
| `nextday` | 1.339 s | 27,667 | **48.4 µs** |

The last row looks like a 11× regression and is not: the call count rose 13×, so
**per call the cost went down**. The fix was memoisation, not a faster check —
`VirtualQuery` costs ~46–200 µs here, so the only lever is fewer syscalls. Read
the ratio, never the total.

**2. A zone you split can be worth more than one you add.** Splitting
`skeleton_vis::is_target_visible` into `occlusion_linecast` and
`is_player_transform` took the same work from 69.3 s to 18.7 s, because the
region became attributable and a third of it turned out to be the part that
mattered.

**3. The most expensive zone is now not a probe at all.**
`hideout::Card::refresh_hideout_state` — 155.681 s, 8.678%, 171,433 calls, **908 µs
each**, and its call count is identical to `game::tarkov_application_update`'s, so
it is 1:1 with the frame. A menu-side path, 8× the next entry, and new code.
That is what a profile is for: it moves.

*(That number is history. The throttle documented in `HideoutModule.cpp` now
holds it to ~305 µs mean over the whole session, and the residual is ~780 real
refreshes at ~13 ms — legitimate work, not a stall.)*

**4. The long tail, and a memo that is a frame-rate artefact rather than a
throttle.** Two results that a top-N-by-total ranking shows you *nothing* about.
(`+6` found the first; `+7` corrected the second, and the correction is the more
useful half.)

**~58 million sub-microsecond calls.** Individually invisible, collectively
several seconds:

| zone | calls | mean |
|---|---|---|
| `esp_bones::managed_string_equals_leaf` | 18,547,726 | ~0.03 µs |
| `esp_bones::bone_key` | 15,001,452 | ~0.06 µs |
| `il2utils::resolve_method` | 13,340,271 | ~0.20 µs |
| `il2utils::resolve_field` | 11,145,941 | ~0.17 µs |
| `esp_bones::get_player_bone_field` | 1,725,696 | ~1.0 µs |

Sort by `total_ns` and none of these appear. The lesson generalises: **a
per-call cost under ~1 µs is not a leaf, it is a multiplier**, and the only way
it shows up is if you sort by `counts`.

**The memo fires 12.6% of the time, not never.** `EspModule::collect_skeleton` keeps a
per-player memo of link visibility, gated on `vis_frame_serial_`, which increments once per
**presented frame**. The memo is consulted once per **game-world update** per player.

`next_next_day+7` measured it directly:

| branch | calls | share | self mean | inclusive mean |
|---|---|---|---|---|
| `collect_skeleton:vis_memo_hit` | 18,231 | **12.6%** | 0.1 µs | — |
| `collect_skeleton:vis_rays` | 127,014 | 87.4% | 7.0 µs | **217.9 µs** |
| `collect_skeleton` (total) | 145,245 | | | 237.8 µs |

and **2,667,294 rays / 127,014 ray-calling calls = 21.0 per call**, i.e. every
ray-calling pass works its whole link list. The capture has 53,638 draws against 53,637
world updates — roughly 1:1 — so a hit happens only when the game runs **two** world
updates inside one presented frame.

**That is a frame-rate artefact, not a throttle.** It saves ~12.6% of 27.7 s ≈ 3.5 s and
it reduces nothing systematically; on a machine where updates outran frames the rate would
invert. An earlier revision of this file, and `CHANGELOG.md` §0.20, both said the memo
"never fires" and put the hit rate near zero. **Both were wrong**, inferred from
2,533,776 rays ÷ 143,808 calls = 17.6 per call — an average diluted by the hits, then read
as if every call raycast. The two zones cost one capture cycle to establish and overturned
it in one.

Still not fixed, for the same reason: whether the memo *should* be a real throttle is a
behaviour question, and it now has a measurement.

**Accounted time is 13–23% depending on the capture.** The other 77–87% is the
game's render, physics and netcode on threads this mod does not hook. Treat that
as a **ceiling on instrumentation**, not a gap in it — a zone cannot measure code
the profiler's thread is not running on.

**Also unexamined:** `always_on::hk_prepare_game_job` fires 8 times a session
and cost **3,258 ms on its worst call**. Eight samples is not enough to
characterise, and it has never been looked at.

**5. `next_next_next_day+crash.tracy` (63.8 MB, 2026-10-04): the third-largest
self time in the session was a camera lookup called 6.9x more often than it
needed to be.** Two identical maxima did the work — `aimbot::project_to_screen`
and `eft_api::w2s_prefer_optic:resolve_camera` both maxed at **55.72 ms**, which
places that frame's stall entirely inside one resolve call, the same way §2 of
the table above places a stall with three matching maxima.

The redundancy itself is arithmetic, not inference: **154,544 resolutions for
22,431 picks**. And `cam-choice` shows there was nothing to amortise —
`resolves=25696 named=25696 fallback=0 none=0 | named_multi=0 far=0`, every call
succeeded by name. `pick_esp_fps_camera` is reached through
`unity::find_camera_if_best`, which is backed by `Camera.all`: **a fresh managed
array allocation per call plus a `GetName` per camera in the scene.** So each
projected bone cost an allocation, not a cheap read.

This is finding #2 of this file in a different costume — *splitting a zone found
the cost, and the cost was redundancy rather than slow code.* The original
suspect was the name→`std::string` conversion inside the camera lookup, which had
already been fixed once. The remaining cost was the number of times the lookup
ran, and no amount of making it faster would have touched it.

## When Tracy is in the crash, not in the profile

A profile answers "where did the time go". It cannot answer "why did the process die
inside Tracy", and on 2026-10-02 that is exactly what was needed.

```powershell
# pull the crash probe's frames out of a log and name them
python tools\symbolize.py --file "C:\Battlestate Games\BsgLauncher\tarkovaddons_log.txt"

# or symbolise addresses/rvas you already have
python tools\symbolize.py 0x100B03 0x44E57
python tools\symbolize.py --base 0x7FFCCD0C0000 0x7FFCCD104E57
```

It reads the linker `.map` next to the deployed DLL (override with `--map` / `--dll`)
and resolves each address to the nearest preceding symbol plus the offset. The `.map`'s
VA column already carries the preferred image base, so no section table is needed. It
demangles through `undname.exe` when VS is installed.

**Trust the fault address. Distrust the frames.** The probe reports a stack word as a
frame whenever its value falls inside our module's address range — it does not check
that the value is a return address, or that it points at code. In the 2026-10-02
crash, four of seven frames resolved to `??_C@_...` compiler-generated **string
literals**.

**Read the offsets before you believe a name.** `nearest preceding symbol` is honest
about what it is, and an offset of `0x1107C8` past a four-byte function is a hole in
the table, not a wild pointer. Three traps, all hit in real use:

- **Under-reporting looks like a finding.** The first version of this parser required
  exactly one alphabetic character in the map's type column and silently dropped
  **26,363 of 43,619** symbols. Check the symbol count the tool prints against the
  map's line count; if it is off by more than the `<absolute>` pseudo-symbols, the
  parser is broken.
- **A truncated table invents neighbours, it does not say "unknown".** Those dropped
  symbols turned two crash frames into `hk_tarkov_application_update` and
  `dxhook::WndProc` — a call chain that read as fact and was entirely the parser's
  doing. Only the fault address survived correction.
- **The probe filters frames by module, not by code-vs-data.** Frames landing in a
  `??_C@_0CL@...` string symbol are stack *words*. The tool now flags offsets over
  `0x20000` as implausible, which is the cheapest available smell.

Symbolizing took a crash from "the game died when I pressed Start Profiler" to a
specific instruction — `mov rbx, qword ptr [rdi]` with `rdi = tracy::s_profilerData + 8`
— which is the whole of §0.7 and `AGENTS_TODO.md` §5.10. The fault turned out to be
ours: `tracy_bridge.cpp` published its `g_started` gate *before* `StartupProfiler()`
allocated the profiler data. See the note on the `tracy_bridge.h` header comment for
the retraction of the earlier, wrong callstacks explanation.

## Caveats

- **Timings are perturbed.** A sampling thread inside the game is not free.
  Absolute numbers are not production-representative; relative shape is.
- **`is_readable_address` and `try_read_il2cpp_string` are extremely hot, and
  have since been memoised.** A wide band there means the syscall cost is real,
  which is the same finding the `optic-perf` `vq=` counter reports for the optics
  path. Both are now cheap in practice, so a capture showing them large again
  means a memo regressed — check the `probe-memo` and `unity-memo` counter lines
  in the log first. `is_readable_address` went 91.6 s / 2,493,902 calls →
  0.09 s / ~2,900 once the eight uncached call sites were routed through
  `is_readable_address_cached`.
- **A flame graph shows where time went, not whether it was necessary.** The
  item-db per-raid pass can be fully visible in the graph and still be
  redundant. Pair this with the `changed == 0` assertion.
- **A zone you add is a cost.** The instrumentation is not free and the
  attribution traps above are the price of reading it. And a diagnostic that
  under-reports is worse than none: the `item-chams:` trace reported
  `shader=ok applied_set=57` from a stale cached field while the bundle was
  actually null for the last four minutes of a session, which is what made a
  real failure hard to see. If a trace cannot be sourced from live state, it
  should say so.
