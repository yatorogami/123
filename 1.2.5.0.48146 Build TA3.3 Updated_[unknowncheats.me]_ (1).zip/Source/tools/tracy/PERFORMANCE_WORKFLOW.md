# Performance workflow: finding and killing expensive paths

An **iterative loop** for answering two questions about CPU time in this project:

1. *Which paths cost more than they should?*
2. *Which of those are complicated, and which are merely redundant?*

This is the procedure. [`tools/tracy/README.md`](README.md) is the **reference** —
the capture CLI, the attribution traps, the zone inventory, and fifteen captures'
worth of recorded findings. Read that for *why* a number means what it means. Read
this for *what to do next, in what order, and what would prove you wrong*.

> **Verification status, stated up front because this repo requires it.**
> Every stage below is derived from captures already recorded in `README.md` and
> from code I read in this tree on 2026-10-12. **I ran none of the capture loop
> myself** — no Windows host, no game, and this directory contains no `.tracy` file.
> The inventory counts and the static facts are re-measured (each with a negative
> control); the performance figures are quoted from `README.md` with their capture
> dates. Nothing here is a claim I validated end to end.

---

## 0. The split that decides everything before you start

These two questions need **different instruments**, and using the wrong one is the
most common way this work goes wrong.

| Question | Instrument | Can a build system answer it? |
|---|---|---|
| *Which paths are **often** used / where did the time go?* | **Tracy capture** | **No.** Only a running process has a time distribution. |
| *Which paths are **not** used?* | **Not a code model — see below.** | No. |

**Do not build a call graph for this project.** Per-frame work reaches every module
through `ModuleManager::apply` → `std::function<void(Module*)>` → a `Module*` stored
in a `std::vector<PVOID>` → a **virtual** call (`Module.h`, **13** virtuals).
IL2CPP entry points are runtime-resolved pointers cast at each call site
(`static_cast<T>(method->methodPointer)`). Hooks are installed **by string name**
(`il2utils::hook_method(game_world_class, "Update", 0, hk_game_world_update, ...)`).
A static analyser resolves none of that, so it will report the entire mod as dead.
`CLEANUP_AUDIT.md` §19.2 records this exact failure against the ISIL dump, where
`LocalRaidStarted` reads as four declarations and zero call sites while genuinely
being invoked via `IEftSession` slot 62. **A new dead-code report here regenerates a
known artefact, not a finding.**

CMake's `compile_commands.json` is real and it is what enabled clang-tidy. It is
also **not** a usage model. `dup_scan.py` and `map_icf.py` answer a different
question again — *what duplicated code costs bytes*, not *what runs*.

---

## 1. The loop

Ten stages, numbered 0-9. Each has a **gate** — a check that can fail. A stage you
cannot gate is a stage that will produce a number nobody measured, which is the
failure mode this repository has been bitten by repeatedly (`AGENTS.md`, and three
tools in `tools/` that each shipped green while comparing nothing).

```
  0 preconditions
        v
  1 name the suspect  <----------------------------------------.
        v                                                    |
  2 capture                                                 |
        v                                                    |
  3 preserve                                                |
        v                                                    |
  4 rank  ---- mean_ns AND counts ----------------------------+
        v
  5 measured?  -- no, children ~ 0 --> 6 add/split zones --> back to 1
        v  (attributed)
  7 classify the shape  -- unzoned/redundant/bimodal/slow/not-ours/artefact
        v
  8 fix
        v
  9 verify  -- or: the instrument refuted you; record it --> back to 1
```

### Stage 0 — Preconditions

Do these before any measurement, because each one silently invalidates everything
downstream.

| Check | Command / fact | Fails how |
|---|---|---|
| The build is **`Prod\|x64`** | `deploy.py build` defaults to Prod | A Debug/Release profile is **not comparable** — different optimisation, inlining, `_ITERATOR_DEBUG_LEVEL`. A claim crossing that line is not an A/B result. |
| The artefact has the profiler | see `README.md` §"Pick the configuration deliberately" | A `Prod` build *without* `TRACY_ENABLE` gives an empty capture, which looks like a broken profiler. |
| The game was launched through **`BsgLauncher.exe`** | — | Starting `EscapeFromTarkov.exe` directly loads no DLL: no log, no mod, no zones. |
| Nothing is mid-edit by another agent | `git status --short` | "The source you are reading may not be the source that was built." Two binaries are not the same program. |
| Your `IntDir` is private | `$env:SLOT` | Two agents sharing one tree collide on the 249 MB PCH and on `*.tlog`. |

**Gate:** the deployed DLL's timestamp is newer than every source you intend to
attribute a number to. If it is not, stop.

### Stage 1 — Name the suspect from a counter, not from a hunch

The cheapest signal is already in the log, and it is deterministic. This tree
emits **~30 distinct periodic counter prefixes** — `boot:`, `cam-choice:`, `chams:`,
`container-chams:`, `container-probe:`, `esp-bones:`, `esp-cone-init:`, `esp-path:`,
`exfil:`, `fireport-cost:`, `hideout:`, `hideout-panel:`, `hk_transit:`,
`hk_transit_point_move_next:`, `hk_ta_is_local_transit_hop:`, `i18n:`, `optic-perf:`,
`optic-packet:`, `optic-route:`, `pen-check:`, `raid-boundary:`, `tracy:`,
`vis-breakdown:`, `vis-cone:`, `vis-dist-cap:`, `local_raid_settings:`,
`modify_raid_settings:`, `configure_pve_location:`.

Derive it rather than quote it — **and read that as "the count depends on the
pattern", not as a number to carry forward**:

```powershell
rg --no-ignore -oP 'logger::(?:info|debug)\((?:std::format\()?"\K[a-z][a-z0-9_-]*(?=:)' `
  TarkovAddons -g '!x64/**' | sort -u
```

Two counters this pattern **misses**, both live: `esp-slow-frame` is emitted as
`"esp-slow-frame[{}/{}]:"` (a `[` follows the prefix, not a `:`), and `optic-perf`
lives inside a `std::format` that the `:$-anchored` group reaches only by accident.
A count derived this way is a **lower bound**, which is the same trap
`README.md` records for the zone inventory — where counting directory-by-directory
undercounted by 3 on the same tree in the same minute.

The counters that carry a *time* rather than a state, and so can start a
suspicion on their own: `esp-slow-frame` (`EspModule.cpp:127`),
`fireport-cost` (`skeleton_visibility.h:290`), `optic-perf` (`eft_api.h:1970`).

Read them **before** capturing. Two reasons, both earned the hard way:

- **A log that is flooding is a log you cannot audit.** The 2026-10-04 session wrote
  11,903 copies of one `ERROR` at 48/second for the last 4m19s. Every other conclusion
  from that file is drawn from a log that is 96% one repeated line.
- **The level-extraction snippet in `README.md` is itself a trap.** `'\]\s+(\S+)'`
  matches the first `]` followed by whitespace, so `[13:10:22][ERROR] quest ...`
  yields `[ERROR]` and `ERROR] quest ...` yields `quest`. The distribution is
  **shaped correctly and labelled wrongly**. Use the two-shape regex in `README.md`,
  then **cross-check**: count `FATAL` and compare it against how many crashes you
  know happened. An empty `FATAL` row in a session that crashed is a broken
  extraction, not a quiet log.
- **The `<no-level>` bucket is not noise.** In that same session it held 13,561 of
  15,274 lines — and 13,547 were one identical un-prefixed string. A per-level
  ranking looks healthy on that file and tells you nothing.

**Group the log by `pid=` before ordering by time.** More than one process writes
`tarkovaddons_log.txt` by design, and `tid` is recycled across processes. Quote the
log **file**, never the console copy, and **copy it aside before relaunching** — the
file is flushed per line, so a crash leaves the last statement on disk.

**Gate:** you can name a specific zone or counter line, with a timestamp window you
could reproduce. "The ESP feels slow" is not a stage-1 output.

### Stage 2 — Capture

Press **Start Profiler** in the Debug Log card. This is not optional:
`TRACY_MANUAL_LIFETIME` means zones are **inert until the button is pressed** —
`Zone`'s constructor returns on a `running()` check. An empty capture is the
expected result of forgetting, not a broken build.

Reproduce **only** the thing you are measuring, for a bounded window. Note the
window's start and end in the log, because a capture and the log must share a
timeline for you to label any bucket later.

**Gate:** `counts > 0` for the suspect zone. `INFO` on the capture says so before
you save.

### Stage 3 — Preserve the capture

> **Do not put captures in `%TEMP%`.** `AGENTS.md`: *"Never put scratch in `/tmp`
> or `TEMP`"* — temp cleanup destroyed an entire earlier test suite and a whole
> verification toolchain. Several examples in `README.md` use
> `$env:TEMP\c5.tracy`; that is where captures get lost.

Save into **`tracy_traces/`**, which is already git-ignored (`.gitignore:90`) and is
already where the GUI writes by default. Name captures with **build + serial + what
you were reproducing**: `+8_loading_screen.tracy`.

Treat `+crash` in a filename as a **claim, not a description** — three captures in
this repo carry it and at least one had no crash in it.

**Keep the `.tracy` itself.** `tracy-csvexport` emits one flat row per zone name
with no caller information. The hierarchy exists **only** in the `.tracy`, read in
`tracy-profiler.exe`. The CSV is for ranking; the GUI is for containment.

**Gate:** the file is in `tracy_traces/`, has a non-lying name, and its size is
plausible for the window.

### Stage 4 — Rank

```powershell
$exe = (Resolve-Path "tools/tracy/tracy-csvexport.exe").Path
# -e = SELF time per zone; -u = INCLUSIVE. These are different questions.
Start-Process $exe -ArgumentList @('-e', "tracy_traces\+8_loading_screen.tracy") -NoNewWindow -Wait `
  -RedirectStandardOutput "tracy_traces\+8_self.csv"
Start-Process $exe -ArgumentList @('-t', '90', "tracy_traces\+8_loading_screen.tracy") -NoNewWindow -Wait `
  -RedirectStandardOutput "tracy_traces\+8_trunc.csv"
```

Columns: `name, total_ns, total_perc, counts, mean_ns, min_ns, max_ns, std_ns`
(plus `percentile_ns, truncated_mean_ns` with `-t`).

Five rules, each of which has cost a capture cycle:

1. **`mean_ns`, never `total_ns`,** for A/B. Totals mostly measure how long you
   played.
2. **Sort by `counts` as well as `total_ns`.** A per-call cost under ~1 µs is not a
   leaf, it is a **multiplier**. `+6` had ~58 million sub-microsecond calls
   (`esp_bones::managed_string_equals_leaf` 18.5 M at ~0.03 µs,
   `il2utils::resolve_method` 13.3 M at ~0.20 µs). A top-N-by-total ranking shows
   you **nothing** about them.
3. **Ignore `total_perc`.** It reported `1080.03%` in `nextday+2`. A percentage
   column wrong by an order of magnitude is worse than none, because it looks
   authoritative and someone will quote it. The `total_ns` column is fine — divide by
   the sum yourself.
4. **Read one table at a time.** `--self` excludes a zone's children, `-u` includes
   them. A self total exceeding its parent's self total is **not** a broken call
   graph; evidence for that is a child's *inclusive* total exceeding its parent's
   inclusive total.
5. **Never reconstruct parentage from totals.** Two zones whose `max_ns` match to the
   nanosecond are in the same worst frame — that is how you locate containment.
   Subtracting to get a "self" time is only valid *after* you have established the
   containment.

**CSV encoding is not fixed:** `csvexport` writes UTF-8 no BOM; the CSVs beside the
`.tracy` in `tracy_traces/` are UTF-16LE with a BOM. Sniff `raw[:2] == b"\xff\xfe"`.
Python's `csv` sniffs neither, and both failure modes read as corruption.

**Gate:** you have ranked by `mean_ns` *and* by `counts`, and you have not quoted a
single percentage from `total_perc`.

### Stage 5 — The decision: measured, or not?

This is the highest-value gate in the whole loop, and it is one question.

> **When a function's self time is large and its children are not, the answer is not
> a better hypothesis about its children — it is that the expensive region has no
> zone.**

Worked example, recorded in `README.md` §"Reading the next capture":
`frame::AimbotModule::gameworld_update` measured **174.84 s self over 2,753 calls**
with **99.92% of it inside regions that had no zone at all** (every zoned child summed
to 0.146 s). Eleven zones were added; the answer arrived in the **very next capture**:

```
aimbot::fireport_resolve   310.59 s   22,129 calls   14,035 us mean   246.03 ms max   39.96%
```

33× the next most expensive zone. **A zone that is 40% of the capture is not a
mystery, it is a missing measurement.**

Compute the ratio: *sum of zoned children's inclusive time* ÷ *enclosing function's
self time*. Above ~0.5, you have an **attribution** problem. Below ~0.1, you have an
**instrumentation** problem.

**Gate:** the suspect's cost is either attributed to a named zone, or explicitly
recorded as unattributed. Never proceed while it is silently unattributed.

### Stage 6 — Add or split zones

If Stage 5 said *unattributed*, instrument it. Two hard-won rules:

**Splitting a zone is usually worth more than adding one.** Splitting
`skeleton_vis::is_target_visible` into `occlusion_linecast` + `is_player_transform`
took the same work from 69.3 s to 18.7 s — the region became attributable and a
third of it turned out to be the part that mattered.

**Never share a zone name between two call sites.** Tracy aggregates custom-named
zones **by name**. `frame::module` was `TA_ZONE_N("frame::module")` +
`TA_ZONE_TEXT(m->name)`, added *specifically* to answer "which module is expensive".
It carried 2,577,013 calls and 70.03 s and exported as **one indivisible row**. The
question survived three capture cycles. The fix is one token —
`TA_ZONE_N(m->name.data())` — and now ~30 modules emit their own rows for free.

Before you build:

```powershell
python -m pytest tools\tests\test_zone_scope.py -q -p no:cacheprovider
```

`TA_ZONE_N` is a bare local literally named `ta_zone`, so **two in one brace scope is
C2374**, reported by MSBuild against a line with nothing wrong with it. It bit three
times in a row on 2026-10-04. The test tracks scope *identity*, not brace depth.
(Measured 2026-10-12: **8 passed**.)

**Inventory — recounted, because it decays silently.** Nothing warns you when a zone
is added, and a name that stops appearing is indistinguishable from one that was
deleted:

```powershell
rg --no-ignore -oP 'TA_ZONE_N\("([^"]+)"\)' TarkovAddons -g '!x64/**' -r '$1' |
  Sort-Object -Unique | Measure-Object
rg --no-ignore -n -P 'TA_ZONE_N\((?!")' TarkovAddons -g '!x64/**'   # dynamic site; -P required
```

Recount rather than trusting any number. `tools/zone_gap.py --list-zones [--names]`
does this properly, and it has now corrected this file twice.

**Live, measured 2026-10-12: 169 names / 170 literal sites / 171 call sites / 33
files.** The first recount (156/30) already exceeded `README.md`'s recorded
113/16, and a second pass the same day added thirteen zones to the largest unzoned
per-frame bodies, so it is 169/33 now.

**The counting method was wrong in two ways, and both inflate the number** — which
is why a *bigger* figure needed correcting as well as a smaller one:

- `item_db::build` — `util/tracy_bridge.h:29`, inside the header's own `//` usage
  example.
- `quest_completer::list_walk` — `module/impl/QuestModule.cpp:1142`, **deliberately
  commented out**, which is why it produces no row.

That is the defect `tools/tests/test_profile_path.py` exists to prevent — a checker
that can pass on a comment is not a checker — reached by a different route. So the
recipe below strips comments, and two more traps in it are worth knowing:

```powershell
# live distinct names. The sed is LOAD-BEARING: `rg -o` prints file:match, so
# without stripping the path you are counting distinct LOCATIONS, not names, and
# the two differ whenever one name is used twice (chams::weapon is).
rg --no-ignore -oP 'TA_ZONE_N\("\K[^"]+' TarkovAddons -g '!x64/**' \
  | sed 's/^[^:]*://' | sort -u | Measure-Object

# the one dynamically-named site; -P is required or the lookahead is literal
rg --no-ignore -n -P 'TA_ZONE_N\((?!")' TarkovAddons -g '!x64/**'

rg --no-ignore -c 'TA_ZONE_N\(' TarkovAddons -g '!x64/**'    # per-file counts
```

The `-g '!x64/**'` is **not optional**: the DLL/PDB are *locked* while the game has
them mapped, so `rg` prints a sharing violation or hangs, and both look like a
tooling failure.

**Gate:** `test_zone_scope.py` green, every new site has a distinct name, and the
inventory has been recounted rather than copied.

### Stage 7 — Classify before you fix

An expensive path is one of six things. They have **different fixes**, and the first
three are the ones people get wrong:

| Shape | Signature | Fix |
|---|---|---|
| **Unzoned** | self time large, children ≈ 0 | Add a zone. Re-capture. *(Stage 5)* |
| **Redundant** | cost is `N × cheap`, N larger than needed | **Call it less.** Making it faster does nothing. |
| **Bimodal** | mean hides a factor ≫ 10 between regimes | Fix the **regime**, not the mean. |
| **Genuinely slow** | per-call cost is high, count is sane | Memoise. The only lever is fewer syscalls. |
| **Not ours** | inside the game's own managed call | Nothing. Do not attribute it to yourself. |
| **Artefact** | rate tracks frame timing, not work | Leave it. Re-derive semantics. |

Evidence for each, all from `README.md`:

- **Redundant.** `+crash`: **154,544 camera resolutions for 22,431 picks** — 6.9× more
  often than needed. The suspect had been the name→`std::string` conversion, already
  fixed once; the real cost was *how many times the lookup ran*. No amount of making
  it faster would have touched it.
- **Bimodal.** `fireport_resolve` ran at **1.44 µs/call for 3.5 minutes and
  37,343 µs/call for 6 minutes** — a factor of 25,873. The headline "14,035 µs mean
  over 22,129 calls" is two populations averaged. Three independent sessions
  reproduced it, and the expensive window closed on the same millisecond as a log line
  flipping `handsNotFirearm` to false.
- **Genuinely slow.** `eft_api::is_readable_address` was **91.6 s over 2,493,902
  calls** — 8% of wall clock spent *checking whether a read was safe*. `VirtualQuery`
  costs ~46-200 µs here, so memoising was the only lever: 91.6 s / 2,493,902 calls →
  0.09 s / ~2,900 calls.
- **Not ours.** `skeleton_vis::pen:resolve_ballistic` is the game's own
  `Shot.TryGetBallisticCollider`, i.e. a `GetComponentInParent` we do not control.
- **Artefact.** The `collect_skeleton` visibility memo fired **12.6%** of the time,
  not never. It is gated on a **presented frame** serial while consulted once per
  **game-world update** — so it only hits when the game runs two world updates inside
  one presented frame. On a machine where updates outran frames the rate would
  invert. Both an earlier revision of `README.md` and `CHANGELOG.md` §0.20 said it
  "never fires". Both were wrong.

**Three hypotheses to kill before believing a diagnosis:**

1. **"The OS stalled us."** A blocked thread shows up in **all the siblings or
   none**. Split every sibling zone by the suspected regimes: `gather_phase` went
   20.6→23.1 µs and `ammo_cache` 27.2→13.3 µs — flat — while `fireport_resolve` went
   1.44→37,343 µs. One sibling zone, same frames, unchanged, is the check.
2. **"It's the loading screen."** **A call rate is not a cost.** "22,129 calls on 78%
   of frames" says how often, not how much. That reasoning was used to rule out the
   loading screen, and the screenshot came *from* the loading screen.
3. **"It's the uncached `resolve_method` walk."** Its two children measured **1 µs and
   570 ns out of 130.12 ms — 0.001%**. A zone-info window on one instance answers
   that in one click, and the opposite claim had been written into a source comment
   with a quotation from the file supporting it.

**Gate:** the shape is named from the table, with the signature that named it.

### Stage 8 — Fix the complexity, not the symptom

If the shape is *complicated* rather than *redundant*, the fix is structural, and it
is the same three moves that have actually worked here:

1. **Hoist the loop invariant.** The camera resolver allocates a fresh managed array
   (`Camera.all`) plus a `GetName` per camera, per projected bone. Hoist it to once
   per pass — which is also why `eft_api::resolve_esp_camera_frame` has **its own
   zone name** rather than sharing the wrapper's: "once per pass" and "once per
   point" averaged together is the meaningless mean the split exists to prevent.
2. **Memoise the syscall, then route every call site through it.** Eight uncached
   call sites were routed through `is_readable_address_cached`.
3. **Replace an O(n) walk with a keyed lookup**, and pay the extra memory.

**If a capture shows them large again, a memo regressed.** Check the `probe-memo` and
`unity-memo` counter lines *first*, before re-instrumenting anything.

**Ceiling — know when to stop.** Accounted time is **13-23%** depending on the
capture. The other 77-87% is the game's render, physics and netcode on threads this
mod does not hook. That is a **ceiling on instrumentation, not a gap in it** — a zone
cannot measure code the profiler's thread is not running on.

**Gate:** the fix is committed on its own, *before* the build, and the commit
message does **not** claim build verification (`AGENTS.md`: a pre-build commit is not
build-verified; if the build then fails, the fix is a new commit).

### Stage 9 — Verify, knowing that you probably cannot

This is where honest people lie to themselves, so the constraint goes first.

**Measured variance, from the 2026-10-01 captures `+3`/`+4`/`+5` with no relevant code
change between `+3` and `+4`:**

| Zone | `+3` | `+4` | `+5` |
|---|---|---|---|
| `aimbot::project_to_screen` mean | 17.81 µs | 11.18 µs | 14.62 µs |
| `skeleton_vis::is_target_visible` count | 2,358,258 | 28,358 | 901,005 |

**An 83× spread in call count and a 59% spread in per-call mean, from the same
binary.** Therefore:

> **A two-capture A/B cannot support a "N% faster" claim.** The effect has to be
> visible against that band, or it needs many more samples, or it needs a
> deterministic in-process measurement.

Three legitimate ways to verify, in order of strength:

**(a) Deterministic counter in the log.** This is the escape hatch, and the pattern
already exists. `AimbotModule::report_fireport_window()` emits, every 30 s:

```
fireport-cost: calls=N total_ms=X mean_us=Y max_ms=Z rate_hz=R
```

It is **deliberately not a zone**, for a reason worth copying: a sampling profiler
cannot resolve a 30-second regime boundary, but a log line can, and it sits on the
**same timeline as the gameplay state** that labels it. The gate is a clock
comparison evaluated **before any string is built** — because `DEBUG` is off by
default but the *argument* to `logger::debug()` is still constructed every frame.

Then parse it offline with a fail-closed script. The house pattern is
`tools/measure_*.py`:

```powershell
python tools\measure_move_vs_dt.py    # exit 0 = measured; exit 2 = matched nothing
```

- **Fail closed.** An earlier parser matched 0 of 115 lines and printed a
  complete-looking report full of `nan`, then divided by a zero row count. Matching
  nothing is now a **hard error**, not a table of nans.
- **Carry a negative control in the header**, and run it.
- Note the parser bug worth not repeating: it rejected 94 of 115 lines because the
  sentinel `corr mm med=-1.00` did not match `[\d.]+`. **A regex on a log is a
  parser that will drift when the format does.**

**(b) Structural argument, no timing claim.** "It is now O(1) per pass instead of
O(bones) per bone" is checkable in the diff and does not depend on a distribution.
Prefer this when you can get it.

**(c) Many samples.** Only when the effect is much larger than the band.

**What a verification is allowed to conclude.** The strongest available result here
was **negative and immediate**: `esp_scan::refresh_cache_stats` measured 4 µs against
a 514 ms tail, and the suspicion that had driven the investigation was simply wrong.
**The instrument said so and saved the capture.** An instrument that can refute you is
the point; treat a refutation as a successful run of the loop, and write it down —
`README.md` §"What the zones have actually found" is mostly those.

**Gate:** the claim is either structural, or backed by a deterministic counter, or
explicitly downgraded to "shape changed, magnitude unverified". **Never write
"N% faster" on two captures.**

---

## 2. Two habits that keep this honest

**Recount; never quote.** Every number in this file was re-measured on 2026-10-12
except the performance figures, which carry their capture date. The zone inventory is
the clearest example of why: `README.md` said 113 names across 16 files, the tree said
156 across 30 the first time it was measured and 169 across 33 hours later, and
nothing failed in between. Its own text predicted this — the count has been wrong as
65, 79, 82, 93, 113 and 158 across revisions, the last of which was wrong *because it
counted a comment*.

**And a number can be wrong by being too HIGH as well as too low.** The `rg` recipe
in `README.md` reported 158 when the true live count was 156, because a usage example
in a `//` comment and a deliberately disabled zone both lex as zones. A figure that
only ever needs raising is not being checked.

**Run the negative control, on the loop and not only on the tools.** A capture that
cannot come back empty is not a measurement. So:

- Check `counts > 0` before saving (Stage 2).
- Check the log extraction against a fact you already know — the `FATAL` row against
  your crash count (Stage 1).
- Check that a suspicious parser exits **2**, not 0 (Stage 9).
- The cheapest possible control on the whole loop: **delete a zone, confirm its row
  disappears from the export.** If it does not, you are reading a stale CSV or a
  stale build, and everything above it is fiction.

---

## 3. Capture naming and storage

| | |
|---|---|
| **Location** | `tracy_traces/` — already git-ignored (`.gitignore:90`), already the GUI's default |
| **Not** | `%TEMP%` / `/tmp`. `AGENTS.md`: temp cleanup destroyed a whole test suite and a verification toolchain |
| **Name** | `<serial>_<what-you-reproduced>.tracy` — `+8_loading_screen.tracy` |
| **`+crash`** | a **claim**, not a description. Three captures carry it; at least one had no crash |
| **Keep** | the `.tracy`. The CSV has no caller information; only the GUI has hierarchy |
| **Zip** | fine — `*.zip` is git-ignored. A 400 MB archive can unpack to 9 GB+ of CSVs; query the SQLite inside instead (`tools/tracy_parser.py`) |

---

## 4. Where the next investigation should start

Two open items are already recorded, so they do not have to be re-derived:

1. **`aimbot::fireport_resolve`'s regime boundary** — which regime is which, and what
   predicate should gate it. The capture cannot label the buckets because the log's
   last line is one record *before* the capture window opens, so there is no shared
   timeline. `report_fireport_window()` now prints into the log every 30 s to close
   that gap; the next capture says what the gate does.
2. **`always_on::hk_prepare_game_job`** — fires **8 times a session** and cost
   **3,258 ms on its worst call**. Eight samples is not enough to characterise, and
   it has never been looked at. Either instrument it or explicitly record that 8
   samples is the reason it is unexamined.

Both illustrate the standing rule: **a finding nobody has looked at is not a finding,
and a diagnostic on a path that is never taken is worse than none, because it looks
like coverage.**