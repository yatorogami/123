<#
.SYNOPSIS
    Run clang-tidy over this tree, using a dedicated CMake analysis tree.

.DESCRIPTION
    The Ninja generator exports compile_commands.json and the Visual Studio
    generator does not -- that is the whole of what the CMake conversion bought
    for static analysis. Two things then had to be solved, both measured rather
    than guessed:

      1. clang cannot read a cl.exe-produced .pch. Running against the normal
         build tree fails immediately:
             error: file '...\cmake_pch.cxx.pch' is not a valid PCH file:
                    file doesn't start with precompiled file magic
         So this configures a SEPARATE tree with -DTA_NO_PCH=ON. That tree is
         several times slower to build and is never the artefact that ships.

      2. The Windows SDK and MSVC include paths come from the INCLUDE
         environment variable that vcvars64.bat sets, not from -I flags in the
         database. Without vcvars in the same process clang cannot find
         windows.h. This script therefore runs clang-tidy from inside a
         vcvars64 shell.

    .clang-tidy at the repository root holds the curated check list. Read it
    before changing it: every suppression in it carries the measurement that
    justifies it.

.PARAMETER File
    One or more first-party sources, relative to TarkovAddons\. Omit for the
    whole first-party set.

.PARAMETER Checks
    Overrides the check list in .clang-tidy. Pass '*' to see the uncurated
    flood -- useful once, to re-measure the header filter.

.PARAMETER Jobs
    Parallel clang-tidy processes. Default: one per logical CPU, capped at 16.

.PARAMETER Reconfigure
    Delete and rebuild the analysis tree first. Needed after any CMakeLists
    change, including a change to the source list.

.PARAMETER Trace
    Include the static analyser's `note:` path-trace lines. Off by default: on
    WorldModule.cpp the trace is 151 lines against 19 actual findings, and
    they interleave into something unreadable. You want them only when you are
    actually chasing one finding.

.EXAMPLE
    tools\run_tidy.ps1
    tools\run_tidy.ps1 -File module\impl\WorldModule.cpp
    tools\run_tidy.ps1 -File module\impl\WorldModule.cpp -Checks '*'
#>
param(
    [string[]]$File,
    [string]$Checks = "",
    [int]$Jobs = 0,
    [switch]$Reconfigure,
    [switch]$Trace
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
$vcvars = "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat"
$cmake = "C:\Program Files\CMake\bin\cmake.exe"
$tidy = "C:\Program Files\LLVM\bin\clang-tidy.exe"

foreach ($exe in @($vcvars, $cmake, $tidy)) {
    if (-not (Test-Path $exe)) { throw "not found: $exe" }
}

# The analysis tree is deliberately separate from build/Prod\x64\<slot>:
# TA_NO_PCH=ON makes it slower and it is not what deploy.py ships.
$analysis = Join-Path $root "build\analysis\x64\tidy"
$db = Join-Path $analysis "compile_commands.json"

if ($Reconfigure -and (Test-Path $analysis)) {
    Write-Host "Removing $analysis" -ForegroundColor Yellow
    Remove-Item -Recurse -Force $analysis
}

if (-not (Test-Path $db)) {
    Write-Host "Configuring analysis tree (TA_NO_PCH=ON) ..." -ForegroundColor Cyan
    $cfg = "`"$vcvars`" >nul && `"$cmake`" -S `"$root`" -B `"$analysis`" " +
           "-G Ninja -DCMAKE_BUILD_TYPE=Prod -DCMAKE_EXPORT_COMPILE_COMMANDS=ON " +
           "-DCMAKE_SYSTEM_PROCESSOR=AMD64 -DTA_NO_PCH=ON"
    cmd /c $cfg 2>&1 | ForEach-Object { Write-Host $_ }
    if ($LASTEXITCODE -ne 0) { throw "analysis configure failed: $LASTEXITCODE" }
    if (-not (Test-Path $db)) { throw "no compile_commands.json at $db" }
}

# Which files. Default is every first-party source in the database, which is
# the same skip list tools/dup_scan.py uses so the two tools agree on what
# "first-party" means.
if ($File) {
    $targets = $File | ForEach-Object {
        if ([System.IO.Path]::IsPathRooted($_)) { $_ }
        else { Join-Path $root "TarkovAddons\$_" }
    }
} else {
    $all = Get-Content $db -Raw | ConvertFrom-Json
    $targets = $all |
        Where-Object { $_.file -notmatch '[\\/](external|libil2cpp|GameDump|build)[\\/]' } |
        ForEach-Object { $_.file } |
        Sort-Object -Unique
}

if (-not $targets -or $targets.Count -eq 0) {
    Write-Error "no files selected -- the filter matched nothing, which is not a clean run"
    exit 2
}

if ($Jobs -le 0) { $Jobs = [Math]::Min(16, [Environment]::ProcessorCount) }

Write-Host ("clang-tidy over {0} file(s), {1} parallel job(s)" -f $targets.Count, $Jobs) -ForegroundColor Cyan

# clang-tidy takes one file per invocation, so the parallelism is at the
# process level. Each invocation re-parses the headers it needs; there is no
# sharing between processes, and that is the price of not having a clangd index.
#
# The file list is PARTITIONED UP FRONT, one slice per job, and the slices
# arrive as plain arrays. An earlier version passed a shared
# Queue[string] through -ArgumentList to Start-ThreadJob, which deserialises
# its arguments into the job's runspace: every job received its own COPY of
# the queue, so no job could ever observe the work another had taken and the
# run never terminated. Static slices have no shared mutable state and finish
# by construction.
$chunks = @{}
for ($i = 0; $i -lt $targets.Count; $i++) { $chunks[$i] = [System.Collections.Generic.List[string]]::new() }
$i = 0
foreach ($t in $targets) { $chunks[$i++ % [Math]::Min($Jobs, $targets.Count)].Add($t) }

$sw = [Diagnostics.Stopwatch]::StartNew()
# NOT $jobs: PowerShell variables are case-insensitive, and $Jobs is the
# [int]$Jobs parameter, so assigning ThreadJob objects to it is a cast error.
$pendingJobs = foreach ($slice in $chunks.Values) {
    if ($slice.Count -eq 0) { continue }
    Start-ThreadJob -ArgumentList @(@($slice), $analysis, $root, $vcvars, $tidy, $Checks, [bool]$Trace) -ScriptBlock {
        param($slice, $analysis, $root, $vcvars, $tidy, $Checks, $Trace)
        $kinds = if ($Trace) { "(warning|error|note):" } else { "(warning|error):" }
        foreach ($f in $slice) {
            $a = @("`"$tidy`"", "`"$f`"", "-p", "`"$analysis`"")
            if ($Checks) { $a += "--checks=$Checks" }
            # cwd = repo root so clang-tidy picks up .clang-tidy
            $cmd = "cd /d `"$root`" && `"$vcvars`" >nul && " + ($a -join " ")
            $text = cmd /c $cmd 2>&1 | Out-String
            # Only first-party diagnostics. The header filter in .clang-tidy
            # does this too; this is the belt to its braces, and it is what
            # makes the counts on screen trustworthy.
            $text -split "`r?`n" |
                Where-Object { $_ -match "^$([regex]::Escape($root))" -and $_ -match $kinds } |
                ForEach-Object { $_ }
        }
    }
}
$received = @($pendingJobs | Wait-Job | Receive-Job)
$sw.Stop()
$pendingJobs | Remove-Job -Force

$diag = @($received | Where-Object { $_ } | Sort-Object -Unique)
$files = @($diag | ForEach-Object { ($_ -split ":\d+:\d+:", 2)[0] } | Sort-Object -Unique)
$byCheck = $diag |
    ForEach-Object { if ($_ -match '\[([a-z0-9\-]+)\]\s*$') { $Matches[1] } else { "(uncategorised)" } } |
    Group-Object | Sort-Object Count -Descending

Write-Host ""
Write-Host ("{0} diagnostic(s) in {1} file(s) across {2} target(s), {3:N1}s" -f `
    $diag.Count, $files.Count, $targets.Count, $sw.Elapsed.TotalSeconds) -ForegroundColor Cyan

if ($byCheck) {
    Write-Host ""
    $byCheck | ForEach-Object { Write-Host ("  {0,5}  {1}" -f $_.Count, $_.Name) }
}
Write-Host ""
$diag | Select-Object -First 60 | ForEach-Object { Write-Host $_ }
if ($diag.Count -gt 60) { Write-Host "  ... $($diag.Count - 60) more" }

exit 0
