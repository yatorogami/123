r"""Is `move` a per-frame quantity at all? -- correlating it with `dt`.

2026-10-06. The finding that appeared to kill the shake investigation:

    local move mm max=56556.84 | dt ms med=16 max=45360

`move` is a delta between consecutive samples, and `dt` is the interval between
those same samples. A 56.5 m "one-frame" motion sits in a window whose longest
gap is 45.36 SECONDS. So it is not a node moving 56 m in a frame: it is a node
that was not sampled for three quarters of a minute, which is exactly what
un-scoping looks like.

The optic path only runs while the scope is up, so gaps are INHERENT to the
sampling, not evidence of corruption. If that is right then:

  - the "56 m in one frame" finding is an artefact of differencing across a gap,
  - the premise-violation claim in tools/optics_status.md sec 7 is wrong,
  - kSuspiciousMoveMm = 1000 mm, which I committed 20 minutes ago, was justified
    by "weapon sway peaked at 216 mm/frame" -- and 6 of 19 corrector=on windows
    exceeded 216 mm, so that justification does not hold either.

So measure it rather than argue it: correlation between window move_max and
window dt_max, and the distribution of move restricted to windows that are
genuinely per-frame.

PARSER NOTE. An earlier version of this rejected 94 of 115 lines because
`corr mm med=-1.00` (the sentinel for an empty correction set) did not match
`[\d.]+`. The regex here allows a leading sign.

FAIL-CLOSED NOTE. The first run of this parser matched ZERO of 115 lines and
printed a complete-looking report full of `nan` and then divided by a zero row
count. A checker that reports success while matching nothing is the exact defect
AGENTS.md warns about, so an empty match is now a hard error rather than a table
of nans. That claim is itself negative-controlled -- see NEGATIVE CONTROL below.

Usage:
    python tools\\measure_move_vs_dt.py [path-to-log]

Exit 0 = measured. Exit 2 = matched nothing and refused to report.

NEGATIVE CONTROL, run against a log containing no `root-frame:` lines at all.
It must exit 2 and must NOT print a distribution:
    'no root-frame lines here' > neg.txt
    python tools\\measure_move_vs_dt.py neg.txt   # expect exit 2
"""
import re
import statistics
import sys

LOG = r"C:\Battlestate Games\BsgLauncher\tarkovaddons_log.txt"
if len(sys.argv) > 1:
    LOG = sys.argv[1]

LINE = re.compile(
    r"root-frame: (?P<n>\d+) frames, applied=(?P<applied>\d+) \| "
    r"local move mm med=(?P<med>-?[\d.]+) max=(?P<max>-?[\d.]+) "
    r"\(>1mm:(?P<o1>\d+) >5mm:(?P<o5>\d+) of (?P<nm>\d+), "
    r"sign-reversals:(?P<rev>\d+)\) \| "
    r"corr mm med=-?[\d.]+ max=-?[\d.]+ \| "
    r"dt ms med=(?P<dtmed>-?[\d.]+) max=(?P<dtmax>-?[\d.]+)"
    r".*?corrector=(?P<state>\S+)")


def pearson(xs, ys):
    n = len(xs)
    if n < 2:
        return float("nan")
    mx, my = statistics.mean(xs), statistics.mean(ys)
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    dx = sum((x - mx) ** 2 for x in xs) ** 0.5
    dy = sum((y - my) ** 2 for y in ys) ** 0.5
    return num / (dx * dy) if dx and dy else float("nan")


def main():
    with open(LOG, encoding="utf-8", errors="replace") as fh:
        raw = fh.read().splitlines()

    rows, skipped = [], 0
    for line in raw:
        if "root-frame:" not in line:
            continue
        m = LINE.search(line)
        if not m:
            skipped += 1
            continue
        g = m.groupdict()
        rows.append({
            "ts": line[1:24], "n": int(g["n"]), "applied": int(g["applied"]),
            "med": float(g["med"]), "max": float(g["max"]),
            "o1": int(g["o1"]), "o5": int(g["o5"]), "nm": int(g["nm"]),
            "rev": int(g["rev"]), "dtmed": float(g["dtmed"]),
            "dtmax": float(g["dtmax"]), "state": g["state"]})

    print("parsed %d window(s), skipped %d (the 'only 1 frame' line)" % (len(rows), skipped))
    if not rows:
        print("\nFATAL: matched 0 of the root-frame lines. The format changed or the "
              "log is not the one this was written against.\nRefusing to print a "
              "table of nans -- see FAIL-CLOSED NOTE in the header.")
        return 2
    print("  corrector=on %d, corrector=DISABLED %d"
          % (sum(1 for r in rows if r["state"] == "on"),
             sum(1 for r in rows if r["state"] == "DISABLED")))

    # ---- 1. the correlation -------------------------------------------------
    print("\n=== window move_max vs window dt_max ===")
    xs = [r["dtmax"] for r in rows]
    ys = [r["max"] for r in rows]
    print("  Pearson r          = %.4f" % pearson(xs, ys))
    print("  Spearman (ranks)   = %.4f" % pearson(
        [sorted(xs).index(v) for v in xs], [sorted(ys).index(v) for v in ys]))
    print("  Pearson r on log10(dt_max) vs move_max = %.4f"
          % pearson([__import__("math").log10(max(v, 1.0)) for v in xs], ys))

    # ---- 2. how many windows are even valid as per-frame --------------------
    print("\n=== windows by the LONGEST GAP they contain ===")
    for thr in (50, 100, 250, 1000, 5000, 20000):
        n = sum(1 for r in rows if r["dtmax"] > thr)
        print("  dt_max > %6d ms : %2d of %d windows (%.0f%%)"
              % (thr, n, len(rows), 100.0 * n / len(rows)))

    # ---- 3. move, restricted to genuinely per-frame windows ----------------
    print("\n=== move_max, split by whether the window had a gap > 250 ms ===")
    for label, sel in (("dt_max<=250ms  (per-frame valid)", lambda r: r["dtmax"] <= 250),
                       ("dt_max>250ms   (gap inside)",      lambda r: r["dtmax"] > 250)):
        sub = [r for r in rows if sel(r)]
        if not sub:
            continue
        v = sorted(r["max"] for r in sub)
        print("  %s : %d window(s)" % (label, len(sub)))
        print("      move_max mm: min %.1f  p50 %.1f  p90 %.1f  max %.1f"
              % (v[0], v[len(v)//2], v[int(len(v)*0.9)], v[-1]))
        m = sorted(r["med"] for r in sub)
        print("      move_med mm: min %.2f  p50 %.2f  p90 %.2f  max %.2f"
              % (m[0], m[len(m)//2], m[int(len(m)*0.9)], m[-1]))

    # ---- 4. the worst frames, with the gap that produced them -------------
    print("\n=== the 8 largest move_max windows, with dt_max beside them ===")
    for r in sorted(rows, key=lambda r: -r["max"])[:8]:
        print("  %s  move_max=%9.1f mm  dt_max=%8.0f ms  dt_med=%4.0f  applied=%2d  %s"
              % (r["ts"], r["max"], r["dtmax"], r["dtmed"], r["applied"], r["state"]))

    # ---- 5. so what threshold is defensible? ------------------------------
    print("\n=== candidate kSuspiciousMoveMm, scored on per-frame-valid windows ===")
    valid = [r for r in rows if r["dtmax"] <= 250]
    vmax = sorted(r["max"] for r in valid)
    print("  per-frame-valid windows: %d, largest move_max in them = %.1f mm"
          % (len(valid), vmax[-1] if vmax else 0.0))
    for thr in (20.0, 216.0, 500.0, 1000.0, 5000.0):
        over_valid = sum(1 for v in vmax if v > thr)
        over_all = sum(1 for r in rows if r["max"] > thr)
        print("  thr %6.0f mm -> flags %d/%d valid windows, %d/%d windows overall"
              % (thr, over_valid, len(valid), over_all, len(rows)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
