"""A small window for building, installing and uninstalling the mod.

Run it with:

    python tools/deploy.py --gui
or, on Windows, by double-clicking tools/deploy.pyw

This is a front-end and nothing more. Every action, message and rule lives in
tools/deploy.py, so the window and the command line can never disagree about
what an install does; the GUI only chooses options, shows the output, and asks
before anything is written.

Two things it has to get right that a naive version gets wrong:

  * A Prod rebuild is ~118 s (see WORKFLOW.md), so the work runs on a background
    thread and the log is pumped from a queue. Doing it on the UI thread freezes
    the window solid for two minutes.
  * There is no Cancel button. Stopping MSBuild part-way leaves cl.exe and the
    precompiled header in a state that CLEAN has to race, and WORKFLOW.md
    records that costing a day. Buttons are disabled while busy instead.

Requires Python 3.10+ and tkinter, which ships with the python.org installers.
Nothing outside the standard library.
"""

from __future__ import annotations

import io
import queue
import sys
import threading
import traceback
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from typing import Callable

from tools import deploy

APP_TITLE = "TarkovAddons Reloaded - build and deploy"

# Shown in the header so the window says what it is before anything is clicked.
BLURB = (
    "Builds the solution and deploys it into the Battlestate BsgLauncher folder. "
    "Launch the game through BsgLauncher.exe afterwards."
)


class QueueWriter(io.TextIOBase):
    """A print() target that forwards whole lines to a queue.

    Lines are buffered until a newline arrives, because a build emits progress
    with carriage returns and splitting on those would fill the pane with
    fragments. Draining happens on the UI thread, never here, so no widget is
    ever touched from the worker.
    """

    def __init__(self, sink: "queue.Queue[str]") -> None:
        self._sink = sink
        self._buffer = ""

    def write(self, text: str) -> int:
        self._buffer += text
        while "\n" in self._buffer:
            line, self._buffer = self._buffer.split("\n", 1)
            self._sink.put(line)
        return len(text)

    def flush(self) -> None:
        if self._buffer:
            self._sink.put(self._buffer)
            self._buffer = ""

    def isatty(self) -> bool:
        # Keeps anything checking for a terminal from misbehaving. In particular
        # deploy.confirm() would otherwise try to input() on the worker thread.
        return False


class Clear:
    """Queue marker asking the UI thread to empty the log.

    The same reason as Question: the worker must not touch a widget. Calling
    log.delete() from the worker works often enough to look fine and corrupts
    tkinter's state when it does not, which is the worst kind of bug to chase.
    """


# tkinter variables, kept alive for the life of the process.
#
# tkinter.Variable.__del__ calls straight into Tcl, and Tcl serialises every call
# behind a per-interpreter lock that the UI thread holds while it runs its event
# loop. Garbage collection can run on ANY thread, so a collection triggered by an
# allocation on a worker thread will finalise a Variable there -- and that call
# into Tcl from the wrong thread deadlocks against the UI thread. It hangs the
# app with no error, no traceback and no window to close.
#
# It is not a hypothetical: it showed up as a worker wedged inside
# traceback.format_exc(), whose allocations happened to trigger the collection.
#
# Holding a reference forever means __del__ never runs, so the cross-thread call
# can never happen. This is the standard workaround. The cost is a handful of
# small objects that would otherwise be freed when a window closes.
_TK_VARIABLES: list = []


def _keep_alive(variable):
    """Hold a tkinter variable for the life of the process. See above."""
    _TK_VARIABLES.append(variable)
    return variable


class Done:
    """Queue marker meaning "the worker finished", carrying the final status.

    A sentinel rather than a bare string so the drain loop can tell "this is the
    end of the run" from "this is another line of output", without having to
    guess from the content of a message.
    """

    def __init__(self, status: str) -> None:
        self.status = status


class Question:
    """A confirmation the worker needs answered before it can carry on.

    The worker puts one of these on the queue and blocks on its event; the drain
    loop, which runs on the UI thread, shows the dialog and sets the answer. That
    round trip is the whole reason this class exists.

    The obvious alternative -- the worker calling root.after() itself and then
    waiting -- is what this replaces. Tk is not thread-safe, and doing that
    raises "main thread is not in main loop" or deadlocks depending on what the
    UI thread happens to be doing. Here only ever one thread touches a widget.
    """

    def __init__(self, text: str) -> None:
        self.text = text
        self.answer = False
        self.event = threading.Event()

    def ask(self, sink: "queue.Queue[object]") -> bool:
        sink.put(self)
        self.event.wait()
        return self.answer

    def resolve(self, answer: bool) -> None:
        self.answer = answer
        self.event.set()


class DeployWindow:
    def __init__(self, root=None) -> None:
        import tkinter as tk
        from tkinter import ttk

        self._tk = tk
        self._ttk = ttk
        # A root can be supplied so the tests can put several windows in one
        # interpreter. A Tk() instance owns the whole interpreter, and destroying
        # it deletes every pending after() command with it -- which killed the
        # drain loop and silently dropped whatever was still queued. A Toplevel
        # on a shared root destroys cleanly, so the window is agnostic about
        # which it was handed.
        self.root = tk.Tk() if root is None else root
        self._owns_root = root is None
        self.root.title(APP_TITLE)
        self.root.minsize(760, 560)

        # Every one of these is kept alive on purpose: see _keep_alive.
        self.flavor = _keep_alive(tk.StringVar(value="with_aimbot"))
        self.configuration = _keep_alive(tk.StringVar(value="Prod"))
        self.rebuild = _keep_alive(tk.BooleanVar(value=False))
        self.purge = _keep_alive(tk.BooleanVar(value=False))
        self.target = _keep_alive(tk.StringVar(value=""))
        self.status = _keep_alive(tk.StringVar(value="Ready."))
        self.busy = False
        # Set once the window is gone, so a pending after() callback stops
        # instead of raising TclError against a destroyed root.
        self._closed = False
        # The live after() handle, so it can be cancelled on close.
        self._drain_after = None

        self._lines: "queue.Queue[str | None]" = queue.Queue()
        self._buttons: list[tk.Widget] = []
        self._detected: Path | None = None

        self._build_ui()
        self._drain_after = self.root.after(100, self._drain)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self._detect_target()

    # -- layout ------------------------------------------------------------

    def _build_ui(self) -> None:
        tk, ttk = self._tk, self._ttk

        outer = ttk.Frame(self.root, padding=12)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text=APP_TITLE, font=("Segoe UI", 13, "bold")).pack(
            anchor="w"
        )
        ttk.Label(outer, text=BLURB, wraplength=700, foreground="#555555").pack(
            anchor="w", pady=(2, 10)
        )

        # Where it deploys to. Shown rather than hidden, because a mod in the
        # wrong folder looks exactly like a mod that does not work.
        target_box = ttk.LabelFrame(outer, text="BsgLauncher folder", padding=8)
        target_box.pack(fill="x")
        row = ttk.Frame(target_box)
        row.pack(fill="x")
        self.target_entry = ttk.Entry(row, textvariable=self.target)
        self.target_entry.pack(side="left", fill="x", expand=True)
        self._buttons.append(ttk.Button(row, text="Auto-detect", command=self._detect_target))
        self._buttons[-1].pack(side="left", padx=(8, 0))
        self._buttons.append(ttk.Button(row, text="Browse...", command=self._browse_target))
        self._buttons[-1].pack(side="left", padx=(6, 0))

        options = ttk.LabelFrame(outer, text="Options", padding=8)
        options.pack(fill="x", pady=(10, 0))

        flavors = ttk.Frame(options)
        flavors.pack(anchor="w")
        ttk.Label(flavors, text="Build to install:").pack(side="left")
        for label, value in (
            ("With aimbot", "with_aimbot"),
            ("No aimbot", "no_aimbot"),
        ):
            ttk.Radiobutton(
                flavors, text=label, value=value, variable=self.flavor
            ).pack(side="left", padx=(10, 0))

        build_row = ttk.Frame(options)
        build_row.pack(anchor="w", pady=(6, 0))
        ttk.Label(build_row, text="Build configuration:").pack(side="left")
        ttk.Combobox(
            build_row,
            textvariable=self.configuration,
            values=list(deploy.CONFIGURATIONS),
            state="readonly",
            width=16,
        ).pack(side="left", padx=(10, 0))
        ttk.Checkbutton(
            build_row, text="Full rebuild", variable=self.rebuild
        ).pack(side="left", padx=(14, 0))

        self.purge_check = ttk.Checkbutton(
            options,
            text="Uninstall: also delete my settings, caches and logs",
            variable=self.purge,
        )
        self.purge_check.pack(anchor="w", pady=(6, 0))

        actions = ttk.Frame(outer)
        actions.pack(fill="x", pady=(10, 0))
        for label, handler in (
            ("Build", self._do_build),
            ("Install", self._do_install),
            ("Uninstall", self._do_uninstall),
        ):
            button = ttk.Button(actions, text=label, command=handler)
            button.pack(side="left", padx=(0, 8))
            self._buttons.append(button)
        ttk.Button(actions, text="Clear log", command=self._clear_log).pack(side="left")

        log_box = ttk.LabelFrame(outer, text="Log", padding=6)
        log_box.pack(fill="both", expand=True, pady=(10, 0))
        self.log = tk.Text(
            log_box,
            # No wrapping: a Windows path is long, and a wrapped log makes it
            # hard to match a line against a real path. The horizontal
            # scrollbar below is what makes that choice usable.
            wrap="none",
            height=18,
            font=("Consolas", 9),
            state="disabled",
        )
        scroll = ttk.Scrollbar(log_box, orient="vertical", command=self.log.yview)
        scroll_x = ttk.Scrollbar(log_box, orient="horizontal", command=self.log.xview)
        self.log.configure(yscrollcommand=scroll.set, xscrollcommand=scroll_x.set)
        self.log.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")
        scroll_x.grid(row=1, column=0, sticky="ew")
        log_box.rowconfigure(0, weight=1)
        log_box.columnconfigure(0, weight=1)

        ttk.Label(outer, textvariable=self.status).pack(anchor="w", pady=(8, 0))

    # -- target ------------------------------------------------------------

    def _detect_target(self) -> None:
        # A missing game is not an error here: the user may be about to install
        # it, or may want to type a path. Report it in the status line instead.
        try:
            found = deploy.find_bsg_launcher(None, required=False)
        except deploy.DeployError as failure:
            self.status.set(str(failure).splitlines()[0])
            return
        if found is None:
            self.status.set("No BsgLauncher folder found on C: through F:. Browse for one.")
            return
        self._detected = found
        self.target.set(str(found))
        self.status.set(f"Found: {found}")

    def _browse_target(self) -> None:
        from tkinter import filedialog

        chosen = filedialog.askdirectory(
            title="Choose the BsgLauncher folder", initialdir=self.target.get() or None
        )
        if chosen:
            self.target.set(chosen)
            self.status.set(f"Target: {chosen}")

    # -- running work ------------------------------------------------------

    def _base_options(self) -> dict:
        options = dict(deploy.DEFAULTS)
        path = self.target.get().strip()
        options["path"] = path or None
        return options

    def _do_build(self) -> None:
        options = dict(deploy.DEFAULTS)
        options["config"] = self.configuration.get()
        options["rebuild"] = self.rebuild.get()
        self._start("Building", lambda: deploy.cmd_build(options), "Build finished.")

    def _do_install(self) -> None:
        # Dry run first, so the pane shows the exact file list, then ask. The
        # question is not "are you sure" in the abstract but "these N files, into
        # this folder", with the list already on screen.
        options = self._base_options()
        options["flavor"] = self.flavor.get()
        options["dry_run"] = True

        def run() -> None:
            deploy.cmd_install(options)
            if not self._ask("Install these files?"):
                self._log("cancelled. nothing was installed.")
                return
            real = dict(options, dry_run=False, yes=True)
            self._lines.put(Clear())
            deploy.cmd_install(real)

        self._start("Checking what would be installed", run, "Install finished.")

    def _do_uninstall(self) -> None:
        options = self._base_options()
        options["purge"] = self.purge.get()
        options["dry_run"] = True

        def run() -> None:
            deploy.cmd_uninstall(options)
            question = "Remove these files?"
            if options["purge"]:
                # Said plainly, because this is the one irreversible path.
                question = (
                    "Remove these files, AND delete your settings, caches and "
                    "logs?\n\nThis cannot be undone."
                )
            if not self._ask(question):
                self._log("cancelled. nothing was removed.")
                return
            real = dict(options, dry_run=False, yes=True)
            self._lines.put(Clear())
            deploy.cmd_uninstall(real)

        self._start("Checking what would be removed", run, "Uninstall finished.")

    def _ask(self, text: str) -> bool:
        """Hand a question to the UI thread and wait for the answer.

        The log pane stays visible behind the dialog, which is the point of
        running the dry run first: the question is asked with the file list
        already on screen.
        """
        return Question(text).ask(self._lines)

    def _start(self, what: str, work: Callable[[], None], done_message: str) -> None:
        if self.busy:
            return
        self.busy = True
        self._set_buttons(enabled=False)
        self.status.set(f"{what}...")

        def run() -> None:
            # Output is captured, not printed: this thread has no console, and
            # touching a widget from here would break tkinter's threading rule.
            sink = QueueWriter(self._lines)
            try:
                with redirect_stdout(sink), redirect_stderr(sink):
                    work()
            except deploy.DeployError as failure:
                sink.write(f"\n{failure}\n")
            except Exception:                      # noqa: BLE001 - see below
                # A GUI launched with pythonw.exe has no console, so an
                # unhandled traceback would vanish with nothing on screen. Show
                # it in the log, which the user can copy into a bug report.
                sink.write("\nunexpected error:\n")
                sink.write(traceback.format_exc())
            finally:
                sink.flush()
                self._lines.put(Done(done_message))

        threading.Thread(target=run, daemon=True).start()

    def _drain(self) -> None:
        from tkinter import messagebox

        # A pending after() can fire after the window has gone, and calling into
        # a destroyed root raises TclError. That used to kill the drain loop
        # part-way through, silently swallowing whatever was still queued -- a
        # traceback above all, since that is the one line the user needs when
        # something unexpected happens. A closing window has nowhere left to
        # draw, so stop instead.
        if self._closed:
            return

        try:
            while True:
                item = self._lines.get_nowait()
                if isinstance(item, Done):
                    self.busy = False
                    self._set_buttons(enabled=True)
                    self.status.set(item.status)
                elif isinstance(item, Question):
                    # Answered here, on the thread that owns the widgets, then
                    # the worker is released. resolve() is called exactly once:
                    # resolving in a finally as well would overwrite the real
                    # answer with the fallback and silently cancel every
                    # confirmation. A dialog that raises is treated as "no" and
                    # still releases the worker, so it cannot hang.
                    try:
                        answer = messagebox.askyesno(
                            APP_TITLE, item.text, parent=self.root
                        )
                    except Exception:              # noqa: BLE001
                        answer = False
                    item.resolve(bool(answer))
                elif isinstance(item, Clear):
                    self._clear_log()
                else:
                    self._append(item)
        except queue.Empty:
            pass
        except self._tk.TclError:
            self._closed = True
            return

        if not self._closed:
            self._drain_after = self.root.after(100, self._drain)

    def _set_buttons(self, enabled: bool) -> None:
        state = "normal" if enabled else "disabled"
        for button in self._buttons:
            try:
                button.configure(state=state)
            except self._tk.TclError:
                self._closed = True
                return

    def _append(self, text: str) -> None:
        try:
            self.log.configure(state="normal")
            self.log.insert("end", text + "\n")
            self.log.see("end")
            self.log.configure(state="disabled")
        except self._tk.TclError:
            self._closed = True

    def _log(self, text: str) -> None:
        self._lines.put(text)

    def _clear_log(self) -> None:
        try:
            self.log.configure(state="normal")
            self.log.delete("1.0", "end")
            self.log.configure(state="disabled")
        except self._tk.TclError:
            self._closed = True

    def _on_close(self) -> None:
        # Threads are daemons, so closing the window cannot hang on a build in
        # progress. Deliberately not offering to cancel one: see the module
        # docstring.
        self._closed = True
        if self._drain_after is not None:
            # Cancel the pending tick before the window goes, so it cannot come
            # due against a root that no longer exists.
            try:
                self.root.after_cancel(self._drain_after)
            except self._tk.TclError:
                pass
            self._drain_after = None
        try:
            self.root.destroy()
        except self._tk.TclError:
            pass

    def run(self) -> int:
        self.root.mainloop()
        return 0


def main() -> int:
    try:
        return DeployWindow().run()
    except Exception as failure:                  # noqa: BLE001
        # No display, or tkinter missing. Falling back to the usage text beats a
        # bare traceback, and points at the flags that still work.
        print(f"cannot start the window: {failure}\n", file=sys.stderr)
        print("The command line works without a window:", file=sys.stderr)
        print(deploy.USAGE, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
