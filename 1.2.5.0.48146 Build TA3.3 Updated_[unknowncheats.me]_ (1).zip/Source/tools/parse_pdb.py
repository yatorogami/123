"""
PDB parser — extracts launcher-target symbol RVAs from a GameAssembly.pdb
file using purelypdb. No IDA required.

Usage:
    python tools/parse_pdb.py <GameAssembly.pdb> [--output rvas.json]

Output: JSON mapping manifest symbol names to hex RVA strings.
"""

import argparse
import json
import sys
from pathlib import Path

try:
    import purelypdb
except ImportError:
    print("ERROR: purelypdb not installed. Run: python -m pip install purelypdb")
    sys.exit(2)


# Maps manifest symbol names to (class, method) search patterns.
# Matching is exact on the method name portion after the last "::", and the
# class_pattern is a substring test. That combination can genuinely match twice:
# nested compiler-generated types repeat both the outer class name and method
# names. The matcher therefore collects all candidates and reports AMBIGUOUS
# rather than taking the first, because first-match-wins is order-dependent --
# see the note in parse_pdb() for the concrete case that motivated it.
SYMBOL_PATTERNS = {
    "be_client_init": ("BEClient", "Init"),
    "be_client_start": ("BEClient", "Start"),
    # 1.2.0.0.47888: the PDB finally names this compiler-emitted generic
    # instantiation explicitly --
    #   System.Runtime.CompilerServices.AsyncTaskMethodBuilder$$Start<AnticheatValidationOperation.<RunValidation>d__10>
    # (0x40B2290) -- so it can be resolved by name. "Start<...>" is a generic
    # method name, which the matcher accepts alongside the exact form. The
    # class_pattern "RunValidation" is what pins the instantiation; do NOT add
    # the d__NN ordinal (see run_validation_movenext_offset below).
    #
    # WRONG-CANDIDATE WARNING: the same PDB also names BattlEye.BEClient$$CreateInstance
    # (0x18D0F70) -- a real method in this build. The old ("BEClient",
    # "CreateInstance") entry bound to it, and it is NOT the patch target: it
    # has no call edge to run_validation_movenext_offset (measured). The
    # CreateInstance name historically came from CreateInstanceResult, the
    # return type of BEClient::Start; BSG apparently promoted it to a real
    # method in 1.2.0.0.47888. Patching 0x18D0F70 would leave BEClient.Start
    # called and the bypass inert.
    "load_be_client": ("RunValidation", "Start"),
    # PDB-verified exact matches on 1.1.5.1.47510 (GameAssembly.pdb, 343233
    # global func symbols):
    #   0x30B0AA0  BattlEye.BEClient::Init
    #   0x10E0950  BattlEye.BEClient::Start
    #   0x1B76260  EFT.AnticheatValidationOperation+<RunValidation>d__10::MoveNext
    # The method is MoveNext, not RunValidation: the older
    # ("AnticheatValidationOperation", "RunValidation") matched nothing, because
    # the comparison below is exact on the substring after the last "::".
    #
    # class_pattern names the NESTED type, `+<RunValidation>`, not the outer
    # class. MoveNext is compiler-generated and appears 10231 times in this PDB
    # (`.ctor` 41761, SetStateMachine 1976), and 852 of 2069 classes carry more
    # than one -- System.Linq.Enumerable has 3017. All the specificity has to
    # come from class_pattern, and `+<RunValidation>` is what distinguishes this
    # state machine from any other member of AnticheatValidationOperation.
    #
    # Do NOT hardcode `d__10` anywhere. The compiler numbers async state machines
    # in declaration order (279 distinct ordinals here, up to d__1640), so adding
    # any method before RunValidation renumbers it and every d__NN mention in a
    # comment, a note or a pattern silently rots. `RunValidation` is stable
    # because it comes from the method name.
    #
    # 1.2.0.47888 PDB names the nested type `.<RunValidation>d__10` (dot, not
    # `+<RunValidation>`) and uses `$$` as the member separator throughout
    # (`BattlEye.BEClient$$Init`). The matcher normalizes `$$` to `::` before
    # comparing, so one pattern serves both PDB generations; `RunValidation`
    # matches both the old `+<RunValidation>` and the new `.<RunValidation>`.
    "run_validation_movenext_offset": ("RunValidation", "MoveNext"),
    # History, 1.1.5.1.47510: 0xEE2660 carried no PDB global func symbol at all
    # (nearest was EFT.MovementContext::get_MoveDiagonalInertia at 0xEE2630,
    # 0x30 earlier). Its identity came from dump.cs's GenericInstMethod table,
    # the ISIL call site (rcx=builder/rdx=stateMachine) and IDA (192-byte
    # function start). It was previously mapped here to ("BEClient",
    # "CreateInstance"), which did not exist then -- that name came from
    # CreateInstanceResult, the return type of BEClient::Start.
    #
    # 1.2.0.0.47888 changed both facts: the Start<<...RunValidation...>>
    # instantiation now has a PDB global symbol (load_be_client above), and a
    # real BattlEye.BEClient::CreateInstance exists at 0x18D0F70 -- which is why
    # the load_be_client entry can no longer use the CreateInstance name.
}


def parse_pdb(path: Path) -> dict[str, str]:
    """Extract symbol RVAs from a PDB file."""
    pdb = purelypdb.parse(str(path))

    # Build section base map from the section header stream
    # Section numbers in PDB symbols are 1-based indices into the sections list
    section_bases: dict[int, int] = {}
    for stream in pdb.streams:
        if isinstance(stream, purelypdb.PDBSectionStream):
            for idx, sec in enumerate(stream.sections):
                section_bases[idx + 1] = sec.VirtualAddress
            break

    # Collect all function symbols from the global symbol stream
    symbols: dict[str, int] = {}
    for stream in pdb.streams:
        if not isinstance(stream, purelypdb.PDBGlobalSymbolStream):
            continue
        for name, data in stream.funcs.items():
            offset = data["offset"]
            segment = data["segment"]
            base = section_bases.get(segment, 0)
            symbols[name] = base + offset

    print(f"  Total symbols in PDB: {len(symbols)}")

    results = {}

    for symbol, (class_pattern, method_name) in SYMBOL_PATTERNS.items():
        # An explicit pattern must match its symbol, or nothing. Iterating a dict
        # and breaking on the first hit is order-dependent, and a too-broad
        # class_pattern will otherwise bind to whichever unrelated symbol happens
        # to come first in PDB order -- which is how this once resolved
        # run_validation_movenext_offset to 0x3FD55A0.
        # The method slot also accepts a generic instantiation "Name<...>": the
        # 1.2.0 PDB names e.g. AsyncTaskMethodBuilder::Start<<...d__10>>, and the
        # exact-form comparison alone can never match that.
        matches = [n for n in symbols
                   if "::" in n.replace("$$", "::")
                   and (lambda m: m == method_name or m.startswith(method_name + "<"))(
                       n.replace("$$", "::").rsplit("::", 1)[-1].strip())
                   and class_pattern in n]
        if len(matches) > 1:
            # Report and resolve nothing. A first-match-wins scan here silently
            # binds to whichever unrelated symbol PDB iteration happens to yield
            # first, which is how this tool resolved
            # run_validation_movenext_offset to 0x3FD55A0
            # (AnticheatValidationOperation::RunValidation, the state machine's
            # builder method) instead of the correct 0x1B76260
            # (AnticheatValidationOperation+<RunValidation>d__10::MoveNext).
            print(f"  {symbol}: AMBIGUOUS -- {len(matches)} PDB symbols match "
                  f"{class_pattern}::{method_name}: "
                  f"{', '.join(sorted(matches)[:3])}"
                  f"{'...' if len(matches) > 3 else ''}")
            continue
        if not matches:
            print(f"  {symbol}: NOT FOUND")
            continue
        pdb_name = matches[0]
        rva_str = f"0x{symbols[pdb_name]:X}"
        results[symbol] = rva_str
        print(f"  {symbol}: {rva_str} (from {pdb_name})")

    return results


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdb", help="path to GameAssembly.pdb")
    parser.add_argument("--output", default="rvas.json", help="output JSON path")
    args = parser.parse_args()

    pdb_path = Path(args.pdb)
    if not pdb_path.exists():
        print(f"ERROR: file not found: {pdb_path}")
        return 2

    print(f"Parsing: {pdb_path}")
    results = parse_pdb(pdb_path)

    if not results:
        print("ERROR: no symbols found")
        return 1

    output_path = Path(args.output)
    output_path.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(f"\nResults saved to: {output_path}")
    print(f"Matched {len(results)}/{len(SYMBOL_PATTERNS)} symbols")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
