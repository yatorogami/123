#!/usr/bin/env python3
"""One-shot: fetch Inter 4.1 + JetBrains Mono 2.304 (both SIL OFL) and report
their REAL glyph coverage against the ranges menu.cpp actually asks for.

Both ship as release zips, so this pulls the zip, keeps the three faces the
menu needs plus the OFL text, and drops the rest -- 39 MB of the Inter zip is
variable-font sources this project has no use for."""
import io
import pathlib
import sys
import urllib.request
import zipfile

REPO = pathlib.Path(__file__).resolve().parent.parent
DEST = REPO / "TarkovAddons" / "assets" / "fonts"

ZIPS = {
    "inter": "https://github.com/rsms/inter/releases/download/v4.1/Inter-4.1.zip",
    "jbmono": "https://github.com/JetBrains/JetBrainsMono/releases/download/v2.304/JetBrainsMono-2.304.zip",
}

# (zip key, member-name predicate, destination filename)
WANTED = [
    ("inter", "Inter-Regular.ttf", "Inter-Regular.ttf"),
    ("inter", "Inter-SemiBold.ttf", "Inter-SemiBold.ttf"),
    ("inter", "OFL.txt", "Inter-OFL.txt"),
    ("jbmono", "JetBrainsMono-Regular.ttf", "JetBrainsMono-Regular.ttf"),
    ("jbmono", "OFL.txt", "JetBrainsMono-OFL.txt"),
]

FALLBACKS = {
    "inter": "https://github.com/rsms/inter/releases/download/v4.1/Inter-4.1.zip",
    "jbmono": "https://github.com/JetBrains/JetBrainsMono/releases/download/v2.304/JetBrainsMono-2.304.zip",
}


def fetch_zip(key: str) -> bytes:
    for url in (ZIPS[key], FALLBACKS[key]):
        try:
            with urllib.request.urlopen(url, timeout=180) as r:
                return r.read()
        except Exception as exc:  # noqa: BLE001
            print(f"  {key}: {url} failed: {exc}")
    sys.exit(f"could not download the {key} zip")


DEST.mkdir(parents=True, exist_ok=True)
blobs = {}
for key in ZIPS:
    print(f"fetching {key}...")
    blobs[key] = fetch_zip(key)
    print(f"  {len(blobs[key]):,} bytes")

for key, member, out_name in WANTED:
    dest = DEST / out_name
    if dest.exists() and dest.stat().st_size > 500:
        print(f"  have {out_name} ({dest.stat().st_size:,} bytes)")
        continue
    zf = zipfile.ZipFile(io.BytesIO(blobs[key]))
    names = [n for n in zf.namelist() if n.endswith("/" + member) or n == member]
    if not names:
        # OFL text is sometimes named differently; show what is there.
        near = [n for n in zf.namelist() if member.split(".")[0].lower() in n.lower()][:8]
        print(f"  {member} NOT in the {key} zip; near matches: {near}")
        continue
    data = zf.read(names[0])
    dest.write_bytes(data)
    print(f"  wrote {out_name}: {len(data):,} bytes  (from {names[0]})")