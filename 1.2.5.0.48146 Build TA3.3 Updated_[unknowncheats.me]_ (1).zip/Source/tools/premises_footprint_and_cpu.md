# Premises about the mod's own cost: memory and CPU

Written 2026-10-15, on the way to answering "is the mod why EFT commits 40 GB?".
Every number here was **measured**, not derived from `sizeof()`, and each entry
says how to re-measure it. Where something is not measured, it says so and says
what would settle it.

This file exists because the alternative was arithmetic from struct sizes, and
that is the exact failure mode this project keeps getting hit. Two of the three
bugs fixed while producing this document were that shape:

* a `PERFORMANCE_INFORMATION` struct read with the MSDN sample layout (14 DWORDs,
  56 bytes) when the real one is 104 bytes with 64-bit fields — plausible numbers,
  silently wrong;
* a sentinel of `-1.0` standing in for "no previous sample" on a value that is
  itself signed, so every **falling** commit printed `n/a (first)`.

Both were caught by checking output, not by reading code. Treat every figure below
as measured-on-this-machine unless it says otherwise.

---

## 1. How to reproduce all of this

The memory and CPU constants come out of the native harness:

```powershell
tools\harness\run_windows.bat
```

and land in the `footprint_cost` section. One run prints both premises plus their
negative controls. The case is
[test_footprint_cost.cpp](../tools/harness/test_footprint_cost.cpp); it is the 23rd
native case.

The in-game numbers come out of the deployed DLL's own log, on a 15-second tick:

```powershell
Select-String -Path "C:\Battlestate Games\BsgLauncher\tarkovaddons_log.txt" -Pattern 'mem\[\d+\]|mod-footprint'
```

Two lines per tick:

```
mem[n] t=Ts commit=NNNN MB (R resident, P paged out) rate=±R MB/min  faults=N  sys=S% of L MB
mod-footprint: >=K KB of M MB (P%)  field_cache=… method_cache=… fixed_tables=…  (FLOOR: …)
```

`commit` is the process's **private commit charge**. `resident` is its working set.
`paged out` is `commit − resident`, i.e. committed memory that is **not in RAM**.
`faults` is cumulative since process creation and does **not** split minor from
major, which is the single biggest limitation on it (see §5).

---

## 2. Memory premise: what one cache entry really costs

```
node cost      116.4 bytes/entry      (1.6x sizeof(MetaKey) = 72)
bucket cost     18.74 bytes/bucket     (4,913,152 bytes for 262,144 buckets)
```

**How it is calculated.** `total = bucket_array + n × node`. Two points are taken
inside one bucket epoch and the node cost is the **slope**:

```
node = (bytes(n2) − bytes(n1)) / (n2 − n1)
buckets = bytes(n1) − n1 × node
per-bucket = buckets / bucket_count
```

`bytes(n)` is `PROCESS_MEMORY_COUNTERS_EX::PrivateUsage` from
`K32GetProcessMemoryInfo`, taken after a settle loop so the first touch of a heap
segment is not charged to the map.

**Why two points.** One measurement cannot separate the bucket array from the
nodes, and a single delta carries whatever the process did in the background during
the call.

**Why one bucket epoch.** MSVC's `unordered_map` grows buckets by powers of two and
rehashes once `size` passes `bucket_count`, so each epoch holds at most
`bucket_count` elements. The first attempt used n1=200,000 and n2=400,000, which
straddles the 262,144 → 524,288 rehash and reported **137 bytes/entry** for what
was really nodes *plus a doubled bucket array*. Plausible and wrong. The case now
asserts `buckets1 == buckets2`; that assertion is what turns this class of error
into a failure.

**Negative control.** Fill a map, destroy it, assert the memory comes back:

```
held 32.8 MB, released on destroy 32.4 MB
```

Without this, "the map grew by 32 MB" and "the process grew by 32 MB for an
unrelated reason" are indistinguishable, and the node cost would be a coincidence.

**Why the overhead is 1.6x and not ~1.0x.** `MetaKey` is 72 bytes. A heap node is
that plus a next pointer, an 8/16-byte CRT header and alignment rounding.

**What would falsify this.** A different allocator, a different MSVC, or an x64
build with `_ITERATOR_DEBUG_LEVEL` set would all move it. The constants are used
only as multipliers in `module/footprint.h` and the reporter prints a *ratio*, so
even a materially wrong constant leaves the conclusion intact — but re-run the case
rather than trusting a number copied out of this file.

---

## 3. CPU premise: what an inert zone costs

```
gate           0.450 ns/call
169 live zones @ 60 fps  ->  0.076 us/frame  ->  0.0008% of one core
```

**How it is calculated.** `TA_ZONE_N` expands to a `tracy::profiler::Zone` whose
constructor opens with `if (!running()) return;`. That is one acquire load and a
branch. The harness times 20,000,000 iterations of exactly that and divides.

**The control that makes it a measurement.** It asserts
`20,000,000 of 20,000,000 took the early-out`. A compiler that hoisted the load out
of the loop would otherwise produce a number for a loop that does not exist.

**Why the flag is not `volatile`.** The point is what the compiler emits when the
flag is genuinely false and hoisting is legal. `volatile` would force a load the
shipping build does not need and inflate the answer.

**The product inputs, named rather than buried.** 169 live zone names is what
`tools\zone_gap.py --list-zones` reports for this tree (it strips comments, so it
excludes two literal `TA_ZONE_N` mentions that are not live code). 60 fps is a round
frame rate. Both are assumptions, and both are inputs to the percentage — change
either and the percentage moves.

**What this does NOT include, stated plainly.** The gate is not the whole macro.
The 11 `TA_ZONE_SITE` sites run `compose_site()` **unconditionally**, before the
constructor is entered, and then `strlen` the composed `"name@site"` string.
`compose_site` steady-state is two pointer compares on a `thread_local` hit. Three
of those 11 are in `skeleton_visibility.h::get_bifacial_position`, which that file's
own notes put at roughly 20 calls per player per tick. So instrumentation in this
tree is **not uniformly free**, and the sites where it is not are enumerated rather
than averaged away.

**What would falsify this.** A different CPU, or `/O1`/`/Od`. It is a
lower-bound-shaped number, so the honest reading is "small", not "zero".

---

## 4. What the mod actually holds

The reporter (`module/footprint.h`) sums the containers with no eviction policy:

| Structure | Size | Policy |
|---|---|---|
| `field_cache()` | `unordered_map<MetaKey, FieldInfo*>` | **no eviction** — saturates on the type universe |
| `method_cache()` | `unordered_map<MetaKey, const MethodInfo*>` | **no eviction** — same |
| `probe_region_slots` | 4096 × 16 B = 64 KB | fixed array, cleared per transit |
| `optics::lens` range table | 4096 × 16 B = 64 KB | fixed array, cleared per transit |
| `ai_limit_first_seen_ms_` | `unordered_map<Il2CppObject*, ULONGLONG>` | **has eviction** — erase loop + 3 clear sites |
| container-chams registry | 572 live in the 2026-10-15 session | cleared at boundary |
| item-chams registry | ~1269 loot in the same session | bounded by live loot |

**The two metadata caches are the only structures here with no eviction policy.**
They are keyed on `(class, name)`, so they saturate on the game's type universe
rather than growing without bound — but "saturates eventually" is not a bound, and
they are the thing to watch if this file is revisited.

### The reported number is a FLOOR, deliberately

The output says `>=` and names what it excludes:

```
mod-footprint: >=1234 KB of 31500 MB (0.004%)  …  (FLOOR: chams+localisation+render NOT included)
```

Not covered: the chams registries, the localisation caches, and anything the render
path allocates. Those are bounded by live game objects and so are expected to be
small, but **expected** is not **measured**. A partial answer presented as a total
is the failure this document exists to prevent, so the word is in the output and
not only in the comment.

---

## 5. The process premise: what EFT is doing

From session pid 9004, 2026-10-15, 58 minutes, 194 samples (valid `sys%` only):

```
commit   min 7,341   max 39,736   mean 29,155   MB
sys%     min 44      max 94
resident floor 629 MB against 23,801 MB committed -- 97% of it on disk
page faults  2.8M -> 48.7M  =  12,724/sec sustained = ~50 MiB/s if all were major
```

**It is a sawtooth, not a leak.** Commit reaches 93–94%, falls to 71% at
t≈1929 s, then climbs again. A falling commit is what distinguishes the two, and
the reporter now prints it as a negative rate rather than discarding it — which is
precisely what the `n/a (first)` bug was doing.

**The limit the peak is measured against.** System commit limit ~61,440 MB (RAM
31.9 GiB + a 32 GiB pagefile). The pagefile is fixed at 32768/32768 MB with
`AutomaticManagedPagefile=False`; at 94% the safety margin is thin but the fixed
size is not itself the cause — removing it would leave a 31.9 GiB limit against the
same load, which is worse.

**The biggest honest gap in §5.** `PageFaultCount` does not split minor from major.
~50 MiB/s is an upper bound that assumes every fault is a disk read, and the true
figure is unknown. Separating them would need `GetSystemTimes`/`QueryWorkingSet`
or an ETW working-set trace, which is a real piece of work and is the first thing
to do if the paging cost matters.

**The earlier crash is consistent with this but does not prove it.** The 11:47
crash (pid 7536) reported `commit=40,632 MB` with `working_set=17,155 MB`, i.e.
~23 GB paged out, and the system was near the ceiling. A failed allocation under
that pressure is expected. That the *fault* was a null-object write in
`GameAssembly.dll` (`mov [rcx+0x10], rax`, `rcx=0`, in
`SettingsManager.SettingsWithProvider.PostLoadDelegate<object>..ctor`) is a
separate observation, and the link between the two is **not** established.

---

## 6. What is deliberately not claimed

* **Tracy's CPU cost while running.** §3 is the *inert* cost. The cost with a
  client attached is real and is only obtainable from a capture — `tracy_traces/`
  holds several (`15.10_good_2.tracy` is 578 MB). No figure is quoted here.
* **Tracy's memory inside EFT.** A per-thread `rpmalloc` heap does live in the
  game process, and the 08:54 crash faulted inside `tracy::rpmalloc_allocate`
  returning null. Its size was never sampled.
* **That the mod is innocent.** What is established is that its *measured*
  footprint is a rounding error against 31–40 GB, and that its *inert* CPU cost is
  0.0008% of a core. That is not the same as "we did not cause the crash" — see
  §5's last paragraph.