#!/usr/bin/env python3
"""Scan first-party C++ for copy/paste duplication.

    python tools/dup_scan.py                     # whole tree, >=10 duplicated lines
    python tools/dup_scan.py --min-lines 25      # only big offenders
    python tools/dup_scan.py --renamed           # structure-only, ignores identifiers
    python tools/dup_scan.py TarkovAddons/module # just some roots
    python tools/dup_scan.py --format json       # machine-readable

Exit 0 = nothing above the threshold, 1 = duplication found,
2 = it checked nothing (bad root, unreadable tree, or an empty file set).

WHAT THIS IS, AND WHAT IT IS NOT
--------------------------------

It is a token-level clone detector, in the PMD-CPD family: lex each file into
tokens, normalize literals away, hash every fixed-length window of tokens,
and report windows that occur in two places. Nothing here understands C++.
That is deliberate -- a parser-level tool would have to model the macro-heavy,
PCH-heavy, `windows.h`-heavy way this tree is written, and every one of those
is a place where a parser gives up.

The matching is a rolling polynomial hash over token *ids*, used only to
bucket candidates. Every candidate bucket is then confirmed by comparing the
actual tokens, so a hash collision cannot invent a clone. Nothing is reported
that was not re-read and found equal.

LIMITS, STATED PLAINLY
----------------------

* **It does not preprocess.** `#ifdef`/`#else` branches are lexed as written,
  so two mutually exclusive branches of the same `#ifdef` can be reported as
  a clone. That is arguably the right answer anyway (a fix applied to one
  branch and not the other is a real bug), but it is a source of noise.
* **Macros are not expanded.** A block built from a project macro will not
  match a hand-expanded copy of the same code.
* **It skips `TarkovAddons/include/`**, which is where `common.h` lives. That
  header pulls in windows.h, the 38 standard headers and nlohmann/json --
  ~250 MB of preprocessed surface. Scanning it would take minutes and report
  the C++ standard library back to you. The consequence to know about: the
  `#include "common.h"` that opens all 82 translation units is invisible here.
* **Vendored trees are skipped**: `external/`, `il2cpp/libil2cpp/`,
  `TarkovLauncherBypass/libs/`. Their duplication is upstream's problem.
* **Embedded data is skipped**: `gui/menu/resources.h` and
  `assets/asset_bundles.h` are base64/byte-array blobs, not code.

Every skip is counted and printed. A scan that skipped more than it scanned
is a scan whose output should not be believed, so the counts are on stdout
rather than in a log nobody reads.

WHY THIS EXISTS
---------------

CMake is the reason to reach for a tool like this, but it is not the reason
this file exists. CMake builds a dependency graph; it has no notion of code
content and cannot find a repeated block. What CMake does buy is
`compile_commands.json` (Ninja exports it, the Visual Studio generator does
not), which is the input every clang-based tool needs. That is the whole of
the benefit, and it is a real one -- see tools/run_tidy.ps1.
"""

from __future__ import annotations

import argparse
import json
import pathlib
import re
import sys
from collections import defaultdict

# ---------------------------------------------------------------------------
# Roots and what to leave alone
# ---------------------------------------------------------------------------

REPO = pathlib.Path(__file__).resolve().parent.parent

DEFAULT_ROOTS = ("TarkovAddons", "TarkovLauncherBypass", "shared")

SUFFIXES = {".c", ".cc", ".cpp", ".h", ".hpp", ".inl", ".ipp"}

# Directory names skipped anywhere in the path, with the reason printed.
SKIP_DIRS = {
    "external": "vendored third party (imgui, safetyhook, tracy, nlohmann/json)",
    "libil2cpp": "Unity-generated, vendored",
    "libs": "vendored (TarkovLauncherBypass/libs/ntdll.h)",
    "include": "common.h -- windows.h + 38 std headers + nlohmann/json",
    "GameDump": "decrypted game dump, gitignored",
    "ISIL-references": "reference material, gitignored",
    "build": "build tree",
    "out": "build output",
    "x64": "MSVC intermediate tree",
    ".git": "git",
    ".pytest_cache": "pytest",
    "__pycache__": "python",
    "node_modules": "node",
}

# Individual files that are data, not code.
SKIP_FILES = {
    "resources.h": "embedded icon data (1.6 MB of base64)",
    "asset_bundles.h": "embedded Unity asset bundle (byte array)",
}

# ---------------------------------------------------------------------------
# Lexer
# ---------------------------------------------------------------------------

_CPP_KEYWORDS = frozenset(
    """
    alignas alignof asm auto bool break case catch char char8_t char16_t char32_t
    class concept const consteval constexpr constinit const_cast continue co_await
    co_return co_yield decltype default delete do double dynamic_cast else enum
    explicit export extern false float for friend goto if inline int long mutable
    namespace new noexcept nullptr operator private protected public register
    reinterpret_cast requires return short signed sizeof static static_assert
    static_cast struct switch template this thread_local throw true try typedef
    typeid typename union unsigned using virtual void volatile wchar_t while
    """.split()
)

_MASTER = re.compile(
    r"""
      (?P<ws>[ \t\r\f\v]+)
    | (?P<lcomment>//[^\n]*)
    | (?P<bcomment>/\*.*?\*/)
    | (?P<rawstring>R"(?P<rdelim>[^ (\\\t\n\v\f\r]{0,16})\(.*?\)(?P=rdelim)")
    | (?P<vstring>@"(?:[^"\n]|"")*")
    | (?P<string>"(?:\\.|[^"\\\n])*")
    | (?P<char>'(?:\\.|[^'\\\n])*')
    | (?P<number>(?:\d|\.\d)(?:[0-9a-zA-Z_']|\.(?=\d))*(?:[eEpP][+-][0-9]+)?)
    | (?P<directive>\#\s*[A-Za-z_]+)
    | (?P<ident>[A-Za-z_$][A-Za-z0-9_$]*)
    | (?P<op><<=|>>=|\.\.\.|->\*|\.\*|<=>|->|\+\+|--|<<|>>|<=|>=|==|!=|&&|\|\|
            |\+=|-=|\*=|/=|%=|&=|\|=|\^=|::|[-+*/%&|^!<>=?:;,.()\[\]{}~@\\#])
    | (?P<other>[\s\S])
    """,
    re.VERBOSE | re.DOTALL,
)


def _at_line_start(text: str, pos: int) -> bool:
    ls = text.rfind("\n", 0, pos) + 1
    return not text[ls:pos].strip()


def _logical_line_end(text: str, pos: int) -> int:
    """End of the logical line starting at `pos`, following `\\` continuations.

    Returns the offset of the terminating newline, or len(text).
    """
    while True:
        nl = text.find("\n", pos)
        if nl == -1:
            return len(text)
        k = nl - 1
        while k >= 0 and text[k] in " \t\r":
            k -= 1
        if k >= 0 and text[k] == "\\":
            pos = nl + 1
            continue
        return nl


def tokenize(text: str, renamed: bool = False) -> list[tuple[str, int]]:
    """Lex C++ into ``(normalized_token, line)`` pairs. 1-based lines.

    Normalization, which is the only "understanding" here:
      * comments and whitespace are dropped entirely
      * string / char / raw-string literals all collapse to ``STR`` / ``CHR``
      * every numeric literal collapses to ``NUM`` -- so ``0x40``, ``64`` and
        ``64.0f`` match, which is what you want when the duplicate is
        "same code, different constant"
      * a preprocessor directive collapses to ``#PP:<NAME>``, keeping the
        directive but dropping its condition AND the rest of the line, so
        ``#ifdef A`` and ``#ifdef B`` compare equal. The whole logical line is
        consumed, backslash continuations included -- consuming only ``#ifdef``
        leaked the condition back in as ordinary identifiers, which
        tools/tests/test_dup_scan.py caught.
      * with ``renamed=True`` every identifier that is not a keyword collapses
        to ``ID``, which finds structurally identical code that was renamed.
        That mode is much noisier and is off by default.
    """
    out: list[tuple[str, int]] = []
    pos = 0
    line = 1
    n = len(text)
    end = 0
    while pos < n:
        m = _MASTER.match(text, pos)
        if m is None:  # pragma: no cover - the `other` branch matches anything
            pos += 1
            continue
        kind = m.lastgroup
        if kind == "ws":
            line += m.group().count("\n")
        elif kind in ("lcomment", "bcomment"):
            line += m.group().count("\n")
        elif kind == "rawstring":
            out.append(("STR", line))
            line += m.group().count("\n")
        elif kind in ("vstring", "string"):
            out.append(("STR", line))
        elif kind == "char":
            out.append(("CHR", line))
        elif kind == "number":
            out.append(("NUM", line))
        elif kind == "directive":
            # Only a real directive when it opens the line. A '#' mid-expression
            # (rare, but legal after a macro expansion) is an operator.
            if not _at_line_start(text, m.start()):
                out.append(("#", line))
            else:
                out.append(("#PP:" + m.group()[1:].strip().upper(), line))
                # Swallow the rest of the logical line by hand. Doing it in the
                # regex needed a second capture group for the directive name,
                # and the numbered groups in this pattern are already
                # reassigned by the raw-string branch -- so group(2) was the
                # raw-string delimiter and `None`. Consuming the tail here is
                # both simpler and immune to that.
                end = _logical_line_end(text, m.end())
        elif kind == "ident":
            tok = m.group()
            out.append(("ID" if renamed and tok not in _CPP_KEYWORDS else tok, line))
        elif kind == "other":
            pass  # stray backslash continuation, stray '@', ...
        else:  # op
            out.append((m.group(), line))
        # A directive consumed more than the regex matched; everything else
        # consumed exactly the match. Block comments and raw strings span
        # lines too, so the line counter is advanced over whatever we took.
        end = max(end, m.end())
        if end > pos:
            line += text.count("\n", pos, end)
        pos = end
    return out


# ---------------------------------------------------------------------------
# Clone detection
# ---------------------------------------------------------------------------

_POLY = 1000003
_MASK = (1 << 64) - 1

# A bucket with more than this many hits is not a clone, it is a mass
# duplication (a generated table, a repeated macro). Capped rather than
# silently truncated -- oversized buckets are reported separately.
MAX_BUCKET = 96

# The default hash window, and the threshold below which a file is not worth
# comparing at all. Named so the tests can assert against the same number the
# tool uses rather than a copy of it.
DEFAULT_WINDOW = 50


def _is_data_table(tokens: list[tuple[str, int]], start: int, length: int) -> bool:
    """Is this run an aggregate initialiser rather than code?

    Needed because the first version of this tool reported `WorldModule.h`'s
    90-line `spawn_bot_roles_[]` array as the largest clone in the tree. Every
    entry lexes to the same `NUM , } , { NUM ,` sequence once comments are
    gone, so the array matches itself and wins. It is not duplicated logic,
    and burying the real copy/paste under it is worse than not running at all.

    Two rules, either sufficient:
      * no call parentheses and no control-flow keyword -- real code has at
        least one of those, an aggregate initialiser has neither
      * 60%+ of the tokens are literals -- a table of names or numbers, even
        if something wraps it in a call
    """
    run = tokens[start : start + length]
    toks = [t for t, _ in run]
    if any(t in _CONTROL for t in toks):
        return False
    if not any(t in ("(", ")") for t in toks):
        return True
    literals = sum(1 for t in toks if t in ("NUM", "STR", "CHR"))
    return literals * 5 >= len(toks) * 3


_CONTROL = frozenset(
    "if for while switch return goto case do else try catch co_await co_yield".split()
)


def _token_ids(tokens: list[tuple[str, int]], vocab: dict[str, int]) -> list[int]:
    ids = []
    for tok, _line in tokens:
        i = vocab.get(tok)
        if i is None:
            i = len(vocab) + 1
            vocab[tok] = i
        ids.append(i)
    return ids


def find_clones(
    per_file: dict[str, list[tuple[str, int]]],
    window: int = DEFAULT_WINDOW,
    max_buckets: int = MAX_BUCKET,
) -> tuple[list[tuple[str, int, str, int, int]], list[tuple[str, int]]]:
    """Return ``(clones, oversized)``.

    ``clones``  -- ``(file_a, tok_a, file_b, tok_b, length)`` maximal runs, kept
                   non-overlapping, longest first.
    ``oversized`` -- ``(token_repr, hits)`` for buckets too big to be a clone.
    """
    vocab: dict[str, int] = {}
    names = sorted(per_file)
    ids = {name: _token_ids(per_file[name], vocab) for name in names}

    buckets: dict[int, list[tuple[str, int]]] = defaultdict(list)
    for name in names:
        seq = ids[name]
        n = len(seq)
        if n < window:
            continue
        pow_w = pow(_POLY, window, 1 << 64)
        h = 0
        for k in range(window):
            h = (h * _POLY + seq[k]) & _MASK
        buckets[h].append((name, 0))
        for i in range(1, n - window + 1):
            h = ((h * _POLY + seq[i + window - 1]) - seq[i - 1] * pow_w) & _MASK
            buckets[h].append((name, i))

    oversized: list[tuple[str, int]] = []
    raw: dict[tuple[str, int, str, int], int] = {}

    for hits in buckets.values():
        if len(hits) < 2:
            continue
        if len(hits) > max_buckets:
            name, start = hits[0]
            oversized.append(
                (" ".join(t for t, _ in per_file[name][start : start + window]), len(hits))
            )
            continue
        for a in range(len(hits)):
            fa, sa = hits[a]
            seqa = ids[fa]
            for b in range(a + 1, len(hits)):
                fb, sb = hits[b]
                seqb = ids[fb]
                # The window itself is equal only if the hash lied; verify.
                if seqa[sa : sa + window] != seqb[sb : sb + window]:
                    continue
                lo = 0
                while sa - lo > 0 and sb - lo > 0 and seqa[sa - lo - 1] == seqb[sb - lo - 1]:
                    lo += 1
                hi = window
                while (
                    sa + hi < len(seqa)
                    and sb + hi < len(seqb)
                    and seqa[sa + hi] == seqb[sb + hi]
                ):
                    hi += 1
                start_a, start_b, length = sa - lo, sb - lo, hi + lo
                key = (fa, start_a, fb, start_b)
                if length > raw.get(key, 0):
                    raw[key] = length

    candidates = [(fa, sa, fb, sb, ln) for (fa, sa, fb, sb), ln in raw.items()]
    candidates.sort(key=lambda c: -c[4])

    # Greedy longest-first, rejecting anything overlapping an accepted run.
    taken: dict[str, list[tuple[int, int]]] = defaultdict(list)

    def free(fname: str, lo: int, hi: int) -> bool:
        for a, b in taken[fname]:
            if lo < b and a < hi:
                return False
        return True

    clones: list[tuple[str, int, str, int, int]] = []
    for fa, sa, fb, sb, ln in candidates:
        if not free(fa, sa, sa + ln) or not free(fb, sb, sb + ln):
            continue
        taken[fa].append((sa, sa + ln))
        taken[fb].append((sb, sb + ln))
        clones.append((fa, sa, fb, sb, ln))
    return clones, oversized


# ---------------------------------------------------------------------------
# Walking
# ---------------------------------------------------------------------------


def iter_sources(roots, skip_dirs=SKIP_DIRS, skip_files=SKIP_FILES):
    """Yield ``(path, reason)``-filtered source files; also tally the skips."""
    files: list[pathlib.Path] = []
    skipped: dict[str, list[str]] = defaultdict(list)
    seen: set[pathlib.Path] = set()

    for root in roots:
        rp = pathlib.Path(root)
        if not rp.exists():
            raise FileNotFoundError(f"root does not exist: {rp}")
        if rp.is_file():
            candidates = [rp]
        else:
            candidates = sorted(rp.rglob("*"))
        for p in candidates:
            if not p.is_file() or p.suffix.lower() not in SUFFIXES:
                continue
            try:
                rel_parts = p.relative_to(REPO).parts
            except ValueError:
                rel_parts = p.parts
            reason = None
            for part in rel_parts[:-1]:
                if part in skip_dirs:
                    reason = f"{part}/ -- {skip_dirs[part]}"
                    break
            if reason is None and p.name in skip_files:
                reason = f"{p.name} -- {skip_files[p.name]}"
            if reason is not None:
                skipped[reason].append(str(p))
                continue
            key = p.resolve()
            if key in seen:
                continue
            seen.add(key)
            files.append(p)
    return files, skipped


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("roots", nargs="*", help="files or directories (default: first-party roots)")
    ap.add_argument("--min-lines", type=int, default=10, help="report runs of >= N lines (default 10)")
    ap.add_argument("--window", type=int, default=DEFAULT_WINDOW, help="tokens per hash window (default 50)")
    ap.add_argument("--renamed", action="store_true", help="also ignore identifier names")
    ap.add_argument("--data", action="store_true", help="also list aggregate-table clones")
    ap.add_argument("--format", choices=("text", "json"), default="text")
    ap.add_argument("--list-files", action="store_true", help="print the scanned file list and exit")
    args = ap.parse_args(argv)

    roots = [pathlib.Path(r) for r in args.roots] or [REPO / r for r in DEFAULT_ROOTS]
    try:
        files, skipped = iter_sources(roots)
    except FileNotFoundError as exc:
        print(f"FAIL -- {exc}", file=sys.stderr)
        return 2

    if args.list_files:
        for f in files:
            print(f.relative_to(REPO) if REPO in f.parents else f)
        print(f"\n{len(files)} file(s)")
        return 0

    if not files:
        print("FAIL -- nothing was checked. No source files under the given roots,\n"
              "       so this is not a pass.", file=sys.stderr)
        return 2

    per_file: dict[str, list[tuple[str, int]]] = {}
    empty = 0
    for f in files:
        text = f.read_text(errors="replace")
        toks = tokenize(text, renamed=args.renamed)
        if len(toks) < args.window:
            empty += 1
            continue
        key = str(f.relative_to(REPO)) if REPO in f.parents else str(f)
        per_file[key] = toks

    total_tokens = sum(len(t) for t in per_file.values())

    if not per_file or total_tokens == 0:
        print("FAIL -- nothing was checked. Every file lexed to fewer tokens than\n"
              "       the hash window, so no comparison was possible.", file=sys.stderr)
        return 2

    clones, oversized = find_clones(per_file, window=args.window)

    reports = []
    for fa, sa, fb, sb, ln in clones:
        la, lb = per_file[fa], per_file[fb]
        span = la[sa + ln - 1][1] - la[sa][1] + 1
        if span < args.min_lines:
            continue
        a0, a1 = la[sa][1], la[sa + ln - 1][1]
        b0, b1 = lb[sb][1], lb[sb + ln - 1][1]
        reports.append(
            {
                "lines": span,
                "tokens": ln,
                "kind": "data" if _is_data_table(la, sa, ln) else "code",
                "a": {"file": fa, "start": a0, "end": a1},
                "b": {"file": fb, "start": b0, "end": b1},
                "same_file": fa == fb,
            }
        )
    reports.sort(key=lambda r: (-r["lines"], r["a"]["file"], r["a"]["start"]))

    if args.format == "json":
        print(
            json.dumps(
                {
                    "files_scanned": len(per_file),
                    "files_skipped_too_small": empty,
                    "tokens": total_tokens,
                    "window": args.window,
                    "min_lines": args.min_lines,
                    "renamed": args.renamed,
                    "oversized_buckets": len(oversized),
                    "clones": reports,
                    "code_clones": sum(1 for r in reports if r["kind"] == "code"),
                    "data_clones": sum(1 for r in reports if r["kind"] == "data"),
                },
                indent=2,
            )
        )
    else:
        code = [r for r in reports if r["kind"] == "code"]
        data = [r for r in reports if r["kind"] == "data"]
        print(
            f"scanned {len(per_file)} file(s), {total_tokens:,} token(s), "
            f"window={args.window}, min-lines={args.min_lines}"
            + ("  [renamed]" if args.renamed else "")
        )
        print(f"skipped {sum(len(v) for v in skipped.values())} file(s):")
        for reason, paths in sorted(skipped.items(), key=lambda kv: -len(kv[1])):
            print(f"  {len(paths):>4}  {reason}")
        if empty:
            print(f"  {empty:>4}  fewer tokens than the window (not compared)")
        print()
        if oversized:
            print(
                f"{len(oversized)} mass-duplication bucket(s) over {MAX_BUCKET} hits were\n"
                f"not compared. Almost always a repeated literal table, not logic.\n"
            )
        if not reports:
            print(f"OK -- no run of >= {args.min_lines} duplicated line(s)")
            return 0

        print(f"CODE: {len(code)} clone(s)")
        if not code:
            print("  (none)")
        for r in code:
            _print_clone(r)
        print()
        print(f"DATA: {len(data)} clone(s) -- aggregate tables, not logic")
        if args.data and data:
            for r in data:
                _print_clone(r)
        elif data:
            print(f"  {sum(r['lines'] for r in data):,} line(s) suppressed; "
                  f"re-run with --data to see them")
        print()

    return 1 if reports else 0


def _print_clone(r) -> None:
    a, b = r["a"], r["b"]
    head = f"  {r['lines']:>4} lines  "
    body = f"{' ' * len(head)}== "
    print(head + f"{a['file']}:{a['start']}-{a['end']}")
    print(body + f"{b['file']}:{b['start']}-{b['end']}")


if __name__ == "__main__":
    sys.exit(main())
