#!/usr/bin/env python3
"""Read an MSVC .map file and report what the linker already deduplicated.

    python tools/map_icf.py                      # newest .map under the tree
    python tools/map_icf.py --map path/to/x.map  # a specific one
    python tools/map_icf.py --unfolded           # the part that still costs bytes
    python tools/map_icf.py --min-symbols 3      # only groups of 3+
    python tools/map_icf.py --format json

Exit 0 = nothing worth reporting, 1 = duplication found,
2 = it checked nothing (no map file, unreadable, or no symbols parsed).

WHY THIS EXISTS
---------------
`tools/dup_scan.py` answers "how much text is written twice". It cannot answer
"how much of that costs anything in the artefact that ships", because it stops
at the source. This one starts from the other end.

MSVC's linker performs Identical COMDAT Folding: two functions that compile to
byte-identical machine code become ONE function at ONE address. So a clone in
the source may cost nothing at all in the DLL.

WHAT THE RAW NUMBERS LOOK LIKE, AND WHY THE DEFAULT IS NOT THE RAW NUMBER
------------------------------------------------------------------------
Grouping every symbol that shares an address on this tree gives 2,172 groups
and 20,203 symbols, which reads like an enormous win and means almost nothing.
Measured, that total is dominated by three categories that are not duplicated
logic and must never be presented as such:

  * `$unwind$...`        -- pdata/xdata unwind records. Two functions sharing
                            an address here often means "no unwind info for
                            either", not "identical code". 6,240 of them across
                            2,023 addresses, the largest single group being
                            1,299 symbols.
  * `?dtor$N@...`, `??_R0`..`??_R4`, `??_7` -- compiler-generated static-dtor
                            and vftable thunks. One per function, emitted by
                            the compiler, never written by a human.
  * `std::` / MSVC runtime template instantiations -- `_Func_impl_no_alloc`,
                            `_Xlength@?$vector@...`, `ImVector<D>`. Real code,
                            but not OURS; folding it is the linker's job and
                            merging it in source would be wrong.

After excluding those three categories, the honest figure on this tree is
**108 fold groups, 407 first-party symbols, 299 duplicate copies already
removed by the linker**. That is the number that means something, and it is
what this tool prints by default. `--all` prints the unfiltered view, clearly
labelled, for when the raw total is what you want.

THE HONEST CONCLUSION, WHICH CUTS AGAINST DEDUPLICATION
-------------------------------------------------------
Almost everything the linker folds is templates and compiler thunks. Of what
survives, the largest first-party group is 92 symbols, and it is not one piece
of logic written twice either -- 76 of them are empty per-module virtual
overrides (`draw_overlay` 24, `application_update` 20, `init` 19,
`gameworld_update` 13), and the rest are `operator delete` plus a tail of
one-off no-op stubs. `draw_menu_extra_before_values`, named in an earlier
version of this note as the largest hand-written group at one hook per module,
does not hold on this tree: 5 modules override it, 6 symbols carry the name in
the map, and all 5 fold. Read these counts as a reading of one `.map`: two
builds ten minutes apart, differing only by a reordered declaration, measured
107 and 113 groups.

That is the finding that should change a plan: for this codebase the
duplication that costs *bytes* is small and mostly trivial, and `dup_scan`'s
clone list is overwhelmingly maintainability debt rather than a size problem.
Merging the biggest `dup_scan` finding will not make the DLL smaller.

WHAT THIS IS NOT
----------------
It is not a clone detector. It never reads the source, so it cannot find a
duplicate the compiler encoded differently, and it cannot say *where in the
source* a folded pair came from -- only which object files and mangled names.
Use dup_scan to find the source; use this to decide whether fixing it changes
the binary.

LIMITS, STATED PLAINLY
----------------------
* **It reads the map, not the binary.** The map is emitted by the linker and is
  authoritative for address layout, but a stale .map beside a newer DLL
  describes a DLL that no longer exists. The header timestamp is printed so
  that is visible rather than assumed.
* **Folding is decided on machine code, not intent.** Two functions can fold
  while being semantically distinct. A folded group is a size fact, not an
  accusation, and is reported as such.
* **`<absolute>` and segment `0000:` rows are excluded** -- they are unplaced
  statics, and counting them would invent a huge fold group at address 0.
* **A symbol listed in both `Publics by Value` and `Static symbols` is one
  symbol**, de-duplicated by (rva, name, object).
* **Classification is by mangled-name pattern and is approximate.** The
  std-library filter is a regex over names, not a linker-aware analysis; it
  will both over- and under-include. It is a filter to make the number
  readable, and `--all` is one flag away when a filter is wrong.

THE MAP FORMAT, AS MEASURED
---------------------------
Four line shapes, confirmed against the real 44,936-line Prod map rather than
assumed from documentation:

    4 fields   0000:00000000  __AbsoluteZero  0000000000000000  <absolute>
    5 fields   0001:00059380  DllMain         000000018005a380  f  dllmain.obj
    6 fields   0001:0003ddc0  ?find_export...? 000000018003ddc0 f  i  dllmain.obj
    12 fields  ...  f  i  *  CIL  library  *:*  CIL  module   (COMDAT group)

The trailing fields after the RVA are decoration: a type char, a static/public
char, then `Lib:Object`. Taking "the last field is the object" is wrong for the
12-field COMDAT rows, where the *library* precedes `*:*` and the object is
after it. That case is recognised explicitly.

Every exclusion is counted and printed. A scan that skipped more than it
parsed is a scan whose output should not be believed.
"""

from __future__ import annotations

import argparse
import collections
import json
import pathlib
import re
import sys

REPO = pathlib.Path(__file__).resolve().parent.parent

_SEGOFF = re.compile(r"^[0-9a-f]{4}:[0-9a-f]{8}$")
_RVA = re.compile(r"^[0-9a-f]{16}$")

# Unplaced statics. Counting them would invent a fold group at address 0.
_UNPLACED_SEGMENT = "0000"

# Imported libraries, by the prefix of the `Lib:` field.
SKIP_LIBS = ("msvcprt", "ucrt", "vcruntime", "api-ms-", "MSVCP", "VCRUNTIME")

# Compiler-emitted symbols. Present in the map, never written by a human, and
# structurally guaranteed to share addresses. See module docstring.
_GENERATED_PREFIXES = (
    "$unwind$",     # pdata/xdata unwind records
    "$bond$",       # CFG bonding
    "$chain$",      # EH state chains
    "$stateUnwindMap$",
    "$cppxdata$",   # static-init tables
    "$ip2state$",   # static-init tables
    "$LN",          # compiler line-number labels; not functions at all
    "?dtor$",       # static/thread destructors
    "??_R0", "??_R1", "??_R2", "??_R3", "??_R4",   # vftable/vbase thunks
    "??_7",         # vftable itself
    "?__",          # MSVC internal helpers
)

# Entities that are library code no matter which scope they appear in.
# These match on the *name entity* (the part before the first `@`), because a
# std free function or a vendored type puts its identity there:
#   ?_Xlength@?$vector@DV?$allocator@D@std@@@std@@CAXXZ   -> _Xlength
#   ??1?$ImVector@D@@QEAA@XZ                              -> ImVector<double>
# Names that are library code regardless of the scope they appear in. These
# match the ENTITY (the identifier before the first `@`), because a std free
# function or a vendored type puts its identity there:
#   ?_Xlength@?$vector@...   -> _Xlength
#   ??1?$ImVector@D@@...      -> ?$ImVector (template type, marker `?$` kept)
_LIBRARY_ENTITIES = re.compile(
    r"^_Xlength$|^_Xsize$|^_Xempty$|^_Unchecked"        # MSVC std internals
    r"|_Func_impl|^_Hash_vec|^_List_|^_Vector_|^_Hash_"
    r"|\?\$fill@|\?\$equal@|\?\$count"
    r"|ImVector|ImChunkStream|ImGuiTableSettings|ImGuiWindowSettings"
    r"|NewWrapper"
)

# SCOPE-owned library code. The OWNING SCOPE of a mangled name is the run of
# identifier components after the first `@`, up to (not including) the point
# where the symbol's own template-argument list begins. It is what decides
# ownership:
#   ?_Get@?$_Func_impl_no_alloc@...std@@   -> owner is ?$_Func_impl_no_alloc
#   ??3@YAXPEAXUImNewWrapper@@0@Z          -> owner is YAXPEAXUImNewWrapper
#   ??_Gexception@detail@json_abi@nlohmann -> owner is detail@json_abi@nlohmann
#
# ANCHORED TO THE OWNER, NEVER TO THE WHOLE NAME. An earlier version searched
# for `std@@` anywhere in the scope, which also matches inside a PARAMETER type
# -- so it reclassified `IntSliderEditableValue::set(std::string const&)`, a
# real `dup_scan` clone, as library code and silently deleted a finding.
_LIBRARY_SCOPES = re.compile(
    r"std$|^__p\d|^__vcpp|^nlohmann$|^detail@json_abi|^ImVector$|^ImChunkStream$"
    # A template-id owner (`?$vector`, `?$_Func_impl_no_alloc`, `U?$pair`) is
    # library when its arguments reach `std@@`. Anchored to the OWNER, so the
    # `std@@` of a PARAMETER inside OUR scope -- `IntSliderEditableValue::set` --
    # is never reached: the owner walk stops before the parameter list.
    r"|^[\w$?!]*(vector|basic_string|allocator|unordered_map|shared_ptr|list|"
    r"pair|deque|_Hash_vec|_List_|_Vector_|_Alloc_construct_ptr|atomic)@.*std@@"
    r"|^[\w$?!]*ImVector@"
    r"|^[\w$?!]*ImChunkStream@"
    # Any remaining scope chain that reaches `std@@` / `nlohmann@@` THROUGH a
    # template argument (`U?$output_adapter_protocol@D@detail@json_abi@nlohmann`).
    r"|std@@|nlohmann@@"
)


def _owning_scope(name: str) -> str:
    """The scope/entity that owns a mangled symbol, as a `@`-joined string.

    The first `@` separates the leaf name from its scope. The scope is then
    the leading run of plain identifier components -- ``detail@json_abi@nlohmann``
    -- stopping at the first component that introduces the symbol's own
    template arguments (``V...``, ``P...``, a second ``@@``) or a parameter.

    Kept as a small explicit walk rather than a regex because the boundary is
    the whole point and a regex that gets it subtly wrong is how the
    IntSliderEditableValue finding went missing.
    """
    _, _, scope = name.partition("@")
    parts = scope.split("@")

    # `??1`, `??$`, `?$` before the first `@` are the access/prefix operators
    # (`??1`=destructor, `??$`=template, `?`=qualified). Strip them so the
    # first real component is seen.
    if parts and parts[0].startswith("?"):
        head = parts[0].lstrip("?")
        # A `?$T` here IS the owner (a template type): `?_Xlength@?$vector@...`
        parts = [head] + parts[1:]

    out = []
    for i, part in enumerate(parts):
        if not part:
            break
        if part[0] in "?VAPU$":
            # `U` is a user-defined template ARGUMENT (`?$shared_ptr<U T@...>`)
            # and `V`/`P` a function argument list. Neither is an owning scope.
            # `??1?$_Hash_vec@V?$allocator@...@std@@` is a std CONTAINER
            # destructor with no owning scope of ours, so report the whole
            # remainder and let `_LIBRARY_SCOPES` decide -- `std@@` reached
            # through the template arguments is what marks it library code.
            if not out:
                return "@".join(parts[i:])
            break
        if not (part[0].isalpha() or part[0] == "_"):
            break
        out.append(part)
    return "@".join(out)


def classify(name: str) -> str:
    """Return ``generated``, ``stdlib`` or ``first_party`` for a mangled name.

    Two rules, and the boundary between them is the whole difficulty:

      * the ENTITY -- the identifier before the first `@` -- decides when it is
        a library type or helper (`_Xlength`, `ImVector<double>`);
      * the SCOPE -- everything after the first `@` -- decides when the symbol
        is enclosed in library code.

    Negative control for the entity rule: `?set@IntSliderEditableValue@@UEAAX
    AEBV?$basic_string@DU?$char_traits@D@std@@...` is OUR code that happens to
    take a `const std::string&`. Its entity is `set`, its owning scope is
    `IntSliderEditableValue`, and `std@@` appears only inside a parameter type
    -- so a rule that searches the whole name for `std@@` hides it. Conversely
    `?_Xlength@?$vector@DV?$allocator@D@std@@@std@@CAXXZ` must be caught, and
    its owning scope `?$vector@...` is a template type, which the scope walk
    deliberately stops before -- the entity `_Xlength` is what catches it.
    """
    if name.startswith(_GENERATED_PREFIXES):
        return "generated"
    entity, _, _ = name.partition("@")
    if _LIBRARY_ENTITIES.search(entity):
        return "stdlib"
    scope = _owning_scope(name)
    if scope and _LIBRARY_SCOPES.search(scope):
        return "stdlib"
    return "first_party"


def parse_map(path: pathlib.Path) -> tuple[dict[int, list[dict]], dict[str, int]]:
    """Parse a linker .map into ``(rva -> [symbol...], skipped counts)``."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        print(f"FAIL -- cannot read map file: {exc}", file=sys.stderr)
        raise SystemExit(2) from None

    symbols: dict[int, list[dict]] = collections.defaultdict(list)
    skipped: collections.Counter[str] = collections.Counter()
    seen: set[tuple[int, str, str]] = set()

    section = "(preamble)"
    for lineno, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if s.startswith("Publics by Value"):
            section = "publics"
            continue
        if s == "Static symbols":
            section = "static"
            continue

        f = s.split()
        if len(f) < 4 or not _SEGOFF.match(f[0]) or not _RVA.match(f[2]):
            continue

        seg, name, rva_hex, tail = f[0], f[1], f[2], f[3:]

        # COMDAT rows carry `... * CIL <library> *:* CIL <module>`; the object
        # is AFTER `*:*`. Everything else, the object is the last field.
        if "*:*" in tail:
            ci = tail.index("*:*")
            obj = tail[ci + 2] if ci + 2 < len(tail) else tail[-1]
        else:
            obj = tail[-1]

        # ORDER MATTERS. 252 of the CRT import rows sit in segment `0000:`, so
        # testing "unplaced" first would file them as unplaced statics and hide
        # a skip category the report claims to print. Identify the library
        # before deciding the row is unplaced.
        lib = obj.rsplit(":", 1)[0] if ":" in obj else ""
        if any(lib.startswith(p) for p in SKIP_LIBS):
            skipped[f"CRT/runtime import ({lib})"] += 1
            continue

        if seg.startswith(_UNPLACED_SEGMENT) or int(rva_hex, 16) == 0:
            skipped["unplaced / <absolute> (no code)"] += 1
            continue

        objfile = obj.rsplit(":", 1)[-1] if ":" in obj else obj
        # COMDAT rows name the object as a bare `CIL <module>` with no `.obj`,
        # so accept a bare name only when it came from a `*:*` row.
        if not (objfile.endswith(".obj") or ("*:*" in tail)):
            skipped[f"non-object source ({obj})"] += 1
            continue

        rva = int(rva_hex, 16)
        key = (rva, name, objfile)
        if key in seen:
            continue
        seen.add(key)
        symbols[rva].append(
            {
                "name": name,
                "object": objfile,
                "section": section,
                "kind": classify(name),
                "line": lineno,
            }
        )
    return dict(symbols), dict(skipped)


def find_default_map() -> pathlib.Path | None:
    """Newest `.map` under the build trees."""
    cands: list[pathlib.Path] = []
    for root in (REPO / "TarkovAddons" / "out", REPO / "TarkovAddons" / "x64"):
        if root.is_dir():
            cands.extend(root.rglob("*.map"))
    return max(cands, key=lambda p: p.stat().st_mtime) if cands else None


def timestamp_of(path: pathlib.Path) -> str:
    """The `Timestamp is ...` line the linker stamps into the map header."""
    try:
        with path.open(encoding="utf-8", errors="replace") as fh:
            for _ in range(8):
                line = fh.readline()
                if not line:
                    break
                if "Timestamp is" in line:
                    return line.strip()
    except OSError:
        pass
    return "(no timestamp header)"


def build_groups(symbols, min_symbols, kinds):
    """Fold groups restricted to `kinds`, ignoring groups that only survive
    because a filtered-out symbol was in them."""
    groups = []
    for rva, syms in symbols.items():
        kept = [s for s in syms if s["kind"] in kinds]
        if len(kept) < min_symbols:
            continue
        # Require the *surviving* symbols alone to reach the threshold, so
        # filtering can never manufacture a group that was not there.
        groups.append(
            {
                "rva": f"0x{rva:016x}",
                "symbols": len(kept),
                "objects": sorted({s["object"] for s in kept}),
                "names": [s["name"] for s in kept],
                "kinds": sorted({s["kind"] for s in kept}),
            }
        )
    groups.sort(key=lambda g: (-g["symbols"], g["rva"]))
    return groups


def find_unfolded(symbols) -> list[dict]:
    """First-party functions sitting alone at their address in an object that
    also contains folded duplicates -- the near-duplicates that survived, and
    so still cost bytes and icache."""
    folded_objs: collections.Counter[str] = collections.Counter()
    for syms in symbols.values():
        live = [s for s in syms if s["kind"] == "first_party"]
        if len(live) > 1:
            for s in live:
                folded_objs[s["object"]] += 1

    out = []
    for rva, syms in symbols.items():
        live = [s for s in syms if s["kind"] == "first_party"]
        if len(live) != 1:
            continue
        w = folded_objs.get(live[0]["object"], 0)
        if w:
            out.append({"rva": f"0x{rva:016x}", "name": live[0]["name"],
                        "object": live[0]["object"], "fold_weight": w})
    out.sort(key=lambda d: (-d["fold_weight"], d["name"]))
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--map", type=pathlib.Path, help="path to a .map file")
    ap.add_argument("--min-symbols", type=int, default=2,
                    help="report fold groups of >= N symbols (default 2)")
    ap.add_argument("--unfolded", action="store_true",
                    help="rank lone first-party functions in fold-heavy objects")
    ap.add_argument("--all", action="store_true",
                    help="include compiler-generated and std symbols (see docstring)")
    ap.add_argument("--top", type=int, default=25, help="rows per table (default 25)")
    ap.add_argument("--format", choices=("text", "json"), default="text")
    args = ap.parse_args(argv)

    if args.min_symbols < 2:
        print("FAIL -- --min-symbols must be >= 2; a group of one is not a fold",
              file=sys.stderr)
        return 2

    path = args.map or find_default_map()
    if path is None:
        print("FAIL -- nothing was checked. No .map found under TarkovAddons/out or\n"
              "       TarkovAddons/x64 and --map was not given. Build first, or pass\n"
              "       --map. This is not a pass.", file=sys.stderr)
        return 2
    if not path.exists():
        print(f"FAIL -- nothing was checked. map file does not exist: {path}",
              file=sys.stderr)
        return 2

    symbols, skipped = parse_map(path)
    n_sym = sum(len(v) for v in symbols.values())
    if not symbols or n_sym == 0:
        print("FAIL -- nothing was checked. The map parsed to zero placed symbols,\n"
              "       so no comparison was possible. This is not a pass.",
              file=sys.stderr)
        return 2

    kinds = {"generated", "stdlib", "first_party"} if args.all else {"first_party"}

    by_kind = collections.Counter(s["kind"] for v in symbols.values() for s in v)
    groups = build_groups(symbols, args.min_symbols, kinds)
    folded = sum(g["symbols"] for g in groups)
    saved = folded - len(groups)

    if args.format == "json":
        print(json.dumps({
            "map": str(path), "timestamp": timestamp_of(path),
            "symbols": n_sym, "distinct_addresses": len(symbols),
            "filtered": not args.all,
            "by_kind": dict(by_kind),
            "fold_groups": len(groups), "folded_symbols": folded,
            "copies_saved": saved,
            "groups": groups, "skipped": skipped,
        }, indent=2))
        return 1 if groups else 0

    scope = "ALL symbols (compiler-generated and std INCLUDED)" if args.all \
        else "first-party symbols only"
    print(f"{path}")
    print(f"  {timestamp_of(path)}")
    print(f"  {n_sym:,} placed symbol(s) at {len(symbols):,} distinct address(es)")
    print(f"  scope: {scope}")
    print()

    for reason, count in sorted(skipped.items(), key=lambda kv: -kv[1]):
        print(f"skipped {count:>6}  {reason}")
    if not args.all:
        print(f"excluded {by_kind['generated'] + by_kind['stdlib']:>6}  "
              f"by name class ({by_kind['generated']:,} compiler-generated, "
              f"{by_kind['stdlib']:,} std/runtime/imgui) -- use --all to include")
    print()

    if not groups:
        print(f"OK -- no address holds {args.min_symbols}+ matching symbols; "
              f"nothing was folded")
        return 0

    print(f"FOLDED: {len(groups):,} address(es) hold {folded:,} symbol(s).")
    print(f"        The linker collapsed these to one copy each, so {saved:,}")
    print(f"        duplicate copies are ALREADY absent from the shipped binary.")
    if not args.all:
        print(f"        Read this as a maintainability figure, not a size one.")
    print()
    print(f"  {'syms':>4}  {'rva':<20} objects")
    for g in groups[: args.top]:
        objs = ", ".join(g["objects"][:3])
        if len(g["objects"]) > 3:
            objs += f", +{len(g['objects']) - 3} more"
        print(f"  {g['symbols']:>4}  {g['rva']:<20} {objs}")
        for n in g["names"][:2]:
            print(f"        {n[:104]}")
    if len(groups) > args.top:
        print(f"  ... {len(groups) - args.top} more group(s); raise --top")
    print()

    folded_objs: collections.Counter[str] = collections.Counter()
    for rva, syms in symbols.items():
        live = [s for s in syms if s["kind"] in kinds]
        if len(live) > 1:
            for s in live:
                folded_objs[s["object"]] += 1
    if folded_objs:
        print("most-folded object files (each symbol here already has its twin collapsed):")
        for o, c in folded_objs.most_common(10):
            print(f"  {c:>5}  {o}")
        print()

    if args.unfolded:
        un = find_unfolded(symbols)
        if not un:
            print("UNFOLDED: none -- every first-party function in a fold-heavy "
                  "object was itself folded")
        else:
            print(f"UNFOLDED: {len(un):,} lone first-party function(s) live in an object")
            print(f"          that also contains folded duplicates. These did NOT")
            print(f"          collapse, so they are duplication that still costs bytes.")
            print(f"  {'weight':>6}  {'rva':<20} name")
            for u in un[: args.top]:
                print(f"  {u['fold_weight']:>6}  {u['rva']:<20} {u['name'][:96]}")
            if len(un) > args.top:
                print(f"  ... {len(un) - args.top} more; raise --top")

    return 1


if __name__ == "__main__":
    sys.exit(main())