param(
    [ValidateSet("Prod", "Debug")]
    [string]$Configuration = "Prod"
)

# Ninja generator: exports compile_commands.json (the VS generator does not),
# which clang-tidy needs. -A x64 is unavailable with Ninja, so pin the
# architecture via CMAKE_SYSTEM_PROCESSOR. vcvars64.bat must run in the same
# shell so cl.exe, the include/lib paths and PATH are all set.
#
# $env:SLOT selects the build tree and is forwarded to the .bat, which used to
# hardcode "opencode". Without the forwarding, build_cmake.ps1 -Slot <n>
# -Rebuild deleted build\Prod\x64\<n> and then reported "Configure failed; no
# build.ninja" while having configured the opencode tree instead.
& "$PSScriptRoot\configure_cmake.bat" -Configuration $Configuration