# Handoff: `skeleton_visibility.h` has 2 clones I deliberately did not merge

> **2026-10-13 — the question §4 asked is ANSWERED: the freeze is lifted.** The
> user confirmed the optics rework finished and removed the
> `[CLEANUP-PENDING:OPTICS]` markers; `skeleton_visibility.h:3`'s marker is
> gone and `AGENTS.md` "Do not touch" now says so. Everything below stays as
> written — the §2 differences and the §5 merge order are still the right
> preparation — but "blocked on the freeze" is no longer the status, and §4's
> second reading ("ignore this note until whoever owns the rework says
> otherwise") has been satisfied. Not actioned: the user's instruction was the
> freeze removal only.

**To:** the ESP / optics workstream (owner of `skeleton_visibility.h`, `esp_text.h`)
**From:** the aimbot/pen-check workstream, 2026-10-10
**Status:** reported, **not touched**, and still blocked on the freeze as of 2026-10-10. I
reverted every edit. The file is byte-identical to
the commit before this note; see §6 for how to verify that in one command.
**Precedent:** `handoff_visibility_inside_hit.md` (archived 2026-10-14 in `.opencode/handoff-archive/`) — same shape of finding. Two blocks that
*aimed identically, differed in three ways that mattered*, and where the obvious fix
transferred badly. That note's reasoning is still the template here.

---

## 1. What was found, and why it stopped

`dup_scan` reports two clones in this file:

```
    30  TarkovAddons/module/skeleton_visibility.h:3234-3263
    19  TarkovAddons/module/skeleton_visibility.h:3203-3221
```

They are the ancestor ballistic-walk's per-layer gate (`:3203`-`:3263`) and the sibling
sweep's copy of it (`:3322`-`:3362`). I extracted them to a shared lambda, got it
compiling, then **reverted it**, because unifying them changes output an investigation
reads and I cannot test the result.

The file carries `[CLEANUP-PENDING:OPTICS] DO NOT CLEAN UP THIS FILE YET` at `:3`. **Whether
that marker is still live is unresolved** — see §4, which is the thing I would most like
settled before anyone edits here.

## 2. The differences, measured rather than read

I diffed the two blocks line by line rather than eyeballing them. These are **all** the
semantic differences; everything else is indentation, the sibling's deeper nesting, and one
named local (`shot_dir`) the ancestor uses where the sibling builds the same vector inline.

### 2.1 Four different forensic strings

| condition | ancestor `:3234`-`:3263` | sibling `:3346`-`:3362` |
|---|---|---|
| non-penetrable | `"blocked at layer {} ({})"` | `"blocked at layer {} (sibling; {})"` |
| non-penetrable reason | `record_stop(..., reason)` | `record_stop(..., "sibling: {}")` |
| ricochet tally | `"ricochet {:.3f} >= {:.2f}"` | `"sibling ricochet {:.3f} >= {:.2f}"` |
| ricochet verdict | `"layer {} is a deflection candidate (ricochet risk {:.3f} >= {:.2f}); round likely skips off"` | `"sibling layer {} is a deflection candidate (ricochet risk {:.3f} >= {:.2f})"` |

That last row is the one I would not erase by hand: **the sibling message is missing
`"; round likely skips off"`.** Two consequences, and both are reasons an investigation
mis-reads the current log:

* grepping the log for one path's wording finds only that path;
* `stop_reason` for the *same* `pen_stop` code is prefixed on the sibling path and bare on
  the ancestor path, so a `stop_reason` that starts `"sibling:"` identifies which sweep
  stopped the round — that information exists in the log today and would be gone after a
  merge that rendered both from one format string.

The stop **code** is the same in both paths, so `g_pen_stop_counts()` buckets do not split.
That part is safe. It is the strings and §2.2 that are not.

### 2.2 Two different variables, which is the part that is not just wording

```cpp
// ancestor, :3259                       // sibling, :3358
layer_is_ballistic = true;               layer_ballistic = ballistic;
```

`layer_is_ballistic` is a `bool` declared at `:3100`; `layer_ballistic` is an
`Il2CppObject*` declared at `:3044`. They are different variables with different
downstream readers:

* `layer_is_ballistic` controls `if (!layer_is_ballistic)` at `:3263`, i.e. whether this
  iteration falls into the sibling sweep at all;
* `layer_ballistic` is read by `same_collider` at `:3134` on the **next** iteration.

So the two blocks do not merely print differently — they leave different state behind. Any
merge has to keep both assignments, which means the "shared" body is not shared, and the
saving is smaller than 49 lines suggests.

### 2.3 The tail differs structurally

Ancestor falls out of the `else` branch and continues the enclosing loop with no `continue`.
Sibling ends `++layer; layer_ballistic = ballistic; advance; continue;`. A lambda returning
"should the walk continue" cannot express both without a flag, and the flag is the smell.

## 3. What I actually did, so you can undo it safely

Nothing. Started and reverted. Concretely, on this tree:

* `TarkovAddons/module/always_on.h` and `TarkovAddons/module/esp_text.h` **were** merged —
  six MoveNext prologues and two draw bodies. Committed as `ee4765438`, plus
  `6019edc59` for the doc figures it shifted.
* `skeleton_visibility.h` was edited toward a merge, then restored with
  `git checkout -- TarkovAddons/module/skeleton_visibility.h` while the edits were
  uncommitted. No `grade_layer` remains; `git grep grade_layer` returns nothing.

## 4. The thing I want settled first: is the OPTICS freeze live?

**RESOLVED 2026-10-10 — the freeze is still live, and this handoff stays blocked.**

The file still carries the marker at line 3, verbatim:

    // [CLEANUP-PENDING:OPTICS] DO NOT CLEAN UP THIS FILE YET.
    // Frozen pending the in-progress optics rework on another machine.

and `AGENTS.md` "Do not touch" still lists `module/skeleton_visibility.h` among the
frozen files with the instruction "Leave those markers in place." I am the optics
workstream's owner for the parts I have been fixing (`optics_lens_pipeline.h`,
`eft_api.h`'s optic paths, `optics_status.md`), and nothing about the clone merge
below makes those safe.

So the reading to act on is the *second* one this section offered: **ignore this
note until whoever owns the rework says otherwise.** The branch-age evidence in
the table below is real but it is not sufficient — a marker in the file is the
authoritative statement, and it is still there. A clone merge in a frozen file is
exactly the kind of edit that produces a conflict nobody can bisect, because the
other machine's diff has no local copy to be compared against.

Keeping the rest of this section because the evidence is still worth having if the
marker ever comes off, and because it documents why I did not act on the obvious
reading:

`AGENTS.md` says the optics rework is "live on another machine". My evidence says otherwise,
and I would rather flag it than act on either reading:

| evidence | what it says |
|---|---|
| `optics` branch | last commit **4 weeks ago** |
| this file, `esp_text.h`, `unity.h` | last touched 2026-10-06 → 10-09, all `XeonDead`, on `master` |
| last 6 h of commits on `master` | all `XeonDead` |
| working tree | clean |

If the rework has finished, **the right change is to delete the stale `[CLEANUP-PENDING:OPTICS]`
markers** — that is a small, safe, useful edit and it is not mine to make. If it has *not*
finished, this note should be ignored until whoever owns it says otherwise, because
`esp_text.h` was merged by me on the user's explicit instruction and is the file most likely
to collide.

## 5. If you merge it anyway, the order I would use

1. Decide the string policy first. Either (a) keep both texts exact by passing two prefixes
   and a suffix flag, or (b) unify the wording *and* accept that historical logs stop
   matching — and say so in `CHANGELOG.md`, because the last session that changed a
   diagnostic string sent an investigation at the wrong subsystem
   (`handoff_visibility_inside_hit.md`, archived 2026-10-14 in `.opencode/handoff-archive/`).
2. Keep both `layer_is_ballistic` and `layer_ballistic` assignments. They are not redundant.
3. Merge the *setup* block (`:3203`-`:3221`) separately from the *decision* block
   (`:3234`-`:3263`). The setup block's only differences are a comment and a named local;
   it is the low-risk half and probably worth doing on its own.
4. The decision block is the half where I would insist on a real test. The pen walk's output
   is asserted by `test_pen_layer_budget.py`, `test_pen_exit_face.py` and
   `test_pen_degenerate_origin.py`; run those *and* a 500 ms trace dump before and after and
   diff the two dumps byte for byte. A trace diff is the only thing that proves the strings
   survived.

   **No test guards any of the four strings in §2.1.** Grepping `tools/tests` for `sibling`,
   `deflection candidate` and `round likely skips off` matches only `conftest.py`,
   `test_crash_probe_confirmed_report.py` and `test_zone_scope.py`, and none of those reads
   this file. So a merge that silently changed a diagnostic string would land green — the
   class of thing `AGENTS.md` says a checker cannot catch. The cheapest real guard is a
   golden-substring test over a captured dump, not another assertion about the return value.
   survived.

## 6. Provenance

| artefact | value |
|---|---|
| file | `TarkovAddons/module/skeleton_visibility.h`, 3,504 lines at `6019edc59` |
| clones | 2, found by `tools/dup_scan.py` `--min-lines 8` |
| measured by | line-level `difflib` unified diff of both ranges; §2.1 and §2.2 are its output, not a reading |
| status | **reverted.** Verify with `git grep grade_layer` (empty) and `git diff 6019edc59 -- TarkovAddons/module/skeleton_visibility.h` (empty) |
| freeze marker | present at `:3`, `[CLEANUP-PENDING:OPTICS] DO NOT CLEAN UP THIS FILE YET` |
| merged elsewhere | `ee4765438` (`always_on.h`, `esp_text.h`), `6019edc59` (docs) |
| build after my pass | Prod\|x64, exit 0, 0 errors, 0 code warnings, in slot `refactor` |
| not covered | no trace dump was taken before or after, because the merge was reverted — so there is **no** evidence that my abandoned extraction preserved output. Treat it as unproven, not as safe |