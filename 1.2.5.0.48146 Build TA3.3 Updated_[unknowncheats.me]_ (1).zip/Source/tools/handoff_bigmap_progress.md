# Progress: big map + minimap (steps 1–5 of plan_bigmap_and_minimap.md)

Date: 2026-10-13. Branch: `master`. **Nothing committed yet.**

> **2026-10-13 later — ALL of steps 1–5 are now committed and build-verified.**
> Steps 1–4 landed in `c357c3dc4`; **step 5 (static markers + labels) landed on
> 2026-10-13** with `minimap.h` parsing, the radar draw path in `EspModule.cpp`
> behind two MinimapModule checkboxes, the 242+270 merged data rows, the
> provenance file, and five new integrity cases. Clean `Prod|x64` build + link
> (exit 0, 0 errors, 0 warnings), `audit_config_pointers.py` 360/29 exit 0,
> `pytest tools/tests` 538 passed with the two known pre-existing failures.
> The step-3 C++ that was "not compiled" on the Linux host has since been built
> here several times. Remaining: step 6 (MapModule + M keybind + full-screen
> view) and step 7 (the drop-down). See the section added at the bottom for
> what step 5 measured that the plan did not predict.

## Steps done

### Step 1 — `tools/tests/test_map_asset_integrity.py` (new, 7 tests)
Written and **verified to fail before the fix** (2 failures: `reserve` 4th Floor
`Third_Floor` not in SVG; `bigmap` 4th Floor duplicating `Third_Floor`). After the
step-2 fix: **7 passed**. Docstring records the negative control.

### Step 2 — 5 broken overlays fixed
- `bigmap.json`: removed 4th Floor overlay (was duplicating `Third_Floor`).
- `reserve.json`: removed 1st Floor (duplicated `Bunkers`) and 4th Floor
  (`Third_Floor` not in `reserve.svg`). 6 → 4 overlays.
- `laboratory.json` / `labyrinth.json`: `svg_layer: null` — **not changed**; they
  gained real SVGs in step 4 instead.

### Step 3 — UI-blocking screen detector + minimap hide (C++, not build-verified)
- `eft_api.h`: added `query_ui_blocking_screen_open()`,
  `update_ui_blocking_screen_open_cached()`, `is_ui_blocking_screen_open_cached()`,
  and the `ui_blocking_screen_open_cached()` atomic. Returns true for screen type
  15 (Inventory) or 42 (TransferItemsInRaid) regardless of LootItem/grid.
- `EspModule.cpp:5916`: added `update_ui_blocking_screen_open_cached()` call
  beside the existing update.
- `EspModule.cpp:4881`: added early-out in `draw_overlay` after the `is_in_raid`
  gate. **Not compiled** — Linux host, no MSVC.

### Step 4 — Labs + Labyrinth SVGs + attribution (new files)
- Merged DynamicMaps' single-floor SVGs into our multi-layer format:
  - `laboratory.svg`: 3 layers (`First_Level`, `Second_Level`, `Technical_Level`),
    viewBox `0 0 720 586`, valid XML.
  - `labyrinth.svg`: 1 layer (`Layer_1`), viewBox `0 0 940.38 860.89`, valid XML.
- Attribution: `laboratory-LICENSE.md` (Shebuka CC BY-NC-SA 4.0),
  `labyrinth-LICENSE.md` (acidphantasm CC BY-NC-SA 4.0).
- `laboratory.json`: `svg`, `svg_layer`, `first_floor_layer`, overlay layers set.
- `labyrinth.json`: `svg`, `svg_layer`, `first_floor_layer` set.
- Integrity test: **7 passed** with the new SVGs.

## Step 5 — static markers + labels (NOT started)
This is the remaining step. Agreed scope:
- New `map_config` fields `static_markers[]` + `labels[]`, parsed in
  `parse_config_file` (`minimap.h:1335`).
- DynamicMaps coordinate mapping **confirmed**: `Position.x` = world x,
  `Position.y` = world z, `Position.z` = altitude → maps directly to
  `unity::vector3 pos`.
- Draw path: reuse `minimap::world_to_uv` + `resolve_minimap_marker_point`.
- **LockedDoor first** (`DoorsModule` already scans doors — presentation-only).
- **Skip** static Extract/Transit markers (duplicate live reads, desync from
  eligibility).
- Categories to include: `LockedDoor`, `Switch`, `Secret` (measured on Customs:
  34 / 1 / 2). Total across all maps: 384 markers, 270 labels.

## Not build-verified
All C++ changes (step 3) are **not compiled** — this is a Linux host with no MSVC.
Per AGENTS.md, "verified" requires a full `Prod|x64` build. The C++ is written
and reasoned but carries no build claim.

## Plan file
`tools/plan_bigmap_and_minimap.md` — full plan, decisions, hand-off notes.

---

# Step 5 as implemented, 2026-10-13 (Windows box, `master`)

## What landed

- **`minimap.h`**: `map_static_marker` and `map_label` structs, both fields on
  `map_config`, `read_dynamic_maps_position` (the one place the coordinate
  mapping lives), `parse_static_marker` / `parse_map_label`, and the two parse
  loops in `parse_config_file`. A marker with no text or no category is
  skipped rather than shipped blank.
- **`EspModule.cpp`**: the radar draws markers and labels after the corpse
  layer, inside the existing clip rect, through the same
  `resolve_minimap_marker_point` every other radar layer uses. Colour is by
  category (LockedDoor yellow / Switch teal / Secret violet, matching the
  upstream palette), the label offset is the exfil labels' `height_dy`, and
  the config comes from `minimap::find_config`'s **owning** shared_ptr so a
  map reload mid-draw cannot invalidate the vectors being iterated.
- **`MinimapModule`**: `radar_minimap_static_markers` and `radar_minimap_labels`
  checkboxes, both default off like every other radar extra, with i18n keys in
  all 19 locales.
- **Data**: 242 markers / 270 labels across the eleven maps that have
  DynamicMaps data (terminal is the arena and carries none). Extract and
  Transit deliberately not merged. `terminal.json` is unchanged.
- **Provenance**: `TarkovAddons/assets/maps/static-markers-LICENSE.md`.

## What step 5 measured that the plan did not predict

**The plan's totals were right and its reason for one of them was not
reproducible as written.** 384 StaticMarkers and 270 Labels parse out of the
submodule exactly as recorded, but the *included* subset is 242 markers, not
the 384 the plan lists as "total across all maps" — the plan's 384 is all
categories, and 242 of those are LockedDoor/Switch/Secret once the source's
`Locked Door` spelling is normalised to `LockedDoor`.

**The negative control caught the test, not the data.** The obvious way to
catch a coordinate-mapping error is a bounds check, and it does not work:
swapping the mapping's second and third components moves each marker's z onto
its altitude, and an altitude is a small number that lands inside nearly every
map's z range — the swapped data passed the bounds test 12/12. The check that
does work compares the markers' z spread against their y spread (10–60× on
correct data; a swap inverts it). `test_marker_z_spread_is_not_an_altitude_spread`
is that check, and its docstring records that it exists *because* the bounds
check failed the control.

## What is still unverified

**No raid has drawn these.** Everything above is build-verified and
data-verified; nothing has been looked at on a live radar. The first raid
should confirm (a) markers land on the doors they name on Customs — the
bounds check proves they are in the map, not that they are on the right door —
and (b) that Streets' 42 markers plus 46 labels are not too dense to read,
which is the case the plan's scope did not measure.
