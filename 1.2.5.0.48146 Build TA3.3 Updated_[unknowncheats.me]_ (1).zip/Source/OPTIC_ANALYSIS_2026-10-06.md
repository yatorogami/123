# Optic Shake Investigation - Session 2026-10-06 20:43-20:44 Analysis

## Session Summary
- **Build stamp**: 0x6AC53108 (deployed 20:34)
- **PID**: 8960 (main), also pid 22284 at startup
- **Optic active**: 20:43:40 to 20:44:42 (~62 seconds)
- **Threads**: tid=17796 (main/game thread), tid=11220 (render thread)
- **No tracy captures or minidumps found**

## Key Findings

### 1. Lens-Size Gate Rebaseline Behavior (DIFFERENT from previous capture)

**Previous capture (2026-10-05)**: 56 rejections, 0 rebaselines, bursts over 16-28s
**This capture (2026-10-06)**: ~108 rejections in first 3s, **1 rebaseline**, then clean

| Time | Thread | Event | Baseline | Rejections | Rebase |
|------|--------|-------|----------|------------|--------|
| 20:44:32.783 | 17796 | First packet, mask empty | - | - | - |
| 20:44:33.382 | 17796 | Heavy rejection burst | 0.3863x0.6862 | 53 | 0 |
| 20:44:33.998 | 11220 | Rejection burst | 0.8521x1.5149 | 55 | **1** |
| 20:44:34.599 | 11220 | Continuing | 0.8521x1.5149 | 55 (cum.) | 0 |
| 20:44:35.323 | 11220 | Rejections dropping | - | 34 | 0 |
| 20:44:35.928 | 17796 | **Clean** | - | 0 | 0 |
| 20:44:36.533+ | both | Stable | ~0.95 ratio | 0 | 0 |

### 2. Cross-Thread Contamination (ROOT CAUSE)

The lens-size gate (`g_lens_size`) is a **global shared struct** evaluated by two threads on **different frames**:

```
Thread 17796 (main):     Frame N   -> measures 0.3863x0.6862 -> 53 rejections
Thread 11220 (render):   Frame N+1 -> measures 0.8521x1.5149 -> 55 rejections -> REBASELINE
```

**The rebaseline timer (`reject_since`) is shared**, so it measures from the FIRST rejection across BOTH threads. But the **rebaseline adopts the CURRENT thread's measurement** as the new baseline.

This is a logical data race: the gate assumes a single timeline, but two threads produce evaluations on different timelines (different game frames). The mutex (`g_optic_refresh_mutex`) serializes the evaluation CALLS, but the STATE persists across calls and mixes the timelines.

### 3. Initial Mask Empty
- First packet (20:44:32.783): `fitted_pts=0`, `cover=0.0%`, rejection reason: "lens mask polygon empty after clip"
- Packet becomes valid at 20:44:32.814
- This is a separate issue: the mask pipeline produces no polygon on the first frame

### 4. Root Frame Movement
- `local move mm med`: 0.01 to 26.71 mm
- `local move mm max`: up to 227 mm
- `applied` (corrector frames): 1 to 46 per window
- The corrector IS being applied and shows movement, but the median is small when applied frequently

## The Bug

**File**: `TarkovAddons/module/optics_lens_pipeline.h`
**Struct**: `lens_image_size_gate g_lens_size` (line 2716)
**Problem**: Global state shared across threads evaluating different frames

The gate's rebaseline logic:
```cpp
if (now - g_lens_size.reject_since >= kRebaselineMs) {
    g_lens_size.ref_w = w;  // ADOPTS CURRENT THREAD'S MEASUREMENT
    g_lens_size.ref_h = h;
    g_lens_size.reject_since = 0;
    ++g_lens_size.rebaselines;
}
```

When thread 11220 rebaselines, it sets the baseline to ITS measurement (0.8521x1.5149), not thread 17796's (0.3863x0.6862). These differ by **2.2x** - a massive discrepancy caused by evaluating different frames.

## Proposed Fix

### Option A: Thread-Local Gate State (Minimal, Safe)
Make `g_lens_size` thread-local. Each thread maintains its own baseline, timer, and counters.

```cpp
// Change from:
inline lens_image_size_gate g_lens_size{};
// To:
inline thread_local lens_image_size_gate g_lens_size{};
```

And similarly for the ring buffer:
```cpp
inline thread_local lenssize_frame_sample g_lens_ring[kLensSizeRing]{};
inline thread_local int g_lens_ring_head = 0;
inline thread_local int g_lens_ring_filled = 0;
inline thread_local unsigned long long g_lens_tick[kLensSizeRing]{};
inline thread_local int g_lens_reject_run = 0, g_lens_accept_run = 0;
inline thread_local int g_lens_reject_run_max = 0, g_lens_accept_run_max = 0;
```

**Pros**: Zero synchronization overhead, each thread evaluates independently
**Cons**: Two baselines exist simultaneously; rebaseline only adapts per-thread

### Option B: Per-Refresh Gate State (Architecturally Clean)
Move gate state into the packet pool slot being built. The gate evaluates during refresh (inside mutex) and stores result in the packet.

**Pros**: Gate state tied to the packet/frame it belongs to
**Cons**: Larger refactor; projection functions would read gate result from published packet

### Option C: Frame-ID Tracking (Targeted Fix)
Add a frame counter to `g_lens_size`. Only allow rebaseline if the current evaluation is on the same frame as the first rejection.

```cpp
struct lens_image_size_gate {
    // ... existing fields ...
    ULONGLONG reject_since_frame = 0;  // Frame ID when rejection started
};
// In acquire_packet, get current frame ID from game or use a monotonic counter
```

**Pros**: Prevents cross-frame contamination
**Cons**: Need reliable frame ID source

## Recommendation: Option A (Thread-Local)

**Reasoning**:
1. The render thread and main thread are fundamentally on different frames - they SHOULD have independent gate evaluations
2. The mutex already serializes the refresh work; thread-local state eliminates the cross-contamination
3. Minimal code change, zero runtime overhead
4. The rebaseline is meant to adapt to genuine optic changes (scope swap), which are global - but a scope swap affects BOTH threads, so both will rebaseline independently within 500ms
5. Previous capture's "0 rebaselines" was likely because the single thread's accepts interleaved; with two threads, one thread's continuous rejection can trigger rebaseline

## Additional Issues Noted

1. **`lenssize-frame: only 0 evaluation(s) recorded`** at 20:44:32.783 but `optic-lenssize` at 20:44:33.382 shows `rej=53` - the ring buffer wasn't capturing the first burst. The first `optic_lens_ensure_frame` call (mask empty) returns early before evaluating the gate.

2. **No `TIMER STARVED` verdict** in this capture because rebaseline DID fire (rebase=1). The previous capture's diagnosis (timer starved by interleaved accepts) doesn't apply here - here the rebaseline worked but adopted the wrong thread's measurement.

3. **Mask drop-outs**: 1 event with `fitted_pts=0` at start, cross-confirmed by `cover=0.0%`. This is the "first frame mask empty" issue, not the gate starvation.