#include <fstream>
#include <string>
#include <windows.h>

const std::string DLL_CONFIG_FILE = "launcher.cfg";
const char* LOG_FILE = "tarkovaddons_launcher_log.txt";

// Minimal WinAPI-only file logger. This DLL loads inside the launcher process
// very early — possibly before the bypass stage — and must leave evidence even
// if the process dies moments later. Append + per-line flush: the last line
// before a crash always survives, and multiple writers (stub here, bypass in
// the launcher process, bypass in the game process) share the file safely via
// append-mode writes.
static void stub_log(const char* level, const std::string& msg) {
    HANDLE file = CreateFileA(LOG_FILE, FILE_APPEND_DATA,
        FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE)
        return;

    SYSTEMTIME st{};
    GetLocalTime(&st);
    char ts[48];
    if (sprintf_s(ts, "[%04hu-%02hu-%02hu %02hu:%02hu:%02hu.%03hu] ",
            st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds) > 0)
    {
        DWORD written = 0;
        WriteFile(file, ts, static_cast<DWORD>(strlen(ts)), &written, nullptr);
    }
    const std::string line = std::string("[") + level + "] " + msg + "\n";
    DWORD written = 0;
    WriteFile(file, line.c_str(), static_cast<DWORD>(line.size()), &written, nullptr);
    CloseHandle(file);
}

// Resolve the launcher's own directory once. Writing next to the exe (the
// BsgLauncher folder, where launcher.cfg lives) instead of the CWD keeps the
// log findable no matter how the launcher was started.
static std::string launcher_dir() {
    char path[MAX_PATH]{};
    if (GetModuleFileNameA(nullptr, path, MAX_PATH) == 0)
        return {};
    std::string dir(path);
    const size_t slash = dir.find_last_of("\\/");
    return slash == std::string::npos ? std::string() : dir.substr(0, slash + 1);
}

static DWORD parse_host_process_id(const char* cmdline) {
    // Previous code did args.find(sub) + stoi() unconditionally: any load of
    // this DLL without a --host-process-id= argument (software-GPU fallback,
    // other tools loading vk_swiftshader.dll, a launcher relaunch) computed
    // npos + len, sliced garbage, and std::stoi threw an unhandled exception
    // during DLL_PROCESS_ATTACH — instant, silent launcher crash on open.
    constexpr const char* sub = "--host-process-id=";
    const char* p = strstr(cmdline, sub);
    if (!p)
    {
        stub_log("ERROR", std::string("no --host-process-id= in command line: ")
            + (cmdline ? cmdline : "(null)"));
        return 0;
    }
    p += strlen(sub);
    if (*p == '\0' || *p == ' ')
    {
        stub_log("ERROR", "--host-process-id= present but empty");
        return 0;
    }
    return static_cast<DWORD>(strtoul(p, nullptr, 10));
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH: {
        stub_log("INFO", "vk_swiftshader.dll attached");

        // resolve parent process id
        const std::string args(GetCommandLineA());
        const DWORD parent_id = parse_host_process_id(args.c_str());
        if (parent_id == 0)
        {
            // Not launched as the launcher's render stub — stay inert instead of
            // injecting into a garbage PID (the old code crashed here).
            stub_log("WARN", "no parent id — staying inert");
            break;
        }
        stub_log("INFO", "parent id parsed: " + std::to_string(parent_id));

        // inject dll
        HANDLE parent = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION, false, parent_id);
        if (parent != nullptr)
        {
            stub_log("INFO", "parent opened, reading " + DLL_CONFIG_FILE);
            std::ifstream file(DLL_CONFIG_FILE);
            if (file)
            {
                std::string dllIn;
                std::getline(file, dllIn);
                dllIn = dllIn.substr(7);
                LPSTR dll = const_cast<char *>(dllIn.c_str());
                file.close();
                stub_log("INFO", "injecting stage1: " + dllIn);
                LPVOID fnLoadLibrary = reinterpret_cast<LPVOID>(GetProcAddress(GetModuleHandle(L"kernel32.dll"), "LoadLibraryA"));
                LPVOID mem = VirtualAllocEx(parent, nullptr, strlen(dll) + 1, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
                if (!mem)
                {
                    stub_log("ERROR", "VirtualAllocEx failed");
                    CloseHandle(parent);
                    break;
                }
                WriteProcessMemory(parent, mem, dll, strlen(dll) + 1, nullptr);
                HANDLE thread = CreateRemoteThread(parent, nullptr, 0, reinterpret_cast<LPTHREAD_START_ROUTINE>(fnLoadLibrary), mem, 0, nullptr);
                if (!thread)
                {
                    stub_log("ERROR", "CreateRemoteThread failed");
                    VirtualFreeEx(parent, mem, 0, MEM_RELEASE);
                    CloseHandle(parent);
                    break;
                }
                while (WaitForSingleObject(thread, 0) != WAIT_OBJECT_0)
                {
                    Sleep(10);
                }
                VirtualFreeEx(parent, mem, 0, MEM_RELEASE);
                CloseHandle(parent);
                stub_log("INFO", "stage1 injection complete: " + dllIn);
            }
            else
            {
                stub_log("ERROR", "cannot open " + DLL_CONFIG_FILE);
                CloseHandle(parent);
            }
        }
        else
        {
            stub_log("ERROR", "OpenProcess(parent) failed — stage1 not injected");
        }
    }
    break;
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }

    return TRUE;
}
