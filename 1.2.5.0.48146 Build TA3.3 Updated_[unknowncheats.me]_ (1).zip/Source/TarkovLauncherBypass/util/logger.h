﻿#pragma once
#include <string>

namespace logger {
    void info(std::string msg);
    void warn(std::string msg);
    void error(std::string msg);

    // Enable the file mirror (<BsgLauncher>\tarkovaddons_launcher_log.txt).
    // WinAPI-only implementation so it is safe to call before the CRT console
    // exists and from paths that terminate the process (no CRT stream buffers
    // to lose). Lines are appended (never truncated) and flushed per write, so
    // the last line before a crash always survives. Safe to share with the
    // injection stub writing the same file from other processes.
    void set_file_log(const std::string& path_utf8);
} // namespace logger
