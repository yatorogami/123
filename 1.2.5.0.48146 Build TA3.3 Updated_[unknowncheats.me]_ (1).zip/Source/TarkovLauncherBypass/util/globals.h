#pragma once
#include <cstddef>
#include <cstdlib>
#include <random>
#include <string>
#include <windows.h>
#include "../util/logger.h"

namespace globals {
    // launcher.cfg is the only file the bypass still reads: which features run
    // and which stage-2 DLLs to inject. Every address and signature comes from
    // the compatibility manifest instead (see util/compat_profile.h).
    const std::string DLL_CONFIG_FILE = "launcher.cfg";

    // Bytes read from a patch target before it is validated. A pattern longer
    // than this cannot be checked against the window, so it is rejected rather
    // than partially trusted.
    constexpr size_t PATCH_WINDOW = 48;

    static int int_rand(const int& min, const int& max) {
        static std::mt19937* generator = nullptr;
        if (!generator) generator = new std::mt19937(clock());
        std::uniform_int_distribution<int> distribution(min, max);
        return distribution(*generator);
    }

    // Match an "XX XX ? XX" pattern against a live byte window. Every declared
    // byte must match; '?' and '??' are whole-byte wildcards. The window is
    // finite, so a pattern running past its end is rejected rather than
    // partially checked.
    static bool pattern_matches(const unsigned char* window, size_t window_len, const std::string& pattern) {
        if (window == nullptr || window_len == 0) return false;

        size_t string_index = 0;
        size_t byte_index = 0;
        while (string_index < pattern.length()) {
            if (pattern[string_index] == '?') {
                if (string_index + 1 < pattern.length() && pattern[string_index + 1] == '?')
                    ++string_index;
                ++string_index;
                while (string_index < pattern.length() && pattern[string_index] == ' ')
                    ++string_index;
                if (byte_index >= window_len)
                    return false;
                ++byte_index;
                continue;
            }

            if (string_index + 1 >= pattern.length())
                break; // truncated token
            const std::string token = pattern.substr(string_index, 2);
            char* end = nullptr;
            const unsigned long value = strtoul(token.c_str(), &end, 16);
            if (end != token.c_str() + 2)
                return false; // not exactly two hex digits
            if (byte_index >= window_len)
                return false;
            if (window[byte_index] != static_cast<unsigned char>(value & 0xFF))
                return false;

            ++byte_index;
            string_index += 2;
            while (string_index < pattern.length() && pattern[string_index] == ' ')
                ++string_index;
        }

        return byte_index > 0;
    }

    // The launcher's only correctness gate on a manifest RVA: read a small
    // window at the remote address and byte-validate the manifest's pattern
    // there. One ReadProcessMemory per candidate replaces the full-module
    // dumps and whole-module scans the old cfg-driven resolver needed.
    static bool remote_bytes_match(HANDLE hProcess, uintptr_t address, const std::string& pattern) {
        if (hProcess == nullptr || address == 0 || pattern.length() < 2)
            return false;

        unsigned char window[PATCH_WINDOW] = {};
        SIZE_T read_bytes = 0;
        if (!ReadProcessMemory(hProcess,
                reinterpret_cast<LPCVOID>(address), // NOLINT(performance-no-int-to-ptr)
                window, sizeof(window), &read_bytes)
            || read_bytes != sizeof(window)) {
            return false;
        }

        return pattern_matches(window, sizeof(window), pattern);
    }
}; // namespace globals
