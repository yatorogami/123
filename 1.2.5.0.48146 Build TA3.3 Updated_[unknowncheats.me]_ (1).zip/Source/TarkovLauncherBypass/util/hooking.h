///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// Thin wrapper over the vendored SafetyHook, replacing the Detours API this
/// DLL used to hook with. Detours needed three things to install a hook
/// (begin a transaction, attach, commit) and handed the trampoline back by
/// writing it through the `ppPointer` argument; SafetyHook collapses that into
/// one `create()` that returns the hook object or a typed error, and the
/// trampoline is read back with `original<T>()`.
///
/// The two conveniences that lived in Detours and are not part of SafetyHook
/// are re-implemented here: resolving an export by module + name (Detours'
/// `DetourFindFunction`) and turning an install failure into something
/// loggable.

#pragma once

#include <string>

#include <windows.h>

#include "../../external/safetyhook/safetyhook.hpp"

// SafetyHook's namespaced spellings are long enough to dominate every call
// site; these aliases match the ones TarkovAddons uses so both projects read
// the same.
using SafetyHookInline = safetyhook::InlineHook;
using SafetyHookError = safetyhook::InlineHook::Error;

namespace hooking {
    // Resolve an exported function by module and name. The equivalent of the
    // Detours `DetourFindFunction` call these two features used to make, and it
    // behaves the same way: both walk the PE export table, so an undocumented
    // name that is not exported comes back as null rather than as a stub.
    // Returns null when the module is not loaded or the name is not exported.
    void* resolve_export(const char* module_name, const char* function_name);

    // Describe an install failure for the log. Returns the SafetyHook error name
    // plus, for the failures that report one, the address of the instruction
    // that caused it.
    std::string error_string(const SafetyHookError error);
} // namespace hooking
