﻿#include "logger.h"

#include <windows.h>

namespace {
    // Plain WinAPI file sink: no CRT streams, no constructors, no buffering.
    // The DLL loads into BsgLauncher.exe, which has no console — every message
    // must land in the file. Each line is written with a single WriteFile so
    // concurrent writers appending to the same log cannot interleave mid-line,
    // and the file always shows the full [timestamp] [level] message record.
    HANDLE g_file = nullptr;
    CRITICAL_SECTION g_lock;
    bool g_lock_init = false;

    void write_line_unlocked(const char* level, const char* msg) {
        SYSTEMTIME st{};
        GetLocalTime(&st);
        char ts[48];
        const int tn = sprintf_s(ts, "[%04hu-%02hu-%02hu %02hu:%02hu:%02hu.%03hu] ",
            st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);

        const std::string line = (tn > 0)
            ? std::string(ts) + "[" + level + "] " + msg + "\n"
            : std::string("[") + level + "] " + msg + "\n";

        if (g_file != INVALID_HANDLE_VALUE && g_file != nullptr)
        {
            DWORD written = 0;
            WriteFile(g_file, line.c_str(), static_cast<DWORD>(line.size()), &written, nullptr);
        }

        // Best-effort console/stdout mirror (debug runs only; no-op in the
        // launcher process, which has no console).
        HANDLE con = GetStdHandle(STD_OUTPUT_HANDLE);
        if (con != nullptr && con != INVALID_HANDLE_VALUE)
        {
            DWORD written = 0;
            WriteFile(con, line.c_str(), static_cast<DWORD>(line.size()), &written, nullptr);
        }
    }
}

void set_color(int, int) {}
void reset_color() {}

namespace logger {
    void set_file_log(const std::string& path_utf8) {
        if (!g_lock_init)
        {
            InitializeCriticalSection(&g_lock);
            g_lock_init = true;
        }
        EnterCriticalSection(&g_lock);

        if (g_file == nullptr)
        {
            const int wlen = MultiByteToWideChar(CP_UTF8, 0, path_utf8.c_str(), -1, nullptr, 0);
            if (wlen > 0)
            {
                std::wstring wpath(static_cast<size_t>(wlen), L'\0');
                MultiByteToWideChar(CP_UTF8, 0, path_utf8.c_str(), -1, wpath.data(), wlen);
                g_file = CreateFileW(wpath.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                    nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
            }
        }

        LeaveCriticalSection(&g_lock);
    }

    void info(std::string msg) {
        if (!g_lock_init)
        {
            InitializeCriticalSection(&g_lock);
            g_lock_init = true;
        }
        EnterCriticalSection(&g_lock);
        write_line_unlocked("INFO", msg.c_str());
        LeaveCriticalSection(&g_lock);
    }

    void warn(std::string msg) {
        if (!g_lock_init)
        {
            InitializeCriticalSection(&g_lock);
            g_lock_init = true;
        }
        EnterCriticalSection(&g_lock);
        write_line_unlocked("WARN", msg.c_str());
        LeaveCriticalSection(&g_lock);
    }

    void error(std::string msg) {
        if (!g_lock_init)
        {
            InitializeCriticalSection(&g_lock);
            g_lock_init = true;
        }
        EnterCriticalSection(&g_lock);
        write_line_unlocked("ERROR", msg.c_str());
        LeaveCriticalSection(&g_lock);
    }
} // namespace logger
