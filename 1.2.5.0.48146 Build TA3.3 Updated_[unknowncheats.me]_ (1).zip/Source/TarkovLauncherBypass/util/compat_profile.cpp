#include "compat_profile.h"

#include <atomic>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <utility>
#include <vector>

#include "../../external/nlohmann/json.hpp"
#include "../../shared/module_paths.h"
#include "logger.h"

namespace compat_profile {
    namespace {
        using json = nlohmann::json;

        struct ManifestSymbol {
            UINT64 rva = 0;
            std::string pattern; // first declared pattern, "" when none
        };

        std::atomic<bool> g_loaded{false};
        std::string g_profile_id;
        std::vector<std::pair<std::string, ManifestSymbol>> g_symbols;

        int status_priority(const std::string& status) {
            if (status == "verified") return 3;
            if (status == "validated") return 2;
            if (status == "staged") return 1;
            return 0;
        }

        UINT64 parse_number(const json& value) {
            if (value.is_number_unsigned()) return static_cast<UINT64>(value.get<uint64_t>());
            if (!value.is_string()) return 0;
            const std::string text = value.get<std::string>();
            if (text.empty()) return 0;
            try {
                size_t consumed = 0;
                const auto parsed = std::stoull(text, &consumed, 0);
                if (consumed != text.size()) return 0;
                return static_cast<UINT64>(parsed);
            } catch (...) {
                return 0;
            }
        }

        std::vector<std::filesystem::path> find_manifests(const std::filesystem::path& root) {
            std::vector<std::filesystem::path> result;
            std::error_code error;
            if (!std::filesystem::exists(root, error)) return result;

            std::filesystem::recursive_directory_iterator iterator(
                root,
                std::filesystem::directory_options::skip_permission_denied,
                error);
            const std::filesystem::recursive_directory_iterator end;
            while (!error && iterator != end) {
                const auto& path = iterator->path();
                std::error_code type_error;
                if (std::filesystem::is_regular_file(path, type_error)
                    && path.filename() == L"manifest.json") {
                    result.push_back(path);
                }
                iterator.increment(error);
            }
            return result;
        }

        // Extract only what offsets-only patching needs: symbol RVAs plus one
        // validation pattern each. Module identities/checksums are deliberately
        // ignored — byte-validating the RVA against the live target is the
        // launcher's only correctness gate.
        bool parse_manifest(
            const std::filesystem::path& path,
            std::string& id_out,
            int& priority_out,
            std::vector<std::pair<std::string, ManifestSymbol>>& symbols_out) {
            std::ifstream stream(path, std::ios::binary);
            if (!stream) return false;
            std::ostringstream contents;
            contents << stream.rdbuf();

            try {
                const json root = json::parse(contents.str());
                if (!root.is_object() || root.value("schema_version", 0) != 1) return false;
                if (!root.contains("profile") || !root["profile"].is_object()) return false;
                const auto& profile = root["profile"];
                if (profile.value("architecture", std::string("x64")) != "x64") return false;
                const std::string status = profile.value("status", std::string());
                const int priority = status_priority(status);
                if (priority == 0) return false;
                if (!root.contains("symbols") || !root["symbols"].is_array()) return false;

                std::vector<std::pair<std::string, ManifestSymbol>> symbols;
                for (const auto& item : root["symbols"]) {
                    if (!item.is_object() || !item.contains("name") || !item["name"].is_string())
                        continue;
                    ManifestSymbol symbol;
                    if (item.contains("rva") && !item["rva"].is_null())
                        symbol.rva = parse_number(item["rva"]);
                    if (item.contains("patterns") && item["patterns"].is_array()
                        && !item["patterns"].empty() && item["patterns"].front().is_string())
                        symbol.pattern = item["patterns"].front().get<std::string>();
                    symbols.emplace_back(item["name"].get<std::string>(), std::move(symbol));
                }

                id_out = profile.value("id", path.parent_path().filename().string());
                priority_out = priority;
                symbols_out = std::move(symbols);
                return true;
            } catch (const std::exception&) {
                return false;
            }
        }
    } // namespace

    void init(HMODULE module) {
        module_paths::init(module);
    }

    std::string log_path() {
        const auto dir = module_paths::dll_directory_wide();
        if (dir.empty()) return "tarkovaddons_launcher_log.txt";
        return (dir / L"tarkovaddons_launcher_log.txt").string();
    }

    bool load_manifest(std::string& detail) {
        detail.clear();

        const auto dll_directory = module_paths::dll_directory_wide();
        if (dll_directory.empty()) {
            detail = "could not determine the launcher DLL directory";
            return false;
        }

        const auto manifests =
            find_manifests(module_paths::data_directory_wide() / L"compatibility" / L"profiles");
        if (manifests.empty()) {
            detail = "no compatibility manifest found under <deploy>/ta/compatibility/profiles";
            return false;
        }

        std::string best_id;
        int best_priority = 0;
        std::vector<std::pair<std::string, ManifestSymbol>> best_symbols;
        for (const auto& path : manifests) {
            std::string id;
            int priority = 0;
            std::vector<std::pair<std::string, ManifestSymbol>> symbols;
            if (parse_manifest(path, id, priority, symbols) && priority > best_priority) {
                best_priority = priority;
                best_id = std::move(id);
                best_symbols = std::move(symbols);
            }
        }

        if (best_symbols.empty()) {
            detail = "compatibility manifests were found, but none parsed with usable symbols";
            return false;
        }

        g_profile_id = std::move(best_id);
        g_symbols = std::move(best_symbols);
        g_loaded.store(true);

        // A patchable symbol is one that carries both halves of a safe write:
        // an RVA and the pattern that has to match the live target there.
        size_t patchable = 0;
        for (const auto& [symbol_name, symbol] : g_symbols)
        {
            if (symbol.rva != 0 && !symbol.pattern.empty())
                ++patchable;
        }
        detail = g_profile_id + " (" + std::to_string(g_symbols.size()) + " symbols, "
            + std::to_string(patchable) + " patchable)";
        return true;
    }

    bool available() {
        return g_loaded.load();
    }

    std::string profile_id() {
        return g_loaded.load() ? g_profile_id : std::string{};
    }

    bool symbol(const char* name, UINT64& rva_out, std::string& pattern_out) {
        rva_out = 0;
        pattern_out.clear();
        if (!g_loaded.load() || name == nullptr) return false;
        for (const auto& [symbol_name, symbol] : g_symbols) {
            if (symbol_name == name) {
                rva_out = symbol.rva;
                pattern_out = symbol.pattern;
                return true;
            }
        }
        return false;
    }
} // namespace compat_profile
