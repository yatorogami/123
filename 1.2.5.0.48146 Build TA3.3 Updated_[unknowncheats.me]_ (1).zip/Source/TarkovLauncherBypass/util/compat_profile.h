#pragma once

#include <Windows.h>

#include <string>

namespace compat_profile {
    // Cache the launcher DLL directory. Call once from the worker init thread,
    // before anything else; the profile root is <dll dir>/compatibility/profiles.
    void init(HMODULE module);

    // Absolute path of the bypass log file
    // (<dll dir>/tarkovaddons_launcher_log.txt), or a bare filename when the
    // directory cannot be resolved.
    std::string log_path();

    // Load the best compatibility manifest under the profile root. The launcher
    // does NOT match module identities or verify checksums — it patches by
    // declared offset only, so any manifest of the right architecture is
    // usable and the newest status wins. Returns true and fills `detail` with
    // the profile id and symbol/patchable counts on success; fills `detail`
    // with the reason on failure.
    bool load_manifest(std::string& detail);

    // True once a manifest has been loaded.
    bool available();
    std::string profile_id();

    // The manifest is the ONLY offset source for this DLL: the legacy
    // offsets.cfg/patterns.cfg fallback and the per-build constants that used
    // to be compiled in are both gone. One lookup hands back everything a
    // patch needs — the declared RVA and the validation pattern that must match
    // the live target at that RVA.
    //
    // Returns false when the symbol is absent. `rva_out` is 0 when the symbol
    // is present but unresolved (rva: null), and `pattern_out` is empty when
    // the symbol declares no pattern; a patch needs both to be safe.
    bool symbol(const char* name, UINT64& rva_out, std::string& pattern_out);
} // namespace compat_profile
