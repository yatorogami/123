#include "hooking.h"

namespace {
    // The failures that report the address of the instruction they choked on
    // all carry it in the same `ip` union member; the rest carry allocator state
    // instead, and reporting that address would be meaningless.
    std::string at_ip(const char* name, const uint8_t* ip) {
        char buf[64];
        sprintf_s(buf, "%s @ %p", name, static_cast<const void*>(ip));
        return buf;
    }
} // namespace

void* hooking::resolve_export(const char* module_name, const char* function_name) {
    const HMODULE module = GetModuleHandleA(module_name);
    if (module == nullptr)
    {
        return nullptr;
    }
    return reinterpret_cast<void*>(GetProcAddress(module, function_name)); // NOLINT(clang-diagnostic-microsoft-cast)
}

std::string hooking::error_string(const SafetyHookError error) {
    switch (error.type)
    {
    case SafetyHookError::BAD_ALLOCATION:
        return "BAD_ALLOCATION (no memory for the trampoline)";
    case SafetyHookError::FAILED_TO_DECODE_INSTRUCTION:
        return at_ip("FAILED_TO_DECODE_INSTRUCTION", error.ip);
    case SafetyHookError::SHORT_JUMP_IN_TRAMPOLINE:
        return at_ip("SHORT_JUMP_IN_TRAMPOLINE", error.ip);
    case SafetyHookError::IP_RELATIVE_INSTRUCTION_OUT_OF_RANGE:
        return at_ip("IP_RELATIVE_INSTRUCTION_OUT_OF_RANGE", error.ip);
    case SafetyHookError::UNSUPPORTED_INSTRUCTION_IN_TRAMPOLINE:
        return at_ip("UNSUPPORTED_INSTRUCTION_IN_TRAMPOLINE", error.ip);
    case SafetyHookError::FAILED_TO_UNPROTECT:
        return at_ip("FAILED_TO_UNPROTECT", error.ip);
    case SafetyHookError::NOT_ENOUGH_SPACE:
        return at_ip("NOT_ENOUGH_SPACE", error.ip);
    }
    return "UNKNOWN";
}
