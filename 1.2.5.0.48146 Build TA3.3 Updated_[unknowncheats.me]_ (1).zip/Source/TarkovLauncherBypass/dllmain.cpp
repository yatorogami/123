#include <windows.h>

#include "feature/disabler.h"
#include "feature/injector.h"
#include "feature/spoofer.h"
#include "util/compat_profile.h"
#include "util/globals.h"
#include "util/logger.h"

DWORD WINAPI init(LPVOID parameter) {
    // Everything deferrable runs here, on the worker thread — nothing in the
    // attach path touches std::filesystem, JSON, or the loader lock.
    const HMODULE hModule = static_cast<HMODULE>(parameter);
    compat_profile::init(hModule);
    logger::set_file_log(compat_profile::log_path());
    logger::info("TarkovLauncherBypass.dll attached");
    logger::info("Worker thread init starting...");

    // The compatibility manifest is the ONLY source of patch addresses and
    // signatures for this DLL. It is still not load-bearing for attach: a
    // missing or stale manifest only means fewer/skipped patches, never a dead
    // launcher — every patch is byte-validated against the live target.
    std::string detail;
    if (compat_profile::load_manifest(detail))
        logger::info("Compatibility manifest loaded: " + detail);
    else
        logger::warn("Compatibility manifest not loaded (" + detail + ") - no patches will be applied");

    // spoof hwid
    logger::info("Initializing spoofer...");
    spoofer::init();

    // inject on start
    logger::info("Initializing injector...");
    injector::init();

    // disable anticheat (blocks until the game launch hook has run)
    logger::info("Initializing disabler (this will block until game launches)...");
    DWORD eft_pid = disabler::disable();

    if (eft_pid != 0)
    {
        logger::info("Game launched with PID: " + std::to_string(eft_pid) + ", proceeding to stage2 injection");
        Sleep(250);
        // inject dlls
        if (injector::should_inject_res())
        {
            logger::info("Injector enabled, injecting stage2 DLLs...");
            for (auto dll : injector::dlls_res())
            {
                logger::info("Injecting stage2: " + dll);
                injector::inject(eft_pid, dll);
            }
            logger::info("Stage2 injection complete");
        }
        else
        {
            logger::warn("Injector disabled, skipping stage2 injection");
        }
        // do spoofing for game
        spoofer::game(eft_pid);

        logger::info("Exiting");
        Sleep(500);
        exit(0); // NOLINT(concurrency-mt-unsafe)
    }
    logger::info("No game launched this run — launcher stays open");
    return 0;
}

void detatch() {
    disabler::exit();
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hModule);
        // Defer everything (profile init, file log, manifest load) onto the
        // worker thread — nothing here runs under the loader lock.
        CreateThread(nullptr, 0, init, hModule, 0, nullptr);
        break;
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
        // Nothing to do. These used to fall through to detatch(), which removed
        // the process-creation hooks on every thread the launcher created —
        // tearing them down moments after installing them, and doing it under
        // the loader lock on a thread that is on its way out.
        break;
    case DLL_PROCESS_DETACH:
        if (lpReserved != nullptr)
        {
            break;
        }
        detatch();
        break;
    default:;
    }

    return TRUE;
}
