//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// Spoofer is a cleaned up version of HWho by hollow
/// https://www.unknowncheats.me/forum/escape-from-tarkov/494040-hwho-slightly-fun-bsg-launcher-hwid-check-bypass.html
/// Credit goes to all original contributors.
///

#pragma once
#include <strsafe.h>
#include <Windows.h>

namespace spoofer {
    void init();

    // Patch the in-game HWID check. The address and its validation pattern both
    // come from the compatibility manifest; nothing is scanned and the module is
    // never dumped. Failure leaves the game running unpatched.
    void game(DWORD eft_pid);
}; // namespace spoofer
