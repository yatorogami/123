//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// Launcher spoofer is a cleaned up version of HWho by hollow
/// https://www.unknowncheats.me/forum/escape-from-tarkov/494040-hwho-slightly-fun-bsg-launcher-hwid-check-bypass.html
/// Credit goes to all original contributors.
///

#include "spoofer.h"

#include <fstream>
#include <iostream>
#include <random>
#include <thread>
#include <vector>
#include <windows.h>
#include <wbemcli.h>
#include <sstream>
#include <TlHelp32.h>

#include "../util/compat_profile.h"
#include "../util/globals.h"
#include "../util/hooking.h"
#include "../util/logger.h"

// The xor key is consumed as key[i % HWID_KEY_MODULUS], so anything shorter
// would read past the end of the vector.
constexpr size_t HWID_KEY_MODULUS = 8;
constexpr size_t HWID_KEY_SIZE = 12;
constexpr size_t HWID_KEY_LOG_BYTES = 12;
constexpr size_t HWID_FUNCTION_PATCH_SIZE = 5;

// How long to wait for GameAssembly before giving up on the in-game patch.
constexpr int GAMEASSEMBLY_TIMEOUT_MS = 30000;

struct RawSMBIOSData
{
    BYTE Used20CallingMethod;
    BYTE SMBIOSMajorVersion;
    BYTE SMBIOSMinorVersion;
    BYTE DmiRevision;
    DWORD Length;
    BYTE SMBIOSTableData[]; // NOLINT(clang-diagnostic-c99-extensions)
};

struct RawSMBIOSTable
{
    BYTE Type;
    BYTE Length;
    WORD Handle;
};

struct RawBiosInformationTable : RawSMBIOSTable
{
    BYTE Vendor;
    BYTE BiosVersion;
    UINT16 BiosSegment;
    BYTE BiosReleaseDate;
    UINT8 BiosSize;
};

struct RawSystemInformationTable : RawSMBIOSTable
{
    BYTE Manufacturer;
    BYTE ProductName;
    BYTE Version;
    BYTE SerialNumber;
    GUID Uuid;
    UINT8 WakeUpType;
    BYTE SKUNumber;
    BYTE Family;
};

struct RawBaseboardInformationTable : RawSMBIOSTable
{
    BYTE Manufacturer;
    BYTE ProductName;
    BYTE Version;
    BYTE SerialNumber;
};

struct RawProcessorInformationTable : RawSMBIOSTable
{
    BYTE Socket;
    UINT8 ProcessorType;
    UINT8 ProcessorFamily;
    BYTE ProcessorManufacturer;
    BYTE ProcessorId[8];
    BYTE ProcessorVersion;
    BYTE Voltage;
    UINT16 ExternalClock;
    UINT16 MaxSpeed;
    UINT16 CurrentSpeed;
    UINT8 Status;
    UINT8 ProcessorUpgrade;
    UINT16 L1CacheHandle;
    UINT16 L2CacheHandle;
    UINT16 L3CacheHandle;
    BYTE SerialNumber;
    BYTE AssetTag;
    BYTE PartNumber;
};

static std::vector<unsigned char> key = {};

static PSTR get_sm_bios_string(RawSMBIOSTable* SmBiosTable, BYTE StringIndex) {
    BYTE CurrentStringIndex = 1;
    auto currentString = reinterpret_cast<PSTR>(reinterpret_cast<BYTE*>(SmBiosTable) + SmBiosTable->Length);

    while (*currentString)
    {
        if (CurrentStringIndex == StringIndex)
        {
            break;
        }

        ++currentString;

        if (!*currentString)
        {
            ++currentString;
            ++CurrentStringIndex;
        }
    }

    if (!*currentString)
        return nullptr;

    return currentString;
}

static void mangle_sm_bios_string(RawSMBIOSTable* SmBiosTable, BYTE StringIndex) {
    char* str = get_sm_bios_string(SmBiosTable, StringIndex);
    if (!str)
    {
        return;
    }

    const auto length = strlen(str);
    for (size_t i = 0; i < length; i++)
    {
        const auto original_character = str[i];
        auto rng = original_character ^ key[i % HWID_KEY_MODULUS];

        if (std::isdigit(original_character))
            rng = static_cast<unsigned>(rng) % 10 + 48; // NOLINT(bugprone-narrowing-conversions, cppcoreguidelines-narrowing-conversions)
        else
            continue;

        rng &= 0x7F; // remove extended ascii
        str[i] = static_cast<char>(rng);
    }
}

// The hook objects own the patched bytes and the trampoline the two hk*
// functions below call into, so they are file-scope and outlive every call.
// Neither is ever reset: both live for the lifetime of the launcher process.
static SafetyHookInline get_system_firmware_table_hook;
static SafetyHookInline wbem_object_get_hook;

UINT (*oGetSystemFirmwareTable)(DWORD, DWORD, PVOID, DWORD) = nullptr;

UINT __stdcall hkGetSystemFirmwareTable(DWORD FirmwareTableProviderSignature, DWORD FirmwareTableID,
    PVOID pFirmwareTableBuffer, DWORD BufferSize) {
    UINT result = oGetSystemFirmwareTable(FirmwareTableProviderSignature, FirmwareTableID, pFirmwareTableBuffer,
        BufferSize);

    if (FirmwareTableProviderSignature == 'RSMB' && FirmwareTableID == 0 && pFirmwareTableBuffer != nullptr)
    {
        auto SMBIOSData = static_cast<RawSMBIOSData*>(pFirmwareTableBuffer);
        RawSMBIOSTable* smbiosTable = nullptr;
        ULONG i = 0;

        bool properTermination;

        do
        {
            properTermination = false;

            // Check that the table header fits in the buffer.
            if (i + sizeof(RawSMBIOSTable) < SMBIOSData->Length)
            {
                ULONG type = SMBIOSData->SMBIOSTableData[i];

                if (type <= 4)
                    smbiosTable = reinterpret_cast<RawSMBIOSTable*>(&SMBIOSData->SMBIOSTableData[i]);

                // Set i to the end of the formated section.
                i += SMBIOSData->SMBIOSTableData[i + 1];

                // Look for the end of the struct that must be terminated by \0\0
                while (i + 1 < SMBIOSData->Length)
                {
                    if (0 == SMBIOSData->SMBIOSTableData[i] && 0 == SMBIOSData->SMBIOSTableData[i + 1])
                    {
                        properTermination = true;
                        i += 2;
                        break;
                    }

                    ++i;
                }

                if (properTermination && smbiosTable)
                {
                    switch (type)
                    {
                    case 0: {
                        auto biosInfo = static_cast<RawBiosInformationTable*>(smbiosTable);
                        mangle_sm_bios_string(smbiosTable, biosInfo->Vendor);
                        mangle_sm_bios_string(smbiosTable, biosInfo->BiosVersion);
                        mangle_sm_bios_string(smbiosTable, biosInfo->BiosReleaseDate);
                    }
                    break;

                    case 1: {
                        auto systemInfo = static_cast<RawSystemInformationTable*>(smbiosTable);

                        mangle_sm_bios_string(smbiosTable, systemInfo->Manufacturer);
                        mangle_sm_bios_string(smbiosTable, systemInfo->ProductName);
                        mangle_sm_bios_string(smbiosTable, systemInfo->Version);
                        mangle_sm_bios_string(smbiosTable, systemInfo->SerialNumber);

                        if (systemInfo->Length > 25)
                        {
                            mangle_sm_bios_string(smbiosTable, systemInfo->SKUNumber);
                            mangle_sm_bios_string(smbiosTable, systemInfo->Family);
                        }

                        auto guidPtr = reinterpret_cast<char*>(&systemInfo->Uuid);
                        for (size_t j = 0; j < sizeof(GUID); j++)
                            guidPtr[j] ^= key[j % HWID_KEY_MODULUS]; // NOLINT(bugprone-narrowing-conversions, cppcoreguidelines-narrowing-conversions)
                    }
                    break;

                    case 2: {
                        auto baseboardInfo = static_cast<RawBaseboardInformationTable*>(smbiosTable);

                        mangle_sm_bios_string(smbiosTable, baseboardInfo->Manufacturer);
                        mangle_sm_bios_string(smbiosTable, baseboardInfo->ProductName);
                        mangle_sm_bios_string(smbiosTable, baseboardInfo->Version);
                        mangle_sm_bios_string(smbiosTable, baseboardInfo->SerialNumber);
                    }
                    break;

                    case 4: {
                        auto processorInfo = static_cast<RawProcessorInformationTable*>(smbiosTable);

                        mangle_sm_bios_string(smbiosTable, processorInfo->ProcessorManufacturer);
                        mangle_sm_bios_string(smbiosTable, processorInfo->ProcessorVersion);
                        if (processorInfo->Length > 32)
                        {
                            mangle_sm_bios_string(smbiosTable, processorInfo->SerialNumber);
                            mangle_sm_bios_string(smbiosTable, processorInfo->PartNumber);
                        }

                        for (int j = 0; j < 4; j++) // PROCESSOR_SIGNATURE
                            processorInfo->ProcessorId[j] ^= key[j % HWID_KEY_MODULUS];
                    }
                    break;

                    default:
                        break;
                    }

                    smbiosTable = nullptr;
                }
            }
        } while (properTermination);
    }

    return result;
}

HRESULT (*oGetFn)(IWbemClassObject*, LPCWSTR, LONG, VARIANT*, CIMTYPE*, long*) = nullptr;

HRESULT __stdcall hkGetFn(IWbemClassObject* pThis, LPCWSTR wszName, LONG lFlags, VARIANT* pVal, CIMTYPE* pType,
    long* plFlavor) {
    const auto original_result = oGetFn(pThis, wszName, lFlags, pVal, pType, plFlavor);

    // only process strings
    if (pVal->vt != VT_BSTR)
        return original_result;

    // ignored values
    if (lstrcmpW(wszName, L"__GENUS") == 0 || lstrcmpW(wszName, L"__PATH") == 0 || lstrcmpW(wszName, L"__RELPATH") == 0)
    {
        return original_result;
    }

    const size_t length = lstrlenW(pVal->bstrVal);
    for (size_t i = 0; i < length; i++)
    {
        const auto original_character = static_cast<char>(pVal->bstrVal[i]);
        auto rng = original_character ^ key[i % HWID_KEY_MODULUS];

        if (std::isdigit(original_character))
            rng = static_cast<unsigned>(rng) % 10 + 48; // NOLINT(bugprone-narrowing-conversions, cppcoreguidelines-narrowing-conversions)
        else
            continue;

        rng &= 0x7F; // remove extended ascii
        pVal->bstrVal[i] = static_cast<WCHAR>(rng);
    }

    return original_result;
}

namespace spoofer {
    static bool should_spoof = false;

    const std::string HWID_FILE = "hwid.bin";
    const std::string GAMEASSEMBLY = "GameAssembly.dll";

    void init() {
        std::ifstream config_file(globals::DLL_CONFIG_FILE);
        if (config_file)
        {
            std::string enabled_string;
            for (int i = 0; i < 3; ++i)
            {
                std::getline(config_file, enabled_string);
            }
            enabled_string = enabled_string.substr(8);
            if (enabled_string != "true") return;
        }
        else
        {
            return;
        }
        logger::info("Spoofer Enabled");
        should_spoof = true;
        config_file.close();

        std::basic_ifstream<unsigned char> file(HWID_FILE, std::ios::binary);
        if (file)
        {
            key = std::vector<unsigned char>((std::istreambuf_iterator<unsigned char>(file)),
                std::istreambuf_iterator<unsigned char>());
            if (key.size() < HWID_KEY_MODULUS)
            {
                // A truncated or empty hwid.bin would make every mangle below
                // read out of bounds. Treat it as absent and mint a new key.
                logger::warn("hwid.bin holds " + std::to_string(key.size())
                    + " bytes, need at least " + std::to_string(HWID_KEY_MODULUS) + " - regenerating");
                key.clear();
            }
        }

        if (key.empty())
        {
            logger::info("Generating HWID Key");
            key.reserve(HWID_KEY_SIZE);
            for (size_t i = 0; i < HWID_KEY_SIZE; i++)
            {
                key.emplace_back(globals::int_rand(0, 0xFF));
            }

            std::ofstream fout(HWID_FILE, std::ios::out | std::ios::binary);
            fout.write(reinterpret_cast<char*>(key.data()), static_cast<std::streamsize>(key.size()));
        }

        std::stringstream ss;
        for (size_t i = 0; i < key.size() && i < HWID_KEY_LOG_BYTES; i++)
            ss << std::hex << (key[i] & 0xFF);
        logger::info("Key: " + ss.str());

        // fastprox.dll backs the WMI query the launcher uses to read hardware
        // ids, and it loads lazily. Poll for it, but never forever: init() runs
        // ahead of the process-creation hook, so a launcher that never loads
        // fastprox would otherwise never install that hook and no game launch
        // would ever be seen.
        constexpr int FASTPROX_TIMEOUT_MS = 10000;
        HMODULE fastprox = nullptr;
        for (int waited = 0; fastprox == nullptr && waited < FASTPROX_TIMEOUT_MS; waited += 100)
        {
            fastprox = GetModuleHandleA("fastprox.dll");
            if (fastprox == nullptr)
                Sleep(100);
        }
        if (fastprox == nullptr)
        {
            logger::warn("fastprox.dll not loaded after " + std::to_string(FASTPROX_TIMEOUT_MS / 1000)
                + "s - HWID spoofing disabled, game launch continues");
            should_spoof = false;
            return;
        }

        const auto getFn = GetProcAddress(fastprox, "?Get@CWbemObject@@UEAAJPEBGJPEAUtagVARIANT@@PEAJ2@Z");
        if (getFn == nullptr)
        {
            logger::error("Failed to find get function - HWID spoofing disabled");
            should_spoof = false;
            return;
        }

        const auto getSystemFirmwareTable =
            GetProcAddress(GetModuleHandleA("KernelBase.dll"), "GetSystemFirmwareTable");
        if (getSystemFirmwareTable == nullptr)
        {
            logger::error("Failed to find firmware function - HWID spoofing disabled");
            should_spoof = false;
            return;
        }

        // Detours' DetourAttach wrote the trampoline back through the same
        // pointer it was handed as the target, so the target address and the
        // trampoline shared one variable. SafetyHook keeps them apart: create()
        // takes the still-unpatched target, and the trampoline is read back from
        // the hook with original<T>().
        auto created_get = SafetyHookInline::create(getFn, hkGetFn);
        if (!created_get)
        {
            logger::error("Failed to hook get function - HWID spoofing disabled: " + hooking::error_string(created_get.error()));
            should_spoof = false;
            return;
        }
        wbem_object_get_hook = std::move(created_get.value());
        oGetFn = wbem_object_get_hook.original<HRESULT (*)(IWbemClassObject*, LPCWSTR, LONG, VARIANT*, CIMTYPE*, long*)>();

        auto created_firmware = SafetyHookInline::create(getSystemFirmwareTable, hkGetSystemFirmwareTable);
        if (!created_firmware)
        {
            logger::error("Failed to hook firmware function - HWID spoofing disabled: " + hooking::error_string(created_firmware.error()));
            should_spoof = false;
            return;
        }
        get_system_firmware_table_hook = std::move(created_firmware.value());
        oGetSystemFirmwareTable = get_system_firmware_table_hook.original<UINT (*)(DWORD, DWORD, PVOID, DWORD)>();
    }

    void game(DWORD eft_pid) {
        if (!should_spoof) return;

        // The manifest is the only source: an RVA for the check plus the
        // pattern that has to match the live module there. The old code
        // ignored the RVA when it had one, dumped the whole ~100 MB GameAssembly
        // and scanned up to 256 MB for a signature compiled into this DLL —
        // which is also the one place that used to kill the game outright when
        // the check could not be located.
        UINT64 hwid_check_rva = 0;
        std::string hwid_check_pattern;
        if (!compat_profile::symbol("hwid_check", hwid_check_rva, hwid_check_pattern))
        {
            logger::warn("hwid_check is not in the compatibility manifest - in-game HWID check left alone");
            return;
        }
        if (hwid_check_rva == 0 || hwid_check_pattern.empty())
        {
            logger::warn("hwid_check declares no RVA/pattern pair in the manifest - check left alone");
            return;
        }

        HANDLE eft = OpenProcess(PROCESS_ALL_ACCESS, false, eft_pid);
        if (eft == nullptr)
        {
            logger::error("Could not open the game process for the HWID patch");
            return;
        }

        // Find GameAssembly.dll. A missing module is not fatal: the check is
        // simply not patched and the game plays on.
        uintptr_t game_assembly = 0;
        for (int waited = 0;
             game_assembly == 0 && waited < GAMEASSEMBLY_TIMEOUT_MS;
             waited += 100)
        {
            HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, eft_pid);
            if (snapshot != INVALID_HANDLE_VALUE)
            {
                MODULEENTRY32W me32;
                me32.dwSize = sizeof(MODULEENTRY32W);

                if (Module32FirstW(snapshot, &me32))
                {
                    do
                    {
                        if (std::wstring(me32.szModule) == std::wstring(GAMEASSEMBLY.begin(), GAMEASSEMBLY.end()))
                        {
                            game_assembly = reinterpret_cast<uintptr_t>(me32.modBaseAddr);
                            break;
                        }
                    } while (Module32NextW(snapshot, &me32));
                }
                CloseHandle(snapshot);
            }
            if (game_assembly == 0)
                Sleep(100);
        }

        if (game_assembly == 0)
        {
            logger::error("GameAssembly never appeared - in-game HWID check left alone");
            CloseHandle(eft);
            return;
        }

        // Byte-validate the manifest RVA against the live module before writing.
        if (!globals::remote_bytes_match(eft, game_assembly + hwid_check_rva, hwid_check_pattern))
        {
            logger::warn("hwid_check @ 0x" + std::to_string(hwid_check_rva)
                + " rejected by byte check against the live module - check left alone");
            CloseHandle(eft);
            return;
        }

        logger::info("Patching HWID Check");

        // replace check function call by setting rax to 0 so we never check hwid
        byte shellcode[HWID_FUNCTION_PATCH_SIZE] = {
            0x48, 0x31, 0xC0, // xor rax, rax
            0x90,             // nop
            0x90              // nop
        };

        auto* address = reinterpret_cast<PVOID>(game_assembly + hwid_check_rva); // NOLINT(performance-no-int-to-ptr)
        if (!WriteProcessMemory(eft, address, shellcode, HWID_FUNCTION_PATCH_SIZE, nullptr))
        {
            logger::error("HWID Function Patch Failed - game continues unpatched");
            CloseHandle(eft);
            return;
        }

        CloseHandle(eft);
        logger::info("HWID Resolution Patched");
    }
} // namespace spoofer
