//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// Disabler is a cleaned up version of PVE BattlEye Bypass by x3e
/// https://www.unknowncheats.me/forum/escape-from-tarkov/728902-pve-battleyent-alternative.html
/// Credit goes to all original contributors.
///
/// Manifest-only edition: every patch target comes from the shared
/// compatibility manifest (compatibility/profiles/<build>/manifest.json),
/// which is the single source of addresses and signatures for this DLL — the
/// offsets.cfg/patterns.cfg fallback and the per-build constants that used to
/// be compiled in here are both gone. Each declared RVA is byte-validated
/// against a small live window in the target process before anything is
/// written, and a target that fails validation, or that the manifest does not
/// resolve, is skipped with a warning instead of aborting the launch. No module
/// dumps, no pattern scanning, no identity/checksum verification.

#include "disabler.h"

#include <cstdint>
#include <fstream>
#include <psapi.h>
#include <shlwapi.h>
#include <string>
#include <vector>

#include "../libs/ntdll.h"

#include "../util/compat_profile.h"
#include "../util/globals.h"
#include "../util/hooking.h"
#include "../util/logger.h"

#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "ntdll.lib")

static bool eft_ready = false;
static DWORD eft_pid = 0;

void patch_bytes(const HANDLE hProcess, void* address, const std::vector<std::uint8_t>& data) {
    const size_t size = data.size();
    DWORD dwOldProtect = 0;
    VirtualProtectEx(hProcess, address, size, PAGE_EXECUTE_READWRITE, &dwOldProtect);
    WriteProcessMemory(hProcess, address, data.data(), size, nullptr);
    FlushInstructionCache(hProcess, address, size);
    VirtualProtectEx(hProcess, address, size, dwOldProtect, &dwOldProtect);
}

static HMODULE find_module(const HANDLE hProcess, const char* name) {
    HMODULE hMods[1024];
    DWORD cbNeeded;
    char szModName[MAX_PATH];

    if (!EnumProcessModules(hProcess, hMods, sizeof(hMods), &cbNeeded))
    {
        return nullptr;
    }

    for (unsigned int i = 0; i < cbNeeded / sizeof(HMODULE); i++)
    {
        if (GetModuleFileNameExA(hProcess, hMods[i], szModName, sizeof(szModName) / sizeof(char)))
        {
            if (StrStrIA(szModName, name))
            {
                return hMods[i];
            }
        }
    }

    return nullptr;
}

// One patch target: the manifest symbol it comes from, and the shape of the
// write. The RVA and the validation pattern both come from the manifest — there
// is no cfg fallback and no per-build constant compiled in here.
struct PatchTarget {
    const char* name;  // manifest symbol name
    bool return_false; // true when the patch must report failure, false for a bare ret
};

static const PatchTarget kUnityPlayerTarget = {
    "be_service_check", false};

static const PatchTarget kGameAssemblyTargets[] = {
    {"load_be_client", false},
    {"be_client_start", false},
    {"be_client_init", true},
};

// Resolve a symbol to a byte-validated RVA in the target process, or 0 when the
// manifest has nothing usable for it or the live bytes disagree. A rejected
// symbol is skipped with a warning — a stale profile costs one patch, never the
// launch.
static UINT64 resolve_remote(HANDLE hProcess, uintptr_t module_base, const PatchTarget& target) {
    UINT64 rva = 0;
    std::string pattern;
    if (!compat_profile::symbol(target.name, rva, pattern))
    {
        logger::warn(std::string(target.name) + ": not in the compatibility manifest — patch skipped");
        return 0;
    }
    if (rva == 0 || pattern.empty())
    {
        logger::warn(std::string(target.name) + ": manifest declares no RVA/pattern pair — patch skipped");
        return 0;
    }

    char buf[160];
    if (!globals::remote_bytes_match(hProcess, module_base + rva, pattern))
    {
        sprintf_s(buf, "%s @ 0x%llX rejected by byte check against the live module",
            target.name, static_cast<unsigned long long>(rva));
        logger::warn(buf);
        return 0;
    }

    sprintf_s(buf, "%s @ 0x%llX (validated)", target.name,
        static_cast<unsigned long long>(rva));
    logger::info(buf);
    return rva;
}

// Redirect the BattlEye build to the plain game executable.
static std::wstring redirect_to_plain_build(LPCWSTR lpCommandLine) {
    std::wstring commandLine(lpCommandLine);
    const std::wstring from = L"EscapeFromTarkov_BE";
    const std::wstring to = L"EscapeFromTarkov";
    size_t pos = 0;
    while ((pos = commandLine.find(from, pos)) != std::wstring::npos)
    {
        commandLine.replace(pos, from.length(), to);
        pos += to.length();
    }
    return commandLine;
}

// Resolve the entry point of a freshly created, still suspended process from its
// PEB. Returns 0 when the remote headers cannot be read.
static uintptr_t remote_entry_point(const HANDLE hProcess) {
    PROCESS_BASIC_INFORMATION pbi;
    if (!NT_SUCCESS(NtQueryInformationProcess(
            hProcess, ProcessBasicInformation, &pbi, sizeof(pbi), nullptr)))
    {
        logger::error("Failed to get pbi");
        return 0;
    }

    PEB peb = {};
    if (!ReadProcessMemory(hProcess, pbi.PebBaseAddress, &peb, sizeof(peb), nullptr))
    {
        logger::error("Failed to read the game PEB");
        return 0;
    }

    IMAGE_DOS_HEADER idh = {};
    if (!ReadProcessMemory(hProcess, peb.ImageBaseAddress, &idh, sizeof(idh), nullptr))
    {
        logger::error("Failed to read the game DOS header");
        return 0;
    }

    IMAGE_NT_HEADERS inh = {};
    if (!ReadProcessMemory(
            hProcess,
            reinterpret_cast<LPVOID>( // NOLINT(performance-no-int-to-ptr)
                reinterpret_cast<ULONG_PTR>(peb.ImageBaseAddress) + idh.e_lfanew),
            &inh,
            sizeof(inh),
            nullptr))
    {
        logger::error("Failed to read the game NT headers");
        return 0;
    }

    return inh.OptionalHeader.AddressOfEntryPoint + inh.OptionalHeader.ImageBase;
}

// The single post-create path shared by both process-creation hooks: park the
// game on its entry point, apply the BattlEye patches, then let it run. One
// implementation is what keeps the CreateProcessW fallback from creating a
// suspended process that nobody ever resumes (a game frozen at its first
// instruction, with no BattlEye patch applied).
static void launch_game(const HANDLE hProcess, const HANDLE hThread) {
    const uintptr_t entry = remote_entry_point(hProcess);
    if (entry == 0)
    {
        logger::error("Could not resolve the game entry point — no patches applied");
        // Release the launcher regardless: disable() blocks until this flag.
        eft_ready = true;
        return;
    }

    // Trampoline: EB FE is an infinite jump, so the process parks on its first
    // instruction and cannot reach the BattlEye init while we patch.
    std::vector<uint8_t> original(2, 0);
    ReadProcessMemory(hProcess, reinterpret_cast<LPVOID>(entry), original.data(), original.size(), nullptr); // NOLINT(performance-no-int-to-ptr)
    patch_bytes(hProcess, reinterpret_cast<LPVOID>(entry), {0xEB, 0xFE});                                   // NOLINT(performance-no-int-to-ptr)
    ResumeThread(hThread);

    // Wait until the thread is parked on the trap, then hold it there. For a
    // thread that has not suspended itself, GetThreadContext reports its initial
    // context — whose Rip is the entry point — so this normally succeeds on the
    // first poll. This project is x64-only (the Win32 configurations were removed
    // as dead), which is why reading Rip directly is correct here.
    CONTEXT context = {};
    context.ContextFlags = CONTEXT_CONTROL;
    bool frozen = false;
    for (int attempt = 0; attempt < 50; ++attempt)
    {
        if (GetThreadContext(hThread, &context) && context.Rip == entry)
        {
            frozen = true;
            break;
        }
        Sleep(100);
    }

    // Both the manifest and the patch bytes are resolved once, here: the
    // offsets.cfg/patterns.cfg pair this DLL used to read alongside the manifest
    // is gone, so a missing or stale profile is the only way a patch is lost.
    if (!frozen)
    {
        // The park never confirmed. Put the real entry point back and carry on
        // without the UnityPlayer patch: the GameAssembly patches below are what
        // keep BattlEye out, and a missed service check is not worth a launch that
        // hangs with the process spinning on its own trampoline.
        logger::error("Entrypoint timed out - restoring the entry point, skipping be_service_check");
        patch_bytes(hProcess, reinterpret_cast<LPVOID>(entry), original); // NOLINT(performance-no-int-to-ptr)
    }
    else
    {
        SuspendThread(hThread);

        // UnityPlayer-side patch while the game is held at its entry point.
        // A missing module or offset only skips this one patch.
        HMODULE hUnityPlayer = find_module(hProcess, "UnityPlayer");
        if (!hUnityPlayer)
        {
            logger::warn("UnityPlayer not loaded at entry - be_service_check skipped");
        }
        else
        {
            const UINT64 rva =
                resolve_remote(hProcess, reinterpret_cast<uintptr_t>(hUnityPlayer), kUnityPlayerTarget);
            if (rva != 0)
            {
                // B0 01 mov al, 1 / C3 ret — report "service OK"
                patch_bytes(hProcess,
                    reinterpret_cast<void*>(reinterpret_cast<uintptr_t>(hUnityPlayer) + rva), // NOLINT(performance-no-int-to-ptr)
                    {0xB0, 0x01, 0xC3});
                logger::info("Patched be_service_check (return true)");
            }
        }

        patch_bytes(hProcess, reinterpret_cast<LPVOID>(entry), original); // NOLINT(performance-no-int-to-ptr)
        ResumeThread(hThread);
    }

    HMODULE hGameAssembly;
    while (!((hGameAssembly = find_module(hProcess, "GameAssembly"))))
    {
        Sleep(10);
    }

    // Let the loader finish mapping sections before we read/patch.
    Sleep(500);

    int patches = 0;
    for (const PatchTarget& target : kGameAssemblyTargets)
    {
        const UINT64 rva =
            resolve_remote(hProcess, reinterpret_cast<uintptr_t>(hGameAssembly), target);
        if (rva == 0)
        {
            continue;
        }
        auto* address = reinterpret_cast<void*>( // NOLINT(performance-no-int-to-ptr)
            reinterpret_cast<uintptr_t>(hGameAssembly) + rva);
        if (target.return_false)
        {
            // xor eax, eax; ret — Init fails cleanly instead of loading BEClient DLL
            patch_bytes(hProcess, address, {0x31, 0xC0, 0xC3});
            logger::info("Patched BattlEye.BEClient.Init -> return 0");
        }
        else
        {
            // ret — never call the BattlEye entry
            patch_bytes(hProcess, address, {0xC3});
            logger::info(std::string("Patched ") + target.name + " -> ret");
        }
        ++patches;
    }

    if (patches == 0)
    {
        logger::error(
            "No GameAssembly BE targets patched — game runs with BattlEye intact "
            "(the manifest must declare an RVA and a validation pattern for each of "
            "load_be_client, be_client_start and be_client_init)");
    }

    logger::info("Disabler patches applied, total patches: " + std::to_string(patches));
    eft_ready = true;
}

using CreateProcessInternalW_t = BOOL(WINAPI*)(
    HANDLE hUserToken,
    LPCWSTR lpApplicationName,
    LPWSTR lpCommandLine,
    LPSECURITY_ATTRIBUTES lpProcessAttributes,
    LPSECURITY_ATTRIBUTES lpThreadAttributes,
    BOOL bInheritHandles,
    DWORD dwCreationFlags,
    LPVOID lpEnvironment,
    LPCWSTR lpCurrentDirectory,
    LPSTARTUPINFOW lpStartupInfo,
    LPPROCESS_INFORMATION lpProcessInformation,
    PHANDLE hRestrictedUserToken);

using CreateProcessW_t = BOOL(WINAPI*)(
    LPCWSTR lpApplicationName,
    LPWSTR lpCommandLine,
    LPSECURITY_ATTRIBUTES lpProcessAttributes,
    LPSECURITY_ATTRIBUTES lpThreadAttributes,
    BOOL bInheritHandles,
    DWORD dwCreationFlags,
    LPVOID lpEnvironment,
    LPCWSTR lpCurrentDirectory,
    LPSTARTUPINFOW lpStartupInfo,
    LPPROCESS_INFORMATION lpProcessInformation);

// The hook objects own the patched bytes and the trampoline, so they have to
// outlive every call into the trampolines below - they are file-scope and are
// only released in disabler::exit(). SafetyHook has no transaction object: the
// equivalent of Detours' DetourAttach(&original, &detour) is create(), and the
// trampoline is read back with original<T>().
static SafetyHookInline create_process_internal_w_hook;
static SafetyHookInline create_process_w_hook;

static CreateProcessInternalW_t oCreateProcessInternalW = nullptr;
static CreateProcessW_t oCreateProcessW = nullptr;

BOOL WINAPI hkCreateProcessW(
    LPCWSTR lpApplicationName,
    LPWSTR lpCommandLine,
    LPSECURITY_ATTRIBUTES lpProcessAttributes,
    LPSECURITY_ATTRIBUTES lpThreadAttributes,
    BOOL bInheritHandles,
    DWORD dwCreationFlags,
    LPVOID lpEnvironment,
    LPCWSTR lpCurrentDirectory,
    LPSTARTUPINFOW lpStartupInfo,
    LPPROCESS_INFORMATION lpProcessInformation) {
    if (lpCommandLine)
    {
        char cmd_buf[121] = {};
        WideCharToMultiByte(CP_UTF8, 0, lpCommandLine, -1, cmd_buf, 120, nullptr, nullptr);
        logger::info(std::string("CreateProcessW called: ") + cmd_buf);
    }
    else
    {
        logger::info("CreateProcessW called (no command line)");
    }

    if (lpCommandLine && wcsstr(lpCommandLine, L"EscapeFromTarkov_BE"))
    {
        logger::info("CreateProcessW: Game launch detected!");
        std::wstring commandLine = redirect_to_plain_build(lpCommandLine);

        STARTUPINFOW si;
        ZeroMemory(&si, sizeof(si));
        si.cb = sizeof(si);

        PROCESS_INFORMATION pi;
        ZeroMemory(&pi, sizeof(pi));

        // CreateProcessW takes 10 parameters (no hRestrictedUserToken) — the
        // extra trailing nullptr was a copy from the InternalW call below.
        const auto ret = oCreateProcessW(
            nullptr,
            const_cast<LPWSTR>(commandLine.data()),
            nullptr,
            nullptr,
            false,
            CREATE_SUSPENDED,
            nullptr,
            lpCurrentDirectory,
            &si,
            &pi);

        if (!ret)
        {
            logger::error("CreateProcessW: game process creation failed");
            return ret;
        }

        eft_pid = GetProcessId(pi.hProcess);
        logger::info("CreateProcessW: Game process created, PID: " + std::to_string(eft_pid));

        // Same path as the primary hook: park, patch, resume. This fallback used
        // to create the game suspended and walk away, leaving it frozen on its
        // first instruction with BattlEye intact and the launcher reporting a
        // successful launch.
        launch_game(pi.hProcess, pi.hThread);

        return ret;
    }

    return oCreateProcessW(
        lpApplicationName,
        lpCommandLine,
        lpProcessAttributes,
        lpThreadAttributes,
        bInheritHandles,
        dwCreationFlags,
        lpEnvironment,
        lpCurrentDirectory,
        lpStartupInfo,
        lpProcessInformation);
}

BOOL WINAPI hkCreateProcessInternalW(
    HANDLE hUserToken,
    LPCWSTR lpApplicationName,
    LPWSTR lpCommandLine,
    LPSECURITY_ATTRIBUTES lpProcessAttributes,
    LPSECURITY_ATTRIBUTES lpThreadAttributes,
    BOOL bInheritHandles,
    DWORD dwCreationFlags,
    LPVOID lpEnvironment,
    LPCWSTR lpCurrentDirectory,
    LPSTARTUPINFOW lpStartupInfo,
    LPPROCESS_INFORMATION lpProcessInformation,
    PHANDLE hRestrictedUserToken) {
    // Diagnostic: log every call so we can see if the hook fires at all
    if (lpCommandLine)
    {
        // Log first 120 chars of command line (wide to narrow)
        char cmd_buf[121] = {};
        WideCharToMultiByte(CP_UTF8, 0, lpCommandLine, -1, cmd_buf, 120, nullptr, nullptr);
        logger::info(std::string("CreateProcessInternalW called: ") + cmd_buf);
    }
    else
    {
        logger::info("CreateProcessInternalW called (no command line)");
    }

    if (lpCommandLine && wcsstr(lpCommandLine, L"EscapeFromTarkov_BE"))
    {
        logger::info("Game launch detected! EscapeFromTarkov_BE found in command line");
        std::wstring commandLine = redirect_to_plain_build(lpCommandLine);

        STARTUPINFOW si;
        ZeroMemory(&si, sizeof(si));
        si.cb = sizeof(si);

        PROCESS_INFORMATION pi;
        ZeroMemory(&pi, sizeof(pi));

        const auto ret = oCreateProcessInternalW(
            nullptr,
            nullptr,
            const_cast<LPWSTR>(commandLine.data()),
            nullptr,
            nullptr,
            false,
            CREATE_SUSPENDED,
            nullptr,
            lpCurrentDirectory,
            &si,
            &pi,
            nullptr);

        if (!ret)
        {
            logger::error("CreateProcessInternalW: game process creation failed");
            return ret;
        }

        eft_pid = GetProcessId(pi.hProcess);
        logger::info("Game process created, PID: " + std::to_string(eft_pid));

        launch_game(pi.hProcess, pi.hThread);

        return ret;
    }

    return oCreateProcessInternalW(
        hUserToken,
        lpApplicationName,
        lpCommandLine,
        lpProcessAttributes,
        lpThreadAttributes,
        bInheritHandles,
        dwCreationFlags,
        lpEnvironment,
        lpCurrentDirectory,
        lpStartupInfo,
        lpProcessInformation,
        hRestrictedUserToken);
}

namespace disabler {
    DWORD disable() {
        std::ifstream config_file(globals::DLL_CONFIG_FILE);
        if (config_file)
        {
            std::string enabled_string;
            for (int i = 0; i < 4; ++i)
            {
                std::getline(config_file, enabled_string);
            }
            enabled_string = enabled_string.substr(9);
            if (enabled_string != "true") return 0;
        }
        else
        {
            return 0;
        }
        logger::info("Disabler Enabled");
        config_file.close();

        logger::info("Setting up CreateProcessInternalW hook...");

        // Detours needed DetourRestoreAfterWith() here to clear payloads left by
        // a previous Detours-based injection into the same launcher process.
        // SafetyHook keeps no such on-disk payload, so there is nothing to
        // restore: the two hooks below are the only patched code this DLL owns.
        auto* const create_process_internal_w =
            hooking::resolve_export("KernelBase.dll", "CreateProcessInternalW");
        if (create_process_internal_w == nullptr)
        {
            logger::error("CreateProcessInternalW not found in KernelBase.dll");
            return 0;
        }
        logger::info(
            "Found CreateProcessInternalW at: " + std::to_string(reinterpret_cast<uintptr_t>(create_process_internal_w)));

        auto created_internal =
            SafetyHookInline::create(create_process_internal_w, hkCreateProcessInternalW);
        if (!created_internal)
        {
            logger::error("Failed to hook CreateProcessInternalW: " + hooking::error_string(created_internal.error()));
            return 0;
        }

        create_process_internal_w_hook = std::move(created_internal.value());
        oCreateProcessInternalW = create_process_internal_w_hook.original<CreateProcessInternalW_t>();
        logger::info("CreateProcessInternalW hook installed, waiting for game launch...");

        // Also hook CreateProcessW as a fallback
        auto* const create_process_w = hooking::resolve_export("KernelBase.dll", "CreateProcessW");
        if (create_process_w == nullptr)
        {
            logger::warn("CreateProcessW not found in KernelBase.dll");
        }
        else if (auto created_w = SafetyHookInline::create(create_process_w, hkCreateProcessW); !created_w)
        {
            logger::warn("Failed to hook CreateProcessW: " + hooking::error_string(created_w.error()));
        }
        else
        {
            create_process_w_hook = std::move(created_w.value());
            oCreateProcessW = create_process_w_hook.original<CreateProcessW_t>();
            logger::info("CreateProcessW hook also installed");
        }

        // Wait for game launch with timeout (5 minutes)
        int timeout_ms = 300000;
        int elapsed = 0;
        while (!eft_ready && elapsed < timeout_ms)
        {
            Sleep(100);
            elapsed += 100;
        }

        if (!eft_ready)
        {
            logger::error("Timeout waiting for game launch after " + std::to_string(timeout_ms / 1000) + " seconds");
            return 0;
        }

        return eft_pid;
    }

    void exit() {
        // Detours' DetourDetach only ever removed the CreateProcessInternalW
        // hook, which left the CreateProcessW fallback still patched in a
        // process that could go on calling it. Both are released here; a hook
        // that was never installed is simply empty.
        create_process_w_hook.reset();
        create_process_internal_w_hook.reset();
        oCreateProcessW = nullptr;
        oCreateProcessInternalW = nullptr;
    }
} // namespace disabler
