#include "common.h"
#include "menu.h"

#include <algorithm>
#include <cstddef>
#include <cmath>
#include <filesystem>
#include <functional>
#include <string>
#include <string_view>
#include <vector>
#include <windows.h>

#include "resources.h"
#include "../dxhook/dxhook.h"
#include "card_fold_state.h"
#include "changed_marker_layout.h"
#include "column_layout.h"
#include "imgui_addons.h"
#include "quick_search.h"
#include "../../module/ModuleManager.h"
#include "../../module/hotkeys.h"
#include "../../util/globals.h"
#include "../../util/i18n.h"
#include "../../../shared/module_paths.h"
#include "../../util/pe_resource.h"
#include "../../util/utils.h"
#include "../../external/stb/stb_image.h"

namespace menu {
    namespace {
        bool draw_imgui = false;
        float widthh;
        float heightt;
        float scale_factor;
        float font_size;
        float large_font_size;
        float hud_font_size;
        // The three UI faces and the HUD face. The names say which is which:
        // "poppins" belonged to the era when the menu loaded Poppins from a
        // generated array, and `ui_regular` is Inter today.
        ImFont* ui_regular;
        ImFont* ui_bold;
        ImFont* mono_face;
        ImFont* icons;
        ImFont* hud_font_face;
        ImFont* hud_mono_face;
        ImTextureID menu_background_texture = ImTextureID_Invalid;
        ID3D12Resource* menu_background_resource = nullptr;
        int menu_background_width = 0;
        int menu_background_height = 0;
        double menu_background_next_attempt = 0.0;
        const char* menu_background_status = "Waiting for graphics device";

        // The artwork is NOT held as a C array. It used to be a second copy in
        // .data, generated into menu_background_bytes.inc, and that file was
        // deleted -- see the note on the three load paths in
        // ensure_menu_background_texture() below.

        ModuleCategory selected_tab = RaidDashboard;

        // ------------------------------------------------------------------
        // QUICK JUMP (Ctrl+K).
        //
        // The menu has 31 cards across ten tabs, and a card is only reachable
        // by knowing which of the ten it is on. This is the other way in:
        // one box that finds any card, any value label and any hotkey, and
        // jumps to it. The ranking is in quick_search.h -- its own header so
        // tools/harness can compile the real one, same reason as
        // card_fold_state.h and column_layout.h.
        //
        // State is file-static rather than per-window because the palette is
        // one window for the process, and it is only ever touched from
        // draw() on the render thread.
        // ------------------------------------------------------------------
        bool qs_open = false;
        std::string qs_query;
        std::vector<quick_search::entry> qs_index;
        std::string qs_index_locale;
        int qs_selected = 0;
        std::size_t qs_query_size_when_ranked = 1;
        bool qs_focus_pending = false;

        // The main window's rect, captured while it is open so the palette
        // can centre on it. Read after ImGui::End(), when GetWindowPos would
        // otherwise answer for the fallback window instead.
        ImVec2 qs_anchor_pos = ImVec2(0.f, 0.f);
        ImVec2 qs_anchor_size = ImVec2(950.f, 700.f);

        // Where a jump lands: the card to scroll to, and a decaying glow so
        // the arrival is visible instead of inferred. nav_target_card is a
        // copy, not a pointer -- module names outlive frames, but a copy
        // removes the question.
        std::string nav_target_card;
        bool nav_target_pending = false;
        float nav_target_glow = 0.f;

        // The rail's label for a tab, as text. Mirrors the navs table in
        // draw() and is used only for the palette's result path.
        std::string nav_label_for_category(const ModuleCategory cat) {
            switch (cat)
            {
            case RaidDashboard: return "Raid Dashboard";
            case Exploit: return i18n::tr("nav_exploit");
            case MapStuff: return i18n::tr("nav_map_stuff");
            case Teleport: return "Teleport";
            case ItemSpawnerEditor: return "Gear Editor";
            case BotSpawner: return "Bot Spawner";
            case ProfileEditor: return "Profile Editor";
            case WeaponBuilder: return "Weapon Editor";
            case QuestCompleter: return "Quest Completer";
            case Credits: return "Credits";
            default: return {};
            }
        }

        // True for a tab the rail can actually show. This is a mirror of the
        // navs[] conditions in draw(), and it has to be one: jumping to a tab
        // with no rail row lands the user on a tab whose selected state
        // nothing displays. Visuals, MapEditor, Config and Misc have no row
        // (their modules are hidden_in_category_menu; see
        // MapEditorModule.cpp for the one that moved).
        bool category_is_navigable(const ModuleCategory cat, const ModuleManager* mm) {
            switch (cat)
            {
            case RaidDashboard:
            case Exploit:
            case MapStuff:
            case ItemSpawnerEditor:
            case ProfileEditor:
            case WeaponBuilder:
            case QuestCompleter:
            case Credits:
                return true;
            case Teleport: return mm->has_module("Map Selector");
            case BotSpawner: return mm->has_module("World");
            default: return false;
            }
        }

        void qs_rebuild_index() {
            qs_index.clear();
            const ModuleManager* mm = ModuleManager::get_instance();
            mm->apply_all([&](Module* m) {
                // hidden_in_category_menu is exactly the set the rail will
                // not draw, so a jump there would select a tab with nothing
                // on it. Skip it rather than promise a card.
                if (m->hidden_in_category_menu) return;
                if (!category_is_navigable(m->category, mm)) return;
                const std::string tab_label = nav_label_for_category(m->category);
                qs_index.push_back({m->category, tab_label, m->name,
                    i18n::tr(m->get_display_key()), true});
                m->apply([&](ConfigValue* c) {
                    if (c->is_hidden_in_owner_menu()) return;
                    qs_index.push_back({m->category, tab_label, m->name,
                        imgui_addons::label_text(c->get_imgui_title()), false});
                });
            });
            // The key panel is drawn on the Raid Dashboard's second column;
            // its "card id" is the same pseudo-card menu.cpp passes to
            // draw_card_frame, so a jump unfolds it like any other.
            const std::string dash_label = nav_label_for_category(RaidDashboard);
            for (const auto& b : hotkeys::all()) {
                if (b.hidden_in_config_panel) continue;
                qs_index.push_back({RaidDashboard, dash_label, "hotkeys", i18n::tr(b.label), false});
            }
            qs_index_locale = i18n::current_locale();
        }

        // Which cards are folded, and how that reaches the config file, is in
        // card_fold_state.h. It lives there rather than here so that
        // tools/harness can link it: menu.cpp needs ImGui, resources.h and the
        // DX hook, so a test could only ever exercise a copy of the format.

        void ensure_menu_background_texture() {
            if (menu_background_texture != ImTextureID_Invalid)
            {
                return;
            }
            if (!dxhook::is_ready()) return;
            if (ImGui::GetTime() < menu_background_next_attempt) return;
            menu_background_next_attempt = ImGui::GetTime() + 1.0;

            // Resolve this DLL from a code address instead of relying on the
            // injector's module handle. Some loaders pass the host module to
            // DllMain, which makes FindResource search the game executable.
            HMODULE self_module = nullptr;
            GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                reinterpret_cast<LPCWSTR>(&ensure_menu_background_texture), &self_module);

            // The background ships as RCDATA 101 (assets/menu_background.rc).
            // It used to ALSO be a 11.4 MB C array of one-byte-per-line hex in
            // menu_background_bytes.inc, which was tried first and is now gone:
            // the same pixels are already in the resource section, so the array
            // was a third copy of a 1.9 MB PNG inflating both the tree and the
            // compile. The on-disk PNG is deployed to the output folder as the
            // last-resort fallback, so all three remaining paths work.
            int width = 0, height = 0, channels = 0;
            stbi_uc* pixels = nullptr;

            DWORD mapped_size = 0;
            const std::byte* mapped_bytes = pe_resource::mapped_rcdata(&ensure_menu_background_texture, 101, mapped_size);
            if (mapped_bytes && mapped_size)
            {
                pixels = stbi_load_from_memory(reinterpret_cast<const stbi_uc*>(mapped_bytes),
                    static_cast<int>(mapped_size), &width, &height, &channels, 4);
                if (pixels) menu_background_status = "Embedded background image loaded";
            }

            HRSRC resource = self_module ? FindResourceW(self_module, MAKEINTRESOURCEW(101), RT_RCDATA) : nullptr;
            if (!pixels && resource)
            {
                HGLOBAL loaded = LoadResource(self_module, resource);
                const void* bytes = loaded ? LockResource(loaded) : nullptr;
                const DWORD size = SizeofResource(self_module, resource);
                if (bytes && size > 0)
                    pixels = stbi_load_from_memory(static_cast<const stbi_uc*>(bytes),
                        static_cast<int>(size), &width, &height, &channels, 4);
            }

            // Manual-map loaders may not expose the DLL resource section.
            if (!pixels)
            {
                for (const auto& image_path : {
                         module_paths::data_directory_wide() / L"TarkovAddons Reloaded Background.png",
                         module_paths::dll_directory_wide() / "TarkovAddons Reloaded Background.png" })
                {
                    if (pixels) break;
                    pixels = stbi_load(image_path.string().c_str(), &width, &height, &channels, 4);
                }
                if (pixels) menu_background_status = "External background image loaded";
            }

            if (!pixels || width <= 0 || height <= 0)
            {
                menu_background_status = "Background image unavailable";
                return;
            }

            const bool created = dxhook::create_texture_rgba(pixels, static_cast<uint32_t>(width),
                static_cast<uint32_t>(height), menu_background_texture, &menu_background_resource);
            stbi_image_free(pixels);
            if (created)
            {
                menu_background_width = width;
                menu_background_height = height;
            }
            menu_background_status = created ? "Background image loaded" : "Background image texture upload failed";
        }

        void build_unicode_glyph_ranges(ImGuiIO& io, ImVector<ImWchar>& out) {
            ImFontGlyphRangesBuilder builder;
            builder.AddRanges(io.Fonts->GetGlyphRangesDefault());
            builder.AddRanges(io.Fonts->GetGlyphRangesCyrillic());
            builder.AddRanges(io.Fonts->GetGlyphRangesGreek());
            builder.AddRanges(io.Fonts->GetGlyphRangesVietnamese());
            builder.AddRanges(io.Fonts->GetGlyphRangesThai());
            builder.AddRanges(io.Fonts->GetGlyphRangesKorean());
            builder.AddRanges(io.Fonts->GetGlyphRangesJapanese());
            builder.AddRanges(io.Fonts->GetGlyphRangesChineseSimplifiedCommon());
            builder.BuildRanges(&out);
        }

        // A face embedded in the DLL as RCDATA (see assets/menu_background.rc),
        // or nullptr.
        //
        // ImGui requires the TTF bytes to outlive the ImFont, and the RCDATA
        // pointer is only stable by convention -- a manual-mapped loader is
        // reading out of the mapped image, and FreeResource on somebody else's
        // module handle could unmap it. So the bytes are copied into a
        // function-local static that lives for the process, which is the same
        // guarantee the embedded Poppins array gives and costs one memcpy of
        // ~400 KB once, at menu open.
        const std::byte* embedded_font(const WORD resource_id, std::vector<unsigned char>& keep) {
            DWORD size = 0;
            const std::byte* bytes = pe_resource::rcdata(nullptr, &embedded_font, resource_id, size);
            if (!bytes || !size)
                return nullptr;
            keep.assign(reinterpret_cast<const unsigned char*>(bytes),
                reinterpret_cast<const unsigned char*>(bytes) + size);
            return reinterpret_cast<const std::byte*>(keep.data());
        }

        // The bytes as the pointer ImGui's loader wants.
        //
        // AddFontFromMemoryTTF takes `void*` and does not modify the data -- it
        // reads the TTF and keeps the pointer for the font's lifetime, which
        // is exactly why the copy above exists. The const_cast is confined to
        // this one function so the three call sites cannot each invent their
        // own justification for it.
        inline void* embedded_font_memory(const WORD resource_id,
            std::vector<unsigned char>& keep) {
            const std::byte* face = embedded_font(resource_id, keep);
            return const_cast<std::byte*>(face);
        }

        // Inter, the menu's UI face. SIL OFL 1.1, embedded for the reason in
        // the .rc: a system font read from C:\Windows\Fonts cannot be shipped
        // inside a DLL, and Segoe UI in particular is not redistributable.
        ImFont* load_ui_font(ImGuiIO& io, const float size, const ImWchar* glyph_ranges) {
            ImFontConfig cfg{};
            cfg.OversampleH = 2;
            cfg.OversampleV = 1;
            static std::vector<unsigned char> inter_bytes;
            void* face = embedded_font_memory(1400, inter_bytes);
            if (face) {
                if (ImFont* font = io.Fonts->AddFontFromMemoryTTF(face,
                        static_cast<int>(inter_bytes.size()), size, &cfg, glyph_ranges))
                    return font;
                logger::warn("ui font: Inter was embedded but refused by the atlas builder");
            }
            for (const char* font_path : {
                     "C:\\Windows\\Fonts\\segoeui.ttf",
                     "C:\\Windows\\Fonts\\arial.ttf"})
            {
                if (!std::filesystem::exists(font_path))
                    continue;

                if (ImFont* font = io.Fonts->AddFontFromFileTTF(font_path, size, &cfg, glyph_ranges))
                    return font;
            }

            // Last resort, and the only face that travels with the DLL when
            // even the resource section is unreadable.
            return io.Fonts->AddFontFromMemoryCompressedBase85TTF(poppins_regular_data, size, &cfg, glyph_ranges);
        }

        // Inter SemiBold: the heading face. Same fallback chain, and it still
        // ends on the regular face rather than on nothing, because a missing
        // heading face is a menu that reads flat, not a menu that stops.
        ImFont* load_ui_bold_font(ImGuiIO& io, const float size, const ImWchar* glyph_ranges) {
            ImFontConfig cfg{};
            cfg.OversampleH = 2;
            cfg.OversampleV = 1;
            static std::vector<unsigned char> inter_bold_bytes;
            if (void* face = embedded_font_memory(1401, inter_bold_bytes)) {
                if (ImFont* font = io.Fonts->AddFontFromMemoryTTF(face,
                        static_cast<int>(inter_bold_bytes.size()), size, &cfg, glyph_ranges))
                    return font;
                logger::warn("ui font: Inter SemiBold was embedded but refused by the atlas builder");
            }
            for (const char* font_path : {
                     "C:\\Windows\\Fonts\\segoeuib.ttf",
                     "C:\\Windows\\Fonts\\arialbd.ttf"})
            {
                if (!std::filesystem::exists(font_path))
                    continue;

                if (ImFont* font = io.Fonts->AddFontFromFileTTF(font_path, size, &cfg, glyph_ranges))
                    return font;
            }

            // Keep the UI usable on systems without a bold font installed.
            return load_ui_font(io, size, glyph_ranges);
        }

        // JetBrains Mono: everything numeric -- slider readouts, coordinates,
        // keycaps, item ids. Ambiguous 0/O/1/l and a constant advance are the
        // reason a numeric menu wants a mono face at all.
        //
        // Its glyph range is deliberately Latin-only, which is also why it is
        // safe: measured coverage is 100% of Latin basic and 100% of Latin-1,
        // and the CJK/Thai faces it lacks are never rendered in it (every
        // caller uses it for digits, key names and template ids). A mono face
        // carrying the full CJK set would cost three times the atlas for
        // glyphs nothing draws.
        ImFont* load_mono_font(ImGuiIO& io, const float size) {
            ImFontConfig cfg{};
            cfg.OversampleH = 2;
            cfg.OversampleV = 1;
            static std::vector<unsigned char> jbmono_bytes;
            void* face = embedded_font_memory(1402, jbmono_bytes);
            if (!face)
                return nullptr;
            return io.Fonts->AddFontFromMemoryTTF(face, static_cast<int>(jbmono_bytes.size()),
                size, &cfg, io.Fonts->GetGlyphRangesDefault());
        }

        // The HUD face, and it is the SAME FAMILY as the menu's now.
        //
        // get_hud_font() is what EspModule draws its world text with (nine
        // call sites), plus the ammo HUD and the watermark. It used to be
        // pinned to a Windows system face because the optics rework was live
        // on another machine and the typeface counted as frozen surface; the
        // freeze was lifted on 2026-10-13 and this face follows the menu onto
        // Inter, so the overlay and the menu stop looking like two products.
        //
        // The fallback chain is unchanged, and still ends on the embedded
        // Poppins: if the resource section cannot be read at all, a menu that
        // looks a bit old beats one that renders nothing.
        ImFont* load_hud_font(ImGuiIO& io, const float size, const ImWchar* glyph_ranges) {
            ImFontConfig cfg{};
            cfg.OversampleH = 2;
            cfg.OversampleV = 1;
            static std::vector<unsigned char> inter_bytes;
            if (void* face = embedded_font_memory(1400, inter_bytes)) {
                if (ImFont* font = io.Fonts->AddFontFromMemoryTTF(face,
                        static_cast<int>(inter_bytes.size()), size, &cfg, glyph_ranges))
                    return font;
                logger::warn("hud font: Inter was embedded but refused by the atlas builder");
            }
            for (const char* font_path : {
                     "C:\\Windows\\Fonts\\segoeui.ttf",
                     "C:\\Windows\\Fonts\\arial.ttf"})
            {
                if (!std::filesystem::exists(font_path))
                    continue;
                if (ImFont* font = io.Fonts->AddFontFromFileTTF(font_path, size, &cfg, glyph_ranges))
                    return font;
            }
            return io.Fonts->AddFontFromMemoryCompressedBase85TTF(poppins_regular_data, size, &cfg, glyph_ranges);
        }

        void merge_font_glyphs(ImFont* dst, const float size, const char* font_path, const ImWchar* glyph_ranges) {
            if (!dst || !font_path || !std::filesystem::exists(font_path))
                return;

            ImFontConfig cfg{};
            cfg.MergeMode = true;
            cfg.DstFont = dst;
            cfg.OversampleH = 1;
            cfg.OversampleV = 1;
            ImGui::GetIO().Fonts->AddFontFromFileTTF(font_path, size, &cfg, glyph_ranges);
        }

        void merge_cjk_fallbacks(ImFont* dst, const float size, ImGuiIO& io) {
            merge_font_glyphs(dst, size, "C:\\Windows\\Fonts\\msyh.ttc",
                io.Fonts->GetGlyphRangesChineseSimplifiedCommon());
            merge_font_glyphs(dst, size, "C:\\Windows\\Fonts\\malgun.ttf", io.Fonts->GetGlyphRangesKorean());
            merge_font_glyphs(dst, size, "C:\\Windows\\Fonts\\meiryo.ttc", io.Fonts->GetGlyphRangesJapanese());
            merge_font_glyphs(dst, size, "C:\\Windows\\Fonts\\YuGothR.ttc", io.Fonts->GetGlyphRangesJapanese());
            // THAI, and this one is a consequence of choosing Inter rather
            // than Segoe UI. Measured from the cmap (tools/check_font_coverage.py):
            // Inter covers Thai at 1.1% -- one code point -- so without this
            // merge the tu locale renders boxes, which is a regression bought
            // by a font swap. Leelawadee UI is the Windows Thai face; Arial
            // Unicode is the fallback for a machine without it.
            merge_font_glyphs(dst, size, "C:\\Windows\\Fonts\\leelawadeeui.ttf",
                io.Fonts->GetGlyphRangesThai());
            merge_font_glyphs(dst, size, "C:\\Windows\\Fonts\\arialuni.ttf",
                io.Fonts->GetGlyphRangesThai());
        }
    } // namespace

    float get_hud_font_size() {
        return hud_font_size;
    }

    ImFont* get_hud_font() {
        return hud_font_face;
    }

    ImFont* get_hud_mono_font() {
        return hud_mono_face;
    }

    ImFont* get_bold_font() {
        return ui_bold;
    }

    // The numeric face, or nullptr when it could not be embedded. Callers MUST
    // handle nullptr -- ImGui::PushFont(nullptr) asserts. push_mono_font() in
    // imgui_addons.h is the wrapper that does.
    ImFont* get_mono_font() {
        return mono_face;
    }

    float get_scale_factor() {
        return scale_factor;
    }

    float get_width() {
        return widthh;
    }

    float get_height() {
        return heightt;
    }

    bool is_active() {
        return draw_imgui == true;
    }

    void setup() {
        ImGuiIO io = ImGui::GetIO();
        int horizontal = 0;
        int vertical = 0;
        utils::get_desktop_resolution(horizontal, vertical);
        widthh = static_cast<float>(horizontal);
        heightt = static_cast<float>(vertical);
        scale_factor = (static_cast<float>(horizontal) / 1920.0f + static_cast<float>(vertical) / 1080.0f) / 2.0f;
        font_size = 16 * scale_factor;
        large_font_size = 18 * scale_factor;
        hud_font_size = 256 * scale_factor;

        ImVector<ImWchar> unicode_glyph_ranges;
        build_unicode_glyph_ranges(io, unicode_glyph_ranges);

        // The menu's four faces, in the order they must exist.
        //
        // `ui_regular` is Inter Regular, `ui_bold` Inter SemiBold, `mono_face`
        // JetBrains Mono. Loaded at their FINAL pixel size (16 / 18 / 15, times
        // the scale factor) and never scaled afterwards -- io.FontGlobalScale
        // would resample an already-rasterised atlas and turn the hinting the
        // size choice exists for into mush.
        ui_regular = load_ui_font(io, font_size, unicode_glyph_ranges.Data);
        merge_cjk_fallbacks(ui_regular, font_size, io);

        ImFontConfig icon_cfg{};
        icon_cfg.MergeMode = true;
        icon_cfg.DstFont = ui_regular;
        icons = io.Fonts->AddFontFromMemoryCompressedTTF(icons_compressed_data, icons_compressed_size,
            font_size, &icon_cfg);

        ui_bold = load_ui_bold_font(io, large_font_size, unicode_glyph_ranges.Data);
        merge_cjk_fallbacks(ui_bold, large_font_size, io);

        // One size BELOW the UI face, because JetBrains Mono's advance is wider
        // than Inter's at the same pixel size: at 16 the digits stop lining up
        // with the labels beside them. 15 keeps the cap height matched while
        // fitting the 110*sf readout box the sliders already reserve.
        mono_face = load_mono_font(io, 15.f * scale_factor);
        if (!mono_face)
            logger::warn("ui font: JetBrains Mono is not embedded; the numeric face falls back to the UI face");

        hud_font_face = load_hud_font(io, hud_font_size, unicode_glyph_ranges.Data);
        if (hud_font_face)
            merge_cjk_fallbacks(hud_font_face, hud_font_size, io);

        // The HUD's numeric face, at the HUD's size. A SECOND atlas rather
        // than a second size of the first: ImGui has no cheap resize, and
        // 256px JetBrains Mono is the size the ammo block is measured
        // against. Ammo HUD is the one place that draws pure numbers into the
        // world ("12 / 60"), which is exactly what mono is for.
        hud_mono_face = load_mono_font(io, hud_font_size);

        ensure_menu_background_texture();
    }

    // See the declaration in menu.h for the contract. The storage is here rather than in the
    // header so there is exactly one instance and no inline-static subtleties.
    namespace {
        const char* g_draw_stage = "menu::draw";
        // Backing store for the two composed labels. A function-local static rather than a
        // member because the label has one writer and one reader, both the render thread
        // inside one draw_imgui() call -- the same argument as draw_stage() itself, and it
        // means no lock and no allocation on a per-frame path.
        char g_stage_buf[128];
    }

    const char* draw_stage() {
        return g_draw_stage;
    }

    void set_draw_stage(const char* stage) {
        if (stage) g_draw_stage = stage;
    }

    void set_draw_stage_card(const char* module) {
        if (!module) return;
        snprintf(g_stage_buf, sizeof(g_stage_buf), "%s card", module);
        g_draw_stage = g_stage_buf;
    }

    void set_draw_stage_overlay(const char* module) {
        if (!module) return;
        snprintf(g_stage_buf, sizeof(g_stage_buf), "%s::draw_overlay", module);
        g_draw_stage = g_stage_buf;
    }

        // ------------------------------------------------------------------
        // The palette window itself. Drawn after the main window's End(), so
        // it composites above the menu without any z-order push, and OUTSIDE
        // the menu's Begin block: it has its own window and its own style
        // stack, and nesting it inside the menu window would make the menu's
        // scroll and clip rect apply to a list that is not card content.
        // ------------------------------------------------------------------
        void draw_quick_search_palette() {
            set_draw_stage("quick search");
            const float sf = scale_factor;

            // Escape dismisses the palette and returns to the menu. draw()'s
            // own Escape gate stands down while this window is open, so if the
            // answer were not here the key would do NOTHING at all -- the
            // user's only way out would be Ctrl+K again, with no affordance
            // on screen saying so. That is the state this block exists to
            // prevent, and it is not hypothetical: this is the gap found on
            // review of the first working version.
            if (ImGui::IsKeyPressed(ImGuiKey_Escape, false)) {
                qs_open = false;
                return;
            }

            // Index freshness: rebuilt when the language changes, because
            // every label is translated per entry. The open-time rebuild is
            // in draw() where the toggle happens.
            if (qs_index_locale != i18n::current_locale())
                qs_rebuild_index();

            // A new query length means a new list, which means the selection
            // is meaningless -- start at the top again rather than keeping a
            // cursor position that points at a different row.
            if (qs_query.size() != qs_query_size_when_ranked) {
                qs_query_size_when_ranked = qs_query.size();
                qs_selected = 0;
            }

            const std::vector<quick_search::match> hits =
                quick_search::rank(qs_query, qs_index, 8);
            if (qs_selected >= static_cast<int>(hits.size()))
                qs_selected = 0;

            const float palette_w = (std::min)(560.f * sf, qs_anchor_size.x - 40.f * sf);
            ImGui::SetNextWindowPos(
                ImVec2(qs_anchor_pos.x + qs_anchor_size.x * 0.5f, qs_anchor_pos.y + 56.f * sf),
                ImGuiCond_Always, ImVec2(0.5f, 0.f));
            ImGui::SetNextWindowSize(ImVec2(palette_w, 0.f), ImGuiCond_Always);
            ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 9.f * sf);
            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10.f * sf, 10.f * sf));
            ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.f * sf);
            ImGui::PushStyleColor(ImGuiCol_WindowBg, menu::with_alpha(menu::palette::bg, 0.985f));
            ImGui::PushStyleColor(ImGuiCol_Border,
                menu::with_alpha(menu::palette::accent, 0.45f));
            if (qs_focus_pending) {
                ImGui::SetNextWindowFocus();
                qs_focus_pending = false;
            }

            // Enter and the arrows are handled here, not in the input box,
            // because the box does not own them: an arrow press inside a text
            // field is a caret move the user may legitimately want.
            bool activate = false;
            if (ImGui::IsKeyPressed(ImGuiKey_Enter, false)
                || ImGui::IsKeyPressed(ImGuiKey_KeypadEnter, false))
                activate = !hits.empty();
            if (ImGui::IsKeyPressed(ImGuiKey_DownArrow, false) && !hits.empty())
                qs_selected = (std::min)(qs_selected + 1, static_cast<int>(hits.size()) - 1);
            if (ImGui::IsKeyPressed(ImGuiKey_UpArrow, false))
                qs_selected = (std::max)(qs_selected - 1, 0);

            if (ImGui::Begin("##quick_jump", nullptr,
                    ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize
                    | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse
                    | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings))
            {
                ImGui::PushStyleColor(ImGuiCol_FrameBg,
                    menu::with_alpha(menu::palette::surface2, 0.9f));
                // The search field is the one control in this window whose
                // whole job is to show text, so it gets the padded frame
                // rather than the card row's (4, 3) -- the reason it read as
                // squished against the left and top edge.
                ImGui::SetNextItemWidth(-1.f);
                imgui_addons::push_search_padding();
                ImGui::InputTextWithHint("##qs_input",
                    i18n::tr("quick_search_hint_inf").c_str(), &qs_query);
                imgui_addons::pop_search_padding();
                ImGui::PopStyleColor();

                if (qs_query.empty()) {
                    ImGui::Dummy(ImVec2(0, 2.f * sf));
                    ImGui::TextColored(menu::palette::muted, "%s",
                        i18n::tr("quick_search_empty_inf").c_str());
                }
                else if (hits.empty()) {
                    ImGui::Dummy(ImVec2(0, 2.f * sf));
                    ImGui::TextColored(menu::palette::muted, "%s",
                        i18n::tr("quick_search_no_results_inf").c_str());
                }
                else {
                    // One row per hit: the label, then the path in caption
                    // grey. The path is what makes a value jump legible --
                    // "FOV" alone is on several cards.
                    ImGui::Dummy(ImVec2(0, 2.f * sf));
                    const float row_h = ImGui::GetTextLineHeightWithSpacing();
                    const int shown = (std::min)(static_cast<int>(hits.size()), 8);
                    if (ImGui::BeginChild("##qs_results",
                            ImVec2(0.f, row_h * static_cast<float>(shown) + 4.f * sf), false,
                            ImGuiWindowFlags_NoScrollbar))
                    {
                        for (int i = 0; i < shown; ++i) {
                            const quick_search::entry& e =
                                qs_index[hits[static_cast<size_t>(i)].index];
                            std::string row = e.label;
                            if (!e.tab_label.empty())
                                row += "    " + e.tab_label + " > " + e.card;
                            ImGui::PushID(i);
                            if (ImGui::Selectable(row.c_str(), qs_selected == i))
                                qs_selected = i;
                            // One click both selects and fires: IsItemClicked is
                            // already scoped to this row, and the row it landed
                            // on is the one qs_selected just took, so a single
                            // condition is enough.
                            if (ImGui::IsItemClicked())
                                activate = true;
                            ImGui::PopID();
                        }
                    }
                    ImGui::EndChild();
                }
            }
            ImGui::End();
            ImGui::PopStyleColor(2);
            ImGui::PopStyleVar(3);

            if (activate && qs_selected >= 0
                && qs_selected < static_cast<int>(hits.size())) {
                // Jump: pick the tab, unfold the card, and ask for a scroll
                // the card frame performs on its way past its own top.
                const quick_search::entry& e = qs_index[hits[static_cast<size_t>(qs_selected)].index];
                selected_tab = e.tab;
                card_fold::set(e.card, false);
                nav_target_card = e.card;
                nav_target_pending = true;
                qs_open = false;
            }
            set_draw_stage("menu::draw");
        }

    void draw() {

        set_draw_stage("menu::draw");
        ensure_menu_background_texture();

        auto* mm = ModuleManager::get_instance();
        if (selected_tab == BotSpawner && !mm->has_module("World"))
        {
            selected_tab = Visuals;
        }
        // draw menu
        theme();
        apply_modern_style();
        ImGui::GetMouseCursor();
        ImGui::SetMouseCursor(ImGuiMouseCursor_Arrow);
        ImGui::GetIO().ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;
        ImGui::GetIO().WantCaptureMouse = is_active();

        // Escape closes the menu. This is checked before the window is drawn,
        // so the close takes effect on the very next frame through the same
        // fade the Insert key already gets -- draw_imgui going false is what
        // animates menu_anim back to zero, and it deliberately keeps drawing
        // until then.
        //
        // THREE states own Escape first, and swallowing it there would lose
        // it: a keybind being assigned (Escape clears that binding -- see
        // draw_keybind_button, which polls GetAsyncKeyState for it later in
        // this same frame), an open popup (ImGui closes the combo itself,
        // so the user needs a second press to close the menu), and the
        // quick-jump palette (qs_open). ImGui reads Escape during EndFrame,
        // so the popup is still registered here -- testing it now is what
        // makes the two-stage behaviour work rather than dropping the menu
        // out from under the combo. The palette joins them because the first
        // press belongs to the thing the user just opened: dismissing the
        // palette and staying in the menu is what the second press is for.
        //
        // A text field being edited is NOT excluded, and that is deliberate:
        // Escape closes the menu everywhere else, and a half-typed filter is
        // cheaper to retype than a menu you cannot dismiss. Add
        // !ImGui::IsAnyItemActive() here if that trade is ever wanted the other
        // way -- it would also stop Escape closing the menu mid-slider-drag.
        if (draw_imgui && !qs_open && ImGui::IsKeyPressed(ImGuiKey_Escape, false)
            && hotkeys::waiting_for_key.load(std::memory_order_acquire) == nullptr
            && !ImGui::IsPopupOpen(nullptr, ImGuiPopupFlags_AnyPopupId))
            draw_imgui = false;

        // CTRL+K opens the quick-jump palette, and CTRL+K again closes it.
        // Read as an ImGui chord rather than through GetAsyncKeyState because
        // the menu owns the keyboard while it is open (dxhook::WndProc routes
        // window messages to ImGui_ImplWin32 and swallows them from the
        // game), and this way the chord cannot be seen by the game either.
        //
        // IsKeyChordPressed does no routing check of its own, so the chord
        // also fires while a text field elsewhere in the menu has focus.
        // That is accepted deliberately: the alternative is a shortcut that
        // stops working exactly when the user is typing, and the failure
        // mode here is benign (the palette opens, Escape dismisses it).
        if (draw_imgui && ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_K)) {
            qs_open = !qs_open;
            if (qs_open) {
                qs_query.clear();
                qs_selected = 0;
                qs_query_size_when_ranked = 0;
                qs_focus_pending = true;
                qs_rebuild_index();
            }
        }

        // smooth open/close animation (fade) — keep drawing while fading out
        static float menu_anim = 0.f;
        const float dt = ImGui::GetIO().DeltaTime;
        const float anim_target = draw_imgui ? 1.f : 0.f;
        menu_anim += (anim_target - menu_anim) * (std::min)(1.f, dt * 14.f);
        const float ease = menu_anim * menu_anim * (3.f - 2.f * menu_anim); // smoothstep

        if (menu_anim > 0.004f)
        {
            const float sf = scale_factor;
            // Enlarged + resizable 2026-09-23: the Debug Log viewer needs vertical
            // room, and the user asked for a bigger/resizable window outright (the
            // old 840x560 NoResize default left the log field too small to read or
            // scroll). Constrained so it can't collapse into an unusable sliver.
            constexpr float width = 950;
            constexpr float height = 700;
            ImGui::SetNextWindowSizeConstraints(
                ImVec2(720.f * sf, 520.f * sf),
                ImVec2(1920.f * sf, 1080.f * sf));
            ImGui::SetNextWindowSize(ImVec2(width * sf, height * sf), ImGuiCond_Once);
            ImGui::SetNextWindowBgAlpha(ease);
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease);
            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));

            if (ImGui::Begin(globals::get_display_title().c_str(), &draw_imgui,
                    ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar))
            {
                ImDrawList* dl = ImGui::GetWindowDrawList();

                // Remembered for the quick-jump palette, which is drawn after
                // this window ends. GetWindowPos()/GetWindowSize() answer for
                // the fallback window once End() has run, so the anchor has
                // to be taken here.
                qs_anchor_pos = ImGui::GetWindowPos();
                qs_anchor_size = ImGui::GetWindowSize();

                // ---- pulsing outer glow ----
                {
                    const ImVec2 wp = ImGui::GetWindowPos();
                    const ImVec2 ws = ImGui::GetWindowSize();
                    ImDrawList* fg = ImGui::GetForegroundDrawList();
                    const float pulse = 0.5f + 0.5f * sinf(static_cast<float>(ImGui::GetTime()) * 2.2f);
                    const float rnd = ImGui::GetStyle().WindowRounding;
                    for (int g = 1; g <= 4; ++g)
                    {
                        const float o = g * 2.0f * sf;
                        const float a = (0.18f - g * 0.035f) * (0.6f + 0.4f * pulse) * ease;
                        if (a <= 0.f) continue;
                        fg->AddRect(ImVec2(wp.x - o, wp.y - o), ImVec2(wp.x + ws.x + o, wp.y + ws.y + o),
                            ImGui::GetColorU32(menu::with_alpha(menu::palette::accent, a)), rnd + o, 0, 2.0f);
                    }
                }

                const ImVec2 work_min = ImGui::GetCursorScreenPos();
                const float work_w = ImGui::GetContentRegionAvail().x;
                const float work_h = ImGui::GetContentRegionAvail().y;
                const float sidebar_w = 158.f * sf;

                // Black Division artwork is an external companion image beside
                // the DLL, so it can be replaced without rebuilding the mod.
                if (menu_background_texture != ImTextureID_Invalid)
                {
                    const ImVec2 work_max(work_min.x + work_w, work_min.y + work_h);
                    // Keep the navigation rail a solid steel blue. The artwork
                    // fills only the card/content side, using a slight fit-to-area
                    // stretch to avoid empty bars beside it.
                    const ImVec2 image_min(work_min.x + sidebar_w, work_min.y);
                    dl->AddImage(menu_background_texture, image_min, work_max,
                        ImVec2(0.f, 0.f), ImVec2(1.f, 1.f),
                        ImGui::GetColorU32(ImVec4(1.f, 1.f, 1.f, ease)));
                    dl->AddRectFilled(image_min, work_max,
                        ImGui::GetColorU32(ImVec4(0.015f, 0.018f, 0.012f, 0.28f * ease)));
                }

                // ---- interactive animated background: drifting dot grid that reacts to the mouse ----
                {
                    const ImVec2 mouse = ImGui::GetIO().MousePos;
                    const float t = static_cast<float>(ImGui::GetTime());
                    const float spacing = 28.f * sf;
                    const float infl = 115.f * sf; // mouse influence radius
                    const float infl_sq = infl * infl;

                    dl->PushClipRect(work_min, ImVec2(work_min.x + work_w, work_min.y + work_h), true);

                    // Precompute drift offsets once per frame (sinf/cosf are expensive)
                    const float drift_x1 = sinf(t * 0.6f) * 2.f * sf;
                    const float drift_y1 = cosf(t * 0.5f) * 2.f * sf;

                    for (float gy = work_min.y + spacing * 0.5f; gy < work_min.y + work_h; gy += spacing)
                    {
                        for (float gx = work_min.x + spacing * 0.5f; gx < work_min.x + work_w; gx += spacing)
                        {
                            // subtle drift so the field feels alive
                            const float px = gx + drift_x1;
                            const float py = gy + drift_y1;

                            const float ddx = px - mouse.x;
                            const float ddy = py - mouse.y;
                            const float d2 = ddx * ddx + ddy * ddy;
                            const float prox = d2 < infl_sq ? (1.f - sqrtf(d2) / infl) : 0.f;

                            const float r = (0.8f + prox * 2.4f) * sf;
                            ImVec4 col = prox > 0.02f ? menu::palette::accent2 : menu::palette::line;
                            col.w = (0.05f + prox * 0.6f) * ease;
                            dl->AddCircleFilled(ImVec2(px, py), r, ImGui::GetColorU32(col), 8);
                        }
                    }

                    // soft accent glow following the cursor
                    if (mouse.x >= work_min.x && mouse.x <= work_min.x + work_w && mouse.y >= work_min.y && mouse.y <= work_min.y + work_h)
                    {
                        for (int g = 0; g < 5; ++g)
                        {
                            const float gr = (28.f + g * 22.f) * sf;
                            const float ga = (0.055f - g * 0.01f) * ease;
                            if (ga <= 0.f) continue;
                            dl->AddCircleFilled(mouse, gr,
                                ImGui::GetColorU32(menu::with_alpha(menu::palette::accent, ga)), 32);
                        }
                    }

                    dl->PopClipRect();
                }

                // sidebar background + divider
                dl->AddRectFilled(work_min, ImVec2(work_min.x + sidebar_w, work_min.y + work_h),
                    ImGui::GetColorU32(menu::with_alpha(menu::palette::surface, 0.90f)));
                dl->AddLine(ImVec2(work_min.x + sidebar_w, work_min.y + 8 * sf),
                    ImVec2(work_min.x + sidebar_w, work_min.y + work_h - 8 * sf),
                    ImGui::GetColorU32(menu::with_alpha(menu::palette::line, 0.6f)), 1.f);

                // sidebar header
                ImGui::SetCursorPos(ImVec2(20 * sf, 18 * sf));
                ImGui::PushFont(ui_bold);
                ImGui::TextColored(menu::palette::accent, "TarkovAddons");
                ImGui::PopFont();
                ImGui::SetCursorPosX(20 * sf);
                // From globals::k_version, not typed here. This line used to be the
                // literal "Reloaded v3.3" while the log header said v3.2, so the
                // release a player saw and the release the log described were two
                // different answers to one question.
                ImGui::TextColored(menu::palette::muted, "%s", globals::version_line().c_str());

                // nav items
                struct nav_def
                {
                    const char* label;
                    ModuleCategory cat;
                    bool translate;
                };
                // Size is the worst case: eight unconditional rows plus the two
                // conditional ones (Teleport, Bot Spawner) plus Credits.
                nav_def navs[11];
                int n = 0;
                navs[n++] = {"Raid Dashboard", RaidDashboard, false};
                navs[n++] = {"nav_exploit", Exploit, true};
                // Its own tab rather than a slot in Exploit, which is full. Sits
                // next to Teleport because both are map features.
                navs[n++] = {"nav_map_stuff", MapStuff, true};
                if (mm->has_module("Map Selector")) navs[n++] = {"Teleport", Teleport, false};
                navs[n++] = {"Gear Editor", ItemSpawnerEditor, false};
                if (mm->has_module("World")) navs[n++] = {"Bot Spawner", BotSpawner, false};
                navs[n++] = {"Profile Editor", ProfileEditor, false};
                navs[n++] = {"Weapon Editor", WeaponBuilder, false};
                navs[n++] = {"Quest Completer", QuestCompleter, false};
                navs[n++] = {"Credits", Credits, false};

                const float nav_top = 64.f * sf;
                const float nav_h = 40.f * sf;

                // Credits is pinned to the footer while every other row flows down
                // from the top, so the flowing rows have to fit in what is left or
                // the last one slides underneath Credits at the minimum window
                // size (720x520). Derive their pitch from the space actually
                // available rather than hard-coding it, so adding a tab cannot
                // break the rail. 40.f * sf is the original pitch and stays in
                // effect until there are enough tabs to need squeezing.
                const float pinned_row = nav_h - 6.f * sf;
                const float flow_space = work_h - pinned_row - 8.f * sf;
                int flowing_rows = 0;
                for (int i = 0; i < n; ++i)
                    if (navs[i].cat != Credits) ++flowing_rows;
                const float flow_h = (flowing_rows > 0 && flow_space > 0.f)
                    ? (std::min)(nav_h, flow_space / static_cast<float>(flowing_rows))
                    : nav_h;

                float active_y0 = work_min.y + nav_top, active_y1 = active_y0 + nav_h;

                for (int i = 0; i < n; ++i)
                {
                    // Count the rows that actually flow, so the pitch stays correct
                    // even if Credits is ever moved out of last place.
                    int flow_index = 0;
                    for (int k = 0; k < i; ++k)
                        if (navs[k].cat != Credits) ++flow_index;

                    // Keep Credits anchored in the old footer position so it is
                    // always easy to reach without taking up space in the main nav.
                    const float nav_y = navs[i].cat == Credits
                        ? work_h - nav_h + 6.f * sf
                        : nav_top + flow_index * flow_h;
                    ImGui::SetCursorPos(ImVec2(10 * sf, nav_y));
                    ImGui::PushID(i);
                    if (ImGui::InvisibleButton("nav", ImVec2(sidebar_w - 20 * sf, nav_h - 6 * sf)))
                        selected_tab = navs[i].cat;
                    const bool hov = ImGui::IsItemHovered();
                    ImGui::PopID();

                    const ImVec2 rmin = ImGui::GetItemRectMin();
                    const ImVec2 rmax = ImGui::GetItemRectMax();
                    const bool sel = selected_tab == navs[i].cat;
                    if (sel)
                    {
                        active_y0 = rmin.y;
                        active_y1 = rmax.y;
                    }

                    if (sel)
                    {
                        dl->AddRectFilled(rmin, rmax,
                            ImGui::GetColorU32(menu::with_alpha(menu::palette::accent, 0.19f)), 7.f);
                        dl->AddRect(rmin, rmax,
                            ImGui::GetColorU32(menu::with_alpha(menu::palette::accent2, 0.25f)), 7.f);
                    }
                    else if (hov)
                        dl->AddRectFilled(rmin, rmax, ImGui::GetColorU32(menu::with_alpha(menu::palette::accent2, 0.08f)), 6.f);

                    const ImU32 col = sel ? ImGui::GetColorU32(menu::palette::txt)
                                          : ImGui::GetColorU32(hov ? menu::palette::accent2 : menu::palette::muted);
                    const std::string nav_label = navs[i].translate ? i18n::tr(navs[i].label) : navs[i].label;
                    const ImVec2 nav_size = ImGui::CalcTextSize(nav_label.c_str());
                    dl->AddText(ImVec2(rmin.x + 16 * sf, rmin.y + (rmax.y - rmin.y - nav_size.y) * 0.5f),
                        col, nav_label.c_str());
                }

                // sliding vertical indicator on sidebar left edge
                static float ind_y0 = 0, ind_y1 = 0;
                static bool ind_init = false;
                if (!ind_init)
                {
                    ind_y0 = active_y0;
                    ind_y1 = active_y1;
                    ind_init = true;
                }
                ind_y0 += (active_y0 - ind_y0) * (std::min)(1.f, dt * 16.f);
                ind_y1 += (active_y1 - ind_y1) * (std::min)(1.f, dt * 16.f);
                dl->AddRectFilled(ImVec2(work_min.x + 4 * sf, ind_y0 + 4 * sf),
                    ImVec2(work_min.x + 7 * sf, ind_y1 - 4 * sf),
                    ImGui::GetColorU32(menu::palette::accent), 2.f);

                // ---- CONTENT ----
                const float content_x = sidebar_w + 22 * sf;
                // Keep the card columns inside the clean central artwork area:
                // below the title/upper divider and above the bottom logo.
                const float content_top = 64.f * sf;
                // Preserve the lower artwork/branding area instead of letting
                // scrollable cards cover the Escape From Tarkov logo.
                const float artwork_clearance = 54.f * sf;

                const float content_avail = work_w - content_x - 16 * sf;
                const float col_gap = 10 * sf;
                // Resize spec (user 2026-09-23): the sidebar rail keeps a fixed
                // width (sidebar_w, scale_factor comes from the desktop
                // resolution, never the window size) while the two content
                // columns each keep exactly half of the remaining window width.
                // col_w is derived from the CURRENT window size every frame —
                // do not cache it or tie it to anything that scales with the
                // window.
                const float col_w = (content_avail - col_gap) * 0.5f;
                const float content_h = work_h - content_top - artwork_clearance;
                const bool config_tab = selected_tab == Config;
                const bool credits_tab = selected_tab == Credits;

                // `id` is the card's stable key (the module name; see card_fold_state.h),
                // `title` is the translated heading. Every card folds by clicking
                // its heading row -- the whole row is the hit target, not just the
                // words, which is why the heading is an InvisibleButton with the
                // text and chevron painted by hand instead of a Text call.
                auto draw_card_frame = [&](const char* id, const char* title, const std::function<void()>& body) {
                    ImDrawList* cdl = ImGui::GetWindowDrawList();
                    ImDrawListSplitter splitter;
                    splitter.Split(cdl, 2);
                    splitter.SetCurrentChannel(cdl, 1);

                    const ImVec2 card_min = ImGui::GetCursorScreenPos();
                    const float card_w = ImGui::GetContentRegionAvail().x;

                    // A jump from the quick-jump palette lands here. The
                    // unfold happened at activation time (card_fold::set);
                    // this is the half that needs the card to exist, because
                    // scrolling to it is only possible from inside its column
                    // child. Consumed once -- a card drawn twice in a frame
                    // must not scroll twice.
                    if (nav_target_pending && id == nav_target_card) {
                        nav_target_pending = false;
                        nav_target_glow = 1.f;
                        const ImVec2 clip_min = ImGui::GetWindowPos();
                        const float clip_h = ImGui::GetWindowHeight();
                        // Only when the card's top is outside the visible
                        // region: a target already in view must not move.
                        if (card_min.y < clip_min.y + 8.f * sf
                            || card_min.y > clip_min.y + clip_h - 48.f * sf) {
                            ImGui::SetScrollY(ImGui::GetScrollY()
                                + (card_min.y - clip_min.y - 24.f * sf));
                        }
                    }

                    // Every card uses the same regular UI face and scale.  This
                    // also applies to custom controls drawn by individual modules.
                    ImGui::PushFont(ui_regular ? ui_regular : ImGui::GetFont());
                    ImGui::Indent(14 * sf);
                    ImGui::Dummy(ImVec2(0, 10 * sf));
                    // Card titles use the same steel-blue treatment as Aimbot;
                    // regular controls retain the global high-contrast text color.
                    // The heading font is intentionally two points larger than
                    // the shared card-body font for a clear visual hierarchy.
                    ImGui::PushFont(ui_bold ? ui_bold : ImGui::GetFont());
                    // The id is pushed only around the button, never around body(),
                    // so folding a card cannot shift the ImGuiIDs of any control
                    // inside it -- SelectValue options and the checkbox star are
                    // both keyed off those.
                    ImGui::PushID(id);
                    // GetID has to happen under the pushed id, before the button
                    // itself: the chevron's animation is keyed on this, and it has
                    // to survive the PopID below.
                    const ImGuiID header_id = ImGui::GetID("##card_header");
                    const ImVec2 title_size = ImGui::CalcTextSize(title);
                    const bool header_clicked = ImGui::InvisibleButton("##card_header",
                        ImVec2(ImGui::GetContentRegionAvail().x, title_size.y + 6.f * sf));
                    ImGui::PopID();
                    ImGui::PopFont();
                    // Read AFTER the click, and re-read rather than holding a
                    // reference: card_fold::load() replaces the whole store, so a
                    // bool& taken before it would be a dangling reference by the
                    // time it was used.
                    if (header_clicked) card_fold::set(id, !card_fold::get(id));
                    const bool collapsed = card_fold::get(id);

                    const ImVec2 header_min = ImGui::GetItemRectMin();
                    const ImVec2 header_max = ImGui::GetItemRectMax();
                    if (ImGui::IsItemHovered())
                        cdl->AddRectFilled(header_min, header_max,
                            ImGui::GetColorU32(menu::with_alpha(menu::palette::accent2, 0.12f)), 6.f);
                    cdl->AddText(ImVec2(header_min.x + 10.f * sf, header_min.y + 3.f * sf),
                        ImGui::GetColorU32(menu::palette::accent2), title);

                    // Chevron: a triangle pointing down when open and right when
                    // folded, rotated between the two by the shared animate() so
                    // the fold reads as a movement instead of a jump.
                    constexpr float half_pi = 1.57079633f;
                    const float open_amt = imgui_addons::animate(header_id, collapsed ? 0.f : 1.f);
                    const float chevron_angle = open_amt * half_pi;
                    const float chev_x = header_max.x - 18.f * sf;
                    const float chev_y = (header_min.y + header_max.y) * 0.5f;
                    const float chev_r = 4.f * sf;
                    const auto rotate = [&](const ImVec2& p) {
                        const float dx = p.x - chev_x;
                        const float dy = p.y - chev_y;
                        return ImVec2(chev_x + dx * cosf(chevron_angle) - dy * sinf(chevron_angle),
                            chev_y + dx * sinf(chevron_angle) + dy * cosf(chevron_angle));
                    };
                    cdl->AddTriangleFilled(rotate({chev_x + chev_r, chev_y}),
                        rotate({chev_x - chev_r * 0.6f, chev_y - chev_r * 0.8f}),
                        rotate({chev_x - chev_r * 0.6f, chev_y + chev_r * 0.8f}),
                        ImGui::GetColorU32(menu::with_alpha(menu::palette::accent2,
                            collapsed ? 0.75f : 1.0f)));

                    if (!collapsed)
                    {
                        // Keep one clean divider directly beneath every card heading.
                        // This matches the Enchantment section treatment without
                        // adding another label or a left-side accent bar.
                        ImGui::Separator();
                        ImGui::Dummy(ImVec2(0, 6 * sf));
                        body();
                    }
                    ImGui::Dummy(ImVec2(0, 10 * sf));
                    ImGui::Unindent(14 * sf);
                    ImGui::PopFont();

                    const ImVec2 card_max = ImVec2(card_min.x + card_w, ImGui::GetCursorScreenPos().y);

                    splitter.SetCurrentChannel(cdl, 0);
                    cdl->AddRectFilled(ImVec2(card_min.x + 2 * sf, card_min.y + 3 * sf),
                        ImVec2(card_max.x + 2 * sf, card_max.y + 4 * sf),
                        ImGui::GetColorU32(ImVec4(0.f, 0.f, 0.f, 0.14f)), 9.f);
                    cdl->AddRectFilled(card_min, card_max,
                        ImGui::GetColorU32(menu::with_alpha(menu::palette::surface, 0.56f)), 9.f);
                    // The tint band stops at the bottom of the heading row, which
                    // is the whole card when it is folded -- the old fixed 39*sf
                    // band would leave a sliver of "header" hanging below a card
                    // with no body. Deriving it from the header also keeps the
                    // band correct at any scale factor.
                    cdl->AddRectFilled(ImVec2(card_min.x + 1 * sf, card_min.y + 1 * sf),
                        ImVec2(card_max.x - 1 * sf, header_max.y),
                        ImGui::GetColorU32(menu::with_alpha(menu::palette::surface2, 0.18f)),
                        8.f, ImDrawFlags_RoundCornersTop);
                    cdl->AddRect(card_min, card_max,
                        ImGui::GetColorU32(menu::with_alpha(menu::palette::line, 0.52f)), 9.f, 0, 1.f);
                    // Arrival glow from a quick-jump: an accent ring that
                    // fades over ~0.9s (decayed in draw()), so the eye finds
                    // the card that was asked for instead of scanning for it.
                    if (nav_target_glow > 0.f && id == nav_target_card)
                        cdl->AddRect(ImVec2(card_min.x - 2.f * sf, card_min.y - 2.f * sf),
                            ImVec2(card_max.x + 2.f * sf, card_max.y + 2.f * sf),
                            ImGui::GetColorU32(menu::with_alpha(menu::palette::accent,
                                0.85f * nav_target_glow)), 11.f, 0, 2.f * sf);
                    splitter.Merge(cdl);

                    ImGui::Dummy(ImVec2(0, 9 * sf));
                };

                // One row of the changed-from-default treatment: a dot in the
                // card's left gutter -- inside the 14*sf indent no control
                // occupies -- that doubles as the hit target for the reset.
                // There is no second widget to line up, and nothing outside
                // the gutter is touched, so no existing row's hit area moves.
                //
                // The reset writes get_default() back through set(), which is
                // the same path the config loader uses, so a reset row is
                // indistinguishable from a freshly loaded default -- including
                // for values whose set() does more than store (MapEditor's
                // preview_style pushes into editor state through it).
                auto draw_changed_marker = [&](ConfigValue* c, const ImVec2& row_top) {
                    const ImVec2 row_bottom = ImGui::GetCursorScreenPos();
                    const float row_h = row_bottom.y - row_top.y;
                    const float dot_x = row_top.x - 8.f * sf;
                    // Centred on the row's LABEL LINE, not on the row box. Every
                    // row here draws a label first, and GetFrameHeight() is that
                    // label's line box (they all AlignTextToFramePadding), so
                    // the line is a fixed height while the row is not: a slider
                    // is two lines, and ItemSearchValue's row grows with the
                    // number of results you typed. A position derived from
                    // row_h is therefore a function of content and slides while
                    // the user is reading the label -- which is what the two
                    // earlier attempts did (row top, then row centre) and why
                    // both read as off. The arithmetic and its reasons live in
                    // changed_marker_layout.h, which the harness compiles.
                    const changed_marker_layout::placement marker =
                        changed_marker_layout::compute(row_top.y, row_h,
                            ImGui::GetFrameHeight(), 18.f * sf);
                    const float dot_y = marker.dot_y;
                    ImDrawList* mdl = ImGui::GetWindowDrawList();
                    ImGui::PushID(c);
                    // NoNav: this is a shortcut, not a stop in the Tab order.
                    ImGui::PushItemFlag(ImGuiItemFlags_NoNav, true);
                    // The button spans the 14*sf card indent exactly, so its
                    // left edge is the column's content edge and no part of it
                    // is clipped by the child window -- at -15*sf it used to
                    // poke a scalar-multiple of the indent outside and lose
                    // that much hit area to the clip rect. Its height comes from
                    // the same placement, so it stays badge-sized on a tall row
                    // instead of spanning the widget and popping its tooltip
                    // into empty space beside a search-result list.
                    ImGui::SetCursorScreenPos(ImVec2(row_top.x - 14.f * sf,
                        marker.button_y));
                    ImGui::InvisibleButton("##changed",
                        ImVec2(12.f * sf, marker.button_h));
                    const bool marker_hovered = ImGui::IsItemHovered();
                    if (marker_hovered)
                        {
                            imgui_addons::push_tooltip_padding();
                            ImGui::SetTooltip("%s", i18n::tr("reset_to_default_inf").c_str());
                            imgui_addons::pop_tooltip_padding();
                        }
                    if (ImGui::IsItemClicked())
                        c->set(c->get_default());
                    ImGui::PopItemFlag();
                    ImGui::PopID();
                    // Restore the cursor: the button advanced it, and the
                    // next row must begin exactly where the value left it.
                    ImGui::SetCursorScreenPos(row_bottom);
                    mdl->AddCircleFilled(ImVec2(dot_x, dot_y), 2.5f * sf, ImGui::GetColorU32(
                        menu::with_alpha(menu::palette::accent2,
                            marker_hovered ? 1.f : 0.85f)));
                    if (marker_hovered)
                        mdl->AddCircle(ImVec2(dot_x, dot_y), 5.5f * sf,
                            ImGui::GetColorU32(menu::with_alpha(menu::palette::accent2, 0.45f)));
                };

                auto draw_card = [&](Module* m) {
                    // Names the card for the overlay's exception report. Set BEFORE the
                    // frame and not reset after it, so a throw anywhere inside -- the
                    // values, prepare_menu_draw, draw_menu_extra -- still reads back as
                    // this card. Module::name outlives the frame.
                    set_draw_stage_card(m->name.c_str());
                    draw_card_frame(m->name.c_str(), i18n::tr(m->get_display_key()).c_str(), [&]() {
                        m->prepare_menu_draw();
                        if (m->draw_menu_extra_before_values())
                            m->draw_menu_extra();
                        m->apply([&](ConfigValue* c) {
                            if (c->is_hidden_in_owner_menu())
                                return;
                            // Changed-from-default, marked in the gutter
                            // after the row has drawn. Computed before the
                            // draw (is_changed() reads the live value) and
                            // consumed after, because the gutter position is
                            // the row top, which only exists before the row
                            // advances the cursor.
                            const bool changed = c->is_changed();
                            const ImVec2 row_top = ImGui::GetCursorScreenPos();
                            c->draw();
                            if (changed)
                                draw_changed_marker(c, row_top);
                        });
                        if (!m->draw_menu_extra_before_values())
                            m->draw_menu_extra();
                    });
                };

                ImGui::SetCursorPos(ImVec2(content_x, content_top));
                ImGui::BeginChild("##col1", ImVec2(col_w, content_h), false);
                bool switched = false;

                // Close column 1 and open column 2. Factored out because the
                // Raid Dashboard needs to perform the same switch from two
                // places: after drawing its last left-column card, and at the
                // Debug Log slot when that card is hidden (see below).
                // Read after the card loop as well, to decide whether column 2 is
                // still open when the hotkeys panel is drawn.
                auto split_to_second_column = [&]() {
                    if (switched) return;
                    switched = true;
                    ImGui::EndChild();
                    ImGui::SetCursorPos(ImVec2(content_x + col_w + col_gap, content_top));
                    ImGui::BeginChild("##col2", ImVec2(col_w, content_h), false);
                };

                if (credits_tab)
                {
                    // [sf], not []: the body reads the local scale factor for
                    // the spacer above the list.
                    draw_card_frame("credits", "Credits", [&]() {
                        // The list itself lives in globals::k_credits so it stays
                        // next to the rest of the build's identity strings rather
                        // than being duplicated here -- this only renders it.
                        ImGui::TextWrapped("TarkovAddons is the work of many hands. The "
                            "original release and the credits below come from the "
                            "author's own list in the UnknownCheats release thread; "
                            "the rest contributed patches, patterns and modules there.");
                        ImGui::Dummy(ImVec2(0, 6 * sf));
                        for (size_t credit_index = 0; credit_index < globals::k_credits_count; ++credit_index) {
                            const globals::Credit& credit = globals::k_credits[credit_index];
                            ImGui::TextWrapped("%s: %s", credit.name, credit.contribution);
                        }
                    });
                }
                else
                {
                    // apply_all, NOT apply. apply() skips modules whose
                    // is_active() is false, and is_active() means "wants to do
                    // work" -- it is computed from the module's own toggles. Using
                    // it here meant a module with every toggle off removed its own
                    // card, taking the only control that could turn it back on with
                    // it. Minimap hit this permanently: is_active() is
                    // `radar->get_value()` and `radar` defaults to false, so on a
                    // default config the card never drew and the radar could never
                    // be enabled. ESP and Chams have the same trap waiting for
                    // anyone who turns off every sub-toggle.
                    // PARTITION, THEN DRAW.
                    //
                    // The card list is built first and the column boundary resolved
                    // from it, so the loop below has no per-card layout branch at all.
                    // It used to have eleven, all keyed on `m->name`, all evaluated
                    // after the card had already been drawn -- which is why every
                    // pinned boundary also needed a "keep this left" opt-out to stop
                    // the height heuristic pre-empting it, and why those opt-outs had
                    // to cover a whole run of cards rather than the one the boundary
                    // keyed on. See column_layout.h for the table and for the three
                    // defects that came out of the old shape.
                    //
                    // Two consequences worth naming. The conditional Debug Log card
                    // needs no special case: it is simply absent from `cards`, so the
                    // boundary moves up to just after Raid Dashboard by itself. And
                    // `switched` becomes a property of the loop rather than something
                    // a predicate can fire at an awkward moment.
                    std::vector<Module*> cards;
                    ModuleManager::get_instance()->apply_all([&](Module* m) {
                        if (m->category != selected_tab || m->hidden_in_category_menu) return;
                        if (m->name == "Debug Log"
                            && !mm->raid_dashboard_module->show_debug_log->get_value())
                            return;
                        cards.push_back(m);
                    });

                    std::vector<std::string_view> card_names;
                    card_names.reserve(cards.size());
                    for (Module* m : cards)
                        card_names.emplace_back(m->name);

                    const column_layout::Partition part =
                        column_layout::partition(selected_tab, card_names);

                    int drawn = 0;
                    for (Module* m : cards)
                    {
                        // The pinned boundary: everything from here on is column 2.
                        if (part.pinned && drawn == part.left_count)
                            split_to_second_column();

                        draw_card(m);
                        // The height heuristic, for tabs with no pinned boundary -- and never
                        // for a card the table keeps left. On a pinned tab the split
                        // is already decided, so this cannot move it.
                        if (!part.pinned && !config_tab && !switched
                            && !column_layout::suppress_heuristic(selected_tab, m->name)
                            && ImGui::GetCursorPosY() >= content_h * 0.5f)
                            split_to_second_column();

                        ++drawn;
                    }
                }
                // Keep key assignments reachable from the Raid Dashboard as
                // well as the hidden legacy Config page.
                //
                // `switched` decides who owns column 2. If the loop above already
                // called split_to_second_column() -- which it does on every tab
                // that has an explicit boundary, and on any tab where the
                // 50%-height fallback fired -- then column 2 is STILL OPEN and
                // the hotkeys panel belongs inside it. Column 1 is only still open
                // when nothing split, and that is the only case that needs
                // closing and re-opening here.
                //
                // The previous unconditional EndChild() + BeginChild("##col2")
                // opened column 2 twice under the same ID in one frame. Whether
                // that discards the first block's cards depends on ImGui's
                // child-window reuse, which is not something to leave resting on
                // a guess: `##col1`/`##col2` are used nowhere else and no ID is
                // saved across them, so honouring `switched` is both correct and
                // free.
                if (config_tab || selected_tab == RaidDashboard)
                {
                    if (!switched)
                    {
                        ImGui::EndChild();                 // close column 1
                        ImGui::SetCursorPos(ImVec2(content_x + col_w + col_gap, content_top));
                        ImGui::BeginChild("##col2", ImVec2(col_w, content_h), false);
                    }
                    set_draw_stage("hotkeys panel");
                    draw_card_frame("hotkeys", i18n::tr("hotkeys_sec").c_str(), []() { hotkeys::draw_panel(); });
                    ImGui::EndChild();
                }
                else
                {
                    ImGui::EndChild();                     // close column 1
                }
            }
            ImGui::End();
            ImGui::PopStyleVar(2); // Alpha + WindowPadding
        }

        // The palette is its own window, above the menu and outside it. It
        // survives the close animation's tail (the same reason the menu
        // does), but never outlives the menu itself: draw_imgui going false
        // through the title bar's close button does not touch qs_open.
        if (qs_open && !draw_imgui)
            qs_open = false;
        if (qs_open)
            draw_quick_search_palette();
        // The arrival glow decays here rather than in the card frame so it
        // advances even on frames the target card is not drawn (a folded
        // tab, or the one frame between the jump and the redraw).
        nav_target_glow = (std::max)(nav_target_glow - ImGui::GetIO().DeltaTime / 0.9f, 0.f);

        // listen to menu key
        if (GetAsyncKeyState(VK_INSERT) & 1)
        {
            draw_imgui = !draw_imgui;
            // The palette belongs to an open menu; hiding the menu without
            // it would leave the next Insert press opening the menu behind
            // a palette nobody can see the reason for.
            qs_open = qs_open && draw_imgui;
        }

        // draw overlay
        //
        // This runs EVERY FRAME, whether or not the menu is open, and it is outside the
        // window block above -- which is why it is worth naming per module. Every
        // draw_overlay() currently returns early when !is_in_raid, but the overlay's
        // raid-boundary cleanups are exactly the kind of code that ends up in here, and
        // "menu::draw" as the stage name cannot tell you which module it was.
        auto draw_list = ImGui::GetBackgroundDrawList();
        ModuleManager::get_instance()->apply([draw_list](Module* m) {
            set_draw_stage_overlay(m->name.c_str());
            m->draw_overlay(draw_list);
        });
        set_draw_stage("menu::draw");
    }
} // namespace menu
