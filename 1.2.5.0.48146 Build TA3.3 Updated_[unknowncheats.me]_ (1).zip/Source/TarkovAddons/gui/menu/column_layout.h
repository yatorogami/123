#pragma once

// WHERE EACH MENU CARD GOES, and where the column boundary falls.
//
// This exists because that decision used to be eleven `m->name == "..."` predicates
// evaluated *while drawing*, in menu.cpp. Three separate defects came out of that,
// all the same shape:
//
//   * The Raid Dashboard boundary was keyed on the Debug Log card, but Debug Log
//     was registered AFTER Favorites -- so switching "Show Debug Log" on moved
//     Favorites into column 1 with it and left the right column holding Configs
//     alone. (2026-10-03)
//   * Because the split was decided after drawing a card, every explicit boundary
//     needed a matching "keep this left" opt-out to stop the height heuristic
//     firing early -- and those opt-outs had to cover a whole *run* of cards, not
//     just the one the boundary keyed on. The Profile page needed a paragraph to
//     explain it.
//   * Deciding mid-draw meant `##col2` could be opened twice in one frame, once by
//     the split and once by the hotkeys panel at the end.
//
// So the policy is DATA here, and it is resolved BEFORE anything is drawn. There is
// no per-card branch in the render loop at all: one partition, then two children
// with known contents.
//
// Header-only and free of ImGui, IL2CPP and Win32 on purpose -- that is what lets
// tools/harness/test_column_layout.cpp compile and assert the real table. A layout
// rule that can only be checked by launching a raid is a layout rule that gets
// "fixed" by nudging a registration order until it looks right once.
//
// It keys on the real ModuleCategory rather than a private copy, so there is one
// source of truth for tab identity.

#include <cstdint>
#include <string_view>
#include <vector>

#include "../../module/ModuleCategory.h"

namespace column_layout {

    enum class Column : uint8_t {
        // Placed by the 50%-height heuristic, or left wherever it lands if the tab
        // has no pinned boundary.
        Auto,
        // Column 1, and the last one of these PINS the boundary: the split falls
        // immediately after it. This is how a tab declares "these belong left,
        // everything after belongs right".
        Left,
        // Column 1, but does NOT pin. The heuristic still decides what follows.
        // Needed by the one tab that has a keep-left card and no pinned split --
        // see kTable.
        Sticky,
    };

    struct Entry {
        ModuleCategory tab;
        std::string_view card;
        Column column;
    };

    // The whole layout, in one place. `card` is Module::name, which is what the
    // render loop matches on; if a module is renamed, this is the table that has to
    // change with it, and tools/harness/test_column_layout.cpp asserts every name
    // here still exists in ModuleManager's registrations.
    inline constexpr Entry kTable[] = {
        // Raid Dashboard. Debug Log is registered immediately after Raid Dashboard
        // for this to work; see the column-order note in ModuleManager.h. The card
        // is *conditionally absent* when "Show Debug Log" is off, and that needs no
        // special case here: the partition is computed from the cards actually
        // present, so the boundary moves up to just after Raid Dashboard by itself.
        {RaidDashboard, "Raid Dashboard", Column::Left},
        {RaidDashboard, "Debug Log", Column::Left},

        // Exploit: Aimbot -> Door Unlocker -> Weapon -> Player left, Chams -> ESP
        // right. Minimap has its own tab, which is what freed the room.
        {Exploit, "Aimbot", Column::Left},
        {Exploit, "Door Unlocker", Column::Left},
        {Exploit, "Weapon", Column::Left},
        {Exploit, "Player", Column::Left},

        // Profile page: the two hideout cards straddle the columns, which is why
        // Hideout is registered BEFORE Experience Editor.
        {ProfileEditor, "Trader Editor", Column::Left},
        {ProfileEditor, "Hideout", Column::Left},

        // These tabs pin a boundary, so the cards after the last Left one sit
        // alone on the right. Each used to be a predicate named
        // "move_X_to_right" that in fact split AFTER X -- the names described the
        // consequence, not the rule, which is why they read as contradictions.
        {BotSpawner, "World", Column::Left},
        // The AI-limit card belongs on the LEFT, next to the card whose map it
        // configures, and NOT inside the Bot Controls card -- eight sliders in a
        // card that already held the bot-teleport pair read as one long list with
        // no separation. Marking it Left is also what pins the boundary here: the
        // split falls after the last Left card, so the order these are declared in
        // decides which card goes right.
        {BotSpawner, "AI Limit", Column::Left},
        {WeaponBuilder, "Weapon Builder", Column::Left},
        {ItemSpawnerEditor, "Item Editor", Column::Left},
        {QuestCompleter, "Quest Completer", Column::Left},

        // Teleport is the one tab with a keep-left card and NO pinned split: Map
        // Selector must stay left, but where the split actually falls is still the
        // height heuristic's decision. Marking it Left would silently promote it to
        // a pinned boundary and move Marked Rooms and Loot Teleporter for good, so
        // it is Sticky on purpose -- see tools/harness/test_column_layout.cpp.
        {Teleport, "Map Selector", Column::Sticky},
    };

    inline Column column_for(const ModuleCategory tab, const std::string_view card) {
        for (const auto& e : kTable)
            if (e.tab == tab && e.card == card)
                return e.column;
        return Column::Auto;
    }

    // True for a card that must not be pushed right by the height heuristic,
    // whether or not it pins the boundary.
    inline bool suppress_heuristic(const ModuleCategory tab, const std::string_view card) {
        const Column c = column_for(tab, card);
        return c == Column::Left || c == Column::Sticky;
    }

    struct Partition {
        // Cards [0, left_count) are column 1; the rest are column 2.
        int left_count = 0;
        // True when the table pinned the boundary. When false the caller falls back
        // to the height heuristic and `left_count` is meaningless.
        bool pinned = false;
    };

    // Resolve the boundary for one tab from the cards that will actually be drawn,
    // in draw order.
    //
    // The boundary is 1 + the index of the LAST Left card. Using the last rather
    // than the first is what lets a tab list its whole left run without caring about
    // order, and it is why "opt out of the heuristic for every card in the run" is
    // no longer a requirement -- Left already implies both.
    inline Partition partition(const ModuleCategory tab,
                               const std::vector<std::string_view>& cards) {
        Partition p;
        int last_left = -1;
        for (int i = 0; i < static_cast<int>(cards.size()); ++i) {
            if (column_for(tab, cards[i]) == Column::Left)
                last_left = i;
        }
        if (last_left >= 0) {
            p.pinned = true;
            p.left_count = last_left + 1;
        }
        return p;
    }
}