#pragma once

#include <algorithm>

// WHERE the changed-from-default gutter dot goes, as arithmetic.
//
// Why this is its own header, and not four lines inside menu.cpp
// ----------------------------------------------------------------
// The dot's position is the only part of the changed-from-default treatment
// with a decision in it, and it is the part that was wrong twice: it was
// pinned to the row's top edge, then re-centred on the whole row, and both
// read as off because neither of them asked what the row's height MEANS.
// menu.cpp needs ImGui, resources.h and the DX hook, so a test could only
// ever exercise a COPY of this geometry -- and a copy is a copy that drifts
// from the geometry that ships. Same split as card_fold_state.h,
// column_layout.h, quick_search.h and hotkey_conflicts.h, for the same
// reason: tools/harness compiles the real thing
// (test_changed_marker_layout.cpp).
//
// The rule, and the measurement it is measured against
// ------------------------------------------------------
// Every row in this menu starts with a LABEL on its own line -- SelectValue,
// TextboxValue, ItemSearchValue, the slider rows and the checkbox rows all
// draw it first (SelectValue::draw's label_above_ only decides whether the
// control goes under or beside it). So "the label line" is a fixed height --
// ImGui's GetFrameHeight(), because every one of those labels is drawn with
// AlignTextToFramePadding, which makes the text's line box exactly a frame --
// and the rest of the row is whatever the control happens to need.
//
// That difference is the whole bug. A two-line slider is twice the height of a
// checkbox. ItemSearchValue's row grows with the NUMBER OF SEARCH RESULTS, so
// its height changes as you type. Any position derived from the row's height
// is therefore a function of content, and moves while the user is reading it.
// The label line depends only on the label.
//
// So: the dot is CENTRED ON THE LABEL LINE, not on the row box and not flush to
// the row's top edge.
//
// - Centred on the row (the version before this) put a search row's dot in the
//   middle of its result list, most of a screen away from the label it
//   annotates.
// - Flush to the row top (the version before that) sat half a line ABOVE the
//   label's optical centre, which against the card's dense padding reads as a
//   mis-registered element rather than as a badge. Centred on the line is the
//   only position that is neither.
//
// The hit target follows the same rule and is capped at the line as well: an
// invisible button stretched over a 200px search row pops "click to reset"
// into empty space next to the results, and swallows clicks there.

namespace changed_marker_layout {

    // Where to draw, in the same screen-space coordinates menu.cpp hands in.
    struct placement {
        // Centre of the dot.
        float dot_y = 0.f;
        // Top of the invisible button, and its height. Callers that want the
        // button centred on the dot's own row (the gutter is narrower than the
        // line) use button_y with button_h.
        float button_y = 0.f;
        float button_h = 0.f;
    };

    // row_top_y     GetCursorScreenPos().y taken BEFORE the row drew.
    // row_h         how far the row advanced the cursor -- available only
    //                AFTERWARDS, which is why the caller draws the dot last.
    // label_line_h  ImGui::GetFrameHeight(): the label's own line box.
    // max_button_h  the height cap, i.e. 18 * scale_factor at the call site.
    //
    // row_h is an INPUT, not a quantity the answer may depend on. It is in the
    // signature only so the degenerate cases can be clamped rather than trusted:
    // a label line longer than its own row, and a row measured as zero high.
    inline placement compute(const float row_top_y, const float row_h,
        const float label_line_h, const float max_button_h) {
        placement out;

        // A row with no height cannot be clamped against its own height, so the
        // line stands alone. This is a real input, not a hypothetical: a value
        // whose draw() emits nothing (a hidden row measured anyway) reports
        // row_h == 0, and clamping to it would produce a ZERO-HEIGHT BUTTON --
        // a marker the user can see and never press.
        const float height = row_h > 0.f ? row_h : label_line_h;

        float line = label_line_h > 0.f ? label_line_h : height;
        // A label line taller than the row that contains it is impossible; take
        // the row, so the dot cannot land outside what was drawn.
        if (line > height) line = height;

        out.dot_y = row_top_y + line * 0.5f;

        // The smaller of the caller's cap and the line, and both bounds are
        // load-bearing in different regimes: the cap (18 * scale_factor) is
        // what keeps the hit area badge-sized on a tall row instead of
        // spanning the whole widget, and the line is what keeps it from
        // spilling below the label when the cap is LARGER than the line --
        // which is what a large DPI scale factor produces, and what would
        // otherwise put the tooltip's trigger back down the widget.
        out.button_h = (std::min)(max_button_h, line);
        out.button_y = row_top_y + (line - out.button_h) * 0.5f;
        return out;
    }

}