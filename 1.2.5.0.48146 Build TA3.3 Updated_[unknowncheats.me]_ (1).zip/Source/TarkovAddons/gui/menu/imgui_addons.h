#pragma once
#include <imgui.h>
#include <imgui_stdlib.h>
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstdint>
#include <functional>
#include <string>
#include <unordered_map>
#include <vector>

#include "menu_style.h"
#include "../../util/i18n.h"

namespace imgui_addons {
    // ---------- small helpers ----------

    inline ImU32 lerp_col(const ImVec4& a, const ImVec4& b, float t) {
        return ImGui::GetColorU32(ImVec4(
            a.x + (b.x - a.x) * t,
            a.y + (b.y - a.y) * t,
            a.z + (b.z - a.z) * t,
            a.w + (b.w - a.w) * t));
    }

    // per-widget animation state (eased toward target each frame)
    inline float animate(ImGuiID id, float target, float speed = 16.f) {
        static std::unordered_map<ImGuiID, float> state;
        float& v = state[id];
        v += (target - v) * (std::min)(1.f, ImGui::GetIO().DeltaTime * speed);
        return v;
    }

    inline std::string label_text(const std::string& label) {
        return label.substr(0, label.find("##"));
    }

    inline void push_disabled_dim() {
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ImGui::GetStyle().Alpha * 0.45f);
    }

    // ---- the numeric face -------------------------------------------------
    //
    // JetBrains Mono, for the places a number is read rather than scanned:
    // slider readouts, keycaps, coordinates, item ids. Ambiguous 0/O/1/l and a
    // constant advance are the reason a numeric menu wants a mono face.
    //
    // PushFont(nullptr) ASSERTS, and the face is legitimately absent when the
    // RCDATA could not be read, so every call goes through this pair. The
    // returned bool says whether a face was actually pushed: pop_mono_font()
    // is then the matching no-op, so the calls can be unconditional.
    inline bool push_mono_font() {
        if (ImFont* mono = menu::get_mono_font()) {
            ImGui::PushFont(mono);
            return true;
        }
        return false;
    }

    inline void pop_mono_font(const bool pushed) {
        if (pushed)
            ImGui::PopFont();
    }

    // ---- search fields ----------------------------------------------------
    //
    // Every search box in this project draws through this, because the theme's
    // FramePadding is (4, 3) -- tuned back when the menu was dense enough that
    // vertical space cost a row, and it leaves typed text against the frame's
    // left and top edge. In a search box, where the text IS the content, that
    // reads as squished rather than compact, and the taller control makes the
    // row below it sit one line lower, which is fine.
    //
    // Scoped on purpose: theme()'s padding cannot move, because the widget
    // helpers here pass widths tuned to it (see the note in menu.h) and the
    // card layout is measured against those metrics.
    inline void push_search_padding() {
        const float sf = menu::get_scale_factor();
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(9.f * sf, 7.f * sf));
        ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 6.f * sf);
    }

    inline void pop_search_padding() {
        ImGui::PopStyleVar(2);
    }

    // ---- tooltips ----------------------------------------------------------
    //
    // The same complaint as the search fields, in a different window. A
    // tooltip inherits theme()'s WindowPadding of (8, 8), which at this font
    // size leaves the text sitting on the popup's edge -- the tooltip reads as
    // a tooltip rather than as a sentence, which defeats the whole point,
    // since these carry the explanations a label cannot (what the three
    // survival modes differ in, what a cost knob does).
    //
    // Scoped the same way and for the same reason: theme()'s padding is
    // measured against by the widget helpers here (menu.h records it), so it
    // gets pushed per tooltip rather than changed for the window.
    //
    // It must be POPPED AFTER SetTooltip returns, because SetTooltip begins
    // AND ends the popup inside the one call -- the var is gone from the stack
    // too early if it is popped after a Begin/End pair, and left on it
    // forever if the call is wrapped in a guard that skips it.
    inline void push_tooltip_padding() {
        const float sf = menu::get_scale_factor();
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(13.f * sf, 9.f * sf));
    }

    inline void pop_tooltip_padding() {
        ImGui::PopStyleVar();
    }

    // The format a number in [mn, mx] should be shown in, derived from the
    // range rather than passed by hand at every call site.
    //
    // The default was "%.3f" everywhere, which rendered a pixel value as
    // "100.000" and an opacity as "0.450" -- debug output wearing a settings
    // label. Three bands cover the values this menu actually holds:
    //
    //   range >= 10   "%.0f"   pixels, degrees, counts, metres
    //   range >= 1    "%.2f"   multipliers, ratios, 0..1 opacity
    //   otherwise     "%.3f"   genuinely fine values (smoothing 0.00..1.00)
    //
    // A call site that disagrees passes its own format to the widget; this is
    // the default, not a policy.
    inline const char* number_format_for_range(const float mn, const float mx) {
        const float span = (std::fabs)(mx - mn);
        if (span >= 10.f)
            return "%.0f";
        if (span >= 1.f)
            return "%.2f";
        return "%.3f";
    }

    // One compact treatment for read-only feedback across custom cards.
    inline void status_line(const std::string& text, const bool highlight = false) {
        if (text.empty()) return;
        const ImVec4 color = highlight ? menu::palette::accent2
                                       : menu::with_alpha(menu::palette::muted, 0.92f);
        ImGui::TextColored(highlight ? menu::palette::accent2 : menu::palette::muted, "•");
        ImGui::SameLine(0.f, 6.f * menu::get_scale_factor());
        ImGui::TextColored(color, "%s", text.c_str());
    }

    inline void safety_bullet_text(const ImVec4& col, const char* text) {
        const float wrap_w = ImGui::GetContentRegionAvail().x;
        ImGui::PushStyleColor(ImGuiCol_Text, col);
        ImGui::PushTextWrapPos(ImGui::GetCursorPosX() + wrap_w);
        ImGui::Bullet();
        ImGui::SameLine();
        ImGui::TextUnformatted(text);
        ImGui::PopTextWrapPos();
        ImGui::PopStyleColor();
    }

    inline bool begin_safety_tooltip() {
        static ImVec2 locked_pos{};
        static bool had_tooltip = false;
        ImGuiIO& io = ImGui::GetIO();
        const bool use_locked_pos = io.KeyCtrl && had_tooltip;

        const float sf = menu::get_scale_factor();
        const ImGuiStyle& style = ImGui::GetStyle();
        const ImVec4 warn_tint = ImVec4(0.92f, 0.42f, 0.10f, 1.f);
        const ImVec4 popup_bg = style.Colors[ImGuiCol_PopupBg];
        ImGui::PushStyleColor(ImGuiCol_PopupBg, lerp_col(popup_bg, warn_tint, 0.18f));
        // The roomier frame every tooltip now gets, instead of the +10*sf this
        // one used to carry on its own -- one definition, so a fourth tooltip
        // cannot differ from the other three.
        push_tooltip_padding();
        if (use_locked_pos)
            ImGui::SetNextWindowPos(locked_pos);

        const bool visible = ImGui::Begin("##Tooltip_Safety", nullptr,
            ImGuiWindowFlags_Tooltip | ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_AlwaysAutoResize);
        ImGui::PopStyleColor();

        if (!visible)
        {
            had_tooltip = false;
            ImGui::End();
            ImGui::PopStyleVar();
            return false;
        }

        ImGui::SeparatorText(i18n::tr("safety_check_inf").c_str());
        locked_pos = ImGui::GetWindowPos();
        had_tooltip = true;
        return true;
    }

    inline void end_safety_tooltip() {
        ImGui::End();
        ImGui::PopStyleVar();
    }

    inline void draw_safety_tooltip_body() {
        safety_bullet_text(menu::palette::txt,
            i18n::tr("safety_warning_inf").c_str());
        ImGui::Spacing();
        safety_bullet_text(menu::with_alpha(menu::palette::txt, 0.88f),
            i18n::tr("safety_understand_inf").c_str());

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        safety_bullet_text(menu::palette::muted,
            i18n::tr("safety_ctrl_click_inf").c_str());

        ImGui::Spacing();
        safety_bullet_text(menu::palette::accent2, i18n::tr("play_it_safe_inf").c_str());
    }

    inline void show_safety_tooltip() {
        if (!begin_safety_tooltip())
            return;

        draw_safety_tooltip_body();
        end_safety_tooltip();
    }

    // ---------- modern widgets ----------

    // animated toggle switch (replaces the old checkbox)
    // `tooltip` is shown while the row is hovered. Optional and defaulted to nullptr,
    // so every existing call site is unchanged; it exists for toggles whose label does
    // not carry what the toggle does (the three survival modes, which differ only in
    // which body parts they protect and cannot say so in a four-word label).
    bool checkbox(const std::string& label, bool* v, const bool disabled = false,
        const bool master = false, const bool safety_switch = false, bool* favorite = nullptr,
        const char* tooltip = nullptr);

    // custom slider track+knob with draggable handle
    inline bool slider_core(const std::string& label, float* value, float vmin, float vmax, bool is_int,
        const char* fmt, const bool disabled = false) {
        const float sf = menu::get_scale_factor();
        ImGui::PushID(label.c_str());

        const std::string txt = label_text(label);

        if (disabled) push_disabled_dim();

        // label + value line
        ImGui::AlignTextToFramePadding();
        ImGui::TextColored(disabled ? menu::with_alpha(menu::palette::muted, 0.7f) : menu::palette::txt,
            "%s", txt.c_str());

        char vbuf[32];
        if (is_int)
            snprintf(vbuf, sizeof(vbuf), "%d", static_cast<int>(lroundf(*value)));
        else
            snprintf(vbuf, sizeof(vbuf), fmt, *value);
        const ImVec2 vts = ImGui::CalcTextSize(vbuf);
        ImGui::SameLine(ImGui::GetWindowWidth() - vts.x - 26.f * sf);
        ImGui::TextColored(disabled ? menu::with_alpha(menu::palette::muted, 0.7f) : menu::palette::txt,
            "%s", vbuf);

        // track
        const ImVec2 p = ImGui::GetCursorScreenPos();
        const float track_w = (std::max)(10.f, ImGui::GetContentRegionAvail().x - 14.f * sf);
        const float hit_h = 16.f * sf;
        const float track_h = 5.f * sf;

        ImGui::InvisibleButton("s", ImVec2(track_w, hit_h));
        const bool active = !disabled && ImGui::IsItemActive();
        const bool hovered = !disabled && ImGui::IsItemHovered();
        if (active)
        {
            float t = (ImGui::GetIO().MousePos.x - p.x) / track_w;
            t = t < 0.f ? 0.f : (t > 1.f ? 1.f : t);
            *value = vmin + t * (vmax - vmin);
            if (is_int) *value = static_cast<float>(lroundf(*value));
        }

        float t = (vmax > vmin) ? (*value - vmin) / (vmax - vmin) : 0.f;
        t = t < 0.f ? 0.f : (t > 1.f ? 1.f : t);

        const float cy = p.y + hit_h * 0.5f;
        ImDrawList* dl = ImGui::GetWindowDrawList();
        dl->AddRectFilled(ImVec2(p.x, cy - track_h * 0.5f), ImVec2(p.x + track_w, cy + track_h * 0.5f),
            ImGui::GetColorU32(menu::palette::surface2), track_h * 0.5f);
        dl->AddRectFilled(ImVec2(p.x, cy - track_h * 0.5f), ImVec2(p.x + t * track_w, cy + track_h * 0.5f),
            ImGui::GetColorU32(menu::palette::accent), track_h * 0.5f);
        const float kr = (active || hovered) ? 7.5f * sf : 6.f * sf;
        dl->AddCircleFilled(ImVec2(p.x + t * track_w, cy), kr + 1.f * sf,
            ImGui::GetColorU32(menu::with_alpha(menu::palette::accent, 0.35f)));
        dl->AddCircleFilled(ImVec2(p.x + t * track_w, cy), kr, ImGui::GetColorU32(ImVec4(1, 1, 1, 1)));

        ImGui::Dummy(ImVec2(0, 4.f * sf));
        if (disabled) ImGui::PopStyleVar();
        ImGui::PopID();
        return active;
    }

    bool slider_float(const std::string& label, float* v, float mn, float mx,
        const bool disabled = false);

    bool slider_int(const std::string& label, int* v, int mn, int mx, const bool disabled = false);

    // right-aligned control width helper
    inline float right_align(float ctrl_w) {
        const float sf = menu::get_scale_factor();
        // Keep controls clear of the scroll bar/right card border.
        ImGui::SameLine(ImGui::GetWindowWidth() - ctrl_w - 26.f * sf);
        ImGui::SetNextItemWidth(ctrl_w);
        return ctrl_w;
    }

    bool slider_int_editable(const std::string& label, int* v, int mn, int slider_max,
        const bool disabled = false);

    bool input_float(const char* label, float* v, const float step = 0.1f, const bool disabled = false);

    // `tooltip` is shown while the track is hovered. Optional and defaulted to nullptr,
    // so every existing call site is unchanged; it exists because some sliders are cost
    // knobs whose number says nothing about what moving it does.
    bool slider_float_editable(const std::string& label, float* v, float mn, float mx, const bool disabled = false,
        const char* tooltip = nullptr);

    bool select(const std::string& label, int* v, const std::vector<const char*>& options,
        const bool disabled = false, const bool translate_options = true,
        const bool label_above = false);

    bool colorpicker(const std::string& label, ImVec4* v, const bool disabled = false);

    bool int_textbot(const std::string& label, int* v);

    bool textbox(const std::string& label, std::string* v);

    bool compact_textbox(const std::string& label, std::string* v, const size_t max_chars = 3,
        const bool disabled = false);
} // namespace imgui_addons
