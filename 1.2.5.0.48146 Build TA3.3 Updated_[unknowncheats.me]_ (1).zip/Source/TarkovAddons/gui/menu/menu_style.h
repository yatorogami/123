#pragma once

// The part of menu.h that imgui_addons.h needs, and nothing else.
//
// Why this header exists
// ----------------------
// imgui_addons.h used to include menu.h for six symbols: four palette constants,
// with_alpha, and get_scale_factor. menu.h in turn includes three ImGui *backend*
// headers -- imgui_impl_win32.h, imgui_impl_dx11.h and imgui_impl_dx12.h -- which
// no caller of a palette constant needs. imgui_addons.h is reached by 49 of the
// project's 71 first-party translation units, so all three backends were being
// parsed 49 times over, and menu.h itself by 55.
//
// None of that is a correctness problem. It is purely rebuild cost: every edit to
// a backend header, or to anything menu.h includes, invalidated all of them.
//
// get_scale_factor is only *declared* here; it is defined in menu.cpp, because it
// reads live UI state. That is fine for a header dependency -- a declaration is
// all a caller needs -- but it does mean imgui_addons.cpp still links against
// menu.cpp. The win is in what has to be parsed, not in what has to be linked.

#include "imgui.h"

namespace menu {

    float get_scale_factor();

    // JetBrains Mono, the numeric face. Declared HERE rather than in menu.h
    // for the reason this header exists at all: imgui_addons.h needs it to
    // push the face around a slider readout, and imgui_addons.h includes
    // this header precisely so it does not have to include menu.h -- which
    // pulls in three ImGui *backend* headers that no caller of a palette
    // constant or a font pointer needs. menu.h includes this one, so every
    // caller that sees get_mono_font() through menu.h sees it too.
    //
    // Null when the face is not embedded. PushFont(nullptr) asserts, so go
    // through imgui_addons::push_mono_font() rather than calling this raw.
    ImFont* get_mono_font();

    namespace palette {
        // Refined navy/steel palette: high contrast above artwork without
        // losing the cool blue identity of Reloaded.
        constexpr ImVec4 accent = ImVec4(0.255f, 0.745f, 0.930f, 1.0f);
        constexpr ImVec4 accent2 = ImVec4(0.565f, 0.765f, 0.895f, 1.0f);
        constexpr ImVec4 bg = ImVec4(0.018f, 0.028f, 0.047f, 0.992f);
        constexpr ImVec4 surface = ImVec4(0.040f, 0.062f, 0.096f, 1.0f);
        constexpr ImVec4 surface2 = ImVec4(0.082f, 0.118f, 0.165f, 1.0f);
        constexpr ImVec4 line = ImVec4(0.185f, 0.310f, 0.410f, 1.0f);
        constexpr ImVec4 txt = ImVec4(0.955f, 0.980f, 1.000f, 1.0f);
        constexpr ImVec4 muted = ImVec4(0.590f, 0.690f, 0.780f, 1.0f);
    } // namespace palette

    inline ImVec4 with_alpha(ImVec4 c, float a) {
        c.w = a;
        return c;
    }

} // namespace menu
