#pragma once

#include <algorithm>
#include <string>
#include <unordered_map>
#include <vector>

// Fold state for the menu's cards, and its config-file representation.
//
// Split out of menu.cpp, and out of menu.h, for the same reason menu_style.h was
// split out of menu.h: this is the part that has nothing to do with drawing.
// menu.cpp owns the card frame and the click, ConfigModule owns the file, and
// this owns the record between them.
//
// The split also makes the record testable for real. menu.cpp cannot be linked
// by tools/harness -- it pulls in ImGui, resources.h and the DX hook -- so a
// harness would otherwise have to copy this logic and test the copy, which is
// how a format quietly diverges from the code that writes it. Nothing here
// touches ImGui, Win32 or the game, so
// tools/harness/test_card_fold.cpp includes this header and tests it.
//
// THREADING -- render thread, or startup before any frame exists. load() runs
// from either the Load button or ConfigModule::init(); init() is on the startup
// thread and ModuleManager::init() calls it BEFORE dxhook::init() installs the
// Present hook, so nothing can be mid-draw while it runs. append_save() and
// clear() run from the Save and Reset Defaults buttons. That ordering is the
// only reason the store is a bare unordered_map with no lock -- do not call any
// of this from a module's application_update().
namespace card_fold {

    // The live state, keyed by card id.
    //
    // The key is the card's stable id, which for a module card is the module's
    // own name -- never its heading. Headings go through i18n::tr, so keying on
    // one would rename the key on a language change and silently unfold the
    // whole menu. "Door Unlocker" and "Debug Log" are the awkward cases and both
    // work: the config record is ;-delimited and a space is not a delimiter.
    inline std::unordered_map<std::string, bool>& state() {
        static std::unordered_map<std::string, bool> value;
        return value;
    }

    // Config-file prefix for the records below. "HK:" is hotkeys', and a
    // ConfigValue's own key is "<value name>##<module name>", so this is a third
    // namespace that cannot land on either of them.
    inline constexpr const char* config_prefix = "CARD:";

    // Reads or writes one card. get() registers the card as OPEN if it is
    // unknown, so a card nobody has folded never needs a record in the file.
    inline bool get(const std::string& id) {
        return state()[id];
    }

    inline void set(const std::string& id, const bool collapsed) {
        state()[id] = collapsed;
    }

    // Applies a loaded config. REPLACES, rather than merges.
    //
    // This is the opposite of hotkeys::load(), which deliberately does not wipe:
    // there every binding has a meaningful in-memory default (fly up/down, the
    // rest unbound) and its own comment explains the choice. A folded card has
    // no such default to fall back on, so "folded under the previously loaded
    // config and absent from this one" has to resolve to open -- otherwise Load
    // would leave cards folded according to a file the user just replaced.
    inline void load(const std::unordered_map<std::string, std::string>& values) {
        state().clear();
        for (const auto& [key, value] : values)
        {
            if (!key.starts_with(config_prefix)) continue;
            // Anything but the literal "true" leaves the card open. A config can
            // be hand-edited, truncated, or written by a build that spelled these
            // differently, and "unrecognised means unfolded" is the direction
            // that fails harmlessly -- a card drawn open is a card whose controls
            // are reachable.
            if (value != "true") continue;
            state()[key.substr(std::char_traits<char>::length(config_prefix))] = true;
        }
    }

    // Appends one record per FOLDED card. Expanded is the default, so recording
    // it would add a line per card per config carrying no information -- which is
    // also why create_config() writes nothing here at all: a brand-new config has
    // no folded cards, and an absent record already means open.
    //
    // Sorted, so two saves of the same state produce the same bytes. Map
    // iteration order is unspecified, and a config whose tail reshuffles on every
    // save cannot be diffed -- which is the main reason a user would look at this
    // file at all.
    inline void append_save(std::string& value) {
        std::vector<std::string> folded;
        for (const auto& [id, collapsed] : state())
            if (collapsed) folded.push_back(id);
        std::sort(folded.begin(), folded.end());

        for (const std::string& id : folded) {
            value.append(config_prefix);
            value.append(id);
            value.append(";");
            value.append("true;");
        }
    }

    // Reset Defaults. Open is the default, so this has to happen for Reset to
    // mean what it says -- otherwise it is the one button in the app that leaves
    // the menu looking unlike the rest of the config it just reset.
    inline void clear() {
        state().clear();
    }

} // namespace card_fold