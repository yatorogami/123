#include "common.h"
#include "imgui_addons.h"

namespace imgui_addons {
    bool checkbox(const std::string& label, bool* v, const bool disabled,
        const bool master, const bool safety_switch, bool* favorite, const char* tooltip) {
        const float sf = menu::get_scale_factor();
        ImGui::PushID(label.c_str());

        const std::string txt = label_text(label);
        // Master toggles remain functionally distinct, but visually they are
        // ordinary card settings.  Only the card heading gets the bold/larger
        // type treatment.
        const float row_h = 24.f * sf;
        const ImVec2 start = ImGui::GetCursorScreenPos();
        const float avail = ImGui::GetContentRegionAvail().x;
        // Leave breathing room for the card edge and its scrollbar.
        const float right_inset = 12.f * sf;
        const float tw = 40.f * sf, th = 20.f * sf;
        const float tx = start.x + avail - tw - right_inset;
        const float ty = start.y + (row_h - th) * 0.5f;
        const float star_x = tx - 20.f * sf;

        ImGui::InvisibleButton("row", ImVec2(avail, row_h));
        const bool hovered = !disabled && ImGui::IsItemHovered();
        // `pressed` is the raw click, read before this row's own disabled gate.
        // The star consumes it first, so starring and unstarring keep working on
        // a row whose toggle is locked, while the gate below still stops the
        // toggle itself from being flipped.
        const bool pressed = ImGui::IsItemClicked();
        bool clicked = !disabled && pressed;
        const ImVec2 mouse = ImGui::GetIO().MousePos;
        const bool favorite_hovered = favorite && mouse.x >= star_x && mouse.x <= tx - 2.f * sf
            && mouse.y >= start.y && mouse.y <= start.y + row_h;
        if (favorite_hovered && pressed)
        {
            *favorite = !*favorite;
            clicked = false;
        }
        if (clicked && safety_switch && !*v && !ImGui::GetIO().KeyCtrl)
            clicked = false;
        if (clicked) *v = !*v;

        if (safety_switch && !disabled && (hovered || (ImGui::IsItemClicked() && !*v && !ImGui::GetIO().KeyCtrl)))
            show_safety_tooltip();

        // Hover tooltip for what the toggle DOES, as opposed to the safety tooltip
        // above which is about the toggle being dangerous. The two are mutually
        // exclusive by construction: a safety switch is never asked for an info
        // tooltip, and ImGui::SetTooltip would otherwise fight show_safety_tooltip's
        // own Begin/End pair for the same frame.
        if (tooltip && tooltip[0] != '\0' && !safety_switch && !disabled && hovered)
            {
                push_tooltip_padding();
                ImGui::SetTooltip("%s", tooltip);
                pop_tooltip_padding();
            }

        const float a = animate(ImGui::GetID("t"), *v ? 1.f : 0.f);
        ImDrawList* dl = ImGui::GetWindowDrawList();

        float label_x = start.x;

        ImFont* label_font = ImGui::GetFont();
        const float font_size = ImGui::GetFontSize();
        const ImVec2 ts = label_font->CalcTextSizeA(font_size, FLT_MAX, 0.f, txt.c_str());
        // The label stays at full contrast on a disabled row; the disabled
        // treatment belongs to the toggle, not the whole line (see the note
        // above push_disabled_dim at the track).
        const ImU32 label_col = ImGui::GetColorU32(
            hovered ? menu::palette::txt : menu::with_alpha(menu::palette::txt, 0.9f));
        dl->AddText(label_font, font_size,
            ImVec2(label_x, start.y + (row_h - ts.y) * 0.5f), label_col, txt.c_str());

        // track
        if (favorite)
        {
            // Only the star's OWN hover state greys it, never the row's disabled
            // flag: starring is a separate action from toggling and stays
            // available even when the toggle is not.
            const ImU32 star_color = ImGui::GetColorU32(*favorite
                    ? menu::palette::accent2
                    : menu::with_alpha(menu::palette::muted, 0.72f));
            dl->AddText(ImGui::GetFont(), ImGui::GetFontSize(),
                ImVec2(star_x, start.y + (row_h - ImGui::GetFontSize()) * 0.5f),
                star_color, *favorite ? "★" : "☆");
            if (favorite_hovered)
                {
                    push_tooltip_padding();
                    ImGui::SetTooltip(*favorite ? "Remove from Favorites" : "Add to Favorites");
                    pop_tooltip_padding();
                }
        }
        // The dim is pushed here, after the label and star, so it covers only the
        // toggle itself: a disabled row still reads its name and keeps its star
        // legible instead of the whole line fading into the background.
        if (disabled) push_disabled_dim();
        const ImU32 track = lerp_col(menu::palette::surface2, menu::palette::accent, a);
        dl->AddRectFilled(ImVec2(tx, ty), ImVec2(tx + tw, ty + th), track, th * 0.5f);

        // knob
        const float kr = th * 0.5f - 2.5f * sf;
        const float kx = tx + th * 0.5f + a * (tw - th);
        dl->AddCircleFilled(ImVec2(kx, ty + th * 0.5f), kr, ImGui::GetColorU32(ImVec4(1, 1, 1, 1)));

        if (disabled) ImGui::PopStyleVar();
        ImGui::PopID();
        return clicked;
    }
    bool slider_float(const std::string& label, float* v, float mn, float mx,
        const bool disabled) {
        return slider_core(label, v, mn, mx, false, "%.2f", disabled);
    }
    bool slider_int(const std::string& label, int* v, int mn, int mx, const bool disabled) {
        float f = static_cast<float>(*v);
        const bool r = slider_core(label, &f, static_cast<float>(mn), static_cast<float>(mx), true, "%.0f", disabled);
        *v = static_cast<int>(lroundf(f));
        return r;
    }
    bool slider_int_editable(const std::string& label, int* v, int mn, int slider_max,
        const bool disabled) {
        const float sf = menu::get_scale_factor();
        ImGui::PushID(label.c_str());

        const std::string txt = label_text(label);

        if (disabled) push_disabled_dim();

        ImGui::AlignTextToFramePadding();
        ImGui::TextColored(disabled ? menu::with_alpha(menu::palette::muted, 0.7f) : menu::palette::txt,
            "%s", txt.c_str());

        const float input_w = (std::min)(110.f * sf, ImGui::GetContentRegionAvail().x * 0.35f);
        right_align(input_w);
        int display_value = *v;
        if (disabled) ImGui::BeginDisabled();
        // DragInt, for the same reason slider_float_editable uses DragFloat:
        // the readout is a scrub handle, CTRL+click is a text field, and the
        // speed is range-derived so a sweep is a sweep on every slider. See
        // the long note there.
        const float drag_speed = (slider_max > mn)
            ? static_cast<float>(slider_max - mn) / (220.f * sf)
            : 0.01f;
        // JetBrains Mono for the readout, so a column of these lines up
        // digit-for-digit down the card instead of drifting by a pixel per
        // glyph. Pushed around the drag box only: the label above it stays in
        // the UI face, which is the point of having two.
        const bool mono = push_mono_font();
        const bool edited = ImGui::DragInt("##val", &display_value, drag_speed, mn, slider_max, "%d",
            ImGuiSliderFlags_AlwaysClamp);
        pop_mono_font(mono);
        if (disabled) ImGui::EndDisabled();
        if (!disabled && ImGui::IsItemHovered() && !ImGui::IsItemActive())
            {
                push_tooltip_padding();
                ImGui::SetTooltip("%s", i18n::tr("drag_to_adjust_inf").c_str());
                pop_tooltip_padding();
            }
        if (edited && !disabled)
            // Clamp BOTH ends. This used to clamp only the low bound, so typing
            // a value above slider_max was accepted and stored: the track then
            // pinned at the right end while the number showed something the
            // slider could not represent, and the out-of-range value went into
            // the config. The non-editable slider cannot produce that state,
            // because dragging is bounded by construction.
            *v = (std::min)(slider_max, (std::max)(mn, display_value));

        const float track_w = (std::max)(10.f, ImGui::GetContentRegionAvail().x - 14.f * sf);
        const float hit_h = 16.f * sf;
        const float track_h = 5.f * sf;
        const ImVec2 p = ImGui::GetCursorScreenPos();

        ImGui::InvisibleButton("s", ImVec2(track_w, hit_h));
        const bool active = !disabled && ImGui::IsItemActive();
        const bool hovered = !disabled && ImGui::IsItemHovered();
        if (active)
        {
            float t = (ImGui::GetIO().MousePos.x - p.x) / track_w;
            t = t < 0.f ? 0.f : (t > 1.f ? 1.f : t);
            const float raw = static_cast<float>(mn) + t * static_cast<float>(slider_max - mn);
            *v = static_cast<int>(lroundf(raw));
        }

        const float clamped = static_cast<float>((std::min)(*v, slider_max));
        float t = (slider_max > mn)
            ? (clamped - static_cast<float>(mn)) / static_cast<float>(slider_max - mn)
            : 0.f;
        t = t < 0.f ? 0.f : (t > 1.f ? 1.f : t);

        const float cy = p.y + hit_h * 0.5f;
        ImDrawList* dl = ImGui::GetWindowDrawList();
        dl->AddRectFilled(ImVec2(p.x, cy - track_h * 0.5f), ImVec2(p.x + track_w, cy + track_h * 0.5f),
            ImGui::GetColorU32(menu::palette::surface2), track_h * 0.5f);
        dl->AddRectFilled(ImVec2(p.x, cy - track_h * 0.5f), ImVec2(p.x + t * track_w, cy + track_h * 0.5f),
            ImGui::GetColorU32(menu::palette::accent), track_h * 0.5f);
        const float kr = (active || hovered) ? 7.5f * sf : 6.f * sf;
        dl->AddCircleFilled(ImVec2(p.x + t * track_w, cy), kr + 1.f * sf,
            ImGui::GetColorU32(menu::with_alpha(menu::palette::accent, 0.35f)));
        dl->AddCircleFilled(ImVec2(p.x + t * track_w, cy), kr, ImGui::GetColorU32(ImVec4(1, 1, 1, 1)));

        ImGui::Dummy(ImVec2(0, 4.f * sf));
        if (disabled) ImGui::PopStyleVar();
        ImGui::PopID();
        return active || edited;
    }
    bool input_float(const char* label, float* v, const float step, const bool disabled) {
        const float sf = menu::get_scale_factor();
        ImGui::PushID(label);
        if (disabled) push_disabled_dim();
        const std::string label_txt = i18n::tr(label);
        ImGui::AlignTextToFramePadding();
        ImGui::TextColored(disabled ? menu::with_alpha(menu::palette::muted, 0.7f) : menu::palette::txt,
            "%s", label_txt.c_str());
        const float input_w = (std::min)(130.f * sf, ImGui::GetContentRegionAvail().x * 0.42f);
        right_align(input_w);
        if (disabled) ImGui::BeginDisabled();
        // The calibration coordinates in the map editor. Mono for the same
        // reason as the slider readouts, and the same "the face may be absent"
        // wrapper.
        const bool mono = push_mono_font();
        const bool edited = ImGui::InputFloat("##val", v, step, step * 10.f,
            number_format_for_range(*v - 100.f, *v + 100.f));
        pop_mono_font(mono);
        if (disabled) ImGui::EndDisabled();
        ImGui::Dummy(ImVec2(0, 2.f * sf));
        if (disabled) ImGui::PopStyleVar();
        ImGui::PopID();
        return edited;
    }
    bool slider_float_editable(const std::string& label, float* v, float mn, float mx, const bool disabled,
        const char* tooltip) {
        const float sf = menu::get_scale_factor();
        ImGui::PushID(label.c_str());

        const std::string txt = label_text(label);

        if (disabled) push_disabled_dim();

        ImGui::AlignTextToFramePadding();
        ImGui::TextColored(disabled ? menu::with_alpha(menu::palette::muted, 0.7f) : menu::palette::txt,
            "%s", txt.c_str());

        const float input_w = (std::min)(130.f * sf, ImGui::GetContentRegionAvail().x * 0.42f);
        right_align(input_w);
        float display_value = *v;
        if (disabled) ImGui::BeginDisabled();
        // DragFloat, not InputFloat, and that is the whole of feature 4: the
        // readout becomes a scrub handle as well as a number. A drag adjusts
        // the value continuously -- the precision affordance a click-to-type
        // box does not have -- and CTRL+click still turns it into a text
        // field, because that hybrid is built into DragFloat itself
        // (ImGuiSliderFlags_NoInput would switch it off). The track below is
        // untouched, so both drag surfaces keep working.
        //
        // The speed is derived from the range so one ~220px sweep spans it.
        // A fixed 1.0 would cross the 0..3840 camera FOV range in four
        // pixels of mouse movement and a 0..1 range in one, which is the
        // difference between a control and a coin flip.
        const float drag_speed = (mx > mn) ? (mx - mn) / (220.f * sf) : 0.01f;
        // Range-derived format, not "%.3f" everywhere: a 0..3840 pixel value
        // rendered as "100.000" and a 0..1 opacity as "0.450", which reads as a
        // debug print rather than a setting. See number_format_for_range().
        // Pass a format to the value type to override it.
        const bool mono = push_mono_font();
        const bool edited = ImGui::DragFloat("##val", &display_value, drag_speed, mn, mx,
            number_format_for_range(mn, mx), ImGuiSliderFlags_AlwaysClamp);
        pop_mono_font(mono);
        if (disabled) ImGui::EndDisabled();
        // Skipped while the box is active: during a CTRL+click text entry a
        // tooltip under the cursor is noise.
        if (!disabled && ImGui::IsItemHovered() && !ImGui::IsItemActive())
            {
                push_tooltip_padding();
                ImGui::SetTooltip("%s", i18n::tr("drag_to_adjust_inf").c_str());
                pop_tooltip_padding();
            }
        if (edited && !disabled)
            // Clamp to [mn, mx]. This used to assign the typed value verbatim,
            // so the text box was a hole straight past the slider's range: type
            // 1e9 or -5 into a 0..1 slider and it was accepted, drawn with the
            // handle pinned at an end, and written to the config verbatim. The
            // non-editable slider cannot be put in that state at all, since
            // slider_core() bounds the drag parameter to 0..1.
            *v = (std::min)(mx, (std::max)(mn, display_value));

        const float track_w = (std::max)(10.f, ImGui::GetContentRegionAvail().x - 14.f * sf);
        const float hit_h = 16.f * sf;
        const float track_h = 5.f * sf;
        const ImVec2 p = ImGui::GetCursorScreenPos();

        ImGui::InvisibleButton("s", ImVec2(track_w, hit_h));
        const bool active = !disabled && ImGui::IsItemActive();
        const bool hovered = !disabled && ImGui::IsItemHovered();
        if (active)
        {
            float t = (ImGui::GetIO().MousePos.x - p.x) / track_w;
            t = t < 0.f ? 0.f : (t > 1.f ? 1.f : t);
            *v = mn + t * (mx - mn);
        }

        float t = (mx > mn) ? (*v - mn) / (mx - mn) : 0.f;
        t = t < 0.f ? 0.f : (t > 1.f ? 1.f : t);

        const float cy = p.y + hit_h * 0.5f;
        ImDrawList* dl = ImGui::GetWindowDrawList();
        dl->AddRectFilled(ImVec2(p.x, cy - track_h * 0.5f), ImVec2(p.x + track_w, cy + track_h * 0.5f),
            ImGui::GetColorU32(menu::palette::surface2), track_h * 0.5f);
        dl->AddRectFilled(ImVec2(p.x, cy - track_h * 0.5f), ImVec2(p.x + t * track_w, cy + track_h * 0.5f),
            ImGui::GetColorU32(menu::palette::accent), track_h * 0.5f);
        const float kr = (active || hovered) ? 7.5f * sf : 6.f * sf;
        dl->AddCircleFilled(ImVec2(p.x + t * track_w, cy), kr + 1.f * sf,
            ImGui::GetColorU32(menu::with_alpha(menu::palette::accent, 0.35f)));
        dl->AddCircleFilled(ImVec2(p.x + t * track_w, cy), kr, ImGui::GetColorU32(ImVec4(1, 1, 1, 1)));


        // Hover tooltip, hooked on the TRACK's existing `hovered` rather than adding a
        // second hit target, so it cannot change what the widget responds to. Placed
        // before PopStyleVar/PopID because SetTooltip opens its own window and wants the
        // ID stack to still be this widget's.
        //
        // Skipped while dragging: the value is moving under the cursor and a popup there
        // is noise. `active` already covers both drag and click.
        if (tooltip && tooltip[0] != '\0' && hovered && !active)
            {
                push_tooltip_padding();
                ImGui::SetTooltip("%s", tooltip);
                pop_tooltip_padding();
            }
        ImGui::Dummy(ImVec2(0, 4.f * sf));
        if (disabled) ImGui::PopStyleVar();
        ImGui::PopID();
        return active || edited;
    }
    bool select(const std::string& label, int* v, const std::vector<const char*>& options,
        const bool disabled, const bool translate_options,
        const bool label_above) {
        const float sf = menu::get_scale_factor();
        ImGui::PushID(label.c_str());
        const std::string raw_label = label_text(label);
        const std::string combo_label = label.find("##") != std::string::npos
            ? raw_label
            : i18n::tr(raw_label);
        ImGui::AlignTextToFramePadding();
        ImGui::TextColored(disabled ? menu::with_alpha(menu::palette::muted, 0.7f) : menu::palette::txt,
            "%s", combo_label.c_str());
        if (label_above)
        {
            // Quest names are often long.  A full-width picker beneath the
            // label prevents the label and dropdown arrow from overlapping.
            ImGui::Dummy(ImVec2(0, 2.f * sf));
            ImGui::SetNextItemWidth(-1.f);
        }
        else
        {
            const float w = (std::min)(230.f * sf, ImGui::GetContentRegionAvail().x * 0.62f);
            right_align(w);
        }
        if (disabled) ImGui::BeginDisabled();
        bool r = false;
        if (!translate_options)
        {
            r = ImGui::Combo("##c", v, options.data(), static_cast<int32_t>(options.size()));
        }
        else
        {
            struct combo_option_cache
            {
                std::vector<std::string> strings;
                std::vector<const char*> ptrs;
            };
            static thread_local std::unordered_map<uint32_t, combo_option_cache> caches;
            const uint32_t combo_id = ImGui::GetID("##c");
            combo_option_cache& cache = caches[combo_id];
            cache.strings.clear();
            cache.ptrs.clear();
            cache.strings.reserve(options.size());
            cache.ptrs.reserve(options.size());
            for (const char* option : options)
            {
                if (!option)
                    cache.strings.emplace_back();
                else
                    cache.strings.push_back(i18n::tr(option));
                cache.ptrs.push_back(cache.strings.back().c_str());
            }
            r = ImGui::Combo("##c", v, cache.ptrs.data(), static_cast<int32_t>(cache.ptrs.size()));
        }
        if (disabled) ImGui::EndDisabled();
        ImGui::Dummy(ImVec2(0, 3.f * sf));
        ImGui::PopID();
        return r;
    }
    bool colorpicker(const std::string& label, ImVec4* v, const bool disabled) {
        const float sf = menu::get_scale_factor();
        ImGui::PushID(label.c_str());
        if (disabled) push_disabled_dim();
        ImGui::AlignTextToFramePadding();
        ImGui::TextColored(disabled ? menu::with_alpha(menu::palette::muted, 0.7f) : menu::palette::txt,
            "%s", label_text(label).c_str());
        const float sw = 40.f * sf;
        ImGui::SameLine(ImGui::GetWindowWidth() - sw - 26.f * sf);
        ImGui::SetNextItemWidth(sw);
        if (disabled) ImGui::BeginDisabled();
        const bool r = ImGui::ColorEdit4("##col", reinterpret_cast<float*>(v),
            ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaPreviewHalf | ImGuiColorEditFlags_PickerHueWheel);
        if (disabled) ImGui::EndDisabled();
        ImGui::Dummy(ImVec2(0, 3.f * sf));
        if (disabled) ImGui::PopStyleVar();
        ImGui::PopID();
        return r;
    }
    bool int_textbot(const std::string& label, int* v) {
        const float sf = menu::get_scale_factor();
        ImGui::PushID(label.c_str());
        ImGui::AlignTextToFramePadding();
        ImGui::TextColored(menu::palette::txt, "%s", label_text(label).c_str());
        const float w = (std::min)(150.f * sf, ImGui::GetContentRegionAvail().x * 0.5f);
        right_align(w);
        const bool r = ImGui::InputInt("##i", v);
        ImGui::Dummy(ImVec2(0, 3.f * sf));
        ImGui::PopID();
        return r;
    }
    bool textbox(const std::string& label, std::string* v) {
        const float sf = menu::get_scale_factor();
        ImGui::PushID(label.c_str());
        ImGui::AlignTextToFramePadding();
        ImGui::TextColored(menu::palette::txt, "%s", label_text(label).c_str());
        const float w = (std::min)(230.f * sf, ImGui::GetContentRegionAvail().x * 0.62f);
        right_align(w);
        const bool r = ImGui::InputText("##t", v);
        ImGui::Dummy(ImVec2(0, 3.f * sf));
        ImGui::PopID();
        return r;
    }
    bool compact_textbox(const std::string& label, std::string* v, const size_t max_chars,
        const bool disabled) {
        const float sf = menu::get_scale_factor();
        ImGui::PushID(label.c_str());
        ImGui::AlignTextToFramePadding();
        ImGui::TextColored(disabled ? menu::with_alpha(menu::palette::muted, 0.7f) : menu::palette::txt,
            "%s", i18n::tr(label_text(label)).c_str());
        const float w = (8.f * static_cast<float>(max_chars) + 14.f) * sf;
        right_align(w);
        if (disabled)
            ImGui::BeginDisabled();
        ImGui::SetNextItemWidth(w);
        bool changed = ImGui::InputText("##t", v);
        if (v->size() > max_chars)
            v->resize(max_chars);
        if (disabled)
            ImGui::EndDisabled();
        ImGui::Dummy(ImVec2(0, 3.f * sf));
        ImGui::PopID();
        return changed;
    }
} // namespace imgui_addons
