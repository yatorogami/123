#pragma once

#include <algorithm>
#include <cstddef>
#include <string>
#include <utility>
#include <vector>

// WHICH KEYBINDS COLLIDE, and which one collides with the menu itself.
//
// hotkeys::all() is one flat registry: every module pushes its bindings in
// and nothing ever compares them. Two features can end up on one key and
// nothing says so -- pressing the key fires both, in registration order,
// and the user has no way to see why. That is a silent failure of exactly
// the kind this project keeps paying for, and it is pure bookkeeping: no
// ImGui, no game, no Win32, so it lives here and tools/harness tests it
// (test_hotkey_conflicts.cpp) rather than trusting the panel to be right.
//
// This is a REPORT, not a gate. It does not unbind anything and it does
// not block a rebind; it tells the user what their configuration does.

namespace hotkey_conflicts {

    // The menu toggle, spelled as a literal rather than VK_INSERT.
    //
    // Why a literal: including <Windows.h> for one constant would make this
    // header un-portable, and tools/harness deliberately compiles what it
    // tests on any C++23 compiler. hotkeys.h -- which does have windows.h on
    // a render path that only ever builds on Windows -- static_asserts that
    // this equals VK_INSERT, so the two can never drift apart silently.
    constexpr int k_menu_toggle_key = 0x2D; // == VK_INSERT

    // One binding, reduced to the three things the report needs. Keeping it
    // structural rather than taking hotkeys::binding& is what keeps this
    // header free of the hotkeys registry (and therefore of imgui.h, which
    // hotkeys.h pulls in through menu.h).
    struct row {
        int key = 0;
        const char* label = "";
        const char* id = "";
    };

    struct group {
        int key = 0;
        // True when the key is the menu toggle itself. A single binding is
        // enough to make that a conflict: INSERT is read directly by
        // menu::draw() through GetAsyncKeyState, outside the binding system,
        // so a binding here is a row that can never fire on its own terms.
        bool reserved = false;
        // Labels in input order, so the report reads like the panel it sits
        // above rather than in an order of its own invention.
        std::vector<const char*> labels;
    };

    // Group rows by key and keep the keys two or more actions use, plus any
    // row sitting on the reserved menu-toggle key.
    //
    // key == 0 means "unbound" and NEVER conflicts. Two unbound rows are two
    // rows that do nothing, which is not news; treating them as a collision
    // would make the default configuration (most bindings unbound) open
    // with a page of conflicts and teach the user to ignore the block.
    inline std::vector<group> find(const std::vector<row>& rows, const int reserved_key = k_menu_toggle_key) {
        // First-seen order, so grouping is deterministic, then one sort by
        // key at the end so the printed report is stable and scannable.
        std::vector<std::pair<int, group>> acc;
        for (const row& r : rows) {
            if (r.key == 0) continue;
            auto it = acc.end();
            for (auto cand = acc.begin(); cand != acc.end(); ++cand) {
                if (cand->first == r.key) { it = cand; break; }
            }
            if (it == acc.end())
                acc.push_back({r.key, group{r.key, r.key == reserved_key, {r.label}}});
            else {
                it->second.labels.push_back(r.label);
                if (r.key == reserved_key) it->second.reserved = true;
            }
        }

        std::vector<group> out;
        for (auto& kv : acc) {
            if (kv.second.labels.size() >= 2 || kv.second.reserved)
                out.push_back(std::move(kv.second));
        }
        std::sort(out.begin(), out.end(),
            [](const group& a, const group& b) { return a.key < b.key; });
        return out;
    }

} // namespace hotkey_conflicts
