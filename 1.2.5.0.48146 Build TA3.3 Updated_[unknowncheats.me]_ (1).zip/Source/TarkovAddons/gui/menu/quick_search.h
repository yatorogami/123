#pragma once

#include <algorithm>
#include <cstddef>
#include <string>
#include <vector>

#include "../../module/ModuleCategory.h"
#include "../../util/text_fold.h"

// THE FUZZY RANKING behind the menu's quick-jump search (Ctrl+K).
//
// Why this is its own header, and not a lambda inside menu.cpp
// ------------------------------------------------------------
// menu.cpp needs ImGui, resources.h and the DX hook, so a test could only
// ever exercise a COPY of the ranking -- and a copy is a copy that drifts
// from the ranking that ships. Everything with a decision in it is here,
// with no ImGui, no IL2CPP and no Win32, so tools/harness compiles the real
// thing (test_quick_search.cpp). This is the same split that produced
// card_fold_state.h and column_layout.h.
//
// What "match" means here
// -----------------------
// Subsequence matching, like every command palette: "aimfov" matches
// "Aimbot FOV". A plain substring test would reject that, and the menu has
// 31 cards and several hundred values, so exact typing is not realistic.
// Scoring exists to put the RIGHT answer first, which is the whole feature:
// a palette that finds the right row fourth is a palette nobody uses twice.
//
// Folding is text_fold::fold, the same UTF-8 case fold the item search uses
// (util/text_fold.h). std::tolower is ASCII-only in this project -- nothing
// calls setlocale -- so a Russian player typing "эсп" against "ЭСП" would
// match nothing, which is the exact defect that header was written for.

namespace quick_search {

    // One searchable thing: a card, a value inside a card, or a hotkey.
    struct entry {
        ModuleCategory tab = RaidDashboard;
        // The nav rail's label for the tab, translated. Copied per entry
        // rather than looked up, so ranking stays a pure function of its
        // arguments and the test does not need the nav table.
        std::string tab_label;
        // The card's stable id: the module name, or "hotkeys" for the key
        // panel. card_fold::set() takes this, which is what unfolds it.
        std::string card;
        // The card title, the value's own label, or the hotkey's label.
        std::string label;
        // True for the card itself. Card entries are what a value entry
        // collapses onto when Enter is pressed.
        bool is_card = false;
    };

    struct match {
        std::size_t index = 0;
        int score = 0;
    };

    // Scoring constants, named so the negative controls in the test can say
    // which rule they broke rather than "the score went down".
    constexpr int k_substring_base = 1000; // beats any subsequence, always
    constexpr int k_char_score = 8;        // per matched needle character
    constexpr int k_consecutive_bonus = 10;// per run without a gap
    constexpr int k_boundary_bonus = 12;   // match starts a word
    constexpr int k_prefix_bonus = 40;     // haystack starts with the needle
    constexpr int k_label_bonus = 60;      // the match landed in the label,
                                           // not in the card/tab text beside it
    constexpr int k_max_gap_penalty = 30;  // a long gap cannot go negative

    inline bool is_boundary_char(const char c) {
        switch (c) {
        case ' ': case '_': case '-': case '/': case ':':
        case '.': case '(': case '[': case '>': case '&': case ',':
        case '#':
            return true;
        default:
            return false;
        }
    }

    // Score one FOLDED needle against one FOLDED haystack. Returns -1 when
    // the needle is not a subsequence of the haystack -- the caller treats
    // that as "no match", never as a zero.
    //
    // The comparison is byte-wise on already-folded UTF-8, which is sound:
    // fold() maps whole code points to whole code points, so a needle's
    // multi-byte sequence can only match the identical sequence in the
    // haystack, and a continuation byte (0x80-0xBF) can never equal a lead
    // byte. There is nothing to align.
    inline int score_folded(const std::string& needle, const std::string& hay) {
        if (needle.empty() || hay.empty()) return -1;

        // Substring first: cheaper, and the answer everyone expects when
        // they type the whole word.
        if (const auto at = hay.find(needle); at != std::string::npos) {
            const int pos = static_cast<int>(at);
            return k_substring_base - 2 * pos - static_cast<int>(hay.size() - needle.size());
        }

        std::size_t ni = 0;
        int score = 0;
        int gap_penalty = 0;
        bool prev_matched = false;
        for (std::size_t i = 0; i < hay.size() && ni < needle.size(); ++i) {
            if (hay[i] != needle[ni]) {
                // Only penalise gaps BETWEEN matched characters. Leading
                // noise (a match deep in a long card title) is already
                // priced by the substring branch's position term and would
                // otherwise double-count here.
                if (prev_matched && gap_penalty < k_max_gap_penalty) {
                    --score;
                    ++gap_penalty;
                }
                continue;
            }
            score += k_char_score;
            if (prev_matched) score += k_consecutive_bonus;
            if (i == 0 || is_boundary_char(hay[i - 1])) score += k_boundary_bonus;
            if (i == 0) score += k_prefix_bonus;
            prev_matched = true;
            ++ni;
        }
        if (ni < needle.size()) return -1;
        return score > 0 ? score : 1;
    }

    // Every needle must match the same haystack. Terms come from splitting
    // the query on whitespace, so "esp loot" is two requirements, not one
    // fuzzy string -- the failure mode this prevents is a query like
    // "god noclip" matching "God Mode" alone and burying the row the user
    // meant under everything else "god" touches.
    inline int score_all_terms(const std::vector<std::string>& terms_folded,
                               const std::string& hay_folded,
                               const std::string& label_folded) {
        if (terms_folded.empty() || hay_folded.empty()) return -1;
        int total = 0;
        for (const std::string& term : terms_folded) {
            const int s = score_folded(term, hay_folded);
            if (s < 0) return -1;
            total += s;
        }
        // The first term deciding the entry from its own label is what
        // stops a card name from flooding: querying "esp" matches every
        // ESP-card row through the card text appended to its haystack, and
        // without this those all outrank the ESP card itself.
        if (score_folded(terms_folded[0], label_folded) >= 0)
            total += k_label_bonus;
        return total;
    }

    // Rank a raw query over the index. Returns matches best-first, capped.
    //
    // The order is deterministic: equal scores keep index order
    // (stable_sort), and the index is built in draw order, so the same
    // query always produces the same list. A palette whose rows reshuffle
    // between keystrokes is worse than no ranking at all.
    inline std::vector<match> rank(const std::string& query, const std::vector<entry>& index,
                                   const std::size_t max_results = 12) {
        std::vector<std::string> terms;
        std::size_t start = 0;
        while (start <= query.size()) {
            const std::size_t sp = query.find(' ', start);
            const std::string token = sp == std::string::npos
                ? query.substr(start)
                : query.substr(start, sp - start);
            if (!token.empty()) terms.push_back(text_fold::folded(token));
            if (sp == std::string::npos) break;
            start = sp + 1;
        }
        if (terms.empty() || index.empty()) return {};

        std::vector<match> out;
        out.reserve(index.size());
        for (std::size_t i = 0; i < index.size(); ++i) {
            const entry& e = index[i];
            std::string label_folded;
            text_fold::fold(e.label, label_folded);
            std::string hay = label_folded;
            hay.push_back(' ');
            text_fold::fold(e.card, hay);
            hay.push_back(' ');
            text_fold::fold(e.tab_label, hay);

            const int score = score_all_terms(terms, hay, label_folded);
            if (score < 0) continue;
            out.push_back({i, score});
        }

        std::stable_sort(out.begin(), out.end(),
            [](const match& a, const match& b) { return a.score > b.score; });

        if (out.size() > max_results) out.resize(max_results);
        return out;
    }

} // namespace quick_search
