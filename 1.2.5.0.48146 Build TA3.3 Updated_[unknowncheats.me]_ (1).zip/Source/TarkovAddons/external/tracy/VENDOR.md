# Tracy — vendored

Upstream: <https://github.com/wolfpld/tracy>
Vendored: **v0.14.1**, commit `30997d5ca6bb632cc10807a1da8a6d3de0aeeb3c`
Source subdirectory copied: upstream `public/` → here (88 files, ~1.8 MB)

Only the embedded *client library* half is vendored — `TracyClient.cpp` plus the
`common/`, `client/`, `tracy/`, and `libbacktrace/` trees it includes. The Qt
front-end is NOT vendored; grab a prebuilt client from the upstream releases
(`windows-<version>.zip`) rather than building it.

Upstream ships the whole repo as a submodule-friendly tree, but this project
vendors its externals by copy (see `external/imgui`, `external/safetyhook`), so
this directory follows the same convention and is committed to git.

## Integration

Compiled via a single translation unit, `TracyClient.cpp`, added to
`TarkovAddons.vcxproj`. On MSVC that file `#pragma comment(lib, ...)` its own
dependencies, so no extra link libraries are needed.

Defined on all four x64 configurations of `TarkovAddons.vcxproj` as of
2026-10-10 -- `Debug|x64` and `Release|x64` from the start, `Prod|x64` and
`Prod no aimbot|x64` since 2026-10-10 (they were dropped 2026-10-08 and restored
on request; the vcxproj comment carries the history) -- via:

| Define | Why |
|---|---|
| `TRACY_ENABLE` | compiles the profiler in at all |
| `TRACY_MANUAL_LIFETIME` | implies `TRACY_DELAYED_INIT`; exposes `StartupProfiler()` so nothing starts until asked |
| `TRACY_ONLY_LOCALHOST` | binds 127.0.0.1 — the server is not reachable off-box |
| `TRACY_NO_BROADCAST` | no UDP broadcast for client discovery |
| `TRACY_CALLSTACK=0` | callstack capture stays off; a nonzero depth crashed the game (tracy_bridge.h) |

So a shipping build carries the profiler, deliberately: the point is profiling
the SHIPPING configuration (rationale in the vcxproj comment). The check is the
artefact, not this file: scan the Prod DLL for `Start Profiler`. Where the
define is absent, `TracyClient.cpp` preprocesses to an empty TU and
`util/tracy_bridge.h` compiles to no-ops.

`util/tracy_bridge.{h,cpp}` is the project-side wrapper. Use it rather than
including `tracy/Tracy.hpp` directly: it is the only place that knows about the
`TRACY_ENABLE` split, and its guarded include is what confines the header to
configs that actually define it.

## Local patch

`client/windows/TracyETW.cpp`, in `ETWError()`: one `static constexpr` changed to
`static const`.

MSVC under `/ZI` (Edit and Continue, used by `Debug|*`) rejects
`static constexpr SourceLocationData{ ..., __FUNCTION__, ..., __LINE__, ... }` at
function scope with `C2131: expression is not constant`. Reproduced in isolation:
compiles clean without `/ZI`, fails with it, independent of `/std:` level.
`const` is equivalent for a literal aggregate of pointers and ints.

Upstream `master` is one commit ahead of v0.14.1 and does **not** contain a fix.
Re-check on the next upgrade; delete the patch if it compiles clean.

## Upgrade procedure

```powershell
git clone --depth 1 --branch v0.14.1 https://github.com/wolfpld/tracy $env:TEMP\t
Remove-Item -Recurse -Force TarkovAddons\external\tracy
Copy-Item -Recurse "$env:TEMP\t\public\*" TarkovAddons\external\tracy
```

Then re-apply the `TracyETW.cpp` patch if still needed, and bump the commit hash
above. `TracyVersion.hpp` in `common/` records the version.
