#pragma once
// Shared linear algebra built on unity.h vector types. unity.h provides the
// game-memory layouts (vector2/3/4) and now const-correct member +-/*; this
// header adds what it lacks: cross products, a column-major mat4 with proper
// algebra, TRS composition and 2D polygon/segment clipping. Consumers:
// optics_lens_pipeline.h, optics_projection.h (and anything else that needs it).
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>

#include "../il2cpp/unity.h"

namespace linalg {
    using v2 = unity::vector2;
    using v3 = unity::vector3;
    using v4 = unity::vector4;

    // unity::vector4 has no operators; access by index is handy for matrix rows.
    inline float vcomp(const v4& v, int i) {
        return i == 0 ? v.x : i == 1 ? v.y
            : i == 2                 ? v.z
                                     : v.w;
    }
    inline bool all_finite3(const v3& v) {
        return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z);
    }
    inline bool all_finite4(const v4& v) {
        return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z) && std::isfinite(v.w);
    }

    inline float dot3(const v3& a, const v3& b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
    inline float len2_3(const v3& a) { return dot3(a, a); }
    inline v3 cross3(const v3& a, const v3& b) {
        return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
    }
    inline float cross2(const v2& a, const v2& b) { return a.x * b.y - a.y * b.x; }

    // ---- double-precision 2D/3D geometry -------------------------------------
    //
    // Required by optics_lens_pipeline.h section 5, and specifically so that a
    // clipped polygon vertex is never narrowed to float32.
    //
    // The reason is not that the barycentric arithmetic is inaccurate -- it is
    // that the INPUT is. A clip vertex is computed to lie exactly on the image
    // square's boundary; storing it as float32 puts it up to 0.5 ULP away from
    // that boundary (~3e-8 at UV magnitude 0.55). The barycentric inside-test
    // then divides that UV error by the triangle area, amplifying it by 1/|d|.
    // At the |d|=5.778e-02 observed on 2026-09-26 that is already ~5e-7, i.e.
    // past the spec's -1e-7 tolerance before a single barycentric operation has
    // contributed any error of its own.
    //
    // Widening the mesh's float32 UVs and positions to these types is lossless
    // (float32 -> double is exact), so this buys precision only for our own
    // arithmetic and cannot introduce disagreement with the game's data.
    struct vd2
    {
        double x = 0, y = 0;
    };
    struct vd3
    {
        double x = 0, y = 0, z = 0;
    };

    inline vd2 operator-(const vd2& a, const vd2& b) { return {a.x - b.x, a.y - b.y}; }
    inline vd2 operator+(const vd2& a, const vd2& b) { return {a.x + b.x, a.y + b.y}; }
    inline vd2 operator*(const vd2& a, double s) { return {a.x * s, a.y * s}; }
    inline vd3 operator-(const vd3& a, const vd3& b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
    inline vd3 operator+(const vd3& a, const vd3& b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
    inline vd3 operator*(const vd3& a, double s) { return {a.x * s, a.y * s, a.z * s}; }
    inline double cross2(const vd2& a, const vd2& b) { return a.x * b.y - a.y * b.x; }
    inline vd3 cross3(const vd3& a, const vd3& b) {
        return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
    }

    // Column-major 4x4: m[col * 4 + row]. clip = M * v (column vectors).
    struct mat4
    {
        float m[16];
        mat4();
        float* col(int c);
        const float* col(int c) const;
        float at(int r, int c) const;
        void set_row(int r, const float v[4]);
    };

    inline mat4 mat_mul(const mat4& a, const mat4& b) {
        mat4 r{};
        for (int c = 0; c < 4; ++c)
            for (int i = 0; i < 4; ++i)
            {
                float s = 0.f;
                for (int k = 0; k < 4; ++k) s += a.at(i, k) * b.at(k, c);
                r.m[c * 4 + i] = s;
            }
        return r;
    }

    inline v4 mat_mul_v(const mat4& a, const v4& v) {
        v4 r{};
        r.x = a.at(0, 0) * v.x + a.at(0, 1) * v.y + a.at(0, 2) * v.z + a.at(0, 3) * v.w;
        r.y = a.at(1, 0) * v.x + a.at(1, 1) * v.y + a.at(1, 2) * v.z + a.at(1, 3) * v.w;
        r.z = a.at(2, 0) * v.x + a.at(2, 1) * v.y + a.at(2, 2) * v.z + a.at(2, 3) * v.w;
        r.w = a.at(3, 0) * v.x + a.at(3, 1) * v.y + a.at(3, 2) * v.z + a.at(3, 3) * v.w;
        return r;
    }

    // Unity quaternion (x, y, z, w) -> rotation matrix, then T * R * S.
    inline mat4 trs(const v3& p, const v4& qv, const v3& s) {
        const float x = qv.x, y = qv.y, z = qv.z, w = qv.w;
        mat4 r{};
        r.m[0] = 1.f - 2.f * (y * y + z * z);
        r.m[4] = 2.f * (x * y - w * z);
        r.m[8] = 2.f * (x * z + w * y);
        r.m[1] = 2.f * (x * y + w * z);
        r.m[5] = 1.f - 2.f * (x * x + z * z);
        r.m[9] = 2.f * (y * z - w * x);
        r.m[2] = 2.f * (x * z - w * y);
        r.m[6] = 2.f * (y * z + w * x);
        r.m[10] = 1.f - 2.f * (x * x + y * y);
        for (int c = 0; c < 3; ++c)
        {
            r.col(c)[0] *= s.x;
            r.col(c)[1] *= s.y;
            r.col(c)[2] *= s.z;
        }
        r.m[12] = p.x;
        r.m[13] = p.y;
        r.m[14] = p.z;
        return r;
    }

    // ---- 2D polygon / segment clipping (Sutherland-Hodgman, CCW inside) ----
    inline float poly_signed_area(const std::vector<v2>& poly) {
        float s = 0.f;
        for (size_t i = 0; i < poly.size(); ++i)
            s += cross2(poly[i], poly[(i + 1) % poly.size()]);
        return s * 0.5f;
    }

    inline double poly_signed_area(const std::vector<vd2>& poly) {
        double s = 0.0;
        for (size_t i = 0; i < poly.size(); ++i)
            s += cross2(poly[i], poly[(i + 1) % poly.size()]);
        return s * 0.5;
    }

    inline std::vector<v2> clip_polygon(const std::vector<v2>& subject,
        const std::vector<v2>& boundary) {
        std::vector<v2> output = subject;
        for (size_t e = 0; e < boundary.size() && !output.empty(); ++e)
        {
            const v2 a = boundary[e];
            const v2 b = boundary[(e + 1) % boundary.size()];
            std::vector<v2> input = std::move(output);
            output.clear();
            v2 prev = input.back();
            for (const v2 cur : input)
            {
                const float dp = cross2(b - a, prev - a);
                const float dc = cross2(b - a, cur - a);
                if ((dp >= 0.f) != (dc >= 0.f))
                {
                    const float t = dp / (dp - dc);
                    output.push_back(prev + (cur - prev) * t);
                }
                if (dc >= 0.f) output.push_back(cur);
                prev = cur;
            }
        }
        return output;
    }

    // Double-precision overload. Deliberately a separate overload rather than a
    // template on the element type: the two differ in more than the type, since
    // this one must keep the cross products AND the interpolation parameter in
    // double so that no intermediate is narrowed. See the vd2 note above.
    inline std::vector<vd2> clip_polygon(const std::vector<vd2>& subject,
        const std::vector<vd2>& boundary) {
        std::vector<vd2> output = subject;
        for (size_t e = 0; e < boundary.size() && !output.empty(); ++e)
        {
            const vd2 a = boundary[e];
            const vd2 b = boundary[(e + 1) % boundary.size()];
            std::vector<vd2> input = std::move(output);
            output.clear();
            vd2 prev = input.back();
            for (const vd2 cur : input)
            {
                const double dp = cross2(b - a, prev - a);
                const double dc = cross2(b - a, cur - a);
                if ((dp >= 0.0) != (dc >= 0.0))
                {
                    const double t = dp / (dp - dc);
                    output.push_back(prev + (cur - prev) * t);
                }
                if (dc >= 0.0) output.push_back(cur);
                prev = cur;
            }
        }
        return output;
    }

    // Visible interval [t0, t1] within [0, 1] of segment A->B inside the convex
    // CCW polygon; false when fully outside.
    inline bool clip_segment(const std::vector<v2>& mask, const v2& a, const v2& b,
        float& t0, float& t1) {
        float low = 0.f, high = 1.f;
        const size_t n = mask.size();
        for (size_t i = 0; i < n; ++i)
        {
            const v2 pa = mask[i];
            const v2 pb = mask[(i + 1) % n];
            const v2 edge = pb - pa;
            const float start = cross2(edge, a - pa);
            const float slope = cross2(edge, b - a);
            if (std::fabs(slope) < 1e-12f)
            {
                if (start < 0.f) return false;
                continue;
            }
            const float t = -start / slope;
            if (slope > 0.f)
                low = (std::max<float>)(low, t);
            else
                high = (std::min<float>)(high, t);
            if (low > high) return false;
        }
        t0 = low;
        t1 = high;
        return true;
    }
} // namespace linalg
