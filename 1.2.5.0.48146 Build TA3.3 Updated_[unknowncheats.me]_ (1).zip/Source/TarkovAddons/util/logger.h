#pragma once
#include <string>

// Log levels:
//   DEBUG - diagnostic spam (per-resume state dumps, shape logs, per-call traces).
//           Suppressed unless enabled via set_debug_enabled() - the Debug Log module
//           toggle flips it at runtime.
//   INFO  - normal-operation milestones (raid started, transit patched, raid ended).
//   WARN  - anomalies worth grepping for (diagnostic stage reports, swallowed faults).
//   ERROR - failures.
// Every line is mirrored to <dll dir>\tarkovaddons_log.txt and flushed per line so the
// tail survives a game crash. The console copy is batched rather than flushed per line — the
// file is the durable record, the console is the live view. See write_line() in logger.cpp.
namespace logger {
    void debug(std::string msg);
    void info(std::string msg);
    // One INFO line that NEVER blocks on the log mutex. For DLL_PROCESS_DETACH only.
    //
    // WHY IT NEEDS TO EXIST, which is the whole reason it is not just `info`.
    //
    // write_line() takes g_log_mutex BLOCKING, and DLL_PROCESS_DETACH runs under the loader
    // lock, where every other thread has already been terminated -- including, on a normal
    // quit, the render thread, which spends its life inside Present and is a plausible
    // holder of that mutex. A blocking lock there is a deadlock, and a deadlock inside
    // DllMain is an unrecoverable hang during teardown: the game would refuse to close. So
    // this try_locks, and if the lock is unavailable it writes unserialised rather than not
    // at all.
    //
    // WHAT IT DOES NOT DO, and this is the part the first version of this comment got
    // wrong: it does NOT produce a session end marker, and its absence means nothing. The
    // image is manual-mapped (AGENTS.md), so the OS keeps no loader record of it and
    // DLL_PROCESS_DETACH does not run on process exit -- only on a FreeLibrary, which this
    // deployment never performs. Measured 2026-10-05: eight launches, zero such lines.
    // Read the SESSION BEGIN comment in dllmain.cpp before expecting one.
    void info_at_exit(std::string msg);
    void warn(std::string msg);
    void error(std::string msg);

    // Reserved for the crash reporter (util/crash_probe.h) and nothing else.
    //
    // It exists so a fatal fault is identifiable by the LEVEL rather than by
    // words at the front of the message. The probe used to log at error with
    // "CRASH probe: " prefixed on every line, which rendered as
    // "[... ERROR] CRASH probe: ..." -- the severity stated twice, once in the
    // tag and once in the text, and neither one greppable on its own. A
    // dedicated level gives "CRASH]" as the tag, so
    // `Select-String '\] CRASH\]'` finds every one of them, and a reviewer
    // reading the log can tell a real fault from an error message at a glance.
    //
    // Deliberately NOT gated by the DEBUG toggle, like error(): a crash report
    // that a setting can hide is not a crash report. Console colours are
    // red-on-white so it is the one line that cannot be missed in a wall of
    // INFO, and the file copy is plain text like every other level -- the
    // escape codes go to the console only.
    void crash(std::string msg);

    // Runtime switch for DEBUG lines (Debug Log module toggle). Thread-safe, cheap.
    void set_debug_enabled(bool enabled);
    bool debug_enabled();

    // The console filter (dllmain) redirects STD_OUTPUT_HANDLE to a pipe so it can
    // filter WebSocket trace spam. SetConsoleTextAttribute must therefore target the
    // real console handle captured at console setup instead of GetStdHandle() — the
    // latter now returns the pipe and log colors would silently vanish. Call once
    // from console setup; falls back to GetStdHandle() when never set.
    void set_console_handle(void* handle);
}; // namespace logger
