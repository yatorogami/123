#pragma once
// ============================================================================
//  pe_resource.h  --  read RCDATA out of our own loaded image
// ============================================================================
//
//  Single shared implementation of the walk that used to be copy-pasted into
//  module/minimap.h, gui/menu/menu.cpp and util/i18n.cpp. All three were the
//  same hand-rolled parser of the PE resource directory, and all three were
//  unbounded: OffsetToData/Size and the intermediate OffsetToDirectory values
//  were never checked against the resource section extent, so a malformed or
//  truncated resource yielded an out-of-bounds read.
//
//  Why the manual walk at all, rather than FindResourceW? Because the mod is
//  built to survive being MANUAL-MAPPED. A loader that does not register the
//  module in the PEB loader lists leaves the Win32 resource APIs unable to find
//  our own resources. Walking .rsrc from a VirtualQuery'd AllocationBase works
//  either way. mapped_rcdata() is therefore tried FIRST and the Win32 API is
//  only a fallback for the ordinary LoadLibrary case.
//
//  Validated against an rc.exe-built image: the walk returns byte-identical
//  results to FindResourceW for every payload, and fails safely for an
//  undeclared id and for a resource of the wrong type. See CLEANUP_AUDIT.md.
// ============================================================================

#include <atomic>
#include <cstdarg>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <string>
#include <Windows.h>

namespace pe_resource {

    // Size of the failure-reason buffer. Generous, because the one line that
    // explains a total failure is the only evidence there is, and truncating it
    // to fit would defeat the purpose.
    inline constexpr std::size_t kFailureBufferSize = 1024;

    // Is [p, p+n) readable, best effort?
    //
    // This is not defensive padding: a candidate "image base" derived from
    // VirtualQuery can be the first page of a thread stack, which is a GUARD
    // page. Dereferencing IMAGE_DOS_HEADER there faults, and the caller cannot
    // catch that.
    //
    // The VirtualQuery form is the fast path, but it is NOT the only path, and
    // that is the whole point of the split. This predicate was, until
    // 2026-09-30, the single gate every image-base candidate had to pass --
    // GetModuleHandleExW's HMODULE and VirtualQuery's AllocationBase alike --
    // so a VirtualQuery that returns nothing, or that is intercepted and
    // answers with an empty region, rejected a perfectly valid HMODULE and took
    // the whole reader down with no remaining source. ReadProcessMemory against
    // our own process reports a fault as a return value instead of raising, so
    // it answers the same question without going through VirtualQuery at all.
    //
    // probe_readable only samples the first and last byte, so for a range that
    // genuinely straddles a hole in the middle it can answer optimistically.
    // That is acceptable here because the only caller reads a DOS header and
    // the NT headers immediately after it, which are contiguous in every real
    // image, and because the resource walk bounds-checks every offset against
    // the section extent by pointer arithmetic rather than by probing.
    inline bool probe_readable(const void* p, std::size_t n) {
        unsigned char first = 0;
        SIZE_T got = 0;
        if (!ReadProcessMemory(GetCurrentProcess(), p, &first, 1, &got) || got != 1)
            return false;
        if (n == 1)
            return true;
        unsigned char last = 0;
        const auto* tail = static_cast<const unsigned char*>(p) + (n - 1);
        return ReadProcessMemory(GetCurrentProcess(), tail, &last, 1, &got) && got == 1;
    }

    inline bool is_readable(const void* p, std::size_t n) {
        if (!p || !n) return false;

        MEMORY_BASIC_INFORMATION mbi{};
        if (!VirtualQuery(p, &mbi, sizeof(mbi)))
            return probe_readable(p, n);
        if (mbi.State != MEM_COMMIT)
            return probe_readable(p, n);
        if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD))
            return false;

        const auto start = reinterpret_cast<std::uintptr_t>(p);
        const auto region_end = reinterpret_cast<std::uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;
        // Spanning past the end of this region is legal, so fall back rather
        // than refusing outright.
        return start + n <= region_end ? true : probe_readable(p, n);
    }

    // SizeOfImage if `base` really is a mapped PE image, else 0.
    //
    // Both the "is this a header" question and the "does this image contain
    // that address" question are needed, and they cannot be answered by one
    // boolean: SizeOfImage is what lets the backward scan reject a NEIGHBOUR
    // image's headers that happen to sit above us, which is the failure mode a
    // naive scan has.
    inline std::size_t image_extent_at(const std::byte* base) {
        if (!base) return 0;
        if (!is_readable(base, sizeof(IMAGE_DOS_HEADER))) return 0;

        const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
        if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0) return 0;
        // Keep e_lfanew inside a sane bound before dereferencing through it.
        if (static_cast<std::size_t>(dos->e_lfanew) > 0x10000000u) return 0;
        if (!is_readable(base + dos->e_lfanew, sizeof(IMAGE_NT_HEADERS))) return 0;

        const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
        if (nt->Signature != IMAGE_NT_SIGNATURE) return 0;

        // Everything below is read through IMAGE_NT_HEADERS, which resolves to
        // THIS process's architecture. An image whose optional header is
        // narrower than that is not one this walk can read, and treating it as
        // a candidate would return a base whose SizeOfImage we then trust for
        // containment tests. Say no instead of guessing.
        if (nt->FileHeader.SizeOfOptionalHeader < sizeof(IMAGE_OPTIONAL_HEADER)) return 0;

        const DWORD extent = nt->OptionalHeader.SizeOfImage;
        // Any real image is at least a page and at most a gigabyte. Both bounds
        // reject garbage without needing the optional header magic.
        if (extent < 0x1000u || extent > 0x40000000u) return 0;
        return extent;
    }

    // Cheap structural check that a candidate pointer really is a mapped PE image
    // base, so image_base_from() can reject a source that cannot answer instead
    // of dereferencing something that is not a header.
    inline bool looks_like_pe_image(const std::byte* base) {
        return image_extent_at(base) != 0;
    }

    // Does the image whose base is `base` actually contain `address`?
    inline bool image_contains(const std::byte* base, const void* address) {
        const std::size_t extent = image_extent_at(base);
        if (!extent || !address) return false;
        const auto low = reinterpret_cast<std::uintptr_t>(base);
        const auto probe = reinterpret_cast<std::uintptr_t>(address);
        return probe >= low && (probe - low) < extent;
    }

    // Walk backwards one page at a time from `code_address` looking for the PE
    // header of an image that CONTAINS it. This is the canonical manual-mapper
    // base recovery, and it is here because the two API-based sources share a
    // failure mode: both are ultimately validated through is_readable(), so
    // anything that blinds is_readable -- an intercepted VirtualQuery, a
    // module whose loader entry names a different image, an image split across
    // allocations so AllocationBase is the start of .text -- takes out every
    // source at once. This one asks the memory itself, and needs no API answer
    // beyond the readability probe.
    //
    // The containment test is what makes it safe. Scanning down from an
    // arbitrary code address eventually reaches some OTHER module's base before
    // it reaches ours if ours is unmapped or its headers are unreadable, and
    // accepting that would walk a neighbouring image's resource tree -- a silent
    // wrong answer, which is worse than the failure being fixed. Only a base
    // whose [base, base+SizeOfImage) covers the address is accepted.
    inline const std::byte* scan_back_for_image_base(const void* code_address) {
        if (!code_address) return nullptr;

        SYSTEM_INFO info{};
        GetSystemInfo(&info);
        const auto page_size = info.dwPageSize ? info.dwPageSize : 0x1000u;
        if (page_size > 0x10000000u) return nullptr;

        auto probe = reinterpret_cast<std::uintptr_t>(code_address)
            & ~static_cast<std::uintptr_t>(page_size - 1);

        // Same 64 MiB sanity cap crash_probe uses for its forward walk; no
        // shipped image comes close, and it bounds the worst case.
        constexpr std::uintptr_t kMaxScanBytes = 64ull << 20;
        const std::uintptr_t floor_address = probe > kMaxScanBytes ? probe - kMaxScanBytes : 0;

        while (probe > floor_address) {
            const auto* candidate = reinterpret_cast<const std::byte*>(probe);
            if (image_contains(candidate, code_address))
                return candidate;
            probe -= page_size;
        }
        return nullptr;
    }

    // The loader's own HMODULE for whatever image contains `code_address`, or
    // nullptr. Deliberately INDEPENDENT of image_base_from(): that one additionally
    // demands the candidate pass looks_like_pe_image(), so when it fails -- a split
    // manual map, where AllocationBase is the start of .text rather than of the
    // image -- reusing its answer here meant the "fallback" re-derived the same
    // failure and both paths died together. GetModuleHandleExW answers a different
    // question (is this address inside a registered module?) and can succeed where
    // the base probe cannot, so the two are now genuinely independent. When it
    // returns a non-null HMODULE, FindResourceW gets a real handle instead of a
    // guessed base.
    //
    // Declared here rather than next to find_rcdata() because mapped_rcdata()
    // consults it when reporting why it could not find an image base.
    inline HMODULE hmodule_from_address(const void* code_address) {
        HMODULE m = nullptr;
        if (code_address
            && GetModuleHandleExW(
                GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                reinterpret_cast<LPCWSTR>(code_address), &m)
            && m)
            return m;
        return nullptr;
    }

    // ------------------------------------------------------------------------
    //  THE CAPTURED BASE
    //
    //  Everything above is a *query*, and a query can stop answering. On
    //  2026-09-30 19:30 this reader worked: i18n read all 19 locale payloads
    //  from this image, and crash_probe reported the image at a base whose
    //  SizeOfImage covered it. Three and a half minutes later, on a different
    //  thread, the minimap's 22 payloads were all missing, and the diagnostic
    //  said all three query sources had failed at once:
    //
    //    GetModuleHandleExW(FROM_ADDRESS) -> a handle that is NOT a PE header
    //    VirtualQuery().AllocationBase    -> NOT a PE image header
    //    backward page scan               -> no header whose SizeOfImage covers it
    //
    //  All three validate through looks_like_pe_image(), so all three dying
    //  together says one thing: image_extent_at(base) had started returning 0
    //  for our own, still-running, still-mapped image. The code address was
    //  base+0x1057A0 -- squarely inside .text -- and the backward scan passed
    //  the base page on its way down and did not accept it either.
    //
    //  So the fix is not a better query. It is to not need a query. The image
    //  base is a constant for the lifetime of the module, and the loader HANDS
    //  it to us: DllMain's hModule IS the base, at the one moment it is
    //  guaranteed to be readable. Capture it there, validate it once while it
    //  still can be, and serve it from memory afterwards. Nothing that happens
    //  later can invalidate it, because serving it reads no headers at all.
    //
    //  module_paths::init() already does exactly this for the DLL's on-disk
    //  path, with the reason written down: loaders hide the module from the
    //  process' module lists "right after LoadLibrary returns". This is the same
    //  hazard, reached later in time.
    // ------------------------------------------------------------------------

    inline std::atomic<const std::byte*>& captured_base_slot() {
        static std::atomic<const std::byte*> slot{ nullptr };
        return slot;
    }

    inline std::atomic<std::size_t>& captured_extent_slot() {
        static std::atomic<std::size_t> slot{ 0 };
        return slot;
    }

    // Record `module_base` (normally DllMain's hModule) as this module's image
    // base, if the headers can be read right now. Idempotent: the first
    // successful capture wins, so a later bad call cannot replace a good one.
    //
    // A failed capture is NOT an error. It just leaves the cache empty and the
    // query sources to answer as best they can, which is the previous
    // behaviour and is strictly better than caching something unvalidated.
    inline void remember_image_base(const void* module_base) {
        if (!module_base) return;
        if (captured_base_slot().load(std::memory_order_acquire)) return;

        const auto* base = static_cast<const std::byte*>(module_base);
        const std::size_t extent = image_extent_at(base);
        if (!extent) return;

        // Extent before base, both release: a reader that acquires a non-null
        // base is then guaranteed to see the extent it was paired with.
        captured_extent_slot().store(extent, std::memory_order_release);
        captured_base_slot().store(base, std::memory_order_release);
    }

    // The captured base, if it is an image that contains `code_address`.
    //
    // Containment only -- deliberately no header read. That is the whole point:
    // the header read is the thing that stopped working, so this path must not
    // perform one.
    inline const std::byte* captured_image_base_for(const void* code_address) {
        const std::byte* base = captured_base_slot().load(std::memory_order_acquire);
        if (!base || !code_address) return nullptr;
        const std::size_t extent = captured_extent_slot().load(std::memory_order_acquire);
        if (!extent) return nullptr;

        const auto low = reinterpret_cast<std::uintptr_t>(base);
        const auto probe = reinterpret_cast<std::uintptr_t>(code_address);
        return (probe >= low && (probe - low) < extent) ? base : nullptr;
    }

    // The image base of the module that contains `code_address`, or nullptr.
    //
    // Four ways to get it, and all four are needed:
    //
    //  0. The base captured at DLL_PROCESS_ATTACH. Not a query, so it cannot be
    //     blinded -- see the block comment above. This is the one that works.
    //  1. GetModuleHandleExW(FROM_ADDRESS) -- the authoritative answer, and the
    //     only one that works when the loader mapped the image as several
    //     separate allocations. gui/menu/menu.cpp already relies on this, for
    //     the same reason: some loaders hand DllMain the HOST module, so
    //     FindResource would otherwise search the game executable.
    //  2. VirtualQuery().AllocationBase -- works when the module is not in the
    //     PEB loader lists at all, i.e. a fully manual map with the LDR entry
    //     unlinked. Falls over if the image was split across allocations,
    //     because then AllocationBase is the start of .text, not of the image.
    //  3. scan_back_for_image_base() -- needs no loader list and no AllocationBase
    //     to be meaningful, so it still answers when 1 and 2 have been blinded.
    //     Without it the reader had exactly one gate that both of the others
    //     share, which is what turned a single denial into 22/22 payloads lost.
    //
    // Each candidate is validated by its PE headers before being accepted, so a
    // source that cannot answer is skipped rather than trusted.
    inline const std::byte* image_base_from(const void* code_address) {
        if (!code_address) return nullptr;

        if (const std::byte* captured = captured_image_base_for(code_address))
            return captured;

        if (const auto* from_loader = reinterpret_cast<const std::byte*>(
                hmodule_from_address(code_address)))
            if (looks_like_pe_image(from_loader))
                return from_loader;

        MEMORY_BASIC_INFORMATION memory{};
        if (VirtualQuery(code_address, &memory, sizeof(memory)) && memory.AllocationBase) {
            const auto* base = static_cast<const std::byte*>(memory.AllocationBase);
            if (looks_like_pe_image(base)) return base;
        }

        return scan_back_for_image_base(code_address);
    }

    // Why the last mapped_rcdata() lookup failed.
    //
    // Added 2026-09-30. The 22/22 "RCDATA payloads missing" report named two
    // possible causes and neither was the real one: the payloads WERE in the binary (a
    // structural walk of the shipped DLL finds ids 1200-1221 and 1300-1318 complete,
    // with sane sizes), and the loader was not discarding .rsrc (the mapped extent
    // 0x96A000 includes the 0x57A000-0x964630 resource section). Replicating this
    // reader's own checks against the file passes for every payload, so the algorithm
    // was not at fault either -- which left image_base_from(), upstream of all of it,
    // as the only remaining candidate, and 22 identical warnings said nothing about it.
    //
    // One overwritten-on-failure reason, in thread-local storage, formatted into
    // a buffer rather than pointed at by a string literal.
    //
    // thread_local, which it was NOT until 2026-09-30. The minimap runs this
    // reader 22 times on the render thread while util/i18n.cpp and
    // gui/menu/menu.cpp call it from others, and the reason is written by the
    // failing lookup and read once afterwards. With one shared pointer another
    // thread could overwrite it in between, so the line that explains a total
    // failure could describe a different lookup entirely. The old comment
    // called that a benign race on a diagnostic string; it is only benign
    // while the diagnostic is not the sole evidence of a 22/22 failure, which
    // is exactly what it turned out to be here.
    inline char* failure_buffer() {
        static thread_local char reason[kFailureBufferSize] = "no lookup attempted";
        return reason;
    }

    inline const char* last_failure() {
        return failure_buffer();
    }

    inline void set_failure(const char* format, ...) {
        va_list args;
        va_start(args, format);
        std::vsnprintf(failure_buffer(), kFailureBufferSize, format, args);
        va_end(args);
    }

    // Locate `resource_id` of type RT_RCDATA inside the image that contains
    // `code_address` (any address inside our own module is fine -- the
    // AllocationBase of the VirtualQuery result is the image base).
    //
    // Returns a pointer into the loaded image, or nullptr. `out_size` is always
    // set: 0 on failure. The returned memory is owned by the loader and stays
    // valid for the lifetime of the module, so callers may read it directly.
    inline const std::byte* mapped_rcdata(const void* code_address, WORD resource_id, DWORD& out_size) {
        out_size = 0;
        set_failure("unknown");

        const std::byte* base = image_base_from(code_address);
        if (!base) {
            // Report FACTS, not conclusions about them. The previous wording
            // inferred "not a PE image header" from a failed validation and left
            // out WHY validation failed, which is the only interesting part --
            // an unreadable page, a wrong magic, a bad SizeOfImage and a
            // hijacked answer all read identically. So this prints the raw
            // VirtualQuery fields for the address and for the allocation base,
            // the magic at each candidate, and whether the init-time capture is
            // populated. One run of this is enough to tell those apart.
            const auto address = static_cast<unsigned long long>(
                reinterpret_cast<std::uintptr_t>(code_address));
            const auto* from_loader = reinterpret_cast<const std::byte*>(
                hmodule_from_address(code_address));
            const auto* allocation = reinterpret_cast<const std::byte*>(
                [code_address] () -> void* {
                    MEMORY_BASIC_INFORMATION memory{};
                    if (VirtualQuery(code_address, &memory, sizeof(memory)))
                        return memory.AllocationBase;
                    return nullptr;
                }());

            MEMORY_BASIC_INFORMATION here{};
            const bool have_here = VirtualQuery(code_address, &here, sizeof(here)) != 0;
            MEMORY_BASIC_INFORMATION there{};
            const bool have_there = allocation
                && VirtualQuery(allocation, &there, sizeof(there)) != 0;

            // The first WORD at a candidate, but ONLY if it is readable. This
            // is a diagnostic, and a diagnostic that faults is worse than none.
            auto magic_at = [](const std::byte* p) -> const char* {
                if (!p || !is_readable(p, 2)) return "unreadable";
                const WORD magic = *reinterpret_cast<const WORD*>(p);
                return magic == IMAGE_DOS_SIGNATURE ? "MZ" : "not-MZ";
            };

            set_failure(
                "no PE image base for 0x%llX. "
                "captured-at-init: %s%s. "
                "GetModuleHandleExW -> %p (%s, extent %llu). "
                "VirtualQuery(code) type=%08lX state=%08lX protect=%08lX "
                "alloc=%p region=%p+0x%llX. "
                "VirtualQuery(alloc) type=%08lX state=%08lX protect=%08lX region=%p+0x%llX. "
                "backward-scan: no header covers the address.",
                address,
                captured_base_slot().load(std::memory_order_acquire) ? "captured" : "NOT captured",
                captured_image_base_for(code_address) ? ", contains this address" : ", does not contain it",
                static_cast<const void*>(from_loader),
                from_loader ? magic_at(from_loader) : "no handle",
                static_cast<unsigned long long>(from_loader ? image_extent_at(from_loader) : 0),
                static_cast<unsigned long long>(have_here ? here.Type : 0),
                static_cast<unsigned long long>(have_here ? here.State : 0),
                static_cast<unsigned long long>(have_here ? here.Protect : 0),
                static_cast<const void*>(allocation),
                static_cast<const void*>(have_here ? here.BaseAddress : nullptr),
                static_cast<unsigned long long>(have_here ? here.RegionSize : 0),
                static_cast<unsigned long long>(have_there ? there.Type : 0),
                static_cast<unsigned long long>(have_there ? there.State : 0),
                static_cast<unsigned long long>(have_there ? there.Protect : 0),
                static_cast<const void*>(have_there ? there.BaseAddress : nullptr),
                static_cast<unsigned long long>(have_there ? there.RegionSize : 0));
            return nullptr;
        }

        const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
        const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
        if (nt->Signature != IMAGE_NT_SIGNATURE) {
            set_failure("base+e_lfanew has no NT signature");
            return nullptr;
        }

        const IMAGE_DATA_DIRECTORY& directory =
            nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_RESOURCE];
        if (!directory.VirtualAddress || !directory.Size) {
            set_failure("DataDirectory[RESOURCE] is empty in this image");
            return nullptr;
        }

        // Absolute extent of the .rsrc section, used to bounds-check every
        // offset we follow. The previous copies validated nothing.
        const auto* const section_begin = base + directory.VirtualAddress;
        const auto* const section_end = section_begin + directory.Size;
        const std::size_t section_size = directory.Size;

        // A directory is a header followed by its entries; the whole thing must
        // lie inside the section.
        auto directory_fits = [&](const void* dir, DWORD entry_count) -> bool {
            const auto* p = static_cast<const std::byte*>(dir);
            if (p < section_begin || p > section_end)
                return false;
            const std::size_t bytes = sizeof(IMAGE_RESOURCE_DIRECTORY)
                + sizeof(IMAGE_RESOURCE_DIRECTORY_ENTRY) * static_cast<std::size_t>(entry_count);
            return static_cast<std::size_t>(section_end - p) >= bytes;
        };

        auto find_id = [&](const IMAGE_RESOURCE_DIRECTORY* parent, WORD id)
            -> const IMAGE_RESOURCE_DIRECTORY_ENTRY* {
            if (!parent || !directory_fits(parent, parent->NumberOfNamedEntries + parent->NumberOfIdEntries))
                return nullptr;

            const auto* entries = reinterpret_cast<const IMAGE_RESOURCE_DIRECTORY_ENTRY*>(parent + 1);
            const DWORD count = parent->NumberOfNamedEntries + parent->NumberOfIdEntries;
            // Named entries come first and are matched by name, not id; the
            // original loop started at NumberOfNamedEntries, which is correct.
            for (DWORD index = parent->NumberOfNamedEntries; index < count; ++index)
                if (entries[index].Id == id) return &entries[index];
            return nullptr;
        };

        auto child_directory = [&](const IMAGE_RESOURCE_DIRECTORY_ENTRY* entry)
            -> const IMAGE_RESOURCE_DIRECTORY* {
            if (!entry || !entry->DataIsDirectory)
                return nullptr;
            // OffsetToDirectory is relative to the start of the resource
            // section, and must land inside it.
            if (entry->OffsetToDirectory >= section_size)
                return nullptr;
            const auto* child =
                reinterpret_cast<const IMAGE_RESOURCE_DIRECTORY*>(section_begin + entry->OffsetToDirectory);
            // The whole HEADER must fit, not just the offset. The offset check
            // alone still lets a directory at section_size-1 through, and the
            // caller's first act is to read NumberOfNamedEntries from it -- an
            // out-of-bounds read of up to sizeof(IMAGE_RESOURCE_DIRECTORY), past
            // .rsrc and possibly past the image, which is exactly the class of
            // bug this function was extracted to eliminate. Zero entries here is
            // deliberately allowed: the caller re-reads the real count and
            // bounds-checks that separately.
            if (!directory_fits(child, 0))
                return nullptr;
            return child;
        };

        // RT_RCDATA is MAKEINTRESOURCE(10): a char* alias for the type id 10.
        // Comparing against the numeric id avoids both the pointer cast and the
        // MSVC-vs-mingw signedness difference in RT_RCDATA itself.
        constexpr WORD kRcDataType = 10;
        const auto* type = find_id(reinterpret_cast<const IMAGE_RESOURCE_DIRECTORY*>(section_begin),
            kRcDataType);
        if (!type) {
            set_failure("no RT_RCDATA(10) entry in the resource root");
            return nullptr;
        }
        const auto* named = find_id(child_directory(type), resource_id);
        if (!named) {
            set_failure("RT_RCDATA present, but this id is not among its entries");
            return nullptr;
        }
        const auto* languages = child_directory(named);
        if (!languages || !directory_fits(languages, languages->NumberOfNamedEntries + languages->NumberOfIdEntries)) {
            set_failure("id entry has no usable language directory");
            return nullptr;
        }

        const auto* entries = reinterpret_cast<const IMAGE_RESOURCE_DIRECTORY_ENTRY*>(languages + 1);
        const DWORD count = languages->NumberOfNamedEntries + languages->NumberOfIdEntries;
        if (!count || entries[0].DataIsDirectory) {
            set_failure("language directory is empty or points at a subdirectory");
            return nullptr;
        }

        // OffsetToData is relative to the section, and points at a data entry
        // whose payload must also fit inside the section.
        if (entries[0].OffsetToData >= section_size) {
            set_failure("data-entry offset falls outside the resource section");
            return nullptr;
        }
        const auto* data = reinterpret_cast<const IMAGE_RESOURCE_DATA_ENTRY*>(section_begin + entries[0].OffsetToData);
        if (!directory_fits(data, 0)) {
            set_failure("data entry does not fit inside the resource section");
            return nullptr;
        }
        // OffsetToData (the field inside IMAGE_RESOURCE_DATA_ENTRY) is an RVA
        // from the IMAGE BASE, not from the start of the resource section --
        // unlike OffsetToDirectory / OffsetToData on the *entries* above, which
        // are section-relative. Bound it against the section's extent expressed
        // in image RVA terms, and note the payload is returned base+OffsetToData.
        const std::size_t section_rva_begin = directory.VirtualAddress;
        const std::size_t section_rva_end = section_rva_begin + section_size;
        if (data->OffsetToData < section_rva_begin || data->OffsetToData >= section_rva_end) {
            set_failure("payload RVA is outside the resource section (bounds or relocation wrong)");
            return nullptr;
        }
        if (data->Size > section_rva_end - data->OffsetToData) {
            set_failure("payload Size runs past the end of the resource section");
            return nullptr;
        }

        out_size = data->Size;
        return base + data->OffsetToData;
    }

    // Win32 resource API, for the ordinary LoadLibrary case. `self_module` may
    // be null, in which case the exe's own resources are searched.
    inline const std::byte* find_rcdata(HMODULE self_module, WORD resource_id, DWORD& out_size) {
        out_size = 0;
        // 10 == RT_RCDATA, spelled numerically for the same reason as above.
        const HRSRC res = FindResourceW(self_module, MAKEINTRESOURCEW(resource_id), MAKEINTRESOURCEW(10));
        if (!res)
            return nullptr;
        const HGLOBAL loaded = LoadResource(self_module, res);
        if (!loaded)
            return nullptr;
        const DWORD size = SizeofResource(self_module, res);
        if (!size)
            return nullptr;
        out_size = size;
        return static_cast<const std::byte*>(LockResource(loaded));
    }

    // Full lookup: manual walk first (works when manual-mapped), Win32 API as
    // a fallback.
    //
    // `self_module` may be null, in which case it is resolved from
    // `code_address` via GetModuleHandleExW. That resolution matters: passing
    // null straight through to FindResourceW searches the HOST EXECUTABLE's
    // resources, never ours, so a mod calling rcdata(nullptr, ...) had a
    // fallback that could not possibly find its own data. Both in-tree callers
    // (util/i18n.cpp and module/minimap.h) did exactly that, which is why their
    // RCDATA payloads were reported unavailable while the on-disk copies kept
    // everything working and hid it.
    //
    // Templated on the address type so callers can pass either a data address or
    // the address of their own function. C++ does not implicitly convert a
    // function pointer to `const void*`, and the usual way to get an address
    // inside the module is the address of a function -- so the conversion is
    // done once, here, rather than at every call site.
    template <typename Fn>
    inline const std::byte* rcdata(HMODULE self_module, Fn code_address, WORD resource_id, DWORD& out_size) {
        const auto address = reinterpret_cast<uintptr_t>(code_address);
        const void* code = reinterpret_cast<const void*>(address);
        if (const std::byte* bytes = mapped_rcdata(code, resource_id, out_size))
            return bytes;

        // Copy the walk's reason out before trying the API route. It is the more
        // specific of the two, and it is the whole explanation when both fail.
        //
        // This used to be `const char* walk_reason = last_failure()` plus a
        // std::strcmp against it afterwards. With the reason now living in a
        // thread_local buffer, that pointer is last_failure() itself, so the
        // comparison could never differ and the "restore" was dead code that
        // only looked like it was preserving something. A std::string copy is
        // what the original was reaching for.
        std::string walk_reason(last_failure());

        if (!self_module)
            self_module = hmodule_from_address(code);
        if (self_module) {
            if (const std::byte* bytes = find_rcdata(self_module, resource_id, out_size))
                return bytes;
            // Both routes have now spoken and both failed. find_rcdata() leaves
            // the reason alone, so name the API route's failure as well rather
            // than leaving a reader with one ambiguous line.
            set_failure("%s | FindResourceW on the module the loader reported for "
                "0x%llX also failed, so this id is genuinely absent from that image too",
                walk_reason.c_str(),
                static_cast<unsigned long long>(reinterpret_cast<std::uintptr_t>(code)));
            return nullptr;
        }

        // No registered module handle either. Say so explicitly: this is the case that
        // a fully manual map produces, and it is the one the old code hid by reporting
        // the same "payload missing" for every cause.
        set_failure("%s | and GetModuleHandleExW(FROM_ADDRESS) returned no module either, "
            "so no resource API can reach this image",
            walk_reason.c_str());
        return nullptr;
    }

} // namespace pe_resource
