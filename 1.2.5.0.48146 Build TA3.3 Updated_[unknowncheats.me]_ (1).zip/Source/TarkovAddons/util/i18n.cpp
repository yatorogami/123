#include "common.h"
#include "i18n.h"

#include <algorithm>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <utility>
#include <unordered_map>
#include <unordered_set>

#include <Windows.h>

#include "../../external/nlohmann/json.hpp"
#include "../module/item_pricing.h"
#include "../util/Config.h"
#include "../../shared/module_paths.h"
#include "../util/pe_resource.h"
#include "logger.h"

namespace i18n {
    namespace {
        std::mutex locale_mutex;
        bool initialized = false;

        // The next four were namespace-scope objects, which meant their
        // allocation ran during STATIC INITIALISATION -- before DllMain, and
        // therefore before crash_probe::install() at dllmain.cpp:266. An
        // allocation failure there is a std::terminate with no probe report,
        // no WER attribution and no log line, which is the one death this
        // project's entire diagnostic posture cannot name.
        //
        // Function-local statics move the allocation to FIRST USE. Every use of
        // these is at or after ModuleManager::init() (dllmain.cpp:359), so by
        // then the probe is armed and a failure throws somewhere it can be
        // reported. `embedded_locale_resource_id` below already used this idiom
        // in this same file, so it is not a new shape here.
        //
        // Measured, not assumed: with an instrumented operator new, k_languages
        // allocates 8 times and translations twice during construction.
        // `active_locale` ("en") allocates ZERO -- it is small-string -- and is
        // converted anyway so the four read as one change.
        //
        // C++11 magic statics are thread-safe, so this does not weaken the
        // locale_mutex discipline: it adds a compiler-inserted guard, and every
        // existing lock is still taken exactly where it was. Destruction order
        // changes from namespace-scope reverse-order to first-use reverse-order;
        // nothing here has a destructor that observes another.
        std::string& active_locale_ref() {
            static std::string value = "en";
            return value;
        }

        std::string& loaded_locale_ref() {
            static std::string value;
            return value;
        }

        std::unordered_map<std::string, std::string>& translations_ref() {
            static std::unordered_map<std::string, std::string> value;
            return value;
        }

        const std::vector<language_entry>& k_languages_ref() {
            static const std::vector<language_entry> value = {
                {"en", "lang_en_sel"},
                {"ru", "lang_ru_sel"},
                {"ge", "lang_ge_sel"},
                {"fr", "lang_fr_sel"},
                {"es", "lang_es_sel"},
                {"mx", "lang_mx_sel"},
                {"it", "lang_it_sel"},
                {"pl", "lang_pl_sel"},
                {"cs", "lang_cs_sel"},
                {"po", "lang_po_sel"},
                {"br", "lang_br_sel"},
                {"tu", "lang_tu_sel"},
                {"ch", "lang_ch_sel"},
                {"tw", "lang_tw_sel"},
                {"jp", "lang_jp_sel"},
                {"kr", "lang_kr_sel"},
                {"hr", "lang_hr_sel"},
                {"sr", "lang_sr_sel"},
                {"ro", "lang_ro_sel"},
                {"hu", "lang_hu_sel"},
                {"sk", "lang_sk_sel"},
            };
            return value;
        }

        std::vector<language_entry> available_languages_cache;
        bool languages_discovered = false;

        // Language resources are embedded in the DLL.  Reading the PE resource
        // section directly also works with manual-map loaders that do not
        // register this module with the standard Windows resource APIs.
        WORD embedded_locale_resource_id(const std::string& code) {
            static const std::pair<const char*, WORD> resources[] = {
                {"en", 1300},
                {"ru", 1301},
                {"ge", 1302},
                {"fr", 1303},
                {"es", 1304},
                {"it", 1305},
                {"pl", 1306},
                {"cs", 1307},
                {"po", 1308},
                {"br", 1309},
                {"tu", 1310},
                {"ch", 1311},
                {"tw", 1312},
                {"jp", 1313},
                {"kr", 1314},
                {"sr", 1315},
                {"ro", 1316},
                {"hu", 1317},
                {"sk", 1318},
            };
            for (const auto& resource : resources)
                if (code == resource.first) return resource.second;
            return 0;
        }


        // Manual .rsrc walk first (the mod may be manual-mapped, in which case
        // the Win32 resource API cannot find our own resources), then
        // FindResourceW as the ordinary-LoadLibrary fallback. See pe_resource.h.
        const std::byte* embedded_locale_bytes(const std::string& code, DWORD& out_size) {
            const WORD resource_id = embedded_locale_resource_id(code);
            if (!resource_id) {
                out_size = 0;
                return nullptr;
            }
            return pe_resource::rcdata(nullptr, &embedded_locale_bytes, resource_id, out_size);
        }

        std::string normalize_locale(std::string code) {
            for (char& ch : code)
                ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));

            if (code == "de")
                return "ge";
            if (code == "ja")
                return "jp";
            if (code == "ko")
                return "kr";
            if (code == "pt")
                return "po";
            if (code == "pt-br" || code == "pt_br")
                return "br";
            if (code == "tr")
                return "tu";
            if (code == "zh" || code == "zh-cn" || code == "zh_cn" || code == "cn")
                return "ch";
            if (code == "zh-tw" || code == "zh_tw")
                return "tw";
            if (code == "es-mx" || code == "es_mx")
                return "mx";

            return code;
        }

        bool is_supported_locale(const std::string& code) {
            for (const language_entry& entry : k_languages_ref())
            {
                if (entry.code == code)
                    return true;
            }
            return false;
        }

        std::wstring locale_code_wide(const std::string& locale_code) {
            return std::wstring(locale_code.begin(), locale_code.end());
        }

        // ------------------------------------------------------------------------
        //  WHERE TRANSLATIONS COME FROM
        // ------------------------------------------------------------------------
        //  1. PRIMARY -- the copy compiled into the DLL, as RCDATA ids 1300-1318
        //     (declared in assets/menu_background.rc). That .rc sits in an
        //     unconditional ItemGroup in the vcxproj, so every configuration
        //     builds it in and these resources are always present. This is what
        //     makes a bare single-DLL drop work with no folder layout at all.
        //
        //  2. OVERRIDE -- a single directory named by `langDir=` in
        //     launcher.cfg, consulted only when a locale has no compiled copy
        //     (i.e. a custom or community translation). This is the ONLY disk
        //     location consulted.
        //
        //  The previous implementation probed ~10 locations: lang\ next to the
        //  DLL, the process CWD, the exe's folder and its parents,
        //  ../BsgLauncher/lang, ../launcher/lang, TarkovAddons\lang,
        //  %APPDATA%\TarkovAddons\lang, plus a 6-level walk looking for
        //  BsgLauncher. Several were CWD-relative, so the result depended on
        //  where the process happened to be launched from -- the same fragility
        //  that affects launcher.cfg itself. None are needed now that the
        //  translations are guaranteed to be in the binary.
        //
        //  English is the floor: en.json ships in the repo AND is compiled in,
        //  so if even English fails to load, the DLL is truncated or was built
        //  without the resource script.
        // ------------------------------------------------------------------------
        std::filesystem::path configured_lang_directory_wide() {
            // An explicit langDir= always wins. Otherwise the bundled fallback
            // translations live in the deployment's ta/lang, next to the DLL --
            // though this branch is rarely reached, because the compiled-in
            // RCDATA copy is tried first and always exists.
            Configuration cfg;
            if (cfg.load("launcher.cfg"))
            {
                const std::string configured = item_pricing::trim_config_value(cfg.get("langDir"));
                if (!configured.empty())
                {
                    return module_paths::path_from_utf8(
                        item_pricing::to_absolute_path(item_pricing::resolve_configured_path(configured)));
                }
            }

            const std::filesystem::path data_dir = module_paths::data_directory_wide();
            if (data_dir.empty())
                return {};

            return data_dir / L"lang";
        }

        std::string configured_lang_directory() {
            const std::filesystem::path dir = configured_lang_directory_wide();
            if (dir.empty())
                return {};
            return module_paths::wide_to_utf8(dir.wstring());
        }

        std::string normalize_locale_file_stem(std::string stem) {
            for (char& ch : stem)
                ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));

            if (stem == "de")
                return "ge";
            if (stem == "ja")
                return "jp";
            if (stem == "ko")
                return "kr";
            if (stem == "pt")
                return "po";
            if (stem == "pt-br" || stem == "pt_br")
                return "br";
            if (stem == "tr")
                return "tu";
            if (stem == "zh" || stem == "zh-cn" || stem == "zh_cn" || stem == "cn")
                return "ch";
            if (stem == "zh-tw" || stem == "zh_tw")
                return "tw";
            if (stem == "es-mx" || stem == "es_mx")
                return "mx";

            return stem;
        }

        // Only the explicit langDir= override is scanned. With translations
        // guaranteed to be compiled in, there is nothing to discover by walking
        // the filesystem -- a locale is available because the binary carries it.
        void collect_locale_codes_from_disk(std::unordered_set<std::string>& out) {
            {
                const std::filesystem::path dir = configured_lang_directory_wide();
                std::error_code ec;
                if (dir.empty() || !std::filesystem::is_directory(dir, ec))
                    return;

                for (const auto& entry : std::filesystem::directory_iterator(dir, ec))
                {
                    if (ec)
                        break;

                    const std::wstring ext = entry.path().extension().wstring();
                    if (_wcsicmp(ext.c_str(), L".json") != 0)
                        continue;

                    const DWORD attrs = GetFileAttributesW(entry.path().c_str());
                    if (attrs == INVALID_FILE_ATTRIBUTES || (attrs & FILE_ATTRIBUTE_DIRECTORY))
                        continue;

                    std::string stem = module_paths::wide_to_utf8(entry.path().stem().wstring());
                    stem = normalize_locale_file_stem(std::move(stem));
                    if (!stem.empty())
                        out.insert(stem);
                }
            }
        }

        // Locale resolution order (see the block comment above for the full
        // rationale):
        //   1. RCDATA compiled into the DLL (ids 1300-1318, declared in
        //      assets/menu_background.rc) -- the guaranteed default
        //   2. <langDir>/<code>.json, only for a locale the binary does not
        //      carry, i.e. a custom or community translation
        //
        // The compiled copy is consulted first and needs no filesystem at all,
        // which is what makes a bare single-file drop work.
        // RCDATA first: the compiled-in translation is guaranteed present, so
        // this is the common path and it does no filesystem work at all. The
        // langDir= override is only consulted when the binary has no copy of
        // this locale, i.e. a custom or community translation pack.
        bool load_locale_file(const std::string& locale_code) {
            DWORD resource_size = 0;
            if (const std::byte* resource_bytes = embedded_locale_bytes(locale_code, resource_size);
                resource_bytes && resource_size)
            {
                try
                {
                    const auto json = nlohmann::json::parse(
                        reinterpret_cast<const char*>(resource_bytes),
                        reinterpret_cast<const char*>(resource_bytes) + resource_size);
                    if (json.is_object())
                    {
                        std::unordered_map<std::string, std::string> next;
                        for (auto it = json.begin(); it != json.end(); ++it)
                            if (it.value().is_string()) next[it.key()] = it.value().get<std::string>();
                        translations_ref() = std::move(next);
                        loaded_locale_ref() = locale_code;
                        return true;
                    }
                    logger::warn("i18n: the built-in " + locale_code
                        + " is not a JSON object; falling back to the override directory");
                } catch (const std::exception& ex)
                {
                    logger::warn(std::string("i18n: failed to parse the built-in ") + locale_code
                        + ": " + ex.what() + " -- falling back to the override directory");
                }
            }

            const std::filesystem::path dir = configured_lang_directory_wide();
            if (dir.empty())
                return false;

            const std::filesystem::path file_path = dir / (locale_code_wide(locale_code) + L".json");
            std::ifstream input(file_path, std::ios::binary);
            if (!input.good())
                return false;

            try
            {
                nlohmann::json json;
                input >> json;
                if (!json.is_object())
                {
                    logger::warn("i18n: " + module_paths::wide_to_utf8(file_path.wstring())
                        + " is not a JSON object");
                    return false;
                }

                std::unordered_map<std::string, std::string> next;
                for (auto it = json.begin(); it != json.end(); ++it)
                {
                    if (it.value().is_string())
                        next[it.key()] = it.value().get<std::string>();
                }

                translations_ref() = std::move(next);
                loaded_locale_ref() = locale_code;
                return true;
            } catch (const std::exception& ex)
            {
                logger::warn("i18n: failed to parse " + module_paths::wide_to_utf8(file_path.wstring())
                    + ": " + ex.what());
                return false;
            }
        }

        void ensure_locale_loaded(const std::string& locale_code) {
            if (loaded_locale_ref() == locale_code && !translations_ref().empty())
                return;

            if (load_locale_file(locale_code))
                return;

            if (locale_code != "en" && load_locale_file("en"))
            {
                logger::warn("i18n: '" + locale_code
                    + "' is unavailable; fell back to English");
                return;
            }

            // Nothing loaded, and this is now a much stronger signal than it used
            // to be: every locale is compiled into the DLL as RCDATA, so reaching
            // here means the resource section is missing or unreadable, not that
            // a folder was missing. The menu will render raw config keys
            // ("weapon_builder_mod", "tp_all_btn", ...) with no explanation, so
            // say the one thing that is actually wrong.
            logger::error(
                "i18n: no translations could be loaded for '" + locale_code
                + "' (English also unavailable) -- the menu will show raw config keys.\n"
                + "  Every translation is compiled into this DLL as RCDATA 1300-1318, so this\n"
                + "  is NOT a missing-folder problem. No lang/ directory is required, and copying\n"
                + "  one next to the DLL will not help.\n"
                + "  Expected causes, in order of likelihood:\n"
                + "    1. The DLL is truncated or corrupt (partial download, blocked write).\n"
                + "       Compare its size against the build output.\n"
                + "    2. It was not built with assets/menu_background.rc. The .rc must be in\n"
                + "       the vcxproj as <ResourceCompile>; without it there are no ids to find.\n"
                + "    3. It is being loaded by a manual mapper that relocates or discards the\n"
                + "       resource section -- see the note in util/pe_resource.h.\n"
                + (configured_lang_directory().empty()
                       ? std::string("    4. No langDir= override is set in launcher.cfg.\n")
                       : "    4. langDir= is set to '" + configured_lang_directory()
                           + "', which was checked too.\n")
                + "  Everything else in the mod works without translations, so this is cosmetic,\n"
                + "  but it makes the menu unreadable.");

            translations_ref().clear();
            loaded_locale_ref() = locale_code;
        }

        void apply_locale(const std::string& locale_code) {
            const std::string normalized = normalize_locale(locale_code);
            const std::string resolved = is_supported_locale(normalized) ? normalized : "en";
            ensure_locale_loaded(resolved);
            active_locale_ref() = resolved;
        }

        const language_entry* find_language_entry(const std::string& code) {
            for (const language_entry& entry : k_languages_ref())
            {
                if (entry.code == code)
                    return &entry;
            }
            return nullptr;
        }

        const std::vector<language_entry>& english_fallback_languages() {
            static const std::vector<language_entry> fallback = {{"en", "lang_en_sel"}};
            return fallback;
        }

        void discover_available_languages() {
            std::unordered_set<std::string> available;

            // A locale is offered if the DLL carries it as RCDATA, or if it
            // exists in the langDir= override. Both are sources load_locale_file
            // will actually succeed on, so the picker never offers a language
            // the loader cannot produce. RCDATA is checked first because it is
            // the one that is guaranteed.
            for (const language_entry& entry : k_languages_ref())
            {
                DWORD resource_size = 0;
                if (embedded_locale_bytes(entry.code, resource_size) && resource_size)
                    available.insert(entry.code);
            }

            // Custom/community translations in the override directory, which
            // may carry codes beyond the 19 built in.
            collect_locale_codes_from_disk(available);

            std::vector<language_entry> next;
            next.reserve(available.size());
            for (const language_entry& entry : k_languages_ref())
            {
                if (available.count(entry.code))
                    next.push_back(entry);
            }

            if (next.empty())
            {
                if (const language_entry* english = find_language_entry("en"))
                    next.push_back(*english);
            }

            available_languages_cache = std::move(next);

            std::string discovered;
            for (const language_entry& entry : available_languages_cache)
            {
                if (!discovered.empty())
                    discovered += ", ";
                discovered += entry.code;
            }
            // The old message hardcoded "(from <lang dir>)" even when every
            // locale came from the compiled-in RCDATA and nothing came from
            // disk, which made the log actively misleading. Now the source is
            // named explicitly.
            const std::string override_dir = configured_lang_directory();
            logger::info("i18n: available languages: " + discovered
                + " (compiled into the DLL"
                + (override_dir.empty() ? std::string("; no langDir override set")
                                        : "; override: " + override_dir)
                + ")");
        }

        const std::vector<language_entry>& active_language_list() {
            if (!languages_discovered)
                return english_fallback_languages();
            return available_languages_cache;
        }
    } // namespace

    void init() {
        std::lock_guard<std::mutex> lock(locale_mutex);
        if (initialized)
            return;
        initialized = true;
        apply_locale("en");
    }

    void init_menu_languages() {
        std::lock_guard<std::mutex> lock(locale_mutex);
        if (languages_discovered)
            return;
        discover_available_languages();
        languages_discovered = true;
    }

    const std::string& current_locale() {
        return active_locale_ref();
    }

    void set_locale(const std::string& locale_code) {
        std::lock_guard<std::mutex> lock(locale_mutex);
        apply_locale(locale_code);
    }

    const std::vector<language_entry>& supported_languages() {
        return k_languages_ref();
    }

    const std::vector<language_entry>& available_languages() {
        return active_language_list();
    }

    int locale_to_index(const std::string& code) {
        const std::string normalized = normalize_locale(code);
        const std::vector<language_entry>& languages = active_language_list();
        for (size_t i = 0; i < languages.size(); ++i)
        {
            if (languages[i].code == normalized)
                return static_cast<int>(i);
        }
        return 0;
    }

    std::string index_to_locale(const int index) {
        const std::vector<language_entry>& languages = active_language_list();
        if (index < 0 || static_cast<size_t>(index) >= languages.size())
            return languages.empty() ? "en" : languages.front().code;
        return languages[static_cast<size_t>(index)].code;
    }

    std::string tr(const char* key) {
        if (!key || !*key)
            return {};
        return tr(std::string(key));
    }

    std::string tr(const std::string& key) {
        if (key.empty())
            return key;

        // The writers (apply_locale / load_locale_file) reassign `translations`
        // wholesale under locale_mutex, so the read has to take the same lock --
        // otherwise a language switch mid-frame races on the unordered_map.
        // tr() runs on every ImGui frame for every visible label, so the mutex
        // is uncontended in practice and this is a few dozen ns.
        std::lock_guard<std::mutex> lock(locale_mutex);
        std::unordered_map<std::string, std::string>& map = translations_ref();
        const auto iter = map.find(key);
        if (iter != map.end() && !iter->second.empty())
            return iter->second;
        return key;
    }

} // namespace i18n
