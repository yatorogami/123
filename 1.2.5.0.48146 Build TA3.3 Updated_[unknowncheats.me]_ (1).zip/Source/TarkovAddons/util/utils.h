#pragma once
#include <Windows.h>

namespace utils {
    void get_desktop_resolution(int& horizontal, int& vertical);

    std::vector<std::string> split(const std::string& s, char delim);
} // namespace utils
