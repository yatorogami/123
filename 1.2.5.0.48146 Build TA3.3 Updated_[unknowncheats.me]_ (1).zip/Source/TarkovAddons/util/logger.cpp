#include "common.h"
#include "logger.h"
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iostream>
#include <mutex>
#include <windows.h>

#include "../../shared/module_paths.h"

namespace {

    // Async state-machine hooks log from several threads at once; without the lock,
    // partial lines interleave and the ordering becomes unreconstructable.
    std::mutex g_log_mutex;

    // The console filter (dllmain) redirects STD_OUTPUT_HANDLE to a pipe so it can
    // filter WebSocket trace spam; SetConsoleTextAttribute must target the real
    // console handle captured at console setup, otherwise the attribute lands on the
    // pipe handle and every log line comes out monochrome.
    HANDLE g_console_handle = nullptr;

    HANDLE console_handle() {
        if (g_console_handle && g_console_handle != INVALID_HANDLE_VALUE)
            return g_console_handle;
        return GetStdHandle(STD_OUTPUT_HANDLE);
    }

    void set_color(int textColor, int bgColor) {
        SetConsoleTextAttribute(console_handle(),
            static_cast<WORD>(bgColor << 4) | textColor);
    }

    void reset_color() { set_color(7, 0); }

    // The console window lives inside the game process, so it dies together with the
    // process on a crash and the last lines are lost. Mirror every log line to a file,
    // opening/flushing/closing per call so each line is on disk before we return and
    // survives any subsequent crash.
    // Next to the DLL, i.e. alongside launcher.cfg. Not the drive root: a non-elevated
    // game process is denied write access to C:\ and the failure is silent, which is why
    // this log never appeared.
    const std::string& log_path() {
        static const std::string cached = [] {
            const std::string dir = module_paths::dll_directory_utf8();
            return dir.empty() ? std::string("tarkovaddons_log.txt")
                               : dir + "\\tarkovaddons_log.txt";
        }();
        return cached;
    }

    // Wall-clock time (ms) + process id + OS thread id prefix, so interleaved logs
    // from concurrent async continuations can be ordered and attributed to
    // their thread, and lines from two processes sharing the file can be told
    // apart.
    //
    // The pid was added 2026-10-02 because a log showed five seconds of life
    // AFTER a "FATAL (unhandled exception filter)" report, which cannot happen
    // in a process that died -- so either the report was not fatal or a second
    // process appended to the same file, and `tid` alone cannot distinguish
    // those. It can: thread ids are small and recycled across processes, and
    // every other writer here shares the file by design (WORKFLOW.md records
    // the launcher and the bypass appending to the same path), so this is not
    // hypothetical. One extra field, and the ambiguity is gone.
    std::string stamp() {
        using namespace std::chrono;
        const auto now = system_clock::now();
        const auto ms = duration_cast<milliseconds>(now.time_since_epoch()) % 1000;
        const std::time_t tt = system_clock::to_time_t(now);
        std::tm tmv{};
        localtime_s(&tmv, &tt);
        char buf[64];
        std::snprintf(buf, sizeof(buf), "%04d-%02d-%02d %02d:%02d:%02d.%03d pid=%lu tid=%lu",
            tmv.tm_year + 1900, tmv.tm_mon + 1, tmv.tm_mday,
            tmv.tm_hour, tmv.tm_min, tmv.tm_sec,
            static_cast<unsigned>(ms.count()),
            static_cast<unsigned long>(GetCurrentProcessId()),
            static_cast<unsigned long>(GetCurrentThreadId()));
        return buf;
    }

    // The log file, opened once and kept open.
    //
    // It used to be constructed per line: CreateFile, seek to end, WriteFile, CloseHandle, for
    // every message, on whichever thread logged. At the rate the hideout refresh was emitting
    // (~100 lines/second) that was a hundred file lifecycles a second on the game's main
    // thread, and the open/close dominated -- not the write.
    //
    // flush() per line is kept, and it is the entire point of the file mirror: it pushes each
    // line to the OS before write_line returns, so a PROCESS crash still leaves it on disk.
    // The only thing lost now is the tail of a machine-level crash, which the old form would
    // not have survived either -- its bytes were in the same unwritten OS buffer.
    //
    // Retried on every call only while the open keeps failing, so a log file deleted or rotated
    // out from under a long session is picked back up, and a genuinely unwritable path does no
    // worse than before.
    //
    // 2026-09-30. This used to be a function-local `static std::ofstream`, REUSED after a
    // failure: `clear(); close();` then `open()` on the same object. The crash at 20:56:06
    // faulted inside `std::basic_filebuf<char>::_Endwrite` on a NULL read of 0x138, reached
    // from the ESP draw thread, and that is the signature of a filebuf whose file handle is
    // gone while a write is still dispatched through it. Reusing one basic_filebuf across
    // close/open is the risky shape.
    //
    // So the stream is now HEAP-ALLOCATED and destroyed rather than reused: on any failure
    // the object is reset, so the next call constructs a fresh basic_filebuf. That costs
    // one allocation on a failure path and nothing on the happy path.
    std::unique_ptr<std::ofstream>& log_stream() {
        static std::unique_ptr<std::ofstream> stream;
        return stream;
    }

    // Destroy the stream so the next call builds a fresh one. This is the whole point:
    // see the note above about why clear()+close()+open() on a reused object is the
    // shape that faults.
    void drop_log_stream() { log_stream().reset(); }

    std::ofstream* log_file() {
        auto& s = log_stream();
        if (!s)
            s = std::make_unique<std::ofstream>(log_path(), std::ios::app);
        // Never hand back a half-open object. nullptr is the only value write_line acts
        // on, and it is re-checked immediately before use regardless.
        if (s && !s->is_open())
            s.reset();
        return s ? s.get() : nullptr;
    }

    // Console writes are batched. The console window lives inside the game process (see above),
    // so it is the live view and never the durable record -- the file is that. Flushing every
    // line means a synchronous WriteFile into the redirect pipe per line, for output a filter
    // thread is draining anyway, and it stalls the caller for no visible gain: a few lines of
    // console latency is invisible, and the file is already durable by then.
    constexpr size_t kConsoleFlushThreshold = 32 * 1024;
    size_t g_console_pending = 0;

    // bgColor defaults to 0 (no background), which is every level except CRASH.
    // A background is the only way to make one line stand out in a fast-scrolling
    // console wall, and it is only worth the extra parameter for CRASH -- hence the
    // default rather than threading a colour pair through every call site.
    void write_line(const char* level, const int color, const std::string& msg,
        const int bgColor = 0) {
        std::lock_guard lock(g_log_mutex);
        const std::string prefix = stamp();

        std::cout << "[" << prefix << " ";
        set_color(color, bgColor);
        std::cout << level;
        reset_color();
        std::cout << "] ";
        std::cout << msg << '\n'; // batched below, plus at static destruction
        g_console_pending += prefix.size() + msg.size() + std::strlen(level);
        if (g_console_pending >= kConsoleFlushThreshold) {
            std::cout.flush();
            g_console_pending = 0;
        }

        if (std::ofstream* f = log_file())
        {
            // Re-check is_open() immediately before the write. This thread holds
            // g_log_mutex so nothing else can close it in between, but the check costs
            // one branch and what it guards against is a hard fault inside the C++
            // runtime rather than a dropped line.
            if (!f->is_open()) {
                drop_log_stream();
            } else {
                // Logging must never be the thing that takes the process down. A
                // filesystem hiccup can make an ostream operation throw, and this session
                // already logged 6197 suppressed C++ exceptions, so this path
                // demonstrably runs during exception-heavy periods.
                try {
                    *f << "[" << prefix << " " << level << "] " << msg << '\n';
                    f->flush();
                } catch (...) {
                    // Swallowed on purpose. The failure check below still runs and puts
                    // the stream back in a known state.
                }
                // A failed write (file deleted, disk full, handle invalidated) leaves the
                // stream in an error state that would silently swallow every later line.
                // DESTROY it rather than clear()+close(): reusing one basic_filebuf
                // across a close/open is the shape that faulted in _Endwrite.
                if (!*f)
                    drop_log_stream();
            }
        }
    }
} // namespace

namespace logger {
    // DEBUG lines are diagnostic spam; default off, flipped by the Debug Log module.
    // The default must be false to match the comment above and the documented
    // contract in logger.h: the module only calls set_debug_enabled() from its
    // own init()/toggle, so a `true` default produced a window of DEBUG output
    // from the moment the logger came up until module init ran -- and a
    // permanent flood if module init was ever skipped.
    std::atomic<bool> g_debug_enabled{false};

    void set_debug_enabled(const bool enabled) { g_debug_enabled.store(enabled, std::memory_order_relaxed); }
    bool debug_enabled() { return g_debug_enabled.load(std::memory_order_relaxed); }

    void set_console_handle(void* handle) { g_console_handle = static_cast<HANDLE>(handle); }

    void debug(std::string msg)
    {
        if (!debug_enabled()) return;
        write_line("DEBUG", 8, std::move(msg));
    }
    void info(std::string msg) { write_line("INFO", 3, std::move(msg)); }
    void warn(std::string msg) { write_line("WARN", 6, std::move(msg)); }
    void error(std::string msg) { write_line("ERROR", 4, std::move(msg)); }

    // One INFO line, written WITHOUT ever blocking on g_log_mutex. See the contract in
    // logger.h -- this exists for DLL_PROCESS_DETACH and nothing else should use it.
    void info_at_exit(std::string msg) {
        const std::string line = "[" + stamp() + " INFO] " + msg + '\n';

        const auto emit = [&]() {
            if (std::ofstream* f = log_file()) {
                if (!f->is_open()) {
                    drop_log_stream();
                    return;
                }
                try {
                    *f << line;
                    f->flush();
                } catch (...) {
                    // Same reason write_line swallows: logging must never be the thing
                    // that takes the process down, and this is the last line we will
                    // ever attempt to write.
                }
            }
        };

        if (g_log_mutex.try_lock()) {
            emit();
            g_log_mutex.unlock();
            return;
        }

        // The mutex is held by a thread that is not coming back -- see logger.h for why
        // that is the expected case here and not a surprise. Writing unserialised is the
        // lesser evil: the alternative is no line at all, and the whole point of this
        // function is that the line exists.
        emit();
    }

    // Bright white on red. Only reachable from the crash reporter; see the
    // contract in logger.h for why this is its own level and not an error.
    void crash(std::string msg) { write_line("CRASH", 15, std::move(msg), 4); }
} // namespace logger
