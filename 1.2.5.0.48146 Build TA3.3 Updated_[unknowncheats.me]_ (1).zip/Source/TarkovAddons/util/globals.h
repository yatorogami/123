#pragma once
#include <cstddef>
#include <string>

namespace globals {
    const std::string DLL_OFFSET_FILE = "offsets.cfg";
    const std::string DLL_PATTERN_FILE = "patterns.cfg";

    // v3.2 -- the first release called stable.
    //
    // The headline change is a single deployment layout: three DLLs at the top,
    // everything they read or write under ta\, and a one-time automatic import
    // from every pre-3.2 location so existing installs keep their settings.
    //
    //   <deploy>\  TarkovAddons.dll  TarkovLauncherBypass.dll  vk_swiftshader.dll
    //              ta\  compatibility\, launcher.cfg, offsets.cfg, patterns.cfg,
    //                   lang\, maps\, configs\, tarkov_prices.json
    //
    // configs\ holds the user's own settings, kept apart from the shipped
    // read-only data so that "back up my settings" is one folder and a mod
    // update cannot be mistaken for a settings reset.
    //
    // Logs deliberately stay next to the DLL rather than moving into ta\: they
    // are diagnostic output, and "send me the log next to TarkovAddons.dll" is
    // a request anyone can act on. The Debug Log panel reads that same path.
    //
    // get_display_title() is the single source of truth for the console title,
    // menu title, watermark and log header.
    //
    // k_version is the ONLY place the version is written, and both strings below
    // are built from it. That is the whole point: the menu's sidebar used to
    // carry its own literal ("Reloaded v3.3") beside this one ("...v3.2"), so the
    // number a player reads on screen and the number in the log header could be
    // different releases and neither would look wrong on its own terms. A
    // version written twice is not a version, it is two claims.
    //
    // constexpr char[] rather than a std::string so prod_name's initializer does
    // not depend on another translation unit's dynamic initialization: it reads
    // a constant, and this header is included by dllmain, the menu, always_on
    // and a dozen modules.
    inline constexpr const char k_version[] = "3.3";
    const std::string prod_name = std::string("TarkovAddons Reloaded v") + k_version;
    const std::string prod_ver("");

    // One attributed credit: the forum handle, and what that person added.
    // `const char*` rather than std::string so the whole table below is a
    // constexpr POD array -- no per-translation-unit heap or static init in a
    // header this widely included (dllmain, menu, always_on, 6 modules...).
    struct Credit {
        const char* name;
        const char* contribution;
    };

    // Everyone credited on the Credits tab, in the order that history happened
    // rather than alphabetically: what the original menu was built from, the
    // fork lineage that carried it forward, the offset/pattern work, the
    // maintainers who kept it alive across each game update, and the feature
    // modules contributed later.
    //
    // Sourced from the UnknownCheats release thread (thread 734993, "TarkovAddons
    // PVE - Item Spawner, Skills, Quests, Trader Rep, EXP and more!"). The first
    // block is the author's own "Credits/Inspirations" list from the opening
    // post; the rest were compiled from the patches, patterns and source
    // contributions posted in that thread.
    //
    // ADDING A NAME: use the handle as it appears on the forum so people are
    // findable, and say what they actually added. Do not credit a build that
    // was only repacked or re-uploaded -- several people here did that work,
    // but the credited entries are the ones where something new was written.
    inline constexpr Credit k_credits[] = {
        // The original release, and the prior art written into it. Six of these
        // are named verbatim in the opening post's credits section, which the
        // author labelled "helped, inspired or got pasted from"; stupid.solutions
        // is the project xXBattlEyeXx is credited there as drawing from, and
        // stangaming is the thread's author.
        {"stangaming", "Original TarkovAddons author -- every fork below is his source"},
        {"x3e", "PVE BattlEye alternative; the launcher bypass descends from it"},
        {"xXBattlEyeXx", "stupid.solutions -- spawner and quest-item work that carried into TarkovAddons"},
        {"StupidSolutions", "Quest completer and menu prior art, still the reference for both"},
        {"kirillqa1709", "Item spawner and quest item adder"},
        {"hollow", "hwho -- hotkey handling"},
        {"ionicjohn", "Early help on the original release"},
        {"archieuwu", "Early help on the original release"},

        // Fork lineage. Each of these took the previous tree forward.
        {"Eclion", "Community Edition fork (Com Fix ECL)"},
        {"Dfuncker", "TarkovAddons Refactored"},
        {"NickolasFleim", "TarkovAddons++"},
        {"Wookiie", "TarkovAddons Reloaded"},
        {"XeonDead", "TarkovAddons Reloaded v3.x -- this tree"},

        // Offsets and patterns.
        {"exhoust", "IL2CPP offset set, and the rewritten il2cpp_offsets.h"},
        {"Mik0h1me", "Menu artwork"},

        // Patch maintenance. TarkovAddons is pattern-driven, so it does not
        // survive a game update on its own; these are the people who kept
        // re-resolving signatures and shipping a build for each patch.
        {"de Tylmarande", "Community Edition branch; per-update rebuilds and the Loot ESP"},
        {"VanargandCode", "Per-update BattlEye and IL2CPP patterns, changelogs, transit and Always Survive fixes"},
        {"EvilEVF", "TA++ Community build released for each patch"},
        {"CoseyK", "Per-update rebuilds and new IL2CPP patterns"},
        {"TarkyRuns", "Prebuilt no-aimbot binaries and setup guides"},
        {"SimKiOl", "Rebuild walkthroughs and the resolve_class_nested fix"},

        // Feature modules contributed as source in the thread.
        {"787latinki", "Rebuilt quest completer, Icebreaker local PvE scenario, Always Survive / local transit hooks, patterns.cfg documentation"},
        {"BAMBAMazing", "Loot ESP module"},
        {"StickOnion", "Chinese-locale text fix (to_english) and the Enhanced build"},
        {"Epple", "disabler.cpp and il2cpp_offsets.h update fixes; \"Escape from Tierkov\" pricing tool"},
        {"bee9sho", "Cleaned-up BattlEye disabler"},
        {"OfficialChaos", "Shared ideas on better interface and proposed an idea for Gym minigame hack"}
    };
    inline constexpr size_t k_credits_count = sizeof(k_credits) / sizeof(k_credits[0]);

    // Short byline for the console title and the startup log line. The full
    // attribution is k_credits above and on the Credits tab -- keep this one
    // to a single readable line, it is printed into a title bar.
    const std::string credits("Wookiie, XeonDead + the UnknownCheats TarkovAddons community");

    constexpr bool console = true;
    // Diagnostic logging is gated solely by logger::debug / the Debug Log module
    // toggle (util/logger.h) — there is no separate verbose switch.

    std::string get_display_title();

    // The SHORT version line the menu draws under "TARKOVADDONS" in the sidebar:
    // "Reloaded v3.3". The product name minus its own first word, built from the
    // same k_version rather than retyped, so it cannot disagree with the log
    // header -- which is the disagreement this pair existed to have.
    //
    // A function returning std::string, not another namespace-scope string: this
    // one is drawn once a frame and there is no reason to pay a static
    // initializer for it in every TU that includes this header.
    std::string version_line();
} // namespace globals
