#pragma once

// The map-drawing primitives that svg_raster_map.cpp and tile_raster_map.cpp
// each carried an identical copy of.
//
// Consolidated 2026-10-14 from dup_scan's largest CROSS-FILE cluster: six pairs,
// the biggest a byte-identical 27-line draw_clipped_polygon, then a
// byte-identical Sutherland-Hodgman clipper behind it. The two rasters are the
// same drawing pipeline over two different map SOURCES -- a parsed SVG vs
// fetched tiles -- and only the source differs, so everything from the clipper
// onwards had been written twice.
//
// It had already begun to drift, which is the whole argument: the tile copy
// called clip_quad_to_map_uv `clip_quad_to_uv`. Same body, second name, one
// grep away from being a third copy. A private function duplicated into two
// translation units is two functions that can disagree.
//
// Header-only on purpose. Two translation units need these, the bodies are
// small, and `inline` costs nothing -- where a new .cpp would mean a new entry
// in CMakeLists.txt AND TarkovAddons.vcxproj to keep in step forever.
//
// map_vertex is at global scope rather than in the namespace because both
// rasters named the type bare, 16 and 14 times, and moving it would have churned
// every one of those for nothing.

#include <imgui.h>

#include <cmath>
#include <vector>

#include "../gui/dxhook/dxhook.h"
#include "../module/minimap.h"

struct map_vertex {
    ImVec2 screen{};
    ImVec2 map_uv{};
};

namespace raster_draw {

inline ImVec2 lerp_vec2(const ImVec2& a, const ImVec2& b, const float t) {
    return {a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t};
}

inline float vertex_axis(const map_vertex& v, const int axis) {
    return axis == 0 ? v.map_uv.x : v.map_uv.y;
}

inline map_vertex lerp_vertex(const map_vertex& a, const map_vertex& b, const float t) {
    map_vertex out{};
    out.screen = lerp_vec2(a.screen, b.screen, t);
    out.map_uv = lerp_vec2(a.map_uv, b.map_uv, t);
    return out;
}

// Sutherland-Hodgman against one half plane. `keep_at_or_above` picks the side.
inline std::vector<map_vertex> clip_half_plane(const std::vector<map_vertex>& input,
    const int axis, const float limit, const bool keep_at_or_above) {
    std::vector<map_vertex> output;
    if (input.empty())
        return output;
    output.reserve(input.size() + 2);
    const size_t count = input.size();
    for (size_t i = 0; i < count; ++i) {
        const map_vertex& current = input[i];
        const map_vertex& next = input[(i + 1) % count];
        const float current_axis = vertex_axis(current, axis);
        const float next_axis = vertex_axis(next, axis);
        const bool current_inside = keep_at_or_above ? current_axis >= limit : current_axis <= limit;
        const bool next_inside = keep_at_or_above ? next_axis >= limit : next_axis <= limit;
        if (current_inside && next_inside) {
            output.push_back(next);
        } else if (current_inside && !next_inside) {
            const float denom = next_axis - current_axis;
            if (fabsf(denom) > 1e-6f)
                output.push_back(lerp_vertex(current, next, (limit - current_axis) / denom));
        } else if (!current_inside && next_inside) {
            const float denom = next_axis - current_axis;
            if (fabsf(denom) > 1e-6f)
                output.push_back(lerp_vertex(current, next, (limit - current_axis) / denom));
            output.push_back(next);
        }
    }
    return output;
}

// A quad clipped to the 0..1 unit square. The name is the svg copy's; the tile
// raster called it clip_quad_to_uv and that second name is what this header
// retired.
inline std::vector<map_vertex> clip_quad_to_map_uv(const map_vertex in[4]) {
    std::vector<map_vertex> poly(in, in + 4);
    poly = clip_half_plane(poly, 0, 0.f, true);
    if (poly.empty()) return {};
    poly = clip_half_plane(poly, 0, 1.f, false);
    if (poly.empty()) return {};
    poly = clip_half_plane(poly, 1, 0.f, true);
    if (poly.empty()) return {};
    poly = clip_half_plane(poly, 1, 1.f, false);
    return poly;
}

// A triangle as a degenerate quad: two of the four corners share a uv, which is
// how ImGui's AddImageQuad is asked for a triangle.
inline void draw_textured_triangle(ImDrawList* draw_list, const ImTextureID tex_id,
    const map_vertex& v0, const map_vertex& v1, const map_vertex& v2,
    const int coordinate_rotation, const ImU32 tint) {
    const ImVec2 uv0 = minimap::map_tex_uv(coordinate_rotation, v0.map_uv.x, v0.map_uv.y);
    const ImVec2 uv1 = minimap::map_tex_uv(coordinate_rotation, v1.map_uv.x, v1.map_uv.y);
    const ImVec2 uv2 = minimap::map_tex_uv(coordinate_rotation, v2.map_uv.x, v2.map_uv.y);
    draw_list->AddImageQuad(tex_id,
        v0.screen, v1.screen, v2.screen, v2.screen,
        uv0, uv1, uv2, uv2, tint);
}

inline void draw_clipped_polygon(ImDrawList* draw_list, const ImTextureID tex_id,
    const std::vector<map_vertex>& poly, const int coordinate_rotation,
    const ImU32 tint) {
    if (poly.size() < 3)
        return;
    if (poly.size() == 3) {
        draw_textured_triangle(draw_list, tex_id, poly[0], poly[1], poly[2], coordinate_rotation, tint);
        return;
    }
    if (poly.size() == 4) {
        const ImVec2 uv0 = minimap::map_tex_uv(coordinate_rotation, poly[0].map_uv.x, poly[0].map_uv.y);
        const ImVec2 uv1 = minimap::map_tex_uv(coordinate_rotation, poly[1].map_uv.x, poly[1].map_uv.y);
        const ImVec2 uv2 = minimap::map_tex_uv(coordinate_rotation, poly[2].map_uv.x, poly[2].map_uv.y);
        const ImVec2 uv3 = minimap::map_tex_uv(coordinate_rotation, poly[3].map_uv.x, poly[3].map_uv.y);
        draw_list->AddImageQuad(tex_id,
            poly[0].screen, poly[1].screen, poly[2].screen, poly[3].screen,
            uv0, uv1, uv2, uv3, tint);
        return;
    }
    // A fan, which is only correct because the clipper above leaves convex rings.
    for (size_t i = 1; i + 1 < poly.size(); ++i)
        draw_textured_triangle(draw_list, tex_id, poly[0], poly[i], poly[i + 1], coordinate_rotation, tint);
}

// Release every GPU texture a layer cache is holding, then empty it.
//
// This one is a TEMPLATE over the container rather than a plain function, and
// the reason is worth keeping in mind: tile_raster_map::raster_layer is a
// `using` alias for svg_raster_map::raster_layer (tile_raster_map.h:38), so the
// two layer_cache types are the SAME type reached through two namespaces and
// these two definitions always had one signature. Templating lets this header
// release whichever one it is handed without naming a namespace, and costs
// nothing -- two instantiations, both tiny.
template <typename LayerCache>
inline void release_layer_cache(LayerCache& layers) {
    for (auto& entry : layers) {
        if (entry.second.tex_id != ImTextureID_Invalid)
            dxhook::release_texture_id(entry.second.tex_id);
        entry.second = {};
    }
    layers.clear();
}

} // namespace raster_draw
