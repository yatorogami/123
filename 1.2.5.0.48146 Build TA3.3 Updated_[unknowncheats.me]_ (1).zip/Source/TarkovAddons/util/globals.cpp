#include "common.h"
#include "globals.h"

namespace globals {
    std::string get_display_title() {
        return prod_ver.empty() ? prod_name : prod_name + " " + prod_ver;
    }

    std::string version_line() {
        return std::string("Reloaded v") + k_version;
    }
} // namespace globals
