#include "common.h"
#include "utils.h"

namespace utils {
    void get_desktop_resolution(int& horizontal, int& vertical) {
        RECT desktop;
        const HWND hDesktop = GetDesktopWindow();
        GetWindowRect(hDesktop, &desktop);
        horizontal = desktop.right;
        vertical = desktop.bottom;
    }
    std::vector<std::string> split(const std::string& s, char delim) {
        std::vector<std::string> result;
        std::stringstream ss(s);
        std::string item;

        while (getline(ss, item, delim))
        {
            result.push_back(item);
        }

        return result;
    }
} // namespace utils
