#pragma once

#include <fstream>
#include <string>
#include <unordered_map>

class Configuration
{
  public:
    bool load(const std::string& filename);

    std::string get(const std::string& key,
        const std::string& defaultValue = "") const;

    bool empty() const;

  private:
    std::unordered_map<std::string, std::string> values;
};