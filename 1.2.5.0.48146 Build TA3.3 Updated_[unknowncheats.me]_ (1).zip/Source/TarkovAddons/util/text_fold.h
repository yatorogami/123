#pragma once
#include <cstddef>
#include <cstdint>
#include <string>

// UTF-8 case folding, shared by the item search and anything else that compares
// user-typed text against localized game strings.
//
// WHY THIS EXISTS, AND WHY NOT std::tolower
// -----------------------------------------
// std::tolower is the C library's, and the C library sits in the "C" locale
// unless something calls setlocale -- nothing in this project does. So it folds
// A-Z and returns EVERY OTHER BYTE UNCHANGED. That is not a subtle limit, it is
// the whole behaviour: the two arms of a compare built on it are equal only when
// the uppercase and lowercase forms share bytes.
//
// Item names are localized (5947 of 6001 resolve to a real localized name; see
// the "game item db: localized ..." line), so a Russian or Greek player typing
// "бинт" or "ασκός" into the item search matches NOTHING, because the stored
// name is "Бинт" / "Ασκός" and the fold leaves both sides alone. That is the
// bug this fixes, and it is exactly the limitation quest_objective_text.h
// documents for its own ASCII fold -- which it needed to accept, because its
// merge key compares two rows the SAME locale already produced, so they are
// byte-identical. A SEARCH is the opposite case: the two sides come from
// different sources and differ only by case, so the fold is the mechanism
// rather than a bonus.
//
// WHAT IS COVERED, AND WHY NOT MORE
// --------------------------------
// Latin-1 Supplement and Latin Extended-A (the accented vowels of fr/es/de/it/
// pt/pl/cs/tr/ro/hu/sk/sr), Cyrillic (ru/ge), and Greek (jp's transliterations
// aside, this is the alphabet the "gr" locale would need and the one most likely
// to appear in a name). That covers the 19 shipped locales' alphabets.
//
// Full Unicode case folding needs a case table -- SimpleCaseFolding.txt plus
// the special cases (Turkish dotless i, final sigma, Cherokee) -- which is a
// large data dependency to carry for a loot search box. What is here is a
// regular-range fold: for each covered range the uppercase and lowercase blocks
// are the same size and contiguous, so the mapping is an offset, not a table.
//
// The one exception worth naming is U+00DF (sharp s). Its uppercase form is
// "SS", which is two characters, so it cannot be an offset; it is left ALONE.
// Mapping it to "ss" would be right for comparison but would change the LENGTH
// of a needle, and every caller here searches for a substring of the same
// string it built, so a length-changing fold would corrupt offsets. Leaving it
// is the conservative choice and costs one rarely-searched letter.
//
// Nothing here allocates. fold() appends into a caller-provided string, and
// contains_folded() compares two strings in one pass without building either.

namespace text_fold {

    // Decode one UTF-8 sequence starting at `i`.
    //
    // `len` receives the number of BYTES consumed and `cp` the code point.
    // Malformed input consumes exactly one byte and yields U+FFFD, so a
    // truncated or invalid sequence advances instead of looping forever -- the
    // failure mode a naive decoder loop has, and the reason the search index is
    // built from raw bytes elsewhere in this project.
    inline void decode(const std::string& s, std::size_t i, char32_t& cp, std::size_t& len) {
        const auto byte = [&](std::size_t k) {
            return static_cast<unsigned char>(s[k]);
        };
        const unsigned char c = byte(i);
        if (c < 0x80) {
            cp = c;
            len = 1;
            return;
        }
        const std::size_t avail = s.size() - i;
        // Continuation bytes are 10xxxxxx; a lead byte says how many follow.
        if ((c & 0xE0) == 0xC0 && avail >= 2 && (byte(i + 1) & 0xC0) == 0x80) {
            cp = static_cast<char32_t>(((c & 0x1Fu) << 6) | (byte(i + 1) & 0x3Fu));
            len = 2;
            return;
        }
        if ((c & 0xF0) == 0xE0 && avail >= 3 && (byte(i + 1) & 0xC0) == 0x80
            && (byte(i + 2) & 0xC0) == 0x80) {
            cp = static_cast<char32_t>(((c & 0x0Fu) << 12) | ((byte(i + 1) & 0x3Fu) << 6)
                | (byte(i + 2) & 0x3Fu));
            len = 3;
            return;
        }
        if ((c & 0xF8) == 0xF0 && avail >= 4 && (byte(i + 1) & 0xC0) == 0x80
            && (byte(i + 2) & 0xC0) == 0x80 && (byte(i + 3) & 0xC0) == 0x80) {
            cp = static_cast<char32_t>(((c & 0x07u) << 18) | ((byte(i + 1) & 0x3Fu) << 12)
                | ((byte(i + 2) & 0x3Fu) << 6) | (byte(i + 3) & 0x3Fu));
            len = 4;
            return;
        }
        cp = 0xFFFD;
        len = 1;
    }

    inline void encode(const char32_t cp, std::string& out) {
        if (cp < 0x80) {
            out.push_back(static_cast<char>(cp));
        } else if (cp < 0x800) {
            out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else if (cp < 0x10000) {
            out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else {
            out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        }
    }

    // The folded code point for one code point, or the input unchanged when it
    // is outside every covered range.
    //
    // Each range below is a pair of equal-length contiguous blocks, so the fold
    // is `cp + delta` -- and `delta` is 0 outside it, which is what leaves
    // unmapped scripts (and therefore CJK names) byte-identical rather than
    // mangled. That matters: a fold that rewrote bytes it did not understand
    // would make two different CJK names compare equal.
    inline char32_t fold_cp(char32_t cp) {
        if (cp >= U'A' && cp <= U'Z')
            return cp + 0x20;
        // Latin-1 Supplement. U+00D7 (multiplication sign) and U+00F7 (division
        // sign) sit in the middle of this block and are NOT letters: folding
        // them would make "x" equal to the division sign. U+00DF is sharp s,
        // whose uppercase is two characters -- see the header.
        if (cp >= 0xC0 && cp <= 0xDE && cp != 0xD7)
            return cp + 0x20;
    // Latin Extended-A (0100-017F). There is no single offset here and the parity
        // REVERSES twice, which is why this block is spelled out in three spans.
         // Measured against the UnicodeData case pairs:
         //
         //   0100-0137  uppercase at EVEN  index  -> even folds +01, odd is self
         //   0139-0148  uppercase at ODD   index  -> odd  folds +01, even is self
         //   014A-0177  uppercase at EVEN  index  -> even folds +01, odd is self
         //   0179-017E  uppercase at ODD   index  -> odd  folds +01, even is self
         //
         // The first version of this block returned cp + 0x20 for the whole span,
         // which mapped Ā onto Ġ -- a wrong answer for every letter in it. The
         // three unpaired lowercase letters stay themselves, and Ÿ folds to ÿ
         // (U+00FF), which is the one case pair that is not adjacent.
        if (cp >= 0x0100 && cp <= 0x0137)
            return (cp & 0x01u) ? cp : cp + 0x01;
        if (cp >= 0x0139 && cp <= 0x0148)
            return (cp & 0x01u) ? cp + 0x01 : cp;
        if (cp >= 0x014A && cp <= 0x0177)
            return (cp & 0x01u) ? cp : cp + 0x01;
        if (cp >= 0x0179 && cp <= 0x017E)
            return (cp & 0x01u) ? cp + 0x01 : cp;
        if (cp == 0x0138 || cp == 0x0149 || cp == 0x017F) // ĸ ŉ ſ: lowercase, unpaired
            return cp;
        if (cp == 0x0178)                                  // Ÿ -> ÿ
            return 0x00FF;
        // Cyrillic. 0410-042F / 0430-044F are 0x20 apart; 0400-040F / 0450-045F
        // are 0x50 apart. Folding the whole 0400-042F span by 0x20 would map
        // U+0401 (Ё) onto U+0421 (С) -- caught by the harness.
        if (cp >= 0x0410 && cp <= 0x042F)
            return cp + 0x20;
        if (cp >= 0x0400 && cp <= 0x040F)
            return cp + 0x50;
        // Greek. 0386/03AC, 0388-038A/03AD-03AF (0x25), 038C/03CC, and
        // 038E/038F are 0x3F apart while 0391-03A1/03B1-03C1 is 0x20. U+03A2 is
        // unassigned, so the two islands are listed rather than spanned. Two
        // vowels were mis-folded by 0x20 in the first version -- harness again.
        if (cp == 0x0386)
            return 0x03AC;
        if (cp >= 0x0388 && cp <= 0x038A)
            return cp + 0x25;
        if (cp == 0x038C)
            return 0x03CC;
        if (cp == 0x038E || cp == 0x038F)
            return cp + 0x3F;
        if (cp >= 0x0391 && cp <= 0x03A1)
            return cp + 0x20;
        if (cp >= 0x03A3 && cp <= 0x03AB)
            return cp + 0x20;
        return cp;
    }

    // Append the case-folded form of `s` to `out`.
    //
    // APPENDS rather than assigning, because the item-search index builds one
    // string per entry as `name + ' ' + id` and then folds the whole thing.
    inline void fold(const std::string& s, std::string& out) {
        out.reserve(out.size() + s.size());
        std::size_t i = 0;
        while (i < s.size()) {
            char32_t cp = 0;
            std::size_t len = 1;
            decode(s, i, cp, len);
            const char32_t folded = fold_cp(cp);
            // An undecodable byte round-trips unchanged instead of becoming
            // U+FFFD, so folding is IDEMPOTENT over arbitrary input: folding an
            // already-folded string yields the same bytes. The search index
            // relies on that -- build_index() re-folds names that may already
            // have been folded by a previous generation.
            if (cp == 0xFFFD && folded == 0xFFFD) {
                out.push_back(s[i]);
            } else {
                encode(folded, out);
            }
            i += len;
        }
    }

    inline std::string folded(const std::string& s) {
        std::string out;
        fold(s, out);
        return out;
    }

    // Case-insensitive substring test. `needle` is expected to be already folded
    // (the search folds the query once and reuses it across every entry), which
    // is why this does not fold internally: folding per entry would rebuild the
    // needle millions of times.
    inline bool contains_folded(const std::string& haystack_folded, const std::string& needle_folded) {
        return haystack_folded.find(needle_folded) != std::string::npos;
    }

} // namespace text_fold