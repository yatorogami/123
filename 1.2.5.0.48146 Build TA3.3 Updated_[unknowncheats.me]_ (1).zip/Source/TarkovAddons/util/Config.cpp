#include "common.h"
#include "Config.h"

bool Configuration::load(const std::string& filename) {
    values.clear();

    std::ifstream file(filename);
    if (!file)
        return false;

    std::string line;
    while (std::getline(file, line))
    {
        if (line.empty())
            continue;

        auto pos = line.find('=');
        if (pos == std::string::npos)
            continue;

        values[line.substr(0, pos)] = line.substr(pos + 1);
    }

    return true;
}

std::string Configuration::get(const std::string& key,
    const std::string& defaultValue) const {
    auto it = values.find(key);
    return it == values.end() ? defaultValue : it->second;
}

bool Configuration::empty() const {
    return values.empty();
}
