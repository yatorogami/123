#include "common.h"
#include "scan.h"

namespace scan {
    UINT64 find_pattern_internal(const std::string& pattern, const char* module_start, size_t module_size) {
        std::vector<int> needle;
        if (!compile_pattern(pattern, needle))
            return static_cast<UINT64>(-1);

        const size_t n = needle.size();
        if (n == 0 || module_size < n)
            return static_cast<UINT64>(-1);

        for (size_t i = 0; i + n <= module_size; ++i)
        {
            bool match = true;
            for (size_t j = 0; j < n; ++j)
            {
                if (needle[j] < 0)
                    continue;
                if (static_cast<unsigned char>(module_start[i + j]) != static_cast<unsigned char>(needle[j]))
                {
                    match = false;
                    break;
                }
            }
            if (match)
                return i;
        }

        logger::error("Pattern not found: " + pattern);
        return static_cast<UINT64>(-1);
    }
    UINT64 find_pattern(const std::string& pattern, const char* module_start, size_t module_size) {
        const UINT64 res = find_pattern_internal(pattern, module_start, module_size);
        if (res == static_cast<UINT64>(-1))
            return 0;

        logger::debug("Found Pattern: " + pattern);
        return reinterpret_cast<UINT64>(module_start) + res;
    }
    UINT64 find_pattern_xref(const std::string& pattern, const char* module_start, size_t module_size,
        size_t offset, size_t instruction_size) {
        const UINT64 res = find_pattern_internal(pattern, module_start, module_size);
        if (res == static_cast<UINT64>(-1))
            return 0;

        const INT64 location = reinterpret_cast<INT64>(module_start) + static_cast<INT64>(res) + static_cast<INT64>(offset);
        if (location < reinterpret_cast<INT64>(module_start)
            || location > static_cast<INT64>(
                   reinterpret_cast<UINT64>(module_start) + module_size - sizeof(INT32)))
        {
            logger::error("Xref out of bounds: " + pattern);
            return 0;
        }

        const INT64 relative = *reinterpret_cast<int32_t*>(location);
        logger::debug("Found Xref: " + pattern);
        return reinterpret_cast<UINT64>(module_start) + res + static_cast<UINT64>(relative) + instruction_size;
    }
} // namespace scan
