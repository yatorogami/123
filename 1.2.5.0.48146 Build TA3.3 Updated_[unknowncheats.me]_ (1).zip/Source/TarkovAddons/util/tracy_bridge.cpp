#include "common.h"
#include "tracy_bridge.h"

#include <atomic>

// The non-Prod definitions of start/running/client_attached/stop are inline
// no-ops in the header, so this TU only needs a body for the TRACY_ENABLE build.
#ifdef TRACY_ENABLE

namespace tracy::profiler {
namespace {
// Profiler state is process-wide, not per-module: a second caller of start()
// must not spawn a second server thread.
std::atomic<bool> g_started{ false };
} // namespace

bool start() {
    if (g_started.load(std::memory_order_acquire)) return true;
    // StartupProfiler() FIRST, publish g_started SECOND. The order is the whole fix.
    //
    // Under TRACY_MANUAL_LIFETIME every scrap of Tracy's state hangs off a plain
    // (non-atomic) `ProfilerData* s_profilerData`, and GetProfilerData() dereferences
    // it with no check -- the TRACY_ASSERT in front of that deref compiles out under
    // NDEBUG, which both Prod configs define. So the window between "our gate says
    // started" and "s_profilerData is non-null" is a window where any TA_ZONE on any
    // thread is a null dereference, and the window is not narrow: StartupProfiler()
    // spawns worker threads before it returns.
    //
    // It used to be the other way round -- g_started.exchange(true) then
    // StartupProfiler() -- and that killed EscapeFromTarkov.exe on 2026-10-02:
    // pressing "Start Profiler" published the gate, the Application::Update thread
    // built a real tracy::ScopedZone against a null s_profilerData, and the fault
    // was a READ of 0x8 at rva +0x100B03 in tracy::GetProfilerData, on the frame
    // below dxhook::WndProc. That is also the most likely explanation for the older
    // "0xC0000005 EXECUTE at 0x0, frames=0" that tracy_bridge.h blamed on
    // TRACY_CALLSTACK; those notes said outright that no unwound stack placed the
    // fault inside Tracy. Now one does.
    StartupProfiler();
    g_started.store(true, std::memory_order_release);
    return true;
}

void stop() {
    if (!g_started.exchange(false, std::memory_order_acq_rel)) return;
    ShutdownProfiler();
}

bool running() {
    // g_started AND Tracy's own flag, not g_started alone.
    //
    // Tracy sets s_isProfilerStarted as the LAST statement of StartupProfiler() and
    // clears it as the FIRST statement of ShutdownProfiler(), so it is the one flag
    // that cannot be true while s_profilerData is null. Consulting it makes the
    // invariant structural rather than positional -- the reorder in start() is what
    // actually fixed the crash, but it is a statement order, and statement orders do
    // not survive refactors the way a second predicate does.
    //
    // IsProfilerStarted() is a bare atomic load. Do not substitute ZoneIsActive or
    // GetProfiler().IsConnected() here: those dereference the very pointer being
    // guarded (see the note in tracy_bridge.h).
    return g_started.load(std::memory_order_acquire) && tracy::IsProfilerStarted();
}

bool client_attached() {
    // Goes through running() rather than reading g_started itself, so there is one
    // gate in this file instead of two that can drift. ProfilerAvailable() touches
    // the profiler's queue, so it must stay behind the check.
    return running() && ProfilerAvailable();
}

} // namespace tracy::profiler

#endif // TRACY_ENABLE
