#pragma once

#include <string>
#include <vector>

namespace i18n {
    struct language_entry
    {
        std::string code;
        std::string display_name;
    };

    void init();

    const std::string& current_locale();
    void set_locale(const std::string& locale_code);

    const std::vector<language_entry>& supported_languages();
    const std::vector<language_entry>& available_languages();
    void init_menu_languages();

    int locale_to_index(const std::string& code);
    std::string index_to_locale(int index);

    std::string tr(const char* key);
    std::string tr(const std::string& key);
} // namespace i18n