#include "common.h"
#include "linalg.h"

namespace linalg {

    mat4::mat4() {
        std::memset(m, 0, sizeof(m));
        m[0] = m[5] = m[10] = m[15] = 1.f;
    }

    float* mat4::col(int c) { return m + c * 4; }

    const float* mat4::col(int c) const { return m + c * 4; }

    float mat4::at(int r, int c) const { return m[c * 4 + r]; }

    void mat4::set_row(int r, const float v[4]) {
        for (int c = 0; c < 4; ++c) m[c * 4 + r] = v[c];
    }

} // namespace linalg
