#pragma once

// Tracy profiler — runtime bridge.
//
// TRACY_ENABLE is currently defined in all four x64 configurations, including both
// Prod ones (so the shipping build can be profiled; see the vcxproj for the
// enable/revert/restore history). Where it is absent, this header expands to nothing
// at all: Tracy.hpp already compiles every zone macro to an empty statement, so call
// sites need no #ifdef and instrumentation can stay in place.
//
// Compiled in but INERT until tracy::profiler::start() is called: no thread, no
// listening socket, no sampling. "Inert" is doing real work in that sentence and used
// to be an assumption rather than a fact — TRACY_MANUAL_LIFETIME alone does NOT make
// instrumentation inert, it only defers the server. A bare TA_ZONE_N in a shipping
// build dereferences a null s_profilerData and takes the process down. tracy::profiler::Zone
// below is what actually delivers the promise; read its comment before simplifying it.
//
// Context — this is an injected DLL inside someone else's process, which shapes
// two defaults:
//   * TRACY_ONLY_LOCALHOST + TRACY_NO_BROADCAST (vcxproj) bind 127.0.0.1 and
//     skip LAN client discovery. A profiler merely listening is already a
//     fingerprint; one that announces itself on the network is worse.
//   * Starting is an explicit per-session act, never a default.
//
// Usage:
//     #include "../util/tracy_bridge.h"
//     void f() {
//         TA_ZONE();                       // unnamed span
//         TA_ZONE_N("item_db::build");     // named span
//         if (tracy::profiler::client_attached()) { ...expensive probe... }
//     }

#ifdef TRACY_ENABLE
// Every config that defines TRACY_ENABLE must also carry $(ProjectDir)external/tracy on
// the include path, or this include is C1083. The guard still matters: DebugLogModule
// includes this header unconditionally, so in the configs WITHOUT TRACY_ENABLE the
// include below must not be reached — and there the macros degrade to no-ops.
#include "tracy/Tracy.hpp"

#include <cstddef>
#include <cstdint>
#include <optional>
#include <string.h>
#endif

#ifdef TRACY_ENABLE

namespace tracy::profiler {

// Starts the profiler server. Idempotent; returns false when compiled without
// TRACY_ENABLE. Safe to call from module init.
bool start();

// True once start() has taken effect and before shutdown().
bool running();

// True when a Tracy client is actually attached. Use this to skip building
// expensive diagnostic payloads when nobody is listening — ZoneIsActive covers
// the same need for a zone's own arguments.
bool client_attached();

// Stops the profiler server. Primarily for tests and clean shutdown; the
// normal path is to leave it running for the session.
void stop();

// A Tracy zone that is INERT until start() has run.
//
// This wrapper is load-bearing, not cosmetic. TRACY_MANUAL_LIFETIME keeps all of
// Tracy's state behind `ProfilerData* s_profilerData`, which stays null until
// StartupProfiler() runs. tracy::ScopedZone's constructor never checks that: it goes
// straight to tracy::GetToken() -> GetProfilerData() -> `return *s_profilerData;`, and
// the TRACY_ASSERT in front of that deref is compiled out by NDEBUG. So a bare
// ZoneTransientN dereferences null on the very first instrumented call of the
// process — which is how the profiler used to kill the game inside
// ConfigModule::load_config, at the first TA_ZONE_N in the process
// (game_items::build, reached from EspModule's ItemSearchValue::set).
//
// Constructing the real zone only once running() holds is what makes "inert until
// Start Profiler is pressed" true rather than aspirational.
//
// Note that gating on tracy::ZoneIsActive or defining TRACY_ON_DEMAND would NOT fix
// this: those guards evaluate GetProfiler().IsConnected(), which dereferences the very
// same null pointer before they can answer.
class Zone
{
  public:
    Zone(const uint32_t line, const char* file, const char* function, const char* name,
        const size_t name_size) {
        if (!running()) return;
        // TRACY_CALLSTACK is the per-zone callstack DEPTH. It is EXPLICITLY 0 in
        // every TRACY_ENABLE configuration, and that zero is load-bearing: it keeps
        // Tracy's client-side SYMBOLIZER switched off.
        //
        // History, because the reasoning is not guessable from the value. It was
        // undefined until 2026-10-01 and TracyC.h's fallback is also 0, so nothing
        // ran. It was set to 12 to get call chains, and pressing "Start Profiler"
        // then crashed EscapeFromTarkov.exe with 0xC0000005 ACCESS_VIOLATION
        // EXECUTE at address 0 -- a call through a null function pointer -- on the
        // thread the log shows inside the transit Run.MoveNext hook, right after 8
        // C++ exceptions and 4 events of 0x40010006.
        //
        // 0x40010006 is DBG_PRINTEXCEPTION_C, which OutputDebugStringA raises when
        // a debugger is attached, and the only OutputDebugStringA on this path is
        // TracyCallstack.cpp:643 inside SymError() -- the symbolizer's OWN failure
        // reporter. So the symbolizer was failing repeatedly on the thread that
        // died, and TracyProfiler.cpp:4632 gates the entire thing on `depth > 0`.
        //
        // The symbolizer is NOT what killed that process, and this comment used to
        // say it was. It was read that way on the strength of four 0x40010006 events
        // landing on the dying thread; that was inference from fingerprints, and it
        // was wrong.
        //
        // On 2026-10-02 the same shape arrived WITH a stack:
        //     code=0xC0000005  ACCESS_VIOLATION READ of 0x8
        //     faulting rva +0x100B03  ->  tracy::GetProfilerThreadData +0x43
        //     #0 tracy::profiler::Zone::Zone +0x2E7   (the only frame that holds up)
        // and the faulting instruction is
        //     mov rdi, qword ptr [rip+...]   ; rdi = tracy::s_profilerData
        //     add rdi, 8
        //     mov rbx, qword ptr [rdi]       ; <- the READ of 0x8
        // so s_profilerData was NULL: it is allocated by StartupProfiler(), and
        // util/tracy_bridge.cpp's start() published its g_started gate BEFORE calling
        // that. Press "Start Profiler", and any instrumented code on another thread
        // inside the window builds a real tracy::ScopedZone against a null pointer.
        // StartupProfiler() spawns worker threads before returning, so the window is
        // not narrow. Fixed by reordering start(); see tracy_bridge.cpp and
        // tools/tests/test_tracy_start_order.py, whose negative control rejects the
        // old ordering.
        //
        // So the callstacks were never implicated. TRACY_CALLSTACK stays 0 on the
        // original reasoning, which still stands on its own terms -- RtlWalkFrameChain
        // over an unregistered .pdata in a manually mapped, LDR-unlinked DLL is not
        // an input to trust. The two were conflated and the conflation is what made
        // this comment read as a settled explanation.
        //
        // The old EXECUTE-at-0x0 crash remains unexplained. It is a plausible sibling
        // of the null-s_profilerData window -- "the profiler was not ready" once as a
        // READ of 0x8, once as an EXECUTE at 0 -- but that is a shape, not a proof,
        // and it had no frames. Do not let the 2026-10-02 answer absorb it.
        //
        // The zones stay. They are flat timing, which is safe, and they are what
        // makes "where did the frame go" answerable. Only the CHAIN is lost, and
        // the chain is the part that cannot be had in this environment.
        //
        // Do not raise this number without reading the above. If client-side
        // callstacks are wanted here, the route is a SERVER-side capture (ETW /
        // xperf / WPA against the process, which walks kernel-side unwind data and
        // does not care that the module is hidden from the loader), not a bigger
        // number on this line.
        m_zone.emplace(line, file, strlen(file), function, strlen(function), name, name_size,
            TRACY_CALLSTACK, true);
    }

    // Matches the signature ZoneTextV(varname, txt, size) forwards to.
    void Text(const char* text, size_t size) {
        if (m_zone) m_zone->Text(text, size);
    }

  private:
    // ScopedZone is non-copyable and non-movable. std::optional supports that fine —
    // it is only ever constructed, read and destroyed here, never copied or moved.
    std::optional<tracy::ScopedZone> m_zone;
};

} // namespace tracy::profiler

// Named span. Prefer this form: the name is what the flame graph groups by, and
// it costs nothing extra over the unnamed variant.
#define TA_ZONE_N(name) \
    tracy::profiler::Zone ta_zone(TracyLine, TracyFile, TracyFunction, name, strlen(name))

// Span whose name is chosen at RUNTIME from a `const char*` variable, e.g. a caller
// label set by the caller of a shared helper.
//
// WHY THIS EXISTS: a zone named for the FUNCTION cannot attribute a shared helper's cost
// to whichever of its callers is responsible. Measured 2026-10-04 16:34 on
// `skeleton_vis::fireport:get_position` -- 26,101 calls, of which 15,264 came from
// `aimbot::fireport_resolve` and 10,837 (41%) from callers the flat CSV could not name.
// The export has no call tree, so the only two ways to attribute are a runtime name or a
// max_ns-equality test, and the second found no parent sharing the maximum.
//
// The name becomes part of the zone's identity, so each distinct `site` produces its own
// row in the CSV rather than one row with a varying label -- which is what makes it
// groupable. Sites are therefore expected to be a SMALL FIXED SET of literals, not a
// formatted string: a per-call `std::format` here would allocate on the hot path to build
// a zone name, which is the exact mistake `unity.h`'s memo made with
// `maybe_report_native_object_memo` (64.87 s of formatting behind an early return).
//
// `site` is read once, at construction, so a caller changing it afterwards cannot
// retroactively rename a span that is already open.
//
// FIXED 2026-10-04: **`name` was accepted and discarded.** The macro expanded to
// `(site), (site) ? strlen(site) : 0` and never mentioned `name`, so every span
// produced a row named by `site` alone. Two consequences, both observed in
// `+8+transit+crash.tracy`:
//
//   * A row called `unknown` (20.69 s, 400 calls, 51.72 us mean) and a row called
//     `aimbot/gameworld_update` (181.42 s) were both the fireport's `get_position`
//     -- and nothing in the export said so. A reader cannot tell what function
//     those rows belong to, which is the one thing a zone name is for.
//   * Two different instrumented sites sharing a label were indistinguishable.
//
// The row is now `name@site`, or just `name` when `site` is null.
//
// NOT a per-call concatenation. `compose_site` caches the last (name, site) pair
// in a thread_local and reuses the string, so the steady state is two pointer
// compares and a c_str() -- no allocation. That matters because the comment above
// this macro exists precisely to forbid one: a `std::format` per zone to build a
// name is the mistake `unity.h`'s memo made, 64.87 s of it. Sites are a small
// fixed set of literals, so the cache hits on every call after the first.
//
// The composed name is held in a local because `Zone`'s constructor needs it
// twice (pointer and length). Two declarations, not one: composing and
// constructing in a single expression would mean calling `compose_site` twice,
// and the second call could rebuild the thread_local buffer the first pointer
// refers to.
//
// Declares `ta_zname` and `ta_zsite`, deliberately NOT `ta_zone`, so a
// `TA_ZONE_SITE` stays legal next to a `TA_ZONE_N` in the same scope -- the
// property the previous revision of this comment claimed and did not have.
//
// ###########################################################################
// THIS MACRO WAS AN INFINITE LOOP AND IT FROZE THE GAME ON RAID LOAD.        #
// ###########################################################################
//
// It used to expand to
//
//     for (const char* ta_zn = compose_site(...),
//              *ta_zkeep = (tracy::profiler::Zone(...), nullptr);
//          ta_zkeep == nullptr; ta_zkeep = nullptr)
//
// `ta_zkeep` is initialised to `nullptr`, the loop condition is
// `ta_zkeep == nullptr`, and the increment assigns `nullptr` again -- so the
// condition is true on every iteration, forever. The comma operator also threw
// the `Zone` temporary away, so the span opened and closed inside the
// init-statement and covered none of the code it was written to measure.
//
// Consequences, in order of how much they cost:
//
//   * `skeleton_visibility.h:355` puts this directly in front of the managed
//     `get_position` call. So `get_bifacial_position` never returned, so
//     `try_get_fireport_position` never returned, so
//     `AimbotModule::gameworld_update` never returned -- and that runs on the
//     GAME's world-update thread. One frame in, that thread was spinning at
//     100% of a core and the raid never finished loading. The game "stopped".
//   * No stack growth, so no stack-overflow signature, and no log line, so the
//     log just stopped mid-load.
//   * It is NOT a Tracy problem and was never gated on the profiler: the `for`
//     loop spins whether or not `running()` holds, which is why it reproduced
//     identically in sessions with the profiler started and in the one without.
//   * `-u`'s export showed the tell: `get_position@...` at 20 ns -- the empty
//     span from the discarded temporary -- and `frame::AimbotModule::gameworld_update`
//     at 1 completed instance while its enclosing
//     `frame::hk_tarkov_application_update` ran 6,778 times. An unpaired zone
//     begin is dropped from the statistics, so the instance that never returned
//     was invisible rather than reported as a long duration.
//
// The rule this replaces: a diagnostic macro must not introduce control flow.
// A zone is a scoped object; `TA_ZONE_N` is a bare local and so is this.
// `tools/tests/test_zone_site_expansion.py` compiles and runs this expansion,
// asserts it terminates, and has a negative control that compiles the old one
// and asserts it does NOT.
namespace ta_detail {
inline const char* compose_site(const char* name, const char* site) {
    static thread_local std::string buf;
    static thread_local const char* last_name = nullptr;
    static thread_local const char* last_site = nullptr;
    if (name != last_name || site != last_site) {
        buf.assign(name ? name : "");
        if (site && *site) { buf += '@'; buf += site; }
        last_name = name;
        last_site = site;
    }
    return buf.c_str();
}
} // namespace ta_detail

#define TA_ZONE_SITE(name, site)                                                  \
    const char* const ta_zname = ::ta_detail::compose_site((name), (site));       \
    ::tracy::profiler::Zone ta_zsite(TracyLine, TracyFile, TracyFunction,          \
        ta_zname, ::strlen(ta_zname))

// Unnamed span, for leaf sites where the enclosing function name is enough.
#define TA_ZONE() tracy::profiler::Zone ta_zone(TracyLine, TracyFile, TracyFunction, nullptr, 0)

// Attaches text to the enclosing TA_ZONE_N, e.g. which route or template id.
#define TA_ZONE_TEXT(ptr, size) ta_zone.Text(static_cast<const char*>(ptr), static_cast<size_t>(size))

// Cheap per-zone guard. Wrap expensive diagnostic-only work in this so its
// arguments are not evaluated when no client is listening:
//     if (TA_ZONE_IS_ACTIVE) { TA_ZONE_TEXT(expensive_label(), n); }
//
// Deliberately NOT tracy's ZoneIsActive: that macro expands to
// `___tracy_scoped_zone.IsActive()`, and ___tracy_scoped_zone only exists under
// ZoneScoped, never under ZoneTransientN — so it would not even compile at a
// TA_ZONE_N call site. client_attached() is the intended meaning anyway: it
// checks the started flag before touching the profiler queue.
// (TA_FRAME removed: defined in both branches, never called anywhere.)
#define TA_ZONE_IS_ACTIVE tracy::profiler::client_attached()

#else // !TRACY_ENABLE — the configs with the profiler compiled out entirely. Every
      // macro is a no-op and every function returns a constant, so instrumentation
      // can be left at the call sites unconditionally. No Tracy.hpp is included.

namespace tracy::profiler {
inline bool start() { return false; }
inline bool running() { return false; }
inline bool client_attached() { return false; }
inline void stop() {}
} // namespace tracy::profiler

#define TA_ZONE_N(name) do {} while (0)
#define TA_ZONE_SITE(name, site) do {} while (0)
#define TA_ZONE() do {} while (0)
#define TA_ZONE_TEXT(ptr, size) do {} while (0)
#define TA_ZONE_IS_ACTIVE false

#endif // TRACY_ENABLE
