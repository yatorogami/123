#pragma once

#include <cstdint>
#include <string>
#include <unordered_map>

#include <imgui.h>

#include "svg_raster_map.h"

namespace minimap {
    struct map_bounds;
    struct map_view_transform;
} // namespace minimap

namespace tile_raster_map {
    struct tile_bounds
    {
        float min_x = 0.f;
        float max_x = 1.f;
        float min_z = 0.f;
        float max_z = 1.f;
    };

    struct tile_map_params
    {
        std::string map_id;
        std::string layer_slug;
        std::string tile_path_template;
        int tile_size = 256;
        int min_zoom = 1;
        int max_zoom = 6;
        float transform[4]{1.f, 0.f, 0.395f, 0.f};
        int coordinate_rotation = 180;
        tile_bounds bounds{};
    };

    using raster_layer = svg_raster_map::raster_layer;
    using layer_cache = std::unordered_map<std::string, raster_layer>;

    void release_layer_cache(layer_cache& layers);
    void cleanup_placeholder_tiles();
    bool ensure_stitched_layer(layer_cache& cache, const std::string& key, const tile_map_params& params);
    void draw_layer(ImDrawList* draw_list, const raster_layer& layer, const minimap::map_view_transform& view,
        int coordinate_rotation, float opacity_mul, const minimap::map_bounds& floor_bounds);
} // namespace tile_raster_map