#pragma once

#include <string>
#include <vector>
#include <windows.h>

#include "globals.h"
#include "logger.h"

namespace scan {
    // Compile IDA-style "48 89 5C 24 ? ..." pattern.
    // Wildcard = -1. Real 0x00 is a normal match (old code treated 0 as wildcard — broken).
    inline bool compile_pattern(const std::string& pattern, std::vector<int>& out) {
        out.clear();
        if (pattern.size() < 2)
            return false;

        size_t string_index = 0;
        while (string_index < pattern.length())
        {
            while (string_index < pattern.length() && pattern[string_index] == ' ')
                ++string_index;
            if (string_index >= pattern.length())
                break;

            if (pattern[string_index] == '?')
            {
                out.push_back(-1);
                string_index += 1;
                if (string_index < pattern.length() && pattern[string_index] == '?')
                    ++string_index;
                if (string_index < pattern.length() && pattern[string_index] == ' ')
                    ++string_index;
                continue;
            }

            if (string_index + 1 >= pattern.length())
                break;

            const std::string byte_string = pattern.substr(string_index, 2);
            string_index += 2;
            if (string_index < pattern.length() && pattern[string_index] == ' ')
                ++string_index;

            char* end = nullptr;
            const unsigned long value = strtoul(byte_string.c_str(), &end, 16);
            if (end == byte_string.c_str())
                return false;
            out.push_back(static_cast<int>(value & 0xFF));
        }

        return !out.empty();
    }

    // Returns offset from module_start, or (UINT64)-1 if not found.
    UINT64 find_pattern_internal(const std::string& pattern, const char* module_start, size_t module_size);

    // Returns absolute address, or 0 if not found.
    UINT64 find_pattern(const std::string& pattern, const char* module_start, size_t module_size);

    UINT64 find_pattern_xref(const std::string& pattern, const char* module_start, size_t module_size,
        size_t offset, size_t instruction_size);

    inline UINT64 import(std::string name) {
        UINT64 res = reinterpret_cast<UINT64>(GetProcAddress(GetModuleHandleA("GameAssembly.dll"), name.c_str()));
        if (!res)
        {
            logger::error("Import Failed: " + name);
        }
        else
        {
            logger::debug("Imported: " + name);
        }
        return res;
    }

    // ---------------------------------------------------------------------
    //  A self-contained PE export-table reader.
    //
    //  This exists to answer one question that no log can answer directly:
    //  when GetProcAddress() returns null for a name the module's export
    //  table demonstrably contains, is the table wrong or is the API lying?
    //
    //  It is here rather than in il2cpp_offsets.h because it is generic PE
    //  work and scan.h is where PE work lives, and it deliberately calls no
    //  Windows API at all -- no GetProcAddress, no GetModuleHandle, no
    //  VirtualQuery. Everything is read out of the already-mapped image and
    //  bounds-checked against the caller-supplied size, so it cannot fault
    //  and it cannot be intercepted. Those two properties are the entire
    //  point: the only way it can be wrong is if the bytes say so.
    //
    //  Every field is read with a helper that checks the whole access fits
    //  inside [base, base+size) first. A hand-written PE parser that trusts
    //  its own arithmetic is a crash waiting for a malformed image, and the
    //  one caller is a diagnostic running inside a third-party process.
    // ---------------------------------------------------------------------
    struct PeImageView {
        UINT64 base = 0;
        UINT64 size = 0;

        // True when [addr, addr+len) lies inside the image.
        inline bool contains(UINT64 addr, UINT64 len) const {
            if (!base || size == 0 || addr < base)
                return false;
            const UINT64 off = addr - base;
            return off <= size && len <= size - off;
        }

        template <typename T>
        inline const T* at(UINT64 addr) const {
            if (!contains(addr, sizeof(T)))
                return nullptr;
            return reinterpret_cast<const T*>(addr);
        }

        inline bool magic_ok(UINT64 addr, uint16_t expect) const {
            const auto* v = at<uint16_t>(addr);
            return v && *v == expect;
        }
    };

    // What a hand-rolled lookup found, or why it could not answer.
    struct ExportLookup {
        bool  parsed = false;        // the image is a PE and the export dir is inside it
        bool  found = false;         // the name is in the export directory
        bool  forwarded = false;     // found, but the entry is a forwarder string
        UINT64 rva = 0;              // the function RVA (or the forwarder string RVA)
        UINT64 address = 0;          // base + rva, the in-memory body
        UINT32 name_count = 0;       // NumberOfNames, for the report
        UINT32 function_count = 0;   // NumberOfFunctions
        UINT32 ordinal = 0;          // the ordinal the name maps to
        UINT64 export_dir_rva = 0;   // for the report
        UINT32 export_dir_size = 0;
        const char* failure = nullptr; // set when parsed==false
    };

    // Parse the export directory of an already-mapped PE by hand.
    inline ExportLookup find_export_by_hand(const PeImageView& img, const char* name) {
        ExportLookup out;
        if (!img.base || !img.size) {
            out.failure = "no image";
            return out;
        }
        if (!img.magic_ok(img.base, 0x5A4D)) { // 'MZ'
            out.failure = "no MZ at base";
            return out;
        }

        const auto* dos = img.at<IMAGE_DOS_HEADER>(img.base);
        if (!dos || dos->e_lfanew <= 0) {
            out.failure = "bad e_lfanew";
            return out;
        }

        const UINT64 nt = img.base + static_cast<UINT64>(dos->e_lfanew);
        if (!img.magic_ok(nt, 0x4550)) { // 'PE\0\0'
            out.failure = "no PE signature";
            return out;
        }

        const auto* file = img.at<IMAGE_FILE_HEADER>(nt + 4);
        if (!file) {
            out.failure = "no file header";
            return out;
        }

        const UINT64 opt = nt + 4 + sizeof(IMAGE_FILE_HEADER);
        const auto* magic = img.at<uint16_t>(opt);
        if (!magic) {
            out.failure = "no optional header";
            return out;
        }

        // DataDirectory[0] sits at a different offset in PE32 and PE32+, and
        // getting that wrong is the classic way a hand parser reads garbage
        // that happens to look plausible. So branch on the magic rather than
        // assuming x64.
        UINT64 dir_offset = 0;
        if (*magic == 0x20B)      dir_offset = opt + 112; // PE32+
        else if (*magic == 0x10B) dir_offset = opt + 96;  // PE32
        else {
            out.failure = "neither PE32 nor PE32+";
            return out;
        }

        const auto* dir = img.at<IMAGE_DATA_DIRECTORY>(dir_offset);
        if (!dir || dir->VirtualAddress == 0) {
            out.failure = "no export data directory";
            return out;
        }

        out.export_dir_rva = dir->VirtualAddress;
        out.export_dir_size = dir->Size;

        const UINT64 edir = img.base + dir->VirtualAddress;
        const auto* exp = img.at<IMAGE_EXPORT_DIRECTORY>(edir);
        if (!exp) {
            out.failure = "export directory outside image";
            return out;
        }
        out.parsed = true;
        out.name_count = exp->NumberOfNames;
        out.function_count = exp->NumberOfFunctions;

        if (!name || !*name || exp->NumberOfNames == 0)
            return out;

        // Bound the count by what the image could possibly hold, so a corrupt
        // NumberOfNames cannot walk us off the end before the per-access
        // checks notice.
        const UINT64 names_table = img.base + exp->AddressOfNames;
        const UINT64 ords_table = img.base + exp->AddressOfNameOrdinals;
        const UINT64 funcs_table = img.base + exp->AddressOfFunctions;
        const size_t name_budget = img.size / sizeof(uint32_t);
        if (name_budget == 0)
            return out;

        const UINT64 limit = exp->NumberOfNames < name_budget
            ? exp->NumberOfNames : static_cast<UINT32>(name_budget);

        for (UINT32 i = 0; i < limit; ++i) {
            const auto* name_rva = img.at<uint32_t>(names_table + i * sizeof(uint32_t));
            if (!name_rva)
                break;
            const UINT64 name_addr = img.base + *name_rva;
            if (!img.contains(name_addr, 1))
                continue;

            // Compare in place, bounded by the image. strcmp is not used: it
            // would walk off the end if the image is truncated mid-name.
            size_t len = 0;
            const char* a = reinterpret_cast<const char*>(name_addr);
            const char* b = name;
            while (img.contains(name_addr + len, 1) && a[len] && b[len]) {
                if (a[len] != b[len])
                    break;
                ++len;
            }
            if (!img.contains(name_addr + len, 1) || a[len] != b[len])
                continue;

            // Exact match (b ended, and a ended too).
            const auto* ord = img.at<uint16_t>(ords_table + i * sizeof(uint16_t));
            if (!ord)
                break;
            out.ordinal = *ord;
            if (out.ordinal >= exp->NumberOfFunctions)
                break; // corrupt ordinal table; do not index with it

            const auto* func_rva = img.at<uint32_t>(funcs_table + out.ordinal * sizeof(uint32_t));
            if (!func_rva)
                break;
            out.found = true;
            out.rva = *func_rva;

            // A forwarder is an RVA that points back into the export
            // directory, i.e. the "name" is the string ", othermodule!sym".
            // It is NOT a function address, and returning it as one would be
            // the kind of bug this file exists to prevent.
            if (out.rva >= dir->VirtualAddress &&
                out.rva < dir->VirtualAddress + dir->Size) {
                out.forwarded = true;
            }
            out.address = img.base + out.rva;
            return out;
        }

        return out;
    }

    // One-line human summary for a failed export lookup. Kept next to the
    // parser so the two cannot describe different things.
    inline std::string describe_export_lookup(const ExportLookup& e, const char* wanted) {
        char buf[320];
        if (!e.parsed) {
            _snprintf_s(buf, sizeof(buf), _TRUNCATE,
                "hand-parse FAILED (%s) for \"%s\"", e.failure ? e.failure : "?", wanted ? wanted : "?");
            return buf;
        }
        if (!e.found) {
            _snprintf_s(buf, sizeof(buf), _TRUNCATE,
                "hand-parse: \"%s\" ABSENT from %u exported names (rva 0x%llX, %u bytes)",
                wanted ? wanted : "?", e.name_count,
                static_cast<unsigned long long>(e.export_dir_rva), e.export_dir_size);
            return buf;
        }
        _snprintf_s(buf, sizeof(buf), _TRUNCATE,
            "hand-parse: \"%s\" FOUND ord=%u rva=0x%llX%s (%u names)",
            wanted ? wanted : "?", e.ordinal,
            static_cast<unsigned long long>(e.rva),
            e.forwarded ? " FORWARDER, not an address" : "",
            e.name_count);
        return buf;
    }

    // Follow E9 rel32 / FF 25 jmp [rip+disp] export stubs to the real body.
    inline UINT64 follow_export_thunk(UINT64 addr, UINT64 module_base, size_t module_size, int max_hops = 4) {
        if (!addr || !module_base || module_size == 0)
            return addr;

        const UINT64 module_end = module_base + module_size;
        UINT64 cur = addr;
        for (int hop = 0; hop < max_hops; ++hop)
        {
            if (cur < module_base || cur + 6 > module_end)
                break;

            const auto* b = reinterpret_cast<const uint8_t*>(cur);
            // jmp rel32
            if (b[0] == 0xE9)
            {
                const int32_t rel = *reinterpret_cast<const int32_t*>(b + 1);
                cur = cur + 5 + static_cast<int64_t>(rel);
                continue;
            }
            // jmp qword ptr [rip+disp32]
            if (b[0] == 0xFF && b[1] == 0x25)
            {
                const int32_t disp = *reinterpret_cast<const int32_t*>(b + 2);
                const UINT64 slot = cur + 6 + static_cast<int64_t>(disp);
                if (slot < module_base || slot + 8 > module_end)
                    break;
                const UINT64 target = *reinterpret_cast<const UINT64*>(slot);
                if (target < module_base || target >= module_end)
                    break;
                cur = target;
                continue;
            }
            break;
        }
        return cur;
    }
} // namespace scan
