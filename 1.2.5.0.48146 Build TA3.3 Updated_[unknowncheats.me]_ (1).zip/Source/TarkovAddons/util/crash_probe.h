#pragma once

// STANDING DIAGNOSTIC -- do not remove.
//
// A crash inside this DLL leaves no evidence in tarkovaddons_log.txt beyond the
// last line that happened to be written. That leaves the crash site unrecoverable
// by inspection.
//
// WER WAS DISABLED on this machine (HKLM\...\Windows Error Reporting\Disabled = 1),
// which is why this probe was for weeks the only post-mortem artefact available.
// That premise is now STALE and is corrected here rather than left to rot: WER was
// re-enabled on 2026-10-03 and immediately paid for itself by naming the faulting
// module and offset of a crash this file had been swallowing for a month. But WER
// reports the faulting MODULE, the fault OFFSET and the THREAD -- it does not carry
// EXCEPTION_RECORD::ExceptionInformation[1], the address that was actually
// unreadable or unwritable. That single field is the whole difference between
// "somewhere in here" and a diagnosis, and it is the field this probe exists to
// print. So WER coming back does not retire the probe, it moves the weight onto it.
//
// SECOND STALE PREMISE, corrected 2026-10-04. This file also said "There is still
// no minidump either: no LocalDumps key is set, so %LOCALAPPDATA%\CrashDumps
// does not even exist." That was wrong, and wrong for a while:
//
//   HKLM\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps\EscapeFromTarkov.exe
//     DumpFolder = C:\Users\Xeon\AppData\Local\CrashDumps   DumpType = 1 (full)   DumpCount = 10
//
// with seven game dumps on disk dated 2026-10-03 19:10 onward. Full dumps, not
// minidumps.
//
// This matters more than a tidied comment. The premise is what made this file
// argue for itself as the primary post-mortem artefact, and it is not one. A dump
// carries every thread's registers and stack, the module list, AND -- the part
// that decides cases -- the process's live globals at fault time. This probe
// cannot print a register, cannot see another thread, and cannot resolve a
// pointer that was cached in .bss.
//
// Concretely, on 2026-10-04 21:24:50 this probe printed NOTHING for the crash
// that killed the process (see the note on g_reported_code), and the diagnosis
// came out of EscapeFromTarkov.exe.27516.dmp in one command: 0xC0000005,
// operation 8, execute at 0x0, thread 26620, and an unwind through
// unity::camera_fov. Nothing in the log could have produced that. The dump was
// there the whole time.
//
// So the honest ordering for the next crash is: READ THE DUMP FIRST. Use this
// file for what it is uniquely good at -- naming a fault the game's own logging
// never mentions, and surviving the cases where no dump is written (WER absent,
// DumpCount exhausted, or a fault handled before the OS sees it).
//
// It was written to find one specific null-write crash (see AGENTS_TODO.md §0)
// and has outgrown it. It stays because this project builds no standalone
// executable to debug from: there is no harness that can re-run a crash on
// demand, no test that reproduces one, and no debugger attached to a live raid.
// A fault here happens once, inside a third-party process we do not control,
// and dies with the process. This VEH is one of the very few mechanisms that
// can still say anything about it afterwards. Deleting a working diagnostic
// because the crash that justified it is fixed throws away the only tool
// available for the next one.
//
// ---------------------------------------------------------------------------
// WHY IT WAS REWRITTEN -- 2026-09-30 23:24:06
// ---------------------------------------------------------------------------
//
// The previous version classified 0xE06D7363 (an MSVC C++ exception) as
// "routine, do not report", counted it in g_routine_count, and returned
// EXCEPTION_CONTINUE_SEARCH. That reasoning is correct in general -- Unity,
// IL2CPP and the CRT throw constantly and handle it themselves -- and it fixed
// a real earlier bug, where a one-shot latch was spent on a throw the game
// caught two seconds later and the probe then stayed silent through the fault
// that actually killed the process.
//
// But it has a dead end at its core, and this build hit it. Three crashes in
// one evening had code 0xE06D7363, flags 0x81 (EXCEPTION_NONCONTINUABLE), on
// the main thread, thrown from msvcp140. The probe counted all three, printed
// nothing, and the process died. The safety net could not help: the suppressed
// count was only ever printed from INSIDE the fatal branch, so a suppressed
// exception that was itself the crash can never be revealed. Zero CRASH lines
// in the log was not evidence of a clean run; it was the filter working as
// designed against the one case that mattered.
//
// A vectored handler fundamentally cannot know whether a throw will be caught.
// Nothing available at raise time settles it. So this version stops trying to
// decide in the handler, and splits the two questions instead:
//
//   CAPTURE happens for every exception, always, in a lock-free ring. It does
//   no I/O, takes no lock, allocates nothing, and cannot block. A C++ throw
//   costs one ring write. Nothing is discarded, so nothing is lost.
//
//   REPORT happens only where the outcome is already known, and those are the
//   only places it happens:
//     - a VEH sees a code that cannot be continued from (an access violation,
//       a fastfail, a stack overflow) -- the process is dying now;
//     - std::terminate is called -- a C++ exception was NOT caught, and this
//       is the definitive signal the VEH does not have;
//     - SetUnhandledExceptionFilter is reached -- unhandled SEH that is not a
//       C++ exception.
//   Each of those prints the ring, so a fatal event is always accompanied by
//   the suppressed throws that led to it. The net that could not fire now
//   fires.
//
// Every report path then returns, or CHAINS to whatever handler it replaced.
// The probe never changes whether or how the process dies. That is the one
// property that must not regress: a diagnostic that alters the failure is
// worse than no diagnostic, because it also destroys the evidence.
//
// "Chains" is the load-bearing word, and it was misunderstood for a month.
// verify_handlers() used to detect displacement and deliberately not repair it,
// on the documented grounds that re-installing would suppress Battlestate's
// crash dialog and minidump. That treats the slot as a swap. It is not: both
// handlers call g_prev_uef / g_prev_terminate after writing their report, so a
// displaced reporter is demoted to second, not removed. The probe now re-asserts
// unconditionally, and the invariant above still holds -- see the note above
// verify_handlers() for the full correction.
//
// The report path deliberately does NOT use logger::crash. logger.cpp records
// that the 20:56:06 access violation faulted inside
// std::basic_filebuf<char>::_Endwrite, reached from the ESP draw thread -- the
// signature of a filebuf whose handle is gone while a write is still dispatched
// through it. The logger allocates a std::ofstream per call and shares it
// across threads, so calling it from a fault context is calling the thing that
// has already crashed once. This probe therefore keeps its own handle, opened
// once at install, and writes with WriteFile + FlushFileBuffers into a stack
// buffer. No iostreams, no allocation, no shared state, no locks.
//
// The RVAs resolve against out/<config>/TarkovAddons.map, written by the same
// link that produced the DLL, so a reported RVA and a .map line always describe
// the same build. The arming line records the build stamp for exactly this
// reason: a plausible symbol for the wrong instruction is worse than none.
//
// ---------------------------------------------------------------------------
// WHY IT WAS REWRITTEN AGAIN -- 2026-10-03 10:35:14
// ---------------------------------------------------------------------------
//
// WER came back, caught a crash for the first time in a month, and the crash
// turned out to be THIS FILE. Not near it, not adjacent to it -- inside it:
//
//     ExceptionCode   0xC0000005 (ACCESS_VIOLATION)
//     ExceptionAddress TarkovAddons.dll + 0x50DA1   (WER: fault offset
//                     0x7FF866C60DA1, module "unknown" because of the manual
//                     map, base 0x7FF866C10000 per this file's own arming line)
//     faulting thread 0x4A30 = 18992, the process MAIN thread
//
// 0x50DA1 resolves, via the .map of the same link, to fill_event+0x41, and the
// six bytes at that offset in the deployed DLL are:
//
//     ff 15 19 63 26 00      call qword ptr [rip+0x266319]
//
// whose target is RVA 0x2B70C0, which the same .map names __imp_GetCurrentThreadId.
// In the build that crashed, fill_event was reachable from record(), record() from
// handler(), and handler() is this file's vectored exception handler. So the
// process died executing GetCurrentThreadId() INSIDE THE VEH, on the main thread,
// five seconds after boot. (That build's fill_event no longer exists: it is split
// below into fill_head and fill_frames, and the call that killed it is gone.)
//
// That explains "crash_probe never triggers" completely, and the explanation is
// worse than the probe being blind:
//
//   1. handler() called record() -- and therefore fill_event() -- BEFORE it
//      called report_fatal(). The capture is not a passive prelude to the report;
//      on this path it is what runs first, and it is where we died.
//   2. A fault inside a vectored exception handler is not catchable. Windows
//      does not fall through to the next VEH, does not look for a __except, does
//      not call SetUnhandledExceptionFilter and does not call std::terminate. It
//      terminates the process on the spot. There is no SEH guard on this path
//      (there never was one), so nothing could have survived it.
//   3. So every fatal fault on a stack-starved thread was destroyed BY the probe,
//      silently, and the log's last line became the last thing that ever got
//      written. "No CRASH lines in the log" was not evidence of a clean run.
//
// The stack arithmetic says why GetCurrentThreadId() faulted. fill_event's own
// prologue is three pushes and `sub rsp, 0x80` -- 152 bytes below entry RSP. Its
// last successful store is [rsp+0x78], i.e. entry-32; the faulting call pushes
// its return address at entry-160. Both are below entry RSP and the first works
// while the second does not, so under 160 bytes of stack were left on that thread.
// On x64 a `call [mem]` pushes the return address BEFORE loading its target, so
// the push is what faulted: this was not a corrupt IAT slot, and the tid call was
// an innocent bystander standing at the end of a 152-byte prologue that a thread
// with no stack could not afford. GetCurrentThreadId() was working fine -- it is
// called on every single log line by logger.cpp:82.
//
// The outer exception was therefore almost certainly something the probe never
// got to name, on a thread that had already exhausted its stack. It is still
// unknown, and it cannot be recovered from the WER record because WER does not
// carry ExceptionInformation[1]. Which is the field this probe prints first.
//
// The fix is ordering and containment, not cleverness:
//
//   - The cheap half of a capture runs first and unconditionally: the record
//     fields, no import call, no stack walk, about twenty bytes of stack.
//   - The expensive half -- the tid and the frame scan -- runs afterwards inside
//     an SEH guard, where a fault is contained and reported as a missing-frames
//     note instead of killing the process.
//   - The report runs after that, so it runs whether or not the enrichment
//     survived, and it emits its header line before anything that could fail.
//   - emit()'s 1 KB line buffer moves off the stack onto a single static buffer.
//     g_emitting already serialises emit(), so the buffer needs no lock, and a
//     1 KB stack frame is unusable on the thread that needs the report most.
//
// The property that must not regress is unchanged in substance: this stays
// read-only on every path, a real fault is never consumed, and it cannot alter
// whether or how the process dies. There is exactly one deliberate exception to
// "CONTINUE_SEARCH throughout", added 2026-10-10 and bounded: while a debugger is
// attached, the two string-carrying debugger print codes are consumed with
// EXCEPTION_CONTINUE_EXECUTION (see is_debugger_signalled). Survival cannot
// change from it -- those codes are not faults, and on neither measured delivery
// model (see the gate comment at is_debugger_signalled) does the consumption
// decide anyone's fate: with no debugger the unhandled print raise is absorbed
// by kernel32's own frame handler, and with a debug port the kernel converts the
// raise into a debug STRING event before any in-process handler sees it. On a
// model where a print raise does go unhandled to a debugger, the consumption
// replaces "the debugger is asked a second time and stops" with "execution
// carries on". That is what makes the guard above legal to add -- catching a
// fault that would otherwise have killed the process does not change the
// outcome, because the outcome was always going to be that the process dies.

#include <windows.h>
#include <atomic>
#include <cstdarg>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <exception>
#include <format>
#include <string>

#include "logger.h"
#include "../../shared/module_paths.h"

// IMAGE_DEBUG_RSDS_HEADER is not declared by <windows.h> -- it comes from dbghelp.h or the
// CRT headers, and depending on either just to read four fields out of our own image would be
// a heavy include for a small need. The layout is what the linker writes and has been stable
// since CodeView existed. Guarded so a future header that does define it cannot collide.
#ifndef IMAGE_DEBUG_RSDS_HEADER
typedef struct _IMAGE_DEBUG_RSDS_HEADER {
    DWORD Signature;
    GUID  Guid;
    DWORD Age;
    CHAR  PdbFileName[1];
} IMAGE_DEBUG_RSDS_HEADER;
#endif
#ifndef IMAGE_DEBUG_RSDS_SIGNATURE
#define IMAGE_DEBUG_RSDS_SIGNATURE 0x53445352 // 'RSDS'
#endif

namespace crash_probe {
    namespace {
        // Words of stack to scan for return addresses. Enough to walk out of a
        // few nested calls without spending long in a fault context.
        //
        // 2048 words = 16 KB as of 2026-10-09. The previous 512 (4 KB) was
        // widened once for a throw chain and then left there, and 2026-10-09
        // is what that costs:
        //
        //   crash #2, 18:49, render thread. The probe reported SIX frames, all
        //   in GameAssembly/UnityPlayer/MSVCP140/ucrtbase/dxgi, and none of ours
        //   -- which reads as "our code is not involved". It was: the minidump's
        //   full stack holds 44 words in our image, the innermost six frames
        //   deep, and the real chain was dxhook::dxPresent11 -> draw_imgui ->
        //   menu::draw -> ModuleManager::apply -> EspModule::draw_overlay ->
        //   eft_api::resolve_esp_camera. The first of those sits at rsp+0x18E8,
        //   roughly 6.4 KB down -- past where a 4 KB scan had already stopped.
        //
        //   So the probe did not under-report our frames because it could not
        //   see them. It stopped, and then spent its 12-frame budget on the
        //   innermost foreign frames so that nothing of ours was left to print.
        //   The frame that would have named the crash was never reached.
        //
        // Too deep is harmless: every word is VirtualQuery-gated before it is
        // read (see the note on readable() in fill_frames), so the scan stops
        // at the first unmapped page rather than faulting, and __except is not
        // what makes it safe on the VEH path.
        constexpr int kStackWords = 2048;
        constexpr int kMaxFrames = 24;

        // The ring. Sized so that a whole raid's worth of routine throws cannot
        // scroll the interesting one out: a throw is a few tens of microseconds
        // and frames are ~2 Hz, so 24 entries covers far more than any realistic
        // gap between a cause and its consequence.
        constexpr int kRing = 24;
        constexpr int kFramesPerEvent = 24;
        // OUR frames, collected on a budget of their own, independent of
        // kFramesPerEvent.
        //
        // This is the part that fixes 2026-10-09 rather than mitigating it.
        // The general frame list fills innermost-first, and on a stack that
        // begins in the game's IL2CPP runtime the budget is spent on foreign
        // frames that cannot be symbolized against our .map -- which is how
        // "44 words in our image" became "no frames of ours in the report".
        // A frame in GameAssembly tells a reader almost nothing; a frame in
        // TarkovAddons.dll resolves to a function name. So ours are collected
        // at any depth the scan reaches, and reported separately with their
        // own slot offsets, regardless of what the general list did.
        constexpr int kOurFrames = 12;
        constexpr int kLineMax = 1024;

        // How many of the newest captured events get their frames listed in
        // full. Three is enough to see a repeating signature and to name the
        // call site, without turning a 3000-deep burst into 36000 lines.
        constexpr int kDetailedEvents = 3;

        // Longest debug-output string echoed from a DBG_PRINTEXCEPTION_C event.
        //
        // 2026-10-05 23:45:06, pid 27056: the session ended with 5,476 of them,
        // the second-largest code in the histogram behind nothing, and all 5,476
        // at one address (KERNELBASE+0xC41CA). The histogram says how many and
        // the histogram is the whole of what the file had to say about them: a
        // count with no content, for the second most frequent thing that
        // happened in the session. See emit_debug_string().
        constexpr int kMaxDebugString = 256;

    // How often tick_memory() samples. 15 s: long enough that the log stays
    // readable over a 45-minute raid (180 lines), short enough that a growth
    // rate is a rate rather than an anecdote.
    constexpr ULONGLONG kMemoryTickIntervalMs = 15000;

        // Base and size of THIS module, captured once at install time so the
        // handler does no module walking of its own while the process faults.
        const std::byte* g_base = nullptr;
        uintptr_t g_size = 0;
        std::atomic<bool> g_installed{ false };

        // --- per-code histogram ---------------------------------------------
        //
        // A count for every exception seen, for every code, printed only when something
        // fatal happens. This is the gap 5.11 named: the ring holds the last 24 events
        // and only when one of them is a reportable fault, while 0x80000003 (BREAKPOINT)
        // and 0x80000004 (SINGLE_STEP) are deliberately never reported. So on
        // 2026-10-02 the user saw a "breakpoint encountered" warning, the game did not
        // die, and the log could neither confirm nor refute it -- there was no total
        // anywhere. A user-visible event with no instrumentation behind it is the worst
        // kind: it invites a guess.
        //
        // These make the guess unnecessary. A session that ends cleanly still cannot
        // print them -- no clean-exit hook survives a hard kill -- but the session that
        // CRASHES prints its whole history, which is when it is wanted. Only codes
        // actually seen are listed, so an uneventful raid costs nothing.
        //
        // 16 slots, open-addressed by the code's hash: each code owns its own slot, so
        // two different codes never share one.
        //
        // The first version hashed into 8 slots and kept `fetch_or(code)`, treating a
        // slot as a SET of codes. That is wrong, and it was wrong VISIBLY, on the first
        // real log:
        //     0xE06D7363 ?/?/?/?/?/?/?/?/?/?/?/?/?/?/?/?/? (merged slot) x7
        //     0xC000070E ?/?/?/?/?/?/?/? (merged slot)              x29
        // Two codes in one slot OR to a value whose individual bits are not codes, so the
        // printer could only say "?". The counts were right; the naming was noise, and the
        // naming is the whole point of a histogram.
        constexpr int kCodeSlots = 16;
        std::atomic<uint32_t> g_code[kCodeSlots]{};        // 0 = empty, else the code
        std::atomic<uint32_t> g_code_count[kCodeSlots]{};
        std::atomic<uint32_t> g_code_total{};

        // Knuth multiplicative hash, masked to the table.
        inline size_t code_slot(const uint32_t code) { return (code * 2654435761u) >> 28; }

        inline const char* code_name(const uint32_t code) {
            switch (code) {
            case 0xC0000005: return "ACCESS_VIOLATION";
            case 0xC000070E: return "THREADPOOL_FREE_LIBRARY_ON_COMPLETION_FAILED";
            case 0xC000001D: return "ILLEGAL_INSTRUCTION";
            case 0xC0000409: return "FAST_FAIL/stack-cookie";
            case 0xC0000374: return "HEAP_CORRUPTION";
            case 0xC00000FD: return "STACK_OVERFLOW";
            case 0xC0000602: return "FAIL_FAST";
            case 0xE06D7363: return "C++ exception";
            case 0x80000003: return "BREAKPOINT";
            case 0x80000004: return "SINGLE_STEP";
            case 0x40010006: return "DBG_PRINTEXCEPTION_C";
            case 0x4001000A: return "DBG_PRINTEXCEPTION_WIDE_C";
            // 0x40010007 was named DBG_PRINTEXCEPTION_STR_C here until
            // 2026-10-10; winnt.h has never defined that name for any value.
            // DBG_RIPEXCEPTION is the documented one.
            case 0x40010007: return "DBG_RIPEXCEPTION";
            default: return "?";
            }
        }

        // Bump the counter for `code`.
        //
        // Lock-free by necessity: this runs inside the vectored exception handler, and a
        // lock taken there can deadlock against whatever already held it. Hence an
        // open-addressed insert with compare_exchange and linear probing -- not a mutex,
        // and not an in-place increment of a shared word.
        inline void count_code(const EXCEPTION_RECORD* rec) {
            if (!rec) return;
            const uint32_t code = rec->ExceptionCode;
            g_code_total.fetch_add(1, std::memory_order_relaxed);
            const size_t home = code_slot(code);
            for (size_t i = 0; i < kCodeSlots; ++i) {
                const size_t slot = (home + i) & (kCodeSlots - 1);
                const uint32_t cur = g_code[slot].load(std::memory_order_relaxed);
                if (cur == code) {                       // already registered here
                    g_code_count[slot].fetch_add(1, std::memory_order_relaxed);
                    return;
                }
                if (cur == 0) {                          // claim it, then count
                    uint32_t expected = 0;
                    if (g_code[slot].compare_exchange_strong(expected, code,
                            std::memory_order_acq_rel, std::memory_order_relaxed)) {
                        g_code_count[slot].fetch_add(1, std::memory_order_relaxed);
                        return;
                    }
                    if (expected == code)                 // lost the race to the same code
                        g_code_count[slot].fetch_add(1, std::memory_order_relaxed);
                    // else: a different code took the slot between our load and the CAS.
                    // Keep probing rather than dropping the count.
                    continue;
                }
            }
            // Table full: 16 distinct exception codes, which no process has produced. The
            // event is still counted in g_code_total, and emit_code_histogram() reports
            // the shortfall, so the two numbers disagree visibly instead of silently.
        }

        // Latches. One per report path, so a fault raised *while reporting*
        // cannot recurse until the stack runs out. They are per-path rather
        // than global because a VEH report and a terminate report are different
        // events and either may legitimately be the first to fire.
        //
        // 2026-10-04: `g_fatal_reported` was ONE bool shared by both the
        // vectored path and the unhandled-filter path -- the exact opposite of
        // what the comment above says it is for. The vectored path reports on
        // `immediately_fatal(code)`, and 0xC0000005 is on that list, so the
        // first access violation of a session spent the latch, including the
        // ones the game handles and continues from, which is most of them.
        //
        // Measured cost, 2026-10-04 21:24:50, pid 27516: a HANDLED first-chance
        // AV at 21:14:37 printed "FATAL (vectored handler)" and took the latch.
        // Ten minutes later the process died of a real one -- execute at 0x0 in
        // unity::camera_fov -- and this probe printed NOTHING, because
        // report_fatal() returned on the spent latch. The dump existed; the log
        // record did not. That is the entire reason that crash took an hour to
        // attribute, and the reason this log's two "FATAL" blocks were both
        // first-chance noise while the one death that mattered had no block.
        //
        // Replaced with duplicate-fault suppression keyed on (code, address): a
        // fault loop at one site still cannot flood the log, and a genuinely
        // different fault later is reported instead of being swallowed. The
        // compare-then-store below is deliberately not a CAS -- two threads
        // faulting simultaneously can both pass, and one duplicated report is a
        // far better outcome than the silence this replaces.
        std::atomic<uint32_t> g_reported_code{ 0 };
        std::atomic<uintptr_t> g_reported_addr{ 0 };

        // A SECOND latch, for confirmed reports only, and the reason one is not
        // enough is that `already_reported` cannot tell two different things apart:
        //
        //   (a) the same fault, seen twice by the SAME observer  -> a loop, suppress it
        //   (b) the same fault, seen by a FIRST-CHANCE observer and then by the
        //       unhandled filter, where it is no longer a maybe            -> REPORT IT
        //
        // (b) is not a duplicate. The vectored handler runs on the fault as it
        // happens and cannot know whether anything will catch it; the unhandled
        // filter runs when the answer is known. Keying both on one (code, address)
        // collapses them, and 2026-10-05 23:45:06 is what that costs:
        //
        //     0xC0000005 EXECUTE at 0x00000254C65C10A0, tid 27320
        //
        // The vectored handler reported it. Twenty milliseconds later the process
        // died of it, the unhandled filter ran, `already_reported` matched on
        // (0xC0000005, 0x254C65C10A0), and report_fatal returned having printed
        // NOTHING. The log's last words about the death were the two unconditional
        // `PROCESS DYING` lines and then silence -- no ring, no histogram, and no
        // frame list for the event that actually killed the process. That is the
        // same defect the kMaxFirstChanceReports cap was removed to fix, and the
        // comment on that cap states the rule this latch exists to keep:
        //
        //   "Confirmed reports are NEVER subject to this cap. That asymmetry is the
        //    whole point: the cap exists to stop unverified noise from burying the
        //    one report that matters, so it must not be able to bury it."
        //
        // The dedup is that same burying, one gate later. Two latches, one per
        // observer class: first-chance noise stays suppressed, and the confirmed
        // report always gets its own block even when the fault repeats.
        std::atomic<uint32_t> g_confirmed_code{ 0 };
        std::atomic<uintptr_t> g_confirmed_addr{ 0 };
        // The old single latch was doing two jobs at once: loop suppression AND
        // flood protection. Removing it fixes the silence but leaves the flood,
        // because "distinct address" is not "rare" -- a game that faults in a loop
        // walks through addresses. So first-chance reports are capped.
        //
        // Confirmed reports are NEVER subject to this cap. That asymmetry is the
        // whole point: the cap exists to stop unverified noise from burying the
        // one report that matters, so it must not be able to bury it.
        constexpr uint32_t kMaxFirstChanceReports = 8;
        std::atomic<uint32_t> g_first_chance_reports{ 0 };
        std::atomic<bool> g_first_chance_capped{ false };
        std::atomic<bool> g_terminate_reported{ false };
        std::atomic_flag g_emitting = ATOMIC_FLAG_INIT;

        // Monotonic event counter, and the ring itself.
        std::atomic<uint32_t> g_seq{ 0 };

        struct Event {
            // 0 = empty, 1 = being written, 2 = complete. A reader that finds
            // anything but 2 skips the slot. Under concurrent exceptions two
            // threads can still land in the same slot, so a record may be torn
            // or overwritten -- acceptable for a diagnostic, and recorded here
            // rather than papered over with a lock that could deadlock in a
            // fault context.
            std::atomic<uint32_t> ready{ 0 };
            uint32_t seq = 0;
            uint32_t code = 0;
            uint32_t flags = 0;
            uint32_t tid = 0;
            uintptr_t site = 0;
            uintptr_t sp = 0;
            uintptr_t param[4] = {};
            uint8_t nframes = 0;
            // Stack words that landed in OUR address range but NOT in executable code.
            // Counted rather than dropped: on 2026-10-02 a "frames=7" report was really
            // 3 code frames plus 4 data words, nothing said so, and the data words got
            // symbolized into a call chain that had to be retracted. See
            // in_executable_section().
            uint8_t ndata = 0;
            // Stack words that are in no mapped image at all -- registers, spilled
            // integers, pointers to heap. Added 2026-10-03. Before this, a frame in
            // d3d11 or ntdll was indistinguishable from noise and was dropped
            // silently, so "no frames" and "we filtered your answer out" looked the
            // same. Reported so a reader can tell those apart.
            uint8_t nout = 0;
            uintptr_t frames[kFramesPerEvent] = {};
            // Byte offset of each frame's slot from the captured SP.
            //
            // This is the field that would have caught the 22:39:37 false lead. Two
            // frames came back symbolized to plausible functions in dxhook, and both
            // disassembled to code that had already run. Nothing in the old Event
            // said how far down the stack each word sat, so there was no way to see
            // that they were 0x20 and 0x28 bytes deep rather than live. Depth is the
            // cheap honest signal; see the note above image_at() for the cheaper
            // signal that was tried and rejected.
            uint16_t slot[kFramesPerEvent] = {};
            // The image each frame belongs to, stored so emit names the module the
            // frame was captured in even if that image is gone by report time.
            uintptr_t fbase[kFramesPerEvent] = {};
            // 1 when the frame is in THIS module. Not decoration: it is the only
            // thing that resolves against our .map, and a report that mixes
            // unresolvable foreign frames with resolvable ones must mark which is
            // which or tools/symbolize.py gets pointed at addresses it cannot name.
            uint8_t frame_ours[kFramesPerEvent] = {};
            // Whether this event was captured with the DEEP scan. A shallow event
            // stops at the frame budget, so its `nours` is empty for a reason
            // that says nothing about whether our frames were on the stack --
            // and a report that says "no frames of ours" for it would be a lie.
            // Set by guarded_enrich, read by emit_our_frames.
            bool deep = false;
            // Whether fill_frames() ran AT ALL. Distinct from `deep`, and the
            // distinction is the point: a routine OutputDebugString event is
            // captured by HEAD ONLY since 2026-10-10 -- the string and the
            // counts are real, but no stack word was ever examined. Printing
            // "0 frame(s) ... out of 2048 scanned" for it would state a scan
            // that did not happen, which is the exact species of lie this file
            // exists to prevent. So the emit paths check this FIRST and say
            // "not scanned" instead of printing zeroes that read as "scanned
            // and found nothing". Set by guarded_enrich; the pin below still
            // walks, and is marked with it.
            bool walked = false;
            // OUR executable frames, at any depth the scan reaches, on their own
            // budget -- see kOurFrames above. A frame in GameAssembly tells a
            // reader almost nothing; a frame in TarkovAddons.dll resolves to a
            // function name. These are the ones that name a call.
            uint8_t nours = 0;
            uintptr_t ours[kOurFrames] = {};
            uint16_t our_slot[kOurFrames] = {};
        };

        Event g_ring[kRing];

        // The first event of the run, kept in a slot of its own.
        //
        // A pure last-N ring answers "what happened just before the crash" and
        // loses "what started this", which is the more useful half when the
        // cause is a loop. At 00:18:37 on 2026-10-01, 24 C++ throws preceded an
        // access violation and the ring held exactly 24 entries, so the first
        // throw survived by arithmetic luck rather than by design -- one more
        // event and it would have been gone.
        //
        // So the oldest event is pinned separately and never overwritten.
        // Together with the tail that answers both questions: where the trouble
        // started, and how it ended. g_pinned_seq records which one it is;
        // UINT32_MAX means "nothing pinned yet". The Event is copied rather than
        // only the sequence number kept, because by the time anything is reported
        // the ring slot for that sequence may itself have wrapped.
        std::atomic<uint32_t> g_pinned_seq{ UINT32_MAX };
        Event g_pinned{};

        // The first event of the run, kept in a slot of its own.
        //
        // A pure last-N ring answers "what happened just before the crash" and
        // loses "what started this", which is the more useful half when the
        // cause is a loop. At 00:18:37 on 2026-10-01, 24 C++ throws preceded an
        // access violation and the ring held exactly 24 entries, so the first
        // throw survived by arithmetic luck rather than by design -- one more
        // event and it would have been gone.
        //
        // So the oldest event is pinned separately and never overwritten.
        // Together with the tail that answers both questions: where the trouble
        // started, and how it ended. g_pinned_seq records which one it is;
        // UINT32_MAX means "no event pinned yet". The Event is copied, rather
        // than only the sequence number kept, because by the time anything is
        // reported the ring slot for that sequence may itself have wrapped.

        // Our own append handle into the same log file the logger writes, so a
        // crash report lands where a reader already looks. Opened once here
        // rather than in the fault path: CreateFileW inside a VEH is a
        // different risk every time, and there is no reason to take it.
        HANDLE g_log = INVALID_HANDLE_VALUE;

        std::terminate_handler g_prev_terminate = nullptr;
        LPTOP_LEVEL_EXCEPTION_FILTER g_prev_uef = nullptr;

        // Re-entry guards for the two chained handlers.
        //
        // Both handlers now run in FRONT of the game's rather than being displaced
        // by it, which puts our own address inside somebody else's chain: the game's
        // reporter may capture the previous filter, and a filter installed on top of
        // ours could call back into us. SetUnhandledExceptionFilter is one slot, so a
        // cycle is one indirection away and the second arrival would recurse until
        // the stack was gone -- the same shape as the bug this file already had, where
        // the probe's own prologue was what killed the process.
        //
        // The guard is deliberately NOT cleared on the way out of on_terminate().
        // That handler is on the terminal path: if it is reached twice, the first
        // arrival has already written the report, and the correct remaining action is
        // to end the process rather than let two handlers chase each other.
        std::atomic<bool> g_in_terminate{ false };
        std::atomic<bool> g_in_uef{ false };

        // DEBUGGER-TRIGGERED EVENTS, AND THE TWO DISPOSITIONS THEY GET.
        //
        // All five of these carry information to a debugger:
        //
        //   0x40010006 DBG_PRINTEXCEPTION_C       OutputDebugStringA's payload
        //   0x4001000A DBG_PRINTEXCEPTION_WIDE_C  OutputDebugStringW's payload
        //       (Windows 10 and later). MISSING from this gate until 2026-10-10,
        //       which left every wide caller exposed to the same hang below.
        //   0x40010007 DBG_RIPEXCEPTION           the debugging subsystem's own
        //       diagnostic event. This file called it DBG_PRINT_EXCEPTION_STR_C
        //       until 2026-10-10 -- not a name winnt.h has ever defined for any
        //       value; winnt.h declares DBG_RIPEXCEPTION for 0x40010007.
        //   0x80000003 BREAKPOINT                 an actual int3 in some thread
        //   0x80000004 SINGLE_STEP
        //
        // HOW THE TWO PRINT CODES ARE DELIVERED -- measured 2026-10-10, with a
        // live debuggee playing both roles. The harness's end-to-end arm
        // (tools/harness/test_debugger_gate.cpp) reproduces and asserts this
        // matrix, and fails if the machine matches neither model:
        //
        //   * NO debugger: kernel32!OutputDebugStringA/W raise 0x40010006 /
        //     0x4001000A IN-PROCESS on every call, ExceptionInformation =
        //     {length, pointer}, and a vectored handler sees each one. The
        //     unhandled raise is absorbed by kernel32's own frame handler --
        //     measured, it never reaches the unhandled filter. So an ODS flood
        //     pays a VEH visit per event even with no debugger attached, and
        //     until 2026-10-10 it paid a stack walk inside that visit too --
        //     which is the shape of the 100%-CPU session this gate comment
        //     used to attribute to "a debugger turned the prints into
        //     exceptions". The visit cannot be removed from in-process code;
        //     the walk now is (capture_and_maybe_report keeps a print by head
        //     only, see is_print_payload). The 2026-10-09 note here claimed
        //     the kernel does not raise 0x40010006 without a debugger; that is
        //     retracted, it does not survive the measurement.
        //   * ANY debug port (started under a debugger, or attached mid-run):
        //     the kernel CONVERTS each 06/0A raise into an
        //     OUTPUT_DEBUG_STRING_EVENT before in-process delivery. The VEH
        //     never sees these two codes, the raise returns as handled, and the
        //     debugger receives a string event, not an exception -- nothing to
        //     stop on. The same 2026-10-09 note claimed attaching a debugger is
        //     when the VEH sees them; also retracted, also backwards.
        //   * Every other code keeps the ordinary protocol in both modes: a
        //     0xE06D7363 calibration throw is delivered to the debugger
        //     first-chance, and if declined it lands in the VEH.
        //
        // THE DISPOSITION THAT IS RIGHT ON EITHER DELIVERY MODEL: the two
        // string-carrying codes are CONSUMED -- EXCEPTION_CONTINUE_EXECUTION --
        // which ends the sequence inside the process: RaiseException returns to
        // its caller and the debugger is never asked again. The VEH is the only
        // in-process point that can do this; after SEH dispatch nothing here
        // sees the event. On the converted model this arm is dormant (the kernel
        // answered first); on the classic two-ask model -- first-chance raise
        // declined by the debugger, unhandled, then asked AGAIN at second
        // chance, where every debugger stops and waits for a human -- the second
        // ask is a stop per OutputDebugString, and this arm is what removes it.
        // The string is not lost: on that model the debugger already read it at
        // the first ask. A debugger explicitly configured to BREAK on first
        // chance still stops -- nothing in-process can prevent that, and the
        // default configurations do not break here.
        //
        // The break codes are deliberately NOT consumed. Continuing execution on
        // an int3 re-executes the int3, forever, and a breakpoint's whole job is
        // to reach the debugger. They keep CONTINUE_SEARCH.
        //
        // What the consumption gives up is the debugger's ability to make this
        // event kill the process -- and nothing in this process reads these codes
        // for any other purpose. The counterfactual is bounded by the measured
        // model: with no debugger the unhandled print raise is absorbed by
        // kernel32's frame handler and never reaches the unhandled filter, so a
        // session without a debugger behaves identically with or without this
        // arm. tools/harness/test_debugger_gate.cpp asserts against a live
        // debuggee which delivery model the machine is running and fails if
        // neither matches, so this paragraph cannot rot into an unverifiable
        // claim again. On a classic-model machine the same harness proves the
        // negative control: a searching handler DOES produce the second-chance
        // stop that consuming removes.
        //
        // Note this is checked at CALL time rather than latched at install: a
        // debugger can be attached and detached mid-session, and IsDebuggerPresent
        // is documented as reading the process's flag directly. It is one memory
        // read from a fixed address, on a path that then does nothing.
        inline bool is_debugger_signalled(uint32_t code) {
            switch (code) {
            case 0x40010006: // DBG_PRINTEXCEPTION_C
            case 0x40010007: // DBG_RIPEXCEPTION
            case 0x4001000A: // DBG_PRINTEXCEPTION_WIDE_C
            case 0x80000003: // BREAKPOINT
            case 0x80000004: // SINGLE_STEP
                return true;
            default:
                return false;
            }
        }

        // The two string-carrying print codes, exactly -- a named predicate
        // rather than a second inline list, because TWO separate decisions now
        // hang off this set and cannot be allowed to drift apart:
        //
        //   * the disposition in handler() (consumed while a debugger is
        //     attached; debugger_gate_consumes() delegates here), and
        //   * the walk policy in capture_and_maybe_report() -- with NO debugger,
        //     kernel32 raises 0x40010006 IN-PROCESS on every OutputDebugString
        //     (measured; see the gate comment), so a flood of prints paid a VEH
        //     visit AND a stack scan per event, for frames no report reads. The
        //     visit cannot be avoided from in-process code; the scan can.
        //
        // The string survives the deferral: it is read from the head-captured
        // params (fill_head copies ExceptionInformation[0..1] before this policy
        // is consulted), which is what emit_debug_string() reads.
        //
        // Cost, measured 2026-10-10 by build/scratch_dbg/crashprobe_cost.cpp
        // (direct handler() calls, no debugger, shallow stack vs a game-shaped
        // one behind 200 junk-filled frames):
        //
        //     0x40010006   shallow   788 us -> 0.01 us per event
        //     0x40010006   deep-junk 1985 us -> 0.01 us per event
        //     0xE06D7363   shallow   791 us ->  787 us   (control, unchanged)
        //     0xE06D7363   deep-junk 1960 us -> 1991 us   (control, unchanged)
        //
        // The controls staying put is the point of the instrument: the deferral
        // removed the walk for prints and nothing else, and after it the stack
        // SHAPE stops mattering for a print because nothing reads the stack.
        // The harness case tools/harness/test_print_capture_policy.cpp asserts
        // this predicate's membership, the head-only capture, and that the SAME
        // event still walks when it is fatal or when a control asks for frames.
        inline bool is_print_payload(uint32_t code) {
            return code == 0x40010006    // DBG_PRINTEXCEPTION_C
                || code == 0x4001000A;   // DBG_PRINTEXCEPTION_WIDE_C
        }

        // The gate handler() calls. Exists as a named function rather than only an
        // inline condition so tools/harness/test_debugger_gate.cpp asserts on THE
        // SAME predicate -- the first version of that test checked the code list
        // directly, its negative control changed the gate instead, and it stayed
        // green. A guard nobody can test is a guard nobody can trust.
        //
        // debugger_attached is passed rather than read from IsDebuggerPresent() here
        // so the test can exercise both branches without launching a debugger.
        inline bool debugger_gate_skips(uint32_t code, bool debugger_attached) {
            return debugger_attached && is_debugger_signalled(code);
        }

        // The subset of the above that is not merely skipped but CONSUMED with
        // EXCEPTION_CONTINUE_EXECUTION -- the 2026-10-10 fix for the second-chance
        // stop. Kept separate from debugger_gate_skips() so the harness can assert
        // the property as a property: every consumed code is also skipped, and the
        // break codes are never in this set (consuming an int3 would loop it).
        // handler() must check THIS one first; a reordering that let skips()
        // answer first would quietly undo the fix -- which is why the harness also
        // calls the real handler and a real debuggee, not just these.
        //
        // Membership is not restated here: it is is_print_payload(), the same
        // predicate the no-debugger walk policy keys on, so the two cannot drift.
        // That the consumed set is exactly the string-carrying set is the
        // property; a second switch with two more case labels would be a second
        // thing to keep in sync, which is how 0x4001000A went missing once.
        inline bool debugger_gate_consumes(uint32_t code, bool debugger_attached) {
            return debugger_attached && is_print_payload(code);
        }

        // A C++ throw is not a crash by itself. 0xE06D7363 is msc::exception,
        // raised by _CxxThrowException and caught by an ordinary try/catch; a
        // VEH sees every one of them because they all arrive as RaiseException.
        //
        // It is still CAPTURED (see the header comment) -- only the immediate
        // report is gated on this list, and only so that a fatal fault is not
        // drowned by routine traffic. Whether a given throw was caught is
        // decided later, by the terminate handler, where the answer is known.
        inline bool immediately_fatal(uint32_t code) {
            switch (code) {
            case 0xC0000005: return true; // ACCESS_VIOLATION
            case 0xC0000006: return true; // IN_PAGE_ERROR
            case 0xC000001D: return true; // ILLEGAL_INSTRUCTION
            case 0xC0000025: return true; // NONCONTINUABLE_EXCEPTION
            case 0xC000008C: return true; // ARRAY_BOUNDS_EXCEEDED
            case 0xC000008D: return true; // FLOAT_DENORMAL_OPERAND
            case 0xC0000094: return true; // INTEGER_DIVIDE_BY_ZERO
            case 0xC00000FD: return true; // STACK_OVERFLOW
            case 0xC0000139: return true; // RANGE_CHECK
            case 0xC0000374: return true; // HEAP_CORRUPTION
            case 0xC0000409: return true; // FAST_FAIL (stack cookie, /GS)
            case 0xC000041D: return true; // FATAL_USER_CALLBACK
            case 0xC0000602: return true; // FAIL_FAST_EXCEPTION
            case 0xE06D7363: return false; // C++ throw -- captured, not reported here
            case 0x80000003: return false; // BREAKPOINT
            case 0x80000004: return false; // SINGLE_STEP
            default: return false;
            }
        }
    }

    // -----------------------------------------------------------------------
    // Reading memory that may not be there
    // -----------------------------------------------------------------------

    inline bool readable(const void* p) {
        MEMORY_BASIC_INFORMATION mbi{};
        if (VirtualQuery(p, &mbi, sizeof(mbi)) != sizeof(mbi)) return false;
        if (mbi.State != MEM_COMMIT) return false;
        if (mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS)) return false;
        const uintptr_t start = reinterpret_cast<uintptr_t>(mbi.BaseAddress);
        const uintptr_t end = start + mbi.RegionSize;
        const uintptr_t a = reinterpret_cast<uintptr_t>(p);
        return a >= start && a < end;
    }

    // __try is only legal in a function that needs no object destruction, so
    // these raw dereferences are isolated here and every caller stays clean.
    // VirtualQuery already filters, but a page can be unmapped between the
    // check and the read, hence the handler.
    inline bool safe_read(const void* p, uintptr_t* out) {
        __try {
            *out = *static_cast<const uintptr_t*>(p);
            return true;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    inline bool safe_read32(const void* p, uint32_t* out) {
        __try {
            *out = *static_cast<const uint32_t*>(p);
            return true;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // A bounded raw byte copy, isolated for the same reason as the two above:
    // __try needs a frame with no destructible objects, and every caller of this
    // wants to print bytes it does not own.
    inline bool safe_read_bytes(const void* p, char* out, size_t cap) {
        if (!p || !out || cap == 0) return false;
        __try {
            std::memcpy(out, p, cap);
            return true;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // RVA of an address inside this module, or 0 if it is elsewhere. Written
    // into a caller-supplied buffer: no std::string on a fault path.
    inline bool rva_of(uintptr_t addr, char* out, size_t cap) {
        if (!g_base || !out || cap < 4) return false;
        const uintptr_t lo = reinterpret_cast<uintptr_t>(g_base);
        if (addr < lo || addr >= lo + g_size) return false;
        std::snprintf(out, cap, "+0x%llX", static_cast<unsigned long long>(addr - lo));
        return true;
    }

    // -----------------------------------------------------------------------
    // Which image is this address in?
    // -----------------------------------------------------------------------
    //
    // Added 2026-10-03, for a crash this file DID report and could not name.
    //
    // 22:39:37, boot + 260 ms, on the injection thread: an execute fault at
    // address 0 (ExceptionInformation[0] == 8), i.e. a call through a null
    // pointer, inside dxhook::init(). Two frames came back, and disassembly
    // showed both were stale stack words -- one in create_window's epilogue
    // after it had already returned, one in the middle of an inlined memcpy.
    // The reason they were stale is the reason this section exists:
    //
    // fill_frames() kept ONLY words that landed in OUR address range. So any
    // frame in d3d11, dxgi, ntdll or KERNELBASE -- which is where the caller of
    // a null call through a COM/D3D boundary actually lives -- was dropped
    // silently, and a deeper word of ours was reported in its place as
    // "frame 0". The filter was hiding the answer.
    //
    // Two constraints shaped the implementation.
    //
    // 1. IT MUST NOT WALK THE PEB. in_executable_section()'s comment records
    //    that RtlLookupFunctionEntry with a null ImageBase walks the loader
    //    lists and that doing so FAULTS from inside a VEH -- measured, not
    //    reasoned. So there is no module enumeration here. Instead one
    //    VirtualQuery gives the allocation base, and the PE header at that base
    //    gives SizeOfImage. No list, no locks, no allocation.
    //
    // 2. IT MUST NOT TRUST __except. This is the bug the first version of this
    //    section had, and it killed the test suite the day it was written, so
    //    the reason is recorded rather than the fix alone.
    //
    //    The first version read foreign PE headers through safe_read16/32,
    //    which are __try/__except. That is a trap here, because a __except does
    //    NOT fire for a fault raised inside a vectored exception handler --
    //    Windows terminates instead (the same measured fact as above, and the
    //    reason guarded_enrich()'s own __except is decorative on the VEH path).
    //    So an uncommitted header page did not become a false "not an image",
    //    it became a dead process. Symptom: tools/probe_test went from 45/45 to
    //    22/45, with the benign `caught` child dying 0xC0000005 on a HANDLED
    //    throw and writing nothing at all.
    //
    //    The rule this section now follows: on the VEH path, VirtualQuery is the
    //    only thing allowed to decide whether a read is safe, because it cannot
    //    fault. __except is a belt-and-braces measure outside this path (emit),
    //    and never the primary guard inside it.
    //
    // 3. THE NAME MUST NOT COME FROM THE LOADER. The arming line prints our own
    //    base as "X3DAudio1_7.dllDAudio1_7.dlll": for a manual-mapped image the
    //    loader entry is unusable, and any name read from it is borrowed from a
    //    neighbour. The PE carries the real one, in its export directory, and
    //    reading it from the image is both safer and more accurate than asking
    //    Windows who it thinks we are.
    //
    // What this still does NOT give is an unwound stack. This is a scan of
    // stack words that happen to be code addresses, and words that are not
    // (data, registers spilled mid-call, anything outside a mapped image) are
    // skipped. The counts of what was skipped are reported alongside the frames
    // so that a reader can see whether a frame is missing rather than having to
    // assume none was.
    //
    // A NOTE ON WHAT WAS DELIBERATELY NOT ADDED. The obvious discriminator for
    // "is this word a live return address or residue" is to check whether a CALL
    // instruction ends at it. It was implemented, measured against the 22:39:37
    // frames, and removed: 0x124542 really is the return address of a
    // `call __security_check_cookie`, so the test would have labelled the stale
    // word as a live frame and made the report MORE confident, not less. The
    // honest signal is the slot offset, which shows depth and lets a gap be seen.

    constexpr int kModNameMax = 28;

    // Is [p, p+n) inside one committed, unguarded region? The only safety test
    // permitted on the capture path -- see note 2 above.
    inline bool readable_range(uintptr_t p, uintptr_t n) {
        if (!p || !n) return false;
        MEMORY_BASIC_INFORMATION mbi{};
        if (VirtualQuery(reinterpret_cast<const void*>(p), &mbi, sizeof(mbi)) != sizeof(mbi))
            return false;
        if (mbi.State != MEM_COMMIT) return false;
        if (mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS)) return false;
        const uintptr_t s = reinterpret_cast<uintptr_t>(mbi.BaseAddress);
        if (p < s) return false;
        const uintptr_t e = s + mbi.RegionSize;
        return n <= e && p + n <= e;
    }

    inline bool safe_read16(const void* p, uint16_t* out) {
        __try {
            *out = *static_cast<const uint16_t*>(p);
            return true;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // Everything known about one mapped image.
    struct ImageInfo {
        uintptr_t base = 0;
        uintptr_t size = 0;
        bool ours = false;
    };

    // Parse the PE header at `base`, which must already be an allocation base.
    //
    // Every read below is preceded by readable_range() over the exact span it
    // touches. That is four extra VirtualQuery calls per IMAGE, not per stack
    // word, because fill_frames() caches this and only re-parses when the base
    // changes -- and a run of return addresses is nearly always in one image.
    // The alternative, one parse per candidate word, was measured at roughly
    // 2000 extra VirtualQuery calls per captured event and was rejected.
    inline bool image_info(uintptr_t base, ImageInfo& out) {
        out = ImageInfo{};
        if (!base) return false;
        if (!readable_range(base, 0x40)) return false;

        uint16_t dos = 0;
        if (!safe_read16(reinterpret_cast<const void*>(base), &dos) || dos != 0x5A4D) return false;
        uint32_t lfanew = 0;
        if (!safe_read32(reinterpret_cast<const void*>(base + 0x3C), &lfanew)) return false;
        if (lfanew < 0x40 || lfanew > 0x1000) return false;

        // PE signature (4) + COFF header (20) + enough of the optional header to
        // reach SizeOfImage at +0x38.
        if (!readable_range(base + lfanew, 0x58)) return false;
        uint32_t sig = 0;
        if (!safe_read32(reinterpret_cast<const void*>(base + lfanew), &sig) || sig != 0x00004550) return false;
        uint32_t img = 0;
        if (!safe_read32(reinterpret_cast<const void*>(base + lfanew + 0x50), &img)) return false;
        if (img < 0x1000 || img > 0x40000000) return false;

        out.base = base;
        out.size = img;
        out.ours = (g_base != nullptr && base == reinterpret_cast<uintptr_t>(g_base));

        // The name is NOT resolved here. See the note above: the export
        // directory's Name field is not a reliable source (measured: reading it
        // lands ~44 bytes before the real string on ntdll), and the name is only
        // wanted at emit time anyway, which is not the VEH path. image_name()
        // asks the loader there instead.
        return true;
    }

    // Re-resolve a name at EMIT time from a stored base.
//
// Why here and not on the capture path, which is the whole design of this:
//   - emit() is not called from the vectored handler. It runs from
//     report_fatal / on_unhandled / on_terminate, and by then we are already
//     dying, so a loader query that walks the PEB is a far smaller risk than on
//     the path that measured a PEB walk as fatal.
//   - it produces a better answer. GetModuleFileNameA gives the loader's own
//     path, where reading the export directory gave a wrong string: measured on
//     ntdll, IMAGE_EXPORT_DIRECTORY.Name resolved to an RVA about 44 bytes
//     BEFORE the actual "ntdll.dll", so the name came back as mojibake. The PE
//     layout was not the problem -- it was the wrong assumption that the field
//     holds the module name and nothing else needs validating.
//   - the name is never needed to DECIDE anything. Only in_image, the size and
//     the code/data test decide that; a name is decoration on a line a human
//     reads. Deciding on decoration is how the 0x0 fault lost its caller in the
//     first place.
//
// A module that cannot be named -- including OUR OWN image, which is manual-mapped
// and therefore not in the loader lists -- prints as "<unnamed image>", and a
// frame in it is still marked <this module> so the reader is never left guessing
// whether it resolves against our .map.
inline bool image_name(uintptr_t base, char* out, size_t cap) {
    if (!base || !out || cap < 2) return false;
    out[0] = '\0';
    char path[MAX_PATH] = {};
    const DWORD n = GetModuleFileNameA(reinterpret_cast<HMODULE>(base), path,
        static_cast<DWORD>(sizeof(path)));
    if (!n || n >= sizeof(path)) return false;

    // Basename. These names share a 1 KB line buffer with an address, a slot
    // offset and an RVA, and the directory part is what gets truncated.
    unsigned start = 0;
    for (unsigned i = 0; i < n; ++i)
        if (path[i] == '\\' || path[i] == '/') start = i + 1;

    unsigned i = 0;
    const unsigned room = static_cast<unsigned>(cap) - 1;
    for (; i < room && start + i < n && path[start + i]; ++i) out[i] = path[start + i];
    out[i] = '\0';
    return i != 0;
}

    // Is `addr` in EXECUTABLE code of this module, as opposed to data?
    //
    // RtlLookupFunctionEntry is the test, not a section walk. It consults .pdata, which the
    // linker emits only for functions, so it returns non-null for a code address and null
    // for a .rdata/.data one. That is exactly the code-vs-data question, answered by a
    // function the OS already provides -- and it needs no PE headers, which matters
    // because this image is manual-mapped and its headers may not have been copied (the
    // same reason mapped_extent falls back to a VirtualQuery walk).
    //
    // Why this exists: a "frame" that is really a stack *value* landing in our address
    // range gets symbolized to whatever function precedes it and reads as a call chain.
    // That happened on 2026-10-02 -- four of seven reported frames resolved to
    // compiler-generated STRING LITERALs in .rdata -- and the resulting chain was pure
    // invention.
    inline bool in_executable_section(uintptr_t addr) {
        if (!addr) return false;
        // g_base is passed rather than nullptr, and that one argument is worth a
        // crash on its own.
        //
        // With a null ImageBase, RtlLookupFunctionEntry calls RtlPcToFileHeader
        // itself, which walks the PEB's InLoadOrderModuleList to find which module
        // contains `addr`. Called from inside a vectored exception handler that
        // walk faults -- measured, not reasoned: tools/probe_test with this call
        // made the child die 0xC0000005 on its first throw, and passed the instant
        // the base was supplied instead. So the frame walk was not merely useless
        // here, it was one of the ways this VEH killed the process.
        //
        // It also could not have been trusted, and that part of the reasoning was
        // WRONG when this was first written -- corrected 2026-10-03 against the
        // minidump of the 12:38 crash. The claim was that a manual-mapped image
        // is not in the loader lists at all, so the search could never find our
        // base and every one of our return addresses would have been counted as
        // a data word. The dump's module list says otherwise: it carries an entry
        // named `C:\Battlestate Games\BsgLauncher\TarkovAddons.dll` at exactly
        // our base (0x7FFF9AD90000, size 0x9DD000). So an entry exists and the
        // walk might well have succeeded.
        //
        // That does not rescue the null form -- it faulted, reproducibly, and
        // supplying the base stops it -- but it does mean the failure is a fault
        // in the loader-list walk, not a lookup that was bound to come back empty.
        // Which is the more interesting defect and is still unexplained. The
        // arming line's mangled loader name ("X3DAudio1_7.dllDAudio1_7.dlll",
        // for our own base) says the entry WER found is not one the normal path
        // can use, so a walk over a partially-registered entry is a plausible
        // cause; that is a hypothesis, not a measurement.
        //
        // g_base is captured at install time, so passing it is both correct and
        // the cheap option: one .pdata binary search inside a module we already
        // hold open, instead of a list walk over someone else's registration.
        DWORD64 base = reinterpret_cast<DWORD64>(g_base);
        // Takes a control-PC (DWORD64), not a pointer to one: that is the address
        // being asked "is there an unwind record covering you?". A
        // PRUNTIME_FUNCTION* here is a type error (C2664), not a silent miscompile.
        return RtlLookupFunctionEntry(static_cast<DWORD64>(addr), &base, nullptr) != nullptr;
    }

    // The same test, for an arbitrary image.
    //
    // This is the form that makes foreign frames usable, and it is only possible
    // now that image_at() can name the image's base without the PEB. Passing
    // that base is what stops RtlLookupFunctionEntry doing its own loader-list
    // walk, which faults from inside a VEH -- so the fix for our own module and
    // the fix for everyone else's are the same fix.
    //
    // For an image whose linker emitted no .pdata this returns false, and a real
    // foreign frame is dropped. That is a false NEGATIVE, which is the safe
    // direction: it costs a frame, it does not invent one.
    inline bool in_executable_section_at(uintptr_t addr, uintptr_t imageBase) {
        if (!addr || !imageBase) return false;
        DWORD64 base = static_cast<DWORD64>(imageBase);
        return RtlLookupFunctionEntry(static_cast<DWORD64>(addr), &base, nullptr) != nullptr;
    }

    // -----------------------------------------------------------------------
    // CAPTURE -- split into a cheap head and an expensive tail, because the
    // thread that most needs this code captured is the thread least able to
    // run it. See the 2026-10-03 note at the top of this file.
    // -----------------------------------------------------------------------

    // The head of an Event: every field except the frames.
    //
    // This is the half that must never fault. It makes no import call, walks
    // no stack, and needs no local buffers -- about twenty bytes of stack and
    // nothing else. `tid` is passed in rather than read here precisely so:
    // GetCurrentThreadId() is an IAT call preceded by a return-address push,
    // and on 2026-10-03 that push is the instruction that killed the process.
    // Zero means "not read" and is printed as such.
    inline void fill_head(Event& e, uint32_t slot, const EXCEPTION_RECORD* rec,
                          uintptr_t sp, uint32_t tid) {
        e.ready.store(0, std::memory_order_relaxed);
        e.seq = slot;
        e.code = rec->ExceptionCode;
        e.flags = rec->ExceptionFlags;
        e.tid = tid;
        e.site = reinterpret_cast<uintptr_t>(rec->ExceptionAddress);
        e.sp = sp;
        const ULONG_PTR n = rec->NumberParameters > 4 ? 4 : rec->NumberParameters;
        for (ULONG_PTR i = 0; i < n; ++i)
            e.param[i] = static_cast<uintptr_t>(rec->ExceptionInformation[i]);
        e.nframes = 0;
        e.nours = 0;
        e.ndata = 0;
        e.nout = 0;
        e.ready.store(2, std::memory_order_release);
    }

    // The tail of an Event: stack words that are code addresses in ANY mapped image,
    // innermost first, each with its slot offset from SP and the image it came from.
    //
    // CHANGED 2026-10-03. This used to keep only words inside OUR address range:
    //
    //     if (!rva_of(value, rva, sizeof(rva))) continue;   // ours or nothing
    //     if (in_executable_section(value)) e.frames[e.nframes++] = value;
    //     else ++e.ndata;
    //
    // which is defensible until it is measured against a real crash. On 22:39:37
    // it reported two frames for an execute fault at address 0 -- a call through
    // a null pointer -- and both were stale words from dxhook that had already
    // run. The real caller was somewhere else entirely, and this filter is the
    // reason it was not in the report: a frame in d3d11, dxgi, ntdll or
    // KERNELBASE was dropped without a word, and a deeper word of OURS was
    // printed in its place with a lower frame number. The filter was not just
    // lossy, it was actively misleading, because it renumbered what survived.
    //
    // Now every word that lands in a mapped image is kept, named by that image.
    // The three skip counts (frames / ndata / nout) are reported together, so a
    // reader can see what was passed over rather than inferring nothing was.
    //
    // The terminator is nframes alone now. It used to be nframes + ndata against
    // kFramesPerEvent, which meant a stack full of data words could consume the
    // whole budget before a single real frame was recorded -- and on a thread
    // whose stack is mostly spilled pointers that is the common case, not the
    // rare one.
    //
    // Cost: one VirtualQuery per candidate word (there was one already, inside
    // readable()), plus one .pdata search per KEPT FRAME rather than per kept
    // frame-in-ours. That is why this half stays behind guarded_enrich(): it is
    // still the expensive half, and the thread that needs the report most is the
    // thread least able to run it.
        // 2026-10-09: `nours` is filled here on its own budget, and the loop terminator
    // is now BOTH budgets rather than the frame budget alone. Reading the
    // crash-#2 report, this is the change that matters most: six foreign frames
    // had consumed the whole 12-frame budget by rsp+0x600, while our first frame
    // sat at rsp+0x18E8 and the innermost real caller at rsp+0x1A38. The loop had
    // already left. Nothing downstream could have fixed that.
    inline void fill_frames(Event& e, uintptr_t sp, bool deep) {
        // One VirtualQuery per candidate word, serving BOTH the readability test
        // and the allocation lookup, because on this path VirtualQuery is the
        // only thing allowed to decide whether a read is safe (see note 2 above).
        ImageInfo cached;
        uintptr_t cachedBase = 0;
        bool haveCached = false;

                for (int i = 0; i < kStackWords; ++i) {
            // THE TERMINATOR, AND THE BUG THAT WAS HERE FOR ONE COMMIT.
            //
            // The first version of the deep scan used
            //     if (e.nframes >= kFramesPerEvent && e.nours >= kOurFrames) break;
            // which quietly changed what every OTHER exception cost. fill_frames
            // runs on EVERY captured event, not only fatal ones -- a session
            // raises ~10,000 of them -- so on any stack without 12 of our frames
            // (nearly all of them; most exceptions are raised in game code) the
            // loop no longer stopped at ~12 foreign frames and ran the full 2048
            // words instead. ~10-20x more VirtualQuery and .pdata work per
            // exception, multiplied by the ~10,000 exceptions of a session.
            //
            // That was invisible without Tracy, where a session raises ~4,000.
            // With a client attached Tracy's symbolizer fails on our
            // manual-mapped, LDR-unlinked image and calls OutputDebugStringA,
            // which raises DBG_PRINT_EXCEPTION_C -- and the count goes to ~10,000.
            // The probe became the CPU hog: one thread pinned at 100% with the
            // game unresponsive, and no crash anywhere.
            //
            // The scan is therefore only deep when it is going to be READ. See
            // the note on `deep` at capture_and_maybe_report.
            const bool frames_filled = e.nframes >= kFramesPerEvent;
            const bool ours_filled = e.nours >= kOurFrames;
            if (deep ? (frames_filled && ours_filled) : frames_filled) break;
            const uintptr_t slotAddr = sp + (static_cast<uintptr_t>(i) * sizeof(uintptr_t));
            if (!readable(reinterpret_cast<const void*>(slotAddr))) continue;
            uintptr_t value = 0;
            if (!safe_read(reinterpret_cast<const void*>(slotAddr), &value)) continue;
            if (!value) continue;

            MEMORY_BASIC_INFORMATION mbi{};
            if (VirtualQuery(reinterpret_cast<const void*>(value), &mbi, sizeof(mbi)) != sizeof(mbi)
                || mbi.State != MEM_COMMIT
                || (mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS))) { ++e.nout; continue; }
            const uintptr_t base = reinterpret_cast<uintptr_t>(mbi.AllocationBase);
            if (!base) { ++e.nout; continue; }

            // Parse the header only when the image changes. A run of return
            // addresses is nearly always in one image, so this is ~1 parse per
            // event rather than ~1 per word.
            if (!haveCached || base != cachedBase) {
                if (!image_info(base, cached)) { ++e.nout; continue; }
                cachedBase = base;
                haveCached = true;
            }
            if (value < cached.base || value >= cached.base + cached.size) { ++e.nout; continue; }

            // Code or not? RtlLookupFunctionEntry is the right question but needs
            // the image base, which we now have -- so it works for foreign images
            // for the same reason it works for ours, which is that supplying the
            // base stops it walking the loader list. An image whose linker emitted
            // no .pdata returns false and loses a real frame: a false NEGATIVE,
            // which is the safe direction, because it costs a frame rather than
            // inventing one.
            if (!in_executable_section_at(value, cached.base)) {
                if (cached.ours) ++e.ndata;   // ours: a literal, a jump table, a constant pool
                continue;
            }

            // OUR executable frame -> the independent list, whatever the general
            // budget still has left. Deliberately collected even once nframes is
            // full: that is the whole point of the separate budget.
            if (cached.ours && e.nours < kOurFrames) {
                e.ours[e.nours] = value;
                e.our_slot[e.nours] = static_cast<uint16_t>(i * sizeof(uintptr_t));
                ++e.nours;
            }

            e.frames[e.nframes] = value;
            e.slot[e.nframes] = static_cast<uint16_t>(i * sizeof(uintptr_t));
            e.fbase[e.nframes] = cached.base;
            e.frame_ours[e.nframes] = cached.ours ? 1 : 0;
            ++e.nframes;
        }
    }

    // Claim a ring slot and record only its head. Returns the sequence number.
    // Cheap enough to be the first thing any capture does.
    inline uint32_t capture_head(const EXCEPTION_RECORD* rec, uintptr_t sp, uint32_t tid) {
        // Before the ring write, so a slot torn by a concurrent exception cannot lose a
        // count that only this path records.
        count_code(rec);
        const uint32_t slot = g_seq.fetch_add(1, std::memory_order_relaxed);
        fill_head(g_ring[slot % kRing], slot, rec, sp, tid);
        return slot;
    }

    // The tid and the frames, behind a guard.
    //
    // Everything that costs stack or reaches into the kernel lives in here and
    // nowhere else, so there is exactly one place to look when this faults. On
    // 2026-10-03 it did fault, on the main thread with under 160 bytes of stack
    // left, and it took the process down before report_fatal() was ever reached.
    //
    // The guard is legitimate only because this probe is read-only and returns
    // EXCEPTION_CONTINUE_SEARCH: a fault here was fatal anyway, so catching it
    // loses a report rather than changing the outcome. Wrapping the REPORT path
    // in the same way would be a different proposition and is deliberately not
    // done -- if reporting faults, there is nothing left to say it with.
    //
    // Returns false if the enrichment faulted, so the caller can say so.
    //
    // `with_frames` is the walk policy decision made by the caller (see the note
    // at capture_and_maybe_report): false only for the routine print codes,
    // where the scan is the 2026-10-09 100%-CPU shape -- an ODS flood paying a
    // per-event walk for frames nothing reads. It is recorded on the event as
    // `walked` so the emit paths can distinguish "not scanned" from "scanned,
    // found nothing", which is the difference this file refuses to blur.
    //
    // The pin below is deliberately NOT gated on it. It runs once per process,
    // not per event, so its deep walk is not part of any flood's cost -- and a
    // run that STARTS with a print flood is exactly when the first event's
    // frames are worth having.
    inline bool guarded_enrich(const EXCEPTION_RECORD* rec, Event& e, uintptr_t sp,
                               bool deep, bool with_frames) {
        bool ok = true;
        __try {
            const uint32_t tid = GetCurrentThreadId();
            e.tid = tid;
            e.deep = deep;
            e.walked = with_frames;
            if (with_frames) fill_frames(e, sp, deep);

            // Pin the first event of the run. compare_exchange so exactly one thread
            // ever claims it, whichever gets there first.
            uint32_t expect = UINT32_MAX;
            if (g_pinned_seq.compare_exchange_strong(expect, e.seq, std::memory_order_acq_rel)) {
                fill_head(g_pinned, e.seq, rec, sp, tid);
                // The pinned walk below IS deep and DOES happen, whatever the
                // ring event's policy was -- say so on it, or a later reader
                // of this slot would be told the opposite by walked/deep.
                g_pinned.deep = true;
                g_pinned.walked = true;
                fill_frames(g_pinned, sp, /*deep=*/true);
            }
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            ok = false;
        }
        return ok;
    }

    // NOTE: there is deliberately no record() any more. It used to capture and
    // enrich in one unguarded call, and it was the first thing handler() ran --
    // see the 2026-10-03 note at the top. capture_head() + guarded_enrich() are
    // the only two ways into the ring, and capture_and_maybe_report() is the only
    // caller of either, so the ordering cannot be got wrong by accident later.

    // -----------------------------------------------------------------------
    // REPORT -- I/O allowed, but still no allocation and no locks
    // -----------------------------------------------------------------------

    inline void emit(const char* fmt, ...) {
        if (g_log == INVALID_HANDLE_VALUE) return;
        // A fault raised while reporting must not recurse.
        if (g_emitting.test_and_set(std::memory_order_acquire)) return;

        // The buffer is static, not on the stack. It used to be a 1 KB
        // automatic array, which is unusable on the thread that needs a report
        // most -- the 2026-10-03 crash happened with under 160 bytes of stack
        // left, and a 1 KB frame cannot fit in that however willing the code
        // is. g_emitting above already guarantees a single writer at a time,
        // so one shared buffer needs no lock of its own and nothing else in
        // this file has to change to accommodate it.
        static char buf[kLineMax];
        va_list ap;
        va_start(ap, fmt);
        const int n = std::vsnprintf(buf, sizeof(buf) - 2, fmt, ap);
        va_end(ap);
        if (n > 0) {
            // Terminate with CRLF. The first version appended nothing, so every
            // probe line ran into the next and the whole report was one
            // enormous line: unreadable in an editor, and invisible to any
            // per-line grep -- which is the only way anyone reads this file.
            DWORD len = static_cast<DWORD>(n < (int)(sizeof(buf) - 2) ? n : (int)(sizeof(buf) - 2));
            buf[len++] = '\r';
            buf[len++] = '\n';
            DWORD written = 0;
            WriteFile(g_log, buf, len, &written, nullptr);
            // The process is usually about to die. Push it to the device, not
            // just to the OS, or the tail is lost with the process.
            FlushFileBuffers(g_log);
        }
        g_emitting.clear(std::memory_order_release);
    }

    // Read a NUL-terminated printable string at a raw address into `out`.
    // Returns false for anything that is not plainly a short ASCII string, so a
    // bad pointer produces "unavailable" rather than a confident wrong answer.
    inline bool read_plain_string(uintptr_t addr, char* out, size_t cap) {
        if (!addr || cap < 2 || !readable(reinterpret_cast<const void*>(addr))) return false;
        bool ok = false;
        __try {
            for (size_t k = 0; k + 1 < cap; ++k) {
                const char c = *reinterpret_cast<const char*>(addr + k);
                if (!c) { ok = (k > 0); break; }
                if (c < 0x20 || c > 0x7E) { ok = false; break; }
                out[k] = c;
            }
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            ok = false;
        }
        if (ok) out[cap - 1] = '\0';
        return ok;
    }

    // Extract a type name from a TypeDescriptor.
    //
    // The mangled name is stored INLINE in the TypeDescriptor, not behind a
    // pointer -- which is the mistake this function's earlier version made: it
    // read a pointer from td+8 and treated that as the string address, so it
    // walked off into unrelated memory and reported nothing for every real
    // exception. The x64 layout is
    //
    //     struct TypeDescriptor { void* pVFTable; void* spare; char name[]; };
    //
    // so the name begins at +0x10. The x86 layout puts it at +0x08, and older
    // images have been seen with a pointer there instead. All four are tried and
    // the first that yields a printable string wins, so no layout assumption is
    // load-bearing and a wrong guess cannot produce a wrong answer -- it just
    // falls through to the next candidate.
    // Extract the mangled type name from a TypeDescriptor, or return false.
    //
    // Two things are load-bearing here, and both were got wrong first:
    //
    //  * The name is stored INLINE, not behind a pointer. x64 is
    //        struct TypeDescriptor { void* pVFTable; void* spare; char name[]; };
    //    so the name starts at +0x10. An earlier version read a *pointer* from
    //    td+8 and treated it as the string address.
    //
    //  * A candidate must contain '@' to be accepted. Every MSVC-mangled name
    //    does -- `?AVlength_error@std@@`, `.?AUCustomError@?A0x777e1ae0@@`,
    //    `?$vector@H@std@@` -- and nothing else at that address does. Without
    //    this test the walk accepted whatever printable bytes it happened to
    //    land on and reported them as the type: it emitted ")" for a real
    //    exception, which is worse than emitting nothing because it looks like
    //    an answer. A wrong type name sends the next hour in the wrong
    //    direction; UNRESOLVED at least says "look elsewhere".
    inline bool try_name_from_type_descriptor(uintptr_t td, char* out, size_t cap) {
        if (!td) return false;
        char cand[192] = {};
        // Inline, x64 then x86 layout.
        for (const uintptr_t at : {td + 0x10, td + 0x08}) {
            if (read_plain_string(at, cand, sizeof(cand)) && std::strchr(cand, '@')) {
                std::snprintf(out, cap, "%s", cand);
                return true;
            }
        }
        // Indirect, for images that store a pointer instead.
        for (const uintptr_t slot : {td + 0x08, td, td + 0x10}) {
            uintptr_t namePtr = 0;
            if (!safe_read(reinterpret_cast<const void*>(slot), &namePtr) || !namePtr) continue;
            if (read_plain_string(namePtr, cand, sizeof(cand)) && std::strchr(cand, '@')) {
                std::snprintf(out, cap, "%s", cand);
                return true;
            }
        }
        return false;
    }

    // Name the type behind a _ThrowInfo, if that is what `ti` is.
    //
    //   _ThrowInfo { unsigned attributes; _PMFN pfnCatch; int frameOffset;
    //                int catchableTypeArrayOffset; }
    //   -> header { int nCatchableTypes; ptr pCatchableTypes; }
    //   -> ptr[] _CatchableType { unsigned properties; TypeDescriptor* pType; }
    //
    // `attributes` is deliberately NOT range-checked. An earlier version rejected
    // anything with bits outside 0x1F, assuming a small bitfield; MSVC's
    // _ThrowFlags are _AttributeTrueMask 0x100, _AttributeJITMask 0x4000,
    // _AttributeValueMask 0x70000, so an ordinary throw failed that test. The
    // structure is validated instead: a sane array offset, a plausible type
    // count, and a printable name.
    inline bool try_name_from_throw_info(uintptr_t ti, char* out, size_t cap) {
        uint32_t arrayOff = 0;
        if (!ti || !readable(reinterpret_cast<const void*>(ti))) return false;
        if (!safe_read32(reinterpret_cast<const void*>(ti + 20), &arrayOff)) return false;
        if (arrayOff == 0 || arrayOff > 0x400) return false;
        const uintptr_t hdr = ti + arrayOff;
        uint32_t nTypes = 0;
        uintptr_t arr = 0;
        if (!safe_read32(reinterpret_cast<const void*>(hdr), &nTypes)) return false;
        if (!safe_read(reinterpret_cast<const void*>(hdr + 8), &arr)) return false;
        if (nTypes == 0 || nTypes > 64) return false;
        for (uint32_t i = 0; i < nTypes; ++i) {
            uintptr_t ct = 0;
            if (!safe_read(reinterpret_cast<const void*>(arr + i * sizeof(uintptr_t)), &ct) || !ct)
                return false;
            uintptr_t td = 0;
            if (!safe_read(reinterpret_cast<const void*>(ct + 8), &td) || !td)
                (void)safe_read(reinterpret_cast<const void*>(ct + 4), &td);
            if (try_name_from_type_descriptor(td, out, cap)) return true;
        }
        return false;
    }

    // Name the type a second, independent way: through the exception object's
    // own vtable. A polymorphic C++ exception's first word points at its vtable,
    // whose [-1] entry is a pointer to the RTTICompleteObjectLocator, whose
    // +0x0C is a TypeDescriptor RVA relative to the module base.
    //
    // This exists because the _ThrowInfo route depends on knowing which
    // ExceptionInformation slot holds the ThrowInfo, and that index is a CRT
    // implementation detail that has already been got wrong once here. The
    // vtable route does not care about slot order at all.
    // The base of the image containing `addr`, found by checking for real PE
    // headers rather than by trusting a pointer.
    //
    // RTTI stores pTypeDescriptor as an RVA relative to the module base, so the
    // base has to be known exactly. The obvious sources -- "it is one of the
    // ExceptionInformation values, masked to 64 KB" -- are a guess: an earlier
    // version did that and produced a TypeDescriptor address one field off, from
    // which it read a single ")" and reported that as the type name. A confident
    // one-character answer is worse than none.
    //
    // Image bases are 64 KB aligned, so the true base is `addr & ~0xFFFF` minus
    // some multiple of 64 KB. Each candidate is accepted only if it really does
    // begin a PE image: 'MZ', a sane e_lfanew, and 'PE\0\0' at the NT header.
    // That makes the answer verified rather than assumed.
    inline bool find_image_base(uintptr_t addr, uintptr_t* out) {
        if (!addr) return false;
        uintptr_t candidate = addr & ~static_cast<uintptr_t>(0xFFFF);
        for (int step = 0; step < 1024; ++step, candidate -= 0x10000) {
            if (candidate < 0x10000) break;
            uintptr_t mz = 0;
            if (!readable(reinterpret_cast<const void*>(candidate))) continue;
            if (!safe_read(reinterpret_cast<const void*>(candidate), &mz)) continue;
            if ((mz & 0xFFFF) != 0x5A4D) continue;                 // 'MZ'
            uintptr_t lfanew = 0;
            if (!safe_read(reinterpret_cast<const void*>(candidate + 0x3C), &lfanew)) continue;
            if (lfanew == 0 || lfanew > 0x100000) continue;
            uintptr_t sig = 0;
            if (!safe_read(reinterpret_cast<const void*>(candidate + lfanew), &sig)) continue;
            if ((sig & 0xFFFFFFFF) != 0x00004550) continue;       // 'PE\0\0'
            *out = candidate;
            return true;
        }
        return false;
    }

    inline bool try_name_from_vtable(const Event& e, char* out, size_t cap) {
        const uintptr_t obj = e.param[1];
        if (!obj || !readable(reinterpret_cast<const void*>(obj))) return false;
        uintptr_t vtable = 0;
        if (!safe_read(reinterpret_cast<const void*>(obj), &vtable) || !vtable) return false;
        uintptr_t col = 0;
        if (!safe_read(reinterpret_cast<const void*>(vtable - sizeof(uintptr_t)), &col) || !col)
            return false;
        uint32_t tdRva = 0;
        if (!safe_read32(reinterpret_cast<const void*>(col + 0x0C), &tdRva) || !tdRva) return false;
        // The TypeDescriptor lives in the same image as the vtable, so the base
        // is found from the vtable. find_image_base verifies PE headers and
        // fails on a manually-mapped image whose DOS/NT headers were never
        // copied, so the parameter-derived base is tried as well; neither is
        // trusted on its own, only the name that comes back is.
        uintptr_t base = 0;
        if (find_image_base(vtable, &base) &&
            try_name_from_type_descriptor(base + tdRva, out, cap))
            return true;
        for (int i = 0; i < 4; ++i) {
            const uintptr_t candidate = e.param[i] & ~static_cast<uintptr_t>(0xFFFF);
            if (!candidate) continue;
            if (try_name_from_type_descriptor(candidate + tdRva, out, cap)) return true;
        }
        return false;
    }

    // This is the answer to "is it a null reference", which the exception code
    // alone cannot give: a managed NullReferenceException and a
    // std::length_error both arrive as 0xE06D7363 and are told apart only by the
    // type behind the throw.
    inline void emit_thrown_type(const Event& e) {
        if (e.code != 0xE06D7363) return;
        char name[192] = {};
        // Every parameter is offered to both walks rather than assuming an index.
        // An earlier version hardcoded ExceptionInformation[2] and, on the real
        // 23:24:06 crash, read attributes=0 and arrayOffset=0 there -- a value
        // that is not a _ThrowInfo at all. Guessing an index is how a diagnostic
        // ends up confidently wrong.
        for (int i = 0; i < 4; ++i) {
            if (try_name_from_throw_info(e.param[i], name, sizeof(name))) {
                emit("crash probe: thrown type: %s  (via _ThrowInfo, ExceptionInformation[%d])",
                    name, i);
                return;
            }
        }
        if (try_name_from_vtable(e, name, sizeof(name))) {
            emit("crash probe: thrown type: %s  (via the exception object's vtable)", name);
            return;
        }
        emit("crash probe: thrown type: UNRESOLVED. ExceptionInformation = "
             "0x%llX 0x%llX 0x%llX 0x%llX",
            static_cast<unsigned long long>(e.param[0]), static_cast<unsigned long long>(e.param[1]),
            static_cast<unsigned long long>(e.param[2]), static_cast<unsigned long long>(e.param[3]));
    }

    // One frame, with the three things that make it checkable: where it sits on the
    // stack, which image it is in, and whether that image is ours.
    //
    // The slot offset is printed FIRST and unconditionally. That ordering is the
    // lesson of 2026-10-03 22:39:37: two frames came back as clean symbolized
    // function names in dxhook and both were dead code, and the only evidence
    // that would have shown it was how deep they sat. A reader should be able to
    // see depth before they see a name that invites them to trust it.
    inline void emit_one_frame(const Event& e, uint8_t i, const char* lead) {
        char name[kModNameMax] = {};
        const bool named = image_name(e.fbase[i], name, sizeof(name));
        emit("crash probe: %s #%u frame %u [rsp+0x%03X] %p %s+0x%llX%s%s",
            lead, e.seq, unsigned(i), unsigned(e.slot[i]),
            reinterpret_cast<void*>(e.frames[i]),
            named ? name : "<unnamed image>",
            static_cast<unsigned long long>(e.frames[i] - e.fbase[i]),
            e.frame_ours[i] ? " <this module>" : "",
            named ? "" : " (name unreadable)");
    }

    // What the counts mean, stated in the report rather than left to the reader.
    //
    // "frames=11" on its own invited a reading that did not exist: that eleven
    // calls were made. They were not. They were eleven stack words that happened
    // to be code addresses, and the number of real call frames among them is not
    // knowable without unwinding, which this file does not do. The skip counts
    // are printed so the gap between "we found this much" and "there was this
    // much" is visible.
    inline void emit_frame_legend(const Event& e, const char* what) {
        emit("crash probe: %s: %u frame word(s), %u in-image non-code word(s) skipped, "
             "%u word(s) in no mapped image skipped, out of %d scanned from RSP -- "
             "this is a SCAN of stack words, not an unwound stack, so it does not "
             "prove these were called in this order",
            what, unsigned(e.nframes), unsigned(e.ndata), unsigned(e.nout), kStackWords);
    }

    // OUR frames, printed after the general list with their RVAs.
    //
    // Kept separate from emit_one_frame rather than folded into the numbered
    // list, because these are the only ones that resolve against our .map and
    // the only ones that can name a function. A reader who wants the call site
    // should not have to pick it out of a list whose other entries are all
    // "GameAssembly.dll+0x2D5F1D6".
    inline void emit_our_frames(const Event& e, const char* what) {
        // Checked before `deep`, because for a not-walked event the `deep`
        // wording below is also wrong ("OUR frames at depth were not collected"
        // invites "they might be in the list above"; there is no list above).
        if (!e.walked) {
            emit("crash probe: %s: stack not scanned (routine OutputDebugString "
                 "event, head-only capture) -- no frames of ours were collected, "
                 "and that is a property of the capture, not of the stack", what);
            return;
        }
        // A shallow capture stops at the frame budget, so an empty `ours` list
        // says nothing about whether our frames were on the stack. Saying
        // "no frames of ours" here would be a lie by omission, which is the
        // exact failure this file exists to prevent.
        if (!e.deep) {
            emit("crash probe: %s: shallow capture (routine event) -- OUR frames "
                 "at depth were not collected; only frames inside the %d-frame "
                 "budget are listed above", what, kFramesPerEvent);
            return;
        }
        if (e.nours == 0) {
            emit("crash probe: %s: NO frame of ours anywhere in %d words of stack -- "
                 "our code is either genuinely absent, or sits deeper than the scan "
                 "reached and this report cannot tell which", what, kStackWords);
            return;
        }
        emit("crash probe: %s: %u frame(s) of OURS, innermost first (RVA resolves "
             "against symbols\\<stamp>\\TarkovAddons.map)", what, unsigned(e.nours));
        for (uint8_t i = 0; i < e.nours; ++i) {
            char site[32] = {};
            if (!rva_of(e.ours[i], site, sizeof(site))) site[0] = '\0';
            emit("crash probe:   OURS#%u [rsp+0x%X] %p%s", unsigned(i),
                 unsigned(e.our_slot[i]), reinterpret_cast<void*>(e.ours[i]),
                 site[0] ? site : " <outside this module>");
        }
    }

    inline void emit_frames(const Event& e, const char* what) {
        // Before the nframes check, deliberately: a not-walked event has
        // nframes == 0 for a reason the next branch's wording would get wrong
        // ("no code address ... within 2048 words of RSP" -- no words were read).
        if (!e.walked) {
            emit("crash probe: %s: head-only capture (routine OutputDebugString "
                 "event) -- the stack was not scanned, so there is no frame list "
                 "here; the event, its code and its string above are real, and the "
                 "absence of frames says nothing about the stack", what);
            return;
        }
        if (e.nframes == 0) {
            emit("crash probe: %s: no code address in any mapped image within %d words of RSP "
                 "(%u word(s) skipped as in-image non-code, %u as outside every image)",
                what, kStackWords, unsigned(e.ndata), unsigned(e.nout));
            return;
        }
        emit_frame_legend(e, what);
        for (uint8_t i = 0; i < e.nframes; ++i) emit_one_frame(e, i, what);
        // Ours last, so the general list is read before the interesting one --
        // but always, and even when the general list is full of foreign frames,
        // because that is the case the separate budget exists for.
        emit_our_frames(e, what);
    }

    // The string carried by a DBG_PRINTEXCEPTION_C, if it is still there.
    //
    // WHY THIS IS NOT A NEW FEATURE BUT A MISSING READ. fill_head() has always
    // copied ExceptionInformation[0..3] into Event::param -- four stores, at head
    // time, no extra cost in the VEH -- and emit_thrown_type() has always decoded
    // param[] for 0xE06D7363, where param[1] is the exception object. For
    // 0x40010006 the payload is the string's LENGTH in param[0] and a POINTER to
    // the string in param[1], and nothing read them. So the text of all 5,476
    // events in the 23:45:06 session was collected, held in the ring, and
    // discarded.
    //
    // PARAMETER ORDER, MEASURED 2026-10-10, BECAUSE THE OBVIOUS READING IS
    // BACKWARDS. kernel32!OutputDebugStringA raises
    //     ExceptionInformation[0] = length in chars, INCLUDING the NUL
    //     ExceptionInformation[1] = pointer to the string
    // read straight off a vectored handler that logged both fields, and
    // cross-checked against the kernel: with a debug port present the kernel
    // renders an {length, pointer} raise into a correct OUTPUT_DEBUG_STRING_EVENT,
    // and renders a hand-built RaiseException with the fields transposed into a
    // garbled length beside a valid pointer. The comment here claimed
    // {pointer, length} until this date; that made every real event read an
    // integer as an address and print "no longer readable". OutputDebugStringW
    // raises 0x4001000A {chars, ptr-to-UTF-16, ...} and then a SECOND 0x40010006
    // carrying an ANSI conversion of the same text, so the read below covers
    // wide callers too, through that second event.
    //
    // WHAT IT BUYS. That session's histogram reads
    //
    //     0x40010006 DBG_PRINTEXCEPTION_C   x5476
    //     0xE06D7363 C++ exception          x381
    //     0xC0000005 ACCESS_VIOLATION       x4
    //
    // which ranks the second-largest thing that happened and says nothing about
    // it. With the string, the report says what was being printed, which is the
    // only way to tell a game's own debug spam from a dependency's -- and
    // tracy_bridge.h:101-102 currently ASSERTS the source is Tracy's symbolizer
    // failing. That cannot be right in a build with TRACY_CALLSTACK=0, where the
    // symbolizer is compiled out; imgui's DefaultLogHandler (imgui.cpp:18079) and
    // TracyProfiler.cpp:329 also call OutputDebugStringA. This is how that gets
    // settled rather than argued.
    //
    // THE LIMITS, stated because they are real:
    //   * The buffer belongs to whoever called OutputDebugStringA. By report time
    //     it may be gone, so a failed read prints a note, not a crash. The read
    //     is a fixed-size __try-guarded copy for that reason.
    //   * param[0] is attacker-shaped data in the sense that it is simply a
    //     number the game supplied. It is only ever used to LOWER the cap, never
    //     to raise it, and a length that disagrees with the buffer's own NUL
    //     loses. The pointer is never dereferenced outside the guarded copy.
    //   * Printed only for the events that also get frames (kDetailedEvents), so
    //     a flood cannot turn the report into the flood. The faulting event is
    //     always in that window.
    inline void emit_debug_string(const Event& e) {
        if (e.code != 0x40010006u) return;                 // DBG_PRINTEXCEPTION_C
        const uintptr_t reported = e.param[0];             // length, the game's claim
        const char* ptr = reinterpret_cast<const char*>(e.param[1]);
        if (ptr == nullptr) {
            emit("crash probe:     debug string: none (null payload)");
            return;
        }
        // Only ever lower the cap with the reported length.
        size_t cap = kMaxDebugString;
        if (reported != 0 && reported - 1 < cap) cap = static_cast<size_t>(reported);
        char buf[kMaxDebugString + 1];
        if (!safe_read_bytes(ptr, buf, cap)) {
            emit("crash probe:     debug string: %llu byte(s) at %p, no longer "
                 "readable", static_cast<unsigned long long>(reported),
                 static_cast<const void*>(ptr));
            return;
        }
        buf[cap] = '\0';
        // Printable filter, and the buffer's own terminator wins over the length:
        // a truncated tail is not worth printing as mojibake.
        size_t n = 0;
        while (n < cap && buf[n] >= 0x20 && buf[n] < 0x7F) ++n;
        buf[n] = '\0';
        if (n == 0) {
            emit("crash probe:     debug string: %llu byte(s) at %p, not printable",
                 static_cast<unsigned long long>(reported), static_cast<const void*>(ptr));
            return;
        }
        // What the game CLAIMED and what is actually shown are printed separately
        // whenever they differ. Printing only the claimed figure next to a
        // truncated string is worse than silence: a payload claiming 2 GB while
        // 256 bytes are shown reads as "2 GB were printed", which is the one
        // thing a report must not let a reader conclude.
        if (static_cast<uintptr_t>(n) == reported) {
            emit("crash probe:     debug string (%llu byte(s)): %s",
                 static_cast<unsigned long long>(reported), buf);
        } else {
            emit("crash probe:     debug string (game said %llu byte(s), showing "
                 "%llu): %s",
                 static_cast<unsigned long long>(reported),
                 static_cast<unsigned long long>(n), buf);
        }
    }

    // One captured event: the header line, then its frames.
    //
    // The frames are the point. An earlier version printed only "frames=10" and
    // dropped the addresses, so a report said a fault was preceded by 23 C++
    // throws each with ten of our return addresses on the stack -- and then
    // printed none of them. The RVAs are what resolve against the .map and name
    // the call site; the count is a summary of data that was thrown away.
    inline void emit_event(const Event& e, const char* tag, bool with_frames) {
        char site[32] = {};
        char note[192] = {};
        (void)rva_of(e.site, site, sizeof(site));
        // Rejected stack words are reported, not hidden, and the two rejection reasons
        // are separated because they mean different things: an in-image non-code
        // word is a value that was never a return address, while a word outside
        // every mapped image is a word we cannot classify at all -- which is where
        // a frame from a module we failed to identify would have gone.
        //
        // A not-walked event says so INSTEAD of printing zero counts: "0
        // skipped" beside "frames=0" reads as "we looked and there was
        // nothing", and for a head-only print event nobody looked.
        if (e.walked)
            std::snprintf(note, sizeof(note), " (scan of stack words, not an unwound stack;"
                                " %u in-image non-code and %u out-of-image word(s) skipped)",
                unsigned(e.ndata), unsigned(e.nout));
        else
            std::snprintf(note, sizeof(note), " (head-only capture: this OutputDebugString "
                                "event was not stack-scanned, by policy)");
        emit("crash probe:   %s #%u code=0x%08X flags=0x%08X tid=%lu at %p%s frames=%u%s",
            tag, e.seq, e.code, e.flags, e.tid, reinterpret_cast<void*>(e.site),
            site[0] ? site : " <outside this module>", unsigned(e.nframes), note);
        if (!with_frames) return;
        emit_debug_string(e);
        for (uint8_t i = 0; i < e.nframes; ++i) emit_one_frame(e, i, "     ");
        // OUR frames last, so they are read after the general list -- but always,
        // and at the depth the scan reached, which is what 2026-10-09 was missing.
        emit_our_frames(e, tag);
    }

    // The per-code histogram, printed last. Reads g_code/g_code_count/g_code_total, which
    // live next to count_code with the rest of the namespace state.
    //
    // Last on purpose: it is the context for everything above it. "captured #4059" means
    // nothing on its own; "29 of 36 were THREADPOOL_FREE_LIBRARY_ON_COMPLETION_FAILED, on
    // three threads" is a diagnosis.
    inline void emit_code_histogram() {
        const uint32_t total = g_code_total.load(std::memory_order_relaxed);
        if (!total) return;
        uint32_t counted = 0;
        for (int i = 0; i < kCodeSlots; ++i)
            counted += g_code_count[i].load(std::memory_order_relaxed);
        emit("crash probe: %llu exception(s) seen, by code:",
            static_cast<unsigned long long>(total));
        for (int i = 0; i < kCodeSlots; ++i) {
            const uint32_t n = g_code_count[i].load(std::memory_order_relaxed);
            if (!n) continue;
            // One code per slot, so this is the code itself rather than a set of codes.
            const uint32_t code = g_code[i].load(std::memory_order_relaxed);
            emit("crash probe:   0x%08X %-42s x%u", code, code_name(code), unsigned(n));
        }
        // The total and the per-slot sum are maintained separately on purpose, so their
        // disagreement is information rather than a rounding artefact.
        if (counted != total)
            emit("crash probe:   WARNING: %u counted but %u attributed -- the code table "
                 "filled up", unsigned(total - counted), unsigned(total));
        emit("crash probe:   (counts EVERY exception; the 'captured' list above is only "
             "the last %d)", int(kRing));
    }

    // Everything captured before `upto`, oldest first. This is the net that
    // could not fire in the previous version.
    //
    // Frames are printed for the newest few events only. A burst can be
    // thousands deep, and 12 addresses times 3000 events is not a report anyone
    // reads to the end -- it is a report nobody reads. The newest events are the
    // ones nearest the fault, which is where the answer is.
    inline void emit_ring(uint32_t upto) {
        const uint32_t first = upto > kRing ? upto - kRing : 0;
        const uint32_t withFramesFrom =
            (upto > kDetailedEvents) ? upto - kDetailedEvents : first;
        uint32_t printed = 0;
        for (uint32_t s = first; s < upto; ++s) {
            const Event& e = g_ring[s % kRing];
            if (e.ready.load(std::memory_order_acquire) != 2) continue;
            if (e.seq != s) continue;                       // overwritten
            emit_event(e, "captured", s >= withFramesFrom);
            ++printed;
        }
        // The pinned first event, if the ring has already overwritten it. It
        // usually has not, in which case it is already listed above and this
        // says so rather than printing it twice.
        const uint32_t pinned = g_pinned_seq.load(std::memory_order_acquire);
        if (pinned != UINT32_MAX && pinned < first) {
            emit("crash probe:   PINNED (first event of this run; the ring has since "
                 "wrapped past it)");
            if (g_pinned.ready.load(std::memory_order_acquire) == 2 &&
                g_pinned.seq == pinned)
                emit_event(g_pinned, "pinned", false);
        } else if (pinned != UINT32_MAX) {
            emit("crash probe:   (pinned first event #%u is listed above)", pinned);
        }
        if (printed == 0)
            emit("crash probe:   (nothing captured before this event)");
    }

    // Has THIS exact fault already been reported? Loop protection only.
    //
    // The old gate was a single process-lifetime bool, which meant "the first
    // thing that looked fatal wins and everything after it is silent" -- see the
    // note on g_reported_code for what that cost. Keying on (code, address)
    // keeps the property that actually matters, which is that a fault repeating
    // at one site cannot flood the log, while dropping the property that caused
    // the damage, which is that a later and different fault is not reported.
    inline bool already_reported(const EXCEPTION_RECORD* rec) {
        const uintptr_t addr = reinterpret_cast<uintptr_t>(rec->ExceptionAddress);
        if (rec->ExceptionCode == g_reported_code.load(std::memory_order_relaxed)
            && addr == g_reported_addr.load(std::memory_order_relaxed))
            return true;
        g_reported_code.store(rec->ExceptionCode, std::memory_order_relaxed);
        g_reported_addr.store(addr, std::memory_order_relaxed);
        return false;
    }

    // Loop protection for the CONFIRMED path, on its own latch. Same compare-then-
    // store shape and the same deliberate non-CAS: two threads reaching the
    // terminate handler together may both print, and one duplicated death report
    // beats the silence this replaces.
    //
    // The latch is per-observer-class on purpose. Sharing `already_reported` with
    // the first-chance path is what made the 2026-10-05 23:45:06 death print
    // nothing at all -- see the note on g_confirmed_code for the whole shape.
    inline bool confirmed_already_reported(const EXCEPTION_RECORD* rec) {
        const uintptr_t addr = reinterpret_cast<uintptr_t>(rec->ExceptionAddress);
        if (rec->ExceptionCode == g_confirmed_code.load(std::memory_order_relaxed)
            && addr == g_confirmed_addr.load(std::memory_order_relaxed))
            return true;
        g_confirmed_code.store(rec->ExceptionCode, std::memory_order_relaxed);
        g_confirmed_addr.store(addr, std::memory_order_relaxed);
        return false;
    }

    // `confirmed` is the distinction this file previously blurred, and it is the
    // distinction a reader of the log needs most.
    //
    // A vectored handler is called on FIRST-CHANCE exceptions: it sees faults
    // the game goes on to handle and continue from. It cannot know which. So a
    // report from that path says so, and does not claim the process died.
    // Only the unhandled-exception filter and the terminate handler run at a
    // point where the answer is known, and only those set confirmed.
    //
    // This is not a cosmetic relabel. On 2026-10-04 this file printed
    // "===== FATAL (vectored handler) =====" for two first-chance exceptions the
    // process survived -- one of which the log shows continuing for a further
    // 727 lines and ten minutes -- and that is what sent the investigation after
    // the wrong crash while the real one produced no block at all.
    // `upto` is the one-past-the-last captured sequence number, passed in rather
    // than re-read from g_seq so that the caller can report the event it just
    // captured without a second thread's events slipping in between.
    // -----------------------------------------------------------------------
    // Memory state at the fault
    // -----------------------------------------------------------------------
    //
    // WHY THIS EXISTS. Two allocation failures in one session on 2026-10-15 --
    // tracy's `rpmalloc_allocate` returning null for a ~2 MiB request, then the
    // Boehm GC's "VirtualAlloc remapping failed" (GameAssembly.dll+0x5614115) --
    // could not be told apart using anything the log recorded. Everything had to
    // be measured from OUTSIDE the process, after the fact:
    //
    //     commit 28.9 GB of a 65.5 GB limit, 23.6 GB of 31.9 GB RAM free,
    //     and ZERO Resource-Exhaustion-Detector (Event 2004) entries that day
    //     -- the only one on record was 12 days older.
    //
    // So the machine was healthy, something else refused the allocation, and the
    // two candidate explanations were indistinguishable from here: address-space
    // fragmentation inside THIS process, or a real ceiling. The guess available
    // from the log alone was "out of memory", and that guess was wrong.
    //
    // WHAT IT PRINTS, and why two numbers. `commit` near `commit_limit` is a
    // ceiling, and the remedy is the pagefile. `commit` far below it with an
    // allocation still failing is fragmentation, and no amount of RAM fixes it.
    // Those are the same two numbers either way, so this prints both plus the
    // verdict, rather than making the next reader derive it under pressure.
    //
    // RESOLUTION IS ONCE, AT INSTALL, NEVER HERE. Same constraint as the module
    // table above, and it is a constraint this file already learned the hard way:
    // GetModuleHandleW/GetProcAddress take the loader lock, and deadlocking on it
    // at teardown is the exact failure being chased. emit_memory_state() therefore
    // reads cached pointers and calls no loader API, so it is safe to run from
    // the unhandled-exception filter. The K32* names live in kernel32 on Windows
    // 7+; psapi is the fallback. Nothing here adds an import to a manual-mapped
    // DLL.
    //
    // COST. Once per fatal report -- not per frame, and not on the first-chance
    // path, where the probe runs on every access violation the game handles and
    // continues from. GetProcessMemoryInfo is not free (it queries this process's
    // working set), so putting it on the capture path would tax every AV in the
    // process to answer a question that only a death raises. By report_fatal() the
    // process is dying anyway and the surrounding report already costs far more:
    // an RVA table walk, a scan of up to kStackWords stack words, and PDB lookups.
    struct mem_counters {
        DWORD  cb;
        DWORD  page_faults;
        SIZE_T peak_working_set;
        SIZE_T working_set;
        SIZE_T quota_peak_paged;
        SIZE_T quota_paged;
        SIZE_T quota_peak_nonpaged;
        SIZE_T quota_nonpaged;
        SIZE_T pagefile_usage;
        SIZE_T peak_pagefile_usage;
        SIZE_T private_usage;
    };
    static_assert(sizeof(mem_counters) == 80, "PROCESS_MEMORY_COUNTERS_EX layout");

    // CORRECTED 2026-10-15. The first version of this struct was the MSDN sample
    // layout -- fourteen DWORDs, 56 bytes -- and it was WRONG on this machine. Not
    // "possibly wrong on some builds": GetPerformanceInfo returned
    // ERROR_INSUFFICIENT_BUFFER (24) for every size from 56 to 88 and succeeded
    // first at 104. The real layout is a DWORD cb, 4 bytes of padding, then
    // 64-bit fields, with the last three counts back down to DWORD:
    //
    //     +00 cb=104   +08 CommitTotal      +30 PhysicalAvailable
    //     +10 CommitLimit                  +38 SystemCache
    //     +18 CommitPeak                   +40 KernelTotal
    //     +20 PhysicalTotal                +48 KernelPaged
    //                                     +50 KernelNonPaged
    //     +58 PageSize (SIZE_T)            +60 HandleCount (DWORD)
    //                                     +64 ProcessCount (DWORD)
    //                                     +68 ThreadCount (DWORD)
    //
    // What that cost: the process half of the report printed and the system half
    // went SILENT, because the old code only said UNKNOWN when BOTH halves failed.
    // So the discriminator -- the entire reason this function exists -- was absent
    // from a real crash report (pid 7536, 11:47) and nothing said so. Reporting
    // the halves independently is the fix; the layout is the repair.
    //
    // PADDED TO 256 DELIBERATELY. cb above the real size is accepted (104, 112, 128
    // and 256 all returned TRUE), so the tail cannot be written past the buffer if
    // a future Windows extends the struct. The first 104 bytes are read by name
    // from offsets confirmed by a byte dump, not inferred.
    struct perf_info {
        DWORD  cb;
        DWORD  _pad0;
        SIZE_T commit_total;
        SIZE_T commit_limit;
        SIZE_T commit_peak;
        SIZE_T physical_total;
        SIZE_T physical_available;
        SIZE_T system_cache;
        SIZE_T kernel_total;
        SIZE_T kernel_paged;
        SIZE_T kernel_nonpaged;
        SIZE_T page_size;
        DWORD  handle_count;
        DWORD  process_count;
        DWORD  thread_count;
        BYTE   _tail[152]; // tolerate a larger struct; see above
    };
    static_assert(sizeof(perf_info) == 256, "PERFORMANCE_INFORMATION layout + tail");
    // Offsets pinned, because the failure mode is a silently wrong number rather
    // than a compile error. Values cross-checked on 2026-10-15 against an
    // independent source (Win32_PerfFormattedData_PerfOS_Memory):
    // commit_total 20.73 GiB vs 21,522 MB reported; commit_limit 63.92 GiB vs
    // 65,459 MB reported; page_size 4096.
    static_assert(offsetof(perf_info, commit_total) == 8, "perf_info offset");
    static_assert(offsetof(perf_info, commit_peak) == 24, "perf_info offset");
    static_assert(offsetof(perf_info, physical_available) == 40, "perf_info offset");
    static_assert(offsetof(perf_info, page_size) == 80, "perf_info offset");
    static_assert(offsetof(perf_info, thread_count) == 96, "perf_info offset");

    using get_process_memory_info_fn = BOOL(WINAPI*)(HANDLE, mem_counters*, DWORD);
    using get_performance_info_fn = BOOL(WINAPI*)(perf_info*, DWORD);
    inline std::atomic<get_process_memory_info_fn> g_get_process_memory_info{ nullptr };
    inline std::atomic<get_performance_info_fn> g_get_performance_info{ nullptr };

    // SAFE CONTEXT ONLY -- called from install(), never from a fault path.
    inline void resolve_memory_apis() {
        if (HMODULE k32 = GetModuleHandleW(L"kernel32.dll")) {
            g_get_process_memory_info.store(reinterpret_cast<get_process_memory_info_fn>(
                GetProcAddress(k32, "K32GetProcessMemoryInfo")), std::memory_order_relaxed);
            g_get_performance_info.store(reinterpret_cast<get_performance_info_fn>(
                GetProcAddress(k32, "K32GetPerformanceInfo")), std::memory_order_relaxed);
        }
        if (HMODULE ps = GetModuleHandleW(L"psapi.dll")) {
            if (!g_get_process_memory_info.load(std::memory_order_relaxed))
                g_get_process_memory_info.store(reinterpret_cast<get_process_memory_info_fn>(
                    GetProcAddress(ps, "GetProcessMemoryInfo")), std::memory_order_relaxed);
            if (!g_get_performance_info.load(std::memory_order_relaxed))
                g_get_performance_info.store(reinterpret_cast<get_performance_info_fn>(
                    GetProcAddress(ps, "GetPerformanceInfo")), std::memory_order_relaxed);
        }
    }

    inline void emit_memory_state() {
        const auto get_mem = g_get_process_memory_info.load(std::memory_order_relaxed);
        const auto get_perf = g_get_performance_info.load(std::memory_order_relaxed);

        // The two halves report INDEPENDENTLY and each says so when it cannot read.
        // There is no combined "nothing was read" line any more, because there is
        // no longer a combined condition: a live process half must not make a dead
        // system half look like a report with nothing to add.
        if (get_mem) {
            mem_counters m = {};
            m.cb = sizeof(m);
            if (get_mem(GetCurrentProcess(), &m, sizeof(m))) {
                emit("crash probe: memory (this process): working_set=%llu MB peak_ws=%llu MB "
                     "commit=%llu MB peak_commit=%llu MB pagefaults=%lu",
                    static_cast<unsigned long long>(m.working_set >> 20),
                    static_cast<unsigned long long>(m.peak_working_set >> 20),
                    static_cast<unsigned long long>(m.private_usage >> 20),
                    static_cast<unsigned long long>(m.peak_pagefile_usage >> 20),
                    static_cast<unsigned long long>(m.page_faults));
            } else {
                // Half-failures are reported as half-failures. The original
                // version said UNKNOWN only when BOTH halves failed, so a working
                // process half made a dead system half look like a report that
                // simply had nothing to add -- and the system half carries the
                // verdict, which is the whole point of the function.
                emit("crash probe: memory (this process): UNKNOWN -- "
                     "GetProcessMemoryInfo failed (win32 error %lu)", GetLastError());
            }
        } else {
            emit("crash probe: memory (this process): UNKNOWN -- "
                 "GetProcessMemoryInfo was not resolved at install time.");
        }
        if (get_perf) {
            perf_info p = {};
            p.cb = sizeof(p);
            if (get_perf(&p, sizeof(p))) {
                // PAGES, not bytes, and not MB. With the 56-byte struct this read
                // whole DWORDs and happened to look plausible; with the real
                // 64-bit layout CommitTotal is 5,432,948 -- which is 20.7 GiB only
                // once multiplied by page_size. Printing the raw value would have
                // reported "commit=5 MB" beside a process that had committed
                // 40 GB, so the conversion is part of the layout fix rather than
                // a nicety beside it.
                const SIZE_T psz = p.page_size ? p.page_size : 4096;
                const auto to_mb = [psz](SIZE_T pages) -> unsigned long long {
                    return static_cast<unsigned long long>((pages >> 20) * psz);
                };
                const unsigned long long used = p.commit_total;
                const unsigned long long limit = p.commit_limit;
                const unsigned long pct =
                    limit ? static_cast<unsigned long>((used * 100ull) / limit) : 0ul;
                emit("crash probe: memory (system): commit=%llu MB peak_commit=%llu MB "
                     "limit=%llu MB (%lu%%)  ram_free=%llu MB of %llu MB  handles=%lu threads=%lu",
                    to_mb(used), to_mb(p.commit_peak), to_mb(limit), pct,
                    to_mb(p.physical_available), to_mb(p.physical_total),
                    p.handle_count, p.thread_count);
                // The verdict, stated rather than left to be derived under pressure.
                if (pct >= 90)
                    emit("crash probe:   commit is within 10%% of the system limit -- a REAL "
                         "ceiling.\n"
                         "         An allocation failing here is expected and the remedy is the "
                         "pagefile size.");
                else
                    emit("crash probe:   commit is NOT near the system limit -- so an allocation "
                         "failing here is NOT\n"
                         "         system exhaustion. Suspect address-space fragmentation in this "
                         "process, or a per-process\n"
                         "         or job limit; adding RAM will not fix either.");
            } else {
                emit("crash probe: memory (system): UNKNOWN -- GetPerformanceInfo failed "
                     "(win32 error %lu). The commit-vs-limit verdict is therefore\n"
                     "         ABSENT from this report; its absence is not evidence that the "
                     "system had headroom.", GetLastError());
            }
        } else {
            emit("crash probe: memory (system): UNKNOWN -- GetPerformanceInfo was not resolved "
                 "at install time.\n"
                 "         The commit-vs-limit verdict is therefore ABSENT from this report; its "
                 "absence is not evidence\n"
                 "         that the system had headroom.");
        }
    }

    // -----------------------------------------------------------------------
    // Periodic memory sampling
    // -----------------------------------------------------------------------
    //
    // WHY THIS EXISTS. The 11:47 crash produced three memory samples in a
    // 45-minute session, which cannot distinguish a monotonic leak from one
    // spike. What they did show is that this process committed 40,632 MB while
    // only 17,155 MB was resident -- roughly 23 GB sitting on the pagefile --
    // and that commit rose from 26,999 MB to 40,632 MB between two access
    // violations on the same thread. A gap, not a curve. The curve is the thing
    // that would have said which.
    //
    // So: a time series, with the DELTA as a first-class field. The rate is the
    // discriminator, not the absolute value. A sustained positive MB/min is a
    // leak and grows unbounded; a spike is one large delta that then flattens.
    // Three snapshots cannot tell those apart at any threshold.
    //
    // COST. One relaxed clock read per call to decide whether to do anything, and
    // on a 15-second interval two API calls and one log line. The call site is
    // the per-frame application-update hook, so the per-frame cost of this
    // function is a single atomic load -- the same gate TA_ZONE uses, and the
    // reason it is not simply "log the counters every frame".
    inline ULONGLONG g_mem_tick_next_ms = 0;
    inline ULONGLONG g_mem_tick_prev_bytes = 0;
    inline ULONGLONG g_mem_tick_prev_ms = 0;
    inline ULONGLONG g_mem_tick_base_ms = 0;
    inline ULONGLONG g_mem_samples = 0;
    inline std::atomic<bool> g_mem_tick_warned{ false };

    // A hook so the probe can PRINT a number it does not own. The footprint of
    // the mod lives in containers the probe cannot see -- field_cache(),
    // method_cache(), the fixed region tables -- and letting crash_probe.h reach
    // for them would invert the layering and couple a fault handler to the module
    // graph. So the modules register a formatter and the probe calls it.
    //
    // `fn` receives a buffer and the process's private usage in MB, and writes
    // one already-formatted line into the buffer. The MB is passed IN rather than
    // re-read by the provider so the ratio is guaranteed to be against a figure
    // from the same sample; two independently-taken numbers divided by each
    // other give a ratio of two moments, which is not a quantity. `fn` runs on
    // the same 15 s tick as everything else here, so it inherits that budget, and
    // it is read through an atomic rather than called directly: registration
    // happens at module init while the tick runs on the game thread, and that
    // pair needs to be ordered rather than merely likely.
    using footprint_fn = void (*)(char* buf, size_t cap, unsigned long long process_private_mb);
    inline std::atomic<footprint_fn> g_footprint_fn{ nullptr };
    inline void set_footprint_provider(footprint_fn fn) {
        g_footprint_fn.store(fn, std::memory_order_release);
    }

    inline void tick_memory() {
        // Deliberately NOT GetTickCount64 on the hot path. One atomic load to
        // decide, and the clock is only read when the interval has actually
        // elapsed -- the same shape as TA_ZONE's running() gate.
        if (GetTickCount64() < g_mem_tick_next_ms) return;
        g_mem_tick_next_ms = GetTickCount64() + kMemoryTickIntervalMs;

        const auto get_mem = g_get_process_memory_info.load(std::memory_order_relaxed);
        const auto get_perf = g_get_performance_info.load(std::memory_order_relaxed);
        if (!get_mem) return;

        mem_counters m = {};
        m.cb = sizeof(m);
        if (!get_mem(GetCurrentProcess(), &m, sizeof(m))) return;

        const ULONGLONG now = GetTickCount64();
        if (!g_mem_tick_base_ms) g_mem_tick_base_ms = now;
        const double elapsed_s = double(now - g_mem_tick_base_ms) / 1000.0;
        const ULONGLONG commit = static_cast<ULONGLONG>(m.private_usage);
        const ULONGLONG resident = static_cast<ULONGLONG>(m.working_set);
        const ULONGLONG paged_out = commit > resident ? commit - resident : 0;

        // The rate. BUG FOUND 2026-10-15 IN REAL DATA, and it was hiding the most
        // interesting signal in the log: a NEGATIVE rate.
        //
        // This used to read
        //     double rate_mb_min = -1.0;
        //     if (have_prev) rate_mb_min = <delta>;
        //     print (rate_mb_min >= 0) ? "%+.0f" : "n/a (first)";
        // so a falling commit produced a negative rate, fell into the else, and
        // was printed as "n/a (first)" -- a claim that there was no previous
        // sample, at sample 227. It happened 47 times in the first 306 samples
        // of the session that found it, always on a falling edge.
        //
        // The direction is the finding, not an edge case: commit FALLING is
        // what distinguishes the sawtooth from a leak, and the old code printed
        // the one moment that disproved a leak as though it had nothing to say.
        // A sentinel has to be distinguishable from every legal VALUE, not
        // merely from the initial one; -1 was inside the value's range because
        // the rate is signed. Hence the explicit bool rather than a magic value.
        bool have_prev = false;
        double rate_mb_min = 0.0;
        if (g_mem_tick_prev_ms && now > g_mem_tick_prev_ms) {
            const double dt_s = double(now - g_mem_tick_prev_ms) / 1000.0;
            if (dt_s > 0) {
                have_prev = true;
                rate_mb_min = (double(commit) - double(g_mem_tick_prev_bytes)) / (1024.0 * 1024.0)
                              * (60.0 / dt_s);
            }
        }
        g_mem_tick_prev_bytes = commit;
        g_mem_tick_prev_ms = now;
        // ULONGLONG to match g_mem_samples. Declared `unsigned long` this was a
        // narrowing conversion (C4244) that MSVC warns about three times over
        // because the header lands in three translation units -- and the build
        // bar here is zero warnings, not "warnings I did not write myself".
        const ULONGLONG n = ++g_mem_samples;

        unsigned long long sys_pct = 0;
        unsigned long long sys_used_mb = 0, sys_limit_mb = 0;
        if (get_perf) {
            perf_info p = {};
            p.cb = sizeof(p);
            if (get_perf(&p, sizeof(p)) && p.commit_limit) {
                const SIZE_T psz = p.page_size ? p.page_size : 4096;
                sys_used_mb = (p.commit_total >> 20) * psz;
                sys_limit_mb = (p.commit_limit >> 20) * psz;
                sys_pct = static_cast<unsigned long long>(
                    (static_cast<unsigned long long>(p.commit_total) * 100ull) / p.commit_limit);
            }
        }

        char rate_text[48];
        if (have_prev)
            std::snprintf(rate_text, sizeof(rate_text), "%+.0f", rate_mb_min);
        else
            std::snprintf(rate_text, sizeof(rate_text), "n/a");

        emit("mem[%llu] t=%.0fs commit=%llu MB (%llu MB resident, %llu MB paged out) "
             "rate=%s MB/min  faults=%llu  sys=%llu%% of %llu MB",
             n, elapsed_s, commit >> 20, resident >> 20, paged_out >> 20,
             rate_text, static_cast<unsigned long long>(m.page_faults),
             sys_pct, sys_limit_mb);

        // The mod's own footprint, when something has registered to report it.
        // Skipped silently ONLY when nobody registered -- that is an absence of
        // configuration, not a failure, and the registry itself says whether it
        // was ever set.
        if (const auto fp = g_footprint_fn.load(std::memory_order_acquire)) {
            char line[512] = {};
            fp(line, sizeof(line), commit >> 20);
            if (line[0]) emit("%s", line);
        }

        // Once per session, and only on the real thing: the SYSTEM ceiling, not
        // this process's growth. 80% is early enough that the next few minutes
        // can still be observed, which is the entire point of watching.
        if (sys_pct >= 80 && !g_mem_tick_warned.exchange(true))
            emit("mem[%llu] WARNING: system commit has reached %llu%% of its limit "
                 "(%llu MB of %llu MB). An allocation failure from here on is a REAL\n"
                 "         ceiling rather than fragmentation, and this process is holding "
                 "%llu MB of it.", n, sys_pct, sys_used_mb, sys_limit_mb, commit >> 20);
    }

    inline void report_fatal(const EXCEPTION_RECORD* rec, const char* how,
                             uint32_t upto, bool confirmed) {
        // THE GATE, and it is two latches because one cannot do this job.
        //
        // A confirmed report -- unhandled filter or terminate handler, the two
        // callers that run where "the process is going down" is known -- is gated
        // on its OWN latch, never on the first-chance one. Sharing them meant a
        // death whose fault the vectored handler had already seen produced no
        // confirmed report at all: on 2026-10-05 23:45:06 the log ends with the
        // two `PROCESS DYING` lines and then nothing, and the frames for the event
        // that killed the process are the frames nobody got.
        //
        // It still cannot print unboundedly: the confirmed latch suppresses a
        // repeat of the same dying fault (terminate after unhandled filter, say),
        // which is the loop protection the dedup was for in the first place.
        if (confirmed) {
            if (confirmed_already_reported(rec)) return;
        } else if (already_reported(rec)) {
            return;
        }
        if (!confirmed) {
            const uint32_t seen = g_first_chance_reports.fetch_add(1, std::memory_order_relaxed);
            if (seen >= kMaxFirstChanceReports) {
                // Say so ONCE. Going quiet without saying why is the exact defect
                // this whole change exists to remove -- a reader must never have to
                // guess whether "nothing more was printed" means "nothing more
                // happened" or "we stopped printing".
                if (!g_first_chance_capped.exchange(true)) {
                    emit("");
                    emit("crash probe: first-chance reports capped at %u per session; "
                         "further distinct faults will be captured into the ring but "
                         "not printed.\n"
                         "         A confirmed report (unhandled filter / terminate) is "
                         "NOT subject to this cap and will still print in full.",
                         kMaxFirstChanceReports);
                }
                return;
            }
        }

        // The tid comes from the captured event, never from a fresh
        // GetCurrentThreadId(). That call is not free on a faulted thread -- it
        // is a return-address push before anything else happens, and on
        // 2026-10-03 that push was the fault. tid == 0 means the enrichment
        // never got that far, and saying so beats calling into the kernel to
        // find out.
        const uint32_t tid = g_ring[(upto ? upto - 1 : 0) % kRing].tid;
        char tid_text[16] = "not-read";
        if (tid) std::snprintf(tid_text, sizeof(tid_text), "%lu", tid);

        emit("");
        if (confirmed)
            emit("crash probe: ===== FATAL (%s) =====", how);
        else
            emit("crash probe: ===== EXCEPTION (%s) -- FIRST CHANCE, the process may "
                 "continue =====\n"
                 "         A vectored handler sees every access violation, including "
                 "the ones the\n"
                 "         game handles and continues from, and it cannot tell them "
                 "apart. Do not\n"
                 "         read this as a death: look for a FATAL block from the "
                 "unhandled filter,\n"
                 "         or for log output simply stopping.", how);
        emit("crash probe: code=0x%08X flags=0x%08X%s tid=%s at %p",
            rec->ExceptionCode, rec->ExceptionFlags,
            (rec->ExceptionFlags & EXCEPTION_NONCONTINUABLE) ? " NONCONTINUABLE" : "",
            tid_text, reinterpret_cast<void*>(rec->ExceptionAddress));
        char site[32] = {};
        (void)rva_of(reinterpret_cast<uintptr_t>(rec->ExceptionAddress), site, sizeof(site));
        emit("crash probe: faulting rva=%s", site[0] ? site : "<outside this module>");

        if (rec->ExceptionCode == EXCEPTION_ACCESS_VIOLATION && rec->NumberParameters >= 2) {
            const ULONG_PTR op = rec->ExceptionInformation[0];
            const char* kind = (op == 0) ? "READ" : (op == 1) ? "WRITE" : "EXECUTE/other";
            emit("crash probe: ACCESS_VIOLATION %s of 0x%p", kind,
                reinterpret_cast<void*>(rec->ExceptionInformation[1]));

            // State the arithmetic. "null plus a field offset" is the reading that has
            // been right every time (0x8 in the Tracy crash, 0x50 in the 22:0x one), and
            // it took three crashes to notice it was being left implicit.
            if (rec->NumberParameters >= 3 && op != 1) {
                const uintptr_t addr =
                    static_cast<uintptr_t>(rec->ExceptionInformation[1]);
                const ULONG_PTR base = rec->ExceptionInformation[2];
                if (base == 0 && addr < 0x1000)
                    emit("crash probe:   null + 0x%llX -- a field read through a null object",
                        static_cast<unsigned long long>(addr));
                else if (base != 0 && addr >= base && (addr - base) < 0x1000)
                    emit("crash probe:   offset +0x%llX from %p -- a field of an object at "
                         "that base, which is %s", static_cast<unsigned long long>(addr - base),
                        reinterpret_cast<void*>(base),
                        readable(reinterpret_cast<const void*>(base)) ? "readable" : "NOT readable");
            }
        }
        emit_thrown_type(g_ring[(upto ? upto - 1 : 0) % kRing]);
        // Before the ring, not after: on an allocation failure the ring is 24 events
        // of noise and the question is "how much address space was left", which the
        // reader needs before deciding whether to read the noise at all.
        emit_memory_state();
        emit_ring(upto);
        emit_code_histogram();
    }

    // -----------------------------------------------------------------------
    // The three entry points
    // -----------------------------------------------------------------------

    // Every entry point captures in the same order, and the order is the fix:
    //
    //   1. the head   -- no import call, no stack walk, ~20 bytes of stack
    //   2. the tail   -- tid and frames, behind an SEH guard
    //   3. the report -- runs whether or not step 2 survived
    //
    // The previous order captured everything and then reported, which on
    // 2026-10-03 meant a 152-byte stack frame and an IAT call ran before
    // report_fatal() was reached at all, and killed the process on the main
    // thread doing it. Capture is not a passive prelude to the report here; on
    // the fatal path it was the thing that ran first, and it was the thing that
    // died. Step 1 is now unconditional and nearly free, so by the time
    // anything can fail, the event is already recorded.
    // Forward declaration only. verify_handlers_throttled() is defined much further
    // down, because it needs to name on_unhandled and on_terminate, which are
    // themselves defined after this point. handler() calls it, so the name has to
    // be visible here.
    inline void verify_handlers_throttled(const char* context);

    // `fatal` means "report this now"; `confirmed` means "nobody caught it". They
    // are separate because only one caller can know the second, and conflating
    // them is what let this file call a handled exception FATAL.
    inline void capture_and_maybe_report(const EXCEPTION_RECORD* rec, uintptr_t sp,
                                         const char* how, bool fatal, bool confirmed) {
        if (!rec) return;
        const uint32_t slot = capture_head(rec, sp, /*tid=*/0);
        // `deep` is whether this event can possibly be REPORTED. Only a fatal
        // code reaches report_fatal() below; everything else is captured to the
        // ring and never printed. So the expensive half -- the 16 KB walk looking
        // for our own frames at depth -- is only worth its cost on an event a
        // reader will see.
        //
        // This is load-bearing in a way that is not obvious from this line: the
        // routine path is the COMMON path by three orders of magnitude, and a
        // terminator that only stops at BOTH budgets rather than the frame budget
        // made the common path cost as much as the rare one. With Tracy attached
        // that was a thread pinned at 100%.
        //
        // `want_frames` is the second half of the same argument, added
        // 2026-10-10, and it is about the routine path again: with no debugger,
        // kernel32 raises 0x40010006 IN-PROCESS on EVERY OutputDebugString
        // (measured; see the gate comment at is_debugger_signalled), so a print
        // flood -- 5,476 events in the 23:45:06 session -- paid a stack scan per
        // event whose frames no report ever reads. Measured before this line
        // existed: ~0.8 ms per print on a shallow stack, ~2.0 ms on a
        // game-shaped one. A print is captured by HEAD ONLY now: the histogram,
        // the ring entry and the string (emit_debug_string reads it from the
        // head-captured params) are unchanged; the walk is not run, and `walked`
        // on the event says so, so the report can say "not scanned" rather than
        // print zeroes that read as "scanned and found nothing".
        //
        // A FATAL print still walks: `fatal` wins, because then somebody is
        // going to read it. That path is the unhandled filter on a machine where
        // kernel32's frame handler does not absorb the print raise -- not this
        // one, but not every one either.
        const bool want_frames = fatal || !is_print_payload(rec->ExceptionCode);
        const bool enriched = guarded_enrich(rec, g_ring[slot % kRing], sp, fatal, want_frames);
        if (!fatal) return;
        // Say plainly that the frames are missing rather than letting "frames=0"
        // read as "there were no return addresses of ours on that stack".
        if (!enriched)
            emit("crash probe: NOTE: the thread did not survive the frame walk "
                 "(no stack, or an unreadable stack region). Everything below is "
                 "still valid; the frame list is empty because it was never "
                 "finished, not because there was nothing in it.");
        report_fatal(rec, how, slot + 1, confirmed);
    }

    inline LONG CALLBACK handler(EXCEPTION_POINTERS* info) {
        if (!info || !info->ExceptionRecord || !info->ContextRecord)
            return EXCEPTION_CONTINUE_SEARCH;
        const EXCEPTION_RECORD* rec = info->ExceptionRecord;
        const uintptr_t sp = static_cast<uintptr_t>(info->ContextRecord->Rsp);

        // Debugger-triggered events, when a debugger is actually attached.
        //
        // Deliberately an early return rather than a filter further down:
        // capture_head() is nearly free, but guarded_enrich() is where the
        // stack work lives (the walk and the pin), and for these codes it
        // would be spent to keep a report nobody asked for. Skipping also
        // means these events are absent from the ring and the histogram while
        // the gate is live.
        //
        // Two dispositions, and this is the only place in this file that returns
        // anything other than EXCEPTION_CONTINUE_SEARCH:
        //
        //   * the two string-carrying print codes are CONSUMED. On a delivery
        //     model where an unhandled raise goes back to the debugger,
        //     searching instead makes the kernel ask it a SECOND time -- a
        //     stop, once per OutputDebugString, which is the symptom this
        //     exists to remove. See debugger_gate_consumes().
        //   * the break codes are SKIPPED, not consumed: continuing execution on
        //     an int3 re-executes the int3 forever, and a breakpoint must reach
        //     the debugger to do its job. See debugger_gate_skips().
        //
        // consumes() is checked FIRST on purpose; if skips() answered first the
        // print codes would take the SEARCH path and the fix would be gone.
        // With no debugger attached both tests are false for every real fault,
        // so a normal session is unaffected. Which delivery model this machine
        // runs -- kernel-converted or in-process raise -- is measured and
        // asserted by tools/harness/test_debugger_gate.cpp; the gate comment at
        // is_debugger_signalled has both shapes, and why the consumption is the
        // right disposition either way (on the converted model this arm is
        // simply never reached for these codes -- dormant, not wrong).
        const bool debugger_attached = IsDebuggerPresent() != 0;
        if (debugger_gate_consumes(rec->ExceptionCode, debugger_attached))
            return EXCEPTION_CONTINUE_EXECUTION;
        if (debugger_gate_skips(rec->ExceptionCode, debugger_attached))
            return EXCEPTION_CONTINUE_SEARCH;

        // Routine exceptions are not captured here. Only fatal faults and
        // debugger-signalled events enter the probe, keeping the VEH path out of
        // the normal C++ exception traffic. An unhandled C++ exception is still
        // handled by the unhandled-exception filter and terminate path below.
        const bool fatal = immediately_fatal(rec->ExceptionCode);
        if (!fatal && !is_debugger_signalled(rec->ExceptionCode))
            return EXCEPTION_CONTINUE_SEARCH;

        capture_and_maybe_report(rec, sp, "vectored handler", fatal,
            /*confirmed=*/false);

        // Last, and rate-limited to once a minute: is this file's report path
        // still installed? On 2026-10-03 13:26:54 an unhandled C++ exception
        // killed the game and this probe said nothing, because by then one of
        // the two single-slot handlers had been taken by the game and a vectored
        // handler -- the one door that cannot be lost -- is not consulted for it.
        // Doing it here means no game file has to change and no cooperation is
        // needed from anything: exceptions arrive on their own.
        if (fatal)
            verify_handlers_throttled("vectored handler");

        return EXCEPTION_CONTINUE_SEARCH;
    }

    // An unhandled C++ exception ends here, and this is the signal the VEH
    // cannot produce. std::terminate is called after the stack unwind has failed
    // to find a handler, so by the time this runs the answer is known: nobody
    // caught it.
    //
    // MEASURED 2026-10-03, and it inverts the reading of this file. For an
    // uncaught C++ throw the UNHANDLED EXCEPTION FILTER fires FIRST and this
    // handler fires SECOND -- and terminate is reached at all only because we
    // CHAIN to the filter that was installed before us. The CRT puts one there
    // by default; on_unhandled() hands the exception to it, it declines, and only
    // then does the runtime get round to terminate.
    //
    // So do not read this handler as a second, independent report door. Take the
    // chain away -- replace g_prev_uef's handler instead of calling it -- and
    // this function is never reached at all: the process dies at the filter with
    // the original code (0xE06D7363) and nothing here runs. That was verified by
    // breaking the chain on purpose; the three `uncaught` cases fail as well as
    // the new chained case, which is how the coupling was found.
    //
    // The practical consequence for the game: if Battlestate's reporter does not
    // return EXCEPTION_CONTINUE_SEARCH, we will not see a terminate for that
    // crash -- we will have already reported it from the filter, one step
    // earlier, which is the reason on_unhandled() is the load-bearing half of
    // this file and not this one.
    inline void on_terminate() {
        // Second arrival: a handler is chained back to this one, which is the
        // only way to get here twice. The first arrival already reported, so the
        // report is not repeated and the process is simply ended -- running the
        // chain again would let two terminate handlers chase each other.
        if (g_in_terminate.exchange(true, std::memory_order_acq_rel)) {
            std::abort();
        }
        if (!g_terminate_reported.exchange(true)) {
            const uint32_t upto = g_seq.load(std::memory_order_relaxed);
            emit("");
            emit("crash probe: ===== UNHANDLED C++ EXCEPTION (std::terminate) =====");
            emit("crash probe: an exception propagated to the top of the stack with no "
                 "handler. A vectored\n"
                 "         handler cannot tell this from a routine throw, which is why "
                 "it is reported here\n"
                 "         and not there.");
            // The most recent event is the throw that killed us.
            if (upto) {
                const Event& e = g_ring[(upto - 1) % kRing];
                if (e.ready.load(std::memory_order_acquire) == 2 && e.seq == upto - 1) {
                    char site[32] = {};
                    (void)rva_of(e.site, site, sizeof(site));
                    emit("crash probe: throw site %p %s tid=%lu raised with flags 0x%08X%s",
                        reinterpret_cast<void*>(e.site), site[0] ? site : "<outside this module>",
                        e.tid, e.flags, (e.flags & EXCEPTION_NONCONTINUABLE) ? " NONCONTINUABLE" : "");
                    emit_thrown_type(e);
                    emit_frames(e, "throw chain");
                }
            }
            emit_ring(upto);
        }

        // Chain, so the process dies exactly as it would have without us. This is
        // the normal path, not a courtesy: verify_handlers() re-asserts this slot
        // when it finds the game has taken it, so the handler that used to run
        // first now runs second, behind the report above.
        if (g_prev_terminate && g_prev_terminate != on_terminate) {
            g_prev_terminate();
        }
        std::abort();
    }

    // Unhandled SEH that is not a C++ throw. Reached for a fault raised on a
    // thread whose stack the OS could not unwind, and for anything that escapes
    // without going through terminate.
    inline LONG WINAPI on_unhandled(EXCEPTION_POINTERS* info) {
        // Second arrival means something is chained back to us. Hand the exception
        // to whatever is left rather than recursing: the first arrival reported,
        // and a filter that keeps calling itself ends in a stack overflow that
        // destroys the report it was trying to write.
        if (g_in_uef.exchange(true, std::memory_order_acq_rel)) {
            return EXCEPTION_CONTINUE_SEARCH;
        }
        if (info && info->ExceptionRecord && info->ContextRecord) {
            // THE ONE LINE THAT MATTERS MOST IN THIS FILE.
            //
            // Unconditional, ungated, ahead of everything else, and deliberately
            // not sharing the latch in report_fatal(). Everything else here can
            // be suppressed, can fail, or can be spent by an earlier event; this
            // is the assertion that the process is going down, and it is the only
            // thing in the file that answers "did the log stop because the game
            // stopped logging, or because this died".
            //
            // It is here, and not only in report_fatal(), because on 2026-10-04
            // 21:24:50 the death produced NO block from this file at all: an
            // earlier handled first-chance AV had already taken the report latch,
            // so report_fatal() returned without a word and the log simply ended.
            // Reading that log, "the probe said nothing" was indistinguishable
            // from "the probe was not there".
            emit("");
            emit("crash probe: ######## PROCESS DYING ########");
            emit("crash probe: reached the UNHANDLED EXCEPTION FILTER, so nothing "
                 "caught this.\n"
                 "         Code 0x%08X at %p. Everything after this point is "
                 "best-effort.", 
                 info->ExceptionRecord->ExceptionCode,
                 info->ExceptionRecord->ExceptionAddress);
            capture_and_maybe_report(info->ExceptionRecord,
                static_cast<uintptr_t>(info->ContextRecord->Rsp),
                "unhandled exception filter", true, /*confirmed=*/true);
        }
        else {
            // No records to report on, but the process is still going down and
            // the log must say so. An unconditional marker is the whole point.
            emit("");
            emit("crash probe: ######## PROCESS DYING ########");
            emit("crash probe: reached the UNHANDLED EXCEPTION FILTER with no "
                 "exception records supplied.");
        }

        // THE LOAD-BEARING LINE. Whoever held the slot before we were installed --
        // on 2026-10-03 that is Battlestate's own reporter -- runs AFTER our
        // report, so its crash dialog and its minidump still happen and the
        // process dies the way it would have if this file did not exist. Taking
        // the slot is not taking the reporter; it is standing in front of it.
        LONG result = EXCEPTION_CONTINUE_SEARCH;
        if (g_prev_uef && g_prev_uef != on_unhandled) {
            result = g_prev_uef(info);
        }
        g_in_uef.store(false, std::memory_order_release);
        return result;
    }

    // How much of the image is actually mapped, starting at `base`.
    //
    // The PE header is tried first, but this DLL is MANUAL-MAPPED into a
    // foreign process, so the loader never validated it and a mapper is under
    // no obligation to have copied the DOS/NT headers to the base. The first
    // version of this probe assumed they were there and silently fell back to
    // a 16 MB guess (the arming line read "size 0x1000000" when the real
    // SizeOfImage is 0x904000).
    //
    // So fall back to walking the VirtualQuery regions upward from the base
    // while they stay committed and contiguous. A mapper that preserves RVA
    // layout -- which it must, or nothing would run -- produces exactly the
    // image extent, without needing a single header to be present.
    inline uintptr_t mapped_extent(const std::byte* base) {
        const auto lo = reinterpret_cast<uintptr_t>(base);
        // Headers, if they survived the map.
        if (base[0] == static_cast<std::byte>('M') && base[1] == static_cast<std::byte>('Z')) {
            const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
            if (dos->e_magic == IMAGE_DOS_SIGNATURE && dos->e_lfanew > 0) {
                const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS64*>(base + dos->e_lfanew);
                if (nt->Signature == IMAGE_NT_SIGNATURE && nt->OptionalHeader.SizeOfImage)
                    return nt->OptionalHeader.SizeOfImage;
            }
        }
        uintptr_t end = lo;
        for (int guard = 0; guard < 64; ++guard) {
            MEMORY_BASIC_INFORMATION mbi{};
            if (VirtualQuery(reinterpret_cast<const void*>(end), &mbi, sizeof(mbi)) != sizeof(mbi)) break;
            if (mbi.State != MEM_COMMIT) break;
            const uintptr_t region_end = reinterpret_cast<uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;
            if (region_end <= end) break;          // no forward progress
            end = region_end;
            if (end - lo > (16u << 20)) break;      // sanity cap
        }
        return end - lo;
    }

    inline void open_log() {
        if (g_log != INVALID_HANDLE_VALUE) return;
        std::string dir;
        try {
            dir = module_paths::dll_directory_utf8();
        } catch (...) {
            dir.clear();
        }
        if (dir.empty()) return;
        const std::string path = dir + "\\tarkovaddons_log.txt";
        const int n = MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, nullptr, 0);
        if (n <= 0) return;
        std::wstring wpath(static_cast<size_t>(n), L'\0');
        if (MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, wpath.data(), n) <= 0) return;
        // FILE_APPEND_DATA rather than GENERIC_WRITE: every write goes to the
        // current end of file, so the probe's lines cannot overwrite the
        // logger's, and the two can share the file without a lock.
        g_log = CreateFileW(wpath.c_str(), FILE_APPEND_DATA,
            FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS,
            FILE_ATTRIBUTE_NORMAL, nullptr);
    }

    // -----------------------------------------------------------------------
    // Is our report path still OURS?
    // -----------------------------------------------------------------------
    //
    // Why this exists: on 2026-10-03 the game died of an unhandled C++
    // exception twice -- 13:26:54 and 19:55:41, both 0xE06D7363 raised in
    // KERNELBASE.dll+0xC41CA on the main thread, both a few seconds after
    // `Local Raid Ended` / `Transfer Items: 1` -- and this probe reported
    // NOTHING, having printed a complete report for an access violation hours
    // earlier. There were two candidate causes and nothing on disk could
    // separate them, which is the whole problem:
    //
    //   (a) our handlers were displaced. SetUnhandledExceptionFilter and
    //       std::set_terminate are each ONE global slot, last writer wins -- and
    //       unlike AddVectoredExceptionHandler, which is a list and survives,
    //       there is no way back in on our own initiative. We install on our
    //       injected thread; the game then initialises for many more minutes,
    //       and IL2CPP, BsgLauncher or Battlestate's own reporter can take
    //       either slot at any point. That would explain the asymmetry exactly:
    //       the access violations reached us through the VEH (a list), the
    //       terminates did not.
    //
    //   (b) the game's own handler legitimately caught it and exited. In that
    //       case no unhandled filter is ever consulted and no displacement
    //       occurred -- the crash was simply never ours to see.
    //
    // (a) IS CONFIRMED. The warning fired within the hour of the check being
    // added, and in every session since. The terminate handler it displaced is
    // at a byte-identical address across processes (a system DLL); the unhandled
    // filter is per-session (the game's image).
    //
    // THIS FUNCTION NOW RE-ASSERTS, AND THE REASON IT USED NOT TO IS RECORDED
    // HERE BECAUSE IT WAS WRONG. It said: "re-asserting means displacing the
    // game's crash reporter -- suppressing Battlestate's dialog and its minidump
    // -- which would change how the process dies. That is the one property this
    // file must never violate."
    //
    // That reasoning assumed a swap. It is not a swap. on_unhandled() and
    // on_terminate() both call g_prev_uef / g_prev_terminate AFTER writing
    // their report, so the displaced handler is not removed, it is demoted to
    // running second. Battlestate's dialog and its minidump still happen. The
    // correct reading of the invariant is not "do not take the slot" but "do not
    // stop the process's own crash reporting from running", and chaining
    // satisfies the second without violating it.
    //
    // So there is no behaviour trade-off to gate behind a switch, and no switch:
    // the process dies the same way whether this repair happens or not, and a
    // config flag would only be a way to ship the blindness on purpose.
    //
    // Two further facts make this worth more than it looks. The reporting code
    // was never untested -- on_unhandled() has always called the same guarded
    // capture path the vectored handler uses, and tools/probe_test asserts on it.
    // It simply had never been REACHED, because the game took the door first.
    // And the class this buys is the one that produces no artefact at all:
    // measured on 2026-10-03, 3 of 3 crashes of shape 0xE06D7363 produced no
    // minidump, no probe line, and a game Player.log that stopped 3 s before the
    // process died, with its final line an unhandled NullReferenceException
    // carrying NO managed stack.
    //
    // The old read-modify-restore also had a window this does not:
    // SetUnhandledExceptionFilter has no getter, so asking meant passing nullptr,
    // which CLEARS the slot; an exception arriving on another thread between the
    // read and the write-back would have found no filter at all. Asking and
    // setting are now the same call. std::set_terminate(x) returns the previous
    // handler and had the same shape.

    // One warning per displaced slot, so a per-frame caller cannot flood the log.
    // INLINE, load-bearing as of 2026-10-04: common_hooks.cpp became a second includer of
    // this header (to call report_handler_owners at the raid boundary), and these two were
    // plain namespace-scope objects. Each TU emitted a definition and the LINK failed with
    // LNK2005 on both names. It surfaced as a link error rather than a compile error, which
    // is the good failure mode -- an ODR violation cannot pass unnoticed here.

    inline std::atomic<bool> g_warned_uef{ false };
    inline std::atomic<bool> g_warned_terminate{ false };

    // How often verify_handlers_throttled() may actually ask. Sixty seconds is
    // comfortably inside a raid and comfortably outside "every exception".
    constexpr uint64_t kVerifyIntervalMs = 60'000;

    // Returns true if both report doors were ALREADY ours, false if one had been
    // taken and has just been re-installed. Both doors work in either case, so
    // the boolean answers "did something have to be repaired", not "can this
    // file report a crash" -- the property worth asserting is the slot itself,
    // which tools/probe_test reads directly.
    // Forward declarations. verify_handlers() below resolves the taker through the
    // lock-free module table, and that table is defined further down this file -- the same
    // arrangement this file already uses for verify_handlers_throttled at :1414.
    inline bool module_owner_lockfree(void* addr, char* out, size_t out_len,
        unsigned& rva_out);

    inline bool verify_handlers(const char* context) {
        bool repaired = false;

        // RE-ASSERT, AND CHAIN. This is the whole change.
        //
        // It used to read the slot and put it straight back unchanged, on the
        // reasoning -- recorded in the note above, and WRONG -- that re-installing
        // would displace the game's crash reporter and suppress Battlestate's
        // dialog and minidump. It would not. on_unhandled() and on_terminate()
        // both call g_prev_uef / g_prev_terminate after writing their report, so
        // whoever held the slot keeps running, one call later. Taking the slot is
        // not taking the reporter; it is standing in front of it.
        //
        // SetUnhandledExceptionFilter has no getter, so asking and setting are the
        // same call: it returns the previous filter, and passing on_unhandled
        // installs ours in the same breath. There is no window in which the slot is
        // empty, which the old read-modify-restore did have.
        if (LPTOP_LEVEL_EXCEPTION_FILTER prev_uef = SetUnhandledExceptionFilter(on_unhandled);
            prev_uef != on_unhandled) {
            g_prev_uef = prev_uef;
            repaired = true;
            if (!g_warned_uef.exchange(true)) {
            // NAME THE TAKER HERE, in the VEH path. This is the line that has to work at
            // the moment of the crash rather than at a raid boundary: on 2026-10-04 the
            // REPAIRED lines arrived in the same breath as the FATAL, and a process that
            // dies there never reaches another boundary at which to be asked. The lookup is
            // CRT-free and lock-free on purpose -- see module_owner_lockfree's note.
            // ARGUMENT ORDER IS THE FORMAT ORDER. emit() is varargs, so a mismatch is
            // invisible to the compiler and fatal at runtime: the first version of these
            // two lines passed (owner, rva, context, ...) against a format reading
            // (%s)(%s)+0x%x..., so the SECOND %s was handed an `unsigned` and the CRT
            // read a string from it. Measured, twice: both crashing dumps faulted at
            // 0xA5230, and 0xA5230 is the RVA of the foreign handler -- the integer that
            // was passed where a pointer belonged. It faulted INSIDE the vectored
            // handler while reporting the original unhandled C++ exception, which is why
            // the report never appeared and the process died silently.
            char uef_owner[MAX_PATH] = {};
            unsigned uef_rva = 0;
            module_owner_lockfree(reinterpret_cast<void*>(prev_uef), uef_owner,
                sizeof uef_owner, uef_rva);
                emit("crash probe: REPAIRED (%s): the unhandled-exception filter had been "
                     "taken by %s+0x%x (0x%p, not our 0x%p). Re-installed ours in front, chained to "
                     "theirs, so an unhandled SEH exception now appears in THIS log and their "
                     "reporter still runs behind it. Their minidump is unaffected -- do not go "
                     "looking in %%LOCALAPPDATA%%\\CrashDumps expecting to stop finding dumps there.",
                    context ? context : "?", uef_owner, uef_rva, reinterpret_cast<void*>(prev_uef),
                    reinterpret_cast<void*>(on_unhandled));
            }
        } else {
            g_warned_uef.store(false);
        }

        if (std::terminate_handler prev_term = std::set_terminate(on_terminate);
            prev_term != on_terminate) {
            g_prev_terminate = prev_term;
            repaired = true;
            if (!g_warned_terminate.exchange(true)) {
            // Same reasoning as the UEF arm above.
            char term_owner[MAX_PATH] = {};
            unsigned term_rva = 0;
            module_owner_lockfree(reinterpret_cast<void*>(prev_term), term_owner,
                sizeof term_owner, term_rva);
                emit("crash probe: REPAIRED (%s): the terminate handler had been taken "
                     "(%s+0x%x = 0x%p, not our 0x%p). Re-installed ours in front and chained to theirs. "
                     "This is the 0xE06D7363 case, and on 2026-10-03 it was the silent one: two "
                     "crashes of that shape (13:26:54 and 19:55:41) produced NO minidump, NO "
                     "probe report, and a game log that stopped 3 s short of the process dying. "
                     "That is what this line exists to stop.",
                    context ? context : "?", term_owner, term_rva, reinterpret_cast<void*>(prev_term),
                    reinterpret_cast<void*>(on_terminate));
            }
        } else {
            g_warned_terminate.store(false);
        }
        return !repaired;
    }

    // The same check, rate-limited, for a caller that runs constantly.
    //
    // The vectored handler sees every exception the process raises -- thousands
    // per session -- so it is the one place that needs no cooperation from the
    // game and no edit to a game file to answer "are we still installed?". At
    // that frequency the four API calls cannot run every time, so the gate is a
    // GetTickCount64 read: cheap, no syscall on any Windows that matters, and it
    // fires roughly once a raid even on a long session.
    //
    // Called AFTER capture_and_maybe_report rather than inside it, so this stays
    // out of the capture path, and it is a no-op unless the handlers were taken.
    inline void verify_handlers_throttled(const char* context) {
        static std::atomic<uint64_t> g_last{ 0 };
        const uint64_t now = GetTickCount64();
        uint64_t last = g_last.load(std::memory_order_relaxed);
        // last == 0 means "never checked", not "checked at boot". GetTickCount64
        // counts from system start, so a process launched seconds after boot would
        // otherwise sit silent for its first full interval -- which is also what
        // made this untestable until it was fixed.
        if (last != 0 && now - last < kVerifyIntervalMs) return;
        if (!g_last.compare_exchange_strong(last, now,
                std::memory_order_relaxed, std::memory_order_relaxed))
            return;                                     // another thread is doing it
        verify_handlers(context);
    }

    // ===================================================================
    // WHO DISPLACED US -- part 1 of 2: a LOCK-FREE module table.
    // ===================================================================
    //
    // WHY THIS EXISTS, because the first version of this probe was not enough.
    // report_handler_owners() below answers the question at a raid boundary --
    // an ordinary thread, safe to call GetModuleHandleExW. But the 2026-10-04
    // crash showed the REPAIRED lines arriving in the SAME BREATH as the FATAL,
    // i.e. the slots were taken AT teardown, which is AFTER the boundary. A
    // process that dies there never reaches another boundary, so the boundary
    // line would have printed intact=yes and the TAKER WOULD NEVER BE NAMED --
    // the address from the REPAIRED line, and nothing more.
    //
    // So the attribution also has to work from the vectored handler, and THAT is
    // the whole constraint: GetModuleHandleExW takes the loader lock, and
    // deadlocking on the loader lock at teardown is the exact failure being
    // chased. So the names are resolved ONCE from a safe context into a static
    // table, and the VEH-side lookup is a linear scan over that table --
    // no API call, no lock, no allocation, nothing that can block.
    //
    // The table is a CACHE and can go stale: a module loaded after the last
    // refresh is unknown until the next refresh. That is the correct trade --
    // a stale answer that cannot deadlock beats a fresh one that can -- and every
    // unknown is printed as such rather than guessed at.
    struct module_rec {
        uintptr_t base;
        uintptr_t size;
        char name[72];
    };
    constexpr size_t kModuleTableMax = 256;
    inline module_rec g_modules[kModuleTableMax] = {};
    inline std::atomic<size_t> g_module_count{ 0 };

    // SAFE CONTEXTS ONLY. Resolves base -> name via K32EnumProcessModules, which
    // lives in kernel32 on Windows 7+, with the psapi export as the fallback.
    // Resolved dynamically rather than linked so no import library is needed.
    //
    // Our own image is deliberately NOT in this table: it is manual-mapped and
    // may be absent from the loader lists (the boot banner says so), and
    // module_owner_lockfree checks g_base/g_size before consulting the table
    // anyway -- so a displacement BY US can never be misattributed.
    inline void refresh_module_table() {
        using enum_modules_fn = BOOL(WINAPI*)(HANDLE, HMODULE*, DWORD, LPDWORD);
        enum_modules_fn enum_modules = nullptr;
        if (HMODULE k32 = GetModuleHandleW(L"kernel32.dll"))
            enum_modules = reinterpret_cast<enum_modules_fn>(
                GetProcAddress(k32, "K32EnumProcessModules"));
        if (!enum_modules) {
            if (HMODULE ps = GetModuleHandleW(L"psapi.dll"))
                enum_modules = reinterpret_cast<enum_modules_fn>(
                    GetProcAddress(ps, "EnumProcessModules"));
        }
        if (!enum_modules) return;

        HMODULE mods[kModuleTableMax] = {};
        DWORD needed = 0;
        if (!enum_modules(GetCurrentProcess(), mods, sizeof(mods), &needed)) return;

        size_t n = 0;
        const DWORD cap = needed / sizeof(HMODULE);
        const size_t limit = (cap < kModuleTableMax) ? cap : kModuleTableMax;
        for (size_t i = 0; i < limit; ++i) {
            if (!mods[i]) continue;
            // Basename only: a full path is noise in a one-line report.
            char path[MAX_PATH] = {};
            if (!GetModuleFileNameA(mods[i], path, MAX_PATH)) continue;
            const char* leaf = path;
            for (const char* q = path; *q; ++q) if (*q == '\\') leaf = q + 1;
            module_rec& r = g_modules[n];
            r.base = reinterpret_cast<uintptr_t>(mods[i]);
            const auto extent = mapped_extent(reinterpret_cast<const std::byte*>(mods[i]));
            r.size = extent ? static_cast<uintptr_t>(extent) : 0;
            std::snprintf(r.name, sizeof(r.name), "%s", leaf);
            if (++n >= kModuleTableMax) break;
        }
        // Publish AFTER filling, so a concurrent reader sees either the old count
        // or the new one against fully written records -- never a half-written one.
        g_module_count.store(n, std::memory_order_release);
    }

    // THE VEH-SAFE LOOKUP. A linear scan and pointer compares; no API call, no
    // lock, no allocation. Callable from the vectored handler.
    // *** CRT-FREE, AND THAT IS LOAD-BEARING ***
    //
    // The first version used std::snprintf to copy the name and to format the "not found"
    // text. It crashed the game within seconds of launch, and the mechanism is worth
    // writing down because it is very easy to repeat:
    //
    //   1. EFT throws C++ exceptions constantly, including during startup.
    //   2. The VEH fires and calls verify_handlers_throttled, whose FIRST call is immediate
    //      (last == 0 means "never checked", so the 60 s interval does not delay it).
    //   3. A slot reads as displaced, so this function runs -- INSIDE the vectored handler.
    //   4. std::snprintf re-entered the CRT at the exact point the process was already
    //      unhappy, faulted, and the VEH fired AGAIN from inside the first one.
    //   5. A recursive fault inside a VEH is terminal, and the probe's own report path was
    //      already mid-fault -- so it printed NOTHING AT ALL, which is the detail that made
    //      this look like a mystery rather than a bug.
    //
    // WER recorded it as ucrtbase.dll / c0000005 / +0x65655, the SAME ucrtbase site twice in
    // one report: that repetition is the recursion, not two independent faults. The user's
    // "it crashes immediately" plus "event log says ucrtbase" was the whole diagnosis.
    //
    // So: bounded copies by hand. No printf, no CRT, no allocation, nothing that can block.
    // The RVA is RETURNED to the caller and formatted by emit(), which already runs in this
    // context safely. VirtualQuery is kept -- it is a syscall with no lock -- and hand-hexed,
    // because dropping the region base would drop the diagnosis with it.
    inline void put_bounded(char* out, const size_t out_len, const char* s) {
        if (!out_len) return;
        size_t i = 0;
        if (s) while (s[i] && i + 1 < out_len) { out[i] = s[i]; ++i; }
        out[i] = '\0';
    }

    inline void put_hex_bounded(char* out, const size_t out_len, const uintptr_t v) {
        static const char kHex[] = "0123456789abcdef";
        char tmp[2 + sizeof(uintptr_t) * 2] = {};
        size_t n = 0;
        tmp[n++] = '0';
        tmp[n++] = 'x';
        for (int shift = static_cast<int>(sizeof(uintptr_t) * 8) - 4; shift >= 0; shift -= 4)
            tmp[n++] = kHex[(v >> shift) & 0xF];
        put_bounded(out, out_len, tmp);
    }

    // THE VEH-SAFE LOOKUP: bounded copies and a linear scan over the table. No CRT, no
    // blocking API call, no allocation. Callable from the vectored handler.
    inline bool module_owner_lockfree(void* addr, char* out, const size_t out_len,
        unsigned& rva_out) {
        rva_out = 0;
        if (!out_len) return false;
        out[0] = '\0';

        if (!addr) { put_bounded(out, out_len, "(null slot)"); return false; }
        const auto a = reinterpret_cast<uintptr_t>(addr);

        // Ours first: manual-mapped, so likely absent from the table.
        const auto self = reinterpret_cast<uintptr_t>(g_base);
        if (self && g_size && a >= self && a < self + g_size) {
            put_bounded(out, out_len, "TarkovAddons.dll (THIS module, manual map)");
            rva_out = static_cast<unsigned>(a - self);
            return true;
        }

        const size_t n = g_module_count.load(std::memory_order_acquire);
        for (size_t i = 0; i < n; ++i) {
            const module_rec& r = g_modules[i];
            if (a < r.base) continue;
            // size 0 means the extent could not be read; "to the end of the address space"
            // would be wrong, so fall back to an exact base match.
            if (r.size ? (a < r.base + r.size) : (a == r.base)) {
                put_bounded(out, out_len, r.name);
                rva_out = static_cast<unsigned>(a - r.base);
                return true;
            }
        }

        // Unknown, and reported as unknown. Hand-formatted: no printf anywhere in here.
        put_bounded(out, out_len, "(not in the module table; region base 0x");
        if (out_len > 48) {
            MEMORY_BASIC_INFORMATION mbi{};
            const uintptr_t rb = VirtualQuery(addr, &mbi, sizeof(mbi))
                ? reinterpret_cast<uintptr_t>(mbi.AllocationBase) : 0;
            char hex[2 + sizeof(uintptr_t) * 2] = {};
            put_hex_bounded(hex, sizeof hex, rb);
            char tail[8] = {};
            put_bounded(tail, sizeof tail, ")");
            size_t at = 0;
            while (at + 1 < out_len && out[at]) ++at;
            put_bounded(out + at, out_len - at, hex);
            at = 0;
            while (at + 1 < out_len && out[at]) ++at;
            put_bounded(out + at, out_len - at, tail);
        }
        return false;
    }



    // Resolve BOTH chained-to handlers and say who holds them, ONCE per call.
    //
    // `intact` is the direct answer to "is anything displacing us right now":
    // verify_handlers returns false when it had to re-assert a slot, and in that
    // case it has just refreshed g_prev_uef / g_prev_terminate to whoever DID
    // hold it -- so the owner named below is the TAKER. When intact, those two
    // still hold the chain captured at install, which is the useful baseline.
    //
    // Safe to call from any ordinary thread. NOT safe from the vectored handler,
    // for the loader-lock reason above; nothing calls it from there.
    // Reports handler ownership, but ONLY when there is something to say.
    //
    // The first version reported on every call. Its caller is the raid-boundary poll, which
    // runs every menu frame, so it produced **13,547 identical lines** and 3.06 MB of log in
    // one session -- and tools/tracy/README.md's flooding rule applies to our own diagnostics
    // exactly as it does to logger::error. It is also the same mistake the raid-boundary
    // diagnostic made at 16,964 lines, which this file's own game_state.h comment documents.
    // Unchanged ownership is not news.
    //
    // So it speaks on exactly three occasions:
    //   1. the first call, for the baseline
    //   2. whenever verify_handlers() found a slot TAKEN and had to re-assert it -- the
    //      interesting case, and rare
    //   3. whenever the owner CHANGES, so a slot moving from X to Y is visible
    //
    // (2) and (3) are both cheap: one atomic exchange and one pointer compare.
    inline void report_handler_owners(const char* context) {
        static std::atomic<bool> g_reported_once{ false };
        static void* g_last_uef = nullptr;
        static void* g_last_term = nullptr;

        const bool intact = verify_handlers(context);
        void* const uef_slot = reinterpret_cast<void*>(g_prev_uef);
        void* const term_slot = reinterpret_cast<void*>(g_prev_terminate);

        const bool first = !g_reported_once.exchange(true);
        const bool moved = (uef_slot != g_last_uef) || (term_slot != g_last_term);
        if (intact && !first && !moved) return;
        g_last_uef = uef_slot;
        g_last_term = term_slot;

        char uef[MAX_PATH] = {};
        char term[MAX_PATH] = {};
        unsigned rva_uef = 0;
        unsigned term_rva = 0;
        module_owner_lockfree(uef_slot, uef, sizeof uef, rva_uef);
        module_owner_lockfree(term_slot, term, sizeof term, term_rva);

        // "(null slot)" used to be the whole story at the boundary, which reads like a
        // failure and is not one: it means nothing held the slot before us and nothing has
        // displaced us since. Say that, so the line does not have to be re-derived.
        char uef_txt[160] = {};
        char term_txt[160] = {};
        if (uef_slot)
            snprintf(uef_txt, sizeof uef_txt, "%s+0x%x", uef, rva_uef);
        else
            snprintf(uef_txt, sizeof uef_txt, "%s", "(empty -- nothing held it before us)");
        if (term_slot)
            snprintf(term_txt, sizeof term_txt, "%s+0x%x", term, term_rva);
        else
            snprintf(term_txt, sizeof term_txt, "%s", "(empty -- nothing held it before us)");

        emit("crash probe: handler-owner (%s): intact=%s | UEF slot -> %s (0x%p) "
             "| terminate slot -> %s (0x%p) | ours are 0x%p / 0x%p",
            context ? context : "?", intact ? "yes" : "NO, a slot was TAKEN and re-asserted",
            uef_txt, uef_slot, term_txt, term_slot,
            static_cast<void*>(on_unhandled), static_cast<void*>(on_terminate));
    }


    inline void install() {
        // Populate the module table here. install() runs on the init THREAD (dllmain.cpp
        // `init`), not from DllMain, so EnumProcessModules is safe -- there is no loader
        // lock held under us at this point, which is the whole reason this is not done
        // from the vectored handler.
        refresh_module_table();
        // Same reasoning, same place: the memory counters are resolved HERE rather
        // than at report time, so emit_memory_state() never takes the loader lock.
        resolve_memory_apis();
        if (g_installed.exchange(true)) return;
        HMODULE self = nullptr;
        if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
            GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
            reinterpret_cast<LPCWSTR>(&install), &self))
            return;
        g_base = reinterpret_cast<const std::byte*>(self);
        g_size = mapped_extent(g_base);
        if (!g_size) g_size = 0x1000000; // last-resort fallback

        open_log();
        AddVectoredExceptionHandler(1, handler);
        g_prev_uef = SetUnhandledExceptionFilter(on_unhandled);
        g_prev_terminate = std::set_terminate(on_terminate);

        char armed[256];
        std::snprintf(armed, sizeof(armed),
            "crash probe: armed, this module at 0x%llX mapped extent 0x%llX%s%s",
            static_cast<unsigned long long>(reinterpret_cast<uintptr_t>(g_base)),
            static_cast<unsigned long long>(g_size),
            g_size == 0x1000000 ? " (FALLBACK -- extent undetermined)" : "",
            g_log == INVALID_HANDLE_VALUE ? " (NO LOG HANDLE -- reports will be lost)" : "");
        logger::info(armed);
        logger::info("crash probe: captures EVERY exception (lock-free ring, no I/O); "
                      "reports only on non-continuable faults, std::terminate, and the "
                      "unhandled-exception filter. A C++ throw is captured, not reported here.");

        // Build identity, so a crash log can be matched to a PDB later.
        //
        // 2026-09-30. Crash #4 (19:36:19) could NOT be symbolised: the log recorded the
        // base and extent but nothing that ties it to a particular binary, the build that
        // was live at 19:00:20 no longer existed anywhere on disk, and the only PDBs left
        // were from 18:31 and 19:37. Every symbol resolved against either would have been
        // a plausible name for the wrong instruction -- precisely the failure mode the
        // nearest-preceding-public-symbol lookup already has, one level up.
        //
        // 2026-09-30. The 23:24:06 crash repeated it from the other end: the deployed PDB
        // did match the deployed DLL, but out/ had already been rebuilt twice by the time
        // anyone looked, so the .map beside it described a different binary. The stamp is
        // what makes that detectable instead of silently wrong.
        //
        // 1. The PE TimeDateStamp plus SizeOfImage identifies the LINK. Not the file:
        //    two builds in the same second collide, but that is a far smaller risk than
        //    no identity at all.
        // 2. The RSDS CodeView record is the AUTHORITATIVE answer, and it is better
        //    than anything the loader can tell us: it is a per-link GUID plus the PDB
        //    path, embedded in the image itself. Crash #4 (19:36) could not be
        //    symbolised at all because the log named no binary, the build was gone from
        //    disk, and the surviving PDBs were from either side of it. This record
        //    names the exact PDB to reach for.
        // 3. GetModuleFileNameW is NOT reported as identity, and the reason is worth
        //    keeping. It walks the PEB loader lists; this module is not correctly
        //    registered in them (a manual mapper is loading it), so it returned
        //    "C:\Windows\System32\X3DAudio1_7.dll" for our own base. That is also very
        //    likely why FindResourceW could not find our RCDATA, which is the whole
        //    reason util/pe_resource.h walks .rsrc by hand. So the name is printed, but
        //    explicitly as a finding rather than as an identity.
        // 4. The first version of this line was itself TRUNCATED at 199 characters,
        //    mid-word, by a 200-byte snprintf buffer. std::format cannot truncate, so it
        //    is used here; that was my bug, not the logger's.
        {
            const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(g_base);
            const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(
                g_base + dos->e_lfanew);
            logger::info(std::format(
                "crash probe: build stamp=0x{:08X} size_of_image=0x{:X} -- match these "
                "against the PDB's own headers before trusting any symbol",
                static_cast<unsigned>(nt->FileHeader.TimeDateStamp),
                static_cast<unsigned>(nt->OptionalHeader.SizeOfImage)));

            // RSDS: {DataDirectory[DEBUG]} -> IMAGE_DEBUG_DIRECTORY[] -> RSDS header.
            //
            // Measured on this project on 2026-09-30: the CodeView entry IS present and
            // correctly sized (96 bytes = 4 sig + 16 guid + 4 age + 72 name) but every
            // byte of it is ZERO except age=1. That is the linker's placeholder for "a PDB
            // was produced but its path is not recorded in the image", so the obvious
            // implementation of this -- print rsds->PdbFileName -- would have shipped a
            // line reading "pdb=" followed by nothing, on every boot, forever. A
            // diagnostic whose normal output is a placeholder trains the reader to skip it.
            //
            // So the zero-filled case is reported as its own finding, with the instruction
            // to use the stamp above, which is the identity that IS always present.
            std::string pdb_text = "no CodeView/DEBUG directory at all";
            const auto& dbg =
                nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_DEBUG];
            if (dbg.VirtualAddress && dbg.Size) {
                pdb_text = "no RSDS record (CodeView entry absent)";
                const auto* dir = reinterpret_cast<const IMAGE_DEBUG_DIRECTORY*>(
                    g_base + dbg.VirtualAddress);
                const DWORD count = dbg.Size / sizeof(IMAGE_DEBUG_DIRECTORY);
                for (DWORD i = 0; i < count; ++i) {
                    if (dir[i].Type != IMAGE_DEBUG_TYPE_CODEVIEW || !dir[i].AddressOfRawData)
                        continue;
                    const auto* rsds = reinterpret_cast<const IMAGE_DEBUG_RSDS_HEADER*>(
                        g_base + dir[i].AddressOfRawData);
                    if (rsds->Signature != IMAGE_DEBUG_RSDS_SIGNATURE) {
                        pdb_text = std::format(
                            "CodeView entry present but ZERO-FILLED (sig=0x{:08X}, "
                            "SizeOfData={}) -- the linker emitted a placeholder rather than "
                            "the PDB path, so there is no in-image pointer to a matching "
                            "PDB. Use the stamp above; the PDB itself is correct.",
                            static_cast<unsigned>(rsds->Signature),
                            static_cast<unsigned>(dir[i].SizeOfData));
                        continue;
                    }
                    // PdbFileName is declared CHAR[1], and std::format captures
                    // its arguments by const reference -- so passing the array
                    // itself asks the formatter to format a char[1], which is a
                    // compile error rather than an implicit decay. Binding it to
                    // a pointer first is what every other call site does by
                    // habit; here it is load-bearing. MSVC accepted the array
                    // under the project's language settings, so this only
                    // surfaced when the header was compiled under /std:c++latest.
                    const char* pdb_name = rsds->PdbFileName;
                    pdb_text = std::format(
                        "path={} guid={:08X}-{:04X}-{:04X}-{:02X}{:02X}-{:02X}{:02X}{:02X}"
                        "{:02X}{:02X}{:02X} age={}",
                        pdb_name,
                        rsds->Guid.Data1, rsds->Guid.Data2, rsds->Guid.Data3,
                        rsds->Guid.Data4[0], rsds->Guid.Data4[1],
                        rsds->Guid.Data4[2], rsds->Guid.Data4[3], rsds->Guid.Data4[4],
                        rsds->Guid.Data4[5], rsds->Guid.Data4[6], rsds->Guid.Data4[7],
                        rsds->Age);
                    break;
                }
            }
            logger::info(std::format("crash probe: pdb -> {}", pdb_text));

            wchar_t path[MAX_PATH] = {};
            if (GetModuleFileNameW(reinterpret_cast<HMODULE>(const_cast<std::byte*>(g_base)),
                    path, MAX_PATH) && path[0]) {
                // std::format has no formatter for wchar_t*, so narrow it here rather than
                // pulling a project-wide conversion helper into a header this standalone.
                // The name is ASCII in practice (a Windows system path); the multi-byte
                // call is only there so a stray non-ASCII character cannot fail the boot log.
                char narrow[MAX_PATH * 3] = {};
                const int n = WideCharToMultiByte(CP_UTF8, 0, path, -1, narrow,
                    static_cast<int>(sizeof(narrow)), nullptr, nullptr);
                if (n > 0) {
                    logger::info(std::format(
                        "crash probe: loader names this base \"{}\" -- UNRELIABLE as identity: "
                        "our image is not correctly registered in the PEB loader lists (manual "
                        "map), so a name that is not TarkovAddons.dll is expected, and is also "
                        "why FindResourceW cannot see our RCDATA. Trust the build stamp above.",
                        narrow));
                }
            }
        }

        // Establish the ownership baseline while we still know it is true, so the
        // warning below can never be a false alarm at boot. From here on the
        // answer is only knowable by asking again -- which is what
        // verify_handlers() is for, and why it is public.
        verify_handlers("install");
    }
} // namespace crash_probe
