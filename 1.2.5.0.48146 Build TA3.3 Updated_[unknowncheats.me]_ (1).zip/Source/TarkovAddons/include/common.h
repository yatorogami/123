#pragma once

// Common includes for TarkovAddons translation units.
//
// This is the precompiled header, renamed from pch.h when the project moved to
// CMake (e605d6395). It IS precompiled: TarkovAddons/CMakeLists.txt declares it
// with target_precompile_headers, and TarkovAddons.vcxproj still builds it via
// /Yc. Every TU names it on line 1:
//
//     #include "common.h"
//
// Which is exactly what the old pch.h did. The move deleted pch.h/pch.cpp and
// dropped /Yu along with them, which is not a mechanical swap -- it left every
// one of the 82 TUs re-parsing windows.h and nlohmann/json (56.9 MB of the old
// 249 MB PCH) on every build. Restored 2026-10-09.
//
// Deliberately NOT included here: project headers (Module.h, ModuleManager.h,
// il2cpp/*, config/*, ...), imgui.h, and the vendored trees (external/,
// il2cpp/libil2cpp/). A PCH carrying project headers silently supplies
// includes a .cpp never wrote, and any file that comes to depend on the PCH
// for a declaration breaks invisibly when the PCH changes. Sharing windows.h
// and <string> is pure win; sharing our own headers hides real bugs. This was
// not hypothetical: switching the PCH on once silently repaired a missing
// <cstdint> in gui/menu/imgui_addons.h, which is why that header now includes
// it itself.

// --- Win32 ---
#include <windows.h>
#include <psapi.h>
#include <shlobj.h>

// --- C++ standard library ---
#include <algorithm>
#include <array>
#include <atomic>
#include <charconv>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <exception>
#include <filesystem>
#include <format>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <random>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

// --- Third party ---
#include <nlohmann/json.hpp>
