#include "common.h"
#include "FloatSliderEditableValue.h"

FloatSliderEditableValue::FloatSliderEditableValue(float initial, float min, float max, const std::string& n,
    const std::string& tooltip_key) : ConfigValue(n) {
    this->value_ = initial;
    this->def_ = initial;
    this->min_ = min;
    this->max_ = max;
    // Store the KEY, not tr(key). ConfigValue::get_tooltip() resolves it per
    // frame, because this constructor runs while ModuleManager is being built
    // and no translation is loaded yet -- see the note on set_tooltip there.
    this->set_tooltip(tooltip_key);
}

void FloatSliderEditableValue::draw() {
    const std::string tip = this->get_tooltip();
    imgui_addons::slider_float_editable(this->get_imgui_title(), &value_, this->min_, this->max_,
        disabled_, tip.empty() ? nullptr : tip.c_str());
}

void FloatSliderEditableValue::set(const std::string& string) {
    float parsed = 0.f;
    this->value_ = config_parse::to_float(string, parsed) ? parsed : this->def_;
}

std::string FloatSliderEditableValue::get() {
    return to_string(this->value_);
}

std::string FloatSliderEditableValue::get_default() {
    return to_string(this->def_);
}

[[nodiscard]] float FloatSliderEditableValue::get_value() const {
    return this->value_;
}

void FloatSliderEditableValue::set_value(const float v) {
    value_ = v < min_ ? min_ : (v > max_ ? max_ : v);
}

std::string FloatSliderEditableValue::to_string(float v) {
    return std::to_string(v);
}
