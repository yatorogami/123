#include "common.h"
#include "ConfigValue.h"

ConfigValue::ConfigValue(const std::string& name) {
    this->name_ = name;
}

void ConfigValue::reg(const std::string& mod) {
    this->module_ = mod;
}

void ConfigValue::set_disabled(const bool d) { disabled_ = d; }

[[nodiscard]] bool ConfigValue::is_disabled() const { return disabled_; }

void ConfigValue::set_hidden_in_owner_menu(const bool hidden) { hidden_in_owner_menu_ = hidden; }

[[nodiscard]] bool ConfigValue::is_hidden_in_owner_menu() const { return hidden_in_owner_menu_; }

void ConfigValue::set_master_toggle(const bool m) { master_toggle_ = m; }

bool ConfigValue::is_changed() { return this->get() != this->get_default(); }

void ConfigValue::set_tooltip(const std::string& i18n_key) { this->tooltip_key_ = i18n_key; }

[[nodiscard]] std::string ConfigValue::get_tooltip() const {
    // Resolved per call, never cached as text. See the note in ConfigValue.h for
    // the ordering that makes an eager translation permanently wrong.
    return this->tooltip_key_.empty() ? std::string() : i18n::tr(this->tooltip_key_);
}

void ConfigValue::set_favorite(const bool favorite) { favorite_ = favorite; }

[[nodiscard]] bool ConfigValue::is_favorite() const { return favorite_; }

[[nodiscard]] std::string ConfigValue::get_favorite_config_key() const {
    return "favorite##" + this->name_ + "##" + this->module_;
}

[[nodiscard]] std::string ConfigValue::get_config_key() const {
    return this->name_ + "##" + this->module_;
}

std::string ConfigValue::get_imgui_title() const {
    return i18n::tr(this->name_) + "##" + this->module_;
}
