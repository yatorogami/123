#pragma once
#include "ConfigValue.h"
#include "../gui/menu/imgui_addons.h"

#pragma pack(push, 1)
class FloatSliderEditableValue : public ConfigValue
{
  public:
    FloatSliderEditableValue(float initial, float min, float max, const std::string& n,
        const std::string& tooltip_key = "");

    void draw() override;

    void set(const std::string& string) override;

    std::string get() override;

    std::string get_default() override;

    [[nodiscard]] float get_value() const;

    // Programmatic setter, clamped to the same range the plain FloatSliderValue
    // clamps to. This was missing here, which made the editable type a strict
    // subset rather than a drop-in replacement: EspModule.h calls
    // radar_range->set_value(...) on a MinimapModule value, so converting
    // Minimap's sliders broke a call from the frozen ESP file. The two types
    // are meant to be interchangeable, so this one carries the full API.
    void set_value(const float v);

  private:
    float value_;
    float def_;
    float min_;
    float max_;

    static std::string to_string(float v);
};
#pragma pack(pop)
