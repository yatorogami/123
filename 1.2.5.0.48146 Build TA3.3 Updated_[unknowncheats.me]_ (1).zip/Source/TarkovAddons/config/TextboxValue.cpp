#include "common.h"
#include "TextboxValue.h"

TextboxValue::TextboxValue(const std::string& initial, const std::string& n) : ConfigValue(n) {
    this->value_ = initial;
    this->def_ = initial;
}

void TextboxValue::draw() {
    imgui_addons::textbox(this->get_imgui_title(), &this->value_);
}

void TextboxValue::set(const std::string& string) {
    this->value_ = string;
}

std::string TextboxValue::get() {
    return this->value_;
}

std::string TextboxValue::get_default() {
    return this->def_;
}
