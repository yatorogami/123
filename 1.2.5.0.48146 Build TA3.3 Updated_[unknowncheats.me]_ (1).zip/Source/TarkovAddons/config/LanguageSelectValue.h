#pragma once

#include <algorithm>
#include <charconv>
#include <string>
#include <system_error>
#include <vector>

#include "ConfigValue.h"
#include "../gui/menu/imgui_addons.h"
#include "../util/i18n.h"

class LanguageSelectValue : public ConfigValue
{
  public:
    LanguageSelectValue(const int initial, const std::string& n);

    void draw() override;

    void rebuild_labels();

    void set(const std::string& string) override;

    std::string get() override;

    std::string get_default() override;

    [[nodiscard]] int get_value() const;

    void set_value(const int v);

    [[nodiscard]] size_t option_count() const;

  private:
    int value_;
    int def_;
    std::vector<std::string> labels_;
    std::vector<std::string> locale_codes_;

    void clamp_value();

    static std::string to_string(const int v);

    // Must not throw -- see the identical comment in SelectValue::from_string.
    // This one is the one that actually fired: the MenuSectionValue that shared
    // this value's config key wrote an empty value, and std::stoi("") threw
    // std::invalid_argument straight out of ConfigModule::load_config().
    static int from_string(const std::string& string);
};