#pragma once
#include <imgui.h>
#include <sstream>
#include <vector>

#include "ConfigValue.h"
#include "../gui/menu/imgui_addons.h"
#include "../util/utils.h"

#pragma pack(push, 1)
class ColorpickerValue : public ConfigValue
{
  public:
    ColorpickerValue(const ImVec4 initial, const std::string& n);

    void draw() override;

    void set(const std::string& string) override;

    std::string get() override;

    std::string get_default() override;

    [[nodiscard]] ImVec4 get_value() const;

  private:
    ImVec4 value_;
    ImVec4 def_;

    static std::string to_string(ImVec4 v);

    // Reached from load_config() with whatever the file held. The old version
    // did four unchecked elements[] indexings plus four stof calls, so a
    // truncated or hand-edited colour threw either std::out_of_range or
    // std::invalid_argument out of the config loader. Bound the element count
    // and make each component total; the caller falls back to the default.
    static bool from_string(const std::string& string, ImVec4& out);
};
#pragma pack(pop)
