#pragma once

#include <functional>

#include "ConfigValue.h"
#include <imgui.h>

class InfoDrawValue : public ConfigValue
{
  public:
    explicit InfoDrawValue(const std::function<void()>& draw_fn, const std::string& id = "Info");

    void draw() override;

    void set(const std::string&) override;
    std::string get() override;
    std::string get_default() override;

  private:
    std::function<void()> draw_fn_;
};