#pragma once
#include <algorithm>
#include <cctype>
#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <string.h>
#include <unordered_set>
#include <vector>

#include "ConfigValue.h"
#include "../module/game_item_db.h"
#include "../gui/menu/imgui_addons.h"
#include "../util/i18n.h"

/**
 * Search box with autocomplete over the LIVE game item database
 * (game_items::snapshot() — every ItemTemplate from the in-raid ItemFactory,
 * named in the game's current locale). Type a name or id, click a result ->
 * the selected BSG id is stored and pushed to a target via on_select.
 */
#pragma pack(push, 1)
class ItemSearchValue : public ConfigValue
{
  public:
    // `hide_quest_items` should be true ONLY for pickers that SPAWN the chosen
    // template (create-item UI, weapon builder). Quest items are spawned by the
    // Quest Completer's own path, which knows the required state transitions; the
    // generic spawn path mishandles them (they land in QuestRaidItems and the
    // placement animation breaks).
    //
    // Leave it false for pickers that only SELECT/filter/teleport to existing
    // world loot (ESP loot filter, Loot Teleport) — quest items do legitimately
    // appear in raids there and must stay selectable and named.
    explicit ItemSearchValue(const std::string& n,
        std::function<void(const std::string&)> on_select = nullptr,
        bool hide_quest_items = false,
        bool multi = false);

    void draw() override;

    // persisted value = the selected id
    void set(const std::string& string) override;

    std::string get() override;
    std::string get_default() override;

    [[nodiscard]] std::string get_selected_id() const;

    // The complete set of ids the current query matches -- or, when the user
    // has clicked a row, the one they pinned. A multi-select box reports this
    // instead of get_selected_id(), so a caller does not have to know which one
    // the user happened to click.
    //
    // A shared_ptr to an IMMUTABLE set, not a reference into the live member.
    // refilter() and the click path run on the RENDER thread while the loot
    // filters run on the GAME thread, and handing the game a pointer into a
    // container being rehashed is the crash b9ca0b366 already fixed once for
    // ESP -- "the render thread handed the game thread a pointer the game
    // thread could free", same shape, same failure. The reader holds its own
    // reference for the call, so a swap underneath it is invisible.
    [[nodiscard]] std::shared_ptr<const std::unordered_set<std::string>> get_matched_ids() const;
    [[nodiscard]] bool is_multi() const;

  private:
    static constexpr int MAX_RESULTS = 40;

    std::string query_;
    std::string selected_id_;
    std::string selected_name_;
    std::function<void(const std::string&)> on_select_;
    bool hide_quest_items_ = false;
    // True = this box selects every result the query matches, so the caller does
    // not depend on the user clicking one of them. See get_matched_ids().
    bool multi_ = false;

    std::vector<int> results_;

    // What the current query matched, published immutable. See
    // get_matched_ids() for why this is not a plain member. Never empty in
    // practice -- an empty query publishes an empty set rather than null, so a
    // multi box reads "nothing selected" and not "no answer".
    std::shared_ptr<const std::unordered_set<std::string>> matched_ids_ =
        std::make_shared<const std::unordered_set<std::string>>();

    // True when this entry must not appear in the dropdown. Only consulted when the
    // picker is a spawn path (see the ctor note).
    bool entry_hidden(size_t index) const;

    // lowercased "fr en id" haystack per item, built once
    static std::vector<std::string>& haystacks();

    // Which published game_items database haystacks() was built from. game_items
    // republishes the same entry count with localized names after its background
    // prewarm, so the haystacks must be keyed on the object's identity, not on
    // its size -- otherwise the search box keeps matching raw template slugs.
    static game_items::db_snapshot_ptr index_snapshot_;

    static void build_index();

    void refilter();
};
#pragma pack(pop)
