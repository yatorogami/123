#pragma once
#include <string>

#include "ConfigValue.h"
// ImGui::Separator lives in the core imgui.h, which is not on ConfigValue.h's
// include path. imgui_addons.h includes it (and is the header every other
// drawing value reaches it through), so this goes through the same door.
#include "../gui/menu/imgui_addons.h"

/**
 * A ConfigValue that draws nothing but an ImGui separator.
 *
 * WHY THIS EXISTS AS A VALUE RATHER THAN A FLAG ON ConfigValue
 * ------------------------------------------------------------
 * The menu's card body is a straight walk over the module's config_values:
 *
 *     m->apply([](ConfigValue* c) { if (!c->is_hidden_in_owner_menu()) c->draw(); });
 *
 * so the only way to break a long run of controls into visually distinct groups,
 * without every module hand-rolling its own draw_menu_extra() and keeping a
 * parallel hide list in sync, is to put something in that run that draws the
 * group boundary. That something is this.
 *
 * It has the same lifecycle as any other value so it can sit in a ctor's
 * conf() initialiser list between two controls, which is the only place the
 * ordering that matters is visible. `menu.cpp` and `ItemSearchValue.cpp` were
 * the first to want this: the Loot Teleporter card stacks a preview counter, an
 * item search and two dropdown+button pairs, and the ESP card stacks exfil,
 * grenade/tripwire and keypanel sub-groups inside one section, which at 25+
 * controls read as one undifferentiated column.
 *
 * It draws a separator ONLY -- no label, no text, no state. A group heading is
 * MenuSectionValue's job, and the two compose: a heading then the group's
 * controls, then a SeparatorValue, then the next heading.
 *
 * `get()`/`get_default()` return empty strings rather than throwing or
 * returning garbage. The config round-trip calls set()/get() on every
 * registered value; a value that owns no state must survive that with an
 * empty string and never appear in a saved file.
 */
#pragma pack(push, 1)
class SeparatorValue : public ConfigValue
{
  public:
    explicit SeparatorValue(const std::string& name = "separator_val");

    void draw() override;

    void set(const std::string& string) override;
    std::string get() override;
    std::string get_default() override;
  private:
};
#pragma pack(pop)
