#include "common.h"
#include "ItemSearchValue.h"
#include "../util/text_fold.h"

// `hide_quest_items` should be true ONLY for pickers that SPAWN the chosen
// template (create-item UI, weapon builder). Quest items are spawned by the
// Quest Completer's own path, which knows the required state transitions; the
// generic spawn path mishandles them (they land in QuestRaidItems and the
// placement animation breaks).
//
// Leave it false for pickers that only SELECT/filter/teleport to existing
// world loot (ESP loot filter, Loot Teleport) — quest items do legitimately
// appear in raids there and must stay selectable and named.
ItemSearchValue::ItemSearchValue(const std::string& n,
    std::function<void(const std::string&)> on_select,
    bool hide_quest_items, bool multi) : ConfigValue(n) {
    this->on_select_ = std::move(on_select);
    this->hide_quest_items_ = hide_quest_items;
    this->multi_ = multi;
}

void ItemSearchValue::draw() {
    build_index();

    const std::string title = this->get_imgui_title();
    ImGui::PushID(title.c_str());
    // Same lock-out rendering as SelectValue: set_disabled() must gray the
    // input, not just be stored on the base class.
    const bool disabled = this->is_disabled();
    if (disabled) ImGui::BeginDisabled();

    // label
    std::string just_text = title.substr(0, title.find("##"));
    ImGui::TextColored(disabled ? menu::with_alpha(menu::palette::muted, 0.7f) : ImGui::GetStyle().Colors[ImGuiCol_Text],
        "%s", just_text.c_str());

    // full-width search input
    //
    // The padding wrapper is what makes this box readable: theme()'s
    // FramePadding is (4, 3), tuned for the dense card rows, and in a field
    // where the typed text IS the content it reads as squished against the
    // left and top edge. Scoped to this one widget -- see the note on
    // push_search_padding().
    ImGui::SetNextItemWidth(-1.f);
    imgui_addons::push_search_padding();
    const bool typed = ImGui::InputTextWithHint("##itemsearch",
        i18n::tr("item_search_hint_inf").c_str(), &query_);
    imgui_addons::pop_search_padding();
    if (typed)
    {
        refilter();
    }

    // current selection summary
    if (!selected_id_.empty())
    {
        // The id is a template slug: mono keeps it scannable as a column of
        // hex, and the name beside it stays in the UI face.
        const bool mono = imgui_addons::push_mono_font();
        ImGui::TextColored(ImGui::GetStyle().Colors[ImGuiCol_CheckMark], "[%s]", selected_id_.c_str());
        imgui_addons::pop_mono_font(mono);
        ImGui::SameLine();
        ImGui::TextColored(ImGui::GetStyle().Colors[ImGuiCol_CheckMark], "> %s",
            selected_name_.c_str());
    }
    else if (multi_ && matched_ids_ && matched_ids_->size() > 1)
    {
        // A multi box needs no pick: the count IS the selection, and saying so
        // is what tells the player they do not have to choose one.
        ImGui::TextColored(ImGui::GetStyle().Colors[ImGuiCol_CheckMark],
            "> all %zu matches selected", matched_ids_->size());
    }

    // results list (only while there is a query)
    if (!query_.empty() && !results_.empty())
    {
        const float row_h = ImGui::GetTextLineHeightWithSpacing();
        const float height = (std::min)(static_cast<int>(results_.size()), 8) * row_h + 8.f;

        ImGui::BeginChild("##itemresults", ImVec2(-1.f, height), true);
        // Pinned shared_ptr: the search haystacks below were built from this
        // exact generation, and prewarm() may publish localized names while this
        // frame is being drawn.
        const game_items::db_snapshot_ptr db_ptr = game_items::snapshot();
        const auto& db = db_ptr->entries;
        for (int idx : results_)
        {
            if (static_cast<size_t>(idx) >= db.size()) continue;
            const game_items::entry& it = db[static_cast<size_t>(idx)];
            ImGui::PushID(idx);

            if (ImGui::Selectable(it.name.c_str(), selected_id_ == it.id))
            {
                selected_id_ = it.id;
                selected_name_ = it.name;
                // In multi mode the click IS the pick. The query already
                // selected everything it matched, and before this line the
                // click set only the cosmetic fields: the summary claimed a
                // pick while the loot filter went on matching the whole query,
                // which is exactly "it stopped working as a selection". Pin the
                // set to this row, and re-typing (or clearing) the query goes
                // back to the whole matched set -- refilter() republishes from
                // query_ every time the text changes.
                if (multi_)
                {
                    auto pinned = std::make_shared<std::unordered_set<std::string>>();
                    pinned->insert(it.id);
                    matched_ids_ = std::move(pinned);
                }
                if (on_select_) on_select_(selected_id_);
            }
            ImGui::PopID();
        }
        ImGui::EndChild();

        ImGui::TextDisabled("%d result%s%s", static_cast<int>(results_.size()),
            results_.size() > 1 ? "s" : "",
            results_.size() >= MAX_RESULTS ? " (refine your search)" : "");
    }
    else if (!query_.empty())
    {
        ImGui::TextDisabled("%s", i18n::tr("item_search_no_results_inf").c_str());
    }

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + ImGui::GetStyle().FramePadding.y * 2 * menu::get_scale_factor());
    ImGui::Dummy({0, 0});
    if (disabled) ImGui::EndDisabled();
    ImGui::PopID();
}

void ItemSearchValue::set(const std::string& string) {
    selected_id_ = string;
    // Recover the display name when the live snapshot is available; if the
    // factory isn't up yet (config load before raid init) draw() retries.
    build_index();
    selected_name_ = game_items::name_by_id(selected_id_);
    // A restored selection is a pinned one. Without this, a multi box reads
    // get_matched_ids() -- which is republished from the QUERY on every
    // keystroke -- so a config restored before any typing selected nothing
    // until the user happened to retype. The click path and this path now mean
    // the same thing, which is the whole point of the field being one field.
    if (multi_ && !selected_id_.empty())
    {
        auto restored = std::make_shared<std::unordered_set<std::string>>();
        restored->insert(selected_id_);
        matched_ids_ = std::move(restored);
    }
}

std::string ItemSearchValue::get() { return selected_id_; }

std::string ItemSearchValue::get_default() { return ""; }

[[nodiscard]] std::string ItemSearchValue::get_selected_id() const { return selected_id_; }

[[nodiscard]] std::shared_ptr<const std::unordered_set<std::string>> ItemSearchValue::get_matched_ids() const {
    return matched_ids_;
}

[[nodiscard]] bool ItemSearchValue::is_multi() const { return multi_; }

bool ItemSearchValue::entry_hidden(size_t index) const {
    if (!hide_quest_items_) return false;
    const game_items::db_snapshot_ptr db = game_items::snapshot();
    return index < db->entries.size() && db->entries[index].quest_item;
}

std::vector<std::string>& ItemSearchValue::haystacks() {
    static std::vector<std::string> hs;
    return hs;
}

game_items::db_snapshot_ptr ItemSearchValue::index_snapshot_;

void ItemSearchValue::build_index() {
    auto& hs = haystacks();
    const game_items::db_snapshot_ptr db_ptr = game_items::snapshot();
    const auto& db = db_ptr->entries;
    // Keyed on the published object's IDENTITY, not on its size. Size alone was
    // wrong: prewarm() republishes the same number of entries with localized
    // names, so a size check kept the raw template slugs in the haystacks for
    // the rest of the session and the search box could never match a real name.
    if (!db.empty() && hs.size() == db.size() && index_snapshot_ == db_ptr) return;
    index_snapshot_ = db_ptr;
    hs.clear();
    if (db.empty()) return;
    hs.reserve(db.size());
    for (const auto& e : db)
    {
        // text_fold::fold, not std::transform + std::tolower: the latter is
        // ASCII-only in the C locale, and these names are LOCALIZED (5947 of
        // 6001 resolve to a real name), so a Russian or Greek player typing
        // "бинт" matched nothing. See util/text_fold.h for the ranges covered
        // and why a full case table is not carried.
        std::string h;
        text_fold::fold(e.name, h);
        h.push_back(' ');
        text_fold::fold(e.id, h);
        hs.push_back(std::move(h));
    }
}

void ItemSearchValue::refilter() {
    results_.clear();
    // Folded once and reused for every entry -- see contains_folded().
    const std::string q = text_fold::folded(query_);

    // split into terms
    std::vector<std::string> terms;
    size_t start = 0;
    while (start < q.size())
    {
        size_t sp = q.find(' ', start);
        if (sp == std::string::npos)
        {
            terms.push_back(q.substr(start));
            break;
        }
        if (sp > start) terms.push_back(q.substr(start, sp - start));
        start = sp + 1;
    }
    if (terms.empty()) return;

    const auto& hs = haystacks();
    const game_items::db_snapshot_ptr db_ptr = game_items::snapshot();
    const auto& db = db_ptr->entries;
    for (int i = 0; i < static_cast<int>(db.size())
        && static_cast<int>(results_.size()) < MAX_RESULTS;
        ++i)
    {
        // Hidden entries are skipped, not just deprioritized: on a spawn
        // picker they must be unselectable, and a full page of quest items
        // would otherwise push real results past MAX_RESULTS.
        if (entry_hidden(static_cast<size_t>(i))) continue;
        bool ok = true;
        for (const auto& term : terms)
        {
            if (!text_fold::contains_folded(hs[static_cast<size_t>(i)], term))
            {
                ok = false;
                break;
            }
        }
        if (ok) results_.push_back(i);
    }

    // The ids behind results_, so a multi-select caller can read the whole
    // selection from a stable container rather than re-deriving it from indices
    // into whichever db snapshot happened to be current when the query changed.
    // Built from the db generation this refilter used, by the snapshots-are-read-
    // together rule the rest of this class follows.
    //
    // PUBLISHED, never mutated in place: the set is built complete and then the
    // member is swapped. A consumer on the game thread holds the previous
    // shared_ptr and reads a set nothing is writing to, which is the whole
    // reason this is not a plain member -- the render thread retypes while the
    // loot filter is walking it (b9ca0b366 is the crash that shape produced).
    auto matched = std::make_shared<std::unordered_set<std::string>>();
    matched->reserve(results_.size());
    for (const int i : results_)
        if (i >= 0 && static_cast<size_t>(i) < db.size())
            matched->insert(db[static_cast<size_t>(i)].id);
    matched_ids_ = std::move(matched);

    // Prefer items whose folded haystack starts with the first term.
    //
    // Was _strnicmp(db[a].name, t0): case-insensitive but ASCII-ONLY, and it
    // compared a FOLDED term against an UNFOLDED name. For a Cyrillic or Greek
    // name that test is always false -- every result landed in the arbitrary
    // order the db happened to be in. Both sides now come from the same fold as
    // the match above, so the ranking and the filter cannot disagree about what
    // "same case" means.
    const std::string& t0 = terms[0];
    const auto starts_with_term = [&](const int idx) {
        const std::string& h = hs[static_cast<size_t>(idx)];
        return h.size() >= t0.size() && h.compare(0, t0.size(), t0) == 0;
    };
    std::stable_sort(results_.begin(), results_.end(), [&](int a, int b) {
        const bool sa = starts_with_term(a);
        const bool sb = starts_with_term(b);
        if (sa != sb) return sa;
        return false;
    });
}
