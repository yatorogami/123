#pragma once
#include <functional>

#include "CheckboxValue.h"
#include "ConfigValue.h"

#pragma pack(push, 1)
class ActionRowValue : public ConfigValue
{
  public:
    ActionRowValue(const std::function<void()>& action, const std::string& n,
        [[maybe_unused]] const bool sameline = false);

    void draw() override;

    void set_disabled(const bool d);

    void set_button_text(const std::string& text);

    [[nodiscard]] bool is_disabled() const;

    void set(const std::string& string) override;

    std::string get() override;

    std::string get_default() override;

  private:
    std::function<void()> action_;
    bool disabled_ = false;
    std::string button_text_;
};
#pragma pack(pop)
