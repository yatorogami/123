#pragma once
#include <mutex>
#include <set>
#include <string>

#include "ConfigValue.h"
#include "../gui/menu/imgui_addons.h"

/**
 * Stores a set of favorited loot names (by display name). Persisted in the config
 * as a single field, items joined with '|' (config itself uses ';' as separator,
 * so '|' is safe here). Toggled in-world via middle-click in EspModule.
 *
 * Thread-safe: contains() is read from the game Update thread (loot scan) while
 * toggle()/draw() write from the render thread, so all access to items_ is guarded.
 * The mutex is a function-local static (NOT a member) because this class is
 * #pragma pack(1) and packing an OS lock primitive would misalign it.
 */
#pragma pack(push, 1)
class FavoritesValue : public ConfigValue
{
  public:
    explicit FavoritesValue(const std::string& n);

    bool contains(const std::string& name) const;

    void toggle(const std::string& name);

    void clear();

    std::set<std::string> all() const;

    void draw() override;

    void set(const std::string& string) override;

    std::string get() override;

    std::string get_default() override;

    // NOT changed-from-default, ever. Favorites are bookmarks the player
    // stars in-world, not a setting with a compiled-in value; the marker
    // would sit on that card permanently for anyone who has ever starred
    // anything, and the reset affordance beside it would clear the whole
    // list -- which is what the Clear button already does, deliberately.
    bool is_changed() override { return false; }

  private:
    std::set<std::string> items_;

    // function-local static mutex (kept out of the packed object layout)
    static std::mutex& mtx();

    // names must not contain the config separators ';' or '|'
    static std::string sanitize(const std::string& in);
};
#pragma pack(pop)
