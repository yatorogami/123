#include "common.h"
#include "SelectValue.h"

SelectValue::SelectValue(int initial, const std::vector<const char*>& options, const std::string& n,
    const bool translate_options, const bool label_above) : ConfigValue(n), translate_options_(translate_options), label_above_(label_above) {
    this->value_ = initial;
    this->def_ = initial;
    this->options = options;
    clamp_value();
}

SelectValue::SelectValue(int initial, const char* const* options, const size_t count, const std::string& n,
    const bool translate_options, const bool label_above) : ConfigValue(n), translate_options_(translate_options), label_above_(label_above) {
    this->value_ = initial;
    this->def_ = initial;
    this->options.assign(options, options + count);
    clamp_value();
}

void SelectValue::draw() {
    clamp_value();
    imgui_addons::select(this->get_imgui_title(), &this->value_, this->options, disabled_,
        translate_options_, label_above_);
}

void SelectValue::set(const std::string& string) {
    this->value_ = from_string(string);
    clamp_value();
}

std::string SelectValue::get() {
    return to_string(this->value_);
}

std::string SelectValue::get_default() {
    return to_string(this->def_);
}

[[nodiscard]] int SelectValue::get_value() const {
    return this->value_;
}

void SelectValue::set_value(const int v) {
    this->value_ = v;
    clamp_value();
}

std::string SelectValue::get_selected() const {
    return {this->options[this->value_]};
}

std::vector<const char*> SelectValue::get_options() {
    return this->options;
}

void SelectValue::set_options(const std::vector<const char*>& opts) {
    option_storage_.clear();
    options.clear();
    option_storage_.reserve(opts.size());
    options.reserve(opts.size());
    for (const char* opt : opts)
    {
        option_storage_.emplace_back(opt ? opt : "");
        options.push_back(option_storage_.back().c_str());
    }
    clamp_value();
}

void SelectValue::clamp_value() {
    if (options.empty())
    {
        value_ = 0;
        return;
    }
    if (value_ < 0)
        value_ = 0;
    else if (static_cast<size_t>(value_) >= options.size())
        value_ = static_cast<int>(options.size()) - 1;
}

std::string SelectValue::to_string(int v) {
    return std::to_string(v);
}

int SelectValue::from_string(const std::string& string) {
    int parsed = 0;
    const char* first = string.c_str();
    const char* last = first + string.size();
    const auto result = std::from_chars(first, last, parsed);
    if (result.ec != std::errc{} || result.ptr != last)
        return -1; // clamped to the first option by clamp_value()
    return parsed;
}
