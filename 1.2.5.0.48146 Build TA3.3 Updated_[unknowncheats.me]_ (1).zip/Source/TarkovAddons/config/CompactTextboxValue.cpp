#include "common.h"
#include "CompactTextboxValue.h"

CompactTextboxValue::CompactTextboxValue(const std::string& initial, const std::string& n, const size_t max_chars) : ConfigValue(n), value_(initial), def_(initial), max_chars_(max_chars) {
}

void CompactTextboxValue::draw() {
    imgui_addons::compact_textbox(get_imgui_title(), &value_, max_chars_, disabled_);
}

void CompactTextboxValue::set(const std::string& string) {
    value_ = string;
    trim();
}

std::string CompactTextboxValue::get() {
    return value_;
}

std::string CompactTextboxValue::get_default() {
    return def_;
}

void CompactTextboxValue::trim() {
    if (value_.size() > max_chars_)
        value_.resize(max_chars_);
}
