#pragma once

#include "ConfigValue.h"
#include "../gui/menu/imgui_addons.h"

class CompactTextboxValue : public ConfigValue
{
  public:
    CompactTextboxValue(const std::string& initial, const std::string& n, const size_t max_chars = 3);

    void draw() override;

    void set(const std::string& string) override;

    std::string get() override;

    std::string get_default() override;

  private:
    std::string value_;
    std::string def_;
    size_t max_chars_;

    void trim();
};