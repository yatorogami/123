#pragma once
#include <string>
#include "ConfigValue.h"
#include <imgui.h>
#include "../util/i18n.h"

class MenuSectionValue : public ConfigValue
{
  public:
    explicit MenuSectionValue(const std::string& title);

    void set_section_active(const bool active);

    void draw() override;

    void set(const std::string&) override;
    std::string get() override;
    std::string get_default() override;

  private:
    std::string title_;
    bool section_active_ = true;
};
