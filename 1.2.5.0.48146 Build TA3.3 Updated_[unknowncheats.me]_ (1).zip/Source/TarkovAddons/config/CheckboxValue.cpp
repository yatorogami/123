#include "common.h"
#include "CheckboxValue.h"

CheckboxValue::CheckboxValue(const bool initial, const std::string& n, const bool safety_switch) : ConfigValue(n) {
    this->value_ = initial;
    this->def_ = initial;
    this->safety_switch_ = safety_switch;
    all_toggles_.push_back(this);
}

void CheckboxValue::draw() {
    const std::string tip = this->get_tooltip();
    imgui_addons::checkbox(this->get_imgui_title(), &this->value_, disabled_, master_toggle_, safety_switch_,
        &favorite_, tip.empty() ? nullptr : tip.c_str());
}

void CheckboxValue::draw_favorite() {
    const std::string tip = this->get_tooltip();
    imgui_addons::checkbox(this->get_imgui_title(), &this->value_, disabled_, master_toggle_, safety_switch_,
        nullptr, tip.empty() ? nullptr : tip.c_str());
}

[[nodiscard]] const std::vector<CheckboxValue*>& CheckboxValue::all_toggles() { return all_toggles_; }

void CheckboxValue::set(const std::string& string) {
    this->value_ = from_string(string);
}

std::string CheckboxValue::get() {
    return to_string(this->value_);
}

std::string CheckboxValue::get_default() {
    return to_string(this->def_);
}

[[nodiscard]] bool CheckboxValue::get_value() const {
    return this->value_;
}

void CheckboxValue::set_value(const bool v) {
    this->value_ = v;
}

std::string CheckboxValue::to_string(bool v) {
    std::ostringstream os("");
    os << std::boolalpha << v;
    return os.str();
}

bool CheckboxValue::from_string(std::string string) {
    bool b1;
    std::istringstream is(string);
    is >> std::boolalpha >> b1;
    return b1;
}
