#pragma once
#include "ConfigValue.h"
#include "../gui/menu/imgui_addons.h"

#pragma pack(push, 1)
class TextboxValue : public ConfigValue
{
  public:
    TextboxValue(const std::string& initial, const std::string& n);

    void draw() override;

    void set(const std::string& string) override;

    std::string get() override;

    std::string get_default() override;

  private:
    std::string value_;
    std::string def_;
};
#pragma pack(pop)
