#include "common.h"
#include "IntSliderEditableValue.h"

IntSliderEditableValue::IntSliderEditableValue(const int initial, const int min, const int slider_max, const std::string& n) : ConfigValue(n) {
    value_ = initial;
    def_ = initial;
    min_ = min;
    slider_max_ = slider_max;
}

void IntSliderEditableValue::draw() {
    imgui_addons::slider_int_editable(this->get_imgui_title(), &value_, min_, slider_max_, disabled_);
}

void IntSliderEditableValue::set(const std::string& string) {
    int parsed = 0;
    value_ = config_parse::to_int(string, parsed) ? parsed : def_;
}

std::string IntSliderEditableValue::get() {
    return to_string(value_);
}

std::string IntSliderEditableValue::get_default() {
    return to_string(def_);
}

[[nodiscard]] int IntSliderEditableValue::get_value() const {
    return value_;
}

std::string IntSliderEditableValue::to_string(const int v) {
    return std::to_string(v);
}
