#pragma once
#include <sstream>
#include <vector>

#include "ConfigValue.h"
#include "../gui/menu/imgui_addons.h"

#pragma pack(push, 1)
class CheckboxValue : public ConfigValue
{
  public:
    CheckboxValue(const bool initial, const std::string& n, const bool safety_switch = false);

    void draw() override;

    // Favorites uses the same live value but intentionally omits the star,
    // because this card is the quick-toggle destination rather than editor.
    void draw_favorite();

    [[nodiscard]] static const std::vector<CheckboxValue*>& all_toggles();

    void set(const std::string& string) override;

    std::string get() override;

    std::string get_default() override;

    [[nodiscard]] bool get_value() const;

    void set_value(const bool v);

  private:
    bool value_;
    bool def_;
    bool safety_switch_ = false;
    inline static std::vector<CheckboxValue*> all_toggles_{};

    static std::string to_string(bool v);

    static bool from_string(std::string string);
};
#pragma pack(pop)
