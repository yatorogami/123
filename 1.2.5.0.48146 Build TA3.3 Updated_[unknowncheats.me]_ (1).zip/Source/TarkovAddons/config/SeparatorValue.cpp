#include "common.h"
#include "SeparatorValue.h"

SeparatorValue::SeparatorValue(const std::string& name) : ConfigValue(name) {}

void SeparatorValue::draw() { ImGui::Separator(); }

void SeparatorValue::set(const std::string& string) { (void)string; }

std::string SeparatorValue::get() { return {}; }

std::string SeparatorValue::get_default() { return {}; }
