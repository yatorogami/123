#include "common.h"
#include "ActionRowValue.h"

ActionRowValue::ActionRowValue(const std::function<void()>& action, const std::string& n,
    [[maybe_unused]] const bool sameline) : ConfigValue(n) {
    this->action_ = action;
}

void ActionRowValue::draw() {
    if (disabled_) ImGui::BeginDisabled();
    // get_imgui_title() returns a std::string BY VALUE, so binding its
    // c_str() to a raw pointer left that pointer dangling the moment the
    // statement ended -- ImGui::Button then read freed memory, which is how
    // the Save/Load buttons lost their captions. Hold the string in a named
    // local so it outlives the call. (The pre-existing
    // ImGui::Button(get_imgui_title().c_str(), ...) was fine: there the
    // temporary lived to the end of that full-expression.)
    const std::string title = this->get_imgui_title();
    const char* label = !button_text_.empty() ? button_text_.c_str() : title.c_str();
    if (ImGui::Button(label, ImVec2(-1.f, 0.f)))
    {
        if (!disabled_)
            this->action_();
    }
    if (disabled_) ImGui::EndDisabled();
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + ImGui::GetStyle().FramePadding.y * 3 * menu::get_scale_factor());
}

void ActionRowValue::set_disabled(const bool d) {
    disabled_ = d;
}

void ActionRowValue::set_button_text(const std::string& text) {
    button_text_ = text;
}

[[nodiscard]] bool ActionRowValue::is_disabled() const {
    return disabled_;
}

void ActionRowValue::set(const std::string& string) {
}

std::string ActionRowValue::get() {
    return "";
}

std::string ActionRowValue::get_default() {
    return "";
}
