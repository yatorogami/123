#pragma once
#include <charconv>
#include <string>
#include <system_error>
#include <vector>

#include "ConfigValue.h"
#include "../gui/menu/imgui_addons.h"

class SelectValue : public ConfigValue
{
  public:
    SelectValue(int initial, const std::vector<const char*>& options, const std::string& n,
        const bool translate_options = true, const bool label_above = false);

    SelectValue(int initial, const char* const* options, const size_t count, const std::string& n,
        const bool translate_options = true, const bool label_above = false);

    void draw() override;

    void set(const std::string& string) override;

    std::string get() override;

    std::string get_default() override;

    [[nodiscard]] int get_value() const;

    void set_value(const int v);

    std::string get_selected() const;

    std::vector<const char*> get_options();

    void set_options(const std::vector<const char*>& opts);

  private:
    int value_;
    int def_;
    std::vector<std::string> option_storage_;
    std::vector<const char*> options;
    bool translate_options_ = true;
    bool label_above_ = false;

    void clamp_value();

    static std::string to_string(int v);

    // Must not throw. This runs inside ConfigModule::load_config()'s apply
    // loop with nothing catching, so std::stoi's std::invalid_argument on an
    // empty or non-numeric value would unwind out of the loader and abandon
    // every value registered after this one -- presenting as "the config did
    // not load". A malformed value is a one-value problem; fall back to the
    // default rather than the whole file.
    static int from_string(const std::string& string);
};
