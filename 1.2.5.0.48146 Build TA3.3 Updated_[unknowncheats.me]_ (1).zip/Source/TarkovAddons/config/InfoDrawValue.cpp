#include "common.h"
#include "InfoDrawValue.h"

InfoDrawValue::InfoDrawValue(const std::function<void()>& draw_fn, const std::string& id) : ConfigValue(id), draw_fn_(draw_fn) {
}

void InfoDrawValue::draw() {
    if (draw_fn_)
        draw_fn_();
}

void InfoDrawValue::set(const std::string&) {}

std::string InfoDrawValue::get() { return {}; }

std::string InfoDrawValue::get_default() { return {}; }
