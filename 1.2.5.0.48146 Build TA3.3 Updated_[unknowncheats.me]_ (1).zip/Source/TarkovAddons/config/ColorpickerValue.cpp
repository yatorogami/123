#include "common.h"
#include "ColorpickerValue.h"

ColorpickerValue::ColorpickerValue(const ImVec4 initial, const std::string& n) : ConfigValue(n) {
    this->value_ = initial;
    this->def_ = initial;
}

void ColorpickerValue::draw() {
    imgui_addons::colorpicker(this->get_imgui_title(), &this->value_, disabled_);
}

void ColorpickerValue::set(const std::string& string) {
    ImVec4 parsed = def_;
    this->value_ = from_string(string, parsed) ? parsed : this->def_;
}

std::string ColorpickerValue::get() {
    return to_string(this->value_);
}

std::string ColorpickerValue::get_default() {
    return to_string(this->def_);
}

[[nodiscard]] ImVec4 ColorpickerValue::get_value() const {
    return this->value_;
}

std::string ColorpickerValue::to_string(ImVec4 v) {
    std::stringstream ss;
    ss << v.x << "|" << v.y << "|" << v.z << "|" << v.w;
    return ss.str();
}

bool ColorpickerValue::from_string(const std::string& string, ImVec4& out) {
    const std::vector<std::string> elements = utils::split(string, '|');
    if (elements.size() < 4)
        return false;

    float rgba[4] = {0.f, 0.f, 0.f, 1.f};
    for (size_t i = 0; i < 4; ++i)
    {
        if (!config_parse::to_float(elements[i], rgba[i]))
            return false;
    }
    out = ImVec4(rgba[0], rgba[1], rgba[2], rgba[3]);
    return true;
}
