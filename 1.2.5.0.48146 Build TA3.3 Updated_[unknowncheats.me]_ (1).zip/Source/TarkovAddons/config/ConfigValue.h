#pragma once
#include <charconv>
#include <string>
#include <system_error>

#include "../util/i18n.h"

namespace config_parse {

    // Total (non-throwing) scalar parsers for set() implementations.
    //
    // Every ConfigValue::set() is called from ConfigModule::load_config()'s
    // apply loop. A hand-edited, truncated, or cross-version config can hand any
    // of them an empty or non-numeric string, and the std::sto* family signals
    // that by throwing. Nothing above that loop catches: the exception unwound
    // straight out of the loader, abandoning every value registered after it and
    // skipping the hotkey restore -- so one bad field looked exactly like "the
    // config did not load". A malformed value is a one-setting problem, so these
    // report failure instead of throwing and the caller falls back to a default.
    //
    // from_chars also rejects trailing junk ("3abc") and embedded nulls, which
    // stoi would have silently accepted as 3.

    inline bool to_int(const std::string& text, int& out) {
        if (text.empty()) return false;
        const char* first = text.data();
        const char* last = first + text.size();
        const auto result = std::from_chars(first, last, out);
        if (result.ec != std::errc{} || result.ptr != last) return false;
        return true;
    }

    inline bool to_float(const std::string& text, float& out) {
        if (text.empty()) return false;
        const char* first = text.data();
        const char* last = first + text.size();
        const auto result = std::from_chars(first, last, out);
        if (result.ec != std::errc{} || result.ptr != last) return false;
        return true;
    }

} // namespace config_parse

/**
 * Represents a config value of a module and its imgui representation.
 */
class ConfigValue
{
  public:
    virtual ~ConfigValue() = default;

    explicit ConfigValue(const std::string& name);

    /**
     * Register with the module
     * @param mod module name
     */
    void reg(const std::string& mod);

    virtual void draw() = 0;

    virtual void set(const std::string& string) = 0;

    virtual std::string get() = 0;

    virtual std::string get_default() = 0;

    virtual void set_disabled(const bool d);

    [[nodiscard]] virtual bool is_disabled() const;

    // A value can be owned by one module for its runtime behavior while being
    // displayed by a different category card.
    void set_hidden_in_owner_menu(const bool hidden);
    [[nodiscard]] bool is_hidden_in_owner_menu() const;

    virtual void set_master_toggle(const bool m);

    // True when this row's current setting differs from its compiled-in
    // default. The menu answers it twice: a dot beside the row, and a reset
    // affordance in the gutter that writes get_default() back through set().
    //
    // Why this is not a cached flag updated on every set(): a value is
    // changed from at least four directions -- the widget, a hotkey
    // (hotkeys::try_toggle writes set_value without any ConfigValue
    // involvement), the config loader, and Reset Defaults -- and "changed"
    // is a question about the CURRENT string, not about the last write. A
    // flag would have to be maintained by all four and would be wrong the
    // moment a fifth appears. get() != get_default() cannot go stale.
    //
    // Virtual because the default is only correct for rows whose setting IS
    // their stored string. FavoritesValue overrides it to false: favorites
    // are bookmarks, not settings, and they already have a Clear button --
    // marking that card "changed" and offering to reset it would clear
    // someone's shortcuts as a side effect of tidying a marker.
    virtual bool is_changed();

    // Explanatory text shown on hover, stored as an i18n KEY and resolved by
    // get_tooltip() at DRAW time.
    //
    // Why resolution is deferred, and why this is not premature optimisation:
    //
    //   dllmain.cpp:359  ModuleManager::get_instance()->init();
    //
    // `new ModuleManager()` constructs every module -- PlayerModule included --
    // and a module constructor is where set_tooltip() is called. i18n::init() does
    // not run until ConfigModule::init(), which is INSIDE that same
    // ModuleManager::init() loop, i.e. strictly after every constructor has
    // finished.
    //
    // So an eager tr() here sees an EMPTY translation map, and tr() answers an
    // unknown key by returning the key. tooltip_ then cached "god_mode_tip"
    // verbatim and the row rendered the raw key forever -- which is exactly the
    // defect this existed for. Caching the key and translating per frame is the
    // same shape as get_imgui_title() below, and it also makes a tooltip follow
    // a language change instead of freezing at whatever the first frame saw.
    void set_tooltip(const std::string& i18n_key);

    [[nodiscard]] std::string get_tooltip() const;

    void set_favorite(const bool favorite);
    [[nodiscard]] bool is_favorite() const;

    [[nodiscard]] std::string get_favorite_config_key() const;

    [[nodiscard]] std::string get_config_key() const;

    std::string get_imgui_title() const;

  protected:
    bool disabled_ = false;
    bool master_toggle_ = false;
    bool hidden_in_owner_menu_ = false;
    bool favorite_ = false;
    std::string tooltip_key_;

  private:
    std::string name_;
    std::string module_;
};
