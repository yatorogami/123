#pragma once
#include "ConfigValue.h"
#include "../gui/menu/imgui_addons.h"

#pragma pack(push, 1)
class IntTextboxValue : public ConfigValue
{
  public:
    IntTextboxValue(int initial, const std::string& n);

    void draw() override;

    void set(const std::string& string) override;

    std::string get() override;

    std::string get_default() override;

    [[nodiscard]] int get_value() const;

  private:
    int value_;
    int def_;

    static std::string to_string(int v);
};
#pragma pack(pop)
