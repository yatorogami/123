#include "common.h"
#include "IntTextboxValue.h"

IntTextboxValue::IntTextboxValue(int initial, const std::string& n) : ConfigValue(n) {
    this->value_ = initial;
    this->def_ = initial;
}

void IntTextboxValue::draw() {
    imgui_addons::int_textbot(this->get_imgui_title(), &this->value_);
}

void IntTextboxValue::set(const std::string& string) {
    int parsed = 0;
    this->value_ = config_parse::to_int(string, parsed) ? parsed : this->def_;
}

std::string IntTextboxValue::get() {
    return to_string(this->value_);
}

std::string IntTextboxValue::get_default() {
    return to_string(this->def_);
}

[[nodiscard]] int IntTextboxValue::get_value() const {
    return this->value_;
}

std::string IntTextboxValue::to_string(int v) {
    return std::to_string(v);
}
