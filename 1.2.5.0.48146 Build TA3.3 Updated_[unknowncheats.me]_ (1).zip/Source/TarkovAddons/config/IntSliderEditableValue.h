#pragma once
#include "ConfigValue.h"
#include "../gui/menu/imgui_addons.h"

#pragma pack(push, 1)
class IntSliderEditableValue : public ConfigValue
{
  public:
    IntSliderEditableValue(const int initial, const int min, const int slider_max, const std::string& n);

    void draw() override;

    void set(const std::string& string) override;

    std::string get() override;

    std::string get_default() override;

    [[nodiscard]] int get_value() const;

  private:
    int value_;
    int def_;
    int min_;
    int slider_max_;

    static std::string to_string(const int v);
};
#pragma pack(pop)