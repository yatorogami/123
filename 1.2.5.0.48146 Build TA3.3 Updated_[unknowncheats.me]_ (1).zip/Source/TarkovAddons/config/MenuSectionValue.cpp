#include "common.h"
#include "MenuSectionValue.h"

MenuSectionValue::MenuSectionValue(const std::string& title) : ConfigValue(title), title_(title) {}

void MenuSectionValue::set_section_active(const bool active) { section_active_ = active; }

void MenuSectionValue::draw() {
    // Card titles provide all visible grouping. Section values are kept
    // for config compatibility but no longer render sub-card labels.
}

void MenuSectionValue::set(const std::string&) {}

std::string MenuSectionValue::get() { return {}; }

std::string MenuSectionValue::get_default() { return {}; }
