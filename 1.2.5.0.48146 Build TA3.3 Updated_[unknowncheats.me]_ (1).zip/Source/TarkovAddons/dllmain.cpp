#include "common.h"
#include <iostream>
#include <windows.h>
#include <string>
#include <thread>
#include <atomic>
#include <vector>
#include <mutex>

#include "gui/dxhook/dxhook.h"
#include "il2cpp/unity.h"
#include "module/always_on.h"
#include "module/common_hooks.h"
#include "module/ModuleManager.h"
#include "module/footprint.h"
#include "module/impl/ConfigModule.h"
#include "util/globals.h"
#include "util/crash_probe.h"
#include "util/i18n.h"
#include "util/logger.h"
#include "../shared/module_paths.h"
#include "util/pe_resource.h"

namespace {
    FILE* console = nullptr;

    // Written by init() on its worker thread, read by DllMain on the loader-lock thread at
    // DLL_PROCESS_DETACH. Atomics because those are genuinely different threads and the
    // detach read may happen before init() has even reached its first line -- in which case
    // start is zero and the END line says so rather than printing a nonsense uptime.
    std::atomic<long long> g_session_start_ms{ 0 };
    std::atomic<unsigned long> g_session_pid{ 0 };

    // Console output filter thread - intercepts stdout/stderr and filters WebSocket trace spam
    struct ConsoleFilter {
        HANDLE read_pipe = nullptr;
        HANDLE write_pipe = nullptr;
        HANDLE old_stdout = nullptr;
        HANDLE old_stderr = nullptr;
        HANDLE console_out = nullptr;
        std::thread filter_thread;
        std::atomic<bool> running{false};

        void start() {
            if (running.load()) return;

            SECURITY_ATTRIBUTES sa{sizeof(SECURITY_ATTRIBUTES), nullptr, TRUE};
            if (!CreatePipe(&read_pipe, &write_pipe, &sa, 0)) return;

            old_stdout = GetStdHandle(STD_OUTPUT_HANDLE);
            old_stderr = GetStdHandle(STD_ERROR_HANDLE);

            // GetStdHandle can still return a launcher-redirected file/pipe even
            // immediately after AllocConsole (AllocConsole only re-points standard
            // handles that are NULL). Opening CONOUT$ by name guarantees a real
            // console screen-buffer handle, so SetConsoleTextAttribute colors and
            // WriteFile forwarding actually land on the console (#10).
            console_out = CreateFileW(L"CONOUT$", GENERIC_READ | GENERIC_WRITE,
                FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
            if (console_out == INVALID_HANDLE_VALUE)
                console_out = nullptr;

            SetStdHandle(STD_OUTPUT_HANDLE, write_pipe);
            SetStdHandle(STD_ERROR_HANDLE, write_pipe);

            running.store(true);
            filter_thread = std::thread([this]() { filter_loop(); });
        }

        void stop() {
            if (!running.load()) return;
            running.store(false);
            if (write_pipe) {
                CloseHandle(write_pipe);
                write_pipe = nullptr;
            }
            if (filter_thread.joinable()) filter_thread.join();
            if (old_stdout) SetStdHandle(STD_OUTPUT_HANDLE, old_stdout);
            if (old_stderr) SetStdHandle(STD_ERROR_HANDLE, old_stderr);
            if (read_pipe) CloseHandle(read_pipe);
            if (console_out)
            {
                CloseHandle(console_out);
                console_out = nullptr;
            }
        }

        void filter_loop() {
            constexpr DWORD BUFSIZE = 4096;
            std::vector<char> buffer(BUFSIZE);
            std::string leftover;

            while (running.load()) {
                DWORD bytes_read = 0;
                if (!ReadFile(read_pipe, buffer.data(), static_cast<DWORD>(buffer.size()) - 1, &bytes_read, nullptr)) {
                    if (GetLastError() == ERROR_BROKEN_PIPE) break;
                    Sleep(1);
                    continue;
                }
                if (bytes_read == 0) {
                    Sleep(1);
                    continue;
                }

                buffer[bytes_read] = '\0';
                leftover += buffer.data();

                size_t pos;
                while ((pos = leftover.find('\n')) != std::string::npos) {
                    std::string line = leftover.substr(0, pos);
                    leftover.erase(0, pos + 1);

                    // Filter WebSocket trace spam
                    if (should_filter_line(line)) continue;

                    // Write filtered line to real console
                    write_to_real_console(line + "\n");
                }
            }
        }

        bool should_filter_line(const std::string& line) {
            // Filter WebSocket trace messages:
            // 09/23/2026 21:44:38|Trace|WebSocket.processPongFrame|A pong was received.
            // 09/23/2026 21:44:38|Trace|WebSocket.processPongFrame|It has been signaled.
            if (line.find("|Trace|WebSocket.") != std::string::npos) return true;
            if (line.find("WebSocket.processPongFrame") != std::string::npos) return true;
            if (line.find("A pong was received") != std::string::npos) return true;
            if (line.find("It has been signaled") != std::string::npos) return true;
            return false;
        }

        void write_to_real_console(const std::string& line) {
            const HANDLE dest = console_out ? console_out : old_stdout;
            if (!dest || dest == INVALID_HANDLE_VALUE) return;
            DWORD written = 0;
            WriteFile(dest, line.c_str(), static_cast<DWORD>(line.size()), &written, nullptr);
        }

        // Prefer the CONOUT$ screen-buffer handle for color/forwarding: the
        // pre-swap stdout handle may itself be a launcher-redirected file, which
        // would make SetConsoleTextAttribute a silent no-op ("gray console") (#10).
        HANDLE console_handle() const { return console_out ? console_out : old_stdout; }
    };

    ConsoleFilter g_console_filter;

    void show_console() {
        AllocConsole();

        // The console renders BYTES using the output code page, and the log carries
        // UTF-8 (item names are localized; the em-dash in route messages is U+2014).
        // On a non-UTF-8 console page (CP437/CP866 are the usual defaults) those bytes
        // get re-interpreted, which is what produced "тАФ" for an em-dash and
        // box-drawing noise like "12g ╨Ь╨░╨│╨╜╤Г╨╝ buckshot" for a Russian item name.
        // Set the console code page to UTF-8 so those bytes decode correctly.
        SetConsoleOutputCP(CP_UTF8);
        SetConsoleCP(CP_UTF8);

        // `console` itself is never read after this line -- freopen_s needs the
        // out-parameter to rebind stdout, but the FILE* is unused. The errno is
        // the part worth keeping, and it was being discarded into a `_`.
        //
        // AllocConsole() succeeding is NOT a guarantee that CONOUT$ opens. If it
        // does not, freopen_s leaves stdout in an indeterminate state and the
        // filter below wraps a broken stream, which presents as "the console is
        // there but nothing prints" -- with nothing in the log to say why. That
        // is the shape of failure this project has paid for repeatedly, and the
        // log line is safe here: the logger is already up (see the SESSION BEGIN
        // at the call site in DllMain, which precedes show_console()).
        if (const errno_t rc = freopen_s(&console, "CONOUT$", "w", stdout); rc != 0)
        {
            logger::error("console: freopen_s(CONOUT$) failed (errno " + std::to_string(rc)
                + ") -- stdout is undefined; the console will be silent. This line is the "
                  "only record that it happened.");
        }
        SetConsoleTitleA(std::string(globals::get_display_title() + " | " + globals::credits).c_str());

        // Start the console filter to suppress WebSocket trace spam
        g_console_filter.start();

        // Colors are applied per-cell with SetConsoleTextAttribute, which needs the
        // real console handle — GetStdHandle(STD_OUTPUT_HANDLE) now returns the filter
        // pipe, so hand the captured console handle to the logger.
        logger::set_console_handle(g_console_filter.console_handle());

        // Console encoding self-test (2026-09-26). Added because a mangled console was
        // mistaken for a data-corruption bug once already: the "???" in a class-name
        // diagnostic were the console rendering invalid bytes, not the bytes themselves.
        //
        // Now at DEBUG, not INFO: it printed a test string on every launch and the code
        // page fix is verified, so it has nothing left to say in normal use. Enable the
        // Debug Log toggle to bring it back when an encoding question comes up:
        //   correct console -> "Тест — OK"
        //   broken  console -> mojibake, meaning THIS line, not the data, is wrong.
        //
        // Cyrillic + em-dash only. The probe originally ended in U+25A3 (a Geometric
        // Shapes glyph) which the console's raster font does not cover, so it rendered
        // as "?" and looked like a NEW encoding failure. That was FONT COVERAGE, not
        // encoding: the log file held the correct bytes all along, and no real log
        // content uses characters outside Latin/Cyrillic + punctuation.
        logger::debug("console-encoding selftest: \xD0\xA2\xD0\xB5\xD1\x81\xD1\x82 "
                      "\xE2\x80\x94 OK");
    }

    DWORD WINAPI init(LPVOID parameter) {
        const auto this_module = static_cast<HMODULE>(parameter);

        // SESSION BEGIN, before absolutely anything else, so it is the first line this
        // session writes and the previous session's last written line is directly above it.
        //
        // The pid is in the timestamp prefix of every line already, but a human (or a grep)
        // reading a multi-MB append-only file needs one unambiguous delimiter per launch
        // rather than a pid to correlate.
        //
        // IT CARRIES NO "AND HERE IT ENDED" HALF, and that is a correction rather than an
        // omission. The first version of this marker wrote one at DLL_PROCESS_DETACH and
        // claimed its absence meant a crash or a kill. Both halves of that were wrong:
        //
        //   - The image is MANUAL-MAPPED (see AGENTS.md), so the OS keeps no loader record
        //     of it and DLL_PROCESS_DETACH is never invoked on process exit. It only runs
        //     on a FreeLibrary, which this deployment never performs. Measured 2026-10-05:
        //     eight SESSION BEGIN lines and zero end lines, across sessions that provably
        //     exited -- no WER event, log simply stops, next launch writes its own BEGIN.
        //   - And the BEGIN text contained the literal words of the end marker, so
        //     `Select-String 'SESSION END'` matched all eight BEGINs and nothing else. The
        //     wording defeated the parser written to read it, which is the whole class of
        //     bug AGENTS.md calls a count nobody measured.
        //
        // So: one BEGIN per launch is the entire record, and a session's end is the next
        // BEGIN's timestamp. Group by pid=, and that gap is unambiguous without a counter,
        // which is why there is no seq= field here.
        //
        // DEATH IS NOT IN THIS FILE. WER (Application event 1000) is the only signal that
        // distinguishes a crash from a clean exit, and a crash that dumps also leaves a
        // minidump -- but per AGENTS.md neither is a plan, so util/crash_probe.h is the
        // instrument that should be believed first.
        //
        // It carries the module base because that is the one thing a reader cannot recover
        // afterwards, and it does NOT carry a build stamp: crash_probe.h already prints
        // `build stamp=0x... size_of_image=0x...` on its own arming line in every session,
        // and duplicating it here would be a second thing to fall out of sync.
        g_session_start_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
        g_session_pid = ::GetCurrentProcessId();
        {
            char base[32] = {};
            snprintf(base, sizeof(base), "0x%llX",
                (unsigned long long)reinterpret_cast<uintptr_t>(this_module));
            logger::info(std::string("==== SESSION BEGIN pid=") + std::to_string(g_session_pid)
                + " image=" + base
                + " -- manual-mapped, so nothing marks where this one stops; the next BEGIN"
                  " is the boundary, and WER Application/1000 is the only death signal ====");
        }

        // alloc console
        if (globals::console) show_console();

        logger::info(globals::get_display_title());
        logger::info(globals::credits);

        // STANDING DIAGNOSTIC, not temporary. Armed before anything else so a
        // fault during the rest of startup is still attributed to this module.
        // WER is disabled machine-wide, so this log line is the only evidence a
        // crash can leave, and there is no standalone executable to debug from.
        // See util/crash_probe.h; do not remove.
        crash_probe::install();

        // The mod's own memory footprint, on the probe's 15 s tick. Registered
        // HERE, right after install(), because both are one-time and the probe's
        // tick runs on the game thread while this runs on the init thread --
        // the provider pointer is read through an acquire load for that reason.
        //
        // "How much of the game's 31 GB is ours" cannot be answered by
        // multiplying counts by sizeof: an unordered_map also holds a bucket
        // array and a per-node allocation with CRT overhead. The constants in
        // module/footprint.h are measured by tools/harness/test_footprint_cost.cpp,
        // which fills a real unordered_map<MetaKey, void*, MetaKeyHash> and takes
        // the slope of GetProcessMemoryInfo, and whose negative control destroys
        // the map and asserts the memory comes back.
        //
        // The line it emits is labelled a FLOOR: it covers the two caches with no
        // eviction policy and the two fixed region tables, and deliberately does
        // NOT claim to cover the chams registries or the render path. A partial
        // answer presented as a total is the failure that file exists to prevent.
        crash_probe::set_footprint_provider(&report_mod_footprint);

        // The one-time import of a pre-3.2 file layout used to run here, on every
        // process start. It moved to tools/deploy.py -- see the module docstring in
        // tools/migrate_legacy.py for why.
        //
        // The two reasons, briefly, because "it was faster" is not one of them:
        //
        //  1. It was never load-bearing. ConfigModule.cpp:263-267 reads
        //     ta\configs\ -> ta\ -> %APPDATA%\TarkovAddons\, and says the middle
        //     one is "still read so that a failed or skipped migration cannot
        //     present as 'no config found'". So not running it costs untidied
        //     data, not lost settings, and the mod reads the old paths anyway.
        //  2. It read the AMBIENT %APPDATA% and then moved real files. That is
        //     what made it dangerous to test -- WORKFLOW.md records a harness bug
        //     that moved 23 real user files, because _dupenv_s reads the CRT copy
        //     of the environment and SetEnvironmentVariableW does not redirect
        //     it. With the roots as arguments in deploy.py, that class of accident
        //     does not exist.
        //
        // It also deleted a stale chams bundle with no prompt, and renamed rather
        // than copy-verifying, so the common same-volume case performed no
        // verification at all. Both are now visible and both are behind confirm().

        // ---- boot gate 1: the Unity window -----------------------------
        //
        // 2026-10-02: this loop is logged as "Waiting for Unity window to
        // become ready..." and the log then shows `Loading Il2CPP API` one or
        // two milliseconds later, which reads like the wait is not waiting.
        // Two possibilities, and they mean different things: the window is
        // genuinely already up (fine), or the gate is not the gate we think it
        // is. Log the fact instead of leaving it to be inferred from a
        // timestamp delta, because a boot gate that silently does nothing is
        // indistinguishable from a boot gate that is not needed.
        logger::info("Waiting for Unity window to become ready...");
        const ULONGLONG gate1_start = GetTickCount64();
        UINT64 gate1_polls = 0;
        while (!FindWindowW(L"UnityWndClass", nullptr))
        {
            ++gate1_polls;
            Sleep(10);
        }
        logger::info("boot: Unity window present after " +
            std::to_string(GetTickCount64() - gate1_start) + " ms, " +
            std::to_string(gate1_polls) + " poll(s)");

        // Is GameAssembly actually up yet, is the loader still listing it, and
        // is it the one the manifest describes? All three are cheap and all
        // three were assumptions rather than measurements until now.
        //
        // The loader-list question is the one that matters, and it was missing:
        // the first version of this line logged `path="<not loaded>"`, which
        // conflates "the module is absent" with "the loader will not name a
        // module that is present". Those need opposite responses, and the
        // ambiguous string is part of why the first diagnosis of the export
        // failures had to be inferred rather than read. log_module_state()
        // separates them and also reads SizeOfImage straight off the PE
        // headers, which works whether or not the loader cooperates.
        //
        // Called twice -- here and again after init -- so the pair is a
        // timeline rather than one reading. If membership flips between them,
        // the unlink races startup and a retry would have been worth something.
        // If it is already unlisted here, the unlink happened before we were
        // called and the direct read was the only thing that could ever work.
        il2cpp_offsets::log_module_state("at Unity gate");

        // load il2cpp offsets
        const ULONGLONG api_start = GetTickCount64();
        const bool api_ok = il2cpp_offsets::init();
        logger::info("boot: IL2CPP API resolved in " +
            std::to_string(GetTickCount64() - api_start) + " ms");
        il2cpp_offsets::log_module_state("after il2cpp init");
        if (!api_ok)
        {
            logger::error("Mod startup stopped: IL2CPP API is incomplete. Update offsets or patterns before retrying.");
            return 0;
        }

        // init unity interop
        const ULONGLONG unity_start = GetTickCount64();
        logger::info("Loading Unity");
        if (!unity::init())
        {
            logger::error("Mod startup stopped: Unity interop did not initialize safely.");
            return 0;
        }
        logger::info("Unity Loaded");
        logger::info("boot: unity::init took " +
            std::to_string(GetTickCount64() - unity_start) + " ms");

        // init modules
        const ULONGLONG modules_start = GetTickCount64();
        logger::info("Loading Modules");
        ModuleManager::get_instance()->init();
        logger::info("Loaded Modules");
        logger::info("boot: ModuleManager::init took " +
            std::to_string(GetTickCount64() - modules_start) + " ms");

        // ---- boot gate 2: the DX modules -------------------------------
        //
        // Same reasoning: this one has a 50 ms poll, so if it ever blocks the
        // cost is obvious, and if it never blocks that is worth recording
        // rather than assuming.
        const ULONGLONG gate2_start = GetTickCount64();
        UINT64 gate2_polls = 0;
        while (!GetModuleHandle(L"d3d11.dll") || !GetModuleHandle(L"dxgi.dll"))
        {
            ++gate2_polls;
            Sleep(50);
        }
        logger::info("boot: d3d11+dxgi present after " +
            std::to_string(GetTickCount64() - gate2_start) + " ms, " +
            std::to_string(gate2_polls) + " poll(s)");

        // dxhook and menu
        logger::info("Hooking Present");
        if (!dxhook::init(this_module))
            logger::error("Present Hook Failed");
        else
            logger::info("Hooked Present");

        // load default features and common hooks
        logger::info("Loading Default Features");
        always_on::init();
        if (!common_hooks::init())
        {
            logger::error("Mod startup stopped: game update hooks could not be installed safely.");
            return 0;
        }
        logger::info("Loaded Default Features");

        std::cout << "\n";
        logger::warn(
            "This is FREE software! If you paid for this software or completed some task to obtain it, you were scammed!");
        std::cout << "\n";

        i18n::init_menu_languages();
        if (config_module_self)
            config_module_self->init_menu_language_options();
        std::cout << "\n";

        logger::info("Menu Key: Insert");
        std::cout << "\n";

        return 0;
    }
} // namespace

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        // First thing, and before the worker thread exists: hModule IS this
        // image's base, and this is the last moment its headers are guaranteed
        // readable. pe_resource reads RCDATA out of .rsrc by walking from an
        // image base, and on 2026-09-30 every way of *asking* for that base
        // stopped answering three and a half minutes into a session -- the
        // minimap's 22 map payloads were unreadable while i18n's 19 locales had
        // loaded fine minutes earlier, from the same image, through the same
        // reader. Capturing the base here means the reader never asks again.
        // See pe_resource::remember_image_base().
        pe_resource::remember_image_base(hModule);
        module_paths::init(hModule);
        DisableThreadLibraryCalls(hModule);
        CreateThread(nullptr, 0, init, hModule, 0, nullptr);
        break;
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
        break;
    case DLL_PROCESS_DETACH: {
        // Kept, but it is NOT the session end marker and must not be read as one.
        //
        // The image is manual-mapped (AGENTS.md), so the OS has no loader record of it and
        // this case does not run on process exit -- only on a FreeLibrary, which this
        // deployment never performs. Measured 2026-10-05: eight launches, zero of these lines.
        // It stays because it costs nothing and would be correct the moment the deployment
        // changed to a real LoadLibrary; what must not happen is a reader treating its
        // absence as evidence of anything.
        //
        // uptime is here because if it ever DOES fire, how long the session lasted is the
        // first thing wanted, and the alternative is diffing first and last timestamps.
        const long long start = g_session_start_ms.load(std::memory_order_acquire);
        const unsigned long pid = g_session_pid.load(std::memory_order_acquire);
        const long long now = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
        // try_lock, never the blocking logger path -- see logger.h. A deadlock inside DllMain
        // is an unrecoverable hang during process teardown.
        logger::info_at_exit(std::string("==== SESSION UNLOAD pid=") + std::to_string(pid)
            + " uptime=" + (start > 0 ? std::to_string(now - start) + "ms" : std::string("unknown"))
            + " via=" + (lpReserved ? "FreeLibrary" : "process-exit")
            + " ====");
        break;
    }
    default:;
    }

    return TRUE;
}
