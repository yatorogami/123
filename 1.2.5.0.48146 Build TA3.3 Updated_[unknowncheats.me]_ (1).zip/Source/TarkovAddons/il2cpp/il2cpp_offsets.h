#pragma once
#include <windows.h>
#include <Psapi.h>
#include <cstdint>
#include "../util/scan.h"
#include "../util/logger.h"
#include "../util/Config.h"
#include "../util/globals.h"
#include "../../shared/module_paths.h"
// For pe_resource::image_extent_at(), which reads SizeOfImage out of an
// already-mapped module's own PE headers with no loader involvement. That is
// what makes it useful here: it still answers when the module is mapped but no
// longer listed, which is the state that makes GetProcAddress fail.
#include "../util/pe_resource.h"
#include "compatibility_profile.h"

// These two were in an anonymous namespace. They stay here rather than moving
// to a .cpp, because PATTERN/PATTERN_CALL/EXPORT_OF below expand to unqualified
// calls to them at sites inside `namespace il2cpp_offsets`, so they have to be
// visible by unqualified name in every TU that includes this header. Moving them
// out would mean giving them external linkage, and `get_offset` is much too
// generic a name for the global namespace.
//
// `inline` is the correct spelling for that requirement: it is what makes a
// definition in a header legal, and it obliges every TU that sees the
// declaration to carry the body -- which is precisely what is wanted here, and
// what an anonymous namespace in a header silently was not.
inline uintptr_t get_export_addr(HMODULE module, const char* name) {
    return reinterpret_cast<uintptr_t>(GetProcAddress(module, name));
}

inline PVOID get_offset(Configuration& cfg, HMODULE module, const char* name) {
        logger::info(std::string("Getting offset from cfg for ") + name);
        std::string value = cfg.get(name);

        if (value.empty())
            return nullptr;

        try
        {
            uintptr_t offset = std::stoull(value, nullptr, 0);
            MODULEINFO info = {};
            if (!GetModuleInformation(GetCurrentProcess(), module, &info, sizeof(info))
                || offset >= info.SizeOfImage)
            {
                logger::warn("Offset outside GameAssembly image for " + std::string(name));
                return nullptr;
            }

            return reinterpret_cast<PVOID>(
                reinterpret_cast<uintptr_t>(module) + offset);
        } catch (const std::invalid_argument&)
        {
            logger::warn("Invalid offset value (" + value + ") for " + name);
        } catch (const std::out_of_range&)
        {
            logger::warn("Offset out of range (" + value + ") for " + name);
        }

        return nullptr;
    }

namespace il2cpp_offsets {

    inline HMODULE module_base;
    inline DWORD module_size;
    inline compatibility_profile::Profile active_profile;
    inline bool active_profile_loaded = false;

#define PATTERN(pattern) reinterpret_cast<PVOID>(scan::find_pattern(pattern, reinterpret_cast<char*>(module_base), module_size))
#define PATTERN_CALL(pattern) reinterpret_cast<PVOID>(scan::find_pattern_xref(pattern, reinterpret_cast<char*>(module_base), module_size, 1, 5))
#define EXPORT_OF(name) reinterpret_cast<PVOID>(get_export_addr(module_base, name))

    inline PVOID il2cpp_class_from_name;
    inline PVOID il2cpp_class_get_nested_types;
    inline PVOID il2cpp_class_get_field_from_name;
    inline PVOID il2cpp_class_get_method_from_name;
    inline PVOID il2cpp_domain_get;
    inline PVOID il2cpp_domain_get_assemblies;
    inline PVOID il2cpp_field_static_get_value;
    inline PVOID il2cpp_field_static_set_value;
    inline PVOID il2cpp_field_get_value_object;
    inline PVOID il2cpp_string_new;
    inline PVOID il2cpp_type_get_object;
    inline PVOID il2cpp_array_new;
    inline PVOID il2cpp_object_new;
    inline PVOID il2cpp_runtime_class_init;

    inline PVOID resolve_pattern(const std::string& pattern) {
        if (pattern.empty())
            return nullptr;
        if (pattern.starts_with("E8") || pattern.starts_with("E9"))
            return PATTERN_CALL(pattern);
        return PATTERN(pattern);
    }

    inline PVOID resolve_pattern_with_retry(const std::string& pattern, int retries = 3, int retry_delay_ms = 150) {
        for (int i = 0; i < retries; i++)
        {
            PVOID result = resolve_pattern(pattern);
            if (result)
                return result;

            logger::warn(
                "Pattern resolve failed, retry " + std::to_string(i + 1) + "/" + std::to_string(retries));
            Sleep(retry_delay_ms);
        }
        return nullptr;
    }

    // Uppercase hex, for the diagnostics. std::format is available but pulling
    // it in for three call sites in a header every TU includes is not worth
    // the compile time, and _snprintf_s needs no <format>.
    inline std::string hex_u64(UINT64 v) {
        char b[24];
        _snprintf_s(b, sizeof(b), _TRUNCATE, "%llX", static_cast<unsigned long long>(v));
        return b;
    }

    // Everything needed to tell "the export is missing" from "GetProcAddress is
    // lying", for one symbol. Called only on the failure path, so it costs
    // nothing when resolution works.
    //
    // Defined below. Declared here because report_export_failure() calls it, and
    // this header is included from translation units in several orders.
    inline void report_getprocaddress_state(const char* export_name, DWORD last_error, HMODULE target);

    // The last_error is sampled by the CALLER immediately after the
    // GetProcAddress and passed in, because this function's first act is to
    // format a string and that alone is enough to clobber the last error.
    inline void report_export_failure(const char* export_name, DWORD last_error) {
        logger::error("export: GetProcAddress(GameAssembly=" +
            hex_u64(reinterpret_cast<UINT64>(module_base)) + ", \"" +
            (export_name ? export_name : "?") + "\") returned NULL, GetLastError=" +
            std::to_string(static_cast<unsigned long>(last_error)) + " (0x" +
            hex_u64(static_cast<UINT64>(last_error)) + ")");

        // Which GameAssembly, because a manifest that matches one build and a
        // loader that hands you another is the cheapest explanation for
        // anything the export table says otherwise.
        wchar_t path[MAX_PATH]{};
        if (module_base && GetModuleFileNameW(module_base, path, MAX_PATH))
            logger::error("export: module path is "
                + module_paths::wide_to_utf8(std::wstring(path)));
        else
            logger::error("export: GetModuleFileNameW on the module returned 0");

        const scan::PeImageView view{
            reinterpret_cast<UINT64>(module_base),
            static_cast<UINT64>(module_size)
        };
        const scan::ExportLookup found = scan::find_export_by_hand(view, export_name);
        const std::string described = scan::describe_export_lookup(found, export_name);

        if (found.parsed && found.found) {
            // The table has it and the API did not. One sentence, not an
            // inference the reader has to make from two log lines.
            logger::error("export: VERDICT -- the export IS in the module's export table, so "
                "GetProcAddress is the failing party, not the manifest. " + described);
        }
        else if (found.parsed) {
            logger::error("export: VERDICT -- the name is genuinely NOT exported; the manifest is "
                "wrong for this build, or the resolver should use a pattern. " + described);
        }
        else {
            logger::error("export: VERDICT -- the hand lookup could not read the export table at "
                "all, so this is NOT evidence either way. " + described);
        }

        report_getprocaddress_state(export_name, last_error, module_base);
    }

    // Is our GetProcAddress itself replaced?
    //
    // Split out of report_export_failure() on 2026-10-02, and the split is the
    // point. It used to live there, which meant it only ran when the *direct
    // export read also failed* -- and the direct read never fails, because it
    // does not ask the loader anything. So the one measurement that would
    // confirm interception never ran in the case interception was suspected.
    // A diagnostic on the dead-end path is worse than none: it looks like
    // coverage.
    //
    // Why it matters now: the 2026-10-02 evidence is that GameAssembly.dll is
    // present in EnumProcessModulesEx(LIST_MODULES_ALL) -- so the loader does
    // list it and it was never unlinked -- while GetProcAddress and
    // GetModuleFileNameW both refuse it. That combination is a filter on those
    // two APIs for one module, not a missing list entry. This is the test that
    // distinguishes "our IAT entry was replaced" from "kernel32's GetProcAddress
    // is doing something policy-shaped", and it needs to run on the fallback
    // path rather than the failure path.
    inline void report_getprocaddress_state(const char* export_name, DWORD last_error, HMODULE target) {
        MODULEINFO kinfo{};
        const HMODULE kernel32 = GetModuleHandleW(L"kernel32.dll");
        if (!kernel32 || !GetModuleInformation(GetCurrentProcess(), kernel32, &kinfo, sizeof(kinfo))
            || !kinfo.SizeOfImage)
        {
            logger::error("export: could not resolve a reference GetProcAddress for comparison "
                "(kernel32 handle, size, or export lookup failed).");
            return;
        }

        const scan::PeImageView k32{ reinterpret_cast<UINT64>(kernel32),
                                      static_cast<UINT64>(kinfo.SizeOfImage) };
        const auto real_gpa = scan::find_export_by_hand(k32, "GetProcAddress");
        if (!real_gpa.parsed || !real_gpa.found || real_gpa.forwarded)
        {
            logger::error("export: could not resolve a reference GetProcAddress for comparison.");
            return;
        }

        using GetProcAddressFn = FARPROC(WINAPI*)(HMODULE, LPCSTR);
        const auto fn = reinterpret_cast<GetProcAddressFn>(real_gpa.address);
        SetLastError(0);
        const auto via_hand = fn(target, export_name);
        const DWORD hand_err = GetLastError();
        SetLastError(0);
        const auto via_iat = GetProcAddress(target, export_name);

        char head[160];
        _snprintf_s(head, sizeof(head), _TRUNCATE,
            "export: reference GetProcAddress (from kernel32's own export table, bypassing our "
            "IAT) at 0x%s; our IAT GetProcAddress; target GetLastError=%lu",
            hex_u64(real_gpa.address).c_str(),
            static_cast<unsigned long>(last_error));

        if (via_hand && !via_iat)
        {
            logger::error(std::string(head) + " -- VERDICT: reference returned 0x" +
                hex_u64(reinterpret_cast<UINT64>(via_hand)) +
                " (GetLastError=" + std::to_string(static_cast<unsigned long>(hand_err)) +
                ") while ours returned NULL. Our IAT entry is REPLACED: a hook is filtering this "
                "module out of GetProcAddress. Nothing about the module changes over time, so no "
                "wait can help -- and this is not the mod's doing.");
        }
        else if (via_hand)
        {
            logger::warn(std::string(head) + " -- reference returned 0x" +
                hex_u64(reinterpret_cast<UINT64>(via_hand)) +
                " and so did ours on this call, so our IAT is NOT replaced: the denial is inside "
                "GetProcAddress itself, i.e. a policy applied to this module rather than a hook on "
                "the entry point.");
        }
        else
        {
            logger::error(std::string(head) +
                " -- both returned NULL, so the reference GetProcAddress denies it too. The "
                "denial is not specific to our import.");
        }
    }

    // Is the module still in the loader's module list?
    //
    // Read-only, and it exists because "the module is mapped but the loader does
    // not know it" is a strong claim that one line of evidence should settle
    // rather than leaving to be inferred. GetProcAddress and GetModuleFileNameW
    // both resolve a handle through that list, which is exactly the observed
    // pair of failures -- both null, with ERROR_MOD_NOT_FOUND, on a handle whose
    // bytes are demonstrably readable.
    //
    // Implemented with EnumProcessModulesEx rather than by walking the PEB's
    // InMemoryOrderModuleList by hand. The hand version was written first and
    // then removed: it needs PEB, PEB_LDR_DATA and LDR_DATA_TABLE_ENTRY, which
    // <windows.h> does not declare under WIN32_LEAN_AND_MEAN (which this project
    // sets), so it would have meant redeclaring loader structures and depending
    // on their field offsets on a path whose whole purpose is to diagnose
    // something subtle. A documented read-only API is the better instrument even
    // when the unchecked one is shorter. It also cannot write to loader memory,
    // which a hand walk does if you get the base-of-entry arithmetic wrong --
    // the exact bug the launcher has, per AGENTS_TODO.md 3.1.
    // Pure query: does the loader still list this module?
    //
    // No logging, on purpose. This is now called from three places -- the boot
    // gate, after init(), and once on the fallback path -- and a diagnostic that
    // both answers a question and writes to the log cannot be called from a
    // place that only wants the answer. Logging lives in log_module_state().
    inline bool loader_lists_module(HMODULE module) {
        if (!module)
            return false;

        HMODULE found[1024];
        DWORD needed = 0;
        // LIST_MODULES_ALL means "every module", which is what we want: the
        // question is whether the loader still lists this one at all, and the
        // filtered variants could hide it for reasons of their own.
        if (!EnumProcessModulesEx(GetCurrentProcess(), found, sizeof(found),
                &needed, LIST_MODULES_ALL))
            return false;

        const DWORD count = needed / sizeof(HMODULE);
        const DWORD limit = (count > 1024) ? 1024 : count;
        const auto base = reinterpret_cast<UINT64>(module);
        for (DWORD i = 0; i < limit; ++i) {
            if (reinterpret_cast<UINT64>(found[i]) == base)
                return true;
        }
        return false;
    }

    inline DWORD loader_module_count() {
        HMODULE found[1024];
        DWORD needed = 0;
        if (!EnumProcessModulesEx(GetCurrentProcess(), found, sizeof(found),
                &needed, LIST_MODULES_ALL))
            return 0;
        const DWORD count = needed / sizeof(HMODULE);
        return (count > 1024) ? 1024 : count;
    }

    // Everything known about GameAssembly.dll at one instant, in one line.
    //
    // The reason this exists in the shape it does: the boot gate used to log
    // path="<not loaded>", which conflates two completely different states --
    // the module is absent, or the loader will not name a module that is
    // present. Those need opposite responses, and the ambiguous string is what
    // left the first diagnosis guessing. So: the handle, whether the loader
    // lists it, whether it will name it, the image extent we can read straight
    // off the PE headers, and how many modules are listed in total.
    //
    // `when` is free text so each call site names its own moment, which turns a
    // single ambiguous reading into a two-point timeline. If the membership
    // flips between the gate and the end of init, the unlink is racing startup
    // and a retry would have been worth something after all; if it is already
    // unlisted at the gate, the unlink happened before we were ever called and
    // the direct read is the only thing that could ever have worked.
    inline void log_module_state(const char* when) {
        const HMODULE ga = GetModuleHandleW(L"GameAssembly.dll");
        if (!ga) {
            logger::error(std::string("boot[") + when + "]: GameAssembly.dll is NOT loaded. "
                "GetModuleHandleW returned null, so there is nothing to resolve against.");
            return;
        }

        const auto base = reinterpret_cast<UINT64>(ga);
        const bool listed = loader_lists_module(ga);
        const DWORD module_count = loader_module_count();

        wchar_t path[MAX_PATH]{};
        const DWORD path_len = GetModuleFileNameW(ga, path, MAX_PATH);

        // The extent is read from the module's own PE header, with no loader
        // involved, which is the whole point: it works whether or not the module
        // is listed. Compared against the manifest's identity in prose by the
        // reader; printed here because it is the fact that proves "mapped and
        // readable" without appealing to anything but this process.
        const size_t extent = pe_resource::image_extent_at(
            reinterpret_cast<const std::byte*>(ga));

        std::string text = std::string("boot[") + when + "]: GameAssembly=";
        text += hex_u64(base);
        text += listed ? " LISTED" : " NOT-LISTED";
        text += std::to_string(module_count) + " module(s) enumerated; ";
        text += path_len ? ("named \"" + module_paths::wide_to_utf8(std::wstring(path)) + "\"")
                         : std::string("GetModuleFileNameW FAILED");
        char tail[96];
        _snprintf_s(tail, sizeof(tail), _TRUNCATE,
            "; SizeOfImage=0x%zX read from its own headers",
            static_cast<size_t>(extent));
        text += tail;

        if (!listed && path_len == 0) {
            text += ". Mapped and readable but unlisted: GetProcAddress and "
                    "GetModuleFileNameW will both fail on this handle. The export "
                    "table must be read directly.";
        }
        logger::info(text);
    }

    // How many required symbols the direct read had to answer, as opposed to
    // GetProcAddress. Zero means the fallback never fired and this launch tells
    // us nothing new; anything above zero means it did, and startup still
    // succeeded -- which is the positive confirmation the fallback needs, since
    // a launch that never hits the problem looks identical to one that fixed it.
    inline int& export_fallback_count() {
        static int count = 0;
        return count;
    }

    // Follow export E9/FF25 stubs (safe for domain_get / string_new style exports).
    //
    // 2026-10-02, and this is the fix the diagnostics pointed at. GetProcAddress
    // is tried first because it is the loader's canonical answer and the only
    // thing here that resolves a forwarder. It fails on some launches -- with
    // ERROR_MOD_NOT_FOUND, 126, and GetModuleFileNameW failing on the same
    // handle -- because GameAssembly.dll is mapped but not in the loader's
    // module list. Reading the export directory directly does not care, because
    // it never asks the loader anything.
    //
    // Both orders were tried in a live process before being written down here:
    // the hand reader returned the correct ordinal and RVA for all six symbols,
    // and an independent parse of the on-disk GameAssembly.dll agreed with it on
    // 6/6 (ord 31/103/111/186/207/232). So the fallback is not a guess that
    // happens to be tried second; it is the path that is known to work, and
    // GetProcAddress is now the optimistic one.
    inline PVOID resolve_export_body(const char* export_name) {
        UINT64 exp = get_export_addr(module_base, export_name);
        if (!exp) {
            // Sample GetLastError FIRST. Every line between the two would
            // clobber it, which is the whole reason the reporting is a
            // separate function taking the value as an argument.
            const DWORD last_error = GetLastError();

            const scan::PeImageView view{
                reinterpret_cast<UINT64>(module_base),
                static_cast<UINT64>(module_size)
            };
            const scan::ExportLookup by_hand = scan::find_export_by_hand(view, export_name);
            if (by_hand.parsed && by_hand.found && !by_hand.forwarded) {
                // ABSOLUTE address, not the RVA. follow_export_thunk() is handed
                // an address by the GetProcAddress path above, and it bounds
                // checks against [module_base, module_base + module_size) --
                // feed it a bare RVA and every hop is out of range, it returns
                // its input unchanged, and we call the head of the image.
                // by_hand.address is base + rva; by_hand.rva is the rva.
                const UINT64 absolute = by_hand.address;
                const UINT64 image_end = reinterpret_cast<UINT64>(module_base) + module_size;
                if (absolute < reinterpret_cast<UINT64>(module_base) || absolute >= image_end) {
                    // Should be impossible: find_export_by_hand bounds-checks
                    // every access and this is the same arithmetic. Asserting it
                    // anyway, because the consequence of being wrong is a call
                    // through a wild pointer into the game, and a failed assert
                    // is a far better outcome than that.
                    logger::error("export: hand-read RVA 0x" + hex_u64(by_hand.rva) +
                        " for \"" + std::string(export_name ? export_name : "?") +
                        "\" lands outside the image; refusing to call it.");
                    report_export_failure(export_name, last_error);
                    return nullptr;
                }
                logger::warn("export: GetProcAddress failed for \"" +
                    std::string(export_name ? export_name : "?") + "\" (GetLastError=" +
                    std::to_string(static_cast<unsigned long>(last_error)) +
                    ", " + (last_error == ERROR_MOD_NOT_FOUND
                        ? "ERROR_MOD_NOT_FOUND - the loader does not list this module"
                        : "see above") +
                    ") but the export is in the image; using the direct read at RVA 0x" +
                    hex_u64(by_hand.rva) + ". Waiting would not have helped.");
                ++export_fallback_count();
                // The "why" line, and it says the same thing for all six symbols,
                // so it fires once. A per-symbol repetition would be six identical
                // ERROR lines -- which is precisely the flood shape this project
                // keeps having to clean up afterwards. The WARN above already
                // names each symbol, so nothing is lost.
                static bool loader_list_reported = false;
                if (!loader_list_reported) {
                    loader_list_reported = true;
                    log_module_state("first export fallback");
                    // The one measurement that separates "our IAT entry is
                    // replaced" from "GetProcAddress applies a policy to this
                    // module". It used to live on the failure path, where the
                    // direct read always succeeds and so it never ran -- a
                    // diagnostic on the dead-end path is worse than none,
                    // because it looks like coverage.
                    report_getprocaddress_state(export_name, last_error, module_base);
                }
                exp = absolute;
            } else {
                report_export_failure(export_name, last_error);
                return nullptr;
            }
        }
        const UINT64 body = scan::follow_export_thunk(
            exp,
            reinterpret_cast<UINT64>(module_base),
            module_size);
        return reinterpret_cast<PVOID>(body ? body : exp);
    }

    inline PVOID resolve_profile_symbol(const compatibility_profile::Symbol& symbol) {
        if (symbol.module != "GameAssembly.dll") return nullptr;

        std::vector<std::string> order = symbol.resolution_order;
        if (order.empty())
        {
            if (symbol.resolver == "export") order.push_back("export");
            else if (symbol.resolver == "pattern") order = {"pattern", "export"};
            else order.push_back("native");
        }

        for (const auto& step : order)
        {
            if (step == "pattern")
            {
                for (const auto& pattern : symbol.patterns)
                {
                    if (PVOID result = resolve_pattern_with_retry(pattern))
                        return result;
                }
            }
            else if (step == "export")
            {
                const std::string export_name = symbol.export_name.empty() ? symbol.name : symbol.export_name;
                if (PVOID result = resolve_export_body(export_name.c_str()))
                    return result;
            }
            else if (step == "rva" || step == "native")
            {
                if (symbol.rva && *symbol.rva < module_size)
                    return reinterpret_cast<PVOID>(reinterpret_cast<uintptr_t>(module_base) + *symbol.rva);
            }
        }
        return nullptr;
    }

    inline bool init() {
        logger::info("Loading Il2CPP API");

        module_base = GetModuleHandleA("GameAssembly.dll");
        if (!module_base)
        {
            logger::error("GameAssembly.dll not loaded");
            return false;
        }

        MODULEINFO info = {};
        GetModuleInformation(GetCurrentProcess(), module_base, &info, sizeof(MODULEINFO));
        module_size = info.SizeOfImage;
        if (!module_size)
        {
            logger::error("GameAssembly.dll image size could not be read");
            return false;
        }

        std::string profile_detail;
        const auto profile_result = compatibility_profile::Profile::load_for_module(
            module_base, active_profile, profile_detail);
        if (profile_result == compatibility_profile::LoadResult::Loaded)
        {
            active_profile_loaded = true;
            logger::info("IL2CPP compatibility profile loaded: " + profile_detail);
        }
        else if (profile_result == compatibility_profile::LoadResult::NotFound)
        {
            active_profile_loaded = false;
            logger::info("No compatibility profile found; using legacy IL2CPP resolver");
        }
        else
        {
            logger::error("IL2CPP compatibility profile rejected: " + profile_detail);
            return false;
        }

        if (active_profile_loaded)
        {
            struct ProfileEntry
            {
                const char* name;
                PVOID* target;
            };
            ProfileEntry profile_entries[] = {
                {"il2cpp_class_from_name", &il2cpp_class_from_name},
                {"il2cpp_class_get_nested_types", &il2cpp_class_get_nested_types},
                {"il2cpp_class_get_field_from_name", &il2cpp_class_get_field_from_name},
                {"il2cpp_class_get_method_from_name", &il2cpp_class_get_method_from_name},
                {"il2cpp_domain_get", &il2cpp_domain_get},
                {"il2cpp_domain_get_assemblies", &il2cpp_domain_get_assemblies},
                {"il2cpp_field_static_get_value", &il2cpp_field_static_get_value},
                {"il2cpp_field_static_set_value", &il2cpp_field_static_set_value},
                {"il2cpp_field_get_value_object", &il2cpp_field_get_value_object},
                {"il2cpp_string_new", &il2cpp_string_new},
                {"il2cpp_type_get_object", &il2cpp_type_get_object},
                {"il2cpp_array_new", &il2cpp_array_new},
                {"il2cpp_object_new", &il2cpp_object_new},
                {"il2cpp_runtime_class_init", &il2cpp_runtime_class_init},
            };

            bool complete = true;
            for (const auto& entry : profile_entries)
            {
                const auto* symbol = active_profile.find(entry.name);
                if (!symbol)
                {
                    logger::error(std::string("Compatibility profile is missing required symbol: ") + entry.name);
                    complete = false;
                    continue;
                }
                *entry.target = resolve_profile_symbol(*symbol);
                if (!*entry.target)
                {
                    logger::error(std::string("Compatibility profile could not resolve required symbol: ") + entry.name);
                    complete = false;
                }
                else
                {
                    logger::debug(std::string("Profile resolved ") + entry.name);
                }
            }

            if (!complete)
            {
                logger::error("IL2CPP compatibility profile is incomplete; startup will stop safely");
                return false;
            }
            logger::info("IL2CPP API Loaded via compatibility profile");
            // Positive confirmation of the fallback, because a launch that never
            // hits the problem and a launch the fallback saved produce identical
            // logs otherwise. "0 by direct read" is a real result and worth
            // having: it says the loader listed the module for every symbol.
            {
                const int via_direct = export_fallback_count();
                logger::info(std::string("boot[il2cpp]: ") + std::to_string(via_direct) +
                    " of 14 required symbol(s) needed a direct read of the export table because "
                    "GetProcAddress could not. " + (via_direct == 0
                        ? "The loader listed the module for all of them this launch."
                        : "The loader did not list the module for those; startup succeeded anyway."));
            }
            return true;
        }

        Configuration cfg;
        bool offsets_loaded = false;
        // Prefer the config stored alongside the injected DLL. This keeps the
        // offsets with the mod instead of relying on Tarkov's working folder.
        const std::filesystem::path dll_offsets = module_paths::data_directory_wide()
            / std::filesystem::path(globals::DLL_OFFSET_FILE);
        if (!dll_offsets.empty())
            offsets_loaded = cfg.load(dll_offsets.string());
        if (!offsets_loaded)
            offsets_loaded = cfg.load((dll_offsets / globals::DLL_OFFSET_FILE).string());
        if (!offsets_loaded)
        {
            wchar_t exe_path[MAX_PATH]{};
            if (GetModuleFileNameW(nullptr, exe_path, MAX_PATH))
            {
                const std::filesystem::path game_dir = std::filesystem::path(exe_path).parent_path();
                offsets_loaded = cfg.load((game_dir / globals::DLL_OFFSET_FILE).string());
                if (!offsets_loaded)
                    offsets_loaded = cfg.load((game_dir / "launcher" / globals::DLL_OFFSET_FILE).string());
            }
        }

        if (offsets_loaded)
        {
            logger::info("Loading Il2CPP offsets from external offsets.cfg");
            il2cpp_class_from_name = get_offset(cfg, module_base, "il2cpp_class_from_name");
            il2cpp_class_get_nested_types = get_offset(cfg, module_base, "il2cpp_class_get_nested_types");
            il2cpp_class_get_field_from_name = get_offset(cfg, module_base, "il2cpp_class_get_field_from_name");
            il2cpp_class_get_method_from_name = get_offset(cfg, module_base, "il2cpp_class_get_method_from_name");
            il2cpp_domain_get = get_offset(cfg, module_base, "il2cpp_domain_get");
            il2cpp_field_static_get_value = get_offset(cfg, module_base, "il2cpp_field_static_get_value");
            il2cpp_field_static_set_value = get_offset(cfg, module_base, "il2cpp_field_static_set_value");
            il2cpp_type_get_object = get_offset(cfg, module_base, "il2cpp_type_get_object");
            il2cpp_domain_get_assemblies = get_offset(cfg, module_base, "il2cpp_domain_get_assemblies");
            il2cpp_string_new = get_offset(cfg, module_base, "il2cpp_string_new");
            il2cpp_field_get_value_object = get_offset(cfg, module_base, "il2cpp_field_get_value_object");
            il2cpp_array_new = get_offset(cfg, module_base, "il2cpp_array_new");
            il2cpp_object_new = get_offset(cfg, module_base, "il2cpp_object_new");
            il2cpp_runtime_class_init = get_offset(cfg, module_base, "il2cpp_runtime_class_init");
        }

        if (il2cpp_class_from_name != nullptr && il2cpp_class_get_nested_types != nullptr && il2cpp_class_get_field_from_name != nullptr
            && il2cpp_class_get_method_from_name != nullptr && il2cpp_domain_get != nullptr && il2cpp_field_static_get_value != nullptr
            && il2cpp_field_static_set_value != nullptr && il2cpp_type_get_object != nullptr && il2cpp_domain_get_assemblies != nullptr
            && il2cpp_string_new != nullptr && il2cpp_field_get_value_object != nullptr && il2cpp_array_new != nullptr
            && il2cpp_object_new != nullptr && il2cpp_runtime_class_init != nullptr)
        {
            logger::info("Il2CPP API Loaded via offset file");
            return true;
        }

        std::string class_from_name_pattern =
            "4C 89 44 24 18 48 89 54 24 10 53 55 56 57 41 54 41 55 41 56 41 57 48 81";

        std::string class_get_nested_types_pattern =
            "48 89 5C 24 08 48 89 74 24 18 57 48 83 EC 20 48 8B FA 48 8B D9 48 85 D2 0F 84 FB";

        std::string class_get_field_from_name_pattern =
            "48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 83 EC 20 48 8B EA 48 8B D9 48";

        std::string class_get_method_from_name_pattern =
            "48 89 5C 24 10 48 89 6C 24 18 48 89 74 24 20 57 41 56 41 57 48 83 EC 20 41";

        std::string domain_get_pattern =
            "48 83 EC 28 48 8B 05 ? ? ? ? 48 85 C0 75 39";

        std::string field_static_get_value_pattern =
            "48 89 5C 24 18 48 89 74 24 20 57 48 83 EC 20 48 8B 41 08";

        std::string field_static_set_value_pattern =
            "48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 83 EC 20 48 8B E9 48 8B FA";

        std::string type_get_object_pattern =
            "48 89 4C 24 08 53 48 83 EC 20 48 8B D9";

        Configuration pattern_cfg;
        bool patterns_loaded = false;
        // Keep pattern updates beside the injected DLL, just like offsets.cfg.
        // The game process's working directory is not guaranteed to be the
        // launcher directory, so it cannot be relied on for this file.
        const std::filesystem::path dll_patterns = module_paths::data_directory_wide()
            / std::filesystem::path(globals::DLL_PATTERN_FILE);
        if (!dll_patterns.empty())
            patterns_loaded = pattern_cfg.load(dll_patterns.string());
        if (!patterns_loaded)
            patterns_loaded = pattern_cfg.load((dll_patterns / globals::DLL_PATTERN_FILE).string());

        if (patterns_loaded)
        {
            logger::info("Loading Il2CPP patterns from external patterns.cfg");
            auto take = [&](const char* key, std::string& dest) {
                std::string p = pattern_cfg.get(key);
                // strip trailing comments from cfg lines
                const auto hash = p.find('#');
                if (hash != std::string::npos)
                    p = p.substr(0, hash);
                while (!p.empty() && (p.back() == ' ' || p.back() == '\t'))
                    p.pop_back();
                if (!p.empty())
                    dest = p;
            };
            take("il2cpp_class_from_name", class_from_name_pattern);
            take("il2cpp_class_get_nested_types", class_get_nested_types_pattern);
            take("il2cpp_class_get_field_from_name", class_get_field_from_name_pattern);
            take("il2cpp_class_get_method_from_name", class_get_method_from_name_pattern);
            take("il2cpp_domain_get", domain_get_pattern);
            take("il2cpp_field_static_get_value", field_static_get_value_pattern);
            take("il2cpp_field_static_set_value", field_static_set_value_pattern);
            take("il2cpp_type_get_object", type_get_object_pattern);
        }

        if (!il2cpp_class_from_name)
            il2cpp_class_from_name = resolve_pattern_with_retry(class_from_name_pattern);
        if (!il2cpp_class_get_nested_types)
            il2cpp_class_get_nested_types = resolve_pattern_with_retry(class_get_nested_types_pattern);
        if (!il2cpp_class_get_field_from_name)
            il2cpp_class_get_field_from_name = resolve_pattern_with_retry(class_get_field_from_name_pattern);
        if (!il2cpp_class_get_method_from_name)
            il2cpp_class_get_method_from_name = resolve_pattern_with_retry(class_get_method_from_name_pattern);

        if (!il2cpp_domain_get)
        {
            il2cpp_domain_get = resolve_export_body("il2cpp_domain_get");
            if (!il2cpp_domain_get)
                il2cpp_domain_get = resolve_pattern_with_retry(domain_get_pattern);
        }
        if (!il2cpp_field_static_get_value)
            il2cpp_field_static_get_value = resolve_pattern_with_retry(field_static_get_value_pattern);
        if (!il2cpp_field_static_set_value)
            il2cpp_field_static_set_value = resolve_pattern_with_retry(field_static_set_value_pattern);
        if (!il2cpp_type_get_object)
        {
            il2cpp_type_get_object = resolve_export_body("il2cpp_type_get_object");
            if (!il2cpp_type_get_object)
                il2cpp_type_get_object = resolve_pattern_with_retry(type_get_object_pattern);
        }

        if (!il2cpp_domain_get_assemblies)
            il2cpp_domain_get_assemblies = resolve_export_body("il2cpp_domain_get_assemblies");
        if (!il2cpp_string_new)
            il2cpp_string_new = resolve_export_body("il2cpp_string_new");
        if (!il2cpp_field_get_value_object)
            il2cpp_field_get_value_object = resolve_export_body("il2cpp_field_get_value_object");
        if (!il2cpp_array_new)
            il2cpp_array_new = resolve_export_body("il2cpp_array_new");
        if (!il2cpp_object_new)
            il2cpp_object_new = resolve_export_body("il2cpp_object_new");
        if (!il2cpp_runtime_class_init)
            il2cpp_runtime_class_init = resolve_export_body("il2cpp_runtime_class_init");

        const uintptr_t base = reinterpret_cast<uintptr_t>(module_base);
        struct
        {
            const char* name;
            PVOID ptr;
        } entries[] = {
            {"il2cpp_class_from_name", il2cpp_class_from_name},
            {"il2cpp_class_get_nested_types", il2cpp_class_get_nested_types},
            {"il2cpp_class_get_field_from_name", il2cpp_class_get_field_from_name},
            {"il2cpp_class_get_method_from_name", il2cpp_class_get_method_from_name},
            {"il2cpp_domain_get", il2cpp_domain_get},
            {"il2cpp_domain_get_assemblies", il2cpp_domain_get_assemblies},
            {"il2cpp_field_static_get_value", il2cpp_field_static_get_value},
            {"il2cpp_field_static_set_value", il2cpp_field_static_set_value},
            {"il2cpp_field_get_value_object", il2cpp_field_get_value_object},
            {"il2cpp_string_new", il2cpp_string_new},
            {"il2cpp_type_get_object", il2cpp_type_get_object},
            {"il2cpp_array_new", il2cpp_array_new},
            {"il2cpp_object_new", il2cpp_object_new},
            {"il2cpp_runtime_class_init", il2cpp_runtime_class_init},
        };

        bool any_null = false;
        for (const auto& e : entries)
        {
            if (!e.ptr)
            {
                logger::warn(std::string("IL2CPP resolve FAILED (null): ") + e.name);
                any_null = true;
                continue;
            }
            const uintptr_t offset = reinterpret_cast<uintptr_t>(e.ptr) - base;
            const auto* b = reinterpret_cast<const uint8_t*>(e.ptr);
            char buf[160];
            std::snprintf(buf, sizeof(buf),
                "%s  +0x%llX  %02X %02X %02X %02X %02X %02X %02X %02X",
                e.name, static_cast<unsigned long long>(offset),
                b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7]);
            logger::info(buf);
        }

        // Do not call Unity or install hooks with a partial API table. Continuing
        // here turns a bad update/configuration into a process crash.
        if (any_null)
        {
            logger::error("IL2CPP API incomplete; mod startup will stop safely");
            return false;
        }

        // any_null is necessarily false here: the block above already returned
        // when it was set, so this is the only reachable outcome. The previous
        // `if (any_null) ... else ...` pair was dead in its true branch, which
        // left a second, misleading "IL2CPP API incomplete" string compiled into
        // the binary that could never be printed.
        logger::info("Il2CPP API Loaded");
        return true;
    }
} // namespace il2cpp_offsets
