#include "common.h"
#include "Il2CppObjectInstance.h"

/**
     * Should be used in most cases, automatically sets the class
     * @param instance object instance
     */
Il2CppObjectInstance::Il2CppObjectInstance(Il2CppObject* instance) {
    this->clazz_ = instance ? instance->klass : nullptr;
    this->instance_ = instance;
}

Il2CppObjectInstance::Il2CppObjectInstance(const Il2CppClass* clazz, Il2CppObject* instance) {
    this->clazz_ = clazz;
    this->instance_ = instance;
}

Il2CppObjectInstance::Il2CppObjectInstance(const Il2CppImage* image, const char* namespaze, const char* name,
    Il2CppObject* instance) {
    clazz_ = il2utils::resolve_class(image, namespaze, name);
    instance_ = instance;
}

Il2CppObject* Il2CppObjectInstance::get_instance() const {
    return instance_;
}
