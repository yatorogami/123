#include "common.h"
#include "compatibility_profile.h"

#include <Psapi.h>

#include "../../external/nlohmann/json.hpp"
#include "../../shared/module_paths.h"

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <system_error>
#include <utility>

namespace compatibility_profile {
    namespace {
        using json = nlohmann::json;

        bool readable(const void* address, const size_t size) {
            if (!address || size == 0) return false;
            MEMORY_BASIC_INFORMATION memory{};
            if (VirtualQuery(address, &memory, sizeof(memory)) == 0) return false;
            if (memory.State != MEM_COMMIT) return false;

            const DWORD protect = memory.Protect & 0xFF;
            if (protect == PAGE_NOACCESS || (memory.Protect & PAGE_GUARD)) return false;

            const auto start = reinterpret_cast<uintptr_t>(address);
            const auto region_start = reinterpret_cast<uintptr_t>(memory.BaseAddress);
            const auto region_end = region_start + memory.RegionSize;
            return start >= region_start && size <= region_end - start;
        }

        bool read_module_identity(HMODULE module, ModuleIdentity& identity, std::string& detail) {
            MODULEINFO info{};
            if (!module || !GetModuleInformation(GetCurrentProcess(), module, &info, sizeof(info)) || !info.lpBaseOfDll) {
                detail = "GetModuleInformation failed";
                return false;
            }

            identity.size = info.SizeOfImage;
            const auto* base = reinterpret_cast<const uint8_t*>(info.lpBaseOfDll);
            if (!readable(base, sizeof(IMAGE_DOS_HEADER))) {
                detail = "module DOS header is not readable";
                return false;
            }

            const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
            if (dos->e_lfanew <= 0 || dos->e_lfanew > 1024 * 1024) {
                detail = "module has an invalid e_lfanew";
                return false;
            }

            const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
            if (!readable(nt, sizeof(IMAGE_NT_HEADERS))) {
                detail = "module NT header is not readable";
                return false;
            }
            if (nt->Signature != IMAGE_NT_SIGNATURE) {
                detail = "module NT signature is invalid";
                return false;
            }

            identity.pe_timestamp = nt->FileHeader.TimeDateStamp;
            return true;
        }

        std::optional<uintptr_t> parse_number(const json& value) {
            if (value.is_null()) return std::nullopt;
            if (value.is_number_unsigned()) return static_cast<uintptr_t>(value.get<uint64_t>());
            if (!value.is_string()) return std::nullopt;

            const std::string text = value.get<std::string>();
            if (text.empty()) return std::nullopt;
            try {
                size_t consumed = 0;
                const auto parsed = std::stoull(text, &consumed, 0);
                if (consumed != text.size()) return std::nullopt;
                return static_cast<uintptr_t>(parsed);
            } catch (...) {
                return std::nullopt;
            }
        }

        std::string read_text_file(const std::filesystem::path& path) {
            std::ifstream stream(path, std::ios::binary);
            if (!stream) return {};
            std::ostringstream contents;
            contents << stream.rdbuf();
            return contents.str();
        }

        std::vector<std::filesystem::path> find_manifests(const std::filesystem::path& root) {
            std::vector<std::filesystem::path> result;
            std::error_code error;
            if (!std::filesystem::exists(root, error)) return result;

            if (std::filesystem::is_regular_file(root, error)) {
                if (root.filename() == L"manifest.json") result.push_back(root);
                return result;
            }

            std::filesystem::recursive_directory_iterator iterator(
                root,
                std::filesystem::directory_options::skip_permission_denied,
                error);
            const std::filesystem::recursive_directory_iterator end;
            while (!error && iterator != end) {
                const auto& path = iterator->path();
                std::error_code type_error;
                if (std::filesystem::is_regular_file(path, type_error)
                    && path.filename() == L"manifest.json") {
                    result.push_back(path);
                }
                iterator.increment(error);
            }
            std::sort(result.begin(), result.end());
            return result;
        }

        int status_priority(const std::string& status) {
            if (status == "verified") return 3;
            if (status == "validated") return 2;
            if (status == "staged") return 1;
            return 0;
        }

        bool parse_symbols(const json& root, Profile& profile, std::string& detail) {
            if (!root.contains("symbols") || !root["symbols"].is_array()) {
                detail = "manifest symbols must be an array";
                return false;
            }

            for (const auto& item : root["symbols"]) {
                if (!item.is_object() || !item.contains("name") || !item["name"].is_string()) {
                    detail = "manifest contains a symbol without a name";
                    return false;
                }

                Symbol symbol;
                symbol.name = item["name"].get<std::string>();
                symbol.module = item.value("module", std::string{});
                symbol.resolver = item.value("resolver", std::string("native"));
                symbol.required = item.value("required", false);
                if (item.contains("expected_matches"))
                {
                    if (!item["expected_matches"].is_number_unsigned()) {
                        detail = "expected_matches must be an integer for symbol " + symbol.name;
                        return false;
                    }
                    symbol.expected_matches = item["expected_matches"].get<std::size_t>();
                    if (symbol.expected_matches == 0) {
                        detail = "expected_matches must be >= 1 for symbol " + symbol.name;
                        return false;
                    }
                }

                if (item.contains("export_name") && item["export_name"].is_string()) {
                    symbol.export_name = item["export_name"].get<std::string>();
                }
                if (item.contains("rva")) {
                    symbol.rva = parse_number(item["rva"]);
                    if (!symbol.rva && !item["rva"].is_null()) {
                        detail = "invalid RVA for symbol " + symbol.name;
                        return false;
                    }
                }
                if (item.contains("patterns")) {
                    if (!item["patterns"].is_array()) {
                        detail = "patterns must be an array for symbol " + symbol.name;
                        return false;
                    }
                    for (const auto& pattern : item["patterns"]) {
                        if (!pattern.is_string() || pattern.get<std::string>().empty()) {
                            detail = "invalid pattern for symbol " + symbol.name;
                            return false;
                        }
                        symbol.patterns.push_back(pattern.get<std::string>());
                    }
                }
                if (item.contains("resolution_order")) {
                    if (!item["resolution_order"].is_array()) {
                        detail = "resolution_order must be an array for symbol " + symbol.name;
                        return false;
                    }
                    for (const auto& step : item["resolution_order"]) {
                        if (!step.is_string()) {
                            detail = "invalid resolution step for symbol " + symbol.name;
                            return false;
                        }
                        symbol.resolution_order.push_back(step.get<std::string>());
                    }
                }

                if (!profile.add_symbol(std::move(symbol), detail)) {
                    detail = "duplicate symbol " + detail;
                    return false;
                }
            }
            return true;
        }

        bool parse_manifest(
            const std::filesystem::path& path,
            const ModuleIdentity& identity,
            Profile& profile,
            int& priority,
            std::string& detail) {
            const std::string text = read_text_file(path);
            if (text.empty()) {
                detail = "manifest is empty or unreadable: " + path.string();
                return false;
            }

            try {
                json root = json::parse(text);
                if (!root.is_object() || root.value("schema_version", 0) != 1) {
                    detail = "unsupported manifest schema in " + path.string();
                    return false;
                }
                if (!root.contains("profile") || !root["profile"].is_object()) {
                    detail = "manifest profile is missing: " + path.string();
                    return false;
                }
                const auto& profile_json = root["profile"];
                const std::string architecture = profile_json.value("architecture", "x64");
                const std::string status = profile_json.value("status", "unverified");
                if (architecture != "x64") {
                    detail = "profile architecture is not x64: " + path.string();
                    return false;
                }
                if (status_priority(status) == 0) {
                    detail = "profile is not approved for runtime use: " + path.string();
                    return false;
                }

                if (!root.contains("modules") || !root["modules"].is_object()
                    || !root["modules"].contains("GameAssembly.dll")) {
                    detail = "profile has no GameAssembly.dll identity: " + path.string();
                    return false;
                }

                // A manifest is a candidate when the supplied identity matches any
                // declared module. The main DLL passes the GameAssembly identity;
                // the launcher passes a UnityPlayer dump taken while the game is
                // suspended, before GameAssembly is loaded.
                bool identity_matches = false;
                for (const auto& [module_name, module_json] : root["modules"].items()) {
                    (void)module_name;
                    if (!module_json.is_object() || !module_json.contains("size")
                        || !module_json["size"].is_number_unsigned()
                        || !module_json.contains("pe_timestamp")) {
                        continue;
                    }
                    if (module_json["size"].get<uint64_t>() != identity.size) continue;
                    const auto module_timestamp = parse_number(module_json["pe_timestamp"]);
                    if (!module_timestamp || static_cast<DWORD>(*module_timestamp) != identity.pe_timestamp) continue;
                    identity_matches = true;
                    break;
                }
                if (!identity_matches) return false;

                profile.reset();

                // Retain every declared module identity for external consumers
                // (the launcher verifies later module dumps against them).
                for (const auto& [module_name, module_json] : root["modules"].items()) {
                    if (!module_json.is_object() || !module_json.contains("size")
                        || !module_json["size"].is_number_unsigned()
                        || !module_json.contains("pe_timestamp")) {
                        continue;
                    }
                    const auto module_timestamp = parse_number(module_json["pe_timestamp"]);
                    if (!module_timestamp) continue;
                    ModuleIdentity module_identity{};
                    module_identity.size = static_cast<DWORD>(module_json["size"].get<uint64_t>());
                    module_identity.pe_timestamp = static_cast<DWORD>(*module_timestamp);
                    profile.add_module_identity(module_name, module_identity);
                }

                profile.set_metadata(
                    profile_json.value("id", path.stem().string()),
                    profile_json.value("game_version", "unknown"),
                    status,
                    path.string());
                if (!parse_symbols(root, profile, detail)) {
                    profile.reset();
                    return false;
                }

                static constexpr const char* required_il2cpp_symbols[] = {
                    "il2cpp_class_from_name",
                    "il2cpp_class_get_nested_types",
                    "il2cpp_class_get_field_from_name",
                    "il2cpp_class_get_method_from_name",
                    "il2cpp_domain_get",
                    "il2cpp_domain_get_assemblies",
                    "il2cpp_field_static_get_value",
                    "il2cpp_field_static_set_value",
                    "il2cpp_field_get_value_object",
                    "il2cpp_string_new",
                    "il2cpp_type_get_object",
                    "il2cpp_array_new",
                    "il2cpp_object_new",
                    "il2cpp_runtime_class_init",
                };
                for (const char* required_name : required_il2cpp_symbols)
                {
                    const Symbol* symbol = profile.find(required_name);
                    if (!symbol || !symbol->required || symbol->module != "GameAssembly.dll") {
                        detail = std::string("profile is missing required GameAssembly symbol: ") + required_name;
                        profile.reset();
                        return false;
                    }
                    if (symbol->resolver != "native" && symbol->resolver != "pattern" && symbol->resolver != "export") {
                        detail = std::string("unsupported resolver for required symbol: ") + required_name;
                        profile.reset();
                        return false;
                    }
                    if (symbol->resolver == "pattern"
                        && (symbol->patterns.empty() || symbol->expected_matches != 1)) {
                        detail = std::string("runtime pattern must have one expected match: ") + required_name;
                        profile.reset();
                        return false;
                    }
                    if (symbol->resolver == "native" && !symbol->rva && symbol->patterns.empty()) {
                        detail = std::string("required native symbol has no RVA or pattern: ") + required_name;
                        profile.reset();
                        return false;
                    }
                }

                priority = status_priority(status);
                return true;
            } catch (const std::exception& exception) {
                profile.reset();
                detail = "could not decode manifest " + path.string() + ": " + exception.what();
                return false;
            }
        }
    } // namespace

    void Profile::reset() {
        loaded_ = false;
        id_.clear();
        game_version_.clear();
        status_.clear();
        path_.clear();
        symbols_.clear();
        modules_.clear();
    }

    void Profile::set_metadata(
        std::string id,
        std::string game_version,
        std::string status,
        std::string path) {
        loaded_ = true;
        id_ = std::move(id);
        game_version_ = std::move(game_version);
        status_ = std::move(status);
        path_ = std::move(path);
    }

    bool Profile::add_symbol(Symbol symbol, std::string& duplicate_name) {
        const auto [iterator, inserted] = symbols_.emplace(symbol.name, std::move(symbol));
        if (inserted) return true;
        duplicate_name = iterator->first;
        return false;
    }

    const Symbol* Profile::find(const std::string_view name) const {
        const auto iterator = symbols_.find(std::string(name));
        return iterator == symbols_.end() ? nullptr : &iterator->second;
    }

    const ModuleIdentity* Profile::module_identity(const std::string& module) const {
        const auto iterator = modules_.find(module);
        return iterator == modules_.end() ? nullptr : &iterator->second;
    }

    void Profile::add_module_identity(std::string module, ModuleIdentity identity) {
        modules_.emplace(std::move(module), identity);
    }

    LoadResult Profile::load_for_module(HMODULE module, Profile& output, std::string& detail) {
        output.reset();
        detail.clear();

        ModuleIdentity identity{};
        if (!read_module_identity(module, identity, detail)) return LoadResult::Invalid;

        // The manifest ships under the data directory, which is <dll dir>/ta/ when
        // that exists and <dll dir> otherwise. Hardcoding <dll dir>/compatibility
        // here is what made this path dead in every build since the Content item's
        // <Link> moved under ta\ (TarkovAddons.vcxproj): a valid manifest was
        // deployed, in ta/compatibility/profiles, and this line read
        // <dll dir>/compatibility/profiles -- a directory nothing creates. The
        // result was LoadResult::NotFound on every launch, which is the *designed*
        // legacy fallback, so nothing logged an error and the profile has never
        // once been loaded.
        //
        // data_directory_wide() is the same accessor the launcher process already
        // uses for exactly this lookup, so both DLLs now resolve one root.
        const auto profile_root = module_paths::data_directory_wide();
        if (profile_root.empty()) {
            detail = "could not determine the TarkovAddons.dll directory";
            return LoadResult::Invalid;
        }

        return load_for_identity(identity, profile_root / L"compatibility" / L"profiles", output, detail);
    }

    LoadResult Profile::load_for_identity(
        const ModuleIdentity& identity,
        const std::filesystem::path& profile_root,
        Profile& output,
        std::string& detail) {
        output.reset();
        detail.clear();

        auto manifests = find_manifests(profile_root);
        std::sort(manifests.begin(), manifests.end());
        manifests.erase(std::unique(manifests.begin(), manifests.end()), manifests.end());
        if (manifests.empty()) {
            detail = "no compatibility manifest directory found";
            return LoadResult::NotFound;
        }

        bool saw_manifest = false;
        bool saw_invalid = false;
        int best_priority = 0;
        Profile best;
        std::string best_path;
        for (const auto& path : manifests) {
            saw_manifest = true;
            int priority = 0;
            std::string parse_detail;
            Profile candidate;
            if (!parse_manifest(path, identity, candidate, priority, parse_detail)) {
                // A size/timestamp mismatch is an expected candidate miss. Other
                // parse failures are reported if no usable profile is found.
                if (!parse_detail.empty() && parse_detail.find("profile has no") == std::string::npos
                    && parse_detail.find("unsupported") == std::string::npos) {
                    saw_invalid = true;
                }
                continue;
            }
            if (priority > best_priority) {
                best_priority = priority;
                best = std::move(candidate);
                best_path = path.string();
            } else if (priority == best_priority && best.loaded() && best_path != path.string()) {
                detail = "multiple compatibility profiles match the current module";
                return LoadResult::Invalid;
            }
        }

        if (!best.loaded()) {
            detail = saw_invalid
                ? "compatibility manifests were invalid or did not match the module identity"
                : "compatibility manifests were found, but none match the module identity";
            return saw_invalid ? LoadResult::Invalid : (saw_manifest ? LoadResult::Mismatch : LoadResult::NotFound);
        }

        output = std::move(best);
        detail = output.id() + " (" + output.game_version() + ") from " + output.path();
        return LoadResult::Loaded;
    }
} // namespace compatibility_profile
