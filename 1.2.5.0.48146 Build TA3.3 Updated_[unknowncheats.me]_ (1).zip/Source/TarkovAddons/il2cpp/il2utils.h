#pragma once
#include <iostream>
#include <sstream>
#include <unordered_map>
#include <utility>
#include <vector>
#include <mutex>
#include <Windows.h>

#include "exports.h"
#include "meta_key.h"
#include "../../external/safetyhook/safetyhook.hpp"
#include "../util/logger.h"
#include "../util/tracy_bridge.h"
#include "../util/utils.h"
#include <cstring>  // std::strstr (is_state_machine_class_name)
#include <type_traits>  // std::is_pointer_v (hook_method's trampoline-slot check)

namespace il2utils {
    // ---- metadata memo -------------------------------------------------------
    //
    // IL2CPP metadata is immutable for the life of the process: the assembly list,
    // the type table and every FieldInfo are fixed once the runtime initialises.
    // That makes these lookups safe to memoise -- and they are genuinely hot.
    //
    // optics::lens::acquire_packet runs up to 250x/second (the 4 ms throttle in
    // eft_api::optic_lens_ensure_frame) and calls, per invocation:
    //   resolve_image("Assembly-CSharp.dll")  -> linear scan of every assembly,
    //       constructing a std::string per image name
    //   resolve_class(..., "CameraManager")   -> il2cpp_class_from_name, a linear
    //       scan of the type table (tens of thousands of entries in Assembly-CSharp)
    // Neither had any caching, so the newly-accepted optic route (pipeline=valid,
    // 2026-09-26) put an O(n) string-compare walk onto a per-frame path for the
    // first time. That is the likeliest cause of the observed FPS collapse -- NOT
    // the double-precision work in build_affine_map, which runs once per optic
    // change behind the cached route, as the single "optic-route: accepted" line
    // in the same log confirms.
    //
    // Only SUCCESSES are cached. A failure can be a "not initialised yet" state
    // that would resolve later, and caching that would turn it into a permanent
    // failure -- the same trap already fixed in the localization caches.
    //
    // The lock is uncontended in steady state and costs ~20 ns; it replaces a walk
    // of tens of thousands of strcmps, so it is not what is being optimised here.
    inline std::mutex& metadata_cache_mutex() {
        static std::mutex m;
        return m;
    }

    // A SEPARATE lock for the method memo, and the reason is measured rather than
    // stylistic. resolve_method is called 7.2 MILLION times in the 2026-10-01
    // current+2 capture (il2utils.h zone, mean 201 ns -- that mean IS the lock plus the
    // key construction). resolve_field, resolve_image and resolve_class all take
    // metadata_cache_mutex, and the optic path calls resolve_image + resolve_class
    // ~514,000 times each from the RENDER thread while the game thread hammers
    // resolve_method. One shared non-recursive mutex for four caches means any one of
    // them stalls the other three.
    //
    // The cost when these two shared a lock, same session:
    //
    //   frame::EspModule::draw_overlay   11.94 s -> 27.06 s   (2.27x worse)
    //   optics::lens::range_readable      7.79 s -> 29.38 s   (3.77x worse)
    //   frame::EspModule::gameworld_update 39.37 s -> 16.85 s  (0.43x, the bone fix)
    //
    // The optic-perf line moved 1604 -> 5341 us/call with range vq 4.0 -> 9.7 per call
    // over the same window, which is the signature of a thread losing time to lock
    // contention and then missing its memo more often. Four independent caches, four
    // independent locks: a slow one can only stall itself.
    inline std::mutex& method_cache_mutex() {
        static std::mutex m;
        return m;
    }

    // The two memos, behind accessors so resolve_field and resolve_method can
    // name a cache without each declaring its own `static` local. That matters
    // because a function-local static in an inline function is fine, but two
    // separate maps would mean two lookups to keep in step with each other in
    // review; one accessor each keeps the key type and the map adjacent.
    //
    // Both are keyed on detail::MetaKey, which is a VALUE -- see
    // il2cpp/meta_key.h for why the name is stored by content.
    inline std::unordered_map<detail::MetaKey, FieldInfo*, detail::MetaKeyHash>& field_cache() {
        static std::unordered_map<detail::MetaKey, FieldInfo*, detail::MetaKeyHash> c;
        return c;
    }

    inline std::unordered_map<detail::MetaKey, const MethodInfo*, detail::MetaKeyHash>& method_cache() {
        static std::unordered_map<detail::MetaKey, const MethodInfo*, detail::MetaKeyHash> c;
        return c;
    }

    inline Il2CppImage* resolve_image(const char* name) {
        // The three resolvers below are the ones worth measuring. This header's own
        // FPS-collapse note says the unmemoised forms were "the likeliest cause of
        // the observed FPS collapse", all three were memoised on 2026-10-01, and
        // until now there was no way to check whether that helped -- it was argued
        // from the source. These three zones are how you check it: profile with a
        // client attached, read the aggregate for each, and the memo is confirmed
        // or refuted by number rather than by argument.
        TA_ZONE_N("il2utils::resolve_image");
        static std::unordered_map<std::string, Il2CppImage*> cache;
        {
            std::lock_guard<std::mutex> lock(metadata_cache_mutex());
            if (const auto it = cache.find(name); it != cache.end())
                return it->second;
        }
        Il2CppDomain* domain = il2cpp::il2cpp_domain_get();
        size_t assemblies_size = 0;
        const Il2CppAssembly** assemblies = il2cpp::il2cpp_domain_get_assemblies(domain, &assemblies_size);
        for (size_t i = 0; i < assemblies_size; ++i)
        {
            Il2CppImage* image = assemblies[i]->image;
            if (std::string(image->name) == std::string(name))
            {
                std::lock_guard<std::mutex> lock(metadata_cache_mutex());
                cache.emplace(name, image);
                return image;
            }
        }

        logger::warn(std::string("resolve_image FAILED: ") + name);
        return nullptr;
    }

    inline const Il2CppClass* resolve_class_nested(const Il2CppClass* parent, const char* name) {
        if (!parent)
        {
            logger::warn(std::string("resolve_class_nested FAILED (null parent): ") + name);
            return nullptr;
        }
        void* iter = nullptr;
        Il2CppClass* nested = nullptr;
        while ((nested = il2cpp::il2cpp_class_get_nested_types(const_cast<Il2CppClass*>(parent), &iter)) != nullptr)
        {
            if (nested->name && strcmp(nested->name, name) == 0)
            {
                return nested;
            }
        }
        logger::warn(std::string("resolve_class_nested FAILED: ") + (parent->name ? parent->name : "?") + "::" + name);
        return nullptr;
    }

    inline const Il2CppClass* resolve_class(const Il2CppImage* image, const char* namespaze, const char* name) {
        TA_ZONE_N("il2utils::resolve_class");
        if (!image)
        {
            logger::warn(std::string("resolve_class FAILED (null image): ") + namespaze + "." + name);
            return nullptr;
        }
        // See the metadata memo note above. il2cpp_class_from_name is a linear scan
        // of the image's type table, which is the single most expensive resolver in
        // this header.
        static std::unordered_map<std::string, const Il2CppClass*> cache;
        const std::string key = std::string(namespaze) + "." + name + "@" +
            std::to_string(reinterpret_cast<uintptr_t>(image));
        {
            std::lock_guard<std::mutex> lock(metadata_cache_mutex());
            if (const auto it = cache.find(key); it != cache.end())
                return it->second;
        }
        const Il2CppClass* cls = il2cpp::il2cpp_class_from_name(image, namespaze, name);
        if (cls)
        {
            std::lock_guard<std::mutex> lock(metadata_cache_mutex());
            cache.emplace(key, cls);
        }
        return cls;
    }

    // See the metadata memo note above. il2cpp_class_get_field_from_name is a
    // string-compare scan of the class's field table, and resolve_field walks the
    // inheritance chain doing that once per class -- so a field declared on a base
    // type costs a scan of every class from the leaf up to it. That put an
    // unmemoised O(fields x depth) walk on a PER-FRAME path at
    // common_hooks.cpp:96 (hk_tarkov_application_update), and there are 138 call
    // sites for this function.
    //
    // resolve_image and resolve_class were memoised for exactly this reason (see
    // the note above, and the FPS-collapse note in it) and resolve_field was
    // missed. WorldModule.cpp:509-513 was already hand-rolling the same idea with
    // a `memory_field_resolved` bool, which is the precedent for doing it once
    // here instead of 138 times.
    //
    // Only SUCCESSES are cached, for the reason given above: a miss can be a
    // "not initialised yet" state that would resolve later.
    //
    // The key is il2utils::detail::MetaKey, which copies the name's CONTENT and
    // allocates nothing. It replaced a std::string built from two to_string
    // calls plus a concatenation on every one of the 14,022,703 calls measured
    // on 2026-10-09; see il2cpp/meta_key.h for why the name must not be keyed
    // by pointer, and for the live .c_str() call site that proves it.
    inline FieldInfo* resolve_field(const Il2CppClass* clazz, const char* name) {
        TA_ZONE_N("il2utils::resolve_field");
        if (!clazz || !name)
            return nullptr;

        // Key on the class we STARTED from, not the one the field was found on.
        // The answer depends on where the walk began: the same field name can
        // resolve from a leaf to one FieldInfo and from a base to another, or not
        // resolve at all from a sibling.
        detail::MetaKey key;
        const bool memoisable = key.assign(clazz, 0, name);

        if (memoisable) {
            std::lock_guard<std::mutex> lock(metadata_cache_mutex());
            if (const auto it = field_cache().find(key); it != field_cache().end())
                return it->second;
        }

        // Walk inheritance: ConditionVisitPlace.target lives on ConditionOneTarget,
        // not the leaf class.
        for (const Il2CppClass* current = clazz; current; current = current->parent)
        {
            if (FieldInfo* field = il2cpp::il2cpp_class_get_field_from_name(
                    const_cast<Il2CppClass*>(current), name))
            {
                // Re-reads nothing; the key is a value, so emplacing it is safe
                // even though `field` was found on a base class.
                if (memoisable) {
                    std::lock_guard<std::mutex> lock(metadata_cache_mutex());
                    field_cache().emplace(key, field);
                }
                return field;
            }
        }
        return nullptr;
    }

    // Same argument as resolve_field above, applied to methods, and it was the last of
    // the three resolvers left unmemoised. il2cpp_class_get_method_from_name is a
    // string-compare scan of the class's method table, and the ESP skeleton path called
    // it through here on a per-frame basis: esp_bones::get_player_body asks for
    // "get_PlayerBody" and get_bifacial_pos asks for "get_position", both of which are
    // reached roughly 20x per player per tick (once per bone link, and the box-visibility
    // path rebuilds the whole bone map a second time -- see EspModule.cpp:5253-5254 and
    // :5273-5274). A managed MethodInfo's methodPointer is fixed for the process
    // lifetime, exactly as the FieldInfo offsets above are.
    //
    // Keyed on (class, name, arg_count) INCLUDING the arity, which resolve_field does not
    // need. "get_position" and similar names are overloaded across arity in IL2CPP, and
    // a key that omitted arg_count would hand one overload's pointer to a caller that
    // asked for another -- a crash, not a stale value.
    //
    // Only successes are cached, for the reason given above: a miss can be a
    // "not initialised yet" state that would resolve later.
    //
    // Allocation-free key, as in resolve_field. This is the larger of the two by
    // call count: 22,114,149 calls / 4.916 s measured 2026-10-09, all hits.
    inline const MethodInfo* resolve_method(const Il2CppClass* clazz, const char* name, int arg_count) {
        TA_ZONE_N("il2utils::resolve_method");
        if (!clazz || !name)
            return nullptr;

        detail::MetaKey key;
        const bool memoisable = key.assign(clazz, arg_count, name);

        if (memoisable) {
            // method_cache_mutex, NOT metadata_cache_mutex -- see the note on it.
            std::lock_guard<std::mutex> lock(method_cache_mutex());
            if (const auto it = method_cache().find(key); it != method_cache().end())
                return it->second;
        }

        const MethodInfo* m = il2cpp::il2cpp_class_get_method_from_name(
            const_cast<Il2CppClass*>(clazz), name, arg_count);
        if (m && memoisable)
        {
            std::lock_guard<std::mutex> lock(method_cache_mutex());
            method_cache().emplace(key, m);
        }
        return m;
    }

    // set_static_field() was removed here: it had no callers anywhere in either
    // project. It also had no null check on the FieldInfo that resolve_field()
    // returns, so a renamed field would have been written through a null
    // pointer. get_static_field() below is the same hazard and is now tri-state.

    // The result of a static-field read. Tri-state, and NAMED rather than
    // std::optional, because the failure this guards is a game update renaming a
    // field -- and for T = bool the two non-present states must not collapse into
    // "false".
    //
    // std::optional<bool> was rejected deliberately: `if (opt)` tests has_value,
    // not the contained value, so `if (opt)` meaning "the field is true" is a
    // silent, plausible mistake. This file has already produced three variants of
    // that bug -- `InfoDrawValue`'s shared default id, the -1 sentinel in
    // eft_api.h's packet_consistent, and SelectValue's clamp -- so the reply
    // spells its states out.
    template <typename T>
    struct StaticField {
        enum class State : unsigned char {
            Present,      // resolved, and .value holds the field's value
            FieldMissing, // the field does not exist on this build
            NoClass,      // the caller passed no class, so nothing could be looked up
        };

        State state = State::NoClass;
        T value{};

        bool present() const { return state == State::Present; }
        explicit operator bool() const { return present(); }

        // What a caller should do when the field is not there. Deliberately not a
        // silent default: see the note at the two call sites, where the correct
        // action differs (keep the last known value vs abandon the operation).
        bool usable() const { return present(); }
    };

    // A one-shot warn per (class, field), so a missing field on a per-frame path
    // cannot turn into 60 file writes a second. Without this the null check would
    // be free and the logging would not be -- logger::warn writes and flushes.
    inline void warn_static_field_once(const char* clazz_name, const char* field,
        const char* why) {
        static std::mutex m;
        static std::unordered_map<std::string, bool> already_warned;
        const std::string key = std::string(clazz_name ? clazz_name : "?")
            + "::" + (field ? field : "?") + "::" + why;
        {
            std::lock_guard<std::mutex> lock(m);
            if (already_warned.count(key))
                return;
            already_warned.emplace(key, true);
        }
        logger::warn(std::string("get_static_field: ") + why + " for "
            + (clazz_name ? clazz_name : "?") + "::" + (field ? field : "?")
            + " -- this is a game update renaming it; the mod will keep working,"
            " but whatever read it will not. Reported once.");
    }

    template <typename T>
    StaticField<T> get_static_field(const Il2CppClass* clazz, const char* name) {
        StaticField<T> out;
        if (!clazz) {
            out.state = StaticField<T>::State::NoClass;
            return out;
        }
        FieldInfo* field = resolve_field(clazz, name);
        if (!field) {
            out.state = StaticField<T>::State::FieldMissing;
            warn_static_field_once(clazz->name, name, "field not found");
            return out;
        }
        // Value-initialised before the call. The previous `T value;` was default-
        // INITIALISED, so for T = Il2CppObject* it was an indeterminate pointer,
        // and a failed read handed that straight to a game method.
        T value{};
        il2cpp::il2cpp_field_static_get_value(field, static_cast<PVOID>(&value));
        out.state = StaticField<T>::State::Present;
        out.value = value;
        return out;
    }

    // Every managed method's native signature ends in a hidden trailing
    // MethodInfo* (the `const MethodInfo* method` parameter of the il2cpp-
    // generated C). Game callers always supply it. A caller that omits it
    // leaves that register/stack slot as a leftover, and any callee that is --
    // or tail-reaches, e.g. through BSG's tracked-store barrier -- a
    // shared-generic wrapper dereferences the leftover as its own MethodInfo*.
    // Crash of 2026-10-08: call through a bare methodPointer into
    // BotGroupEnemyInfo::.ctor; the ctor's tracked _botGroup store landed in
    // Dictionary<object,object>::Add's wrapper, which read garbage r9
    // ([r9+0x20]=0x1C) and AV'd reading 0xDC. The checked wrappers in
    // Il2CppObjectInstance.h build the call type through this trait so the
    // resolved MethodInfo* is always the last argument.
    template <typename T> struct with_methodinfo;
    template <typename Ret, typename... A>
    struct with_methodinfo<Ret(*)(A...)> {
        using type = Ret(*)(A..., const MethodInfo*);
    };
    template <typename T>
    using with_methodinfo_t = typename with_methodinfo<T>::type;

    // log_fail=false for optional/legacy APIs that are expected to miss on some game versions.
    // allow_any_argc: when true (default), fall back to argc=-1. Disable for overloaded names
    // like ConditionProgressChecker.Test (0-arg vs object) — wrong arity crashes Unity.
    // mi_out: when non-null, receives the MethodInfo* the pointer was resolved from, so the
    // caller can pass it as the hidden trailing argument (see with_methodinfo). Untouched on
    // failure -- callers must zero-initialise it.
    template <typename T>
    T get_method(const Il2CppClass* clazz, const char* name, const int args,
        bool log_fail = true, bool allow_any_argc = true, const MethodInfo** mi_out = nullptr) {
        if (!clazz)
        {
            if (log_fail)
                logger::warn(std::string("get_method FAILED (null class): ") + name);
            return nullptr;
        }

        // Exact argc first, then optional -1 (any) — Unity overloads vary by version.
        const MethodInfo* method = resolve_method(clazz, name, args);
        if ((!method || !method->methodPointer) && allow_any_argc && args != -1)
            method = resolve_method(clazz, name, -1);

        if (!method || !method->methodPointer)
        {
            if (log_fail)
            {
                logger::warn(std::string("get_method FAILED: ")
                    + (clazz->name ? clazz->name : "?") + "::" + name
                    + " args=" + std::to_string(args));
            }
            return nullptr;
        }
        // Reject wrong overload when caller asked for exact argc (e.g. Test/0 vs Test/1).
        if (!allow_any_argc && args >= 0 && method->parameters_count != static_cast<uint8_t>(args))
            return nullptr;

        if (mi_out)
            *mi_out = method;
        return static_cast<T>(method->methodPointer); // NOLINT(clang-diagnostic-microsoft-cast)
    }

    // Registry of active inline hooks. Replaces the old detours hook_log so that
    // unhook_method can reset the exact InlineHook it created (safetyhook has no
    // global detach-by-target API, so we must keep the hook objects alive).
    namespace {
        struct ActiveHook
        {
            const void* target = nullptr; // Il2Cpp method being hooked
            void* hook = nullptr;         // hook / destination function
            void* original = nullptr;     // trampoline that resumes the original function
            SafetyHookInline hook_obj;    // owns the inline hook (auto-resets on destruction)
        };

        inline std::vector<ActiveHook> hook_registry;
        inline std::mutex hook_registry_mutex;

        // Locate a live hook matching a target method + destination. Returns hook_registry.end() if not found.
        // inline because this header may be included by several translation units.
        // Returns an iterator (not a pointer) so the caller can erase directly without comparing ActiveHook
        // structs, which have no operator== (the InlineHook member is not comparable).
        inline std::vector<ActiveHook>::iterator find_hook(const void* target, void* hook) {
            std::lock_guard<std::mutex> lock(hook_registry_mutex);
            for (auto it = hook_registry.begin(); it != hook_registry.end(); ++it)
            {
                if (it->target == target && it->hook == hook)
                    return it;
            }
            return hook_registry.end();
        }
    } // namespace

    // The last parameter is the ADDRESS of the caller's trampoline slot, and the `T2*` plus the
    // static_assert are what make that a compile-time fact instead of a convention to remember.
    //
    // This was a confirmed crash, not a style point. The body ends with
    //
    //     *reinterpret_cast<void**>(original) = trampoline;
    //
    // which dereferences it. Pass `&o_foo` and `original` is the caller's address, so the store
    // lands in the variable — intended. Pass a bare `o_foo` and `original` is the function
    // pointer's VALUE, which is nullptr on first install; the store then becomes a write to
    // address 0. reinterpret_cast<void*> of a function pointer is legal on x64 (same size and
    // alignment), so nothing warned at compile time and it faulted at runtime instead:
    // EXCEPTION_ACCESS_VIOLATION, write, 0x0 — see module/production_panel_probe.h.
    //
    // WHY `T2*` AND NOT `T2`. Deduction is what rejects the bare form, and the shapes differ:
    //
    //   parameter T2*     &o_foo : sig**  ->  T2 = sig*  -> is_pointer  -> ok
    //                      o_foo  : sig*   ->  T2 = sig   -> NOT pointer -> assert fires
    //
    //   parameter T2      &o_foo : sig**  ->  T2 = sig** -> is_pointer  -> ok
    //                      o_foo  : sig*   ->  T2 = sig*  -> is_pointer  -> ok  <-- DOES NOT CATCH IT
    //
    // With the parameter by value both arguments deduce to a pointer, so a static_assert on
    // is_pointer_v<T2> passes for the exact call that crashes. The extra `*` is what forces T2 to
    // be the pointee, and therefore what makes "did the caller write &?" observable to the
    // compiler. Verified by compiling both shapes against bare and & arguments; the by-value pair
    // compiles clean, the T2* pair rejects only the bare one.
    //
    // WHY NOT `T2&`. `&o_foo` is a prvalue, and a non-const lvalue reference cannot bind to it, so
    // taking the parameter by reference fails to compile at all 50 correct call sites in the tree.
    // That was tried and reverted; `T2*` binds the prvalue by value and has the discrimination.
    template <typename T, typename T2>
    void hook_method(const Il2CppClass* clazz, const char* name, const int args, T hook, T2* original) {
        static_assert(std::is_pointer_v<T2>,
            "hook_method: the trampoline slot must be passed as its ADDRESS, e.g. &o_foo. A bare "
            "function pointer is dereferenced here and writes through nullptr on first install.");
        const char* class_name = (clazz && clazz->name) ? clazz->name : "(null class)";
        if (!clazz)
        {
            logger::warn(std::string("hook_method FAILED (null class): ") + class_name + "::" + name);
            return;
        }
        const MethodInfo* method = resolve_method(clazz, name, args);
        if (!method)
        {
            logger::warn(std::string("hook_method FAILED (null method): ") + class_name + "::" + name);
            return;
        }
        if (!method->methodPointer)
        {
            logger::warn(std::string("hook_method FAILED (null methodPointer): ") + class_name + "::" + name);
            return;
        }

        auto created = safetyhook::InlineHook::create(method->methodPointer, hook);
        if (!created)
        {
            logger::warn(std::string("hook_method FAILED (inline hook): ") + class_name + "::" + name);
            return;
        }
        SafetyHookInline& hook_obj = created.value();

        // Capture the trampoline that resumes the original function before moving the InlineHook away.
        const uintptr_t trampoline = reinterpret_cast<uintptr_t>(hook_obj.original<T>());

        ActiveHook entry;
        entry.target = method->methodPointer;
        entry.hook = hook;
        entry.original = reinterpret_cast<void*>(trampoline);
        entry.hook_obj = std::move(hook_obj);
        {
            std::lock_guard<std::mutex> lock(hook_registry_mutex);
            hook_registry.push_back(std::move(entry));
        }

        // 'original' now points to the trampoline that resumes the original function.
        *reinterpret_cast<void**>(original) = reinterpret_cast<void*>(trampoline);
    }

    // Get vtable method pointer from an actual instance of the class.
    // In IL2CPP, the vtable is stored per-object, not in the class metadata.
    // Each Il2CppObject has a "klass" pointer and the vtable follows immediately after.
    // Layout: [Il2CppObject header (16 bytes: monitor + klass)] [vtable array]
    template <typename T>
    T get_vtable_method_from_instance(Il2CppObject* instance, size_t vtable_offset) {
        if (!instance || !instance->klass)
        {
            logger::warn("get_vtable_method_from_instance FAILED (null instance or klass)");
            return nullptr;
        }
        
        // VirtualInvokeData structure: { Il2CppMethodPointer methodPtr; const MethodInfo* method; }
        // On x64, this is 16 bytes total, with methodPtr at offset 0
        constexpr size_t VIRTUAL_INVOKE_DATA_SIZE = 16;
        size_t slot_index = vtable_offset / VIRTUAL_INVOKE_DATA_SIZE;
        
        // The vtable starts right after the Il2CppObject header
        // Il2CppObject is: { union { Il2CppMonitorData* monitor; void* synchronizer_data; }; Il2CppClass* klass; }
        // On x64: 8 bytes (monitor) + 8 bytes (klass) = 16 bytes header
        constexpr size_t OBJECT_HEADER_SIZE = 16;
        
        auto* vtable_array = reinterpret_cast<VirtualInvokeData*>(
            reinterpret_cast<uintptr_t>(instance) + OBJECT_HEADER_SIZE);
        
        if (!vtable_array)
        {
            logger::warn("get_vtable_method_from_instance FAILED (null vtable)");
            return nullptr;
        }
        
        VirtualInvokeData& slot = vtable_array[slot_index];
        Il2CppMethodPointer target_func = slot.methodPtr;
        
        if (!target_func)
        {
            logger::warn("get_vtable_method_from_instance FAILED (null methodPtr at slot " + 
                std::to_string(slot_index) + ")");
            return nullptr;
        }
        
        return reinterpret_cast<T>(target_func);
    }

    // Hook a virtual method by vtable slot offset using an instance to get the actual function pointer.
    template <typename T, typename T2>
    void hook_vtable_method_from_instance(Il2CppObject* instance, size_t vtable_offset, T hook, T2 original) {
        if (!instance)
        {
            logger::warn("hook_vtable_method_from_instance FAILED (null instance)");
            return;
        }
        
        const char* class_name = (instance->klass && instance->klass->name) ? instance->klass->name : "(unknown class)";
        
        Il2CppMethodPointer target_func = get_vtable_method_from_instance<Il2CppMethodPointer>(instance, vtable_offset);
        
        if (!target_func)
        {
            logger::warn(std::string("hook_vtable_method_from_instance FAILED: ") + class_name);
            return;
        }
        
        auto created = safetyhook::InlineHook::create(reinterpret_cast<void*>(target_func), hook);
        if (!created)
        {
            logger::warn(std::string("hook_vtable_method_from_instance FAILED (inline hook): ") + class_name + 
                " slot=" + std::to_string(vtable_offset));
            return;
        }
        SafetyHookInline& hook_obj = created.value();

        const uintptr_t trampoline = reinterpret_cast<uintptr_t>(hook_obj.original<T>());

        ActiveHook entry;
        entry.target = reinterpret_cast<const void*>(target_func);
        entry.hook = hook;
        entry.original = reinterpret_cast<void*>(trampoline);
        entry.hook_obj = std::move(hook_obj);
        {
            std::lock_guard<std::mutex> lock(hook_registry_mutex);
            hook_registry.push_back(std::move(entry));
        }

        *reinterpret_cast<void**>(original) = reinterpret_cast<void*>(trampoline);
    }


    template <typename T, typename T2>
    void unhook_method(const Il2CppClass* clazz, const char* name, const int args, T hook, T2 original) {
        if (!clazz || !original) return;
        const MethodInfo* method = resolve_method(clazz, name, args);
        if (!method || !method->methodPointer) return;

        auto it = find_hook(method->methodPointer, hook);
        if (it == hook_registry.end()) return;

        // Restoring the original is handled by the InlineHook destructor (auto-reset), which runs
        // synchronously when the entry is erased from the registry.
        std::lock_guard<std::mutex> lock(hook_registry_mutex);
        hook_registry.erase(it);
    }

    // Install/remove hook only when desired state changes (safe re-toggle).
    template <typename THook, typename TOrig>
    void set_method_hook(const Il2CppClass* clazz, const char* name, const int args,
        THook hook, TOrig* original, bool* installed, const bool want) {
        if (!installed) return;
        if (want == *installed) return;
        if (want)
        {
            *original = nullptr;
            hook_method(clazz, name, args, hook, original);
            *installed = (*original != nullptr);
        }
        else
        {
            if (*installed && *original)
                unhook_method(clazz, name, args, hook, original);
            *original = nullptr;
            *installed = false;
        }
    }


    // -----------------------------------------------------------------------
    // Compiler-generated state machines
    // -----------------------------------------------------------------------
    //
    // C# `async` methods and iterator methods (`yield return`) are both compiled into a nested
    // class named "<MethodName>d__<number>" whose MoveNext is where the body actually lives.
    // Three helpers here, split so the knowledge is stated once:
    //
    //   is_state_machine_class_name  — is this class a state machine at all
    //   find_state_machine_class     — given the DECLARING class, find its nested state machine
    //   resolve_state_machine_movenext — given a state machine class, get its MoveNext
    //
    // hook_async_method is now just find + resolve + hook. The iterator walker in
    // module/hideout_reflection.h uses is_state_machine_class_name and
    // resolve_state_machine_movenext, because it is handed an already-constructed state machine
    // object and only needs to drive it — it must NOT go through find_state_machine_class, which
    // searches a class's nested types and so cannot help when the class is already in hand.

    // True for a compiler-generated state machine class name ("<>OfTypeIterator>d__97`1",
    // "<>c__DisplayClass3_0"). Cheap string test, no metadata access, so it is safe to call on
    // any class name.
    inline bool is_state_machine_class_name(const char* name) {
        if (!name || name[0] != '<') return false;
        return std::strstr(name, ">d__") != nullptr;
    }

    // The state machine class for `method_name`, declared as a nested type of `owner`, or null.
    //
    // Requires `owner` to be class-initialised, because nestedTypes is populated during
    // initialisation — this function does that itself, and is safe to call on an already-live
    // class.
    inline const Il2CppClass* find_state_machine_class(const Il2CppClass* owner,
        const char* method_name) {
        if (!owner || !method_name) return nullptr;
        if (const MethodInfo* probe = resolve_method(owner, method_name, -1)) {
            if (!probe->methodPointer) return nullptr;
        } else {
            // The declaring method has to exist: without it there is nothing to be a state
            // machine FOR, and a loose name match could bind to an unrelated sibling.
            return nullptr;
        }

        // Initialize the class to ensure nestedTypes are populated
        il2cpp::il2cpp_runtime_class_init(const_cast<Il2CppClass*>(owner));
        if (!owner->nestedTypes || owner->nested_type_count == 0) return nullptr;

        // Pass 1, exact "<MethodName>d__": a loose substring would also match siblings
        // such as <RunCharacterSelectionFlow>d__ when hooking "Run".
        const std::string exact_name = std::string("<") + method_name + ">d__";
        for (uint16_t i = 0; i < owner->nested_type_count; i++) {
            Il2CppClass* nested = owner->nestedTypes[i];
            if (!nested || !nested->name) continue;
            if (std::string(nested->name).find(exact_name) != std::string::npos) return nested;
        }

        // Pass 2, fallback to the loose "<MethodName>...d__" substring.
        for (uint16_t i = 0; i < owner->nested_type_count; i++) {
            Il2CppClass* nested = owner->nestedTypes[i];
            if (!nested || !nested->name) continue;
            const std::string nested_name(nested->name);
            if (nested_name.find(method_name) != std::string::npos
                && is_state_machine_class_name(nested->name))
                return nested;
        }
        return nullptr;
    }

    // MoveNext for a class that is already known to be a state machine, or null.
    //
    // Class-initialises first: Il2CppClass.methods is populated by SetupMethods during
    // initialisation, so resolving against a class the runtime has not initialised silently
    // misses EVERY method on it. (That is a real failure mode, not a theoretical one — see
    // module/hideout_reflection.h, where GetEnumerator was missing from a class for exactly this
    // reason.)
    inline const MethodInfo* resolve_state_machine_movenext(const Il2CppClass* state_machine_class) {
        if (!is_state_machine_class_name(state_machine_class ? state_machine_class->name : nullptr))
            return nullptr;
        il2cpp::il2cpp_runtime_class_init(const_cast<Il2CppClass*>(state_machine_class));
        return resolve_method(state_machine_class, "MoveNext", 0);
    }

    // Hook async methods by targeting the MoveNext method on the generated state machine class.
    // Async methods in IL2CPP use a state machine pattern where the actual execution happens
    // in the MoveNext method of a nested class named like "<MethodName>d__XX".
    //
    // Usage example:
    //   static void (*orig_movenext)(Il2CppObject* stateMachine);
    //   static void hk_movenext(Il2CppObject* stateMachine) { ... }
    //   il2utils::hook_async_method(async_class, "SomeAsyncMethod", 0, hk_movenext, &orig_movenext);
    // Same trampoline-slot contract as hook_method, and for the same reason: this forwards `original`
    // straight through, so a bare function pointer here reaches the store as nullptr. The assert
    // exists so the diagnostic points at this call site rather than at the forward below.
    template <typename T, typename T2>
    void hook_async_method(const Il2CppClass* async_class, const char* method_name, const int args, T hook, T2* original) {
        static_assert(std::is_pointer_v<T2>,
            "hook_async_method: the trampoline slot must be passed as its ADDRESS, e.g. &o_foo.");
        // First, get the async method to find its state machine type
        const MethodInfo* method = resolve_method(async_class, method_name, args);
        if (!method || !method->methodPointer)
        {
            logger::warn(std::string("hook_async_method FAILED: ")
                + (async_class->name ? async_class->name : "?") + "::" + method_name);
            return;
        }

        const Il2CppClass* state_machine_class = find_state_machine_class(async_class, method_name);
        if (!state_machine_class)
        {
            logger::warn(std::string("hook_async_method FAILED (no state machine found): ")
                + (async_class->name ? async_class->name : "?") + "::" + method_name);
            return;
        }

        // Hook the MoveNext method on the state machine class (0 arguments)
        hook_method(state_machine_class, "MoveNext", 0, hook, original);
    }

    inline Il2CppObject* get_system_type(const Il2CppImage* image, const char* namespaze, const char* name) {
        const Il2CppClass* klass = resolve_class(image, namespaze, name);
        if (!klass)
            return nullptr;
        const Il2CppType* type = il2cpp::il2cpp_class_get_type(const_cast<Il2CppClass*>(klass));
        if (!type)
            return nullptr;
        return il2cpp::il2cpp_type_get_object(type);
    }

    inline std::wstring conv_wstring(const Il2CppString* string) {
        if (!string || string->length <= 0)
            return {};

        std::wstring out;
        out.reserve(static_cast<size_t>(string->length));
        for (int i = 0; i < string->length; ++i)
            out.push_back(string->chars[i]);
        return out;
    }

    inline std::string wide_to_utf8(const std::wstring& input) {
        if (input.empty())
            return {};

        const int size = WideCharToMultiByte(CP_UTF8, 0, input.data(), static_cast<int>(input.size()),
            nullptr, 0, nullptr, nullptr);
        if (size <= 0)
            return {};

        std::string out(static_cast<size_t>(size), '\0');
        WideCharToMultiByte(CP_UTF8, 0, input.data(), static_cast<int>(input.size()),
            out.data(), size, nullptr, nullptr);
        return out;
    }

    inline std::string conv_string(const Il2CppString* string) {
        return wide_to_utf8(conv_wstring(string));
    }
} // namespace il2utils
