# PROVENANCE — `il2cpp/libil2cpp/`

Where the six vendored headers came from, and what has been verified about the
game they are matched to. Written because nothing in the tree recorded any of
this, which is why it had to be re-derived from a third-party archive rather
than read off the repo.

Scope: the **headers** and the engine they describe. It says nothing about the
correctness of the offsets in `il2cpp_offsets.h`, which are a separate question
(see `AGENTS_TODO.md` §1.5 — `LoadFromFileAsync` currently does not resolve, and
that is an offsets/pattern problem, not a header-provenance problem).

## Verified engine version: 2022.3.43f2

```
UnityPlayer.dll  ProductVersion : 2022.3.43f2 (d42a179a7d86)
                 FileVersion    : 2022.3.43.13904407
```

Read from the `VS_VERSION_INFO` resource of
`D:\Games\Tarkov\UnityPlayer.dll`, the shipped install. The publicly reported
version for this line is **2022.3.43f1**; the binary says **f2**. The `f2`
revision is the one to record — an `f1` assumption is a one-patch error, but a
`f1` assumption written into a provenance file is an error that outlives the
patch that corrects it.

**`boot.config` cannot answer this on this install.** The obvious source is
one grep, and it is worth recording that the grep finds nothing: the file has
eight lines and no `unity-version` key.

```
gfx-enable-gfx-jobs=1
gfx-enable-native-gfx-jobs=1
wait-for-native-debugger=0
hdr-display-enabled=0
gc-max-time-slice=3
single-instance=
build-guid=b4cfd088142e472592c2e6d6ba3de9b4
```

So the version resource is the working source here, not the primary one.

## The compatibility manifest is correct — all three fields verified

`compatibility/profiles/1.1.5.1.47510/manifest.json` had been flagged as holding
one unverifiable row, on the grounds that its `UnityPlayer.dll` PE timestamp
(2025-12-15) postdates Unity's 2022.3.43f1 release by ~16 months. **That
inference is wrong and the row is right.** PE `TimeDateStamp` is stamped when
the module is *linked*, so it records when Battlestate built the player, not
when Unity cut the engine release. A 2025-12-15 link of a 2022.3.43 engine is
ordinary, not contradictory.

Re-derived from the live install, all three fields match exactly:

| field | manifest | measured from `D:\Games\Tarkov` |
| --- | --- | --- |
| `GameAssembly.dll` `pe_timestamp` | `0x6AAD381A` | `0x6AAD381A` (2026-09-18 13:09:46 UTC) |
| `GameAssembly.dll` `size` | 107925504 | 107925504 |
| `GameAssembly.dll` `text_sha256` | `827a8463…d32a2` | `827a8463…d32a2` |
| `UnityPlayer.dll` `pe_timestamp` | `0x693FDD26` | `0x693FDD26` (2025-12-15 10:04:22 UTC) |
| `UnityPlayer.dll` `size` | 29716480 | 29716480 |
| `UnityPlayer.dll` `text_sha256` | `cdc48e31…15b63` | `cdc48e31…15b63` |

Two conventions the manifest does not spell out, recovered by measurement, and
worth writing down because both are easy to get wrong when validating a profile:

- **`size` is `SizeOfImage`** (the optional-header value), **not** the on-disk
  file size. They differ materially: 107925504 vs 105014096 for `GameAssembly`,
  29716480 vs 28725584 for `UnityPlayer` — the gap is uninitialized data, since
  `.data` has `vsize` 0x81DDD8 against `rawsize` 0x556000. A validator that
  compares `st_size` to this field will reject a perfectly good install.
- **`text_sha256` is the SHA-256 of the `.text` section's raw on-disk bytes**,
  taken over `SizeOfRawData` bytes at `PointerToRawData` — not over
  `Misc.VirtualSize`. Both modules' hashes match under that reading and neither
  matches under the virtual-size reading, so the convention is pinned.

The manifest's `provenance.notes` cites `Assembly-CSharp\EFT\Build.txt` as
evidence for the build identity. That file is 1198 bytes of **disassembly** —
`sub rsp,28h` / `call 000000018008BC60h` and so on — with no version literal
anywhere in it. As a *semantic* reference for the build it is fair; as a
version record it is not, and nothing in the manifest depends on it being one.

## Game build id and dump directory names agree

`GameDump/` directories carry no separators, and the manifest id was read as
mismatching them. It does not. Nine digits decode as `1|1|5|X|YYZZZ`:

```
115147510  ->  1.1.5.1.47510      (the manifest's profile)
115047242  ->  1.1.5.0.47242
```

So the manifest id and the dump directory are the same build. The apparent
mismatch was a formatting artifact of reading a concatenated name as punctuated.

## `ISIL-references/IsilDump` age: the stated evidence does not hold

`IsilDump` was flagged as looking like an older build than `1.1.5.1.47510`, on
the strength of ~76% type overlap and `AFKMonitor` being present "only in the
fresh dump". Measured against `GameDump\115147510\DiffableCs`:

- `AFKMonitor` **is** in `IsilDump` (3 files, including two nested types). The
  cited example is not an example.
- Assembly-CSharp: 3424 entries in `IsilDump`, 2671 in the fresh dump,
  2475 in common. That is 72.3% of `IsilDump` / 92.7% of fresh — but **100% of
  the 949 `IsilDump`-only names contain `_NestedType_`**, and the fresh
  `DiffableCs` dump contains **zero** entries matching `NestedType`. The two
  dumps simply disagree about whether compiler-generated nested types get their
  own file, so the 72.3% measures a naming convention, not build age.

What remains genuinely unexplained is the other direction: 196 top-level type
names present only in the fresh dump (`AimingType`, `AmbientType`,
`AirdropDataPacket`, `AILayerDebugStruct`, … all absent from the whole
`IsilDump` tree). Those are real differences, and whether they are new types or
a different enumeration rule for enums is not settled here.

`IsilDump` also predates nothing provable: it is the reference the manifest was
generated from, and the manifest's native facts all verify against the current
install. Treat it as a *type* reference of unconfirmed vintage, not a module
reference.

## Metadata version: 31 — verified, from a dump rather than the install

The shipped `global-metadata.dat` cannot be read. First eight bytes are
`38 F4 41 03 7C 14 3B 94` (`0x0341F438`, `0x943B147C`) where an unencrypted file
starts `AF 1B B1 FA` (`0xFAB11BAF`) plus a version int. It is obfuscated across
the whole file, not just a header: comparing it against the decrypted copy in
`GameDump` gives **zero** identical bytes in either the prefix or the suffix, so
there is no plaintext island to recover the version from.

`GameDump/` does have decrypted copies, and all three checked agree:

| dump | magic | metadata version | size |
| --- | --- | --- | --- |
| `GameDump/115147510` | `0xFAB11BAF` | **31** | 27831348 |
| `GameDump/115047473` | `0xFAB11BAF` | **31** | 27831332 |
| `GameDump/110146911` | `0xFAB11BAF` | **31** | 27776688 |

The shipped file is **27831348 bytes — exactly the size of `115147510`**, the
build the compatibility manifest describes. Matching length plus matching build
identity is good corroboration that the dump corresponds to the shipped
metadata, but it is not proof: the encryption is total, so there is no shared
byte to compare.

**So "metadata version 31" is true** — it was previously recorded here as "not
a fact about this file", on the reasoning that the shipped copy could not be
read. That conflated *cannot be read from the shipped artefact* with *is not
true*, and cast doubt on a claim that is in fact correct. It is now verified,
from `GameDump/115147510`.

Separately, the shipped file has no `20\d\d\.\d+\.\d+[a-z]\d+` literal anywhere
across all 27831348 bytes, so it could never have answered the engine-version
question even unencrypted. That part of the original note stands.

## The upstream archive is `js6pak/libil2cpp-archive`, and the six headers match it exactly

Identified and confirmed, so the provenance question is now answered except for
one narrow residual noted at the end.

**Which commit? It does not matter.** Two adjacent entries were compared:

| commit | label | changes |
| --- | --- | --- |
| `8613ac1` | **2022.3.40 (v31)** | `codegen/il2cpp-codegen-common.h` only — adds a `il2cpp_codegen_memcpy_with_write_barrier` template |
| `c3b25fa` | **2022.3.48 (v31)** | `codegen/il2cpp-codegen-il2cpp.{h,cpp}`, `vm/Field.{h,cpp}` — a marshal-directive overload and a `FieldInfo*` → `const FieldInfo*` const-correctness fix |

**All six generated headers are byte-identical between the two** — FNV-1a over
the UTF-8 bytes, 6/6 matching, identical lengths (6488 / 2359 / 22188 / 4121 /
31311 / 3733). Neither commit touches a generated header at all; both touch only
`codegen/` and `vm/` runtime *source*, which this project does not use. So the
choice between them is immaterial for the vendored set, and there is no
"more suitable" commit to pick.

**Our copies are these headers, converted C→C++.** Verified by comparing the set
of declared type names, which survives the conversion but would differ between
Unity versions if this were the wrong archive entry. Across the six files the
two sides produced 22 apparent differences, and **all 22 are extraction
artifacts, not content differences**:

- 7 names appear "upstream only" and are in fact **struct members** present in
  both — `__klassIndex`, `__methodDefinitionIndex`, `startIndex`, `typeIndex`
  (union payloads in `Il2CppTokenAdjustorThunkPair` / `Il2CppTokenIndexMethodTuple`),
  `klass` (first member of `Il2CppObject`), `__typeIndex` and
  `methodDefinitionIndex` (members of `Il2CppRGCTXDefinitionData` and
  `Il2CppMethodSpec`). Confirmed present in our files as members.
- 15 names appear "locally only" and are in fact **upstream function-pointer
  typedefs** — `Il2CppMethodPointer`, `il2cpp_register_object_callback`,
  `Il2CppLogCallback`, `Il2CppProfileGCFunc`, `Il2CppAndroidUpStateFunc`,
  `Il2CppSetFindPlugInCallback`, … The C-side extraction pattern
  (`typedef … ?\b(\w+);`) captures the *parameter* of `typedef void (*Name)(Arg);`
  rather than `Name`. Spot-checked six upstream, all present.

Net: the declared-type sets are identical. Our files are larger than upstream
(6801/2152/23199/4241/32735/3906 vs 6488/2359/22188/4121/31311/3733) purely from
the conversion plus `#pragma once` and added commentary — expected, and not a
content difference.

**Why the structural test still cannot be run.** The six files are a *partial*
subset — 176 type declarations, only what the mod references — so the usual
version check (lay a vendored struct over the real metadata table and check the
arithmetic lands on the next table's offset) has nothing to stand on.
`Il2CppTypeDefinition`, the most version-sensitive struct in the format, is **not
declared at all** — only `Il2CppTypeDefinitionSizes` and a pointer to it — and
`il2cpp-metadata.h` has no `Il2CppGlobalMetadataHeader`. The conversion also
added explanatory comments that the originals do not have, so a whole-file hash
can never match. Type-set equality is the strongest available check, and it
passes.

**The residual, now closed.** `unity.bepinex.dev/libil2cpp-source/` — the source
js6pak's CI publishes to — carries a per-version archive, and `2022.3.43.zip`,
the engine line this game actually is, is extracted to `GameDump/2022.3.43/`.
That is an exact-version artefact, so the check that could previously only be
argued from "3.40 and 3.48 are identical and 3.43 is between them" is now a
direct comparison.

All six file sizes are identical to the 3.40 and 3.48 copies
(6488 / 2359 / 22188 / 4121 / 31311 / 3733). The stronger test is per-struct —
the **ordered member sequence** of every struct in the C original against the
C++ conversion, which is layout-sensitive in a way a type-name comparison is not.

**112 of 113 structs match member-for-member. The one that differs is a real,
deliberate, and previously undocumented local addition:**

```c
// upstream 2022.3.43 -- this struct ends at max_length
typedef struct Il2CppArray : public Il2CppObject {
    Il2CppArrayBounds* bounds;
    il2cpp_array_size_t max_length;
} Il2CppArray;
```

```cpp
// ours -- one extra member
using Il2CppArray = struct Il2CppArray : Il2CppObject {
    Il2CppArrayBounds* bounds;
    il2cpp_array_size_t max_length;
    void* data;              // <-- not upstream
};
```

Verified safe on both counts, tree-wide rather than by inspection:

1. **Every use takes its address.** Roughly 70 call sites spell "element 0" as
   `&arr->data`; none dereferences `data`. The member exists purely so that
   `&arr->data` names the address where IL2CPP really stores the elements. The
   one apparent exception, `type->data.generic_class`, is a different member —
   the union inside `Il2CppType`.
2. **`sizeof(Il2CppArray)` is used, 10 times, but never for an element offset.**
   Every occurrence is the length argument to `is_readable_address()` /
   `readable_range()` when validating a header before dereferencing it. The local
   member makes that 48 rather than upstream's 40, so the check asks whether 8
   *more* bytes are readable than strictly required — strictly more
   conservative, and never a wrong address.

The member carried **no comment**, in a vendored header, describing a local
divergence from upstream. That is precisely the shape of thing a later reader
tidies away as an accidental difference and thereby breaks ~70 call sites. It
now has a comment saying what it is, why it exists, why it is safe, and that it
must not be deleted. Comment-only; no code changed.

So the headers are now **verified against the exact engine line this game
reports** — 2022.3.43, the same line as the live build's 2022.3.43f2 — modulo
that one intentional divergence.

**The "2022.3.20–2022.3.62 window" that used to be quoted here is unsourced.**
It appears in no code, comment, or vendored file. Its only occurrence in the
repository is prose in `AGENTS_TODO.md` — and, until this revision, in this file,
which had simply repeated it back. A citation loop: a claim with no artefact
behind it, laundered by repetition. It is not restated here, because restating
it would make it look sourced. The archive is the real provenance, and it is now
named.

There remains strong **indirect** evidence the runtime-side layouts are right:
the vendored set is dominated by the structs the mod dereferences continuously
(`Il2CppClass`, `MethodInfo`, `FieldInfo`, `Il2CppObject`). A wrong layout there
would break every `resolve_class` / `get_method` rather than subtly misbehave,
and the mod demonstrably works. That is a strong operational signal and a weak
provenance one — it cannot distinguish "correct" from "correct enough that
nothing exercised the difference".

## Derivation — the one remaining gap

`libil2cpp/` was vendored in `bb8615f1` *TA_Reloaded_2.0_Base*
(2026-08-22, XeonDead), an import commit whose message records nothing about
where the headers came from. `aa64917b` (`libil2cpp: restore <stddef.h>, drop
stray project include`) is the only other commit touching the directory and is
a two-file cleanup, not a derivation record.

So the established facts are: the game is **2022.3.43f2** with metadata
**version 31**; the vendored set is a six-file partial extraction of Unity's
generated IL2CPP output, converted C→C++; and it is **confirmed to be
`js6pak/libil2cpp-archive`** by declared-type-set equality, with the generated
headers byte-identical across 2022.3.40 and 2022.3.48.

The git side is the only part still open: no commit message in this repository
records the import, so the *date* and the exact archive entry the original
author used are not on record. Given the type sets match exactly and the
headers are stable across the whole 3.4x range, the entry is almost certainly
3.43 or a near neighbour — but the person who ran the import is the only one who
can state it. What a future change should do: record the archive URL, the
commit SHA, and the date *in the commit that vendors them*, so this question
never has to be re-derived.

## A note on `GameDump/` vs the encrypted install

`GameDump/` and `ISIL-references/IsilDump` are the useful references here
precisely because the shipped install is partly unreadable. Verified in this
pass, the split is:

- **Readable, and checked against the live install:** `GameAssembly.dll`,
  `UnityPlayer.dll`. Not obfuscated — PE headers, section tables and `.text`
  bytes hash and match the manifest exactly. That is where the engine version
  and every module fact came from.
- **Not readable, so a dump is the only source:** `global-metadata.dat`,
  obfuscated at rest. The metadata version (31) came from
  `GameDump/115147510/global-metadata.dat`, which sits *beside* `DiffableCs/`
  rather than inside it.

`GameDump/<build>/dump.cs` opens with a plain image/type table and no version
banner, so it adds nothing on this question — the decrypted `global-metadata.dat`
next to it is the artefact that matters.

For anything the manifest does not cover (a type that moved, a method that
changed shape), `GameDump/<build>/DiffableCs/` is the reference of record, and
its nesting convention differs from `ISIL-references/IsilDump` as recorded
above.

## How these facts were obtained

- Engine version: `Get-Item …\UnityPlayer.dll | % VersionInfo` (ProductVersion).
- `boot.config`: read in full to confirm absence, not just to fail a grep.
- Manifest fields: PE section table parsed directly, `TimeDateStamp` from
  `IMAGE_FILE_HEADER`, `SizeOfImage` from `OptionalHeader`, SHA-256 over the
  `.text` raw bytes. Reproduce with the manifest's own `size`/`pe_timestamp`/
  `text_sha256` as the expected values.
- Type counts: file-name sets of
  `ISIL-references\IsilDump\Assembly-CSharp` and
  `GameDump\115147510\DiffableCs\Assembly-CSharp`, compared by base name
  (`.txt` vs `.cs`, so stems are the only common key).
- `global-metadata.dat`: first 8 bytes as two little-endian uint32s, plus a
  regex sweep of the whole file.
