#pragma once

// Content-based, allocation-free memo keys for the IL2CPP metadata caches.
//
// WHY THIS EXISTS
//
// resolve_field and resolve_method are memoised. They are not, however,
// allocation-free: each call built its key as
//
//     std::to_string(reinterpret_cast<uintptr_t>(clazz)) + "::" +
//     std::to_string(arg_count) + "::" + name
//
// which is two heap allocations plus a concatenation, to arrive at an answer
// that is almost always already in the map. Measured 2026-10-09 on a Prod
// capture: il2utils::resolve_method 22,114,149 calls / 4.916 s (mean 0.22 us)
// and il2utils::resolve_field 14,022,703 calls / 2.809 s (mean 0.20 us). Those
// are 36 MILLION cache HITS, and the key construction is what they cost. The
// lookup itself is a hash of a short string.
//
// The lock is deliberately NOT what this optimises. il2utils.h documents two
// separate mutexes and a measured 2.27x regression when the method memo shared
// one with the image/class/field memos; that stays.
//
// WHY THE KEY IS CONTENT-BASED AND NOT THE POINTER
//
// The obvious cheaper key is (clazz, name POINTER, arg_count) -- no string
// handling at all. It is unsafe, and there is a live counter-example in the
// tree: PlayerModule.cpp:833 builds
//
//     std::string trader_id_key = std::string(TRADER_API[sel]) + "_ID";
//
// and passes trader_id_key.c_str() at :845. TRADER_API entries are 8-18 chars,
// so the concatenation is 11-21 chars and lands past MSVC's 15-char SSO
// buffer: it heap-allocates, and the std::string dies at end of scope. Every
// entry in TRADER_API is a DIFFERENT trader of the SAME length class, so
// consecutive calls draw from the same heap bucket and can reuse the address.
// A pointer-keyed memo would then hand a caller who asked for
// PRAPOR_TRADER_ID the FieldInfo* it had cached for LIGHT_KEEPER_TRADER_ID --
// a wrong value, not a crash, which is the harder kind to notice.
//
// So the key copies the name's CONTENT. A caller may pass any pointer that is
// alive for the duration of the call, including a .c_str() of a temporary,
// because nothing derived from the pointer outlives the call. Only the bytes
// are retained. See tools/tests/test_no_runtime_string_memo_keys.py, which
// keeps new call sites honest about this.
//
// FAIL-OPEN ON AN OVERLONG NAME
//
// A name that does not fit the inline buffer sets cacheable = false and the
// caller resolves without memoising. Truncating instead would be a correctness
// bug: two different long names would collide onto one entry and hand back the
// wrong FieldInfo, which is the exact failure mode this file exists to prevent.
// IL2CPP member names are C# identifiers and do not come close to the limit;
// the path exists so that "unusual" cannot silently become "wrong".

#include <cstddef>
#include <cstdint>
#include <cstring>

namespace il2utils::detail {

struct MetaKey {
    // 48 covers every C# identifier IL2CPP emits with room to spare. The limit
    // is on the BUFFER, not the accepted length -- see the fail-open note above.
    static constexpr std::size_t kInlineName = 48;

    std::uintptr_t clazz = 0;
    std::uint32_t arg_count = 0;
    std::uint32_t name_hash = 0;
    std::uint16_t name_len = 0;
    bool cacheable = true;
    char name[kInlineName] = {};

    // Fills the key from a NUL-terminated name. Returns false when the name is
    // too long to represent exactly, in which case the key must not be used to
    // memoise anything.
    bool assign(const void* clazz_ptr, int argc, const char* n) noexcept {
        clazz = reinterpret_cast<std::uintptr_t>(clazz_ptr);
        arg_count = static_cast<std::uint32_t>(argc);
        cacheable = true;
        if (!n) {
            name_len = 0;
            name_hash = 0;
            name[0] = '\0';
            cacheable = false;
            return false;
        }
        const std::size_t len = std::strlen(n);
        // Hashed for EVERY name, including ones that will not be memoised.
        // Without this a too-long name leaves the inline buffer zeroed, and two
        // DIFFERENT overlong names then compare equal -- which is precisely the
        // collision this type exists to prevent, one level up. Caught by
        // tools/harness/test_meta_key.cpp.
        std::uint32_t h = 2166136261u;
        for (std::size_t i = 0; i < len; ++i) {
            h ^= static_cast<unsigned char>(n[i]);
            h *= 16777619u;
        }
        name_hash = h;
        if (len >= kInlineName) {
            name_len = 0;
            cacheable = false;
            return false;
        }
        name_len = static_cast<std::uint16_t>(len);
        std::memcpy(name, n, len + 1);
        return true;
    }

    friend bool operator==(const MetaKey& a, const MetaKey& b) noexcept {
        return a.clazz == b.clazz && a.arg_count == b.arg_count &&
               a.name_hash == b.name_hash && a.name_len == b.name_len &&
               std::memcmp(a.name, b.name, a.name_len) == 0;
    }
};

// FNV-1a over the name, then mixed with the class address and arity. The
// address is already well distributed; the name is hashed because comparing it
// byte-wise inside the map would be O(len) per probe.
struct MetaKeyHash {
    std::size_t operator()(const MetaKey& k) const noexcept {
        std::uint64_t h = 1469598103934665603ull;
        for (std::uint16_t i = 0; i < k.name_len; ++i) {
            h ^= static_cast<unsigned char>(k.name[i]);
            h *= 1099511628211ull;
        }
        h ^= k.name_hash;
        h *= 1099511628211ull;
        h ^= static_cast<std::uint64_t>(k.clazz);
        h *= 1099511628211ull;
        h ^= k.arg_count;
        h *= 1099511628211ull;
        return static_cast<std::size_t>(h);
    }
};

} // namespace il2utils::detail