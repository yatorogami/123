#pragma once
#include <type_traits>
#include "libil2cpp/il2cpp-class-internals.h"
#include "il2utils.h"

/**
 * Represents an instance of an il2cpp object and provides interfaces for it
 */
class Il2CppObjectInstance
{
  public:
    /**
     * Should be used in most cases, automatically sets the class
     * @param instance object instance
     */
    explicit Il2CppObjectInstance(Il2CppObject* instance);

    /**
     * Explicitly declare the class
     * @param clazz il2cpp class
     * @param instance object instance
     */
    Il2CppObjectInstance(const Il2CppClass* clazz, Il2CppObject* instance);

    /**
     * Resolve the class
     * @param image il2cpp image
     * @param namespaze namespce
     * @param name class name
     * @param instance object instance
     */
    Il2CppObjectInstance(const Il2CppImage* image, const char* namespaze, const char* name,
        Il2CppObject* instance);

    template <typename T>
    void set_field(const char* name, T value) {
        if (!instance_ || !clazz_) return;
        const FieldInfo* field = il2utils::resolve_field(this->clazz_, name);
        if (!field) return;
        *reinterpret_cast<T*>(reinterpret_cast<UINT64>(instance_) + field->offset) = value; // NOLINT(performance-no-int-to-ptr)
    }

    template <typename T>
    T get_field(const char* name) {
        if (!instance_ || !clazz_) return T{};
        const FieldInfo* field = il2utils::resolve_field(this->clazz_, name);
        if (!field) return T{};
        return *reinterpret_cast<T*>(reinterpret_cast<UINT64>(instance_) + field->offset); // NOLINT(performance-no-int-to-ptr)
    }

    template <typename T>
    T get_method(const char* name, const int args, bool log_fail = true, bool allow_any_argc = true) {
        return clazz_ ? il2utils::get_method<T>(clazz_, name, args, log_fail, allow_any_argc) : T{};
    }

    // ---- Checked access -----------------------------------------------------
    //
    // get_method returns a bare T, so this compiles:
    //
    //     inst.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_ContainedItem", 0)
    //         (inst.get_instance());
    //
    // and if the resolve misses, that is a call through address 0x0. That is the
    // shape that killed the process on 2026-10-04 (execute at 0x0, in the optic
    // camera path; see tools/handoff_call_through_null_crash.md).
    //
    // These two fold the resolve, the test and the call into one expression, so
    // the dangerous form has nothing left to write.
    //
    // `on_miss` has NO default, deliberately. The fail-closed value is not
    // deducible from the return type: a float that means "scope zoom" wants 1.0
    // (= not magnified), while a float that means "alpha" wants 0.0. A deduced
    // T{} would be silently wrong for one of them, and silently wrong is how a
    // crash becomes a feature that quietly does nothing. Forcing the value at
    // every call site makes the decision visible and reviewable.
    //
    // For a void-returning method there is no value to fail to, but the call
    // must still not happen -- use checked_void_call.
    // `on_miss` is typed as the method's RETURN type, not as R. `decltype(R(nullptr))`
    // would be the function-pointer type itself, which then deduces `auto` to the
    // pointer and fails to compile at the `return`.
    //
    // FP appends the hidden trailing MethodInfo* (see il2utils::with_methodinfo).
    // Game code always passes it; a bare methodPointer call that omits it leaves
    // the slot as a leftover and any shared-generic wrapper down the call chain
    // dereferences the garbage -- the 2026-10-08 AV inside
    // Dictionary<object,object>::Add via BotGroupEnemyInfo::.ctor's tracked-store
    // barrier (see il2utils.h).
    template <typename R, typename... Args>
    auto call_or(const char* name, const int args, R on_miss, Args... call_args) {
        using FP = R(*)(Il2CppObject*, Args..., const MethodInfo*);
        const MethodInfo* mi = nullptr;
        const FP fn = clazz_
            ? il2utils::get_method<FP>(clazz_, name, args, true, true, &mi)
            : nullptr;
        if (!fn || !mi) return on_miss;
        return fn(get_instance(), call_args..., mi);
    }

    // `void (*)(Il2CppObject*, Args..., const MethodInfo*)` -- resolves, and does
    // nothing on a miss. R is the call-site's declared function-pointer type; the
    // trailing MethodInfo* is appended here, so existing call sites are unchanged.
    template <typename R, typename... Args>
    void call_or_void(const char* name, const int args, Args... call_args) {
        using FP = il2utils::with_methodinfo_t<R>;
        const MethodInfo* mi = nullptr;
        const FP fn = clazz_
            ? il2utils::get_method<FP>(clazz_, name, args, true, true, &mi)
            : nullptr;
        if (!fn || !mi) return;
        fn(get_instance(), call_args..., mi);
    }

    Il2CppObject* get_instance() const;

  private:
    const Il2CppClass* clazz_;
    Il2CppObject* instance_;
};
