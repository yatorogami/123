#pragma once

#include <Windows.h>

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <optional>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

namespace compatibility_profile {
    enum class LoadResult {
        NotFound,
        Loaded,
        Mismatch,
        Invalid,
    };

    struct ModuleIdentity {
        DWORD size = 0;
        DWORD pe_timestamp = 0;
    };

    struct Symbol {
        std::string name;
        std::string module;
        std::string resolver;
        std::string export_name;
        std::vector<std::string> patterns;
        std::vector<std::string> resolution_order;
        std::size_t expected_matches = 1;
        std::optional<uintptr_t> rva;
        bool required = false;
    };

    class Profile {
      public:
        // Select a profile for an in-process module (reads SizeOfImage + PE
        // timestamp from the loaded image). Searches
        // module_paths::data_directory_wide()/compatibility/profiles -- i.e.
        // <dll dir>/ta/compatibility/profiles when ta/ exists, else
        // <dll dir>/compatibility/profiles. That is where the MSBuild Content item
        // puts the manifest and where deploy.py ships it, and it is the same root
        // TarkovLauncherBypass uses. Do NOT hardcode <dll dir>/compatibility here:
        // that spelling was live until 2026-10-01 and made this lookup return
        // NotFound on every launch, silently. See AGENTS_TODO.md 5.8.
        static LoadResult load_for_module(HMODULE module, Profile& output, std::string& detail);

        // Select a profile for an externally supplied module identity (e.g. a
        // dump of a module in another process). Callers provide the manifest root.
        static LoadResult load_for_identity(
            const ModuleIdentity& identity,
            const std::filesystem::path& profile_root,
            Profile& output,
            std::string& detail);

        bool loaded() const { return loaded_; }
        const std::string& id() const { return id_; }
        const std::string& game_version() const { return game_version_; }
        const std::string& status() const { return status_; }
        const std::string& path() const { return path_; }
        const Symbol* find(std::string_view name) const;

        // Manifest module identities, retained so external consumers (the
        // launcher) can verify a later dump of any declared module.
        const ModuleIdentity* module_identity(const std::string& module) const;

        // Internal construction helpers used by the file loader.
        void reset();
        void set_metadata(
            std::string id,
            std::string game_version,
            std::string status,
            std::string path);
        bool add_symbol(Symbol symbol, std::string& duplicate_name);
        void add_module_identity(std::string module, ModuleIdentity identity);

      private:
        bool loaded_ = false;
        std::string id_;
        std::string game_version_;
        std::string status_;
        std::string path_;
        std::unordered_map<std::string, Symbol> symbols_;
        std::unordered_map<std::string, ModuleIdentity> modules_;
    };
} // namespace compatibility_profile
