#include "common.h"
#include "unity.h"

namespace unity {

    vector2::vector2() { x = y = 0.f; }

    vector2::vector2(const float f1, const float f2) {
        x = f1;
        y = f2;
    }

    vector2 vector2::operator-(vector2 b) const {
        return {x - b.x, y - b.y};
    }

    vector2 vector2::operator+(vector2 b) const {
        return {x + b.x, y + b.y};
    }

    vector2 vector2::operator*(float k) const {
        return {x * k, y * k};
    }

    vector3::vector3() { x = y = z = 0.f; }

    vector3::vector3(const float f1, const float f2, const float f3) {
        x = f1;
        y = f2;
        z = f3;
    }

    [[nodiscard]] vector3 vector3::add(const vector3 b) const {
        return {x + b.x, y + b.y, z + b.z};
    }

    [[nodiscard]] float vector3::distance(const vector3 b) const {
        return static_cast<float>(sqrt(pow(x - b.x, 2) + pow(y - b.y, 2) + pow(z - b.z, 2)));
    }

    [[nodiscard]] float vector3::length() const {
        return x * x + y * y + z * z;
    }

    [[nodiscard]] float vector3::dot(const vector3 b) const {
        return x * b.x + y * b.y + z * b.z;
    }

    vector3 vector3::normalize() {
        if (const float len = length(); len > 0)
            return {x / len, y / len, z / len};
        return {x, y, z};
    }

    vector3 vector3::operator-(vector3 b) const {
        return {x - b.x, y - b.y, z - b.z};
    }

    vector3 vector3::operator+(vector3 b) const {
        return {x + b.x, y + b.y, z + b.z};
    }

    vector3 vector3::operator*(float k) const {
        return {x * k, y * k, z * k};
    }

    vector3 vector3::operator/(float k) const {
        return {x / k, y / k, z / k};
    }

    vector4::vector4() { x = y = z = w = 0.f; }

    vector4::vector4(const float f1, const float f2, const float f3, const float f4) {
        x = f1;
        y = f2;
        z = f3;
        w = f4;
    }

    quaternion::quaternion() { x = y = z = w = 0.f; }

    quaternion::quaternion(const float f1, const float f2, const float f3, const float f4) {
        x = f1;
        y = f2;
        z = f3;
        w = f4;
    }

    quaternion quaternion::euler(float m_f_x, float m_f_y, float m_f_z) {
        constexpr float m_f_deg2_rad = pi_f / 180.f;

        m_f_x = m_f_x * m_f_deg2_rad * 0.5f;
        m_f_y = m_f_y * m_f_deg2_rad * 0.5f;
        m_f_z = m_f_z * m_f_deg2_rad * 0.5f;

        const float m_f_sin_x = sinf(m_f_x);
        const float m_f_cos_x = cosf(m_f_x);

        const float m_f_sin_y = sinf(m_f_y);
        const float m_f_cos_y = cosf(m_f_y);

        const float m_f_sin_z = sinf(m_f_z);
        const float m_f_cos_z = cosf(m_f_z);

        x = m_f_cos_y * m_f_sin_x * m_f_cos_z + m_f_sin_y * m_f_cos_x * m_f_sin_z;
        y = m_f_sin_y * m_f_cos_x * m_f_cos_z - m_f_cos_y * m_f_sin_x * m_f_sin_z;
        z = m_f_cos_y * m_f_cos_x * m_f_sin_z - m_f_sin_y * m_f_sin_x * m_f_cos_z;
        w = m_f_cos_y * m_f_cos_x * m_f_cos_z + m_f_sin_y * m_f_sin_x * m_f_sin_z;

        return *this;
    }

    quaternion quaternion::euler(const vector3 m_v_rot) {
        return euler(m_v_rot.x, m_v_rot.y, m_v_rot.z);
    }

    [[nodiscard]] vector3 quaternion::to_euler() const {
        vector3 m_v_euler;

        const float m_f_dist = (x * x) + (y * y) + (z * z) + (w * w);

        const float m_f_test = x * w - y * z;
        if (m_f_test > 0.4995f * m_f_dist)
        {
            m_v_euler.x = pi_f * 0.5f;
            m_v_euler.y = 2.f * atan2f(y, x);
            m_v_euler.z = 0.f;
        }
        else if (m_f_test < -0.4995f * m_f_dist)
        {
            m_v_euler.x = pi_f * -0.5f;
            m_v_euler.y = -2.f * atan2f(y, x);
            m_v_euler.z = 0.f;
        }
        else
        {
            m_v_euler.x = asinf(2.f * (w * x - y * z));
            m_v_euler.y = atan2f(2.f * w * y + 2.f * z * x, 1.f - 2.f * (x * x + y * y));
            m_v_euler.z = atan2f(2.f * w * z + 2.f * x * y, 1.f - 2.f * (z * z + x * x));
        }

        constexpr float m_f_rad_2deg = 180.f / pi_f;
        m_v_euler.x *= m_f_rad_2deg;
        m_v_euler.y *= m_f_rad_2deg;
        m_v_euler.z *= m_f_rad_2deg;

        return m_v_euler;
    }

    quaternion quaternion::operator*(quaternion b) {
        return {
            w * b.x + x * b.w + y * b.z - z * b.y,
            w * b.y - x * b.z + y * b.w + z * b.x,
            w * b.z + x * b.y - y * b.x + z * b.w,
            w * b.w - x * b.x - y * b.y - z * b.z};
    }

    quaternion quaternion::operator+(quaternion b) {
        return {
            x + b.x,
            y + b.y,
            z + b.z,
            w + b.w};
    }

    quaternion quaternion::operator*(float s) {
        return {
            x * s,
            y * s,
            z * s,
            w * s};
    }

    vector3 quaternion::operator*(vector3 v) {
        quaternion p{v.x, v.y, v.z, 0.f};
        quaternion tq{x, y, z, w};
        quaternion ctq{-x, -y, -z, w};

        quaternion result = (tq * p) * ctq;

        return {result.x, result.y, result.z};
    }

    rect::rect() { f_x = f_y = f_width = f_height = 0.f; }

    rect::rect(const float f1, const float f2, const float f3, const float f4) {
        f_x = f1;
        f_y = f2;
        f_width = f3;
        f_height = f4;
    }

    color::color() { r = g = b = a = 0.f; }

    color::color(const float f_red, const float f_green, const float f_blue,
        const float f_alpha) {
        r = f_red;
        g = f_green;
        b = f_blue;
        a = f_alpha;
    }

    float* matrix4_x4::operator[](int i) { return m[i]; }

    [[nodiscard]] Il2CppArray* list::to_array() const { return m_p_list_array; }

} // namespace unity
