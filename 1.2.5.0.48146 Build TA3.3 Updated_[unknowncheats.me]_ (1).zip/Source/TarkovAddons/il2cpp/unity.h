#pragma once
#define _USE_MATH_DEFINES

// The `[CLEANUP-PENDING:OPTICS]` marker that used to open this file is GONE:
// the optics rework landed and the user lifted the freeze on 2026-10-13
// (AGENTS.md, "Do not touch"). A dead-code pass had found six unreferenced math
// helpers here -- `camera_aspect`, `conjugate`, `nlerp`,
// `quaternion_from_two_vectors`, `to_vectors` and `transform_set_parent` --
// written to the derivation in optic_idea.md and kept for the rework. **All
// six were DELETED 2026-10-13**, once the rework had landed without adopting
// them; `transform_set_parent` took its resolver (`set_parent_internal`, a
// `SetParent` get_method at init) with it. `camera_pixel_width`/`_height`
// below are the live example of the resolve-into-a-local-and-test shape the
// `camera_fov` crash fix was modelled on. See CLEANUP_AUDIT.md section 2.4.

#include <cmath>
#include <math.h>
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <format>
#include "libil2cpp/il2cpp-api-types.h"
#include <Windows.h>

#include "Il2CppObjectInstance.h"
#include "libil2cpp/il2cpp-object-internals.h"
#include "il2utils.h"
#include "../util/logger.h"
#include "../util/pe_resource.h"
#include "../util/tracy_bridge.h"

namespace unity {
    // float-precision pi.
    //
    // M_PI is a `double` macro, so every use of it assigned into a float was a
    // narrowing conversion. That single root cause produced all 72 C4305
    // ("truncation from 'double' to 'float'") warnings in this header.
    //
    // An `f` literal of the same real value is correctly rounded to the identical
    // float as `(float)M_PI`, so direct assignments and the exact `* 0.5f`
    // halvings are bit-for-bit unchanged. The two divisions below
    // (pi_f / 180.f and 180.f / pi_f) now round once in float instead of twice
    // (double, then float), so they may differ from the previous value by 1 ULP
    // (~1e-7 relative). For degree/radian conversion factors on camera angles
    // that is immaterial, and single rounding is the more correct of the two.
    inline constexpr float pi_f = 3.14159265358979323846f;

    struct vector2
    {
        float x, y;

        vector2();

        vector2(const float f1, const float f2);

        vector2 operator-(vector2 b) const;

        vector2 operator+(vector2 b) const;

        vector2 operator*(float k) const;
    };

    inline float dot(vector2 a, vector2 b) {
        return a.x * b.x + a.y * b.y;
    }

    inline float length(vector2 v) {
        return std::sqrt(dot(v, v));
    }

    inline vector2 normalize(vector2 v, vector2 fallback = {1.0f, 0.0f}) {
        float len = length(v);

        if (len < 1e-6f)
        {
            return fallback;
        }

        return {v.x / len, v.y / len};
    }

    inline float wrapAngle(float angle) {
        const float pi = pi_f;

        while (angle > pi)
        {
            angle -= 2.0f * pi;
        }

        while (angle <= -pi)
        {
            angle += 2.0f * pi;
        }

        return angle;
    }

    inline vector2 fromAngle(float angle) {
        return {std::cos(angle), std::sin(angle)};
    }

    inline vector2 rotateTowards(vector2 currentDir, vector2 origin, vector2 target, float maxAngle) {
        currentDir = normalize(currentDir, {1.0f, 0.0f});

        vector2 desiredDir = normalize(target - origin, currentDir);

        float currentAngle = std::atan2(currentDir.y, currentDir.x);
        float desiredAngle = std::atan2(desiredDir.y, desiredDir.x);

        float delta = wrapAngle(desiredAngle - currentAngle);

        delta = std::clamp(delta, -maxAngle, maxAngle);

        return fromAngle(currentAngle + delta);
    }

    struct vector3
    {
        float x, y, z;

        vector3();

        vector3(const float f1, const float f2, const float f3);

        [[nodiscard]] vector3 add(const vector3 b) const;

        [[nodiscard]] float distance(const vector3 b) const;

        [[nodiscard]] float length() const;

        [[nodiscard]] float dot(const vector3 b) const;

        vector3 normalize();

        vector3 operator-(vector3 b) const;

        vector3 operator+(vector3 b) const;

        vector3 operator*(float k) const;

        vector3 operator/(float k) const;
    };

    inline float dot(vector3 a, vector3 b) {
        return a.x * b.x + a.y * b.y + a.z * b.z;
    }

    inline vector3 cross(vector3 a, vector3 b) {
        return {
            a.y * b.z - a.z * b.y,
            a.z * b.x - a.x * b.z,
            a.x * b.y - a.y * b.x};
    }

    inline float length(vector3 v) {
        return std::sqrt(dot(v, v));
    }

    inline vector3 normalize(vector3 v, vector3 fallback = {1.0f, 0.0f, 0.0f}) {
        float len = length(v);

        if (len < 1e-6f)
        {
            return fallback;
        }

        return {v.x / len, v.y / len, v.z / len};
    }

    inline vector3 rotateAroundAxis(vector3 v, vector3 axis, float angle) {
        float c = std::cos(angle);
        float s = std::sin(angle);

        return v * c + cross(axis, v) * s + axis * dot(axis, v) * (1.0f - c);
    }

    inline vector3 rotateTowards(vector3 current, vector3 desired, float maxAngle) {
        current = normalize(current, {1.0f, 0.0f, 0.0f});
        desired = normalize(desired, current);

        float d = dot(current, desired);

        if (d > 0.999999f)
        {
            return desired;
        }

        const float pi = pi_f;

        if (d < -0.999999f)
        {
            vector3 axis;

            if (std::fabs(current.x) < 0.9f)
            {
                axis = cross(current, {1.0f, 0.0f, 0.0f});
            }
            else
            {
                axis = cross(current, {0.0f, 1.0f, 0.0f});
            }

            axis = normalize(axis, {0.0f, 1.0f, 0.0f});

            // Explicit template argument on purpose: <Windows.h> defines min/max
            // as function-like macros, and a bare std::min(a, b) would be
            // macro-expanded (std::min<T> is safe because `min` is followed by `<`).
            float step = std::min<float>(pi_f, maxAngle);

            return rotateAroundAxis(current, axis, step);
        }

        d = std::clamp(d, -1.0f, 1.0f);

        vector3 axis = normalize(cross(current, desired), {0.0f, 1.0f, 0.0f});

        float angle = std::acos(d);
        float step = std::min<float>(angle, maxAngle);

        return rotateAroundAxis(current, axis, step);
    }

    struct vector4
    {
        float x, y, z, w;

        vector4();

        vector4(const float f1, const float f2, const float f3, const float f4);
    };

    struct quaternion
    {
        float x, y, z, w;

        quaternion();

        quaternion(const float f1, const float f2, const float f3, const float f4);

        quaternion euler(float m_f_x, float m_f_y, float m_f_z);

        quaternion euler(const vector3 m_v_rot);

        [[nodiscard]] vector3 to_euler() const;

        quaternion operator*(quaternion b);

        quaternion operator+(quaternion b);

        quaternion operator*(float s);

        vector3 operator*(vector3 v);
    };

    inline quaternion identity() {
        return {0.0f, 0.0f, 0.0f, 1.0f};
    }

    inline float dot(quaternion a, quaternion b) {
        return a.w * b.w + a.x * b.x + a.y * b.y + a.z * b.z;
    }

    inline float length(quaternion q) {
        return std::sqrt(dot(q, q));
    }

    inline quaternion normalize(quaternion q) {
        float len = length(q);

        if (len < 1e-6f)
        {
            return identity();
        }

        return {
            q.x / len,
            q.y / len,
            q.z / len,
            q.w / len};
    }

    inline quaternion negated(quaternion q) {
        return {-q.x, -q.y, -q.z, -q.w};
    }

    inline quaternion fromAxisAngle(vector3 axis, float angle) {
        axis = normalize(axis, vector3{0.0f, 1.0f, 0.0f});

        float halfAngle = angle * 0.5f;

        float s = std::sin(halfAngle);
        float c = std::cos(halfAngle);

        return normalize({axis.x * s,
            axis.y * s,
            axis.z * s,
            c});
    }

    struct bounds
    {
        vector3 m_v_center;
        vector3 m_v_extents;
    };

    struct plane
    {
        vector3 m_v_normal;
        float f_distance;
    };

    struct ray
    {
        vector3 m_v_origin;
        vector3 m_v_direction;
    };

    struct rect
    {
        float f_x, f_y;
        float f_width, f_height;

        rect();

        rect(const float f1, const float f2, const float f3, const float f4);
    };

    struct color
    {
        float r, g, b, a;

        color();

        explicit color(const float f_red = 0.f, const float f_green = 0.f, const float f_blue = 0.f,
            const float f_alpha = 1.f);
    };

    struct matrix4_x4
    {
        float m[4][4] = {};

        float* operator[](int i);
    };

    template <typename TKey, typename TValue>
    struct dict : Il2CppObject
    {
        struct entry
        {
            int m_i_hash_code;
            int m_i_next;
            TKey m_t_key;
            TValue m_t_value;
        };

        Il2CppArray* m_p_buckets;
        Il2CppArray* m_p_entries;
        int m_i_count;
        int m_i_version;
        int m_i_free_list;
        int m_i_free_count;
        void* m_p_comparer;
        void* m_p_keys;
        void* m_p_values;

        // index_in_range() guards the index accessors below. m_i_count is the
        // number of LIVE entries, while m_p_entries->max_length is the capacity;
        // slots at or beyond the live count are free-list or uninitialised, and
        // anything at or beyond max_length is off the allocation entirely.
        // Callers that walk a dictionary must not read or write past the live
        // range -- an out-of-range write here is a heap corruption, not a no-op.
        [[nodiscard]] bool index_in_range(int i_index) const {
            return m_p_entries != nullptr && i_index >= 0 && i_index < m_p_entries->max_length;
        }

        entry* get_entry() {
            return reinterpret_cast<entry*>(&m_p_entries->data);
        }

        TKey get_key_by_index(int i_index) {
            TKey t_key = {0};

            if (!index_in_range(i_index))
                return t_key;

            return get_entry()[i_index].m_t_key;
        }

        TValue get_value_by_index(int i_index) {
            TValue t_value = {0};

            if (!index_in_range(i_index))
                return t_value;

            return get_entry()[i_index].m_t_value;
        }

        TValue get_value_by_key(TKey t_key) {
            TValue t_value = {0};
            for (int i = 0; i < m_i_count; i++)
            {
                if (get_entry()[i].m_t_key == t_key)
                    t_value = get_entry()[i].m_t_value;
            }
            return t_value;
        }

        bool set_value_by_index(int i_index, TValue v) {
            if (!index_in_range(i_index))
                return false;

            get_entry()[i_index].m_t_value = v;
            return true;
        }
    };

    // Mono List<T> layout: _items (T[]), _size (int), _version (int), ...
    //
    // m_p_list_array is _items -- the BACKING ARRAY, whose max_length is the CAPACITY,
    // not how many slots are live. A List<T> that has grown to 1000 and holds 55 items
    // reports max_length == 1000, and the tail is null rather than absent. Iterating to
    // max_length is safe (nulls are skipped) but it reports a capacity as if it were a
    // population, and it makes any "have I seen everything" cursor overshoot by the whole
    // unused tail.
    //
    // m_i_size is _size, the live count. Use live_count() when the question is "how many
    // entries exist"; use the array directly only when the caller genuinely wants every
    // slot including the unused ones.
    struct list : Il2CppObject
    {
        Il2CppArray* m_p_list_array; // 0x10, _items
        int m_i_size;                // 0x18, _size

        [[nodiscard]] Il2CppArray* to_array() const;

        // The live element count, clamped into the array. A null array is an empty list,
        // not a crash: _size is read only once the array is known to exist, so a
        // half-constructed list cannot send this off the end of nothing.
        [[nodiscard]] size_t live_count() const {
            if (!m_p_list_array || m_i_size < 0) return 0;
            const size_t cap = static_cast<size_t>(m_p_list_array->max_length);
            const size_t size = static_cast<size_t>(m_i_size);
            return size < cap ? size : cap;
        }
    };

    // Mono HashSet<T> layout: _buckets, _slots, _count, _lastIndex, _freeList, _comparer, ...
    // Slot { int hashCode; int next; T value; } — occupied slots have hashCode >= 0.
    template <typename TValue>
    struct hashset : Il2CppObject
    {
        struct slot
        {
            int m_i_hash_code;
            int m_i_next;
            TValue m_t_value;
        };

        Il2CppArray* m_p_buckets; // 0x10
        Il2CppArray* m_p_slots;   // 0x18
        int m_i_count;            // 0x20
        int m_i_last_index;       // 0x24
        int m_i_free_list;        // 0x28

        slot* get_slots() { return m_p_slots ? reinterpret_cast<slot*>(&m_p_slots->data) : nullptr; }
    };

    using find_objects_of_type_sig = Il2CppArray* (*)(PVOID);
    inline find_objects_of_type_sig find_objects_of_type_internal = nullptr;
    // Unity overload: FindObjectsOfType(Type, bool includeInactive)
    using find_objects_of_type_inc_sig = Il2CppArray* (*)(PVOID, bool);
    inline find_objects_of_type_inc_sig find_objects_of_type_inc_internal = nullptr;
    using find_object_of_type_sig = Il2CppObject* (*)(PVOID);
    inline find_object_of_type_sig find_object_of_type_internal = nullptr;
    using get_name_sig = Il2CppString* (*)(Il2CppObject*);
    inline get_name_sig get_name_internal = nullptr;
    using get_component_sig = Il2CppObject* (*)(Il2CppObject*, Il2CppObject*);
    inline get_component_sig get_component_internal = nullptr;
    using get_position_sig = vector3 (*)(Il2CppObject*);
    inline get_position_sig get_position_internal = nullptr;
    using set_position_sig = void (*)(Il2CppObject*, vector3);
    inline set_position_sig set_position_internal = nullptr;
    using get_parent_sig = Il2CppObject* (*)(Il2CppObject*);
    inline get_parent_sig get_parent_internal = nullptr;
    using component_get_game_object_sig = Il2CppObject* (*)(Il2CppObject*);
    inline component_get_game_object_sig component_get_game_object_internal = nullptr;
    using world_to_screen_point_sig = vector3 (*)(Il2CppObject*, vector3);
    inline world_to_screen_point_sig world_to_screen_point_internal = nullptr;
    using camera_get_current_sig = Il2CppObject* (*)();
    inline camera_get_current_sig camera_get_current_internal = nullptr;
    // Legacy Unity API (Camera[] allCameras) — removed in newer Unity used by EFT 1.0.6.5.46221.
    using camera_get_all_sig = Il2CppArray* (*)();
    inline camera_get_all_sig camera_get_all_internal = nullptr;
    // Current Unity: get_allCamerasCount() + GetAllCameras(Camera[]).
    using camera_get_all_count_sig = int (*)();
    inline camera_get_all_count_sig camera_get_all_count_internal = nullptr;
    using camera_get_all_fill_sig = int (*)(Il2CppArray*);
    inline camera_get_all_fill_sig camera_get_all_fill_internal = nullptr;
    using enumerable_to_array_sig = Il2CppArray* (*)(Il2CppObject*);
    inline enumerable_to_array_sig enumerable_to_array_internal = nullptr;

    inline const Il2CppClass* camera;

    inline Il2CppObject* transform_type;

    // The five UnityEngine classes init() cannot start without, as ONE table.
    //
    // They were five separate locals and one combined `if (!a || !b || ...)`, which
    // is why a failure produced a single line naming none of them:
    //     Unity init failed: required UnityEngine classes missing — check il2cpp_class_from_name
    // That line cannot distinguish two failures with opposite causes -- "the pointer
    // is the wrong function" and "the pointer is right but was asked too early" --
    // and it does not say how many of the five went missing. Resolving them from one
    // array rather than five locals also removes the shape where the retry loop and
    // the failure report disagree about what "required" means.
    struct UnityRequiredClass {
        const char* name;
        const Il2CppClass* resolved;
    };

    inline constexpr size_t kUnityRequiredClassCount = 5;

    inline bool all_required_resolved(const UnityRequiredClass* classes, size_t count) {
        for (size_t i = 0; i < count; ++i)
            if (!classes[i].resolved)
                return false;
        return true;
    }

    // One line per unresolved class, so the failure names what is actually missing
    // instead of describing a group. `resolved_here` is the count that DID come back:
    // "Object/Transform/Camera resolved, GameObject and Component did not" and "none of
    // them resolved" are different bugs, and the group message collapses them.
    inline void log_missing_unity_classes(
        const UnityRequiredClass* classes, size_t count, int attempts_used) {
        size_t resolved_here = 0;
        for (size_t i = 0; i < count; ++i) {
            if (classes[i].resolved) {
                ++resolved_here;
                continue;
            }
            logger::error("Unity init: required class UnityEngine." +
                std::string(classes[i].name) + " did not resolve (still null after " +
                std::to_string(attempts_used) + " attempt(s), 150 ms apart)");
        }
        logger::error("Unity init: " + std::to_string(resolved_here) + " of " +
            std::to_string(count) + " required UnityEngine classes resolved");
    }

    inline bool init() {
        Il2CppImage* unity_engine = il2utils::resolve_image("UnityEngine.CoreModule.dll");
        Il2CppImage* system_core = il2utils::resolve_image("System.Core.dll");
        if (!unity_engine)
        {
            logger::error("Unity init failed: UnityEngine.CoreModule.dll image not found (domain/assemblies broken?)");
            return false;
        }
        if (!system_core)
            logger::warn("System.Core.dll image not found — Enumerable.ToArray may be unavailable");

        // The retry, and what it is for.
        //
        // Verified against the shipped GameAssembly.dll this profile describes
        // (1.1.5.1.47510; manifest identity matches, and .text SHA-256 matches for
        // both GameAssembly.dll and UnityPlayer.dll), so the pointer below is the one
        // the manifest's pattern resolves to on the machine that produced this:
        //
        //   il2cpp_class_from_name -> rva 0x7CF90   (exactly 1 match in the image)
        //
        // That body keeps a PER-IMAGE class hash map at `image + 0x30` and builds it
        // lazily, in this order:
        //
        //   cmp qword ptr [rcx+0x30], 0 / jne reader   ; already there?
        //   ...
        //   mov qword ptr [rdi+0x30], rbx              ; PUBLISH -- map still empty
        //   cmp dword ptr [rdi+0x18], 0                ; fill starts (type count)
        //   ...
        //   mov rbx, qword ptr [rdi+0x30]              ; re-read, PER ITERATION
        //
        // A reader that arrives while the counts are still zero falls through to
        // `xor eax, eax`: null for EVERY name, not just absent ones. There is no lock
        // anywhere in that function -- the only atomics in it are CRT scaffolding.
        //
        // unity::init() runs on the thread DllMain creates (dllmain.cpp:360 -> :182 ->
        // :277), not Unity's main thread, and the boot gate returned on its first poll
        // in both failing launches ("Unity window present after 0 ms, 0 poll(s)"). So
        // this runs inside Unity's own startup, which is when the game's main thread is
        // doing the first CoreModule lookups itself. Either thread can read the other's
        // half-built map, and the result is all five null plus a log line that named
        // none of them.
        //
        // 3 attempts, 150 ms apart -- deliberately the same numbers, and the same
        // treatment, as resolve_pattern_with_retry() in il2cpp_offsets.h, which is the
        // precedent for a cold-start lookup that is transient.
        //
        // Bounded rather than open-ended, because one outcome is NOT recoverable and
        // must not be allowed to look like it is: the guard is `if ([image+0x30] != 0)
        // use as-is`, so if THIS thread is the one that published an empty map, no
        // number of retries will populate it. Both outcomes are now distinguishable in
        // the log -- "resolved on attempt N" is the race, "still null after 3 attempts"
        // is something else -- which is the whole reason this loop logs rather than
        // silently retrying.
        //
        // Retry cost is bounded too: il2utils::resolve_class memoises SUCCESSES only
        // (il2utils.h), so a later attempt re-runs only the lookups that actually
        // failed and every resolved class is free.
        constexpr int kRequiredClassAttempts = 3;
        constexpr int kRequiredClassDelayMs = 150;

        const Il2CppClass* enumerable = system_core
            ? il2utils::resolve_class(system_core, "System.Linq", "Enumerable")
            : nullptr;

        UnityRequiredClass required[kUnityRequiredClassCount] = {};
        int attempts_used = 0;
        for (; attempts_used < kRequiredClassAttempts; ++attempts_used)
        {
            if (attempts_used)
                Sleep(kRequiredClassDelayMs);

            required[0] = { "Object",     il2utils::resolve_class(unity_engine, "UnityEngine", "Object") };
            required[1] = { "GameObject", il2utils::resolve_class(unity_engine, "UnityEngine", "GameObject") };
            required[2] = { "Transform",  il2utils::resolve_class(unity_engine, "UnityEngine", "Transform") };
            required[3] = { "Component",  il2utils::resolve_class(unity_engine, "UnityEngine", "Component") };
            required[4] = { "Camera",     il2utils::resolve_class(unity_engine, "UnityEngine", "Camera") };

            if (all_required_resolved(required, kUnityRequiredClassCount))
                break;
        }

        const Il2CppClass* object = required[0].resolved;
        const Il2CppClass* game_object = required[1].resolved;
        const Il2CppClass* transform = required[2].resolved;
        const Il2CppClass* component = required[3].resolved;
        camera = required[4].resolved;

        const bool classes_ok = all_required_resolved(required, kUnityRequiredClassCount);

        // The positive result of the loop, and the only line that PROVES the race. A
        // class that was null on attempt 1 and non-null on a later attempt can only
        // have been looked up while the other thread's map was still being filled.
        //
        // It has to be tested here, on `classes_ok`, not inside the failure branch:
        // inside that branch `attempts_used > 0` means the opposite thing -- that the
        // retries ran AND still came back null, which is the unrecoverable case.
        if (classes_ok && attempts_used > 0)
            logger::warn("Unity init: required UnityEngine classes were null on the first "
                "attempt and resolved on attempt " + std::to_string(attempts_used + 1)
                + " of " + std::to_string(kRequiredClassAttempts)
                + " -- this is a race on il2cpp_class_from_name's per-image cache, not a "
                  "wrong function pointer. See the retry note above.");

        if (!classes_ok)
        {
            // attempts_used is the number of attempts actually MADE (the loop exits on
            // its condition, so it has already been incremented past the last one) --
            // not attempts_used + 1, which would report 4 of 3.
            log_missing_unity_classes(required, kUnityRequiredClassCount, attempts_used);
            logger::error("Unity init failed: required UnityEngine classes missing — check il2cpp_class_from_name");
            return false;
        }

        // Resolve with exact argc; get_method also falls back to argc=-1 (any overload).
        find_objects_of_type_internal = il2utils::get_method<find_objects_of_type_sig>(
            object, "FindObjectsOfType", 1, /*log_fail=*/true, /*allow_any_argc=*/false);
        // Separate 2-arg overload — never cast as 1-arg (wrong arity crashes).
        find_objects_of_type_inc_internal = il2utils::get_method<find_objects_of_type_inc_sig>(
            object, "FindObjectsOfType", 2, /*log_fail=*/false, /*allow_any_argc=*/false);
        if (!find_objects_of_type_internal && find_objects_of_type_inc_internal)
        {
            // No 1-arg API: call 2-arg with includeInactive=false via wrapper below.
            find_objects_of_type_internal = nullptr;
        }

        find_object_of_type_internal = il2utils::get_method<find_object_of_type_sig>(object, "FindObjectOfType", 1);
        if (!find_object_of_type_internal)
            find_object_of_type_internal = il2utils::get_method<find_object_of_type_sig>(object, "FindObjectOfType", 2);

        get_name_internal = il2utils::get_method<get_name_sig>(object, "GetName", 1);
        if (!get_name_internal)
            get_name_internal = il2utils::get_method<get_name_sig>(object, "get_name", 0);

        get_component_internal = il2utils::get_method<get_component_sig>(game_object, "GetComponent", 1);
        get_position_internal = il2utils::get_method<get_position_sig>(transform, "get_position", 0);
        set_position_internal = il2utils::get_method<set_position_sig>(transform, "set_position", 1);
        get_parent_internal = il2utils::get_method<get_parent_sig>(transform, "get_parent", 0);
        component_get_game_object_internal = il2utils::get_method<component_get_game_object_sig>(
            component, "get_gameObject", 0);
        world_to_screen_point_internal = il2utils::get_method<world_to_screen_point_sig>(
            camera, "WorldToScreenPoint", 1);
        if (!world_to_screen_point_internal)
            world_to_screen_point_internal = il2utils::get_method<world_to_screen_point_sig>(
                camera, "WorldToScreenPoint", 2);
        camera_get_current_internal = il2utils::get_method<camera_get_current_sig>(camera, "get_current", 0);

        // Unity 2021+ / EFT 46221: get_allCamerasCount + GetAllCameras(Camera[]).
        // Legacy get_allCameras (Camera[]) was removed — probe silently, no WARN on miss.
        camera_get_all_count_internal = il2utils::get_method<camera_get_all_count_sig>(
            camera, "get_allCamerasCount", 0);
        camera_get_all_fill_internal = il2utils::get_method<camera_get_all_fill_sig>(
            camera, "GetAllCameras", 1);
        camera_get_all_internal = il2utils::get_method<camera_get_all_sig>(
            camera, "get_allCameras", 0, /*log_fail=*/false);
        if (!camera_get_all_internal && !camera_get_all_fill_internal)
            logger::warn("Camera all-cameras API missing (legacy get_allCameras and GetAllCameras both failed)");

        if (enumerable)
            enumerable_to_array_internal = il2utils::get_method<enumerable_to_array_sig>(enumerable, "ToArray", 1);

        transform_type = il2utils::get_system_type(unity_engine, "UnityEngine", "Transform");
        if (!transform_type)
            logger::error("Unity init failed: System.Type for Transform is null (type_get_object?)");

        const int ok = (find_objects_of_type_internal ? 1 : 0)
            + (get_position_internal ? 1 : 0)
            + (component_get_game_object_internal ? 1 : 0)
            + (camera_get_current_internal ? 1 : 0);
        if (ok < 3)
        {
            logger::error("Unity init incomplete — method resolve still broken (get_method_from_name?)");
            return false;
        }

        logger::info("Unity methods resolved (" + std::to_string(ok) + "/4 core OK)");
        return true;
    }

    inline Il2CppObject** find_objects_of_type(Il2CppObject* type, _Out_ size_t* amount,
        bool include_inactive = false) {
        *amount = 0;
        if (!type) return nullptr;

        // Prefer the classic 1-arg FindObjectsOfType(Type) path used by 46010 Quest ESP —
        // it is the most reliable on EFT IL2CPP. Only use the 2-arg includeInactive overload
        // when requested AND it actually returns a valid array; otherwise fall back.
        Il2CppArray* array = nullptr;

        if (include_inactive && find_objects_of_type_inc_internal)
            array = find_objects_of_type_inc_internal(type, true);

        if (!array && find_objects_of_type_internal)
            array = find_objects_of_type_internal(type);

        if (!array && find_objects_of_type_inc_internal)
            array = find_objects_of_type_inc_internal(type, include_inactive);

        if (!array)
            return nullptr;

        *amount = array->max_length;
        return reinterpret_cast<Il2CppObject**>(&array->data);
    }

    inline Il2CppObject* find_object_of_type(Il2CppObject* type) {
        return (type && find_object_of_type_internal) ? find_object_of_type_internal(type) : nullptr;
    }

    inline std::string get_name(Il2CppObject* object) {
        if (!object || !get_name_internal) return {};
        Il2CppString* name = get_name_internal(object);
        return il2utils::conv_string(name);
    }

    // Byte length of `s`, or npos when it is not pure ASCII. An ASCII needle is
    // what makes the two helpers below able to compare against Il2CppString's own
    // UTF-16 in place: UTF-8 encodes every ASCII code point as that single byte,
    // so byte-for-byte against UTF-16 code units is the same string.
    inline size_t ascii_len_or_not(const char* s) {
        size_t n = 0;
        for (; s[n] != '\0'; ++n)
            if (static_cast<unsigned char>(s[n]) >= 0x80) return static_cast<size_t>(-1);
        return n;
    }

    // name_equals / name_contains: name comparison that allocates nothing.
    //
    // get_name() goes through il2utils::conv_string, which is conv_wstring then
    // wide_to_utf8 -- two heap allocations and a WideCharToMultiByte() call pair,
    // per object. find_camera_if() calls it on EVERY camera in the scene, so a
    // "find the camera called X" used to cost one conversion per camera per call,
    // on a path the aimbot runs per candidate per frame. These compare the UTF-16
    // in place instead: no allocation, no conversion, no Win32 call.
    //
    // A non-ASCII needle falls back to the converting comparison rather than
    // comparing wrongly, so these are correct for every input and not only for
    // the ASCII literals every current caller happens to pass.
    //
    // Third site of this shape. The first was
    // aimbot_bones::get_skeleton_suffix_pos (AimbotModule.h), which converted
    // every rig-dictionary key to std::string purely to substring-test it.
    inline bool name_equals(Il2CppObject* object, const char* name) {
        if (!object || !get_name_internal || !name) return false;
        Il2CppString* s = get_name_internal(object);
        if (!s || s->length <= 0) return *name == '\0';
        const size_t n = ascii_len_or_not(name);
        if (n != static_cast<size_t>(-1) && static_cast<size_t>(s->length) == n) {
            for (int i = 0; i < s->length; ++i)
                if (static_cast<unsigned char>(name[i])
                    != static_cast<unsigned char>(s->chars[i]))
                    return false;
            return true;
        }
        return il2utils::conv_string(s) == std::string(name);
    }

    inline bool name_contains(Il2CppObject* object, const char* fragment) {
        if (!object || !get_name_internal || !fragment || *fragment == '\0')
            return false;
        Il2CppString* s = get_name_internal(object);
        if (!s || s->length <= 0) return false;
        const size_t n = ascii_len_or_not(fragment);
        if (n != static_cast<size_t>(-1) && static_cast<size_t>(s->length) >= n) {
            const int limit = s->length - static_cast<int>(n);
            for (int start = 0; start <= limit; ++start) {
                size_t k = 0;
                while (k < n && static_cast<unsigned char>(fragment[k])
                    == static_cast<unsigned char>(s->chars[start + static_cast<int>(k)]))
                    ++k;
                if (k == n) return true;
            }
            return false;
        }
        return il2utils::conv_string(s).find(fragment) != std::string::npos;
    }

    inline vector3 transform_get_pos(Il2CppObject* transform) {
        return (transform && get_position_internal) ? get_position_internal(transform) : vector3{};
    }

    inline void transform_set_pos(Il2CppObject* transform, vector3 pos) {
        if (set_position_internal) set_position_internal(transform, pos);
    }

    inline Il2CppObject* transform_get_parent(Il2CppObject* transform) {
        if (!transform || !get_parent_internal) return nullptr;
        return get_parent_internal(transform);
    }

    inline Il2CppObject* component_get_game_object(Il2CppObject* component) {
        return (component && component_get_game_object_internal) ? component_get_game_object_internal(component) : nullptr;
    }

    inline Il2CppObject* gameobject_get_transform(Il2CppObject* game_object) {
        return (game_object && transform_type && get_component_internal)
            ? get_component_internal(game_object, transform_type)
            : nullptr;
    }

    inline Il2CppObject* gameobject_get_component(Il2CppObject* game_object, Il2CppObject* system_type) {
        return (game_object && system_type && get_component_internal)
            ? get_component_internal(game_object, system_type)
            : nullptr;
    }

    inline vector3 world_to_screen_point(Il2CppObject* camera_inst, vector3 pos) {
        return (camera_inst && world_to_screen_point_internal)
            ? world_to_screen_point_internal(camera_inst, pos)
            : vector3{};
    }

    // Memoised managed-method pointer, keyed on (class, name).
    //
    // A MethodInfo's methodPointer is fixed for the process lifetime, exactly like the
    // FieldInfo offsets the project already caches in eft_api::cached_field. Keying on
    // the CLASS matters: the ESP alternates between FPS Camera and BaseOpticCamera
    // subclasses, and a cache keyed on name alone would hand back the wrong class's
    // method.
    //
    // Only successes are cached, so a class that is not yet initialised resolves again
    // later rather than being frozen out. NOT thread-safe, and for THIS map a torn
    // entry really can only cost a re-resolve, because the value is a method pointer
    // that is fixed for the process lifetime.
    //
    // The same argument does NOT hold for eft_api::cached_field, which used to be
    // cited here as the precedent: its value is a FieldInfo, so a torn entry can hand
    // back an offset belonging to a DIFFERENT class, and the caller then reads or
    // writes `object + foreign_offset`. It is unsynchronised too, and now reachable
    // from more than one thread since the ESP path split. Treat that one as a real
    // data race, not a benign one.
    inline std::mutex& method_cache_mutex() {
        static std::mutex m;
        return m;
    }

    template <typename T>
    inline T cached_method(const Il2CppClass* clazz, const char* name, int args) {
        static std::unordered_map<std::string, T> cache;
        const std::string key = std::to_string(reinterpret_cast<uintptr_t>(clazz)) + "." + name;
        {
            std::lock_guard<std::mutex> lock(method_cache_mutex());
            if (const auto it = cache.find(key); it != cache.end()) return it->second;
        }
        T fn = il2utils::get_method<T>(clazz, name, args);
        if (fn)
        {
            std::lock_guard<std::mutex> lock(method_cache_mutex());
            cache.emplace(key, fn);
        }
        return fn;
    }

    // These three are called PER PROJECTED POINT from world_to_screen_optic's fallback
    // path. Uncached, each one did a name-based il2cpp_class_get_method_from_name walk
    // (twice, because get_method retries with argc=-1 on failure) -- so two strcmp walks
    // of the method table per point per frame. That is the 1x-only stutter reported
    // 2026-09-26: at 1x the whole screen is in view and every ESP point pays it, while
    // at 4x the scope picture shows a small area and far fewer points are drawn.
    inline int camera_pixel_height(Il2CppObject* camera_inst) {
        if (!camera_inst || !camera_inst->klass) return 0;
        const auto fn = cached_method<int (*)(Il2CppObject*)>(
            camera_inst->klass, "get_pixelHeight", 0);
        return fn ? fn(camera_inst) : 0;
    }

    inline int camera_pixel_width(Il2CppObject* camera_inst) {
        if (!camera_inst || !camera_inst->klass) return 0;
        const auto fn = cached_method<int (*)(Il2CppObject*)>(
            camera_inst->klass, "get_pixelWidth", 0);
        return fn ? fn(camera_inst) : 0;
    }

    // ---------------------------------------------------------------------------
    // camera_fov's resolve-miss diagnostic -- added 2026-10-14.
    //
    // The crash this file carries (2026-10-04 21:24:50, execute at 0x0) was
    // diagnosed to `camera_fov` calling through a null resolver, and fixed. What
    // was NEVER explained is why the resolve missed: the log line said
    // `get_method FAILED: Int32::get_fieldOfView args=0`, and `Int32` is not a
    // camera class. So the class the instance reported was itself wrong, which
    // points at a bad `klass` pointer rather than a missing method -- and that
    // is a different bug with a different fix. Two candidates were recorded and
    // neither was distinguished: the derived class's method table, or teardown
    // of the optic camera while its packet was being rebuilt.
    //
    // This answers it on the next miss, without a raid planned around it:
    //   * instance and klass readability (ReadProcessMemory-shaped, cannot fault)
    //   * the class name and its ANCESTOR chain, so "the klass pointer is
    //     garbage" and "the method table lacks it" are different lines
    //   * how many ancestors DO resolve get_fieldOfView -- if Camera resolves
    //     and the instance's class does not, the pointer is wrong; if none do,
    //     the method table itself is the question
    //
    // The whole thing is on the MISS path only, which is why the detail is
    // affordable: a miss re-resolves on every call (cached_method deliberately
    // does not cache a null), so the log volume of these lines IS the answer to
    // "is a miss common" -- no new counter needed for that.
    // ---------------------------------------------------------------------------
    inline void camera_fov_resolve_miss(Il2CppObject* camera_inst) {
        const bool inst_ok = pe_resource::probe_readable(camera_inst, sizeof(void*));
        const void* klass = inst_ok ? camera_inst->klass : nullptr;
        const bool klass_ok = pe_resource::probe_readable(klass, sizeof(Il2CppClass));

        std::string chain;
        int ancestors_with_method = 0;
        int ancestors = 0;
        if (klass_ok) {
            for (const Il2CppClass* cur = static_cast<const Il2CppClass*>(klass);
                 cur && ancestors < 8 && pe_resource::probe_readable(cur, sizeof(Il2CppClass));
                 cur = cur->parent) {
                const char* nm = cur->name;
                if (!chain.empty()) chain += " <- ";
                chain += (nm && pe_resource::probe_readable(nm, 1)) ? nm : "<unreadable>";
                ++ancestors;
                // log_fail=false: the caller's own WARN has already fired once;
                // this loop is a survey and must not repeat it per ancestor.
                if (il2utils::resolve_method(cur, "get_fieldOfView", 0))
                    ++ancestors_with_method;
            }
        }

        logger::warn(std::string("camera-fov-miss: inst=")
            + (camera_inst ? std::to_string(reinterpret_cast<uintptr_t>(camera_inst)) : "null")
            + " inst_readable=" + (inst_ok ? "1" : "0")
            + " klass=" + (klass ? std::to_string(reinterpret_cast<uintptr_t>(klass)) : "null")
            + " klass_readable=" + (klass_ok ? "1" : "0")
            + " class=" + (chain.empty() ? std::string("<unreadable>") : chain)
            + " ancestors=" + std::to_string(ancestors)
            + " ancestors_resolving_get_fieldOfView=" + std::to_string(ancestors_with_method)
            + ". If ancestors_resolving is 0 but the class chain reads as a camera "
              "hierarchy, the METHOD TABLE is the question; if the chain does not "
              "read as a camera at all, the KLASS POINTER is, and the object was "
              "already being torn down when this ran.");
    }

    inline float camera_fov(Il2CppObject* camera_inst) {
        // WAS: return inst.get_method<float (*)(Il2CppObject*)>("get_fieldOfView", 0)(camera_inst);
        //
        // That is a call through whatever get_method returned, and get_method returns nullptr
        // when the method is not found -- so a miss is an immediate call to address 0. This is
        // not theoretical: on 2026-10-04 21:24:58 this exact line killed the process.
        // `operation 8, execute at 0x0` on the thread that had just logged
        //   optic-packet: invalid at [lens mask polygon empty after clip]
        //   get_method FAILED: Int32::get_fieldOfView args=0
        // which is this resolver failing and the next instruction calling through it. The
        // only `get_method FAILED` line in the whole session, immediately before the crash.
        //
        // Written the way camera_pixel_width and camera_pixel_height above already are, which
        // is what makes the omission here visible: those two resolve into a local and test it.
        // (`camera_aspect` was named here until 2026-10-13, when the last unreferenced
        // quaternion/camera surface from the optics rework was deleted -- the pixel pair is the
        // live example of the same shape.)
        if (!camera_inst || !camera_inst->klass) return 0.f;
        const auto fn = cached_method<float (*)(Il2CppObject*)>(
            camera_inst->klass, "get_fieldOfView", 0);
        if (!fn) {
            // The one detail the original crash log could not give, recorded
            // here rather than left to infer from the next minidump.
            camera_fov_resolve_miss(camera_inst);
            return 0.f;
        }
        return fn(camera_inst);
    }

    inline Il2CppObject* get_current_camera() {
        return camera_get_current_internal ? camera_get_current_internal() : nullptr;
    }

    // Enumerate all cameras; predicate receives Camera* and returns true to stop.
    //
    // find_camera_if_best is the general form: it scans the SAME single enumeration and
    // ranks whatever `pred` accepts by `score`, lowest wins. `out_count`, when given,
    // receives how many candidates passed `pred` -- which is how a caller learns that a
    // name it thought was unique matched more than once.
    //
    // Scoring every candidate is only worth the extra work when the caller can actually
    // rank them, so the caller supplies a score that is constant when it has nothing to
    // compare against; a constant score makes every later candidate lose the strict `<`,
    // which reproduces find_camera_if's first-match-wins exactly.
    template <typename Pred, typename Score>
    inline Il2CppObject* find_camera_if_best(Pred pred, Score score, int* out_count = nullptr) {
        if (out_count) *out_count = 0;
        Il2CppObject* best = nullptr;
        float best_score = 0.f;

        auto scan = [&](Il2CppArray* arr) {
            if (!arr) return;
            for (size_t i = 0; i < arr->max_length; ++i)
            {
                Il2CppObject* cam = reinterpret_cast<Il2CppObject**>(&arr->data)[i];
                if (!cam || !pred(cam)) continue;
                if (out_count) ++*out_count;
                const float s = score(cam);
                if (!best || s < best_score) { best = cam; best_score = s; }
            }
        };

        if (camera_get_all_internal) { scan(camera_get_all_internal()); return best; }

        if (!camera || !camera_get_all_count_internal || !camera_get_all_fill_internal)
            return nullptr;

        const int count = camera_get_all_count_internal();
        if (count <= 0) return nullptr;

        Il2CppArray* arr = il2cpp::il2cpp_array_new(const_cast<Il2CppClass*>(camera),
            static_cast<size_t>(count));
        if (!arr) return nullptr;

        camera_get_all_fill_internal(arr);
        scan(arr);
        return best;
    }

    template <typename Pred>
    inline Il2CppObject* find_camera_if(Pred pred) {
        return find_camera_if_best(pred, [](Il2CppObject*) { return 0.f; });
    }

    inline Il2CppObject* get_named_camera(const char* name) {
        // Compared per camera in find_camera_if, so the needle must not be
        // rebuilt inside the predicate.
        return find_camera_if([&](Il2CppObject* cam) {
            return name_equals(cam, name);
        });
    }

    inline Il2CppObject* find_camera_name_contains(const char* fragment) {
        if (!fragment || !*fragment) return nullptr;
        return find_camera_if([&](Il2CppObject* cam) {
            return name_contains(cam, fragment);
        });
    }

    inline Il2CppArray* enumerable_to_array(Il2CppObject* enumerable) {
        return (enumerable && enumerable_to_array_internal) ? enumerable_to_array_internal(enumerable) : nullptr;
    }

    inline int transform_get_child_count(Il2CppObject* transform) {
        // The same call-through-null as camera_fov above; see the comment there. These three
        // are its siblings and were written the same wrong way.
        //
        // 2026-10-06: the fail-closed 0 is INDISTINGUISHABLE from a leaf node, so a resolve
        // miss silently empties every walk that counts children -- transform_apply_to_all_children
        // below, and IcebreakerScenarioModule's cutscene pruning. It fails by doing nothing,
        // with no log and no counter. That is worse than the crash it replaced: a crash is
        // visible, a silent empty walk looks like "there was nothing there".
        //
        // A null `transform` is a normal early-out (callers check), so it stays silent. A
        // non-null transform whose RESOLVE misses is not normal and is now reported, because
        // the two are different situations that 0 conflates. WARN not ERROR: get_method already
        // logs the miss, and this says which consumer ate it. Per-frame callers exist, so this
        // is deliberately NOT an unconditional per-call logger -- get_method's own warn is
        // already per-call, so adding a second doubles the flood on a broken build.
        if (!transform) return 0;
        if (!transform->klass) return 0;
        const auto fn = cached_method<int (*)(Il2CppObject*)>(
            transform->klass, "get_childCount", 0);
        if (!fn)
        {
            logger::warn("transform_get_child_count: get_childCount did not resolve on "
                         + std::string(transform->klass->name ? transform->klass->name : "?")
                         + " -- reporting 0 children, which a caller cannot distinguish"
                           " from a leaf node");
            return 0;
        }
        return fn(transform);
    }

    inline Il2CppObject* transform_get_child(Il2CppObject* transform, const int index) {
        if (!transform || !transform->klass) return nullptr;
        const auto fn = cached_method<Il2CppObject* (*)(Il2CppObject*, int)>(
            transform->klass, "GetChild", 1);
        return fn ? fn(transform, index) : nullptr;
    }

    inline Il2CppObject* transform_get_game_object(Il2CppObject* transform) {
        // get_gameObject specifically is the method at the centre of the 2026-10-03/04 exfil
        // crashes -- there it resolved fine and threw, because the COMPONENT was destroyed.
        // This null check is not about that; it is about the resolver missing entirely.
        if (!transform || !transform->klass) return nullptr;
        const auto fn = cached_method<Il2CppObject* (*)(Il2CppObject*)>(
            transform->klass, "get_gameObject", 0);
        return fn ? fn(transform) : nullptr;
    }

    inline void transform_apply_to_all_children(Il2CppObject* transform, const std::function<void(Il2CppObject*)>& func) {
        for (int i = 0; i < transform_get_child_count(transform); ++i)
        {
            Il2CppObject* child = transform_get_child(transform, i);
            transform_apply_to_all_children(child, func);
            func(child);
        }
    }

    // Native liveness of a UnityEngine.Object (Shader / Material / Texture /
    // AssetBundle). The managed wrapper can stay allocated while the native side
    // is already gone — scene unload + Resources.UnloadUnusedAssets after a
    // transit zeroes m_CachedPtr (field on UnityEngine.Object, so resolve_field
    // finds it on any leaf class via the parent walk). A dead wrapper pointer is
    // exactly what makes set_shader() fall back to Unity's magenta error shader.
    // We cannot rely on is_il2cpp_object_likely_valid() here: it only checks the
    // managed klass, not whether the native object is still alive.
    // ---------------------------------------------------------------- native-object memo
    //
    // WHY. The 2026-10-01 12-minute capture (tracy_traces/current.tracy) measured this
    // function at 48.0 s over 44,009 calls -- 6.50% of wall clock, 1.09 ms PER CALL. It was
    // also the real explanation for the ~1 ms/frame of unexplained self time in
    // hk_tarkov_application_update, which an earlier diagnosis wrongly attributed to the
    // game's own Update. One VirtualQuery per frame, for 12 minutes, on a pointer that
    // changes a handful of times per session.
    //
    // 1.09 ms for one VirtualQuery is the same anomaly the string path showed (46.7 us
    // there, and ~207 us recorded elsewhere in this codebase), and it is why removing the
    // call matters more than making it cheaper.
    //
    // NOT the string memo, and deliberately so. That table caches IL2CPP MANAGED heap
    // regions; this checks a NATIVE Unity object, which lives in a different address
    // space. Sharing one table would have the two working sets evict each other for no
    // gain, and unity.h cannot call into eft_api.h anyway -- eft_api.h includes unity.h,
    // so the dependency only runs one way. A local memo is both the only option and the
    // right one.
    //
    // KEYED ON THE POINTER, not the region, and this is not the same trade as the string
    // memo. Here the answer is almost always "alive" for a pointer that does not change,
    // so the question is "have I verified THIS pointer recently", not "is this address
    // inside a region I have seen". The second question is what the string memo asks and
    // is not what this function needs to know.
    //
    // THE TTL IS WHAT KEEPS IT SOUND. `m_CachedPtr` is already checked every call and is
    // what Unity zeroes on a transit, so the common death path never reaches the
    // VirtualQuery at all. The syscall is here for the rarer case -- a live managed
    // wrapper whose native object is gone -- and a memo with no expiry would stop
    // noticing that forever. So the memo is re-verified every kNativeMemoTtlCalls
    // invocations, which bounds how long a stale "alive" can survive. At 64 that is one
    // second at 60 fps, and the chams self-heal this exists to drive recovers from a
    // transit in well under that. A pointer change also invalidates immediately, for free.
    inline constexpr unsigned kNativeMemoTtlCalls = 64;
    // HOW MANY ENTRIES, which is not the same question as the TTL. Two callers reach this:
    //
    //   - asset_bundles::is_asset_bundle_valid(), once per frame on ONE pointer. A single
    //     entry is perfect for it, and that is the call that cost 48.0 s.
    //   - ChamsModule::load_item_chams_shader, which looks up an item_shader_cache_ keyed
    //     by shader type_id. Several DIFFERENT shaders alternate, so a one-entry memo would
    //     miss every time and would make that call site slower, not faster.
    //
    // So it is a small direct-mapped table. 16 entries is far more than the bundle path
    // needs and enough to stop the shader cache thrashing; it costs 16 x 24 bytes.
    inline constexpr size_t kNativeMemoSlots = 16;

    struct native_object_memo {
        const void* ptr = nullptr;     // the native pointer that was verified
        unsigned long long stamp = 0;  // call count when it was verified
    };
    inline native_object_memo (&native_memo_slots())[kNativeMemoSlots] {
        static native_object_memo m[kNativeMemoSlots]{};
        return m;
    }
    // Same Fibonacci-high-bits shape as the string memo, because the same reasoning applies
    // to both: multiply by 2^64/phi and keep the high bits, then MASK. The mask is not
    // decorative -- an unmasked 32-bit shift indexes a 16-entry array with a number up to
    // 4,294,967,295, which is an out-of-bounds write.
    inline size_t native_memo_index(uintptr_t ptr) {
        static_assert((kNativeMemoSlots & (kNativeMemoSlots - 1)) == 0,
            "the mask below is only valid for a power-of-two table");
        return static_cast<size_t>((ptr * 11400714819323198485ull) >> 32) & (kNativeMemoSlots - 1);
    }
    struct native_object_counters {
        unsigned long long hits = 0;
        unsigned long long misses = 0;
        unsigned long long revalidations = 0;
    };
    inline native_object_counters& native_object_stats() {
        static native_object_counters c{};
        return c;
    }
    inline native_object_counters drain_native_object_stats() {
        auto& c = native_object_stats();
        native_object_counters out;
        out.hits = c.hits;             c.hits = 0;
        out.misses = c.misses;         c.misses = 0;
        out.revalidations = c.revalidations; c.revalidations = 0;
        return out;
    }
    // CALLED ONLY from the gated sites. See the note at the memo hit: the throttle has to be
    // enforced by the CALLER's cheap counter, because nothing inside this function can
    // un-evaluate the arguments it is passed.
    //
    // The clock check is kept as well, and the two are ANDed rather than either/or: the
    // caller's counter bounds how OFTEN this is entered, and this clock bounds how often
    // it actually PRINTS. Without the second, a caller that gates every call would
    // drain-and-print at its own cadence instead of every 30 s, which is a log-rate
    // change nobody asked for.
    inline void maybe_report_native_object_memo() {
        static auto s_last = std::chrono::steady_clock::now();
        constexpr long long kDumpMs = 30000;
        const auto now = std::chrono::steady_clock::now();
        if (now - s_last < std::chrono::milliseconds(kDumpMs)) return;
        s_last = now;
        const auto c = drain_native_object_stats();
        const auto total = c.hits + c.misses;
        if (total < 1000) return;
        const double rate = 100.0 * static_cast<double>(c.hits) / static_cast<double>(total);
        logger::debug(std::format(
            "unity-memo: hit/miss={}/{} ({:.2}%) revalidations={} -- revalidations per miss should"
            " track 1/{}; a rising miss rate means the TTL is too long for how fast pointers change",
            c.hits, c.misses, rate, c.revalidations, kNativeMemoTtlCalls));
    }

    // The liveness check, memoised.
    //
    // Zoned because this was a third raw VirtualQuery invisible to
    // eft_api::is_readable_address and its probe_scoped counters, and because the profile
    // number above is what justified memoising it.
    // `site` is a caller label that becomes part of the zone's identity, so each
    // caller gets its OWN ROW in the export rather than one row with a moving
    // label. Pass a small fixed literal; nullptr means "no attribution", which
    // is why the parameter defaults rather than being required.
    //
    // WHY THIS PARAMETER EXISTS -- 2026-10-05. The profile said this function
    // cost 40.1 s over 100,122 calls, and that number was almost entirely
    // misleading:
    //
    //     mean 400,503 ns   median 110 ns   p90 1.79 ms   p99 2.54 ms   sd 740,685 ns
    //
    // The median call is 110 ns, which is what the comment further down already
    // said a memo hit costs ("a compare and a return") -- so the code is fine and
    // the MEAN was the artefact. Standard deviation exceeds the mean, the bottom
    // half of all calls contribute under 0.006 s of the 40.1 s, and the top 10%
    // (each >= 1.79 ms) contribute at least 18.0 s. It is a tail in a few hundred
    // calls, not a per-call cost.
    //
    // A flat row cannot answer "which caller", and the export has no call tree,
    // so the only ways to attribute are a runtime zone name or inferring from
    // max_ns equality. Hence this parameter. The prior is that the tail is the
    // chams shader path -- the memo is a 16-entry direct-mapped table and
    // `load_item_chams_shader` cycles several DIFFERENT shader pointers through
    // it -- but that is a guess that agrees with what I want to find, so it is
    // recorded here as a hypothesis to be measured, not as a conclusion.
    inline bool is_unity_object_alive(Il2CppObject* obj, const char* site = nullptr) {
        // TA_ZONE_SITE expands to `do {} while (0)` when the profiler is compiled out,
        // which leaves `site` unreferenced in that arm. Harmless, but it is an unused-
        // parameter warning in a header this widely included, so name it deliberately.
        (void)site;
        TA_ZONE_SITE("unity::is_unity_object_alive", site);
        if (!obj || !obj->klass) return false;

        // m_CachedPtr lives on UnityEngine.Object and every Unity object we pass
        // here derives from it, so the offset is stable — cache it once.
        static int32_t cached_offset = -1;
        if (cached_offset == -1)
        {
            const FieldInfo* f = il2utils::resolve_field(obj->klass, "m_CachedPtr");
            cached_offset = (f && f->offset > 0) ? f->offset : 0;
        }
        if (cached_offset <= 0) return false;

        void* cached_ptr = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(obj) + cached_offset);
        if (!cached_ptr) return false;

        auto& st = native_object_stats();
        native_object_memo& memo = native_memo_slots()[native_memo_index(reinterpret_cast<uintptr_t>(cached_ptr))];
        const auto now_stamp = st.hits + st.misses;
        // A different pointer in this slot, or an expired entry, must go to the syscall. The
        // expiry is what stops a memo from outliving the fact it recorded.
        const bool same_pointer = memo.ptr == cached_ptr;
        const bool expired = now_stamp - memo.stamp >= kNativeMemoTtlCalls;
        if (same_pointer && !expired) {
            st.hits += 1;
            // THE THROTTLE IS THE BUG, and it was invisible because it was never zoned.
            //
            // maybe_report_native_object_memo() called std::format on EVERY hit. It
            // looks guarded -- it early-returns unless 30 s have passed -- but
            // std::format's ARGUMENTS are evaluated at the call site, so the
            // `std::to_string`-free but still non-trivial argument work happened on all
            // 140,875 calls, not on the ~9 that print. That is the WORKFLOW.md
            // "per-frame logging costs real time" note, and this function is called
            // per-frame from several sites.
            //
            // The zone says 460 us mean with a 98% memo hit rate, which is two numbers
            // that cannot both be right: a memo hit is a compare and a return. The zone's
            // own comment claimed the profile number "justified memoising this", so
            // nobody re-read it after the fact.
            //
            // Fix: gate the throttle on the cheap counter FIRST, and only then read the
            // clock. `st.hits` is already being incremented, so the guard costs one
            // relaxed load and no syscall, no chrono read, and no formatting -- and it
            // only has to be conservative: the report is a diagnostic, so checking every
            // 4096 calls means it prints at most a few times a minute rather than never.
            //
            // Deliberately NOT `if (TA_ZONE_IS_ACTIVE)`: that would couple a correctness
            // fix to whether a profiler happens to be attached, and the cost is real
            // whether or not anyone is listening.
            constexpr unsigned long long kReportEvery = 4096;
            if ((st.hits % kReportEvery) == 0) maybe_report_native_object_memo();
            return true;
        }
        if (same_pointer) st.revalidations += 1;
        st.misses += 1;

        // The native object must live in committed, readable memory.
        MEMORY_BASIC_INFORMATION mbi{};
        const bool alive = VirtualQuery(cached_ptr, &mbi, sizeof(mbi))
            && mbi.State == MEM_COMMIT
            && !(mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD));
        // A failed check must NOT be remembered as an answer. Storing "dead" would be the
        // one thing that makes the memo actively wrong: a dead shader would be cached as
        // dead forever and the chams self-heal that depends on this would never fire. The
        // pointer is nulled so the next call re-probes.
        if (!alive) {
            memo.ptr = nullptr;
            return false;
        }
        memo.ptr = cached_ptr;
        memo.stamp = now_stamp;
        // Same counter gate as the hit path above, for the same reason. This is the
        // MISS path, so it runs orders of magnitude less often -- but "less often" is
        // not "never", and the argument-evaluation cost is identical per call.
        constexpr unsigned long long kReportEvery = 4096;
        if ((st.misses % kReportEvery) == 0) maybe_report_native_object_memo();
        return true;
    }
} // namespace unity
