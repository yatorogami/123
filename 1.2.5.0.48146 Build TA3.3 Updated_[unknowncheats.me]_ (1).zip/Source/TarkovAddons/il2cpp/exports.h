#pragma once
#include "il2cpp_offsets.h"
#include "libil2cpp/il2cpp-class-internals.h"
#include "libil2cpp/il2cpp-object-internals.h"
#include "libil2cpp/il2cpp-api-types.h"

namespace il2cpp {
    inline Il2CppClass* il2cpp_class_from_name(
        const Il2CppImage* image, const char* namespaze, const char* name) {
        return reinterpret_cast<Il2CppClass* (*)(const Il2CppImage*, const char*, const char*)>(
            il2cpp_offsets::il2cpp_class_from_name)(image, namespaze, name);
    }

    inline Il2CppClass* il2cpp_class_get_nested_types(
        Il2CppClass* klass, void** iter) {
        return reinterpret_cast<Il2CppClass* (*)(Il2CppClass*, void**)>(
            il2cpp_offsets::il2cpp_class_get_nested_types)(klass, iter);
    }

    inline FieldInfo* il2cpp_class_get_field_from_name(
        Il2CppClass* klass, const char* name) {
        return reinterpret_cast<FieldInfo* (*)(Il2CppClass*, const char*)>(
            il2cpp_offsets::il2cpp_class_get_field_from_name)(klass, name);
    }

    inline const MethodInfo* il2cpp_class_get_method_from_name(Il2CppClass* klass, const char* name, int argsCount) {
        if (!klass || !il2cpp_offsets::il2cpp_class_get_method_from_name)
            return nullptr;
        // The pattern resolves the UNWRAPPED body, not the exported wrapper. The
        // export reaches it through a forwarding stub, measured on 1.1.5.1.47510
        // (the GameAssembly.dll in TarkovAddons/GameDump/115147510_tarkov-dump):
        //   sub_18033A2B0:  xor r9d, r9d ; jmp sub_180208CF0
        // so the stub zeroes r9 before jumping. Body entry, as IDA has it:
        //   0x208CF0  sub_180208CF0  193 bytes
        //   mov ebp, r9d   ; flag mask (wrapper always xor r9d,r9d before call)
        //   mov edi, r8d   ; argsCount
        //   mov r14, rdx   ; name
        //   mov rsi, rcx   ; klass
        // If r9 is garbage, the (method.flags & mask) == mask check never matches → null.
        // 4th arg must be 0 (same as game wrapper trampoline).
        // The old comment here cited "@ 0x33CCF0 (46221)", which was correct for
        // that build and misleading for every later one: the RVA moves per build,
        // which is the whole reason this resolves by pattern. Do not paste an
        // address in here as if it were stable -- read it off the live module.
        return reinterpret_cast<MethodInfo* (*)(Il2CppClass*, const char*, int, int)>(
            il2cpp_offsets::il2cpp_class_get_method_from_name)(
            klass, name, argsCount, 0);
    }

    inline const Il2CppType* il2cpp_class_get_type(Il2CppClass* klass) {
        if (!klass)
            return nullptr;
        // byval_arg is at +0x20 on 46221 (image, gc_desc, name, namespaze).
        // PE export il2cpp_class_get_type is a 2-arg checker wrapper — avoid it.
        return reinterpret_cast<Il2CppType*>(reinterpret_cast<UINT64>(klass) + 0x20); // NOLINT(performance-no-int-to-ptr)
    }

    inline Il2CppDomain* il2cpp_domain_get() {
        return reinterpret_cast<Il2CppDomain* (*)()>(il2cpp_offsets::il2cpp_domain_get)();
    }

    inline const Il2CppAssembly** il2cpp_domain_get_assemblies(
        const Il2CppDomain* domain, size_t* size) {
        return reinterpret_cast<const Il2CppAssembly** (*)(const Il2CppDomain*, size_t*)>(
            il2cpp_offsets::il2cpp_domain_get_assemblies)(domain, size);
    }

    inline void il2cpp_field_static_get_value(
        FieldInfo* field, void* value) {
        if (!field || !il2cpp_offsets::il2cpp_field_static_get_value)
            return;
        // REAL body is 2-arg (field, value). Export wrapper requires non-null r8.
        return reinterpret_cast<void (*)(FieldInfo*, void*)>(
            il2cpp_offsets::il2cpp_field_static_get_value)(field, value);
    }

    inline void il2cpp_field_static_set_value(FieldInfo* field, void* value) {
        return reinterpret_cast<void (*)(FieldInfo*, void*)>(
            il2cpp_offsets::il2cpp_field_static_set_value)(field, value);
    }

    inline Il2CppString* il2cpp_string_new(const char* str) {
        return reinterpret_cast<Il2CppString* (*)(const char*)>(il2cpp_offsets::il2cpp_string_new)(str);
    }

    inline Il2CppObject* il2cpp_type_get_object(const Il2CppType* type) {
        return reinterpret_cast<Il2CppObject* (*)(const Il2CppType*)>(il2cpp_offsets::il2cpp_type_get_object)(type);
    }

    inline Il2CppObject* il2cpp_field_get_value_object(FieldInfo* field, Il2CppObject* obj, Il2CppType* type) {
        return reinterpret_cast<Il2CppObject* (*)(FieldInfo*, Il2CppObject*, Il2CppType*)>(
            il2cpp_offsets::il2cpp_field_get_value_object)(field, obj, type);
    }

    inline Il2CppArray* il2cpp_array_new(Il2CppClass* element_class, size_t length) {
        if (!element_class || !il2cpp_offsets::il2cpp_array_new)
            return nullptr;
        return reinterpret_cast<Il2CppArray* (*)(Il2CppClass*, size_t)>(
            il2cpp_offsets::il2cpp_array_new)(element_class, length);
    }

    inline Il2CppObject* il2cpp_object_new(const Il2CppClass* klass) {
        if (!klass || !il2cpp_offsets::il2cpp_object_new)
            return nullptr;
        return reinterpret_cast<Il2CppObject* (*)(const Il2CppClass*)>(
            il2cpp_offsets::il2cpp_object_new)(klass);
    }

    inline void il2cpp_runtime_class_init(Il2CppClass* klass) {
        if (!klass || !il2cpp_offsets::il2cpp_runtime_class_init)
            return;
        reinterpret_cast<void (*)(Il2CppClass*)>(
            il2cpp_offsets::il2cpp_runtime_class_init)(klass);
    }
} // namespace il2cpp
