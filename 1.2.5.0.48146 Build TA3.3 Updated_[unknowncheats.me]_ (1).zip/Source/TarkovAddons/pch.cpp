// Translation unit that builds the precompiled header.
//
// It exists only to carry the /Yc flag; the body is a single include. The
// content lives in include/common.h -- this file was called pch.cpp when the
// header was called pch.h, and kept its name so the vcxproj's
// <ClCompile Include="pch.cpp"><PrecompiledHeader>Create</...> entry survives
// the CMake conversion.
//
// PrecompiledHeaderFile is the bare "common.h", not a path: MSVC matches /Yu
// against the name in the flag rather than the resolved path, and all 82 TUs
// say #include "common.h" on line 1. See include/common.h for what is in the
// PCH and, more importantly, for what is deliberately kept out of it.
#include "common.h"