#include "common.h"
#include "common_hooks.h"
#include "../util/tracy_bridge.h"
#include "../util/crash_probe.h"
#include "footprint.h"

namespace common_hooks {

    // Consecutive failed reads of InGameStatus.InRaid before is_in_raid is forced false.
    // See the fail-closed note at the read site. 3 frames is ~50 ms at 60 fps: long
    // enough that a single dropped frame mid-raid does not blink every module off,
    // short enough that a teardown is caught well before the next overlay frame.
    inline constexpr int kRaidReadFailFrames = 3;

    // Function-scope state for that debounce. Reset whenever a read succeeds, so the
    // count can never accumulate across separate boundaries.
    inline int  s_raid_read_fail_frames      = 0;
    inline bool s_raid_read_failed_logged    = false;

    // Ratchet state. See the long note at the poll.
    //
    // s_poll_may_set_true: the poll's permission to set the flag TRUE. It has TWO writers
    // and both are required, which is what makes it a ratchet rather than a constant:
    //
    //   granted  by the poll, after kRaidFalseFrames CONSECUTIVE `InRaid == false` reads
    //   revoked  by on_local_raid_ended_event(), the moment the raid is known to be over
    //
    // Before 2026-10-04 15:40 only the grant existed, so the value was `true` from
    // start-up and never changed -- which made `set_in_raid(true)` effectively ungated
    // and let the flag come back 1.123 s after `Local Raid Ended`. See the event handler.
    //
    // Starts TRUE because at process start there is no raid, so there is nothing to
    // protect and the first poll reading `true` would be correct anyway.
    inline bool s_poll_may_set_true          = true;

    // Consecutive `InRaid == false` reads; reset by any `true` read and by the event.
    // Symmetric with kRaidReadFailFrames on purpose: one false frame during teardown is
    // not evidence the game has settled, and arming on it is how a stale `true` one tick
    // later becomes a live flag again.
    inline int  s_raid_false_frames          = 0;
    inline constexpr int kRaidFalseFrames = 10;

    // s_raid_end_event_seen: LocalRaidEnded fired and no poll has yet agreed. Purely so
    // the "the poll cleared it, no event was seen" line can distinguish the two cases
    // that both end in a false edge.
    inline bool s_raid_end_event_seen        = false;

    // The EVENT half of the false edge is defined OUTSIDE this namespace, as
    // game_state::on_local_raid_ended_event, because ItemModule.h cannot include
    // common_hooks.h (circular). It reaches in here for the one flag it needs.

} // namespace common_hooks

// The EVENT half of the false edge.
//
// Called at the very top of hk_local_raid_ended, before o_local_raid_ended runs and
// before any of our own logging, because the whole value of an event-driven edge is that
// it is earlier than the poll. Measured 2026-10-03 22:57:09.841: our own "Local Raid
// Ended" line is the last thing known to have executed before the process died, so this
// is as early as the flag can honestly be cleared.
void game_state::on_local_raid_ended_event() noexcept {
    common_hooks::s_raid_end_event_seen = true;
    // REVOKES the poll's permission to set the flag true. It must never ARM it -- that
    // is the bug the ratchet exists to prevent -- but "deliberately does NOT touch it"
    // was wrong, and provably so.
    //
    // A permission that is granted once and never taken away is not a ratchet. Measured
    // 2026-10-04: s_poll_may_set_true was initialised true and assigned true by the poll,
    // and assigned FALSE NOWHERE in the tree -- so after start-up it was the constant
    // `true`, `set_in_raid(true)` had no effective gate, and the comment 200 lines below
    // claiming "ratchet not armed, so it does nothing. The bug cannot recur" described a
    // protection the code did not contain. I wrote both the claim and the counterexample.
    //
    // The consequence, same session: `Local Raid Ended` at 15:29:05.396 cleared the flag;
    // the next poll that read `InRaid == true` set it back; and at 15:29:06.519, 1.123 s
    // later, `EspModule::draw_overlay` got past its `!is_in_raid` gate at :4667 and threw.
    // The ESP workstream's `scene_objects_live=false while is_in_raid is still true` warn
    // is that same window caught by instrumentation instead of inferred from a throw.
    //
    // The event is the only party that knows the raid is over, so it is the only party
    // that can take the permission away. Re-arming is the poll's job, and only after a
    // SUSTAINED false -- see kRaidFalseFrames at the poll.
    common_hooks::s_poll_may_set_true = false;
    common_hooks::s_raid_false_frames = 0;
    game_state::set_in_raid(false);
}

// The one writer for game_state::is_in_raid. See the declaration for the edge design.
//
// It owns the region-memo clears BECAUSE the flag and the memos must change together,
// and because the flag now has writers on two threads: hk_local_raid_ended (game thread)
// and the poll in hk_tarkov_application_update (also game thread, but a different call
// context), with readers on the render thread. Leaving the clears on a function-local
// `was_in_raid` in one of those would mean an event-driven edge missed them entirely.
bool game_state::set_in_raid(bool value) noexcept {
    // exchange, not a load-then-store: two writers racing on the same edge must
    // produce exactly one transition, not two, or the memos are cleared twice for one
    // boundary. The loser of the race sees its own value back and does nothing.
    if (is_in_raid.exchange(value, std::memory_order_relaxed) == value)
        return false;

    // Bound the region memos' lifetime to a transit.
    //
    // Both are VirtualQuery region caches over memory the game reuses. The IL2CPP GC
    // heap is committed for the process and never unmapped, but that argument does not
    // hold for a stack or a freed VirtualAlloc block -- a stale entry would trade a
    // syscall for a window in which a freed page reads as valid.
    //
    // eft_api: string-path lookups. optics::lens: the same trade on the same boundary,
    // for camera objects, component arrays and Transform chains -- all rebuilt by the
    // game on every transit, so un-cleared it answers "readable" from regions verified
    // against objects the PREVIOUS raid owned. That is not a fault; it is a silent read
    // of the wrong object, which is worse to diagnose than a crash.
    //
    // Correct in the worst case: clearing costs one VirtualQuery pair per probe until
    // the tables refill, which is exactly the pre-memo behaviour.
    eft_api::clear_probe_region_memo();
    optics::lens::clear_range_readable_table();
    return true;
}

namespace common_hooks {
    void hk_tarkov_application_update(Il2CppObject* instance) {
        // The frame boundary. With a Tracy client attached this is the outermost
        // zone in the mod, so the flame graph reads as one subtree per frame.
        //
        // Unlike the breadcrumb triple that used to live here, this is free when
        // no client is attached: tracy::profiler::Zone returns on !running()
        // before doing anything, and start() only happens from the "Start
        // Profiler" button. The breadcrumb was not free because logger::debug's
        // ARGUMENT was built by the caller -- three std::strings per frame
        // regardless of the toggle. A zone has no such argument.
        TA_ZONE_N("frame::hk_tarkov_application_update");

        // A per-frame "breadcrumb N begin / dispatching / done" triple used to
        // live here, to bisect which half of this function was faulting. It is
        // gone because it was not free: logger::debug() is a no-op unless
        // "Show Debug Log" is on, but the argument is built by the CALLER, so
        // every frame allocated and concatenated three std::strings regardless
        // of the toggle -- 3 heap allocations x 60-240 fps, discarded.
        //
        // The per-LOAD-CYCLE traces in asset_bundles.h replace it and are kept:
        // those fire once per bundle load, not once per frame, and they are what
        // proved the chams path was innocent.

        // load asset bundle from game thread
        //
        // start_load() returns null on every failure path (no writable directory,
        // unresolved method, refused file). The cycle state is "not started", so
        // without a backoff the next frame would retry immediately -- a per-frame
        // error log and a per-frame 18 KB file write for as long as the failure
        // lasts. The two cases are written out rather than sharing a label so the
        // else-if chain below still reads as the original three-state machine.
        const bool bundle_not_started = !asset_bundle_load_object;
        const bool retry_allowed = !bundle_retry_after_ms_
            || GetTickCount64() >= bundle_retry_after_ms_;

        if (bundle_not_started && retry_allowed)
        {
            if (bundle_retry_after_ms_)
            {
                logger::info("chams: retrying the asset bundle load");
                bundle_retry_after_ms_ = 0;
            }

            logger::info("Loading Asset Bundle");
            asset_bundle_load_object = asset_bundles::start_load();
            if (!asset_bundle_load_object)
                bundle_retry_after_ms_ = GetTickCount64() + kBundleRetryBackoffMs;
        }
        else if (bundle_not_started)
        {
            // Waiting out the backoff. Nothing to do this frame.
        }
        else if (!asset_bundle_loaded)
        {
            // Tri-state, and the Failed arm is the point of the change. check_progress()
            // used to answer bool, so "still loading" and "finished with no bundle" were
            // indistinguishable and a failed request was polled every frame for as long as
            // it lived -- 11,903 ERROR lines over 258 s at 46/s on 2026-10-01, 85% of that
            // session's log, and never recovering because the underlying cause was a leaked
            // AssetBundle registry entry (asset_bundles::reset_bundle never called Unload).
            //
            // Failed is terminal FOR THIS REQUEST, so the request is dropped and the
            // existing backoff takes over: bundle_not_started becomes true, and the retry
            // is gated on bundle_retry_after_ms_ instead of running every frame. That reuses
            // the machinery already here for start_load failures rather than adding a
            // second timer.
            const auto state = asset_bundles::check_progress(asset_bundle_load_object);
            if (state == asset_bundles::BundleLoadState::Loaded) {
                asset_bundle_loaded = true;
                reload_watchdog_armed_ = false; // reload completed
            }
            else if (state == asset_bundles::BundleLoadState::Failed) {
                asset_bundle_load_object = nullptr;
                bundle_retry_after_ms_ = GetTickCount64() + kBundleRetryBackoffMs;
                // The watchdog is disarmed: it exists to restart a load that is WEDGED, and
                // this load finished. Left armed it would fire once more against the null
                // request and log a second misleading "load stalled" line.
                reload_watchdog_armed_ = false;
            }
            else if (reload_watchdog_armed_ && GetTickCount64() - reload_start_ms_ > kBundleReloadTimeoutMs)
            {
                // LoadFromFileAsync never completed (wedged after a transit):
                // force-restart the cycle instead of parking on a dead bundle.
                logger::warn("Reloading chams Asset Bundle: load stalled, restarting");
                asset_bundle_load_object = asset_bundles::start_load();
                reload_start_ms_ = GetTickCount64();
                if (!asset_bundle_load_object)
                {
                    // A restart that also fails must not leave the watchdog armed
                    // against a bundle that will never exist, or the next
                    // completion check restarts again immediately.
                    reload_watchdog_armed_ = false;
                    bundle_retry_after_ms_ = GetTickCount64() + kBundleRetryBackoffMs;
                }
            }
        }
        else
        {
            // After a transit the old scene unloads and Unity can destroy the
            // native AssetBundle behind our managed wrapper (chams shaders then
            // go magenta/opaque). Any module hitting a dead shader raises a
            // reload request; also self-heal if we spot the dead wrapper here.
            const bool stale_bundle =
                asset_bundles::asset_bundle && !asset_bundles::is_asset_bundle_valid();
            if (stale_bundle) asset_bundles::request_reload();

            if (asset_bundles::consume_reload_request())
            {
                logger::info("Reloading chams Asset Bundle (stale after transit)");
                asset_bundles::reset_bundle();
                asset_bundle_load_object = asset_bundles::start_load();
                asset_bundle_loaded = false;
                reload_start_ms_ = GetTickCount64();
                reload_watchdog_armed_ = true;
                if (!asset_bundle_load_object)
                {
                    reload_watchdog_armed_ = false;
                    bundle_retry_after_ms_ = GetTickCount64() + kBundleRetryBackoffMs;
                }
            }
        }

        // set ingame status
        //
        // Tri-state, and the consumption policy matters more than the check.
        //
        // HISTORY, because the reasoning below reverses it and the reversal needs a
        // reason. This used to fail OPEN: on a read that did not return a value the last
        // known value was KEPT, on the grounds that a game update renaming `InRaid` makes
        // both "not in a raid" and "in a raid" guesses, and that failing open is wrong
        // only in the window between the patch and the fix while failing closed is wrong
        // forever (the mod silently stops, 18 files read this flag).
        //
        // That argument is correct about the RENAME case and it was applied to a case it
        // does not describe. A failed read is not only a rename: it is also what a
        // TEARING-DOWN InGameStatus looks like. Measured 2026-10-03, the exfil crash
        // (22:57:09, build 6AC13F71): the game's own "Local Raid Ended" fired, the world
        // came apart -- the camera resolver's own cam-choice dist_mean_m went 1.30 m ->
        // 2.04 m in the final minute -- and `resolve_esp_camera` took 9.0 ms against a
        // 9.8 us mean. Throughout that, is_in_raid was still TRUE, so
        // hk_game_world_update kept dispatching and AimbotModule kept projecting bones
        // through a camera resolver against a dead world. An uncaught C++ exception from
        // GameAssembly ended the process.
        //
        // The asymmetry decides it. Failing open on a rename costs the user their ESP
        // until they update the mod -- bad, visible, and FIXABLE by reading the log.
        // Failing open on teardown costs them the process, once, unreproducibly, from a
        // frame that looks like any other. One is a support ticket; the other is the
        // thing that made this file's own crash list.
        //
        // So: fail CLOSED. Two guards keep that from being its own outage.
        //
        //   1. DEBOUNCE. A single failed read does not drop the flag, because one bad
        //      frame mid-raid would blink every module off and clear both region memos
        //      for nothing. Only kRaidReadFailFrames CONSECUTIVE failures count, and at
        //      60 fps that is ~50 ms -- far shorter than a teardown, far longer than a
        //      dropped frame.
        //   2. LOUD. The rename case is now the dangerous one, so it must be greppable
        //      rather than silent: warn once with the failure count, which distinguishes
        //      "one blip at a boundary" from "this build never resolves InRaid".
        //
        // RATCHETED, and the ratchet is the whole point of having an event at all.
        //
        // hk_local_raid_ended drives the false edge from the game's own "raid is over"
        // call, strictly earlier than any poll could be. But that creates a hazard a
        // naive "event sets false, poll sets both ways" would walk straight into:
        //
        //   t0  LocalRaidEnded fires, set_in_raid(false).        <- correct
        //   t1  next application update, InGameStatus.InRaid STILL READS TRUE, because
        //       the game has not yet updated its own field -- this is the stale read
        //       that made the original crash possible at all.
        //   t2  the poll dutifully sets the flag back to TRUE.
        //
        // So the poll is NOT one-way. It keeps its proven true path, and is gated by a
        // ratchet instead. The ratchet needs BOTH halves, and this is the record of the
        // half that was missing until 2026-10-04 15:40:
        //
        //   grant   only the poll observing InRaid == false, and only kRaidFalseFrames
        //           CONSECUTIVE times, re-arms the poll's ability to set true
        //   revoke  on_local_raid_ended_event() CLEARS that permission immediately
        //
        // With only the grant, s_poll_may_set_true was `true` from start-up and never
        // changed, so the "teardown" row below described nothing: there was no state in
        // which the poll was "not armed". The t1/t2 hazard above was live, and the log
        // shows it firing -- flag cleared 15:29:05.396, set TRUE again by 15:29:06.519.
        //
        // Termination, which is the property that matters:
        //   end of raid   event sets false AND revokes -> poll reads false x10 (re-arms)
        //                 -> poll reads true on the next raid -> sets true.
        //                 At most 10 polls late on the way back up.
        //   teardown      event sets false AND revokes -> poll reads STALE true, not
        //                 armed, so it does nothing.      The bug cannot recur.
        //   missed event  nothing sets false from the event, so the poll's false read is
        //                 the only path that clears it -- which is why the poll is kept
        //                 at all rather than deleted. The revoke is then absent, which
        //                 is harmless: there was no permission to withdraw, because the
        //                 flag was cleared by the same read that begins the re-arm run.
        if (is_in_raid) {
            const auto in_raid = il2utils::get_static_field<bool>(is_in_raid, "InRaid");
            if (in_raid.present()) {
                s_raid_read_fail_frames = 0;
                s_raid_read_failed_logged = false;
                if (!in_raid.value) {
                    // The game agrees we are out. The flag is cleared on the FIRST such
                    // read -- a stale `true` must not survive even one frame -- but the
                    // permission to set it true again is only re-granted after
                    // kRaidFalseFrames CONSECUTIVE false reads, and the counter is reset
                    // by any `true` read below. Clearing and arming are deliberately NOT
                    // on the same threshold: one is about not trusting the game, the
                    // other is about not trusting a single sample.
                    if (++s_raid_false_frames >= kRaidFalseFrames) {
                        s_poll_may_set_true = true;
                        s_raid_false_frames = 0;
                    }
                    // On the TRANSITION, not on the read. The read says false every frame
                    // of every menu session; logging that produced 16,964 identical lines
                    // and 59% of the log on 2026-10-04. set_in_raid tells us whether
                    // anything actually changed, and outside a raid the answer is no.
                    const bool moved = game_state::set_in_raid(false);
                    if (moved) {
                        if (s_raid_end_event_seen) {
                            s_raid_end_event_seen = false;
                        } else {
                            logger::debug("raid-boundary: InRaid poll cleared the flag; "
                                "no LocalRaidEnded event was seen (alt-F4, disconnect, or "
                                "a crash inside the game's handler before our line ran)");
                        }
                    }

                    // WHO took the crash probe's two single-slot handlers?
                    //
                    // This is the last ORDINARY-thread moment before teardown, which is
                    // why it is asked here and not from the vectored handler:
                    // GetModuleHandleExW takes the loader lock, and the crash being chased
                    // happens at teardown, which is exactly when that lock may already be
                    // held. Asking from a VEH could deadlock on the event under
                    // investigation. (crash_probe.h, module_owner_of's note.)
                    //
                    // Both raid-end doors land in this block -- the LocalRaidEnded event
                    // and the InRaid poll -- so whichever way a raid ends, the taker gets
                    // named. On 2026-10-04 the guess was Unity's own Crash Handler and
                    // nothing could confirm it; that guess is what this line replaces.
                    crash_probe::report_handler_owners("raid-boundary");
                } else if (s_poll_may_set_true) {
                    // A `true` read invalidates any run of false reads in progress, so
                    // the sustained-false requirement cannot be satisfied by a run the
                    // game interrupted by disagreeing with itself.
                    s_raid_false_frames = 0;
                    game_state::set_in_raid(true);
                }
            } else if (++s_raid_read_fail_frames >= kRaidReadFailFrames) {
                game_state::set_in_raid(false);   // fail CLOSED, debounced
                if (!s_raid_read_failed_logged) {
                    s_raid_read_failed_logged = true;
                    logger::warn(std::format(
                        "raid-boundary: InRaid unreadable for {} consecutive frames; "
                        "treating as NOT in a raid so modules stop touching a world that "
                        "is going away. If this repeats every raid rather than only at a "
                        "boundary, the game renamed the field and the mod needs updating.",
                        s_raid_read_fail_frames));
                }
            }
        } else {
            game_state::set_in_raid(false);
        }

        ModuleManager::get_instance()->apply([instance](Module* m) {
            m->application_update(instance);
        });

        if (o_tarkov_application_update)
        {
            // The game's own Update, not ours, and it was the largest unexplained
            // number in the 2026-10-01 profile: 1.03 ms of self time per call,
            // 43.2 s over the session, sitting inside the outer zone as cost that
            // belonged to neither this mod nor ModuleManager::apply. Zoned so the
            // outer zone's remaining self time is the mod's actual per-frame cost
            // instead of a blend of the two.
            //
            // hk_game_world_update below gets no equivalent zone on purpose: its
            // original measured 3.1 us per call, so a zone there would be a
            // rounding error with a flame-graph entry to maintain.
            TA_ZONE_N("game::tarkov_application_update");
            o_tarkov_application_update(instance);
        }
    }
    void hk_game_world_update(Il2CppObject* instance) {
        // The in-raid half of the frame. Everything under here only runs during a
        // raid, so this zone is how a profile distinguishes menu time from raid
        // time -- which the outer zone above cannot, because it also covers both.
        TA_ZONE_N("frame::hk_game_world_update");
        // Memory sampling, here rather than in the probe's own handler because
        // this is the frame path and the probe has no per-frame entry point.
        // Ungated on is_in_raid on purpose: a leak that builds up in the menu or
        // the hideout is the same leak, and gating it here would hide exactly the
        // part of the curve that has not started falling yet. Cost when the
        // interval has not elapsed is one atomic load.
        crash_probe::tick_memory();
        if (o_game_world_update)
            o_game_world_update(instance);
        if (!instance) return;

        // no modules outside of raid
        if (!game_state::is_in_raid) return;

        // A live GameWorld being updated = the destination raid has finished loading.
        // Close the raid-start guard's load window so the (now benign) post-load
        // matching/create flow is restored; without this the window only closed on a
        // time cap that could expire mid-load on slow transits (Streets 2026-09-24:
        // >70 s load vs old 40 s cap -> duplicate matching let through -> native crash).
        always_on::raid_start_guard_load_complete();

        Il2CppObjectInstance game_world_instance(instance);
        const auto main_player_object = game_world_instance.get_field<Il2CppObject*>("MainPlayer");

        // if player is not loaded yet
        if (main_player_object == nullptr) return;

        Il2CppObjectInstance main_player(main_player_object);

        game_state::current_zoom = eft_api::get_scope_zoom(main_player);

        ModuleManager::get_instance()->apply([game_world_instance, main_player](Module* m) {
            m->gameworld_update(game_world_class, game_world_instance, main_player);
        });
    }
} // namespace common_hooks
