#include "common.h"
#include "Module.h"

Module::~Module() {
    for (const auto config_value : config_values)
    {
        delete config_value;
    }
}

Module::Module(std::string name, const ModuleCategory category, std::string display_key) : name(std::move(name)), category(category),
                                                                                           display_key_(display_key.empty() ? this->name : std::move(display_key)) {
}

[[nodiscard]] const std::string& Module::get_display_key() const { return display_key_; }

void Module::application_update([[maybe_unused]] Il2CppObject* application) {
    application_update();
}

void Module::draw_menu_extra() {}

[[nodiscard]] bool Module::draw_menu_extra_before_values() const { return false; }

void Module::prepare_menu_draw() {}

void Module::clear_runtime_cache() {}

[[nodiscard]] size_t Module::get_runtime_cache_count() { return 0; }

[[nodiscard]] size_t Module::get_runtime_cache_bytes() { return 0; }

void Module::apply(const std::function<void(ConfigValue*)>& function) const {
    for (auto config_value : config_values)
    {
        function(config_value);
    }
}
