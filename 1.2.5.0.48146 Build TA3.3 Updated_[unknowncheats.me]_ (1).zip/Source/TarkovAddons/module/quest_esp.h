#pragma once

// The `[CLEANUP-PENDING:OPTICS]` freeze that used to open this file is GONE:
// the optics rework landed and the user lifted the freeze on 2026-10-13
// (AGENTS.md, "Do not touch"). A dead-code pass found
// `last_collect_was_authoritative` below with no callers; it was deferred while
// optics was in flight and **DELETED 2026-10-13** once the freeze lifted.
// See CLEANUP_AUDIT.md section 2.3.

#include <string>
#include <vector>
#include <functional>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <Windows.h>
#include "../util/tracy_bridge.h"

// MongoID only — avoid QuestModule → ItemModule include chain.
#ifndef TARKOV_MONGO_ID_DEFINED
#define TARKOV_MONGO_ID_DEFINED
struct mongo_id
{
    unsigned int time_stamp;
    unsigned long long counter;
    void* string_id;
};
#endif

#include "eft_api.h"
#include "game_state.h"
#include "../il2cpp/Il2CppObjectInstance.h"
#include "../il2cpp/exports.h"
#include "../il2cpp/il2utils.h"
#include "../il2cpp/unity.h"
#include "../util/logger.h"

namespace quest_esp {
    enum class poi_type : char {
        visit,
        find,
        place,
    };

    struct poi_entry
    {
        unity::vector3 pos{};
        std::string quest_name;
        std::string description;
        poi_type type = poi_type::visit;
        float distance = 0.f;
        Il2CppObject* condition = nullptr;
    };

    inline constexpr int quest_status_started = 2;
    inline constexpr int quest_status_available_for_finish = 3;

    struct transit_point_entry
    {
        std::string location_id;
        std::string name;
        std::string description;
        Il2CppObject* point = nullptr;
    };

    struct trigger_cache_state
    {
        std::vector<std::pair<std::string, Il2CppObject*>> experience_triggers;
        std::vector<std::pair<std::string, Il2CppObject*>> place_triggers;
        std::unordered_map<std::string, Il2CppObject*> experience_by_id;
        std::unordered_map<std::string, Il2CppObject*> place_by_id;
        std::vector<transit_point_entry> transit_points;
        ULONGLONG last_soft_prune_ms = 0;
        ULONGLONG last_full_scan_ms = 0;
        Il2CppObject* last_world = nullptr;
        std::string last_location_id;
    };

    enum class collect_phase : char {
        idle,
        building,
        scanning_loot,
        ready,
    };

    struct find_rule
    {
        std::string quest_name;
        std::string description;
        Il2CppObject* condition = nullptr;
    };

    struct incremental_collect_state
    {
        collect_phase phase = collect_phase::idle;
        std::vector<poi_entry> result;
        std::vector<find_rule> find_rules;
        Il2CppArray* loot_array = nullptr;
        size_t loot_cursor = 0;
        size_t loot_bound = 0;
        unity::vector3 my_pos{};
        ULONGLONG started_ms = 0;
        // true = full cycle finished (building + optional loot scan). Safe to publish empty
        // (quest completed). false = forced/partial ready — do not wipe a good store.
        bool authoritative = false;
    };

    inline trigger_cache_state& triggers() {
        static trigger_cache_state state;
        return state;
    }

    inline incremental_collect_state& incremental() {
        static incremental_collect_state state;
        return state;
    }

    inline void reset_incremental() {
        auto& state = incremental();
        state.phase = collect_phase::idle;
        state.result.clear();
        state.find_rules.clear();
        state.loot_array = nullptr;
        state.loot_cursor = 0;
        state.loot_bound = 0;
        state.started_ms = 0;
        state.authoritative = false;
    }

    inline void mark_collect_ready(const bool authoritative) {
        auto& state = incremental();
        state.phase = collect_phase::ready;
        state.authoritative = authoritative;
    }

    inline void force_collect_ready() {
        auto& state = incremental();
        if (state.phase == collect_phase::building || state.phase == collect_phase::scanning_loot)
            mark_collect_ready(/*authoritative=*/false);
    }

    inline bool is_collect_stale(const ULONGLONG now_ms, const ULONGLONG timeout_ms) {
        const auto& state = incremental();
        if (state.phase == collect_phase::idle || state.phase == collect_phase::ready)
            return false;
        if (state.started_ms == 0)
            return false;
        return now_ms - state.started_ms >= timeout_ms;
    }

    inline Il2CppArray* try_get_loot_iteration_array(Il2CppObject* game_world) {
        Il2CppObject* loot_hydra_obj = eft_api::try_get_field_object(game_world, "LootItems");
        if (!loot_hydra_obj) return nullptr;

        Il2CppObjectInstance loot_hydra(loot_hydra_obj);
        unity::list* loot_list = loot_hydra.get_field<unity::list*>("_iteration");
        if (!loot_list || !loot_list->m_p_list_array) return nullptr;
        return loot_list->m_p_list_array;
    }

    inline std::string mongo_id_key(const mongo_id& id) {
        char buf[64];
        snprintf(buf, sizeof(buf), "%u:%llx",
            id.time_stamp, static_cast<unsigned long long>(id.counter));
        return buf;
    }

    inline bool class_name_contains(Il2CppObject* obj, const char* needle) {
        return obj && obj->klass && obj->klass->name && strstr(obj->klass->name, needle) != nullptr;
    }

    inline bool class_inherits_from(Il2CppObject* obj, const char* base_name) {
        if (!obj || !obj->klass || !base_name || !base_name[0]) return false;

        for (const Il2CppClass* klass = obj->klass; klass; klass = klass->parent)
        {
            if (klass->name && strcmp(klass->name, base_name) == 0)
                return true;
        }

        return false;
    }

    inline bool is_place_condition_type(Il2CppObject* condition) {
        if (!condition) return false;

        if (class_name_contains(condition, "ConditionZone")
            || class_name_contains(condition, "ConditionLeaveItemAtLocation")
            || class_name_contains(condition, "ConditionPlaceBeacon"))
            return true;

        return class_inherits_from(condition, "ConditionZone");
    }

    inline bool is_multiple_targets_condition(Il2CppObject* condition) {
        if (!condition) return false;

        if (class_name_contains(condition, "ConditionFindItem")
            || is_place_condition_type(condition))
            return true;

        return class_inherits_from(condition, "ConditionMultipleTargets");
    }

    inline void register_place_trigger_id(
        std::vector<std::pair<std::string, Il2CppObject*>>& triggers,
        std::unordered_map<std::string, Il2CppObject*>& by_id,
        const std::string& id,
        Il2CppObject* trigger) {
        if (!trigger || id.empty()) return;

        triggers.emplace_back(id, trigger);
        by_id.emplace(id, trigger);
    }

    // ---------------------------------------------------------------------------
    // PlaceItemTrigger.InputTriggerIds -- the id family the beacon objectives
    // actually name, measured 2026-10-14.
    //
    // The place-condition line added with the 2026-10-13 fix answered its own
    // premise in one raid: `found=0` for EVERY id (ter_013_area_1..4,
    // place_THX_15), against a cache built from get_Id and get_TriggerId. So a
    // ConditionPlaceBeacon's zoneIds[] entry names NEITHER of those. What
    // PlaceItemTrigger also carries (dump.cs, TypeDefIndex 13826) is
    // `InputTriggerIds` -- an [IteratorStateMachine] property returning
    // IEnumerable<string> -- and it was never read. This walks it and registers
    // every entry, so the next raid's `found=` says which family the ids live
    // in instead of leaving the question to inference.
    //
    // The walk is the iterator shape specifically, because that is what the
    // property is: the returned object IS the compiler-generated state machine
    // (`PlaceItemTrigger.<get_InputTriggerIds>d__13`). Drive its MoveNext and
    // read `<>2__current`. The name+field pair is the gate
    // hideout_reflection.h documents at length -- an ASYNC state machine also
    // has a MoveNext and executing one from here would run a coroutine on the
    // game thread, so the `<>2__current` field is required before any call.
    // Hard-bounded at 32: a misread shape must not spin.
    // ---------------------------------------------------------------------------
    inline int register_input_trigger_ids(
        Il2CppObject* trigger,
        std::vector<std::pair<std::string, Il2CppObject*>>& triggers,
        std::unordered_map<std::string, Il2CppObject*>& by_id) {
        if (!trigger || !trigger->klass) return 0;

        Il2CppObjectInstance inst(trigger);
        const auto get_inputs = inst.get_method<Il2CppObject* (*)(Il2CppObject*)>(
            "get_InputTriggerIds", 0, /*log_fail=*/false, /*allow_any_argc=*/false);
        if (!get_inputs) return 0;

        Il2CppObject* enumerable = get_inputs(trigger);
        if (!enumerable || !enumerable->klass) return 0;
        if (!il2utils::is_state_machine_class_name(
                enumerable->klass->name ? enumerable->klass->name : ""))
            return 0; // not an iterator: nothing here can enumerate it safely
        const FieldInfo* current_field = il2utils::resolve_field(enumerable->klass, "<>2__current");
        if (!current_field) return 0;
        const MethodInfo* move = il2utils::resolve_state_machine_movenext(enumerable->klass);
        if (!move || !move->methodPointer) return 0;
        if (!eft_api::is_il2cpp_object_likely_valid(enumerable)) return 0;

        const auto step = reinterpret_cast<bool (*)(Il2CppObject*)>(move->methodPointer);
        int registered = 0;
        for (size_t i = 0; i < 32; ++i) {
            if (!eft_api::is_readable_address(enumerable, sizeof(Il2CppObject))) break;
            if (!step(enumerable)) break;
            const auto* slot = reinterpret_cast<Il2CppString* const*>(
                reinterpret_cast<const std::uint8_t*>(enumerable) + current_field->offset);
            if (!eft_api::is_readable_address(slot, sizeof(Il2CppString*))) break;
            Il2CppString* raw = *slot;
            if (!raw) continue;
            const std::string id = il2utils::conv_string(raw);
            if (id.empty()) continue;
            const std::size_t before = by_id.size();
            register_place_trigger_id(triggers, by_id, id, trigger);
            if (by_id.size() != before) ++registered;
        }
        return registered;
    }

    inline Il2CppObject* get_condition_collection_object(Il2CppObject* counter_creator) {
        if (!counter_creator || !counter_creator->klass) return nullptr;

        Il2CppObjectInstance creator(counter_creator);

        const auto get_conditions = creator
                                        .get_method<Il2CppObject* (*)(Il2CppObject*)>("get_Conditions", 0);
        if (get_conditions)
        {
            Il2CppObject* via_method = get_conditions(counter_creator);
            if (via_method) return via_method;
        }

        Il2CppObject* backing = creator.get_field<Il2CppObject*>("<Conditions>k__BackingField");
        if (backing) return backing;

        Il2CppObject* template_obj = creator.get_field<Il2CppObject*>("_templateConditions");
        if (!template_obj) return nullptr;

        return Il2CppObjectInstance(template_obj).get_field<Il2CppObject*>("Conditions");
    }

    inline mongo_id get_condition_id(Il2CppObject* condition) {
        if (!condition) return {};
        Il2CppObjectInstance inst(condition);
        return inst.get_field<mongo_id>("<id>k__BackingField");
    }

    inline Il2CppObject* find_progress_checker(Il2CppObject* quest, Il2CppObject* condition) {
        if (!quest || !condition) return nullptr;

        Il2CppObjectInstance quest_inst(quest);
        const auto get_checkers = quest_inst
                                      .get_method<Il2CppObject* (*)(Il2CppObject*)>("get_ProgressCheckers", 0);
        if (!get_checkers) return nullptr;

        Il2CppObject* checkers_obj = get_checkers(quest);
        if (!checkers_obj) return nullptr;

        auto* checkers = reinterpret_cast<unity::dict<Il2CppObject*, Il2CppObject*>*>(checkers_obj);
        if (!checkers || !checkers->m_p_entries) return nullptr;

        Il2CppObject* checker = checkers->get_value_by_key(condition);
        if (checker) return checker;

        const std::string target_key = mongo_id_key(get_condition_id(condition));
        if (target_key.empty()) return nullptr;

        for (int i = 0; i < checkers->m_i_count; ++i)
        {
            Il2CppObject* key = checkers->get_key_by_index(i);
            if (!key) continue;
            if (mongo_id_key(get_condition_id(key)) == target_key)
                return checkers->get_value_by_index(i);
        }

        return nullptr;
    }

    // Exact-argc method pointer only (no argc=-1 fallback). Overloads like Test/0 vs Test/1
    // must never be mixed — wrong arity hard-crashes the game.
    template <typename T>
    T get_method_exact(Il2CppObject* obj, const char* name, int args) {
        if (!obj || !obj->klass) return nullptr;
        return il2utils::get_method<T>(obj->klass, name, args, /*log_fail=*/false, /*allow_any_argc=*/false);
    }

    inline bool is_progress_checker_completed(Il2CppObject* checker) {
        if (!checker || !checker->klass) return false;

        // Only IsCompleted() — exact 0 args. Do NOT call Test(): get_method used to fall back
        // to Test(object) via argc=-1 and that crashed Unity on invoke.
        if (const auto is_completed = get_method_exact<bool (*)(Il2CppObject*)>(checker, "IsCompleted", 0))
            return is_completed(checker);

        if (const auto get_completed = get_method_exact<bool (*)(Il2CppObject*)>(checker, "get_IsCompleted", 0))
            return get_completed(checker);

        return false;
    }

    inline bool is_condition_in_completed_collection(Il2CppObject* completed_collection,
        Il2CppObject* condition) {
        if (!completed_collection || !condition || !completed_collection->klass) return false;
        if (!eft_api::is_il2cpp_object_likely_valid(completed_collection)
            || !eft_api::is_il2cpp_object_likely_valid(condition))
            return false;

        // CompletedConditionsCollection.Contains(Condition) — non-generic, no MethodInfo* tail.
        const MethodInfo* contains_method =
            il2utils::resolve_method(completed_collection->klass, "Contains", 1);
        if (!contains_method || !contains_method->methodPointer) return false;
        if (contains_method->parameters_count != 1) return false;

        return reinterpret_cast<bool (*)(Il2CppObject*, Il2CppObject*)>(
            contains_method->methodPointer)(completed_collection, condition);
    }

    inline bool is_condition_in_status_hashset(Il2CppObject* completed_set,
        const mongo_id& condition_id) {
        if (!completed_set || !completed_set->klass) return false;
        if (!eft_api::is_il2cpp_object_likely_valid(completed_set)) return false;

        // Must be HashSet (QuestStatusData.CompletedConditions), not CompletedConditionsCollection.
        if (completed_set->klass->name
            && strstr(completed_set->klass->name, "HashSet") == nullptr
            && strstr(completed_set->klass->name, "hashset") == nullptr)
        {
            // Some builds keep the concrete name as HashSet`1 — accept either HashSet or empty name.
            // If it's clearly the collection type, refuse (would crash on MongoID ABI).
            if (strstr(completed_set->klass->name, "CompletedConditions") != nullptr)
                return false;
        }

        // HashSet<MongoID>.Contains — generic; MongoID (24B) by pointer + MethodInfo* (QuestModule ABI).
        const MethodInfo* contains_method =
            il2utils::resolve_method(completed_set->klass, "Contains", 1);
        if (!contains_method || !contains_method->methodPointer) return false;

        mongo_id id_copy = condition_id;
        // Zero id is never a real condition — skip call (avoids bad hash lookups).
        if (id_copy.time_stamp == 0 && id_copy.counter == 0 && id_copy.string_id == nullptr)
            return false;

        return reinterpret_cast<bool (*)(Il2CppObject*, void*, const MethodInfo*)>(
            contains_method->methodPointer)(completed_set, &id_copy, contains_method);
    }

    inline bool try_read_int_field(Il2CppObject* obj, const char* name, int& out) {
        if (!obj || !obj->klass || !name) return false;
        FieldInfo* field = il2utils::resolve_field(obj->klass, name);
        if (!field) return false;
        out = *reinterpret_cast<int*>(reinterpret_cast<uintptr_t>(obj) + field->offset);
        return true;
    }

    inline Il2CppObject* try_read_obj_field(Il2CppObject* obj, const char* name) {
        if (!obj || !obj->klass || !name) return nullptr;
        FieldInfo* field = il2utils::resolve_field(obj->klass, name);
        if (!field) return nullptr;
        return *reinterpret_cast<Il2CppObject**>(reinterpret_cast<uintptr_t>(obj) + field->offset);
    }

    inline bool is_condition_completed(Il2CppObject* quest,
        Il2CppObject* condition,
        Il2CppObject* status_completed_set) {
        if (!condition || !condition->klass) return false;

        // 1) HashSet<MongoID> on QuestStatusData (persisted objective completion).
        if (status_completed_set
            && is_condition_in_status_hashset(status_completed_set, get_condition_id(condition)))
            return true;

        if (quest && quest->klass)
        {
            // 2) Live progress checker IsCompleted only (no Test — crash risk).
            Il2CppObject* checker = find_progress_checker(quest, condition);
            if (checker && is_progress_checker_completed(checker))
                return true;

            // 3) CompletedConditionsCollection.Contains(Condition) on the quest.
            if (const auto get_completed = get_method_exact<Il2CppObject* (*)(Il2CppObject*)>(
                    quest, "get_CompletedConditions", 0))
            {
                Il2CppObject* completed_collection = get_completed(quest);
                if (completed_collection
                    && is_condition_in_completed_collection(completed_collection, condition))
                    return true;
            }
        }

        return false;
    }

    // --- Quest description pipeline (from Icebreaker Test) ---

    inline std::unordered_map<std::string, std::string>& persistent_desc_cache() {
        static std::unordered_map<std::string, std::string> cache;
        return cache;
    }

    // ---------------------------------------------------------------------------
    // The quest and the completed-conditions set a CONDITION came from.
    //
    // The full rationale is on the completed-sweep below -- it exists so the sweep
    // does not have to walk the quest book. Declared HERE, above clear_caches()
    // which clears it, because MSVC resolves members in declaration order and a
    // use above the definition is a C3861.
    //
    // GAME THREAD ONLY, and RAID-SCOPED: the collect clears it per raid and
    // clear_caches() clears it at the raid boundary.
    // ---------------------------------------------------------------------------
    struct condition_owner {
        Il2CppObject* quest = nullptr;
        Il2CppObject* completed_set = nullptr;
    };

    inline std::unordered_map<Il2CppObject*, condition_owner>& condition_owners() {
        static std::unordered_map<Il2CppObject*, condition_owner> owners;
        return owners;
    }

    inline void record_condition_owner(Il2CppObject* condition,
        Il2CppObject* quest, Il2CppObject* completed_set) {
        if (!condition || !quest) return;
        // First write wins. A condition can appear under more than one quest
        // (the same ConditionZone type instantiated twice), and the first is the
        // one the collect emitted from -- which is the owner a marker from this
        // collect will name.
        condition_owners().emplace(condition, condition_owner{quest, completed_set});
    }

    inline void clear_caches() {
        reset_incremental();
        persistent_desc_cache().clear();
        // The owners map and the published marker set must die TOGETHER, and the
        // pairing is the safety property. It maps an Il2CppObject* the game owns
        // to the quest that was carrying it, so it is a raid-scoped table: the
        // conditions in quest_poi_store are from ONE raid, and the answers about
        // them are only valid for that raid.
        //
        // The DANGEROUS direction is the store outliving the table, because then
        // the sweep reads a condition whose owner table was rebuilt for a
        // different raid's objects and hands the game a pointer from the wrong
        // generation. EspModule::clear_runtime_cache() empties the store and
        // calls this, in that order, so both end in one function -- and it is the
        // same function that has to be right in both places, not two that have to
        // agree. The other direction (table empty, store populated) makes the
        // sweep a no-op, which is the safe one and needs no guard.
        condition_owners().clear();

        auto& cache = triggers();
        cache.last_world = nullptr;
        cache.last_location_id.clear();
        cache.last_soft_prune_ms = 0;
        cache.last_full_scan_ms = 0;
        cache.experience_triggers.clear();
        cache.place_triggers.clear();
        cache.experience_by_id.clear();
        cache.place_by_id.clear();
        cache.transit_points.clear();
    }

    // ---- GAME-THREAD ONLY ---------------------------------------------------
    // Everything in this namespace -- triggers(), incremental(),
    // persistent_desc_cache() and the two statistics below -- is confined to
    // the game thread (gameworld_update / application_update / clear_runtime_
    // cache). The statistics used to be read from the render thread by
    // ConfigModule::draw_cache_info, which iterated these very containers while
    // the game thread was inserting into them. EspModule::refresh_cache_stats()
    // now calls them from the game thread instead, so no mutex is needed and
    // there is no cross-thread access left to protect.
    //
    // poi_entry data reaches the render thread only as the quest_poi_store
    // snapshot EspModule publishes; draw_overlay() never calls into here.
    inline size_t get_runtime_cache_count() {
        const auto& cache = triggers();
        const auto& state = incremental();
        return cache.experience_triggers.size()
            + cache.place_triggers.size()
            + cache.transit_points.size()
            + state.result.size()
            + state.find_rules.size();
    }

    inline size_t get_runtime_cache_bytes() {
        const auto& cache = triggers();
        const auto& state = incremental();
        size_t bytes = (cache.experience_triggers.size() + cache.place_triggers.size()
                           + cache.transit_points.size())
            * 128;
        for (const auto& poi : state.result)
            bytes += poi.quest_name.size() + poi.description.size() + 96;
        bytes += state.find_rules.size() * 96;
        bytes += persistent_desc_cache().size() * 64;
        return bytes;
    }

    // --- Quest descriptions (simplified) ---------------------------------
    // Only show text that looks human. Visit place MongoIDs / failed locale keys
    // stay empty (marker still draws with quest name).
    // Resolve ONLY on game thread via fill_poi_descriptions — never from draw.

    inline std::string read_il2cpp_string_result(Il2CppString* str) {
        if (!str || str->length <= 0) return {};
        return eft_api::to_display_utf8(il2utils::conv_wstring(str));
    }

    inline std::string trim_text(std::string text) {
        while (!text.empty() && (text.front() == ' ' || text.front() == '\t'))
            text.erase(text.begin());
        while (!text.empty() && (text.back() == ' ' || text.back() == '\t'))
            text.pop_back();
        return text;
    }

    inline bool is_template_id_char(const char c) {
        return std::isxdigit(static_cast<unsigned char>(c)) != 0;
    }

    inline bool is_pure_template_id(const std::string& text) {
        if (text.size() != 24) return false;
        for (const char c : text)
            if (!is_template_id_char(c)) return false;
        return true;
    }

    inline std::string normalize_template_id(std::string id) {
        for (char& c : id)
            c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        return id;
    }

    // Failed / unusable description: hide instead of showing garbage.
    inline bool is_displayable_description(const std::string& text) {
        if (text.empty()) return false;
        if (is_pure_template_id(text)) return false;
        if (text.rfind("Name/", 0) == 0) return false;
        if (text.find("Name/Name/") != std::string::npos) return false;
        if (text.find("/Name/") != std::string::npos) return false;
        // Bare key-like "Something/hexid"
        if (text.size() >= 25)
        {
            const std::string tail = text.substr(text.size() - 24);
            if (is_pure_template_id(tail) && text.find('/') != std::string::npos
                && text.find(' ') == std::string::npos)
                return false;
        }
        // Unresolved format placeholder
        if (text.find("{0}") != std::string::npos || text.find("{1}") != std::string::npos)
            return false;
        return true;
    }

    // Item templates only (place/find loot). Do NOT use for visit place MongoIDs.
    inline std::string resolve_template_display_name(const std::string& template_id) {
        if (!is_pure_template_id(template_id) || !game_state::item_factory) return {};

        const std::string normalized = normalize_template_id(template_id);
        Il2CppObjectInstance factory(game_state::item_factory);
        const auto get_preset = factory.get_method<Il2CppObject* (*)(Il2CppObject*, Il2CppString*)>(
            "GetPresetItem", 1, /*log_fail=*/false);
        if (!get_preset) return {};

        Il2CppString* id_str = il2cpp::il2cpp_string_new(normalized.c_str());
        if (!id_str) return {};

        Il2CppObject* item = get_preset(game_state::item_factory, id_str);
        if (!item || !eft_api::is_il2cpp_object_likely_valid(item)) return {};

        const std::string name = eft_api::try_get_item_localized_display_name(item);
        if (name.empty() || name == "Item" || name == normalized || is_pure_template_id(name))
            return {};
        return name;
    }

    inline const MethodInfo* resolve_method_walk_parents(
        Il2CppClass* klass, const char* name, int args) {
        for (Il2CppClass* k = klass; k; k = k->parent)
        {
            if (const MethodInfo* m = il2utils::resolve_method(k, name, args))
            {
                if (m->methodPointer)
                    return m;
            }
        }
        return nullptr;
    }

    // Icebreaker-style: MethodInfo walk parents (VisitPlace inherits OneTarget).
    inline Il2CppString* invoke_get_formatted_description(Il2CppObject* condition) {
        if (!condition || !condition->klass) return nullptr;

        const MethodInfo* mi = resolve_method_walk_parents(
            condition->klass, "get_FormattedDescription", 0);
        if (!mi || !mi->methodPointer)
        {
            static const Il2CppImage* img = il2utils::resolve_image("Assembly-CSharp.dll");
            static const Il2CppClass* one_target = img
                ? il2utils::resolve_class(img, "EFT.Quests", "ConditionOneTarget")
                : nullptr;
            if (one_target)
                mi = il2utils::resolve_method(one_target, "get_FormattedDescription", 0);
        }
        if (!mi || !mi->methodPointer) return nullptr;

        using fn_t = Il2CppString* (*)(Il2CppObject*, const MethodInfo*);
        return reinterpret_cast<fn_t>(mi->methodPointer)(condition, mi);
    }

    // Light locale: ParseLocalization + game key only for underscore keys (not bare hex).
    inline std::string light_localize_description(const std::string& text) {
        if (text.empty()) return text;

        std::string localized = text;
        if (const std::string parsed = eft_api::try_parse_localization(localized);
            eft_api::is_plausible_localized_result(localized, parsed)
            && is_displayable_description(parsed))
            localized = parsed;

        // Locale keys like QuestCondition_xxx / UI_...
        if (!is_pure_template_id(localized)
            && localized.find('_') != std::string::npos
            && localized.find(' ') == std::string::npos)
        {
            bool ascii = true;
            for (unsigned char c : localized)
            {
                if (c > 0x7F)
                {
                    ascii = false;
                    break;
                }
            }
            if (ascii && localized.size() > 8)
            {
                if (const std::string by_key = eft_api::try_localize_game_key(localized);
                    eft_api::is_plausible_localized_result(localized, by_key)
                    && is_displayable_description(by_key))
                    localized = by_key;
            }
        }
        return localized;
    }

    // Replace embedded 24-hex item template ids with item names (place/find).
    inline std::string substitute_item_template_ids(const std::string& text) {
        if (text.size() < 24) return text;

        std::string out;
        out.reserve(text.size());
        for (size_t i = 0; i < text.size();)
        {
            if (i + 24 <= text.size())
            {
                bool hex = true;
                for (size_t j = 0; j < 24; ++j)
                {
                    if (!is_template_id_char(text[i + j]))
                    {
                        hex = false;
                        break;
                    }
                }
                if (hex)
                {
                    const std::string id = text.substr(i, 24);
                    const std::string name = resolve_template_display_name(id);
                    if (!name.empty())
                    {
                        out += name;
                        i += 24;
                        continue;
                    }
                }
            }
            out += text[i++];
        }
        return out;
    }

    // C++ body (no __try — objects with dtors are illegal inside SEH frames).
    inline void write_condition_description_body(Il2CppObject* condition, char* out, size_t out_cap) {
        if (!out || out_cap == 0) return;
        out[0] = '\0';
        if (!condition || !eft_api::is_il2cpp_object_likely_valid(condition) || !condition->klass)
            return;

        // Visit place: almost always bare MongoID — skip IL2CPP entirely.
        if (condition->klass->name
            && (strstr(condition->klass->name, "ConditionVisitPlace")
                || strstr(condition->klass->name, "ConditionLocationTrigger")))
            return;

        Il2CppString* desc = invoke_get_formatted_description(condition);
        if (!desc) return;

        std::string text = trim_text(read_il2cpp_string_result(desc));
        if (text.empty()) return;

        text = light_localize_description(text);

        // Item substitution for find/place (embedded template ids).
        if (!is_pure_template_id(text) && text.size() >= 24)
            text = substitute_item_template_ids(text);

        text = trim_text(text);
        if (!is_displayable_description(text)) return;

        const size_t n = (std::min)(text.size(), out_cap - 1);
        memcpy(out, text.data(), n);
        out[n] = '\0';
    }

    // SEH-safe wrapper. Empty out = do not show description.
    inline void write_condition_description_seh(Il2CppObject* condition, char* out, size_t out_cap) {
        if (!out || out_cap == 0) return;
        out[0] = '\0';
        __try
        {
            write_condition_description_body(condition, out, out_cap);
        } __except (EXCEPTION_EXECUTE_HANDLER)
        {
            out[0] = '\0';
        }
    }

    // GAME THREAD only. Returns how many non-empty descriptions written.
    inline size_t fill_poi_descriptions(std::vector<poi_entry>& pois, const size_t max_resolve = 24) {
        if (pois.empty()) return 0;

        size_t non_empty = 0;
        size_t attempted = 0;
        auto& persistent = persistent_desc_cache();

        for (poi_entry& poi : pois)
        {
            if (attempted >= max_resolve) break;
            if (!poi.description.empty())
            {
                if (is_displayable_description(poi.description))
                    ++non_empty;
                else
                    poi.description.clear();
                continue;
            }
            if (!eft_api::is_il2cpp_object_likely_valid(poi.condition))
                continue;

            char key_buf[32];
            snprintf(key_buf, sizeof(key_buf), "%p", static_cast<void*>(poi.condition));
            const std::string key = key_buf;

            if (const auto found = persistent.find(key); found != persistent.end())
            {
                poi.description = found->second;
                ++attempted;
                if (!poi.description.empty()) ++non_empty;
                continue;
            }

            char buf[512];
            buf[0] = '\0';
            write_condition_description_seh(poi.condition, buf, sizeof(buf));
            std::string description = buf;

            // Cache empties too so we don't re-invoke IL2CPP every collect tick.
            persistent.emplace(key, description);
            poi.description = std::move(description);
            ++attempted;
            if (!poi.description.empty()) ++non_empty;
        }

        return non_empty;
    }

    inline std::string get_condition_target_string(Il2CppObject* condition) {
        if (!condition || !condition->klass) return {};

        const FieldInfo* target_field = il2utils::resolve_field(condition->klass, "target");
        if (!target_field) return {};

        const uintptr_t addr = reinterpret_cast<uintptr_t>(condition) + target_field->offset;
        if (is_multiple_targets_condition(condition))
        {
            Il2CppArray* arr = *reinterpret_cast<Il2CppArray**>(addr);
            if (!arr || arr->max_length == 0) return {};
            Il2CppString* first = reinterpret_cast<Il2CppString**>(&arr->data)[0];
            return first ? eft_api::to_display_utf8(il2utils::conv_wstring(first)) : std::string{};
        }

        Il2CppString* str = *reinterpret_cast<Il2CppString**>(addr);
        return str ? eft_api::to_display_utf8(il2utils::conv_wstring(str)) : std::string{};
    }

    inline bool target_array_contains_template(Il2CppObject* condition, const std::string& template_id) {
        if (!condition || !condition->klass || template_id.empty()) return false;

        const FieldInfo* target_field = il2utils::resolve_field(condition->klass, "target");
        if (!target_field) return false;

        Il2CppArray* arr = *reinterpret_cast<Il2CppArray**>(
            reinterpret_cast<uintptr_t>(condition) + target_field->offset);
        if (!arr) return false;

        for (size_t i = 0; i < arr->max_length; ++i)
        {
            Il2CppString* tid = reinterpret_cast<Il2CppString**>(&arr->data)[i];
            if (!tid) continue;
            const std::string target = il2utils::conv_string(tid);
            if (target.empty()) continue;
            if (target.find(template_id) != std::string::npos || template_id.find(target) != std::string::npos)
                return true;
        }
        return false;
    }

    inline unity::vector3 get_object_position(Il2CppObject* component) {
        if (!component) return {};
        Il2CppObject* go = unity::component_get_game_object(component);
        if (!go) return {};
        Il2CppObject* tr = unity::gameobject_get_transform(go);
        if (!tr) return {};
        return unity::transform_get_pos(tr);
    }

    inline size_t get_bindable_list_count(Il2CppObject* list_obj) {
        if (!list_obj) return 0;

        Il2CppObjectInstance list_inst(list_obj);
        const auto get_count = list_inst.get_method<int (*)(Il2CppObject*)>("get_Count", 0);
        if (get_count)
        {
            const int count = get_count(list_obj);
            if (count > 0) return static_cast<size_t>(count);
        }

        unity::list* clist = list_inst.get_field<unity::list*>("List");
        if (!clist || !clist->m_p_list_array) return 0;
        return clist->m_p_list_array->max_length;
    }

    inline void foreach_condition_in_collection(Il2CppObject* collection,
        const std::function<void(Il2CppObject*)>& fn) {
        if (!collection || !fn) return;

        Il2CppObjectInstance coll(collection);
        unity::list* clist = coll.get_field<unity::list*>("List");
        if (!clist || !clist->m_p_list_array) return;

        Il2CppArray* arr = clist->m_p_list_array;
        const size_t count = get_bindable_list_count(collection);
        const size_t limit = count > 0 ? count : arr->max_length;
        for (size_t i = 0; i < limit; ++i)
        {
            Il2CppObject* cond = reinterpret_cast<Il2CppObject**>(&arr->data)[i];
            if (!cond) continue;
            fn(cond);
        }
    }

    // ---------------------------------------------------------------------------
    // Every condition a MARKER can be attached to, depth-first, with the one recursion
    // that produces more than one level: `ConditionCounterCreator` carries its own
    // `ConditionCollection` (ConditionCounterCreator.Conditions, 0xE8) alongside
    // `_templateConditions` (0xE0), and the children in it are ordinary conditions --
    // visit / zone / find among them -- so a marker can name one.
    //
    // It is here rather than inlined at each of the two call sites because both of them
    // depend on reaching EXACTLY the same set. `start_collect_cycle` emits markers from
    // it; `drop_completed_pois` retires them, and a marker whose condition the sweep did
    // not reach reads as "this objective no longer exists" and is dropped. Miss the
    // recursion in the sweep and every counter-creator objective disappears five seconds
    // after it appears -- the one failure direction this code must not have.
    //
    // `Condition.ChildConditions` is deliberately NOT walked. It is a different list
    // (Condition, 0x68) from the one a marker is ever emitted for, and the collect has
    // never walked it; including it here would make the sweep's reach exceed the
    // collect's, which is the same disagreement in the other direction.
    // ---------------------------------------------------------------------------
    template <typename Fn>
    inline void foreach_marker_condition(Il2CppObject* condition, const Fn& fn) {
        if (!condition) return;

        if (class_name_contains(condition, "ConditionCounterCreator"))
        {
            Il2CppObject* nested = get_condition_collection_object(condition);
            foreach_condition_in_collection(nested, [&](Il2CppObject* sub) {
                foreach_marker_condition(sub, fn);
            });
            return;
        }

        fn(condition);
    }

    inline void foreach_quest_condition_collection(
        Il2CppObject* quest,
        const std::function<void(Il2CppObject* collection, int status_key)>& fn) {
        if (!quest || !quest->klass || !fn) return;

        const MethodInfo* get_conditions =
            il2utils::resolve_method(quest->klass, "get_Conditions", 0);
        if (!get_conditions || !get_conditions->methodPointer) return;

        Il2CppObject* conditions_obj =
            reinterpret_cast<Il2CppObject* (*)(Il2CppObject*)>(get_conditions->methodPointer)(quest);
        if (!conditions_obj) return;

        auto* conditions_dict = reinterpret_cast<unity::dict<int, Il2CppObject*>*>(conditions_obj);
        if (!conditions_dict || !conditions_dict->m_p_entries) return;

        for (int i = 0; i < conditions_dict->m_i_count; ++i)
        {
            Il2CppObject* collection = conditions_dict->get_value_by_index(i);
            if (!collection) continue;
            fn(collection, conditions_dict->get_key_by_index(i));
        }
    }

    inline unity::vector3 get_place_trigger_position(Il2CppObject* trigger) {
        unity::vector3 pos = get_object_position(trigger);
        if (pos.x != 0.f || pos.y != 0.f || pos.z != 0.f)
            return pos;

        if (!trigger) return pos;

        Il2CppObjectInstance inst(trigger);
        const auto get_dummy = inst.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_BeaconDummy", 0);
        if (!get_dummy) return pos;

        Il2CppObject* dummy_go = get_dummy(trigger);
        if (!dummy_go) return pos;

        Il2CppObject* tr = unity::gameobject_get_transform(dummy_go);
        if (!tr) return pos;

        return unity::transform_get_pos(tr);
    }

    // Drop destroyed Unity objects from a trigger list (cheap — no FindObjectsOfType).
    inline void prune_trigger_pairs(
        std::vector<std::pair<std::string, Il2CppObject*>>& list,
        std::unordered_map<std::string, Il2CppObject*>& by_id) {
        if (list.empty()) return;

        size_t write = 0;
        for (size_t read = 0; read < list.size(); ++read)
        {
            if (!eft_api::is_il2cpp_object_likely_valid(list[read].second))
                continue;
            if (write != read)
                list[write] = std::move(list[read]);
            ++write;
        }
        list.resize(write);

        by_id.clear();
        by_id.reserve(list.size());
        for (const auto& [id, obj] : list)
        {
            if (by_id.find(id) == by_id.end())
                by_id.emplace(id, obj);
        }
    }

    inline void prune_transit_points(std::vector<transit_point_entry>& points) {
        if (points.empty()) return;
        size_t write = 0;
        for (size_t read = 0; read < points.size(); ++read)
        {
            if (!eft_api::is_il2cpp_object_likely_valid(points[read].point))
                continue;
            if (write != read)
                points[write] = std::move(points[read]);
            ++write;
        }
        points.resize(write);
    }

    // Cheap: re-read TransitController only (no scene-wide FindObjectsOfType).
    inline void refresh_transit_points_only(Il2CppObject* game_world) {
        auto& cache = triggers();
        cache.transit_points.clear();
        if (!game_world) return;

        Il2CppObject* transit_controller = eft_api::try_get_field_object(
            game_world, "<TransitController>k__BackingField");
        if (!transit_controller)
            transit_controller = eft_api::try_get_field_object(game_world, "TransitController");
        if (!transit_controller) return;

        auto* by_id = reinterpret_cast<unity::dict<int, Il2CppObject*>*>(
            eft_api::try_get_field_object(transit_controller, "pointsById"));
        if (!by_id || by_id->m_i_count <= 0) return;

        cache.transit_points.reserve(static_cast<size_t>(by_id->m_i_count));
        for (int i = 0; i < by_id->m_i_count; ++i)
        {
            Il2CppObject* point = by_id->get_value_by_index(i);
            if (!eft_api::is_il2cpp_object_likely_valid(point)) continue;

            Il2CppObject* parameters = eft_api::try_get_field_object(point, "parameters");
            transit_point_entry entry{};
            entry.point = point;
            if (parameters)
            {
                entry.location_id = eft_api::try_read_string_field(parameters, "location");
                entry.name = eft_api::try_read_string_field(parameters, "name");
                entry.description = eft_api::try_read_string_field(parameters, "description");
                if (entry.location_id.empty())
                    entry.location_id = eft_api::try_read_string_field(parameters, "target");
            }
            cache.transit_points.push_back(std::move(entry));
        }
    }

    // Expensive: 3× FindObjectsOfType across the whole scene. Only on world/location change
    // or rare full rescan — this was causing ~10s freezes when called every collect cycle.
    inline void full_scan_triggers(Il2CppObject* game_world) {
        auto& cache = triggers();
        const ULONGLONG now = GetTickCount64();

        std::vector<std::pair<std::string, Il2CppObject*>> new_experience;
        std::vector<std::pair<std::string, Il2CppObject*>> new_place;
        std::unordered_map<std::string, Il2CppObject*> new_experience_by_id;
        std::unordered_map<std::string, Il2CppObject*> new_place_by_id;
        // Aggregate for the one DEBUG line that answers the 2026-10-14
        // `found=0` question: how many triggers exposed InputTriggerIds at all,
        // and how many ids that added.
        int input_id_triggers = 0;
        int input_id_total = 0;
        std::string input_id_sample;

        const Il2CppImage* image = il2utils::resolve_image("Assembly-CSharp.dll");
        if (!image)
        {
            cache.last_full_scan_ms = now;
            return;
        }

        // TriggerWithId.get_Id is shared — resolve once per scan, not per object.
        using get_id_fn_t = Il2CppString* (*)(Il2CppObject*);
        get_id_fn_t cached_get_id = nullptr;
        get_id_fn_t cached_get_trigger_id = nullptr;

        auto resolve_get_id = [&](Il2CppObject* obj) -> get_id_fn_t {
            if (cached_get_id) return cached_get_id;
            if (!obj || !obj->klass) return nullptr;
            cached_get_id = il2utils::get_method<get_id_fn_t>(
                obj->klass, "get_Id", 0, /*log_fail=*/false, /*allow_any_argc=*/false);
            return cached_get_id;
        };

        auto collect_trigger_with_id = [&](const char* class_name) {
            Il2CppObject* type = il2utils::get_system_type(image, "EFT.Interactive", class_name);
            if (!type) return;

            size_t count = 0;
            Il2CppObject** objects = unity::find_objects_of_type(type, &count);
            if (!objects || count == 0) return;
            new_experience.reserve(new_experience.size() + count);
            for (size_t i = 0; i < count; ++i)
            {
                if (!objects[i]) continue;
                const auto get_id = resolve_get_id(objects[i]);
                if (!get_id) continue;
                Il2CppString* id_str = get_id(objects[i]);
                if (!id_str) continue;
                const std::string id = il2utils::conv_string(id_str);
                if (id.empty()) continue;
                new_experience.emplace_back(id, objects[i]);
                if (new_experience_by_id.find(id) == new_experience_by_id.end())
                    new_experience_by_id.emplace(id, objects[i]);
            }
        };

        collect_trigger_with_id("ExperienceTrigger");
        collect_trigger_with_id("QuestTrigger");

        Il2CppObject* place_type = il2utils::get_system_type(image, "EFT.Interactive", "PlaceItemTrigger");
        if (place_type)
        {
            size_t count = 0;
            Il2CppObject** objects = unity::find_objects_of_type(place_type, &count);
            if (objects && count > 0)
            {
                new_place.reserve(count);
                for (size_t i = 0; i < count; ++i)
                {
                    if (!objects[i]) continue;
                    const auto get_id = resolve_get_id(objects[i]);
                    if (get_id)
                    {
                        if (Il2CppString* id_str = get_id(objects[i]))
                            register_place_trigger_id(
                                new_place, new_place_by_id,
                                il2utils::conv_string(id_str), objects[i]);
                    }

                    if (!cached_get_trigger_id && objects[i]->klass)
                    {
                        cached_get_trigger_id = il2utils::get_method<get_id_fn_t>(
                            objects[i]->klass, "get_TriggerId", 0,
                            /*log_fail=*/false, /*allow_any_argc=*/false);
                    }
                    if (cached_get_trigger_id)
                    {
                        if (Il2CppString* trigger_id_str = cached_get_trigger_id(objects[i]))
                        {
                            const std::string trigger_id = il2utils::conv_string(trigger_id_str);
                            if (new_place_by_id.find(trigger_id) == new_place_by_id.end())
                                register_place_trigger_id(
                                    new_place, new_place_by_id,
                                    trigger_id, objects[i]);
                        }
                    }

                    // The id family the beacon objectives actually name, per the
                    // 2026-10-14 `found=0` measurement. Registered AFTER the two
                    // property reads so a failure here cannot suppress them.
                    const std::size_t before = new_place_by_id.size();
                    const int added = register_input_trigger_ids(
                        objects[i], new_place, new_place_by_id);
                    if (new_place_by_id.size() != before)
                    {
                        ++input_id_triggers;
                        input_id_total += added;
                        if (input_id_sample.size() < 96)
                        {
                            for (const auto& entry : new_place_by_id)
                            {
                                if (input_id_sample.find(entry.first) == std::string::npos)
                                {
                                    if (!input_id_sample.empty()) input_id_sample += " ";
                                    input_id_sample += entry.first;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        // Keep previous trigger cache if FOT returned nothing (scene not ready).
        const bool scan_empty = new_experience.empty() && new_place.empty();
        if (!scan_empty)
        {
            cache.experience_triggers = std::move(new_experience);
            cache.place_triggers = std::move(new_place);
            cache.experience_by_id = std::move(new_experience_by_id);
            cache.place_by_id = std::move(new_place_by_id);
        }

        // One line per scan, DEBUG only. This is the answer to the question the
        // place-condition `found=0` lines raised on 2026-10-14: a raid where
        // input_id_triggers is 0 means the property path failed too, and the
        // lead moves to the trigger objects' own fields; a raid where it is
        // positive and `found=` stays 0 means these are simply not the ids the
        // quest conditions name.
        if (logger::debug_enabled())
        {
            logger::debug("quest esp: place triggers: input_id_triggers="
                + std::to_string(input_id_triggers) + " input_id_total="
                + std::to_string(input_id_total) + " sample=["
                + (input_id_sample.empty() ? std::string("none") : input_id_sample) + "]");
        }

        refresh_transit_points_only(game_world);
        cache.last_full_scan_ms = now;
        cache.last_soft_prune_ms = now;
    }

    inline void refresh_triggers(
        Il2CppObject* game_world,
        const std::string& location_id = {},
        const bool force = false) {
        auto& cache = triggers();
        const ULONGLONG now = GetTickCount64();

        // Full scene FindObjectsOfType is extremely expensive on large maps (streets/customs).
        // Soft-prune dead pointers every few seconds; full FOT only rarely.
        constexpr ULONGLONG soft_prune_interval_ms = 8000;
        constexpr ULONGLONG full_scan_interval_ms = 120000;

        const bool world_changed = game_world != cache.last_world;
        const bool location_changed = !location_id.empty()
            && location_id != cache.last_location_id;
        const bool cache_empty = cache.experience_triggers.empty()
            && cache.place_triggers.empty();

        if (world_changed || location_changed)
        {
            cache.experience_triggers.clear();
            cache.place_triggers.clear();
            cache.experience_by_id.clear();
            cache.place_by_id.clear();
            cache.transit_points.clear();
            cache.last_world = game_world;
            if (!location_id.empty())
                cache.last_location_id = location_id;
            full_scan_triggers(game_world);
            return;
        }

        cache.last_world = game_world;
        if (!location_id.empty())
            cache.last_location_id = location_id;

        // Soft prune (pointer validity only) — cheap enough every few seconds.
        if (force || now - cache.last_soft_prune_ms >= soft_prune_interval_ms)
        {
            prune_trigger_pairs(cache.experience_triggers, cache.experience_by_id);
            prune_trigger_pairs(cache.place_triggers, cache.place_by_id);
            prune_transit_points(cache.transit_points);
            cache.last_soft_prune_ms = now;
        }

        const bool need_full =
            force
            || cache_empty
            || (cache.experience_triggers.empty() && cache.place_triggers.empty())
            || (now - cache.last_full_scan_ms >= full_scan_interval_ms);

        if (need_full)
            full_scan_triggers(game_world);
        else if (cache.transit_points.empty() && game_world)
            refresh_transit_points_only(game_world);
    }

    inline bool strings_equal_insensitive(const std::string& a, const std::string& b) {
        if (a.size() != b.size()) return false;
        for (size_t i = 0; i < a.size(); ++i)
        {
            if (std::tolower(static_cast<unsigned char>(a[i]))
                != std::tolower(static_cast<unsigned char>(b[i])))
                return false;
        }
        return true;
    }

    inline bool string_contains_insensitive(const std::string& haystack, const std::string& needle) {
        if (needle.empty() || haystack.empty()) return false;
        if (needle.size() > haystack.size()) return false;

        auto lower = [](unsigned char c) { return static_cast<char>(std::tolower(c)); };
        for (size_t i = 0; i + needle.size() <= haystack.size(); ++i)
        {
            bool match = true;
            for (size_t j = 0; j < needle.size(); ++j)
            {
                if (lower(static_cast<unsigned char>(haystack[i + j]))
                    != lower(static_cast<unsigned char>(needle[j])))
                {
                    match = false;
                    break;
                }
            }
            if (match) return true;
        }
        return false;
    }

    inline Il2CppObject* find_experience_trigger(const std::string& trigger_id) {
        if (trigger_id.empty()) return nullptr;

        const auto& cache = triggers();
        const auto found = cache.experience_by_id.find(trigger_id);
        if (found != cache.experience_by_id.end())
            return found->second;

        for (const auto& [id, trigger] : cache.experience_triggers)
        {
            if (strings_equal_insensitive(id, trigger_id))
                return trigger;
        }
        return nullptr;
    }

    inline Il2CppObject* find_place_trigger(const std::string& zone_id) {
        if (zone_id.empty()) return nullptr;

        const auto& cache = triggers();
        const auto found = cache.place_by_id.find(zone_id);
        if (found != cache.place_by_id.end())
            return found->second;

        for (const auto& [id, trigger] : cache.place_triggers)
        {
            if (strings_equal_insensitive(id, zone_id))
                return trigger;
        }
        return nullptr;
    }

    inline bool transit_matches_destination(const transit_point_entry& transit, const std::string& map_name) {
        if (map_name.empty()) return false;
        if (strings_equal_insensitive(transit.location_id, map_name)) return true;
        if (string_contains_insensitive(transit.location_id, map_name)
            || string_contains_insensitive(map_name, transit.location_id))
            return true;
        if (strings_equal_insensitive(transit.name, map_name)) return true;
        if (strings_equal_insensitive(transit.description, map_name)) return true;
        return false;
    }

    inline void add_poi(std::vector<poi_entry>& out, const unity::vector3& pos,
        const std::string& quest_name, const std::string& description,
        const poi_type type, const unity::vector3& my_pos,
        Il2CppObject* condition = nullptr) {
        if (pos.x == 0.f && pos.y == 0.f && pos.z == 0.f) return;
        out.push_back({pos, quest_name, description, type, my_pos.distance(pos), condition});
    }

    inline std::vector<std::string> read_string_array_field(Il2CppObject* obj, const char* field_name) {
        std::vector<std::string> out;
        if (!obj || !obj->klass || !field_name) return out;

        const FieldInfo* field = il2utils::resolve_field(obj->klass, field_name);
        if (!field) return out;

        Il2CppArray* arr = *reinterpret_cast<Il2CppArray**>(
            reinterpret_cast<uintptr_t>(obj) + field->offset);
        if (!arr || arr->max_length == 0) return out;

        out.reserve(arr->max_length);
        for (size_t i = 0; i < arr->max_length; ++i)
        {
            Il2CppString* str = reinterpret_cast<Il2CppString**>(&arr->data)[i];
            if (!str) continue;
            const std::string value = il2utils::conv_string(str);
            if (!value.empty())
                out.push_back(value);
        }
        return out;
    }

    inline void process_visit_conditions(Il2CppObject* quest, Il2CppObject* condition,
        Il2CppObject* completed_set,
        const std::string& quest_name, std::vector<poi_entry>& out,
        const unity::vector3& my_pos,
        std::unordered_map<std::string, std::string>& desc_cache) {
        if (!class_name_contains(condition, "ConditionVisitPlace")
            && !class_name_contains(condition, "ConditionLocationTrigger"))
            return;

        if (is_condition_completed(quest, condition, completed_set)) return;

        const std::string trigger_id = get_condition_target_string(condition);
        if (trigger_id.empty()) return;

        Il2CppObject* trigger = find_experience_trigger(trigger_id);
        if (!eft_api::is_il2cpp_object_likely_valid(trigger))
            trigger = find_place_trigger(trigger_id);
        if (!eft_api::is_il2cpp_object_likely_valid(trigger)) return;

        // Descriptions filled later on game thread (fill_poi_descriptions) when toggle is on.
        (void)desc_cache;
        add_poi(out, get_object_position(trigger), quest_name,
            {},
            poi_type::visit, my_pos, condition);
    }

    inline void process_inzone_conditions(Il2CppObject* quest, Il2CppObject* condition,
        Il2CppObject* completed_set,
        const std::string& quest_name, std::vector<poi_entry>& out,
        const unity::vector3& my_pos,
        std::unordered_map<std::string, std::string>& desc_cache) {
        if (!class_name_contains(condition, "ConditionInZone")) return;
        if (is_condition_completed(quest, condition, completed_set)) return;

        const std::vector<std::string> zone_ids = read_string_array_field(condition, "zoneIds");
        if (zone_ids.empty()) return;

        (void)desc_cache;
        for (const std::string& zone_id : zone_ids)
        {
            Il2CppObject* trigger = find_experience_trigger(zone_id);
            if (!eft_api::is_il2cpp_object_likely_valid(trigger))
                trigger = find_place_trigger(zone_id);
            if (!eft_api::is_il2cpp_object_likely_valid(trigger)) continue;

            add_poi(out, get_object_position(trigger), quest_name, {},
                poi_type::visit, my_pos, condition);
        }
    }

    // "Use the transit from A to B" — ConditionTransitionLocation (e.g. New Day / New Paths).
    inline void process_transition_conditions(Il2CppObject* quest, Il2CppObject* condition,
        Il2CppObject* completed_set,
        const std::string& quest_name, std::vector<poi_entry>& out,
        const unity::vector3& my_pos,
        std::unordered_map<std::string, std::string>& desc_cache) {
        if (!class_name_contains(condition, "ConditionTransitionLocation")) return;
        if (is_condition_completed(quest, condition, completed_set)) return;

        std::vector<std::string> map_names = read_string_array_field(condition, "<MapNames>k__BackingField");
        if (map_names.empty())
        {
            // JsonProperty "target" maps to MapNames — also try plain target array field.
            map_names = read_string_array_field(condition, "target");
        }
        if (map_names.empty())
        {
            Il2CppObjectInstance cond(condition);
            const auto get_map_names = cond.get_method<Il2CppArray* (*)(Il2CppObject*)>("get_MapNames", 0);
            if (get_map_names)
            {
                if (Il2CppArray* arr = get_map_names(condition))
                {
                    for (size_t i = 0; i < arr->max_length; ++i)
                    {
                        Il2CppString* str = reinterpret_cast<Il2CppString**>(&arr->data)[i];
                        if (!str) continue;
                        const std::string value = il2utils::conv_string(str);
                        if (!value.empty())
                            map_names.push_back(value);
                    }
                }
            }
        }
        if (map_names.empty()) return;

        (void)desc_cache;
        const auto& transit_points = triggers().transit_points;

        for (const transit_point_entry& transit : transit_points)
        {
            if (!eft_api::is_il2cpp_object_likely_valid(transit.point)) continue;

            bool match = false;
            for (const std::string& map_name : map_names)
            {
                if (transit_matches_destination(transit, map_name))
                {
                    match = true;
                    break;
                }
            }
            if (!match) continue;

            add_poi(out, get_object_position(transit.point), quest_name, {},
                poi_type::visit, my_pos, condition);
        }
    }

    inline void register_find_condition(Il2CppObject* quest, Il2CppObject* condition,
        Il2CppObject* completed_set,
        const std::string& quest_name,
        std::vector<find_rule>& rules,
        std::unordered_map<std::string, std::string>& desc_cache) {
        if (!class_name_contains(condition, "ConditionFindItem")) return;

        if (is_condition_completed(quest, condition, completed_set)) return;

        (void)desc_cache;
        rules.push_back({quest_name,
            {}, // description at draw time via condition
            condition});
    }

    // ---------------------------------------------------------------------------
    // The place gate. Everything below replaced `get_zone_id`, deleted with it:
    //
    // It looked for a field named `zoneId`/`zoneID`/`ZoneId`. NO class this gate
    // matches has any of those -- `ConditionZone` and its children carry
    // `zoneIds`, plural, a `string[]`, at a per-class offset (0xE8 on
    // ConditionZone, which inherits `target` at 0xE0 from
    // ConditionMultipleTargets; 0xE0 on ConditionInZone). il2cpp_class_get_field_
    // from_name is an exact strcmp and il2utils::resolve_field walks the
    // inheritance chain upward only, never toward a longer name, so every place
    // objective returned an empty id and bailed at the next line: NO place
    // marker was ever emitted, on any quest, in any raid, in any build since the
    // root commit (bb8615f18, 2026-08-22). Diagnosed in
    // tools/handoff_quest_place_pois.md; the field defect was proven against
    // both GameDumps by tools/quest_condition_fields.py.
    //
    // A ConditionZone with three zone ids must produce THREE markers, which is
    // why this reads the array the way process_inzone_conditions already does
    // rather than renaming the singular lookup. The `zoneID` entry that used to
    // sit in the list exists only on ConditionLaunchFlare, a class
    // is_place_condition_type never matches -- dead, and not evidence the list
    // was ever right.
    // ---------------------------------------------------------------------------
    inline void process_place_condition(Il2CppObject* quest, Il2CppObject* condition,
        Il2CppObject* completed_set,
        const std::string& quest_name,
        std::vector<poi_entry>& out, const unity::vector3& my_pos,
        std::unordered_map<std::string, std::string>& desc_cache) {
        if (!is_place_condition_type(condition)) return;

        if (is_condition_completed(quest, condition, completed_set)) return;

        const std::vector<std::string> zone_ids = read_string_array_field(condition, "zoneIds");

        const char* condition_class = (condition && condition->klass && condition->klass->name)
            ? condition->klass->name
            : "?";

        // One POI per zone id. Capped so a malformed condition cannot emit an
        // unbounded marker set; place conditions carry one or two ids in the
        // dumps, so the cap is far above anything observed.
        constexpr size_t kMaxPlacePoisPerCondition = 16;

        for (size_t i = 0; i < zone_ids.size() && i < kMaxPlacePoisPerCondition; ++i)
        {
            const std::string& zone_id = zone_ids[i];

            Il2CppObject* trigger = find_place_trigger(zone_id);
            const bool found = eft_api::is_il2cpp_object_likely_valid(trigger);

            // The one premise this fix rests on, and it is UNVERIFIED: that a
            // ConditionPlaceBeacon.zoneIds[] entry names a PlaceItemTrigger the
            // trigger cache already holds. Everything supports it (BeaconPlacer
            // keeps a List<PlaceItemTrigger>, PlaceItemTrigger.get_BeaconDummy
            // is the placed position, TryRenameId is how a quest's zone id gets
            // attached at runtime) and nothing proves it. Read the next raid's
            // log for this line: found=0 for every id means the id names
            // something else, and get_InputTriggerIds() -- a property returning
            // IEnumerable<string>, NOT in the cache, since full_scan_triggers
            // registers get_Id and get_TriggerId only -- is the first place to
            // look. found=1 with no marker on screen means the draw path, not
            // the field read, is what is broken.
            //
            // Guarded by debug_enabled() so the argument is not built every
            // cycle with DEBUG off (AGENTS.md: the caller builds it regardless).
            if (logger::debug_enabled())
            {
                logger::debug(std::format("quest esp: place condition {} zoneIds={} id={} found={}",
                    condition_class, zone_ids.size(), zone_id, found ? 1 : 0));
            }

            if (!found) continue;

            (void)desc_cache;
            add_poi(out, get_place_trigger_position(trigger), quest_name,
                {},
                poi_type::place, my_pos, condition);
        }
    }

    inline void process_condition_for_cycle(Il2CppObject* quest, Il2CppObject* condition,
        Il2CppObject* completed_set,
        const std::string& quest_name,
        std::vector<poi_entry>& out,
        std::vector<find_rule>& find_rules,
        const unity::vector3& my_pos,
        std::unordered_map<std::string, std::string>& desc_cache) {
        // The ConditionCounterCreator descent lives in foreach_marker_condition, shared
        // with the completed-sweep, so the set of conditions a marker can be attached to
        // is stated once. Each processor below no-ops on a class it does not handle, so
        // dispatching to all five per condition costs five class-name substring tests and
        // nothing else. The callback carries the condition and nothing else; the quest and
        // the completed set are the same for every condition in the walk.
        foreach_marker_condition(condition,
            [&](Il2CppObject* cond) {
                process_visit_conditions(quest, cond, completed_set, quest_name, out, my_pos, desc_cache);
                process_inzone_conditions(quest, cond, completed_set, quest_name, out, my_pos, desc_cache);
                process_transition_conditions(quest, cond, completed_set, quest_name, out, my_pos, desc_cache);
                register_find_condition(quest, cond, completed_set, quest_name, find_rules, desc_cache);
                process_place_condition(quest, cond, completed_set, quest_name, out, my_pos, desc_cache);
            });
    }

    inline void scan_loot_chunk(
        incremental_collect_state& state,
        const size_t max_items) {
        if (!state.loot_array || state.find_rules.empty() || state.loot_bound == 0) return;

        const size_t end = (std::min)(state.loot_cursor + max_items, state.loot_bound);
        for (size_t i = state.loot_cursor; i < end; ++i)
        {
            Il2CppObject* loot_obj = reinterpret_cast<Il2CppObject**>(&state.loot_array->data)[i];
            if (!eft_api::is_il2cpp_object_likely_valid(loot_obj)) continue;

            Il2CppObject* item_obj = Il2CppObjectInstance(loot_obj).get_field<Il2CppObject*>("_item");
            if (!item_obj || !eft_api::try_get_item_is_quest(item_obj)) continue;

            Il2CppObject* template_obj = eft_api::try_get_item_template(item_obj);
            if (!template_obj) continue;

            const std::string template_id = eft_api::try_get_template_string_id(template_obj);
            if (template_id.empty()) continue;
            // Stale quest loot: template is quest-flagged but no started quest
            // targets it anymore — skip (fail-open while the cache is cold).
            if (!eft_api::is_active_quest_item_id(template_id)) continue;

            Il2CppObject* go = unity::component_get_game_object(loot_obj);
            if (!go) continue;
            Il2CppObject* tr = unity::gameobject_get_transform(go);
            if (!tr) continue;

            const unity::vector3 pos = unity::transform_get_pos(tr);
            for (const find_rule& rule : state.find_rules)
            {
                if (!rule.condition) continue;
                if (!target_array_contains_template(rule.condition, template_id)) continue;
                add_poi(state.result, pos, rule.quest_name, rule.description,
                    poi_type::find, state.my_pos, rule.condition);
            }
        }

        state.loot_cursor = end;
    }

    // ---------------------------------------------------------------------------
    // The quest walk. `start_collect_cycle` is its caller.
    //
    // WHAT THIS COSTS, stated because it was got wrong once. Every
    // `get_QuestController`, `get_Quests`, `get_Name`, `get_ProgressCheckers`,
    // `get_CompletedConditions` and `Contains` below is a MANAGED call, and there
    // are hundreds of them across a late-wipe profile. A comment on this function
    // used to read "the walk itself is field reads and a status filter -- it is
    // the completion probes [that cost]". That is false, and it was false in a
    // code path that then ran the whole walk on a 5 s clock: `esp_scan::
    // quest_poi_scan` had already measured 213 ms max before this was added.
    //
    // A periodic caller therefore must NOT walk. It records what the one
    // raid-long collect establishes -- see condition_owners -- and looks that up.
    //
    // `fn(quest, quest_name, condition, completed_set)` runs for every condition of
    // every condition-collection keyed by Started or AvailableForFinish on every quest
    // at one of those two statuses. Collections keyed by any other quest status are
    // skipped — a collection is the set of objectives that apply *in that status*, and
    // the statuses this reads are the two a player can still act on.
    //
    // Returns false when the game's own state could not be reached at all (no player, no
    // quest controller, no book, no `_questsData`), which is a DIFFERENT answer from
    // "there are no outstanding conditions" and every caller has to keep the two apart:
    // the first means leave the marker set alone, the second means empty it.
    // ---------------------------------------------------------------------------
    template <typename Fn>
    inline bool foreach_outstanding_condition(Il2CppObject* main_player, const Fn& fn) {
        // No `!fn` here: Fn is a lambda, which has no operator bool, and a guard that
        // cannot be written is a guard that is not there.
        if (!main_player || !main_player->klass) return false;

        Il2CppObjectInstance main_player_inst(main_player);
        const auto get_quest_controller = main_player_inst
                                              .get_method<Il2CppObject* (*)(Il2CppObject*)>("get_QuestController", 0);
        if (!get_quest_controller) return false;

        Il2CppObject* quest_controller = get_quest_controller(main_player);
        if (!quest_controller) return false;

        Il2CppObjectInstance qc(quest_controller);
        const auto get_quests = qc.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_Quests", 0);
        if (!get_quests) return false;

        Il2CppObject* quest_book = get_quests(quest_controller);
        if (!quest_book) return false;

        unity::list* quests_data = Il2CppObjectInstance(quest_book).get_field<unity::list*>("_questsData");
        if (!quests_data || !quests_data->m_p_list_array) return false;

        Il2CppArray* quest_array = quests_data->m_p_list_array;
        for (size_t qi = 0; qi < quest_array->max_length; ++qi)
        {
            Il2CppObject* quest_data_ptr = reinterpret_cast<Il2CppObject**>(&quest_array->data)[qi];
            if (!quest_data_ptr || !eft_api::is_il2cpp_object_likely_valid(quest_data_ptr))
                continue;

            // QuestStatusData is the list element — prefer its Status/CompletedConditions.
            // Safe field reads only (get_field null-derefs if the FieldInfo is missing).
            int quest_status = 0;
            try_read_int_field(quest_data_ptr, "Status", quest_status);

            Il2CppObject* quest_ptr = try_read_obj_field(quest_data_ptr, "Quest");
            if (!quest_ptr || !eft_api::is_il2cpp_object_likely_valid(quest_ptr))
                continue;

            if (quest_status != quest_status_started
                && quest_status != quest_status_available_for_finish)
            {
                // Fallback: live status on the Quest instance / nested _statusData.
                if (Il2CppObject* status_obj = try_read_obj_field(quest_ptr, "_statusData"))
                    try_read_int_field(status_obj, "Status", quest_status);
            }
            if (quest_status != quest_status_started
                && quest_status != quest_status_available_for_finish)
                continue;

            const auto get_name = get_method_exact<Il2CppString* (*)(Il2CppObject*)>(
                quest_ptr, "get_Name", 0);
            Il2CppString* quest_name_str = get_name ? get_name(quest_ptr) : nullptr;
            const std::string quest_name = quest_name_str
                ? eft_api::to_display_utf8(il2utils::conv_wstring(quest_name_str))
                : "Quest";

            // HashSet<MongoID> on QuestStatusData.
            Il2CppObject* completed_set = try_read_obj_field(quest_data_ptr, "CompletedConditions");
            if (!completed_set)
            {
                if (Il2CppObject* status_obj = try_read_obj_field(quest_ptr, "_statusData"))
                    completed_set = try_read_obj_field(status_obj, "CompletedConditions");
            }

            foreach_quest_condition_collection(quest_ptr, [&](Il2CppObject* collection, int status_key) {
                if (status_key != quest_status_started
                    && status_key != quest_status_available_for_finish)
                    return;

                foreach_condition_in_collection(collection, [&](Il2CppObject* condition) {
                    foreach_marker_condition(condition, [&](Il2CppObject* cond) {
                        fn(quest_ptr, quest_name, cond, completed_set);
                    });
                });
            });
        }
        return true;
    }

    inline void start_collect_cycle(
        Il2CppObject* game_world,
        Il2CppObject* main_player,
        const unity::vector3& my_pos,
        const std::string& location_id = {}) {
        reset_incremental();
        auto& state = incremental();
        state.phase = collect_phase::building;
        state.my_pos = my_pos;
        state.started_ms = GetTickCount64();
        state.result.clear();
        state.find_rules.clear();
        // Fresh owners for this raid's collect. A raid-scoped table cleared by
        // clear_caches() is only correct if it is also cleared HERE -- otherwise a
        // second raid's collect repopulates a table still holding the first
        // raid's Il2CppObject* and the sweep reads pointers the game has freed.
        condition_owners().clear();

        if (!game_world || !main_player)
        {
            state.phase = collect_phase::idle;
            state.started_ms = 0;
            return;
        }

        // Refresh zone triggers often enough that transit / late scene load cannot leave
        // Quest ESP stuck on destroyed ExperienceTrigger / PlaceItemTrigger pointers.
        refresh_triggers(game_world, location_id, false);

        std::unordered_map<std::string, std::string> desc_cache;

        if (!foreach_outstanding_condition(main_player,
                [&](Il2CppObject* quest, const std::string& quest_name,
                    Il2CppObject* condition, Il2CppObject* completed_set) {
                    // The sweep's only source of truth. One insert per condition,
                    // on the walk that is already happening; see condition_owners.
                    record_condition_owner(condition, quest, completed_set);
                    process_condition_for_cycle(quest, condition, completed_set, quest_name,
                        state.result, state.find_rules, my_pos, desc_cache);
                }))
        {
            state.phase = collect_phase::idle;
            return;
        }

        if (!state.find_rules.empty())
        {
            state.loot_array = try_get_loot_iteration_array(game_world);
            if (state.loot_array)
                state.loot_bound = state.loot_array->max_length;
        }

        if (state.find_rules.empty() || !state.loot_array || state.loot_bound == 0)
            mark_collect_ready(/*authoritative=*/true);
        else
        {
            state.phase = collect_phase::scanning_loot;
            state.loot_cursor = 0;
            state.authoritative = false;
        }

        // Empty-collect diagnostics removed (was log spam under load).
    }

    // ---------------------------------------------------------------------------
    // Drop the markers whose objective the game now reports as finished.
    //
    // WHY THIS EXISTS. `start_collect_cycle` runs ONCE per raid — EspModule gates it on
    // `force_esp_refresh || quest_esp_last_refresh_ms_ == 0` and the comment there says
    // "one full collect until cache clear / manual refresh (no periodic rescan)". So the
    // published marker set IS the completion state as of the moment the player entered
    // the raid, held for as long as the raid lasts. Everything that finishes an objective
    // after that moment — clear a kill counter, place the beacon, find the item, hand the
    // quest in at a trader, die and lose it — leaves its marker on screen until the player
    // extracts or presses refresh. That is the whole of "Quest ESP shows tasks that are
    // already completed", and nothing else in the module re-examined the set afterwards.
    //
    // THE COST, and why it is bounded by the markers rather than by the profile.
    // `foreach_outstanding_condition` visits every condition of every live quest, and
    // `is_condition_completed` is up to three managed calls per condition — on the profile
    // this was written for, a few hundred conditions every sweep. So the completed test
    // runs ONLY on conditions the published set actually references: the `live` set is
    // built first and the walk's callback returns immediately for anything not in it.
    // That turns the per-sweep managed-call count from O(profile) into O(markers), which
    // is what makes a periodic sweep affordable at all. Note the cost is NOT the walk —
    // that is field reads and a status filter — it is the completion probes, and those
    // are now proportional to what is on screen.
    //
    // THE RULE, and it is two conditions, not one: a marker is dropped when its
    // objective is reported finished, OR when its condition is not among the ones the
    // walk reached. The second half is what retires the markers of a quest handed in at
    // a trader -- those conditions are no longer live objectives of a Started or
    // AvailableForFinish quest, so they are not visited -- and it is correct only
    // because `foreach_outstanding_condition` and `foreach_marker_condition` reach the
    // same set `start_collect_cycle` emits from, including the ConditionCounterCreator
    // descent. If those ever stop agreeing, this drops live markers.
    //
    // FAIL-OPEN on the cases where the game has not answered, and only those:
    //   - the quest state was unreachable -> nothing is dropped;
    //   - a marker with no condition at all -> kept.
    // What is NOT treated as unknown: a condition the walk reached and the game called
    // finished, and a condition on a quest that is no longer live. Both are answers.
    //
    // A SET rather than a vector because one condition backs many markers: a
    // ConditionZone with three zone ids emits three POIs sharing that one Condition, and
    // the erase that retires the objective has to retire all three.
    //
    // GAME THREAD ONLY, like everything else in this namespace. Returns how many markers
    // were dropped; `pois` is left untouched when nothing was.
    // ---------------------------------------------------------------------------
    // THE COST, and why it is markers rather than profile now. The first version
    // re-walked the quest book to answer, per marker, "which quest was this
    // condition on" -- a full managed walk of every quest, every condition
    // collection and every condition, with `get_Conditions` / `get_Progress-
    // Checkers` / `get_CompletedConditions` inside it, on a 5 s clock inside the
    // zone that already measured 213 ms max. The commit comment claimed "the walk
    // itself is field reads and a status filter"; those getters are managed calls
    // and there are hundreds of them. The full record is on the comment above
    // `condition_owners`.
    //
    // The collect already visits every (quest, condition, set) triple to decide
    // what to emit. Recording it there costs one unordered_map insert per
    // condition during the walk that is happening anyway, and turns this into a
    // lookup -- no walk, no managed getters, O(markers) probes and nothing else.
    //

    // ---------------------------------------------------------------------------
    // Drop the markers whose objective the game now reports as finished.
    //
    // WHY THIS EXISTS. `start_collect_cycle` runs ONCE per raid — EspModule gates it on
    // `force_esp_refresh || quest_esp_last_refresh_ms_ == 0` and the comment there says
    // "one full collect until cache clear / manual refresh (no periodic rescan)". So the
    // published marker set IS the completion state as of the moment the player entered
    // the raid, held for as long as the raid lasts. Everything that finishes an objective
    // after that moment — clear a kill counter, place the beacon, find the item, hand the
    // quest in at a trader — leaves its marker on screen until the player extracts or
    // presses refresh. That is the whole of "Quest ESP shows tasks that are already
    // completed", and nothing else in the module re-examined the set afterwards.
    //
    // THE COST, and why it is markers rather than profile now. The walk the first
    // version did is in foreach_outstanding_condition's own comment; it was the wrong
    // shape. What is left is a lookup per marker and up to three managed calls in
    // `is_condition_completed`. The comment above condition_owners() records why.
    //
    // THE RULE, and it is two conditions, not one: a marker is dropped when its
    // objective is reported finished, OR when its condition is not among the ones the
    // table names. The second half is what retires the markers of a quest handed in at
    // a trader -- those conditions are no longer live objectives of a Started or
    // AvailableForFinish quest, so they are not revisited -- and it is correct only
    // because the table is filled from the SAME walk the collect emitted from, including
    // the ConditionCounterCreator descent. If those ever stop agreeing, this drops live
    // markers.
    //
    // FAIL-OPEN on the cases where the game has not answered, and only those:
    //   - the quest state was unreachable -> nothing is dropped;
    //   - a marker with no condition at all -> kept;
    //   - no owners recorded at all (no collect ran this raid) -> kept.
    // What is NOT treated as unknown: a condition the table names and the game
    // called finished, and a condition on a quest that is no longer live. Both are
    // answers.
    //
    // A SET rather than a vector because one condition backs many markers: a
    // ConditionZone with three zone ids emits three POIs sharing that one Condition, and
    // the erase that retires the objective has to retire all three.
    //
    // GAME THREAD ONLY, like everything else in this namespace. Returns how many markers
    // were dropped; `pois` is left untouched when nothing was.
    // ---------------------------------------------------------------------------
    inline size_t drop_completed_pois(std::vector<poi_entry>& pois) {
        if (pois.empty()) return 0;
        const auto& owners = condition_owners();
        // No collect has run in this raid, so nothing here can be judged. Keeping
        // the set is the only safe reading: "no table" is not "no objectives".
        if (owners.empty()) return 0;

        // Conditions that are still outstanding objectives. Built from the markers
        // themselves so the retention test is one lookup per marker, and narrowed
        // to what the table names and did not report finished.
        std::unordered_set<Il2CppObject*> live;
        live.reserve(pois.size() * 2);
        for (const poi_entry& poi : pois)
            if (poi.condition) live.insert(poi.condition);

        // Every marker is conditionless, so there is nothing any sweep could learn.
        if (live.empty()) return 0;

        for (auto it = live.begin(); it != live.end();) {
            const auto found = owners.find(*it);
            // A condition the collect's owners table does not name came from a
            // quest that is no longer live -- or from a raid whose table was
            // cleared. Both are "no longer an objective"; neither is a read of
            // the game's state, so this is a decision, not a failure.
            if (found == owners.end()) {
                it = live.erase(it);
                continue;
            }
            if (!is_condition_completed(found->second.quest, *it, found->second.completed_set)) {
                ++it;
                continue;
            }
            it = live.erase(it);
        }

        const size_t original = pois.size();
        size_t write = 0;
        for (size_t read = 0; read < original; ++read) {
            const poi_entry& poi = pois[read];
            if (poi.condition && live.find(poi.condition) == live.end()) continue;
            if (write != read) pois[write] = std::move(pois[read]);
            ++write;
        }

        if (write == original) return 0;
        pois.resize(write);
        return original - write;
    }

    inline bool advance_collect(Il2CppObject* game_world, const size_t max_loot_per_tick) {
        auto& state = incremental();
        if (state.phase != collect_phase::scanning_loot) return false;

        TA_ZONE_N("quest_esp::collect");
        // Re-bind loot list each tick — the internal array can be reallocated while we scan.
        if (Il2CppArray* live = try_get_loot_iteration_array(game_world))
        {
            state.loot_array = live;
            state.loot_bound = live->max_length;
            if (state.loot_cursor > state.loot_bound)
                state.loot_cursor = state.loot_bound;
        }
        else
        {
            // Loot list gone mid-scan — publish visit/place already collected (authoritative enough).
            mark_collect_ready(/*authoritative=*/true);
            return true;
        }

        if (state.loot_bound == 0 || state.find_rules.empty())
        {
            mark_collect_ready(/*authoritative=*/true);
            return true;
        }

        scan_loot_chunk(state, max_loot_per_tick);
        if (state.loot_cursor >= state.loot_bound)
            mark_collect_ready(/*authoritative=*/true);

        return state.phase == collect_phase::ready;
    }

    inline bool is_collect_ready() {
        return incremental().phase == collect_phase::ready;
    }

    // Returns POIs and whether the cycle was a full/authoritative collect (safe to clear store).
    inline std::vector<poi_entry> take_collect_result(bool* out_authoritative = nullptr) {
        auto& state = incremental();
        if (out_authoritative)
            *out_authoritative = state.authoritative;
        std::vector<poi_entry> result = std::move(state.result);
        reset_incremental();
        return result;
    }

    inline bool is_collect_idle() {
        return incremental().phase == collect_phase::idle;
    }

    inline bool is_collect_scanning_loot() {
        return incremental().phase == collect_phase::scanning_loot;
    }
} // namespace quest_esp