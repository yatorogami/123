#include "common.h"
#include "ModuleManager.h"
#include "../util/tracy_bridge.h"

ModuleManager::~ModuleManager() {
    for (auto module : modules)
    {
        delete static_cast<Module*>(module);
    }
}

void ModuleManager::init() const {
    auto* self = const_cast<ModuleManager*>(this);
    hotkeys::clear_bindings();
    hotkeys::register_esp(self->esp_module);
    hotkeys::register_minimap(self->minimap_module);
    hotkeys::register_map(self->map_module);
    hotkeys::register_player(self->player_module, self->ai_limit_module);
    hotkeys::register_weapon(self->weapon_module);
    hotkeys::register_doors(self->doors_module);
    hotkeys::register_world(self->world_module);
    hotkeys::register_ammo_hud(self->ammo_hud_module);
    hotkeys::register_icebreaker_scenario(self->icebreaker_scenario_module);
    hotkeys::register_config(self->config_module);
#ifdef INCLUDE_AIMBOT
    hotkeys::register_aimbot(self->aimbot_module);
#endif

    for (auto module : modules)
    {
        auto* m = static_cast<Module*>(module);
        logger::info("  init: " + m->name);
        m->init();
        logger::info("  done: " + m->name);
    }
}

void ModuleManager::apply(const std::function<void(Module*)>& function) const {
    // Every module's per-frame work hangs off this one call, so a zone here is
    // what turns the flame graph from "one frame" into "which module cost what".
    // Without it the children are flat siblings and the per-module attribution has
    // to be inferred from zone names.
    //
    // The inner zone is what the 2026-10-01 profile asked for. This function ran
    // 110,105 calls carrying 35.0 s of SELF time -- 6.44% of the session, 318 us
    // per call -- with nothing at all underneath it, because every module's
    // per-frame body lands here unzoned. Only EspModule was measured, and only on
    // two of its three entry points. So the one number that should say "which
    // module is expensive" had no way to say it.
    //
    // One zone carrying the name as text, rather than twenty zones: same answer,
    // one entry in the zone list, and it sits AFTER the is_active() gate so it
    // only fires for modules that actually run.
    TA_ZONE_N("frame::ModuleManager::apply");
    for (auto module : modules)
    {
        auto* m = static_cast<Module*>(module);
        if (!m->is_active()) continue;
        {
            // The module's NAME is the zone name, not text attached to one shared
            // zone. This was "frame::module" + ZoneText(m->name), and that is the
            // difference between a number you can query and a number you can only
            // read by eye in the UI: Tracy aggregates custom-named zones BY NAME, so
            // a shared name collapses every module into one row, while TA_ZONE_TEXT
            // lands in the per-call payload and never reaches the zone statistics at
            // all. The CSV export -- which is how these traces have been read --
            // therefore showed a single "frame::module" row carrying 2,577,013 calls
            // and 70.03 s with no way to split it by module.
            //
            // The 2026-10-01 profile added this zone precisely to answer "which module
            // is expensive". With the name as text it could not answer that in export,
            // only in the live UI, so the question survived three sessions.
            //
            // m->name is a std::string, so .data() is NUL-terminated (C++11 and later)
            // and valid for the strlen in the macro. Cost when profiling is a short
            // memcpy of the module name into the queue; when not profiling, Zone's
            // ctor returns on the running() check before touching any of it.
            TA_ZONE_N(m->name.data());
            function(m);
        }
    }
}

void ModuleManager::apply_all(const std::function<void(Module*)>& function) const {
    TA_ZONE_N("frame::ModuleManager::apply_all");
    for (auto module : modules)
    {
        function(static_cast<Module*>(module));
    }
}

std::vector<Module*> ModuleManager::get_modules() const {
    auto res = std::vector<Module*>();
    for (auto module : modules)
    {
        res.push_back(static_cast<Module*>(module));
    }
    return res;
}

ModuleManager* ModuleManager::get_instance() {
    if (!instance)
    {
        instance = new ModuleManager();
    }
    return instance;
}

bool ModuleManager::has_module(const std::string& name) const {
    for (auto module : modules)
    {
        if (static_cast<Module*>(module)->name == name) return true;
    }
    return false;
}
