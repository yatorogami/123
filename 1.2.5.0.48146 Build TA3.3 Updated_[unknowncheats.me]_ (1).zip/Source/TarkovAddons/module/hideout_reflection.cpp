#include "common.h"
#include "hideout_reflection.h"

[[nodiscard]] float hideout_resource::fraction() const {
    float value = -1.0f;
    if (timer_total > 0 && timer_left >= 0)
        value = static_cast<float>(timer_left) / static_cast<float>(timer_total);
    else if (resource_total > 0.0 && resource_left >= 0.0)
        value = static_cast<float>(resource_left / resource_total);
    if (value < 0.0f) return 0.0f;
    return value > 1.0f ? 1.0f : value;
}

[[nodiscard]] float hideout_resource::slots_remaining() const {
    if (supplies_capacity <= 0) return 0.0f;
    return fraction() * static_cast<float>(supplies_capacity);
}
