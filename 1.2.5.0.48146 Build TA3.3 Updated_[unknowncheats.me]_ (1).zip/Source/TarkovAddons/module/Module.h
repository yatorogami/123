#pragma once
#include <imgui.h>
#include <vector>
#include <functional>

#include "ModuleCategory.h"
#include "../config/ConfigValue.h"
#include "../il2cpp/Il2CppObjectInstance.h"
#include "../il2cpp/libil2cpp/il2cpp-api-types.h"

class Module
{
  public:
    virtual ~Module();

    Module(std::string name, const ModuleCategory category, std::string display_key = {});

    std::string name;
    ModuleCategory category;
    // Retain a module's implementation while omitting its card from the menu.
    bool hidden_in_category_menu = false;

    [[nodiscard]] const std::string& get_display_key() const;

    virtual void draw_overlay(ImDrawList* draw_list) = 0;
    virtual void application_update() = 0;
    virtual void application_update([[maybe_unused]] Il2CppObject* application);
    virtual void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
        Il2CppObjectInstance main_player) = 0;
    virtual void init() = 0;

    virtual void draw_menu_extra();

    // A small number of bridge cards need their manually-owned controls before
    // their registered values. The default preserves the existing menu order.
    [[nodiscard]] virtual bool draw_menu_extra_before_values() const;

    virtual void prepare_menu_draw();

    virtual void clear_runtime_cache();

    [[nodiscard]] virtual size_t get_runtime_cache_count();

    [[nodiscard]] virtual size_t get_runtime_cache_bytes();

    // Returns true if the module has any active features that need per-frame processing.
    // Override in modules with master toggles to skip entirely when all features are off.
    [[nodiscard]] virtual bool is_active() const { return true; }

    std::vector<ConfigValue*> config_values = std::vector<ConfigValue*>();

    void apply(const std::function<void(ConfigValue*)>& function) const;

    template <typename T>
    T* conf(T* value) {
        value->reg(this->name);
        config_values.push_back(value);
        return value;
    }

  private:
    std::string display_key_;
};
