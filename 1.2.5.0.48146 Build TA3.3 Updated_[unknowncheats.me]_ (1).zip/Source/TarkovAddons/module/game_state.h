#pragma once

#include <atomic>

#include "../il2cpp/libil2cpp/il2cpp-api-types.h"

// IMPORTANT: use `inline` (not `static`) so all TUs share one instance.
// `static` in a header gives each .cpp its own copy — hotkeys_register.cpp
// writing esp_manual_refresh_request would not be seen by EspModule.

namespace game_state {
    // ---------------------------------------------------------------------------
    // is_in_raid is ATOMIC, and it is written from more than one thread.
    //
    // Measured 2026-10-03, build 6AC13F71: hk_local_raid_ended logs on tid 1028
    // (the game thread) while cam-choice — i.e. EspModule::draw_overlay, which
    // gates on this flag — logs on tid 31900 (the render thread). Game writes,
    // render reads, same process. A plain bool is a data race there; it happens
    // to work on x86 and it is still UB.
    //
    // Relaxed on purpose. Every existing reader is a single boolean test whose
    // worst outcome is one frame drawn or not drawn, and a seq_cst store would
    // put an mfence on the exfil path for no gain. Nothing here orders the flag
    // against other memory — it gates work, it does not publish it.
    //
    // READ IT DIRECTLY for the plain boolean test; that is a relaxed load and
    // compiles unchanged at all ~70 existing call sites. WRITE IT ONLY THROUGH
    // set_in_raid() below — a bare assignment would skip the edge bookkeeping
    // that clears the region memos, and those are the whole reason the flag and
    // the memos have to change together.
    inline std::atomic<bool> is_in_raid{ false };

    // The single writer. Defined in common_hooks.cpp, which is where the two
    // memo-clearing functions it must call are visible; game_state.h is a leaf
    // header (il2cpp types only) and must stay one.
    //
    // Both edges are asymmetric on purpose:
    //
    //   FALSE — driven by the event. hk_local_raid_ended is the game's own
    //     "this raid is over" call, and it is the EARLIEST point at which we
    //     know the world is going away: it fires before o_local_raid_ended runs,
    //     which is before the game tears anything down. Measured 22:57:09.841 on
    //     the exfil crash — our own "Local Raid Ended" line is the last thing
    //     known to have executed before the process died, so this hook is as
    //     early as the flag can honestly go.
    //
    //   TRUE — driven by evidence, NOT by hk_local_raid_started. That hook is the
    //     REQUEST side of a raid start: its own comment says "nothing about the
    //     destination is knowable here", the RPC result is not unpacked until
    //     later, and LocalGameCreate fires ~3 s afterwards. Setting true there
    //     would enable all ~18 gated files against a world that does not exist
    //     yet — and draw_overlay, which gates on this flag and nothing else,
    //     would resolve a camera with no MainPlayer and no GameWorld. That is
    //     the exact crash class this change exists to remove. TRUE is set from
    //     hk_game_world_update once MainPlayer is confirmed non-null, which is
    //     the same moment raid_start_guard_load_complete() calls the destination
    //     "finished loading".
    //
    // The polled InGameStatus.InRaid read remains as a ONE-WAY BACKSTOP: it may
    // clear the flag, it may never set it. Event-only would be strictly worse if
    // an event is ever missed (alt-F4, disconnect, a crash inside the game's own
    // handler before our line runs), because the flag would then read true for
    // the rest of the session — a worse failure than the one being fixed.
    // Returns TRUE if this call actually moved the flag. False means it was already at
    // `value` and nothing happened.
    //
    // That return value is load-bearing, not convenience. The first version of the
    // raid-boundary diagnostic logged on "the poll read false", which outside a raid is
    // every single frame: 16,964 identical lines, 59% of a 28,682-line log (measured
    // 2026-10-04, build 6AC16917). tools/tracy/README.md's flooding rule applies to our
    // own diagnostics exactly as it does to logger::error -- a line that repeats every
    // frame makes the whole log unauditable, and it was hiding a real crash sitting in
    // the last 67 lines.
    bool set_in_raid(bool value) noexcept;

    // The EVENT half of the false edge. Called from hk_local_raid_ended with nothing but
    // "the game said the raid is over".
    //
    // Declared here, in the leaf header, rather than in common_hooks.h: the hook that
    // needs it lives in ItemModule.h, and including common_hooks.h from there would be
    // circular (common_hooks.h pulls ModuleManager.h, which pulls ItemModule.h). The hook
    // must not have to know about the ratchet, the poll, or the memo clears -- it reports
    // the event and that is all it knows.
    void on_local_raid_ended_event() noexcept;
    inline float current_zoom = 1;
    // ESP world-to-screen zoom for the current overlay frame (1 when projecting via optic camera).
    inline float esp_draw_zoom = 1;
    // Optic ESP projection state (set once per overlay frame in EspModule).
    inline bool esp_optic_proj = false;
    // ACTIVE INVESTIGATION (2026-10-05): does the optic root-position outlier
    // filter apply? true = OFF, i.e. the filter is skipped. Mirrors
    // EspModule::optic_root_corrector ("ON" there means the filter applies), so
    // this reads as the DISABLED state rather than duplicating the enabled one.
    //
    // It lives here, not in a config lookup, because the reader is
    // optics_lens_pipeline.h and the writer is EspModule: game_state is the
    // existing channel between exactly those two, and every other optic flag
    // above travels the same way. A CheckboxValue is a member of EspModule, so
    // the pipeline cannot reach it without including a module it must not.
    //
    // atomic because the menu draws on the same thread but the corrector runs on
    // whichever thread owns the optic frame, and a plain bool would be a data race
    // rather than a stale read.
    inline std::atomic<bool> optic_root_corrector_off{ false };
    inline Il2CppObject* esp_optic_cam = nullptr;
    // Last optic camera that setup_esp_optic_frame() actually resolved, kept across
    // frames. NOT a substitute for esp_optic_cam, which is cleared every frame on
    // purpose so consumers can tell "no optic projection this frame" from a stale
    // pointer. This exists only so DIAGNOSTICS that run mid-frame have something to
    // read: optic_lens_ensure_frame() is called from inside setup_esp_optic_frame()
    // while esp_optic_cam is still null (it is assigned at the very end), so the
    // `optic-fov` trace was gated on a pointer that is structurally null at both of
    // its hot call sites and produced ZERO lines for a whole raid on 2026-09-30.
    inline Il2CppObject* esp_optic_cam_cached = nullptr;
    // Scales offset-from-center for optic W2S (probe-calibrated * user slider).
    inline float esp_optic_radial = 1.f;

    // ---------------------------------------------------------------------------
    // WHO WROTE esp_optic_radial, AND WHEN? (2026-09-29 22:30)
    //
    // There are exactly two writers of esp_optic_radial in eft_api.h:
    //     :2746  esp_optic_radial = 1.f;      -- UNCONDITIONAL, top of setup_esp_optic_frame
    //     :2827  esp_optic_radial = k;        -- only reached if (using_optic && cam)
    // and exactly one reader, world_to_screen() at :2491, which passes it straight into
    // world_to_screen_optic. So this global IS the applied radial scale.
    //
    // The 22:18 log contradicts that reading. `optic-proj` prints radK from THIS variable
    // and reported radK=1.000 in 67 of 68 samples, while `optic-state` printed final_k
    // over 0.062..0.849 in the same seconds -- and final_k is assigned from the SAME local
    // `k` five lines earlier (:2822 vs :2827). Two adjacent assignments of one value that
    // disagree at the point of measurement is not a tuning problem; it means one of the two
    // reports does not describe the applied value.
    //
    // The suspicious asymmetry: the reset is UNCONDITIONAL and the calibration is
    // CONDITIONAL. Any second call to setup_esp_optic_frame in a pass where using_optic is
    // false -- a non-ADS pass, the aimbot's own path -- leaves the global at 1.0 for
    // whatever consumer runs next. That is a hypothesis, not a measurement.
    //
    // These two counters are the measurement. `epoch` increments on EVERY write, so
    //     radK_epoch == set_epoch   => last write was the calibration, and radK must equal
    //                                 `radK_set`. If they differ there, the bug is upstream.
    //     radK_epoch != set_epoch   => the last write was the unconditional reset, i.e.
    //                                 setup_esp_optic_frame ran a pass that did not reach
    //                                 the calibration. Calibration never reaches the consumer.
    // Also counts calls, to see whether the function is invoked more than once per overlay
    // frame -- which is what would make the reset win.
    inline unsigned long long esp_optic_radial_epoch = 0;   // bumped by every write
    inline unsigned long long esp_optic_radial_set_epoch = 0;  // epoch of the last :2827 write
    inline float esp_optic_radial_set = 1.f;               // the k written at :2827
    inline unsigned long long esp_optic_frame_calls = 0;   // setup_esp_optic_frame invocations

    // The value AS DRAWN, captured inside world_to_screen() on the first point projected
    // at each new epoch. The dump samples at a 600 ms boundary, which lands after an
    // arbitrary number of setup_esp_optic_frame calls -- and since the reset at :2746 is
    // unconditional, the dump can only ever observe the reset state. That is a property of
    // WHERE THE PROBE IS, not evidence about what the projection used. These two record the
    // value the first point of each epoch was actually projected with, which is the only
    // reading that answers the question.
    inline float esp_optic_radial_drawn = 1.f;
    inline float esp_optic_radial_drawn_set = 1.f;
    inline unsigned long long esp_optic_radial_drawn_epoch = 0;

    // Section 7 two-pass region split (optic_idea.md line 574). When on, a point OUTSIDE
    // the fitted lens mask is drawn through the MAIN camera instead of the optic camera,
    // because the game renders the periphery with the main camera -- a full-screen scope
    // mask is only meaningful if something shows outside it.
    //
    // Measured 2026-09-27: the mask covers 15-20% of the screen and ~85% of projected
    // points fall outside it, so with this off most of the ESP is drawn through a camera
    // magnifying ~5.8x. That was the reported "objects outside the scope get enlarged".
    //
    // Kept as a runtime flag rather than hard-wired because the periphery rendering is
    // the one part of this the disassembly implies rather than states: the architectural
    // argument and the measurement both point this way, but whether a given scope blacks
    // out its surround instead of showing the eye view is a per-optic rendering detail
    // best confirmed by looking. One toggle settles it without a rebuild.
    inline bool esp_optic_s7 = true;

    // What to do with ESP that lands OUTSIDE the fitted lens mask.
    //
    // 2026-09-27. This started as a binary "route the periphery through the main camera",
    // derived from an architectural argument: ScopeMaskRenderer builds a FULL-SCREEN mask
    // texture, and a mask is only meaningful if something shows outside it. The measurement
    // supported the argument and it was implemented -- main_outside ran at 3k-43k per
    // drain, so the routing demonstrably happened.
    //
    // The argument was still wrong, and the user report settled it. A magnified scope is
    // a CAMERA-IN-CAMERA WITH A CUTOUT: the surround is not a second view, it is the scope
    // housing, and objects falling there sit in a DEAD VISIBILITY ZONE. This log is a
    // magnified scope (`m11` ~19.07, i.e. fov ~6 deg, `cover` ~16% of the screen) and the
    // report was that ESP kept drawing outside the glass with no boundary at all. Routing
    // those points to the main camera put ESP over the housing -- the same class of wrong
    // as drawing them magnified, only less obviously so.
    //
    // Default is therefore a hard CULL, which is what the game does. Main-camera routing
    // is kept because it IS correct for a 1x optic, where the game renders the eye view
    // around the glass.
    enum class optic_periphery {
        cull = 0,        // outside the mask is NOT drawn. Magnified scope. DEFAULT.
        main_camera = 1, // outside the mask is drawn at 1x. 1x optic / red dot.
    };
    inline optic_periphery esp_optic_periphery = optic_periphery::cull;

    // Dual ADS ESP mask (EspModule sets per pass; is_visible respects it).
    // 0 = off, 1 = keep only OUTSIDE shape (eye layer), 2 = keep only INSIDE (optic layer).
    inline int esp_ads_mask_mode = 0;
    inline float esp_ads_mask_cx = 0.f;
    inline float esp_ads_mask_cy = 0.f;
    inline float esp_ads_mask_half = 0.f; // radius (circle) or half-side (square), pixels
    inline bool esp_ads_mask_circle = true;
    // Dual ADS active this frame (EspModule); aimbot marker uses it for no-zoom rear plane.
    inline bool esp_dual_ads_active = false;
    inline float esp_optic_user_scale = 1.f;

    // ---- section 7 clipping counters -----------------------------------------
    // The ONE live clip path, finally counted.
    //
    // 2026-10-01. `esp_mask_cull_checks` / `esp_mask_cull_rejected` above were measured
    // over 80 samples to be structurally zero: esp_ads_mask_allows() short-circuits on
    // mode==0, which clear_esp_ads_mask() sets every frame. So the cull accounting that
    // was supposed to answer "is the mask hiding too much, and which model is hiding it"
    // has never once counted anything.
    //
    // Meanwhile the clipping that actually happens runs through
    // eft_api::optic_lens_segment_interval / _segment_s7 against the fitted polygon, and
    // those have NO counters at all. So the entire visible region behaviour -- which
    // pieces survive, how often nothing is clipped at all, how often the caller silently
    // draws unclipped because there was no packet -- was unmeasured.
    //
    // `unclipped_calls` is the one that matters most: it is the count of times a caller
    // asked for a clipped segment and got "no, draw it whole". If that is non-zero while
    // the packet looks healthy, the over-coverage report has a second cause entirely
    // outside the ellipse geometry.
    struct s7_counters {
        unsigned long long interval_calls = 0;   // optic_lens_segment_interval entries
        unsigned long long interval_ok = 0;      // produced an inside interval
        unsigned long long interval_full = 0;    // t0~0 and t1~1: nothing was clipped
        unsigned long long interval_none = 0;    // returned false: caller draws unclipped
        unsigned long long s7_calls = 0;         // optic_lens_segment_s7 entries
        unsigned long long s7_inside = 0;        // had an inside piece
        unsigned long long s7_outside = 0;       // had one or two outside pieces
        unsigned long long s7_none = 0;          // returned false: caller draws unclipped

        // The split that "no outside piece" needed, and did not have.
        //
        // 2026-10-01. The first run of these counters reported bare=716 of 736
        // inside-bearing segments and that number meant nothing, because "no outside piece"
        // is two completely different outcomes:
        //
        //   fully_inside    t0~0 and t1~1: the segment lies ENTIRELY inside the glass, so
        //                   the complement [0,t0] U [t1,1] is empty by construction. The
        //                   two-pass is behaving perfectly and there is nothing to fix.
        //   complement_lost t0>0 or t1<1: the segment CROSSES the glass boundary, so the
        //                   complement should be non-empty and is not. That is a real
        //                   geometry defect: the outside part of the segment is being
        //                   dropped, or resolved from a camera it should not be.
        //
        // 97% bare is more likely fully_inside than complement_lost -- through a magnified
        // optic most ESP geometry is inside the glass -- but "more likely" is the same kind
        // of reasoning that produced the esp_ads_mask_half comment, which named the wrong
        // variable and was never checked. These are separated rather than assumed.
        unsigned long long s7_fully_inside = 0;
        unsigned long long s7_complement_lost = 0;
        // Splits by WHY _s7 declined, since "returned false" has four distinct causes
        // with four different fixes and they used to be indistinguishable.
        unsigned long long s7_decl_proj = 0;     // optic projection off this frame
        unsigned long long s7_decl_s7 = 0;       // esp_optic_s7 toggle off
        unsigned long long s7_decl_nopacket = 0; // no valid packet: draws unclipped
        unsigned long long s7_decl_size = 0;     // menu w/h degenerate

        // The same four causes for optic_lens_segment_interval, which the first version of
        // this struct did not count at all.
        //
        // 2026-10-01. Reporting "interval ok=0" from that omission led to the conclusion
        // that the function was dead code. It is not: it has two live callers, in
        // EspModule.cpp (the box-corner cross and the bone-link clip), and BOTH draw the
        // segment unclipped when it returns false. So 966 declining calls is 966 bone
        // links and box corners spilling over the scope picture -- not zero calls.
        //
        // Worse, the omission made the counter look conclusive. `interval_calls` was
        // incremented and then no outcome counter moved, which reads exactly like "called
        // and never succeeded" when the truth was "called and declined before the only
        // counted path". A counter whose total does not reconcile with its parts should not
        // be trusted to say anything, including that code is unreachable.
        unsigned long long interval_decl_proj = 0;
        unsigned long long interval_decl_nopacket = 0;
        unsigned long long interval_decl_size = 0;
    };
    inline s7_counters esp_s7{};

    // Not reset per frame. The drain lives in eft_api's rate-limited block, alongside the
    // rest of the region reporting, for the same reason as esp_mask_cull_* above: the
    // per-frame clear would zero them before they could accumulate.
    inline void clear_esp_ads_mask() {
        esp_ads_mask_mode = 0;
        // Deliberately does NOT reset the cull counters: this runs once per frame, so
        // resetting here would zero them before they accumulated. They are drained by the
        // rate-limited block in eft_api::optic_lens_ensure_frame instead.
    }

    // Real lens opening from the optics lens pipeline (menu pixels, CCW convex).
    // Populated by eft_api when the pipeline packet is valid; count == 0 falls
    // back to the user-sized circle/square below.
    inline float esp_lens_mask_px[64 * 2] = {};
    inline int esp_lens_mask_count = 0;

    inline bool esp_lens_mask_contains(const float x, const float y) {
        const int n = esp_lens_mask_count;
        if (n < 3) return false;
        // Convex CCW polygon: inside = every edge cross product >= 0.
        for (int i = 0; i < n; ++i) {
            const int j = (i + 1) % n;
            const float ex = esp_lens_mask_px[j * 2] - esp_lens_mask_px[i * 2];
            const float ey = esp_lens_mask_px[j * 2 + 1] - esp_lens_mask_px[i * 2 + 1];
            const float px = x - esp_lens_mask_px[i * 2];
            const float py = y - esp_lens_mask_px[i * 2 + 1];
            if (ex * py - ey * px < 0.f) return false;
        }
        return true;
    }

    inline bool esp_ads_mask_contains(const float x, const float y) {
        // Pipeline-fitted scope opening wins whenever it is available; the
        // user-sized circle/square remains the fallback (pipeline rejected).
        if (esp_lens_mask_count >= 3)
            return esp_lens_mask_contains(x, y);
        const float dx = x - esp_ads_mask_cx;
        const float dy = y - esp_ads_mask_cy;
        const float h = esp_ads_mask_half;
        if (h <= 0.f) return false;
        if (esp_ads_mask_circle)
            return (dx * dx + dy * dy) <= (h * h);
        return (dx <= h && dx >= -h && dy <= h && dy >= -h);
    }

    // Cull accounting. "Everything is hidden at certain angles" is a report about a
    // COUNT, so it should be measurable rather than inferred. Reset per interval by the
    // drain in eft_api's rate-limited optic-perf block.
    //
    // `fitted_used` separates the two mask sources: the pipeline's fitted polygon
    // (esp_lens_mask_px, an approximation of the opening -- the spec calls it "an
    // approximation, not a reconstruction") versus the user's own circle/square. When
    // the fitted mask is what is hiding objects, the rejection count here is the
    // magnitude of the problem and `fitted_used` says which model caused it.
    inline unsigned long long esp_mask_cull_checks = 0;
    inline unsigned long long esp_mask_cull_rejected = 0;
    inline unsigned long long esp_mask_cull_fitted_used = 0;
    inline int esp_mask_cull_mode_at_count = 0;

    // Zoom-path provenance. Added because "1.5x too much with Dual off" could not be
    // attributed from the log: the only visible number was `radK` AFTER clamping, which
    // hides both the raw calibration and the fact that the clamp engaged.
    //
    // The suspicion these expose: `calibrate_optic_radial_scale_impl` measures how much
    // the optic camera's own narrow FOV magnifies a 1.25 m lateral probe, and
    // `map_optic_pixels_to_menu` then applies that factor AGAIN as a radial scale. The
    // spec is explicit that it should not (line 40): "Magnification already comes from the
    // optic projection, so changing from 1x to 5x does not require another multiplication
    // by five." The [0.15, 1.5] clamp then silently floors the over-count at 1.5.
    inline float esp_zoom_auto_k = 1.f;        // raw calibration, before user scale/clamp
    inline float esp_zoom_user_k = 1.f;
    inline float esp_zoom_final_k = 1.f;       // after clamp
    inline bool esp_zoom_k_clamped = false;
    inline float esp_zoom_scope_zoom = 1.f;    // game_state::current_zoom this frame
    inline bool esp_zoom_using_optic = false;
    inline bool esp_zoom_dual = false;
    inline bool esp_zoom_packet_valid = false;

    inline bool esp_ads_mask_allows(const float x, const float y) {
        if (esp_ads_mask_mode == 0) return true;
        ++esp_mask_cull_checks;
        const bool inside = esp_ads_mask_contains(x, y);
        if (esp_lens_mask_count >= 3) ++esp_mask_cull_fitted_used;
        // mode 1 = outside only (eye), mode 2 = inside only (optic)
        const bool allowed = esp_ads_mask_mode == 1 ? !inside : inside;
        if (!allowed) ++esp_mask_cull_rejected;
        esp_mask_cull_mode_at_count = esp_ads_mask_mode;
        return allowed;
    }

    // ESP data refresh (ConfigModule → EspModule). rate > 1 = more frequent, < 1 = rarer.
    inline float esp_loot_update_rate = 0.25f;
    inline float esp_container_update_rate = 0.25f;
    inline float esp_quest_update_rate = 0.25f;
    inline bool esp_manual_refresh_mode = false;
    // Set by hotkey / button; consumed once by EspModule gameworld_update.
    inline bool esp_manual_refresh_request = false;
    inline Il2CppObject* item_factory = nullptr;
} // namespace game_state
