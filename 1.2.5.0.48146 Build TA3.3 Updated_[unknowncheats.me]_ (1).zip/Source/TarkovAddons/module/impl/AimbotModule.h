#pragma once

// Everything in this file is aimbot-only, and the aimbot is a build flavour
// ("Prod no aimbot" defines nothing, every other config defines
// INCLUDE_AIMBOT). The guard used to exist on exactly two things --
// ModuleManager's instantiation of the module and the hotkey panel's heading --
// so a no-aimbot build still compiled and linked the whole thing: the bone
// resolver, the shared target/fireport state, the InitiateShot hook and its
// trampoline slot. That is the opposite of what the flavour promises, and it
// is why AimbotModule.cpp appears in the no-aimbot compile list.
//
// The guard belongs HERE rather than only on the two .cpp files so that no
// translation unit can reach the type or its shared state at all. It costs the
// no-aimbot build one empty AimbotModule.cpp; dropping that file from the
// project per-configuration would need the define promoted from a
// PreprocessorDefinitions entry to a project property, which is a larger change
// than the one empty translation unit it saves.
#ifdef INCLUDE_AIMBOT

#include "../../config/CheckboxValue.h"
#include "../../config/ColorpickerValue.h"
#include "../../config/FloatSliderEditableValue.h"
#include "../../config/SelectValue.h"
#include "../../gui/menu/menu.h"
#include "../../il2cpp/Il2CppObjectInstance.h"
#include "../../il2cpp/il2utils.h"
#include "../../il2cpp/libil2cpp/il2cpp-class-internals.h"
#include "../../il2cpp/libil2cpp/il2cpp-object-internals.h"
#include "../../il2cpp/unity.h"
#include "../../util/logger.h"
// For TA_ZONE_N, used by the bone resolvers below. Also reachable through
// ../eft_api.h, but stated explicitly rather than relied on transitively: these
// zones are load-bearing for answering "is the aimbot expensive", and a future
// edit to eft_api.h's include list should not silently uninstrument them.
#include "../../util/tracy_bridge.h"
#include "../Module.h"
#include "../ModuleCategory.h"
#include "../eft_api.h"
#include "../game_state.h"
#include "../skeleton_visibility.h"
#include <cmath>
#include <cstdarg>
#include <cstring>
#include <imgui.h>
#include <map>
#include <string>
#include <string_view>
#include <Windows.h>
#include <format>

// Aimbot bone resolution utilities for targeting
// These functions help resolve player body parts for aim assistance
namespace aimbot_bones {

    /**
     * Gets the position of a bifacial transform object
     * @param bifacial The bifacial transform object
     * @param out Output vector for the position
     * @return true if successful, false otherwise
     */
    inline bool get_bifacial_pos(Il2CppObject *bifacial, unity::vector3 &out) {
        // Was a fourth copy of this resolve+call+isfinite sequence. It now delegates to the
        // one in eft_api, which is the same function with the same checks -- see the note on
        // eft_api::try_get_managed_position for why there is exactly one.
        return eft_api::try_get_managed_position(bifacial, out);
    }

    /**
     * Gets the position of a skeleton bone by suffix
     * @param player_obj The player object
     * @param suffix The bone suffix to search for
     * @param out Output vector for the position
     * @return true if successful, false otherwise
     */
    inline bool get_skeleton_suffix_pos(Il2CppObject *player_obj,
        const char *suffix, unity::vector3 &out) {
        TA_ZONE_N("aimbot::get_skeleton_suffix_pos");
        if (!player_obj || !suffix)
            return false;
        Il2CppObjectInstance player(player_obj);
        Il2CppObject *body = player.get_field<Il2CppObject *>("_playerBody");
        if (!body)
            return false;
        Il2CppObjectInstance body_inst(body);
        Il2CppObject *skel = body_inst.get_field<Il2CppObject *>("Skeleton");
        if (!skel)
            skel = body_inst.get_field<Il2CppObject *>("_skeleton");
        if (!skel)
            return false;
        Il2CppObjectInstance sk(skel);
        unity::list *keys = sk.get_field<unity::list *>("_keys");
        unity::list *values = sk.get_field<unity::list *>("_values");
        if (!keys || !values || !keys->m_p_list_array || !values->m_p_list_array)
            return false;
        Il2CppArray *ka = keys->m_p_list_array;
        Il2CppArray *va = values->m_p_list_array;
        const size_t n =
            ka->max_length < va->max_length ? ka->max_length : va->max_length;

        // The needle is widened ONCE, here, instead of per entry below. It is a
        // compile-time literal at all four call sites ("Base HumanLCalf" and
        // friends), so the buffer cannot overflow in practice; it is bounded
        // anyway, and a suffix too long to fit returns false rather than
        // truncating into a match that is not the bone being asked for.
        constexpr size_t needle_max = 63;
        wchar_t needle_buf[needle_max + 1]{};
        size_t needle_len = 0;
        for (; suffix[needle_len] != '\0' && needle_len < needle_max; ++needle_len)
            needle_buf[needle_len] = static_cast<unsigned char>(suffix[needle_len]);
        if (suffix[needle_len] != '\0')
            return false;
        const std::wstring_view needle(needle_buf, needle_len);

        for (size_t i = 0; i < n; ++i)
        {
            Il2CppString *key_str = reinterpret_cast<Il2CppString **>(&ka->data)[i];
            if (!key_str || key_str->length <= 0)
                continue;
            // Matched in place as UTF-16, with no conversion at all.
            //
            // This was `const std::string key = il2utils::conv_string(key_str)`,
            // and conv_string is conv_wstring followed by wide_to_utf8 -- so it cost
            // TWO heap allocations and a WideCharToMultiByte() call pair for every
            // entry in the Skeleton dictionary, per target, per frame, purely to do a
            // substring test. That is an unbounded allocation rate on a per-frame
            // path, which is worth removing on its own terms.
            //
            // What it is NOT worth is overstated, so the measurement is here: over a
            // 67-entry dictionary modelled on EFT's rig, the old path cost 1.40-1.51
            // us per call against 0.24-0.26 us now, so 5.8x. At ~122 calls/s and a
            // candidate or two per frame that is roughly 17 ms/s -- about 0.03% of a
            // core. The 2026-10-01 capture put the whole aimbot wall check at 0.18%,
            // so this was never the CPU sink, and claiming otherwise after reading
            // the code alone would have been wrong. It is an allocation removed from
            // a hot loop, not a fix for a frame-rate problem.
            //
            // Il2CppString already carries length + chars, so a wstring_view over it
            // is the same search with nothing allocated and nothing converted. A
            // UTF-16 needle finds exactly what the UTF-8 one did: the suffixes are
            // ASCII, and UTF-8 encodes ASCII as single bytes, so the two searches
            // agree on every input this can see.
            const std::wstring_view key(key_str->chars,
                static_cast<size_t>(key_str->length));
            if (key.find(needle) == std::wstring_view::npos)
                continue;
            Il2CppObject *transform = reinterpret_cast<Il2CppObject **>(&va->data)[i];
            if (!transform)
                return false;
            out = unity::transform_get_pos(transform);
            return std::isfinite(out.x);
        }
        return false;
    }

    /**
     * Gets a player bone field by name
     * @param pb The player bones object
     * @param field_name The name of the field to get
     * @param as_transform Whether to treat as transform
     * @param out Output vector for the position
     * @return true if successful, false otherwise
     */
    inline bool get_player_bone_field(Il2CppObject *pb, const char *field_name,
        const bool as_transform,
        unity::vector3 &out) {
        if (!pb || !pb->klass || !field_name)
            return false;
        const FieldInfo *field = il2utils::resolve_field(pb->klass, field_name);
        if (!field || field->offset <= 0)
            return false;
        Il2CppObject *bone_obj = *reinterpret_cast<Il2CppObject **>(
            reinterpret_cast<uintptr_t>(pb) + field->offset);
        if (!bone_obj)
            return false;
        if (as_transform || std::strcmp(field_name, "Neck") == 0 || std::strcmp(field_name, "LeftPalm") == 0 || std::strcmp(field_name, "RightPalm") == 0)
        {
            out = unity::transform_get_pos(bone_obj);
            return std::isfinite(out.x);
        }
        return get_bifacial_pos(bone_obj, out);
    }

    /**
     * Resolves an aim bone position for a player
     * @param player_obj The player object
     * @param bone_idx The bone index to resolve
     * @param out Output vector for the position
     * @return true if successful, false otherwise
     */
    inline bool resolve_aim_bone(Il2CppObject *player_obj, const int bone_idx,
        unity::vector3 &out) {
        TA_ZONE_N("aimbot::resolve_aim_bone");
        if (!player_obj)
            return false;
        Il2CppObjectInstance player(player_obj);
        Il2CppObject *body = player.get_field<Il2CppObject *>("_playerBody");
        if (!body)
            return false;
        Il2CppObjectInstance body_inst(body);
        Il2CppObject *pb = body_inst.get_field<Il2CppObject *>("PlayerBones");
        if (!pb || !pb->klass)
            return false;

        bool ok = false;
        switch (bone_idx)
        {
        case 0:
            ok = get_player_bone_field(pb, "Head", false, out);
            break;
        case 1:
            ok = get_player_bone_field(pb, "Neck", true, out);
            break;
        case 2:
            ok = get_player_bone_field(pb, "Spine3", false, out);
            break;
        case 3:
            ok = get_player_bone_field(pb, "Pelvis", false, out);
            break;
        case 4:
            ok = get_player_bone_field(pb, "LeftShoulder", false, out);
            break;
        case 5:
            ok = get_player_bone_field(pb, "RightShoulder", false, out);
            break;
        case 6:
            ok = get_player_bone_field(pb, "LeftPalm", true, out);
            break;
        case 7:
            ok = get_player_bone_field(pb, "RightPalm", true, out);
            break;
        case 8:
            ok = get_player_bone_field(pb, "LeftThigh2", false, out);
            break;
        case 9:
            ok = get_player_bone_field(pb, "RightThigh2", false, out);
            break;
        case 10:
            ok = get_skeleton_suffix_pos(player_obj, "Base HumanLCalf", out);
            break;
        case 11:
            ok = get_skeleton_suffix_pos(player_obj, "Base HumanRCalf", out);
            break;
        case 12:
            ok = get_skeleton_suffix_pos(player_obj, "Base HumanLFoot", out);
            break;
        case 13:
            ok = get_skeleton_suffix_pos(player_obj, "Base HumanRFoot", out);
            break;
        default:
            ok = get_player_bone_field(pb, "Head", false, out);
            break;
        }
        return ok;
    }

    /**
     * Moves the mouse by specified delta values
     * @param dx Horizontal delta
     * @param dy Vertical delta
     */
    inline void move_mouse(int dx, int dy) {
        INPUT input = {0};
        input.type = INPUT_MOUSE;
        input.mi.dx = dx;
        input.mi.dy = dy;
        input.mi.dwFlags = MOUSEEVENTF_MOVE;
        SendInput(1, &input, sizeof(INPUT));
    }

    /**
     * Performs aim assistance by moving mouse towards target
     * @param target Target screen position
     * @param screen_center Screen center position
     * @param smoothing Smoothing factor
     */
    inline void aimbot(unity::vector2 target, unity::vector2 screen_center, float smoothing) {
        float dx = (target.x - screen_center.x) / smoothing;
        float dy = (target.y - screen_center.y) / smoothing;

        if (fabsf(dx) < 0.5f && fabsf(dy) < 0.5f) return;

        move_mouse((int)dx, (int)dy);
    }
} // namespace aimbot_bones

/// Stores the target position for aimbot
inline unity::vector3 target_store = {};
/// Stores the player's position
inline unity::vector3 player_pos = {};
/// Stores the local player's fireport (muzzle) position, refreshed per world tick
inline unity::vector3 fireport_pos = {};
/// counter for dumping player pos
inline int counter = 0;
/// Flag indicating if target is valid
inline bool target_valid = false;
/// Stores the local player object (stable during raid)
inline Il2CppObject *local_player_store = nullptr;
/// Flag indicating whether we should teleport the bullet or not
inline bool should_tp_bullet = false;

/// Function signature for the original initiate_shot method
using initiate_shot_sig = void (*)(Il2CppObject *, Il2CppObject *,
    Il2CppObject *, unity::vector3,
    unity::vector3, unity::vector3, int, float);
/// Original initiate_shot function pointer
inline initiate_shot_sig o_initiate_shot;

/**
 * Hook function for initiate_shot that modifies shot behavior
 * @param instance The FirearmController instance
 * @param weapon The weapon object
 * @param ammo The ammo object
 * @param shot_position The shot position
 * @param shot_direction The shot direction
 * @param fireport_position The fireport position
 * @param chamber_index The chamber index
 * @param overheat The overheat value
 */
inline void hk_initiate_shot(Il2CppObject *instance, Il2CppObject *weapon,
    Il2CppObject *ammo, unity::vector3 shot_position,
    unity::vector3 shot_direction,
    unity::vector3 fireport_position,
    int chamber_index, float overheat) {
    // ZONED 2026-10-04, and this function had NO zone at all until now.
    //
    // Why that mattered: it is the only aimbot path that runs on the game's shot
    // rather than on our frame, so it is invisible in every capture taken so far.
    // A capture that showed the aimbot costing nothing and the game hitching could
    // not distinguish "the aimbot did not cause it" from "the aimbot caused it here".
    //
    // It also re-derives the fireport at `:initiate_shot:fireport` below, and that
    // call is **NOT** covered by the `hands_not_firearm` gate added to
    // `gameworld_update` -- the gate is local to that function. So the one call
    // measured at 40-72 ms per invocation during a loading screen is still
    // reachable from here. That is deliberate for now: a shot during a load is not
    // a thing a player does, and the gate's evidence is about the per-frame path.
    // Zoned rather than changed, so a capture can say how often this is actually
    // hit before anyone decides whether it needs one.
    TA_ZONE_N("aimbot::initiate_shot");

    if (target_valid)
    {
        // Only redirect the local player's shots.  Matching profile nicknames
        // was unreliable after a transition because the profile instance can
        // be rebuilt while FirearmController is kept alive.
        Il2CppObject *player_obj = nullptr;
        {
            // `get_field("_player")` is a memoised resolve_field plus one managed
            // read. Its own zone because this is the only place the shot path
            // resolves anything at all, and "the redirect never fired" and "the
            // redirect fired and was slow" are different bugs with the same symptom.
            TA_ZONE_N("aimbot::initiate_shot:player_field");
            Il2CppObjectInstance hands_controller_instance(instance);
            player_obj = hands_controller_instance.get_field<Il2CppObject *>("_player");
        }
        if (player_obj != nullptr && player_obj == local_player_store)
        {
            if (should_tp_bullet)
            {
                {
                    // Spawn slightly above aim point, fire downward through the body part.
                    TA_ZONE_N("aimbot::initiate_shot:tp_bullet");
                    shot_position = target_store;
                    shot_position.y += 0.08f;
                    shot_direction = {0.f, -1.f, 0.f};
                    fireport_position = target_store;
                }
            }
            else
            {
                // Point the shot at the locked target from the CURRENT fireport.
                // target_store was computed in gameworld_update (a different tick);
                // the fireport moves with every frame of hand/recoil animation and
                // FovShotCompensation then skews the direction relative to it, so
                // re-deriving here keeps the ray exactly on the target.
                bool have_fireport_now = false;
                unity::vector3 fireport_now{};
                {
                    // The expensive one, and the reason this function is zoned.
                    // `try_get_fireport_position` is the call that measured 310 s and
                    // then 180 s and then 166 s in three captures -- all of it
                    // `Bifacial.get_position()`, all of it during a loading screen.
                    TA_ZONE_N("aimbot::initiate_shot:fireport");
                    FIREPORT_SITE("aimbot/initiate_shot");
                    have_fireport_now = skeleton_vis::try_get_fireport_position(
                        player_obj, fireport_now);
                }
                if (have_fireport_now)
                {
                    {
                        TA_ZONE_N("aimbot::initiate_shot:direction");
                        const unity::vector3 to_target = target_store - fireport_now;
                        // NB: use the free length()/normalize() — the vector3 member
                        // length() is squared and member normalize() divides by it.
                        if (unity::length(to_target) > 1e-4f
                            && std::isfinite(to_target.x) && std::isfinite(to_target.y)
                            && std::isfinite(to_target.z))
                        {
                            // must be unit length: Shot.Init does _velocity = direction * speed
                            shot_direction = unity::normalize(to_target);
                        }
                    }
                }
                // If the fireport read fails (between weapons etc.), fall back to
                // the original vector built from fireport_position — still better
                // than firing a stale half-second-old direction.
                //
                // Zoned separately because it is a DIFFERENT ANSWER, not a slower
                // version of the same one: reaching it means the fireport read
                // failed, which during a load it may do for tens of seconds. A
                // capture that shows this zone hot is showing a fallback path
                // carrying the traffic, not the intended path being slow.
                else if (const unity::vector3 fb =
                             target_store - fireport_position;
                    unity::length(fb) > 1e-4f)
                {
                    {
                        TA_ZONE_N("aimbot::initiate_shot:stale_direction");
                        shot_direction = unity::normalize(fb);
                    }
                }
            }
        }
    }

    {
        // The game's own call. Zoned so the redirect above can be read as a
        // fraction of the hook rather than of the frame: this is where the time
        // goes when we are not the problem, and without it the hook's own cost and
        // the work it wraps are one number.
        TA_ZONE_N("aimbot::initiate_shot:game_call");
        o_initiate_shot(instance, weapon, ammo, shot_position, shot_direction,
            fireport_position, chamber_index, overheat);
    }
}

class AimbotModule : Module
{
  public:
    /// Constructor for AimbotModule
    AimbotModule();

    // Every config value below is a raw pointer owned by this object and created
    // in the constructor's member-init list, nowhere else. They carry `= nullptr`
    // defaults DELIBERATELY, and the reason is a crash rather than a style rule.
    //
    // On 2026-10-03 12:38:03 `show_cone` was declared here and dereferenced in
    // draw_overlay, but was missing from the constructor's init list. The i18n
    // key was already in every lang/*.json, the member was documented, and
    // draw_overlay and aim_cone_radius() were written -- everything except that
    // one line shipped. With no default initializer the member held INDETERMINATE
    // memory, and the first render frame in a raid read through it:
    // ACCESS_VIOLATION, READ of 0x50, AimbotModule::draw_overlay+0xCA, render
    // thread, via dxPresent11 -> draw_imgui -> menu::draw -> ModuleManager::apply.
    //
    // Two mistakes are separable here and both matter. The missing line is the
    // bug; the missing initializer is why the failure was undefined rather than
    // merely wrong. A raw pointer with no initializer is not null -- it is
    // whatever the allocator handed back -- so the same omission would next time
    // read through a wild address instead of faulting at 0x0. With `= nullptr`,
    // an omission is a deterministic null dereference at a known line.
    //
    // This is the lesson of the hook_method trap in AGENTS_TODO.md §0, and it is
    // the same shape as §3.7's duplicate "Info" config id: fix the call site AND
    // make the mistake impossible to express. The init list in the .cpp is now
    // the single place these can be set and it names every one of them.

    /// Map to store target objects sorted by distance
    std::map<float, Il2CppObject *> target_objects;

    /// Select value for aim feature
    /// None / Magic Bullet / Aim Assist
    SelectValue *aim_type = nullptr;
    /**
     * Draw the filled dot on the locked target.
     *
     * SEPARATE from show_cone on purpose, and the two answer different questions:
     *
     *   show_cone  -> WHERE am I allowed to lock. A large outline marking the eligible
     *                 region around the reticle. It is a calibration aid, off by default,
     *                 and says nothing about whether anything is currently selected.
     *   show_target-> WHAT am I aiming at. One small marker on the chosen bone, inside
     *                 or outside that region, moving as the pick changes.
     *
     * Conflating them would make the common case unreadable: with the cone on and a
     * target locked, you want to see BOTH -- the circle to know your limits, the dot to
     * know your choice. Turning the cone off must not hide the dot, which is the one
     * that matters in a fight, and turning the dot off must not remove the circle, since
     * the circle is what tells you why a target is not being picked.
     */
    CheckboxValue *show_target = nullptr;
    /// Slider for target size
    FloatSliderEditableValue *target_size = nullptr;
    /**
     * Opacity multiplier for BOTH the target dot and the selection cone, 0..1.
     *
     * A separate control from target_color's own alpha, which does work -- the shared
     * picker is a ColorEdit4 with AlphaPreviewHalf and GetColorU32 packs the alpha
     * byte -- but it is buried in a popup with no numeric readout, which is a poor way
     * to dial an overlay you are trying to see through. This is the slider form of the
     * same idea and it MULTIPLIES the picker's alpha, so the two compose rather than
     * fight: picker 0.5 x this 0.5 = 0.25.
     *
     * Deliberately a multiplier and not a second absolute alpha. Two absolute values
     * for one property is a control that lies about its own state.
     */
    FloatSliderEditableValue *target_opacity = nullptr;
    /// Slider for maximum distance
    FloatSliderEditableValue *max_distance = nullptr;
    /**
     * Radius of the selection cone around the screen centre, as a percentage of
     * screen height. 0 disables it (whole screen eligible, the old behaviour).
     *
     * Percent-of-height rather than raw pixels so the covered FIELD OF VIEW is
     * the same on a 1080p and a 1440p screen: pixels are square, so a pixel
     * radius is a circle on screen either way, but the fraction of the view it
     * spans would otherwise double with resolution.
     */
    FloatSliderEditableValue *aim_cone = nullptr;
    /// Checkbox for drawing the selection cone on screen. Default off: it is a
    /// calibration aid, and a large circle around the crosshair is not something
    /// to have on by default in an overlay.
    CheckboxValue *show_cone = nullptr;

    /**
     * The cone's OWN colour and opacity, separate from the target dot's.
     *
     * These two existed as an omission, not a decision: aim_cone and show_cone were
     * added without a colour, and the outline inherited target_color. So a user who
     * wanted the cone legible but the target dot subtle -- or the reverse, which is
     * the more common ask, since the cone covers the middle of the screen where every
     * target's head is -- had one knob for two things drawn at very different sizes.
     *
     * The cone is also the only element that is purely a calibration aid, so it earns
     * its own settings: it defaults to a dim cyan rather than the target magenta so
     * that turning it on does not immediately recolour the thing you are aiming at.
     */
    ColorpickerValue *cone_color = nullptr;
    /// Opacity multiplier for the cone outline, 0..1. Same multiply-not-replace
    /// relationship with the picker's own alpha as target_opacity has.
    FloatSliderEditableValue *cone_opacity = nullptr;

    /**
     * Selection-cone radius in pixels: aim_cone as a percentage of screen height.
     * 0 means disabled, and the whole screen is eligible.
     *
     * Defined once and called from BOTH the gate in gameworld_update and the
     * outline in draw_overlay, because those two must agree exactly. Written
     * twice they would drift, and a circle that does not line up with the region
     * it claims to show is worse than not drawing it at all.
     */
    [[nodiscard]] float aim_cone_radius() const {
        // Shared by the render thread (draw_overlay) and the gameworld thread
        // (gameworld_update), so it is read from both. The null guard is cheap
        // and turns a future omission from a crash on either thread into "cone
        // disabled", which is the correct answer for a calibration aid anyway.
        if (!aim_cone)
            return 0.f;
        const float pct = aim_cone->get_value();
        return pct > 0.f
            ? (pct / 100.f) * static_cast<float>(menu::get_height())
            : 0.f;
    }
    /// Slider for aim smoothness
    FloatSliderEditableValue *aim_smoothness = nullptr;
    /// Checkbox for ballistic prediction (lead + drop)
    CheckboxValue *velocity_tracking = nullptr;
    /// Checkbox for wall check
    CheckboxValue *wall_check = nullptr;
    /// Color picker for target color
    ColorpickerValue *target_color = nullptr;

    /**
     * The target DOT's colour, opacity applied.
     *
     * Only the filled dot reads this now. It previously also drove the cone outline,
     * which is why the cone had no colour of its own.
     */
    [[nodiscard]] ImVec4 target_tint() const {
        ImVec4 c = target_color ? target_color->get_value() : ImVec4(1.f, 0.f, 1.f, 1.f);
        if (target_opacity)
            c.w *= target_opacity->get_value();
        return c;
    }

    /**
     * The cone outline's colour, opacity applied. Deliberately a separate function
     * from target_tint() rather than a parameter: the two are configured
     * independently, and folding them back together is exactly the bug this replaced.
     */
    [[nodiscard]] ImVec4 cone_tint() const {
        ImVec4 c = cone_color ? cone_color->get_value() : ImVec4(0.f, 1.f, 1.f, 1.f);
        if (cone_opacity)
            c.w *= cone_opacity->get_value();
        return c;
    }
    /// Select value for aim bone selection
    SelectValue *aim_bone = nullptr;

    /**
     * Draws the aimbot overlay on screen
     * @param draw_list The ImGui draw list
     */
    void draw_overlay(ImDrawList *draw_list) override;

    /**
     * Updates application state
     */
    void application_update() override;

    /**
     * Updates game world state
     * @param game_world_class The game world class
     * @param game_world_instance The game world instance
     * @param main_player The main player instance
     */
    void gameworld_update(const Il2CppClass *game_world_class,
        Il2CppObjectInstance game_world_instance,
        Il2CppObjectInstance main_player) override;

    /**
     * Initializes the aimbot module
     */
    void init() override;

  private:
    eft_api::weapon_ammo_state cached_{};
};

#endif // INCLUDE_AIMBOT