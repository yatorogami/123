#include "common.h"
#include "ChamsModule.h"

// PROTOTYPE, one call site -- see module/material_catalogue.h. Delete both to
// remove. Not referenced by any other module.
#include "../material_catalogue.h"

ChamsModule::ChamsModule() : Module("Chams", Exploit, "chams_mod"),
                             player_chams(conf(new CheckboxValue(false, "player_chams_cb"))),
                             gear_chams(conf(new CheckboxValue(false, "gear_chams_cb"))),
                             chams_type(conf(new SelectValue(0, {"solid_sel", "wireframe_sel", "forcefield_sel", "glass_sel", "lava_sel", "outline_sel"}, "chams_type_sel"))),
                             visible_color(conf(new ColorpickerValue({0, 1, 1, 0.75}, "visible_color_clr"))),
                             invisible_color(conf(new ColorpickerValue({0, 0, 1, 0.75}, "invisible_color_clr"))),
                             weapon_chams(conf(new CheckboxValue(false, "weapon_chams_cb"))),
                             weapon_chams_type(conf(
                                 new SelectValue(5, {"solid_sel", "wireframe_sel", "forcefield_sel", "glass_sel", "lava_sel", "outline_sel"}, "weapon_chams_type_sel"))),
                             weapon_chams_color(conf(new ColorpickerValue({0.7f, 0.7f, 0.7f, 1}, "weapon_color_clr"))),
                             include_scope(conf(new CheckboxValue(false, "include_scope_cb"))),
                             include_arms(conf(new CheckboxValue(false, "include_arms_cb"))),
                             item_chams(conf(new CheckboxValue(false, "item_chams_cb"))),
                             item_chams_type(conf(
                                 new SelectValue(0, {"solid_sel", "wireframe_sel", "forcefield_sel", "glass_sel", "lava_sel", "outline_sel"}, "item_chams_type_sel"))),
                             item_visible_color(conf(new ColorpickerValue({1, 0.85f, 0.1f, 1}, "item_visible_color_clr"))),
                             item_occluded_color(conf(new ColorpickerValue({1, 0.15f, 0.15f, 1}, "item_occluded_color_clr"))),
                             item_chams_distance(conf(new FloatSliderEditableValue(100.f, 1.f, 300.f, "item_chams_distance_sld"))),
                             container_chams(conf(new CheckboxValue(false, "container_chams_cb"))),
                             container_chams_type(conf(
                                 new SelectValue(0, {"solid_sel", "wireframe_sel", "forcefield_sel", "glass_sel", "lava_sel", "outline_sel"}, "container_chams_type_sel"))),
                             container_visible_color(conf(new ColorpickerValue({0.2f, 1.f, 0.4f, 0.85f}, "container_visible_color_clr"))),
                             container_occluded_color(conf(new ColorpickerValue({0.05f, 0.5f, 0.2f, 0.6f}, "container_occluded_color_clr"))),
                             container_chams_distance(conf(new FloatSliderEditableValue(100.f, 1.f, 300.f, "container_chams_distance_sld"))) {
    chams_module_self = this;
    visible_color->set_hidden_in_owner_menu(true);
    invisible_color->set_hidden_in_owner_menu(true);
    weapon_chams_color->set_hidden_in_owner_menu(true);
}

std::string ChamsModule::get_shader_name(const int id) {
    switch (id)
    {
    case 0:
        return "chams.shader";
    case 1:
        return "wireframe.shader";
    case 2:
        return "forcefield.shader";
    case 3:
        return "glass.shader";
    case 4:
        return "lava.shader";
    case 5:
        return "outline.shader";
    default:
        return "";
    }
}

void ChamsModule::draw_overlay(ImDrawList* draw_list) {
}

void ChamsModule::application_update() {
    // The raid-end half of the boundary reset, and the reason it is HERE rather
    // than in gameworld_update: hk_game_world_update gates every module's
    // gameworld_update on game_state::is_in_raid, so the instant a raid ends --
    // death, exfil, disconnect -- nothing in gameworld_update runs again to notice.
    // hk_tarkov_application_update has no such gate and calls this every frame, in
    // the menu and in the hideout too.
    //
    // So an exfil leaves the container chams bookkeeping pointing at a scene that
    // is being torn down unless something outside the raid loop drops it. The
    // transit half is handled by the GameWorld-instance check in
    // gameworld_update; this is the exfil half. Both call the same
    // reset_container_chams_state, which forgets rather than restores.
    //
    // Cost when there is nothing to do: three size() calls on empty containers,
    // once per frame, no log.
    if (!game_state::is_in_raid)
        reset_container_chams_state();
}

unity::color ChamsModule::to_unity_color(const ImVec4& c) {
    // color's 4-arg constructor is explicit — direct-init it here
    return unity::color(c.x, c.y, c.z, c.w);
}

ImU32 ChamsModule::pack_color(const ImVec4& c) {
    return static_cast<ImU32>(static_cast<ImU32>(c.x * 255.f + 0.5f)
        | (static_cast<ImU32>(c.y * 255.f + 0.5f) << 8)
        | (static_cast<ImU32>(c.z * 255.f + 0.5f) << 16)
        | (static_cast<ImU32>(c.w * 255.f + 0.5f) << 24));
}

bool ChamsModule::is_item_renderer(const Il2CppObject* renderer) {
    if (!renderer || !renderer->klass || !renderer->klass->name) return false;
    const char* name = renderer->klass->name;
    return strcmp(name, "MeshRenderer") == 0 || strcmp(name, "SkinnedMeshRenderer") == 0;
}

void ChamsModule::report_item_chams_scan(const scan_stats& st, const size_t loot_count,
    const size_t cursor_at_entry, const size_t cursor_after, Il2CppObject* shader,
    const size_t applied_set_size, const size_t saved_set_size, const size_t swept) {
    if (!logger::debug_enabled()) return;
    static ULONGLONG s_last_trace = 0;
    const ULONGLONG now = GetTickCount64();
    // A tick that DID work is always reported, throttle or not. The first version throttled
    // unconditionally, and because the 8 s repaint does all its work in ONE tick and the
    // 250 ms scan cadence then runs idle, the throttle landed on the idle tail: 140 of 141
    // lines read `cursor=1000->1000 examined=0`, which is the exact shape of the bug the
    // trace exists to detect. A diagnostic that mostly prints the symptom of the defect it
    // is looking for is worse than none, because it looks like a confirmation.
    const bool did_work = st.examined > 0;
    if (!did_work && s_last_trace != 0 && now - s_last_trace < kItemChamsTraceMs) return;
    s_last_trace = now;

    // HOW TO READ THIS LINE, because the two candidate defects look identical from outside
    // the game -- both present as "some items have no chams texture":
    //
    //   cursor=loot, examined=0, applied=0
    //       The cursor is parked at the end and there is nothing to do. This is the bug
    //       where applied_items was cleared without rewinding the cursor, so the re-paint
    //       could not reach anything. Fixed by rewinding, so this shape should now be
    //       preceded by a "cursor rewound to 0" line instead.
    //
    //   applied>0, zero_renderer==applied, renderers=0
    //       Items are being visited and recorded, but nothing is actually painted. That is
    //       is_item_renderer() rejecting every renderer, or the _renderers list being
    //       empty. The item is no longer recorded in this state, so it will be retried.
    //
    //   out_of_range high, applied>0
    //       Working as intended: the distance gate is holding items back until the player
    //       walks closer. Not a defect.
    //
    //   unpainted > 0
    //       Items left the radius and were restored. Non-zero is NORMAL and is the point:
    //       distance is a real radius, so walking away turns the chams back off. If this
    //       is 0 while out_of_range is high and things stayed lit, the restore path is
    //       not firing and the paint is still one-way.
    //
    //   unaccounted > 0
    //       A branch in the scan loop is not counting itself. Should always be 0. If it is
    //       not, the counts above do not reconcile and `applied` is not a fraction of
    //       anything -- which is exactly the state the first version of this line shipped
    //       in, with 949 of 1000 examined items unattributable.
    //
    //   materials > renderers, multi_slot > 0
    //       Items on this map have multi-slot meshes, and every slot is being painted.
    //       Before the fix this read materials == renderers no matter what, because only
    //       material[0] was ever touched: the one count that could have revealed submeshes
    //       was the same count that hid them.
    //
    //   swept > 0
    //       Saved materials dropped because they named items no longer in the loot list.
    //       This is NORMAL and expected: the player picked items up. It is the counter
    //       that proves the address-reuse restore bug is being cleaned up rather than
    //       accumulating -- if swept is 0 while saved sits well above applied_set, the
    //       sweep is not running and stale entries are still there.
    //       saved should track applied_set closely once this is working.
    //
    // applied_set_size is PASSED IN rather than read from applied_items, because this is a
    // static member and has no `this`. Reading applied_items.size() here is a compile error,
    // and the first draft of this function did exactly that. saved_set_size is passed in for
    // the same reason -- the first draft of the un-paint change reached for
    // original_item_materials.size() here and produced exactly this C2228, which is the
    // clearest evidence yet that the "static has no this" rule is not decorative.
    // Every branch of the scan loop increments exactly one counter, so the counts RECONCILE:
    // examined == null + corpse + already + no_game_object + no_transform + out_of_range + applied.
    // The first version left the corpse and null-transform branches uncounted and 949 of 1000
    // examined items were unattributable, which made "44 applied" unreadable as "44 of the
    // items that should have been painted". `unaccounted` is printed so a future branch that
    // forgets to count itself is visible rather than silent.
    //
    // AND THE INVENTORY IS WRONG WITHOUT null_obj. A first in-game capture (2026-10-01
    // 18:36, 127 scan lines) printed unaccounted=945 against null=945 on every single full
    // pass, and the numbers matched exactly -- which is the signature of one specific
    // omission, not of an uncounted mystery branch. null_obj is a real branch of this loop
    // (the unused tail of the LootItems backing array) and it was counted but not summed.
    // The reconciliation was therefore reporting a defect that did not exist, on every
    // line, which is worse than not printing it: it is the exact failure this field was
    // added to prevent, and it would have sent the next reader hunting a phantom branch.
    const size_t accounted = st.null_obj + st.corpse + st.already + st.no_game_object
        + st.no_transform + st.out_of_range + st.applied;
    const size_t unaccounted = st.examined > accounted ? st.examined - accounted : 0;

    logger::debug(std::format(
        "item-chams: loot={} cursor={}->{} examined={} applied={} renderers={} materials={} "
        "multi_slot={} zero_renderer={} oor={} unpainted={} already={} corpse={} no_go={} "
        "no_xform={} null={} unaccounted={} cap={} shader={} applied_set={} saved={} swept={}",
        loot_count, cursor_at_entry, cursor_after, st.examined, st.applied, st.renderers,
        st.materials, st.multi_slot, st.zero_renderer, st.out_of_range, st.unpainted, st.already,
        st.corpse, st.no_game_object, st.no_transform, st.null_obj, unaccounted, st.hit_cap,
        shader ? "ok" : "NULL", applied_set_size, saved_set_size, swept));
}

void ChamsModule::item_chams_reapply_if_settings_changed() {
    const int type = item_chams_type->get_value();
    const ImU32 visible = pack_color(item_visible_color->get_value());
    const ImU32 occluded = pack_color(item_occluded_color->get_value());
    if (type == item_chams_last_type_ && visible == item_chams_last_visible_
        && occluded == item_chams_last_occluded_)
        return;
    item_chams_last_type_ = type;
    item_chams_last_visible_ = visible;
    item_chams_last_occluded_ = occluded;
    // applied_items is dropped, but the SAVED materials are not: those record what the
    // renderer looked like before we ever touched it, which is still the truth. Keeping
    // them is what stops a colour change from making the item un-paintable -- if we
    // dropped them here, the re-paint would overwrite the originals with the previous
    // chams and walking out of range would then "restore" the chams.
    applied_items.clear();
    // Cursor with it: a settings change invalidates every recorded "already chams'd" item,
    // and the re-apply it triggers can only reach what the cursor has not passed.
    item_chams_last_scanned_index_ = 0;
}

Il2CppObject* ChamsModule::load_item_chams_shader(const Il2CppImage* unity_image, const int type_id) {
    const auto cached = item_shader_cache_.find(type_id);
    if (cached != item_shader_cache_.end())
    {
        // The cached shader may have died with the old scene on transit:
        // Unity destroys the native shader (m_CachedPtr zeroed) while our
        // cached wrapper pointer stays non-null. Applying a dead shader is
        // what makes items render purple/pink and opaque — evict everything
        // and ask the update hook for a fresh AssetBundle instead.
        if (unity::is_unity_object_alive(cached->second, "chams/shader_cache")) return cached->second;
        item_shader_cache_.clear();
        applied_items.clear();
        // Rewind for the same reason as every other clear site: after a transit the whole
        // scene has been rebuilt, so every item is a fresh object and none of them can be
        // treated as already chams'd. Without this the post-transit repaint had nothing to
        // do, which is one of the two shapes the trace line is written to distinguish.
        item_chams_last_scanned_index_ = 0;
        asset_bundles::request_reload();
        logger::info("Item chams: cached shader dead after transit - AssetBundle reload requested");
        return nullptr;
    }
    if (!asset_bundles::asset_bundle) return nullptr;
    const std::string shader_name = get_shader_name(type_id);
    if (shader_name.empty()) return nullptr;
    Il2CppObject* shader_system_type = il2utils::get_system_type(unity_image, "UnityEngine", "Shader");
    if (!shader_system_type) return nullptr;
    Il2CppObject* shader = asset_bundles::load_asset(shader_name.c_str(), shader_system_type);
    // Only cache successful loads — caching nullptr would poison the cache
    // permanently for this shader type until the module is reset.
    if (!shader) return nullptr;
    item_shader_cache_[type_id] = shader;
    log_shader_properties_once(shader, shader_name);
    return shader;
}

using ChamsObjPtr = Il2CppObject*;
using ChamsStrPtr = Il2CppString*;

// ---------------------------------------------------------------------------
// What the bundled chams shader actually declares, logged once per shader name.
//
// The 2026-10-14 report is "chams works, but applying replaces the original
// texture entirely" -- a flat-colour item instead of a textured one. Whether
// THAT is fixable by carrying _MainTex across is a question about the shader,
// and the shader's source is not in the tree (`assets/` holds the prebuilt
// bundle blob), so every answer so far has been an inference. Unity can be
// asked directly: Shader exposes its declared property list. If `_MainTex` is
// in it, the carry-over below lands on a sampler and the texture survives; if
// it is not, no amount of texture plumbing will help and the fix belongs in
// the bundle, not here.
//
// One line, once per shader, DEBUG-gated: the walk is a handful of managed
// calls on a cold path and the answer is a property of the bundle.
// ---------------------------------------------------------------------------
void ChamsModule::log_shader_properties_once(Il2CppObject* shader, const std::string& shader_name) {
    if (!logger::debug_enabled()) return;
    static std::unordered_set<std::string> logged;
    if (!logged.insert(shader_name).second) return;

    Il2CppObjectInstance shader_inst(shader);
    const auto get_property_count = shader_inst.get_method<int (*)(Il2CppObject*)>(
        "get_propertyCount", 0, /*log_fail=*/false);
    const auto get_property_name = shader_inst.get_method<ChamsStrPtr (*)(Il2CppObject*, int)>(
        "GetPropertyName", 1, /*log_fail=*/false);
    const auto get_property_type = shader_inst.get_method<int (*)(Il2CppObject*, int)>(
        "GetPropertyType", 1, /*log_fail=*/false);
    if (!get_property_count || !get_property_name || !get_property_type) {
        logger::debug("chams-shader: '" + shader_name
                      + "' property list UNREADABLE -- the shader's declared properties could not "
                        "be walked, so whether it samples _MainTex is unknown");
        return;
    }

    const int count = get_property_count(shader_inst.get_instance());
    std::string props;
    bool has_main_tex = false;
    for (int i = 0; i < count && i < 64; ++i) {
        ChamsStrPtr raw = get_property_name(shader_inst.get_instance(), i);
        const std::string name = raw ? eft_api::try_read_il2cpp_string(raw) : std::string();
        if (name.empty()) continue;
        const int type = get_property_type(shader_inst.get_instance(), i);
        if (!props.empty()) props += " ";
        props += name + ":" + std::to_string(type);
        if (name == "_MainTex") has_main_tex = true;
    }
    logger::debug("chams-shader: '" + shader_name + "' declares " + std::to_string(count)
                  + " properties [" + props + "] -- _MainTex=" + (has_main_tex ? "yes" : "NO")
                  + ". NO means carrying the original texture across is a no-op and the flat "
                    "look is the bundle's, not this module's.");
}

void ChamsModule::apply_chams_to_material(Il2CppObjectInstance& material_instance, Il2CppObject* shader,
    const unity::color& visible, const unity::color& occluded, Il2CppObject* original_material) {
    // Read the original's texture BEFORE touching the material we are painting.
    // `original_material` is a DIFFERENT object (the pre-paint shared material),
    // so this is safe to do at any point -- but doing it first keeps the read
    // obviously independent of the writes below.
    Il2CppObject* carried_texture = nullptr;
    if (original_material) {
        Il2CppObjectInstance original_inst(original_material);
        carried_texture = original_inst.call_or<ChamsObjPtr>(
            "get_mainTexture", 0, ChamsObjPtr{}, original_material);
    }

    material_instance.call_or_void<void (*)(Il2CppObject*, Il2CppObject*)>(
        "set_shader", 1, shader);

    Il2CppString* color_visible = il2cpp::il2cpp_string_new("_Color_Visible");
    Il2CppString* color_occluded = il2cpp::il2cpp_string_new("_Color_Occluded");

    const auto set_color = material_instance.get_method<void (*)(
        Il2CppObject*, Il2CppString*, unity::color)>("SetColor", 2);
    set_color(material_instance.get_instance(), color_visible, visible);
    set_color(material_instance.get_instance(), color_occluded, occluded);

    // Carry the original texture across instead of nulling it, so an item keeps
    // its artwork under the two-colour shader. This used to be an unconditional
    // set_mainTexture(nullptr) with the comment "so all the shaders look right"
    // -- which made every chams'd item a flat fill and is the 2026-10-14 report.
    // If the bundled shader does not declare _MainTex the set is inert and the
    // one-time chams-shader: line says so in as many words.
    material_instance.call_or_void<void (*)(Il2CppObject*, Il2CppObject*)>(
        "set_mainTexture", 1, carried_texture);
}

int ChamsModule::apply_chams_to_renderer(Il2CppObject* renderer, Il2CppObject* shader,
    const unity::color& visible, const unity::color& occluded, std::vector<Il2CppObject*>* save_out) {
    Il2CppObjectInstance renderer_instance(renderer);

    // One ENTRY PER RENDERER holding that renderer's pre-paint materials, appended in
    // renderer order. Nesting rather than one flat list is what makes the un-paint walk
    // below index-aligned without an out-of-band count; see the header note.
    //
    // This must run BEFORE get_materials below, and the ordering is the whole trick.
    // get_materials is the INSTANTIATING accessor: it replaces the renderer's array with
    // private copies and hands those back. Once it has run, the pristine originals are
    // gone from the renderer, and re-reading would capture our own chams as the thing to
    // restore -- an un-paint that restores the chams.
    //
    // get_sharedMaterials is the non-instantiating accessor, so it reports what is
    // currently bound WITHOUT swapping in copies. Whether those are true shared assets
    // or instances the game made earlier does not matter: "whatever was bound when we
    // first found it" is the correct definition of un-paint either way.
    if (save_out)
    {
        using get_shared_fn = Il2CppArray* (*)(Il2CppObject*);
        static const get_shared_fn get_shared_materials =
            renderer_instance.get_method<get_shared_fn>("get_sharedMaterials", 0, false, false);
        if (get_shared_materials)
        {
            if (Il2CppArray* shared = get_shared_materials(renderer_instance.get_instance()))
            {
                for (size_t m = 0; m < shared->max_length; ++m)
                {
                    save_out->push_back(reinterpret_cast<Il2CppObject**>(&shared->data)[m]);
                }
            }
        }
    }

    // EVERY material slot, not just the first.
    //
    // This used to call get_material, which is Unity's singular `Renderer.material`
    // and returns material[0] ONLY. A mesh with N submeshes has N material slots,
    // so every slot past the first kept its original shader and texture: the item
    // rendered as a patchwork, some parts flat-chams and the rest untouched. That is
    // the "some items get the new texture, some don't" report -- it is per-SUBMESH,
    // which is why it looks like the feature works on some items and not others.
    //
    // get_materials is the plural `Renderer.materials` and returns the whole array.
    // It is the instantiating accessor, same as the singular one, so mutating the
    // returned copies is safe here for exactly the reason optics_lens_pipeline.h:1279
    // prefers get_sharedMaterial on a renderer we do not own: an instantiating
    // accessor gives us private copies instead of repainting a shared asset.
    //
    // get_materials allocates a managed array per call, so it is resolved once and
    // cached rather than per-renderer-per-repaint; the 8 s re-paint cadence would
    // otherwise allocate one array per renderer per item per cycle. Resolution walks
    // base classes, so this single cache is correct for both MeshRenderer and
    // SkinnedMeshRenderer -- neither declares get_materials itself, Renderer does.
    //
    // allow_any_argc=false, verified against the dump: Renderer declares exactly one
    // get_materials, at arity 0. The fallback can therefore only ever return a
    // DIFFERENT function, which is how the two-argument set_material mistake reached
    // a shipped DLL. Exact arity or nothing.
    using get_materials_fn = Il2CppArray* (*)(Il2CppObject*);
    static const get_materials_fn get_materials =
        renderer_instance.get_method<get_materials_fn>("get_materials", 0, false, false);

    if (get_materials)
    {
        Il2CppArray* materials = get_materials(renderer_instance.get_instance());
        if (materials)
        {
            int slots = 0;
            for (size_t m = 0; m < materials->max_length; ++m)
            {
                Il2CppObject* material = reinterpret_cast<Il2CppObject**>(&materials->data)[m];
                if (!material) continue;
                // The pre-paint material for the SAME slot: save_out was filled
                // above from get_sharedMaterials in array order, and get_materials
                // instantiates that same array, so index m lines up. Null when the
                // caller asked for no saving (and therefore read no originals).
                Il2CppObject* original =
                    (save_out && m < save_out->size()) ? (*save_out)[m] : nullptr;
                Il2CppObjectInstance material_instance(material);
                apply_chams_to_material(material_instance, shader, visible, occluded, original);
                ++slots;
            }
            return slots;
        }
    }

    // Fallback for a game build that drops or renames the plural accessor. `material`
    // rather than `sharedMaterial`, deliberately: mutating a shared asset would
    // repaint every other item in the level using that same material, including ones
    // outside the distance gate.
    Il2CppObjectInstance material_instance(
        renderer_instance.call_or<ChamsObjPtr>(
            "get_material", 0, ChamsObjPtr{}, renderer_instance.get_instance()));
    if (!material_instance.get_instance()) return 0;
    apply_chams_to_material(material_instance, shader, visible, occluded,
        (save_out && !save_out->empty()) ? (*save_out)[0] : nullptr);
    return 1;
}

int ChamsModule::collect_item_renderers(Il2CppObject* loot_obj, std::vector<Il2CppObject*>& out) {
    Il2CppObjectInstance loot_instance(loot_obj);

    if (unity::list* renderer_list = loot_instance.get_field<unity::list*>("_renderers"))
    {
        if (Il2CppArray* renderer_array = renderer_list->m_p_list_array)
        {
            for (size_t r = 0; r < renderer_array->max_length; ++r)
            {
                Il2CppObject* renderer = reinterpret_cast<Il2CppObject**>(&renderer_array->data)[r];
                if (!is_item_renderer(renderer)) continue;
                out.push_back(renderer);
            }
        }
    }

    return static_cast<int>(out.size());
}

int ChamsModule::paint_renderer_list(const std::vector<Il2CppObject*>& renderers, Il2CppObject* shader,
    const unity::color& visible, const unity::color& occluded, int* slots_out,
    std::vector<std::vector<Il2CppObject*>>* save_out) {
    int applied = 0;
    int slots = 0;
    for (Il2CppObject* renderer : renderers)
    {
        // One saved entry per renderer, ALWAYS, including when the renderer turns out
        // to have no materials or a dead accessor. That is what makes the un-paint
        // walk index-aligned: the Nth renderer the collector produced is always
        // saved[N], with no counting needed to get there. A flat list would need an
        // out-of-band slot count, and every way of getting that count wrong shifts
        // all the later renderers onto wrong slots.
        //
        // This must run BEFORE get_materials inside apply_chams_to_renderer, and the
        // ordering is the whole trick: get_materials is the INSTANTIATING accessor,
        // so once it has run the pristine originals are gone from the renderer and
        // re-reading would capture our own chams as the thing to restore.
        std::vector<Il2CppObject*> this_renderer;
        // Count RENDERERS separately from material SLOTS. They were the same number
        // while this painted material[0] only, which is exactly why the multi-slot
        // case was invisible: a half-converted item looked identical to a fully
        // converted one in the old counters.
        const int painted = apply_chams_to_renderer(renderer, shader, visible, occluded,
            save_out ? &this_renderer : nullptr);
        if (save_out) save_out->push_back(std::move(this_renderer));
        slots += painted;
        if (painted > 0) ++applied;
    }

    if (slots_out) *slots_out = slots;
    return applied;
}

int ChamsModule::apply_chams_to_item(Il2CppObject* loot_obj, Il2CppObject* shader,
    const unity::color& visible, const unity::color& occluded, int* slots_out,
    std::vector<std::vector<Il2CppObject*>>* save_out) {
    std::vector<Il2CppObject*> renderers;
    collect_item_renderers(loot_obj, renderers);

    int slots = 0;
    const int applied = paint_renderer_list(renderers, shader, visible, occluded, &slots, save_out);

    if (slots_out) *slots_out = slots;
    return applied;
}

int ChamsModule::restore_renderer_list(const std::vector<Il2CppObject*>& renderers,
    std::vector<std::vector<Il2CppObject*>>& originals) {
    // The callers' collectors have already filtered to MeshRenderer /
    // SkinnedMeshRenderer, so there is deliberately NO second filter here: applying
    // is_item_renderer again over a list that contains nothing it would reject is
    // harmless today, and the day a collector changes its filter the two walks
    // would silently disagree about which renderer saved[n] belongs to.
    //
    // Walk the two sequences together, one saved entry per renderer. They line up by
    // construction: saved[n] belongs to the nth renderer the collector produced on
    // the paint pass. Note the renderer index is NOT the slot index -- each renderer
    // holds its own material array, and conflating the two is the bug that made the
    // original material[0] paint invisible.
    size_t renderer_index = 0;
    int restored = 0;
    for (Il2CppObject* renderer : renderers)
    {
        if (renderer_index >= originals.size()) break;
        const std::vector<Il2CppObject*>& saved_for_renderer = originals[renderer_index++];

        Il2CppObjectInstance renderer_instance(renderer);

        // There is NO per-slot setter to use here. Verified against
        // GameDump/110146911/DiffableCs/UnityEngine.CoreModule/UnityEngine/Renderer.cs:
        //
        //     public void set_material(Material value)          <- ONE argument
        //     public void set_materials(Material[] value)       <- the array setter
        //     public void set_sharedMaterials(Material[] value)
        //
        // Renderer.SetMaterial(int, Material) -- the indexed setter in the C# API -- is
        // NOT on the IL2CPP Renderer, which is what makes this a trap rather than a
        // detail: `get_method("set_material", 2)` finds nothing at arity 2, and
        // get_method's allow_any_argc FALLBACK then hands back the ONE-argument
        // set_material. Calling that through a two-argument function pointer passes the
        // slot index in the register the real method reads as its Material*, so the game
        // dereferences a small integer. It would have faulted the first time an item
        // left the radius, or the first time Loot Chams was switched off.
        //
        // So the restore goes through set_materials with a whole array, and the array is
        // Unity's own: get_materials returns a Material[] of exactly the right element
        // type and length, so writing the saved pointers into it and handing it back
        // needs no il2cpp_array_new and no element class.
        //
        // Whether that array is the renderer's internal one or a fresh copy is
        // immaterial: if it is internal the writes have already rebound the renderer and
        // set_materials is a no-op over the same values; if it is a copy the
        // set_materials is what commits them. Both end at the same place.
        //
        // Resolved ONCE, not per renderer. The 2026-10-01 18:36 Tracy export put
        // il2utils::resolve_method at 7,214,309 calls / 1.45 s across the session, so
        // these are cheap individually (~200 ns each, memoised) but they are the single
        // most-called thing in the mod, and resolving them per renderer per restore is
        // exactly the shape of traffic that number is made of. The paint path already
        // caches for the same reason; this was the one place that did not.
        using get_materials_fn = Il2CppArray* (*)(Il2CppObject*);
        using set_materials_fn = void (*)(Il2CppObject*, Il2CppArray*);
        static get_materials_fn cached_get_materials = nullptr;
        static set_materials_fn cached_set_materials = nullptr;
        // allow_any_argc=false on both. The getters are unambiguous at arity 0 and the
        // setter at arity 1, so the fallback can only ever find the wrong function --
        // which is precisely how the two-argument mistake above survived to shipping.
        if (!cached_get_materials || !cached_set_materials)
        {
            cached_get_materials =
                renderer_instance.get_method<get_materials_fn>("get_materials", 0, false, false);
            cached_set_materials =
                renderer_instance.get_method<set_materials_fn>("set_materials", 1, false, false);
        }
        // A failed resolve is NOT cached, so a game update that renames one of these
        // costs one wasted lookup per restore rather than permanently disabling the
        // un-paint. Same rule as the native-object memo: never remember a bad answer.
        if (!cached_get_materials || !cached_set_materials) continue;

        Il2CppArray* target = cached_get_materials(renderer_instance.get_instance());
        if (!target) continue;

        // Write the saved materials in, null-padding anything the saved list does not
        // cover. A slot we could not restore is set to null rather than left holding our
        // chams: a visibly wrong slot is better than a chams leak into a view the
        // distance gate never governed, and Unity treats a null material slot as
        // unrendered rather than faulting.
        size_t restored_here = 0;
        for (size_t slot = 0; slot < target->max_length; ++slot)
        {
            Il2CppObject* original = slot < saved_for_renderer.size() ? saved_for_renderer[slot] : nullptr;
            // Liveness is checked before the pointer is STORED, and a dead one is stored
            // as null. Nothing here dereferences it -- it is written into managed array
            // storage, which is exactly the kind of value that array holds.
            if (original && !unity::is_unity_object_alive(original, "chams/original")) original = nullptr;
            reinterpret_cast<Il2CppObject**>(&target->data)[slot] = original;
            if (original) ++restored_here;
        }
        cached_set_materials(renderer_instance.get_instance(), target);
        restored += static_cast<int>(restored_here);
    }

    return restored;
}

int ChamsModule::unpaint_chams_to_item(Il2CppObject* loot_obj) {
    const uintptr_t key = reinterpret_cast<uintptr_t>(loot_obj);
    const auto saved = original_item_materials.find(key);
    if (saved == original_item_materials.end()) return 0;

    // Move the list out first, so a re-entrant path cannot see a half-consumed entry.
    std::vector<std::vector<Il2CppObject*>> originals;
    originals.swap(saved->second);
    original_item_materials.erase(saved);

    // Re-collect the renderers with the SAME collector the paint pass used. An
    // independently written walk here is how the two lists would drift apart, and
    // the index-aligned restore depends on them being identical.
    std::vector<Il2CppObject*> renderers;
    collect_item_renderers(loot_obj, renderers);
    if (renderers.empty()) return 0;

    return restore_renderer_list(renderers, originals);
}

void ChamsModule::forget_item_materials(const uintptr_t loot_key) {
    original_item_materials.erase(loot_key);
}

void ChamsModule::unpaint_all_items(Il2CppObjectInstance& game_world_instance) {
    // Walk the LIVE loot list rather than the saved keys. A key in applied_items can
    // name an item the game has already destroyed -- picking an item up removes its
    // LootItem -- and calling back into one of those is a fault, not a restore. The
    // list only contains objects that exist right now, which is exactly the set we are
    // allowed to touch.
    Il2CppObject* loot_hydra_obj = game_world_instance.get_field<Il2CppObject*>("LootItems");
    if (!loot_hydra_obj) {
        // No world to walk. Drop the bookkeeping rather than leave it pinned forever;
        // whatever is still painted is the game's problem now, not ours.
        original_item_materials.clear();
        applied_items.clear();
        return;
    }
    Il2CppObjectInstance loot_hydra(loot_hydra_obj);
    unity::list* loot_list = loot_hydra.get_field<unity::list*>("_iteration");
    if (!loot_list || !loot_list->m_p_list_array) {
        original_item_materials.clear();
        applied_items.clear();
        return;
    }

    // live_count(), not the backing array's max_length -- same capacity-vs-count
    // mistake the scan loop had, and it would walk ~945 null slots here too. This runs
    // on the OFF edge, which is a single tick the player is watching for a response, so
    // the wasted walk is the most noticeable place for it.
    Il2CppArray* loot_array = loot_list->m_p_list_array;
    const size_t loot_count = loot_list->live_count();
    for (size_t i = 0; i < loot_count; ++i)
    {
        Il2CppObject* loot_obj = reinterpret_cast<Il2CppObject**>(&loot_array->data)[i];
        if (!loot_obj) continue;
        const uintptr_t key = reinterpret_cast<uintptr_t>(loot_obj);
        if (!applied_items.contains(key)) continue;
        unpaint_chams_to_item(loot_obj);
        applied_items.erase(key);
    }

    // Whatever is left names an item that no longer exists, so there is nothing to
    // restore and nothing that will ever ask again. Dropping it here is what stops the
    // map growing across a raid as the player picks items up.
    original_item_materials.clear();
}

void ChamsModule::scan_item_chams(const Il2CppImage* unity_image, Il2CppObjectInstance& game_world_instance,
    Il2CppObjectInstance& main_player) {
    // The whole scan, INCLUDING the throttled-out early return. That placement is the
    // point: a zone placed after the 250 ms gate would only ever measure the ticks that
    // did work, which is a flattering and wrong number -- it is how the log-side throttle
    // spent 140 of 141 lines on idle ticks. Placed here, the zone also shows how often
    // the scan is called at all, so a capture can answer "does loot chams cost anything"
    // without inferring it from call counts elsewhere.
    //
    if (!asset_bundles::asset_bundle) return;
    item_chams_reapply_if_settings_changed();

    // Self-heal cadence: a game-side revert of item materials leaves applied_items
    // telling us the item is already chams'd when it visually isn't. Clear on a
    // slow cadence so every in-range item is re-applied over the next few ticks.
    //
    // The cursor MUST rewind with the set. Clearing applied_items alone leaves the scan
    // resuming past everything it has already seen, so the re-paint this exists to perform
    // never reaches those items and they stay unchams'd for the rest of the raid. See the
    // note on item_chams_last_scanned_index_ in the header.
    const ULONGLONG now_reapply = GetTickCount64();
    if (item_chams_last_reapply_ms_ == 0
        || now_reapply - item_chams_last_reapply_ms_ >= kItemChamsReapplyIntervalMs)
    {
        item_chams_last_reapply_ms_ = now_reapply;
        // Size BEFORE the clear. Reading it afterwards logs a hardcoded 0, which is the
        // kind of line that looks like evidence and is not.
        const size_t had_applied = applied_items.size();
        applied_items.clear();
        item_chams_last_scanned_index_ = 0;
        if (logger::debug_enabled())
            logger::debug(std::format(
                "item-chams: reapply cadence fired, cleared {} applied, cursor rewound to 0", had_applied));
    }

    // Throttle the world scan; applied_items makes repeat ticks cheap.
    const ULONGLONG now = GetTickCount64();
    constexpr ULONGLONG item_chams_scan_interval_ms = 250;
    constexpr int max_item_chams_per_tick = 64;
    if (item_chams_last_scan_ms_ != 0 && now - item_chams_last_scan_ms_ < item_chams_scan_interval_ms) return;
    item_chams_last_scan_ms_ = now;

    Il2CppObject* chams_shader = load_item_chams_shader(unity_image, item_chams_type->get_value());
    if (!chams_shader) return;

    const unity::color visible = to_unity_color(item_visible_color->get_value());
    const unity::color occluded = to_unity_color(item_occluded_color->get_value());

    // Read the slider ONCE. It was read twice to compute one square, which is a
    // correctness smell for no reason -- and it is a ConfigValue the menu can write
    // from the render thread, so two reads could straddle a change and produce a
    // max_dist_sq belonging to neither value.
    const float max_distance = item_chams_distance->get_value();
    const float max_dist_sq = max_distance * max_distance;
    unity::vector3 origin = {0, 0, 0};
    if (main_player.get_instance())
    {
        if (Il2CppObject* player_object = unity::component_get_game_object(main_player.get_instance()))
            if (Il2CppObject* player_transform = unity::gameobject_get_transform(player_object))
                origin = unity::transform_get_pos(player_transform);
    }

    // GameWorld.LootItems is a DictionaryListHydra<int, LootItem>; its
    // _iteration list holds every spawned LootItem (ObservedLootItem and Corpse
    // included -- corpses ARE LootItems, so AI bodies come along too, which is why
    // the corpse skip below is needed rather than cosmetic).
    Il2CppObject* loot_hydra_obj = game_world_instance.get_field<Il2CppObject*>("LootItems");
    if (!loot_hydra_obj) return;
    Il2CppObjectInstance loot_hydra(loot_hydra_obj);
    unity::list* loot_list = loot_hydra.get_field<unity::list*>("_iteration");
    if (!loot_list || !loot_list->m_p_list_array) return;
    // THE LIVE COUNT, NOT THE BACKING ARRAY'S CAPACITY.
    //
    // This was loot_array->max_length, and the 2026-10-01 18:36 in-game capture shows
    // exactly why that is wrong: every full pass reported loot=1000, examined=1000 and
    // null=945, with applied=49. List<T>._items is the backing ARRAY, so max_length is
    // its capacity -- the list had grown to 1000 slots and held ~55 items, and the other
    // 945 were null. Three consequences, and the first two are why this was invisible:
    //
    //   1. The reported population was capacity, so `examined` said 1000 when the real
    //      figure was ~55. Every ratio read off that line was wrong by ~18x.
    //   2. The cursor was measured in capacity units and parked at 1000, so it had
    //      "seen" 1000 items when it had seen 55. Any shrink test against it was
    //      comparing a capacity to a capacity and mostly agreeing by accident.
    //   3. The wasted work is real but small: ~945 null checks per pass, once per 8 s.
    //
    // live_count() reads List<T>._size and clamps it into the array, so an over-reported
    // _size degrades to the capacity rather than running off the end.
    Il2CppArray* loot_array = loot_list->m_p_list_array;
    const size_t loot_count = loot_list->live_count();

    // Track the last scanned index so we only iterate new items on each scan.
    // When the list shrinks (items removed), we reset to avoid skipping items.
    //
    // This is a member now, not a function-local static, so that every applied_items.clear()
    // can rewind it. See the note in ChamsModule.h: with it function-local, the 8 s
    // re-paint cadence cleared the set but could not rewind the cursor, so the repaint
    // could never reach an item the cursor had already passed.
    //
    // WHAT THE FORWARD-ONLY CURSOR COSTS NOW THAT UN-PAINT EXISTS. Both directions of
    // the radius transition -- paint on approach, un-paint on leaving -- are decided as
    // the cursor sweeps past an index, and the cursor only ever moves forward. So a
    // transition is noticed on the next full sweep, which the 8 s re-paint cadence
    // guarantees, rather than the same tick it happens. An item can therefore sit up
    // to 8 s outside the radius still lit. Rewinding every tick instead would make the
    // transition instant and cost a full list walk per 250 ms tick; the 8 s bound is
    // the deliberate trade, and `unpainted` in the trace is how it is watched.
    size_t& last_scanned_index = item_chams_last_scanned_index_;
    if (loot_count < last_scanned_index)
        last_scanned_index = 0;

    // The cursor position at ENTRY, logged below, because "cursor was already at the end
    // when the tick started" is the signature of the bug this trace exists to catch.
    const size_t cursor_at_entry = last_scanned_index;
    scan_stats st{};

    // Spread material instantiation over ticks so a loot-dense map never
    // stalls a single frame.
    int processed = 0;
    for (size_t i = last_scanned_index; i < loot_count; ++i)
    {
        ++st.examined;
        Il2CppObject* loot_obj = reinterpret_cast<Il2CppObject**>(&loot_array->data)[i];
        if (!loot_obj) { ++st.null_obj; continue; }
        // Corpses are ALWAYS skipped. This used to be behind an "Include Corpses"
        // checkbox, which was a crossing feature with Enemy Chams: a corpse is a
        // LootItem, but it is also a dead player, and painting it with the flat loot
        // shader fought the enemy-highlight colouring that ChamsModule's player path
        // applies to AllAlivePlayersList. Two features owning the same renderer, with
        // the loser's state depending on tick order, is worse than not offering the
        // option. Corpses are a Player Chams concern.
        if (eft_api::class_name_contains(loot_obj, "Corpse")) { ++st.corpse; continue; }

        const uintptr_t loot_key = reinterpret_cast<uintptr_t>(loot_obj);

        Il2CppObject* game_object = unity::component_get_game_object(loot_obj);
        if (!game_object) { ++st.no_game_object; continue; }
        Il2CppObject* transform = unity::gameobject_get_transform(game_object);
        if (!transform) { ++st.no_transform; continue; }

        const unity::vector3 pos = unity::transform_get_pos(transform);
        const float dx = origin.x - pos.x;
        const float dy = origin.y - pos.y;
        const float dz = origin.z - pos.z;
        const bool in_range = dx * dx + dy * dy + dz * dz <= max_dist_sq;

        // Distance is a REAL radius now, not a first-paint gate.
        //
        // An item that has been painted and then falls out of range is un-painted, so
        // walking away actually turns the chams back off and lowering the slider has a
        // visible effect. The paint was one-way before this, which is what made the
        // control feel inert: once an item was lit it stayed lit for the whole raid no
        // matter what the slider said.
        if (!in_range)
        {
            ++st.out_of_range;
            // The gate is original_item_materials, NOT applied_items.
            //
            // This was `applied_items.contains(loot_key)`, and that made the un-paint
            // unreachable. The 2026-10-01 18:36 capture shows it: every one of 127 scan
            // lines reads unpainted=0, including 32 full passes with oor=5..14, so items
            // were demonstrably falling out of range and none were ever restored. The
            // reason is the ORDER of the two things this loop depends on. The re-paint
            // cadence runs at the top of this function and does `applied_items.clear()`;
            // the only ticks that examine anything are the ones right after it, because
            // the cursor is parked at the end in between. So by the time this branch is
            // reached, applied_items has just been emptied and contains nothing --
            // `applied_items.contains(loot_key)` is false for every item, painted or not,
            // and the restore is dead code.
            //
            // original_item_materials is the right gate because it is deliberately NOT
            // cleared by the re-paint: it records what the renderer looked like before
            // we ever touched it, which stays true across a repaint. "Do we owe this
            // item a restore?" is a question about having painted it, and that map is
            // the record of exactly that.
            //
            // Erasing from applied_items afterwards keeps the two consistent, so the
            // item is re-painted (and re-saved) if it comes back into range.
            if (original_item_materials.contains(loot_key))
            {
                unpaint_chams_to_item(loot_obj);
                applied_items.erase(loot_key);
                ++st.unpainted;
            }
            continue;
        }

        if (applied_items.contains(loot_key)) { ++st.already; continue; }

        // The return value was DISCARDED here, so an item with no qualifying renderer was
        // recorded in applied_items as though it had been painted, and the 8 s re-paint
        // would "find" it already done forever. Now it is counted, and a zero-renderer item
        // is NOT recorded, so the next tick can try again once its renderers exist.
        //
        // save_out is passed ONLY when this item has no saved materials yet. Saving is a
        // one-shot per item: it records the pre-paint state, and re-saving after a repaint
        // would capture our own chams as the thing to restore.
        int item_slots = 0;
        std::vector<std::vector<Il2CppObject*>> fresh_originals;
        const bool needs_save = original_item_materials.find(loot_key) == original_item_materials.end();
        const int painted = apply_chams_to_item(loot_obj, chams_shader, visible, occluded,
            &item_slots, needs_save ? &fresh_originals : nullptr);
        st.renderers += static_cast<size_t>(painted < 0 ? 0 : painted);
        st.materials += static_cast<size_t>(item_slots < 0 ? 0 : item_slots);
        // Slots strictly greater than renderers means at least one renderer on this item
        // had more than one material. That is the multi-submesh case the singular
        // get_material() silently left half-painted.
        if (item_slots > painted) ++st.multi_slot;
        ++st.applied;
        if (painted > 0)
        {
            // Save on the first paint only. An empty list means the accessor gave us
            // nothing to restore, and recording that would make the item permanently
            // un-un-paintable: the entry exists, so needs_save is false forever, and the
            // un-paint would find nothing and restore nothing.
            if (needs_save && !fresh_originals.empty())
                original_item_materials.emplace(loot_key, std::move(fresh_originals));
            applied_items.insert(loot_key);
        }
        else
            ++st.zero_renderer;

        if (++processed >= max_item_chams_per_tick)
        {
            last_scanned_index = i + 1;
            st.hit_cap = true;
            report_item_chams_scan(st, loot_count, cursor_at_entry, last_scanned_index,
                chams_shader, applied_items.size(), original_item_materials.size(), 0);
            return;
        }
    }
    last_scanned_index = loot_count;

    // A COMPLETED pass is the only safe place to sweep, and reaching this line is what
    // "completed" means: the cap path above returned early with most of the list
    // unvisited, and sweeping there would drop the saved materials of live items that
    // simply have not been re-painted yet.
    //
    // Once the pass IS complete the two sets agree by construction, which is what makes
    // this cheap: every live in-range item was just painted and is in applied_items;
    // every live out-of-range item that had an entry was just un-painted and its entry
    // erased. So anything still in original_item_materials but NOT in applied_items can
    // only name an item that is no longer in the loot list at all.
    const size_t swept = sweep_stale_materials();

    report_item_chams_scan(st, loot_count, cursor_at_entry, last_scanned_index,
        chams_shader, applied_items.size(), original_item_materials.size(), swept);
}

size_t ChamsModule::sweep_stale_materials() {
    if (original_item_materials.empty()) return 0;

    // WHY THIS IS NOT JUST A LEAK. An entry for a destroyed item is harmless until the
    // allocator hands its address to a NEW item. Then needs_save is false for that
    // address (an entry exists), so the new item's own materials are never captured, and
    // when it leaves range unpaint_chams_to_item writes the DEAD item's materials onto
    // the live one -- wrong textures, or an invisible item when those materials have
    // themselves died and the liveness check nulls them.
    //
    // The 2026-10-01 19:41 capture is the evidence that this state occurs: a pass
    // reporting examined=425 applied=0 oor=412 unpainted=411 ended with saved=34. All
    // 412 out-of-range items had just been restored, so those 34 entries can only name
    // items that had already left the list. 34 of 425 is 8%, so a stale hit is not a
    // remote edge case.
    size_t swept = 0;
    for (auto it = original_item_materials.begin(); it != original_item_materials.end(); ) {
        if (!applied_items.contains(it->first)) {
            it = original_item_materials.erase(it);
            ++swept;
        }
        else {
            ++it;
        }
    }
    return swept;
}

namespace {
    // get_activeSelf on a GameObject. unity.h carries no active-state helper and it
    // is one of the frozen optics headers, so the one call this needs lives here.
    //
    // FAILS OPEN on purpose: if the game renames the method the filter stops
    // selecting and we paint an occasional dormant child mesh, which is the cost of
    // being wrong here. Failing closed (treating every object as inactive) would
    // silently turn container chams into a checkbox that does nothing -- the shape
    // of failure the transform_get_child_count note in unity.h exists to warn about.
    bool game_object_is_active_self(Il2CppObject* game_object) {
        if (!game_object) return false;
        Il2CppObjectInstance instance(game_object);
        using active_self_fn = bool (*)(Il2CppObject*);
        static active_self_fn get_active_self = nullptr;
        // Not cached as a nullptr the way the static-const pattern above does: a
        // failed resolve must cost one wasted lookup per call, not permanently
        // remember a bad answer.
        if (!get_active_self)
            get_active_self = instance.get_method<active_self_fn>("get_activeSelf", 0, false, false);
        return get_active_self ? get_active_self(game_object) : true;
    }
}

void ChamsModule::discover_containers(const Il2CppClass* game_world_class, container_scan_stats& st) {
    TA_ZONE_N("chams::container_discover");

    if (!game_world_class || !game_world_class->image) return;

    // EFT.Interactive.LootableContainer, resolved from the GameWorld's own image --
    // the same source DoorsModule uses for EFT.Interactive.Door, so the two agree
    // about which assembly holds the interactive classes.
    Il2CppObject* container_type = il2utils::get_system_type(game_world_class->image,
        "EFT.Interactive", "LootableContainer");
    if (!container_type) return;

    size_t found = 0;
    Il2CppObject** objects = nullptr;
    {
        // Split from the per-object loop on purpose. This is a SCENE-WIDE search,
        // so its cost scales with the whole scene rather than with the container
        // count -- the ESP measured it at 8.4 ms average / 135 ms peak
        // (EspModule.cpp:6998-7007), which is why it runs on a 2 s / 15 s clock
        // here and not on the paint tick.
        TA_ZONE_N("chams::container_find_objects");
        objects = unity::find_objects_of_type(container_type, &found);
    }
    st.found = found;
    if (!objects || found == 0)
    {
        container_objs_.clear();
        return;
    }

    std::vector<Il2CppObject*> next;
    // Hard cap. A pathological scene returning tens of thousands of components
    // would otherwise grow the cache without bound; the slider caps what is
    // painted anyway, and this caps what is walked.
    next.reserve((std::min)(found, static_cast<size_t>(4096)));

    for (size_t i = 0; i < found; ++i)
    {
        Il2CppObject* obj = objects[i];
        if (!eft_api::is_il2cpp_object_likely_valid(obj)) { ++st.invalid; continue; }

        // GHOST FILTER, and it is the whole feature. find_objects_of_type returns
        // every LootableContainer component in the scene, and every map ships far
        // more container prefabs than one raid uses: the loot spawner rolls a
        // subset and the un-rolled ones keep a live component, a position and a
        // renderer, with nothing about them distinguishable from a real container.
        // Painting one puts flat chams on an empty patch of wall or floor.
        //
        // This sits on the NEW-OBJECT path only because the cache is rebuilt from
        // scratch every pass -- there is no carried-over `existing` map for a
        // previously-admitted ghost to survive in, which is the leak the ESP's
        // merge branch had to defend against.
        if (!eft_api::is_container_actually_placed(obj)) { ++st.ghost; continue; }
        if (!eft_api::is_container_object_alive(obj)) { ++st.no_transform; continue; }

        next.push_back(obj);
        ++st.cached;
    }

    container_objs_.swap(next);

    // REWIND. The cache is a different list now, and a cursor measured against the
    // old one skips any container that only exists in the new one -- the exact
    // failure the item path's cursor rewind exists to prevent, one list over.
    container_chams_last_index_ = 0;
}

void ChamsModule::collect_child_renderers(Il2CppObject* transform, Il2CppObject* renderer_type,
    std::vector<Il2CppObject*>& out, const int depth) {
    // Depth 1 is the container's own children, 2 its grandchildren, and the cap is
    // deliberately 2. A container is usually parented into furniture -- a drawer
    // inside a desk, a shelf in a rack -- and an unbounded walk would paint the
    // furniture with it. GetComponentsInChildren(Renderer, true) is the obvious
    // call and it is the one that repaints the room.
    if (depth > 2) return;

    const int child_count = unity::transform_get_child_count(transform);
    for (int i = 0; i < child_count; ++i)
    {
        Il2CppObject* child = unity::transform_get_child(transform, i);
        if (!child) continue;
        Il2CppObject* child_game_object = unity::transform_get_game_object(child);
        if (!child_game_object) continue;
        // ACTIVE children only. A dormant state variant (the open drawer next to
        // the closed one, say) is not something the player is looking at, and
        // painting it means the chams appear later when the game activates it.
        if (!game_object_is_active_self(child_game_object)) continue;

        if (Il2CppObject* renderer = unity::gameobject_get_component(child_game_object, renderer_type))
            if (is_item_renderer(renderer)) out.push_back(renderer);

        collect_child_renderers(child, renderer_type, out, depth + 1);
    }
}

int ChamsModule::collect_container_renderers(Il2CppObject* container_obj, Il2CppObject* renderer_type,
    std::vector<Il2CppObject*>& out) {
    Il2CppObject* game_object = unity::component_get_game_object(container_obj);
    if (!game_object) return 0;

    // Both call sites pass a fresh vector, but this is the same collector the
    // restore path re-runs and the list is index-aligned, so "nothing found" is
    // measured against the size on entry rather than against zero.
    const size_t on_entry = out.size();

    // The container's own renderer first: the crate mesh usually sits on the very
    // same GameObject as the LootableContainer component. Order is stable across
    // passes, which is what the index-aligned restore depends on.
    if (Il2CppObject* own_renderer = unity::gameobject_get_component(game_object, renderer_type))
        if (is_item_renderer(own_renderer)) out.push_back(own_renderer);

    Il2CppObject* transform = unity::gameobject_get_transform(game_object);
    if (!transform) return static_cast<int>(out.size());

    collect_child_renderers(transform, renderer_type, out, 1);

    // ONE ANCESTOR, and only when the container's own subtree is empty.
    //
    // Measured 2026-10-13 22:37 (pid 22380, the interaction probe build): the
    // bag and corpse families are LEAVES. `scontainer_medbag_smu06_lootable` has
    // no renderer on its own GameObject and none below it, while its parent
    // `scontainer_medbag_smu06` carries `_LOD0` and `_SHADOW_LOD0` as ordinary
    // active MeshRenderer children -- the mesh the player is looking at. Same
    // shape for `scontainer_bag_sport_lootable` and for `Corpse_*_LOOTABLE`,
    // whose parent is the corpse root holding the body LODs. Everything that
    // already worked (cashbox, safe, weapon box, card_file_box, barrel) keeps
    // its mesh in its own subtree, which is why this is a fallback and not a
    // second pass: a container that found renderers below itself gets exactly
    // the list it got before, so the up-walk cannot change what already works.
    //
    // WHY EXACTLY ONE. The 2026-10-13 probe named the grandparent for both
    // failing families and both are SHARED prefab roots: `meds1` for the
    // medical bag, and `LOOTABLE1` with SEVENTEEN children for the corpse set.
    // Two levels up is the desk, the shelf and every other corpse on the map --
    // the "repaints the room" failure the depth cap above exists to prevent.
    //
    // The player-chams path cannot be fed by this: it paints
    // `PlayerBody.BodySkins[].SkinnedMeshRenderer` materials directly and keeps
    // no saved-materials map to corrupt, while these are MeshRenderer LOD bodies
    // reached through the transform hierarchy.
    if (out.size() == on_entry) {
        if (Il2CppObject* parent = unity::transform_get_parent(transform)) {
            if (Il2CppObject* parent_go = unity::component_get_game_object(parent))
                if (Il2CppObject* parent_renderer = unity::gameobject_get_component(parent_go, renderer_type))
                    if (is_item_renderer(parent_renderer)) out.push_back(parent_renderer);
            collect_child_renderers(parent, renderer_type, out, 1);
        }
    }

    return static_cast<int>(out.size());
}

void ChamsModule::container_chams_reapply_if_settings_changed() {
    const int type = container_chams_type->get_value();
    const ImU32 visible = pack_color(container_visible_color->get_value());
    const ImU32 occluded = pack_color(container_occluded_color->get_value());
    if (type == container_chams_last_type_ && visible == container_chams_last_visible_
        && occluded == container_chams_last_occluded_)
        return;
    container_chams_last_type_ = type;
    container_chams_last_visible_ = visible;
    container_chams_last_occluded_ = occluded;
    // applied_containers is dropped, but the SAVED materials are not: those record
    // what the renderer looked like before we ever touched it, which is still the
    // truth. Keeping them is what stops a colour change from making a container
    // un-paintable -- if we dropped them here, the re-paint would overwrite the
    // originals with the previous chams and walking out of range would then
    // "restore" the chams. Same rule the item path documents above.
    applied_containers.clear();
    // Cursor with it: a settings change invalidates every recorded "already
    // chams'd" container, and the re-apply it triggers can only reach what the
    // cursor has not passed.
    container_chams_last_index_ = 0;
}

int ChamsModule::unpaint_chams_to_container(Il2CppObject* container_obj, Il2CppObject* renderer_type) {
    const uintptr_t key = reinterpret_cast<uintptr_t>(container_obj);
    const auto saved = original_container_materials.find(key);
    if (saved == original_container_materials.end()) return 0;

    // Move the list out first, so a re-entrant path cannot see a half-consumed entry.
    std::vector<std::vector<Il2CppObject*>> originals;
    originals.swap(saved->second);
    original_container_materials.erase(saved);

    // Re-collect the renderers with the SAME collector the paint pass used. An
    // independently written walk here is how the two lists would drift apart, and
    // the index-aligned restore depends on them being identical.
    std::vector<Il2CppObject*> renderers;
    collect_container_renderers(container_obj, renderer_type, renderers);
    if (renderers.empty()) return 0;

    return restore_renderer_list(renderers, originals);
}

void ChamsModule::unpaint_all_containers(Il2CppObject* renderer_type) {
    // Walk the CACHE rather than the saved keys, and gate every entry on liveness
    // before touching it. A key in original_container_materials can name a
    // container the game has already destroyed -- the cache is at most one discovery
    // interval old -- and calling into one of those is a fault, not a restore. The
    // item path walks the live loot list for the same reason; the cache is the
    // closest thing containers have to one.
    const size_t had_painted = applied_containers.size();
    const size_t had_saved = original_container_materials.size();
    size_t restored_containers = 0;
    int restored_slots = 0;
    size_t dead = 0;

    for (Il2CppObject* container : container_objs_)
    {
        if (!container) continue;
        const uintptr_t key = reinterpret_cast<uintptr_t>(container);
        if (!original_container_materials.contains(key)) continue;
        // Two checks, not one: is_il2cpp_object_likely_valid covers the managed
        // wrapper, and is_unity_object_alive covers the native object it points at
        // -- the managed wrapper outlives the native side, and get_materials on the
        // latter is exactly the fault this gate exists to prevent.
        if (!eft_api::is_il2cpp_object_likely_valid(container)
            || !unity::is_unity_object_alive(container, "chams/unpaint_all_containers"))
        {
            forget_container_materials(key);
            applied_containers.erase(key);
            ++dead;
            continue;
        }
        restored_slots += unpaint_chams_to_container(container, renderer_type);
        ++restored_containers;
        applied_containers.erase(key);
    }

    original_container_materials.clear();
    applied_containers.clear();

    if (logger::debug_enabled())
        logger::debug(std::format(
            "container-chams: OFF edge -- restored {} containers / {} slots, dropped {} dead, "
            "cleared {} painted / {} saved",
            restored_containers, restored_slots, dead, had_painted, had_saved));
}

void ChamsModule::forget_container_materials(const uintptr_t key) {
    original_container_materials.erase(key);
}

void ChamsModule::reset_container_chams_state() {
    const size_t had_painted = applied_containers.size();
    const size_t had_saved = original_container_materials.size();
    const size_t had_cached = container_objs_.size();

    // FORGET, DO NOT RESTORE -- the trade clear_runtime_cache documents for the item
    // path, for the same reason. This runs at a raid boundary (is_in_raid observed
    // false from application_update) or at a transit (a new GameWorld instance
    // inside one raid), and at both of those the renderers these entries point at
    // are being torn down or rebuilt underneath us. Walking one to write its
    // materials back is the fault the item path already learned to avoid; whatever
    // is still painted dies with the scene that painted it.
    applied_containers.clear();
    original_container_materials.clear();
    container_objs_.clear();

    // The ramp clock goes with it: the destination raid's containers are rolled by
    // its own spawner, so it needs its own early-ramp window.
    container_chams_last_index_ = 0;
    container_chams_first_discover_ms_ = 0;
    container_chams_last_discover_ms_ = 0;
    container_chams_last_scan_ms_ = 0;
    container_chams_last_reapply_ms_ = 0;

    if ((had_painted || had_saved || had_cached) && logger::debug_enabled())
        logger::debug(std::format(
            "container-chams: boundary reset -- dropped {} painted / {} saved / {} cached",
            had_painted, had_saved, had_cached));
}

void ChamsModule::report_container_scan(const container_scan_stats& st, const size_t cache_size,
    const size_t cursor_at_entry, const size_t cursor_after, Il2CppObject* shader,
    const size_t applied_set_size, const size_t saved_set_size) {
    if (!logger::debug_enabled()) return;
    static ULONGLONG s_last_trace = 0;
    const ULONGLONG now = GetTickCount64();
    // A tick that DID work is always reported, throttle or not -- the same rule and
    // the same reason as the item trace: with an unconditional throttle, the repaint
    // does all its work in one tick and the throttle lands on the idle tail, so the
    // line mostly prints the symptom of the defect it exists to detect.
    const bool did_work = st.examined > 0 || st.cached > 0;
    if (!did_work && s_last_trace != 0 && now - s_last_trace < kContainerChamsTraceMs) return;
    s_last_trace = now;

    // HOW TO READ THIS LINE, and the two candidate defects that look identical from
    // outside the game -- both present as "some containers have no chams":
    //
    //   ghost high, cached low
    //       Discovery is working and the map is full of un-rolled prefabs. Normal.
    //       If cached is 0 with ghost 0 too, the LootableContainer type did not
    //       resolve -- check that find_objects_of_type ran at all.
    //   applied>0, zero_renderer==applied, renderers=0
    //       Containers are visited but nothing paints: the transform walk is
    //       finding no qualifying renderer, or is_item_renderer rejects them all.
    //   out_of_range high, applied>0
    //       Working as intended: the distance gate holds containers back until the
    //       player walks closer. Not a defect.
    //   unpainted > 0
    //       Containers left the radius and were restored. Non-zero is NORMAL and is
    //       the point -- distance is a real radius. 0 while out_of_range is high
    //       and things stayed lit means the restore path is not firing.
    //   unaccounted > 0
    //       A branch of the scan loop is not counting itself. Should always be 0;
    //       if it is not, `applied` is not a fraction of anything.
    //
    // Every branch of the scan loop increments exactly one counter, so the counts
    // RECONCILE: examined == already + no_go + no_xform + out_of_range + applied.
    const size_t accounted = st.already + st.no_game_object + st.no_transform
        + st.out_of_range + st.applied;
    const size_t unaccounted = st.examined > accounted ? st.examined - accounted : 0;

    logger::debug(std::format(
        "container-chams: found={} cached={} ghost={} invalid={} no_xform={} live={} "
        "cursor={}->{} examined={} applied={} renderers={} materials={} zero_renderer={} "
        "oor={} unpainted={} dead={} already={} no_go={} unaccounted={} cap={} shader={} "
        "applied_set={} saved={}",
        st.found, st.cached, st.ghost, st.invalid, st.no_transform, cache_size,
        cursor_at_entry, cursor_after, st.examined, st.applied, st.renderers, st.materials,
        st.zero_renderer, st.out_of_range, st.unpainted, st.dead_skipped, st.already,
        st.no_game_object, unaccounted, st.hit_cap,
        shader ? "ok" : "NULL", applied_set_size, saved_set_size));
}

void ChamsModule::scan_container_chams(const Il2CppImage* unity_image, const Il2CppClass* game_world_class,
    Il2CppObjectInstance& main_player) {
    // The whole scan, INCLUDING every early return below it, so a Tracy capture of
    // this zone answers "does container chams cost anything" without inferring it
    // from call counts elsewhere. A zone placed after the gates would only measure
    // the ticks that did work, which is a flattering and wrong number.
    TA_ZONE_N("chams::container_scan");
    if (!asset_bundles::asset_bundle) return;
    container_chams_reapply_if_settings_changed();

    const ULONGLONG now = GetTickCount64();

    // Throttle the whole thing, including discovery, so a discovery pass NEVER
    // lands on a tick whose walk is skipped. With the throttle placed after
    // discovery, one pass in every eight would discard its own found/cached/ghost
    // counters -- and those are the numbers that say whether discovery is working
    // at all. The cost is that a due discovery waits at most one throttle period.
    //
    // Same 250 ms cadence the item scan uses, declared here rather than shared: the
    // two clocks are independent, and coupling them would make one feature's
    // throttle the other's.
    constexpr ULONGLONG container_chams_scan_interval_ms = 250;
    if (container_chams_last_scan_ms_ != 0
        && now - container_chams_last_scan_ms_ < container_chams_scan_interval_ms) return;
    container_chams_last_scan_ms_ = now;

    // ---- discovery, on its own slow clock ----
    //
    // The ramp: the loot spawner rolls containers over the opening seconds of a
    // raid, so a container that will exist this raid may not be findable yet on the
    // first pass. 2 s while the first 30 s are still filling, 15 s after -- the ESP
    // runs the same ramp for the same reason, just slower in steady state because
    // markers do not self-heal.
    container_scan_stats st{};
    const bool in_ramp = container_chams_first_discover_ms_ == 0
        || now - container_chams_first_discover_ms_ < kContainerChamsRampWindowMs;
    const ULONGLONG discover_interval = in_ramp ? kContainerChamsRampIntervalMs
                                                : kContainerChamsSteadyIntervalMs;
    if (container_chams_last_discover_ms_ == 0
        || now - container_chams_last_discover_ms_ >= discover_interval)
    {
        discover_containers(game_world_class, st);
        container_chams_last_discover_ms_ = now;
        // Set once per raid. Every later discovery must leave it alone or the ramp
        // never ends.
        if (container_chams_first_discover_ms_ == 0)
            container_chams_first_discover_ms_ = now;
    }

    // Self-heal cadence: the game can rebind scene materials on its own -- a visual
    // switch, a material rebind after a transit -- which would leave applied_containers
    // claiming a container is chams'd when it visually is not. Clearing on a slow
    // cadence re-applies everything in range over the next few ticks, exactly like
    // the item path's 8 s re-paint.
    if (container_chams_last_reapply_ms_ == 0
        || now - container_chams_last_reapply_ms_ >= kItemChamsReapplyIntervalMs)
    {
        container_chams_last_reapply_ms_ = now;
        // Size BEFORE the clear. Reading it afterwards logs a hardcoded 0, which is
        // the kind of line that looks like evidence and is not.
        const size_t had_applied = applied_containers.size();
        applied_containers.clear();
        // Cursor with it, or the re-paint this exists to perform cannot reach
        // anything the cursor has already passed.
        container_chams_last_index_ = 0;
        if (logger::debug_enabled())
            logger::debug(std::format(
                "container-chams: reapply cadence fired, cleared {} applied, cursor rewound to 0",
                had_applied));
    }

    Il2CppObject* chams_shader = load_item_chams_shader(unity_image, container_chams_type->get_value());
    if (!chams_shader) return;

    const unity::color visible = to_unity_color(container_visible_color->get_value());
    const unity::color occluded = to_unity_color(container_occluded_color->get_value());

    // Read the slider ONCE. It is a ConfigValue the menu can write from the render
    // thread, so two reads could straddle a change and produce a max_dist_sq
    // belonging to neither value.
    const float max_distance = container_chams_distance->get_value();
    const float max_dist_sq = max_distance * max_distance;

    unity::vector3 origin = {0, 0, 0};
    if (main_player.get_instance())
    {
        if (Il2CppObject* player_object = unity::component_get_game_object(main_player.get_instance()))
            if (Il2CppObject* player_transform = unity::gameobject_get_transform(player_object))
                origin = unity::transform_get_pos(player_transform);
    }

    Il2CppObject* renderer_type = il2utils::get_system_type(unity_image, "UnityEngine", "Renderer");
    if (!renderer_type) return;

    const size_t cache_size = container_objs_.size();
    size_t& last_index = container_chams_last_index_;
    if (cache_size < last_index)
        last_index = 0;

    const size_t cursor_at_entry = last_index;
    constexpr int max_container_chams_per_tick = 32;
    int processed = 0;

    for (size_t i = last_index; i < cache_size; ++i)
    {
        ++st.examined;
        Il2CppObject* container = container_objs_[i];
        // Cannot happen -- discovery filters every entry -- but a null in the cache
        // is counted rather than silently skipped, because the reconciliation at the
        // bottom of the trace line only holds if every branch counts itself.
        if (!container) { ++st.no_game_object; continue; }

        const uintptr_t container_key = reinterpret_cast<uintptr_t>(container);

        Il2CppObject* game_object = unity::component_get_game_object(container);
        if (!game_object) { ++st.no_game_object; continue; }
        Il2CppObject* transform = unity::gameobject_get_transform(game_object);
        if (!transform) { ++st.no_transform; continue; }

        const unity::vector3 pos = unity::transform_get_pos(transform);
        const float dx = origin.x - pos.x;
        const float dy = origin.y - pos.y;
        const float dz = origin.z - pos.z;
        const bool in_range = dx * dx + dy * dy + dz * dz <= max_dist_sq;

        // Distance is a REAL radius, not a first-paint gate -- the same correction
        // the item path carries. Walking away actually turns the chams back off, so
        // lowering the slider has a visible effect instead of a one-way latch.
        if (!in_range)
        {
            ++st.out_of_range;
            // The gate is original_container_materials, NOT applied_containers.
            // The 8 s re-paint clears applied_containers at the top of this
            // function, so by the time this branch is reached that set has just
            // been emptied and contains nothing -- a gate on it makes the restore
            // dead code, which is precisely the shape of bug the item trace caught
            // 127 scan lines of on 2026-10-01.
            if (original_container_materials.contains(container_key))
            {
                // Liveness before the call: the cache is up to one discovery
                // interval old, and get_materials on a renderer whose native object
                // is gone is a fault, not a restore.
                if (eft_api::is_il2cpp_object_likely_valid(container)
                    && unity::is_unity_object_alive(container, "chams/container_oor"))
                {
                    unpaint_chams_to_container(container, renderer_type);
                    ++st.unpainted;
                }
                else
                {
                    // Gone. Drop the bookkeeping rather than leave a saved entry
                    // naming an object that will never be restored -- and that the
                    // allocator may hand to a different object later.
                    forget_container_materials(container_key);
                    ++st.dead_skipped;
                }
                // Erasing from applied_containers afterwards keeps the two
                // consistent, so the container is re-painted (and re-saved) if it
                // comes back into range.
                applied_containers.erase(container_key);
            }
            continue;
        }

        if (applied_containers.contains(container_key)) { ++st.already; continue; }

        // save_out is passed ONLY when this container has no saved materials yet.
        // Saving is a one-shot per container: it records the pre-paint state, and
        // re-saving after a repaint would capture our own chams as the thing to
        // restore.
        std::vector<Il2CppObject*> renderers;
        collect_container_renderers(container, renderer_type, renderers);

        int item_slots = 0;
        std::vector<std::vector<Il2CppObject*>> fresh_originals;
        const bool needs_save = original_container_materials.find(container_key)
            == original_container_materials.end();
        const int painted = paint_renderer_list(renderers, chams_shader, visible, occluded,
            &item_slots, needs_save ? &fresh_originals : nullptr);

        st.renderers += static_cast<size_t>(painted < 0 ? 0 : painted);
        st.materials += static_cast<size_t>(item_slots < 0 ? 0 : item_slots);
        ++st.applied;
        if (painted > 0)
        {
            // Save on the first paint only. An empty list means the accessor gave us
            // nothing to restore, and recording that would make the container
            // permanently un-un-paintable: the entry exists, so needs_save is false
            // forever, and the restore would find nothing and restore nothing.
            if (needs_save && !fresh_originals.empty())
                original_container_materials.emplace(container_key, std::move(fresh_originals));
            applied_containers.insert(container_key);
        }
        else
            ++st.zero_renderer;

        // Spread material instantiation over ticks so a container-dense map never
        // stalls a single frame.
        if (++processed >= max_container_chams_per_tick)
        {
            last_index = i + 1;
            st.hit_cap = true;
            report_container_scan(st, cache_size, cursor_at_entry, last_index, chams_shader,
                applied_containers.size(), original_container_materials.size());
            return;
        }
    }
    last_index = cache_size;

    report_container_scan(st, cache_size, cursor_at_entry, last_index, chams_shader,
        applied_containers.size(), original_container_materials.size());
}

void ChamsModule::gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
    Il2CppObjectInstance main_player) {
    TA_ZONE_N("chams::gameworld_update");
    const Il2CppImage* unity_image = il2utils::resolve_image("UnityEngine.CoreModule.dll");

    // ---- DEBUG: interaction probe, once per process ----
    //
    // Installed here rather than from init() for two reasons: init() runs before
    // Assembly-CSharp is necessarily resolvable (always_on::init has to poll for
    // it), and this is also the first place that holds the GameWorld's own image
    // -- the same source discover_containers uses, so the two agree about which
    // assembly holds the interactive classes.
    if (!interaction_hooks_installed_)
        install_interaction_hooks(game_world_class->image);

    // The probe's distance figure. Three managed calls on a path that already
    // walks the player for the chams origin, and it is what turns "it did not
    // paint" into "it did not paint because it was 180 m away".
    if (Il2CppObject* player_instance = main_player.get_instance())
    {
        if (Il2CppObject* player_go = unity::component_get_game_object(player_instance))
            if (Il2CppObject* player_tr = unity::gameobject_get_transform(player_go))
                last_player_pos_ = unity::transform_get_pos(player_tr);
    }

    // ---- PROTOTYPE: managed Material catalogue, once per process ----
    //
    // Delete this call and module/material_catalogue.h to remove it. It answers
    // one question -- can this process enumerate live Material objects by name
    // through the managed ABI, with no hardcoded RVAs -- and logs a tri-state
    // verdict (0 ok / 1 failed / 2 checked nothing) plus every count that
    // separates "it ran" from "it worked". See the file's header and
    // tools/material_catalogue_route.md. Deliberately here, right after the
    // image is resolved and BEFORE any paint state is touched: it must not be
    // able to interact with the chams caches, and a raid that starts already
    // logged is the only way to catch it early.
    material_catalogue::probe_once(unity_image);

    // ---- raid / transit boundary ----
    //
    // TWO boundaries, two detectors, because they are visible from different
    // places:
    //
    //   RAID END (death, exfil)  -- hk_game_world_update stops calling this the
    //     instant is_in_raid goes false, so nothing here can observe it. That half
    //     lives in application_update, whose hook has no raid gate.
    //
    //   TRANSIT -- inside ONE raid, with the flag potentially true straight
    //     through the load, while the entire scene is destroyed and rebuilt. What
    //     changes is the GameWorld instance itself, and that is observable here.
    //
    // Either way the container chams must start clean: every cached container
    // pointer and every saved material belongs to the scene that is going away, and
    // a new object that happens to land on a stale address would otherwise be
    // treated as already painted. reset_container_chams_state forgets rather than
    // restores, which is the documented trade for a teardown path.
    Il2CppObject* world_ptr = game_world_instance.get_instance();
    if (world_ptr != last_seen_game_world_)
    {
        // The nullptr case is the first raid after start-up (or after the raid-end
        // reset in application_update already emptied everything): nothing to drop,
        // and logging it as a transit would be a lie.
        if (last_seen_game_world_ != nullptr)
        {
            logger::debug("container-chams: new GameWorld instance while in raid -- transit, resetting");
            reset_container_chams_state();
        }
        last_seen_game_world_ = world_ptr;
    }

    // weapon chams
    if (weapon_chams->get_value())
    {
        TA_ZONE_N("chams::weapon");
    {
        Il2CppObject* renderer_type = il2utils::get_system_type(unity_image, "UnityEngine", "Renderer");
        const auto main_player_game_object = unity::component_get_game_object(main_player.get_instance());
        const auto main_player_transform = unity::gameobject_get_transform(main_player_game_object);
        std::vector<Il2CppObject*> renderers{};
        unity::transform_apply_to_all_children(main_player_transform,
            [&renderer_type, &renderers](Il2CppObject* transform) {
                Il2CppObject* game_object = unity::transform_get_game_object(
                    transform);
                renderers.push_back(
                    unity::get_component_internal(game_object, renderer_type));
            });

        for (const auto renderer : renderers)
        {
            if (renderer == nullptr) continue;
            Il2CppObjectInstance renderer_instance(renderer);

            Il2CppObject* material_obj =
                renderer_instance.call_or<ChamsObjPtr>("get_material", 0, ChamsObjPtr{}, nullptr);
            if (!material_obj) continue;
            Il2CppObjectInstance material_instance(material_obj);

            std::string name = unity::get_name(material_instance.get_instance());

            bool is_scope = name.find("scope") != std::string::npos || name.find("optic") != std::string::npos;
            bool is_arms = name.find("watch") != std::string::npos || name.find("bear") != std::string::npos || name.find("Bear") != std::string::npos || name.find("usec") != std::string::npos || name.find("arm") != std::string::npos || name.find("Usec") != std::string::npos;
            bool is_gear = name.find("helmet")
                    != std::string::npos
                || name.find("glasses")
                    != std::string::npos
                || name.find("rig")
                    != std::string::npos
                || name.find("belt")
                    != std::string::npos
                || name.find("wear")
                    != std::string::npos
                || name.find("mask")
                    != std::string::npos
                || name.find("balaclava")
                    != std::string::npos;
            if ((!is_scope || include_scope->get_value()) && (!is_arms || include_arms->get_value()) && !is_gear)
            {
                // load shader from assetbundle
                if (!asset_bundles::asset_bundle) continue;
                Il2CppObject* shader_system_type = il2utils::get_system_type(
                    unity_image, "UnityEngine", "Shader");
                Il2CppObject* chams_shader = asset_bundles::load_asset(
                    get_shader_name(weapon_chams_type->get_value()).c_str(), shader_system_type);

                material_instance.call_or_void<void (*)(Il2CppObject*, Il2CppObject*)>(
                    "set_shader", 1, chams_shader);

                Il2CppString* color_visible = il2cpp::il2cpp_string_new("_Color_Visible");
                Il2CppString* color_occluded = il2cpp::il2cpp_string_new("_Color_Occluded");

                const auto set_color = material_instance.get_method<void (*)(
                    Il2CppObject*, Il2CppString*, unity::color)>("SetColor", 2);

                const ImVec4 visible = weapon_chams_color->get_value();
                set_color(material_instance.get_instance(), color_visible,
                    unity::color{visible.x, visible.y, visible.z, visible.w});
                set_color(material_instance.get_instance(), color_occluded,
                    unity::color{visible.x, visible.y, visible.z, visible.w});

                // set texture to null so all the shaders look right
                material_instance.call_or_void<void (*)(Il2CppObject*, Il2CppObject*)>(
                    "set_mainTexture", 1, nullptr);
            }
        }
    }
    }  // TA_ZONE_N("chams::weapon")

    // chams
    if (player_chams->get_value())
    {
        TA_ZONE_N("chams::player");
        Il2CppArray* alive_players = game_world_instance.get_field<unity::list*>("AllAlivePlayersList")->m_p_list_array;

        for (size_t i = 0; i < alive_players->max_length; ++i)
        {
            Il2CppObject* player_object =
                reinterpret_cast<Il2CppObject**>(&alive_players->data)[i];
            if (!player_object) continue;
            if (player_object == main_player.get_instance()) continue;
            Il2CppObjectInstance player_instance(player_object);

            // re-apply when menu is open
            if (menu::is_active())
            {
                applied_players.clear();
            }

            // skip already processed players
            const uintptr_t player_key = reinterpret_cast<uintptr_t>(player_object);
            if (applied_players.contains(player_key)) continue;

            // explicit type required
            Il2CppObjectInstance player_body(
                game_world_class->image, "EFT", "PlayerBody",
                player_instance.call_or<ChamsObjPtr>(
                    "get_PlayerBody", 0, ChamsObjPtr{}, player_instance.get_instance()));

            const auto body_skins = player_body.get_field<unity::dict<int, Il2CppObject*>*>("BodySkins");

            for (int j = 0; j < body_skins->m_i_count; ++j)
            {
                Il2CppObjectInstance lodded_skin(body_skins->get_value_by_index(j));

                const auto lods_array = lodded_skin.get_field<Il2CppArray*>("_lods");
                for (size_t k = 0; k < lods_array->max_length; ++k)
                {
                    Il2CppObject* skin_object = reinterpret_cast<Il2CppObject**>(&lods_array->data)[k];
                    Il2CppObjectInstance abstract_skin_instance(skin_object);

                    Il2CppObjectInstance skinned_mesh_renderer(
                        abstract_skin_instance.call_or<ChamsObjPtr>(
                            "get_SkinnedMeshRenderer", 0, ChamsObjPtr{}, abstract_skin_instance.get_instance()));

                    Il2CppObjectInstance material_instance(
                        skinned_mesh_renderer.call_or<ChamsObjPtr>("get_material", 0, ChamsObjPtr{}, skinned_mesh_renderer.get_instance()));

                    std::string name = unity::get_name(material_instance.get_instance());
                    if (!(name.find("armour") != std::string::npos || name.find("helmet") != std::string::npos || name.find("glasses") != std::string::npos || name.find("cover") != std::string::npos || name.find("rig") != std::string::npos || name.find("belt") != std::string::npos || name.find("wear") != std::string::npos || name.find("mask") != std::string::npos || name.find("balaclava") != std::string::npos) || gear_chams->get_value())
                    {
                        // load shader from assetbundle
                        if (!asset_bundles::asset_bundle) continue;
                        Il2CppObject* shader_system_type = il2utils::get_system_type(
                            unity_image, "UnityEngine", "Shader");
                        Il2CppObject* chams_shader = asset_bundles::load_asset(
                            get_shader_name(chams_type->get_value()).c_str(), shader_system_type);

                        material_instance.call_or_void<void (*)(Il2CppObject*, Il2CppObject*)>(
                            "set_shader", 1, chams_shader);

                        Il2CppString* color_visible = il2cpp::il2cpp_string_new("_Color_Visible");
                        Il2CppString* color_occluded = il2cpp::il2cpp_string_new("_Color_Occluded");

                        const auto set_color = material_instance.get_method<void (*)(
                            Il2CppObject*, Il2CppString*, unity::color)>("SetColor", 2);

                        const ImVec4 visible = visible_color->get_value();
                        const ImVec4 invisible = invisible_color->get_value();
                        set_color(material_instance.get_instance(), color_visible,
                            unity::color{visible.x, visible.y, visible.z, visible.w});
                        set_color(material_instance.get_instance(), color_occluded,
                            unity::color{invisible.x, invisible.y, invisible.z, invisible.w});

                        // set texture to null so all the shaders look right
                        material_instance.call_or_void<void (*)(Il2CppObject*, Il2CppObject*)>(
                            "set_mainTexture", 1, nullptr);
                    }
                }
            }

            applied_players.insert(player_key);
        }
    }

    // loot chams
    const bool item_chams_on = item_chams->get_value();
    if (item_chams_on)
    {
        if (!item_chams_was_enabled_)
        {
            // OFF -> ON edge: a stale applied_items (item materials reverted by
            // the game after a transit) would otherwise keep the toggle dead and
            // "switching the checkbox does nothing" — force a full re-scan so the
            // chams re-paint immediately.
            item_chams_was_enabled_ = true;
            item_chams_last_scan_ms_ = 0;
            applied_items.clear();
            item_chams_last_scanned_index_ = 0;
        }
        scan_item_chams(unity_image, game_world_instance, main_player);
    }
    else
    {
        // OFF edge: actually TAKE THE PAINT OFF.
        //
        // This used to just set the flag and stop scanning, leaving every lit item lit
        // for the rest of the raid -- un-satisfying in a way that reads as the toggle
        // being partly broken, and the same one-way paint that made the distance slider
        // look inert. Now that the original materials are kept, switching loot chams off
        // restores the world.
        //
        // Self-guarding on applied_items being empty, so it costs nothing on the frames
        // after the first and needs no separate "already did this" flag.
        if (!applied_items.empty())
            unpaint_all_items(game_world_instance);
        item_chams_was_enabled_ = false;
    }

    // container chams
    const bool container_chams_on = container_chams->get_value();
    if (container_chams_on)
    {
        if (!container_chams_was_enabled_)
        {
            // OFF -> ON edge, same shape and same reason as the item one: force a
            // full discovery + repaint so the checkbox answers immediately instead
            // of waiting out the discovery interval.
            container_chams_was_enabled_ = true;
            container_chams_last_scan_ms_ = 0;
            container_chams_last_discover_ms_ = 0;
            applied_containers.clear();
            container_chams_last_index_ = 0;
        }
        scan_container_chams(unity_image, game_world_class, main_player);
    }
    else
    {
        // OFF edge: take the paint off, exactly like the item path. Self-guarding
        // on the saved map being empty, so it costs nothing on later frames.
        if (!original_container_materials.empty())
        {
            Il2CppObject* renderer_type = il2utils::get_system_type(unity_image, "UnityEngine", "Renderer");
            if (renderer_type)
                unpaint_all_containers(renderer_type);
            else
            {
                // No way to address a renderer means no way to restore one. Forget
                // rather than leave bookkeeping that claims a restore is owed.
                applied_containers.clear();
                original_container_materials.clear();
            }
        }
        container_chams_was_enabled_ = false;
    }

    refresh_cache_stats();
}

void ChamsModule::init() {
    player_chams->set_master_toggle(true);
    weapon_chams->set_master_toggle(true);
    item_chams->set_master_toggle(true);
    container_chams->set_master_toggle(true);
}

// ---------------------------------------------------------------------------
// DEBUG: the interaction probe.
//
// Two classes, because those are the two WorldInteractiveObject subclasses
// whose Interact(InteractionResult) a player reaches by opening something:
// LootableContainer (crates, safes, registers -- and PrivateLootableContainer
// by inheritance, which does not override it) and Trunk (car boots). Door is
// deliberately NOT hooked: it carries no loot, and its interactive overload is
// Interact(bool, int) on a different class entirely.
//
// Trunk IS hooked even though the container work treats it as a door: the point
// of the probe is that opening something NAMES it, so a car boot opens as
// "Trunk" in the log instead of as silence.
// ---------------------------------------------------------------------------
void ChamsModule::install_interaction_hooks(const Il2CppImage* image) {
    interaction_hooks_installed_ = true;
    if (!image) {
        logger::warn("interaction probe: no image to resolve EFT.Interactive from");
        return;
    }

    if (const Il2CppClass* lc = il2utils::resolve_class(image, "EFT.Interactive", "LootableContainer"))
        il2utils::hook_method(lc, "Interact", 1, hk_lootable_container_interact,
            &o_lootable_container_interact);
    if (const Il2CppClass* trunk = il2utils::resolve_class(image, "EFT.Interactive", "Trunk"))
        il2utils::hook_method(trunk, "Interact", 1, hk_trunk_interact, &o_trunk_interact);

    if (logger::debug_enabled())
        logger::debug("interaction probe: installed on EFT.Interactive.LootableContainer and Trunk");
}

// The ORIGINAL runs first in both bodies, and that ordering is the safety
// property: the player's interaction completes no matter what the diagnostic
// does afterwards, and everything after it is read-only.
void ChamsModule::hk_lootable_container_interact(Il2CppObject* interactable, Il2CppObject* interaction_result) {
    if (o_lootable_container_interact) o_lootable_container_interact(interactable, interaction_result);
    if (chams_module_self) chams_module_self->log_interaction_probe(interactable, interaction_result);
}

void ChamsModule::hk_trunk_interact(Il2CppObject* interactable, Il2CppObject* interaction_result) {
    if (o_trunk_interact) o_trunk_interact(interactable, interaction_result);
    if (chams_module_self) chams_module_self->log_interaction_probe(interactable, interaction_result);
}

// EInteractionType (dump.cs): 0 Open, 1 Close, 2 Unlock, 3 Breach, 4 Lock,
// 5 GoIn, 6 GoOut, 7 Seal, 8 Unseal. Printed by number AND name so an unknown
// value is visible as a number rather than swallowed.
static const char* interaction_type_name(const int type) {
    switch (type) {
    case 0: return "Open";
    case 1: return "Close";
    case 2: return "Unlock";
    case 3: return "Breach";
    case 4: return "Lock";
    case 5: return "GoIn";
    case 6: return "GoOut";
    case 7: return "Seal";
    case 8: return "Unseal";
    default: return "?";
    }
}

// ---------------------------------------------------------------------------
// DEBUG: describe an interactable's hierarchy when the renderer collector finds
// nothing.
//
// WHY. The 2026-10-13 21:20 raid proved the medbag / sport-bag / corpse families
// are admitted by every filter the container pipeline has -- cached, ghost_pass,
// initialized and in_range all true -- and are STILL not painted, because
// collect_container_renderers returns 0 for them while every static container
// (cashbox, safe, card box, weapon box, barrel) returns 1-5. The collector walks
// DOWN from the container's own GameObject only, so the three candidates were:
// the mesh sits on the PARENT, on an INACTIVE child, or deeper than the depth-2
// cap. Guessing between them is how a parent walk ends up painting a corpse's
// body root, so this prints which one it is instead.
//
// ANSWERED, 22:37 the same day (pid 22380): the PARENT. The bag and corpse
// containers are leaves; their meshes are ordinary active MeshRenderer children
// of the immediate parent (`_LOD0`, `_SHADOW_LOD0`). collect_container_renderers
// now walks exactly one ancestor, only when the own subtree came up empty.
//
// THE DUMP LIED ONCE, and it is worth the paragraph. v1 walked the ancestor loop
// with the same `transform` variable the child walk uses, so the children it
// printed belonged to PARENT2 -- a subtree that has nothing to do with the
// container -- and it cheerfully showed a MeshRenderer while the collector, right
// above it in the same hook, reported none. For one raid the log read as the
// collector being refuted by the diagnostic that exists to test it. The two now
// walk from separate variables, and the fix above is a reading of THIS dump, not
// of the first one.
//
// BOUNDED, because it runs on the game thread inside an interaction: two
// ancestors, two levels of children, at most 8 children named, and no renderer
// component is ever resolved twice.
// ---------------------------------------------------------------------------
static std::string describe_renderer_hierarchy(Il2CppObject* interactable, Il2CppObject* renderer_type) {
    std::string out;
    if (!interactable || !renderer_type) return out;

    auto renderer_class = [&](Il2CppObject* go) -> const char* {
        if (!go) return "-";
        if (Il2CppObject* r = unity::gameobject_get_component(go, renderer_type))
            return (r->klass && r->klass->name) ? r->klass->name : "?";
        return "none";
    };

    Il2CppObject* go = unity::component_get_game_object(interactable);
    if (!go) return "no GameObject";

    out += "own renderer=";
    out += renderer_class(go);

    // Ancestors: the interactable is often a LEAF named "<prefab>_lootable"
    // under the visual root, which is the shape DoorsModule already walks for
    // the WorldInteractiveObject itself.
    //
    // `ancestor` and `transform` are deliberately separate variables. v1 of this
    // dump walked the ancestor loop with `transform` itself, so the child walk
    // below started at PARENT2 and reported a subtree that had nothing to do with
    // the container -- it printed a healthy MeshRenderer two levels up the tree
    // while collect_container_renderers, correctly starting at the container's own
    // transform, found none. The two disagreed for a whole raid and the log looked
    // like it was refuting the collector. A diagnostic that walks the wrong node is
    // worse than no diagnostic: it is evidence, and it is evidence about elsewhere.
    Il2CppObject* transform = unity::gameobject_get_transform(go);
    Il2CppObject* ancestor = transform;
    Il2CppObject* parent_transform = nullptr;
    if (ancestor) {
        for (int depth = 0; depth < 2; ++depth) {
            Il2CppObject* parent = unity::transform_get_parent(ancestor);
            if (!parent) break;
            Il2CppObject* parent_go = unity::component_get_game_object(parent);
            if (!parent_go) break;
            out += depth == 0 ? " parent[" : " parent2[";
            out += unity::get_name(parent_go);
            out += " renderer=";
            out += renderer_class(parent_go);
            out += "]";
            // Kept for the second walk below: the collector looks here next, so
            // the dump has to be able to describe here.
            if (depth == 0) parent_transform = parent;
            ancestor = parent;
        }
    }

    // Children, depth-capped the way the collector is, with the active flag
    // printed so an inactive mesh is distinguishable from a missing one.
    struct walker {
        // Returns how many mesh renderers it NAMED, using the collector's own
        // is_item_renderer predicate rather than a lookalike -- the diagnostic
        // has to measure with the same rule the thing under test uses, or a
        // "MeshRenderer" here means nothing to `renderers=0` there.
        static int run(Il2CppObject* tr, Il2CppObject* renderer_type, int depth,
                       std::string& out, int& named) {
            int meshes = 0;
            if (!tr || depth > 2 || named >= 8) return meshes;
            const int count = unity::transform_get_child_count(tr);
            for (int i = 0; i < count && named < 8; ++i) {
                Il2CppObject* child = unity::transform_get_child(tr, i);
                if (!child) continue;
                Il2CppObject* child_go = unity::component_get_game_object(child);
                if (!child_go) continue;
                const bool active = game_object_is_active_self(child_go);
                Il2CppObject* child_renderer = unity::gameobject_get_component(child_go, renderer_type);
                // Qualified: this is a free function, not a member, so unqualified
                // lookup does not reach the static member (C3861).
                if (ChamsModule::is_item_renderer(child_renderer)) ++meshes;
                out += " child[";
                out += active ? "act" : "inact";
                out += " ";
                out += unity::get_name(child_go);
                out += " renderer=";
                if (child_renderer) out += (child_renderer->klass && child_renderer->klass->name)
                    ? child_renderer->klass->name : "?";
                else out += "none";
                out += "]";
                ++named;
                meshes += run(child, renderer_type, depth + 1, out, named);
            }
            return meshes;
        }
    };

    if (transform) {
        int named = 0;
        out += " own_children=";
        out += std::to_string(unity::transform_get_child_count(transform));
        const int own_meshes = walker::run(transform, renderer_type, 1, out, named);

        // THEN THE PARENT, because that is the collector's second look and the
        // dump has to cover the same ground in the same order. v2 walked only
        // the container's own children, which is the one subtree already known
        // to be empty -- and for jacket_03_LOOTABLE and Corpse_*_LOOTABLE the
        // 8-name cap got spent on a SIBLING variant in the shared set
        // (jacket_01_*, Corpse_Usec_var_03_*) before reaching this object's own
        // branch, so the line named a MeshRenderer belonging to a different
        // jacket entirely. A diagnostic that spends its budget on a sibling is
        // the v1 bug in new clothes: evidence, about a different object.
        if (own_meshes == 0 && parent_transform) {
            int parent_named = 0;
            out += " parent_children=";
            out += std::to_string(unity::transform_get_child_count(parent_transform));
            const int parent_meshes = walker::run(parent_transform, renderer_type, 1, out, parent_named);
            // Both levels empty is a real answer, not a failed diagnostic: the
            // mesh is somewhere the collector is not allowed to look, and the
            // log should say so in words rather than by omission.
            if (parent_meshes == 0) out += " NO_MESH_ON_EITHER_LEVEL";
        }
    }

    return out;
}

void ChamsModule::log_interaction_probe(Il2CppObject* interactable, Il2CppObject* interaction_result) {
    // One std::format for the whole line, so the gate goes in front of it.
    if (!logger::debug_enabled()) return;
    if (!eft_api::is_il2cpp_object_likely_valid(interactable)) return;

    const char* klass = (interactable->klass && interactable->klass->name) ? interactable->klass->name : "?";

    // InteractionResult+0x10 is the readonly EInteractionType. Bounded before the
    // read: the result object arrives from the game and has never been checked.
    int interaction_type = -1;
    if (interaction_result
        && eft_api::is_readable_address(interaction_result, 0x18))
        interaction_type = *reinterpret_cast<const int*>(
            reinterpret_cast<uintptr_t>(interaction_result) + 0x10);

    Il2CppObject* game_object = unity::component_get_game_object(interactable);
    const std::string go_name = game_object ? unity::get_name(game_object) : std::string{};

    unity::vector3 pos{};
    float distance = -1.f;
    if (Il2CppObject* transform = game_object ? unity::gameobject_get_transform(game_object) : nullptr) {
        pos = unity::transform_get_pos(transform);
        const float dx = pos.x - last_player_pos_.x;
        const float dy = pos.y - last_player_pos_.y;
        const float dz = pos.z - last_player_pos_.z;
        distance = sqrtf(dx * dx + dy * dy + dz * dz);
    }

    // Non-containers get the identification line and nothing else: reporting
    // container-pipeline verdicts for a car boot would be noise.
    const bool is_container = strstr(klass, "LootableContainer") != nullptr;
    if (!is_container) {
        logger::debug(std::format(
            "interact: {} '{}' type={}({}) pos=({:.1f},{:.1f},{:.1f}) dist={:.1f}m [not a container]",
            klass, go_name.empty() ? "?" : go_name.c_str(),
            interaction_type, interaction_type_name(interaction_type),
            pos.x, pos.y, pos.z, distance));
        return;
    }

    const uintptr_t key = reinterpret_cast<uintptr_t>(interactable);
    const bool in_cache = std::find(container_objs_.begin(), container_objs_.end(), interactable)
        != container_objs_.end();

    // The game's own flag, read directly, so the proxy fields below can be judged
    // against it: <IsInitialized>k__BackingField is a compiler-generated backing
    // field at 0x1C0 and is what the spawner sets when it rolls a container.
    bool initialized = false;
    if (const FieldInfo* field = il2utils::resolve_field(interactable->klass, "<IsInitialized>k__BackingField"))
        if (eft_api::is_readable_address(
                reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(interactable) + field->offset), 1))
            initialized = *reinterpret_cast<const uint8_t*>(
                reinterpret_cast<uintptr_t>(interactable) + field->offset) != 0;

    int renderer_count = 0;
    std::vector<Il2CppObject*> renderers;
    if (Il2CppObject* renderer_type = il2utils::get_system_type(
            il2utils::resolve_image("UnityEngine.CoreModule.dll"), "UnityEngine", "Renderer")) {
        renderer_count = collect_container_renderers(interactable, renderer_type, renderers);
    }

    const float max_distance = container_chams_distance->get_value();

    logger::debug(std::format(
        "interact: {} '{}' type={}({}) pos=({:.1f},{:.1f},{:.1f}) dist={:.1f}m "
        "cached={} ghost_pass={} initialized={} renderers={} painted={} saved={} "
        "in_range={}(slider {:.0f}m)",
        klass, go_name.empty() ? "?" : go_name.c_str(),
        interaction_type, interaction_type_name(interaction_type),
        pos.x, pos.y, pos.z, distance,
        in_cache,
        eft_api::is_container_actually_placed(interactable),
        initialized,
        renderer_count,
        applied_containers.contains(key),
        original_container_materials.contains(key),
        distance >= 0.f && distance <= max_distance,
        max_distance));

    // The collector found nothing while every static container finds 1-5: say
    // WHERE the mesh is instead of guessing. Same DEBUG gate, one extra line,
    // and only for the objects that need it.
    if (renderer_count == 0) {
        logger::debug(std::format("interact: no_renderer {} -- {}",
            go_name.empty() ? "?" : go_name.c_str(),
            describe_renderer_hierarchy(interactable, il2utils::get_system_type(
                il2utils::resolve_image("UnityEngine.CoreModule.dll"), "UnityEngine", "Renderer"))));
    }
}

// GAME THREAD. Two size() calls, so it is called at the end of every
// gameworld_update rather than on a timer.
void ChamsModule::refresh_cache_stats() {
    cache_entries_.store(applied_players.size() + applied_items.size() + applied_containers.size(),
        std::memory_order_relaxed);
}

void ChamsModule::clear_runtime_cache() {
    applied_players.clear();
    applied_items.clear();
    // The saved materials go too, and this is a FORGET rather than an un-paint on
    // purpose. clear_runtime_cache fires on raid transitions and config loads, where
    // the renderers these point at are being torn down or rebuilt underneath us --
    // walking them to restore would be writing into a scene that is going away. The
    // cost is that anything still painted when this runs keeps its chams until the
    // game rebinds its materials or the next raid; the alternative is faulting on the
    // teardown path, which is the worse trade.
    original_item_materials.clear();
    item_shader_cache_.clear();
    item_chams_last_scan_ms_ = 0;
    // The full cache wipe resets every other cursor-like field, so this one belongs here too.
    item_chams_last_scanned_index_ = 0;
    item_chams_last_type_ = -1;
    item_chams_last_visible_ = 0;
    item_chams_last_occluded_ = 0;
    item_chams_last_reapply_ms_ = 0;
    item_chams_was_enabled_ = false;
    // The container chams state goes through its own reset rather than being
    // repeated inline: the boundary reset clears the cache, the saved materials,
    // the cursor and every discovery clock, and this is the same boundary.
    reset_container_chams_state();
    last_seen_game_world_ = nullptr;
    container_chams_was_enabled_ = false;
    // Report the emptied state immediately instead of leaving the panel showing
    // the previous totals until the next tick.
    cache_entries_.store(0, std::memory_order_relaxed);
}

// Render thread. Plain atomic loads: no lock, no container access, so this
// cannot collide with the game thread's inserts.
[[nodiscard]] size_t ChamsModule::get_runtime_cache_count() {
    return cache_entries_.load(std::memory_order_relaxed);
}

[[nodiscard]] size_t ChamsModule::get_runtime_cache_bytes() {
    return cache_entries_.load(std::memory_order_relaxed) * sizeof(Il2CppObject*);
}

void ChamsModule::prepare_menu_draw() {
    const auto dis = [](ConfigValue* v, const bool disabled) { v->set_disabled(disabled); };

    const bool player_on = player_chams->get_value();
    const bool weapon_on = weapon_chams->get_value();

    dis(gear_chams, !player_on);
    dis(chams_type, !player_on);
    dis(visible_color, !player_on);
    dis(invisible_color, !player_on);
    dis(weapon_chams_type, !weapon_on);
    dis(weapon_chams_color, !weapon_on);
    dis(include_scope, !weapon_on);
    dis(include_arms, !weapon_on);

    const bool item_on = item_chams->get_value();
    dis(item_chams_type, !item_on);
    dis(item_visible_color, !item_on);
    dis(item_occluded_color, !item_on);
    dis(item_chams_distance, !item_on);

    const bool container_on = container_chams->get_value();
    dis(container_chams_type, !container_on);
    dis(container_visible_color, !container_on);
    dis(container_occluded_color, !container_on);
    dis(container_chams_distance, !container_on);
}
