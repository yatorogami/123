#pragma once

#include <algorithm>
#include <cctype>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "../Module.h"
#include "../ModuleCategory.h"
#include "../eft_api.h"
#include "../../config/CheckboxValue.h"
#include "../game_state.h"
#include "../../il2cpp/Il2CppObjectInstance.h"
#include "../../il2cpp/il2utils.h"
#include "../../il2cpp/unity.h"

// In-raid destination browser.  Positions are read only from the currently
// loaded GameWorld; it never attempts a cross-map move or matchmaking request.
class TeleportModule : public Module
{
  public:
    // Keep the internal name stable: menu navigation uses it to detect the
    // Teleport sidebar. The display key controls only the visible card title.
    TeleportModule();

    void draw_overlay(ImDrawList*) override;
    void application_update() override;
    void init() override;

    void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world,
        Il2CppObjectInstance main_player) override;

    void draw_menu_extra() override;

  private:
    struct destination
    {
        std::string name;
        unity::vector3 position{};
    int status = -1;         // ExfiltrationPoint.Status (a BYTE); -1 = n/a (transits)
    // Whether THIS PLAYER may leave by this extract. Added 2026-10-05 because
    // `status` is not eligibility: the same module's own comment above
    // (`ESP-parity active = Available(2) / Open(4,5)`) filtered the map selector on a
    // status byte, so an extract unusable because the player is Scav or a requirement is
    // unmet was offered as a live teleport destination. `unknown` falls back to the
    // status test, so a failed snapshot degrades to the old behaviour rather than to none.
    //
    // REVISED 2026-10-10: that comment's `Available(2) / Open(4,5)` table was itself wrong
    // -- 2 is `UncompleteRequirements`, not "Available". The status fallback is now
    // `RegularMode` (4) only, and the eligibility verdict already ANDs in the live status,
    // so both directions of the original misreport are closed. See eft_api.h
    // `exfil_status` and `exfil_eligibility_of`.
    eft_api::exfil_eligibility eligibility = eft_api::exfil_eligibility::unknown;
        std::string requirement; // item ShortName when the point needs an item
    };
    // ESP-parity "active" is decided by ELIGIBILITY when it is known -- and eligibility is
    // the conjunction of `EligiblePoints` membership AND a live status of RegularMode(4).
    // See the `eligibility` member and eft_api::exfil_eligibility_of.
    static bool exit_status_active(int status, eft_api::exfil_eligibility eligibility);
    // Shared with draw_menu_extra() on the render thread, so published as one
    // immutable snapshot rather than four separately-updated members.
    //
    // This used to be four plain members reassigned every gameworld_update with
    // std::move, while the render thread iterated them with no lock and no mutex
    // anywhere in this class. `destination` holds two std::strings, so a
    // concurrent move is a use-after-free on the string heap -- not a stale read.
    // See draw_menu_extra() for the reader side.
    struct destination_snapshot
    {
        std::string location_id;
        std::string transit_controller_name;
        std::vector<destination> exits;
        std::vector<destination> transits;
        Il2CppObject* main_player = nullptr;
    };
    std::mutex data_mutex_;
    std::shared_ptr<const destination_snapshot> snapshot_{
        std::make_shared<const destination_snapshot>() };

    // Render-thread only. These are never touched by gameworld_update; the
    // clamping that used to happen there moved to draw_menu_extra(), which is
    // the only side that can observe a change.
    std::vector<destination> visible_exits_; // filtered view for the combo
    int selected_exit_ = -1;
    int selected_transit_ = -1;
    // Switch controlling whether the Extract combo lists only currently active
    // exits (ESP parity: Available/Open) or every exit on the map.
    CheckboxValue* active_extracts_only;

    void clear();

    // The location probe is NOT declared here any more: it is
    // eft_api::read_location_id, one definition shared with EspModule,
    // RaidDashboardModule, MapModule and AiLimitModule. See that function for
    // why the union of the old copies is the careful one.

    // `exfiltration_controller` is passed in rather than resolved here because
    // collect_exit_array is handed an ARRAY and has no controller of its own; the
    // refresh happens once per update in collect_exits (EligiblePoints() builds a
    // filtered array, so calling it per exit would be quadratic for no benefit).
    static void collect_exit_array(Il2CppArray* points, std::vector<destination>& out,
        size_t base_index, Il2CppObject* exfiltration_controller);

    // `main_player` supplies the Profile that `EligiblePoints(Profile)` requires; without
    // it exfil eligibility stays `unknown` and the map selector falls back to the status
    // test rather than hiding every exit.
    static void collect_exits(Il2CppObjectInstance& game_world, Il2CppObject* main_player,
        std::vector<destination>& out);

    static void collect_transits(Il2CppObjectInstance& game_world, std::vector<destination>& out);

    static void draw_destination_combo(const char* label, const std::vector<destination>& entries, int& selected);

    void teleport(const destination& entry, const destination_snapshot& snapshot) const;

    bool is_shoreline_pier_waterfront(const std::string& name, const std::string& location) const;

    static bool is_icebreaker_name(std::string name);

    bool is_shoreline_pier_boat(std::string name, const std::string& location) const;

    void clamp_selection();
};

// Marked rooms are discovered from the loaded map's actual Door objects.  This
// avoids maintaining hard-coded coordinates and automatically keeps the list
// limited to the current map.
class MarkedRoomsModule : public Module
{
  public:
    MarkedRoomsModule();

    void draw_overlay(ImDrawList*) override;
    void application_update() override;
    void init() override;

    void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world,
        Il2CppObjectInstance main_player) override;

    void draw_menu_extra() override;

  private:
    struct room
    {
        std::string name;
        unity::vector3 position{};
    };
    // Same defect, same fix as TeleportModule above -- see the comment there.
    struct marked_rooms_snapshot
    {
        std::string location_id;
        std::vector<room> rooms;
        Il2CppObject* main_player = nullptr;
    };
    std::mutex data_mutex_;
    std::shared_ptr<const marked_rooms_snapshot> snapshot_{
        std::make_shared<const marked_rooms_snapshot>() };

    int selected_ = -1;               // render thread only
    Il2CppObject* scanned_world_ = nullptr; // game thread only (rescan trigger)

    void clear();

    // MarkedRoomsModule had its own byte-identical copy of the location probe
    // and NEVER CALLED IT -- deleted 2026-10-14 rather than forwarded. That was
    // the one part of the duplication that was pure dead weight.

    void scan_marked_rooms(const Il2CppClass* game_world_class, std::vector<room>& out);

    void teleport(unity::vector3 destination, const marked_rooms_snapshot& snapshot) const;
};
