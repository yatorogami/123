#pragma once
#include <algorithm>
#include <atomic>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include "../eft_api.h"
#include "../game_state.h"
#include "../Module.h"
#include "../ModuleCategory.h"
#include "../QueuedAction.h"
#include "../../config/ActionRowValue.h"
#include "../../config/SelectValue.h"
#include "../../config/TextboxValue.h"
#include "../../gui/menu/imgui_addons.h"
#include "../../il2cpp/exports.h"
#include "../../il2cpp/unity.h"
#include "../hideout_reflection.h"     // shared reflection memos + hideout/profile accessors
#include "../production_panel_probe.h" // Tracy zones on the station's recipe panel (read-only)

// The manual side of the hideout card. Deliberately has no dependency on
// HideoutAutomationModule: the two are laid out independently (management on the left
// column of the Profile page, automation on the right), which requires them to be
// registered in that order and to draw their own cards.
class HideoutModule : public Module
{
  public:
    // Note: area_select (SelectValue) copies option strings into its own internal storage on
    // set_options() and returns pointers into that storage from get_options() — it owns that
    // memory, not us. Do NOT delete[] anything returned by get_options() here.
    ~HideoutModule() override;

    HideoutModule();

    // Session-backed action. This one only asks the CLIENT to open its own hideout screen — it
    // touches no server state and sends nothing. It is the only session verb left here; see the
    // class-level note about why every production verb was removed.
    ActionRowValue* open_hideout;

    // Area tools. These read the hideout, so they are available only while it is open
    // (outside a raid). Pure reads: none of them sends a request to the server.
    TextboxValue* area_search;
    SelectValue* area_select;

    void draw_overlay(ImDrawList*) override;

    void prepare_menu_draw() override;

    // -----------------------------------------------------------------------
    // Card layout
    // -----------------------------------------------------------------------
    //
    // prepare_menu_draw() hides every config value from the framework's automatic pass, so the
    // draw_menu_extra() below is the whole card. The layout answers one question the old flat
    // stack did not: which of these things am I looking at?
    //
    //   SESSION  — the one action that opens the hideout at all
    //   CRAFTING — what is running RIGHT NOW, each with its own Collect/Cancel, because that is
    //              the thing a player opens this card to do
    //   NEW CRAFT— pick a recipe and start it
    //   AREAS    — the area list, a genuinely different subject that used to run straight into
    //              the recipe controls with nothing between them
    //   ADVANCED — the raw-id escape hatch, closed by default
    //
    // The ordering is deliberate: the highest-frequency, highest-consequence control is first,
    // and the three full-width buttons of the old layout ("Take / Cancel / Reset", all gated on
    // a pasted MongoID) are gone from the main path because each production row now carries its
    // own action.

    // A dim group heading with breathing room above it. ImGui::SeparatorText is too loud inside
    // a card that already has a titled header, so this is a plain muted line.
    static void group_label(const char* text);

    // Group heading with a count or a short qualifier flush right.
    static void group_label(const char* text, const std::string& right);

    void draw_menu_extra() override;

    void application_update() override;

    void application_update(Il2CppObject* application) override;

    void gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) override;

    void init() override;

  private:
    // -----------------------------------------------------------------------
    // Thread hand-off: ONE immutable snapshot, published atomically
    // -----------------------------------------------------------------------
    //
    // The game thread fills this once a second; the render thread reads it every frame. They
    // are different threads (common_hooks.h drives application_update from the game hook,
    // draw_overlay from the render path), and the payload is std::string/std::vector, so
    // handing it over by member variable is a use-after-free waiting to happen: the game thread
    // reassigns the vectors, freeing the buffer the render thread is halfway through reading.
    //
    // That is not hypothetical. For this module's whole life the reads never succeeded, so the
    // race was dormant; the moment areas and productions actually started arriving, the first
    // repopulate crashed the client. Publishing an immutable snapshot and loading a shared_ptr
    // means the render thread pins a version that can no longer be mutated — the same shape as
    // the optics pipeline's published packet.
    struct hideout_snapshot
    {
        // True while the hideout is open and its Profile is reachable.
        bool ready = false;
    // Data kept from a hideout that no longer exists. The live handles are always dropped on
    // the not-ready edges (live_hideout_, the producer list), because those are raw pointers
    // into an object the game has torn down. Everything below is OUR copy -- names, levels,
    // per-area upgrade requirements and the item totals -- and stays true after the hideout
    // closes, so the card can keep answering "what does this zone need" in a raid.
    //
    // Separate from `ready`, which means "the hideout is loaded and these numbers are live".
    // A stale snapshot is renderable but not refreshable, and the two must not be conflated:
    // keying the controls off `ready` alone is what made the card go dead and stay dead.
    bool stale = false;
        // Bumped whenever the area data changes, so the dropdown is rebuilt only when
        // something actually moved.
        size_t area_revision = 0;

        std::vector<std::string> area_names; // EAreaType display name
        std::vector<std::string> area_ids;   // EAreaType number, parallel to area_names
        std::vector<int> area_levels;        // parallel to area_names
        std::vector<bool> area_active;       // true when the player owns the area
        // AreaInfo.LastRecipe — the scheme this area is currently running, parallel to the above.
        // It is the ONLY link from a running production back to the station that owns it, which
        // is what lets a water plant's "production" be recognised as a fuel gauge rather than a
        // crafting job. Empty when the area is running nothing.
        std::vector<std::string> area_last_recipe;

        std::vector<ProductionInfo> productions;
        // Facilities that drain a resource instead of making an item — the water plant and the
        // generator. Copied out of the file-scope memo at publish time so the render thread never
        // reads a container the game thread is refilling.
        std::vector<hideout_resource> resources;
        std::vector<std::string> recipe_ids;
        // Display labels parallel to recipe_ids — a localized product name where the recipe is
        // currently running and has a Product list, otherwise the raw id.
        std::vector<std::string> recipe_labels;

        std::string status;

        // What every not-yet-maxed area needs for its NEXT level, and the same thing summed across
        // all of them. Collected on the game thread, read on the render thread, same rules as the
        // rest of this struct.
        //
        // Recomputed on the hideout-open transition and then on the slow recipe clock, NOT on the
        // 1 Hz areas clock: the requirement lists change only when the player spends materials or
        // finishes an upgrade, and walking every area's StageAt is a managed call per area. The
        // steady state is therefore a cached list, which is also what makes it cheap enough to keep
        // on the card permanently rather than behind a button.
        upgrade_plan upgrades;
    };

    // recipe id -> EAreaType, built from AreaInfo.LastRecipe.
    //
    // This is route A of the station cross-check: an area states which scheme it last ran, so a
    // running production's recipe id maps back to exactly one area and that area's Type is the
    // station. It is derived entirely from the HideoutInfo DTO, which is reachable, and it is
    // independent of BaseHideoutScheme.areaType (route B) — which is the point, since a check
    // comparing a source against itself proves nothing.
    //
    // Free function rather than a member because it is pure: it reads two parallel vectors that
    // are already built in lockstep by refresh_areas, and the index bound is re-checked here
    // rather than trusted, because a shorter vector here would otherwise read past the end.
    static std::unordered_map<std::string, int> hideout_last_recipe_to_area(
        const hideout_snapshot& snap);

    std::atomic<std::shared_ptr<const hideout_snapshot>> published_;

    // A consistent read. Holding the returned shared_ptr keeps that version alive for as long
    // as the caller uses it, even if the game thread publishes a newer one mid-frame.
    //
    // Never returns null: callers dereference the result directly (`snapshot()->field`) from
    // the render path and from the game path alike, so a null here would be a crash in code that
    // has no null check to fail. The constructor seeds an empty version, so the fallback is
    // unreachable — it exists so that "no snapshot yet" can never become a null dereference.
    [[nodiscard]] std::shared_ptr<const hideout_snapshot> snapshot() const;

    // One bool, with no reference counting. Read this instead of snapshot()->ready on any path
    // that runs per frame: snapshot() returns by value, so each use is an atomic refcount
    // increment and decrement, and two of those on the early-return path measured 471,476 ns per
    // throttled call - the entire residual cost of refresh_hideout_state after its throttle was
    // fixed. See snapshot_ready() in the .cpp for the full accounting.
    [[nodiscard]] bool snapshot_ready() const;
    // Written BEFORE the store that publishes, and never after, so this can only ever lag by one
    // publish - never lead. A stale read costs at most one redundant refresh.
    std::atomic<bool> published_ready_{false};

    // Render-thread-only. Never touched by the game thread.
    size_t built_area_revision_ = SIZE_MAX;
    std::string built_search_;
    std::vector<std::string> filtered_area_ids_;
    std::vector<std::string> built_recipe_labels_;

    // Game-thread-only.
    Il2CppObject* schemes_task_ = nullptr; // in-flight GetProductionRecipes task
    // The live hideout representation, or null when there isn't one. Doubles as the install trigger
    // for production_panel_probe: "the type exists" is true at startup, "the hideout is loaded" is
    // what we actually need. Written and read only on the game thread, so no atomics.
    Il2CppObject* live_hideout_ = nullptr;

    // The upgrade list's own cadence. Reset on the hideout-open edge so a reopen refills
    // immediately rather than showing the previous session's numbers for up to 30 s.
    ULONGLONG last_upgrades_ms_ = 0;
    // Whether the last attempt reached the HideoutRepresentation. Distinguishes "no list yet"
    // from "the chain is not reachable", which are different facts and were previously conflated
    // into an empty card section.
    bool upgrades_collected_ = false;
    ULONGLONG last_refresh_ms_ = 0;
    // Recipes deliberately do NOT share the 1 s areas clock — see refresh_hideout_state.
    ULONGLONG last_recipes_ms_ = 0;
    // Set by a recipe action, so the list is re-fetched as soon as the player has changed it
    // rather than up to kRecipesIntervalMs later.
    bool force_recipes_ = false;

    // How many passes have run since the hideout last closed. The bracketing step lines are
    // full verbosity only for the first few: that is where the crashes were (they all landed
    // during hideout load), and a truncated bracket is only useful if the passes before the
    // fault were verbose. After that, one summary line per second is the whole steady-state
    // story. Reset by publish_empty() so every reopen gets its brackets back.
    int passes_since_open_ = 0;


    // The only queued action left. It asks the client to open its own hideout screen and sends
    // nothing to the server, so it is not one of the removed production verbs.
    QueuedAction open_hideout_action_;

    // ---- data refresh ------------------------------------------------------

    // Publish an empty snapshot. Used on every "not ready" edge so the render thread cannot
    // keep showing a hideout that has closed, and so nothing has to be torn down in place.
    void publish_empty(bool retain_data = false);

    // Collect hideout state, outside a raid only.
    //
    // The Profile comes from TarkovApplication._menuOperation._profile rather than from
    // player.get_Profile(): outside a raid there is no main player, and the menu operation is
    // the only holder of a Profile there (ISIL MainMenuShowOperation.txt:438). Everything
    // downstream — Areas, Production, ProductionSchemes — hangs off that Profile's hideout.
    //
    // Nothing here mutates published state directly: a snapshot is built locally and swapped in
    // at the end, so the render thread always sees a whole, self-consistent version.
    void refresh_hideout_state(Il2CppObject* application);

    // Area trace, gated on the Debug Log module toggle. Called on transitions and (through
    // refresh_areas) once per refresh, so it must not warn — the per-area lines land here and
    // would otherwise be a wall of text a second.
    void log_areas(const std::string& message);

    void log_areas_once(const std::string& message);

    // Reflect the live area list into the pending snapshot.
    //
    // The element is EFT.AreaInfo — CONFIRMED LIVE 2026-09-27 from the debug log, which
    // dumped the real class: 27 entries, methods get_AreaType/.ctor only, and flat fields
    // Active/Type/Level/CompleteTime/Constructing/PassiveBonusesEnabled/LastRecipe/Slots.
    // There is no get_CurrentLevel, no get_Template and no get_NextStage — those belong to
    // EFT.Hideout.AreaData, which lives on the HideoutRepresentation the client builds for
    // its own UI and which Profile does not reference. An earlier revision walked the
    // AreaData shape and correctly skipped all 27 elements once a second.
    //
    // Consequences of AreaInfo being a flat DTO, all forced rather than chosen:
    //   * identity is the EAreaType number, not a template id
    //   * "maxed" is not representable — there is no NextStage to be null
    //   * upgrade Requirements are not here at all; they are template-side data the client
    //     loads from the hideout bundles, so they cannot be read from HideoutInfo
    void refresh_areas(Il2CppObject* hideout, hideout_snapshot& next);

    // Reflect HideoutInfo.Production (Dictionary<string, ProductionData>). Seven fields per
    // entry was the single most expensive walk in this module before the memo.
    //
    // The walk itself lives in hideout_read_productions so the automation module reads
    // production state through exactly the same code path. It already falls through to an
    // empty vector on every bail-out, which is what keeps a previous raid's productions from
    // lingering with a stale progress bar.
    //
    // Populate the recipe dropdown from IEftSession.GetProductionRecipes().
    //
    // This used to read a ProductionSchemes FIELD off the hideout object. The 2026-09-27 log
    // disproved that: Profile.Hideout is the EFT.HideoutInfo DTO, which has neither that field
    // nor a GetProductionRecipes method, so it logged "GetProductionRecipes not found on the
    // hideout" and the dropdown stayed empty. The method is on IEftSession (ISIL
    // EFT/IEftSession.txt:304) and returns a Task whose Result is the collection — so the list
    // arrives asynchronously and has to be polled, not read straight after the call.
    //
    // Both write into `next`, which is published once at the end of the refresh. The dropdown's
    // option buffer is filled on the RENDER thread from the snapshot, so SelectValue is never
    // touched from here.
    void refresh_recipes(Il2CppObject* session, const std::vector<ProductionInfo>& productions,
        hideout_snapshot& next);


    // ---- menu actions ------------------------------------------------------

    static Il2CppObject* get_object_field(Il2CppObject* object, const char* name);

    [[nodiscard]] bool has_pending_menu_actions() const;

    // Status line. Written from BOTH threads — the queued session actions report from the
    // game thread, the button callbacks report from the render thread — and read from the
    // render thread every frame. A bare std::string would be a data race (the assignment can
    // reallocate under the reader), so it gets its own lock. Cheap: it changes a few times a
    // second at most.
    mutable std::mutex status_mutex_;
    std::string status_;

    void set_menu_status(const std::string& status);

    [[nodiscard]] std::string current_status() const;

    void request_open_hideout();


    // A recipe's display name, or a short id when the label never resolved. Kept because the
    // production rows still name themselves with it (see draw_menu_extra) and because the recipe
    // count in the Hideout Improvements card is meaningless without the labels behind it.
    //
    // Purely a READ of the published snapshot. The selected_recipe_id() / request_start_crafting
    // pair that used to sit above this went with the production verbs.
    // "Scav case" when the label resolved, else a short id. Status lines name the thing in
    // words because "Queued for 5d5589c1" is not something anyone can act on.
    [[nodiscard]] std::string describe_recipe(const std::string& id) const;

    void discard_menu_actions(const std::string& reason);

    void open_hideout_at_main_point(Il2CppObject* menu_operation);
};
