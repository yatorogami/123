#pragma once

#include "../Module.h"
#include "../ModuleCategory.h"
#include "../../config/CheckboxValue.h"
#include "../../config/ColorpickerValue.h"
#include "../../config/CompactTextboxValue.h"
#include "../../config/FloatSliderEditableValue.h"
#include "../../config/IntSliderEditableValue.h"
#include "../../config/MenuSectionValue.h"
#include "../../config/SelectValue.h"

class MinimapModule;

inline MinimapModule* minimap_module_self = nullptr;

class MinimapModule : Module
{
  public:
    MinimapModule();

    MenuSectionValue* section_general_;
    CheckboxValue* radar;
    CheckboxValue* radar_exfils;
    CheckboxValue* radar_minimap_quest_esp;
    CheckboxValue* radar_minimap_quest_names;
    CheckboxValue* radar_minimap_bots;
    CheckboxValue* radar_minimap_bot_names;
    CheckboxValue* radar_minimap_bot_corpses;
    ColorpickerValue* radar_minimap_bot_corpse_color;

    MenuSectionValue* section_map_;
    CheckboxValue* radar_minimap;
    SelectValue* radar_minimap_style;
    CheckboxValue* radar_minimap_rotate;
    CheckboxValue* radar_minimap_grid;
    FloatSliderEditableValue* radar_minimap_grid_opacity;
    CheckboxValue* radar_minimap_compass;
    CheckboxValue* radar_minimap_backdrop;
    ColorpickerValue* radar_minimap_backdrop_color;
    FloatSliderEditableValue* radar_minimap_opacity;
    CheckboxValue* radar_minimap_static_markers;
    CheckboxValue* radar_minimap_labels;

    MenuSectionValue* section_layout_;
    SelectValue* radar_minimap_corner;
    FloatSliderEditableValue* radar_size;
    FloatSliderEditableValue* radar_range;
    FloatSliderEditableValue* radar_margin_x;
    FloatSliderEditableValue* radar_margin_y;

    MenuSectionValue* section_text_;
    IntSliderEditableValue* minimap_text_font_size;
    CheckboxValue* minimap_marker_outline;

    MenuSectionValue* section_symbols_;
    CompactTextboxValue* minimap_sym_player;
    IntSliderEditableValue* minimap_sym_player_size;
    CompactTextboxValue* minimap_sym_entity;
    IntSliderEditableValue* minimap_sym_entity_size;
    CompactTextboxValue* minimap_sym_quest;
    IntSliderEditableValue* minimap_sym_quest_size;
    CompactTextboxValue* minimap_sym_exfil;
    IntSliderEditableValue* minimap_sym_exfil_size;
    CompactTextboxValue* minimap_sym_transit;
    IntSliderEditableValue* minimap_sym_transit_size;
    CompactTextboxValue* minimap_sym_height_up;
    IntSliderEditableValue* minimap_sym_height_up_size;
    CompactTextboxValue* minimap_sym_height_down;
    IntSliderEditableValue* minimap_sym_height_down_size;

    void init() override;

    [[nodiscard]] bool is_active() const override { return radar->get_value(); }

    void prepare_menu_draw() override;

    void draw_overlay(ImDrawList* /*draw_list*/) override;

    void application_update() override;

    void gameworld_update(const Il2CppClass* /*game_world_class*/, Il2CppObjectInstance /*game_world_instance*/,
        Il2CppObjectInstance /*main_player*/) override;
};