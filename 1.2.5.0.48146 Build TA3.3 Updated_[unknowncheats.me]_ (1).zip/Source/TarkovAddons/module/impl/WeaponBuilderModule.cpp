#include "common.h"
#include "WeaponBuilderModule.h"

WeaponBuilderModule::WeaponBuilderModule(InventoryEditorModule* editor) : Module("Weapon Builder", WeaponBuilder, "weapon_builder_mod"), editor_(editor),
                                                                          enchantment_percent(conf(
                                                                              new FloatSliderEditableValue(1.f, 1.f, 100.f, "weapon_builder_enchantment_percent_txt"))),
                                                                          threshold_amount(conf(
                                                                              new FloatSliderEditableValue(1.f, 1.f, 100.f, "weapon_builder_enchantment_threshold_txt"))),
                                                                          selected_item_(conf(new ItemSearchValue("weapon_builder_item_search_txt",
                                                                              nullptr, /*hide_quest_items=*/true))) {
    // The search control is positioned manually between slot selection and
    // installation, so prevent the generic card renderer drawing a second copy.
    selected_item_->set_hidden_in_owner_menu(true);
    // Same for the two enchantment sliders: they are drawn by hand in the
    // Enchantment section, not by the generic renderer. Only drawing is gated —
    // ConfigModule walks every config value for save/load/reset regardless, so
    // these still persist like any other setting.
    enchantment_percent->set_hidden_in_owner_menu(true);
    threshold_amount->set_hidden_in_owner_menu(true);
}

void WeaponBuilderModule::draw_overlay(ImDrawList*) {}

void WeaponBuilderModule::application_update() {}

void WeaponBuilderModule::init() {}

void WeaponBuilderModule::draw_menu_extra() {
    const bool in_raid = game_state::is_in_raid;
    if (!in_raid)
        imgui_addons::status_line("Enter a raid before refreshing backpack weapons.");

    if (ImGui::Button("Refresh Backpack Weapons", ImVec2(-1.f, 0.f)) && in_raid)
        refresh_action_.request(in_raid);

    const char* weapon_preview = "No weapon selected";
    if (has_selected_weapon())
        weapon_preview = weapons_[selected_weapon_].label.c_str();
    ImGui::BeginDisabled(!in_raid || weapons_.empty());
    ImGui::TextUnformatted("Backpack Weapon");
    ImGui::SetNextItemWidth(-1.f);
    if (ImGui::BeginCombo("##weapon_builder_weapon", weapon_preview))
    {
        for (int i = 0; i < static_cast<int>(weapons_.size()); ++i)
        {
            const bool selected = selected_weapon_ == i;
            if (ImGui::Selectable(weapons_[i].label.c_str(), selected))
            {
                selected_weapon_ = i;
                slots_.clear();
                selected_slot_ = -1;
            }
            if (selected) ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }

    if (ImGui::Button("Inspect Weapon Slots", ImVec2(-1.f, 0.f)) && has_selected_weapon())
        inspect_action_.request(in_raid);

    const char* slot_preview = "No slot selected";
    if (has_selected_slot())
        slot_preview = slots_[selected_slot_].label.c_str();
    ImGui::TextUnformatted("Weapon Mod Slot");
    ImGui::SetNextItemWidth(-1.f);
    if (ImGui::BeginCombo("##weapon_builder_slot", slot_preview))
    {
        for (int i = 0; i < static_cast<int>(slots_.size()); ++i)
        {
            const bool selected = selected_slot_ == i;
            if (ImGui::Selectable(slots_[i].label.c_str(), selected))
                selected_slot_ = i;
            if (selected) ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }

    selected_item_->draw();
    const bool ready = has_selected_slot() && !selected_item_->get_selected_id().empty();
    if (ImGui::Button("Install Selected Item Into Slot", ImVec2(-1.f, 0.f)) && ready)
        install_action_.request(in_raid);
    ImGui::EndDisabled();

    if (!status_.empty())
        imgui_addons::status_line(status_, true);

    ImGui::SeparatorText("Enchantment");
    ImGui::SetNextItemWidth(-1.f);
    ImGui::Combo("Enchantment Type", &enchantment_type_selection_, enchantments_, IM_ARRAYSIZE(enchantments_));
    ImGui::SetNextItemWidth(-1.f);
    ImGui::Combo("Enchantment Rarity", &enchantment_rarity_, rarities_, IM_ARRAYSIZE(rarities_));
    enchantment_percent->draw();
    threshold_amount->draw();
    if (ImGui::Button("Apply Enchantment to Selected Weapon", ImVec2(-1.f, 0.f)))
    {
        if (!editor_)
            enchantment_result_ = {"The Item Editor is unavailable.", false};
        else if (!has_selected_weapon())
            enchantment_result_ = {"Select a backpack weapon first.", false};
        else
            editor_->queue_weapon_enchantment_by_id(weapons_[selected_weapon_].id,
                enchantment_type_values_[enchantment_type_selection_], enchantment_rarity_,
                enchantment_percent->get_value(), threshold_amount->get_value());
    }
    if (ImGui::Button("Restore Weapon Durability", ImVec2(-1.f, 0.f)))
    {
        if (!editor_)
            durability_result_ = {"The Item Editor is unavailable.", false};
        else if (!has_selected_weapon())
            durability_result_ = {"Select a backpack weapon first.", false};
        else
            editor_->queue_weapon_durability_restore_by_id(weapons_[selected_weapon_].id);
    }

    // Each action gets its own line, so a success is never mistaken for the
    // other action's result. success drives the highlight colour; the text
    // carries the detail.
    if (!enchantment_result_.message.empty())
        imgui_addons::status_line(enchantment_result_.message, enchantment_result_.success);
    if (!durability_result_.message.empty())
        imgui_addons::status_line(durability_result_.message, durability_result_.success);
}

void WeaponBuilderModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance main_player) {
    // Zoned 2026-10-12. Four regions, because the shape here is four INDEPENDENT
    // actions and only one of them runs every tick:
    //
    //   pull_editor_results      every world update
    //   refresh_weapons          .take(), so once per request
    //   inspect_slots            .take(), once per request
    //   install_selected_item    .take(), once per request
    //
    // One zone over the body would report a mean dominated by whichever of the four
    // happened to be expensive, and would average the per-tick call in with three
    // that almost never run. That is the fireport_resolve lesson (1.44 us/call
    // against 37,343 us/call, one mean, two populations) applied to a function where
    // the split is already visible in the source.
    if (!game_state::is_in_raid)
    {
        clear_queues();
        {
            TA_ZONE_N("weapon_builder::pull_editor_results");
            pull_editor_results();
        }
        return;
    }
    {
        TA_ZONE_N("weapon_builder::pull_editor_results");
        pull_editor_results();
    }
    if (refresh_action_.take(game_state::is_in_raid))
    {
        TA_ZONE_N("weapon_builder::refresh_weapons");
        refresh_weapons(main_player);
    }
    if (inspect_action_.take(game_state::is_in_raid))
    {
        TA_ZONE_N("weapon_builder::inspect_slots");
        inspect_slots(main_player);
    }
    if (install_action_.take(game_state::is_in_raid))
    {
        TA_ZONE_N("weapon_builder::install_selected_item");
        install_selected_item(main_player);
    }
}

bool WeaponBuilderModule::has_selected_weapon() const {
    return selected_weapon_ >= 0 && selected_weapon_ < static_cast<int>(weapons_.size());
}

bool WeaponBuilderModule::has_selected_slot() const {
    return selected_slot_ >= 0 && selected_slot_ < static_cast<int>(slots_.size());
}

void WeaponBuilderModule::pull_editor_results() {
    if (!editor_) return;
    const InventoryEditorModule::external_result& result = editor_->last_external_result();
    if (result.serial == last_external_serial_) return;
    last_external_serial_ = result.serial;

    // "idle" means the raid ended before the request could resolve. It is not
    // attributed to either action, so clear both rather than leave one of them
    // claiming a result that never happened.
    if (result.status == InventoryEditorModule::external_status::idle)
    {
        enchantment_result_ = {};
        durability_result_ = {};
        return;
    }
    action_result* target = result.action == InventoryEditorModule::external_action::durability
        ? &durability_result_
        : &enchantment_result_;
    *target = {result.message,
        result.status == InventoryEditorModule::external_status::success};
}

std::string WeaponBuilderModule::call_string(Il2CppObject* object, const char* method) {
    if (!eft_api::is_il2cpp_object_likely_valid(object)) return {};
    Il2CppObjectInstance instance(object);
    const auto call = instance.get_method<Il2CppString* (*)(Il2CppObject*)>(method, 0, false, false);
    Il2CppString* value = call ? call(object) : nullptr;
    return value ? il2utils::conv_string(value) : std::string{};
}

std::string WeaponBuilderModule::item_id(Il2CppObject* item) { return call_string(item, "get_Id"); }

std::string WeaponBuilderModule::template_id(Il2CppObject* item) { return call_string(item, "get_StringTemplateId"); }

bool WeaponBuilderModule::is_weapon(Il2CppObject* item) {
    for (const Il2CppClass* type = item ? item->klass : nullptr; type; type = type->parent)
        if (type->name && std::string(type->name) == "Weapon") return true;
    return false;
}

std::string WeaponBuilderModule::database_name(const std::string& id) {
    return game_items::name_by_id(id);
}

Il2CppObject* WeaponBuilderModule::find_tree_item(Il2CppObject* item, const std::string& wanted, int depth) {
    if (!eft_api::is_il2cpp_object_likely_valid(item) || depth > 5) return nullptr;
    if (item_id(item) == wanted) return item;
    if (Il2CppArray* slots = eft_api::try_get_array_field(item, "Slots"))
    {
        for (size_t i = 0; i < (std::min)(slots->max_length, static_cast<size_t>(32)); ++i)
        {
            Il2CppObject* slot = reinterpret_cast<Il2CppObject**>(&slots->data)[i];
            Il2CppObject* child = eft_api::try_get_backing_field_object(
                slot, "<ContainedItem>k__BackingField", "ContainedItem");
            if (Il2CppObject* found = find_tree_item(child, wanted, depth + 1)) return found;
        }
    }
    if (Il2CppArray* grids = eft_api::try_get_array_field(item, "Grids"))
    {
        for (size_t i = 0; i < (std::min)(grids->max_length, static_cast<size_t>(16)); ++i)
        {
            Il2CppObject* grid = reinterpret_cast<Il2CppObject**>(&grids->data)[i];
            Il2CppObject* collection = eft_api::try_get_backing_field_object(
                grid, "<ItemCollection>k__BackingField", "ItemCollection");
            std::vector<Il2CppObject*> children;
            eft_api::append_list_items(collection ? eft_api::try_get_field_object(collection, "ItemsList") : nullptr,
                children, 128);
            for (Il2CppObject* child : children)
                if (Il2CppObject* found = find_tree_item(child, wanted, depth + 1)) return found;
        }
    }
    return nullptr;
}

Il2CppObject* WeaponBuilderModule::find_backpack_item(Il2CppObjectInstance player, const std::string& wanted) {
    Il2CppObject* controller = eft_api::try_get_field_object(player.get_instance(), "_inventoryController");
    Il2CppObjectInstance controller_instance(controller);
    const auto get_inventory = controller_instance.get_method<Il2CppObject* (*)(Il2CppObject*)>(
        "get_Inventory", 0, false, false);
    Il2CppObject* inventory = get_inventory ? get_inventory(controller) : nullptr;
    Il2CppObject* equipment = eft_api::try_get_field_object(inventory, "Equipment");
    Il2CppObjectInstance equipment_instance(equipment);
    const auto get_slot = equipment_instance.get_method<Il2CppObject* (*)(Il2CppObject*, int)>(
        "GetSlot", 1, false, false);
    Il2CppObject* backpack_slot = get_slot ? get_slot(equipment, 4) : nullptr;
    Il2CppObject* backpack = eft_api::try_get_backing_field_object(
        backpack_slot, "<ContainedItem>k__BackingField", "ContainedItem");
    return find_tree_item(backpack, wanted);
}

void WeaponBuilderModule::refresh_weapons(Il2CppObjectInstance player) {
    weapons_.clear();
    slots_.clear();
    selected_weapon_ = selected_slot_ = -1;
    Il2CppObject* controller = eft_api::try_get_field_object(player.get_instance(), "_inventoryController");
    Il2CppObjectInstance controller_instance(controller);
    const auto get_inventory = controller_instance.get_method<Il2CppObject* (*)(Il2CppObject*)>(
        "get_Inventory", 0, false, false);
    Il2CppObject* inventory = get_inventory ? get_inventory(controller) : nullptr;
    Il2CppObject* equipment = eft_api::try_get_field_object(inventory, "Equipment");
    Il2CppObjectInstance equipment_instance(equipment);
    const auto get_slot = equipment_instance.get_method<Il2CppObject* (*)(Il2CppObject*, int)>(
        "GetSlot", 1, false, false);
    Il2CppObject* backpack_slot = get_slot ? get_slot(equipment, 4) : nullptr;
    Il2CppObject* backpack = eft_api::try_get_backing_field_object(
        backpack_slot, "<ContainedItem>k__BackingField", "ContainedItem");
    if (!backpack)
    {
        status_ = "No backpack was found.";
        return;
    }
    std::vector<Il2CppObject*> items{backpack};
    eft_api::collect_compound_items_recursive(backpack, items);
    for (Il2CppObject* item : items)
    {
        if (!is_weapon(item)) continue;
        const std::string id = item_id(item);
        if (id.empty()) continue;
        std::string name = database_name(template_id(item));
        if (name.empty()) name = call_string(item, "get_Name");
        weapons_.push_back({id, name.empty() ? "Weapon" : name});
    }
    status_ = "Found " + std::to_string(weapons_.size()) + " backpack weapon(s).";
}

void WeaponBuilderModule::inspect_slots(Il2CppObjectInstance player) {
    slots_.clear();
    selected_slot_ = -1;
    // Bounds must be checked at CONSUME time, not only when the request was
    // made: gameworld_update runs refresh -> inspect -> install in one pass,
    // and refresh_weapons() clears weapons_ and resets selected_weapon_ to -1.
    // Two queued clicks in the same frame therefore used to index
    // weapons_[-1] here.
    if (!has_selected_weapon())
    {
        status_ = "No weapon selected.";
        return;
    }
    Il2CppObject* weapon = find_backpack_item(player, weapons_[selected_weapon_].id);
    if (!is_weapon(weapon))
    {
        status_ = "Selected weapon is no longer in the backpack.";
        return;
    }
    Il2CppArray* slots = eft_api::try_get_array_field(weapon, "Slots");
    if (!slots)
    {
        status_ = "No mod slots were found on this weapon.";
        return;
    }
    for (size_t i = 0; i < (std::min)(slots->max_length, static_cast<size_t>(32)); ++i)
    {
        Il2CppObject* slot = reinterpret_cast<Il2CppObject**>(&slots->data)[i];
        if (!eft_api::is_il2cpp_object_likely_valid(slot)) continue;
        const std::string id = call_string(slot, "get_ID");
        if (id.empty()) continue;
        std::string label = call_string(slot, "get_Name");
        if (label.empty()) label = id;
        Il2CppObject* current = eft_api::try_get_backing_field_object(
            slot, "<ContainedItem>k__BackingField", "ContainedItem");
        if (current)
        {
            std::string current_name = database_name(template_id(current));
            if (current_name.empty()) current_name = call_string(current, "get_Name");
            if (!current_name.empty()) label += ": " + current_name;
        }
        else
            label += ": Empty";
        slots_.push_back({id, label});
    }
    status_ = slots_.empty() ? "No mod slots were found on this weapon."
                             : "Select a weapon slot, then search an item to install.";
}

void WeaponBuilderModule::install_selected_item(Il2CppObjectInstance player) {
    if (!game_state::item_factory)
    {
        status_ = "Item factory is not ready yet.";
        return;
    }
    // Same consume-time bounds requirement as inspect_slots: install is the
    // third action in the same pass, so refresh may have invalidated the
    // selection and the slot list may be stale or empty.
    if (!has_selected_weapon() || !has_selected_slot())
    {
        status_ = "Select a weapon slot first.";
        return;
    }
    Il2CppObject* weapon = find_backpack_item(player, weapons_[selected_weapon_].id);
    Il2CppArray* slots = eft_api::try_get_array_field(weapon, "Slots");
    if (!slots)
    {
        status_ = "Weapon slots could not be resolved.";
        return;
    }
    Il2CppObject* target_slot = nullptr;
    for (size_t i = 0; i < slots->max_length; ++i)
    {
        Il2CppObject* slot = reinterpret_cast<Il2CppObject**>(&slots->data)[i];
        if (call_string(slot, "get_ID") == slots_[selected_slot_].id)
        {
            target_slot = slot;
            break;
        }
    }
    if (!target_slot)
    {
        status_ = "Selected slot is no longer available.";
        return;
    }
    Il2CppObjectInstance factory(game_state::item_factory);
    const auto get_preset = factory.get_method<Il2CppObject* (*)(Il2CppObject*, Il2CppString*)>(
        "GetPresetItem", 1, false, false);
    Il2CppObject* new_item = get_preset ? get_preset(game_state::item_factory,
                                              il2cpp::il2cpp_string_new(selected_item_->get_selected_id().c_str()))
                                        : nullptr;
    if (!new_item)
    {
        status_ = "The selected item could not be created.";
        return;
    }
    Il2CppObjectInstance slot_instance(target_slot);
    const auto install = slot_instance.get_method<void (*)(Il2CppObject*, Il2CppObject*)>(
        "ChangeContainedItemDirectly", 1, false, false);
    if (!install)
    {
        status_ = "This slot does not support direct installation.";
        return;
    }
    install(target_slot, new_item);
    status_ = "Item installed into selected weapon slot.";
    inspect_slots(player);
}

void WeaponBuilderModule::clear_queues() {
    refresh_action_.clear();
    inspect_action_.clear();
    install_action_.clear();
}
