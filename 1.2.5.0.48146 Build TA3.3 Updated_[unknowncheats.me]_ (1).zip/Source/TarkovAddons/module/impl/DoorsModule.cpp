#include "common.h"
#include "DoorsModule.h"

DoorsModule::DoorsModule() : Module("Door Unlocker", Exploit, "door_unlocker_mod"),
                             section_doors_(conf(new MenuSectionValue("doors_sec"))),
                             unlock_doors(conf(new ActionRowValue([this] { unlock_doors_impl(); }, "unlock_doors_btn"))),
                             always_breach_door(conf(new CheckboxValue(false, "always_breach_door_cb"))),
                             bypass_interaction_check(conf(new CheckboxValue(false, "bypass_interaction_check_cb"))),
                             unlock_ray_range(conf(new FloatSliderEditableValue(20.f, 3.f, 50.f, "interaction_probe_range_itm"))) {}

void DoorsModule::application_update() {
    TA_ZONE_N("doors::application_update");
    combat_feel::always_breach_ui = always_breach_door->get_value();
    apply_interaction_unlock();
}

void DoorsModule::gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance,
    Il2CppObjectInstance) {
    TA_ZONE_N("doors::gameworld_update");
    if (!unlock_doors_action_.take(game_state::is_in_raid)) return;

    Il2CppObject* door_type = il2utils::get_system_type(game_world_class->image, "EFT.Interactive", "Door");
    size_t count = 0;
    Il2CppObject** doors = unity::find_objects_of_type(door_type, &count);
    for (size_t i = 0; i < count; ++i)
    {
        Il2CppObjectInstance door(doors[i]);
        const auto set_state = door.get_method<void (*)(Il2CppObject*, int)>("set_DoorState", 1);
        if (set_state) set_state(door.get_instance(), 2);
    }
    logger::debug("Unlocked Doors");
}

void DoorsModule::draw_overlay(ImDrawList*) {}

void DoorsModule::init() {}

void DoorsModule::unlock_doors_impl() {
    unlock_doors_action_.request(game_state::is_in_raid);
}

void DoorsModule::apply_interaction_unlock() {
    if (!bypass_interaction_check->get_value() || !game_state::is_in_raid)
        return;

    ULONGLONG now = GetTickCount64();
    if (now - g_last_unlock_ray_ms < 150) return;
    g_last_unlock_ray_ms = now;

    // Force-init skeleton_vis on demand so this works without ESP.
    if (!skeleton_vis::is_ready())
        return;

    Il2CppObject* cam = unity::get_current_camera();
    if (!cam) return;
    Il2CppObject* cam_go = unity::component_get_game_object(cam);
    if (!cam_go) return;
    Il2CppObject* cam_tr = unity::gameobject_get_transform(cam_go);
    if (!cam_tr) return;

    unity::vector3 cam_pos = unity::transform_get_pos(cam_tr);
    unity::vector3 fwd{};
    {
        Il2CppObjectInstance tr(cam_tr);
        const auto get_fwd = tr.get_method<unity::vector3 (*)(Il2CppObject*)>("get_forward", 0, false);
        if (!get_fwd) return;
        fwd = get_fwd(cam_tr);
    }

    const float range = unlock_ray_range->get_value();
    const unity::vector3 end{
        cam_pos.x + fwd.x * range,
        cam_pos.y + fwd.y * range,
        cam_pos.z + fwd.z * range};

    skeleton_vis::raycast_hit hit{};
    if (!skeleton_vis::g_linecast(cam_pos, end, skeleton_vis::try_get_occlusion_layer_mask(),
            skeleton_vis::query_ignore_triggers, &hit))
        return;
    if (hit.m_distance < 0.1f || hit.m_normal.length() < 0.1f)
        return;

    Il2CppObject* hit_tr = skeleton_vis::g_hit_get_transform(&hit);
    if (!hit_tr) return;
    Il2CppObject* go = unity::component_get_game_object(hit_tr);
    if (!go) return;
    std::string go_name = unity::get_name(go);

    static Il2CppObject* s_wio_type = nullptr;
    if (!s_wio_type)
    {
        const Il2CppImage* img = il2utils::resolve_image("Assembly-CSharp.dll");
        if (!img) return;
        s_wio_type = il2utils::get_system_type(img, "EFT.Interactive", "WorldInteractiveObject");
    }
    if (!s_wio_type) return;

    // Hit GO + up to two ancestors (interactables are often parented under
    // their interactive root).
    Il2CppObject* wio = nullptr;
    Il2CppObject* cur_go = go;
    for (int depth = 0; depth < 3 && cur_go; ++depth)
    {
        wio = unity::gameobject_get_component(cur_go, s_wio_type);
        if (wio) break;
        Il2CppObject* tr = unity::gameobject_get_transform(cur_go);
        if (!tr) break;
        cur_go = unity::transform_get_parent(tr);
        cur_go = cur_go ? unity::component_get_game_object(cur_go) : nullptr;
    }
    if (!wio) return;

    int state = -1;
    {
        Il2CppObjectInstance wio_inst(wio);
        if (const auto get_state = wio_inst.get_method<int (*)(Il2CppObject*)>("get_DoorState", 0))
            state = get_state(wio);
    }
    if (state != 1) return; // only Locked(1) — leave Closed/Open/busy alone

    // Subclasses (Door, LootableContainer, ...) override set_DoorState —
    // resolving via the instance class covers it.
    Il2CppObjectInstance wio_inst(wio);
    if (const auto set_state = wio_inst.get_method<void (*)(Il2CppObject*, int)>("set_DoorState", 1))
    {
        set_state(wio, 2);
        logger::debug(std::format(
            "Door Unlocker L2b: unlocked '{}' (Locked -> Closed)", go_name));
    }
}
