#pragma once

#include <algorithm>
#include <format>
#include <string>
#include <vector>
#include <Windows.h>

#include "../eft_api.h"
#include "../game_item_db.h"
#include "../game_state.h"
#include "../Module.h"
#include "../ModuleCategory.h"
#include "../../config/CheckboxValue.h"
#include "../../config/FloatSliderEditableValue.h"
#include "../../il2cpp/Il2CppObjectInstance.h"
#include "../../gui/menu/imgui_addons.h"
#include "../../util/logger.h"

// Tarkov 1.1.0.1.46699 Item Editor.
// The item picker is refreshed only on request and stores item-instance IDs,
// never live object pointers.  This avoids using stale pointers after items are
// moved in the inventory UI.
class InventoryEditorModule : public Module
{
  public:
    InventoryEditorModule();


    // Enchantment percentage and durability threshold, 1-100.
    //
    // Float, not int: BuffComponent stores BOTH as System.Double
    // (ISIL BuffComponent.get_Value -> `this._value (System.Double)` at +0x20, and
    // get_ThresholdDurability -> `_thresholdDurability` at +0x28, both set through
    // set_Value/set_ThresholdDurability which take a Double). An int widget would
    // round away the fractional part the game actually keeps, and the two are not
    // interchangeable: the value is a multiplier, so 1-100 maps onto 0.99..0.0.
    //
    // Upper bound 100 is the in-game ceiling (the modifier is displayed as
    // (1 - Value) * 100, so 0% .. 100% is the whole legal range).
    //
    // Drawn manually inside the Enchantment section below rather than by the generic
    // card renderer, so the pair stays between the type/rarity combos and the apply
    // button where it was. The constructor sets hidden_in_owner_menu to match.
    FloatSliderEditableValue* enchantment_percent;
    FloatSliderEditableValue* threshold_amount;

    void draw_menu_extra() override;

    void application_update() override;
    void draw_overlay(ImDrawList*) override;
    void init() override;

    // ---- outcome reporting for the Weapon Builder card ------------------------
    //
    // The two queue_*_by_id entry points below are called from the Weapon
    // Builder's UI thread, but the work happens HERE, in gameworld_update, on the
    // game thread. The caller therefore cannot learn anything from the call
    // itself: it knows the request was accepted, never what became of it. Without
    // a result published back, that card showed no feedback at all and the only
    // confirmation landed on the Item Editor's status line, a different card.
    enum class external_status { idle,
        pending,
        success,
        failure };
    // Which of the two entry points a result belongs to. Carried explicitly so a
    // consumer can route it to the right label instead of inferring it from the
    // message text.
    enum class external_action { none,
        enchantment,
        durability };

    struct external_result
    {
        external_status status = external_status::idle;
        external_action action = external_action::none;
        std::string message;
        // Bumped on every publish so a consumer can spot a NEW result by comparing
        // integers, instead of diffing message text (and so a repeat of an
        // identical message still refreshes the consumer).
        unsigned long long serial = 0;
    };

    // Read on the game thread by whoever issued the request; see
    // WeaponBuilderModule::pull_editor_results.
    const external_result& last_external_result() const;

    // Percentages arrive from the Weapon Builder's own sliders. They are applied to
    // the shared values below, which are the ones apply_enchantment reads, so a
    // request from either card ends up clamped identically. The clamp is kept here
    // as well as in the widgets because a saved config can carry any value: the
    // sliders bound what the user types, not what a config file can contain.
    void queue_weapon_enchantment_by_id(const std::string& id, int type, int rarity,
        float enchantmentPercentage, float thresholdAmount);

    void queue_weapon_durability_restore_by_id(const std::string& id);

    void gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance main_player) override;

  private:
    struct inventory_item
    {
        std::string instance_id;
        std::string label;
    };

    struct gear_component
    {
        std::string instance_id;
        std::string label;
    };

    // ERepairBuffType.DamageReduction — the only type that both has a modifier field
    // in BuffComponent and an EItemAttributeId, and therefore the only one this card
    // can apply. The type is fixed rather than selectable; see draw_menu_extra and
    // BUFFCOMPONENT_NOTES.md.
    static constexpr int k_gear_enchantment_type = 1;

    std::vector<inventory_item> items_;
    int selected_index_ = -1;
    // Set per action: k_gear_enchantment_type for this card's own enchantment, or the
    // type supplied by an external Weapon Builder request. Not a persistent setting,
    // which is why the removed type combo no longer assigns it every frame.
    int enchantment_type_ = 0;
    int enchantment_rarity_ = 0;
    // The live values the enchantment is actually applied with, in percent. These
    // are separate from the FloatSliderEditableValue widgets above because an
    // external request (Weapon Builder) can overwrite them for one action, and the
    // sliders must keep showing what the user picked.
    float enchantment_percent_ = 1.f;
    float threshold_amount_ = 1.f;
    int key_uses_ = 1;
    bool queue_refresh_ = false;
    bool queue_inspect_gear_ = false;
    bool queue_restore_durability_ = false;
    bool queue_restore_durability_tree_ = false;
    bool queue_key_uses_ = false;
    std::vector<gear_component> gear_components_;
    std::string queue_enchantment_component_id_;
    std::string external_weapon_id_;
    std::string external_weapon_durability_id_;
    std::string enchantment_status_;
    std::string durability_status_;
    external_result external_result_;

    // Why an external request could not be applied. "Changed nothing" is three
    // different situations and the caller has to be able to tell them apart, so the
    // lookup is split from the action instead of collapsing to a single bool.
    enum class external_target { missing,
        not_a_weapon,
        ready };

    static external_target resolve_external_weapon(Il2CppObjectInstance main_player,
        const std::string& target_id, Il2CppObject*& out_item);

    void publish_external(const external_status status, const external_action action,
        std::string message);

    // Copy the slider values into the live fields apply_enchantment reads. Called on
    // the game thread immediately before an enchantment, never per frame: the widgets
    // are drawn on the UI thread, so reading them here is also the narrowest window in
    // which they can be sampled. Clamped again because a config file can hold any
    // value — FloatSliderEditableValue::set does not bound what it loads.
    void sync_enchantment_inputs();

    // Trims the trailing zeros a float would otherwise print ("25.000000"), so the
    // status line reads like the slider does.
    static std::string percent_text(const float value);

    [[nodiscard]] bool has_selected_item() const;

    void clear_queues();

    static std::string call_string_method(Il2CppObject* object, const char* method);

    // 46699 metadata: Item.get_TemplateId returns MongoID, while
    // Item.get_StringTemplateId returns the IL2CPP string we need here.
    static std::string get_item_id(Il2CppObject* item);
    static std::string get_item_name(Il2CppObject* item);
    static std::string get_template_id(Il2CppObject* item);

    static std::string get_localized_item_name(Il2CppObject* item);

    static std::string get_database_item_name(const std::string& template_id);

    static bool set_signed_int_field(Il2CppObject* object, const char* field_name, int value);

    static bool set_float_field(Il2CppObject* object, const char* field_name, float value);

    static int restore_durability(Il2CppObject* item);

    int apply_enchantment(Il2CppObject* item) const;

    static bool set_object_field(Il2CppObject* object, const char* field_name, Il2CppObject* value);

    static Il2CppObject* create_and_attach_buff(Il2CppObject* item);

    // The dump exposes Buff only on Weapon/Vest/ArmoredEquipment or through
    // ArmorComponent. This guard prevents the batch action from adding buffs
    // to ordinary backpack contents such as ammo, food, and loose barter loot.
    static bool can_hold_buff(Il2CppObject* item);

    static bool is_weapon(Il2CppObject* item);

    static Il2CppObject* find_existing_buff(Il2CppObject* item);

    static int apply_key_uses(Il2CppObject* item, int uses);

    static int set_remaining_key_uses(Il2CppObject* key_component, int requested_remaining);

    void refresh_backpack_items(Il2CppObjectInstance main_player);

    static void collect_selected_gear_and_plates(Il2CppObject* gear, std::vector<Il2CppObject*>& out,
        const int depth = 0);

    static std::string get_component_display_name(Il2CppObject* item);

    static std::string get_slot_display_name(Il2CppObject* slot);

    static bool is_plate_slot(std::string name);

    static void collect_gear_enchantment_components(Il2CppObject* gear, std::vector<gear_component>& out);

    static Il2CppObject* find_item_in_tree(Il2CppObject* item, const std::string& wanted_id, const int depth = 0);

    static Il2CppObject* find_inventory_item(Il2CppObjectInstance main_player, const std::string& wanted_id);

    static void collect_backpack_items(Il2CppObjectInstance main_player, std::vector<Il2CppObject*>& out);
};
