#include "common.h"
#include "TeleportModule.h"

// Keep the internal name stable: menu navigation uses it to detect the
// Teleport sidebar. The display key controls only the visible card title.
TeleportModule::TeleportModule() : Module("Map Selector", Teleport, "map_selector_mod"),
                                   active_extracts_only(conf(new CheckboxValue(false, "active_extracts_only_cb"))) {}

void TeleportModule::draw_overlay(ImDrawList*) {}

void TeleportModule::application_update() {}

void TeleportModule::init() {}

void TeleportModule::gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world,
    Il2CppObjectInstance main_player) {
    if (!game_state::is_in_raid)
    {
        clear();
        return;
    }
    Il2CppObject* transit_controller = game_world.get_field<Il2CppObject*>("<TransitController>k__BackingField");

    auto next = std::make_shared<destination_snapshot>();
    next->main_player = main_player.get_instance();
    next->location_id = eft_api::read_location_id(game_world_class, game_world);
    next->transit_controller_name =
        (transit_controller && transit_controller->klass && transit_controller->klass->name)
        ? transit_controller->klass->name
        : "Not available";
    collect_exits(game_world, main_player.get_instance(), next->exits);
    collect_transits(game_world, next->transits);

    // One pointer swap under the lock. The render thread keeps whatever snapshot
    // it already holds alive until it is finished drawing with it.
    std::lock_guard<std::mutex> lock(data_mutex_);
    snapshot_ = std::move(next);
}

void TeleportModule::draw_menu_extra() {
    // One shared_ptr copy pins the whole snapshot -- exits, transits, strings and
    // the player pointer -- for the rest of this draw, with no lock held.
    std::shared_ptr<const destination_snapshot> snapshot;
    {
        std::lock_guard<std::mutex> lock(data_mutex_);
        snapshot = snapshot_;
    }
    const destination_snapshot& snap = *snapshot;
    const bool ready = game_state::is_in_raid && snap.main_player != nullptr;

    // Rebuild the filtered view on menu draw (statuses refresh with the
    // gameworld cadence; the filter mirrors what the ESP extracts overlay
    // reports as currently usable).
    visible_exits_.clear();
    if (active_extracts_only->get_value())
    {
        for (const auto& e : snap.exits)
            // Eligibility decides, not the status byte: this filter is what makes an
            // extract TELEPORTABLE, so a wrong word here is a wrong destination rather
            // than a cosmetic label. `unknown` falls back to the status test.
            if (exit_status_active(e.status, e.eligibility))
                visible_exits_.push_back(e);
    }
    else
        visible_exits_ = snap.exits;
    // Clamping lived in gameworld_update() and raced the selection index from
    // this thread. It belongs here, where the filtered view is actually built.
    if (selected_exit_ >= static_cast<int>(visible_exits_.size()))
        selected_exit_ = visible_exits_.empty() ? -1 : 0;
    if (snap.exits.empty())
        selected_exit_ = -1;
    else if (selected_exit_ < 0)
        selected_exit_ = 0;
    if (snap.transits.empty())
        selected_transit_ = -1;
    else if (selected_transit_ < 0 || static_cast<size_t>(selected_transit_) >= snap.transits.size())
        selected_transit_ = 0;
    for (auto& e : visible_exits_)
        if (!e.requirement.empty())
            e.name += " (need Item " + e.requirement + ")";
    ImGui::TextColored(menu::palette::muted, "Current map");
    ImGui::TextColored(menu::palette::accent2, "%s", ready && !snap.location_id.empty() ? snap.location_id.c_str() : "Enter a raid to select a map");
    ImGui::TextColored(menu::palette::muted, "Transit controller: %s", ready ? snap.transit_controller_name.c_str() : "Not available");
    if (ready && snap.transit_controller_name == "NetworkTransitController")
        ImGui::TextColored(menu::palette::accent,
            "Network transit is active; Icebreaker cannot launch locally from this raid.");
    ImGui::Dummy(ImVec2(0, 6.f * menu::get_scale_factor()));

    draw_destination_combo("Extract", visible_exits_, selected_exit_);
    if (ImGui::Button("Teleport to Extract", ImVec2(-1.f, 0.f)) && ready && selected_exit_ >= 0
        && static_cast<size_t>(selected_exit_) < visible_exits_.size())
        teleport(visible_exits_[static_cast<size_t>(selected_exit_)], snap);

    ImGui::Dummy(ImVec2(0, 6.f * menu::get_scale_factor()));
    draw_destination_combo("Transit", snap.transits, selected_transit_);
    if (ImGui::Button("Teleport to Transit", ImVec2(-1.f, 0.f)) && ready && selected_transit_ >= 0
        && static_cast<size_t>(selected_transit_) < snap.transits.size())
        teleport(snap.transits[static_cast<size_t>(selected_transit_)], snap);

    if (!ready)
        ImGui::TextColored(menu::palette::muted, "Destinations appear after the current raid has loaded.");
}

bool TeleportModule::exit_status_active(int status, eft_api::exfil_eligibility eligibility) {
    // The game already answers "can this player leave by it right now" --
    // ExfiltrationController.EligiblePoints() -- and an extract can sit at status 2
    // "Available" while being absent from it (Scav, unmet requirement, entry-point gated).
    // Filtering on the status byte therefore offered unusable extracts as destinations.
    //
    // AND THE CONVERSE, which is why this is a conjunction rather than an either/or:
    // `EligiblePoints` does not read `_status` at all (it filters on `Settings.Chance > 0`,
    // `Settings.Name`, `EligibleEntryPoints.Contains(entryPoint)`), so membership alone
    // happily reports an extract that is at `UncompleteRequirements` or `Awaiting
    // activation`. `exfil_eligibility_of` is therefore the conjunction of the two, and this
    // function just interviews its result.
    if (eligibility == eft_api::exfil_eligibility::eligible) return true;
    if (eligibility == eft_api::exfil_eligibility::not_eligible) return false;
    // unknown: the snapshot could not be taken, so keep the previous behaviour rather
    // than hiding every exit.
    //
    // `RegularMode` only. The old test was `status == 2 || 4 || 5`, and 2 is
    // `UncompleteRequirements` -- a point whose requirements are NOT met, i.e. exactly
    // the state this checkbox exists to exclude. See the enum table in eft_api.h.
    return status == static_cast<int>(eft_api::exfil_status::regular_mode);
}

void TeleportModule::clear() {
    selected_exit_ = selected_transit_ = -1;
    visible_exits_.clear();
    {
        std::lock_guard<std::mutex> lock(data_mutex_);
        snapshot_ = std::make_shared<const destination_snapshot>();
    }
}

// The location probe that used to be defined here -- twice in this file,
// byte-identically, once for TeleportModule and once for MarkedRoomsModule --
// is now eft_api::read_location_id, which is the union of what all the copies
// did. Both were inlined by LTCG (only EspModule's survives as a symbol in the
// .map), so merging them saved nothing measurable. One definition is the point.

void TeleportModule::collect_exit_array(Il2CppArray* points, std::vector<destination>& out,
    size_t base_index, Il2CppObject* exfiltration_controller) {
    for (il2cpp_array_size_t i = 0; i < points->max_length; ++i)
    {
        auto* point = reinterpret_cast<Il2CppObject**>(&points->data)[i];
        if (!eft_api::is_il2cpp_object_likely_valid(point)) continue;
        auto* go = unity::component_get_game_object(point);
        auto* transform = go ? unity::gameobject_get_transform(go) : nullptr;
        if (!transform) continue;
        std::string name = eft_api::try_get_exfil_display_name(point);
        if (name.empty()) name = "Extract " + std::to_string(base_index + i + 1);
        destination dest;
        dest.name = std::move(name);
        dest.position = unity::transform_get_pos(transform);
        // Same status source the ESP extracts drawing uses (EExfiltrationStatus:
        // 1=Closed, 2=Available, 4/5=Open, 6=Pending, 7=Inactive, 8=Hidden).
        // Status is a BYTE (ISIL ExfiltrationPoint.txt:95 -- movzx eax,byte ptr
        // [rcx+58h]) and it is not eligibility. Read through the game's own getter, and
        // take the eligibility verdict from `EligiblePoints()`; see
        // eft_api::exfil_eligibility_of for why inferring this from a status byte is wrong.
        dest.status = eft_api::get_exfil_status(point);
        dest.eligibility = eft_api::exfil_eligibility_of(point);
        std::string requirement;
        if (eft_api::try_get_exfil_item_requirement(point, requirement))
            dest.requirement = std::move(requirement);
        out.push_back(std::move(dest));
    }
}

void TeleportModule::collect_exits(Il2CppObjectInstance& game_world,
    Il2CppObject* main_player, std::vector<destination>& out) {
    Il2CppObject* controller = game_world.get_field<Il2CppObject*>(
        "<ExfiltrationController>k__BackingField");
    if (!eft_api::is_il2cpp_object_likely_valid(controller)) return;
    const uintptr_t controller_base = reinterpret_cast<uintptr_t>(controller);

    // ONCE per update, ABOVE both branches -- it used to sit inside the regular-points
    // `if`, so when that field failed to resolve, SecretEligiblePoints was never read either
    // and the entire snapshot went stale. Placed next to the controller check, where neither
    // branch can skip it.
    //
    // EligiblePoints(Profile) needs a Profile, so `main_player` is threaded in from
    // gameworld_update. Without it the regular list is not taken and eligibility stays
    // `unknown`; the map selector then falls back to the status test rather than hiding
    // every exit.
    eft_api::refresh_exfil_eligibility(controller, main_player);

    // Regular points...
    if (FieldInfo* points_field = il2utils::resolve_field(
            controller->klass, "<ExfiltrationPoints>k__BackingField");
        points_field && points_field->offset > 0)
    {
        auto* points = *reinterpret_cast<Il2CppArray**>(controller_base + points_field->offset);
        if (points) collect_exit_array(points, out, out.size(), controller);
    }

    // ...and SECRET (hidden) points — a separate array the game never feeds
    // into EligiblePoints. Item-gated secret extracts carry the same
    // Requirements structure, so the "need Item X" labeling applies.
    if (FieldInfo* secret_field = il2utils::resolve_field(
            controller->klass, "<SecretExfiltrationPoints>k__BackingField");
        secret_field && secret_field->offset > 0)
    {
        auto* secrets = *reinterpret_cast<Il2CppArray**>(controller_base + secret_field->offset);
        if (secrets) collect_exit_array(secrets, out, out.size(), controller);
    }
}

void TeleportModule::collect_transits(Il2CppObjectInstance& game_world, std::vector<destination>& out) {
    Il2CppObject* controller = game_world.get_field<Il2CppObject*>("<TransitController>k__BackingField");
    if (!eft_api::is_il2cpp_object_likely_valid(controller)) return;
    auto* points = Il2CppObjectInstance(controller).get_field<unity::dict<int, Il2CppObject*>*>("pointsById");
    if (!points || points->m_i_count <= 0) return;
    out.reserve(points->m_i_count);
    for (int i = 0; i < points->m_i_count; ++i)
    {
        auto* point = points->get_value_by_index(i);
        if (!eft_api::is_il2cpp_object_likely_valid(point)) continue;
        auto* go = unity::component_get_game_object(point);
        auto* transform = go ? unity::gameobject_get_transform(go) : nullptr;
        if (!transform) continue;
        std::string name = eft_api::try_get_transit_display_name(point);
        if (name.empty()) name = "Transit " + std::to_string(i + 1);
        out.push_back({std::move(name), unity::transform_get_pos(transform)});
    }
}

void TeleportModule::draw_destination_combo(const char* label, const std::vector<destination>& entries, int& selected) {
    if (entries.empty())
    {
        ImGui::TextColored(menu::palette::muted, "%s: none found", label);
        return;
    }
    if (selected < 0 || static_cast<size_t>(selected) >= entries.size()) selected = 0;
    ImGui::TextColored(menu::palette::muted, "%s", label);
    if (ImGui::BeginCombo((std::string("##") + label).c_str(), entries[static_cast<size_t>(selected)].name.c_str()))
    {
        for (size_t i = 0; i < entries.size(); ++i)
            if (ImGui::Selectable(entries[i].name.c_str(), selected == static_cast<int>(i))) selected = static_cast<int>(i);
        ImGui::EndCombo();
    }
}

void TeleportModule::teleport(const destination& entry, const destination_snapshot& snapshot) const {
    if (!eft_api::is_il2cpp_object_likely_valid(snapshot.main_player)) return;
    auto* go = unity::component_get_game_object(snapshot.main_player);
    auto* transform = go ? unity::gameobject_get_transform(go) : nullptr;
    if (!transform) return;

    unity::vector3 destination = entry.position;
    // Pier Boat and Icebreaker should land at one shared safe point. Use
    // Icebreaker's live trigger position when the Pier Boat entry is used.
    if (is_shoreline_pier_boat(entry.name, snapshot.location_id))
    {
        for (const TeleportModule::destination& transit : snapshot.transits)
        {
            if (is_icebreaker_name(transit.name))
            {
                destination = transit.position;
                break;
            }
        }
    }
    const bool use_pier_offset = is_shoreline_pier_waterfront(entry.name, snapshot.location_id);

    if (use_pier_offset)
    {
        // Shoreline's north axis is +Z. Move away from the water-side
        // trigger: 20 ft north (~6.1 m) and 10 ft up (~3.05 m).
        destination.z += 6.1f;
        destination.y += 3.05f;
    }
    else
    {
        destination.y += 0.25f; // prevents placing the player below terrain at a trigger origin
    }
    unity::transform_set_pos(transform, destination);
}

bool TeleportModule::is_shoreline_pier_waterfront(const std::string& name, const std::string& location_id) const {
    std::string location = location_id;
    std::string destination_name = name;
    auto lower = [](std::string& value) {
        std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) {
            return static_cast<char>(std::tolower(c));
        });
    };
    lower(location);
    lower(destination_name);
    if (location.find("shoreline") == std::string::npos) return false;
    return destination_name.find("icebreaker") != std::string::npos
        || destination_name.find("pier boat") != std::string::npos;
}

bool TeleportModule::is_icebreaker_name(std::string name) {
    std::transform(name.begin(), name.end(), name.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return name.find("icebreaker") != std::string::npos;
}

bool TeleportModule::is_shoreline_pier_boat(std::string name, const std::string& location) const {
    if (!is_shoreline_pier_waterfront(name, location)) return false;
    std::transform(name.begin(), name.end(), name.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return name.find("pier boat") != std::string::npos;
}

void TeleportModule::clamp_selection() {
    // Retained for source compatibility, but it is now a no-op: the clamping
    // moved into draw_menu_extra(), the only thread that owns the selection
    // indices. Running it from gameworld_update() raced them.
}

MarkedRoomsModule::MarkedRoomsModule() : Module("Marked Rooms", Teleport, "marked_rooms_mod") {}

void MarkedRoomsModule::draw_overlay(ImDrawList*) {}

void MarkedRoomsModule::application_update() {}

void MarkedRoomsModule::init() {}

void MarkedRoomsModule::gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world,
    Il2CppObjectInstance main_player) {
    // Zoned 2026-10-12. Two regions, deliberately NOT one:
    //
    //  * eft_api::read_location_id runs EVERY tick -- a managed read of the world object.
    //  * scan_marked_rooms runs only when `game_world` changed identity, and the
    //    existing comment says it "is slow (it walks every Door in the map)".
    //
    // That is the bimodal shape again: on a normal tick this function is nearly
    // free, and the rare tick costs a whole map. One zone over the body would
    // report the arithmetic mean of those and answer nothing.
    if (!game_state::is_in_raid)
    {
        clear();
        return;
    }
    auto next = std::make_shared<marked_rooms_snapshot>();
    next->main_player = main_player.get_instance();
    {
        TA_ZONE_N("marked_rooms::location_id");
        next->location_id = eft_api::read_location_id(game_world_class, game_world);
    }
    if (game_world.get_instance() != scanned_world_)
    {
        // Only the game thread ever reads or writes this flag, so it needs no
        // lock. The scan itself is slow (it walks every Door in the map), so it
        // stays outside the lock.
        {
            TA_ZONE_N("marked_rooms::scan");
            scanned_world_ = game_world.get_instance();
            scan_marked_rooms(game_world_class, next->rooms);
        }
    }
    else
    {
        // No rescan this tick, so the previously published rooms are carried
        // forward. That was implicit when rooms_ was a member; with a snapshot
        // it has to be said out loud or the list empties on every tick.
        std::lock_guard<std::mutex> lock(data_mutex_);
        next->rooms = snapshot_->rooms;
    }

    std::lock_guard<std::mutex> lock(data_mutex_);
    snapshot_ = std::move(next);
}

void MarkedRoomsModule::draw_menu_extra() {
    std::shared_ptr<const marked_rooms_snapshot> snapshot;
    {
        std::lock_guard<std::mutex> lock(data_mutex_);
        snapshot = snapshot_;
    }
    const marked_rooms_snapshot& snap = *snapshot;
    const bool ready = game_state::is_in_raid && snap.main_player != nullptr;
    ImGui::TextColored(menu::palette::muted, "Current map");
    ImGui::TextColored(menu::palette::accent2, "%s", ready && !snap.location_id.empty() ? snap.location_id.c_str() : "Enter a raid to select a map");
    ImGui::Dummy(ImVec2(0, 6.f * menu::get_scale_factor()));

    // Clamping moved here from gameworld_update(), which raced it against this
    // thread's writes to selected_.
    if (selected_ < 0 || static_cast<size_t>(selected_) >= snap.rooms.size())
        selected_ = snap.rooms.empty() ? -1 : 0;

    if (snap.rooms.empty())
    {
        ImGui::TextColored(menu::palette::muted,
            ready ? "No marked rooms were found on this map." : "Marked rooms appear after the raid loads.");
        return;
    }

    ImGui::TextColored(menu::palette::muted, "Marked Room");
    if (ImGui::BeginCombo("##marked_room", snap.rooms[static_cast<size_t>(selected_)].name.c_str()))
    {
        for (size_t i = 0; i < snap.rooms.size(); ++i)
            if (ImGui::Selectable(snap.rooms[i].name.c_str(), selected_ == static_cast<int>(i)))
                selected_ = static_cast<int>(i);
        ImGui::EndCombo();
    }
    if (ImGui::Button("Teleport to Marked Room", ImVec2(-1.f, 0.f)) && ready)
        teleport(snap.rooms[static_cast<size_t>(selected_)].position, snap);
}

void MarkedRoomsModule::clear() {
    selected_ = -1;
    scanned_world_ = nullptr;
    {
        std::lock_guard<std::mutex> lock(data_mutex_);
        snapshot_ = std::make_shared<const marked_rooms_snapshot>();
    }
}

void MarkedRoomsModule::scan_marked_rooms(const Il2CppClass* game_world_class, std::vector<room>& out) {
    if (!game_world_class || !game_world_class->image) return;
    Il2CppObject* door_type = il2utils::get_system_type(game_world_class->image, "EFT.Interactive", "Door");
    size_t count = 0;
    Il2CppObject** doors = unity::find_objects_of_type(door_type, &count);
    if (!doors) return;

    for (size_t i = 0; i < count; ++i)
    {
        Il2CppObject* door = doors[i];
        if (!eft_api::is_il2cpp_object_likely_valid(door)) continue;
        const std::string key_id = eft_api::try_read_string_field(door, "KeyId");
        const char* label = nullptr;
        if (key_id == "5780cf7f2459777de4559322")
            label = "Dorms 314 Marked Room";
        else if (key_id == "5d80c62a86f7744036212b3f")
            label = "RB-VO Marked Room";
        else
            continue;

        Il2CppObject* go = unity::component_get_game_object(door);
        Il2CppObject* transform = go ? unity::gameobject_get_transform(go) : nullptr;
        if (transform) out.push_back({label, unity::transform_get_pos(transform)});
    }
}

void MarkedRoomsModule::teleport(unity::vector3 destination, const marked_rooms_snapshot& snapshot) const {
    if (!eft_api::is_il2cpp_object_likely_valid(snapshot.main_player)) return;
    Il2CppObject* go = unity::component_get_game_object(snapshot.main_player);
    Il2CppObject* transform = go ? unity::gameobject_get_transform(go) : nullptr;
    if (!transform) return;
    destination.y += 0.25f;
    unity::transform_set_pos(transform, destination);
}
