#pragma once
#include <Windows.h>

#include "../eft_api.h"
#include "../game_state.h"
#include "../Module.h"
#include "../ModuleCategory.h"
#include "../../config/CheckboxValue.h"
#include "../../config/FloatSliderEditableValue.h"
#include "../../config/MenuSectionValue.h"
#include "../../config/ActionRowValue.h"
#include "../../config/IntSliderEditableValue.h"
#include "../../config/SelectValue.h"
#include "../../il2cpp/Il2CppObjectInstance.h"
#include "../../il2cpp/exports.h"
#include "../../il2cpp/il2utils.h"
#include "../../il2cpp/unity.h"
#include "../../util/logger.h"
#include "../../util/utils.h"
#include "../../gui/menu/menu.h"
#include <cmath>
#include <format>
// For std::size, used by the static_asserts that tie the *_KEYS / *_API pairs
// together below. This header reaches five translation units, one of them via
// ModuleManager.h, and std::size is declared in <iterator> -- relying on it
// arriving transitively through <format> or <vector> is how a header that
// compiles in one TU stops compiling in another.
#include <iterator>
#include "../always_on.h"
#include "../survival_clamp.h"

inline bool do_speed;
inline int speed_value;

inline Il2CppObject* fly_main_player = nullptr;

inline size_t fly_freefall_time_offset = 0;
inline size_t fly_is_grounded_offset = 0;

inline bool should_survive;

inline void init_fly_hack_offsets() {
    if (fly_freefall_time_offset != 0) return;

    const Il2CppImage* image = il2utils::resolve_image("Assembly-CSharp.dll");
    if (!image) return;

    const Il2CppClass* movement_context_class = il2utils::resolve_class(image, "EFT", "MovementContext");
    if (!movement_context_class) return;

    if (const FieldInfo* freefall_field = il2utils::resolve_field(movement_context_class, "FreefallTime"))
        fly_freefall_time_offset = freefall_field->offset;
    if (const FieldInfo* grounded_field = il2utils::resolve_field(movement_context_class, "_isGrounded"))
        fly_is_grounded_offset = grounded_field->offset;
}

inline void try_set_freefall_time(Il2CppObject* movement_ctx, const float value) {
    if (!movement_ctx || fly_freefall_time_offset == 0) return;
    *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(movement_ctx) + fly_freefall_time_offset) = value;
}

inline void try_set_is_grounded(Il2CppObject* movement_ctx, const bool grounded) {
    if (!movement_ctx || !movement_ctx->klass) return;

    const MethodInfo* set_grounded = il2utils::resolve_method(movement_ctx->klass, "set_IsGrounded", 1);
    if (set_grounded && set_grounded->methodPointer)
        reinterpret_cast<void (*)(Il2CppObject*, bool)>(set_grounded->methodPointer)(movement_ctx, grounded);
    else if (fly_is_grounded_offset != 0)
        *reinterpret_cast<bool*>(reinterpret_cast<uintptr_t>(movement_ctx) + fly_is_grounded_offset) = grounded;
}

inline Il2CppObject* try_get_player_bifacial_transform(Il2CppObject* movement_ctx) {
    if (!movement_ctx || !movement_ctx->klass) return nullptr;
    const FieldInfo* player_transform_field = il2utils::resolve_field(movement_ctx->klass, "_playerTransform");
    if (!player_transform_field) return nullptr;
    return *reinterpret_cast<Il2CppObject**>(
        reinterpret_cast<uintptr_t>(movement_ctx) + player_transform_field->offset);
}

inline bool try_get_movement_position(Il2CppObject* movement_ctx, unity::vector3& out) {
    if (!movement_ctx || !movement_ctx->klass) return false;

    const MethodInfo* get_pos = il2utils::resolve_method(movement_ctx->klass, "get_TransformPosition", 0);
    if (get_pos && get_pos->methodPointer)
    {
        out = reinterpret_cast<unity::vector3 (*)(Il2CppObject*)>(get_pos->methodPointer)(movement_ctx);
        return true;
    }

    if (Il2CppObject* bifacial = try_get_player_bifacial_transform(movement_ctx))
    {
        // Bifacial path: delegated to the single reader, as the three sibling copies are.
        // The get_TransformPosition branch above is deliberately NOT folded in -- that is a
        // different method on a different object (the movement context, not a
        // BifacialTransform), so it is not the same access function, only the same shape.
        return eft_api::try_get_managed_position(bifacial, out);
    }

    return false;
}

inline bool try_set_movement_position(Il2CppObject* movement_ctx, Il2CppObject* player, const unity::vector3& pos) {
    if (movement_ctx && movement_ctx->klass)
    {
        const MethodInfo* set_pos = il2utils::resolve_method(movement_ctx->klass, "set_TransformPosition", 1);
        if (set_pos && set_pos->methodPointer)
        {
            reinterpret_cast<void (*)(Il2CppObject*, unity::vector3)>(set_pos->methodPointer)(movement_ctx, pos);
            return true;
        }
    }

    if (movement_ctx)
    {
        Il2CppObject* bifacial = try_get_player_bifacial_transform(movement_ctx);
        if (bifacial && bifacial->klass)
        {
            const MethodInfo* set_position = il2utils::resolve_method(bifacial->klass, "set_position", 1);
            if (set_position && set_position->methodPointer)
            {
                reinterpret_cast<void (*)(Il2CppObject*, unity::vector3)>(set_position->methodPointer)(bifacial, pos);
                return true;
            }
        }
    }

    if (player && player->klass)
    {
        const MethodInfo* set_position = il2utils::resolve_method(player->klass, "set_Position", 1);
        if (set_position && set_position->methodPointer)
        {
            reinterpret_cast<void (*)(Il2CppObject*, unity::vector3)>(set_position->methodPointer)(player, pos);
            return true;
        }
    }

    return false;
}

inline unity::vector3 try_get_movement_up(Il2CppObject* movement_ctx) {
    if (!movement_ctx) return {0.f, 1.f, 0.f};

    if (Il2CppObject* bifacial = try_get_player_bifacial_transform(movement_ctx))
    {
        const MethodInfo* get_up = il2utils::resolve_method(bifacial->klass, "get_up", 0);
        if (get_up && get_up->methodPointer)
            return reinterpret_cast<unity::vector3 (*)(Il2CppObject*)>(get_up->methodPointer)(bifacial);
    }

    return {0.f, 1.f, 0.f};
}

inline bool is_fly_key_held(const int key_code) {
    if (key_code == 0) return false;
    if (key_code == VK_CONTROL)
        return (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0
            || (GetAsyncKeyState(VK_LCONTROL) & 0x8000) != 0
            || (GetAsyncKeyState(VK_RCONTROL) & 0x8000) != 0;
    return (GetAsyncKeyState(key_code) & 0x8000) != 0;
}

inline void fly_hack_tick(Il2CppObject* player, const int speed, const int up_key, const int down_key) {
    init_fly_hack_offsets();

    if (!player || !player->klass) return;
    if (!unity::get_current_camera()) return;

    const MethodInfo* get_mc = il2utils::resolve_method(player->klass, "get_MovementContext", 0);
    if (!get_mc || !get_mc->methodPointer) return;

    Il2CppObject* movement_ctx = reinterpret_cast<Il2CppObject* (*)(Il2CppObject*)>(get_mc->methodPointer)(player);
    if (!movement_ctx) return;

    try_set_freefall_time(movement_ctx, 0.f);
    try_set_is_grounded(movement_ctx, true);

    const bool up_held = is_fly_key_held(up_key);
    const bool down_held = is_fly_key_held(down_key);

    if (!up_held && !down_held) return;

    if (up_held)
        try_set_freefall_time(movement_ctx, -0.4f);

    unity::vector3 pos;
    if (!try_get_movement_position(movement_ctx, pos)) return;

    constexpr float fly_step_per_frame = 0.012f;
    const float step = fly_step_per_frame * static_cast<float>(speed);
    const unity::vector3 up = try_get_movement_up(movement_ctx);
    const unity::vector3 delta = {up.x * step, up.y * step, up.z * step};

    if (up_held)
        pos = pos.add(delta);
    if (down_held)
        pos = {pos.x - delta.x, pos.y - delta.y, pos.z - delta.z};

    try_set_movement_position(movement_ctx, player, pos);
}

using fixed_update_sig = void (*)(Il2CppObject*);
inline fixed_update_sig o_player_camera_controller_fixed_update = nullptr;

inline void hk_player_camera_controller_fixed_update(Il2CppObject* instance) {
    if (do_speed)
    {
        // The three call-throughs in this hook were swept to the checked
        // accessor on 2026-10-14 (handoff_call_through_null_crash.md's open bug
        // class). Each used to resolve and invoke in one expression, so a miss
        // was a call to address 0x0 -- the shape that killed the process on
        // 2026-10-04. get_velocity and Move are per-frame reads, and a null
        // fail-closed value here means the fly-speed nudge quietly does nothing
        // this frame rather than killing the process.
        Il2CppObjectInstance controller_instance(instance);
        Il2CppObjectInstance main_player(controller_instance.call_or<Il2CppObject*>(
            "get_Player", 0, nullptr));
        Il2CppObjectInstance character_controller(main_player.get_field<Il2CppObject*>("_characterController"));
        unity::vector3 velocity = character_controller.call_or<unity::vector3>(
            "get_velocity", 0, unity::vector3{});
        velocity.x /= 100;
        velocity.y = 0;
        velocity.z /= 100;
        for (int i = 0; i < speed_value; ++i)
        {
            // R stays the OLD declared signature (an int-returning Move whose
            // value was always discarded); call_or_void calls it and ignores the
            // result, exactly as the resolved-and-invoked form did.
            character_controller.call_or_void<int (*)(Il2CppObject*, unity::vector3, float)>(
                "Move", 2, velocity, 100.0f);
        }
    }

    o_player_camera_controller_fixed_update(instance);
}

using local_game_stop_sig = void (*)(Il2CppObject*, Il2CppString*, int, Il2CppString*, float);

inline local_game_stop_sig o_local_game_stop;

// EFT.ExitStatus -- GameDump/115147510/DiffableCs/Assembly-CSharp/EFT/ExitStatus.cs.
// The numbering is corroborated by the ISIL, not just the dump: MatchEndSettings
// switches on it (GetReward's 0..5 jump table, GetMultiplier's Survived/Killed/Left/
// Runner/Mia arms with 5 falling through to the transitCount multiplier), and
// BaseStatisticsManager.EndStatisticsSession tests `exitStatus == 0 || exitStatus == 5`
// as one branch against the death branch.
enum EExitStatus : int {
    kExitStatusSurvived = 0,
    kExitStatusKilled = 1,
    kExitStatusLeft = 2,
    kExitStatusRunner = 3,
    kExitStatusMissingInAction = 4,
    kExitStatusTransit = 5,
};

// "Always Survive" only rewrites the DEATH outcomes. It must leave a transit alone:
// LocalTransitController.Transit ends the outgoing raid through this very override
// (ISIL LocalTransitController.Transit: `mov r8d,5` / `mov r9,[r9+18h]` / `call r10`
// -> Stop(profileId, ExitStatus.Transit, destinationLocationName, 0)), and the game
// keys the rest of the hop off that status. Rewriting 5 -> 0 reports the transfer as a
// successful extraction instead, so the transfer/carry-over bookkeeping never runs and
// the destination raid inherits nothing. It also desyncs always_on's transit tracking
// (g_raid_start_guard stays armed on a raid that is supposed to transition).
// Every other status the game can hand us -- Killed (InitiateGameStopping, the Spawn
// damage action), Left (LocalLeaveGame), MissingInAction (EndByTimerScenario.StopGame,
// BufferInnerZone) -- is a real death/leave outcome and still gets forced to Survived.
inline void hk_local_game_stop(Il2CppObject* instance, Il2CppString* profile_id, int exit_status,
    Il2CppString* exit_name, float delay) {
    if (should_survive && exit_status != kExitStatusTransit)
    {
        logger::debug("Always Survive: " + std::to_string(exit_status) + " -> " + std::to_string(kExitStatusSurvived));
        exit_status = kExitStatusSurvived;
    }
    else if (should_survive)
    {
        logger::debug("Always Survive: transit exit kept (exit_name=" + il2utils::conv_string(exit_name) + ")");
    }

    always_on::raid_start_guard_disarm("hk_local_game_stop");

    o_local_game_stop(instance, profile_id, exit_status, exit_name, delay);
}

// The game-facing half of the three survival modes: the two hooks, the local
// player tracking, and the walk that reads a bodypart's current health.
//
// The decision table and the floor arithmetic are NOT here -- they are in
// module/survival_clamp.h, which has no il2cpp in it and is covered by
// tools/harness/test_survival_clamp.cpp. This namespace calls into it.
//
// Why hooks at all: the previous implementation hooked ApplyDamage and returned 0
// for the vital body parts. Live logging proved that a dead end -- the hook fires
// with the right instance and the right body part, and the health is still
// subtracted, because ApplyDamage's return value is not what applies the damage.
// ChangeHealth takes the delta as an argument, so modifying the argument is what
// actually changes the health.
//
// Death funnels through ActiveHealthController.Kill, so hook_kill gates it, and
// it gates it for all three modes. hook_change_health is what separates them.
namespace semi_god {
    using kill_sig = void (*)(Il2CppObject*, int);
    using change_health_sig = void (*)(Il2CppObject*, int, float, void*);
    using mode = survival_clamp::mode;

    inline kill_sig original_kill = nullptr;
    inline change_health_sig original_change_health = nullptr;
    inline bool installed = false;
    inline bool damage_hook_installed = false;
    inline Il2CppObject* local_health_controller = nullptr;
    inline const Il2CppClass* hooked_class = nullptr;
    inline mode active_mode = mode::off;

    inline int diag_budget = 8;
    inline int diag_total_calls = 0;
    // Separate budget for the clamp. This fires per DAMAGE EVENT, not per frame,
    // but a raid full of bleed ticks would still emit thousands of lines, and
    // logger::debug's argument is built by the caller whether or not DEBUG is on
    // (DebugLogModule::init disables the sink, not the formatting).
    inline int clamp_diag_budget = 8;
    inline int clamp_total = 0;

    // Current health of one body part, read straight out of the controller's own
    // _bodyState dictionary.
    //
    // The clamp needs the part's CURRENT value to work out how much of `delta`
    // is still safe, and reading it through the game's GetBodyPartHealth would be
    // a managed call on every damage event. This is the same dictionary walk
    // eft_api already uses for limb health, against the same dump-verified entry
    // layout (int key + object value, 4-byte pad on x64), and the field lookups
    // go through cached_field so this is not a per-event reflection walk.
    //
    // Returns false rather than guessing when the part cannot be read. A caller
    // that clamps on a miss would clamp the wrong number, and one that passes the
    // damage through is no worse than not hooking at all.
    inline bool try_read_part_current(Il2CppObject* health_controller, const int body_part, float& out_current) {
        if (!health_controller || !health_controller->klass) return false;

        Il2CppObject* body_state_obj = eft_api::try_get_field_object(health_controller, "_bodyState");
        if (!body_state_obj || !body_state_obj->klass) return false;

        auto* body_state = reinterpret_cast<unity::dict<int, Il2CppObject*>*>(body_state_obj);
        if (!body_state->m_p_entries || body_state->m_p_entries->max_length == 0) return false;

        const int entry_count = static_cast<int>(body_state->m_p_entries->max_length);
        if (entry_count <= 0 || entry_count > 64) return false;

        const auto* entries = reinterpret_cast<const eft_api::body_state_dict_entry*>(&body_state->m_p_entries->data);
        if (!entries) return false;

        for (int i = 0; i < entry_count; ++i)
        {
            const auto& entry = entries[i];
            if (entry.hash_code < 0) continue;
            if (entry.key != body_part) continue;
            if (!entry.part_state || !entry.part_state->klass) return false;

            Il2CppObject* health_value = eft_api::try_get_field_object(entry.part_state, "Health");
            if (!health_value || !health_value->klass) return false;

            // HealthValue.Value is a ValueStruct whose first float is Current
            // (dump.cs 439030). Read the field rather than calling get_Current:
            // Il2CppObjectInstance::get_method has no cache and walks the method
            // table on every call, which is the thing worth avoiding here.
            const FieldInfo* value_field = eft_api::cached_field(health_value->klass, "Value");
            if (!value_field) return false;

            out_current = *reinterpret_cast<float*>(
                reinterpret_cast<UINT64>(health_value) + value_field->offset);
            return std::isfinite(out_current) && out_current > 0.0f;
        }
        return false;
    }

    // The delta to actually forward, given what the game wanted to apply.
    // All the deciding is survival_clamp::apply; this only supplies `current`.
    inline float clamped_delta(Il2CppObject* self, const int body_part, const float delta) {
        if (!survival_clamp::part_is_protected(active_mode, body_part)) return delta;
        if (delta >= 0.0f) return delta; // healing, never clamped

        float current = survival_clamp::k_unknown_hp;
        if (!try_read_part_current(self, body_part, current)) return delta;

        return survival_clamp::apply(active_mode, body_part, current, delta);
    }

    inline void hook_change_health(Il2CppObject* self, const int body_part,
        const float delta, void* change_info) {
        if (!original_change_health) return;

        // Only the local player. `self` is the ActiveHealthController the game
        // called ChangeHealth on, and it is a singleton per raid -- every bot,
        // every AI -- so without this test the clamp would freeze the lobby.
        if (self == local_health_controller) {
            const float applied = clamped_delta(self, body_part, delta);
            if (applied != delta) {
                ++clamp_total;
                if (clamp_diag_budget > 0) {
                    --clamp_diag_budget;
                    char buf[160];
                    sprintf_s(buf,
                        "semi_god[%s]: ChangeHealth #%d part=%d  delta=%.3f -> %.3f",
                        survival_clamp::name(active_mode), clamp_total, body_part, delta, applied);
                    logger::debug(buf);
                }
            }
            original_change_health(self, body_part, applied, change_info);
            return;
        }

        original_change_health(self, body_part, delta, change_info);
    }

    // The kill gate. Installed for all three modes and, unlike the clamp above, it
    // is unconditional: a mode that holds the vitals at 1 HP should already make
    // this unreachable, so anything that still arrives here is a death path that
    // bypassed ChangeHealth entirely.
    inline void hook_kill(Il2CppObject* self, const int damage_type) {
        ++diag_total_calls;
        const bool is_us = self == local_health_controller;

        if (diag_budget > 0)
        {
            --diag_budget;
            char buf[192];
            sprintf_s(buf,
                "semi_god: Kill #%d  self=0x%llX  tracked=0x%llX  match=%s  damage_type=%d  -> %s",
                diag_total_calls,
                reinterpret_cast<unsigned long long>(self),
                reinterpret_cast<unsigned long long>(local_health_controller),
                is_us ? "YES" : "no",
                damage_type,
                is_us ? "BLOCKED" : "passthrough");
            logger::debug(buf);
        }

        // Swallow our own death. Everyone else dies normally.
        if (is_us)
            return;

        if (original_kill)
            original_kill(self, damage_type);
    }

    // Installs or removes both hooks for `m`, and points them at the local
    // player. Called once per frame with whichever of the three toggles is on;
    // they are mutually exclusive (PlayerModule::sync_god_mode_state), so at most
    // one is ever non-off.
    inline void sync(Il2CppObject* health_controller, const mode m) {
        const bool enabled = m != mode::off;
        active_mode = m;
        local_health_controller = enabled ? health_controller : nullptr;

        if (enabled && health_controller && health_controller->klass)
            hooked_class = health_controller->klass;

        if (!hooked_class)
            return;

        // Report resolution once, on the transition only, so this stays off the per-frame path.
        if (enabled != installed || enabled != damage_hook_installed)
        {
            const MethodInfo* kill_method = il2utils::resolve_method(hooked_class, "Kill", 1);
            const MethodInfo* change_method = il2utils::resolve_method(hooked_class, "ChangeHealth", 3);
            logger::debug(std::string("semi_god: ") + (enabled ? std::string("enabling ") + survival_clamp::name(m) : "disabling")
                + " on class=" + (hooked_class->name ? hooked_class->name : "(null)")
                + " Kill/1=" + (kill_method ? "resolved" : "NOT FOUND")
                + " ChangeHealth/3=" + (change_method ? "resolved" : "NOT FOUND"));
        }

        il2utils::set_method_hook(hooked_class, "Kill", 1,
            hook_kill, &original_kill, &installed, enabled);
        il2utils::set_method_hook(hooked_class, "ChangeHealth", 3,
            hook_change_health, &original_change_health, &damage_hook_installed, enabled);
    }
} // namespace semi_god

class PlayerModule : Module
{
  public:
    // bots treat the player as one of their own.

    PlayerModule();

    // --- Survival / raid helpers ---------------------------------------------
    MenuSectionValue* section_survival_;
    CheckboxValue* god_mode;
    CheckboxValue* semi_god_mode;
    // "Buddha Mode". Named god_mode2 for config compatibility: the config key is
    // `god_mode_negative_on_cb##player_mod` (ConfigValue::get_config_key), so
    // renaming the string would silently reset every user's saved setting. Only
    // the display strings in lang/*.json were renamed.
    CheckboxValue* god_mode2;
    CheckboxValue* infinite_stamina;
    CheckboxValue* no_hunger_thirst;
    CheckboxValue* instant_search;
    // The Search skill's Elite sub-perk (SkillManager.SearchDouble, a
    // BooleanBuff, not the FloatBuff Lucky Search uses). Labelled "Double
    // Search" after the game's own field name, the way Lucky Search is labelled
    // after AttentionEliteLuckySearch.
    CheckboxValue* double_search;
    CheckboxValue* always_survive;

    // --- Profile modifiers (exp / rep / skills) ------------------------------
    MenuSectionValue* section_profile_mods_;
    static constexpr const char* EXP_TYPE_KEYS[] = {"exp_door_breached_sel", "exp_item_looting_sel", "exp_damage_sel", "exp_heal_sel", "exp_examine_sel", "exp_kill_base_sel", "exp_item_looting_2_sel"};
    static constexpr const char* EXP_TYPE_API[] = {"ExpDoorBreached", "ExpItemLooting", "ExpDamage", "ExpHeal", "ExpExamine", "ExpKillBase", "ExpItemLooting"};
    static constexpr const char* TRADER_KEYS[] = {"trader_lightkeeper_sel", "trader_ragman_sel", "trader_arena_manager_sel", "trader_peacekeeper_sel", "trader_skier_sel", "trader_prapor_sel", "trader_jaeger_sel", "trader_mechanic_sel", "trader_terapevt_sel", "trader_btr_sel"};
    static constexpr const char* TRADER_API[] = {"LIGHT_KEEPER_TRADER", "RAGMAN_TRADER", "ARENA_MANAGER_TRADER", "PEACEKEEPER", "SKIER", "PRAPOR_TRADER", "JAEGER_TRADER", "MECHANIC_TRADER", "TERAPEVT_TRADER", "BTR_TRADER"};
    static constexpr const char* SKILL_KEYS[] = {"skill_pistol_sel", "skill_revolver_sel", "skill_smg_sel", "skill_assault_sel", "skill_shotgun_sel", "skill_sniper_sel", "skill_lmg_sel", "skill_hmg_sel", "skill_launcher_sel", "skill_attached_launcher_sel", "skill_misc_sel", "skill_melee_sel", "skill_dmr_sel", "skill_throwing_sel", "skill_aim_drills_sel", "skill_recoil_control_sel", "skill_trouble_shooting_sel", "skill_perception_sel", "skill_attention_sel", "skill_intellect_sel", "skill_immunity_sel", "skill_charisma_sel", "skill_memory_sel", "skill_endurance_sel", "skill_strength_sel", "skill_vitality_sel", "skill_health_sel", "skill_metabolism_sel", "skill_stress_resistance_sel", "skill_sniping_sel", "skill_covert_movement_sel", "skill_prone_movement_sel", "skill_light_vests_sel", "skill_heavy_vests_sel", "skill_weapon_modding_sel", "skill_advanced_modding_sel", "skill_lockpicking_sel", "skill_surgery_sel", "skill_search_sel", "skill_weapon_treatment_sel", "skill_mag_drills_sel", "skill_freetrading_sel", "skill_barter_sel", "skill_crafting_sel", "skill_hideout_management_sel", "skill_bear_assaultoperations_sel", "skill_bear_authority_sel", "skill_bear_aksystems_sel", "skill_bear_heavycaliber_sel", "skill_bear_rawpower_sel", "skill_usec_arsystems_sel", "skill_usec_deepweaponmodding_sel", "skill_usec_longrangeoptics_sel", "skill_usec_negotiations_sel", "skill_usec_tactics_sel"};
    static constexpr const char* SKILL_API[] = {"Pistol", "Revolver", "SMG", "Assault", "Shotgun", "Sniper", "LMG", "HMG", "Launcher", "AttachedLauncher", "Misc", "Melee", "DMR", "Throwing", "AimDrills", "RecoilControl", "TroubleShooting", "Perception", "Attention", "Intellect", "Immunity", "Charisma", "Memory", "Endurance", "Strength", "Vitality", "Health", "Metabolism", "StressResistance", "Sniping", "CovertMovement", "ProneMovement", "LightVests", "HeavyVests", "WeaponModding", "AdvancedModding", "Lockpicking", "Surgery", "Search", "WeaponTreatment", "MagDrills", "Freetrading", "Barter", "Crafting", "HideoutManagement", "BearAssaultoperations", "BearAuthority", "BearAksystems", "BearHeavycaliber", "BearRawpower", "UsecArsystems", "UsecDeepweaponmodding", "UsecLongrangeoptics", "UsecNegotiations", "UsecTactics"};

    // These three pairs must stay the same length, and nothing in the language
    // enforces it. Each *_KEYS array is the option list a SelectValue is built
    // from, and SelectValue::clamp_value() bounds its index to that list's
    // length -- so *_API[select->get_value()] is in range exactly while the two
    // arrays agree. Today they are 7, 10 and 55.
    //
    // Add a key without its API entry and the clamp still permits the new index,
    // so the read runs one element past a `constexpr const char*[]`. That does
    // not fault at the read: it yields a garbage pointer, which faults later and
    // somewhere else entirely, inside resolve_field or get_static_field, with
    // nothing in the stack to connect it back to this line. Three index sites
    // reach SKILL_API and one of them (:600) is the error path, so the
    // out-of-range read can happen while reporting a *different* failure.
    //
    // These are asserts rather than a comment because the failure mode is silent
    // and the fix is otherwise a bisect through a game update. They cost nothing
    // when they hold, which is now.
    static_assert(std::size(EXP_TYPE_KEYS) == std::size(EXP_TYPE_API),
        "EXP_TYPE_KEYS is the option list exp_type's SelectValue clamps to, and "
        "EXP_TYPE_API is indexed by that same value. If these lengths differ, "
        "EXP_TYPE_API[exp_type->get_value()] can read past the end. Add the key "
        "and the API name together.");
    static_assert(std::size(TRADER_KEYS) == std::size(TRADER_API),
        "TRADER_KEYS and TRADER_API are a parallel pair, indexed by "
        "trader_select->get_value(). Keep them the same length.");
    static_assert(std::size(SKILL_KEYS) == std::size(SKILL_API),
        "SKILL_KEYS and SKILL_API are a parallel pair, indexed by "
        "skill_select->get_value() at three sites. Keep them the same length.");


    SelectValue* exp_type;
    IntSliderEditableValue* exp_amount;
    ActionRowValue* add_exp;

    SelectValue* fence_rep_source;
    FloatSliderEditableValue* fence_rep_amount;
    ActionRowValue* add_fence_rep;

    SelectValue* trader_select;
    FloatSliderEditableValue* trader_rep_amount;
    ActionRowValue* add_trader_rep;

    SelectValue* skill_select;
    IntSliderEditableValue* skill_level;
    ActionRowValue* set_skill;

    // --- Vision / camera -----------------------------------------------------
    MenuSectionValue* section_vision_;
    CheckboxValue* thermal_vision;
    CheckboxValue* night_vision;
    CheckboxValue* no_visor;
    CheckboxValue* third_person;
    // Distance behind player (local -Z). Higher Y lifts camera out of head mesh.
    FloatSliderEditableValue* third_person_distance;
    FloatSliderEditableValue* third_person_height;

    // --- Misc exploits -------------------------------------------------------
    MenuSectionValue* section_player_misc_;
    CheckboxValue* far_reach;
    CheckboxValue* flares; // call airdrop on hotkey
    bool queue_call_airdrop = false;

    // Movement controls intentionally sit at the bottom of the Player card.
    MenuSectionValue* section_movement_;
    CheckboxValue* speed_hack;
    IntSliderEditableValue* speed;
    CheckboxValue* fly_hack;
    IntSliderEditableValue* fly_speed;
    int fly_up_key = VK_SPACE;
    int fly_down_key = VK_CONTROL;

    bool queue_add_exp = false;
    bool queue_add_fence_rep = false;
    bool queue_add_trader_rep = false;
    bool queue_set_skill = false;

    void add_exp_impl();

    void add_fence_rep_impl();

    void add_trader_rep_impl();

    void set_skill_impl();

    void sync_profile_mod_controls_lock();

    void sync_movement_controls_lock();

    // ---- Camera / vision helpers ------------------------------------------
    static Il2CppObject* try_get_camera_component(Il2CppObject* camera, const char* ns, const char* cls_name);

    static void apply_thermal(Il2CppObject* thermal, const bool on);

    // BSG.CameraEffects.NightVision is the camera-side NVG component, the sibling
    // of ThermalVision (both are fetched by CameraManager.InitCamera off the FPS
    // camera). Its On state lives in the private _on backing field -- set_On is
    // itself a bare field write -- and OnPreCull/OnPostRender gate the whole
    // render path on that byte, so the field write is sufficient. See the note
    // above apply_night_vision in PlayerModule.cpp.
    static void apply_night_vision(Il2CppObject* night_vision_component, const bool on);

    static void apply_visor(Il2CppObject* visor, const bool remove);

    // dump: Player.get_CameraPosition() → Transform (backing field <CameraPosition>k__BackingField)
    static Il2CppObject* try_get_player_camera_position_transform(Il2CppObject* player);

    static void apply_point_of_view(Il2CppObject* player, const int pov,
        const float tp_distance, const float tp_height);

    static void apply_far_reach();

    static bool player_is_aiming(Il2CppObject* player);


    static void try_call_airdrop(Il2CppObjectInstance& game_world, Il2CppObject* local_player);

    void draw_overlay(ImDrawList*) override;

    void sync_god_mode_state();

    void application_update() override;

    void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
        Il2CppObjectInstance main_player) override;

    void init() override;

    [[nodiscard]] bool is_active() const override {
        return god_mode->get_value() || semi_god_mode->get_value() || god_mode2->get_value()
            || infinite_stamina->get_value() || no_hunger_thirst->get_value() || instant_search->get_value()
            || double_search->get_value()
            || always_survive->get_value() || thermal_vision->get_value() || no_visor->get_value()
            || third_person->get_value() || far_reach->get_value() 
            || flares->get_value() || speed_hack->get_value() || fly_hack->get_value();
    }
};
