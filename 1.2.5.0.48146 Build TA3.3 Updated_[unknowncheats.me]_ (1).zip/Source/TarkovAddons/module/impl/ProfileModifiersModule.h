#pragma once

#include "PlayerModule.h"

// Presentation-only card. The live profile operations remain owned by
// PlayerModule; this separates their controls without duplicating settings.
class ProfileModifiersModule final : public Module
{
  public:
    explicit ProfileModifiersModule(PlayerModule* player);

    void draw_overlay(ImDrawList*) override;
    void application_update() override;
    void gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) override;
    void init() override;
    [[nodiscard]] bool draw_menu_extra_before_values() const override;

    void draw_menu_extra() override;

  private:
    PlayerModule* player_ = nullptr;
    std::vector<ConfigValue*> profile_values_;
};
