#include "common.h"
#include "MinimapModule.h"

// MapStuff, not Exploit: Exploit already carries six cards across two columns
// (Aimbot, Door Unlocker, Weapon, Player, Chams, ESP). The display key is
// unchanged, so saved configs are unaffected -- ModuleCategory is a runtime
// grouping key and is never serialised.
MinimapModule::MinimapModule() : Module("Minimap", MapStuff, "minimap_mod"),
                                 section_general_(conf(new MenuSectionValue("general_sec"))),
                                 radar(conf(new CheckboxValue(false, "minimap_cb"))),
                                 radar_exfils(conf(new CheckboxValue(false, "extracts_transits_cb"))),
                                 radar_minimap_quest_esp(conf(new CheckboxValue(false, "quest_esp_map_cb"))),
                                 radar_minimap_quest_names(conf(new CheckboxValue(false, "quest_names_map_cb"))),
                                 radar_minimap_bots(conf(new CheckboxValue(false, "bot_markers_cb"))),
                                 radar_minimap_bot_names(conf(new CheckboxValue(false, "bot_names_cb"))),
                                 radar_minimap_bot_corpses(conf(new CheckboxValue(false, "bot_corpse_markers_cb"))),
                                 radar_minimap_bot_corpse_color(conf(new ColorpickerValue(
                                     {0.55f, 0.55f, 0.55f, 1.f}, "bot_corpse_color_clr"))),
                                 section_map_(conf(new MenuSectionValue("map_display_sec"))),
                                 radar_minimap(conf(new CheckboxValue(true, "map_background_cb"))),
                                 radar_minimap_style(conf(new SelectValue(0, {"abstract_sel", "satellite_sel"}, "map_style_sel"))),
                                 radar_minimap_rotate(conf(new CheckboxValue(false, "rotate_cb"))),
                                 radar_minimap_grid(conf(new CheckboxValue(false, "map_grid_cb"))),
                                 radar_minimap_grid_opacity(conf(new FloatSliderEditableValue(100.f, 0.f, 100.f, "map_grid_opacity_itm"))),
                                 radar_minimap_compass(conf(new CheckboxValue(false, "compass_frame_cb"))),
                                 radar_minimap_backdrop(conf(new CheckboxValue(false, "map_backdrop_cb"))),
                                 radar_minimap_backdrop_color(conf(new ColorpickerValue(
                                     {8.f / 255.f, 12.f / 255.f, 14.f / 255.f, 120.f / 255.f}, "map_backdrop_color_clr"))),
                                 radar_minimap_opacity(conf(new FloatSliderEditableValue(100.f, 0.f, 100.f, "opacity_itm"))),
                                 radar_minimap_static_markers(conf(new CheckboxValue(false, "map_static_markers_cb"))),
                                 radar_minimap_labels(conf(new CheckboxValue(false, "map_labels_cb"))),
                                 section_layout_(conf(new MenuSectionValue("layout_sec"))),
                                 radar_minimap_corner(conf(new SelectValue(1, {"bottom_right_sel", "top_right_sel"}, "position_sel"))),
                                 radar_size(conf(new FloatSliderEditableValue(250.f, 100.f, 400.f, "size_itm"))),
                                 radar_range(conf(new FloatSliderEditableValue(400.f, 5.f, 2000.f, "range_itm"))),
                                 radar_margin_x(conf(new FloatSliderEditableValue(24.f, 0.f, 300.f, "margin_x_itm"))),
                                 radar_margin_y(conf(new FloatSliderEditableValue(24.f, 0.f, 300.f, "margin_y_itm"))),
                                 section_text_(conf(new MenuSectionValue("marker_text_sec"))),
                                 minimap_text_font_size(conf(new IntSliderEditableValue(9, 8, 36, "minimap_text_size_itm"))),
                                 minimap_marker_outline(conf(new CheckboxValue(false, "marker_map_outline_cb"))),
                                 section_symbols_(conf(new MenuSectionValue("marker_symbols_sec"))),
                                 minimap_sym_player(conf(new CompactTextboxValue("\xE2\x88\x86", "player_symbol_txt", 3))),
                                 minimap_sym_player_size(conf(new IntSliderEditableValue(10, 6, 36, "player_symbol_size_itm"))),
                                 minimap_sym_entity(conf(new CompactTextboxValue("\xE2\x96\xA0", "entity_symbol_txt", 3))),
                                 minimap_sym_entity_size(conf(new IntSliderEditableValue(7, 6, 36, "entity_symbol_size_itm"))),
                                 minimap_sym_quest(conf(new CompactTextboxValue("\xC3\x97", "quest_symbol_txt", 3))),
                                 minimap_sym_quest_size(conf(new IntSliderEditableValue(13, 6, 36, "quest_symbol_size_itm"))),
                                 minimap_sym_exfil(conf(new CompactTextboxValue("\xE2\x97\x89", "exfil_symbol_txt", 3))),
                                 minimap_sym_exfil_size(conf(new IntSliderEditableValue(10, 6, 36, "exfil_symbol_size_itm"))),
                                 minimap_sym_transit(conf(new CompactTextboxValue("\xE2\x97\x88", "transit_symbol_txt", 3))),
                                 minimap_sym_transit_size(conf(new IntSliderEditableValue(10, 6, 36, "transit_symbol_size_itm"))),
                                 minimap_sym_height_up(conf(new CompactTextboxValue("\xE2\x96\xB2", "height_up_symbol_txt", 3))),
                                 minimap_sym_height_up_size(conf(new IntSliderEditableValue(7, 6, 36, "height_up_symbol_size_itm"))),
                                 minimap_sym_height_down(conf(new CompactTextboxValue("\xE2\x96\xBC", "height_down_symbol_txt", 3))),
                                 minimap_sym_height_down_size(conf(new IntSliderEditableValue(7, 6, 36, "height_down_symbol_size_itm"))) {
    minimap_module_self = this;

    // Keep the general minimap controls through Bot Corpse Color, but hide
    // the Map Display section and every setting that follows it.
    /*ConfigValue* hidden_values[] = {
            section_map_, radar_minimap, radar_minimap_style, radar_minimap_rotate,
            radar_minimap_grid, radar_minimap_grid_opacity, radar_minimap_compass,
            radar_minimap_backdrop, radar_minimap_backdrop_color, radar_minimap_opacity,
            section_layout_, radar_minimap_corner, radar_size, radar_range,
            radar_margin_x, radar_margin_y, section_text_, minimap_text_font_size,
            minimap_marker_outline, section_symbols_, minimap_sym_player,
            minimap_sym_player_size, minimap_sym_entity, minimap_sym_entity_size,
            minimap_sym_quest, minimap_sym_quest_size, minimap_sym_exfil,
            minimap_sym_exfil_size, minimap_sym_transit, minimap_sym_transit_size,
            minimap_sym_height_up, minimap_sym_height_up_size, minimap_sym_height_down,
            minimap_sym_height_down_size,
        };
        for (ConfigValue* value : hidden_values)
            value->set_hidden_in_owner_menu(true);

        radar_minimap_bot_corpse_color->set_hidden_in_owner_menu(true);*/
}

void MinimapModule::init() {
    radar->set_master_toggle(true);

    // These controls are hidden in the streamlined menu. Keep the map
    // visible and anchored in the upper-right on every fresh startup.
    radar_minimap->set_value(true);
    radar_minimap_corner->set_value(1);
    radar_margin_x->set_value(24.f);
    radar_margin_y->set_value(24.f);
}

void MinimapModule::prepare_menu_draw() {
    const auto dis = [](ConfigValue* v, const bool disabled) { v->set_disabled(disabled); };
    const bool radar_on = radar->get_value();

    section_general_->set_section_active(radar_on);
    dis(radar_exfils, !radar_on);
    dis(radar_minimap_quest_esp, !radar_on);
    dis(radar_minimap_quest_names, !radar_on || !radar_minimap_quest_esp->get_value());
    dis(radar_minimap_bots, !radar_on);
    dis(radar_minimap_bot_names, !radar_on || !radar_minimap_bots->get_value());
    dis(radar_minimap_bot_corpses, !radar_on);
    dis(radar_minimap_bot_corpse_color, !radar_on || !radar_minimap_bot_corpses->get_value());

    section_map_->set_section_active(radar_on);
    dis(radar_minimap, !radar_on);
    dis(radar_minimap_style, !radar_on);
    dis(radar_minimap_rotate, !radar_on);
    dis(radar_minimap_grid, !radar_on);
    dis(radar_minimap_grid_opacity, !radar_on || !radar_minimap_grid->get_value());
    dis(radar_minimap_compass, !radar_on);
    dis(radar_minimap_backdrop, !radar_on);
    dis(radar_minimap_backdrop_color, !radar_on || !radar_minimap_backdrop->get_value());
    dis(radar_minimap_opacity, !radar_on);
    dis(radar_minimap_static_markers, !radar_on);
    dis(radar_minimap_labels, !radar_on || !radar_minimap_static_markers->get_value());

    section_layout_->set_section_active(radar_on);
    dis(radar_minimap_corner, !radar_on);
    dis(radar_size, !radar_on);
    dis(radar_range, !radar_on);
    dis(radar_margin_x, !radar_on);
    dis(radar_margin_y, !radar_on);

    section_text_->set_section_active(radar_on);
    dis(minimap_text_font_size, !radar_on);
    dis(minimap_marker_outline, !radar_on);

    section_symbols_->set_section_active(radar_on);
    dis(minimap_sym_player, !radar_on);
    dis(minimap_sym_player_size, !radar_on);
    dis(minimap_sym_entity, !radar_on);
    dis(minimap_sym_entity_size, !radar_on);
    dis(minimap_sym_quest, !radar_on);
    dis(minimap_sym_quest_size, !radar_on);
    dis(minimap_sym_exfil, !radar_on);
    dis(minimap_sym_exfil_size, !radar_on);
    dis(minimap_sym_transit, !radar_on);
    dis(minimap_sym_transit_size, !radar_on);
    dis(minimap_sym_height_up, !radar_on);
    dis(minimap_sym_height_up_size, !radar_on);
    dis(minimap_sym_height_down, !radar_on);
    dis(minimap_sym_height_down_size, !radar_on);
}

void MinimapModule::draw_overlay(ImDrawList*) {
}

void MinimapModule::application_update() {
}

void MinimapModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance,
    Il2CppObjectInstance) {
}
