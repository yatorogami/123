#pragma once

#include "PlayerModule.h"

// Presents the existing experience and skill controls separately from trader
// reputation controls, without changing their implementation or persistence.
class ExperienceEditorModule final : public Module
{
  public:
    explicit ExperienceEditorModule(PlayerModule* player);

    void draw_overlay(ImDrawList*) override;
    void application_update() override;
    void gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) override;
    void init() override;
    [[nodiscard]] bool draw_menu_extra_before_values() const override;
    void draw_menu_extra() override;

  private:
    PlayerModule* player_ = nullptr;
    std::vector<ConfigValue*> values_;
};
