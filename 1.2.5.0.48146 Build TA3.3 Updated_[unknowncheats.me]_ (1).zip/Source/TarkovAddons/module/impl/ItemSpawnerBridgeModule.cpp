#include "common.h"
#include "ItemSpawnerBridgeModule.h"

ItemSpawnerBridgeModule::ItemSpawnerBridgeModule(ItemModule* items) : Module("Item Spawner (Weapon Builder)", WeaponBuilder, "item_spawner_mod"), items_(items) {}

void ItemSpawnerBridgeModule::draw_overlay(ImDrawList*) {}

void ItemSpawnerBridgeModule::application_update() {}

void ItemSpawnerBridgeModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) {}

void ItemSpawnerBridgeModule::init() {}

[[nodiscard]] bool ItemSpawnerBridgeModule::draw_menu_extra_before_values() const { return true; }

void ItemSpawnerBridgeModule::draw_menu_extra() {
    if (!items_) return;
    items_->apply([](ConfigValue* value) {
        if (!value->is_hidden_in_owner_menu()) value->draw();
    });
}
