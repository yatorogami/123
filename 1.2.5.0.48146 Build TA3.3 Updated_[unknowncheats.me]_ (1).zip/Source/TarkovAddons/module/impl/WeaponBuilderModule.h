#pragma once

#include <algorithm>
#include <string>
#include <vector>

#include <imgui.h>

#include "../Module.h"
#include "../ModuleCategory.h"
#include "../QueuedAction.h"
#include "../game_state.h"
#include "../eft_api.h"
#include "InventoryEditorModule.h"
#include "../../config/FloatSliderEditableValue.h"
#include "../../config/ItemSearchValue.h"
#include "../../il2cpp/Il2CppObjectInstance.h"
#include "../../il2cpp/exports.h"
#include "../../gui/menu/imgui_addons.h"
#include "../../util/logger.h"

// Builds a weapon directly from its live attachment slots. The existing
// ItemModule compatibility hooks permit deliberately non-standard attachments.
class WeaponBuilderModule final : public Module
{
  public:
    explicit WeaponBuilderModule(InventoryEditorModule* editor);

    void draw_overlay(ImDrawList*) override;
    void application_update() override;
    void init() override;

    void draw_menu_extra() override;

    void gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance main_player) override;

  private:
    struct weapon_entry
    {
        std::string id;
        std::string label;
    };
    struct slot_entry
    {
        std::string id;
        std::string label;
    };
    // Outcome of an enchantment / durability action, for the label under its button.
    struct action_result
    {
        std::string message;
        bool success = false;
    };

    std::vector<weapon_entry> weapons_;
    std::vector<slot_entry> slots_;
    int selected_weapon_ = -1;
    int selected_slot_ = -1;
    QueuedAction refresh_action_;
    QueuedAction inspect_action_;
    QueuedAction install_action_;
    InventoryEditorModule* editor_ = nullptr;
    int enchantment_rarity_ = 0;
    // 1-100, matching BuffComponent's System.Double fields (see
    // InventoryEditorModule::enchantment_percent) and the in-game ceiling. These
    // were previously free-text ints bounded at 400 here and 8000 in the editor,
    // so the same request could arrive with wildly different values depending on
    // which card sent it.
    FloatSliderEditableValue* enchantment_percent;
    FloatSliderEditableValue* threshold_amount;
    // The two buff types whose modifier field is read by WEAPON-side code. Every
    // consumer of BuffComponent's three derived fields was traced:
    //
    //   <WeaponSpread>         +0x40  Weapon.GetBarrelDeviation(),
    //                                 Weapon.<.ctor>b__105_6, FirearmController.Shot()
    //   <MalfunctionProtections> +0x50 FirearmController.GetTotalMalfunctionChance()
    //   <DamageReduction>      +0x48  ArmorComponent.ApplyDamage()   <-- ARMOR ONLY
    //
    // So the three implemented types are partitioned by item domain, and this card is
    // weapon-only (refresh_weapons and resolve_external_weapon both gate on
    // is_weapon). DamageReduction belongs to the Item Editor's gear card, which
    // targets ArmoredEquipment.Armor -> ArmorComponent.Buff -- exactly where
    // ApplyDamage reads it.
    //
    // Cut from this list: DamageReduction (armor-only, see above), plus WeaponDamage(3),
    // ArmorEfficiency(4) and DurabilityImprovement(5), which have no modifier field
    // and no EItemAttributeId at all -- UpdateModifiers sends them to a `default:`
    // branch that calls ResetEnhancedAttribute and returns. See
    // BUFFCOMPONENT_NOTES.md. Re-add an entry only if BSG gives the type a
    // representation on the weapon side.
    const char* enchantments_[2] = {"Weapon Spread", "Malfunction Protection"};
    // Combo index -> ERepairBuffType. These are NOT the same numbers:
    // MalfunctionProtections is 2 in the enum but sits at index 1 here. Passing the
    // combo index straight through used to work only because the list used to be
    // every value in gapless enum order; with a gap in the list that silently sent
    // index 1 to enum 1 (DamageReduction) instead.
    int enchantment_type_values_[2] = {
        0, /*WeaponSpread*/ 2 /*MalfunctionProtections*/};
    int enchantment_type_selection_ = 0;
    const char* rarities_[2] = {"Common", "Rare"};
    std::string status_;
    action_result enchantment_result_;
    action_result durability_result_;
    unsigned long long last_external_serial_ = 0;
    // Spawn path: quest items are hidden (the Quest Completer spawns those itself).
    ItemSearchValue* selected_item_;

    bool has_selected_weapon() const;
    bool has_selected_slot() const;

    // Copy the Item Editor's published outcome into this card's labels.
    //
    // The two actions are executed by InventoryEditorModule on the game thread, so
    // the click itself carries no outcome — the editor is what discovers whether the
    // weapon still exists, is still a weapon, and whether the write landed. The serial
    // is the change signal: diffing message text would miss a repeated identical
    // result, and re-reading every frame would be pointless work on a per-frame path.
    void pull_editor_results();

    static std::string call_string(Il2CppObject* object, const char* method);
    static std::string item_id(Il2CppObject* item);
    static std::string template_id(Il2CppObject* item);
    static bool is_weapon(Il2CppObject* item);
    static std::string database_name(const std::string& id);
    static Il2CppObject* find_tree_item(Il2CppObject* item, const std::string& wanted, int depth = 0);
    static Il2CppObject* find_backpack_item(Il2CppObjectInstance player, const std::string& wanted);

    void refresh_weapons(Il2CppObjectInstance player);

    void inspect_slots(Il2CppObjectInstance player);

    void install_selected_item(Il2CppObjectInstance player);

    void clear_queues();
};
