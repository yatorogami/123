#pragma once

#include <algorithm>

#include "QuestModule.h"
#include "../../config/ActionRowValue.h"
#include "../../config/SelectValue.h"

// UI-only companion to QuestModule.  Keeping reset in its own module gives it
// a separate card without duplicating the quest runtime access code.
class QuestResetModule : public Module
{
  public:
    explicit QuestResetModule(QuestModule* quest_module);

    TextboxValue* completed_search_;
    SelectValue* completed_quests_;
    ActionRowValue* reset_;

    std::vector<std::string> filtered_completed_ids_ = {};

    void prepare_menu_draw() override;

    void draw_overlay(ImDrawList*) override;
    void application_update() override;
    void gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) override;
    void init() override;

  private:
    QuestModule* quest_module_ = nullptr;
};
