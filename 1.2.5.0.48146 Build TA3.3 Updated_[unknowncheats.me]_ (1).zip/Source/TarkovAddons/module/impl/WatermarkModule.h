#pragma once
#include "../Module.h"
#include "../../config/IntSliderEditableValue.h"
#include "../ModuleCategory.h"
#include "../../config/CheckboxValue.h"
#include "../../config/ColorpickerValue.h"
#include "../../config/TextboxValue.h"
#include "../../util/globals.h"

class WatermarkModule : Module
{
  public:
    WatermarkModule();

    CheckboxValue* enabled;
    TextboxValue* text;
    ColorpickerValue* color;
    IntSliderEditableValue* font_size;

    void draw_overlay(ImDrawList* draw_list) override;

    void application_update() override;

    void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
        Il2CppObjectInstance main_player) override;

    void init() override;

    void prepare_menu_draw() override;
};