#include "common.h"
#include "MapModule.h"
#include "EspModule.h"
#include "../game_state.h"
#include "../eft_api.h"
#include "../../gui/menu/menu.h"

#include <algorithm>
#include <cctype>
#include <vector>

MapModule::MapModule(EspModule* esp)
    : Module("Big Map", MapStuff, "big_map_mod"),
      section_view_(conf(new MenuSectionValue("view_sec"))),
      big_map(conf(new CheckboxValue(false, "big_map_cb"))),
      big_map_zoom(conf(new FloatSliderEditableValue(1.f, 1.f, 8.f, "big_map_zoom_itm"))),
      big_map_quest(conf(new CheckboxValue(true, "big_map_quest_cb"))),
      big_map_exfils(conf(new CheckboxValue(true, "big_map_exfils_cb"))),
      big_map_players(conf(new CheckboxValue(true, "big_map_players_cb"))),
      big_map_static(conf(new CheckboxValue(true, "big_map_static_cb"))),
      big_map_location(conf(new SelectValue(kFollowLocationIndex, std::vector<const char*>{"big_map_loc_current"},
          "big_map_loc_itm", false, true))),
      big_map_loc_note(conf(new InfoDrawValue([]() {
          imgui_addons::status_line(i18n::tr("big_map_loc_raid_locked"));
      }, "big_map_loc_note"))),
      esp_(esp) {
}

void MapModule::init() {
}

void MapModule::application_update() {
    // Deliberately empty, and the reason it exists rather than being absent:
    // ModuleManager::apply() walks the interface, and an override that does
    // nothing is still part of the contract. The big map is a RENDER-thread
    // feature -- everything it needs is either read inside draw_overlay (the map
    // itself) or was captured on the game thread by gameworld_update (the
    // player's position), so there is nothing for a per-frame main-thread tick
    // to do.
}

// -----------------------------------------------------------------------------
// Location picker
// -----------------------------------------------------------------------------

// A friendly name for one config id. In a raid the game's own localised name is
// better than anything derivable from an id ("bigmap" -> "Customs"), but
// try_get_location_display_name needs the game's location settings, which do not
// exist out of raid -- so outside one it returns empty and the prettified id is
// the fallback rather than a blank row in the drop-down.
static std::string map_display_label(const std::string& id) {
    if (const std::string localized = eft_api::try_get_location_display_name(id); !localized.empty())
        return localized;

    std::string label = id;
    for (char& ch : label)
        if (ch == '-' || ch == '_')
            ch = ' ';
    if (!label.empty())
        label[0] = static_cast<char>(toupper(static_cast<unsigned char>(label[0])));
    return label;
}

// The config ids, sorted.
//
// SORTED, and that is load-bearing rather than cosmetic: scan_configs()
// enumerates a directory, directory order is not stable between runs, and the
// picker stores an INDEX. An unsorted list would mean that saving a config and
// returning to the stash shows a different map.
//
// Returned by value so the render thread holds its own copy of the ids rather
// than pointers into a set the game thread may replace mid-iteration.
static std::vector<std::string> sorted_config_ids() {
    const minimap::config_set_ptr configs = minimap::current_configs();
    std::vector<std::string> ids;
    ids.reserve(configs->items.size());
    for (const auto& item : configs->items)
        if (item && !item->id.empty())
            ids.push_back(item->id);
    std::sort(ids.begin(), ids.end());
    return ids;
}

void MapModule::refresh_location_options() {
    const minimap::config_set_ptr configs = minimap::current_configs();
    // Rebuilt whenever the SET changes, not once per process. A one-shot flag
    // would leave the picker holding indices into a list that no longer exists
    // after a config reload -- the stored pick would still be in range, so
    // nothing would complain, and it would just quietly be a different map.
    if (location_options_built_ && options_built_from_ == configs)
        return;

    // Index 0 is the sentinel "the map I am in", so a pick survives the raid it
    // was made in and the list does not gain an entry when you walk into a map
    // that was not there before.
    std::vector<std::string> labels;
    labels.push_back(i18n::tr("big_map_loc_current"));
    for (const std::string& id : sorted_config_ids())
        labels.push_back(map_display_label(id));

    // set_options COPIES into SelectValue's own option_storage_, so these
    // pointers only have to outlive the call. The labels vector below is
    // therefore local rather than a member -- keeping it alive would be a leak
    // with no benefit.
    std::vector<const char*> options;
    options.reserve(labels.size());
    for (const std::string& label : labels)
        options.push_back(label.c_str());

    big_map_location->set_options(options);
    options_built_from_ = configs;
    location_options_built_ = true;
}

std::string MapModule::location_for_index(const int index) const {
    if (index == kFollowLocationIndex)
        return current_location_id_;

    // Re-derive the SAME order refresh_location_options built its list from
    // rather than caching a parallel vector of ids beside the options. Two lists
    // that must agree is exactly the kind of thing that agrees until the set
    // changes and then silently does not.
    const std::vector<std::string> ids = sorted_config_ids();
    if (index < 1 || static_cast<size_t>(index) > ids.size())
        return {};
    return ids[static_cast<size_t>(index) - 1];
}

void MapModule::sync_shown_location() {
    // IN A RAID THE PICKER IS IGNORED, and that is a property of the architecture
    // rather than a restriction invented here: minimap::active_map() is ONE
    // global loaded map, and EspModule::draw_radar_overlay() re-requests the
    // player's own location every single frame. A second map cannot be loaded
    // alongside it, so honouring the picker mid-raid would produce a big map of
    // Woods with Customs' extracts and players drawn on it -- confidently wrong,
    // which is worse than a control that visibly does not apply. Loading a second
    // map means giving active_map() per-view state, the SVG/tile caches and the
    // reload handshake, and that is its own piece of work.
    const bool in_raid = game_state::is_in_raid.load(std::memory_order_relaxed);
    const std::string wanted = in_raid ? current_location_id_
                                       : location_for_index(big_map_location->get_value());
    if (wanted == shown_location_)
        return;

    shown_location_ = wanted;
    // The view belongs to the map that is leaving: centre, follow flag and zoom
    // baseline are all in that map's coordinates.
    center_u_ = 0.5f;
    center_v_ = 0.5f;
    follow_player_ = true;
    has_last_centered_pos_ = false;
    dragging_ = false;
    // A floor pick is an index into ONE map's overlay_layers -- carrying it over
    // would point at an unrelated layer or land out of range.
    minimap::clear_floor_override();
}

void MapModule::prepare_menu_draw() {
    const bool on = big_map->get_value();
    section_view_->set_section_active(on);
    big_map_zoom->set_disabled(!on);
    big_map_quest->set_disabled(!on);
    big_map_exfils->set_disabled(!on);
    big_map_players->set_disabled(!on);
    big_map_static->set_disabled(!on);
    // The picker is disabled IN A RAID, not just when the map is off, so the
    // disabled state is the reason it will not take the pick rather than the
    // user discovering it by pressing one and seeing nothing happen. The note
    // row below it says why; see sync_shown_location().
    const bool in_raid = game_state::is_in_raid.load(std::memory_order_relaxed);
    big_map_location->set_disabled(!on || in_raid);
    big_map_loc_note->set_disabled(!on);
}

void MapModule::gameworld_update(const Il2CppClass* game_world_class,
    Il2CppObjectInstance game_world_instance,
    Il2CppObjectInstance main_player) {
    if (!configs_scanned_) {
        // EspModule does this too, behind its own flag. It is a directory scan,
        // so the second call is wasted work at worst -- and without it this
        // module draws nothing at all whenever the ESP card is off.
        minimap::scan_configs();
        configs_scanned_ = true;
    }

    const std::string previous = current_location_id_;
    current_location_id_ = eft_api::read_location_id(game_world_class, game_world_instance);
    if (current_location_id_ != previous)
    {
        // EspModule's own reset, and the reason this module needs one too: the
        // player dot must not be drawn at the last raid's coordinates in the
        // frame between the location changing and the first fresh transform.
        player_pos_ = {};
        has_player_pos_ = false;
        has_last_centered_pos_ = false;
    }

    // The player transform. This was the whole reason the big map's dot sat at
    // the world origin for its first increment: gameworld_update took main_player
    // as [[maybe_unused]] and nothing ever assigned player_pos_, so every draw
    // read the default-constructed zero vector -- which is a legal position on
    // Customs, and therefore looked like a position rather than like no data.
    if (main_player.get_instance())
    {
        Il2CppObject* player_go = unity::component_get_game_object(main_player.get_instance());
        Il2CppObject* player_transform = player_go ? unity::gameobject_get_transform(player_go) : nullptr;
        if (player_transform)
        {
            player_pos_ = unity::transform_get_pos(player_transform);
            has_player_pos_ = true;
        }
    }
}

// -----------------------------------------------------------------------------
// Input
// -----------------------------------------------------------------------------

void MapModule::handle_map_input(const ImVec2& origin, const float side,
    const minimap::map_view_transform* view, const unity::vector3& player_pos) {
    ImGuiIO& io = ImGui::GetIO();
    const ImVec2 mouse = io.MousePos;
    const bool hovered = mouse.x >= origin.x && mouse.x <= origin.x + side &&
                         mouse.y >= origin.y && mouse.y <= origin.y + side;

    // Re-centre on the player when they have walked a radar's width away from
    // wherever the map was last centred. Same rule the radar uses, so panning
    // until you lose yourself behaves identically on both views.
    if (follow_player_ && has_player_pos_ && has_last_centered_pos_)
    {
        constexpr float recentre_range = 75.f;
        const float dx = player_pos.x - last_centered_player_pos_.x;
        const float dz = player_pos.z - last_centered_player_pos_.z;
        if (dx * dx + dz * dz > recentre_range * recentre_range)
            follow_player_ = false;
    }
    if (follow_player_ && has_player_pos_)
    {
        last_centered_player_pos_ = player_pos;
        has_last_centered_pos_ = true;
    }

    if (!hovered)
    {
        dragging_ = false;
        return;
    }

    // Wheel zoom multiplies the SLIDER rather than replacing it, so the slider
    // stays the baseline the user can set once and the wheel is the per-raid
    // adjustment. Clamped to the slider's own ceiling so the two cannot disagree
    // about the maximum.
    if (io.MouseWheel != 0.f)
    {
        const float current = (std::max)(1.f, big_map_zoom->get_value());
        const float next = (std::max)(1.f, (std::min)(8.f, current * (1.f + io.MouseWheel * 0.15f)));
        if (next != current)
            big_map_zoom->set_value(next);
    }

    if (!view || view->map_w <= 1.f || view->map_h <= 1.f)
    {
        dragging_ = false;
        return;
    }

    if (io.MouseDown[0])
    {
        if (!dragging_)
        {
            dragging_ = true;
            drag_last_ = mouse;
        }
        else
        {
            const ImVec2 uv_last = minimap::screen_to_map_uv(*view, drag_last_);
            const ImVec2 uv_now = minimap::screen_to_map_uv(*view, mouse);
            drag_last_ = mouse;
            // A drag of any real length means the user is looking at something
            // other than the player, so stop re-centring under them. The
            // threshold stops a stray click from unpinning the map.
            constexpr float drag_threshold = 4.f;
            if (fabsf(uv_now.x - uv_last.x) > 0.004f || fabsf(uv_now.y - uv_last.y) > 0.004f)
                follow_player_ = false;
            center_u_ += uv_last.x - uv_now.x;
            center_v_ += uv_last.y - uv_now.y;
        }
    }
    else
    {
        dragging_ = false;
    }
}

// -----------------------------------------------------------------------------
// Floor controls
// -----------------------------------------------------------------------------

void MapModule::draw_floor_controls(const float side, const std::string& map_label) {
    const std::shared_ptr<const minimap::map_config> cfg =
        shown_location_.empty() ? nullptr : minimap::find_config(shown_location_);

    // ImGuiStyleVar is a UNION in 1.92, so the {var, value} brace form that
    // older ImGui accepted does not initialise one. Two scalar pushes instead.
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(6.f, 4.f));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(6.f, 4.f));
    if (ImGui::BeginChild("##big_map_floor_bar", ImVec2(side, 0.f), ImGuiChildFlags_None,
            ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse))
    {
        // "Auto" is the DEFAULT state, so the button only exists once there is an
        // override to drop. Showing it greyed otherwise is how the user tells
        // "this map has no manual floor" apart from "I have not chosen one" --
        // get_minimap_floor_label() underneath it answers both the same way.
        const std::string floor_label =
            minimap::has_floor_override()
                ? minimap::floor_cycle_label(*cfg, minimap::manual_floor_index())
                : i18n::tr("big_map_floor_follow");
        if (!map_label.empty())
            ImGui::Text("%s  |  %s", map_label.c_str(), floor_label.c_str());
        else
            ImGui::Text("%s", floor_label.c_str());

        ImGui::SameLine();
        if (ImGui::Button(i18n::tr("big_map_floor_prev").c_str()))
            minimap::cycle_manual_floor(*cfg, -1);
        ImGui::SameLine();
        if (ImGui::Button(i18n::tr("big_map_floor_next").c_str()))
            minimap::cycle_manual_floor(*cfg, +1);
        ImGui::SameLine();
        if (minimap::has_floor_override())
        {
            if (ImGui::Button(i18n::tr("big_map_floor_follow").c_str()))
                minimap::clear_floor_override();
        }
        else
        {
            ImGui::TextDisabled("%s", i18n::tr("big_map_floor_follow").c_str());
        }
        ImGui::SameLine();
        if (follow_player_)
            ImGui::TextDisabled("%s", i18n::tr("big_map_centre_me").c_str());
        else if (ImGui::Button(i18n::tr("big_map_centre_me").c_str()))
        {
            follow_player_ = true;
            has_last_centered_pos_ = false;
        }
    }
    ImGui::EndChild();
    ImGui::PopStyleVar(2);
    // two scalars pushed above, two popped here

    if (!cfg)
        return;

    // Keyboard equivalents, for a user who does not want to reach for the mouse.
    // Comma/period rather than the arrow keys: the arrow keys are ImGui's
    // navigation keys and would move focus instead of changing floors. Gated on
    // the map window being hovered, because these are bare key reads rather than
    // widget ones and would otherwise fire while the user was in the menu.
    if (!ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows))
        return;
    if (ImGui::IsKeyPressed(ImGuiKey_Comma, false))
        minimap::cycle_manual_floor(*cfg, -1);
    if (ImGui::IsKeyPressed(ImGuiKey_Period, false))
        minimap::cycle_manual_floor(*cfg, +1);
    if (ImGui::IsKeyPressed(ImGuiKey_Backslash, false))
        minimap::clear_floor_override();
}

// -----------------------------------------------------------------------------
// Overlay
// -----------------------------------------------------------------------------

void MapModule::draw_overlay([[maybe_unused]] ImDrawList* draw_list) {
    if (!big_map->get_value()) return;

    if (!configs_scanned_)
    {
        // draw_overlay is reachable before the first raid's gameworld_update, so
        // the picker cannot wait for that call to run: the drop-down would be
        // empty until the user had been in a raid once.
        minimap::scan_configs();
        configs_scanned_ = true;
    }
    refresh_location_options();
    sync_shown_location();

    // Out of raid there is no location to resolve, but that is exactly what the
    // picker is for: browsing a map you are not in. With nothing picked and
    // nothing to fall back on, there is no honest map to show.
    const std::string& location = shown_location_;
    if (location.empty()) return;

    if (location != last_requested_location_) {
        minimap::request_active_map(location);
        last_requested_location_ = location;
    }

    const unity::vector3 view_player_pos = player_pos_;
    const bool have_player_pos = has_player_pos_;

    const minimap::map_floor* floor = nullptr;
    minimap::map_bounds bounds{};
    minimap::map_view_transform view{};
    uint32_t map_w = 0;
    uint32_t map_h = 0;
    // get_active_floor re-derives the active layers from the player position, so
    // it is given the real one and the manual override is applied inside it. With
    // no position yet (out of raid, or the frame before the first transform) it
    // is given the origin, which only matters for which overlay is picked by
    // default -- the manual override still wins.
    if (!minimap::get_active_floor(view_player_pos.x, view_player_pos.y, view_player_pos.z, floor) || !floor ||
        !minimap::is_map_ready() || !minimap::get_active_display_bounds(bounds) ||
        !minimap::get_map_size(map_w, map_h))
        return;

    const float world_w = bounds.max_x - bounds.min_x;
    const float world_h = bounds.max_z - bounds.min_z;
    if (world_w <= 0.f || world_h <= 0.f) return;

    const ImVec2 display = ImGui::GetIO().DisplaySize;
    // ~90% of the smaller dimension, as the plan asks (plan 4.3). Centred and
    // sized ONCE: ImGuiCond_Once, so the user's own resize afterwards sticks and
    // is not fought every frame.
    const float side = (std::min)(display.x, display.y) * 0.9f;
    const ImVec2 window_pos{(display.x - side) * 0.5f, (display.y - side) * 0.5f};

    ImGui::SetNextWindowPos(window_pos, ImGuiCond_Once);
    ImGui::SetNextWindowSize(ImVec2(side, side), ImGuiCond_Once);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));

    // NoMove is what makes the map itself pannable by drag: the window cannot be
    // dragged off screen, so a left-drag over the map is unambiguously a pan.
    const ImGuiWindowFlags flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar |
                                   ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoResize |
                                   ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoBringToFrontOnFocus;

    if (!ImGui::Begin("##big_map", nullptr, flags)) {
        ImGui::End();
        ImGui::PopStyleVar();
        return;
    }

    ImDrawList* window_draw = ImGui::GetWindowDrawList();
    const ImVec2 origin = ImGui::GetWindowPos();
    const ImVec2 size = ImGui::GetWindowSize();

    // Fit the WHOLE map, not a radius around the player. build_map_view takes
    // "metres from centre to the edge", so half the larger world extent is what
    // makes the larger axis exactly fill the window -- and dividing by the zoom
    // is then just a smaller window onto the same map.
    const float zoom = (std::max)(1.f, big_map_zoom->get_value());
    const float fit_range = 0.5f * (std::max)(world_w, world_h) / zoom;

    // Follow the player unless the user has panned away. Recomputed every frame
    // rather than cached, because build_map_view needs the centre BEFORE the view
    // exists and the view is what the pan maths inverts.
    float center_u = center_u_;
    float center_v = center_v_;
    if (follow_player_)
    {
        if (have_player_pos)
        {
            float player_u = 0.5f;
            float player_v = 0.5f;
            if (minimap::world_to_uv(bounds, view_player_pos.x, view_player_pos.z, player_u, player_v))
            {
                center_u = player_u;
                center_v = player_v;
                center_u_ = player_u;
                center_v_ = player_v;
            }
        }
        else
        {
            center_u = 0.5f;
            center_v = 0.5f;
        }
    }

    // The floor bar is a child window, so it shrinks the drawable area below it.
    const float floor_bar_h = 26.f * menu::get_scale_factor();
    const float map_side = (std::min)(size.x, size.y) - floor_bar_h;

    if (minimap::build_map_view(bounds, map_w, map_h, origin.x, origin.y + floor_bar_h, map_side, center_u,
            center_v, fit_range, 0.f, false, view)) {
        window_draw->PushClipRect(origin, {origin.x + size.x, origin.y + size.y}, true);
        minimap::draw_active_map(window_draw, view);

        // The player, so an unzoomed map is not just a picture. Direction comes
        // from the camera yaw when it resolves; without it the dot points north,
        // which is honest rather than wrong.
        ImVec2 player_point{};
        if (have_player_pos && minimap::world_to_map_point(bounds, view_player_pos.x, view_player_pos.z, view, player_point)) {
            const ImU32 tint = IM_COL32(255, 255, 255, 235);
            window_draw->AddCircleFilled(player_point, 5.f, tint);
            window_draw->AddCircle(player_point, 5.f, IM_COL32(0, 0, 0, 200), 8, 1.5f);
        }

        if (esp_)
        {
            EspModule::big_map_marker_context ctx;
            ctx.draw_list = window_draw;
            ctx.bounds = bounds;
            ctx.view = view;
            ctx.clip_min = origin;
            ctx.clip_max = {origin.x + size.x, origin.y + size.y};
            ctx.player_pos = view_player_pos;
            ctx.show_quest = big_map_quest->get_value();
            ctx.show_quest_names = true;
            ctx.show_exfils = big_map_exfils->get_value();
            ctx.show_players = big_map_players->get_value();
            ctx.show_player_names = big_map_players->get_value();
            ctx.show_corpse = false;
            ctx.show_static_markers = big_map_static->get_value();
            ctx.show_labels = big_map_static->get_value();
            esp_->draw_big_map_markers(ctx, location);
        }
        window_draw->PopClipRect();

        handle_map_input({origin.x, origin.y + floor_bar_h}, map_side, &view, view_player_pos);
    } else {
        window_draw->AddRectFilled(origin, {origin.x + size.x, origin.y + size.y},
            IM_COL32(16, 18, 22, 190));
    }

    const std::string label = minimap::get_minimap_floor_label();
    draw_floor_controls(map_side, label);

    ImGui::End();
    ImGui::PopStyleVar();
}