#include "common.h"
#include "AimbotModule.h"

// Read-only grenade throw probe (2026-10-04). Reads the cached launch vector off
// the player's grenade hands controller once per frame and reports it; it does
// not modify anything. See grenade_throw_probe.h for why this polls fields
// instead of hooking ThrowGrenade, and what phase 2 would be.
#include "../grenade_throw_probe.h"

// Mirrors the guard on AimbotModule.h. Without it this file would try to define
// methods of a class that the header had just made invisible, and the no-aimbot
// configuration would stop compiling rather than simply shipping less code.
#ifdef INCLUDE_AIMBOT

/// Constructor for AimbotModule
AimbotModule::AimbotModule() : Module("Aimbot", Exploit, "aimbot_mod"),
                               aim_type(conf(new SelectValue(0, {"none_sel", "magic_bullet_sel", "magic_aim_sel", "aimbot_sel"}, "aim_type_sel"))),
                               show_target(conf(new CheckboxValue(true, "show_target_cb"))),
                               target_size(conf(new FloatSliderEditableValue(3, 1, 10, "target_size_itm"))),
                               target_opacity(conf(new FloatSliderEditableValue(1.0f, 0.0f, 1.0f, "target_opacity_itm"))),
                               max_distance(conf(new FloatSliderEditableValue(200.f, 20.f, 1500.f, "max_distance_itm"))),
                               aim_cone(conf(new FloatSliderEditableValue(30.f, 0.f, 100.f, "aim_cone_itm"))),
                               show_cone(conf(new CheckboxValue(false, "show_cone_cb"))),
                               cone_color(conf(new ColorpickerValue({0.f, 1.f, 1.f, 1.f}, "cone_color_clr"))),
                               cone_opacity(conf(new FloatSliderEditableValue(0.35f, 0.f, 1.f, "cone_opacity_itm"))),
                               aim_smoothness(conf(new FloatSliderEditableValue(3.0f, 0.0f, 10.0f, "aim_smoothness_itm"))),
                               velocity_tracking(conf(new CheckboxValue(false, "velocity_tracking_cb"))),
                               wall_check(conf(new CheckboxValue(false, "wall_check_cb"))),
                               target_color(conf(new ColorpickerValue({1, 0, 1, 1}, "target_color_clr"))),
                               aim_bone(conf(new SelectValue(0,
                                   {
                                       "aim_bone_head_sel",
                                       "aim_bone_neck_sel",
                                       "aim_bone_chest_sel",
                                       "aim_bone_pelvis_sel",
                                       "aim_bone_l_shoulder_sel",
                                       "aim_bone_r_shoulder_sel",
                                       "aim_bone_l_hand_sel",
                                       "aim_bone_r_hand_sel",
                                       "aim_bone_l_thigh_sel",
                                       "aim_bone_r_thigh_sel",
                                       "aim_bone_l_calf_sel",
                                       "aim_bone_r_calf_sel",
                                       "aim_bone_l_foot_sel",
                                       "aim_bone_r_foot_sel",
                                   },
                                   "aim_bone_sel", /*translate_options=*/true))) {
    target_size->set_hidden_in_owner_menu(true);
    target_color->set_hidden_in_owner_menu(true);
    target_opacity->set_hidden_in_owner_menu(true);
}

void AimbotModule::draw_overlay(ImDrawList *draw_list) {
    // Render-thread sibling of frame::EspModule::draw_overlay, same reason.
    TA_ZONE_N("frame::AimbotModule::draw_overlay");
    // no aimbot outside of raid
    if (!game_state::is_in_raid)
        return;

    // Selection cone, behind its own option. Same three conditions as the pick
    // itself -- in a raid (checked above), an aim type selected, and a non-zero
    // cone -- because a radius-0 circle is a dot on the crosshair, which is noise
    // rather than information.
    //
    // Outline, not filled: at 30% of screen height a filled disc tints the middle
    // of the screen, which is where the reticle and every target's head are, and
    // this overlay draws OVER the ESP rather than under it.
    if (show_cone->get_value() && aim_type->get_value() != 0)
    {
        const float radius = aim_cone_radius();
        if (radius > 0.f)
        {
            // cone_tint(), NOT target_tint(). These were one control until this
            // change; the cone is a large low-contrast guide and the target is a
            // small high-contrast marker, and they want opposite settings.
            draw_list->AddCircle(
                {menu::get_width() / 2.f, menu::get_height() / 2.f}, radius,
                ImGui::GetColorU32(cone_tint()), 0, 2.0f);
        }
    }

    // show target — project via optic cam when ADS (matches reticle /
    // ESP-in-optic)
    if (show_target->get_value() && (aim_type->get_value() != 0))
    {
        if (!(target_store.x == 0 && target_store.y == 0)) // NOLINT(clang-diagnostic-float-equal)
        {
            // Dual ADS: no fake zoom on rear plane; optic only inside the mask.
            const unity::vector3 screen_pos = eft_api::world_to_screen_aim_marker(
                target_store, game_state::current_zoom,
                game_state::esp_optic_user_scale);
            if (eft_api::is_visible(screen_pos))
            {
                draw_list->AddCircleFilled(
                    {screen_pos.x, screen_pos.y},
                    target_size->get_value() * menu::get_scale_factor(),
                    ImGui::GetColorU32(target_tint()));
            }
        }
    }
}

void AimbotModule::application_update() {
    // Zoned 2026-10-04; this function had no zone at all.
    //
    // It is the aimbot's per-update entry point and the only place its state is
    // CLEARED when the raid ends. That makes it load-bearing for the exact question
    // another workstream is chasing -- `target_store`, `player_pos`, `fireport_pos`,
    // `local_player_store` and `target_objects` are all reset here, and only here,
    // on `!is_in_raid`. If the flag lags teardown, this is the code that has to keep
    // running past the point where the objects it holds are being destroyed, and
    // until now a capture could not show that happening because nothing here was
    // measured.
    TA_ZONE_N("aimbot::application_update");
    if (!game_state::is_in_raid)
    {
        target_store = {};
        player_pos = {};
        fireport_pos = {};
        target_valid = false;
        local_player_store = nullptr;
        target_objects.clear();
        counter = 0;
    }
    else
    {
        // Which options are MEANINGFUL for the selected mode, as a table.
        //
        // This replaces four near-identical switch arms that had drifted apart: the
        // wall check was hidden in one and shown in another for reasons that had to be
        // re-derived from the pick loop each time, and the appearance controls carried a
        // three-line comment each, repeated verbatim three times. A table says the same
        // thing once and cannot drift.
        //
        // "Meaningful", not merely implemented: the wall check is HIDDEN in magic bullet
        // because the pick loop gates it on `aim_type > 1` and that mode teleports the
        // bullet rather than tracing one, so the checkbox controlled nothing. Aim
        // smoothness is hidden there for the same reason -- only mode 3 drives the mouse.
        // An option that looks live but is not consulted is worse than an absent one.
        //
        //                        none  mBullet  mAim  aimbot
        const auto visible = [this](bool v_none, bool v_mb, bool v_ma, bool v_ab) {
            switch (aim_type->get_value())
            {
            case 1:  return v_mb;
            case 2:  return v_ma;
            case 3:  return v_ab;
            default: return v_none;
            }
        };
        const auto apply = [this, &visible](ConfigValue* v,
            bool n, bool mb, bool ma, bool ab) {
            if (v) v->set_hidden_in_owner_menu(!visible(n, mb, ma, ab));
        };

        apply(aim_bone,          false, true,  true,  true);
        apply(max_distance,      false, true,  true,  true);
        apply(velocity_tracking, false, true,  true,  true);
        // Wall check: modes 2 and 3 only. See the note above.
        apply(wall_check,        false, false, true,  true);
        // Smoothness: mode 3 only -- the only mode that moves the mouse.
        apply(aim_smoothness,    false, false, false, true);

        // --- The target marker: WHAT we are aiming at ---------------------------
        // Deliberately a separate block from the cone below, and the separation is the
        // feature rather than tidiness. The cone marks the region we are ALLOWED to
        // lock; the dot marks what we HAVE locked. Independent toggles, because the
        // useful in-game configuration is both-on (see the note on show_target).
        apply(show_target,       false, true,  true,  true);
        apply(target_size,       false, true,  true,  true);
        apply(target_color,      false, true,  true,  true);
        apply(target_opacity,    false, true,  true,  true);

        // --- The selection cone: WHERE we are allowed to lock -------------------
        // The cone is the pick GATE for every mode above None, so its radius and colour
        // are meaningful in all three -- unlike wall_check and aim_smoothness.
        //
        // These four were previously never hidden at all, which meant they were the only
        // options still on screen with Aim Type set to None: two live-looking controls
        // that cannot affect anything, sitting directly under the dropdown that turned
        // them off.
        apply(show_cone,         false, true,  true,  true);
        apply(aim_cone,          false, true,  true,  true);
        apply(cone_color,        false, true,  true,  true);
        apply(cone_opacity,      false, true,  true,  true);
    }
}

void AimbotModule::gameworld_update(const Il2CppClass *game_world_class,
    Il2CppObjectInstance game_world_instance,
    Il2CppObjectInstance main_player) {
    // Named to match frame::EspModule::gameworld_update so the two are directly
    // comparable in a capture. This module had NO zone at all, which is why the
    // 2026-10-01 profile could not attribute its share of hk_game_world_update
    // and why "is magic aim expensive" had to be answered from the source instead.
    TA_ZONE_N("frame::AimbotModule::gameworld_update");

    // LIVENESS GATE, 2026-10-04. There was no liveness check here at all: the
    // function takes `main_player` and dereferences it on the next line, through
    // `component_get_game_object`. `skeleton_visibility.h:1438-1447` uses
    // `unity::is_unity_object_alive` for exactly this pattern three lines away.
    //
    // This is the TEARDOWN window, which the `hands_not_firearm` gate added in 0.46
    // does not cover. That one catches the LOADING screen -- a half-built weapon --
    // and did so 3 sessions out of 3. This catches the other end: the player object
    // being destroyed. Measured in `+7 exfil_success`:
    //
    //     aimbot::local_player_transform   first 30 s:  1.02 us mean, 0.00 ms max
    //                                       last  12 s: 366 us mean, 51.24 ms max
    //
    // and the trace's last 12 s sit after `Local Raid Ended`, with `is_in_raid` still
    // reading true (the overlay agent's `cam-choice` is still reporting 9 s later).
    // So this is the reading that a managed call on `main_player` degrades while the
    // object is being torn down, and it is the same shape as the
    // `hk_initiate_shot` frame the FATAL was captured on.
    //
    // WHY NOT `IHealthController.get_IsAlive()`, which the other workstream
    // established exists and which we already resolve: it is the wrong predicate
    // here. "Dead" is a gameplay state -- a corpse is still in a raid with a working
    // camera -- and that is exactly why the overlay deliberately does not gate
    // drawing on it. What matters at teardown is that the WRAPPER is gone, which is
    // what `m_CachedPtr` answers.
    //
    // FAILS CLOSED ON THE VERDICT ONLY. `target_valid` and `target_store` are
    // cleared, because a live target must not survive the frame the shooter stops
    // existing. The cached reads -- `local_player_store`, `player_pos`,
    // `fireport_pos`, `target_objects` -- are deliberately NOT cleared: the helper
    // memoises with a 64-call TTL, so it can be stale in either direction, and
    // destroying the pointers we would need to recover on a doubtful read is a
    // worse failure than the one this gate prevents. `application_update` clears
    // all of them on `!is_in_raid`, which is the edge that is actually definitive.
    if (!unity::is_unity_object_alive(main_player.get_instance(), "aimbot/main_player"))
    {
        target_store = {};
        target_valid = false;
        return;
    }
    //
    // WHAT THIS FUNCTION SPENT, as of 2026-10-04 13:10: **174.84 s self over 2,753
    // calls, 63,509 us mean**, with every zoned region inside it summing to 0.146 s.
    // That is 99.92% unattributed, and it is the largest self time in the project.
    //
    // The per-call cost has climbed 47x across five captures (15.8 us -> 4.0 ->
    // 1,338 -> 12,812 -> 63,509) while the call count FELL (14,630 -> 1,397 ->
    // 2,753). Work that gets more expensive while being called less is not a
    // workload change; it behaves like cost scaling with elapsed time or with
    // accumulated state. That is the shape this has to explain and I do not yet have
    // an explanation for it.
    //
    // Every region below is zoned for one reason: the aggregate above is not
    // actionable, and three successive hypotheses (the pick loop, the method
    // resolves, the scan body) all came back free. What is left is the code that had
    // no zone on it at all, and the only honest way to find it is to make each piece
    // measurable rather than to pick one and guess.
    // ---------------------------------------------------------------------

    // The local player's rig transform: three hops (component -> GameObject ->
    // Transform -> position), once per call, unzoned until now. `player_pos` is the
    // fallback origin for the pen walk AND the reference for the camera trust test,
    // so a wrong or slow read here is load-bearing rather than incidental.
    Il2CppObject *player_go = nullptr;
    Il2CppObject *player_transform = nullptr;
    {
        TA_ZONE_N("aimbot::local_player_transform");
        // Split into its three hops, 2026-10-04, because the whole thing measured
        // 118.75 us mean / **51.24 ms max** in the +7 exfil capture while reading
        // ~1 us in +5, and a single number cannot say which hop degrades when the
        // player object is being torn down. All three are managed calls on the same
        // object, so they will NOT degrade together: `get_position` is the one the
        // fireport's `Bifacial.get_position` proved can cost 40 ms on a half-built
        // object, and this is the same class of read on the same object.
        {
            TA_ZONE_N("aimbot::lpt:game_object");
            player_go = unity::component_get_game_object(main_player.get_instance());
        }
        if (player_go)
        {
            {
                TA_ZONE_N("aimbot::lpt:transform");
                player_transform = unity::gameobject_get_transform(player_go);
            }
        }
        if (player_transform)
        {
            {
                // The one that reads a POSITION, and therefore the only one of the
                // three that can force Unity to bring the transform hierarchy up to
                // date. The other two are pointer walks.
                TA_ZONE_N("aimbot::lpt:pos");
                player_pos = unity::transform_get_pos(player_transform);
            }
        }
    }
    local_player_store = main_player.get_instance();

    bool hands_not_firearm = false;
    {
        TA_ZONE_N("aimbot::ammo_cache");
        eft_api::try_read_weapon_ammo(local_player_store, cached_, &hands_not_firearm);
    }

    // Grenade throw vector, READ ONLY. 2026-10-04.
    //
    // Deliberately NOT gated on `hands_not_firearm`: that flag is set by
    // try_read_weapon_ammo, and a grenade in hands is a ThrowWeap rather than a
    // firearm, so the flag does not reliably distinguish the two. The probe
    // instead asks the hands controller what class it is and returns immediately
    // unless it is a grenade controller, which costs one string compare per frame
    // on the firearm path and nothing else.
    //
    // It self-limits: g_get_hands_controller is resolved once, and if that fails
    // the probe warns and returns on every frame rather than retrying a lookup
    // that cannot start succeeding.
    grenade_probe::probe(local_player_store);
    // #20 diagnostic campaign (TEMPORARY): the wall check consumes these
    // values, so dump the cache on-change via logger::info — a wrong or
    // failed read shows up the moment it happens. Remove once blame is
    // established.
    //
    // GATED on logger::debug_enabled(), and the gate is the whole point of the
    // rewrite. This used to std::format five values into `ammo_diag` on EVERY
    // frame and compare the result against the previous one to decide whether
    // to log -- building the string a hundred-plus times a second in order to
    // usually discard it. That is precisely the cost WORKFLOW.md warns about
    // under "Per-frame logging costs real time": the argument is built by the
    // caller, so a disabled logger does not make it free.
    //
    // The zone is INSIDE the gate deliberately. With debug off the zone never
    // opens and the name is absent from a capture, which is the proof the
    // gating works; with debug on it appears and shows what the formatting
    // actually costs. A zone outside would have shown a near-zero line either
    // way and answered nothing.
    // Re-read of the weapon's ammo state, and the strongest remaining suspect.
    //
    // This runs on EVERY call of this function, and
    // `tools/probe_test`'s lesson applies directly: the gate makes it LOOK free, but
    // the `std::format` arguments are evaluated at the call site whether or not the
    // block runs. Five arguments including `cached_.chamber_name`, which is a
    // `std::string` -- and `try_read_weapon_ammo` above may have just reassigned it.
    // A string copy per frame is not free, and this is the only remaining unguarded
    // argument evaluation on the hot path.
    //
    // I hit exactly this bug in `unity.h` this session -- `maybe_report_native_object_memo`
    // looked throttled and cost 64.87 s because of it -- and I did not check here first.
    // That is the order I should have worked in.
    //
    // Zoned so it stops being invisible either way: if it reads large the gate needs to
    // move to a counter like the memo's did; if it reads ~0 then this path is clean and
    // the cost is somewhere this zone does not cover.
    if (logger::debug_enabled())
    {
        TA_ZONE_N("aimbot::ammo_diagnostic");
        static std::string s_last_ammo_diag;
        std::string ammo_diag = std::format(
            "chamber='{}' penPower={} obstChance={:.3f} speed={:.1f} handsNotFirearm={}",
            cached_.chamber_name, cached_.penetration_power,
            cached_.obstacle_pen_chance, cached_.initial_speed,
            hands_not_firearm ? "true" : "false");
        if (ammo_diag != s_last_ammo_diag)
        {
            s_last_ammo_diag = ammo_diag;
            logger::debug("Magic Aim ammo cache: " + ammo_diag);
        }
    }
    should_tp_bullet = (aim_type->get_value() == 1); //aim_type is magic bullet

    //const auto get_speed = main_player.get_method<float (*)(Il2CppObject *)>("get_Speed", 0);

    // Real muzzle position for the shot direction and the time-of-flight estimate;
    // falls back to the player transform. Overwriting player_pos with the fireport
    // made is_target_visible raycast FROM the gun into the gun (first hit = own
    // hierarchy => "visible"), silently disabling the wall check. It also fed a
    // fireport origin into time_of_flight, slightly mis-scaling the prediction lead.
    //
    // try_get_fireport_position() now rejects a read that lands on the world origin,
    // so a not-yet-placed muzzle reports failure here rather than a confident
    // {0,0,0}. The fallback inherits the same check for the same reason -- player_pos
    // is a transform read, and at raid start it is the SAME unpopulated rig, so
    // falling back to it unguarded would have reintroduced the exact bug one line
    // below. When both reads are degenerate there is no trustworthy origin and the
    // wall check is skipped for this frame rather than cast from the map corner.
    // GATED ON `hands_not_firearm`, 2026-10-04. The reason this function's zones
    // exist at all, and then the reason this call is now conditional.
    //
    // WHAT IT WAS: **310.59 s / 39.96% of one capture**, 33x the next most
    // expensive zone in it, and 180.28 s / the #1 zone in the next. Split by
    // zone it is entirely `Bifacial.get_position()` -- the managed call -- and not
    // the two `resolve_method` walks the comment above this used to blame, which
    // measure 1 us and 570 ns out of 130 ms.
    //
    // WHY IT IS BIMODAL, from `fireport-cost:` in the log -- the per-30s window
    // added for exactly this question. Three independent sessions, three
    // reproductions, and in each the entire cost is ONE window that opens with the
    // load and ends the instant the weapon appears:
    //
    //   pid 21872  15:24:42 Loading in at: bigmap
    //              15:24:52  chamber='' penPower=0 handsNotFirearm=true
    //              15:25:56  chamber='556x45NATO M855A1' handsNotFirearm=false
    //              15:25:56  fireport-cost: calls=760  total_ms=33277 mean_us=43786
    //              15:26:26  fireport-cost: calls=4200 total_ms=5     mean_us=1
    //
    //   pid 30432  16:25:42 Loading in at: bigmap
    //              16:25:51  chamber='' penPower=0 handsNotFirearm=true
    //              16:27:00  chamber='556x45NATO M855A1' handsNotFirearm=false
    //              16:27:00  fireport-cost: calls=859  total_ms=35076 mean_us=40834
    //              16:27:30  fireport-cost: calls=4666 total_ms=6     mean_us=1
    //
    //   pid 26280  16:35:59 Loading in at: factory4_day
    //              16:36:05  chamber='' penPower=0 handsNotFirearm=true
    //              16:36:44  chamber='556x45NATO M855A1' handsNotFirearm=false
    //              16:36:44  fireport-cost: calls=342  total_ms=24722 mean_us=72287
    //              16:37:15  fireport-cost: calls=6812 total_ms=6     mean_us=0
    //
    // 3/3, and the expensive window closes on the SAME MILLISECOND as the log line
    // where `handsNotFirearm` flips to false. After it, the same call costs 0-1 us
    // forever -- including in the `+7 exfil_success` run, where this zone measured
    // **0.00 s over 8,466 calls, 0.3 us mean, 0.01 ms max.**
    //
    // WHY NOT is_in_raid. It cannot exclude this window: `is_in_raid` goes TRUE
    // the moment `MainPlayer` is non-null (game_state.h:50-57), which is before the
    // map streams. Reinforcing it is another workstream's task and this gate does
    // not wait on it. What is needed here is a predicate that says "the player has
    // something to shoot with", and the ammo read at the top of this function
    // already produces one, per frame, for free.
    //
    // WHAT THIS COSTS WHEN IT FIRES. `fireport_pos` has exactly two readers: the
    // pen walk's ray origin and `time_of_flight`. With no firearm drawn there is
    // no shot to take, and the existing `if (!fireport_ok) fireport_pos =
    // player_pos;` already substitutes the rig position -- which is the documented
    // conservative fallback and is what happens today whenever the read fails. So
    // the gate degrades origin fidelity only while the player is unarmed, and
    // cannot change a verdict that matters.
    //
    // THE HONEST LIMIT OF THE EVIDENCE. `hands_not_firearm` is a PROXY for "still
    // loading", established from three window boundaries. It is not a proven cause
    // and it is not tight: a player who holsters for 30 s mid-raid also satisfies
    // it, and would get the rig fallback instead of the muzzle. That is the
    // intended degradation. What this does NOT establish is why
    // `Bifacial.get_position()` costs 40 ms on a half-built weapon -- that is a
    // question about the game, and no reading of our own profile answers it.
    //
    // `fireport-cost:` keeps running, so the next capture says what the gate
    // actually saved rather than what it was predicted to save.
    //
    // MEASURED, 2026-10-04 14:36 capture (`next_next_next_day+4+stuck.tracy`), self
    // time: **310.59 s over 22,129 calls, 14,035 us mean, 246.03 ms max — 39.96%
    // of the whole capture**, and 33x the next most expensive zone in it. Its
    // `frame::AimbotModule::gameworld_update` parent reads 0.0132 s SELF and
    // 314.31 s inclusive, so this one call is 98.8% of the function.
    //
    // This is also what the 174.84 s / 63,509 us mean "99.92% unattributed" was:
    // the region had no zone, so its time was charged to the enclosing function's
    // self. It was never a mystery, it was an unmeasured line.
    //
    // The comment that used to sit here blamed the two UNCACHED name->method walks,
    // on the strength of skeleton_visibility.h's own note. **The capture disproved
    // that**: its two `il2utils::resolve_method` children measured 1 us and 570 ns,
    // which is 0.001% of 130 ms in the instance Tracy was showing. 99.999% is the
    // two managed calls those resolves produce pointers for -- `Player.get_Fireport`
    // and `Bifacial.get_position` -- which are now zoned separately inside
    // `try_get_fireport_position` as `skeleton_vis::fireport:get_Fireport` and
    // `:get_position`.
    //
    // It is called from here unconditionally, and AGAIN inside
    // try_get_visibility_origin() below via its own memo -- so the fireport is
    // resolved at least twice per frame from this one function. That redundancy is
    // real and worth fixing, but on these numbers it is worth at most half of
    // 310 s, and only if the memo path is the cheaper of the two.
    bool fireport_ok = false;
    // GATED ON "a firearm is out", not on is_in_raid. See the long note above.
    if (!hands_not_firearm)
    {
        TA_ZONE_N("aimbot::fireport_resolve");
        // Labels the caller for skeleton_visibility.h's shared getter, which four call
        // sites reach and which the profile cannot attribute on its own -- 26,101 calls
        // against 15,264 from this zone alone on 2026-10-04.
        // Guard, not assignment: it restores the previous label on the way out, so
        // this call site cannot be blamed for a later one's cost. See
        // skeleton_visibility.h for the 5x over-count that made this necessary.
        FIREPORT_SITE("aimbot/gameworld_update");
        fireport_ok = skeleton_vis::try_get_fireport_position(local_player_store, fireport_pos);
    }
    // Windowed cost report. Not a Tracy zone and deliberately so: this number has
    // to survive a session with no profiler attached, because the question it
    // answers -- is the fireport expensive during the LOADING SCREEN or during RAID
    // PLAY -- needs the log's timeline (`Loading in at:`, `Local Raid Ended`) to
    // answer, and the log is the only artefact that outlives the capture.
    //
    // Called from here rather than from inside `try_get_fireport_position` so it
    // runs exactly once per frame regardless of how many callers the function has.
    skeleton_vis::report_fireport_window();
    if (!fireport_ok)
        fireport_pos = player_pos;
    const bool origin_usable =
        (fireport_ok || !skeleton_vis::is_degenerate_origin(player_pos));

    // The pen walk's ray origin, chosen through the shared resolver so it gets the
    // camera trust test, the degenerate guard and the source counters -- none of which
    // the raw `fireport_pos` this replaces had.
    //
    // fireport_first, not camera_first: the walk is grading a BULLET, and the bullet
    // leaves the muzzle. hk_initiate_shot re-derives its direction from the fireport at
    // fire time, so tracing from the camera would be grading a shot the game is not
    // going to take. The camera remains available as a trust-tested fallback.
    //
    // Deliberately NOT the ESP's default (camera_first). The two features ask
    // different questions -- "can the player see it" vs "can the round reach it" --
    // and a shared origin would have quietly picked whichever answer suited the other.
    unity::vector3 vis_origin{};
    bool vis_origin_ok = false;
    {
        // Zoned separately from `aimbot::fireport_resolve` above, and the separation is
        // the point: this call runs the SAME fireport resolution again behind its own
        // memo, plus a Camera.current read, a camera trust test and a transform walk.
        //
        // So the two zones together answer a question that neither can: whether the
        // fireport is being resolved TWICE per frame from this one function, each time
        // for two uncached name->method walks. `pen-origin fireport=` in the tally
        // says the walk succeeded; it cannot say how many walks that took.
        TA_ZONE_N("aimbot::visibility_origin_resolve");
        vis_origin_ok = origin_usable
            && skeleton_vis::try_get_visibility_origin(local_player_store, vis_origin,
                skeleton_vis::vis_origin_preference::fireport_first,
                skeleton_vis::g_pen_origin_counts(),
                // THE 202 s. `+8+transit+crash` measured this call at 202.14 s
                // inclusive over 9,355 calls -- 99.7% of this function -- at
                // 21,608 us mean, all of it `Bifacial.get_position()` inside the
                // fireport memo, and only while `has_rig` was false. The direct
                // call above, gated on `hands_not_firearm`, measured 0.00 s in the
                // same capture; this one was ungated and carried everything that
                // was left.
                //
                // Same predicate as the gate above, for the same reason: with no
                // firearm out there is no shot to take, and the camera-stands rule
                // below it already handles a missing reference point.
                !hands_not_firearm);
    }
    if (!vis_origin_ok)
        vis_origin = {};

    // `main_player_transform` was here and was a DEAD READ: assigned from
    // `unity::gameobject_get_transform(local_player_store)`, never read anywhere in
    // this function -- four matches in the tree, all of them the declaration and its
    // own zone. A managed call per frame on the hot path, feeding nothing.
    //
    // FOUND 2026-10-04 while adding the zones above. LEFT ALIBI at the time, on the
    // reasoning that a dead local is not a performance finding and removing it changes
    // what the next capture measures. That was the right call for the measurement and
    // the wrong call for the code, so it needed three captures to settle.
    //
    // MEASURED, on 09.10_3 / _4 / _5 -- the three captures the alibi was waiting for:
    //
    //   aimbot::main_player_transform   61,758 / 29,849 / 58,874 calls
    //     mean 0.649 / 0.592 / 0.768 us      max 204.5 / 61.6 / 264.4 us
    //
    // Sub-microsecond mean, so the cost was never the point -- the point is that it is
    // a managed call in the per-frame path that produces nothing. Removed rather than
    // left, because leaving it costs a call and a zone row forever to document a
    // measurement that has now been taken.
    //
    // `tools/tests/test_zone_scope.py` listed this name in its expected set, because
    // the set is "zones added to attribute the unattributed self time" and this was
    // one of them. It is removed from that set in the same commit: leaving it would
    // assert the presence of code that no longer exists.
    // Target pick uses same projection as draw (optic when ADS) so FOV matches reticle.
    if (aim_type->get_value() != 0)
    {
        // Half one of the boundary. Everything from the method resolves down to the
        // end of the scan is GATHERING: who is in range, and what does each of them
        // cost to look at. The pick half is `aimbot::pick_phase` below.
        //
        // Both halves get a zone because the alternative is what was actually done
        // until 2026-10-04: a single 63.5 ms mean at the function level that nobody
        // could decompose. Two halves is the coarsest split that still tells us which
        // half of the function to stop looking at.
        //
        // The three locals that the pick phase needs (`get_profile`, `get_velocity`,
        // `screen_center`) are deliberately hoisted ABOVE this block rather than left
        // inside it: a zone is a scope, so declaring them under a zone that ends
        // before the pick is a use-after-scope. They keep their own zone, which is
        // what that resolve was measured for in the first place.
        //
        // Explicit braces, not a bare zone, because `aimbot::pick_phase` opens in the
        // same scope three hundred lines later and TA_ZONE_N expands to a variable
        // literally named `ta_zone` -- two of them in one scope is a redefinition
        // (C2374). This is the third time this session that error has been hit; the
        // braces are the whole fix and there is no cleverer way to express it.
        //
        // Resolved HERE rather than at the top of the function, because they are only
        // USED here. They used to be resolved unconditionally, which meant a
        // name->method walk every frame whose result was discarded whenever Aim Type
        // was None. resolve_method has no cache, unlike resolve_field.
        //
        // Zoned because that is exactly why they moved, and it had no number of its
        // own: frame::AimbotModule::gameworld_update carried 16.75 s of SELF time on
        // 2026-10-04 (729.8 us mean over 22,952 calls, third-largest self time in the
        // session) with every pick-loop child separately zoned and separately small.
        // The cost had to be outside the loop, and these two uncached name->method
        // walks per frame are the prime candidate. If the next capture shows this
        // zone near zero, the cost is in the scan loop's own body instead -- which is
        // exactly the question the number answers.
        Il2CppObject *(*get_profile)(Il2CppObject *) = nullptr;
        unity::vector3 (*get_velocity)(Il2CppObject *) = nullptr;
        {
            TA_ZONE_N("aimbot::main_player_method_resolve");
            get_profile = main_player.get_method<Il2CppObject *(*)(Il2CppObject *)>("get_Profile", 0);
            get_velocity = main_player.get_method<unity::vector3 (*)(Il2CppObject *)>("get_Velocity", 0);
        }

        const unity::vector3 screen_center = {menu::get_width() / 2,
            menu::get_height() / 2, 0};

        // Radius comes from the member helper, not a second copy of the formula.
        //
        // This used to recompute `(pct / 100) * menu::get_height()` inline, which is
        // exactly what aim_cone_radius() exists to prevent: the gate in the pick loop
        // and the outline in draw_overlay must agree, or the drawn circle stops
        // describing the region it claims to show. They agreed by coincidence, which is
        // not a property anyone can rely on. One definition, two callers.
        //
        // Hoisted out of the pick phase along with `picked`/`picked_pos` below purely
        // for scope reasons -- a zone is a scope, and these three are written in the
        // pick and read in the output stage after it. They are trivial values; if any
        // of them ever showed up in a profile the answer would be to hoist the
        // computation into a member, not to have measured it here.
        const float cone_radius_px = aim_cone_radius();

        // `picked`, not `closest`.
        //
        // This was a float initialised to 1e9, compared against distFromReticle and
        // then `break`-ing on the first success -- so the comparison could only ever be
        // true on the first surviving candidate and the reticle distance never
        // influenced anything. It read like crosshair-proximity scoring and was not;
        // the real ordering is target_objects' 3D-distance key.
        //
        // Replaced with a plain flag because that is what it always was. Behaviour is
        // identical -- "nearest usable target, first one that passes wins" -- but the
        // code now says so, and the final `if (picked)` can no longer be mistaken for
        // a threshold on how central the target had to be.
        bool picked = false;
        unity::vector3 picked_pos = {};

        {
        TA_ZONE_N("aimbot::gather_phase");

        // --- selection cone ---------------------------------------------------
        //
        // The original implementation picked whichever living player happened to
        // be closest to the SCREEN CENTRE, with the whole screen live: that is a
        // tie-break on screen position, so it would happily pick a prone player
        // 40 m away who was nearer the middle of the screen over the enemy
        // standing 8 m off to the side.
        //
        // What is kept here is the other half of that behaviour, which is the
        // part that was right: candidates are ordered by 3D distance to the
        // shooter (target_objects is a std::map keyed on it) and the first one
        // that passes the visibility and wall checks wins. So the choice is
        // "nearest usable target", not "nearest to the crosshair".
        //
        // What is added is the DEADZONE the whole-screen version lacked: only
        // targets inside a cone around the reticle are eligible at all. That is
        // two things at once --
        //
        //   * correctness: a target you are not pointing at is not a target, so
        //     it should not be selectable however close it is.
        //   * cost: eligibility is decided from the projection that has already
        //     happened, BEFORE the wall check. The wall check is the expensive
        //     half (skeleton_vis::is_target_visible_penetrating, an IL2CPP
        //     physics query plus the layer walk), so an out-of-cone candidate
        //     now costs a projection instead of a full penetration walk.
        //
        // Measured on the 2026-10-02 capture, the walk is the only part of the
        // pick loop worth gating: aimbot::candidate_pick is 1.04 us against
        // occlusion_linecast at 9.32 us for the same bone.
        //
        // `alive_players` is `AllAlivePlayersList` -- an Il2CppList's backing array,
        // read through three field hops and then walked below. Zoned because the field
        // reads are the part that could grow: the walk itself is bounded by the array
        // and shows up under `aimbot::alive_player_scan`.
        Il2CppArray *alive_players = nullptr;
        {
            TA_ZONE_N("aimbot::alive_players_fetch");
            alive_players = game_world_instance.get_field<unity::list *>("AllAlivePlayersList")
                ->m_p_list_array;
        }

        target_objects.clear();

        if (alive_players && alive_players->max_length > 0)
        {
            // Per-frame and O(alive players): every entry costs a role lookup
            // (several memoised resolve_field calls) and try_is_btr_by_weapon,
            // which does THREE uncached resolve_method name lookups plus a
            // std::string copy of the controller class name. Zoned because it is
            // the most likely place for the aimbot's cost to actually live, and
            // it was previously invisible.
            TA_ZONE_N("aimbot::alive_player_scan");
            for (size_t i = 0; i < alive_players->max_length; ++i)
            {
                Il2CppObject *possible_target_object =
                    reinterpret_cast<Il2CppObject **>(&alive_players->data)[i];
                if (!possible_target_object)
                    continue;
                Il2CppObjectInstance possible_target_instance(possible_target_object);

                // Its own block, and the braces are load-bearing rather than stylistic:
                // TA_ZONE_N expands to a variable literally named `ta_zone`, and
                // `aimbot::alive_player_scan`'s zone is still open around this whole
                // loop, so a bare zone here is a redefinition (C2374). Same trap as
                // `aimbot::velocity_prediction` inside candidate_pick.
                Il2CppObject *profile_ptr = nullptr;
                {
                    TA_ZONE_N("aimbot::alive_player_scan:profile_fetch");
                    profile_ptr = get_profile(possible_target_object);
                }
                if (!profile_ptr) continue;
                Il2CppObjectInstance profile_instance(profile_ptr);
                // Zoned separately because the 2026-10-01 20-minute capture put
                // 4.430% of a core in this loop and could not attribute any of it:
                // alive_player_scan is 96.5% child time, and none of the two things
                // below had a zone of its own. These two answer "which half of the
                // per-player cost is it" in one capture.
                int role = -1;
                {
                    TA_ZONE_N("aimbot::role_check");
                    role = profile_ptr ? eft_api::get_wild_spawn_role(profile_ptr) : -1;
                }
                // Short-circuited exactly as before: a known BTR role never reaches
                // the weapon test.
                bool skip_btr = role == eft_api::wild_spawn_shooter_btr;
                if (!skip_btr)
                {
                    TA_ZONE_N("aimbot::btr_check");
                    skip_btr = eft_api::try_is_btr_by_weapon(possible_target_object);
                }
                if (skip_btr) continue; //skip BTR shooter as a target

                // The transform walk, as its own zone. This is the part of the loop
                // that was 19.58 s of unowned SELF time in `frame::AimbotModule::
                // gameworld_update` on 2026-10-04 (1,338 us mean over 14,630 calls) --
                // the last region in this function with no child accounting for it,
                // once `candidate_pick`'s children were attributed and my two
                // hypothesis zones came back at 0.01 s and 0.00 s, i.e. both wrong.
                //
                // Three managed-ish hops per surviving player: component->GameObject,
                // GameObject->Transform, Transform->position. Zoned together because
                // they are one traversal and splitting them three ways would triple
                // the zone count to answer a question that does not arise -- the
                // interesting split is "is this traversal the cost", not "which hop".
                //
                // `possible_target_instance.get_instance()` is the one non-obvious
                // term: it is a cast of the object we already hold, so it is free, but
                // it reads like a dereference and would be the first thing a reader
                // suspects. It is spelled out here so the zone's cost is attributable
                // to the three calls rather than to this line.
                // Braces again, for the same C2374 reason as profile_fetch above.
                Il2CppObject *possible_target_game_object = nullptr;
                Il2CppObject *possible_target_transform = nullptr;
                unity::vector3 target_pos{};
                {
                    TA_ZONE_N("aimbot::alive_player_scan:transform_walk");
                    possible_target_game_object =
                        unity::component_get_game_object(possible_target_instance.get_instance());
                    if (possible_target_game_object)
                        possible_target_transform =
                            unity::gameobject_get_transform(possible_target_game_object);
                    if (possible_target_transform)
                        target_pos = unity::transform_get_pos(possible_target_transform);
                }
                if (!possible_target_game_object)
                    continue;
                if (!possible_target_transform)
                    continue;

                const float distance = player_pos.distance(target_pos);

                // Its own zone, and the reason for it: this is the std::map insert,
                // and `target_objects` is cleared and rebuilt EVERY frame. A node
                // allocated here is freed by the clear, so this is a malloc/free pair
                // per surviving player per frame -- the shape of cost that does not
                // appear in any profiler total until you look for it, because it is
                // "a few tens of nanoseconds" per call spread over 14,630 frames.
                //
                // `max_distance->get_value()` is read per iteration rather than hoisted,
                // which is a config read that cannot change mid-loop; it is left alone
                // deliberately, because hoisting it would be a behaviour change in a
                // function whose cost is what is being measured.
                if (distance > max_distance->get_value())
                {
                    continue; // do not add playerObjects outside our magic bullet slider-defined range
                }
                else if (possible_target_object != local_player_store)
                {
                    // Braces for the C2374 reason again -- and this one is the only
                    // place where the zone measures something this cheap, which is the
                    // point: if a malloc/free pair per player per frame turns out to be
                    // material, that is a shape change (reserve, or a vector + sort)
                    // and it needs a number to justify it.
                    TA_ZONE_N("aimbot::alive_player_scan:candidate_insert");
                    target_objects.insert(
                        {distance, possible_target_object}); // sort naturally by distance to target
                }
            }
        }       // end if (alive_players && max_length > 0)
        }       // end aimbot::gather_phase

        // ---- half two: the pick ----------------------------------------------
        //
        // The boundary between "who is in range" and "who do we shoot at".
        //
        // Zoned as a whole because everything inside it is the AIMBOT: the pick, the
        // wall check, and whatever records the result. Everything before it is scene
        // gathering. If this region is large the cost is in deciding to aim; if it is
        // small then the 174.84 s is in the gathering above, and the per-region zones
        // there will say which part.
        //
        // It is deliberately a boundary and not a hypothesis. Three successive guesses
        // about where the unattributed time lived -- the pick loop, the method resolves,
        // the scan body -- all came back free, and a fourth guess would have been a
        // guess. This measures the two halves against each other instead.
        {
        TA_ZONE_N("aimbot::pick_phase");
        // Nearest-first over the sorted candidates, taking the first that passes
        // visibility and the wall check. Zoned separately from the scan above
        // because this is where the bone resolve and the raycast live.
        {
        TA_ZONE_N("aimbot::candidate_pick");
        // Resolved ONCE for the whole pass, not once per candidate.
        //
        // This call was inside the loop, and the loop iterates the sorted candidate
        // list -- ~7 bones per pick in the 2026-10-04 capture. Each iteration asked
        // Camera.all for a freshly allocated managed array and ran a GetName per
        // camera in the scene, to answer a question that is deterministic within the
        // pass. Measured: 154,544 resolutions for 22,431 picks, 6.33 s self, 41.0 us
        // mean, and the projection's 55.72 ms worst frame was one of them (identical
        // max on the resolve zone). That is 92% of candidate_pick's 16.81 s.
        //
        // Once per pass is the right granularity and not a cache: the camera can
        // legitimately change between frames, and a stale camera is precisely the
        // failure the by-name lookup exists to prevent (see resolve_esp_camera's
        // Camera.current note). This value cannot outlive the pass that made it.
        //
        // An invalid frame -- no camera, or one refused as too far -- makes every
        // projection return {}, which fails is_visible() and `continue`s. So a
        // refused camera rejects every candidate this pass, which is the same
        // conservative outcome as before: the old code resolved per candidate and
        // would have been refused on all of them too.
        const eft_api::esp_camera_frame cam_frame =
            eft_api::resolve_esp_camera_frame(true, game_state::current_zoom);

        for (const auto &target_object : target_objects)
        {
            unity::vector3 bone_pos{};
            if (!aimbot_bones::resolve_aim_bone(target_object.second, aim_bone->get_value(), bone_pos)) continue;
            if (aim_bone->get_value() == 0 && aim_type->get_value() > 1) bone_pos.y -= 0.03f; // head position correction

            // Its own zone, because the 2026-10-01 capture put 3.928% of a core in
            // candidate_pick as a single undifferentiated number: 1.08% was self
            // and the rest sat in shared children, with the wall check only 0.205%
            // of it. So the projection was the prime suspect and there was no way to
            // tell. It is measured separately from the raycast, which keeps its own
            // zone in skeleton_visibility.h.
            //
            // No resolve_camera zone inside this any more, and that is the point:
            // the cost it carried has moved up to resolve_esp_camera_frame above,
            // where it is paid once per pass instead of once per candidate.
            TA_ZONE_N("aimbot::project_to_screen");
            unity::vector3 screen_pos = eft_api::world_to_screen_with_frame(bone_pos, cam_frame);
            if (!eft_api::is_visible(screen_pos)) continue;

            screen_pos.z = 0;
            const float distFromReticle = screen_pos.distance(screen_center);

            // The cone gate. Placed HERE, after the projection and before the
            // wall check, for the reason in the note above: the projection is
            // already paid for, and this is the last point at which an
            // ineligible candidate can be dropped without touching physics.
            //
            // Cheapest possible rejection: one compare against a per-frame
            // constant. No allocation, no further resolve, no raycast.
            if (cone_radius_px > 0.f && distFromReticle > cone_radius_px)
                continue;

            // Wall check for magic aim and aimbot modes — penetration aware.
            // A blocked ray only discards the target when the chambered ammo
            // could NOT punch through the obstacle (thin wood/glass/sheet metal
            // carry a BallisticCollider whose PenetrationLevel the ammo beats).
            //
            // `vis_origin_ok` gate: if neither the fireport nor the rig gave a
            // usable position this frame, the walk is skipped rather than traced from
            // the world origin, where it would classify the whole map as cover and
            // silently reject every target. Skipping is the conservative failure --
            // the wall check is an opt-in filter, and not running it for one frame
            // leaves the previous behaviour, whereas a bogus origin would fabricate a
            // verdict.
            // `!hands_not_firearm` gate, added 2026-10-04. The walk grades a BULLET --
            // it reads PenetrationPower off the chambered round and asks whether that
            // round can reach the target. With a grenade in hand there is no round, and
            // the answer is meaningless rather than merely unnecessary.
            //
            // It was worse than meaningless. `vis_origin_ok` above stays TRUE in that
            // window, because the camera resolves fine once the fireport is suppressed,
            // so the walk ran anyway -- traced from the CAMERA, per the `pen-origin`
            // tally at 23:14:34 (`camera=3151 fireport=227`, against `camera=128
            // fireport=3657` thirty seconds later with a rifle out). A camera-origin
            // ray is short and starts inside the shooter's own mesh or the wall they
            // are stood against, so it hit the degenerate-origin exit almost every
            // time: **70 of the 82 `origin effectively inside a mesh` records in the
            // 23:14 Factory log, and all 70 came back PENETRABLE.**
            //
            // That is 70 fabricated "clear line" verdicts on a live aim path, and it is
            // why the origin_in_mesh stop next door in skeleton_visibility.h was
            // needed as well. Both fixes are required: this one stops the meaningless
            // question being asked, that one stops an unanswerable one being reported
            // as a pass.
            if (aim_type->get_value() > 1 && wall_check->get_value() && vis_origin_ok
                && !hands_not_firearm)
            {
                // The wall check. Braces, and they are load-bearing again:
                // `aimbot::candidate_pick` and `aimbot::pick_phase` are both still open
                // here, and TA_ZONE_N expands to a variable literally named `ta_zone`,
                // so a bare zone is a redefinition (C2374).
                //
                // local_player_store is passed as the SHOOTER. The walk's origin is our
                // own muzzle, so the first collider it meets is frequently our own body;
                // without this the walk could not tell our own arm from a wall, found no
                // BallisticCollider on it, and reported `no BallisticCollider on hit
                // chain (env/terrain)` -> BLOCKED. That is the ESP's hit_owner fix,
                // which this path never received.
                //
                // Zoned at this call site in ADDITION to the one inside
                // is_target_visible_penetrating, and the pair answers a question the
                // inner one cannot: `is_target_visible_penetrating` measures itself,
                // while this measures the CALL including the argument setup and the
                // `cached_` field reads. Those three float reads happen per candidate
                // that reaches here, and the aimbot_diagnostic zone below shows that
                // cache reads are not free.
                TA_ZONE_N("aimbot::wall_check_call");
                if (!skeleton_vis::is_target_visible_penetrating(vis_origin, bone_pos,
                        target_object.second,
                        static_cast<float>(cached_.penetration_power),
                        cached_.obstacle_pen_chance,
                        cached_.ricochet_chance,
                        local_player_store))
                {
                    continue;
                }
            }

            // Velocity tracking (target prediction).
            //
            // EFT simulates ballistics every physics tick (LateFixedUpdate ->
            // ComplexLateUpdate uses Time.fixedUnscaledDeltaTime, and the client
            // drives it from Player.ArmsLateUpdate at the fixed rate) and reports
            // get_Velocity() in that tick's time base. Predict in the game's own
            // time base instead of blindly adding a raw per-frame delta -- that
            // hops around because it's sampled at mouse-frame rate, not tick rate.
            //
            // The correct aim point is where the target is when the shot lands:
            // estimate the time-of-flight, project the target forward by how far
            // it travels during that window, then apply the bullet drop over the
            // same window. Skips effectively idle targets whose velocity is just
            // per-frame noise.
            //
            // NOTE: no manual 0.5*g*t^2 here. Shot.Init sets _velocity =
            // direction * speed and the shot then follows that initial velocity
            // through TrajectoryCalculator, which already models gravity/drag
            // from the ammo's ballistic data. Aiming above the target like a
            // simple parabola double-compensates and shots sail over heads.
            auto time_of_flight = [&](unity::vector3 target) -> float {
                const float dist = fireport_pos.distance(target);
                if (cached_.initial_speed > 1.0f)
                    return dist / cached_.initial_speed;
                return 0.f; // no ammo data -> no prediction rather than garbage
            };
            // Zoned because it is a per-candidate managed call (get_Velocity, via the
            // uncached method pointer above) plus arithmetic, on the hot path, and
            // it was inside the 16.75 s of unowned self time. GATED on the same
            // config value that decides whether it runs at all, so with prediction
            // off the zone is absent from the capture -- which is the proof the
            // gate works rather than a near-zero line that says nothing.
            //
            // Inside the `if`, not before it: TA_ZONE_N expands to a variable
            // literally named `ta_zone`, and candidate_pick's zone is still open at
            // this point -- two in one scope is a redefinition (C2374). Ordering
            // also keeps the gate honest, since a zone outside the `if` would open
            // on frames where the work does not run.
            if (velocity_tracking->get_value())
            {
                TA_ZONE_N("aimbot::velocity_prediction");
                const unity::vector3 velocity =
                    normalize(get_velocity(target_object.second), {0.f, 0.f, 0.f});
                const float tof = time_of_flight(bone_pos);
                if (tof > 0.f && unity::length(velocity) > 1e-4f)
                    bone_pos = bone_pos.add(velocity * tof);
            }

            // First candidate that survives every filter above wins. No comparison
            // against a running minimum: target_objects is already ordered by 3D
            // distance, so "first that passes" IS the selection rule, and adding a
            // reticle-distance test on top would silently contradict it.
            picked_pos = bone_pos;
            picked = true;
            break;
        }
        }   // end aimbot::candidate_pick

        if (picked)
        {
            target_store = picked_pos;
            target_valid = true;
        }
        else
        {
            target_store = {};
            target_valid = false;
        }
        }   // end aimbot::pick_phase

        // ---- the mode-3 output stage -------------------------------------------
        //
        // Zoned as one region because it is the last unzoned code in the function and
        // it runs on EVERY call in mode 3, including the overwhelming majority of calls
        // that pick nothing: the projection happens before the button check, so a frame
        // where the user is not holding XBUTTON1 still pays for
        // world_to_screen_prefer_optic.
        //
        // That projection resolves the camera AGAIN -- a third resolution on this path,
        // after `aimbot::fireport_resolve` and `aimbot::visibility_origin_resolve` are
        // two more, and it is the only one that goes through the WRAPPER rather than the
        // hoisted frame. So in mode 3 the camera is resolved three times per frame, and
        // the one that could have reused `cam_frame` cannot, because `cam_frame` is
        // scoped inside the pick phase.
        //
        // Split from the button press below so that "how expensive is projecting for a
        // frame where we are not shooting" is a number rather than an argument.
        {
            TA_ZONE_N("aimbot::mode3_output");
            if (aim_type->get_value() == 3 && !(target_store.x == 0 && target_store.y == 0))
            {
                unity::vector3 aim_screen{};
                {
                    // Split from `aimbot::mode3_mouse` below, and the split is the
                    // point. The projection is unconditional; the mouse is not. If
                    // this line is expensive it means the camera is being re-resolved
                    // for frames where the trigger is never touched, and that is a
                    // removable cost rather than a design one.
                    TA_ZONE_N("aimbot::mode3_projection");
                    aim_screen = eft_api::world_to_screen_prefer_optic(
                        picked_pos, game_state::current_zoom);
                }
                if (eft_api::is_visible(aim_screen))
                {
                    // Braces, because `aimbot::mode3_output` is still open here and
                    // two zones in one scope is a redefinition (C2374).
                    {
                        // GetAsyncKeyState is a USER32 call, once per frame, on the
                        // path that only matters when the button is down. Its own zone
                        // mostly so that a stall in input handling is visible at all --
                        // this is the only place in the aimbot that touches input
                        // state, and it is the one place where the answer to "is the
                        // aimbot doing anything" is not in our own code.
                        TA_ZONE_N("aimbot::mode3_mouse");
                        if (GetAsyncKeyState(VK_XBUTTON1) & 0x8000)
                        {
                            aimbot_bones::aimbot({aim_screen.x, aim_screen.y}, {screen_center.x, screen_center.y}, aim_smoothness->get_value());
                        }
                    }
                }
            }
        }
    }
    else
    {
        // Aim Type is None. Reached once per frame in that mode, so it is not free
        // even though it does nothing -- but it is two stores, and a zone here would
        // measure the `else` rather than any cost.
        target_store = {};
        target_valid = false;
    }
}

void AimbotModule::init() {
    Il2CppImage *image = il2utils::resolve_image("Assembly-CSharp.dll");
    const Il2CppClass *player_class =
        il2utils::resolve_class(image, "EFT", "Player");
    const Il2CppClass *firearm_controller_class =
        il2utils::resolve_class_nested(player_class, "FirearmController");
    il2utils::hook_method(firearm_controller_class, "InitiateShot", 7,
        hk_initiate_shot, &o_initiate_shot);
}

#endif // INCLUDE_AIMBOT
