#include "common.h"
#include "InventoryEditorModule.h"

InventoryEditorModule::InventoryEditorModule() : Module("Item Editor", ItemSpawnerEditor, "gear_editor_mod"),
                                                 enchantment_percent(conf(
                                                     new FloatSliderEditableValue(1.f, 1.f, 100.f, "editor_enchantment_percent_txt"))),
                                                 threshold_amount(conf(
                                                     new FloatSliderEditableValue(1.f, 1.f, 100.f, "editor_enchantment_threshold_txt"))) {
    // Both sliders are positioned manually inside the Enchantment section (see
    // draw_menu_extra), so hide them from the generic card renderer — otherwise
    // each one is drawn twice. Only DRAWING is gated by this flag: ConfigModule
    // saves, loads, resets and favourites through Module::apply, which walks
    // every config value regardless, so the settings still persist.
    enchantment_percent->set_hidden_in_owner_menu(true);
    threshold_amount->set_hidden_in_owner_menu(true);
}

void InventoryEditorModule::draw_menu_extra() {
    const bool enabled = game_state::is_in_raid;
    if (!game_state::is_in_raid)
        imgui_addons::status_line("Enter a raid before refreshing backpack items.");

    if (ImGui::Button("Refresh Backpack Items", ImVec2(-1.f, 0.f)) && enabled)
        queue_refresh_ = true;

    const char* preview = "No item selected";
    if (selected_index_ >= 0 && selected_index_ < static_cast<int>(items_.size()))
        preview = items_[selected_index_].label.c_str();

    ImGui::BeginDisabled(!enabled || items_.empty());
    ImGui::TextUnformatted("Backpack item");
    ImGui::SetNextItemWidth(-1.f);
    if (ImGui::BeginCombo("##backpack_item", preview))
    {
        for (int i = 0; i < static_cast<int>(items_.size()); ++i)
        {
            const bool selected = selected_index_ == i;
            if (ImGui::Selectable(items_[i].label.c_str(), selected))
            {
                selected_index_ = i;
                gear_components_.clear();
            }
            if (selected) ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }

    ImGui::SeparatorText("Enchantment");
    // The type is not selectable. ERepairBuffType declares six values but only
    // three are implemented: WeaponSpread(0), DamageReduction(1) and
    // MalfunctionProtections(2). The other three -- WeaponDamage(3),
    // ArmorEfficiency(4), DurabilityImprovement(5) -- have no modifier field in
    // BuffComponent (only three exist, at +0x40/+0x48/+0x50) and no
    // EItemAttributeId (the enum has exactly six buff ids, 77-82, covering only
    // those three types x two rarities). UpdateModifiers sends them to a
    // `default:` branch that calls ResetEnhancedAttribute and returns, leaving
    // every modifier at its 1.0 baseline. This list used to offer Armor
    // Efficiency and Durability Improvement; both were silently no-ops.
    //
    // See BUFFCOMPONENT_NOTES.md for the disassembly and the full enum table.
    // Re-add an entry here only if BSG gives the type a representation.
    ImGui::TextUnformatted("Type: Damage Reduction");
    const char* rarities[] = {"Common", "Rare"};
    ImGui::SetNextItemWidth(-1.f);
    ImGui::Combo("Rarity", &enchantment_rarity_, rarities, IM_ARRAYSIZE(rarities));
    enchantment_percent->draw();
    threshold_amount->draw();
    if (ImGui::Button("Inspect Gear Components", ImVec2(-1.f, 0.f)) && has_selected_item())
        queue_inspect_gear_ = true;

    if (!gear_components_.empty())
    {
        ImGui::TextUnformatted("Detected soft armor and plates");
        for (int i = 1; i < gear_components_.size(); i++)
        {
            gear_component& component = gear_components_[i];
            ImGui::PushID(component.instance_id.c_str());
            ImGui::TextWrapped("%s", component.label.c_str());
            if (ImGui::Button("Enchant this component", ImVec2(-1.f, 0.f)))
                queue_enchantment_component_id_ = component.instance_id;
            ImGui::PopID();
        }
    }

    if (!enchantment_status_.empty())
        imgui_addons::status_line(enchantment_status_, true);

    ImGui::SeparatorText("Durability");
    if (ImGui::Button("Restore Gear Durability", ImVec2(-1.f, 0.f)) && has_selected_item())
        queue_restore_durability_tree_ = true;
    if (!durability_status_.empty())
        imgui_addons::status_line(durability_status_, true);

    ImGui::SeparatorText("Key / Keycard");
    ImGui::SetNextItemWidth(-1.f);
    ImGui::InputInt("Remaining Uses", &key_uses_);
    key_uses_ = (std::max)(0, key_uses_);
    if (ImGui::Button("Set Uses", ImVec2(-1.f, 0.f)) && has_selected_item())
        queue_key_uses_ = true;

    ImGui::EndDisabled();
}

void InventoryEditorModule::application_update() {}

void InventoryEditorModule::draw_overlay(ImDrawList*) {}

void InventoryEditorModule::init() {}

const InventoryEditorModule::external_result& InventoryEditorModule::last_external_result() const { return external_result_; }

void InventoryEditorModule::queue_weapon_enchantment_by_id(const std::string& id, int type, int rarity,
    float enchantmentPercentage, float thresholdAmount) {
    external_weapon_id_ = id;
    enchantment_type_ = type;
    enchantment_rarity_ = rarity;
    enchantment_percent_ = (std::clamp)(enchantmentPercentage, 1.f, 100.f);
    threshold_amount_ = (std::clamp)(thresholdAmount, 1.f, 100.f);
    publish_external(external_status::pending, external_action::enchantment,
        "Applying the weapon enchantment...");
}

void InventoryEditorModule::queue_weapon_durability_restore_by_id(const std::string& id) {
    external_weapon_durability_id_ = id;
    publish_external(external_status::pending, external_action::durability,
        "Restoring weapon durability...");
}

void InventoryEditorModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance main_player) {
    TA_ZONE_N("inventoryeditor::gameworld_update");
    if (!game_state::is_in_raid)
    {
        clear_queues();
        // A request can be issued from the menu and only reach gameworld_update
        // inside a raid, so without this the requesting card would sit on
        // "pending" indefinitely. Guarded so leaving a raid does not bump the
        // serial once per frame while the menu is open.
        if (external_result_.status != external_status::idle)
            publish_external(external_status::idle, external_action::none, {});
        return;
    }

    if (queue_refresh_)
    {
        queue_refresh_ = false;
        refresh_backpack_items(main_player);
    }

    if (!external_weapon_id_.empty())
    {
        const std::string target_id = external_weapon_id_;
        external_weapon_id_.clear();
        Il2CppObject* item = nullptr;
        const external_target target = resolve_external_weapon(main_player, target_id, item);

        // "Changed nothing" has three causes here, not one: the id resolved to
        // nothing, it resolved to something that is not a weapon, or it resolved
        // to a weapon that has no enchantment component to update. Collapsing them
        // into "no longer in the backpack" sent users looking for a missing item
        // that was sitting in their bag the whole time.
        bool applied = false;
        std::string message;
        if (target == external_target::missing)
            message = "Failed: the selected weapon is no longer in the backpack or equipment.";
        else if (target == external_target::not_a_weapon)
            message = "Failed: the selected item is not a weapon, so it has no weapon enchantment.";
        else
        {
            applied = apply_enchantment(item) > 0;
            // The applied percentages are echoed because this entry point clamps
            // them (0-8000 / 0-100) while the caller may have offered more. Without
            // that, the value in the requester's input box and the value in the
            // item silently disagree.
            message = applied
                ? "Applied weapon enchantment: value " + percent_text(enchantment_percent_)
                    + ", threshold " + percent_text(threshold_amount_) + "."
                : "Failed: this weapon exposes no enchantment component that could be updated.";
        }
        enchantment_status_ = message;
        publish_external(applied ? external_status::success : external_status::failure,
            external_action::enchantment, std::move(message));
        return;
    }

    if (!external_weapon_durability_id_.empty())
    {
        const std::string target_id = external_weapon_durability_id_;
        external_weapon_durability_id_.clear();
        Il2CppObject* item = nullptr;
        const external_target target = resolve_external_weapon(main_player, target_id, item);

        bool restored = false;
        std::string message;
        if (target == external_target::missing)
            message = "Failed: the selected weapon is no longer in the backpack or equipment.";
        else if (target == external_target::not_a_weapon)
            message = "Failed: the selected item is not a weapon, so it has no durability to restore.";
        else
        {
            restored = restore_durability(item) > 0;
            message = restored
                ? "Restored weapon durability and its maximum to the original template value."
                : "Failed: this weapon has no repairable component to restore.";
        }
        durability_status_ = message;
        publish_external(restored ? external_status::success : external_status::failure,
            external_action::durability, std::move(message));
        return;
    }

    // Composite armor can invalidate Tarkov's component iteration when
    // several embedded plates are modified together. Inspect it first and
    // only enqueue one explicitly selected component at a time.
    if (queue_inspect_gear_)
    {
        queue_inspect_gear_ = false;
        if (!has_selected_item()) return;
        const std::string selected_id = items_[selected_index_].instance_id;
        if (Il2CppObject* item = find_inventory_item(main_player, selected_id))
        {
            gear_components_.clear();
            collect_gear_enchantment_components(item, gear_components_);
            enchantment_status_ = gear_components_.empty()
                ? "No compatible gear or plates were found."
                : "Choose one armor component to enchant.";
        }
        return;
    }

    if (!queue_enchantment_component_id_.empty())
    {
        const std::string target_id = queue_enchantment_component_id_;
        int changed = 0;
        if (Il2CppObject* item = find_inventory_item(main_player, target_id))
        {
            // Process exactly one selected armor component per frame. This
            // avoids the collection rebuild caused by modifying an entire
            // vest and its inserts in the same operation.
            sync_enchantment_inputs();
            enchantment_type_ = k_gear_enchantment_type;
            changed = apply_enchantment(item);
        }
        enchantment_status_ = changed > 0
            ? "Enchantment applied to selected component."
            : "This plate has no safe enchantment component to update.";
        queue_enchantment_component_id_.clear();
        return;
    }

    if (!queue_restore_durability_ && !queue_restore_durability_tree_
        && !queue_key_uses_) return;
    if (!has_selected_item())
    {
        clear_queues();
        return;
    }

    const std::string selected_id = items_[selected_index_].instance_id;
    int changed = 0;
    if (Il2CppObject* item = find_inventory_item(main_player, selected_id))
    {
        if (queue_restore_durability_) changed += restore_durability(item);
        if (queue_restore_durability_tree_)
        {
            std::vector<Il2CppObject*> gear_tree;
            collect_selected_gear_and_plates(item, gear_tree);
            for (Il2CppObject* gear_piece : gear_tree)
                changed += restore_durability(gear_piece);
        }
        if (queue_key_uses_) changed += apply_key_uses(item, key_uses_);
    }
    logger::info("Item Editor changed " + std::to_string(changed) + " value(s). ");
    if (queue_restore_durability_ || queue_restore_durability_tree_)
        durability_status_ = changed > 0
            ? "Durability and maximum restored to the original template value."
            : "No repairable weapon, armor, or armor plate was found.";
    clear_queues();
}

InventoryEditorModule::external_target InventoryEditorModule::resolve_external_weapon(Il2CppObjectInstance main_player,
    const std::string& target_id, Il2CppObject*& out_item) {
    out_item = find_inventory_item(main_player, target_id);
    if (!eft_api::is_il2cpp_object_likely_valid(out_item)) return external_target::missing;
    if (!is_weapon(out_item)) return external_target::not_a_weapon;
    return external_target::ready;
}

void InventoryEditorModule::publish_external(const InventoryEditorModule::external_status status, const InventoryEditorModule::external_action action,
    std::string message) {
    external_result_.status = status;
    external_result_.action = action;
    external_result_.message = std::move(message);
    ++external_result_.serial;
}

void InventoryEditorModule::sync_enchantment_inputs() {
    enchantment_percent_ = (std::clamp)(enchantment_percent->get_value(), 1.f, 100.f);
    threshold_amount_ = (std::clamp)(threshold_amount->get_value(), 1.f, 100.f);
}

std::string InventoryEditorModule::percent_text(const float value) {
    std::string text = (std::format("{:.2f}", static_cast<double>(value)));
    while (text.size() > 1 && text.back() == '0') text.pop_back();
    if (!text.empty() && text.back() == '.') text.pop_back();
    return text + "%";
}

[[nodiscard]] bool InventoryEditorModule::has_selected_item() const {
    return selected_index_ >= 0 && selected_index_ < static_cast<int>(items_.size());
}

void InventoryEditorModule::clear_queues() {
    queue_refresh_ = false;
    queue_inspect_gear_ = false;
    queue_restore_durability_ = false;
    queue_restore_durability_tree_ = false;
    queue_key_uses_ = false;
    queue_enchantment_component_id_.clear();
}

std::string InventoryEditorModule::call_string_method(Il2CppObject* object, const char* method) {
    if (!eft_api::is_il2cpp_object_likely_valid(object)) return {};
    Il2CppObjectInstance instance(object);
    const auto get_string = instance.get_method<Il2CppString* (*)(Il2CppObject*)>(method, 0, false, false);
    if (!get_string) return {};
    Il2CppString* value = get_string(object);
    return value ? il2utils::conv_string(value) : std::string{};
}

std::string InventoryEditorModule::get_item_id(Il2CppObject* item) { return call_string_method(item, "get_Id"); }

std::string InventoryEditorModule::get_item_name(Il2CppObject* item) { return call_string_method(item, "get_Name"); }

std::string InventoryEditorModule::get_template_id(Il2CppObject* item) { return call_string_method(item, "get_StringTemplateId"); }

std::string InventoryEditorModule::get_localized_item_name(Il2CppObject* item) {
    static const Il2CppImage* assembly = il2utils::resolve_image("Assembly-CSharp.dll");
    static const Il2CppClass* extensions = il2utils::resolve_class(assembly, "EFT", "LocalizationExtensions");
    static const auto localized_name = il2utils::get_method<Il2CppString* (*)(Il2CppObject*)>(
        extensions, "LocalizedName", 1);
    if (!localized_name || !eft_api::is_il2cpp_object_likely_valid(item)) return {};
    Il2CppString* value = localized_name(item);
    return value ? il2utils::conv_string(value) : std::string{};
}

std::string InventoryEditorModule::get_database_item_name(const std::string& template_id) {
    return game_items::name_by_id(template_id);
}

bool InventoryEditorModule::set_signed_int_field(Il2CppObject* object, const char* field_name, int value) {
    if (!eft_api::is_il2cpp_object_likely_valid(object)) return false;
    const FieldInfo* field = il2utils::resolve_field(object->klass, field_name);
    if (!field) return false;
    *reinterpret_cast<int*>(reinterpret_cast<uintptr_t>(object) + field->offset) = value;
    return true;
}

bool InventoryEditorModule::set_float_field(Il2CppObject* object, const char* field_name, float value) {
    if (!eft_api::is_il2cpp_object_likely_valid(object)) return false;
    const FieldInfo* field = il2utils::resolve_field(object->klass, field_name);
    if (!field) return false;
    *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(object) + field->offset) = value;
    return true;
}

int InventoryEditorModule::restore_durability(Il2CppObject* item) {
    if (!eft_api::is_il2cpp_object_likely_valid(item)) return 0;
    Il2CppObject* repairable = eft_api::try_get_field_object(item, "Repairable");
    if (!repairable)
    {
        if (Il2CppObject* armor = eft_api::try_get_field_object(item, "Armor"))
            repairable = eft_api::try_get_field_object(armor, "Repairable");
    }
    if (!eft_api::is_il2cpp_object_likely_valid(repairable)) return 0;

    const FieldInfo* maximum = il2utils::resolve_field(repairable->klass, "MaxDurability");
    if (!maximum || !il2utils::resolve_field(repairable->klass, "Durability")) return 0;

    // MaxDurability is reduced permanently by normal repair actions. The
    // component exposes TemplateDurability, which is the original template
    // value, so restore both the ceiling and its current durability without
    // changing the shared item template.
    Il2CppObjectInstance repairable_instance(repairable);
    const auto get_template_durability = repairable_instance.get_method<int (*)(Il2CppObject*)>(
        "get_TemplateDurability", 0, false, false);
    const float current_max = *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(repairable) + maximum->offset);
    const float original_max = get_template_durability
        ? static_cast<float>(get_template_durability(repairable))
        : current_max;
    if (original_max <= 0.f) return 0;

    const bool restored_max = set_float_field(repairable, "MaxDurability", original_max);
    const bool restored_current = set_float_field(repairable, "Durability", original_max);
    return restored_max && restored_current ? 1 : 0;
}

int InventoryEditorModule::apply_enchantment(Il2CppObject* item) const {
    Il2CppObject* buff = find_existing_buff(item);
    // Standalone weapons expose Buff directly, while armor and plates
    // expose it through their ArmorComponent. The manual component path
    // below creates only one missing buff at a time.
    //
    // Creating is unconditional: both call sites wanted it, so the old
    // `allow_create` parameter was always true and is gone.
    if (!buff && can_hold_buff(item))
        buff = create_and_attach_buff(item);
    if (!eft_api::is_il2cpp_object_likely_valid(buff)) return 0;

    // The backing fields alone are not enough: set_Value refreshes the
    // derived weapon/armor modifier fields used by the game.  The earlier
    // version wrote the fields directly, leaving an apparently valid buff
    // with no gameplay effect.
    Il2CppObjectInstance buff_instance(buff);
    const auto set_type = buff_instance.get_method<void (*)(Il2CppObject*, int)>("set_BuffType", 1, false, false);
    const auto set_value = buff_instance.get_method<void (*)(Il2CppObject*, double)>("set_Value", 1, false, false);
    const auto set_threshold = buff_instance.get_method<void (*)(Il2CppObject*, double)>("set_ThresholdDurability", 1, false, false);
    const FieldInfo* rarity = il2utils::resolve_field(buff->klass, "Rarity");
    if (!set_type || !set_value || !rarity) return 0;

    set_type(buff, enchantment_type_);
    *reinterpret_cast<int*>(reinterpret_cast<uintptr_t>(buff) + rarity->offset) = enchantment_rarity_;
    // The game displays this modifier as (1 - Value) * 100.  Convert the
    // UI percentage into its internal multiplier: 100% -> 0.0, 50% ->
    // 0.5, and 0% -> 1.0.  Passing 100 directly produced -9900%.
    set_value(buff, 1.0 - static_cast<double>(enchantment_percent_) / 100.0);
    set_threshold(buff, 1.0 - static_cast<double>(threshold_amount_) / 100.0);
    return 1;
}

bool InventoryEditorModule::set_object_field(Il2CppObject* object, const char* field_name, Il2CppObject* value) {
    if (!eft_api::is_il2cpp_object_likely_valid(object)) return false;
    const FieldInfo* field = il2utils::resolve_field(object->klass, field_name);
    if (!field) return false;
    *reinterpret_cast<Il2CppObject**>(reinterpret_cast<uintptr_t>(object) + field->offset) = value;
    return true;
}

Il2CppObject* InventoryEditorModule::create_and_attach_buff(Il2CppObject* item) {
    // dump.cs (46699): BuffComponent has .ctor(Item item). Allocate it
    // through IL2CPP so Unity's GC tracks the object, then add it to the
    // inherited Item.Components list before exposing it on the item field.
    if (!can_hold_buff(item)) return nullptr;
    const Il2CppImage* assembly = il2utils::resolve_image("Assembly-CSharp.dll");
    const Il2CppClass* buff_class = il2utils::resolve_class(assembly, "EFT.InventoryLogic", "BuffComponent");
    if (!buff_class) return nullptr;
    Il2CppObject* buff = il2cpp::il2cpp_object_new(buff_class);
    if (!buff) return nullptr;

    Il2CppObjectInstance buff_instance(buff);
    const auto ctor = buff_instance.get_method<void (*)(Il2CppObject*, Il2CppObject*)>(".ctor", 1, false, false);
    if (!ctor) return nullptr;
    ctor(buff, item);

    // Weapons and vests expose Buff directly. Armored equipment and armor
    // plates instead own it through ArmorComponent.Buff (including the
    // Black Division variants). Set the target before adding the component
    // to its item list, so an unsupported item is left untouched.
    bool attached = set_object_field(item, "Buff", buff);
    if (!attached)
    {
        if (Il2CppObject* armor = eft_api::try_get_field_object(item, "Armor"))
            attached = set_object_field(armor, "Buff", buff);
    }
    if (!attached) return nullptr;

    if (Il2CppObject* components = eft_api::try_get_field_object(item, "Components"))
    {
        Il2CppObjectInstance components_instance(components);
        const auto add = components_instance.get_method<void (*)(Il2CppObject*, Il2CppObject*)>("Add", 1, false, false);
        if (add) add(components, buff);
    }
    return buff;
}

bool InventoryEditorModule::can_hold_buff(Il2CppObject* item) {
    if (!eft_api::is_il2cpp_object_likely_valid(item)) return false;
    if (il2utils::resolve_field(item->klass, "Buff") != nullptr) return true;
    if (Il2CppObject* armor = eft_api::try_get_field_object(item, "Armor"))
        return il2utils::resolve_field(armor->klass, "Buff") != nullptr;
    return false;
}

bool InventoryEditorModule::is_weapon(Il2CppObject* item) {
    if (!eft_api::is_il2cpp_object_likely_valid(item)) return false;
    // Weapons have several concrete subclasses (AssaultRifle, Pistol,
    // Shotgun, etc.), so identify the Weapon base in the IL2CPP hierarchy.
    for (const Il2CppClass* clazz = item->klass; clazz; clazz = clazz->parent)
        if (clazz->name && std::string(clazz->name) == "Weapon") return true;
    return false;
}

Il2CppObject* InventoryEditorModule::find_existing_buff(Il2CppObject* item) {
    if (!eft_api::is_il2cpp_object_likely_valid(item)) return nullptr;
    if (Il2CppObject* buff = eft_api::try_get_field_object(item, "Buff")) return buff;
    if (Il2CppObject* armor = eft_api::try_get_field_object(item, "Armor"))
        if (Il2CppObject* buff = eft_api::try_get_field_object(armor, "Buff")) return buff;

    // Armored gear often exposes ArmorComponent only through the inherited
    // Item.Components list rather than an item field in this game build.
    Il2CppObject* components = eft_api::try_get_field_object(item, "Components");
    if (!eft_api::is_il2cpp_object_likely_valid(components)) return nullptr;
    Il2CppObjectInstance list(components);
    const auto get_count = list.get_method<int (*)(Il2CppObject*)>("get_Count", 0, false, false);
    const auto get_item = list.get_method<Il2CppObject* (*)(Il2CppObject*, int)>("get_Item", 1, false, false);
    if (!get_count || !get_item) return nullptr;
    const int count = (std::clamp)(get_count(components), 0, 64);
    for (int i = 0; i < count; ++i)
    {
        Il2CppObject* component = get_item(components, i);
        if (!eft_api::is_il2cpp_object_likely_valid(component) || !component->klass) continue;
        const std::string class_name = component->klass->name ? component->klass->name : "";
        if (class_name.find("BuffComponent") != std::string::npos) return component;
        if (class_name.find("ArmorComponent") != std::string::npos)
            if (Il2CppObject* buff = eft_api::try_get_field_object(component, "Buff")) return buff;
    }
    return nullptr;
}

int InventoryEditorModule::apply_key_uses(Il2CppObject* item, int uses) {
    // 46699: Key has KeyComponent at 0x78. Keycard inherits that field;
    // its separate KeycardComponent contains the same key at Key.
    if (Il2CppObject* key = eft_api::try_get_field_object(item, "KeyComponent"))
        return set_remaining_key_uses(key, uses);
    if (Il2CppObject* keycard_component = eft_api::try_get_field_object(item, "KeycardComponent"))
    {
        if (Il2CppObject* key = eft_api::try_get_field_object(keycard_component, "Key"))
            return set_remaining_key_uses(key, uses);
    }
    // A standalone key may itself be a KeyComponent-derived item in future builds.
    return set_remaining_key_uses(item, uses);
}

int InventoryEditorModule::set_remaining_key_uses(Il2CppObject* key_component, int requested_remaining) {
    // EFT displays remaining uses as MaximumNumberOfUsage - NumberOfUsages.
    // Change this specific key/keycard only. Keep the template maximum
    // untouched and represent extra remaining uses with a negative
    // consumed-use value (e.g. 999/10 stores -989).
    Il2CppObject* template_object = eft_api::try_get_field_object(key_component, "Template");
    if (!eft_api::is_il2cpp_object_likely_valid(template_object)) return 0;

    const int requested = (std::max)(0, requested_remaining);
    const int maximum = eft_api::try_get_field_int(template_object, "MaximumNumberOfUsage");
    if (maximum <= 0) return 0;
    return set_signed_int_field(key_component, "NumberOfUsages", maximum - requested) ? 1 : 0;
}

void InventoryEditorModule::refresh_backpack_items(Il2CppObjectInstance main_player) {
    std::vector<Il2CppObject*> raw_items;
    collect_backpack_items(main_player, raw_items);
    items_.clear();
    selected_index_ = -1;
    for (Il2CppObject* item : raw_items)
    {
        const std::string id = get_item_id(item);
        if (id.empty()) continue;
        const std::string template_id = get_template_id(item);
        // Match the spawn menu: prefer the curated item database's English
        // name instead of Item.Name, which may be an internal name/ID.
        std::string name = get_database_item_name(template_id);
        if (name.empty()) name = get_localized_item_name(item);
        if (name.empty()) name = get_item_name(item);
        if (name.empty()) name = item->klass && item->klass->name ? item->klass->name : "Unknown item";
        items_.push_back({id, name});
    }
    logger::info("Item Editor found " + std::to_string(items_.size()) + " backpack item(s).");
}

void InventoryEditorModule::collect_selected_gear_and_plates(Il2CppObject* gear, std::vector<Il2CppObject*>& out,
    const int depth) {
    if (!eft_api::is_il2cpp_object_likely_valid(gear) || depth > 3 || out.size() >= 32) return;
    out.push_back(gear);

    // Armor inserts live in direct slots. Limit traversal to slots only:
    // this avoids the non-inventory grid data exposed by some Black
    // Division gear while still reaching every installed armor layer.
    Il2CppArray* slots = eft_api::try_get_array_field(gear, "Slots");
    if (!slots || slots->max_length > 32) return;
    if (!eft_api::is_readable_address(&slots->data, slots->max_length * sizeof(Il2CppObject*))) return;
    for (size_t i = 0; i < slots->max_length; ++i)
    {
        Il2CppObject* slot = reinterpret_cast<Il2CppObject**>(&slots->data)[i];
        if (!eft_api::is_il2cpp_object_likely_valid(slot)) continue;
        Il2CppObject* plate = eft_api::try_get_backing_field_object(
            slot, "<ContainedItem>k__BackingField", "ContainedItem");
        if (eft_api::is_il2cpp_object_likely_valid(plate))
            collect_selected_gear_and_plates(plate, out, depth + 1);
    }
}

std::string InventoryEditorModule::get_component_display_name(Il2CppObject* item) {
    if (!eft_api::is_il2cpp_object_likely_valid(item)) return "Unknown";
    std::string name = get_database_item_name(get_template_id(item));
    if (name.empty()) name = get_localized_item_name(item);
    if (name.empty()) name = get_item_name(item);
    if (name.empty() && item->klass && item->klass->name) name = item->klass->name;
    return name.empty() ? "Unknown" : name;
}

std::string InventoryEditorModule::get_slot_display_name(Il2CppObject* slot) {
    std::string name = call_string_method(slot, "get_Name");
    if (name.empty()) name = call_string_method(slot, "get_ID");
    if (name.empty() && slot && slot->klass && slot->klass->name) name = slot->klass->name;
    return name.empty() ? "armor slot" : name;
}

bool InventoryEditorModule::is_plate_slot(std::string name) {
    std::transform(name.begin(), name.end(), name.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return name.find("plate") != std::string::npos;
}

void InventoryEditorModule::collect_gear_enchantment_components(Il2CppObject* gear, std::vector<InventoryEditorModule::gear_component>& out) {
    if (!eft_api::is_il2cpp_object_likely_valid(gear)) return;

    // The outer item owns its integrated soft armor. Component-button
    // application is update-only, just like the individual plate entries.
    const std::string gear_id = get_item_id(gear);
    if (!gear_id.empty())
        out.push_back({gear_id, "Integrated soft armor: " + get_component_display_name(gear)});

    // Modern rigs/armor expose each insert as a direct slot. This lists
    // every contained soft-armor insert and plate separately; it does not
    // recurse into grids, which are unsafe on composite armor in a raid.
    Il2CppArray* slots = eft_api::try_get_array_field(gear, "Slots");
    if (!slots || slots->max_length > 32) return;
    if (!eft_api::is_readable_address(&slots->data, slots->max_length * sizeof(Il2CppObject*))) return;
    for (size_t i = 0; i < slots->max_length; ++i)
    {
        Il2CppObject* slot = reinterpret_cast<Il2CppObject**>(&slots->data)[i];
        if (!eft_api::is_il2cpp_object_likely_valid(slot)) continue;
        Il2CppObject* insert = eft_api::try_get_backing_field_object(
            slot, "<ContainedItem>k__BackingField", "ContainedItem");
        if (!eft_api::is_il2cpp_object_likely_valid(insert)) continue;
        const std::string insert_id = get_item_id(insert);
        if (insert_id.empty()) continue;

        const std::string slot_name = get_slot_display_name(slot);
        const char* kind = is_plate_slot(slot_name) ? "Armor plate" : "Soft armor";
        out.push_back({insert_id, std::string(kind) + " (" + slot_name + "): " + get_component_display_name(insert)});
    }
}

Il2CppObject* InventoryEditorModule::find_item_in_tree(Il2CppObject* item, const std::string& wanted_id, const int depth) {
    if (!eft_api::is_il2cpp_object_likely_valid(item) || depth > 5) return nullptr;
    if (get_item_id(item) == wanted_id) return item;

    // Recurse through both grids and slots. Armor inserts live in Slots,
    // while a worn rig/armor may itself be reached from an equipment slot.
    if (Il2CppArray* grids = eft_api::try_get_array_field(item, "Grids"))
    {
        const size_t count = (std::min)(grids->max_length, static_cast<size_t>(16));
        for (size_t i = 0; i < count; ++i)
        {
            Il2CppObject* grid = reinterpret_cast<Il2CppObject**>(&grids->data)[i];
            if (!eft_api::is_il2cpp_object_likely_valid(grid)) continue;
            Il2CppObject* collection = eft_api::try_get_backing_field_object(
                grid, "<ItemCollection>k__BackingField", "ItemCollection");
            std::vector<Il2CppObject*> children;
            eft_api::append_list_items(collection ? eft_api::try_get_field_object(collection, "ItemsList") : nullptr,
                children, 128);
            for (Il2CppObject* child : children)
                if (Il2CppObject* found = find_item_in_tree(child, wanted_id, depth + 1)) return found;
        }
    }
    if (Il2CppArray* slots = eft_api::try_get_array_field(item, "Slots"))
    {
        const size_t count = (std::min)(slots->max_length, static_cast<size_t>(32));
        for (size_t i = 0; i < count; ++i)
        {
            Il2CppObject* slot = reinterpret_cast<Il2CppObject**>(&slots->data)[i];
            Il2CppObject* child = eft_api::try_get_backing_field_object(
                slot, "<ContainedItem>k__BackingField", "ContainedItem");
            if (Il2CppObject* found = find_item_in_tree(child, wanted_id, depth + 1)) return found;
        }
    }
    return nullptr;
}

Il2CppObject* InventoryEditorModule::find_inventory_item(Il2CppObjectInstance main_player, const std::string& wanted_id) {
    Il2CppObject* controller = eft_api::try_get_field_object(main_player.get_instance(), "_inventoryController");
    if (!controller) return nullptr;
    Il2CppObjectInstance controller_instance(controller);
    const auto get_inventory = controller_instance.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_Inventory", 0, false, false);
    Il2CppObject* inventory = get_inventory ? get_inventory(controller) : nullptr;
    Il2CppObject* equipment = inventory ? eft_api::try_get_field_object(inventory, "Equipment") : nullptr;
    if (!equipment) return nullptr;
    Il2CppObjectInstance equipment_instance(equipment);
    const auto get_slot = equipment_instance.get_method<Il2CppObject* (*)(Il2CppObject*, int)>("GetSlot", 1, false, false);
    if (!get_slot) return nullptr;

    // All player equipment roots are considered, so the armor currently
    // worn by the player is resolved as reliably as items in the backpack.
    for (int index = 0; index < 16; ++index)
    {
        Il2CppObject* slot = get_slot(equipment, index);
        Il2CppObject* root = eft_api::try_get_backing_field_object(slot,
            "<ContainedItem>k__BackingField", "ContainedItem");
        if (Il2CppObject* found = find_item_in_tree(root, wanted_id)) return found;
    }
    return nullptr;
}

void InventoryEditorModule::collect_backpack_items(Il2CppObjectInstance main_player, std::vector<Il2CppObject*>& out) {
    Il2CppObject* controller = eft_api::try_get_field_object(main_player.get_instance(), "_inventoryController");
    if (!controller) return;
    Il2CppObjectInstance controller_instance(controller);
    const auto get_inventory = controller_instance.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_Inventory", 0, false, false);
    if (!get_inventory) return;
    Il2CppObject* inventory = get_inventory(controller);
    Il2CppObject* equipment = eft_api::try_get_field_object(inventory, "Equipment");
    if (!equipment) return;
    Il2CppObjectInstance equipment_instance(equipment);
    const auto get_slot = equipment_instance.get_method<Il2CppObject* (*)(Il2CppObject*, int)>("GetSlot", 1, false, false);
    if (!get_slot) return;

    // EquipmentSlot.Backpack is 4; only that tree is exposed by this editor.
    Il2CppObject* backpack_slot = get_slot(equipment, 4);
    if (!backpack_slot) return;
    Il2CppObjectInstance slot_instance(backpack_slot);
    const auto get_contained = slot_instance.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_ContainedItem", 0, false, false);
    if (get_contained)
    {
        Il2CppObject* backpack = get_contained(backpack_slot);
        if (eft_api::is_il2cpp_object_likely_valid(backpack))
        {
            out.push_back(backpack);
            eft_api::collect_compound_items_recursive(backpack, out);
        }
    }
}
