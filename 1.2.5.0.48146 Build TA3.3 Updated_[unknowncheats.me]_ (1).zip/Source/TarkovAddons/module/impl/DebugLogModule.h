#pragma once

#include <Windows.h>
#include <atomic>
#include <cstring>
#include <deque>
#include <filesystem>
#include <fstream>
#include <imgui.h>
#include <string>

#include "../Module.h"
#include "../ModuleCategory.h"
#include "../../config/CheckboxValue.h"
#include "../../gui/menu/imgui_addons.h"
#include "../../util/logger.h"
#include "../../../shared/module_paths.h"
#include "../../util/tracy_bridge.h"

// Reads the crash-safe logger mirror (next to the DLL, see logger.cpp) and toggles the
// DEBUG log level at runtime. DEBUG lines are diagnostic spam (per-resume state dumps,
// shape logs, per-call traces) that normal play does not need; INFO/WARN/ERROR always
// print.
//
// 2026-09-26: this card previously had its OWN "DebugLogging" checkbox in addition to
// the dashboard's "Show Debug Log". Two toggles for one feature let you enable the
// card and see nothing in it, or spam DEBUG output with no way to read it. There is
// now ONE toggle — the dashboard's "Show Debug Log" — and it does both: it reveals
// this card and enables DEBUG output. The old per-module key is no longer read, so
// the two can no longer disagree.
class DebugLogModule final : public Module
{
  public:
    DebugLogModule();

    // Single source of truth is the dashboard's "Show Debug Log" checkbox, but
    // ModuleManager includes this header, so the dependency cannot be inverted here.
    // RaidDashboardModule pushes the value in each frame via set_enabled(); the
    // default is off so a missing push can never silently enable DEBUG spam.
    static void set_enabled(const bool enabled);
    static bool enabled();

    void draw_overlay(ImDrawList*) override;

    void application_update() override;

    void gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) override;
    void init() override;

    // Tracy profiler opt-in, drawn above the log dump.
    //
    // Deliberately inside the DEBUG card: a profiler thread inside an injected
    // DLL is a fingerprint, so enabling it is an explicit per-session act
    // alongside the other diagnostics, never a build-time default. The whole
    // block is compiled out of Prod* (no TRACY_ENABLE), so Prod builds show
    // nothing here and pay nothing.
    void draw_tracy_controls();

    void draw_menu_extra() override;

  private:
    static inline std::atomic<bool> s_enabled{true};

    std::string log_text_;
    std::string copy_status_;

    // The mirror lives next to the DLL (module_paths resolves it; it is the same path
    // logger.cpp writes), not at C:\ - the old hard-coded path read a stale root file.
    static std::filesystem::path log_mirror_path();

    static std::string read_recent_log();

    static bool copy_to_clipboard(const std::string& text);
};
