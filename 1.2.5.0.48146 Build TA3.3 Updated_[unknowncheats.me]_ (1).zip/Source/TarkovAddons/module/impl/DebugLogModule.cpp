#include "common.h"
#include "DebugLogModule.h"

DebugLogModule::DebugLogModule() : Module("Debug Log", RaidDashboard, "debug_log_mod") {}

void DebugLogModule::set_enabled(const bool enabled) { s_enabled.store(enabled); }

bool DebugLogModule::enabled() { return s_enabled.load(); }

void DebugLogModule::draw_overlay(ImDrawList*) {}

void DebugLogModule::application_update() {
    TA_ZONE_N("debuglog::application_update");
    logger::set_debug_enabled(enabled());
}

void DebugLogModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) {}

void DebugLogModule::init() {
    logger::set_debug_enabled(enabled());
}

void DebugLogModule::draw_tracy_controls() {
#ifdef TRACY_ENABLE
    ImGui::SeparatorText("Profiler (Tracy)");
    ImGui::TextWrapped(
        "Starts an in-process profiler server on 127.0.0.1. Run the Tracy client and press "
        "Connect. Useful for 'where did the time go' questions; the flame graph is the "
        "answer, this toggle is only the door.");

    if (tracy::profiler::running())
    {
        const bool attached = tracy::profiler::client_attached();
        // Sampling is only worth its cost while something is listening.
        if (ImGui::Button(attached ? "Stop Profiler (client attached)" : "Stop Profiler",
                ImVec2(-1.f, 0.f)))
        {
            tracy::profiler::stop();
            logger::info("tracy: profiler stopped");
        }
        ImGui::SameLine();
        ImGui::TextDisabled(attached ? "client connected" : "waiting for client...");
    }
    else if (ImGui::Button("Start Profiler", ImVec2(-1.f, 0.f)))
    {
        tracy::profiler::start();
        logger::info("tracy: profiler started on 127.0.0.1:8086 - connect the Tracy client");
    }
#else
    ImGui::SeparatorText("Profiler (Tracy)");
    // This branch is currently UNREACHABLE: TRACY_ENABLE is defined in all four x64
    // configurations, including both Prod ones, so #ifdef TRACY_ENABLE is always
    // true here. The message used to say "TRACY_ENABLE is Debug/Release only",
    // which has been false since the Prod configs gained it -- and a false claim
    // in a diagnostic panel is worse than none, because it is what you read when
    // the profiler does not show up. Stated as the condition rather than the
    // configuration list, so it cannot go stale again.
    ImGui::TextDisabled("Not available in this build (compiled without TRACY_ENABLE).");
#endif
}

void DebugLogModule::draw_menu_extra() {
    draw_tracy_controls();
    ImGui::Separator();
    log_text_ = read_recent_log();
    if (ImGui::Button("Copy Log to Clipboard", ImVec2(-1.f, 0.f)))
        copy_status_ = copy_to_clipboard(log_text_) ? "Log copied to clipboard." : "Could not copy the log.";
    if (!copy_status_.empty())
        imgui_addons::status_line(copy_status_, true);

    // Tall, borderless-scrollable child: 220 px was too short to read, and the
    // fixed window gave no room to grow it. Sized off the (now larger) menu
    // window; wrapped so long lines stay inside the panel.
    ImGui::BeginChild("##debug_log_output", ImVec2(0.f, 520.f * menu::get_scale_factor()), true);
    if (log_text_.empty())
        ImGui::TextUnformatted("No log entries yet.");
    else
    {
        ImGui::PushTextWrapPos(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x);
        ImGui::TextWrapped("%s", log_text_.c_str());
        ImGui::PopTextWrapPos();
    }
    ImGui::EndChild();
}

std::filesystem::path DebugLogModule::log_mirror_path() {
    const std::string dir = module_paths::dll_directory_utf8();
    return dir.empty() ? std::filesystem::path("tarkovaddons_log.txt")
                       : std::filesystem::path(dir) / "tarkovaddons_log.txt";
}

std::string DebugLogModule::read_recent_log() {
    std::ifstream file(log_mirror_path());
    if (!file) return {};

    std::deque<std::string> lines;
    std::string line;
    while (std::getline(file, line))
    {
        lines.push_back(line);
        if (lines.size() > 120) lines.pop_front();
    }

    std::string output;
    for (const std::string& entry : lines)
        output += entry + "\n";
    return output;
}

bool DebugLogModule::copy_to_clipboard(const std::string& text) {
    if (text.empty() || !OpenClipboard(nullptr)) return false;
    EmptyClipboard();
    HGLOBAL memory = GlobalAlloc(GMEM_MOVEABLE, text.size() + 1);
    if (!memory)
    {
        CloseClipboard();
        return false;
    }
    void* target = GlobalLock(memory);
    if (!target)
    {
        GlobalFree(memory);
        CloseClipboard();
        return false;
    }
    memcpy(target, text.c_str(), text.size() + 1);
    GlobalUnlock(memory);
    if (!SetClipboardData(CF_TEXT, memory))
    {
        GlobalFree(memory);
        CloseClipboard();
        return false;
    }
    CloseClipboard();
    return true;
}
