#pragma once

// Hideout Improvements — READ-ONLY.
//
// This file used to be HideoutAutomationModule: unattended auto-collect and auto-queue, plus a
// "fake workout" button. All of that is gone, deliberately, and the reasoning is worth keeping
// here so it is not rebuilt by accident.
//
// WHY IT WAS REMOVED
//
// 1. The queueing verbs do not craft for you; they ask the SERVER to. StartSingleProduction takes
//    (recipeId, IEnumerable<ItemToHandover> items, IEnumerable<ItemToHandover> tools) and the
//    handover array this module built was frequently EMPTY. Sending an empty handover and asking
//    for a production to start is a request for the server to source the materials, not a request
//    to spend the player's own. The server's answer proved it: pressing Collect produced
//
//        228 - ItemsMoving: Template 5c052fb986f7746b2101e909 not found
//
//    which is the server refusing because the template is not in the player's inventory. So the
//    feature never worked as "automation of your own crafting"; it was leaning on the server to
//    gather items, and failing when it would not.
//
// 2. Auto-collect is the same request with extra steps — TakeHideoutProduction on a timer.
//    "Taking" a finished production is a server-side pickup, not a local acknowledgement, so
//    automating it is automating an inventory transaction on the player's behalf.
//
// 3. The workout button was forging a minigame result: it rolled a physical skill and a success
//    rate locally and submitted the outcome. The skill and the outcome are the SERVER's to pick
//    (ISIL EFT/SkillManager.txt:15196-15365 shows the bench collecting Endurance, Strength,
//    Vitality and Health into an array for the interaction to choose from), so a client-side roll
//    is a forged result, not a simulation.
//
// 4. LATER, AND AGAINST (1)-(3): "QTE always succeeds" (qte_always_success, below) forces a
//    minigame outcome too. It is kept, and the disagreement is recorded rather than smoothed over,
//    because the two are not the same claim and only one of them is certain:
//      * the workout button INVENTED data (a skill roll the game had already resolved elsewhere);
//      * this one REPLACES an answer the client itself computes, in code read from the shipped
//        binary rather than guessed (see the control flow below).
//    What this module cannot know, and does not claim, is whether the server re-checks a QTE
//    outcome. `QTEController` fills a `QTEResult` locally and the hideout interaction consumes it;
//    nothing here has been traced far enough to say what crosses the wire afterwards. So the
//    honest statement is that the CLIENT reports success every time, and whether that survives
//    contact with the server is the next thing an in-game run would have to show.
//
// None of these are "ease of use". They remove the player's inventory and their server from the
// loop, which is the line. What remains here touches nothing: it reads state the client already
// holds and reports it.
//
// WHAT THIS CARD IS NOW
//
// Three read-cost knobs, one readout, and one minigame modifier — see note 4 above for the one
// that is not read-only. The recipe knob stops the recipe list being re-fetched, which is worth
// having on its own merits: GetProductionRecipes is a managed round trip returning ~260 scheme
// objects, and re-running it on a clock recomputes a list that does not change while the player
// stands in the hideout. Turning it off makes the list load once and stay put.
//
// The three read-cost toggles live in hideout_reflection.h rather than here, because the code that
// honours them is in HideoutModule — this module owns no refresh of its own. A file-scope toggle in
// the shared header is what keeps the two modules from needing a pointer to each other. The QTE
// toggle below is the exception: nothing else honours it, so it lives here with its hook.

#include <cstdint>
#include <string>

#include "../Module.h"
#include "../ModuleCategory.h"
#include "../hideout_reflection.h"
#include "../il2cpp/il2utils.h"
#include "../../config/CheckboxValue.h"
#include "../../gui/menu/imgui_addons.h"
#include "../../gui/menu/menu.h"

// ---------------------------------------------------------------------------
// "QTE always succeeds"
// ---------------------------------------------------------------------------
//
// WHERE THE HOOK GOES, AND WHY IT IS THAT HOOK
//
// The QTE minigame is EFT.Hideout: QTEController runs a sequence of QuickTimeEvent entries,
// SpawnAction builds a QTEAction per entry, and the concrete QTEAction in this build is
// ShrinkingCircleQTE — the ONLY subclass, counted across the whole of Assembly-CSharp in the dump
// for the build this tree targets. Its verdict is a single call, and the control flow around it was
// READ from the installed GameAssembly.dll (tools/pe_disasm.py, build 120047965, using the dump's
// own RVAs) rather than inferred from the signatures:
//
//     <Process>d__32.MoveNext:
//       0x2002BE7  call  ShrinkingCircleQTE.IsSuccessInput
//       0x2002BF6  test  al, al
//       0x2002BF8  je    -> the failure edge
//       0x2002BFE  mov   dl, 1            ; success = true
//       0x2002C00  call  Finish
//     ...and the failure edge, which lands on the SAME Finish call:
//       0x2002C8B  xor   edx, edx          ; success = false
//       0x2002C8D  call  Finish
//
// So both edges funnel through one call, and IsSuccessInput decides the reported outcome of every
// action — INCLUDING the timeout one: a wait that ends without input still reaches it. That is why
// the timeout is covered rather than special-cased.
//
// Its body, also read:
//
//     scale = _dynamicCircleImage.transform.localScale.x
//     return scale within [_successStartScale, _successEndScale]
//            && Input.GetKeyDown(_targetInput);
//
// It is a PURE query — two field reads and one Input call, no side effects — so returning true
// REPLACES an answer rather than skipping a step the game needs. The alternatives were rejected for
// reasons, not taste: hooking Finish() means forwarding a CancellationToken struct by value
// through a detour that never sees the MethodInfo* argument, which is more ABI surface than this
// needs for the same answer; and widening `_successRange` does not survive contact with
// PrepareAction(), which recomputes the two doubles from it on every action.
//
// WHAT IS NOT CLAIMED
//
// Whether the server accepts the result is unknown here; see note 4 in the header comment. And a
// build that adds a SECOND QTEAction subclass would need a second hook — the install log line names
// what was hooked, so that gap shows up in the log rather than as a toggle that quietly does
// nothing.

// Default FALSE, which is the opposite of its three siblings and deliberate: those default to the
// cheaper behaviour, this one defaults to the game's own. The CheckboxValue ctor below says false
// too, and the two must agree — this flag is only ever written from draw_menu_extra(), which a
// folded card never calls, so the static initialiser is what actually runs (the same trap
// hideout_reflection.h records for its own knobs).
inline bool& hideout_qte_always_success_flag() {
    static bool always = false;
    return always;
}

inline void hideout_set_qte_always_success(const bool always) {
    // Change-gated for the reason every other knob in this card is: this is called every frame the
    // card is unfolded, and an ungated line would bury the transition in noise. It also makes the
    // moment attributable — if this line is absent from a session, the toggle never ran.
    if (hideout_qte_always_success_flag() != always)
        logger::info(std::string("hideout-knob: qte_always_success ") + (always ? "true" : "false")
            + (always ? " -> QTE results forced to success" : " -> game decides again"));
    hideout_qte_always_success_flag() = always;
}

inline bool hideout_qte_always_success() {
    return hideout_qte_always_success_flag();
}

// No null check on the trampoline, and that is deliberate rather than lazy: this function is only
// ever reached THROUGH the detour, so a null here would mean the detour was installed without a
// trampoline, which hook_method cannot do. The sibling hooks in PlayerModule.h are written the
// same way.
using qte_is_success_input_sig = bool (*)(Il2CppObject*);

inline qte_is_success_input_sig o_qte_is_success_input;

inline bool hk_qte_is_success_input(Il2CppObject* instance) {
    if (hideout_qte_always_success()) {
        // Logged ONCE per enable, not per action. This is the line that turns "the toggle is on"
        // into "the hook is actually reached", which is the difference between a feature that
        // works and one that merely installed: the two are indistinguishable from the menu, and
        // an in-game run is the only place the difference can show up.
        static bool announced = false;
        if (!announced) {
            announced = true;
            logger::info("hideout QTE: IsSuccessInput overridden -> reporting success");
        }
        return true;
    }
    return o_qte_is_success_input(instance);
}

class HideoutAutomationModule final : public Module
{
  public:
    HideoutAutomationModule();

    // The single knob. Default ON, so behaviour is unchanged until the player opts out.
    //
    // The label says what it does rather than what it is, because "reload recipes" reads as a
    // button and this is a switch: unticking it pins the list.
    CheckboxValue* reload_recipes;

    // The second knob, and it is a SEPARATE one on purpose - see the coalescing note in
    // module/hideout_reflection.h. This one governs how often the GAME re-renders its station
    // views (~245 ms per rebuild on the Workbench, on every action); the one above governs our own
    // 30 s recipe fetch. Bundled, unticking one would silently change the cost of the other.
    CheckboxValue* rebuild_freely;

    // The third knob, and the only one that changes WHICH rows are drawn rather than how often
    // something is fetched or re-rendered. On: the crafting list narrows to whatever station the
    // player has open, using that panel's own <Schemes> set. Off: the whole hideout, as before.
    // Default ON, like its siblings, so unticking is the opt-in.
    CheckboxValue* stick_station;

    // The fourth knob, and the only one that is not about cost. Default OFF, which is the opposite
    // of its three siblings and deliberate: they default to the cheaper behaviour, this one
    // defaults to the game's own answer.
    CheckboxValue* qte_always_success;

    // Everything is hidden from the framework's automatic pass so the layout below is the whole
    // card. Hiding only DEPENDENT values is what previously made this card look broken: the
    // framework drew the parents and draw_menu_extra drew them again under the same ImGui IDs.
    void prepare_menu_draw() override;

    void draw_menu_extra() override;

    // The Module base declares these pure; the card is read-only so they have nothing to do.
    // Leaving them out would make the class abstract and the registration in ModuleManager.h
    // would stop compiling. gameworld_update is the one that is easy to miss — the hideout does
    // not exist in a raid, so it genuinely has nothing to do there.
    void init() override;
    void application_update() override;
    void application_update(Il2CppObject*) override;
    void gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) override;
    void draw_overlay(ImDrawList*) override;
};
