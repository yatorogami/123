#include "common.h"
#include "PlayerModule.h"

PlayerModule::PlayerModule() : Module("Player", Exploit, "player_mod"),
                               section_survival_(conf(new MenuSectionValue("survival_sec"))),
                               god_mode(conf(new CheckboxValue(false, "god_mode_cb"))),
                               semi_god_mode(conf(new CheckboxValue(false, "semi_god_mode_cb"))),
                               god_mode2(conf(new CheckboxValue(false, "god_mode_negative_on_cb"))),
                               infinite_stamina(conf(new CheckboxValue(false, "infinite_stamina_cb"))),
                               no_hunger_thirst(conf(new CheckboxValue(false, "no_hunger_thirst_cb"))),
                               instant_search(conf(new CheckboxValue(false, "instant_search_cb"))),
                               double_search(conf(new CheckboxValue(false, "double_search_cb"))),
                               always_survive(conf(new CheckboxValue(false, "always_survive_cb"))),
                               section_profile_mods_(conf(new MenuSectionValue("profile_modifiers_sec"))),
                               exp_type(conf(new SelectValue(0, EXP_TYPE_KEYS, std::size(EXP_TYPE_KEYS), "exp_type_sel"))),
                               exp_amount(conf(new IntSliderEditableValue(10000, 0, 500000, "exp_amount_itm"))),
                               add_exp(conf(new ActionRowValue([&] {
                                   add_exp_impl();
                               },
                                   "add_exp_btn"))),
                               fence_rep_source(conf(new SelectValue(0, {"boss_help_sel", "scav_help_sel", "scav_kill_sel", "boss_kill_sel", "traitor_kill_sel", "exit_standing_sel"}, "fence_rep_source_sel"))), fence_rep_amount(conf(new FloatSliderEditableValue(0.1f, 0, 5, "fence_rep_amount_itm"))), add_fence_rep(conf(new ActionRowValue([&] {
                                   add_fence_rep_impl();
                               },
                                                                                                                                                                                                                                                                                                                "add_fence_rep_btn"))),
                               trader_select(conf(new SelectValue(0, TRADER_KEYS, std::size(TRADER_KEYS), "trader_sel"))), trader_rep_amount(conf(new FloatSliderEditableValue(0.1f, 0, 5, "trader_rep_amount_itm"))), add_trader_rep(conf(new ActionRowValue([&] {
                                   add_trader_rep_impl();
                               },
                                                                                                                                                                                                                           "add_trader_rep_btn"))),
                               skill_select(conf(new SelectValue(0, SKILL_KEYS, std::size(SKILL_KEYS), "skill_sel"))), skill_level(conf(new IntSliderEditableValue(51, 0, 51, "skill_level_itm"))), set_skill(conf(new ActionRowValue([&] {
                                   set_skill_impl();
                               },
                                                                                                                                                                                                        "set_skill_btn"))),
                               section_vision_(conf(new MenuSectionValue("vision_sec"))), thermal_vision(conf(new CheckboxValue(false, "thermal_vision_cb"))), night_vision(conf(new CheckboxValue(false, "night_vision_cb"))), no_visor(conf(new CheckboxValue(false, "no_visor_cb"))), third_person(conf(new CheckboxValue(false, "third_person_cb"))), third_person_distance(conf(new FloatSliderEditableValue(2.5f, 0.8f, 8.f, "third_person_distance_itm"))), third_person_height(conf(new FloatSliderEditableValue(0.85f, 0.2f, 2.5f, "third_person_height_itm"))), section_player_misc_(conf(new MenuSectionValue("player_misc_sec"))), far_reach(conf(new CheckboxValue(false, "far_reach_cb"))), flares(conf(new CheckboxValue(false, "flares_cb"))), section_movement_(conf(new MenuSectionValue("movement_sec"))), speed_hack(conf(new CheckboxValue(false, "speed_hack_cb"))), speed(conf(new IntSliderEditableValue(2, 1, 10, "speed_itm"))), fly_hack(conf(new CheckboxValue(false, "fly_hack_cb"))), fly_speed(conf(new IntSliderEditableValue(2, 1, 10, "fly_speed_itm"))) {
    third_person_distance->set_hidden_in_owner_menu(true);
    third_person_height->set_hidden_in_owner_menu(true);
    flares->set_hidden_in_owner_menu(true);

    // Hover text for the three survival modes. The labels alone do not distinguish
    // them -- "God Mode", "Buddha Mode" and "Semi-God Mode" read as one feature with
    // three spellings until you know that one denies damage outright, one floors every
    // body part at 1 HP and one floors only the head and thorax. That difference is
    // the whole feature and it was nowhere in the UI.
    god_mode->set_tooltip("god_mode_tip");
    god_mode2->set_tooltip("god_mode2_tip");
    semi_god_mode->set_tooltip("semi_god_mode_tip");

    ConfigValue* profile_values[] = {
        section_profile_mods_, exp_type, exp_amount, add_exp,
        fence_rep_source, fence_rep_amount, add_fence_rep,
        trader_select, trader_rep_amount, add_trader_rep,
        skill_select, skill_level, set_skill};
    for (ConfigValue* value : profile_values)
        value->set_hidden_in_owner_menu(true);
}

void PlayerModule::add_exp_impl() {
    if (!game_state::is_in_raid) return;
    queue_add_exp = true;
}

void PlayerModule::add_fence_rep_impl() {
    if (!game_state::is_in_raid) return;
    queue_add_fence_rep = true;
}

void PlayerModule::add_trader_rep_impl() {
    if (!game_state::is_in_raid) return;
    queue_add_trader_rep = true;
}

void PlayerModule::set_skill_impl() {
    if (!game_state::is_in_raid) return;
    queue_set_skill = true;
}

void PlayerModule::sync_profile_mod_controls_lock() {
    constexpr bool unlocked = true;
    section_profile_mods_->set_section_active(unlocked);

    const auto dis = [](ConfigValue* v, const bool disabled) { v->set_disabled(disabled); };
    dis(exp_type, !unlocked);
    dis(exp_amount, !unlocked);
    dis(fence_rep_source, !unlocked);
    dis(fence_rep_amount, !unlocked);
    dis(trader_select, !unlocked);
    dis(trader_rep_amount, !unlocked);
    dis(skill_select, !unlocked);
    dis(skill_level, !unlocked);

    add_exp->set_disabled(!unlocked);
    add_fence_rep->set_disabled(!unlocked);
    add_trader_rep->set_disabled(!unlocked);
    set_skill->set_disabled(!unlocked);
}

void PlayerModule::sync_movement_controls_lock() {
    const auto dis = [](ConfigValue* v, const bool disabled) { v->set_disabled(disabled); };
    dis(speed, !speed_hack->get_value());
    dis(fly_speed, !fly_hack->get_value());
    dis(third_person_distance, !third_person->get_value());
    dis(third_person_height, !third_person->get_value());
}

Il2CppObject* PlayerModule::try_get_camera_component(Il2CppObject* camera, const char* ns, const char* cls_name) {
    if (!camera) return nullptr;
    static const Il2CppImage* ue = nullptr;
    if (!ue) ue = il2utils::resolve_image("UnityEngine.CoreModule.dll");
    if (!ue) ue = il2utils::resolve_image("UnityEngine.dll");
    Il2CppObject* go = unity::component_get_game_object(camera);
    if (!go) return nullptr;
    const Il2CppImage* img = il2utils::resolve_image("Assembly-CSharp.dll");
    Il2CppObject* type = il2utils::get_system_type(img, ns, cls_name);
    if (!type && img)
        type = il2utils::get_system_type(img, "", cls_name);
    if (!type) return nullptr;
    return unity::gameobject_get_component(go, type);
}

void PlayerModule::apply_thermal(Il2CppObject* thermal, const bool on) {
    if (!thermal || !thermal->klass) return;
    Il2CppObjectInstance tv(thermal);
    if (FieldInfo* f = il2utils::resolve_field(thermal->klass, "On"))
    {
        if (f->offset > 0)
            *reinterpret_cast<bool*>(reinterpret_cast<uintptr_t>(thermal) + f->offset) = on;
    }
    if (!on) return;
    // Clear thermal artefacts (Stupid.Solutions Thermals).
    auto set_bool = [&](const char* name, bool v) {
        if (FieldInfo* f = il2utils::resolve_field(thermal->klass, name))
            if (f->offset > 0)
                *reinterpret_cast<bool*>(reinterpret_cast<uintptr_t>(thermal) + f->offset) = v;
    };
    set_bool("IsFpsStuck", false);
    set_bool("IsGlitch", false);
    set_bool("IsMotionBlurred", false);
    set_bool("IsNoisy", false);
    set_bool("IsPixelated", false);
    if (FieldInfo* mask_f = il2utils::resolve_field(thermal->klass, "TextureMask"))
    {
        if (mask_f->offset > 0)
        {
            Il2CppObject* mask = *reinterpret_cast<Il2CppObject**>(
                reinterpret_cast<uintptr_t>(thermal) + mask_f->offset);
            if (mask && mask->klass)
            {
                if (FieldInfo* size = il2utils::resolve_field(mask->klass, "Size"))
                    if (size->offset > 0)
                        *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(mask) + size->offset) = 0.f;
                if (FieldInfo* stretch = il2utils::resolve_field(mask->klass, "Stretch"))
                    if (stretch->offset > 0)
                        *reinterpret_cast<bool*>(reinterpret_cast<uintptr_t>(mask) + stretch->offset) = false;
            }
        }
    }
}

// Night vision is NOT the same trick as thermal, and the difference is the field.
//
// ThermalVision.On is a PUBLIC FIELD (dump.cs:149941, offset 0x20), so
// apply_thermal above can name it directly. NightVision.On is a PROPERTY whose
// only backing store is the private `_on` at 0xC4 (dump.cs:162645), and both of
// the game's own accessors are one-instruction field accesses:
//
//   get_On:  movzx eax, byte ptr [rcx+0C4h]     // RVA 0x12A2F20
//   set_On:  mov    [rcx+0C4h], dl               // RVA 0x1265020
//
// Neither touches StateSwitcher, the material, or the mask, so writing _on
// directly is exactly what the game does -- calling set_On would save nothing.
//
// The render path then keys off that byte alone (BSG.CameraEffects.NightVision
// OnPreCull, RVA 0x187FAD0):
//   cmp [rbx+0C4h], al / setne al  ->  Shader.SetGlobalFloat(_nightVisionOn, on)
//   cmp byte ptr [rbx+0C4h], 0     ->  clear and re-record _nightVisionCB
// and OnPostRender does the same. EffectsController.ResetEffectsInstant reads
// `_on` the same way to decide it must call StartSwitch(false), i.e. the game
// treats `_on` as the durable state, which is why this does not decay while the
// toggle is on.
//
// What we deliberately do NOT do, and why:
//   * We do not call StartSwitch/ApplySettings/SetMask the way
//     PlayerCameraController.OnNightVisionChanged does. That route re-reads a
//     NightVisionComponent in the headwear slot and its device template every
//     time; it is the game's own path and we have no device to feed it.
//   * We do not touch SwitchComponentsOn/SwitchComponentsOff or TextureMask --
//     the circular vignette Switch() enables. Leaving them alone gives the
//     full-screen effect and keeps the toggle independent of whether a mask
//     texture happens to be configured.
//   * OpticComponentUpdater.CopyComponentFromOptic disables this component while
//     a scope camera owns the frame, so the toggle silently does nothing
//     mid-ADS instead of fighting the game for the camera.
//
// If the camera carries no BSG.CameraEffects.NightVision at all (GetComponent
// returns null) the call site skips this entirely -- the same contract thermal
// has always had.
void PlayerModule::apply_night_vision(Il2CppObject* nv, const bool on) {
    if (!nv || !nv->klass) return;
    if (FieldInfo* f = il2utils::resolve_field(nv->klass, "_on"))
    {
        if (f->offset > 0)
            *reinterpret_cast<bool*>(reinterpret_cast<uintptr_t>(nv) + f->offset) = on;
    }
}

void PlayerModule::apply_visor(Il2CppObject* visor, const bool remove) {
    if (!visor || !visor->klass) return;
    // VisorEffect.Intensity public field
    if (FieldInfo* f = il2utils::resolve_field(visor->klass, "Intensity"))
    {
        if (f->offset > 0)
            *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(visor) + f->offset) = remove ? 0.f : 1.f;
    }
}

Il2CppObject* PlayerModule::try_get_player_camera_position_transform(Il2CppObject* player) {
    if (!player || !player->klass) return nullptr;
    Il2CppObjectInstance p(player);
    if (const auto get_cp = p.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_CameraPosition", 0, false))
    {
        Il2CppObject* tr = get_cp(player);
        if (eft_api::is_il2cpp_object_likely_valid(tr)) return tr;
    }
    if (FieldInfo* f = il2utils::resolve_field(player->klass, "<CameraPosition>k__BackingField"))
    {
        if (f->offset > 0)
        {
            Il2CppObject* tr = *reinterpret_cast<Il2CppObject**>(
                reinterpret_cast<uintptr_t>(player) + f->offset);
            if (eft_api::is_il2cpp_object_likely_valid(tr)) return tr;
        }
    }
    return nullptr;
}

void PlayerModule::apply_point_of_view(Il2CppObject* player, const int pov,
    const float tp_distance, const float tp_height) {
    if (!player || !player->klass) return;
    Il2CppObjectInstance p(player);
    // set_PointOfView(EPointOfView) — 0 FP, 1 TP, 2 FreeCamera
    if (const auto set_pov = p.get_method<void (*)(Il2CppObject*, int)>("set_PointOfView", 1, false))
        set_pov(player, pov);

    // Third person: pull camera back + up so we are not inside the head mesh.
    if (pov == 1)
    {
        Il2CppObject* cam_tr = try_get_player_camera_position_transform(player);
        if (cam_tr)
        {
            const float dist = (std::max)(0.5f, tp_distance);
            const float height = (std::max)(0.1f, tp_height);
            // Local space: -Z is behind the player, +Y is up.
            if (const auto set_lp = Il2CppObjectInstance(cam_tr).get_method<void (*)(Il2CppObject*, unity::vector3)>("set_localPosition", 1, false))
                set_lp(cam_tr, {0.f, height, -dist});
        }
    }
}

void PlayerModule::apply_far_reach() {
    // EFTHardSettings.Instance — LOOT_RAYCAST_DISTANCE / DOOR_RAYCAST_DISTANCE / DelayToOpenContainer
    static const Il2CppImage* img = il2utils::resolve_image("Assembly-CSharp.dll");
    if (!img) return;
    const Il2CppClass* hs = il2utils::resolve_class(img, "", "EFTHardSettings");
    if (!hs) hs = il2utils::resolve_class(img, "EFT", "EFTHardSettings");
    if (!hs) return;
    const MethodInfo* get_inst = il2utils::resolve_method(hs, "get_Instance", 0);
    if (!get_inst || !get_inst->methodPointer) return;
    Il2CppObject* inst = reinterpret_cast<Il2CppObject* (*)(const MethodInfo*)>(get_inst->methodPointer)(get_inst);
    if (!inst || !inst->klass) return;
    auto set_f = [&](const char* name, float v) {
        if (FieldInfo* f = il2utils::resolve_field(inst->klass, name))
            if (f->offset > 0)
                *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(inst) + f->offset) = v;
    };
    set_f("LOOT_RAYCAST_DISTANCE", 12.f);
    set_f("DOOR_RAYCAST_DISTANCE", 12.f);
    set_f("DelayToOpenContainer", 0.f);
    set_f("POSE_CHANGING_SPEED", 15.f);
    set_f("PICKUP_DELAY", 0.f);
}

bool PlayerModule::player_is_aiming(Il2CppObject* player) {
    if (!player) return false;
    Il2CppObjectInstance p(player);
    // HandsController (FirearmController).IsAiming
    Il2CppObject* hands = nullptr;
    if (const auto get_h = p.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_HandsController", 0, false))
        hands = get_h(player);
    if (!hands)
        hands = p.get_field<Il2CppObject*>("_handsController");
    if (!eft_api::is_il2cpp_object_likely_valid(hands) || !hands->klass) return false;
    Il2CppObjectInstance h(hands);
    if (const auto get_aim = h.get_method<bool (*)(Il2CppObject*)>("get_IsAiming", 0, false))
        return get_aim(hands);
    return false;
}


void PlayerModule::try_call_airdrop(Il2CppObjectInstance& game_world, Il2CppObject* local_player) {
    unity::vector3 pos{0, 0, 0};
    if (local_player)
    {
        Il2CppObject* go = unity::component_get_game_object(local_player);
        Il2CppObject* tr = go ? unity::gameobject_get_transform(go) : nullptr;
        if (tr) pos = unity::transform_get_pos(tr);
    }
    // GameWorld.InitAirdrop(string lootTemplateId, bool takeNearbyPoint, Vector3 position)
    Il2CppObjectInstance& gw = game_world;
    if (const auto init = gw.get_method<void (*)(Il2CppObject*, Il2CppString*, bool, unity::vector3)>(
            "InitAirdrop", 3, false))
    {
        init(gw.get_instance(), il2cpp::il2cpp_string_new(""), true, pos);
        logger::info("Airdrop called (flares)");
        return;
    }
    if (const auto init2 = gw.get_method<void (*)(Il2CppObject*, Il2CppString*, bool, unity::vector3)>(
            "InitAirdrop", 3, true))
    {
        init2(gw.get_instance(), nullptr, true, pos);
        logger::info("Airdrop called (flares)");
    }
    else
        logger::warn("InitAirdrop not found");
}

void PlayerModule::draw_overlay(ImDrawList*) {}

void PlayerModule::sync_god_mode_state() {
    const bool gm1 = god_mode->get_value();
    const bool gm2 = god_mode2->get_value();
    const bool semi = semi_god_mode->get_value();

    if (gm1 && (gm2 || semi))
    {
        god_mode2->set_value(false);
        semi_god_mode->set_value(false);
    }
    else if (gm2 && semi)
    {
        semi_god_mode->set_value(false);
    }

    god_mode2->set_disabled(gm1 || semi);
    semi_god_mode->set_disabled(gm1 || gm2);
    god_mode->set_disabled(gm2 || semi);
}


void PlayerModule::application_update() {
    TA_ZONE_N("player::application_update");
    sync_god_mode_state();
    sync_profile_mod_controls_lock();
    sync_movement_controls_lock();

    if (!game_state::is_in_raid)
    {
        fly_main_player = nullptr;
        return;
    }

    if (fly_hack->get_value() && fly_main_player)
        fly_hack_tick(fly_main_player, fly_speed->get_value(), fly_up_key, fly_down_key);
}

void PlayerModule::gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
    Il2CppObjectInstance main_player) {
    TA_ZONE_N("player::gameworld_update");
    sync_god_mode_state();
    sync_profile_mod_controls_lock();
    sync_movement_controls_lock();
    fly_main_player = main_player.get_instance();

    // NO PLAYER, NO PROFILE. Added 2026-10-12 after the crash in pid 15628
    // (EscapeFromTarkov.exe.15628.dmp).
    //
    // The next block resolved get_Profile off `main_player.get_instance()->klass` and then
    // CALLED it on that same pointer. When the game hands gameworld_update a null player,
    // the ->klass read is already a null dereference; if the class read survives, the call
    // is `Player.get_Profile()` with a null `this`, and the game's stub for it does NOT
    // null-check:
    //
    //     GameAssembly+0x419B0E0   mov rax, qword ptr [rcx + 0x9c0]   ; rcx == NULL
    //     GameAssembly+0x419B0E7   ret
    //
    // +0x9C0 is `Player.<Profile>k__BackingField` (dump.cs:276606), which is why the
    // faulting address is exactly 0x9C0 and not the 0xFFFFFFFFFFFFFFFF sentinel the other
    // crash family reads. Note the neighbouring getter `get_ProfileId` at +0x419B0C0 reads
    // the SAME offset and DOES test it first -- the game's own asymmetry, not ours.
    //
    // Returning is the right shape and not a papering-over: everything below this point
    // derives from the local player -- its Profile, its stamina, its god-mode state -- and
    // with no player there is nothing for any of it to mean. The three sync_* helpers above
    // have already run, and they only mirror config values onto toggles.
    if (!main_player.get_instance())
        return;

    // Cache the get_Profile MethodInfo after first resolution to avoid repeated
    // string-based IL2CPP metadata lookups on every frame.
    static const MethodInfo* get_profile_method = nullptr;
    if (!get_profile_method)
        get_profile_method = il2utils::resolve_method(main_player.get_instance()->klass, "get_Profile", 0);

    Il2CppObject* profile_obj = nullptr;
    if (get_profile_method && get_profile_method->methodPointer)
        profile_obj = reinterpret_cast<Il2CppObject* (*)(Il2CppObject*)>(get_profile_method->methodPointer)(
            main_player.get_instance());
    Il2CppObjectInstance main_profile(profile_obj);

    if (infinite_stamina->get_value())
    {
        Il2CppObjectInstance physical(main_player.get_field<Il2CppObject*>("Physical"));

        Il2CppObjectInstance stamina(physical.get_field<Il2CppObject*>("Stamina"));
        stamina.set_field("Current", 100.0f);

        Il2CppObjectInstance stamina_hands(physical.get_field<Il2CppObject*>("HandsStamina"));
        stamina_hands.set_field("Current", 100.0f);

        Il2CppObjectInstance oxygen(physical.get_field<Il2CppObject*>("Oxygen"));
        oxygen.set_field("Current", 100.0f);
    }

    // Cache get_ActiveHealthController MethodInfo after first resolution.
    static const MethodInfo* get_health_controller_method = nullptr;
    if (!get_health_controller_method)
        get_health_controller_method = il2utils::resolve_method(
            main_player.get_instance()->klass, "get_ActiveHealthController", 0);

    Il2CppObject* health_controller_obj = nullptr;
    if (get_health_controller_method && get_health_controller_method->methodPointer)
        health_controller_obj = reinterpret_cast<Il2CppObject* (*)(Il2CppObject*)>(
            get_health_controller_method->methodPointer)(main_player.get_instance());
    Il2CppObjectInstance health_controller(health_controller_obj);

    // All three survival modes resolve to one enum, and everything downstream --
    // the ChangeHealth/Kill hooks and the per-frame coefficient work below --
    // reads that single value. The three are mutually exclusive (enforced by
    // sync_god_mode_state), so the order here is only a tie-break that cannot
    // currently be reached.
    survival_clamp::mode survival_mode = survival_clamp::mode::off;
    if (god_mode->get_value())
        survival_mode = survival_clamp::mode::god;
    else if (god_mode2->get_value())
        survival_mode = survival_clamp::mode::buddha;
    else if (semi_god_mode->get_value())
        survival_mode = survival_clamp::mode::semi;

    semi_god::sync(health_controller.get_instance(), survival_mode);

    static bool god_was_on = false;
    static float saved_fall_height = 0.f;
    static bool fall_saved = false;

    if (survival_mode == survival_clamp::mode::god)
    {
        // cache the real fall-safe height once so we can restore it later
        if (!fall_saved)
        {
            saved_fall_height = health_controller.get_field<float>("_fallSafeHeight");
            fall_saved = true;
        }

        // Swept to the checked accessor 2026-10-14 (the call-through-null bug
        // class). These three are void calls, so a miss is "the god-mode
        // effects silently do not apply this frame" instead of a call to 0x0.
        health_controller.call_or_void<void (*)(Il2CppObject*, float)>(
            "SetDamageCoeff", 1, -1.0f);
        health_controller.call_or_void<void (*)(Il2CppObject*, int)>(
            "RemoveNegativeEffects", 1, 7); // 7 = Common
        health_controller.call_or_void<void (*)(Il2CppObject*)>(
            "RestoreFullHealth", 0);
        health_controller.set_field("_fallSafeHeight", 99999999.0f);
        god_was_on = true;
    }
    else if (survival_mode == survival_clamp::mode::buddha)
    {
        // cache the real fall-safe height once so we can restore it later
        if (!fall_saved)
        {
            saved_fall_height = health_controller.get_field<float>("_fallSafeHeight");
            fall_saved = true;
        }

        // NO SetDamageCoeff here. It used to be set to 0.00001f, which is what
        // made this mode "god mode with damage turned down": it did not let a
        // bodypart reach 1 HP, it stopped the damage before the bodypart could
        // move at all. Buddha mode is defined by the damage LANDING and the clamp
        // in semi_god::hook_change_health stopping it at 1 HP -- which is why that
        // branch reads `mode::buddha` in part_is_protected and this one does not.
        health_controller.set_field("_fallSafeHeight", 99999999.0f);
        god_was_on = true;
    }
    else if (god_was_on)
    {
        // god mode turned off -> restore normal damage + fall height (once)
        health_controller.call_or_void<void (*)(Il2CppObject*, float)>(
            "SetDamageCoeff", 1, 1.0f);
        if (fall_saved)
            health_controller.set_field("_fallSafeHeight", saved_fall_height);
        god_was_on = false;
    }

    if (no_hunger_thirst->get_value())
    {
        health_controller.call_or_void<void (*)(Il2CppObject*, float)>(
            "ChangeEnergy", 1, 100.0f);
        health_controller.call_or_void<void (*)(Il2CppObject*, float)>(
            "ChangeHydration", 1, 100.0f);
    }

    // Cache get_Skills MethodInfo after first resolution.
    static const MethodInfo* get_skills_method = nullptr;
    if (!get_skills_method)
        get_skills_method = il2utils::resolve_method(main_player.get_instance()->klass, "get_Skills", 0);

    Il2CppObject* skill_manager_obj = nullptr;
    if (get_skills_method && get_skills_method->methodPointer)
        skill_manager_obj = reinterpret_cast<Il2CppObject* (*)(Il2CppObject*)>(get_skills_method->methodPointer)(
            main_player.get_instance());
    Il2CppObjectInstance skill_manager(skill_manager_obj);

    // The checkbox is labelled "Lucky Search" in every locale (renamed from
    // "Instant Search" on 2026-10-14), and that label is the accurate one: this is
    // the Lucky Search mechanic, not a search-speed one.
    //
    // What the game does with this value, from ISIL-references/120047965:
    // ActiveSearchContentOperation..ctor rolls Random.Range(0f, 1f), compares it
    // against a threshold derived from this skill, and stores the outcome in its
    // own public bool `Instant` (offset 0x50) --
    //     Instant = (roll - threshold >= 0) && (roll - threshold != 0)
    // ONE roll, not two; there is no second loot-table roll anywhere. When
    // Instant is set, SinglePlayerSearchContentOperation.ExecuteInternal plays
    // GUISounds "looting_luck2" and takes the no-animation path, and SearchContent
    // skips the Random.Range(1,3)-second delay the normal search pays. Maxing
    // the skill value drives the threshold to ~0, so Instant is true nearly always.
    //
    // The identifier stays `instant_search` on purpose: the hotkey id
    // "exploit.instant_search" is persisted to disk (hotkeys.h honours legacy
    // spellings on the way in, the way "exploit.god_mode2" is still honoured for
    // "exploit.buddha_mode"), so renaming it is a migration, not a rename.
    if (instant_search->get_value())
    {
        Il2CppObjectInstance attention_elite_lucky_search(
            skill_manager.get_field<Il2CppObject*>("AttentionEliteLuckySearch"));

        attention_elite_lucky_search.set_field("Value", 100000.0f);
    }

    // The Search skill's Elite sub-perk: SkillManager.SearchDouble, built with
    // BuffType = 1 (EBuffType.Elite) and EBuffId 97, aggregated in
    // CreatePractical() beside SearchBuffSpeed. It is a BooleanBuff, so Value is
    // a real bool at 0x30 -- not the float Lucky Search takes.
    //
    // What it gates, from ISIL-references/120047965, PlayerSearchController::
    // CanStartNewSearchOperation():
    //     if (_profile == null)        return false;
    //     if (_profile.Skills == null) return _searchOperationsList.Count < 1;
    //     if (skillQuery(...))         return _searchOperationsList.Count < 2;
    //     else                        return _searchOperationsList.Count < 1;
    // Normally zero searches may be in flight at once; with this one, one --
    // i.e. a second container can be opened while the first is still searching.
    // The list is the BindableList<SearchContentOperation> at field 0x40 that
    // SearchContents appends to, so the gate is read at search START, not during.
    //
    // NOT PROVEN ONLINE. That skill query is a generic call through
    // IInventoryProfileSkillInfo, so identifying it as SearchDouble is structural
    // (a bool in the Search group gating the only 1 -> 2 gate in the search path)
    // rather than read off a resolved token. And searching goes out through
    // NetworkSearchContentOperation, so the server may enforce its own
    // concurrency regardless of what this writes. Untested in a raid.
    if (double_search->get_value())
    {
        Il2CppObjectInstance search_double(
            skill_manager.get_field<Il2CppObject*>("SearchDouble"));

        search_double.set_field("Value", true);
    }

    // --- Vision / camera / misc (Stupid.Solutions) ---
    {
        Il2CppObject* cam = unity::get_current_camera();
        if (cam)
        {
            if (Il2CppObject* thermal = try_get_camera_component(cam, "", "ThermalVision"))
                apply_thermal(thermal, thermal_vision->get_value());
            // ThermalVision is in the image's root namespace; the NVG sibling
            // lives in BSG.CameraEffects, so the namespace must be spelled out
            // here -- get_system_type does not search.
            if (Il2CppObject* nv = try_get_camera_component(cam, "BSG.CameraEffects", "NightVision"))
                apply_night_vision(nv, night_vision->get_value());
            if (Il2CppObject* visor = try_get_camera_component(cam, "", "VisorEffect"))
                apply_visor(visor, no_visor->get_value());
        }

        // Third person only when not aiming — ADS forces FirstPerson so optics work.
        const bool aiming = player_is_aiming(main_player.get_instance());
        const int pov = (third_person->get_value() && !aiming) ? 1 : 0;

        apply_point_of_view(main_player.get_instance(), pov,
            third_person_distance->get_value(),
            third_person_height->get_value());

        if (far_reach->get_value())
            apply_far_reach();

        if (queue_call_airdrop)
        {
            queue_call_airdrop = false;
            if (flares->get_value())
                try_call_airdrop(game_world_instance, main_player.get_instance());
        }
    }

    if (queue_add_exp)
    {
        queue_add_exp = false;
        Il2CppObjectInstance eft_stats(
            main_profile.call_or<Il2CppObject*>("get_EftStats", 0, nullptr));

        Il2CppObjectInstance session_counters(eft_stats.get_field<Il2CppObject*>("SessionCounters"));

        const Il2CppImage* assembly_csharp = il2utils::resolve_image("Assembly-CSharp.dll");
        const Il2CppClass* predefined_counters = il2utils::resolve_class(assembly_csharp, "EFT.Counters",
            "PredefinedCounters");

        // The field name comes from EXP_TYPE_API, which the static_asserts in
        // PlayerModule.h keep the same length as the dropdown exp_type clamps to,
        // so this index is in range.
        const char* reason_name = EXP_TYPE_API[exp_type->get_value()];
        const auto reason_field = il2utils::get_static_field<Il2CppObject*>(
            predefined_counters, reason_name);

        // Consumption policy: ABANDON, do not guess. `reason` is handed to a game
        // method, and the previous code passed an indeterminate pointer there --
        // `T value;` default-initialises, so for T = Il2CppObject* it was whatever
        // was on the stack if the read did not happen. Skipping the call leaves the
        // EXP simply not applied, which is visible and harmless; passing garbage
        // is neither.
        if (!reason_field.present())
        {
            logger::warn("Add EXP: EFT.Counters." + std::string(reason_name)
                + " did not resolve; EXP not applied");
            return;
        }

        // Checked accessor (the 2026-10-14 sweep). The reason_field policy above
        // still stands: a resolve miss on the STATIC field abandons the EXP
        // rather than guessing; this one fails closed to a no-op.
        session_counters.call_or_void<void (*)(Il2CppObject*, int, Il2CppObject*)>(
            "AddInt", 2, exp_amount->get_value(), reason_field.value);

        logger::debug("Added EXP");
    }

    if (queue_add_fence_rep)
    {
        queue_add_fence_rep = false;
        Il2CppObjectInstance loyalty_data(
            main_player.call_or<Il2CppObject*>("get_Loyalty", 0, nullptr));

        loyalty_data.call_or_void<void (*)(Il2CppObject*, double, int)>(
            "KillAsSavage", 2, fence_rep_amount->get_value(), fence_rep_source->get_value());

        logger::debug("Added Fence Rep");
    }

    if (queue_add_trader_rep)
    {
        queue_add_trader_rep = false;
        std::string trader_id_key = std::string(TRADER_API[trader_select->get_value()]) + "_ID";

        logger::debug("Resolving Profile class");
        const Il2CppClass* profile_class = il2utils::resolve_class(game_world_class->image, "EFT", "Profile");
        logger::debug(std::string("Getting TraderInfo class, got profile (is_null=") + (profile_class == nullptr ? "true" : "false") + ")");
        const Il2CppClass* trader_info_class = il2utils::resolve_class_nested(profile_class, "TraderInfo");
        if (!trader_info_class)
        {
            logger::warn("trader_info_class null");
            return;
        }
        logger::debug("Resolve field " + trader_id_key);
        FieldInfo* id_field = il2utils::resolve_field(trader_info_class, trader_id_key.c_str());
        if (!id_field)
        {
            logger::warn("id_field null for " + trader_id_key);
            return;
        }
        if (!id_field->type)
        {
            logger::warn("id_field->type null for " + trader_id_key);
            return;
        }

        Il2CppObject* trader_id_obj = nullptr;
        il2cpp::il2cpp_field_static_get_value(id_field, &trader_id_obj);
        Il2CppString* trader_id = reinterpret_cast<Il2CppString*>(trader_id_obj);

        const MethodInfo* try_get_method = il2utils::resolve_method(profile_class, "TryGetTraderInfo", 2);
        if (!try_get_method || !try_get_method->methodPointer)
        {
            logger::warn("TryGetTraderInfo method not found");
            return;
        }
        const auto try_get_trader_info = static_cast<bool (*)(Il2CppObject*, Il2CppString*, Il2CppObject**)>(try_get_method->methodPointer);

        logger::debug("Finding trader info...");
        Il2CppObject* trader_info = nullptr;
        if (try_get_trader_info(main_profile.get_instance(), trader_id, &trader_info) && trader_info)
        {
            const FieldInfo* standing_field = il2utils::resolve_field(trader_info->klass, "<Standing>k__BackingField");
            if (standing_field)
            {
                auto* standing_ptr = reinterpret_cast<double*>(
                    reinterpret_cast<uintptr_t>(trader_info) + standing_field->offset);
                *standing_ptr += trader_rep_amount->get_value();
            }
        }

        logger::info("Added Trader Rep");
    }

    if (queue_set_skill)
    {
        queue_set_skill = false;

        Il2CppObjectInstance skill_controller(
            main_player.call_or<Il2CppObject*>("get_Skills", 0, nullptr));

        if (const auto skill_ptr = skill_controller.get_field<Il2CppObject*>(SKILL_API[skill_select->get_value()]))
        {
            Il2CppObjectInstance skill_instance(skill_ptr);

            skill_instance.call_or_void<void (*)(Il2CppObject*, int)>(
                "SetLevel", 1, skill_level->get_value());

            logger::debug(
                "Set Skill: " + std::string(SKILL_API[skill_select->get_value()]) + " Level: " + std::to_string(skill_level->get_value()));
        }
        else
        {
            logger::warn("Skill not found: " + std::string(SKILL_API[skill_select->get_value()]));
        }
    }

    do_speed = speed_hack->get_value();
    speed_value = speed->get_value();

    should_survive = always_survive->get_value();
}

void PlayerModule::init() {
    const Il2CppImage* image = il2utils::resolve_image("Assembly-CSharp.dll");
    init_fly_hack_offsets();

    // need a fixed update here so speed hack is consistent, this is a good one i found with access to player
    const Il2CppClass* player_camera_controller_class = il2utils::resolve_class(
        image, "EFT.CameraControl", "PlayerCameraController");
    il2utils::hook_method(player_camera_controller_class, "FixedUpdate", 0,
        hk_player_camera_controller_fixed_update,
        &o_player_camera_controller_fixed_update);

    // local game stop
    const Il2CppClass* local_game = il2utils::resolve_class(image, "EFT", "LocalGame");
    il2utils::hook_method(local_game, "Stop", 4, hk_local_game_stop, &o_local_game_stop);
}
