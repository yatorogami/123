#include "common.h"
#include "WeaponModule.h"

WeaponModule::WeaponModule() : Module("Weapon", Exploit, "weapon_mod"),
                               no_jam(conf(new CheckboxValue(false, "no_malfunction_cb"))),
                               infinite_ammo(conf(new CheckboxValue(false, "infinite_ammo_cb"))),
                               section_feel_(conf(new MenuSectionValue("combat_feel_sec"))),
                               no_head_bobbing(conf(new CheckboxValue(false, "no_head_bobbing_cb"))),
                               no_aim_sway(conf(new CheckboxValue(false, "no_aim_sway_cb"))),
                               no_breath_sway(conf(new CheckboxValue(false, "no_breath_sway_cb"))),
                               no_recoil_force(conf(new CheckboxValue(false, "no_recoil_force_cb"))) {
}

void WeaponModule::draw_overlay(ImDrawList* draw_list) {
    (void)draw_list;
}

void WeaponModule::application_update() {
    // Keep Detours in sync with UI even outside raid (doors / PWA exist in-raid mostly,
    // but re-toggle must unhook immediately when user disables).
    combat_feel::sync(
        combat_feel::always_breach_ui,
        no_head_bobbing->get_value(),
        no_aim_sway->get_value(),
        no_breath_sway->get_value(),
        no_recoil_force->get_value());
}

void WeaponModule::gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
    Il2CppObjectInstance main_player) {
    (void)game_world_class;
    (void)game_world_instance;

    combat_feel::sync(
        combat_feel::always_breach_ui,
        no_head_bobbing->get_value(),
        no_aim_sway->get_value(),
        no_breath_sway->get_value(),
        no_recoil_force->get_value());

    if (no_jam->get_value() || infinite_ammo->get_value())
    {
        Il2CppObject* hands_controller_object =
            main_player.call_or<Il2CppObject*>("get_HandsController", 0, nullptr);

        if (hands_controller_object && std::string(hands_controller_object->klass->name) == "FirearmController")
        {
            Il2CppObjectInstance firearm_controller(hands_controller_object);
            Il2CppObject* item_obj =
                firearm_controller.call_or<Il2CppObject*>("get_Item", 0, nullptr);
            if (!item_obj) return;
            Il2CppObjectInstance weapon(item_obj);
            Il2CppObject* tmpl_obj =
                weapon.call_or<Il2CppObject*>("get_Template", 0, nullptr);
            if (!tmpl_obj) return;
            Il2CppObjectInstance templt(tmpl_obj);

            if (no_jam->get_value())
            {
                templt.set_field("AllowOverheat", false);
                templt.set_field("AllowJam", false);
                templt.set_field("AllowMisfire", false);
                templt.set_field("AllowSlide", false);
                templt.set_field("AllowFeed", false);
                templt.set_field("DurabilityBurnRatio", 0.0f);
            }

            if (infinite_ammo->get_value())
            {
                Il2CppObject* mag_object =
                    weapon.call_or<Il2CppObject*>("GetCurrentMagazine", 0, nullptr);
                if (!mag_object) return;
                Il2CppObjectInstance magazine(mag_object);
                const int current_count =
                    weapon.call_or<int>("GetCurrentMagazineCount", 0, 0);
                const int max_count =
                    weapon.call_or<int>("GetMaxMagazineCount", 0, 0);

                if (current_count != 0)
                {
                    Il2CppObject* first_ammo =
                        magazine.call_or<Il2CppObject*>("FirstRealAmmo", 0, nullptr);
                    if (!first_ammo) return;
                    Il2CppObjectInstance first_real_ammo(first_ammo);

                    const int max_stack_size =
                        first_real_ammo.call_or<int>("get_StackMaxSize", 0, 1);

                    first_real_ammo.set_field("StackObjectsCount", std::min<int>(max_count, max_stack_size));
                }
            }
        }
    }
}
void WeaponModule::init() {
}
