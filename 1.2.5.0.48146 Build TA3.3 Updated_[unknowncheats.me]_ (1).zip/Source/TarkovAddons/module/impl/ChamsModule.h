#pragma once
#include <atomic>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "../eft_api.h"
#include "../../config/FloatSliderEditableValue.h"
#include "../../il2cpp/il2utils.h"
#include "../../il2cpp/Il2CppObjectInstance.h"
#include "../../il2cpp/unity.h"
#include "../Module.h"
#include "../../assets/asset_bundles.h"
#include "../../config/ColorpickerValue.h"
#include "../../config/CheckboxValue.h"
#include "../../config/SelectValue.h"

class ColorpickerValue;
class Module;
class FloatSliderEditableValue;
class ChamsModule;

inline ChamsModule* chams_module_self = nullptr;

class ChamsModule : Module
{
  public:
    ChamsModule();

    CheckboxValue* player_chams;
    CheckboxValue* gear_chams;
    SelectValue* chams_type;
    ColorpickerValue* visible_color;
    ColorpickerValue* invisible_color;
    CheckboxValue* weapon_chams;
    SelectValue* weapon_chams_type;
    ColorpickerValue* weapon_chams_color;
    CheckboxValue* include_scope;
    CheckboxValue* include_arms;

    // Loot chams: swap every in-world item's material over to the bundle's chams
    // shader so the whole model renders as one flat static texture visible
    // through geometry. This offloads loot highlighting from the per-frame ESP
    // drawing to a one-time material pass per item — the GPU depth test does the
    // rest for free.
    CheckboxValue* item_chams;
    SelectValue* item_chams_type;
    ColorpickerValue* item_visible_color;
    ColorpickerValue* item_occluded_color;
    FloatSliderEditableValue* item_chams_distance;

    // Container chams: the same material swap as Loot Chams, applied to the
    // LootableContainer components in the scene (crates, safes, registers).
    //
    // WHY CONTAINERS ARE NOT PART OF LOOT CHAMS. GameWorld.LootItems holds the
    // loose loot -- the LootItem objects scan_item_chams walks. A LootableContainer
    // is a different thing entirely: an EFT.Interactive component that lives on a
    // scene object and has no entry in that list, so the loot scan cannot see one.
    // It also has no _renderers field, which is the field apply_chams_to_item
    // reads to find what to paint. So containers need their own enumeration
    // (FindObjectsOfType, below) and their own renderer collection (the transform
    // walk), sharing the paint/restore primitives with the item path.
    CheckboxValue* container_chams;
    SelectValue* container_chams_type;
    ColorpickerValue* container_visible_color;
    ColorpickerValue* container_occluded_color;
    FloatSliderEditableValue* container_chams_distance;

    // Player names are neither unique nor always initialized for AI. Track the
    // actual managed object so every spawned entity gets its own material pass.
    std::set<uintptr_t> applied_players = std::set<uintptr_t>();

    // Loot objects already converted this raid. Keys are raw pointers only —
    // the game destroys the managed object when an item is picked up, and stale
    // keys are harmless because we never dereference them.
    std::unordered_set<uintptr_t> applied_items = std::unordered_set<uintptr_t>();

    // What each painted item's materials looked like BEFORE we touched them, so the
    // paint can be removed again.
    //
    // WHY THIS EXISTS. Painting is one-way in the stock code: set_shader/SetColor/
    // set_mainTexture are called and nothing ever puts the old values back. That is
    // what made the distance slider useless rather than merely coarse -- it read as
    // "paint an item once the player has come within N metres" and then held for the
    // rest of the raid, so lowering it did nothing at all. It is also how a chams
    // material leaks into a view the player did not ask for: the same Material
    // instance is reachable from an item's world renderer and from other renderers
    // the game binds it to, so a paint can show up somewhere the distance gate never
    // considered -- an inventory preview being the obvious one.
    //
    // KEYED BY ITEM, NOT BY RENDERER, and the value is ONE ENTRY PER RENDERER holding that
    // renderer's saved materials. That shape is deliberate: a flat list of materials
    // cannot be walked back against the renderer set without an out-of-band count, and
    // the two ways that count can go wrong -- a null saved slot, or a renderer whose
    // set_material did not resolve -- both silently shift every LATER renderer onto the
    // wrong slots. Nesting makes the alignment exact by construction: the Nth
    // MeshRenderer/SkinnedMeshRenderer in _renderers is saved[N], whatever happened
    // inside it. Keying by renderer instead would multiply the entry count by the
    // submesh count and leave nothing to walk without re-resolving _renderers.
    //
    // The saved values are Il2CppObject* into the managed heap. They are NOT
    // dereferenced to decide validity -- only compared and passed back to
    // set_material on a renderer we are certain is live -- so a stale entry here
    // cannot fault. Entries for destroyed items are pruned by the scan loop, which
    // walks the live loot list every tick.
    //
    // GAME-THREAD-ONLY, same as applied_items above.
    std::unordered_map<uintptr_t, std::vector<std::vector<Il2CppObject*>>> original_item_materials =
        std::unordered_map<uintptr_t, std::vector<std::vector<Il2CppObject*>>>();

    // ---- Container chams state ----
    //
    // The cached LootableContainer list, rebuilt from a scene-wide
    // FindObjectsOfType on the discovery clock below and painted from on the same
    // 250 ms tick the item path uses. Raw pointers into the managed heap, copied
    // out while the returned array is still on the stack; game-thread only.
    //
    // find_objects_of_type is a SCENE-WIDE search, and the ESP measured it at
    // 8.4 ms average / 135 ms peak (EspModule.cpp:6998-7007). That is why it runs
    // on a slow clock here instead of per paint tick.
    std::vector<Il2CppObject*> container_objs_;

    // Containers painted this raid. Keys are raw pointers and are never
    // dereferenced to decide validity -- only compared and used as map keys, same
    // contract as applied_items.
    std::unordered_set<uintptr_t> applied_containers;

    // What each painted container's materials looked like BEFORE we touched it, so
    // the paint can be taken back off again. Same nesting rule as the item map:
    // one entry per renderer, in renderer order.
    //
    // DELIBERATELY NOT SWEPT PER SCAN, unlike original_item_materials, and the
    // difference is which list is authoritative. The loot list is re-walked every
    // 250 ms, so an item absent from it is gone and its entry can be dropped. The
    // container cache is only refreshed every DISCOVERY interval, so an entry
    // absent from it during one pass may simply have been missed -- and dropping
    // it is exactly what would let the next re-paint record our own chams as the
    // thing to restore (needs_save goes false->true against a painted renderer).
    // Entries therefore live for the whole raid and are dropped wholesale on the
    // boundary reset, which is where every other per-raid cache is dropped too.
    std::unordered_map<uintptr_t, std::vector<std::vector<Il2CppObject*>>> original_container_materials =
        std::unordered_map<uintptr_t, std::vector<std::vector<Il2CppObject*>>>();

    // The GameWorld instance the container cache was built against. A DIFFERENT
    // instance means the scene was torn down and rebuilt -- a transit, where
    // is_in_raid can stay true straight through the load -- and every cached
    // container pointer and every saved material belongs to the old scene.
    // Raid end is caught separately, in application_update.
    Il2CppObject* last_seen_game_world_ = nullptr;

    // Snapshot of the item-chams settings that applied_items was built with;
    // changing them in the menu wipes the cache so the new look is re-applied.
    int item_chams_last_type_ = -1;
    ImU32 item_chams_last_visible_ = 0;
    ImU32 item_chams_last_occluded_ = 0;
    ULONGLONG item_chams_last_scan_ms_ = 0;

    // Last full re-paint cadence + previous toggle state. The game can revert item
    // materials on its own (visual-switch / material rebinds after a transit), which
    // would leave applied_items sticky and the checkbox "doing nothing". Clearing on
    // a slow cadence re-paints everything in range in a few ticks; the OFF->ON edge
    // forces one immediately.
    ULONGLONG item_chams_last_reapply_ms_ = 0;
    bool item_chams_was_enabled_ = false;
    static constexpr ULONGLONG kItemChamsReapplyIntervalMs = 8000;

    // Per-tick counters for the item-chams trace line. Declared BEFORE
    // report_item_chams_scan() below, which takes one by const reference: a type used in a
    // declaration must exist first, and the declaration is not a member so the usual
    // "members are all visible in the class body" rule does not save it.
    struct scan_stats {
        size_t examined = 0;
        size_t applied = 0;
        size_t renderers = 0;        // sum of apply_chams_to_item's return value
        size_t zero_renderer = 0;    // items visited that painted NOTHING
        size_t out_of_range = 0;
        size_t unpainted = 0;        // items restored because they left the radius
        size_t already = 0;
        size_t null_obj = 0;
        size_t corpse = 0;           // skipped: corpses belong to Player Chams, not Loot Chams
        size_t no_game_object = 0;   // component_get_game_object returned null
        size_t no_transform = 0;     // gameobject_get_transform returned null
        size_t materials = 0;        // material SLOTS painted, summed over items
        size_t multi_slot = 0;       // items whose slots exceeded their renderer count
        bool hit_cap = false;
    };
    static constexpr ULONGLONG kItemChamsTraceMs = 2000;

    // The scan cursor, lifted out of scan_item_chams()'s function-local `static` so that
    // every place which clears applied_items can also rewind it.
    //
    // WHY IT MATTERS, and it is the leading suspect for "some items do not get their
    // texture". applied_items.clear() on the 8 s re-paint cadence is supposed to make the
    // next scan re-apply everything in range. It cannot: the scan resumes at
    // last_scanned_index and only ever moves FORWARD, so an item the cursor has already
    // passed is never revisited and the re-paint cannot reach it. The reapply therefore
    // only works for items that happened to spawn after the cursor, which is a small and
    // shrinking fraction of a raid. The cursor rewinds to 0 on every clear, so "clear and
    // repaint" means what it says.
    //
    // It was a function-local static, which is why none of the six clear sites could touch
    // it -- there was no handle to touch.
    size_t item_chams_last_scanned_index_ = 0;

    // Container-chams cadence. Discovery is the slow clock (2 s while the first
    // 30 s of the raid are still filling, 15 s after); the paint walk runs on the
    // item path's 250 ms tick off the cached list. The ramp exists for the same
    // reason the ESP has one: the loot spawner rolls containers over the opening
    // seconds of a raid, so a container that will exist this raid may not be
    // findable yet on the first pass.
    ULONGLONG container_chams_first_discover_ms_ = 0;
    ULONGLONG container_chams_last_discover_ms_ = 0;
    ULONGLONG container_chams_last_scan_ms_ = 0;
    ULONGLONG container_chams_last_reapply_ms_ = 0;
    bool container_chams_was_enabled_ = false;
    size_t container_chams_last_index_ = 0;

    // Snapshot of the container-chams settings the paint was built with; changing
    // them in the menu clears applied_containers so the new look re-applies.
    int container_chams_last_type_ = -1;
    ImU32 container_chams_last_visible_ = 0;
    ImU32 container_chams_last_occluded_ = 0;

    // Per-tick counters for the container-chams trace line, same reconciliation
    // discipline as the item one: every branch of the scan loop increments
    // exactly one counter, and `unaccounted` is printed so a branch that forgets
    // to is visible rather than silent.
    struct container_scan_stats {
        size_t found = 0;        // FindObjectsOfType results, before any filter
        size_t ghost = 0;        // skipped: prefab in the scene the spawner did not roll
        size_t invalid = 0;      // skipped: managed object failed the validity check
        size_t no_transform = 0; // skipped: no transform -> cannot place or paint
        size_t cached = 0;       // survived the filters into container_objs_
        size_t examined = 0;
        size_t applied = 0;
        size_t renderers = 0;    // sum of paint_renderer_list's return value
        size_t materials = 0;    // material SLOTS painted, summed over containers
        size_t zero_renderer = 0;
        size_t out_of_range = 0;
        size_t unpainted = 0;
        size_t already = 0;
        size_t no_game_object = 0;
        size_t dead_skipped = 0; // out-of-range container whose native object is gone
        bool hit_cap = false;
    };
    static constexpr ULONGLONG kContainerChamsTraceMs = 2000;
    static constexpr ULONGLONG kContainerChamsRampWindowMs = 30000;
    static constexpr ULONGLONG kContainerChamsRampIntervalMs = 2000;
    static constexpr ULONGLONG kContainerChamsSteadyIntervalMs = 15000;

    // Shaders come from the embedded chams asset bundle — cache them per type
    // instead of re-loading the asset for every single material.
    // GAME-THREAD-ONLY, like the two sets above: applied_players,
    // applied_items, item_shader_cache_ and the item_chams_last_* members are
    // written from gameworld_update -> scan_item_chams and from
    // clear_runtime_cache, and read nowhere else.
    //
    // get_runtime_cache_count()/get_runtime_cache_bytes() used to be the
    // exception: they read applied_players/applied_items straight from the
    // render thread (ConfigModule::draw_cache_info) with nothing synchronising
    // the two, so the panel could size() a set mid-rehash. The counts are now
    // computed on the game thread (refresh_cache_stats) and published as
    // atomics; the render thread never touches a container.
    std::unordered_map<int, Il2CppObject*> item_shader_cache_ = std::unordered_map<int, Il2CppObject*>();
    std::atomic<size_t> cache_entries_{0};

    void refresh_cache_stats();

    static std::string get_shader_name(const int id);

    void draw_overlay(ImDrawList* draw_list) override;

    void application_update() override;

    static unity::color to_unity_color(const ImVec4& c);

    static ImU32 pack_color(const ImVec4& c);

    // Only mesh/skinned mesh materials are safe to flatten — particle, trail and
    // line renderers exist on some loot (smoke, flares) and would render wrong.
    static bool is_item_renderer(const Il2CppObject* renderer);

    void item_chams_reapply_if_settings_changed();

    Il2CppObject* load_item_chams_shader(const Il2CppImage* unity_image, const int type_id);

    // ---- Shared renderer-list primitives ----
    //
    // Both chams surfaces (loose loot, containers) do the same two things: take a
    // list of MeshRenderer/SkinnedMeshRenderer objects and paint every material
    // slot on each, or put the saved materials back. The lists differ in where
    // they come from -- a LootItem's _renderers field versus a transform walk
    // over a container's children -- and that is the ONLY difference, so it lives
    // in the collectors below and the paint/restore logic exists once.
    //
    // The save/restore alignment rule from apply_chams_to_renderer holds here
    // unchanged: saved[n] belongs to the Nth qualifying renderer in the list,
    // which is only true because the collector produces the SAME list in the same
    // order on both passes. That is why the item collectors are shared functions
    // rather than the two inline loops they replaced.
    static int paint_renderer_list(const std::vector<Il2CppObject*>& renderers, Il2CppObject* shader,
        const unity::color& visible, const unity::color& occluded, int* slots_out,
        std::vector<std::vector<Il2CppObject*>>* save_out);

    // Puts back the materials saved by the paint above, in renderer order.
    // Consumes `originals` (the caller swaps it out of the save map first, so a
    // partial walk cannot leave a half-restored entry behind). Returns how many
    // material slots were actually restored.
    static int restore_renderer_list(const std::vector<Il2CppObject*>& renderers,
        std::vector<std::vector<Il2CppObject*>>& originals);

    // A LootItem's renderers, from its _renderers field. Shared by the item paint
    // and un-paint paths so the two can never disagree about the list.
    static int collect_item_renderers(Il2CppObject* loot_obj, std::vector<Il2CppObject*>& out);

    // `original_material` is the renderer's pre-paint material for the SAME slot
    // (index-aligned by apply_chams_to_renderer's save list), or null when the
    // caller has none. It is read but never written: its mainTexture is carried
    // onto the chams material after set_shader so the item keeps its artwork
    // under the two-colour shader instead of rendering as a flat fill -- the
    // 2026-10-14 report that chams "replaces the original texture entirely".
    static void apply_chams_to_material(Il2CppObjectInstance& material_instance, Il2CppObject* shader,
        const unity::color& visible, const unity::color& occluded,
        Il2CppObject* original_material = nullptr);

    // Walks the bundled chams shader's declared property list once and logs it,
    // so "does it sample _MainTex" is a measurement instead of an inference.
    // The bundle's .shader sources are not in the tree; this is the only honest
    // route to the answer short of a render.
    static void log_shader_properties_once(Il2CppObject* shader, const std::string& shader_name);

    static int apply_chams_to_renderer(Il2CppObject* renderer, Il2CppObject* shader,
        const unity::color& visible, const unity::color& occluded,
        std::vector<Il2CppObject*>* save_out = nullptr);

    // Paints every material slot of every renderer on one in-world item, and remembers
    // what each slot looked like beforehand so the paint can be taken back off.
    //
    // Returns the number of RENDERERS painted. slots_out, when given, receives the
    // number of material SLOTS, which is >= the renderer count whenever a mesh has
    // submeshes. The caller needs the pair: a return of 1 renderer with 3 slots is a
    // fully converted item, and conflating the two is how the multi-material bug hid.
    //
    // save_out, when given, receives one entry per renderer holding that renderer's
    // pre-paint materials. It must be non-null only on the FIRST paint of an item: the
    // saved values are captured before get_materials instantiates over them, and
    // re-capturing later would record our own chams as the thing to restore.
    static int apply_chams_to_item(Il2CppObject* loot_obj, Il2CppObject* shader,
        const unity::color& visible, const unity::color& occluded, int* slots_out = nullptr,
        std::vector<std::vector<Il2CppObject*>>* save_out = nullptr);

    // Puts back the materials saved by the paint above, in renderer order. A no-op when
    // the item was never painted, and a no-op per slot whose saved material is no longer
    // alive -- the scene can be gone by the time we get here, and writing through a dead
    // material is the same class of fault as writing through a dead shader. Returns how
    // many material slots were actually restored.
    int unpaint_chams_to_item(Il2CppObject* loot_obj);

    // Drops one item's saved materials without touching the game. For the teardown paths
    // -- settings changed, toggle off, raid over -- where the scene is going away or is
    // about to be repainted wholesale, and calling back into a renderer we no longer own
    // is the riskier half of the pair.
    void forget_item_materials(uintptr_t loot_key);

    // Restores every painted item still present in the live loot list, then drops the
    // saved materials wholesale. Used on the OFF edge, where leaving the paint on is
    // the bug. Walks the live list rather than the saved keys on purpose: a saved key
    // can name a destroyed LootItem, and calling into one of those faults.
    void unpaint_all_items(Il2CppObjectInstance& game_world_instance);

    void scan_item_chams(const Il2CppImage* unity_image, Il2CppObjectInstance& game_world_instance,
        Il2CppObjectInstance& main_player);

    // Drops saved materials that name items no longer in the live loot list, so a destroyed
    // item's address being reused cannot cause its materials to be restored onto a
    // different item. Only valid immediately after a scan pass has run to completion.
    // Returns how many were dropped.
    size_t sweep_stale_materials();

    // ---- Container chams ----
    //
    // Discovery: one FindObjectsOfType(LootableContainer) pass, ghost-filtered,
    // rebuilding container_objs_. Runs on the slow clock from
    // scan_container_chams.
    void discover_containers(const Il2CppClass* game_world_class, container_scan_stats& st);

    // A container's renderers: its own component first, then its children, ACTIVE
    // children only, depth-capped. The depth cap and the active test are both
    // there for the same reason -- a container is usually a child of furniture
    // (a drawer inside a desk), and an unbounded walk would paint the desk, the
    // room, or whatever else the prefab nests under it.
    //
    // ONE ANCESTOR FALLBACK, taken only when the container's own subtree yielded
    // nothing: the bag and corpse families are leaves whose mesh is a normal
    // active child of the immediate parent (measured 2026-10-13, pid 22380 --
    // `_LOD0` / `_SHADOW_LOD0` under `scontainer_medbag_smu06`). One level, not
    // two: the grandparent is a shared prefab root holding the whole corpse set
    // (`LOOTABLE1`, 17 children). A container that finds renderers below itself
    // gets exactly the list it got before, so existing containers cannot change.
    static int collect_container_renderers(Il2CppObject* container_obj, Il2CppObject* renderer_type,
        std::vector<Il2CppObject*>& out);

    static void collect_child_renderers(Il2CppObject* transform, Il2CppObject* renderer_type,
        std::vector<Il2CppObject*>& out, const int depth);

    void container_chams_reapply_if_settings_changed();

    int unpaint_chams_to_container(Il2CppObject* container_obj, Il2CppObject* renderer_type);

    // Restores every painted container still in the cache, then drops the book-
    // keeping. The OFF edge, where leaving the paint on is the bug.
    void unpaint_all_containers(Il2CppObject* renderer_type);

    // Drops one container's saved materials without touching the game, for the
    // paths where the object is gone and restoring is not an option.
    void forget_container_materials(const uintptr_t key);

    // Drops every container-chams map, the cache and the clocks, WITHOUT
    // restoring anything. The transit/exfil/raid-end path.
    //
    // Forget rather than restore, matching clear_runtime_cache's documented
    // trade: at a boundary the renderers these point at are being torn down or
    // rebuilt underneath us, and walking one to write its materials back is the
    // fault the item path already learned to avoid. Whatever is still painted
    // dies with the scene.
    void reset_container_chams_state();

    void scan_container_chams(const Il2CppImage* unity_image, const Il2CppClass* game_world_class,
        Il2CppObjectInstance& main_player);

    static void report_container_scan(const container_scan_stats& st, const size_t cache_size,
        const size_t cursor_at_entry, const size_t cursor_after, Il2CppObject* shader,
        const size_t applied_set_size, const size_t saved_set_size);

    // ---- DEBUG: the interaction probe ----------------------------------------
    //
    // Hooks EFT.Interactive's Interact(InteractionResult) on the classes a player
    // can open and logs ONE line per interaction naming what was opened and
    // whether this module's container pipeline would see it.
    //
    // WHY IT EXISTS. The container-chams trace is an AGGREGATE: it counts per
    // pass, so a single container that never paints looks exactly like one that
    // was merely far away -- which is precisely the ambiguity that made "some
    // containers aren't chams-ed" unanswerable from the log. This probe answers
    // it per-object, from the one event that has no ambiguity: the player opened
    // the thing.
    //
    // WHAT IT REPORTS, and why each field:
    //   cached      -- is the opened object in container_objs_ at all?
    //   ghost_pass  -- would the discovery filter have admitted it?
    //   initialized -- the game's own <IsInitialized>k__BackingField, which is
    //                  what the three proxy fields are proxies FOR
    //   renderers   -- what collect_container_renderers finds for it, the same
    //                  collector the paint walk uses
    //   painted/saved/in_range -- whether the pipeline actually reached it
    //
    // DEBUG-LOG-GATED: the whole line is one std::format, so the gate goes in
    // front of it (AGENTS.md: the caller builds the argument regardless of the
    // level). Installed once per process from the first gameworld_update, which
    // is the first place that holds both a resolved Assembly-CSharp image and a
    // live scene -- see install_interaction_hooks.
    void log_interaction_probe(Il2CppObject* interactable, Il2CppObject* interaction_result);

    // One aggregated trace line per scan tick (throttled by kItemChamsTraceMs), guarded by
    // logger::debug_enabled() so the std::format argument is not built when Debug Log is
    // off. Per-ITEM logging at the 250 ms scan cadence would be hundreds of lines a second,
    // which is the log-flood failure this repo has already had once.
    static void report_item_chams_scan(const scan_stats& st, size_t loot_count,
        size_t cursor_at_entry, size_t cursor_after, Il2CppObject* shader,
        size_t applied_set_size, size_t saved_set_size, size_t swept);

    void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
        Il2CppObjectInstance main_player) override;

    // ---- interaction probe internals ----
    //
    // Interact(InteractionResult) is virtual and every subclass overrides it, so
    // the hook has to be installed per concrete class: hooking the base
    // WorldInteractiveObject slot would never be reached, because the call
    // dispatches to the runtime type's own methodPointer.
    //
    // ONE hook body per target, NOT one shared body: the body must call ITS OWN
    // trampoline, and nothing inside a single function can tell two targets
    // apart. The runtime class name comes from the object itself, so the log line
    // does not need to know which hook fired.
    using interact_sig = void (*)(Il2CppObject*, Il2CppObject*);
    static inline interact_sig o_lootable_container_interact = nullptr;
    static inline interact_sig o_trunk_interact = nullptr;
    static void hk_lootable_container_interact(Il2CppObject* interactable, Il2CppObject* interaction_result);
    static void hk_trunk_interact(Il2CppObject* interactable, Il2CppObject* interaction_result);

    // Set FIRST inside the installer so a failed install cannot retry every
    // tick: the image is resolved by the time gameworld_update runs, so a
    // failure here means a renamed class, and retrying would log the same
    // warning for the rest of the raid.
    bool interaction_hooks_installed_ = false;

    // Last player position, refreshed by gameworld_update so the probe can print
    // a distance. GAME-THREAD-ONLY, same as every other member here: the hook
    // fires from the game's own interaction path.
    unity::vector3 last_player_pos_{};

    void install_interaction_hooks(const Il2CppImage* image);

    void init() override;

    [[nodiscard]] bool is_active() const override {
        return player_chams->get_value() || weapon_chams->get_value() || item_chams->get_value()
            || container_chams->get_value();
    }

    void clear_runtime_cache() override;

    [[nodiscard]] size_t get_runtime_cache_count() override;

    [[nodiscard]] size_t get_runtime_cache_bytes() override;

    void prepare_menu_draw() override;
};
