#pragma once

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <sstream>
#include <string>

#include <imgui.h>

#include "../../config/ActionRowValue.h"
#include "../../gui/menu/menu.h"
#include "../../il2cpp/il2utils.h"
#include "../../il2cpp/unity.h"
#include "../../util/i18n.h"
#include "../../util/logger.h"
#include "../Module.h"
#include "../ModuleCategory.h"
#include "../game_state.h"
#include <format>

class IcebreakerScenarioModule : public Module
{
  public:
    IcebreakerScenarioModule();

    ActionRowValue *skip_cutscene;

    void skip_cutscene_impl();

    int skip_hold_key = 'F';

    // _cutsceneSkipUI is null offline, so the live hold-to-skip widget is redrawn here.
    void draw_overlay(ImDrawList *draw_list) override;
    void application_update() override;

    void gameworld_update(const Il2CppClass *, Il2CppObjectInstance game_world, Il2CppObjectInstance main_player) override;

    void init() override;

    void resolve_runtime_api();

  private:
    struct timeline_data
    {
        Il2CppString *cutscene_id;
        Il2CppString *scene_name;
        float duration;
        std::uint32_t padding_14;
        Il2CppArray *start_actions;
        Il2CppArray *end_actions;
        bool can_skip;
        bool has_subtitles;
        std::uint8_t padding_2a[6];
        Il2CppString *subtitle_id;
        Il2CppObject *timeline;
        Il2CppObject *timeline_object_names;
        Il2CppObject *timeline_objects;
        Il2CppObject *audio_data;
    };

    struct timeline_list : Il2CppObject
    {
        Il2CppArray *items;
        std::int32_t size;
        std::int32_t version;
        Il2CppObject *sync_root;
    };

    struct collider_bounds
    {
        unity::vector3 center;
        unity::vector3 extents;
    };

    static_assert(offsetof(timeline_data, start_actions) == 0x18);
    static_assert(offsetof(timeline_data, audio_data) == 0x50);
    static_assert(sizeof(timeline_data) == 0x58);
    static_assert(sizeof(collider_bounds) == 0x18);

    using start_cutscene_sig = Il2CppObject *(*)(Il2CppObject *, Il2CppString *, Il2CppObject *, bool, bool, float);
    using register_director_sig = void (*)(Il2CppObject *, Il2CppString *, Il2CppObject *);
    using get_trigger_emitter_sig = Il2CppObject *(*)();
    using emit_rally_trigger_sig = void (*)(Il2CppObject *, int);

    inline static Il2CppImage *assembly_csharp_ = nullptr;
    inline static start_cutscene_sig o_start_cutscene_ = nullptr;
    inline static register_director_sig o_register_playable_director_ = nullptr;
    inline static register_director_sig o_register_cutscene_director_ = nullptr;
    inline static get_trigger_emitter_sig get_trigger_emitter_ = nullptr;
    inline static emit_rally_trigger_sig emit_rally_trigger_ = nullptr;
    inline static bool trigger_pending_ = false;
    inline static std::string scenario_trigger_id_;
    inline static Il2CppObject *playable_director_client_ = nullptr;
    inline static Il2CppObject *playable_director_ = nullptr;
    inline static Il2CppObject *cutscene_director_client_ = nullptr;
    inline static Il2CppObject *cutscene_root_ = nullptr;
    inline static Il2CppObject *scenario_rally_zone_ = nullptr;
    inline static Il2CppObject *scenario_rally_collider_ = nullptr;

    bool controllers_logged_ = false;
    bool online_world_logged_ = false;
    Il2CppObject *last_server_ = nullptr;
    Il2CppObject *last_client_ = nullptr;
    Il2CppObject *raid_world_ = nullptr;
    Il2CppObject *logged_bank_ = nullptr;
    bool scenario_ready_logged_ = false;
    bool start_attempted_ = false;
    bool trigger_emitter_logged_ = false;
    bool rally_zones_logged_ = false;
    bool runtime_api_ready_ = false;
    static constexpr float skip_hold_seconds = 1.5f;

    bool state_seen_ = false;
    bool queue_skip_cutscene_ = false;
    bool cutscene_active_ = false;
    float skip_hold_ = 0.0f;
    std::string last_cutscene_id_;

    static bool equals_ignore_case(std::string value, std::string expected);

    static bool is_class_or_parent(Il2CppObject *object, const char *name);

    static Il2CppObject *object_field(Il2CppObject *object, const char *name);

    template <typename T>
    static T value_field(Il2CppObject *object, const char *name) {
        if (!object || !object->klass)
            return {};
        const FieldInfo *field = il2utils::resolve_field(object->klass, name);
        if (!field || field->offset <= 0)
            return {};
        return *reinterpret_cast<T *>(reinterpret_cast<std::uintptr_t>(object) + field->offset);
    }

    template <typename T>
    static bool set_value_field(Il2CppObject *object, const char *name, T value) {
        if (!object || !object->klass)
            return false;
        const FieldInfo *field = il2utils::resolve_field(object->klass, name);
        if (!field || field->offset <= 0)
            return false;
        *reinterpret_cast<T *>(reinterpret_cast<std::uintptr_t>(object) + field->offset) = value;
        return true;
    }

    static std::string string_field(Il2CppObject *object, const char *name);

    static std::string string_array(Il2CppArray *array);

    static const timeline_data *find_timeline(Il2CppObject *bank, const char *cutscene_id);

    static bool has_timeline(Il2CppObject *bank, const char *cutscene_id, const char *scene_id);

    void poll_cutscene_phase(Il2CppObject *client);

    // _cutsceneSkipUI stays null offline because CanShowCutsceneSkipUI() refuses while _offlineMode
    // is set, so the live prompt is unreachable without clearing that flag.
    static void log_skip_ui(Il2CppObject *client);

    void draw_skip_prompt(ImDrawList *draw_list, const float progress) const;

    static const MethodInfo *find_method(const Il2CppClass *klass, const char *name);

    static std::string param_types(const MethodInfo *method);
    // StopCutscene takes a PlayableDirector, not the server's CutsceneProcess. With skip=false,
    // its TimelineShowed call reports local completion before clearing the process ID, restores
    // input, and unsubscribes/stops the director itself. Do not stop the director a second time.
    void run_queued_skip(Il2CppObject *client);

    static bool ensure_directors_registered(Il2CppObject *client, const char *scene_id);

    static Il2CppObject *resolve_root_game_object(Il2CppObject *game_object);

    static void log_cinematic_hierarchy(Il2CppObject *root_transform);

    static void log_branch(Il2CppObject *transform, const std::string &path);

    static void deactivate_cinematic_objects();

    static int get_player_id(Il2CppObject *player);

    static int get_player_raid_id(Il2CppObject *player);

    void try_activate_rally_zone(Il2CppObject *game_world, Il2CppObject *main_player);

    static Il2CppObject *make_player_id_list(Il2CppObject *server, int player_id);

    static void log_timelines(Il2CppObject *bank);

    static void log_cutscene_objects();

    static void discover_scenario_trigger();

    void log_trigger_emitter();

    void log_rally_zones();

    void reset_raid();
};
