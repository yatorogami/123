#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <functional>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <Windows.h>
#include <imgui.h>

#include "../game_state.h"
#include "../Module.h"
#include "../ModuleCategory.h"
#include "../eft_api.h"
#include "../../config/ActionRowValue.h"
#include "../../config/CheckboxValue.h"
#include "../../config/FloatSliderEditableValue.h"
#include "../../config/InfoDrawValue.h"
#include "../../config/IntSliderEditableValue.h"
#include "../../config/MenuSectionValue.h"
#include "../../config/SelectValue.h"
#include "../../il2cpp/Il2CppObjectInstance.h"
#include "../../il2cpp/exports.h"
#include "../../il2cpp/il2utils.h"
#include "../../il2cpp/unity.h"
#include "../../util/logger.h"
#include "../../util/globals.h"
#include "../../util/utils.h"
#include "../../gui/menu/menu.h"

// What one container pass did. Deliberately a POD of ints and bools, and
// deliberately NOT a formatted std::string.
//
// The pass runs on the game thread (GameWorld.Update, dispatched at
// common_hooks.cpp:445) while the Loot Teleporter card reads it on the render thread
// (dxhook::draw_imgui -> menu::draw() at gui/dxhook/dxhook.cpp:1284, whose own comment
// calls it "the game's object model on this thread", -> menu.cpp:1276). An int or an
// aligned ULONGLONG tears into "a stale number for one frame", which is what
// loot_teleport_preview_counts_ below already relies on; a std::string tears into a
// reader following a heap pointer the writer just freed -- and the try/catch around
// menu::draw() only catches std::exception, not the access violation that would be.
// So the string is formatted on the reading side, in get_loot_tp_container_report(),
// and only these counters cross.
struct container_loot_stats {
    int found = 0;         // LootableContainer components in the scene
    int walked = 0;        // of those, placed (non-ghost) and readable
    int seen = 0;          // items inside them
    int matched = 0;       // of those, passing the active filter
    int detached = 0;      // taken out of their container
    int thrown = 0;        // and recreated as ground loot
    int detach_refused = 0;
    int detach_faulted = 0;
    int no_template = 0;
    int throw_refused = 0;
    int throw_faulted = 0;
    bool capped = false;
    bool timed_out = false;
    ULONGLONG elapsed_ms = 0;
};

// Port of Stupid.Solutions SpawnBot:
//   LocalGame (IBotGame) → BotsController.GetSpawner() → SpawnBotByTypeForce
class WorldModule : Module
{
  public:
    WorldModule();

    void application_update() override;

    // --- Bot spawn (local raid force spawn) ---------------------------------
    MenuSectionValue* section_spawn_;
    // Labels are display-only (not translated). Index maps to spawn_bot_roles_[] below.
    // WildSpawnType values: EFT 1.0.6.5.46221 dump.cs
    SelectValue* spawn_bot_type;

    IntSliderEditableValue* spawn_bot_count;
    SelectValue* spawn_bot_difficulty;

    ActionRowValue* spawn_bot;
    bool queue_spawn_bot = false;

    void spawn_bot_impl();

    // Poll/show game's SpawnDelaysService queue (can be heavy / noisy — optional).
    CheckboxValue* show_game_delayed;

    // Live queue status (our requests + optional game delay list).
    InfoDrawValue* spawn_queue_info_;

    // --- Loot TP -------------------------------------------------------------
    MenuSectionValue* section_loot_tp_;
    // teleport every loose loot item on the map into rings around the player for easy looting
    FloatSliderEditableValue* loot_circle_radius;
    FloatSliderEditableValue* loot_height_offset;
    ActionRowValue* loot_to_me;
    // Also pull matching items out of placed LootableContainers (crates, safes,
    // duffels, weapon boxes) instead of only loose ground loot.
    //
    // DEFAULT OFF, and that is deliberate. Loose loot is moved by writing a
    // transform; this branch detaches items from container inventories and creates
    // new ground-loot entities, which is the only part of the teleporter that mutates
    // game inventory state. The first attempt at it (a2a04695c, reverted in
    // 961527747) shipped default-ON, called a removal API that does not exist, and
    // locked the game for 20 s before a managed throw ended the process.
    CheckboxValue* loot_tp_from_containers;
    // Hard cap on how many container items ONE button press will move. Creating a
    // ground-loot entity per item is not free, and a big map can hold thousands of
    // container items; without a cap one press is an unbounded stall.
    IntSliderEditableValue* loot_tp_container_cap;
    bool queue_loot_to_me = false;
    // 0 All, 1 Quest Items, 2 Wishlisted, 3 Selected Item, 4 Selected Category.
    int queued_loot_filter_ = 0;
    std::function<bool(int, const std::string&, const std::string&, bool, Il2CppObject*)>
        loot_teleport_filter_matcher_;
    std::array<int, 6> loot_teleport_preview_counts_{};
    ULONGLONG loot_teleport_preview_refresh_ms_ = 0;
    // Result of the most recent container pass, for the Loot Teleporter card. Not a
    // ConfigValue: it is a result, not a setting. See container_loot_stats above for
    // why this is counters and a has-run flag rather than a ready-made string.
    container_loot_stats loot_tp_container_stats_{};
    bool loot_tp_container_has_run_ = false;

    void loot_to_me_impl(const int filter = 0);

    void set_loot_teleport_filter_matcher(
        std::function<bool(int, const std::string&, const std::string&, bool, Il2CppObject*)> matcher);

    [[nodiscard]] int get_loot_teleport_preview_count(const int filter) const;

    [[nodiscard]] std::string get_loot_tp_container_report() const;

    void refresh_loot_teleport_preview(Il2CppObjectInstance game_world_instance,
        Il2CppObjectInstance main_player);

    // --- Bot control / TP ----------------------------------------------------
    MenuSectionValue* section_bot_tp_;
    ActionRowValue* kill_all;
    bool queue_kill_all = false;

    void kill_all_impl();

    ActionRowValue* tp_all;
    bool queue_tp_all = false;

    void tp_all_impl();

    // Teleport a single target in front of you (Stupid.Solutions TeleportEntityToCrosshair style).
    // Mode: 0 = closest by world distance, 1 = closest to screen crosshair.
    SelectValue* tp_one_mode;
    ActionRowValue* tp_one;
    bool queue_tp_one = false;

    void tp_one_impl();

    // Role allow-list for TP All / TP One. When every filter is OFF → teleport all except BTR.
    // When any is ON → only matching kinds (BTR always excluded).
    CheckboxValue* tp_scav;
    CheckboxValue* tp_boss;
    CheckboxValue* tp_guard;
    CheckboxValue* tp_cultist;
    CheckboxValue* tp_raider;
    CheckboxValue* tp_defector;
    CheckboxValue* tp_black_division;
    CheckboxValue* tp_pmc;

    void draw_overlay(ImDrawList* draw_list) override;

    static bool is_local_player(Il2CppObjectInstance& player_instance);

    // Flat XZ destination in front of the player (ignore look pitch so bots don't end in floor/ceiling).
    // out_right is a unit horizontal vector for multi-bot spacing.
    static bool try_teleport_pos_in_front(Il2CppObjectInstance& main_player, unity::vector3& out,
        unity::vector3* out_right = nullptr, const float distance = 5.f);

    // Bot pathfinding rewrites Player.Teleport every tick while a path is active — stop + BotMover.Teleport.
    // Boss AI is more aggressive about repathing; clear path, pause mover, and re-apply BotMover.Teleport.
    static void try_teleport_bot_path(Il2CppObject* player_object, const unity::vector3& dest);

    static void try_set_movement_transform_pos(Il2CppObject* player_object, const unity::vector3& dest);

    static void teleport_player_to(Il2CppObject* player_object, const unity::vector3& dest);

    void kill_all_players(Il2CppObjectInstance& game_world_instance);

    // BotOwner.Memory is a public field; also try get_Memory for older layouts.
    static Il2CppObject* try_get_bot_memory(Il2CppObject* bot_owner);

    // Clear BotGoalTarget + GoalEnemy (Stupid.Solutions "lobotomy").
    static void bot_clear_goals(Il2CppObject* bot_owner);

    // MakeBotAlly: BotsGroup.RemoveEnemy + AddAlly, then clear combat goals.
    static bool bot_make_ally(Il2CppObject* bot_owner, Il2CppObject* local_player);

    static Il2CppObject* try_get_bot_owner_from_player(Il2CppObject* player_object);

    bool tp_role_allowed(const eft_api::npc_kind kind) const;

    void tp_all_players(Il2CppObjectInstance& game_world_instance, Il2CppObjectInstance& main_player);

    // Pick one eligible player and teleport them to ~5m in front of local player.
    void tp_one_player(Il2CppObjectInstance& game_world_instance, Il2CppObjectInstance& main_player);

    void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
        Il2CppObjectInstance main_player) override;

    void init() override;

  private:
    struct pending_spawn_entry
    {
        std::string label;
        int role = 0;
        int count = 1;
        int difficulty = 1;
        ULONGLONG request_ms = 0;
    };

    struct game_delay_entry
    {
        std::string text;
        int count = 0;
        float created_time = 0.f; // Unity Time.time when queued
        float waited_s = 0.f;
    };

    std::vector<pending_spawn_entry> pending_spawns_;
    std::vector<game_delay_entry> game_delay_lines_;
    int game_bots_delayed_ = 0;
    int game_in_spawn_process_ = 0;
    int game_wait_count_ = 0;
    ULONGLONG last_queue_poll_ms_ = 0;
    // Hysteresis: don't flash 30→0→30 when poll fails or list is mid-mutation.
    int empty_poll_streak_ = 0;
    Il2CppObject* cached_spawner_ = nullptr;

    // WildSpawnType values for 46221 dump (must match SelectValue order above).
    static constexpr int spawn_bot_roles_[] = {
        // Regular / scav
        1,  // assault
        0,  // marksman
        10, // cursedAssault
        19, // assaultGroup
        // PMC / raiders
        9,  // pmcBot
        24, // exUsec
        52, // pmcUSEC
        51, // pmcBEAR
        // Reshala
        3, // bossBully
        5, // followerBully
        // Killa / Shturman
        6, // bossKilla
        7, // bossKojaniy
        8, // followerKojaniy
        // Glukhar + guards
        11, // bossGluhar
        12, // followerGluharAssault
        13, // followerGluharSecurity
        14, // followerGluharScout
        15, // followerGluharSnipe
        // Sanitar
        17, // bossSanitar
        16, // followerSanitar
        // Tagilla
        22, // bossTagilla
        23, // followerTagilla
        // Goons
        26, // bossKnight
        27, // followerBigPipe
        28, // followerBirdEye
        // Kaban
        32, // bossBoar
        33, // followerBoar
        36, // bossBoarSniper
        41, // followerBoarClose1 (Gus)
        42, // followerBoarClose2 (Basmach)
        // Kolontay
        43, // bossKolontay
        44, // followerKolontayAssault
        45, // followerKolontaySecurity
        // Zryachiy
        29, // bossZryachiy
        30, // followerZryachiy
        38, // peacefullZryachiyEvent
        40, // ravangeZryachiyEvent
        // Partisan
        47, // bossPartisan
        // Cultists
        21, // sectantPriest
        20, // sectantWarrior
        39, // sectactPriestEvent
        57, // sectantPredvestnik
        58, // sectantPrizrak
        59, // sectantOni
        // Events / misc
        25, // gifter
        48, // spiritWinter
        49, // spiritSpring
        50, // peacemaker
        53, // skier
        34, // arenaFighter
        35, // arenaFighterEvent
        37, // crazyAssaultEvent
        46, // shooterBTR
        // Infected
        60, // infectedAssault
        61, // infectedPmc
        62, // infectedCivil
        63, // infectedLaborant
        64, // infectedTagilla
        // Labyrinth
        65, // bossTagillaAgro
        66, // bossKillaAgro
        67, // tagillaHelperAgro
        // Black Division
        68, // blackDivision
        77, // bossBullyBlackDiv
        78, // followerBullyBlackDiv
        79, // pmcBotBlackDiv
        // VSRF
        69, // vsRF
        70, // vsRFSniper
        73, // vsRFFight
        // Other
        72, // sentry
        74, // civilian
        76, // bossWedge
        80, // bossWedgeLab
        81, // followerWedgeLab
    };

    static bool is_infected_role(const int wild_spawn_type);

    static Il2CppObject* try_get_local_game();

    static Il2CppObject* try_get_bots_controller(Il2CppObject* local_game);

    static Il2CppObject* try_get_bot_spawner(Il2CppObject* bots_controller);

    static Il2CppObject* try_create_bot_spawn_params(const int trigger_type);

    static bool try_spawn_bot_by_type(const int type_index, int count, int difficulty);

    static const char* role_label(const int type_index);

    static const char* difficulty_label(const int d);

    static float try_unity_time();

    // Requested entries leave when:
    //  1) raid ends (full clear)
    //  2) older than k_pending_max_age_ms (they are history, not live tracking)
    //  3) list cap (oldest dropped when > 24 after a new request)
    static constexpr ULONGLONG k_pending_max_age_ms = 90000; // 90s

    void prune_pending_spawns(const ULONGLONG now);

    void clear_game_delay_snapshot();

    // Apply new snapshot only on successful read. Empty results need N consecutive
    // empty polls before we clear UI (avoids 30→0→30 flicker while list mutates).
    void commit_game_delay_snapshot(
        const bool ok,
        const int wait_count,
        const int bots_delayed,
        const int in_process,
        std::vector<game_delay_entry>&& lines);

    void refresh_game_spawn_queue();

    void draw_spawn_queue_info();
};
