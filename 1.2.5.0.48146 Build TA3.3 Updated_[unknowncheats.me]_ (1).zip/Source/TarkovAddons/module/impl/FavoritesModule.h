#pragma once

#include <imgui.h>

#include "../Module.h"
#include "../ModuleCategory.h"
#include "../../config/CheckboxValue.h"
#include "../../gui/menu/imgui_addons.h"

// A compact, live view of feature toggles selected with the star beside their
// original controls. It owns no gameplay state: it only exposes the same
// CheckboxValue instances in one convenient Raid Dashboard card.
class FavoritesModule final : public Module
{
  public:
    FavoritesModule();

    void draw_overlay(ImDrawList*) override;
    void application_update() override;
    void gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) override;
    void init() override;

    void draw_menu_extra() override;
};
