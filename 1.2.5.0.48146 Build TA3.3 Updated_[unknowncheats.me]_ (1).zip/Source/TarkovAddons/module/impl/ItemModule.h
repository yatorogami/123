#pragma once
#include <chrono>
#include <random>
#include <vector>

#include "../eft_api.h"
#include "../game_item_db.h"
#include "../game_state.h"
#include "../Module.h"
#include "../ModuleCategory.h"
#include "../always_on.h"
#include "../../config/ActionRowValue.h"
#include "../../config/CheckboxValue.h"
#include "../../config/IntTextboxValue.h"
#include "../../config/ItemSearchValue.h"
#include "../../config/SelectValue.h"
#include "../../config/TextboxValue.h"
#include "../../il2cpp/Il2CppObjectInstance.h"
#include "../../util/logger.h"

inline Il2CppObject* item_factory;
using init_level_sig = Il2CppObject* (*)(Il2CppObject*, Il2CppObject*, Il2CppObject*, bool, Il2CppObject*, Il2CppObject*,
    Il2CppObject*);
inline init_level_sig o_init_level = nullptr;

inline Il2CppObject* hk_init_level(Il2CppObject* instance, Il2CppObject* item_factory_, Il2CppObject* config,
    const bool load_bundles_and_create_pools, Il2CppObject* resources,
    Il2CppObject* progress,
    Il2CppObject* ct) {
    item_factory = item_factory_;
    game_state::item_factory = item_factory_;

    // Let the game populate the template dictionary FIRST, then build the item db.
    // Doing it before the call yields an empty snapshot (the dictionary is filled
    // during init), which is why the db used to be built lazily from the first
    // loot-item lookup instead.
    Il2CppObject* result = o_init_level(instance, item_factory_, config,
        load_bundles_and_create_pools, resources, progress, ct);

    // Build + localize here rather than on first use: by InitLevel time the
    // factory is done, so consumers (ESP labels, item search, category filter)
    // see real names from the first draw instead of a 24-hex id.
    game_items::prewarm(&eft_api::try_get_item_name_for_template_id);

    return result;
}

// Try to place an item into any of an equipment item's grids (backpack/rig/etc.). Returns true on success.
inline bool place_item_in_grids(Il2CppObject* slot_item, Il2CppObject* item) {
    if (!slot_item) return false;
    Il2CppObjectInstance slot_item_instance(slot_item);
    Il2CppArray* grids = slot_item_instance.get_field<Il2CppArray*>("Grids");
    if (!grids) return false;

    for (size_t i = 0; i < grids->max_length; ++i)
    {
        Il2CppObject* grid_obj = reinterpret_cast<Il2CppObject**>(&grids->data)[i];
        if (!grid_obj) continue;
        Il2CppObjectInstance grid(grid_obj);

        Il2CppObject* space = grid.call_or<Il2CppObject*>(
            "FindFreeSpace", 1, nullptr, item);
        if (!space) continue;

        grid.call_or_void<void (*)(Il2CppObject*, Il2CppObject*, Il2CppObject*)>(
            "PlaceItem", 2, item, space);
        return true;
    }
    return false;
}

// Drop an item into the world at `position` through the game's OWN throw path.
// Returns the created LootItem, or nullptr when the game refuses.
//
// `GameWorld.ThrowItem(Item, IPlayer, Vector3 position, Quaternion rotation,
// Vector3 velocity, Vector3 angularVelocity, bool syncable, bool
// performPickUpValidation, float makeVisibleAfterDelay)` builds the loot
// entity, its view and its pickup validation itself -- which is the whole
// reason to use it rather than composing an entity ourselves. An item object
// the game does not know about is exactly what the 2026-10-13 session was
// holding three copies of: GetPresetItem succeeded, placement silently did
// nothing, and the objects were owned by nobody.
//
// Goes through call_or(), the fail-closed checked wrapper: a bare
// get_method<...>("ThrowItem", 9) that fails to resolve is a call through
// address zero, which is the shape that killed this process on 2026-10-04.
inline Il2CppObject* throw_item_in_world(Il2CppObject* game_world, Il2CppObject* player,
    Il2CppObject* item, const unity::vector3& position) {
    if (!game_world || !player || !item) return nullptr;
    Il2CppObjectInstance gw(game_world);
    if (!gw.get_instance()) return nullptr;
    const unity::vector3 zero{0.f, 0.f, 0.f};
    // Identity rotation and no velocity: the item should simply be there, not
    // launched. unity::identity() is namespace-scope in unity.h -- not a member
    // of quaternion -- so it is called unqualified from the unity namespace the
    // file already uses elsewhere.
    return gw.call_or<Il2CppObject*>("ThrowItem", 9, nullptr,
        item, player, position, unity::identity(), zero, zero, true, true, 0.f);
}

// Reusable: create `count` copies of a preset item (Found-in-Raid). Real quest items go into the
// QuestRaidItems container; normal items go into the player's gear (backpack/rig/secure/pockets).
// Returns true if at least one copy was placed. Shared by ItemModule and QuestModule.
inline bool spawn_quest_item(Il2CppObjectInstance main_player, const std::string& template_id, int count = 1) {
    if (!item_factory) return false;
    if (count < 1) count = 1;
    if (count > 25) count = 25;

    Il2CppObjectInstance item_factory_instance(item_factory);
    const auto get_preset = item_factory_instance.get_method<Il2CppObject* (*)(Il2CppObject*, Il2CppString*)>(
        "GetPresetItem", 1);
    // Resolved once, TESTED once: this was a resolve-only site the audit counts
    // separately from the inline call-throughs, but it is the same bug in
    // disguise -- the local is invoked in the loop below with no test between.
    // A miss now returns false instead of calling address 0x0.
    if (!get_preset) return false;

    Il2CppObjectInstance inventory_controller(main_player.get_field<Il2CppObject*>("_inventoryController"));
    Il2CppObjectInstance inventory(
        inventory_controller.call_or<Il2CppObject*>("get_Inventory", 0, nullptr));
    Il2CppObjectInstance equipment(inventory.get_field<Il2CppObject*>("Equipment"));
    Il2CppObjectInstance quest_raid_items(inventory.get_field<Il2CppObject*>("QuestRaidItems"));

    bool any = false;
    for (int c = 0; c < count; ++c)
    {
        Il2CppObject* item = get_preset(item_factory, il2cpp::il2cpp_string_new(template_id.c_str()));
        if (!item) continue;
        Il2CppObjectInstance item_instance(item);

        // is this a real quest item (special) or a normal item?
        bool is_quest = false;
        if (item->klass)
        {
            const MethodInfo* qm = il2utils::resolve_method(item->klass, "get_QuestItem", 0);
            if (qm && qm->methodPointer)
                is_quest = static_cast<bool (*)(Il2CppObject*)>(qm->methodPointer)(item);
        }

        bool placed = false;
        if (is_quest)
        {
            // quest items -> dedicated quest inventory
            Il2CppObjectInstance qgrid(
                quest_raid_items.call_or<Il2CppObject*>("get_Grid", 0, nullptr));
            Il2CppObject* space = qgrid.call_or<Il2CppObject*>(
                "FindFreeSpace", 1, nullptr, item);
            if (space)
            {
                qgrid.call_or_void<void (*)(Il2CppObject*, Il2CppObject*, Il2CppObject*)>(
                    "PlaceItem", 2, item, space);
                placed = true;
            }
        }
        else
        {
            // normal items -> gear: backpack(4), rig(6), secure container(5), pockets(8)
            const int slots[] = {4, 6, 5, 8};
            for (const int s : slots)
            {
                Il2CppObject* slot_obj = equipment.call_or<Il2CppObject*>(
                    "GetSlot", 1, nullptr, s);
                if (!slot_obj) continue;
                Il2CppObjectInstance slot(slot_obj);
                Il2CppObject* contained = slot.call_or<Il2CppObject*>(
                    "get_ContainedItem", 0, nullptr);
                if (!contained) continue;
                if (place_item_in_grids(contained, item))
                {
                    placed = true;
                    break;
                }
            }
        }

        // mark Found-in-Raid so the backend accepts it for quest validation
        item_instance.call_or_void<void (*)(Il2CppObject*, bool)>(
            "set_SpawnedInSession", 1, true);

        if (placed) any = true;
    }
    return any;
}

inline bool no_limit = false;

using mod_can_be_moved_sig = bool* (*)(Il2CppObject*, Il2CppObject*);
inline mod_can_be_moved_sig o_mod_can_be_moved = nullptr;

inline bool* hk_mod_can_be_moved(Il2CppObject* instance, Il2CppObject* container) {
    bool* res = o_mod_can_be_moved(instance, container);
    if (no_limit) *res = true;
    return res;
}

using get_mod_raid_moddable_sig = bool (*)(Il2CppObject*);
inline get_mod_raid_moddable_sig o_get_mod_raid_moddable = nullptr;

inline bool hk_get_mod_raid_moddable(Il2CppObject* instance) {
    if (no_limit) return true;
    return o_get_mod_raid_moddable(instance);
}

// for some reason when using bool this was causing issues, probably missed something obvious
using slot_check_conditions_sig = PVOID (*)(PVOID, PVOID, PVOID, PVOID);

inline slot_check_conditions_sig o_slot_check_conditions = nullptr;

inline PVOID hk_slot_check_conditions(PVOID instance, PVOID item, PVOID ignore_restrictions, PVOID ignore_malfunctions) {
    if (no_limit)
        return o_slot_check_conditions(instance, item, reinterpret_cast<PVOID>(1), reinterpret_cast<PVOID>(1));
    return o_slot_check_conditions(instance, item, ignore_restrictions, ignore_malfunctions);
}

using is_mod_suitable_sig = bool (*)(Il2CppObject*, Il2CppObject*);

inline is_mod_suitable_sig o_is_mod_suitable = nullptr;

inline bool hk_is_mod_suitable(Il2CppObject* instance, Il2CppObject* mod) {
    if (no_limit) return true;
    return o_is_mod_suitable(instance, mod);
}

using is_ammo_compatible_sig = bool (*)(Il2CppObject*, Il2CppArray*);

inline is_ammo_compatible_sig o_is_ammo_compatible = nullptr;

inline bool hk_is_ammo_compatible(Il2CppObject* instance, Il2CppArray* chambers) {
    if (no_limit) return true;
    return o_is_ammo_compatible(instance, chambers);
}

using limited_at_address_sig = bool (*)(Il2CppObject*, Il2CppObject*, Il2CppObject*, int*);

inline limited_at_address_sig o_limited_at_address_inventory = nullptr;

inline bool hk_limited_at_address_inventory(Il2CppObject* instance, Il2CppObject* item, Il2CppObject* address,
    int* limit) {
    if (no_limit) return false;
    return o_limited_at_address_inventory(instance, item, address, limit);
}

inline limited_at_address_sig o_limited_at_address_item = nullptr;

inline bool hk_limited_at_address_item(Il2CppObject* instance, Il2CppObject* item, Il2CppObject* address,
    int* limit) {
    if (no_limit) return false;
    return o_limited_at_address_item(instance, item, address, limit);
}

inline limited_at_address_sig o_limited_at_address_backend = nullptr;

inline bool hk_limited_at_address_backend(Il2CppObject* instance, Il2CppObject* item, Il2CppObject* address,
    int* limit) {
    if (no_limit) return false;
    return o_limited_at_address_backend(instance, item, address, limit);
}

using check_compat_sig = bool (*)(Il2CppObject*, Il2CppObject*);
inline check_compat_sig o_check_compat_stack_slot = nullptr;

inline bool hk_check_compat_stack_slot(Il2CppObject* instance, Il2CppObject* item) {
    if (no_limit) return true;
    return o_check_compat_stack_slot(instance, item);
}

inline check_compat_sig o_check_compat_item_controller = nullptr;

inline bool hk_check_compat_item_controller(Il2CppObject* instance, Il2CppObject* item) {
    if (no_limit) return true;
    return o_check_compat_item_controller(instance, item);
}

inline check_compat_sig o_check_compat_magazine = nullptr;

inline bool hk_check_compat_magazine(Il2CppObject* instance, Il2CppObject* item) {
    if (no_limit) return true;
    return o_check_compat_magazine(instance, item);
}

inline check_compat_sig o_check_compat_virtual_container = nullptr;

inline bool hk_check_compat_virtual_container(Il2CppObject* instance, Il2CppObject* item) {
    if (no_limit) return true;
    return o_check_compat_virtual_container(instance, item);
}

inline check_compat_sig o_check_compat_slot = nullptr;

inline bool hk_check_compat_slot(Il2CppObject* instance, Il2CppObject* item) {
    if (no_limit) return true;
    return o_check_compat_slot(instance, item);
}

inline check_compat_sig o_check_compat_grid = nullptr;

inline bool hk_check_compat_grid(Il2CppObject* instance, Il2CppObject* item) {
    if (no_limit) return true;
    return o_check_compat_grid(instance, item);
}

using check_restrictions_sig = bool (*)(Il2CppObject*, Il2CppObject*, Il2CppObject*);
inline check_restrictions_sig o_check_restrictions = nullptr;

inline bool hk_check_restrictions(Il2CppObject* instance, Il2CppObject* item, Il2CppObject* controller) {
    if (no_limit) return false;
    return o_check_restrictions(instance, item, controller);
}

inline check_restrictions_sig o_check_special_slot = nullptr;

inline bool hk_check_special_slot(Il2CppObject* instance, Il2CppObject* item, Il2CppObject* controller) {
    if (no_limit) return false;
    return o_check_special_slot(instance, item, controller);
}

inline check_restrictions_sig o_check_slot_restrictions = nullptr;

inline bool hk_check_slot_restrictions(Il2CppObject* instance, Il2CppObject* item, Il2CppObject* controller) {
    if (no_limit) return false;
    return o_check_slot_restrictions(instance, item, controller);
}

inline bool big_grid = false;

using get_grid_size_sig = UINT64 (*)(Il2CppObject*, Il2CppString*);
inline get_grid_size_sig o_get_grid_size;

inline UINT64 hk_get_grid_size(Il2CppObject* instance, Il2CppString* profile_id) {
    const UINT64 res = o_get_grid_size(instance, profile_id);

    if (big_grid)
    {
        logger::debug("Changing Transit Grid Size");
        // intvec2(0xA, 0xA)
        return 0xA0000000A;
    }

    return res;
}

using local_raid_ended_sig = Il2CppObject* (*)(Il2CppObject*, Il2CppObject*, Il2CppObject*, Il2CppArray*,
    unity::dict<Il2CppString*, Il2CppArray*>*);
inline local_raid_ended_sig o_local_raid_ended;

inline Il2CppObject* hk_local_raid_ended(Il2CppObject* instance, Il2CppObject* settings, Il2CppObject* results,
    Il2CppArray* lost_insured_items,
    unity::dict<Il2CppString*, Il2CppArray*>* transfer_items) {
    // FIRST, before our own logging and before o_local_raid_ended runs. This is the
    // game's own "the raid is over" call, so it is the earliest point at which we can
    // honestly know the world is going away -- and that is the entire value of an
    // event-driven edge over polling InGameStatus.InRaid once a frame.
    //
    // Why it matters, measured 2026-10-03 22:57:09.841 on build 6AC13F71: the exfil
    // crash. Our "Local Raid Ended" line below is the last thing known to have executed
    // before the process died, so this hook is as early as the flag can be cleared. The
    // polled flag was still TRUE through the teardown, hk_game_world_update kept
    // dispatching, and AimbotModule kept projecting bones through resolve_esp_camera
    // against a world that had already gone (the resolver's own cam-choice dist_mean_m
    // went 1.30 m -> 2.04 m in the final minute, and resolve_esp_camera peaked at 9.0 ms
    // against a 9.8 us mean). An uncaught C++ exception from GameAssembly ended it.
    //
    // Note it also clears the two region memos, via game_state::set_in_raid. That is
    // deliberate and not a side effect to be minimised: those caches hold VirtualQuery
    // regions verified against the objects THIS raid owned, and after this point the game
    // is reusing that memory. Left un-cleared they answer "readable" for a different
    // object, which is harder to diagnose than a crash.
    game_state::on_local_raid_ended_event();

    logger::debug("Local Raid Ended");
    logger::debug("Insured Items: " + std::to_string(lost_insured_items->max_length));
    logger::debug("Transfer Items: " + std::to_string(transfer_items->m_i_count));

    // Exfil/raid end complete — disarm the transit guard so subsequent menu-initiated
    // transits (Transit -> Exfil -> Infil) aren't blocked by a stale load window.
    always_on::raid_start_guard_disarm("hk_local_raid_ended");

    // Print out json for transited items
    /*
    for (int i = 0; i < transfer_items->m_i_count; ++i)
    {
        logger::debug("  " + il2utils::conv_string(transfer_items->get_key_by_index(i)));
        logger::debug("  " + std::to_string(transfer_items->get_value_by_index(i)->max_length));
        for (size_t j = 0; j < transfer_items->get_value_by_index(i)->max_length; ++j)
        {
            Il2CppObjectInstance flat_item(
                reinterpret_cast<Il2CppObject**>(&transfer_items->get_value_by_index(i)->data)[j]);
            const auto unparsed_data_ptr = flat_item.get_field<Il2CppObject*>("upd");
            if (!unparsed_data_ptr) continue;
            Il2CppObjectInstance unparsed_data(unparsed_data_ptr);
            const auto jtoken_ptr = unparsed_data.get_field<Il2CppObject*>("JToken");
            if (!jtoken_ptr) continue;
            Il2CppObjectInstance jtoken(jtoken_ptr);
            logger::debug("      " + il2utils::conv_string(
                jtoken.get_method<Il2CppString*(*)(Il2CppObject*)>("ToString", 0)(jtoken.get_instance())));
        }
    }
    */

    return o_local_raid_ended(instance, settings, results, lost_insured_items, transfer_items);
}

class ItemModule : public Module
{
  public:
    ItemModule();


    // Search items by name (FR/EN) with autocomplete; clicking a result fills item_id.
    // Spawn path: quest items are hidden (the Quest Completer spawns those itself).
    ItemSearchValue* item_search;
    TextboxValue* item_id;
    // Where a created item goes: the equipment slots below, at the player's
    // feet, or in front of them. 0/1/2, matching drop_inv_sel / drop_feet_sel /
    // drop_cross_sel. The default is the equipment slot, which is what this
    // card did before the world-drop existed.
    SelectValue* item_drop_mode;
    SelectValue* item_slot;
    CheckboxValue* override_max_amount;
    IntTextboxValue* amount;
    CheckboxValue* fir;
    CheckboxValue* replace_slot;

    // 2 buttons per row (window is too narrow for a single line of 5).
    ActionRowValue* create_item;       // row 1 col 1
    ActionRowValue* create_quest_item; // row 1 col 2
    ActionRowValue* transit_item;      // row 2 col 1
    // Mark existing inventory items as Found-in-Raid (SpawnedInSession).
    ActionRowValue* mark_backpack_fir; // row 2 col 2
    ActionRowValue* mark_all_gear_fir; // row 3 col 1

    CheckboxValue* no_slot_limits;

    CheckboxValue* increased_transfer_size;

    bool queue_create_item = false;
    bool queue_create_quest_item = false;
    bool queue_transit_item = false;
    bool queue_mark_backpack_fir = false;
    bool queue_mark_all_gear_fir = false;
    // 0 = into the equipment slots, 1 = at the player's feet, 2 = in front of
    // them. Captured from item_drop_mode at button time (see
    // create_item_impl) and consumed in gameworld_update. Only meaningful when
    // queue_create_item is set.
    int queue_drop_mode = 0;

    void sync_item_controls_lock();

    void create_item_impl();

    void create_quest_item_impl();

    void transit_item_impl();

    void mark_backpack_fir_impl();

    void mark_all_gear_fir_impl();

    // Item.SpawnedInSession / set_SpawnedInSession (FiR flag in EFT).
    static int set_item_fir(Il2CppObject* item, const bool value = true);

    // Mark root container + every nested item (grids/slots) as FiR.
    static int mark_container_tree_fir(Il2CppObject* root);

    // EquipmentSlot: Backpack=4, Secure=5, TacticalVest=6, Pockets=8 (same as spawn_quest_item).
    static int mark_equipment_slots_fir(Il2CppObjectInstance& equipment, const int* slots, const int slot_count);

    void draw_overlay(ImDrawList* draw_list) override;

    void application_update() override;

    static void exec_transit_item(Il2CppObjectInstance game_world_instance, Il2CppObjectInstance main_player,
        Il2CppObject* item);

    void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
        Il2CppObjectInstance main_player) override;

    void init() override;
};
