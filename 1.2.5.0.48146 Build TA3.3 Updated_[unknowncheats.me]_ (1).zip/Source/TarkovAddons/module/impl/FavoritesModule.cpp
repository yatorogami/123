#include "common.h"
#include "FavoritesModule.h"

FavoritesModule::FavoritesModule() : Module("Favorites", RaidDashboard, "favorites_mod") {}

void FavoritesModule::draw_overlay(ImDrawList*) {}

void FavoritesModule::application_update() {}

void FavoritesModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) {}

void FavoritesModule::init() {}

void FavoritesModule::draw_menu_extra() {
    int favorite_count = 0;
    for (CheckboxValue* toggle : CheckboxValue::all_toggles())
    {
        if (!toggle || !toggle->is_favorite())
            continue;
        ++favorite_count;
        toggle->draw_favorite();
    }

    if (favorite_count == 0)
        imgui_addons::status_line("Click the star beside any feature to add it here.");
}
