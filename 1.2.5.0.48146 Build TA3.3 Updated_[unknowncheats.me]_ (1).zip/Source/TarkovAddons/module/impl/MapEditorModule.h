#pragma once

#include "../Module.h"
#include "../ModuleCategory.h"
#include "../../config/ActionRowValue.h"
#include "../../config/CheckboxValue.h"
#include "../../config/FloatSliderEditableValue.h"
#include "../../config/MenuSectionValue.h"
#include "../../config/SelectValue.h"
#include "../../gui/menu/imgui_addons.h"
#include "../../module/minimap.h"
#include "../game_state.h"
#include "../../util/i18n.h"
#include "../../util/logger.h"

class MapEditorModule : public Module
{
  public:
    MapEditorModule();

    CheckboxValue* enable_editor;
    CheckboxValue* minimap_calibrate;
    ActionRowValue* export_exfil_coords;
    CheckboxValue* show_zone_outlines;
    CheckboxValue* show_abstract_overlay;
    FloatSliderEditableValue* abstract_overlay_opacity;
    SelectValue* preview_style;
    MenuSectionValue* section_actions_;
    ActionRowValue* apply_btn_;
    ActionRowValue* reload_configs_btn_;
    ActionRowValue* reload_btn_;
    ActionRowValue* save_btn_;

    void draw_overlay(ImDrawList* draw_list) override;

    void application_update() override;

    void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
        Il2CppObjectInstance main_player) override;

    void init() override;

    void prepare_menu_draw() override;

    void draw_menu_extra() override;

  private:
    static bool draw_cal_field(const char* label, float* value, const bool disabled);

    static bool draw_cal_int_field(const char* label, int* value, const bool disabled);

    static void draw_calibration_block(const char* title_key, minimap::map_style_calibration& cal,
        const bool disabled, const bool satellite_fields = false);

    static void draw_overlay_block(minimap::map_editor_state& editor, const bool disabled);
};