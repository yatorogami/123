#include "common.h"
#include "ExperienceEditorModule.h"

ExperienceEditorModule::ExperienceEditorModule(PlayerModule* player) : Module("Experience Editor", ProfileEditor, "experience_editor_mod"), player_(player) {
    if (player_)
        values_ = {player_->exp_type, player_->exp_amount, player_->add_exp,
            player_->skill_select, player_->skill_level, player_->set_skill};
}

void ExperienceEditorModule::draw_overlay(ImDrawList*) {}

void ExperienceEditorModule::application_update() {}

void ExperienceEditorModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) {}

void ExperienceEditorModule::init() {}

[[nodiscard]] bool ExperienceEditorModule::draw_menu_extra_before_values() const { return true; }

void ExperienceEditorModule::draw_menu_extra() {
    for (ConfigValue* value : values_)
        if (value) value->draw();
}
