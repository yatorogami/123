#include "common.h"
#include "HideoutAutomationModule.h"

// The three defaults below, hideout_rebuild_freely_flag()'s static in hideout_reflection.h, and
// the current-value slot in ta/configs/legit_sel are THREE separate sources of the same default,
// and they have to agree or the feature runs in a state nobody chose.
//
// They are all false/true/false-for-freely on purpose: freely defaults to FALSE, so coalescing is
// ON by default. The knob's LABEL still describes the ticked state ("refresh every station view on
// each change"), which is why unticking it is the fast path - see the polarity note in
// hideout_reflection.h. The label is not being changed here because it lives in 19 locale files
// owned by another workstream; that is a separate change, not a default fix.
HideoutAutomationModule::HideoutAutomationModule() : Module("Hideout Improvements", ProfileEditor, "hideout_improvements_mod"),
                                                     reload_recipes(conf(new CheckboxValue(true, "hideout_reload_recipes_cb"))),
                                                     rebuild_freely(conf(new CheckboxValue(false, "hideout_rebuild_freely_cb"))),
                                                     stick_station(conf(new CheckboxValue(true, "hideout_stick_station_cb"))),
                                                     qte_always_success(conf(new CheckboxValue(false, "hideout_qte_always_success_cb"))) {
}

void HideoutAutomationModule::prepare_menu_draw() {
    reload_recipes->set_hidden_in_owner_menu(true);
    rebuild_freely->set_hidden_in_owner_menu(true);
    stick_station->set_hidden_in_owner_menu(true);
    qte_always_success->set_hidden_in_owner_menu(true);
}

void HideoutAutomationModule::draw_menu_extra() {
    // get_value(), not get(): ConfigValue::get() is the config-SERIALISATION accessor and
    // returns std::string, so passing it to a bool parameter does not compile.
    hideout_set_recipe_reload(reload_recipes->get_value());
    hideout_set_rebuild_freely(rebuild_freely->get_value());
    hideout_set_stick_station(stick_station->get_value());
    hideout_set_qte_always_success(qte_always_success->get_value());

    reload_recipes->draw();
    rebuild_freely->draw();
    stick_station->draw();
    qte_always_success->draw();

    // A readout, not a control. It answers the question the knob raises — "is the list
    // actually loaded, and is it pinned?" — which is otherwise invisible, and a list that
    // silently failed to load looks exactly like a list with nothing in it.
    std::string status;
    const size_t loaded = hideout_recipe_count();
    if (loaded == 0)
    {
        status = i18n::tr("hideout_recipes_none");
    }
    else
    {
        status = i18n::tr("hideout_recipes_loaded") + " " + std::to_string(loaded);
        if (!hideout_recipe_reload())
            status += "  \xC2\xB7  " + i18n::tr("hideout_recipes_pinned");
    }
    if (!status.empty())
        imgui_addons::status_line(status, true);
}

void HideoutAutomationModule::init() {
    // One hook, installed once, at startup. The class is a plain type in the assembly rather than
    // something the hideout instantiates on open, so there is no "is the hideout live yet" edge to
    // wait for -- and hooking late would leave the first QTE of a session unhooked.
    //
    // No TA_ZONE here: this runs once, and the hook BODY below is a predictable branch on a bool
    // during a minigame's frames. A per-frame zone costing nanoseconds is noise in the flame graph,
    // which is the thing the zones exist to avoid (see zone_gap.py, which ranks by SIZE -- the
    // measurement to make first, but not worth a zone on a two-branch detour).
    const Il2CppImage* image = il2utils::resolve_image("Assembly-CSharp.dll");
    if (!image) {
        logger::warn("hideout QTE: Assembly-CSharp.dll not resolved; QTE override unavailable");
        return;
    }
    const Il2CppClass* qte = il2utils::resolve_class(image, "EFT.Hideout", "ShrinkingCircleQTE");
    if (!qte) {
        // Loud, because this is the silent-failure shape: the toggle would still draw, still save,
        // and change nothing. hook_method warns for a missing METHOD; this is the missing CLASS.
        logger::warn("hideout QTE: EFT.Hideout.ShrinkingCircleQTE not found; "
            "the QTE toggle will do nothing this session");
        return;
    }
    il2utils::hook_method(qte, "IsSuccessInput", 0, hk_qte_is_success_input,
        &o_qte_is_success_input);
    logger::info(std::string("hideout QTE: hooked ") + (qte->name ? qte->name : "(unnamed)")
        + "::IsSuccessInput; toggle 'hideout_qte_always_success_cb' now has something to talk to");
}

void HideoutAutomationModule::application_update() {}

void HideoutAutomationModule::application_update(Il2CppObject*) {}

void HideoutAutomationModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) {}

void HideoutAutomationModule::draw_overlay(ImDrawList*) {}
