#include "common.h"
#include "AmmoHudModule.h"

AmmoHudModule::AmmoHudModule() : Module("Ammo HUD", Visuals, "ammo_hud_mod"),
                                 enabled(conf(new CheckboxValue(false, "enabled_cb"))),
                                 color(conf(new ColorpickerValue({0.95f, 0.92f, 0.82f, 1.f}, "color_clr"))),
                                 font_size(conf(new IntSliderEditableValue(18, 8, 36, "font_size_itm"))),
                                 section_layout_(conf(new MenuSectionValue("layout_sec"))),
                                 pos_x(conf(new FloatSliderEditableValue(80.f, 0.f, 3840.f, "ammo_hud_pos_x_itm"))),
                                 pos_y(conf(new FloatSliderEditableValue(820.f, 0.f, 2160.f, "ammo_hud_pos_y_itm"))) {
    hidden_in_category_menu = true;
}

void AmmoHudModule::init() {
    enabled->set_master_toggle(true);
}

void AmmoHudModule::prepare_menu_draw() {
    const auto dis = [](ConfigValue* v, const bool disabled) { v->set_disabled(disabled); };
    const bool on = enabled->get_value();

    section_layout_->set_section_active(on);
    dis(color, !on);
    dis(font_size, !on);
    dis(pos_x, !on);
    dis(pos_y, !on);

    for (ConfigValue* value : config_values)
        value->set_disabled(true);
}

void AmmoHudModule::draw_menu_extra() {
    if (!enabled->get_value()) return;

    const float sf = menu::get_scale_factor();
    ImGui::Dummy(ImVec2(0, 2.f * sf));
    ImGui::TextColored(menu::palette::muted, "%s", i18n::tr("ammo_hud_drag_inf").c_str());
}

void AmmoHudModule::draw_overlay(ImDrawList* draw_list) {
    if (!game_state::is_in_raid || !enabled->get_value() || !cached_.active) return;

    const float sf = menu::get_scale_factor();
    const float font_px = static_cast<float>(font_size->get_value()) * sf;
    // The ammo block is the one place in the overlay that draws PURE
    // numbers ("12 / 60", a weapon code), which is what a mono face is
    // for: tabular figures stop the block jittering as the count changes,
    // and the weapon code reads as data rather than as prose. Falls back
    // to the HUD face when the resource is unreadable, never to nothing.
    ImFont* font = menu::get_hud_mono_font();
    if (!font) font = menu::get_hud_font();
    const ImU32 color_u32 = ImGui::GetColorU32(color->get_value());

    // Cache the formatted strings and only update when values change.
    // Avoids 4 heap allocations per frame (2 to_string + 2 concatenations).
    static std::string mag_line;
    static std::string chamber_line;
    static int last_mag_count = -1;
    static int last_mag_max = -1;
    static int last_chamber_count = -1;
    static std::string last_chamber_name;

    if (cached_.mag_count != last_mag_count || cached_.mag_max != last_mag_max)
    {
        last_mag_count = cached_.mag_count;
        last_mag_max = cached_.mag_max;
        mag_line = std::to_string(cached_.mag_count) + " / " + std::to_string(cached_.mag_max);
    }

    if (cached_.chamber_count != last_chamber_count || cached_.chamber_name != last_chamber_name)
    {
        last_chamber_count = cached_.chamber_count;
        last_chamber_name = cached_.chamber_name;
        chamber_line = cached_.chamber_count > 0 && !cached_.chamber_name.empty()
            ? cached_.chamber_name
            : i18n::tr("ammo_hud_empty_lbl");
    }

    float x = pos_x->get_value();
    float y = pos_y->get_value();

    if (menu::is_active())
    {
        const ImVec2 drag_min(x, y);
        const ImVec2 drag_max(x + font_px * 8.f, y + font_px * 2.4f);
        const ImU32 border_col = (color_u32 & 0x00FFFFFFu) | (static_cast<ImU32>(0.35f * 255.f) << 24);
        draw_list->AddRect(drag_min, drag_max, border_col, 2.f * sf, 0, 1.5f * sf);

        const ImVec2 mouse = ImGui::GetIO().MousePos;
        if (ImGui::IsMouseDown(ImGuiMouseButton_Left)
            && mouse.x >= drag_min.x && mouse.x <= drag_max.x
            && mouse.y >= drag_min.y && mouse.y <= drag_max.y)
        {
            const ImVec2 delta = ImGui::GetIO().MouseDelta;
            pos_x->set_value(x + delta.x);
            pos_y->set_value(y + delta.y);
        }
        return;
    }

    ImVec2 pos(x, y);
    draw_list->AddText(font, font_px, pos, color_u32, mag_line.c_str());
    pos.y += font_px + 2.f * sf;
    draw_list->AddText(font, font_px, pos, color_u32, chamber_line.c_str());
}

void AmmoHudModule::application_update() {
    TA_ZONE_N("ammo_hud::application_update");
    // Retain the module but keep its overlay disabled.
    enabled->set_value(false);
    if (!game_state::is_in_raid)
        cached_ = {};
}

void AmmoHudModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance,
    Il2CppObjectInstance main_player) {
    TA_ZONE_N("ammo_hud::gameworld_update");
    if (!enabled->get_value())
    {
        cached_ = {};
        return;
    }

    bool hands_not_firearm = false;
    eft_api::weapon_ammo_state fresh{};
    if (eft_api::try_read_weapon_ammo(main_player.get_instance(), fresh, &hands_not_firearm))
    {
        cached_ = fresh;
        return;
    }

    if (hands_not_firearm)
        cached_ = {};
}
