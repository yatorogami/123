#include "common.h"
#include "ConfigModule.h"

#include "../../gui/menu/card_fold_state.h"

ConfigModule::ConfigModule(const std::vector<Module*>& m) : Module("Configs", RaidDashboard, "configs_mod"),
                                                            config(conf(new SelectValue(0, {"legit_sel", "rage_sel", "config_1_sel", "config_2_sel", "config_3_sel", "config_4_sel", "config_5_sel"}, "config_file_sel"))),
                                                            load(conf(new ActionRowValue([&] {
                                                                load_config(config->get_selected());
                                                            },
                                                                "load_btn"))),
                                                            save(conf(new ActionRowValue([&] {
                                                                save_config(config->get_selected());
                                                            },
                                                                "save_btn", true))),
                                                            reset_defaults(conf(new ActionRowValue([&] {
                                                                reset_all_to_defaults();
                                                            },
                                                                "reset_defaults_btn", true))),
                                                            section_language_(conf(new MenuSectionValue("menu_language_sec_hdr"))), menu_language_(conf(new LanguageSelectValue(0, "menu_language_sec"))), section_text_size_(conf(new MenuSectionValue("on_screen_text_size_sec"))), esp_text_font_size(conf(new IntSliderEditableValue(12, 8, 36, "esp_text_size_itm"))), quest_esp_font_size(conf(new IntSliderEditableValue(12, 8, 36, "quest_esp_text_size_itm"))), section_esp_text_(conf(new MenuSectionValue("esp_text_readability_sec"))), esp_text_outline(conf(new CheckboxValue(false, "text_outline_cb"))), esp_text_background(conf(new CheckboxValue(false, "text_background_cb"))), esp_text_clustering(conf(new CheckboxValue(false, "label_clustering_cb"))), esp_text_depth_sort(conf(new CheckboxValue(false, "depth_text_sort_cb"))), section_esp_update_(conf(new MenuSectionValue("esp_update_sec"))), loot_update_rate(conf(new FloatSliderEditableValue(1.f, 0.05f, 4.f, "loot_update_rate_itm"))), container_update_rate(conf(new FloatSliderEditableValue(1.f, 0.05f, 4.f, "container_update_rate_itm"))), quest_update_rate(conf(new FloatSliderEditableValue(1.f, 0.05f, 4.f, "quest_update_rate_itm"))), esp_manual_refresh(conf(new CheckboxValue(false, "esp_manual_refresh_cb"))), esp_refresh_now(conf(new ActionRowValue([&] {
                                                                game_state::esp_manual_refresh_request = true;
                                                            },
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "esp_refresh_now_btn"))),
                                                            section_market_prices_(conf(new MenuSectionValue("market_prices_sec"))), update_market_prices(conf(new ActionRowValue([&] {
                                                                item_pricing::refresh_async();
                                                            },
                                                                                                                                         "update_prices_btn"))),
                                                            market_prices_info_(conf(new InfoDrawValue([this] {
                                                                draw_market_prices_info();
                                                            }))),
                                                            section_cache_(conf(new MenuSectionValue("cache_sec"))), clear_cache(conf(new ActionRowValue([&] {
                                                                clear_all_caches();
                                                            },
                                                                                                                         "clear_cache_btn", true))),
                                                            cache_info_(conf(new InfoDrawValue([this] {
                                                                draw_cache_info();
                                                            }))) {
    modules = m;
    config_module_self = this;
    /*ConfigValue* hidden_config_values[] = {
            section_text_size_, esp_text_font_size, quest_esp_font_size,
            section_esp_text_, esp_text_outline, esp_text_background,
            esp_text_clustering, esp_text_depth_sort, section_esp_update_,
            loot_update_rate, container_update_rate, quest_update_rate,
        };
        for (ConfigValue* value : hidden_config_values)
            value->set_hidden_in_owner_menu(true);
        update_market_prices->set_hidden_in_owner_menu(true);*/
}

void ConfigModule::for_each_module(const std::function<void(Module*)>& fn) {
    for (auto* module : modules)
        fn(module);
    if (config_module_self)
        fn(config_module_self);
}

std::string ConfigModule::format_bytes(const size_t bytes) {
    if (bytes < 1024)
        return std::to_string(bytes) + " B";
    if (bytes < 1024 * 1024)
    {
        char buf[32];
        snprintf(buf, sizeof(buf), "%.1f KB", static_cast<double>(bytes) / 1024.0);
        return buf;
    }
    char buf[32];
    snprintf(buf, sizeof(buf), "%.2f MB", static_cast<double>(bytes) / (1024.0 * 1024.0));
    return buf;
}

void ConfigModule::clear_all_caches() {
    if (item_pricing::is_updating()) return;

    item_pricing::clear_cache();
    for_each_module([](Module* module) {
        module->clear_runtime_cache();
    });

    logger::debug("All caches cleared");
}

void ConfigModule::reset_all_to_defaults() {
    for_each_module([](Module* module) {
        module->apply([](ConfigValue* c) {
            c->set(c->get_default());
            c->set_favorite(false);
        });
    });

    for (auto& binding : hotkeys::all())
    {
        if (binding.id == "exploit.fly_up")
            hotkeys::binding_key(binding) = VK_SPACE;
        else if (binding.id == "exploit.fly_down")
            hotkeys::binding_key(binding) = VK_CONTROL;
        else
            hotkeys::binding_key(binding) = 0;
    }
    // Defaults mean every card open, so Reset has to clear the fold state as
    // well -- otherwise this is the one button in the app that leaves the menu
    // looking unlike the rest of the config it just reset.
    card_fold::clear();
    for_each_module([](Module* module) {
        if (module->name != "Watermark") return;
        module->apply([](ConfigValue* c) {
            if (c->get_config_key().find("text_txt") != std::string::npos)
                c->set(globals::get_display_title());
        });
    });
}

void ConfigModule::init_menu_language_options() {
    if (menu_language_initialized_)
        return;

    menu_language_->rebuild_labels();
    menu_language_->set_value(i18n::locale_to_index(i18n::current_locale()));
    sync_menu_language_settings();
    menu_language_initialized_ = true;
}

void ConfigModule::sync_menu_language_settings() {
    i18n::set_locale(i18n::index_to_locale(menu_language_->get_value()));
}

void ConfigModule::prepare_menu_draw() {
    const bool busy = item_pricing::is_updating();
    update_market_prices->set_disabled(busy);
    clear_cache->set_disabled(busy);
    reset_defaults->set_disabled(busy);

    const bool manual = esp_manual_refresh->get_value();
    loot_update_rate->set_disabled(manual);
    container_update_rate->set_disabled(manual);
    quest_update_rate->set_disabled(manual);
    // Manual refresh button always usable (also works as one-shot when auto is on).
    esp_refresh_now->set_disabled(false);
}

void ConfigModule::draw_market_prices_info() {
    ImGui::Dummy(ImVec2(0, 4.f));

    if (item_pricing::is_updating())
    {
        ImGui::TextColored(menu::palette::accent2, "%s", i18n::tr("updating_prices_inf").c_str());
        return;
    }

    const std::string source_path = item_pricing::get_active_file_path();
    if (!source_path.empty())
        ImGui::TextWrapped("%s\n%s", i18n::tr("source_file_inf").c_str(), source_path.c_str());
    else
        ImGui::TextWrapped("%s", i18n::tr("source_file_not_loaded_inf").c_str());

    const size_t price_count = item_pricing::get_price_count();
    if (price_count > 0)
        ImGui::Text("%s %zu %s", i18n::tr("loaded_inf").c_str(), price_count, i18n::tr("prices_inf").c_str());

    const std::string file_mtime = item_pricing::get_active_file_mtime_string();
    if (!file_mtime.empty())
        ImGui::Text("%s %s", i18n::tr("file_updated_inf").c_str(), file_mtime.c_str());

    const std::string status = item_pricing::get_status_message();
    if (!status.empty())
        ImGui::TextWrapped("%s", status.c_str());
}

void ConfigModule::draw_cache_info() {
    ImGui::Dummy(ImVec2(0, 4.f));

    size_t total_entries = 0;
    size_t total_bytes = 0;

    for_each_module([&](Module* module) {
        if (module == config_module_self) return;

        const size_t entries = module->get_runtime_cache_count();
        const size_t bytes = module->get_runtime_cache_bytes();
        if (entries == 0 && bytes == 0) return;

        total_entries += entries;
        total_bytes += bytes;
        ImGui::Text("%s: %zu %s (~%s)",
            i18n::tr(module->get_display_key()).c_str(), entries,
            i18n::tr("entries_inf").c_str(), format_bytes(bytes).c_str());
    });

    if (item_pricing::is_loaded())
    {
        const size_t price_entries = item_pricing::get_price_count();
        const size_t price_bytes = item_pricing::get_cache_bytes();
        total_entries += price_entries;
        total_bytes += price_bytes;
        ImGui::Text("%s: %zu %s (~%s)",
            i18n::tr("price_table_inf").c_str(), price_entries,
            i18n::tr("entries_inf").c_str(), format_bytes(price_bytes).c_str());
    }

    ImGui::Dummy(ImVec2(0, 2.f));
    ImGui::Text("%s %zu %s, ~%s",
        i18n::tr("total_inf").c_str(), total_entries, i18n::tr("entries_inf").c_str(),
        format_bytes(total_bytes).c_str());
}

void ConfigModule::draw_overlay(ImDrawList* draw_list) {
}

void ConfigModule::application_update() {
    TA_ZONE_N("config::application_update");
    static int last_language = 0;
    const int language = menu_language_->get_value();
    if (language != last_language)
    {
        sync_menu_language_settings();
        last_language = language;
    }

    // Publish ESP scan rates for EspModule (same frame as hotkey tick).
    game_state::esp_loot_update_rate = loot_update_rate->get_value();
    game_state::esp_container_update_rate = container_update_rate->get_value();
    game_state::esp_quest_update_rate = quest_update_rate->get_value();
    game_state::esp_manual_refresh_mode = esp_manual_refresh->get_value();

    hotkeys::tick();
}

void ConfigModule::gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
    Il2CppObjectInstance main_player) {
}

void ConfigModule::init() {
    i18n::init();
    esp_text::config_module = this;
    load_config(config->get_selected());
}

std::filesystem::path ConfigModule::config_path(const std::string& config) {
    return module_paths::ensure_config_directory_wide() / module_paths::path_from_utf8(config);
}

std::filesystem::path ConfigModule::previous_config_path(const std::string& config) {
    const std::filesystem::path data_dir = module_paths::data_directory_wide();
    if (data_dir.empty())
        return {};
    return data_dir / module_paths::path_from_utf8(config);
}

std::filesystem::path ConfigModule::legacy_config_path(const std::string& config) {
    const std::string legacy_dir = item_pricing::get_legacy_appdata_directory();
    if (legacy_dir.empty())
        return {};

    return std::filesystem::path(item_pricing::to_absolute_path(
        item_pricing::join_path(legacy_dir, config)));
}

void ConfigModule::load_config(const std::string& config) {
    logger::debug("Loading Config " + config);

    // The config is looked for in three places, in order, and only then
    // created from defaults:
    //
    //   1. ta/configs/<config>   -- where it lives now
    //   2. ta/<config>           -- the 3.2 layout, still read so that a
    //                               failed or skipped migration cannot
    //                               present as "no config found"
    //   3. %APPDATA%\TarkovAddons\<config> -- pre-3.2
    //
    // Steps 2 and 3 both exist so that an install which has settings never
    // silently starts up on defaults. create_config() is only reached when
    // all three genuinely come up empty, which is the one case where
    // starting from defaults is correct.
    const std::filesystem::path path = config_path(config);
    std::ifstream t(path);

    if (!t.good())
    {
        if (const std::filesystem::path previous = previous_config_path(config);
            !previous.empty() && previous != path && std::filesystem::exists(previous))
        {
            logger::info("Config '" + config + "' found at the 3.2 location " + previous.string()
                + "; it still loads from there. To move it into " + path.string()
                + ", re-run: python tools/deploy.py install");
            t.open(previous);
        }
    }

    if (!t.good())
    {
        if (const std::filesystem::path legacy = legacy_config_path(config);
            !legacy.empty() && std::filesystem::exists(legacy))
        {
            logger::info("Config '" + config + "' found at the legacy location " + legacy.string()
                + "; it still loads from there. To move it into " + path.string()
                + ", re-run: python tools/deploy.py install");
            t.open(legacy);
        }
    }

    if (!t.good())
    {
        t = create_config(config);
    }

    std::stringstream buffer;
    buffer << t.rdbuf();
    t.close();

    // map keys to values
    auto res = utils::split(buffer.str(), ';');
    auto values = std::unordered_map<std::string, std::string>();
    // The record is 4 fields wide (key, value, favorite-key, favorite), so
    // stepping by 2 pairs the value keys and the favorite keys up together.
    // That only works because the width is exactly 4; bound the second index
    // so a hand-edited or truncated config cannot throw out_of_range.
    for (size_t i = 0; i + 1 < res.size(); i += 2)
    {
        values[res[i]] = res[i + 1];
    }

    for_each_module([&values](Module* module) {
        logger::debug(std::format("Applying Config for module {}", module->name));
        module->apply([&values](ConfigValue* c) {
            // A value that throws on a malformed field must not abandon the
            // rest of the file. load_config() runs inside dllmain's startup
            // with no handler above it, so an escaping exception leaves
            // every later value at its default and skips the hotkey restore
            // -- which reads as "the config did not load" rather than as
            // "one setting was bad". Contain it here and carry on.
            try
            {
                const auto iter = values.find(c->get_config_key());
                if (iter == values.end())
                    c->set(c->get_default());
                else
                    c->set(iter->second);

                const auto favorite = values.find(c->get_favorite_config_key());
                c->set_favorite(favorite != values.end() && favorite->second == "true");
            } catch (const std::exception& ex)
            {
                logger::warn("config: '" + c->get_config_key()
                    + "' rejected its stored value (" + ex.what()
                    + "); keeping the default for this setting only");
                c->set_favorite(false);
            }
        });
    });

    // Restore hotkeys from this config file. Do not wipe — users expect Load to
    // apply saved binds (only Reset Defaults clears them to fly-up/down only).
    hotkeys::load(values);
    // Card fold state comes from the same file under card_fold's own "CARD:"
    // prefix. Unlike hotkeys above this one REPLACES: a folded card has no
    // meaningful default to keep, so "folded in the previous config, absent
    // from this one" has to resolve to open.
    card_fold::load(values);
    // Always show current product version on watermark after load.
    for_each_module([](Module* module) {
        if (module->name != "Watermark") return;
        module->apply([](ConfigValue* c) {
            if (c->get_config_key().find("text_txt") != std::string::npos)
                c->set(globals::get_display_title());
        });
    });
}

void ConfigModule::save_config(const std::string& config) {
    logger::debug("Saving Config " + config);

    // create config string
    std::string value;
    for_each_module([&value](Module* module) {
        module->apply([&value](ConfigValue* c) {
            value.append(c->get_config_key());
            value.append(";");
            value.append(c->get());
            value.append(";");
            value.append(c->get_favorite_config_key());
            value.append(";");
            value.append(c->is_favorite() ? "true" : "false");
            value.append(";");
        });
    });

    hotkeys::append_save(value);
    // Nothing here for create_config() below: a brand-new config has no folded
    // cards, and open is the state an absent record already means.
    card_fold::append_save(value);

    // write file
    std::ofstream t(config_path(config));
    t.write(value.c_str(), static_cast<std::streamsize>(value.size()));
    t.close();
}

std::ifstream ConfigModule::create_config(const std::string& config) {
    std::string value;
    for_each_module([&value](Module* module) {
        module->apply([&value](ConfigValue* c) {
            value.append(c->get_config_key());
            value.append(";");
            value.append(c->get_default());
            value.append(";");
            value.append(c->get_favorite_config_key());
            value.append(";");
            value.append("false;");
        });
    });

    hotkeys::append_defaults(value);

    // write file
    const std::filesystem::path path = config_path(config);

    std::ofstream ot(path);
    ot.write(value.c_str(), static_cast<std::streamsize>(value.size()));
    ot.close();

    return std::ifstream(path);
}
