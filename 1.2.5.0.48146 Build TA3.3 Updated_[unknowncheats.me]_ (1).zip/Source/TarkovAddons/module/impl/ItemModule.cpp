#include "common.h"
#include "ItemModule.h"

ItemModule::ItemModule() : Module("Item Spawner", ItemSpawnerEditor, "item_spawner_mod"),
                           item_search(conf(new ItemSearchValue("search_item_txt", [this](const std::string& id) { item_id->set(id); }, /*hide_quest_items=*/true))), item_id(conf(new TextboxValue("", "item_id_txt"))), item_drop_mode(conf(new SelectValue(0, {"drop_inv_sel", "drop_feet_sel", "drop_cross_sel"}, "drop_mode_sel"))), item_slot(conf(new SelectValue(4, {"primary_weapon_sel", "secondary_weapon_sel", "holster_sel", "melee_sel", "backpack_sel", "secure_container_sel", "rig_sel", "armor_sel", "pockets_sel", "eyewear_sel", "face_cover_sel", "headwear_sel", "earpiece_sel", "dog_tag_sel", "armband_sel"}, "item_slot_sel"))), override_max_amount(conf(new CheckboxValue(false, "override_max_amount_cb"))), amount(conf(new IntTextboxValue(1, "item_amount_txt"))), fir(conf(new CheckboxValue(true, "found_in_raid_cb"))), replace_slot(conf(new CheckboxValue(false, "replace_slot_cb"))), create_item(conf(new ActionRowValue([&] { create_item_impl(); }, "create_item_btn"))), create_quest_item(conf(new ActionRowValue([&] { create_quest_item_impl(); }, "create_quest_item_btn", true))), transit_item(conf(new ActionRowValue([&] { transit_item_impl(); }, "transit_item_btn"))), mark_backpack_fir(conf(new ActionRowValue([&] { mark_backpack_fir_impl(); }, "mark_backpack_fir_btn", true))), mark_all_gear_fir(conf(new ActionRowValue([&] { mark_all_gear_fir_impl(); }, "mark_all_gear_fir_btn"))), no_slot_limits(conf(new CheckboxValue(false, "no_slot_limits_cb"))), increased_transfer_size(conf(new CheckboxValue(false, "increased_transfer_size_cb"))) {
    create_quest_item->set_hidden_in_owner_menu(true);
    transit_item->set_hidden_in_owner_menu(true);
    mark_backpack_fir->set_hidden_in_owner_menu(true);
}

void ItemModule::sync_item_controls_lock() {
    constexpr bool unlocked = true;
    const auto dis = [](ConfigValue* v, const bool disabled) { v->set_disabled(disabled); };
    dis(item_search, !unlocked);
    dis(item_id, !unlocked);
    dis(item_drop_mode, !unlocked);
    dis(item_slot, !unlocked);
    dis(override_max_amount, !unlocked);
    dis(amount, !unlocked);
    dis(fir, !unlocked);
    dis(replace_slot, !unlocked);
    create_item->set_disabled(!unlocked);
    create_quest_item->set_disabled(!unlocked);
    transit_item->set_disabled(!unlocked);
    mark_backpack_fir->set_disabled(!unlocked);
    mark_all_gear_fir->set_disabled(!unlocked);
}

void ItemModule::create_item_impl() {
    if (!game_state::is_in_raid) return;
    // The drop choice is read HERE, on the render thread, and carried to
    // gameworld_update as a plain int -- the same queue-and-execute pattern the
    // module already uses, so gameworld_update never touches a ConfigValue
    // while the menu is drawing one.
    queue_drop_mode = item_drop_mode->get_value();
    queue_create_item = true;
}

void ItemModule::create_quest_item_impl() {
    if (!game_state::is_in_raid) return;
    queue_create_quest_item = true;
}

void ItemModule::transit_item_impl() {
    if (!game_state::is_in_raid) return;
    queue_transit_item = true;
}

void ItemModule::mark_backpack_fir_impl() {
    if (!game_state::is_in_raid) return;
    queue_mark_backpack_fir = true;
}

void ItemModule::mark_all_gear_fir_impl() {
    if (!game_state::is_in_raid) return;
    queue_mark_all_gear_fir = true;
}

int ItemModule::set_item_fir(Il2CppObject* item, const bool value) {
    if (!eft_api::is_il2cpp_object_likely_valid(item) || !item->klass) return 0;
    Il2CppObjectInstance inst(item);
    if (const auto set_fn = inst.get_method<void (*)(Il2CppObject*, bool)>("set_SpawnedInSession", 1, false))
    {
        set_fn(item, value);
        return 1;
    }
    // Backing field fallback (dump: <SpawnedInSession>k__BackingField on Item).
    if (FieldInfo* f = il2utils::resolve_field(item->klass, "<SpawnedInSession>k__BackingField"))
    {
        if (f->offset > 0)
        {
            *reinterpret_cast<bool*>(reinterpret_cast<uintptr_t>(item) + f->offset) = value;
            return 1;
        }
    }
    return 0;
}

int ItemModule::mark_container_tree_fir(Il2CppObject* root) {
    if (!eft_api::is_il2cpp_object_likely_valid(root)) return 0;
    int n = set_item_fir(root, true);
    std::vector<Il2CppObject*> items;
    items.reserve(64);
    eft_api::collect_compound_items_recursive(root, items);
    for (Il2CppObject* it : items)
        n += set_item_fir(it, true);
    return n;
}

int ItemModule::mark_equipment_slots_fir(Il2CppObjectInstance& equipment, const int* slots, const int slot_count) {
    int total = 0;
    for (int i = 0; i < slot_count; ++i)
    {
        Il2CppObject* slot_obj = equipment.call_or<Il2CppObject*>(
            "GetSlot", 1, nullptr, slots[i]);
        if (!slot_obj) continue;
        Il2CppObjectInstance slot(slot_obj);
        Il2CppObject* contained = slot.call_or<Il2CppObject*>(
            "get_ContainedItem", 0, nullptr);
        if (!contained) continue;
        total += mark_container_tree_fir(contained);
    }
    return total;
}

void ItemModule::draw_overlay(ImDrawList* draw_list) {
}

void ItemModule::application_update() {
    TA_ZONE_N("item::application_update");
    sync_item_controls_lock();
    no_limit = no_slot_limits->get_value();
    big_grid = increased_transfer_size->get_value();
}

void ItemModule::exec_transit_item(Il2CppObjectInstance game_world_instance, Il2CppObjectInstance main_player,
    Il2CppObject* item) {
    Il2CppObjectInstance transit_controller(
        game_world_instance.get_field<Il2CppObject*>("<TransitController>k__BackingField"));

    Il2CppObjectInstance transfer_items_controller(
        transit_controller.call_or<Il2CppObject*>("get_TransferItemsController", 0, nullptr));

    Il2CppString* player_id = main_player.call_or<Il2CppString*>("get_ProfileId", 0, nullptr);
    Il2CppObject* transit_stash_ptr = transfer_items_controller.call_or<Il2CppObject*>(
        "GetOrAddTransferContainer", 1, nullptr, player_id);

    transfer_items_controller.call_or_void<void (*)(Il2CppObject*, Il2CppObject*)>(
        "InitPlayerStash", 1, main_player.get_instance());

    Il2CppObjectInstance transfer_stash(transit_stash_ptr);

    Il2CppObjectInstance transfer_grid(
        transfer_stash.call_or<Il2CppObject*>("get_Grid", 0, nullptr));

    Il2CppObject* space = transfer_grid.call_or<Il2CppObject*>(
        "FindFreeSpace", 1, nullptr, item);

    if (space)
    {
        transfer_grid.call_or_void<void (*)(Il2CppObject*, Il2CppObject*, Il2CppObject*)>(
            "PlaceItem", 2, item, space);

        logger::debug("Moved Transit Item");
    }

    transfer_items_controller.call_or_void<void (*)(Il2CppObject*, Il2CppObject*)>(
        "MoveItemsFromTempStashToTransferStash", 1, main_player.get_instance());
}

// A drop position as one log-safe string.
//
// A helper rather than a second sprintf, because the two call sites must not be
// able to drift: when only the SUCCESS line carried coordinates, the refusal
// line had none, and that single asymmetry is what made the 2026-10-15
// refusals undiagnosable (see the refusal branch in gameworld_update).
static std::string format_drop(const unity::vector3& p) {
    char buf[64];
    std::snprintf(buf, sizeof(buf), "%.2f %.2f %.2f", p.x, p.y, p.z);
    return std::string(buf);
}

void ItemModule::gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
    Il2CppObjectInstance main_player) {
    TA_ZONE_N("item::gameworld_update");
    sync_item_controls_lock();

    if (queue_mark_backpack_fir || queue_mark_all_gear_fir)
    {
        const bool all_gear = queue_mark_all_gear_fir;
        queue_mark_backpack_fir = false;
        queue_mark_all_gear_fir = false;

        Il2CppObjectInstance inventory_controller(
            main_player.get_field<Il2CppObject*>("_inventoryController"));
        if (inventory_controller.get_instance())
        {
            Il2CppObjectInstance inventory(
                inventory_controller.call_or<Il2CppObject*>("get_Inventory", 0, nullptr));
            Il2CppObjectInstance equipment(inventory.get_field<Il2CppObject*>("Equipment"));

            int marked = 0;
            if (all_gear)
            {
                // Backpack, secure, rig, pockets + weapons on body (mags/mods get recursive FiR).
                const int slots[] = {0, 1, 2, 3, 4, 5, 6, 8};
                marked = mark_equipment_slots_fir(equipment, slots, 8);

                // Profile.SetSpawnedInSession(true) marks profile-level session flag if available.
                if (const auto get_profile = main_player.get_method<Il2CppObject* (*)(Il2CppObject*)>(
                        "get_Profile", 0, false))
                {
                    if (Il2CppObject* profile = get_profile(main_player.get_instance()))
                    {
                        Il2CppObjectInstance prof(profile);
                        if (const auto set_all = prof.get_method<void (*)(Il2CppObject*, bool)>(
                                "SetSpawnedInSession", 1, false))
                            set_all(profile, true);
                    }
                }
            }
            else
            {
                const int backpack_slot = 4;
                marked = mark_equipment_slots_fir(equipment, &backpack_slot, 1);
            }

            logger::debug(std::string(all_gear ? "All gear" : "Backpack")
                + " FiR marked items: " + std::to_string(marked));
        }
    }

    if (queue_create_item || queue_create_quest_item || queue_transit_item)
    {
        if (!item_factory)
        {
            logger::error("No Item Factory");
            queue_create_item = false;
            queue_create_quest_item = false;
            queue_transit_item = false;
            return;
        }

        Il2CppObjectInstance item_factory_instance(item_factory);
        // Checked accessor (the 2026-10-14 sweep). The old form resolved into a
        // local and invoked it with no test -- a miss was a call to address 0x0.
        // A null result now clears the queues and says so, instead of handing
        // the game a null item three branches later.
        Il2CppObject* item = item_factory_instance.call_or<Il2CppObject*>(
            "GetPresetItem", 1, nullptr, il2cpp::il2cpp_string_new(item_id->get().c_str()));

        logger::debug("Created Item: " + item_id->get()
            + (item ? "" : " -- GetPresetItem returned null, nothing will be placed"));

        if (!item)
        {
            queue_create_item = false;
            queue_create_quest_item = false;
            queue_transit_item = false;
            return;
        }

        Il2CppObjectInstance inventory_controller(
            main_player.get_field<Il2CppObject*>("_inventoryController"));

        Il2CppObjectInstance inventory(
            inventory_controller.call_or<Il2CppObject*>("get_Inventory", 0, nullptr));

        // The queue_drop_mode==0 branch needs the inventory; a world drop does
        // not, and reading it for a drop would resolve (and then abandon) three
        // more managed references for no reason.
        const bool world_drop = queue_create_item && queue_drop_mode != 0;

        // create into inventory
        if (queue_create_item && !world_drop)
        {
            queue_create_item = false;

            Il2CppObjectInstance equipment(
                inventory.get_field<Il2CppObject*>("Equipment"));

            // DIAGNOSTIC, added 2026-10-13 after the report "searching and
            // selecting still doesn't allow spawning items into inventory".
            //
            // The log showed the search working (GetPresetItem logged a real
            // template id three times, so item_id is being filled and the
            // factory resolves) and "Placed Item" NEVER appearing -- the item
            // was created and then dropped by this branch, in silence. Three
            // silent no-ops, and the player is none the wiser while the game
            // holds three orphaned items.
            //
            // Each step below says which one it is, because the branch has
            // four ways to do nothing that look identical from the menu: a
            // null slot, an empty slot (no contained item to hold the grids --
            // the default target is the backpack, so a player with no backpack
            // lands here), a container with no grids at all, and a grid with
            // no free space for this item. The chosen slot is also now a FIRST
            // choice with the rest of the gear as a fallback, so the last case
            // no longer drops an item the player has already paid for.
            const int slot_index = item_slot->get_value();
            Il2CppObject* slot_obj = equipment.call_or<Il2CppObject*>(
                "GetSlot", 1, nullptr, slot_index);
            Il2CppObjectInstance equipment_slot(slot_obj);
            logger::debug("item spawn: target slot=" + std::to_string(slot_index)
                + " slot_obj=" + (slot_obj ? "ok" : "NULL")
                + " replace_slot=" + (replace_slot->get_value() ? "on" : "off"));

            if (!replace_slot->get_value())
            {
                Il2CppObject* item_ptr = slot_obj
                    ? equipment_slot.call_or<Il2CppObject*>(
                          "get_ContainedItem", 0, nullptr)
                    : nullptr;

                logger::debug(std::string("item spawn: contained item in slot=")
                    + (item_ptr ? "ok" : "NONE -- the chosen slot cannot hold anything"));

                if (item_ptr)
                {
                    // The SHARED helper, not a hand-rolled copy.
                    //
                    // This path used to inline the same loop with two defects
                    // the shared one never had: it indexed element [0] of
                    // Grids on every iteration -- a container with several
                    // grids only ever offered its first -- and it dereferenced
                    // Grids with no null check. The duplication is also why
                    // the two paths drifted: spawn_quest_item in ItemModule.h
                    // has always used place_item_in_grids().
                    //
                    // And the chosen slot is now a FIRST choice rather than
                    // the whole answer: an empty slot, or a grid with no room
                    // for this item, used to drop the item silently -- the
                    // player clicked Create, the item was already created by
                    // GetPresetItem, and nothing appeared. The rest of the
                    // gear is tried before giving up, and each step says which
                    // one it was.
                    if (!place_item_in_grids(item_ptr, item))
                    {
                        logger::debug("item spawn: chosen slot refused it -- trying the rest of the gear");
                        const int fallback_slots[] = {4, 6, 5, 8}; // backpack, rig, secure, pockets
                        bool placed = false;
                        for (const int s : fallback_slots)
                        {
                            if (s == slot_index) continue;
                            Il2CppObject* other = equipment.call_or<Il2CppObject*>(
                                "GetSlot", 1, nullptr, s);
                            if (!other) continue;
                            Il2CppObjectInstance other_slot(other);
                            Il2CppObject* other_contained = other_slot.call_or<Il2CppObject*>(
                                "get_ContainedItem", 0, nullptr);
                            if (!other_contained) continue;
                            if (place_item_in_grids(other_contained, item))
                            {
                                logger::debug("item spawn: placed in fallback slot "
                                    + std::to_string(s));
                                placed = true;
                                break;
                            }
                        }
                        if (!placed)
                            logger::debug("item spawn: NO slot accepted the item -- its size may "
                                "exceed every grid it fits in");
                    }
                    else
                    {
                        logger::debug("Placed Item");
                    }
                }
            }
            else
            {
                equipment_slot.call_or_void<void (*)(Il2CppObject*, Il2CppObject*)>(
                    "Add", 1, item);
                logger::debug("item spawn: Add() called on the slot (replace_slot=on)");
            }
        }
        // drop into the world -- at the player's feet or in front of them
        //
        // This is the OTHER answer to "the created item was owned by nothing":
        // instead of hunting for a grid that will take it, hand it to the game
        // and let it make the loot entity. The position comes from the player's
        // own transform rather than the camera on purpose -- the camera
        // resolver is render-thread-cached (see the note in
        // eft_api::resolve_esp_camera) and this runs on the GAME thread, so
        // reading it here would race with the ESP. Body facing and aim direction
        // are the same vector in any situation that matters for a drop, and a
        // 2.5 m throw distance is what the feature is for.
        else if (world_drop)
        {
            queue_create_item = false;

            Il2CppObject* player_transform = nullptr;
            {
                Il2CppObject* player_go = unity::component_get_game_object(
                    main_player.get_instance());
                player_transform = player_go ? unity::gameobject_get_transform(player_go) : nullptr;
            }

            unity::vector3 drop_position{};
            bool have_position = false;
            if (player_transform)
            {
                drop_position = unity::transform_get_pos(player_transform);
                if (queue_drop_mode == 2)
                {
                    Il2CppObjectInstance pt(player_transform);
                    const auto get_fwd = pt.get_method<unity::vector3 (*)(Il2CppObject*)>(
                        "get_forward", 0, false);
                    if (get_fwd)
                        drop_position = drop_position.add(get_fwd(player_transform) * 2.5f);
                }
                // A few centimetres up so the entity does not start inside the
                // floor -- the game's own collision settles it from there.
                drop_position = drop_position.add({0.f, 0.10f, 0.f});
                have_position = true;
            }

            if (!have_position)
            {
                logger::error("item spawn: no player transform, cannot place a world drop "
                    "-- nothing was created into the world");
            }
            else if (Il2CppObject* loot = throw_item_in_world(game_world_instance.get_instance(),
                         main_player.get_instance(), item, drop_position))
            {
                // The LootItem is logged rather than used: the game owns it from
                // here, and holding the pointer across frames is exactly the
                // "owned by nobody" problem in the other direction.
                (void)loot;
                logger::debug("item spawn: dropped in the world at " + format_drop(drop_position));
            }
            else
            {
                // The one case that still leaves an orphan: the game refused the
                // throw. Say so with the id, because the item now exists and is
                // owned by nothing.
                //
                // The POSITION and the mode are in this line, and were not until
                // 2026-10-15: success logged coordinates and failure logged only
                // the template id, which made "refused" undiagnosable from the log
                // -- 18 refusals across two templates and one successful template
                // in a single session, with nothing to say whether the refusals
                // were about the item or about where the player stood. Both are
                // hypotheses the log could not separate, and the whole cost of
                // answering it was one sprintf on a path that already fails.
                logger::error("item spawn: GameWorld.ThrowItem refused " + item_id->get()
                    + " mode=" + (queue_drop_mode == 2 ? "front" : "feet")
                    + " at " + format_drop(drop_position)
                    + " -- it is created but owned by nothing");
            }
        }
        // create into quest inventory
        else if (queue_create_quest_item)
        {
            queue_create_quest_item = false;

            Il2CppObjectInstance quest_raid_items(inventory.get_field<Il2CppObject*>("QuestRaidItems"));
            Il2CppObjectInstance stash_grid(
                quest_raid_items.call_or<Il2CppObject*>("get_Grid", 0, nullptr));

            Il2CppObject* space = stash_grid.call_or<Il2CppObject*>(
                "FindFreeSpace", 1, nullptr, item);

            if (space)
            {
                stash_grid.call_or_void<void (*)(Il2CppObject*, Il2CppObject*, Il2CppObject*)>(
                    "PlaceItem", 2, item, space);
                logger::debug("Placed Quest Item");
            }
            else
            {
                logger::debug("item spawn: quest stash refused it -- no free space, or its "
                    "Grid did not resolve");
            }
        }
        // create into transit inventory
        else if (queue_transit_item)
        {
            queue_transit_item = false;
            exec_transit_item(game_world_instance, main_player, item);
        }

        Il2CppObjectInstance item_instance(item);

        if (override_max_amount->get_value())
        {
            item_instance.set_field("StackObjectsCount", amount->get_value());
        }
        else
        {
            // A zero max_size is the fail-closed value, and it is also the one
            // input to this min that means "not an item stack at all" -- every
            // real stack has a maximum of at least 1, so clamping to it would
            // write 0 and empty the stack. An unresolvable property therefore
            // leaves the count alone, which is the same as the override branch
            // above rather than a third behaviour nobody asked for.
            const int max_size = item_instance.call_or<int>("get_StackMaxSize", 0, 0);
            // std::min<int>, not std::min: see the note in il2cpp/unity.h on the
            // <Windows.h> min/max macros.
            const int requested = amount->get_value();
            item_instance.set_field("StackObjectsCount",
                max_size > 0 ? std::min<int>(requested, max_size) : requested);
        }

        if (fir->get_value())
        {
            item_instance.call_or_void<void (*)(Il2CppObject*, bool)>(
                "set_SpawnedInSession", 1, true);
        }
    }
}

void ItemModule::init() {
    sync_item_controls_lock();

    const Il2CppImage* assembly = il2utils::resolve_image("Assembly-CSharp.dll");

    // item factory
    const Il2CppClass* game_world_class = il2utils::resolve_class(assembly, "EFT", "GameWorld");
    il2utils::hook_method(game_world_class, "InitLevel", 6, hk_init_level, &o_init_level);

    // slot limitss
    const Il2CppClass* item_controller_class = il2utils::resolve_class(
        assembly, "EFT.InventoryLogic", "ItemController");
    const Il2CppClass* inventory_controller_class = il2utils::resolve_class(
        assembly, "EFT.InventoryLogic", "InventoryController");
    const Il2CppClass* backend_inventory_controller_class = il2utils::resolve_class(
        assembly, "EFT.InventoryLogic", "BackEndInventoryController");

    il2utils::hook_method(item_controller_class, "IsLimitedAtAddress", 3, hk_limited_at_address_item,
        &o_limited_at_address_item);
    il2utils::hook_method(inventory_controller_class, "IsLimitedAtAddress", 3, hk_limited_at_address_inventory,
        &o_limited_at_address_inventory);
    il2utils::hook_method(backend_inventory_controller_class, "IsLimitedAtAddress", 3,
        hk_limited_at_address_backend,
        &o_limited_at_address_backend);

    const Il2CppClass* stack_slot_class = il2utils::resolve_class(assembly, "EFT.InventoryLogic", "StackSlot");
    il2utils::hook_method(stack_slot_class, "CheckCompatibility", 1, hk_check_compat_stack_slot,
        &o_check_compat_stack_slot);

    il2utils::hook_method(item_controller_class, "CheckCompatibility", 1, hk_check_compat_item_controller,
        &o_check_compat_item_controller);
    il2utils::hook_method(item_controller_class, "CheckRestrictions", 2, hk_check_restrictions,
        &o_check_restrictions);
    il2utils::hook_method(item_controller_class, "CheckForOnlySpecialSlotsItem", 2, hk_check_special_slot,
        &o_check_special_slot);
    il2utils::hook_method(item_controller_class, "CheckSlotRestrictions", 2, hk_check_slot_restrictions,
        &o_check_slot_restrictions);

    const Il2CppClass* magazine_class = il2utils::resolve_class(assembly, "EFT.InventoryLogic", "Magazine");
    il2utils::hook_method(magazine_class, "CheckCompatibility", 1, hk_check_compat_magazine,
        &o_check_compat_magazine);
    il2utils::hook_method(magazine_class, "IsAmmoCompatible", 1, hk_is_ammo_compatible,
        &o_is_ammo_compatible);

    const Il2CppClass* virtual_container_class = il2utils::resolve_class(
        assembly, "EFT.InventoryLogic", "VirtualContainer");
    il2utils::hook_method(virtual_container_class, "CheckCompatibility", 1, hk_check_compat_virtual_container,
        &o_check_compat_virtual_container);

    const Il2CppClass* grid_class = il2utils::resolve_class(assembly, "EFT.InventoryLogic", "Grid");
    il2utils::hook_method(grid_class, "CheckCompatibility", 1, hk_check_compat_grid, &o_check_compat_grid);

    const Il2CppClass* slot_class = il2utils::resolve_class(assembly, "EFT.InventoryLogic", "Slot");
    il2utils::hook_method(slot_class, "CheckCompatibility", 1, hk_check_compat_slot, &o_check_compat_slot);
    il2utils::hook_method(slot_class, "CheckConditions", 3, hk_slot_check_conditions, &o_slot_check_conditions);

    // IL2CPP type names must stay literal — never use i18n keys here.
    const Il2CppClass* weapon_class = il2utils::resolve_class(assembly, "EFT.InventoryLogic", "Weapon");
    il2utils::hook_method(weapon_class, "IsModSuitable", 1, hk_is_mod_suitable, &o_is_mod_suitable);

    const Il2CppClass* mod_class = il2utils::resolve_class(assembly, "EFT.InventoryLogic", "Mod");
    il2utils::hook_method(mod_class, "get_RaidModdable", 0, hk_get_mod_raid_moddable, &o_get_mod_raid_moddable);
    il2utils::hook_method(mod_class, "CanBeMoved", 1, hk_mod_can_be_moved, &o_mod_can_be_moved);

    // grid size
    const Il2CppClass* transfer_items_controller = il2utils::resolve_class(
        assembly, "EFT", "TransferItemsController");
    il2utils::hook_method(transfer_items_controller, "GetGridSizeForProfileId", 1, hk_get_grid_size,
        &o_get_grid_size);

    // local raid ended
    const Il2CppClass* eft_client_backend_session = il2utils::resolve_class(
        assembly, "EFT", "EftClientBackendSession");
    il2utils::hook_method(eft_client_backend_session, "LocalRaidEnded", 4, hk_local_raid_ended,
        &o_local_raid_ended);
}
