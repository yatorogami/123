#pragma once
#include "../Module.h"
#include "../ModuleCategory.h"
#include "../../config/CheckboxValue.h"
#include "../../config/MenuSectionValue.h"
#include "../../il2cpp/Il2CppObjectInstance.h"
#include "../../il2cpp/il2utils.h"
#include "../../il2cpp/unity.h"
#include "../../util/logger.h"

// Combat feel hooks (CT AutoPatchMethods-style). Detours restored on toggle off.
namespace combat_feel {
    using breach_sig = bool (*)(Il2CppObject*, unity::vector3);
    using float_get_sig = float (*)(Il2CppObject*);
    using void_0_sig = void (*)(Il2CppObject*);
    using void_f_sig = void (*)(Il2CppObject*, float);

    inline breach_sig o_breach = nullptr;
    inline float_get_sig o_head_bob = nullptr;
    inline float_get_sig o_aim_sway = nullptr;
    inline void_0_sig o_breath_shot = nullptr;
    inline void_f_sig o_breath_process = nullptr;
    inline void_f_sig o_add_recoil = nullptr;

    inline bool installed_breach = false;
    inline bool installed_head_bob = false;
    inline bool installed_aim_sway = false;
    inline bool installed_breath_shot = false;
    inline bool installed_breath_process = false;
    inline bool installed_recoil = false;
    // UI lives on WorldModule (under Unlock Doors); WeaponModule reads this each sync.
    inline bool always_breach_ui = false;

    inline bool hk_breach_success_roll(Il2CppObject* self, unity::vector3 your_position) {
        (void)self;
        (void)your_position;
        return true; // always succeed kick/breach roll
    }

    inline float hk_head_bobbing(Il2CppObject* self) {
        (void)self;
        return 0.f;
    }

    inline float hk_aim_sway_strength(Il2CppObject* self) {
        (void)self;
        return 0.f;
    }

    inline void hk_breath_on_shot(Il2CppObject* self) {
        (void)self;
        // swallow — no breath kick from shot
    }

    inline void hk_breath_process(Il2CppObject* self, float delta_time) {
        (void)self;
        (void)delta_time;
        // swallow continuous breath motion
    }

    inline void hk_add_recoil_force(Il2CppObject* self, float incoming_force) {
        (void)self;
        (void)incoming_force;
        // swallow recoil force application
    }

    inline const Il2CppClass* find_class(const char* ns, const char* name) {
        const Il2CppImage* img = il2utils::resolve_image("Assembly-CSharp.dll");
        if (!img) return nullptr;
        const Il2CppClass* c = il2utils::resolve_class(img, ns, name);
        if (c) return c;
        // Some builds put nested recoil under empty ns
        return il2utils::resolve_class(img, "", name);
    }

    inline void sync(
        const bool always_breach,
        const bool no_head_bob,
        const bool no_aim_sway,
        const bool no_breath,
        const bool no_recoil) {
        // Door.BreachSuccessRoll(Vector3) -> bool
        {
            const Il2CppClass* door = find_class("EFT.Interactive", "Door");
            il2utils::set_method_hook(door, "BreachSuccessRoll", 1,
                hk_breach_success_roll, &o_breach, &installed_breach, always_breach);
        }

        // ProceduralWeaponAnimation getters
        {
            const Il2CppClass* pwa = find_class("EFT.Animations", "ProceduralWeaponAnimation");
            // private get_HeadBobbing — still present on klass method table
            il2utils::set_method_hook(pwa, "get_HeadBobbing", 0,
                hk_head_bobbing, &o_head_bob, &installed_head_bob, no_head_bob);
            il2utils::set_method_hook(pwa, "get_AimSwayStrength", 0,
                hk_aim_sway_strength, &o_aim_sway, &installed_aim_sway, no_aim_sway);
        }

        // BreathEffector — both methods for full breath sway disable
        {
            const Il2CppClass* breath = find_class("EFT.Animations", "BreathEffector");
            il2utils::set_method_hook(breath, "OnShot", 0,
                hk_breath_on_shot, &o_breath_shot, &installed_breath_shot, no_breath);
            il2utils::set_method_hook(breath, "Process", 1,
                hk_breath_process, &o_breath_process, &installed_breath_process, no_breath);
        }

        // NewRecoilShotEffect.AddRecoilForce
        {
            const Il2CppClass* recoil = find_class("EFT.Animations.NewRecoil", "NewRecoilShotEffect");
            if (!recoil)
                recoil = find_class("EFT.Animations", "NewRecoilShotEffect");
            il2utils::set_method_hook(recoil, "AddRecoilForce", 1,
                hk_add_recoil_force, &o_add_recoil, &installed_recoil, no_recoil);
        }
    }

    inline void force_unhook_all() {
        sync(false, false, false, false, false);
    }
} // namespace combat_feel

class WeaponModule : Module
{
  public:
    WeaponModule();

    CheckboxValue* no_jam;
    CheckboxValue* infinite_ammo;

    // Combat feel (CT AutoPatchMethods — Detour on/off restores originals).
    // Always-kick-door UI is under World → Unlock Doors (see combat_feel::always_breach_ui).
    MenuSectionValue* section_feel_;
    CheckboxValue* no_head_bobbing;
    CheckboxValue* no_aim_sway;
    CheckboxValue* no_breath_sway;
    CheckboxValue* no_recoil_force;

    void draw_overlay(ImDrawList* draw_list) override;

    void application_update() override;

    void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
        Il2CppObjectInstance main_player) override;

    void init() override;
};
