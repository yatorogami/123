#include "common.h"
#include "RaidDashboardModule.h"

RaidDashboardModule::RaidDashboardModule() : Module("Raid Dashboard", RaidDashboard, "raid_dashboard_mod"),
                                             show_debug_log(conf(new CheckboxValue(false, "raid_dashboard_debug_cb"))),
                                             keep_orig_hash(conf(new CheckboxValue(true, "raid_dashboard_keep_hash_cb"))),
                                             keep_orig_server_id(conf(new CheckboxValue(true, "raid_dashboard_keep_server_id_cb"))),
                                             write_local_raid_settings(conf(new CheckboxValue(
                                                 true, "raid_dashboard_write_settings_cb"))) {}

void RaidDashboardModule::draw_overlay(ImDrawList*) {}

void RaidDashboardModule::application_update() {
    TA_ZONE_N("raiddashboard::application_update");
    DebugLogModule::set_enabled(show_debug_log->get_value());
    // Read HERE, not in gameworld_update() like the two Keep* boxes: this one gates a
    // write that happens during raid START, so sampling it only once a GameWorld
    // already exists would apply it a raid too late to be a useful bisect.
    always_on::assign_write_local_raid_settings(write_local_raid_settings->get_value());
}

void RaidDashboardModule::init() {
    DebugLogModule::set_enabled(show_debug_log->get_value());
    always_on::assign_write_local_raid_settings(write_local_raid_settings->get_value());
}

void RaidDashboardModule::draw_menu_extra() {
    if (!game_state::is_in_raid)
    {
        ImGui::TextColored(menu::palette::accent2, "Waiting for local raid");
        imgui_addons::status_line("Enter a raid to populate live status.");
        return;
    }

    ImGui::TextColored(menu::palette::accent2, "%s",
        location_display_.empty() ? "Local Raid" : location_display_.c_str());
    ImGui::Separator();
    ImGui::Text("Status");
    ImGui::SameLine();
    ImGui::TextColored(menu::palette::accent2, "LOCAL / ACTIVE");
    ImGui::Text("Coordinates  X %.1f   Y %.1f   Z %.1f",
        player_pos_.x, player_pos_.y, player_pos_.z);
    ImGui::Text("FPS  %.0f", ImGui::GetIO().Framerate);
    ImGui::Text("Loose Loot  %d", loose_loot_count_);
    ImGui::Text("Item Factory  %s", game_state::item_factory ? "Ready" : "Loading");
}

void RaidDashboardModule::gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world,
    Il2CppObjectInstance main_player) {
    TA_ZONE_N("raiddashboard::gameworld_update");
    if (!game_state::is_in_raid)
    {
        clear_runtime_cache();
        return;
    }

    const ULONGLONG now = GetTickCount64();
    if (now - last_sample_ms_ < 250) return;
    last_sample_ms_ = now;

    location_display_ = eft_api::try_get_location_display_name(read_location_id(game_world_class, game_world));
    Il2CppObject* player_go = unity::component_get_game_object(main_player.get_instance());
    Il2CppObject* player_transform = player_go ? unity::gameobject_get_transform(player_go) : nullptr;
    if (player_transform)
        player_pos_ = unity::transform_get_pos(player_transform);

    loose_loot_count_ = 0;
    Il2CppObject* loot_hydra = game_world.get_field<Il2CppObject*>("LootItems");
    unity::list* list = nullptr;
    if (loot_hydra)
    {
        Il2CppObjectInstance hydra(loot_hydra);
        list = hydra.get_field<unity::list*>("_iteration");
    }
    if (list && list->m_p_list_array)
    {
        Il2CppArray* array = list->m_p_list_array;
        for (size_t i = 0; i < array->max_length; ++i)
            if (reinterpret_cast<Il2CppObject**>(&array->data)[i]) ++loose_loot_count_;
    }

    always_on::assign_keep_transition_hash(keep_orig_hash->get_value());
    always_on::assign_keep_server_id(keep_orig_server_id->get_value());
}

void RaidDashboardModule::clear_runtime_cache() {
    location_display_.clear();
    player_pos_ = {};
    loose_loot_count_ = 0;
    last_sample_ms_ = 0;
}

// Was its own copy of the location probe, reading ONE class through
// Il2CppObjectInstance::get_field. Consolidated 2026-10-14 into
// eft_api::read_location_id, which tries both classes and guards a field whose
// offset is <= 0. get_field did not: at offset 0 it would read the object header
// and reinterpret it as a pointer. Strictly more capable, same value wherever
// the old one returned one.
std::string RaidDashboardModule::read_location_id(const Il2CppClass* world_class, Il2CppObjectInstance& world) {
    return eft_api::read_location_id(world_class, world);
}
