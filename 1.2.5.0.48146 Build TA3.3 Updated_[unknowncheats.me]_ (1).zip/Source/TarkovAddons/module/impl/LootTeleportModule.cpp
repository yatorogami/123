#include "common.h"
#include "LootTeleportModule.h"

LootTeleportModule::LootTeleportModule(WorldModule* world) : Module("Loot Teleporter", Teleport, "loot_tp_sec"), world_(world),
loot_selected_item_(conf(new ItemSearchValue("ltp_item_search_txt", nullptr, false, /*multi=*/true))),
loot_category_filter_(conf(new SelectValue(0, {
												  "loot_category_all_sel",
												  "loot_category_valuables_sel",
												  "loot_category_barter_sel",
												  "loot_category_medical_sel",
												  "loot_category_food_sel",
												  "loot_category_ammo_sel",
												  "loot_category_weapons_sel",
												  "loot_category_armor_sel",
												  "loot_category_keys_sel",
	},
	"ltp_category_sel"))),
	loot_wl_filter_(conf(new SelectValue(0, {
													 "ltp_wlgroup_all_sel",
													 "ltp_wlgroup_quests_sel",
													 "ltp_wlgroup_hideout_sel",
													 "ltp_wlgroup_trading_sel",
													 "ltp_wlgroup_equipment_sel",
													 "ltp_wlgroup_other_sel",
		},
		"ltp_wlgroup_sel"))),
		teleport_quest_loot_(conf(new ActionRowValue([this] {
	if (world_) world_->loot_to_me_impl(1);
			},
			"loot_tp_quest_btn"))),
	teleport_category_loot_(conf(new ActionRowValue([this] {
	if (world_) world_->loot_to_me_impl(4);
		},
		"loot_tp_category_btn"))),
	teleport_wishlist_loot_(conf(new ActionRowValue([this] {
	if (world_) world_->loot_to_me_impl(5);
		},
		"loot_tp_wishlist_btn"))),
	teleport_selected_loot_(conf(new ActionRowValue([this] {
	if (world_) world_->loot_to_me_impl(3);
		},
		"loot_tp_selected_btn"))) {
	if (!world_) return;
	world_->section_loot_tp_->set_hidden_in_owner_menu(true);
	world_->loot_circle_radius->set_hidden_in_owner_menu(true);
	world_->loot_height_offset->set_hidden_in_owner_menu(true);
	world_->loot_to_me->set_hidden_in_owner_menu(true);
	world_->loot_tp_from_containers->set_hidden_in_owner_menu(true);
	world_->loot_tp_container_cap->set_hidden_in_owner_menu(true);
	world_->set_loot_teleport_filter_matcher(
		[this](int filter, const std::string& id, const std::string& name,
			bool is_quest, Il2CppObject* player) {
				return matches_filter(filter, id, name, is_quest, player);
		});
	// Own settings are drawn manually in draw_menu_extra; keep them out of the
	// automatic card value list so they don't render twice. The four ActionRowValue
	// buttons belong to this list too -- they are conf()-registered, so menu.cpp's
	// apply() would draw them a second time under an identical ImGui ID (the label
	// is "tr(name)##module", and both draws use the same module).
	loot_selected_item_->set_hidden_in_owner_menu(true);
	loot_category_filter_->set_hidden_in_owner_menu(true);
	loot_wl_filter_->set_hidden_in_owner_menu(true);
	teleport_quest_loot_->set_hidden_in_owner_menu(true);
	teleport_category_loot_->set_hidden_in_owner_menu(true);
	teleport_wishlist_loot_->set_hidden_in_owner_menu(true);
	teleport_selected_loot_->set_hidden_in_owner_menu(true);
}

void LootTeleportModule::draw_overlay(ImDrawList*) {}

void LootTeleportModule::application_update() {}

void LootTeleportModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) {}

void LootTeleportModule::init() {}

[[nodiscard]] bool LootTeleportModule::draw_menu_extra_before_values() const { return true; }

void LootTeleportModule::draw_menu_extra() {
	if (!world_) return;
	imgui_addons::status_line("Teleport preview (loose loot)", true);
	imgui_addons::status_line("All loot: " + std::to_string(world_->get_loot_teleport_preview_count(0)));
	imgui_addons::status_line("By-name loot: " + std::to_string(world_->get_loot_teleport_preview_count(3)));
	imgui_addons::status_line("Quest item loot: " + std::to_string(world_->get_loot_teleport_preview_count(1)));
	imgui_addons::status_line("Category loot: " + std::to_string(world_->get_loot_teleport_preview_count(4)));
	imgui_addons::status_line("Wishlist loot: " + std::to_string(world_->get_loot_teleport_preview_count(5)));
	ImGui::Separator();

	// Item-selection controls. 0=All, 1=Quest, 4=Category, 5=Wishlist, 3=By-name
	// (see matches_filter). Option 2 was the combined category-or-wishlist choice and
	// is gone: it is what made a category-only teleport pull wishlist items too.
	imgui_addons::status_line("Item selection", true);
	teleport_quest_loot_->draw();
	ImGui::Separator();
	loot_selected_item_->draw();
	teleport_selected_loot_->draw();
	ImGui::Separator();
	loot_category_filter_->draw();
	teleport_category_loot_->draw();
	ImGui::Separator();
	loot_wl_filter_->draw();
	teleport_wishlist_loot_->draw();
	ImGui::Separator();
	world_->loot_to_me->draw();
	ImGui::Separator();

	// Containers get their own block rather than being folded into the four buttons
	// above, because this is the only branch of the card that mutates container
	// inventories instead of moving a transform. It is off by default for that reason,
	// and the cap is the difference between a hitch and a stall on a map holding
	// thousands of container items.
	//
	// The report line is what the last press actually did, straight out of
	// WorldModule's counters. There is no live preview for containers, and that is
	// deliberate: a preview would need the same scene-wide FindObjectsOfType plus a
	// per-item matcher pass that the loose-loot preview already costs 500 ms of, and
	// `matches_filter` above is not cheap per call -- it classifies the template, the
	// wishlist group and the loot kind and re-reads the multi-select every time. The
	// reverted version did exactly that every 500 ms across 733 containers.
	imgui_addons::status_line("Containers", true);
	world_->loot_tp_from_containers->draw();
	world_->loot_tp_container_cap->draw();
	imgui_addons::status_line(world_->get_loot_tp_container_report());
	ImGui::Separator();
}

item_categories::loot LootTeleportModule::loot_kind_for_template(const std::string& template_id) const {
	return game_items::loot_kind_by_id(template_id);
}

void LootTeleportModule::ensure_wishlist_sets(Il2CppObject* profile, const bool force) {
	if (wishlist_sets_.ready && !force)
		return;
	eft_api::refresh_wishlist_filter_sets(profile, wishlist_sets_);
	wishlist_sets_refresh_ms_ = GetTickCount64();
}

item_categories::kind LootTeleportModule::classify_template(const std::string& template_id) const {
	return item_categories::classify_id(template_id, wishlist_sets_);
}

item_categories::wishlist_mask LootTeleportModule::wishlist_mask() const {
	// loot_wl_filter_ SelectValue indices:
	//   0 = All (admit all groups -> return 0 mask)
	//   1 = Quests   -> wishlist_group::quests (0)
	//   2 = Hideout  -> wishlist_group::hideout (1)
	//   3 = Trading  -> wishlist_group::trading (2)
	//   4 = Equipment-> wishlist_group::equipment (3)
	//   5 = Other    -> wishlist_group::other (4)
	const auto idx = loot_wl_filter_->get_value();
	if (idx == 0) return 0;
	return item_categories::group_bit(static_cast<item_categories::wishlist_group>(idx - 1));
}

bool LootTeleportModule::matches_filter(const int filter, const std::string& template_id,
	std::string name, const bool is_quest, Il2CppObject* local_player) {
	(void)name; // the shared predicate does not match on the display name

	// The predicate itself is item_categories::matches_teleport_filter, shared with
	// EspModule::matches_loot_teleport_filter. The two were verbatim copies and had
	// already drifted once -- this half had been moved onto the class taxonomy while
	// the other still substring-matched -- so the duplication was not neutral.
	//
	// What stays here is what genuinely differs per module: which ConfigValues to
	// read (ltp_* keys, deliberately not shared with the ESP card's loot_*), and the
	// lazy wishlist refresh, which needs a live Il2CppObject*.
	//
	// Deliberate difference from the ESP draw path: this card picks ONE filter
	// option, so each option decides alone -- option 2 asks category OR wishlist,
	// never "is this the selected item too". The ESP draw path
	// (EspModule::loot_ui_filter_allowed) has two independent checkboxes and applies
	// the "selected items only" gate BEFORE the category gate, so with both on it
	// shows only the selected item if it is in the category. Different UI shape,
	// different answer; not a drift.
	if (filter == 2 && local_player && !wishlist_sets_.ready)
	{
		Il2CppObjectInstance player(local_player);
		const auto get_profile = player.get_method<Il2CppObject * (*)(Il2CppObject*)>(
			"get_Profile", 0);
		if (get_profile)
			ensure_wishlist_sets(get_profile(local_player));
	}

	const std::string selected = loot_selected_item_->get_selected_id();
	item_categories::teleport_filter_input in;
	in.is_quest = is_quest;
	in.wishlist = classify_template(template_id);
	in.wl_group = item_categories::classify_group(template_id, wishlist_sets_);
	in.wl_mask = wishlist_mask();
	in.category_kind = loot_kind_for_template(template_id);
	in.category = loot_category_filter_->get_value();
	in.selected_id = selected.c_str();
	// Multi-select: the query selects every id it matched, so "Teleport Selected
	// Loot" moves all of them. The click is kept as a single pick for a box that
	// wants one, but this card no longer depends on it -- which is the fix for
	// "it can only choose one from the list".
	if (loot_selected_item_->is_multi())
		in.selected_ids = loot_selected_item_->get_matched_ids();
	in.template_id = template_id.c_str();
	// This card TELEPORTS what it matches; the ESP card only labels it. The two
	// want opposite answers to "an item whose class the taxonomy does not
	// recognise", and the shared predicate carries the difference as an explicit
	// opt-in so it cannot drift back into one shared rule. Measured 2026-10-11 on
	// the live db: 989 of 6001 entries are unmapped (24 of 124 classes), so under
	// the permissive rule one in six loot items matched EVERY category the user
	// picked -- which is how "Teleport Category Loot To Me" came to pull
	// wishlist items along with it. Strict here; ESP keeps the default.
	in.allow_unknown_category = item_categories::kTeleportCategoryAllowsUnknown;
	return item_categories::matches_teleport_filter(filter, in);
}

BotControlModule::BotControlModule(WorldModule* world) : Module("Bot Controls", BotSpawner, "bot_tp_sec"), world_(world) {
	if (!world_) return;
	ConfigValue* values[] = {
		world_->section_bot_tp_,
		world_->kill_all,
		world_->tp_all,
		world_->tp_one_mode,
		world_->tp_one,
		world_->tp_scav,
		world_->tp_boss,
		world_->tp_guard,
		world_->tp_cultist,
		world_->tp_raider,
		world_->tp_defector,
		world_->tp_black_division,
		world_->tp_pmc,
	};
	for (ConfigValue* value : values)
		value->set_hidden_in_owner_menu(true);
}

void BotControlModule::draw_overlay(ImDrawList*) {}

void BotControlModule::application_update() {}

void BotControlModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) {}

void BotControlModule::init() {}

void BotControlModule::draw_menu_extra() {
	if (!world_) return;
	ConfigValue* values[] = {
		world_->section_bot_tp_,
		world_->kill_all,
		world_->tp_all,
		world_->tp_scav,
		world_->tp_boss,
		world_->tp_guard,
		world_->tp_cultist,
		world_->tp_raider,
		world_->tp_defector,
		world_->tp_black_division,
		world_->tp_pmc,
	};
	for (ConfigValue* value : values)
		value->draw();
}
