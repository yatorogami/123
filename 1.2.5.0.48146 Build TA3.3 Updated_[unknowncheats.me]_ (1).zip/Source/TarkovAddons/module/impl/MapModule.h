#pragma once

#include "../Module.h"
#include "../ModuleCategory.h"
#include "../../config/CheckboxValue.h"
#include "../../config/FloatSliderEditableValue.h"
#include "../../config/InfoDrawValue.h"
#include "../../config/MenuSectionValue.h"
#include "../../config/SelectValue.h"
#include "../../il2cpp/unity.h"
#include "../../module/minimap.h"

// Pointer only -- the type is needed in full by MapModule.cpp, not by anyone who
// includes this header. EspModule.h is one of the largest in the tree and
// ModuleManager.h includes every module header, so this keeps the cost off
// every TU that wants the big map's controls.
class EspModule;

// Step 6 of tools/plan_bigmap_and_minimap.md: a keybound FULL-SCREEN map.
//
// WHY ITS OWN MODULE, and not a flag on EspModule: the overlay dispatch
// (gui/menu/menu.cpp) calls every ACTIVE module's draw_overlay() every frame and
// is not raid-gated, but EspModule::draw_overlay() early-returns when
// !game_state::is_in_raid -- so a map that should also work in the stash could
// not live there. The same reason MapEditorModule is a separate card.
//
// WHY IT RESOLVES ITS OWN LOCATION, and does not ask EspModule: ModuleManager's
// apply() visits only modules whose is_active() is true, and EspModule::is_active()
// is false when every ESP feature is off -- so with ESP off, EspModule never runs
// gameworld_update() and its current_location_id is stale. A map that went blank
// whenever the ESP card was off would be a worse bug than a duplicated probe.
//
// WHY IT HOLDS AN EspModule*, and what it is NOT allowed to do with it: the
// marker drawing is EspModule::draw_big_map_markers, so the two views share one
// renderer and cannot drift apart. This module builds the VIEW (bounds, centre,
// zoom, pan, floor) and owns the controls; it does not re-implement anything
// EspModule already draws. Constructor-injected rather than reached through a
// global, matching AiLimitModule(world_module, player_module) and
// WeaponBuilderModule(inventory_editor_module).
class MapModule : public Module
{
  public:
    explicit MapModule(EspModule* esp);

    MenuSectionValue* section_view_;
    CheckboxValue* big_map;
    // The slider is the BASELINE zoom. Wheel zoom multiplies it, and the two
    // are not the same control: the slider survives a raid, the wheel does not.
    FloatSliderEditableValue* big_map_zoom;
    // One switch per marker layer, so the big map can be more or less crowded
    // than the radar without either one asking the other what to draw.
    CheckboxValue* big_map_quest;
    CheckboxValue* big_map_exfils;
    CheckboxValue* big_map_players;
    CheckboxValue* big_map_static;

    // Step 7: the map picker. Options are filled from minimap::current_configs()
    // rather than declared here, because the set of maps is whatever
    // scan_configs() found on disk -- hardcoding twelve names would be a list
    // that goes stale the moment a map is added or a folder is missing.
    // Index 0 is "the map I am in", which is why a pick survives the raid it
    // was made in.
    SelectValue* big_map_location;
    // Why the picker above is inert in a raid. A control that does nothing with
    // no explanation reads as a bug, and the reason (one global loaded map, and
    // the radar re-requesting the player's own location every frame) is not
    // something the user can be expected to know.
    InfoDrawValue* big_map_loc_note;

    void draw_overlay(ImDrawList* draw_list) override;

    void application_update() override;

    void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
        Il2CppObjectInstance main_player) override;

    void init() override;

    void prepare_menu_draw() override;

    [[nodiscard]] bool is_active() const override {
        return big_map->get_value();
    }

  private:
    EspModule* esp_ = nullptr;

    // Owned here rather than borrowed from EspModule -- see the class comment.
    // Written on the game thread, read on the render thread, which is the same
    // hand-off EspModule::my_pos already makes.
    std::string current_location_id_;
    unity::vector3 player_pos_ = {};
    // Separate from the vector, and that is the load-bearing half: (0,0,0) is a
    // legal world position -- Customs' origin is inside the playable area -- so a
    // zero vector cannot mean "no position yet". Reading it as "the player is at
    // the origin" is the bug this flag exists to prevent.
    bool has_player_pos_ = false;

    bool configs_scanned_ = false;
    // The location the big map is SHOWING, which is the picker's choice while in
    // a raid and the live one otherwise. last_requested_location_ is what was
    // last handed to minimap::request_active_map; comparing against it is how
    // the reload is triggered exactly once per change.
    std::string shown_location_;
    std::string last_requested_location_;
    // The picker index that means "this raid's map". -1 is not a map, so the
    // sentinel cannot collide with one.
    static constexpr int kFollowLocationIndex = -1;
    int location_picker_floor_ = kFollowLocationIndex;
    bool location_options_built_ = false;
    // The config SET the picker was built from. `reload_map_configs_from_disk()`
    // and `scan_configs()` each publish a NEW shared_ptr, so pointer identity is
    // the cheapest reliable "the map set changed" signal available -- and the
    // picker stores indices, which is exactly the thing that silently means a
    // different map after a reload if the list is not rebuilt with it.
    minimap::config_set_ptr options_built_from_;

    // View centre in map UV space, and whether it is still pinned to the player.
    // Panning sets follow_player_ false; pressing the follow button, or moving
    // the player more than one radar range from the last centred position, sets
    // it back -- the same re-centre rule the radar uses, so the two behave alike.
    float center_u_ = 0.5f;
    float center_v_ = 0.5f;
    bool follow_player_ = true;
    unity::vector3 last_centered_player_pos_ = {};
    bool has_last_centered_pos_ = false;

    bool dragging_ = false;
    ImVec2 drag_last_{};

    // Which location the picker should point at. "Current" is first, then every
    // config scan_configs() found, sorted so the list does not reshuffle between
    // sessions (directory order is not stable).
    void refresh_location_options();
    [[nodiscard]] std::string location_for_index(int index) const;
    // Writes shown_location_ from the picker and the live location id, and
    // resets the view state that belongs to the old map.
    void sync_shown_location();

    // Pan/zoom. Split from draw_overlay so the input handling is testable
    // against a known view instead of only inside a live window.
    void handle_map_input(const ImVec2& origin, const float side,
        const minimap::map_view_transform* view, const unity::vector3& player_pos);

    // The floor controls strip drawn at the top of the map. Returns nothing: it
    // mutates the minimap override through the cycling helpers.
    void draw_floor_controls(const float side, const std::string& map_label);
};