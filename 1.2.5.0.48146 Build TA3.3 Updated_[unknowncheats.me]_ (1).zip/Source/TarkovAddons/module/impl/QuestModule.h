#pragma once
#include <algorithm>
#include <atomic>
#include <cctype>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>
#include "../game_state.h"
#include "../Module.h"
#include "../ModuleCategory.h"
#include "../../il2cpp/unity.h"
#include "../../gui/menu/imgui_addons.h"
#include "../../config/SelectValue.h"
#include "../../config/IntSliderEditableValue.h"
#include "ItemModule.h" // for spawn_quest_item()
#include "../quest_objectives.h"

// Matches EFT's MongoID struct (24 bytes): uint timeStamp @0x0, ulong counter @0x8, string @0x10.
// Used only as the key type so unity::dict computes the right entry stride for
// Dictionary<MongoID, TaskConditionCounter>. Shared definition with eft_api.h/quest_esp.h —
// guard avoids a redefinition error when both headers end up in the same translation unit.
#ifndef TARKOV_MONGO_ID_DEFINED
#define TARKOV_MONGO_ID_DEFINED
struct mongo_id
{
    unsigned int time_stamp;
    unsigned long long counter;
    void* string_id;
};
#endif

// The quest list, as the render thread is allowed to see it.
//
// It used to be three std::vectors that gameworld_update() cleared and refilled IN PLACE,
// read from the render thread with nothing but a non-atomic bool between them. Three
// consequences, in increasing order of how long they take to notice:
//
//   - a push_back reallocating under the render thread's read is reachable, and it read
//     Il2CppString* (GC-managed, collectable the instant the raid ends) off the render
//     thread;
//   - the three vectors are independent, so they can be momentarily out of STEP, which
//     pairs one quest's NAME with a DIFFERENT quest's id;
//   - and that id is what the game thread then summarises, so the checklist and the tally
//     become the wrong quest's, with nothing on screen to say so.
//
// QuestResetModule had the same read of the completed-quest pair, and guarded it with
// min(names.size(), ids.size()) -- which bounds the index but not the pairing, so it
// prevented an out-of-bounds read and nothing else.
//
// This is the hand-off HideoutModule already uses, for the same reason
// (HideoutModule.h:98-110): the game thread builds one of these per scan and the render
// thread holds a shared_ptr to whichever version it started with, so a version cannot be
// freed underneath a reader mid-frame. The Il2CppString* are converted to std::string on
// the game thread, which is where a managed pointer may be dereferenced at all.
struct quest_list_snapshot
{
    // Parallel vectors, and deliberately kept that way: the walk is index-driven, and three
    // separate vectors that are pushed to separately are exactly the out-of-step pairing
    // this type exists to remove. Reserve-then-assign per index, or push to all three in
    // one statement, so they cannot disagree.
    std::vector<std::string> names;
    std::vector<int> statuses;
    std::vector<std::string> ids;

    // The quest's runtime class name, for the localisation audit only. Not part of size():
    // it is a diagnostic, so a card that rendered correctly before it existed must keep
    // working if it is ever absent -- whereas names/statuses/ids are load-bearing and a
    // short one of those would mispair a name with an id.
    std::vector<const char*> classes;

    // Status 4 only, for the Quest Reset card's own picker.
    std::vector<std::string> completed_names;
    std::vector<std::string> completed_ids;

    [[nodiscard]] size_t size() const {
        return (std::min)(names.size(), (std::min)(statuses.size(), ids.size()));
    }
};

// The sentinel id behind the "All" dropdown entry.
//
// Empty rather than a magic string like "<all>", because a quest template id is 24 hex
// characters and can never be empty -- gameworld_update skips any quest whose get_Id()
// returns null, and the ids that do resolve are MongoIDs. So "" provably cannot collide
// with a real quest, where "<all>" would be one localization or data change away from
// doing so, silently, on the one entry whose collision would complete the wrong quest.
//
// It also REUSES the meaning "no quest is selected", which previously meant the card drew
// nothing. So this is not a new state; it is the existing empty state given a rendering.
inline constexpr const char* kAllQuestsId = "";

// What the Quest Completer card shows about the quest picked in the dropdown,
// plus a done/total tally for every quest in the list.
//
// Immutable once published. The game thread builds a new one per scan and the
// render thread holds a shared_ptr to whichever version it started with, so a
// version cannot be freed underneath a reader mid-frame -- the same hand-off
// HideoutModule uses, and for the same reason (HideoutModule.h:98-110).
// What the Quest Completer card shows about every quest in the list.
//
// Immutable once published. The game thread builds ONE per raid and the render thread holds
// a shared_ptr to it, so a version cannot be freed underneath a reader mid-frame -- the same
// hand-off HideoutModule uses, and for the same reason (HideoutModule.h:98-110).
//
// BUILT ONCE AT RAID ENTRANCE AND READ ONLY AFTERWARDS, which is the whole design and was
// arrived at the hard way (2026-10-04). The card used to refresh on a timer so the tick boxes
// would move while the player shot things; the game already shows its own objective progress,
// so the card only has to answer "what am I carrying". Three refresh mechanisms were tried and
// all three cost more than the feature was worth:
//
//   every 300 ms          647-quest walk, ~13,000 managed calls per second, forever
//   every 500 ms (All)    120 ms per publish once it had to read five quests that throw
//   every 2 s (All)       the same 120 ms, less often, still 25% of a core
//
// So there is no refresh, and the lifecycle is symmetric: build on the raid-entrance walk,
// dismantle on the raid-exit clear. What that costs is a stale tally within a raid, which is
// the trade the player chose and the reason this comment exists.
//
// ONE SOURCE OF TRUTH, which is the second thing this shape fixes. There used to be a
// single-quest `lines`/`done`/`total`, a round-robin `badges` map, and a separate `groups`
// vector for the All view -- three counters over the same data, which is how the header and
// the dropdown badge came to disagree. `groups` is now the only place any of it lives: the
// single-quest view looks its own group up in it, and the dropdown derives its tallies from
// it. A second counter cannot drift from the first if there is no second counter.
struct quest_objectives_snapshot
{
    // One entry per quest with at least one readable objective, in dropdown order.
    // Quests whose conditions yield nothing are OMITTED rather than shown as an empty
    // heading -- see all_unreadable for how that is reported rather than hidden.
    struct grouped_objective
    {
        std::string quest_id;
        std::string quest_name;
        std::vector<quest_objectives::objective> lines;
        int done = 0;
        int total = 0;

        // Where this quest can be done, read from its own conditions. See
        // quest_objectives::location_binding_of() -- in particular, the zones are the
        // game's internal ids and are deliberately NOT resolved against the current map.
        quest_objectives::location_binding location;

        // FALSE when the quest's conditions could not be walked at all. This is NOT the same
        // as `location.zone_bound == false`, which means "walked, and nothing named a zone":
        // one is unknown and the other is a real answer. Rendering them identically would
        // claim an unreadable quest is doable anywhere, which is how it gets picked for a
        // raid it cannot be completed on.
        bool known = false;

        // Whether the "done" column means anything. See quest_objectives::progress_readable().
        bool readable = true;
    };
    std::vector<grouped_objective> groups;

    // How many quests the build was asked to read, and how many it actually read. Both shown
    // on the card when they differ, because a short list that looks complete is worse than a
    // short one that admits it.
    int all_requested = 0;
    int all_shown = 0;

    // WHY the two above differ, because they differed for the wrong reason and the card said
    // so. all_requested > all_shown has two completely different causes:
    //
    //   the CAP bit      -- more listed quests than kAllQuestCap. Truncation, and the player
    //                       is being shown a subset on purpose.
    //   quests UNREADABLE -- collect_all() skips a quest whose conditions yield no rows at
    //                       all (quest_objectives.h:867), which is what a dormant quest does.
    //
    // On the profile measured on 2026-10-04 it was the second: 8 listed, 3 shown, cap 24, so
    // nothing was truncated -- five dormant SideQuests simply produced no rows. The card said
    // "Showing 3 of 8 quests. Use the search box for the rest", which is wrong twice: nothing
    // was truncated, and searching for those five finds rows that show nothing at all.
    //
    // So the cap message is now gated on all_capped, and the unreadable case gets its own
    // text. Reporting a shortfall without saying which kind is how a number stops being
    // evidence.
    bool all_capped = false;
    int all_unreadable = 0;
};

class QuestModule : Module
{
  public:
    // Note: quest_select (SelectValue) copies option strings into its own internal storage on
    // set_options() and returns pointers into that storage from get_options() — it owns that
    // memory, not us. Do NOT delete[] anything returned by get_options() here.
    ~QuestModule() override;

    QuestModule();

    TextboxValue* quest_search;
    SelectValue* quest_select;
    // The "All" view's backstop, as a number the player can move. 64 is the
    // default because it is roughly twice the largest active set observed on a
    // real profile (36 on 2026-10-08); the cap exists so a pathological profile
    // cannot make the raid-entrance build unbounded, and nobody has yet shown a
    // profile that reaches 64 -- which is exactly the case where the right
    // answer is a measurement of what reading a quest costs, not a larger
    // constant. The slider makes that visible instead of burying it in a
    // header, and its range bottoms out at 24, the constant this replaced.
    IntSliderEditableValue* quest_all_cap;
    ActionRowValue* complete;
    ActionRowValue* force_complete;
    ActionRowValue* revert;
    ActionRowValue* start;

    bool queue_unlock = false;
    bool queue_force_complete = false;
    bool queue_revert = false;
    bool queue_start = false;

    // ID of the quest selected at the moment the user clicked an action button.
    // Captured in the UI thread, consumed in the game thread. Matching by ID
    // avoids fragile display-name comparison that breaks when the list is refiltered.
    std::string pending_quest_id = {};

    // ID of the quest the dropdown is showing, for the objective checklist. Unlike
    // pending_quest_id this is not an action, it is a display: the game thread
    // needs to know which quest to summarise and it cannot ask, because reading
    // quest_select's value would race the render thread that owns it.
    //
    // Under a mutex rather than left as a bare std::string like pending_quest_id.
    // pending_quest_id is written once per click and read on the next scan, so a
    // torn read there is a narrow window; this one is written whenever the
    // selection moves and read every scan, and a std::string's buffer pointer is
    // exactly the kind of thing a half-finished assignment leaves dangling.
    // Contended once per scan, in single-digit microseconds.
    void set_selected_quest(const std::string& id);

    [[nodiscard]] std::string selected_quest() const;

    // Published quest list, built once per scan on the game thread and read by both
    // cards' render-side code. Never null: see objectives() for why "nothing published
    // yet" has to be a real empty state rather than a null to dereference.
    [[nodiscard]] std::shared_ptr<const quest_list_snapshot> quest_list() const;

    // The completed-quest pair the Quest Reset card shows. Reads the same published
    // list rather than QuestModule's own members, so the pairing cannot drift.
    [[nodiscard]] std::shared_ptr<const quest_list_snapshot> completed_quests() const { return quest_list(); }

    // Published objective state, read by draw_menu_extra and draw_overlay.
    std::atomic<std::shared_ptr<const quest_objectives_snapshot>> objectives_published_;
    std::atomic<std::shared_ptr<const quest_list_snapshot>> list_published_;
    [[nodiscard]] std::shared_ptr<const quest_objectives_snapshot> objectives() const;

    // The status line under the buttons. Written by the action buttons on the render
    // thread AND by the game thread when it refuses an action ("cannot complete story
    // quests"), so it needs the same treatment as selected_quest_id_: a bare std::string
    // assigned from two threads hands the reader a buffer pointer mid-reallocation.
    void set_completion_status(const std::string& text);
    [[nodiscard]] std::string completion_status() const;

    // Game-thread-only. Objectives per quest id, so a tally survives a rescan
    // of the quest list instead of blanking whenever the detail moves.

    void complete_impl();

    void force_complete_impl();

    void revert_impl();

    void start_impl();

    // Shared refusal for the four action buttons when the "All" summary is selected. See
    // the definition for why bulk-completion is not offered rather than merely guarded.
    void refuse_all_selection();

    std::atomic<bool> names_lock{false};

    // The real exclusion for the scan-and-publish section, as distinct from names_lock
    // above, which only ever SKIPS.
    //
    // Why both exist, because the pair is not obvious: names_lock is an exchange, and an
    // exchange between the two game-thread paths is already correct exclusion that never
    // blocks a frame. What it cannot express is a caller that must NOT be skipped --
    // QuestModule::draw_overlay's raid-boundary clear, where skipping means leaving the
    // previous raid's Il2Cpp pointers alive into the next one, which is the use-after-free
    // that clear exists to prevent. So the boundary takes this instead and waits.
    //
    // It is mutable because the render thread's boundary path locks it while the two
    // game-thread paths hold it via a non-const guard.
    //
    // Added 2026-10-04 with the boundary clear that needed it. Before this, that clear ran
    // with neither, and the container it destroys -- listed_quests_ -- is the one
    // publish_progress walks on every tick.
    mutable std::mutex names_mutex_;
    std::vector<std::string> filtered_quest_ids = {};  // IDs in current filtered UI list
    std::string completion_status_ = {};

    void prepare_menu_draw() override;

    void draw_menu_extra() override;

    // The "All" selection's body: one group per quest. Render-thread only, and reads only
    // the snapshot it is handed -- never listed_quests_ or any Il2Cpp pointer, which are
    // game-thread-owned and raid-scoped.
    void draw_all_objectives(const quest_objectives_snapshot& snap, float scale_factor);

    // Reports whether the dropdown can be showing unlocalized strings: the game's
    // Localized() returns the KEY ITSELF on a miss, so "5dabf25c51e0590000000000 name" is
    // both a plausible quest name and a raw locale key, and nothing on screen tells them
    // apart. Once per raid, per-quest detail gated on logger::debug_enabled().
    //
    // Game thread, at the end of a scan. Reads only its argument.
    void audit_name_localisation(const quest_list_snapshot& list);

    // Re-run the per-quest audit. The summary above logs once per process; this clears that
    // latch so a later scan can report again, which is what makes it possible to watch the
    // names CHANGE -- a key that resolves once the locale table finishes loading is the
    // expected shape of a transient false positive, and a latch would hide exactly that.
    void reaudit_names() {
        name_audit_summary_logged_ = false;
        name_problems_reported_.clear();
    }

    // One detail line per distinct (quest, finding). The latch is what makes this a
    // diagnostic rather than a flood; the debug_enabled() gate alone does not, because that
    // is a user setting rather than a rate limit.
    void report_name_problem(const std::string& id, const std::string& name, int status,
        bool blank, bool raw_key, bool key_valid, const char* class_name);

    void revert_completed_from_picker(const std::string& quest_id);

    static std::string status_prefix(int s);

    void draw_overlay(ImDrawList* draw_list) override;

    void application_update() override;

    ULONGLONG quest_scan_last_ms_ = 0;
    // NO REFRESH INTERVAL, and its absence is the design. There were three of these and all
    // three are gone, along with the code they governed:
    //
    //   quest_scan_interval_ms = 300   governed the 647-quest LIST walk -- ~13,000 managed
    //                                 calls per second, forever, to re-read a list that only
    //                                 changes when the player acts on a quest. Replaced by
    //                                 once-per-raid + a request flag on every SetStatus.
    //   kProgressIntervalMs = 500      kept the SELECTED quest's tick boxes moving. Redundant:
    //                                 the game shows its own objective progress.
    //   kAllIntervalMs = 2000          served the All view. Measured at 120 ms per publish
    //                                 x 998 publishes = 119.99 s of a 499 s session.
    //
    // So there is no per-frame quest work at all now. build_snapshot() runs once at raid
    // entrance; draw_overlay() dismantles it at raid exit. See quest_objectives_snapshot for
    // what that trades, and application_update() for the empty override it left behind.


    // Set by the four SetStatus call sites to say "the quest set changed". Consumed by the
    // next gameworld_update. Atomic because the requesters include render-thread button
    // handlers and the consumer is the game thread.
    std::atomic<bool> quest_list_refresh_requested_{true};

    // The selection the last progress publish was for, so a selection change is re-read at
    // once instead of waiting out the interval.

    // True when a button action is queued and the game thread must not skip its tick.
    [[nodiscard]] bool action_pending() const;

    // Asks for the quest list to be re-walked on the next gameworld_update. Called by
    // every SetStatus in QuestModule.cpp and by nothing else -- that is what makes
    // once-per-raid correct rather than merely cheap.
    void refresh_quest_list();

    // Reads every listed quest's conditions and publishes the whole card as ONE immutable
    // snapshot. Called once per raid, from the list walk. There is no refresh path: see the
    // lifecycle note on quest_objectives_snapshot and on application_update().
    //
    // AMORTIZED ACROSS FRAMES since 2026-10-11 -- see begin_snapshot_build() /
    // step_snapshot_build() for why, and for why it is not a thread.
    void build_snapshot();

    // --- amortized build -------------------------------------------------
    //
    // WHAT THIS IS. build_snapshot() used to read all ~43 quests' conditions in ONE
    // gameworld_update. Measured on 2026-10-11 that is a 332 ms hitch
    // ("esp-slow-frame[1/6]: gameworld_update total=332647us") at raid entrance, and on both
    // GameAssembly crashes of that night the quest condition reads ("condition read failed",
    // 36 of them spanning 22:59:52 -> 23:00:01) sat in the same window as the fault.
    //
    // WHY NOT A THREAD, which is the obvious next suggestion and was considered. This work is
    // managed IL2CPP: collect_all() calls get_Conditions, IsConditionDone, get_CurrentValue
    // and get_FormattedDescription through methodPointer on LIVE quest objects
    // (quest_objectives.h:278). Those Il2CppObject* are raid-scoped and the game is free to
    // mutate or free them, so the reads cannot move off the game thread.
    //
    // game_item_db::prewarm DOES run managed calls on a detached thread and is the precedent
    // for going async here, but its call is safe for a specific reason that does not carry
    // over: try_localize_key() touches a process-lifetime SINGLETON
    // (LocalizationManager.get_Instance, re-validated with is_il2cpp_object_strict on every
    // call -- eft_api.h:6781) and passes a FRESHLY ALLOCATED Il2CppString
    // (il2cpp_string_new -- eft_api.h:6863). It holds no pointer into mutable game state.
    // The quest read holds 43 of them, all live. Same API, different safety property.
    //
    // SO: same thread, less work per tick. The game_item_db shape that DOES transfer is the
    // publish discipline -- enumerate into a local, hand over an immutable snapshot under a
    // lock, never mutate a published one -- and that is preserved exactly.
    //
    // Per tick this reads at most kQuestsPerBuildTick quests, so the worst tick is
    // 332 ms / 43 spread out rather than concentrated. The card shows nothing until the
    // build completes, which is the same thing it already did (objectives_published_ is only
    // stored once, at the end), so this changes no visible behaviour.
    void begin_snapshot_build();
    void step_snapshot_build();
    [[nodiscard]] bool snapshot_build_in_flight() const { return build_active_; }

    // How many quests one gameworld_update reads. 4 keeps the added-up cost of the build
    // inside a few frames at the ~40-quest late-wipe profile the cap is sized for, while
    // staying far under the 16 ms frame the slow-frame warning fires at.
    static constexpr size_t kQuestsPerBuildTick = 4;

    // True between begin_snapshot_build() and the publish inside step_snapshot_build().
    // Game-thread-only, exactly like listed_quests_, for the same reason: the in-progress
    // cursor indexes all_quest_inputs_, which holds live Il2Cpp quest pointers.
    bool build_active_ = false;
    size_t build_cursor_ = 0;
    std::shared_ptr<quest_objectives_snapshot> build_target_;
    std::vector<quest_objectives::quest_group> build_collected_;

    void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
        Il2CppObjectInstance main_player) override;

    void init() override;

  private:
    mutable std::mutex selection_mutex_;
    std::string selected_quest_id_ = {};

    mutable std::mutex status_mutex_;
    std::string completion_status_storage_ = {};

    // Latch for the localisation audit's once-per-process summary, cleared by reaudit_names().
    // A function-local static would outlive this module and survive a raid boundary, which
    // is wrong for a diagnostic whose whole point is to be re-runnable against new data.
    bool name_audit_summary_logged_ = false;

    // Per-(quest, finding) latch for the audit's DETAIL lines. Without it the detail repeats
    // on every 300 ms scan whenever the Debug Log is on: measured 1,800 lines from one raid
    // on 2026-10-04. Cleared at the raid boundary with the summary latch, because both
    // describe one raid's data.
    std::unordered_set<std::string> name_problems_reported_;

    // Renders the groups whose location binding is `zone_bound`, or all of them when the
    // argument is nullopt (the "could not read the conditions" pass). One loop per section
    // rather than three copies of the block, because three copies drift.
    //
    // std::optional rather than a bool plus a flag: "render zone-bound", "render
    // not-zone-bound" and "render all" are three distinct meanings, and a bool plus a
    // sentinel for the third is the shape where the sentinel quietly becomes a fourth.
    void draw_objective_groups(const std::vector<quest_objectives_snapshot::grouped_objective>& groups,
        std::optional<bool> zone_bound, float scale_factor);

    // Quest ids listed in the dropdown at the last scan, in dropdown order, with
    // the Il2Cpp quest object each one was read from.
    //
    // Game-thread-only, and it exists so the badge pass can be spread over
    // several scans instead of running over every listed quest at once. It is
    // repopulated from scratch on every scan and never read on the render
    // thread, so the Il2Cpp pointers in it do not outlive the scan that put
    // them there -- see the raid-boundary comment in gameworld_update.
    struct listed_quest
    {
        std::string id;
        Il2CppObject* quest = nullptr;
    };
    std::vector<listed_quest> listed_quests_ = {};

    // Reused across the round-robin badge pass so one quest per scan does not allocate
    // a vector per scan. Game-thread-only; quest_objectives::summarise clears it.

    // id + quest pointer for every listed quest, for the "All" pass. Rebuilt per scan
    // alongside listed_quests_, in the SAME order, because collect_all() reads the first
    // kAllQuestCap of it and that subset has to be the quests the dropdown shows first.
    std::vector<std::pair<std::string, Il2CppObject*>> all_quest_inputs_;
};
