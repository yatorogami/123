#pragma once

#include "../game_state.h"
#include "../Module.h"
#include "../ModuleCategory.h"
#include "../QueuedAction.h"
#include "../skeleton_visibility.h"
#include "../../config/ActionRowValue.h"
#include "../../config/CheckboxValue.h"
#include "../../config/FloatSliderEditableValue.h"
#include "../../config/MenuSectionValue.h"
#include "../../il2cpp/il2utils.h"
#include "../../il2cpp/unity.h"
#include "../../util/globals.h"
#include "../../util/logger.h"
#include "WeaponModule.h"

#include <format>
#include <string>

class DoorsModule : public Module
{
  public:
    DoorsModule();

    MenuSectionValue* section_doors_;
    ActionRowValue* unlock_doors;
    CheckboxValue* always_breach_door;
    // Interactable opener (Magical Hand L2b): the locked WorldInteractiveObject the
    // crosshair rests on is force-unlocked (Locked(1) -> Closed(2)) so the game offers
    // the normal F interaction — doors unlock as you look at them. Lives here next to
    // the bulk unlock button per user request (verified working in-game 2026-09-24).
    // Config keys kept from the old PlayerModule "Magical Hand" section so existing
    // settings persist.
    CheckboxValue* bypass_interaction_check;
    FloatSliderEditableValue* unlock_ray_range;

    void application_update() override;

    void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance,
        Il2CppObjectInstance) override;

    void draw_overlay(ImDrawList*) override;
    void init() override;

  private:
    QueuedAction unlock_doors_action_;
    static inline ULONGLONG g_last_unlock_ray_ms = 0;

    void unlock_doors_impl();

    // L2b raycast unlock. ISIL-verified context (Workstream #11 / SOLVED #18):
    // EDoorState 1 = Locked, 2 = Closed, 4 = Open, 8 = interaction-busy;
    // CanStartInteraction is only on the network-sync path; the real local gate
    // is InteractionContextHelper.GetAvailableActions, which demands a key only
    // when DoorState == 1. So: raycast -> WIO -> Locked(1) -> set_DoorState(2)
    // and the game itself offers the plain F Open. BTR/vehicle doors are outside
    // WorldInteractiveObject entirely — out of scope.
    void apply_interaction_unlock();
};
