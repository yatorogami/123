#pragma once
#include "../Module.h"
#include "../ModuleCategory.h"
#include "../eft_api.h"
#include "../game_state.h"
#include "../../config/CheckboxValue.h"
#include "../../config/ColorpickerValue.h"
#include "../../config/FloatSliderEditableValue.h"
#include "../../config/IntSliderEditableValue.h"
#include "../../config/MenuSectionValue.h"
#include "../../gui/menu/menu.h"
#include "../../util/i18n.h"

class AmmoHudModule : Module
{
  public:
    AmmoHudModule();

    CheckboxValue* enabled;
    ColorpickerValue* color;
    IntSliderEditableValue* font_size;

    MenuSectionValue* section_layout_;
    FloatSliderEditableValue* pos_x;
    FloatSliderEditableValue* pos_y;

    void init() override;

    void prepare_menu_draw() override;

    void draw_menu_extra() override;

    void draw_overlay(ImDrawList* draw_list) override;

    void application_update() override;

    void gameworld_update(const Il2CppClass* /*game_world_class*/, Il2CppObjectInstance /*game_world_instance*/,
        Il2CppObjectInstance main_player) override;

  private:
    eft_api::weapon_ammo_state cached_{};
};