#include "common.h"
#include "QuestModule.h"

// Note: quest_select (SelectValue) copies option strings into its own internal storage on
// set_options() and returns pointers into that storage from get_options() — it owns that
// memory, not us. Do NOT delete[] anything returned by get_options() here.
QuestModule::~QuestModule() {
}

using Il2CppObjectPtr = Il2CppObject*;
using Il2CppStringPtr = Il2CppString*;

// The scan-and-publish critical section, with a release that cannot be skipped.
//
// names_lock used to be a bare bool cleared by three hand-placed assignments, one at the
// bottom of a 540-line function. Everything between the set and the clear -- including
// publish_objectives(), which makes unguarded managed calls into IsConditionDone and
// get_CurrentValue -- sat inside it. Anything that unwound past that last line left the
// flag set, and BOTH callers then returned on their first line for the rest of the raid:
// gameworld_update stopped rescanning, and draw_overlay stopped calling set_selected_quest.
// The dropdown, the tally and the checklist all froze on their last values, silently and
// permanently, because from the code's point of view every step had succeeded.
//
// The flag is atomic so the check-and-set cannot interleave either -- as a plain bool, both
// threads could pass `if (names_lock)` before either wrote, and then the render thread would
// walk the vectors the game thread is refilling. That guard never excluded anything; it only
// narrowed the window. Excluding properly needs more than an atomic (it needs the readers to
// wait rather than skip), and that is a separate change -- but the flag being atomic is a
// precondition for it and costs nothing here.
//
// THAT PRECONDITION IS NOW SPENT, and this is the separate change (2026-10-04).
//
// A skip-guard is not a lock, and three call sites all looked guarded because each one took
// the flag, which is how the one that did not -- draw_overlay's raid-boundary clear -- went
// unnoticed for so long. Two threads could both be inside the section at the same time: the
// game thread inside publish_progress's walk of listed_quests_, and the render thread
// destroying it. names_mutex_ is the actual exclusion, and the flag remains as a re-entrancy
// tripwire: a thread that arrives while the section is busy returns immediately rather than
// queueing, which is what keeps a game-thread Update from ever blocking on a render-thread
// frame. Only the raid-boundary clear WAITS, because skipping there means keeping the previous
// raid's Il2Cpp pointers alive into the next one.
//
// Both, deliberately. try_lock is what the two hot paths use -- they have a per-frame budget
// and losing a frame is free -- and lock() is what the boundary uses, because that one must
// not be skipped. A guard that silently drops the clearing on contention would reintroduce the
// use-after-free it exists to prevent.
namespace {
    struct scan_guard
    {
        std::atomic<bool>& flag;
        // Held for the section's duration. This is what makes the raid-boundary
        // clear safe; it is deliberately NOT what keeps the two game-thread paths
        // apart, because the exchange in front of them already does that without
        // ever blocking a frame.
        std::unique_lock<std::mutex> held;
        explicit scan_guard(std::atomic<bool>& f, std::mutex& m) : flag(f), held(m) {
            flag.store(true);
        }
        scan_guard(const scan_guard&) = delete;
        scan_guard& operator=(const scan_guard&) = delete;
        ~scan_guard() { flag.store(false); }
    };
} // namespace

QuestModule::QuestModule() : Module("Quest Completer", QuestCompleter, "quest_completer_mod"),
                             quest_search(conf(new TextboxValue("", "quest_search_txt"))),
                             quest_select(conf(new SelectValue(0, {}, "quest_active_sel", true, true))),
                             quest_all_cap(conf(new IntSliderEditableValue(
                                 static_cast<int>(quest_objectives::kAllQuestCap), 24, 256,
                                 "quest_all_cap_slider"))),
                             complete(conf(new ActionRowValue([&] {
                                 complete_impl();
                             },
                                 "quest_complete_btn"))),
                             force_complete(conf(new ActionRowValue([&] {
                                 force_complete_impl();
                             },
                                 "quest_force_complete_btn"))),
                             revert(conf(new ActionRowValue([&] {
                                 revert_impl();
                             },
                                 "quest_revert_btn"))),
                             start(conf(new ActionRowValue([&] {
                                 start_impl();
                             },
                                 "quest_start_btn"))) {
    objectives_published_.store(std::make_shared<const quest_objectives_snapshot>());
    list_published_.store(std::make_shared<const quest_list_snapshot>());
}

void QuestModule::set_selected_quest(const std::string& id) {
    std::lock_guard<std::mutex> lock(selection_mutex_);
    selected_quest_id_ = id;
}

std::string QuestModule::selected_quest() const {
    std::lock_guard<std::mutex> lock(selection_mutex_);
    return selected_quest_id_;
}

void QuestModule::set_completion_status(const std::string& text) {
    std::lock_guard<std::mutex> lock(status_mutex_);
    completion_status_storage_ = text;
}

std::string QuestModule::completion_status() const {
    std::lock_guard<std::mutex> lock(status_mutex_);
    return completion_status_storage_;
}

std::shared_ptr<const quest_list_snapshot> QuestModule::quest_list() const {
    // Same reasoning as objectives() below: both readers index into what they get, so
    // "nothing published yet" has to be an empty state rather than a null.
    if (std::shared_ptr<const quest_list_snapshot> current = list_published_.load())
        return current;
    return std::make_shared<const quest_list_snapshot>();
}

std::shared_ptr<const quest_objectives_snapshot> QuestModule::objectives() const {
    // Never null for the same reason HideoutModule's snapshot() is not: every
    // reader does `objectives()->field`, so "nothing published yet" has to be a
    // real empty state rather than a null to dereference. The constructor seeds
    // one, which is what the first application_update (before any scan has run)
    // reads.
    if (std::shared_ptr<const quest_objectives_snapshot> current = objectives_published_.load())
        return current;
    return std::make_shared<const quest_objectives_snapshot>();
}

// The action buttons reject the "All" selection rather than acting on it.
//
// pending_quest_id would be kAllQuestsId, which is not a quest: gameworld_update matches it
// against every real template id and finds nothing, so the flag would sit as a pending
// action against a string no quest owns and be cleared at the end of the scan having done
// nothing. The button would appear to work. That is the "silently does nothing" failure
// mode the rest of this card has been fighting, so it is refused explicitly and says why.
//
// Completing every quest at once is a genuinely destructive bulk operation -- it hands in
// story quests and marks placement conditions complete -- so it is not offered here at all.
// If it is ever wanted it needs its own confirmation, not a side effect of a dropdown
// defaulting to "All".
void QuestModule::refuse_all_selection() {
    set_completion_status(i18n::tr("quest_all_no_action"));
    logger::warn("quest actions: refused, the All summary is not a quest and cannot be "
        "completed, reverted or started");
}

void QuestModule::complete_impl() {
    if (!game_state::is_in_raid) return;
    const int idx = quest_select->get_value();
    if (idx >= 0 && idx < (int)filtered_quest_ids.size())
        pending_quest_id = filtered_quest_ids[idx];
    if (pending_quest_id == kAllQuestsId) {
        pending_quest_id.clear();
        refuse_all_selection();
        return;
    }
    queue_unlock = true;
}

void QuestModule::force_complete_impl() {
    if (!game_state::is_in_raid) return;
    const int idx = quest_select->get_value();
    if (idx >= 0 && idx < (int)filtered_quest_ids.size())
        pending_quest_id = filtered_quest_ids[idx];
    if (pending_quest_id == kAllQuestsId) {
        pending_quest_id.clear();
        refuse_all_selection();
        return;
    }
    if (!pending_quest_id.empty())
        set_completion_status("Force completion queued for the selected quest.");
    queue_force_complete = true;
}

void QuestModule::revert_impl() {
    if (!game_state::is_in_raid) return;
    const int idx = quest_select->get_value();
    if (idx >= 0 && idx < (int)filtered_quest_ids.size())
        pending_quest_id = filtered_quest_ids[idx];
    if (pending_quest_id == kAllQuestsId) {
        pending_quest_id.clear();
        refuse_all_selection();
        return;
    }
    logger::info("Revert queued for quest id: " + pending_quest_id);
    queue_revert = true;
}

void QuestModule::start_impl() {
    if (!game_state::is_in_raid) return;
    const int idx = quest_select->get_value();
    if (idx >= 0 && idx < (int)filtered_quest_ids.size())
        pending_quest_id = filtered_quest_ids[idx];
    if (pending_quest_id == kAllQuestsId) {
        pending_quest_id.clear();
        refuse_all_selection();
        return;
    }
    queue_start = true;
}

// ---------------------------------------------------------------- name reporting
//
// THE STATE OF THIS, because the first version of it was wrong in a way worth recording.
//
// It shipped as: per-quest detail gated on logger::debug_enabled(), plus a summary latched
// once per raid. That gate is a mistake. logger::debug_enabled() is a user setting for the
// Debug Log card, not a diagnostic rate limit, and when it is ON -- which it is by default
// for anyone debugging -- every suspect quest printed on EVERY 300 ms scan. Measured on
// 2026-10-04: 1 summary line and **1,800 detail lines** from a single raid, six quests
// reported five times a second for the whole raid. That is the log-flood failure
// AGENTS_TODO.md §1.5 already records this project committing once (11,903 ERROR lines,
// 85% of one session), and it was introduced here deliberately.
//
// A toggle answers "may I say anything"; a latch answers "have I said this". Both are
// needed, and the latch is the one that was missing.
//
// The latch is keyed on the quest id AND the finding, so a quest whose name CHANGES -- the
// locale table finishing its load, a quest starting -- is reported again, because a name
// going from blank to real is exactly the transition worth seeing and a permanent latch
// would hide it.
void QuestModule::report_name_problem(const std::string& id, const std::string& name,
    const int status, const bool blank, const bool raw_key, const bool key_valid,
    const char* class_name) {
    if (!logger::debug_enabled()) return;

    // Keyed on everything that can change, so a repeat only happens when something did.
    const std::string key = id + "|" + name + "|" + std::to_string(status)
        + "|" + (blank ? "b" : "-") + (raw_key ? "r" : "-") + (key_valid ? "v" : "-");
    if (!name_problems_reported_.emplace(std::move(key), true).second) return;

    logger::debug("quest name: id=" + id + " status=" + std::to_string(status)
        + " name='" + name + "'"
        + " blank=" + (blank ? "yes" : "no")
        + " raw_key=" + (raw_key ? "YES" : "no")
        + " key_valid=" + (key_valid ? "yes" : "NO")
        + " class=" + std::string(class_name ? class_name : "?"));
}

// ---------------------------------------------------------------- localisation audit
//
// WHY THIS EXISTS. The card shows quest names, and a name reaches the dropdown by this
// route (QuestTemplate.txt / LocalizationExtensions.txt ISIL):
//
//   Quest.get_Name()        -> QuestTemplate.get_Name()
//   QuestTemplate.get_Name()-> LocalizationExtensions.Localized(get_NameLocaleKey())
//
// and TWO separate things can go wrong on it:
//
//  1. get_NameLocaleKey() returns `Id + " name"` when `_questName` is null or empty, and
//     `_questName` otherwise. (Note the machine code, not the ISIL prose: the ISIL labels
//     the branches the other way round and I read it wrong the first time -- `test al,al /
//     je` means the IsNullOrEmpty TRUE path falls THROUGH to String.Concat.)
//  2. Localized(id, prefix) returns THE KEY ITSELF when the key is not in the locale table.
//     Disassembly: `call LocalizedValue ... ; Return returnVal1` with no fallback, and
//     LocalizedValue's own head is `IsNullOrEmpty(id) -> if true, return id`.
//
// So a dropdown row can be showing "5dabf25c51e0590000000000 name" -- a raw locale key --
// and it looks like a quest name because it is a plausible-looking string. That is
// indistinguishable from a real name by eye, which is why it needs a probe rather than an
// opinion, and why the earlier "blank rows" explanation was incomplete: blank was ONE
// symptom of the same chain.
//
// WHAT IS LOGGED, per quest, once per raid:
//   - the raw name, and whether it IS its own locale key (name == "<id> name")
//   - whether the game's own HasValidLocalization says the key resolves
//   - the class name, because the fallback exists per quest TEMPLATE type
//
// Gated on logger::debug_enabled() AND latched per (quest, finding), so the detail costs
// one line per distinct problem per raid rather than one per problem per scan. An
// unconditional one-shot SUMMARY per raid means "no output" is still an answer rather than
// an ambiguity -- see report_name_problem for why the toggle alone was not enough.
//
// WHAT IT FOUND on 2026-10-04, which is not what the code expected to find:
//
//   647 quests, 45 with a BLANK name, 0 showing a raw locale key.
//
// So the "unlocalized string" theory is DISPROVED for this profile: no row is showing a
// locale key. What is there instead is a set of quests whose name is empty even though
// `HasValidLocalization("<id> name")` returns TRUE -- every one of them class=SideQuest.
// The game resolves the key and then returns nothing, which is a different defect in a
// different place than the fallback this audit was written to look for, and it is why the
// two are counted and reported separately: "raw_key" and "blank" are not the same failure.
//
// NOT A DEFECT EITHER, on the evidence: these are quests that are not running -- dormant
// holiday-event entries, or ones removed and left in the database -- whose status field
// still reads 2. That accounts for the empty name AND for the per-condition non-std throw
// that always accompanies them. The full account, the SideQuest-is-an-empty-subclass point
// that rules out a class-specific cause, and the ObjectId dates that put two of them in
// Halloween 2025 are in the `stale` note in gameworld_update, where the count is reported.
// This audit still runs because it is what FOUND them, not because it is still unexplained.
//
// WHY has_valid_localization() IS NOW GATED ON THE TOGGLE (2026-10-11). It used to be
// called unconditionally for every active quest -- 43 managed IL2CPP calls plus 43 string
// allocations per list walk on the measured profile -- while the only thing the debug toggle
// actually suppressed was the OUTPUT. The gate was in the wrong place: it sat at the top of
// report_name_problem, which is called from the BOTTOM of the loop below, so the loop had
// already paid for every call by the time anything checked. That is the anti-pattern
// WORKFLOW.md names for logger::debug: "it is a no-op when the toggle is off, but the
// argument is still built by the caller every frame".
//
// The counter that needs no managed call is still counted with the toggle OFF, deliberately:
// `blank` is a pure string test over the whole list, and it is the finding this audit exists
// to report (see the 2026-10-04 result above -- 45 blank names, and the raw-key theory
// DISPROVED). Everything else -- raw_keys, and the three counters that consume key_valid --
// is dropped with the toggle off, and the summary NAMES that absence rather than printing
// zeros that would read as a measured "nothing unresolvable".
void QuestModule::audit_name_localisation(const quest_list_snapshot& list) {
    // One read of the toggle for the whole walk, so the gate cannot drift between the count
    // and the summary.
    const bool probe_localisation = logger::debug_enabled();

    size_t blank = 0;
    size_t raw_keys = 0;
    size_t valid = 0;
    size_t unresolvable = 0;
    // Blank AND key_valid: the game HAS the translation and returns nothing anyway. Counted
    // separately because it is the finding this audit actually turned up, and folding it
    // into "blank" would hide the distinction that matters -- a missing translation is a
    // data problem we cannot fix, and a resolved-but-empty one is a read problem we might.
    size_t blank_despite_valid = 0;

    for (size_t qi = 0; qi < list.size(); ++qi) {
        const std::string& name = list.names[qi];
        const std::string& id = list.ids[qi];
        const int status = list.statuses[qi];

        const bool is_blank = name.empty();
        if (is_blank) ++blank;   // whole-list, no probe needed -- the headline finding

        // THE GATE, placed before the key is built rather than after. is_raw_key needs
        // `expected_key`, but building it costs an allocation per quest, and with the toggle
        // off that allocation would be paid 84 times to compute a counter that feeds a clause
        // the summary does not print.
        //
        // So with the toggle OFF the walk stops here: zero managed calls, zero key
        // allocations, and `blank` still counted. With it ON, everything below runs exactly
        // as it did before this change.
        //
        // (Before the gate the loop body was: build key, count blank, count raw_key, skip
        // inactive, CALL HasValidLocalization. The toggle was checked in report_name_problem,
        // which runs at the BOTTOM -- so every managed call was already paid for.)
        if (!probe_localisation) continue;

        // The key this quest WOULD use, built the way get_NameLocaleKey builds it:
        // Id + " name" (QuestTemplate.txt ISIL, String.Concat(this.Id, " name")).
        const std::string expected_key = id + " name";

        const bool is_raw_key = !name.empty() && name == expected_key;
        if (is_raw_key) ++raw_keys;

        // Only the ACTIVE quests are of interest: those are the ones the dropdown shows.
        if (status != 2 && status != 3) continue;

        // The game's own answer to "does this key resolve?", rather than our guess at it.
        // LocalizationManager.HasValidLocalization(string) is an instance method, so it
        // needs the singleton, which is why this is not a pure string test.
        const bool key_valid = eft_api::has_valid_localization(expected_key);
        if (key_valid) ++valid;
        else ++unresolvable;
        if (is_blank && key_valid) ++blank_despite_valid;

        // The status gate is ABOVE this point already, so only quests the dropdown can show
        // are reported -- otherwise the blank-name counts would be dominated by locked and
        // completed quests that are never listed.
        if (!is_blank && !is_raw_key && key_valid) continue;  // nothing to say

        report_name_problem(id, name, status, is_blank, is_raw_key, key_valid,
            qi < list.classes.size() ? list.classes[qi] : nullptr);
    }

    // Once per raid. Unconditional, because a silent audit is indistinguishable from an
    // audit that never ran -- and this is the difference between "the dropdown is fine" and
    // "nothing looked at the dropdown".
    if (name_audit_summary_logged_) return;
    name_audit_summary_logged_ = true;

    // The counters fed by the probe exist only when it ran. Printing them as 0 when the
    // toggle was off would be worse than printing nothing: "0 active quests have an
    // unresolvable locale key" reads as a measured clean bill of health, and it would be a
    // LIE, because nothing was asked. So they are omitted and their absence is named --
    // `raw_keys` included, which is also only counted below the gate now.
    //
    // `blank` and the list size are always real: string tests over the list, made above the
    // gate. So the summary still reports the finding this audit exists to produce.
    std::string summary = "quest name audit: " + std::to_string(list.size()) + " quests, "
        + std::to_string(blank) + " with a blank name";
    if (probe_localisation) {
        summary += " (" + std::to_string(blank_despite_valid)
            + " of them despite a VALID locale key), "
            + std::to_string(raw_keys) + " showing their raw locale key, "
            + std::to_string(unresolvable) + " of " + std::to_string(valid + unresolvable)
            + " active quests have an unresolvable locale key";
    }
    else {
        // Adjacent literals only -- `"a" + "b"` is pointer arithmetic, not concatenation,
        // so these are three separate `+=` rather than one `+` chain. C2110 at compile.
        summary += " (locale validity NOT probed -- it is one managed call per active quest,";
        summary += " so it runs only with the Debug Log enabled; enable it for the resolved/";
        summary += "unresolved split, the raw-key count and the per-quest lines)";
    }
    logger::info(summary);
}

void QuestModule::prepare_menu_draw() {
    // Force Complete is intentionally exposed separately from normal
    // completion: it also marks placement/beacon conditions as complete.
    force_complete->set_hidden_in_owner_menu(false);
    revert->set_hidden_in_owner_menu(true);
    start->set_hidden_in_owner_menu(true);
}

// One objective row: a tick box, the text, and the count right-aligned.
static void draw_objective_row(const quest_objectives::objective& line, const float sf) {
    // The count column is reserved rather than measured, so a row's text does not
    // jump sideways as its number changes width between "1/10" and "12/10".
    char count[24];
    if (line.has_count) {
        const int current = line.current < line.target ? line.current : line.target;
        snprintf(count, sizeof(count), "%d/%d", current, line.target);
    }
    else {
        count[0] = '\0';
    }

    const ImVec4 box_colour = line.done ? menu::palette::accent2 : menu::palette::muted;
    ImGui::TextColored(box_colour, "[%s]", line.done ? "x" : " ");
    ImGui::SameLine(0.f, 5.f * sf);

    const float count_width = count[0] ? ImGui::CalcTextSize(count).x + 8.f * sf : 0.f;
    ImGui::PushTextWrapPos(ImGui::GetContentRegionAvail().x - count_width);
    ImGui::TextUnformatted(line.text.c_str());
    ImGui::PopTextWrapPos();

    if (count[0]) {
        // SameLine after a wrapped TextUnformatted resumes at the wrap position's
        // right edge, not the line's own end, so the count is placed from the
        // window's right edge instead of being appended.
        ImGui::SameLine(0.f, 8.f * sf);
        ImGui::TextColored(line.done ? menu::with_alpha(menu::palette::accent2, 0.75f)
                                     : menu::palette::muted,
                           "%s", count);
    }
}

// The "All" view: every listed quest's objectives, one group per quest.
//
// Drawn here rather than in the menu because it is the same rows, the same tick boxes and
// the same counts -- only the heading differs. Reusing draw_objective_row() is the point:
// a second renderer for the same data would drift from the first, and the drift would show
// up as "the total does not match the rows" on one view and not the other, which is the
// class of bug this card has already produced once.
// Draws the groups matching `zone_bound`, or every group when it is nullopt -- which is the
// "unreadable" pass. Split out so the three sections are one loop each rather than three
// copies of a block that has to stay in step.
//
// A separate loop per section rather than one loop over all groups: the section headings
// have to appear BETWEEN sections, and interleaving them would mean testing membership
// twice per group anyway.
void QuestModule::draw_objective_groups(
    const std::vector<quest_objectives_snapshot::grouped_objective>& groups,
    const std::optional<bool> zone_bound, const float sf) {
    for (const quest_objectives_snapshot::grouped_objective& group : groups)
    {
        if (zone_bound.has_value() && group.location.zone_bound != *zone_bound) continue;

        // Pushed by ID rather than by name: two quests CAN share a display name, and an
        // ImGui ID collision between two groups makes one of them unclickable and both of
        // them share hover state. The template id is unique where the name is not.
        ImGui::PushID(group.quest_id.c_str());
        ImGui::TextColored(menu::palette::accent, "%s", group.quest_name.c_str());
        {
            char group_tally[24];
            snprintf(group_tally, sizeof(group_tally), "%d/%d", group.done, group.total);
            ImGui::SameLine(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x
                - ImGui::CalcTextSize(group_tally).x);
            ImGui::TextColored(menu::palette::muted, "%s", group_tally);
        }

        // The zones, when there are any. These are the game's internal zone identifiers and
        // are deliberately NOT matched against the current location -- see
        // location_binding_of() for why deciding that mapping here would put quests in the
        // wrong group. Shown so the player can see WHY a quest is in this section.
        if (group.location.zone_bound && !group.location.zones.empty()) {
            std::string zones = group.location.zones.front();
            for (size_t zi = 1; zi < group.location.zones.size() && zi < 4; ++zi)
                zones += ", " + group.location.zones[zi];
            if (group.location.zones.size() > 4)
                zones += " +" + std::to_string(group.location.zones.size() - 4);
            ImGui::TextColored(menu::palette::muted, "  %s", zones.c_str());
        }

        for (const quest_objectives::objective& line : group.lines) {
            ImGui::PushID(line.text.c_str());
            draw_objective_row(line, sf);
            ImGui::PopID();
        }
        ImGui::PopID();
    }
}

void QuestModule::draw_all_objectives(const quest_objectives_snapshot& snap, float sf) {
    ImGui::Dummy(ImVec2(0, 3.f * sf));

    ImGui::TextColored(menu::palette::muted, "%s", i18n::tr("quest_obj_title").c_str());
    {
        // The SUM of every group's tally, not a count of groups: "12/40 objectives done
        // across 6 quests" is the question, and a heading reading "6 quests" answers a
        // different one.
        int done = 0;
        int total = 0;
        for (const quest_objectives_snapshot::grouped_objective& group : snap.groups) {
            done += group.done;
            total += group.total;
        }
        char tally[24];
        snprintf(tally, sizeof(tally), "%d/%d", done, total);
        ImGui::SameLine(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x
            - ImGui::CalcTextSize(tally).x);
        ImGui::TextColored(total > 0 && done >= total ? menu::palette::accent2 : menu::palette::txt,
            "%s", tally);
    }

    if (snap.groups.empty())
    {
        imgui_addons::status_line(i18n::tr("quest_obj_none"));
        return;
    }

    // Said when the cap bites. A truncated list that reads as complete is worse than a
    // short one, because the player cannot tell that a quest they are carrying was skipped.
    //
    // GATED ON all_capped, not on all_requested > all_shown. Those two are not the same
    // condition and conflating them made this line lie: it fired whenever any quest yielded
    // no rows, told the player the list had been truncated when it had not been, and then
    // sent them to the search box for rows that cannot be read. Both cases get their own
    // text now, because "you are seeing fewer quests" has two opposite causes and the player
    // can only act on one of them.
    if (snap.all_capped)
    {
        // Two substitutions on one string, so they are applied to explicit positions rather than
        // by replacing "{}" twice: both placeholders are the same token, and a sequential
        // replace would put BOTH numbers into the first slot and leave the second empty.
        // The alternative -- formatting the translation at the call site -- would mean every
        // locale's word order is fixed to English, so the two tokens are replaced by index.
        std::string capped = i18n::tr("quest_obj_all_capped");
        const size_t first = capped.find("{}");
        const size_t second = first == std::string::npos ? first : capped.find("{}", first + 2);
        if (first != std::string::npos) {
            capped.replace(first, 2, std::to_string(snap.all_shown));
            if (second != std::string::npos) {
                // `second` was measured before the first replacement, so it shifts by the
                // length difference. Measured again rather than adjusted, so a wrong
                // adjustment cannot silently misplace the second number.
                const size_t second_after = capped.find("{}");
                if (second_after != std::string::npos)
                    capped.replace(second_after, 2, std::to_string(snap.all_requested));
            }
        }
        imgui_addons::status_line(capped);
    }
    else if (snap.all_unreadable > 0)
    {
        // NOT truncation, and the difference is the whole point of the message. These quests
        // have no readable conditions, so there is nothing to show and nothing the search box
        // can find -- it can find their rows in the dropdown, and selecting one shows an empty
        // checklist. Saying "use the search box" here is a dead end with a confident voice.
        //
        // Their usual cause is a quest that is not running: a dormant holiday-event entry, or
        // one removed from the game and left in the database. See the `stale` note in
        // gameworld_update for the full account and the evidence.
        std::string unreadable = i18n::tr("quest_obj_all_unreadable");
        const size_t at = unreadable.find("{}");
        if (at != std::string::npos)
            unreadable.replace(at, 2, std::to_string(snap.all_unreadable));
        imgui_addons::status_line(unreadable);
    }

    ImGui::Dummy(ImVec2(0, 1.f * sf));

    // Grouped by location binding, because a flat list of quests is the wrong answer to the
    // question this view exists for. On a map, most of what the player carries cannot be
    // done there -- and a flat list makes them read all of it before finding the two that
    // can. The grouping puts the doable-anywhere quests first, because those are the ones
    // most likely to be worth the raid, then the location-bound ones with the zones they
    // name.
    //
    // This REPLACED taking the first kAllQuestCap in dropdown order. That was stable and
    // arbitrary at once: dropdown order is the profile's, not the map's, so it kept twelve
    // quests of no relevance to the map and dropped the relevant ones. The cap survives as a
    // backstop on the whole set.
    const size_t not_bound = static_cast<size_t>(std::count_if(snap.groups.begin(), snap.groups.end(),
        [](const quest_objectives_snapshot::grouped_objective& g) {
            return g.known && !g.location.zone_bound;
        }));
    const size_t unreadable = static_cast<size_t>(std::count_if(snap.groups.begin(), snap.groups.end(),
        [](const quest_objectives_snapshot::grouped_objective& g) { return !g.known; }));
    const size_t bound = snap.groups.size() - not_bound - unreadable;

    char section[96];
    snprintf(section, sizeof(section), "%d anywhere, %d on this map, %d unreadable",
        static_cast<int>(not_bound), static_cast<int>(bound), static_cast<int>(unreadable));
    ImGui::TextColored(menu::palette::muted, "%s", section);

    if (not_bound) {
        ImGui::TextColored(menu::palette::txt, "%s", i18n::tr("quest_group_anywhere").c_str());
        draw_objective_groups(snap.groups, false, sf);
    }
    if (bound) {
        ImGui::TextColored(menu::palette::txt, "%s", i18n::tr("quest_group_zones").c_str());
        draw_objective_groups(snap.groups, true, sf);
    }
    if (unreadable) {
        ImGui::TextColored(menu::palette::txt, "%s", i18n::tr("quest_group_unknown").c_str());
        draw_objective_groups(snap.groups, std::nullopt, sf);
    }
}

void QuestModule::draw_menu_extra() {
    const std::string status = completion_status();
    if (!status.empty())
        imgui_addons::status_line(status, true);

    const float sf = menu::get_scale_factor();
    const std::shared_ptr<const quest_objectives_snapshot> snap = objectives();

    if (!game_state::is_in_raid)
    {
        imgui_addons::status_line(i18n::tr("quest_obj_raid_only"));
        return;
    }

    // WHICH VIEW, decided here and here only.
    //
    // This used to be three cases with a `snap->all_quests` flag, a stale-detail_id check and
    // a detail_ready check, because the snapshot was published per-selection and the render
    // thread had to work out whether it was looking at the thing it had asked for. None of
    // that is needed now: build_snapshot() publishes EVERY listed quest, once, and the
    // selection is answered entirely from what is already in hand.
    //
    // So the gate collapses to one lookup, and it cannot be stale, because there is no
    // per-selection publication to go stale. That deletes the entire class of fault where the
    // card drew nothing and the log said everything had succeeded.
    const std::string selected = selected_quest();

    // Empty id is the "All" sentinel (kAllQuestsId IS ""), which is also the default
    // selection -- so this is the common path, not an edge case.
    if (selected.empty())
    {
        draw_all_objectives(*snap, sf);
        return;
    }

    // The one lookup. A miss means the quest is listed but produced no readable rows, which
    // for this profile is a dormant holiday/removed entry -- and it is NOT drawn as an empty
    // checklist, because an empty checklist reads as "nothing to do" rather than "cannot be
    // read". The All view's unreadable count is the place that is reported properly.
    const quest_objectives_snapshot::grouped_objective* group = nullptr;
    for (const quest_objectives_snapshot::grouped_objective& candidate : snap->groups) {
        if (candidate.quest_id == selected) { group = &candidate; break; }
    }
    if (!group)
    {
        imgui_addons::status_line(i18n::tr("quest_obj_none"));
        return;
    }

    ImGui::Dummy(ImVec2(0, 3.f * sf));

    // Header: the quest's objectives, with the tally right-aligned. Placed from
    // the content region's right edge rather than with a plain SameLine, so it
    // stays put as the label translates to a different width.
    ImGui::TextColored(menu::palette::muted, "%s", i18n::tr("quest_obj_title").c_str());
    {
        char tally[24];
        snprintf(tally, sizeof(tally), "%d/%d", group->done, group->total);
        ImGui::SameLine(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x
            - ImGui::CalcTextSize(tally).x);
        // Accent only when there is something to accent: `0/0` in the highlight
        // colour would read as progress.
        ImGui::TextColored(group->total > 0 && group->done >= group->total
                               ? menu::palette::accent2
                               : menu::palette::txt,
                           "%s", tally);
    }

    // The boxes below are drawn from a "done" flag that a failed resolution also
    // produces, so this has to be on the card: without it, an unreadable quest is
    // indistinguishable from an unstarted one, and the number above never moves.
    if (!group->readable)
    {
        imgui_addons::status_line(i18n::tr("quest_obj_unreadable"));
    }

    if (group->lines.empty())
    {
        imgui_addons::status_line(i18n::tr("quest_obj_none"));
        return;
    }

    ImGui::Dummy(ImVec2(0, 1.f * sf));
    for (const quest_objectives::objective& line : group->lines)
    {
        ImGui::PushID(line.text.c_str());
        draw_objective_row(line, sf);
        ImGui::PopID();
    }
}

void QuestModule::revert_completed_from_picker(const std::string& quest_id) {
    if (!game_state::is_in_raid) return;
    if (quest_id.empty()) return;
    pending_quest_id = quest_id;
    set_completion_status("Reset queued for the selected completed quest.");
    queue_revert = true;
}

std::string QuestModule::status_prefix(int s) {
    switch (s)
    {
    case 0: return "[Locked] ";
    case 1: return "[Available] ";
    case 2: return "[Active] ";
    case 3: return "[Ready] ";
    case 4: return "[Done] ";
    default: return "";
    }
}

void QuestModule::draw_overlay(ImDrawList* draw_list) {
    if (!game_state::is_in_raid)
    {
        // Nothing here holds an Il2Cpp pointer any more -- that was the reason for the
        // care: quest_names was a vector of Il2CppString*, GC-managed and collectable the
        // instant the raid ended, and dereferencing one from this thread after that is a
        // use-after-free. The names now arrive as std::string inside an immutable
        // published snapshot, so there is nothing to invalidate here at all.
        filtered_quest_ids.clear();
        quest_select->set_options({});

        // The raid is the lifetime of both the Il2Cpp quest objects in
        // listed_quests_ and every Condition pointer in the objective text cache,
        // so both are dropped at the same boundary. A new raid can hand a fresh
        // object the address of a freed one, which is what makes a pointer-keyed
        // cache unsafe to keep across this line.
        //
        // UNDER THE LOCK, AND THIS IS A FIX (2026-10-04). This clear ran on the RENDER
        // thread with no lock while the game thread walked the same containers, and
        // listed_quests_ is a std::vector of a struct holding an Il2CppObject*. Clearing
        // it under a concurrent read is not a benign race: the reader can be holding an
        // element while the clear destroys it, and the pointer it then passes to
        // quest_objectives::collect() is a freed Il2Cpp object. quest_objectives::
        // clear_caches() is worse -- text_cache() is an unordered_map keyed by those same
        // pointers, and destroying its buckets while another thread inserts is undefined
        // behaviour that can throw, which is a plausible source of the non-std throw the
        // overlay backoff has been counting since 2026-10-03.
        //
        // The race was reachable exactly when this runs: is_in_raid has just gone false,
        // which is the same edge on which the game thread is between updates. Note the
        // asymmetry that let it through -- gameworld_update and application_update both
        // took the lock, so every WRITER except this one appeared guarded, and the
        // unguarded one was the one at the raid boundary.
        //
        // The exchange-then-skip is the wrong shape here: skipping would leave the
        // previous raid's Il2Cpp pointers alive into the next raid, which is the exact
        // use-after-free this block exists to prevent. So this waits instead. It is the
        // render thread, so a wait is a frame of a frozen dropdown rather than a stall in
        // the game's own Update, and the game thread cannot hold the lock for long -- every
        // holder is a bounded walk that ends in a publish.
        //
        // Locking the whole block, not just the clears: the snapshot's per-quest tallies are
        // derived from listed_quests_ by the game thread, and a partial lock would leave the
        // render thread racing the one container this block exists to empty.
        {
            // Waits, via the guard's own unique_lock -- see the header's note on why this
            // path must not be a skip-guard.
            const scan_guard guard(names_lock, names_mutex_);
            listed_quests_.clear();
            // The amortized build holds all_quest_inputs_, which is populated FROM
            // listed_quests_ and indexes into it. Clearing the list above leaves those
            // quest pointers dangling, so a build still in flight would read a previous
            // raid's objects on its next tick. Cancelled here, under the same lock, so it
            // cannot be mid-walk. This is the one new obligation the amortization adds:
            // its working state now outlives a single call, so anything that empties the
            // list has to empty it too.
            build_active_ = false;
            build_cursor_ = 0;
            build_collected_.clear();
            build_collected_.shrink_to_fit();
            build_target_.reset();
            all_quest_inputs_.clear();
            quest_objectives::clear_caches();
        }
        set_selected_quest({});
        objectives_published_.store(std::make_shared<const quest_objectives_snapshot>());
        list_published_.store(std::make_shared<const quest_list_snapshot>());
        // The audit latch belongs to this raid's data, so it goes with it -- otherwise the
        // next raid's audit stays silent because the previous one already ran.
        reaudit_names();
        return;
    }
    if (names_lock.exchange(true)) return;
    const scan_guard guard(names_lock, names_mutex_);

    std::string search_lower = quest_search->get();
    std::transform(search_lower.begin(), search_lower.end(), search_lower.begin(), ::tolower);

    // quest_select->set_options() copies these strings into its own internal storage
    // immediately, so a locally-owned std::vector<std::string> is enough — no manual
    // new[]/delete[] needed (and no longer safe: SelectValue owns get_options()'s memory).
    std::vector<std::string> new_display_names = {};
    std::vector<std::string> new_filtered_ids = {};
    // DIAGNOSTIC (2026-10-11). Counters for the per-frame log line at the bottom of
    // this function. Reset per frame because this whole body runs per frame, so a
    // static would accumulate across the whole raid and say nothing about any one
    // frame's filter. Split named vs id-labelled so the line can distinguish
    // "quests exist but the search ate them" from "the rows were built and then
    // lost between here and the widget".
    size_t named_rows = 0;
    size_t from_id_rows = 0;
    // quest id -> objectives done / total, from the last scan. Read here so the
    // dropdown can carry the tally; see the badge pass in gameworld_update for
    // why it is refreshed a few quests at a time rather than all of them.
    const std::shared_ptr<const quest_objectives_snapshot> snap = objectives();

    // The list itself is a published snapshot, so this is a read of an immutable object
    // and not a walk of vectors the game thread is refilling underneath it.
    const std::shared_ptr<const quest_list_snapshot> list = quest_list();

    // A HASH of the tallies, built once here. This loop runs over list->size() -- 647 on the
    // profile measured on 2026-10-04, not the 8 that survive the status filter -- on EVERY
    // frame, from the render thread. Scanning `snap->groups` inside it, which is what this
    // did first, is 647 x |groups| string comparisons per frame: a quadratic I introduced
    // when I replaced the badge map with a lookup over the unified snapshot. `groups` is
    // small (3 here) and 647 is not, so the product is not negligible even though each side
    // is trivial.
    //
    // The map is rebuilt per frame rather than published with the snapshot on purpose: it
    // borrows pointers INTO snap->groups, which is owned by the snapshot, so storing it would
    // create a second thing with the snapshot's lifetime and none of its safety.
    const std::unordered_map<std::string, const quest_objectives_snapshot::grouped_objective*> badge_by_id = [&] {
        std::unordered_map<std::string, const quest_objectives_snapshot::grouped_objective*> by_id;
        by_id.reserve(snap->groups.size());
        for (const quest_objectives_snapshot::grouped_objective& group : snap->groups)
            by_id.emplace(group.quest_id, &group);
        return by_id;
    }();

    for (size_t qi = 0; qi < list->size(); ++qi)
    {
        const std::string& raw_name = list->names[qi];

        const int s = list->statuses[qi];
        // Only active/ready-to-turn-in quests belong in the completer.
        if (s != 2 && s != 3) continue;

        // Skip a quest the game has no name for, rather than offering a blank row.
        //
        // The scan rejects a NULL Il2CppString*, not an empty one, and an empty name is a
        // real possibility rather than a corrupted read: Quest.get_Name() forwards to
        // QuestTemplate.get_Name(), which is
        //
        //   get_Name() -> LocalizationExtensions.Localized(get_NameLocaleKey())
        //
        // and get_NameLocaleKey() returns the raw `_questName` field when
        // String.IsNullOrEmpty(_questName) is true (QuestTemplate.txt ISIL, lines 21-29).
        // A template with no name key therefore produces "" rather than null, and those
        // became unlabelled rows in the dropdown -- a row you cannot tell apart from any
        // other, and one that still occupies an index the Complete/Revert buttons act on.
        //
        // Blank rows are not dropped silently, though: a row with no name is still a quest
        // the player may want, so it is kept and labelled with its template id, which is
        // stable, unique, and copy-pasteable. Only a quest with neither a name NOR an id is
        // dropped, and that cannot be acted on anyway.
        if (raw_name.empty())
        {
            if (list->ids[qi].empty()) continue;
        }

        // The lowercase copy is made ONLY when there is something to match against. It used to be
        // unconditional, which meant a std::string copy plus a tolower pass for all 647 quests
        // on every frame to support a filter that is empty almost always. Two allocations per
        // quest per frame, 647 times, for a comparison against the empty string.
        if (!search_lower.empty()) {
            std::string name_lower = raw_name;
            std::transform(name_lower.begin(), name_lower.end(), name_lower.begin(), ::tolower);
            if (name_lower.find(search_lower) == std::string::npos) continue;
        }

        const std::string& id = list->ids[qi];

        // The row's label: the name when there is one, the id otherwise. Assigned here so
        // the badge suffix below and the search above all read the same string.
        const std::string label = raw_name.empty() ? id : raw_name;

        // The tally goes in the dropdown rather than in a second list: a quest
        // that is 1 objective from done and one that has not started look
        // identical by name, and which one to spend the raid on is the decision
        // this card exists to inform. Only quests that HAVE been tallied get a
        // suffix, so an untallied row reads as a bare name rather than as 0/0.
        //
        // DERIVED FROM `groups`, which is the whole point of the snapshot having one source.
        // It used to be a badge_cache_ map filled by a round-robin pass over the listed
        // quests, maintained separately from the header's counter -- and two counters over the
        // same rows is exactly how the dropdown and the card came to disagree. There is no
        // map to keep in step now, and nothing to prune when a quest leaves the active set.
        const auto badge = badge_by_id.find(id);
        if (badge != badge_by_id.end() && badge->second->total > 0)
        {
            new_display_names.push_back(label + "  [" + std::to_string(badge->second->done)
                + "/" + std::to_string(badge->second->total) + "]");
        }
        else
        {
            new_display_names.push_back(label);
        }
        new_filtered_ids.push_back(id);

        // DIAGNOSTIC (2026-10-11). Split the rows that SURVIVED the filter into
        // named and id-labelled, because their two failure modes are opposite and
        // the existing "stale-unnamed=12" on the game thread says how many the
        // walk saw, not how many the widget got. A quest with no name falls back
        // to its 24-hex id, so 12 from_id here is rows that SHOULD render; if the
        // dropdown is empty with from_id=12 present, none of them reached it.
        if (raw_name.empty())
            ++from_id_rows;
        else
            ++named_rows;
    }

    // ---- "All" entry: one summary over every listed quest ----
    //
    // FIRST, and before the quests, so it is the default selection and the card opens on
    // the answer to "what am I working on" rather than on whichever quest happened to be
    // index 0. The quest rows keep their order after it, so nothing else shifts.
    //
    // Its id is the empty string, which is a sentinel rather than a guess: quest template
    // ids are 24 hex characters and can never be empty (QuestModule::gameworld_update
    // skips a quest whose get_Id() returns null), so "" cannot collide with a real quest.
    // An empty selected_quest() already meant "no selection" and drew nothing, so the
    // sentinel takes over that meaning rather than adding a second kind of nothing.
    if (!new_filtered_ids.empty() && search_lower.empty())
    {
        std::string all_label = i18n::tr("quest_sel_all");
        // The same done/total the header shows -- summed from the SAME groups, not from a
        // separate tally -- so the row and the card beneath it cannot disagree.
        int all_done = 0;
        int all_total = 0;
        for (const quest_objectives_snapshot::grouped_objective& group : snap->groups) {
            all_done += group.done;
            all_total += group.total;
        }
        if (all_total > 0)
            all_label += "  [" + std::to_string(all_done) + "/" + std::to_string(all_total) + "]";

        new_display_names.insert(new_display_names.begin(), all_label);
        new_filtered_ids.insert(new_filtered_ids.begin(), kAllQuestsId);
    }

    std::vector<const char*> new_quest_names = {};
    new_quest_names.reserve(new_display_names.size());
    for (const std::string& name : new_display_names)
        new_quest_names.push_back(name.c_str());

    filtered_quest_ids = std::move(new_filtered_ids);
    quest_select->set_options(new_quest_names);
    if (static_cast<size_t>(quest_select->get_value()) >= new_quest_names.size())
        quest_select->set("0");

    // DIAGNOSTIC (2026-10-11). The card showed requirements while the dropdown
    // stayed empty, and no line in the log could say which of the two was wrong.
    // The list walk reports walked/kept/listed on the GAME thread, but that says
    // nothing about what the RENDER thread handed the widget: kept=17 with an
    // empty dropdown means "the filter ate them" or "the hand-off lost them",
    // and those are different bugs.
    //
    // Reported at the exact point the rows disappear, and read BACK from
    // quest_select after set_options so the number is what the widget holds, not
    // what we built. kept=18 options=0 is the hand-off; kept=0 is the filter.
    // Neither can be told apart from any line currently logged.
    //
    // WHY THE debug_enabled() GATE WRAPS THE BUILD ITSELF, not just the call.
    // logger::debug() already returns early when DEBUG is off, so the string
    // would not be WRITTEN -- but it is still CONSTRUCTED, five std::to_string
    // calls and a vector copy per frame, forever, to publish a number nobody
    // reads. That is the exact rule AGENTS.md states outright. One atomic load on
    // the outside is what makes the debug-off cost zero. The change gate then
    // stops the enabled case flooding once per frame, and it follows the
    // `static std::string last_walk` shape gameworld_update already uses.
    if (logger::debug_enabled())
    {
        const std::string quest_rows_line = "quest rows: kept="
            + std::to_string(new_display_names.size())
            + " named=" + std::to_string(named_rows)
            + " from_id=" + std::to_string(from_id_rows)
            + " groups=" + std::to_string(snap->groups.size())
            + " options=" + std::to_string(quest_select->get_options().size())
            + " filter='" + search_lower + "'";
        static std::string last_quest_rows;
        if (quest_rows_line != last_quest_rows)
        {
            last_quest_rows = quest_rows_line;
            logger::debug(quest_rows_line);
        }
    }

    // Tell the game thread which quest the checklist belongs to. Read back from
    // quest_select rather than from the option index: set_options above can clamp
    // the value, and the mapping from index to id only exists in
    // filtered_quest_ids.
    const int selected = quest_select->get_value();
    set_selected_quest(selected >= 0 && selected < (int)filtered_quest_ids.size()
                           ? filtered_quest_ids[selected]
                           : std::string());
}

void QuestModule::refresh_quest_list() {
    // Set rather than performed. The call site may be a render-thread button handler or a
    // game-thread action that has just changed a status, and neither can do the walk here:
    // the first would touch IL2CPP from the render thread, the second is already mid-walk.
    // gameworld_update picks it up on its next tick.
    //
    // An atomic exchange, not a store, so two requesters in one frame collapse into one
    // walk rather than queueing two.
    quest_list_refresh_requested_.store(true, std::memory_order_release);
}

bool QuestModule::action_pending() const {
    return queue_unlock || queue_force_complete || queue_revert || queue_start;
}

void QuestModule::gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
    Il2CppObjectInstance main_player) {
    TA_ZONE_N("quest::gameworld_update");
    // exchange, not load-then-store: as a plain bool both threads could read false and
    // both proceed, which is the interleaving the guard exists to prevent.
    //
    // The exchange is what excludes the OTHER GAME-THREAD path, and it does so without ever
    // blocking this one. It does not exclude the render thread's raid-boundary clear -- that
    // is names_mutex_, which the guard below holds. Between the two, the section is exclusive
    // against both callers while neither game-thread caller can stall a frame.
    if (names_lock.exchange(true)) return;
    const scan_guard guard(names_lock, names_mutex_);

    // THE SCAN RUNS ONCE PER RAID. That is not an optimisation, it is the correct model of
    // what the data is, and the previous 300 ms throttle was wrong for a reason worth
    // recording.
    //
    // The walk reads the player's ENTIRE quest list -- 647 quests on the profile measured
    // on 2026-10-04 -- and for each one does a get_Quests() field read, a Quest field read,
    // a _statusData field read, a Status field read, get_Name() (a managed call that
    // localises a string), _template, and get_Id(). That is five to eight IL2CPP calls per
    // quest, every 300 ms, for the length of a raid: roughly 13,000 managed calls per scan
    // second, forever, to re-read a list that almost never changes.
    //
    // What can actually change in-raid is the STATUS of a handful of quests, and that is
    // driven by the player -- completing one, reverting one, starting one. Every path that
    // does it is in this function, and all of them call refresh_quest_list() below to say
    // so. So the list is re-read when it is known to have changed, and otherwise not.
    //
    // WHY THE PROGRESS COUNTS ARE STILL LIVE, because that is the part that must not go
    // stale: a checklist that does not tick while you kill things is worthless, and it is
    // the reason the scan existed. Progress lives in the CONDITION objects, not in the list
    // walk, so publish_objectives() re-reads the SELECTED quest's conditions on its own
    // slower cadence and never re-walks the 647. Selecting a different quest re-reads that
    // one immediately, so the count a player is looking at is never more than
    // kProgressInterval_ms old.
    //
    // The upshot: the dropdown is built from the once-per-raid list, and the numbers on it
    // come from the per-quest publish. A quest completing updates both, because completing
    // one is what triggers the list refresh.
    // THE AMORTIZED BUILD TICK. Placed ABOVE the early-return below, because that return is
    // exactly what would starve it: the walk is once-per-raid, so on almost every frame of a
    // raid quest_list_refresh_requested_ is false and this function returns at the `skip`
    // branch without ever reaching the walk -- and an in-flight build needs to keep making
    // progress on precisely those frames. Runs before the request check because the build is
    // not a scan: it is already-decided work being spread out, and gating it on a new request
    // would leave a half-read card whenever the player did nothing.
    if (snapshot_build_in_flight())
        step_snapshot_build();

    // Zoned 2026-10-06. The expensive path below runs once per raid or on a
    // quest action, but this function is called EVERY frame via ModuleManager::apply,
    // and the 06.10_good capture put its MAX at 621,167 us (0.62 s) against a mean
    // of 9.312 us. The zone distinguishes "ran and was cheap" from "skipped" --
    // without it, the only evidence that the function ran was its self time, which
    // is 0 on the frames that early-return.
    if (!action_pending() && !quest_list_refresh_requested_)
    {
        TA_ZONE_N("quest_completer::skip");
        return;
    }
    quest_list_refresh_requested_ = false;

    // The list refresh itself. Reached ONLY when something asked for it, and the only
    // requesters are the four SetStatus calls below plus the first scan of a raid -- which
    // is what makes once-per-raid correct rather than merely cheap.
    //
    // Each of those four is the player acting on a quest (Complete, Force Complete, Revert,
    // Start), and each is followed by refresh_quest_list(). A status cannot change behind our
    // back through this module: the game only changes one in-raid in response to a player
    // action, and every action the card offers goes through one of these four.
    //
    // Placed once here rather than at each call site because a MISSED call site is exactly
    // the failure this is meant to prevent -- the dropdown keeps showing a quest that is
    // already handed in, and the player tries to complete it again.
    //
    // MOVED TO THE END OF THE WALK, and it was reporting a lie before. This line sat above
    // the walk and printed listed_quests_.size(), which at that point is the PREVIOUS
    // walk's count -- so the first walk of every raid announced "listed_quests_ now 0" on a
    // walk that then found 8, and the count was only ever right by accident on a refresh
    // where the number happened not to change. A "self-announcing rare event" that
    // announces the wrong number is worse than no line: it is what made the once-per-raid
    // design look broken on first contact.
    // (Verified in the 2026-10-04 14:23 session: "quest list: walked a fresh list,
    // listed_quests_ now 0" immediately followed by "quest scan: walked=647 kept=8
    // listed=8".)

    Il2CppObjectInstance quest_controller(
        main_player.call_or<Il2CppObjectPtr>(
            "get_QuestController", 0, Il2CppObjectPtr{}, main_player.get_instance()));

    Il2CppObjectInstance quest_book(
        quest_controller.call_or<Il2CppObjectPtr>(
            "get_Quests", 0, Il2CppObjectPtr{}, quest_controller.get_instance()));

    const auto status_data = quest_book.get_field<unity::list*>("_questsData");

    // Built here, published once the walk is done. The render thread reads this and
    // never the vectors while they are being filled.
    auto next_list = std::make_shared<quest_list_snapshot>();
    if (status_data && status_data->m_p_list_array) {
        const size_t capacity = status_data->m_p_list_array->max_length;
        next_list->names.reserve(capacity);
        next_list->statuses.reserve(capacity);
        next_list->ids.reserve(capacity);
        next_list->classes.reserve(capacity);
    }
    // Zoned 2026-10-06. This is the walk that reads 647 quests with 5-8
    // IL2CPP calls each (get_Quest, _statusData, Status, get_Name, _template,
    // get_Id) plus two string conversions per quest. The 06.10_good capture
    // measured it at 621,167 us max -- but that was the whole function, early
    // return and all. This zone isolates the walk itself.
    //TA_ZONE_N("quest_completer::list_walk");
    listed_quests_.clear();

    // Counters for the post-walk summary below. `walked` is every QuestData the list
    // yielded, `kept` the subset that passed the status filter into listed_quests_.
    size_t walked = 0;
    size_t kept = 0;
    // Blanks that get_Name() returned "" for and the localisation table then answered.
    // Reported because it is the whole question: if this is 0 the client genuinely ships
    // an empty string for those keys and no lookup on our side will ever name them.
    size_t names_recovered_by_lookup = 0;

    // get_field returns nullptr when the field is absent (renamed by a game
    // update) or when quest_book itself is null because get_Quests() failed.
    // Both hops were previously dereferenced unchecked, which is a clean
    // access violation rather than an empty quest list.
    //
    // This path publishes the empty list rather than returning without publishing,
    // so the dropdown is emptied instead of keeping the previous raid's quests on
    // screen. A stale list that reads as current is worse than an empty one.
    if (!status_data || !status_data->m_p_list_array)
    {
        logger::warn("Quests: _questsData unavailable; quest list left empty this frame");
        next_list->names.clear();
        next_list->statuses.clear();
        next_list->ids.clear();
        next_list->completed_names.clear();
        next_list->completed_ids.clear();
        list_published_.store(std::move(next_list));
        build_snapshot();
        // The request has been serviced, so do not retry every frame on a quest book that
        // is still coming up. The next player action re-requests it, and so does the next
        // raid's first scan.
        quest_list_refresh_requested_ = false;
        return;
    }

    for (size_t i = 0; i < status_data->m_p_list_array->max_length; ++i)
    {
        Il2CppObject* quest_data_ptr = reinterpret_cast<Il2CppObject**>(&status_data->m_p_list_array->data)[i];
        if (!quest_data_ptr) continue;

        Il2CppObjectInstance quest_data(quest_data_ptr);

        const auto quest_ptr = quest_data.get_field<Il2CppObject*>("Quest");
        if (!quest_ptr) continue;

        Il2CppObjectInstance quest(quest_ptr);

        Il2CppObjectInstance quest_status(quest.get_field<Il2CppObject*>("_statusData"));

        // 0 = Locked, 1 = AvailableForStart, 2 = Started, 3 = AvailableForFinish, 4 = Completed
        const int status_val = quest_status.get_field<int>("Status");
        if (status_val < 0 || status_val > 4) continue;

        Il2CppString* quest_name =
            quest.call_or<Il2CppString*>("get_Name", 0, nullptr);
        if (!quest_name) continue;

        Il2CppObject* tmpl_ptr = quest.get_field<Il2CppObject*>("_template");
        if (!tmpl_ptr) continue;
        Il2CppObjectInstance quest_template(tmpl_ptr);
        Il2CppString* quest_id =
            quest_template.call_or<Il2CppString*>("get_Id", 0, nullptr);
        if (!quest_id) continue;

        const std::string quest_id_str = il2utils::conv_string(quest_id);
        std::string quest_name_str = il2utils::conv_string(quest_name);

        // A BLANK NAME IS USUALLY A MISSED LOOKUP, NOT A MISSING NAME (2026-10-04).
        //
        // 45 of 647 quests returned "" from get_Name(), all of them class=SideQuest, and
        // five of those had HasValidLocalization(Id + " name") == TRUE. A key the game says
        // is valid, resolving to nothing, is a contradiction -- so before accepting "" we ask
        // the localisation table directly and take its answer if it is a plausible string.
        //
        // Why this is the right place rather than at the dropdown: this is where the name is
        // produced, so one fix reaches the dropdown, the All view, the search filter and the
        // audit at once. A fallback bolted onto the row label would leave the audit still
        // reporting 45 blanks and the search still failing to match them.
        //
        // try_localize_key() rather than Localized() directly, because that wrapper rejects
        // the miss paths (it returns the constructed key, or "Name/<key>") -- a quest
        // literally named "68f2e289... name" would be worse than the blank it replaces.
        //
        // Cheap and bounded, and the bound is why: only blanks are looked up, and
        // try_localize_key memoises per key, so this is 45 lookups on the once-per-raid walk
        // and zero thereafter. NOT on a per-frame path.
        //
        // What this cannot fix: a quest whose localisation row genuinely holds an empty
        // string. Then try_localize_key returns "" too and the row keeps its id, which is the
        // honest answer -- there is no name in the client to display.
        if (quest_name_str.empty() && !quest_id_str.empty())
        {
            const std::string recovered = eft_api::try_localize_key(quest_id_str + " name");
            if (!recovered.empty()) {
                quest_name_str = recovered;
                ++names_recovered_by_lookup;
            }
        }

        // reserve() once above; three pushes that cannot interleave with anything,
        // and all three in one statement so the vectors stay index-aligned.
        next_list->names.push_back(quest_name_str);
        next_list->statuses.push_back(status_val);
        next_list->ids.push_back(quest_id_str);
        // For the localisation audit only: which template class, because the
        // "Id + ' name'" fallback in QuestTemplate.get_NameLocaleKey is per-template and a
        // class is what distinguishes one broken template from a family of them. Owned by
        // the class table for the process, so a bare const char* is safe to publish here.
        next_list->classes.push_back(quest.get_instance()->klass && quest.get_instance()->klass->name
            ? quest.get_instance()->klass->name : "");

        // How many quests the walk saw, and how many passed the status filter. Zero here
        // with a populated dropdown would mean the filter is inverted; zero here with an
        // empty dropdown means the walk itself found nothing, which is the case where
        // publish_objectives has no listed quest to match the selection against.
        walked += 1;
        if (status_val == 2 || status_val == 3) kept += 1;
        if (status_val == 4)
        {
            next_list->completed_names.push_back(quest_name_str);
            next_list->completed_ids.push_back(quest_id_str);
        }
        else if (status_val == 2 || status_val == 3)
        {
            // Same two statuses the dropdown keeps, so a quest can be tallied
            // only if it can be picked. The Il2Cpp pointer is held for this scan
            // only; draw_overlay drops the list at the raid boundary.
            listed_quests_.push_back({quest_id_str, quest.get_instance()});
        }

        // Match actions by pending_quest_id (captured at click time) — robust against list reorder/refilter.
        const bool is_selected = !pending_quest_id.empty() && (quest_id_str == pending_quest_id);

        // Story quests remain protected. Placement/beacon quests are
        // protected only for normal Complete; Force Complete deliberately
        // handles their counters and condition IDs below.
        if ((queue_unlock || queue_force_complete) && is_selected)
        {
            const bool is_story_quest = quest_template.get_field<bool>("<IsMainQuest>k__BackingField");
            bool is_placement_quest = false;
            const MethodInfo* get_conditions =
                il2utils::resolve_method(quest.get_instance()->klass, "get_Conditions", 0);
            if (get_conditions && get_conditions->methodPointer)
            {
                Il2CppObject* conditions_obj =
                    static_cast<Il2CppObject* (*)(Il2CppObject*)>(get_conditions->methodPointer)(quest.get_instance());
                auto* cond_dict = reinterpret_cast<unity::dict<int, Il2CppObject*>*>(conditions_obj);
                if (cond_dict && cond_dict->m_p_entries)
                {
                    for (int di = 0; di < cond_dict->m_i_count && !is_placement_quest; ++di)
                    {
                        Il2CppObject* collection = cond_dict->get_value_by_index(di);
                        if (!collection) continue;
                        Il2CppObjectInstance coll(collection);
                        unity::list* clist = coll.get_field<unity::list*>("List");
                        if (!clist || !clist->m_p_list_array) continue;
                        for (size_t ci = 0; ci < clist->m_p_list_array->max_length; ++ci)
                        {
                            Il2CppObject* condition = reinterpret_cast<Il2CppObject**>(&clist->m_p_list_array->data)[ci];
                            const char* type = (condition && condition->klass && condition->klass->name)
                                ? condition->klass->name
                                : "";
                            if (strstr(type, "ConditionZone") || strstr(type, "ConditionLeaveItemAtLocation")
                                || strstr(type, "ConditionPlaceBeacon"))
                            {
                                is_placement_quest = true;
                                break;
                            }
                        }
                    }
                }
            }
            if (is_story_quest || (is_placement_quest && !queue_force_complete))
            {
                const std::string refusal = is_story_quest
                    ? "Cannot complete story quests from this menu."
                    : "Cannot complete quests that require placing objects.";
                set_completion_status(refusal);
                logger::warn(refusal + " Quest: " + il2utils::conv_string(quest_name));
                queue_unlock = false;
                queue_force_complete = false;
                continue;
            }
        }

        // ---- START: force-start a locked/available quest ----
        if (queue_start && is_selected)
        {
            logger::debug("Starting Quest: " + il2utils::conv_string(quest_name));

            quest.call_or_void<void (*)(Il2CppObject*, int, bool, bool)>(
                "SetStatus", 3, 2 /* Started */, true, false);
            // Status changed, so the dropdown's quest set changed. Once-per-raid list
            // refreshes are only correct because every status change says so here.
            refresh_quest_list();

            const MethodInfo* start_m = il2utils::resolve_method(
                quest_controller.get_instance()->klass, "SendQuestStartedToBackend", 1);
            if (start_m && start_m->methodPointer)
            {
                static_cast<Il2CppObject* (*)(Il2CppObject*, Il2CppString*)>(
                    start_m->methodPointer)(quest_controller.get_instance(), quest_id);
                logger::info("Quest '" + il2utils::conv_string(quest_name) + "': started via backend");
                queue_start = false;
            }
            else
            {
                logger::warn("Quest '" + il2utils::conv_string(quest_name) + "': SendQuestStartedToBackend not found, status set in-memory only");
            }
        }

        if (queue_unlock && is_selected)
        {
            // Status 2 = Started (force-complete), status 3 = AvailableForFinish (just hand in)
            if (status_val != 2 && status_val != 3) continue;

            logger::debug("Unlocking Quest: " + il2utils::conv_string(quest_name) + " status=" + std::to_string(status_val));

            // For status 3 (already ready to finish), skip counter/condition steps — go straight to hand-in.
            if (status_val == 3)
            {
                logger::info("Quest '" + il2utils::conv_string(quest_name) + "': already AvailableForFinish, sending backend hand-in");
                quest_controller.call_or<Il2CppObjectPtr>(
                    "SendQuestCompleteToBackend", 1, Il2CppObjectPtr{}, quest_controller.get_instance(), quest_id);
                queue_unlock = false;
                continue;
            }

            // 1) Fill the REAL condition counters to their target value.
            Il2CppObjectInstance main_profile(
                main_player.call_or<Il2CppObjectPtr>(
                    "get_Profile", 0, Il2CppObjectPtr{}, main_player.get_instance()));

            auto* counters = main_profile.get_field<unity::dict<mongo_id, Il2CppObject*>*>(
                "TaskConditionCounters");

            int filled = 0;
            if (counters && counters->m_p_entries)
            {
                for (int ci = 0; ci < counters->m_i_count; ++ci)
                {
                    Il2CppObject* counter_obj = counters->get_value_by_index(ci);
                    if (!counter_obj) continue;

                    Il2CppObjectInstance counter(counter_obj);

                    // keep only counters belonging to this quest
                    if (counter.get_field<Il2CppObject*>("Conditional") != quest.get_instance()) continue;

                    Il2CppObject* template_obj = counter.get_field<Il2CppObject*>("Template");
                    if (!template_obj) continue;

                    Il2CppObjectInstance condition(template_obj);
                    const float target = condition.call_or<float>(
                        "get_value", 0, float{}, condition.get_instance());

                    counter.call_or_void<void (*)(Il2CppObject*, int)>(
                        "set_Value", 1, static_cast<int>(target));
                    filled++;
                }
            }

            logger::info("Quest '" + il2utils::conv_string(quest_name) + "': filled " + std::to_string(filled) + " condition counter(s)");

            // 1b) Mark EVERY condition id as completed in CompletedConditions.
            int marked = 0;
            int spawned = 0;
            {
                Il2CppObject* status_obj = quest.get_field<Il2CppObject*>("_statusData");
                const MethodInfo* get_conditions =
                    il2utils::resolve_method(quest.get_instance()->klass, "get_Conditions", 0);

                if (status_obj && get_conditions && get_conditions->methodPointer)
                {
                    Il2CppObjectInstance status(status_obj);
                    Il2CppObject* completed_set = status.get_field<Il2CppObject*>("CompletedConditions");
                    Il2CppObject* conditions_obj =
                        static_cast<Il2CppObject* (*)(Il2CppObject*)>(get_conditions->methodPointer)(
                            quest.get_instance());

                    if (completed_set && completed_set->klass && conditions_obj)
                    {
                        const MethodInfo* add_m = il2utils::resolve_method(completed_set->klass, "Add", 1);
                        auto* cond_dict = reinterpret_cast<unity::dict<int, Il2CppObject*>*>(conditions_obj);

                        if (add_m && add_m->methodPointer && cond_dict->m_p_entries)
                        {
                            auto add_fn = static_cast<bool (*)(Il2CppObject*, void*, const MethodInfo*)>(
                                add_m->methodPointer);

                            for (int di = 0; di < cond_dict->m_i_count; ++di)
                            {
                                Il2CppObject* collection = cond_dict->get_value_by_index(di);
                                if (!collection) continue;

                                Il2CppObjectInstance coll(collection);
                                unity::list* clist = coll.get_field<unity::list*>("List");
                                if (!clist || !clist->m_p_list_array) continue;

                                Il2CppArray* carr = clist->m_p_list_array;
                                for (size_t cci = 0; cci < carr->max_length; ++cci)
                                {
                                    Il2CppObject* cond = reinterpret_cast<Il2CppObject**>(&carr->data)[cci];
                                    if (!cond) continue;

                                    Il2CppObjectInstance cond_inst(cond);

                                    mongo_id cid = cond_inst.get_field<mongo_id>("<id>k__BackingField");
                                    add_fn(completed_set, &cid, add_m);
                                    marked++;

                                    const char* ccls = (cond->klass && cond->klass->name) ? cond->klass->name : "";
                                    if (strstr(ccls, "PlaceBeacon") || strstr(ccls, "Beacon"))
                                        logger::info("  beacon condition marked: " + std::string(ccls));
                                    if (strstr(ccls, "FindItem") || strstr(ccls, "HandoverItem"))
                                    {
                                        Il2CppArray* targets = cond_inst.get_field<Il2CppArray*>("target");
                                        if (targets && targets->max_length > 0)
                                        {
                                            Il2CppString* tid =
                                                reinterpret_cast<Il2CppString**>(&targets->data)[0];
                                            if (tid)
                                            {
                                                const std::string item_id = il2utils::conv_string(tid);

                                                int cnt = static_cast<int>(
                                                    cond_inst.call_or<float>(
                                                        "get_value", 0, float{}, cond_inst.get_instance()));
                                                if (cnt < 1) cnt = 1;

                                                if (spawn_quest_item(main_player, item_id, cnt))
                                                {
                                                    spawned++;
                                                    logger::info("Quest item spawned x" + std::to_string(cnt) + " (FiR): " + item_id);
                                                }
                                                else
                                                {
                                                    logger::warn("Quest item spawn FAILED: " + item_id);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            logger::info("Quest '" + il2utils::conv_string(quest_name) + "': marked " + std::to_string(marked) + " condition(s), spawned " + std::to_string(spawned) + " item(s)");

            // 2) Flip status to AvailableForFinish (3) then send the hand-in (rewards given normally).
            quest.call_or_void<void (*)(Il2CppObject*, int, bool, bool)>(
                "SetStatus", 3, 3 /* AvailableForFinish */, true, false);
            // See the note on the list refresh: every SetStatus says so, or the once-per-raid
            // list keeps showing a stale status.
            refresh_quest_list();

            quest_controller.call_or<Il2CppObjectPtr>(
                "SendQuestCompleteToBackend", 1, Il2CppObjectPtr{}, quest_controller.get_instance(), quest_id);

            logger::info("Quest '" + il2utils::conv_string(quest_name) + "': completed (status 3), backend notified");
            queue_unlock = false;
        }

        // ---- REVERT: same base as complete, just the inverse ----
        if (queue_revert && is_selected)
        {
            logger::info("Reverting Quest: " + il2utils::conv_string(quest_name) + " (status=" + std::to_string(status_val) + ")");

            Il2CppObjectInstance main_profile(
                main_player.call_or<Il2CppObjectPtr>(
                    "get_Profile", 0, Il2CppObjectPtr{}, main_player.get_instance()));

            auto* counters = main_profile.get_field<unity::dict<mongo_id, Il2CppObject*>*>(
                "TaskConditionCounters");

            // 1) Reset counters to 0
            int reset = 0;
            if (counters && counters->m_p_entries)
            {
                for (int ci = 0; ci < counters->m_i_count; ++ci)
                {
                    Il2CppObject* counter_obj = counters->get_value_by_index(ci);
                    if (!counter_obj) continue;

                    Il2CppObjectInstance counter(counter_obj);
                    if (counter.get_field<Il2CppObject*>("Conditional") != quest.get_instance()) continue;

                    counter.call_or_void<void (*)(Il2CppObject*, int)>(
                        "set_Value", 1, 0);
                    reset++;
                }
            }

            // 2) Clear CompletedConditions + log all condition types
            {
                Il2CppObject* status_obj = quest.get_field<Il2CppObject*>("_statusData");
                const MethodInfo* get_conditions =
                    il2utils::resolve_method(quest.get_instance()->klass, "get_Conditions", 0);

                if (status_obj && get_conditions && get_conditions->methodPointer)
                {
                    Il2CppObjectInstance status(status_obj);
                    Il2CppObject* completed_set = status.get_field<Il2CppObject*>("CompletedConditions");

                    Il2CppObject* conditions_obj =
                        static_cast<Il2CppObject* (*)(Il2CppObject*)>(get_conditions->methodPointer)(
                            quest.get_instance());

                    if (conditions_obj)
                    {
                        auto* cond_dict = reinterpret_cast<unity::dict<int, Il2CppObject*>*>(conditions_obj);
                        if (cond_dict->m_p_entries)
                        {
                            for (int di = 0; di < cond_dict->m_i_count; ++di)
                            {
                                Il2CppObject* collection = cond_dict->get_value_by_index(di);
                                if (!collection) continue;
                                Il2CppObjectInstance coll(collection);
                                unity::list* clist = coll.get_field<unity::list*>("List");
                                if (!clist || !clist->m_p_list_array) continue;
                                Il2CppArray* carr = clist->m_p_list_array;
                                for (size_t cci = 0; cci < carr->max_length; ++cci)
                                {
                                    Il2CppObject* cond = reinterpret_cast<Il2CppObject**>(&carr->data)[cci];
                                    if (!cond || !cond->klass || !cond->klass->name) continue;
                                    const std::string cname = cond->klass->name;
                                    logger::info("  condition type: " + cname);

                                    if (cname == "ConditionPlaceBeacon")
                                    {
                                        Il2CppObjectInstance cond_inst(cond);
                                        Il2CppString* zone_id_str = cond_inst.get_field<Il2CppString*>("zoneId");
                                        if (zone_id_str)
                                            logger::info("  beacon zone reset: " + il2utils::conv_string(zone_id_str));
                                        // Note: do NOT spawn beacon items here — items spawned via spawn_quest_item
                                        // land in QuestRaidItems and cause placement animation to bug out.
                                        // The player should obtain the beacon item normally (inventory/trader).
                                    }
                                }
                            }
                        }
                    }

                    // Always clear CompletedConditions even if condition iteration failed
                    if (completed_set && completed_set->klass)
                    {
                        const MethodInfo* clear_m = il2utils::resolve_method(completed_set->klass, "Clear", 0);
                        if (clear_m && clear_m->methodPointer)
                        {
                            static_cast<void (*)(Il2CppObject*)>(clear_m->methodPointer)(completed_set);
                            logger::info("Quest revert: CompletedConditions cleared");
                        }
                        else
                            logger::warn("Quest revert: Clear() not found on CompletedConditions");
                    }
                    else
                        logger::warn("Quest revert: CompletedConditions is null");
                }
            }

            // 3) Reset status to Started (2) — keeps quest active so beacons can be placed again
            quest.call_or_void<void (*)(Il2CppObject*, int, bool, bool)>(
                "SetStatus", 3, 2 /* Started */, true, false);
            // A revert moves a COMPLETED quest (status 4, not in the dropdown) back to
            // Started (status 2, in it), so this one ADDS a row to the dropdown and is the
            // clearest case of the list being stale without this call.
            refresh_quest_list();

            // 4) Tell backend: use RestartQuest if available (handles Done→Started), else fall back to SendQuestStartedToBackend
            if (quest_controller.get_instance() && quest_controller.get_instance()->klass)
            {
                auto* klass = quest_controller.get_instance()->klass;

                // SPT may expose a RestartTask or SetQuestStatus endpoint
                const MethodInfo* restart_m = il2utils::resolve_method(klass, "RestartQuest", 1);
                if (!restart_m) restart_m = il2utils::resolve_method(klass, "RestartTask", 1);

                if (restart_m && restart_m->methodPointer)
                {
                    static_cast<Il2CppObject* (*)(Il2CppObject*, Il2CppString*)>(
                        restart_m->methodPointer)(quest_controller.get_instance(), quest_id);
                    logger::info("Quest revert: backend notified via RestartQuest");
                }
                else
                {
                    // Fall back to SendQuestStartedToBackend (works for Active→reset, may be ignored for Done)
                    const MethodInfo* start_m = il2utils::resolve_method(klass, "SendQuestStartedToBackend", 1);
                    if (start_m && start_m->methodPointer)
                    {
                        static_cast<Il2CppObject* (*)(Il2CppObject*, Il2CppString*)>(
                            start_m->methodPointer)(quest_controller.get_instance(), quest_id);
                        logger::info("Quest revert: backend notified via SendQuestStartedToBackend (RestartQuest not found)");
                    }
                    else
                        logger::warn("Quest revert: no backend reset method found — in-memory only");
                }
            }

            logger::info("Quest '" + il2utils::conv_string(quest_name) + "': reverted, reset " + std::to_string(reset) + " counter(s)");
            queue_revert = false;
        }

        // ---- FORCE COMPLETE: mark all conditions + set status 4 so SPT persists Done on raid exit ----
        if (queue_force_complete && is_selected)
        {
            logger::info("Force-completing Quest: " + il2utils::conv_string(quest_name) + " (status=" + std::to_string(status_val) + ")");

            Il2CppObjectInstance main_profile(
                main_player.call_or<Il2CppObjectPtr>(
                    "get_Profile", 0, Il2CppObjectPtr{}, main_player.get_instance()));

            // 1) Fill counters to target
            auto* counters = main_profile.get_field<unity::dict<mongo_id, Il2CppObject*>*>("TaskConditionCounters");
            int filled = 0;
            if (counters && counters->m_p_entries)
            {
                for (int ci = 0; ci < counters->m_i_count; ++ci)
                {
                    Il2CppObject* counter_obj = counters->get_value_by_index(ci);
                    if (!counter_obj) continue;
                    Il2CppObjectInstance counter(counter_obj);
                    if (counter.get_field<Il2CppObject*>("Conditional") != quest.get_instance()) continue;
                    Il2CppObject* template_obj = counter.get_field<Il2CppObject*>("Template");
                    if (!template_obj) continue;
                    Il2CppObjectInstance condition(template_obj);
                    const float target = condition.call_or<float>(
                        "get_value", 0, float{}, condition.get_instance());
                    counter.call_or_void<void (*)(Il2CppObject*, int)>(
                        "set_Value", 1, static_cast<int>(target));
                    filled++;
                }
            }

            // 2) Mark all conditions in CompletedConditions
            int marked = 0;
            {
                Il2CppObject* status_obj = quest.get_field<Il2CppObject*>("_statusData");
                const MethodInfo* get_conditions = il2utils::resolve_method(quest.get_instance()->klass, "get_Conditions", 0);
                if (status_obj && get_conditions && get_conditions->methodPointer)
                {
                    Il2CppObjectInstance status(status_obj);
                    Il2CppObject* completed_set = status.get_field<Il2CppObject*>("CompletedConditions");
                    Il2CppObject* conditions_obj = static_cast<Il2CppObject* (*)(Il2CppObject*)>(get_conditions->methodPointer)(quest.get_instance());
                    if (completed_set && completed_set->klass && conditions_obj)
                    {
                        const MethodInfo* add_m = il2utils::resolve_method(completed_set->klass, "Add", 1);
                        auto* cond_dict = reinterpret_cast<unity::dict<int, Il2CppObject*>*>(conditions_obj);
                        if (add_m && add_m->methodPointer && cond_dict->m_p_entries)
                        {
                            auto add_fn = static_cast<bool (*)(Il2CppObject*, void*, const MethodInfo*)>(add_m->methodPointer);
                            for (int di = 0; di < cond_dict->m_i_count; ++di)
                            {
                                Il2CppObject* collection = cond_dict->get_value_by_index(di);
                                if (!collection) continue;
                                Il2CppObjectInstance coll(collection);
                                unity::list* clist = coll.get_field<unity::list*>("List");
                                if (!clist || !clist->m_p_list_array) continue;
                                Il2CppArray* carr = clist->m_p_list_array;
                                for (size_t cci = 0; cci < carr->max_length; ++cci)
                                {
                                    Il2CppObject* cond = reinterpret_cast<Il2CppObject**>(&carr->data)[cci];
                                    if (!cond) continue;
                                    Il2CppObjectInstance cond_inst(cond);
                                    mongo_id cid = cond_inst.get_field<mongo_id>("<id>k__BackingField");
                                    add_fn(completed_set, &cid, add_m);
                                    marked++;
                                }
                            }
                        }
                    }
                }
            }

            // 3) Set status 4 (Completed) — SPT saves this at raid exit, no rewards
            quest.call_or_void<void (*)(Il2CppObject*, int, bool, bool)>(
                "SetStatus", 3, 4 /* Completed */, true, false);
            // Status 4 REMOVES the quest from the dropdown (only 2 and 3 are listed), so
            // without this the player completes a quest and it is still sitting there.
            refresh_quest_list();

            quest_controller.call_or<Il2CppObjectPtr>(
                "SendQuestCompleteToBackend", 1, Il2CppObjectPtr{}, quest_controller.get_instance(), quest_id);

            logger::info("Quest '" + il2utils::conv_string(quest_name) + "': force-completed (status 4), filled " + std::to_string(filled) + " counter(s), marked " + std::to_string(marked) + " condition(s)");
            queue_force_complete = false;
        }
    }

    if (queue_unlock)
    {
        queue_unlock = false;
    }
    if (queue_force_complete)
    {
        queue_force_complete = false;
    }
    if (queue_revert)
    {
        queue_revert = false;
    }
    if (queue_start)
    {
        queue_start = false;
    }

    // What the walk saw, once per state change rather than once per scan. `walked` and
    // `kept` together answer whether the fault is upstream of publish_objectives (the walk
    // found nothing, or the status filter rejected everything) or inside it (the list is
    // populated but the selection still does not match). The card cannot distinguish
    // those, and guessing between them is what went wrong twice already.
    //
    // `stale` is the count of LISTED quests (status 2|3) still carrying no name after the
    // lookup fallback had its chance. It is in this line rather than only in a comment
    // because it is the one number that says whether the dropdown is showing the player
    // rows they cannot act on, and on the profile measured on 2026-10-04 it was 5 of 8 --
    // see the note below before deciding that is a defect.
    {
        // WHY THESE FIVE ARE NOT A BUG, and this is the one place in the file that says so,
        // because every symptom reads like one.
        //
        // Observed, reproducibly across the 13:03 and 14:23 sessions on 2026-10-04: eight
        // quests at status 2|3, of which five carry no name at all, are class=SideQuest,
        // and have HasValidLocalization(Id + " name") == TRUE. Reading a condition of one
        // throws a non-std exception, every time, and always for SideQuest -- the per-
        // condition guard contains it, so the card keeps working and one quest's checklist
        // is simply absent.
        //
        // SideQuest is NOT the cause. It is `public sealed class SideQuest : Quest` with an
        // empty body (GameDump/115147510 SideQuest.cs): no field, no override, not even
        // get_Name. So there is no SideQuest-specific code path to be broken -- the class is
        // only the server's marker for a quest that is not a trader's.
        //
        // The account that fits all of it is the player's, given 2026-10-04 and recorded here
        // as theirs rather than mine: these are quests that are NOT RUNNING -- dormant
        // holiday-event entries, or ones removed from the game and left behind in the
        // database. Their status field still reads 2, their name rows are empty, and their
        // conditions are not live, which is why reading one throws.
        //
        // The ObjectId timestamps corroborate it and are the strongest evidence here, because
        // they were derived from the ids alone: 68f2e289 (2025-10-18) and 68f4d99a
        // (2025-10-19) are one day apart, in the middle of October, which is exactly when
        // EFT runs its Halloween event. The other three are 2026-03-18, 2026-04-24 and
        // 2026-05-05.
        //
        // SO: nothing here is being "fixed", and specifically the per-condition throw should
        // NOT be chased as a defect -- it is what a dormant quest does. What remains open is
        // whether to FILTER these rows out of the dropdown. Deliberately not done yet,
        // because the honest test for it is "has a name OR has readable conditions", and
        // until named-by-lookup reports above 0 we cannot tell a dormant quest from a real
        // one that merely lost its name.
        size_t stale = 0;
        for (size_t qi = 0; qi < next_list->names.size(); ++qi) {
            const int st = qi < next_list->statuses.size() ? next_list->statuses[qi] : -1;
            if ((st == 2 || st == 3) && next_list->names[qi].empty()) ++stale;
        }

        const std::string line = "quest scan: walked=" + std::to_string(walked)
            + " kept(status 2|3)=" + std::to_string(kept)
            + " listed=" + std::to_string(listed_quests_.size())
            + " names=" + std::to_string(next_list->names.size())
            + " named-by-lookup=" + std::to_string(names_recovered_by_lookup)
            + " stale-unnamed=" + std::to_string(stale)
            + " selected='" + selected_quest() + "'";
        // The rare-event announcement, now that it can tell the truth. It is separate from
        // the line above because that one is change-gated (it only logs when the numbers
        // move) while this one is the "a walk happened at all" signal, which matters most
        // exactly when the numbers did NOT move -- a status change on a quest that was
        // already listed produces an identical summary and would otherwise be silent.
        logger::info("quest list: walked a fresh list, listed_quests_ now "
            + std::to_string(listed_quests_.size()));
        static std::string last_walk;
        if (line != last_walk) {
            last_walk = line;
            logger::info(line);
        }
    }

    // The list goes up BEFORE the objectives, because the objectives are derived from
    // it and the render thread reads them in that order: a reader that saw objectives
    // for a quest the list does not contain yet would draw a row the dropdown cannot
    // select.
    list_published_.store(std::move(next_list));
    audit_name_localisation(*quest_list());

    // THE BUILD. This is the raid-entrance half of the lifecycle; draw_overlay's `!is_in_raid`
    // branch is the raid-exit half. It has to be here rather than anywhere else because this is
    // the one point at which listed_quests_ has just been filled from a real quest book: the
    // snapshot must be built from a populated list, and every other caller either runs before
    // that or has no list to build from.
    build_snapshot();
}

void QuestModule::application_update() {
    // DELIBERATELY EMPTY, and this is the fourth shape this function has had.
    //
    // It started empty. Then it held the per-quest PROGRESS refresh, because the quest list
    // walk had gone to once-per-raid and something had to keep the tick boxes moving. Then it
    // also served the All view, because publish_all_objectives() was reachable only from the
    // walk and had therefore gone frozen. Both were correct in isolation and each cost more
    // than the feature was worth:
    //
    //   every 500 ms, All view   120 ms per publish x 998 publishes = 119.99 s inside a
    //                            499 s session, measured in the +8 capture (2026-10-04)
    //   every 2 s, All view       the same 120 ms, less often, still 25% of a core
    //
    // The resolution is that there is no refresh at all: build_snapshot() runs once at raid
    // entrance and draw_overlay() dismantles it at raid exit. The game already shows its own
    // objective progress, so this card only has to answer "what am I carrying", and that
    // answer does not change while a raid is running.
    //
    // What this costs is a stale tally within a raid -- completing an objective will not move
    // the number until the next one. That is the trade, chosen deliberately on 2026-10-04,
    // recorded here and on the struct rather than left to be rediscovered as a bug.
    //
    // The override stays because ModuleManager::apply() calls it every frame, and removing
    // the virtual would be a wider change than this decision warrants.
}

// The whole build. Called ONCE per raid, from the list walk, and never again until the next
// raid or a status change -- see the lifecycle note on the struct in QuestModule.h for why
// there is no refresh and what that trades.
//
// WHAT IT DOES, and the reason it is one function rather than three. It used to be
// publish_progress (one quest), publish_objectives (that quest plus a round-robin of badge
// tallies) and publish_all_objectives (every quest, for the All view), each dispatched on the
// current selection. Three functions over the same conditions produced THREE counters, which
// is how the card header and the dropdown badge came to disagree, and how the All view ended
// up frozen for a whole raid when the walk went to once-per-raid and only one of the three
// callers still ran.
//
// Now: read every listed quest once, into `groups`, and let both views index it. The
// single-quest view looks up its own group; the All view renders the lot. There is no second
// counter to drift, and no selection-dependent code path at all -- the selection is a RENDER
// concern now, and this function does not know or care what is selected.
//
// Cost: one pass over listed_quests_ (status 2|3 only -- 8 on the profile measured on
// 2026-10-04), not over the 647 the list walk itself touches. Measured against the list
// walk's own 0.67 ms per quest that is ~5 ms, paid once, instead of 120 ms paid a thousand
// times.
void QuestModule::build_snapshot() {
    // Amortized since 2026-10-11: this used to do the whole ~43-quest read inline, which is
    // a measured 332 ms gameworld_update at raid entrance. It now only ARMS the build;
    // gameworld_update() drives it a few quests at a time. See the block comment on
    // begin_snapshot_build() in QuestModule.h for why it is spread over frames rather than
    // moved to a thread, and for the game_item_db precedent that shows what does and does
    // not carry across.
    begin_snapshot_build();
    step_snapshot_build();
}

// Phase 1: take the quest list as it stands and prepare to walk it. No managed calls here,
// so this is cheap and safe to do from the list walk itself.
void QuestModule::begin_snapshot_build() {
    build_active_ = true;
    build_cursor_ = 0;
    build_target_ = std::make_shared<quest_objectives_snapshot>();
    build_collected_.clear();

    // The quest pointers come from listed_quests_ and are raid-scoped; they never leave the
    // game thread. With the walk now spanning frames they live LONGER than one call did --
    // that is the whole point of the change, and it is safe only because they are still only
    // ever touched from the game thread. The raid-boundary clear in gameworld_update() drops
    // listed_quests_, so a build in flight across a raid boundary would hold a stale
    // pointer; begin_snapshot_build() therefore always restarts from the CURRENT list rather
    // than resuming, and a boundary cancels below.
    all_quest_inputs_.clear();
    all_quest_inputs_.reserve(listed_quests_.size());
    for (const listed_quest& listed : listed_quests_)
        all_quest_inputs_.emplace_back(listed.id, listed.quest);

    build_target_->all_requested = static_cast<int>(all_quest_inputs_.size());
}

// Phase 2: read at most kQuestsPerBuildTick quests, then publish when the walk completes.
// Called every gameworld_update, so the build finishes over a handful of frames.
void QuestModule::step_snapshot_build() {
    if (!build_active_) return;

    auto next = build_target_;

    // WHY THE WHOLE BODY IS WRAPPED. The evidence that it needs to be, from 2026-10-04:
    // `selected=... listed=8 matched=yes` logged and the `collected N row(s)` line
    // immediately after it never did, on any scan, while the heartbeat kept firing. Nothing
    // else logs between them, so execution was leaving this function mid-way, and the only
    // way out of the middle of a C++ function is an exception. That exception escaped
    // BEFORE objectives_published_.store(), which is why the card sat on "Reading
    // objectives..." forever while every other part of the scan looked healthy.
    //
    // The stage marker is what names WHICH call throws. Without it "collect() failed" is a
    // guess between get_Conditions, IsConditionDone, get_CurrentValue and
    // get_FormattedDescription, and those need different fixes.
    const char* stage = "start";

    try {
        // THE READ, a few quests at a time. quest_objectives::collect_all() is the function
        // this loop used to be, in one call; it now has no caller and is left in place as the
        // reference for the per-quest order. The body below is its loop verbatim, minus the
        // `out.clear()` and the final push loop:
        //
        //   - the no_row latch is checked BEFORE collect() for the same reason collect_all()
        //     checks it before the call (the per-condition throw IS the cost being avoided,
        //     so it has to be avoided BEFORE the call rather than cached after it);
        //   - an empty result is noted, so a dormant quest is paid for once per raid;
        //   - group.id/group.name, the done/total tally over MERGED rows, location_binding_of
        //     and calls_readable are each computed exactly where collect_all() computed them.
        //
        // collect() keeps its own per-quest fault guard, so one bad quest still costs one
        // quest rather than the whole build.
        //
        // `stage` keeps the name collect_all() carried, so a throw on quest N still reports
        // "collect_all" -- which is what tells the reader the fault is in the READ rather
        // than in the ranking or the store below.
        std::vector<quest_objectives::objective> lines;
        const size_t end = (build_cursor_ + kQuestsPerBuildTick) < all_quest_inputs_.size()
                         ? (build_cursor_ + kQuestsPerBuildTick) : all_quest_inputs_.size();
        stage = "collect_all";
        for (; build_cursor_ < end; ++build_cursor_) {
            Il2CppObject* quest = all_quest_inputs_[build_cursor_].second;
            if (!quest) continue;

            if (quest_objectives::known_to_have_no_rows(quest)) continue;

            lines.clear();
            // The id comes along for the fault report only. collect() must never go looking
            // for it: a managed get_Id on the path that has just thrown is a second chance to
            // fault, and a fault inside a fault handler escapes to the per-quest guard.
            quest_objectives::collect(quest, lines, all_quest_inputs_[build_cursor_].first.c_str());
            if (lines.empty()) {
                quest_objectives::note_no_rows(quest);
                continue;
            }

            quest_objectives::quest_group group;
            group.id = all_quest_inputs_[build_cursor_].first;
            group.name = all_quest_inputs_[build_cursor_].first;
            for (const quest_objectives::objective& line : lines) {
                group.total++;
                if (line.done) group.done++;
            }
            group.known = quest_objectives::location_binding_of(quest, group.location);
            group.readable = quest_objectives::calls_readable(quest);
            group.lines = std::move(lines);
            build_collected_.push_back(std::move(group));
        }

        // NOT DONE YET. Return WITHOUT publishing: the next tick continues from the cursor.
        // Publishing a partial walk here would make the card claim a quest set it has not
        // read yet, which is the same class of defect as the stale list the empty-status
        // branch above exists to avoid.
        if (build_cursor_ < all_quest_inputs_.size()) return;

        std::vector<quest_objectives::quest_group>& collected = build_collected_;

        // THE BACKSTOP, applied here where it can rank. The limit is now the
        // player's own slider (quest_all_cap), defaulting to kAllQuestCap: 24
        // stopped being a backstop because 36 active quests is a normal
        // late-wipe profile, and 64 is roughly twice the largest set observed.
        // The honest reading is that the premise behind the cap expired, not
        // that the number needs raising forever: if a real profile reaches the
        // slider's maximum, the answer is a measurement of what reading a quest
        // costs, not a larger constant -- and the slider is what makes that
        // visible instead of burying it in a header.
        //
        // The cap is checked ONCE, over the finished walk, not incrementally. Applying it per
        // tick would truncate the walk mid-way and silently drop every quest past the cursor
        // -- which is the exact defect the pre-call resize was reverted for.
        const int all_cap = quest_all_cap->get_value();
        if (collected.size() > static_cast<size_t>(all_cap)) {
            next->all_capped = true;
        }

        // Rank into the order the card RENDERS (anywhere, zones, unreadable -- see
        // all_view_rank) BEFORE truncating, so what the cap drops is the bottom of what the
        // player reads rather than an arbitrary slice of the profile.
        //
        // stable_sort, NOT stable_partition, and the two are equivalent here: sorting by a
        // three-valued key with a stable sort leaves equal keys in their original relative
        // order, which is exactly what partitioning by that key does. Measured on this
        // toolchain: input ranks {2,0,1,0,2,1} tagged 0,1 in pairs sorts to ranks 001122 with
        // tags 010101, i.e. every bucket keeps the profile's order.
        //
        // It is stable_sort because std::stable_partition does not accept a binary predicate
        // on this MSVC (14.51.36231). Both partition overloads invoke the predicate UNARILY --
        // algorithm(6961), (6974), (6986) in std::partition and (7219), (7232) in
        // _Stable_partition_unchecked -- where the standard specifies pred(*it, *it). See
        // WORKFLOW.md's MSVC-gotchas section. std::sort and std::stable_sort are unaffected
        // and order_by_outstanding() has always used one of them.
        stage = "rank by view order";
        std::stable_sort(collected.begin(), collected.end(),
            [](const quest_objectives::quest_group& a, const quest_objectives::quest_group& b) {
                return quest_objectives::all_view_rank(a.known, a.location.zone_bound)
                     < quest_objectives::all_view_rank(b.known, b.location.zone_bound);
            });

        // The count the shortfall arithmetic needs, taken BEFORE the truncation so it is the
        // number actually dropped. See all_view_unreadable() for why passing the cap's limit
        // here instead was wrong.
        int capped_away = 0;
        if (next->all_capped) {
            capped_away = static_cast<int>(collected.size()) - all_cap;
            collected.resize(all_cap);
        }

        // Names come from the published LIST rather than being re-derived: the game already
        // resolved every name during the walk, and calling get_Name() again per quest here
        // would be a second managed call for a string we are already holding.
        stage = "attach names";
        const std::shared_ptr<const quest_list_snapshot> list = quest_list();
        next->groups.reserve(collected.size());
        for (quest_objectives::quest_group& group : collected) {
            quest_objectives_snapshot::grouped_objective out;
            out.quest_id = group.id;
            out.lines = std::move(group.lines);
            out.done = group.done;
            out.total = group.total;
            out.location = std::move(group.location);
            out.known = group.known;
            out.readable = group.readable;

            // A quest with no name keeps its id as its label, matching the dropdown row that
            // does the same -- so the heading and the dropdown entry the player clicked are
            // the same string, and neither is a blank line.
            out.quest_name = group.id;
            for (size_t qi = 0; qi < list->ids.size(); ++qi) {
                if (list->ids[qi] != group.id) continue;
                if (qi < list->names.size() && !list->names[qi].empty()) {
                    out.quest_name = list->names[qi];
                    break;
                }
                break;
            }

            next->groups.push_back(std::move(out));
        }

        next->all_shown = static_cast<int>(next->groups.size());

        // The OTHER cause of a shortfall: quests that produced no rows at all. Counted so the
        // card can say WHICH kind of shortfall it is instead of implying truncation.
        //
        // The subtraction, and its two earlier versions, are all in all_view_unreadable() with
        // the arithmetic spelled out. The short version: capped_away is the number the cap
        // ACTUALLY dropped, not the cap's limit, and the expression is clamped only because a
        // negative here is a bookkeeping bug rather than a fact about the player.
        next->all_unreadable = quest_objectives::all_view_unreadable(
            next->all_requested, next->all_shown, capped_away);

        // One line per BUILD, not per refresh -- there is no refresh, so this cannot flood,
        // and it is the number that says whether the card is showing what it should.
        //
        // capped_away is printed explicitly rather than left for the reader to subtract,
        // because until this line the three numbers could be made to agree by more than one
        // arithmetic and the disagreement was invisible.
        logger::info("quest build: " + std::to_string(next->all_requested) + " listed, "
            + std::to_string(next->all_shown) + " readable, "
            + std::to_string(next->all_unreadable) + " unreadable, "
            + std::to_string(capped_away) + " hidden by the cap"
            + (next->all_capped ? " (CAPPED)" : ""));

        stage = "store";
        // Clear the in-flight state BEFORE the publish, and release the accumulated groups:
        // leaving build_active_ set would restart the walk on the next tick against a list
        // that has already been consumed. The store is the last thing, so a throw anywhere
        // above leaves the build armed and the previous published snapshot untouched -- the
        // card shows stale data rather than a half-built one, which is the same choice the
        // original make-then-store ordering made.
        build_active_ = false;
        build_cursor_ = 0;
        build_collected_.clear();
        build_collected_.shrink_to_fit();
        build_target_.reset();
        objectives_published_.store(std::move(next));
    }
    catch (const std::exception& e) {
        // Two identifiers, narrowing the fault by different amounts: `stage` is the region of
        // THIS function, and quest_objectives::detail_stage_ names the specific managed call
        // inside collect(). e.what() alone is nearly useless -- on MSVC an il2cpp-raised
        // managed exception arrives as a bare HRESULT with no indication of origin.
        std::string where(stage);
        if (quest_objectives::detail_stage_)
            where += std::string(" / ") + quest_objectives::detail_stage_;
        quest_objectives::detail_stage_ = nullptr;

        logger::error("quest objectives: build_snapshot threw at stage '" + where + "': " + e.what());

        // Abandon the walk. Retrying from the same cursor forever would re-throw on the same
        // quest every frame, which is the "Reading objectives..." card the stage marker was
        // added to diagnose. The published snapshot is left as it was.
        build_active_ = false;
        build_cursor_ = 0;
        build_collected_.clear();
        build_collected_.shrink_to_fit();
        build_target_.reset();
    }
    catch (...) {
        logger::error(std::string("quest objectives: build_snapshot threw a non-std exception at stage '")
            + stage + "'");
        build_active_ = false;
        build_cursor_ = 0;
        build_collected_.clear();
        build_collected_.shrink_to_fit();
        build_target_.reset();
    }
}

void QuestModule::init() {
}
