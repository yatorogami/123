#pragma once
#include <exception>
#include <fstream>
#include <Windows.h>

#include <imgui.h>

#include "../Module.h"
#include "../ModuleCategory.h"
#include "../esp_text.h"
#include "../hotkeys.h"
#include "../../util/i18n.h"
#include "../item_pricing.h"
#include "../../config/ActionRowValue.h"
#include "../../config/CheckboxValue.h"
#include "../../config/FloatSliderEditableValue.h"
#include "../../config/InfoDrawValue.h"
#include "../../config/IntSliderEditableValue.h"
#include "../../config/MenuSectionValue.h"
#include "../../config/LanguageSelectValue.h"
#include "../../config/SelectValue.h"
#include "../game_state.h"

#include "../../util/globals.h"
#include "../../util/logger.h"

std::vector<Module*> static modules = {};
inline ConfigModule* config_module_self = nullptr;

class ConfigModule : Module
{
  public:
    ConfigModule(const std::vector<Module*>& m);

    static void for_each_module(const std::function<void(Module*)>& fn);

    SelectValue* config;

    ActionRowValue* load;

    ActionRowValue* save;

    ActionRowValue* reset_defaults;

    // NOTE: this section's key must stay distinct from the LanguageSelectValue's.
    // They used to share "menu_language_sec", so both produced the identical
    // config key `menu_language_sec##Configs`. MenuSectionValue::get() returns
    // {}, so its record wrote an EMPTY value that clobbered the real language
    // index in the load map, and the subsequent LanguageSelectValue::set("")
    // called std::stoi("") -- which throws std::invalid_argument. That escaped
    // load_config() entirely, so every value registered after this point kept
    // its default and the hotkey restore never ran: the config appeared not to
    // load. Renaming the section (rather than the selector) means a config
    // written by an older build now restores the language correctly instead of
    // being discarded, and the new section key is an inert extra entry.
    MenuSectionValue* section_language_;
    LanguageSelectValue* menu_language_;
    bool menu_language_initialized_ = false;

    MenuSectionValue* section_text_size_;
    IntSliderEditableValue* esp_text_font_size;
    IntSliderEditableValue* quest_esp_font_size;

    MenuSectionValue* section_esp_text_;
    CheckboxValue* esp_text_outline;
    CheckboxValue* esp_text_background;
    CheckboxValue* esp_text_clustering;
    CheckboxValue* esp_text_depth_sort;

    // Higher rate = more frequent ESP data scans (loot / containers / quests). 1 = default.
    MenuSectionValue* section_esp_update_;
    FloatSliderEditableValue* loot_update_rate;
    FloatSliderEditableValue* container_update_rate;
    FloatSliderEditableValue* quest_update_rate;
    // When on: auto scans for loot/containers/quests stop; refresh via button or hotkey only.
    CheckboxValue* esp_manual_refresh;
    ActionRowValue* esp_refresh_now;

    MenuSectionValue* section_market_prices_;

    ActionRowValue* update_market_prices;

    InfoDrawValue* market_prices_info_;

    MenuSectionValue* section_cache_;

    ActionRowValue* clear_cache;

    InfoDrawValue* cache_info_;

    static std::string format_bytes(const size_t bytes);

    void clear_all_caches();

    static void reset_all_to_defaults();

    void init_menu_language_options();

    void sync_menu_language_settings();

    void prepare_menu_draw() override;

    void draw_market_prices_info();

    void draw_cache_info();

    void draw_overlay(ImDrawList* draw_list) override;

    void application_update() override;

    void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
        Il2CppObjectInstance main_player) override;

    void init() override;

    // ------------------------------------------------------------------------
    //  WHERE THE CONFIG LIVES
    // ------------------------------------------------------------------------
    //  ta/configs/<config> inside the deployment folder, next to the DLL. It is
    //  in configs/ rather than loose in ta/ so that the one file a user is most
    //  likely to need to delete, copy or back up is not mixed in with the
    //  shipped read-only data (launcher.cfg, offsets.cfg, patterns.cfg, the
    //  compatibility manifests). See module_paths.h for the full layout.
    //
    //  It used to be %APPDATA%\TarkovAddons\<config>, which meant the file
    //  lived in a hidden profile, survived an uninstall, and did not move with
    //  the deployment. 3.2 put it directly in ta/; configs/ is a further
    //  refinement of that.
    //
    //  Two fallbacks sit behind this, and both are read-path fallbacks rather
    //  than only a migration concern:
    //
    //    1. previous_config_path() -- the 3.2 layout, which put the file
    //       directly in ta/. `deploy.py install` offers to move it into
    //       configs/, but a read that depended on that move having succeeded
    //       would reset the user to defaults the moment the move failed for
    //       any reason (an unwritable folder, a locked file, a partial earlier
    //       run). Reading the old path as well makes the settings file
    //       self-sufficient: the move is an optimisation that also tidies up,
    //       never a precondition for finding the user's config.
    //    2. legacy_config_path() -- the pre-3.2 %APPDATA% location, which
    //       load_config() has always fallen back to.
    //
    //  ensure_config_directory_wide() returning ta/ itself when configs/ cannot
    //  be created collapses case 1 automatically, since config_path() then
    //  resolves to exactly previous_config_path().
    // ------------------------------------------------------------------------
    static std::filesystem::path config_path(const std::string& config);

    // Where 3.2 kept the config: directly in ta/, not in configs/.
    static std::filesystem::path previous_config_path(const std::string& config);

    static std::filesystem::path legacy_config_path(const std::string& config);

    static void load_config(const std::string& config);

    static void save_config(const std::string& config);

    static std::ifstream create_config(const std::string& config);
};