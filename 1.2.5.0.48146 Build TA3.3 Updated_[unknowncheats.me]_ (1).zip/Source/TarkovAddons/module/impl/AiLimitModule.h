#pragma once
#include <algorithm>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <Windows.h>
#include <imgui.h>

#include "../../config/CheckboxValue.h"
#include "../../config/FloatSliderEditableValue.h"
#include "../../config/InfoDrawValue.h"
#include "../../config/IntSliderEditableValue.h"
#include "../../config/MenuSectionValue.h"
#include "../../il2cpp/Il2CppObjectInstance.h"
#include "../../il2cpp/il2utils.h"
#include "../../util/logger.h"
#include "../Module.h"
#include "../ModuleCategory.h"
#include "../eft_api.h"
#include "../game_state.h"
#include "PlayerModule.h"
#include "WorldModule.h"

// The bot-AI limiter, as its own card on the Bot Spawner tab.
//
// It was written inside WorldModule and drawn by the Bot Controls card, which
// put eight new sliders in a column that already held the bot-teleport pair --
// the "squished with the Bot Teleport card" complaint. Moving it here keeps the
// knobs with the behaviour they drive, keeps the Bot Controls card back to its
// original shape, and makes the tab read as three cards with one job each:
//
//   Bot Spawner  |  force-spawn, loot teleport
//   AI Limit     |  this card -- how many bots keep thinking
//   Bot Controls |  kill / teleport the bots that are there
//
// What it actually does, and where every member name was verified, is in the
// block comment at the top of AiLimitModule.cpp.
class AiLimitModule final : public Module
{
  public:
    // `player` supplies the two "invisible to AI" toggles, which live in
    // PlayerModule because their runtime, their hotkeys and their mutual
    // exclusion all do. This card only PRESENTS them, exactly as
    // BotControlModule presents WorldModule's bot-teleport values -- so the
    // config keys stay `##Player` and a saved setting survives the move, and
    // 350 lines of working code do not have to be re-verified.
    explicit AiLimitModule(WorldModule* world, PlayerModule* player);

    void draw_overlay(ImDrawList*) override;
    void application_update() override;
    void gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) override;
    void init() override;
    void draw_menu_extra() override;
    // The invisible-to-AI rows are drawn by hand so they sit ABOVE the limit's
    // sliders. See draw_menu_extra() and the ctor's hidden-flag comment.
    [[nodiscard]] bool draw_menu_extra_before_values() const override;
    // Carries the mutual exclusion, because application_update() is gated on
    // is_active() and is_active() is one of the values being policed.
    void prepare_menu_draw() override;

    // Both halves of this card need per-frame work: the limit while it is on,
    // the invisibility chain while either toggle is on. Returning false from
    // here would remove the card from the menu's card list, which is the
    // show_cone trap -- so this is only "is anything switched on", never
    // "should the controls be reachable".
    [[nodiscard]] bool is_active() const override {
        return ai_limit_enabled->get_value()
            || invisible_to_bots_ally->get_value()
            || invisible_to_bots_neutral->get_value();
    }

    // --- invisible to AI (moved from PlayerModule) ---------------------------
    enum class InvisibleToBots : int { neutral = 0, ally = 1 };

    // Walks every bot group and drops the local player out of its enemy map,
    // optionally adding the player to its Allies dictionary.
    static void apply_invisible_to_bots(Il2CppObjectInstance& game_world, Il2CppObject* local_player,
        InvisibleToBots mode);

    // The two toggles are mutually exclusive, so enabling one disables the other.
    void sync_invis_state();

    // The ally/neutral chain, with its own cadence. Separate from
    // gameworld_update's limit path so that switching the limit off cannot
    // disable it -- see the comment on the definition.
    void update_invisible_to_bots(Il2CppObjectInstance game_world_instance, Il2CppObject* local_player);

    // --- invisible to AI -----------------------------------------------------
    // Public because hotkeys_register.cpp binds them (hk_invisible_bots_*), which
    // is the convention for every other hotkey-bound value in this codebase.
    //
    // The two strengths of "invisible to bots": neutral is the weaker one (not an
    // enemy, but bots may investigate), ally is stronger (bots treat the player as
    // one of their own). Moved here from PlayerModule because both are
    // AI-perception behaviour and this card is where the rest of it lives -- see
    // the block comment at the top of the invisible-to-AI section in
    // AiLimitModule.cpp for the lag that move uncovered.
    CheckboxValue* invisible_to_bots_neutral;
    CheckboxValue* invisible_to_bots_ally;
    // Cadence gate for apply_invisible_to_bots. The two toggles are mutually
    // exclusive (sync_invis_state above), so one stamp serves both.
    ULONGLONG invisible_bots_last_ms_ = 0;

  private:
    // WorldModule owns the bot helpers this shares with the bot-teleport card
    // (bot_clear_goals, try_get_bot_owner_from_player). Both are static, so this
    // is a convenience handle rather than a dependency on its state.
    WorldModule* world_ = nullptr;
    // Supplies the two invisible-to-AI toggles; see the ctor comment.
    PlayerModule* player_ = nullptr;

    MenuSectionValue* section_ai_limit_;
    // Header for the two invisible-to-AI toggles presented by this card.
    MenuSectionValue* section_invisible_;
    CheckboxValue* ai_limit_enabled;
    // Fill the active-limit / distance sliders from the detected map's preset
    // when a raid starts. ailimit stores one pair per map; this keeps one live
    // pair and refills it, which is the same behaviour with 20 fewer config keys.
    CheckboxValue* ai_limit_auto_map;
    // The half of ailimit's park this does not do everywhere: after BotStandBy
    // has parked the bot, deactivate its GameObject so Unity stops updating it at
    // all. Safe where the raid has no server to disagree with; on a live one it is
    // a local lie. Whatever it does, only bots WE deactivated are woken.
    CheckboxValue* ai_limit_deactivate;
    IntSliderEditableValue* ai_limit_active;
    IntSliderEditableValue* ai_limit_distance;
    // Newly spawned bots are immune to parking for this long.
    FloatSliderEditableValue* ai_limit_grace;
    // Frames between scans. Lower reacts faster and costs more per second.
    IntSliderEditableValue* ai_limit_interval;
    InfoDrawValue* ai_limit_info_;

    // One bot for one scan. Rebuilt from AllAlivePlayersList every pass, so no
    // Il2CppObject* outlives the list it came from.
    struct ai_limit_slot
    {
        Il2CppObject* player = nullptr;
        float dist_sq = 0.f;
        // Younger than the grace window: never parked, never woken by us.
        bool eligible = false;
        bool keep_awake = false;
    };

    // Fill the active-limit / distance sliders from `location_id`'s preset row.
    // Returns false when the map is not in the table, and leaves both alone.
    bool ai_limit_fill_from_map(const std::string& location_id);

    void ai_limit_draw_info();

    // Walk the whole BotOwner -> BotStandBy chain on a live bot and report
    // whether every link resolves. Called once per raid, so a rename on a new
    // game build is one log line rather than one per scan.
    static bool ai_limit_chain_resolves(Il2CppObject* bot_owner);

    // Resolve BotOwner.StandBy, which every park/wake path needs.
    static Il2CppObject* ai_limit_get_standby(Il2CppObject* bot_owner);

    // Park (or wake) one bot through BotStandBy. `bot_owner` and `player` must
    // both be live: the owner carries the AI, the player carries the GameObject.
    // Not static: it reads ai_limit_deactivate and writes ai_limit_deactivated_,
    // and a static version of this failed to compile for exactly that reason.
    void ai_limit_set_bot_standby(Il2CppObject* bot_owner, Il2CppObject* player, const bool park);

    std::vector<ai_limit_slot> ai_limit_slots_;
    // Bots whose GameObject this feature deactivated. The wake path only
    // SetActive(true)s a bot that is in here, so a bot the GAME deactivated is
    // never switched back on behind its back -- and a bot that despawned or died
    // while parked leaves the set on the next pass rather than being remembered
    // until the raid ends.
    std::unordered_set<Il2CppObject*> ai_limit_deactivated_;
    // First time we saw each bot, for the spawn grace window. Keyed on the
    // object address and pruned every pass, so a dead bot leaves no trace and a
    // recycled address can only cost one bot its grace period.
    std::unordered_map<Il2CppObject*, ULONGLONG> ai_limit_first_seen_ms_;
    int ai_limit_frame_ = 0;
    int ai_limit_awake_ = 0;
    int ai_limit_total_ = 0;
    std::string ai_limit_location_;
    bool ai_limit_was_enabled_ = false;
    // Set once the per-raid summary line has been emitted, so it is one line
    // per raid rather than one per scan.
    bool ai_limit_reported_ = false;
    // Raid-scoped so a build that renames a link gets exactly one warning.
    bool ai_limit_chain_checked_ = false;
    bool ai_limit_chain_broken_ = false;
};
