#include "common.h"
#include "WatermarkModule.h"
#include "../../gui/menu/menu.h" // menu::get_hud_font, reached only
                                  // transitively before menu_style.h split

WatermarkModule::WatermarkModule() : Module("Watermark", Config, "watermark_mod"),
                                     enabled(conf(new CheckboxValue(true, "enabled_cb"))),
                                     text(conf(new TextboxValue(globals::get_display_title(), "text_txt"))),
                                     color(conf(new ColorpickerValue({0.314f, 0.722f, 0.871f, 1.0f}, "color_clr"))),
                                     font_size(conf(new IntSliderEditableValue(16, 8, 36, "font_size_itm"))) {
    // Keep the implementation, but omit this card from the Configs UI.
    hidden_in_category_menu = true;
    for (ConfigValue* value : config_values)
        value->set_hidden_in_owner_menu(true);
}

void WatermarkModule::draw_overlay(ImDrawList* draw_list) {
    if (!enabled->get_value()) return;
    // Always current build title (saved config may still hold an old version string).
    const std::string title = globals::get_display_title();
    draw_list->AddText(menu::get_hud_font(),
        static_cast<float>(font_size->get_value()) * menu::get_scale_factor(), {10, 10},
        ImGui::GetColorU32(menu::palette::accent), title.c_str());
}

void WatermarkModule::application_update() {
    TA_ZONE_N("watermark::application_update");
    // The watermark is always displayed; its Configs card remains hidden.
    enabled->set_value(true);
    // Keep conf text in sync so menu shows the real version after config load.
    const std::string title = globals::get_display_title();
    if (text->get() != title)
        text->set(title);
}

void WatermarkModule::gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
    Il2CppObjectInstance main_player) {
}

void WatermarkModule::init() {
    text->set(globals::get_display_title());
}

void WatermarkModule::prepare_menu_draw() {
    for (ConfigValue* value : config_values)
        value->set_disabled(true);
}
