#include "common.h"
#include "ProfileModifiersModule.h"

ProfileModifiersModule::ProfileModifiersModule(PlayerModule* player) : Module("Trader Editor", ProfileEditor, "trader_editor_mod"), player_(player) {
    if (!player_) return;
    profile_values_ = {
        player_->fence_rep_source, player_->fence_rep_amount,
        player_->add_fence_rep, player_->trader_select, player_->trader_rep_amount,
        player_->add_trader_rep};
    for (ConfigValue* value : profile_values_)
        value->set_hidden_in_owner_menu(true);
}

void ProfileModifiersModule::draw_overlay(ImDrawList*) {}

void ProfileModifiersModule::application_update() {}

void ProfileModifiersModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) {}

void ProfileModifiersModule::init() {}

[[nodiscard]] bool ProfileModifiersModule::draw_menu_extra_before_values() const { return true; }

void ProfileModifiersModule::draw_menu_extra() {
    for (ConfigValue* value : profile_values_)
        if (value) value->draw();
}
