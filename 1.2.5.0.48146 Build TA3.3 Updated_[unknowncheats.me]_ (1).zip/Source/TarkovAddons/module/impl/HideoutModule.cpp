#include "common.h"
#include "HideoutModule.h"

// Note: area_select (SelectValue) copies option strings into its own internal storage on
// set_options() and returns pointers into that storage from get_options() — it owns that
// memory, not us. Do NOT delete[] anything returned by get_options() here.
HideoutModule::~HideoutModule() {
}

HideoutModule::HideoutModule() : Module("Hideout", ProfileEditor, "hideout_mod"),
                                 open_hideout(conf(new ActionRowValue([this] {
                                     request_open_hideout();
                                 },
                                     "open_hideout_btn"))),
                                 area_search(conf(new TextboxValue("", "area_search_txt"))), area_select(conf(new SelectValue(0, {}, "area_sel"))) {
    // Publish an empty version up front. A default-constructed
    // atomic<shared_ptr> is NULL, and every reader does `snapshot()->field` — so the very
    // first application_update (which runs immediately after the asset bundle load, before
    // any refresh has run) would dereference a null shared_ptr. Publishing in the
    // constructor makes "no data yet" a real, safe state instead of a crash.
    published_ready_.store(false, std::memory_order_release);
    published_.store(std::make_shared<const hideout_snapshot>());
}

void HideoutModule::draw_overlay(ImDrawList*) {
    // Everything below reads ONE pinned snapshot. The game thread may publish a newer one
    // at any moment, but this shared_ptr keeps the version we started with alive and
    // immutable, so no vector can be reallocated underneath the loop.
    //
    // No raid gating here: the data is collected OUTSIDE a raid (the hideout does not
    // exist in one), so clearing on !is_in_raid used to wipe exactly the state the refresh
    // had just produced.
    const std::shared_ptr<const hideout_snapshot> snap = snapshot();

    // Rebuilding the option list costs ~2 string allocations per area plus a full copy of
    // SelectValue's option buffer, and draw_overlay runs every rendered frame. Redo it only
    // when the search text or the underlying area data actually moved.
    const std::string search = area_search->get();
    if (snap->area_revision == built_area_revision_ && search == built_search_) return;
    built_area_revision_ = snap->area_revision;
    built_search_ = search;

    const std::string search_lower = hideout_to_lower(search);

    std::vector<std::string> new_display_names;
    std::vector<std::string> new_filtered_ids;
    new_display_names.reserve(snap->area_names.size() + 1);
    new_filtered_ids.reserve(snap->area_names.size() + 1);

    // "ALL" IS OPTION 0, and it is a real option rather than a special case bolted onto each
    // consumer: it occupies a slot in BOTH vectors, so every index into area_select stays aligned
    // with filtered_area_ids_. Appending it last was rejected because "All" is the only useful
    // default when the card opens - the dropdown's own default is index 0.
    //
    // The sentinel is the EMPTY id rather than a magic number, because ids are
    // std::to_string(EAreaType) and "0" is a real area (the hideout root). "" cannot collide with
    // a real id by construction.
    //
    // Search deliberately does NOT filter this row out: "All" means all areas whatever is typed,
    // and a filter box that hides its own no-filter option is a trap.
    new_display_names.push_back(i18n::tr("hideout_area_all"));
    new_filtered_ids.push_back(std::string());

    for (size_t i = 0; i < snap->area_names.size(); ++i)
    {
        if (!search_lower.empty() && hideout_to_lower(snap->area_names[i]).find(search_lower) == std::string::npos)
            continue;

        // AreaInfo has no "max level" concept (no NextStage to be null), so the prefix
        // shows the level and whether the player actually owns the area.
        const std::string prefix = "[Lv " + std::to_string(snap->area_levels[i]) + "] "
            + (snap->area_active[i] ? "" : "(locked) ");
        new_display_names.push_back(prefix + snap->area_names[i]);
        new_filtered_ids.push_back(snap->area_ids[i]);
    }

    // set_options() copies these into SelectValue's own storage immediately, so pointers
    // into the locals stay valid for the call and SelectValue owns them from then on.
    // SelectValue is touched HERE, on the render thread, and nowhere else — the game
    // thread only publishes the labels.
    std::vector<const char*> option_ptrs;
    option_ptrs.reserve(new_display_names.size());
    for (const std::string& name : new_display_names)
        option_ptrs.push_back(name.c_str());

    filtered_area_ids_ = std::move(new_filtered_ids);
    area_select->set_options(option_ptrs);
    if (static_cast<size_t>(area_select->get_value()) >= option_ptrs.size())
        area_select->set_value(0);
}

void HideoutModule::prepare_menu_draw() {
    const std::shared_ptr<const hideout_snapshot> snap = snapshot();
    const bool in_raid = game_state::is_in_raid;
    // Open Hideout only asks the client to show its own screen, so it is gated on the raid
    // flag alone. Everything else here is a local read.
    open_hideout->set_disabled(in_raid);
    // The area tools read the hideout, which only exists outside a raid — so they follow
    // the snapshot's data, not the raid flag. This is the inversion that used to
    // leave them permanently dead: they were enabled in raid, where no data can arrive.
    //
    // `stale` counts as having data. `ready` means "live and refreshable"; a stale
    // snapshot is our own copy of a hideout that has closed, and the whole point of
    // retaining it is that the zone list and its requirements stay readable in a raid.
    // Gating these two lines off `ready` alone is what made the card go dead and stay dead
    // after the hideout closed.
    const bool have_area_data = snap->ready || snap->stale;
    area_search->set_disabled(!have_area_data);
    area_select->set_disabled(!have_area_data || snap->area_names.empty());

    // Every control is laid out by hand in draw_menu_extra, so the framework's automatic
    // pass must not draw them a second time. This is what buys the grouped layout below.
    // The values stay registered so their config keys keep round-tripping.
    //
    // The list here is ALSO the inventory of what draw_menu_extra actually renders. A control
    // that is registered and hidden but never ->draw()ed is unreachable, and get_materials was
    // exactly that for the whole life of the area-requirements feature: constructed, toggled
    // here, registered here, and drawn nowhere. Its handler chain (request_area_requirements ->
    // probe_live_upgrade_requirements -> probe_area_requirements, plus run_log_area_details and
    // the queue_area_requirements_ flag) was dead with it and has been removed. Anything added
    // here has to get a ->draw() call in draw_menu_extra or it will not appear.
    for (ConfigValue* value : {static_cast<ConfigValue*>(open_hideout),
             static_cast<ConfigValue*>(area_search), static_cast<ConfigValue*>(area_select)})
        value->set_hidden_in_owner_menu(true);
}

void HideoutModule::group_label(const char* text) {
    ImGui::Dummy(ImVec2(0, ImGui::GetStyle().ItemSpacing.y));
    ImGui::TextColored(menu::palette::muted, "%s", text);
}

void HideoutModule::group_label(const char* text, const std::string& right) {
    group_label(text);
    if (right.empty()) return;
    ImGui::SameLine(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x
        - ImGui::CalcTextSize(right.c_str()).x);
    ImGui::TextColored(menu::palette::muted, "%s", right.c_str());
}

void HideoutModule::draw_menu_extra() {
    // THE CARD'S OWN COST, which had no measurement at all until 2026-10-01.
    //
    // Every hideout zone that existed was in production_panel_probe.h and covered the GAME's code -
    // hooked calls, the panel's rebuild, the rows. This card is module code, so "the hideout
    // overhead is negligible" was an inference from the log's walk timings with the largest single
    // component, the per-frame ImGui draw, simply unmeasured. This zone closes that.
    //
    // It is expected to be tens of microseconds and it runs every frame the card is unfolded, so if
    // it ever reads milliseconds that is a real finding rather than a rounding error.
    TA_ZONE_N("hideout::Card::draw_menu_extra");
    const std::shared_ptr<const hideout_snapshot> snap = snapshot();
    const bool in_raid = game_state::is_in_raid;
    const float sf = menu::get_scale_factor();
    const std::string status = current_status();

    // ---- SESSION ------------------------------------------------------
    group_label(i18n::tr("hideout_section_session").c_str());
    open_hideout->draw();

    // ---- CRAFTING -----------------------------------------------------
    group_label(i18n::tr("hideout_section_crafting").c_str(),
        snap->productions.empty() ? std::string()
                                  : std::to_string(snap->productions.size()));
    if (snap->productions.empty())
    {
        ImGui::TextColored(menu::palette::muted, "%s",
            i18n::tr("hideout_nothing_running").c_str());
    }
    for (const ProductionInfo& prod : snap->productions)
    {
        ImGui::PushID(prod.recipe_id.c_str());

        // The item being made, not the recipe id. Product label comes from
        // ProductionData.Products[]._tpl, which is the authoritative result; the id is
        // kept as a dim suffix so a row is still identifiable when the label is missing.
        const std::string name = prod.product_label.empty()
            ? describe_recipe(prod.recipe_id)
            : prod.product_label;
        ImGui::TextUnformatted(name.c_str());
        if (!prod.product_label.empty())
        {
            ImGui::SameLine();
            ImGui::TextColored(menu::palette::muted, "  %.8s", prod.recipe_id.c_str());
        }

        // Read through the interpolating view rather than off the snapshot directly. The
        // snapshot is rebuilt at 1 Hz, but the value it carries is the server's Progress,
        // which only moves when the server refreshes it — so drawing the raw field froze both
        // the bar and the clock. production_view_now adds the wall time since the sample was
        // taken, and the next refresh re-anchors to the server.
        const production_view view_now = production_view_now(prod);

        char progress_label[32];
        std::snprintf(progress_label, sizeof(progress_label), "%.0f%%", view_now.progress * 100.0f);
        // The bar keeps a fixed height so a row's button does not shift as the percentage
        // text changes width between frames.
        ImGui::ProgressBar(view_now.progress, ImVec2(-1, 0), progress_label);

        // Status and remaining time on one line, with the row's action pushed right.
        std::string state;
        ImVec4 state_colour = menu::palette::muted;
        if (prod.available_for_finish)
        {
            state = i18n::tr("hideout_ready_to_collect");
            state_colour = ImVec4(0.25f, 0.85f, 0.35f, 1.0f);
        }
        else if (prod.interrupted)
        {
            state = i18n::tr("hideout_interrupted");
            state_colour = ImVec4(1.0f, 0.55f, 0.15f, 1.0f);
        }
        else if (prod.in_progress)
        {
            state = i18n::tr("hideout_in_progress");
        }
        else
        {
            state = i18n::tr("hideout_paused");
        }
        // Only while the job is actually advancing. A row that is not in_progress has a deadline
        // the game is not ticking, so its "remaining" is frozen and meaningless - and worse than
        // meaningless, because it can exceed the total. Measured 2026-10-01 00:17, this row:
        //
        //     5d5589c1=19500/12187
        //
        // 19500 s left on a 12187 s job, identical across eight consecutive sweeps, on a
        // production the DTO reports as in_progress=no / interrupted=no with only 244 s of
        // 12187 s done. So it is stopped, not slow, and the card was drawing "Paused  05:25:00" -
        // a countdown for something that will never reach zero, running backwards past the total.
        //
        // The state line above already says "Paused", which is the whole truth for this row. A
        // stopped job does not have a remaining time, so it does not get a clock.
        if (prod.in_progress && prod.production_time > 0 && !prod.available_for_finish)
        {
            // Seconds left comes from the server's own two durations, not from the wall clock.
            // StartTimestamp is present and readable but is NOT seconds-since-epoch — the
            // 2026-09-27 log showed 1765208473 against a 2026 clock, i.e. ~290 days ago — so
            // the old now-minus-start countdown rendered as ~25 million seconds and the bars
            // pinned at 100%. production_time - raw_progress is the game's own arithmetic.
            char clock[16];
            if (view_now.seconds_left > 0)
                std::snprintf(clock, sizeof(clock), "%02d:%02d:%02d",
                    view_now.seconds_left / 3600,
                    (view_now.seconds_left % 3600) / 60,
                    view_now.seconds_left % 60);
            else
                std::snprintf(clock, sizeof(clock), "--:--:--");
            state += "  " + std::string(clock);
        }
        ImGui::TextColored(state_colour, "%s", state.c_str());

        // No action button on this row. It used to offer Collect when a job was done and
        // Cancel otherwise, both of which are server requests — see the class-level note.
        // The row is now a pure readout of what the job is doing.
        ImGui::Dummy(ImVec2(0, ImGui::GetStyle().ItemSpacing.y * 0.5f));
        ImGui::PopID();
    }

    // ---- RESOURCES -----------------------------------------------------
    // Fuel and water, not output. The water plant and the generator drain a supply to keep
    // running, so what matters is how much is left and how long that lasts — a product name
    // and a crafting progress bar would both be fiction. The bar is the fraction the game's
    // own ConsumptionTimer reports, and the countdown is the same timer's remaining value,
    // so this is the facility's real state and not a re-derivation of it.
    if (!snap->resources.empty())
    {
        group_label(i18n::tr("hideout_section_resources").c_str(),
            std::to_string(snap->resources.size()));
        for (const hideout_resource& res : snap->resources)
        {
            ImGui::PushID(res.area_type);
            ImGui::TextUnformatted(
                (res.area_name.empty() ? i18n::tr("hideout_section_resources") : res.area_name)
                    .c_str());

            const float fraction = res.fraction();
            char gauge_label[48];
            if (res.timer_total > 0)
            {
                std::snprintf(gauge_label, sizeof(gauge_label), "%.0f%%  %s",
                    fraction * 100.0f,
                    res.is_working ? i18n::tr("hideout_consuming").c_str()
                                   : i18n::tr("hideout_idle").c_str());
            }
            else
            {
                // No timer on this facility (never filled, or drained to nothing). Fall back
                // to the raw resource totals, which are still a real remaining fraction.
                std::snprintf(gauge_label, sizeof(gauge_label), "%.0f%%  %.0f/%.0f",
                    fraction * 100.0f, res.resource_left, res.resource_total);
            }
            ImGui::ProgressBar(fraction, ImVec2(-1, 0), gauge_label);

            // Time to empty, and what is actually installed.
            std::string detail;
            if (res.timer_left > 0)
            {
                char clock[16];
                const int h = res.timer_left / 3600;
                const int m = (res.timer_left % 3600) / 60;
                const int s = res.timer_left % 60;
                std::snprintf(clock, sizeof(clock), "%02d:%02d:%02d", h, m, s);
                detail = std::string(clock) + " " + i18n::tr("hideout_time_left");
            }
            else if (!res.is_on)
            {
                detail = i18n::tr("hideout_resource_off");
            }
            if (!detail.empty())
                ImGui::TextColored(menu::palette::muted, "  %s", detail.c_str());

            // Slot pips.
            //
            // Capacity (MaxSuppliesCount) is real; the remaining share is the game's single
            // aggregate divided across the slots. So this says "this much of the total supply
            // is left", which is true, rather than asserting which specific slots are spent —
            // BarterItem exposes no accessors and the consumer holds one aggregate double, so
            // the distribution across slots is not knowable. See hideout_resource::slots_remaining.
            if (res.supplies_capacity > 0)
            {
                const int lit = static_cast<int>(res.slots_remaining() + 0.5f);
                std::string pips;
                pips.reserve(static_cast<size_t>(res.supplies_capacity) * 2 + 1);
                for (int i = 0; i < res.supplies_capacity; ++i)
                    pips += (i < lit ? "\xE2\x96\x88" : "\xE2\x96\x91"); // full / empty block
                ImGui::TextColored(menu::palette::muted, "  %s  %d/%d",
                    pips.c_str(), lit, res.supplies_capacity);
            }
            else if (res.supplies_installed > 0)
            {
                ImGui::TextColored(menu::palette::muted, "  %d %s",
                    res.supplies_installed, i18n::tr("hideout_supplies").c_str());
            }

            ImGui::Dummy(ImVec2(0, ImGui::GetStyle().ItemSpacing.y * 0.5f));
            ImGui::PopID();
        }
    }

    // ---- AREAS --------------------------------------------------------
    group_label(i18n::tr("hideout_section_areas").c_str(),
        snap->area_names.empty() ? std::string()
                                 : std::to_string(snap->area_names.size()));
    area_search->draw();
    area_select->draw();

    // ---- UPGRADE MATERIALS --------------------------------------------
    //
    // Permanent rather than behind the button: the list is the reason to open the card at all, and
    // it is collected on a 30 s clock so the steady state is a cached walk. See the collect block
    // in refresh_hideout_state for the cadence and the read-only guarantee.
    group_label(i18n::tr("hideout_section_upgrades").c_str(),
        snap->upgrades.areas.empty() ? std::string()
                                     : std::to_string(snap->upgrades.areas.size()));

    if (!snap->upgrades.reachable)
    {
        // Branch on snap->ready, NOT on representation_found. This said "Reach the hideout to read
        // upgrade requirements" for two whole minutes while the player was standing in the hideout
        // watching a populated Areas section render directly above it - 2026-10-03, hideout open
        // 17:49:21, first reachable collect 17:51:22. snap->ready is the snapshot's own answer to
        // "is the hideout loaded", and when it is true the hideout is demonstrably loaded, so
        // telling the player to go there is not a near-miss: it contradicts the section above it.
        //
        // representation_found cannot decide this on its own. It is false both when the player is
        // elsewhere AND when they are in the hideout but the controller has not been captured yet,
        // and those need opposite sentences. The two middle states - holding a representation
        // without its area list, and holding neither - share one honest answer, so they share a
        // string; hideout_requirements_unavailable already existed for exactly that and was
        // previously only reachable from the button at the bottom of this file.
        ImGui::TextColored(menu::palette::muted, "%s", i18n::tr(snap->ready
                                                               // In the hideout. The data is not readable yet - open a station so
                                                               // ShowProduceView fires and the controller is captured.
                                                               ? "hideout_requirements_unavailable"
                                                               // Not in the hideout, so this one is actually true.
                                                               : "hideout_upgrades_unavailable")
                                                           .c_str());
    }
    else if (snap->upgrades.areas.empty())
    {
        // Reachable, the list was walked, and nothing came back with a next stage. Whether that
        // means "finished" or "we failed to read them" is decided by the two counters, NOT by
        // this list being empty - an unreadable area also yields no requirements, so an empty
        // list on its own is not evidence of a maxed hideout.
        //
        // Claiming "all stations are at their maximum level" requires that at least one area was
        // actually classified as finished AND none went unclassified. Any unknown and the honest
        // answer is that the read is incomplete, which is a different sentence from either of
        // the other two.
        ImGui::TextColored(menu::palette::muted, "%s", i18n::tr((snap->upgrades.areas_maxed > 0 && snap->upgrades.areas_unknown == 0) ? "hideout_requirements_empty"      // read it, and it is genuinely all maxed
                                                                                                                                      : "hideout_requirements_incomplete" // read it, but some areas were unreadable
                                                           )
                                                           .c_str());
    }
    else
    {
        // WHICH AREAS THIS SECTION SHOWS is the Show-area selection, resolved here rather than
        // baked into the snapshot: the snapshot is shared with the game thread and the selection
        // is render-owned, so filtering here keeps the two apart.
        //
        // ids are std::to_string(EAreaType) (refresh_areas, `ids.push_back(std::to_string(type))`)
        // and upgrade_area.area_type is that same enum, so the match is a string compare on the
        // integer and needs no new mapping table.
        const int sel = area_select->get_value();
        const std::string sel_id =
            (sel >= 0 && static_cast<size_t>(sel) < filtered_area_ids_.size())
            ? filtered_area_ids_[static_cast<size_t>(sel)]
            : std::string();
        const bool all = sel_id.empty(); // the option-0 sentinel, or nothing selected yet

        // ALL: the summed roll-up alone. This is the answer to "what should I go and pick up", and
        // totals is already exactly that - summed across every area, keyed by template, with an
        // item two areas both want counted ONCE (see the used_by note below). So "All" is not a
        // new computation, it is the roll-up promoted to the whole section.
        //
        // A SPECIFIC AREA: its own rows, and its own share of the totals. Showing the global
        // roll-up under one area's heading would be a lie by omission - those are not that
        // area's requirements.
        std::vector<const upgrade_area*> shown;
        if (all)
        {
            for (const upgrade_area& a : snap->upgrades.areas) shown.push_back(&a);
        }
        else
        {
            for (const upgrade_area& a : snap->upgrades.areas)
                if (std::to_string(a.area_type) == sel_id) shown.push_back(&a);
        }

        if (shown.empty())
        {
            // The selection names an area with nothing pending. That is different from "the
            // hideout is finished" and must not borrow its wording.
            ImGui::TextColored(menu::palette::muted, "%s",
                i18n::tr("hideout_requirements_none_for_area").c_str());
        }
        else
        {
            // Per-area, then the roll-up. The roll-up comes SECOND on purpose: it is the answer to
            // "what should I go and pick up", and it only makes sense once the per-area rows explain
            // why those items are wanted.
            for (const upgrade_area* area_ptr : shown)
            {
                const upgrade_area& area = *area_ptr;
                ImGui::PushID(area.area_type);
                const std::string heading = area.name.empty()
                    ? ("area " + std::to_string(area.area_type))
                    : area.name;
                group_label((heading + "  " + i18n::tr("hideout_upgrades_next_level") + " "
                    + std::to_string(area.current_level) + " -> "
                    + std::to_string(area.next_level))
                        .c_str());
            // A stage that EXISTS but is not available yet is a different state from one that is
            // available and needs nothing, and an empty requirement list is how the first was
            // being rendered - so the card showed a bare "0 -> 1" with no rows and no reason.
            // Measured 2026-10-03: the hideout's only pending area was the seasonal Christmas
            // tree, two months out, and the card gave no hint of that.
            // Stage.<StartTime>k__BackingField says when it opens; say it here.
            if (area.start_time_ticks > 0)
            {
                // DateTime ticks count from 0001-01-01; this is the offset to the Unix epoch.
                static constexpr long long kTicksToUnixEpoch = 621355968000000000LL;
                const long long unix_secs =
                    (area.start_time_ticks - kTicksToUnixEpoch) / 10000000LL;
                if (unix_secs > 0)
                {
                    const std::time_t t = static_cast<std::time_t>(unix_secs);
                    std::tm tm_utc{};
#if defined(_WIN32)
                    gmtime_s(&tm_utc, &t);
#else
                    gmtime_r(&t, &tm_utc);
#endif
                    char buf[32];
                    std::strftime(buf, sizeof(buf), "%Y-%m-%d", &tm_utc);
                    ImGui::TextColored(menu::palette::muted, "  %s %s",
                        i18n::tr("hideout_upgrades_available_from").c_str(), buf);
                }
            }
                for (const upgrade_requirement& req : area.requirements)
                {
                    ImGui::TextUnformatted(req.label.c_str());
                    if (req.have_known)
                        ImGui::SameLine();
                    ImGui::TextColored(req.have >= req.need ? menu::palette::accent
                                                            : menu::palette::muted,
                        "%d / %d", req.have, req.need);
                }
                ImGui::PopID();
            }

            // The roll-up, restricted to the shown areas. Under "All" that is every area, which is
            // the pre-existing behaviour; under one area it is that area's own share. total_index in
            // collect_upgrade_plan already guarantees one row per template with need summed and have
            // taken once, so this reproduces the game-wide roll-up exactly when `all` is true.
            {
                std::map<std::string, const upgrade_plan::total*> totals_by_id;
                for (const upgrade_plan::total& t : snap->upgrades.totals)
                    totals_by_id.emplace(t.template_id, &t);

                std::vector<const upgrade_plan::total*> rollup;
                for (const upgrade_area* area_ptr : shown)
                {
                    for (const upgrade_requirement& r : area_ptr->requirements)
                    {
                        if (!r.is_item || r.template_id.empty()) continue;
                        auto it = totals_by_id.find(r.template_id);
                        if (it == totals_by_id.end()) continue;
                        bool already = false;
                        for (const upgrade_plan::total* seen : rollup)
                            if (seen->template_id == r.template_id)
                            {
                                already = true;
                                break;
                            }
                        if (!already) rollup.push_back(it->second);
                    }
                }

                if (!rollup.empty())
                {
                    group_label(i18n::tr("hideout_upgrades_total").c_str(),
                        std::to_string(rollup.size()));
                    for (const upgrade_plan::total* t : rollup)
                    {
                        ImGui::PushID(t->template_id.c_str());
                        ImGui::TextUnformatted(t->label.c_str());
                        // used_by is what makes the roll-up trustworthy: an item two areas both want is
                        // counted once in the total, not twice, and this says so on the row.
                        ImGui::SameLine();
                        ImGui::TextColored(menu::palette::muted, "x%d  (%s %d)",
                            t->used_by, i18n::tr("hideout_upgrades_have_need").c_str(),
                            t->have_known ? t->have : 0, t->need);
                        ImGui::PopID();
                    }
                }
            }
        }
    }

    if (!status.empty())
        imgui_addons::status_line(status, true);
}

void HideoutModule::application_update() {
}

void HideoutModule::application_update(Il2CppObject* application) {
    // Hideout state is collected HERE, outside a raid, because the hideout does not exist
    // in one. The dispatcher (module/common_hooks.h) only calls gameworld_update while
    // is_in_raid, so anything hideout-related placed there can never run.
    refresh_hideout_state(application);

    // Polled, not called once, and it installs against the live hideout rather than against the
    // mere presence of the type: resolve_class() by name succeeds at startup, well before the
    // hideout exists, and resolve_method() does not runtime-init the class, so that timing
    // produced silent failures. refresh_hideout_state above has just refreshed live_hideout_.
    // One atomic load per frame once installed. Qualified: install() is namespaced.
    production_panel_probe::production_panel_probe_install(live_hideout_);

    // Pays any rebuild that the coalescing gate dropped. Must be the game thread and must be
    // per-frame: it calls the game's own UpdateViews, and the debt has to land promptly or the
    // panel sits showing stale counts. Early-out is one relaxed atomic load.
    production_panel_probe::production_panel_probe_tick();

    if (game_state::is_in_raid)
    {
        discard_menu_actions("Hideout menu actions are only available outside raids.");
        return;
    }
    if (!has_pending_menu_actions()) return;

    Il2CppObject* menu_operation = get_object_field(application, "_menuOperation");
    if (!menu_operation)
    {
        discard_menu_actions("Hideout menu operation is unavailable.");
        return;
    }

    // The one remaining queued action. It resolves _menuOperation._session and calls
    // OpenHideoutAtMainPointSync on it — both client-side, and neither is a production verb.
    //
    // The _session lookup below this used to feed Take / Cancel / Reset / Start, and is gone
    // with them: nothing in this module sends a request to the server any more, so there is no
    // reason to reach for a session at all.
    if (open_hideout_action_.take(true))
        open_hideout_at_main_point(menu_operation);
}

void HideoutModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) {
    // Intentionally empty.
    //
    // The dispatcher only calls this while is_in_raid, and there is no hideout in a raid —
    // the user's own observation, and the reason every hideout read used to be dead code
    // here. Do NOT move hideout work into this function: main_player exists in a raid, but
    // Profile.Hideout does not, so the reads resolve to nothing.
    //
    // Anything hideout-related belongs in application_update(Il2CppObject*), which runs in
    // both phases and can reach the Profile through
    // TarkovApplication._menuOperation._profile (ISIL MainMenuShowOperation.txt:438).
}

void HideoutModule::init() {
}

std::unordered_map<std::string, int> HideoutModule::hideout_last_recipe_to_area(
    const HideoutModule::hideout_snapshot& snap) {
    std::unordered_map<std::string, int> map;
    const size_t count = (std::min)(snap.area_last_recipe.size(), snap.area_ids.size());
    for (size_t i = 0; i < count; ++i)
    {
        if (snap.area_last_recipe[i].empty()) continue;
        map.emplace(snap.area_last_recipe[i], std::atoi(snap.area_ids[i].c_str()));
    }
    return map;
}

[[nodiscard]] std::shared_ptr<const HideoutModule::hideout_snapshot> HideoutModule::snapshot() const {
    if (std::shared_ptr<const hideout_snapshot> current = published_.load())
        return current;
    static const std::shared_ptr<const hideout_snapshot> empty =
        std::make_shared<const hideout_snapshot>();
    return empty;
}

// Whether a snapshot has ever been published, WITHOUT taking a reference on it.
//
// This exists because snapshot() returns a shared_ptr BY VALUE, so every call is an atomic
// increment followed by an atomic decrement. That is the right interface for a reader that is
// going to hold the snapshot for a while - the render thread genuinely needs the reference - and
// the wrong one for a caller that only wants to read one bool and drop it.
//
// Measured cost of getting that wrong, 2026-10-02 15:11 capture. After the throttle was moved
// above the probe in 1753b04a the per-call mean fell from 908 us to 483 us - a real improvement,
// but nowhere near the near-zero that an early return should cost, and the reason was not the
// throttle:
//
//     171 real refreshes, mean 7.1 ms          =  1.2 s of actual work
//     n = 50,634 calls, total 25.0 s
//     50,463 calls that returned early         = 23.8 s, i.e. 471,476 ns EACH
//
// The early-return path does three things: the Tracy zone, one bool, and snapshot()->ready. Only
// the last can cost anything, and it is called TWICE on that path - once in the is_in_raid branch
// at line 479 and once in the throttle condition at line 522. Two shared_ptr round-trips is
// ~940 ns, which is the whole residual.
//
// The throttle itself is confirmed correct by the log: 171 refreshes, mean gap 3,027 ms, and
// ZERO gaps under 900 ms. It is doing exactly what it says.
//
// So this is a plain load of a bool rather than a load of a shared_ptr. published_ready_ is
// written before the store that publishes, never after, and a stale read of it can only cost one
// extra refresh - which the throttle would have permitted anyway.
[[nodiscard]] bool HideoutModule::snapshot_ready() const {
    return published_ready_.load(std::memory_order_acquire);
}

void HideoutModule::publish_empty(bool retain_data) {
    // Every "not ready" edge funnels through here, so this is the one place that has to clear
    // the live handle. Leaving it set would let the panel probe install against a hideout that
    // has since been torn down.
    live_hideout_ = nullptr;
    // The live-production overlay is keyed by scheme id and holds no roots, so it must not
    // outlive the hideout the producers belonged to. A producer pointer is not a GC root: the
    // game can collect it, and an entry read afterwards would be a wild pointer.
    production_panel_probe::live_producing_clear();

    // RETAIN_DATA IS ABOUT THE DISPLAY COPY ONLY, and the split is the whole point.
    //
    // The two handles above are raw pointers into a hideout the game has destroyed, and
    // holding them across the edge is how this module used to be the thing that faulted.
    // Everything in the snapshot is our own copy -- names, levels, per-area Stage
    // requirements, item totals -- and none of it becomes invalid when the hideout closes.
    // Dropping it made the card answer "reach the hideout" to a player who was in the
    // middle of a raid, which is the one moment the question "what does this zone need to
    // level" is most likely to be useful.
    auto next = std::make_shared<hideout_snapshot>();
    if (retain_data)
    {
        const std::shared_ptr<const hideout_snapshot> keep = snapshot();
        next->area_names = keep->area_names;
        next->area_ids = keep->area_ids;
        next->area_levels = keep->area_levels;
        next->area_active = keep->area_active;
        next->area_last_recipe = keep->area_last_recipe;
        next->upgrades = keep->upgrades;
        next->status = keep->status;
        next->stale = true;
    }
    // Keep advancing the revision: the render thread keys its rebuild off it, and a stale
    // revision would let it skip repainting an emptied dropdown.
    next->area_revision = snapshot()->area_revision + 1;
    // An empty snapshot is not ready, and the flag goes FIRST so a reader that sees it true
    // already has the non-empty snapshot behind it. Order matters only in that direction: a
    // reader seeing false here costs at most one redundant refresh, which the throttle permits.
    published_ready_.store(false, std::memory_order_release);
    published_.store(std::move(next));
    // Every reopen gets its full bracketing back; see the member's comment.
    passes_since_open_ = 0;
}

// Milliseconds until the recipe clock next fires, clamped at zero on both ends.
//
// The obvious `interval - (now - last)` is two unsigned subtractions in a row and neither is
// safe here. `last` is not guaranteed to be in the past relative to `now`, because the
// recipe-reload knob can hold `recipes_due` false while the clock term has already expired, and
// refresh_recipes zeroes `last_recipes_ms_` to re-arm the label budget. Either way one of the
// subtractions wraps, and the readout prints a 20-digit "next in" instead of a countdown.
//
// A wrapped value is not a crash, which is why this survived as long as it did, but it is
// exactly the kind of line that costs a debugging round to explain when it turns up in a log.
inline ULONGLONG next_recipes_in_ms(const ULONGLONG now, const ULONGLONG last,
    const ULONGLONG interval) {
    const ULONGLONG since = now > last ? now - last : 0;
    return interval > since ? interval - since : 0;
}

// QPC stopwatch for one region of a pass.
//
// QueryPerformanceCounter and not GetTickCount64: the latter only advances about every 15.6 ms
// on this machine (the same trap is called out beside g_pkt_published in eft_api.h), which
// cannot resolve a 0.4 ms probe and barely resolves an 80 ms walk.
struct qpc_stopwatch
{
    LARGE_INTEGER begin{};
    LARGE_INTEGER end{};

    void start() { QueryPerformanceCounter(&begin); }
    void stop() { QueryPerformanceCounter(&end); }
    double ms() const {
        return eft_api::probe_ticks_to_ms(
            static_cast<unsigned long long>(end.QuadPart - begin.QuadPart));
    }
};

// One decimal place, so 0.4ms and 81.3ms are told apart without a wall of digits.
inline std::string ta_ms(const double v) {
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%.1f", v);
    return buf;
}

void HideoutModule::refresh_hideout_state(Il2CppObject* application) {
    // The whole per-pass refresh, which is the card's actual data cost. Paired with the zone on
    // draw_menu_extra above: that one runs every frame the card is visible, and this one is
    // EXPECTED to run at 1 Hz. Between them they are the entire cost of the feature - and the
    // zone on this function is what proved that expectation was wrong, see the throttle below.
    TA_ZONE_N("hideout::Card::refresh_hideout_state");

    if (game_state::is_in_raid)
    {
        // In a raid the hideout is torn down. Published state is only dropped on a REAL
        // transition, not every frame: this runs once per frame, so a cheap bool check has
        // to guard the snapshot swap. Besides the pointless work, an unconditional publish
        // would bump area_revision constantly and make the render thread rebuild the
        // dropdown on every frame.
        //
        // retain_data=true: entering a raid is the exact case the card's data is still worth
        // having. The live handles go (they point into a destroyed hideout); the per-area
        // requirements and item totals stay, so "what does Production need to level" survives
        // the trip out of the hideout. This used to blank the card for the whole raid.
        if (snapshot_ready())
        {
            log_areas("hideout closed (entered raid) — keeping area + upgrade data");
            publish_empty(true);
        }
        return;
    }

    // ---- THE THROTTLE, AND IT HAS TO BE HERE ----
    //
    // It used to sit below the hideout_is_loaded probe, which is the same as saying "throttle after
    // deciding whether there is anything to throttle". Measured cost of that ordering, from the
    // 2026-10-01 12:12 capture - and the zone on this function is the only reason it was found:
    //
    //     hideout::Card::refresh_hideout_state  inclusive 158,710,577,246 ns
    //                                             exclusive 155,680,616,426 ns   n=171,433
    //
    // 155.7 seconds of EXCLUSIVE time, 15.98% of all instrumented work in a 49-minute session,
    // spent ABOVE a throttle that had already decided not to do anything. Mean 908 us on a call
    // that returns without touching the hideout.
    //
    // What it was buying per frame: the memo teardown, and hideout_is_loaded() - which is TWO
    // MANAGED CALLS (get_HideoutControllerAccess, then get_IsLoaded) walking
    // application -> controller -> _hideoutGameLoader. That is the only managed call on this path
    // and it is essentially the whole cost.
    //
    // What it was guarding: 1,340 real refreshes totalling 17,836 ms, 0.61% of the session.
    // The guard cost 30x what it guarded.
    //
    // This also corrects a claim made one commit earlier, that the card's overhead was a 0.06%
    // duty cycle. That figure came from the log's walk timings and was accurate FOR THE REFRESH -
    // it was blind to everything above the throttle, which is where the cost actually was. The
    // zone added to check the card found a 26x larger number on the very next capture.
    //
    // Why here and not at the top: the raid branch above owns the is_in_raid transition and must
    // stay reachable every frame, so it cannot be throttled. Everything after it can be.
    //
    // Wall-clock rather than a frame count, so the interval is the same at 30 fps and at 240 fps -
    // a fixed frame budget silently quadruples the refresh rate on a fast machine. Queued button
    // clicks bypass it: user actions are rare and must not wait out the window.
    static constexpr ULONGLONG kRefreshIntervalMs = 10000;
    const ULONGLONG now = GetTickCount64();
    // A zone on the DECISION ALONE, because the outer zone's number stopped being believable and
    // the code and the profiler disagree by four orders of magnitude:
    //
    //     2026-10-02 21:16   refresh_hideout_state  n=101,705  exclusive mean 481,794 ns
    //
    // 206 of those calls do the real work (~13 ms each). The other 101,499 read one plain bool, one
    // atomic bool, one ULONGLONG and call GetTickCount64 - which is tens of nanoseconds, not 466 us.
    // The 24bfbd5 fix removed the two shared_ptr round-trips from this exact path and the mean did
    // not move (483 us -> 492 us), so "it was the refcounting" was wrong and the cost has not been
    // located yet.
    //
    // Narrow zone, so the next capture either shows the decision is cheap - which would mean the
    // OUTER zone is misreporting, and that is worth knowing - or it shows the real cost where it is.
    bool throttled = false;
    {
        TA_ZONE_N("hideout::Card::throttle_decision");
        throttled = snapshot_ready() && last_refresh_ms_
            && now - last_refresh_ms_ < kRefreshIntervalMs;
    }
    if (throttled) return;
    last_refresh_ms_ = now;

    // Drop any addressability results the previous pass left behind, BEFORE any early return
    // below, so that no memo entry can ever be older than the pass that created it.
    //
    // The walks reset it again at their own start, which is the tighter bound and the one that
    // matters; this is the backstop for the reads that happen outside a walk - hideout's own
    // 'Areas' field is read to find the array, and that read precedes the walk's reset. Left
    // alone it would have been answering from a memo filled a second earlier.
    //
    // Below the throttle now, so it costs once a second instead of once a frame.
    hideout_probe_cache_reset();

    // Stage 1: is the hideout open at all? ISIL: HideoutGameLoader.get_IsLoaded() is
    // `this._playerOwner != null`.
    //
    // Once per interval rather than per frame, because this is below the throttle. The
    // open/close edge is detected within a second of happening, which is what the transition
    // log below depends on.
    if (!hideout_is_loaded(application))
    {
        // Only on a real transition. The game thread reaches this on EVERY frame while the
        // hideout is closed, so publishing unconditionally would rebuild the render thread's
        // dropdown every frame for no reason.
        if (snapshot()->ready)
        {
            // Closing the hideout is when the game rebuilds HideoutInfo from its own state,
            // so it is also the moment the DTO becomes authoritative again. The row
            // suppression that used to live here went with the Take button: with nothing able
            // to request a take, the DTO cannot fall behind anything this module did.
            //
            // retain_data=true, same reason as the raid edge above: this is "exited the
            // hideout", and the area list plus the per-zone upgrade requirements are our own
            // copies and stay answerable after the hideout is gone. The producers this list
            // was collected through DO die with it, and those handles are dropped inside
            // publish_empty regardless of the flag.
            log_areas("hideout closed — keeping area + upgrade data");
            publish_empty(true);
        }
        // Probe again next interval; the open/close edge is what matters, and this branch is
        // now reached once a second rather than once a frame.
        last_refresh_ms_ = 0;
        return;
    }

    // Stage 2: menu operation -> session + profile.
    Il2CppObject* menu_operation = hideout_menu_operation(application);
    if (!menu_operation)
    {
        log_areas_once("no _menuOperation on the application while the hideout is loaded");
        publish_empty();
        return;
    }
    Il2CppObject* profile = hideout_menu_profile(menu_operation);
    if (!profile)
    {
        log_areas_once("no _profile on the menu operation (MainMenuShowOperation._profile)");
        publish_empty();
        return;
    }

    // Stage 3: profile -> hideout representation. The resolver logs which accessor won.
    Il2CppObject* hideout = hideout_read_representation(profile);
    if (!hideout)
    {
        log_areas_once("Profile has no hideout representation yet");
        publish_empty();
        return;
    }

    const std::shared_ptr<const hideout_snapshot> previous = snapshot();
    if (!previous->ready)
    {
        const Il2CppClass* kls = hideout->klass;
        log_areas(std::string("hideout opened — representation class=")
            + (kls->namespaze && *kls->namespaze ? std::string(kls->namespaze) + "." : "")
            + (kls->name ? kls->name : "?"));
    }

    // From here on the hideout is genuinely loaded. Set after the log block so the probe's
    // install trigger can never observe a handle that is still being established, and cleared
    // by publish_empty() on every not-ready edge.
    live_hideout_ = hideout;

    // The production verbs live on IEftSession, not on the hideout DTO.
    Il2CppObject* session = hideout_session(menu_operation);

    // Build the whole next version locally, then publish once.
    auto next = std::make_shared<hideout_snapshot>();
    next->ready = true;
    next->area_revision = previous->area_revision;
    next->recipe_ids = previous->recipe_ids;
    next->recipe_labels = previous->recipe_labels;

    // Bracketed step by step. Three crashes in a row landed somewhere in this module and the
    // log only ever said "areas loaded", so the boundary between each step below is what
    // tells us where execution actually stopped. Cheap: log_areas is gated on the debug
    // toggle and the whole block runs about once a second.
    //
    // GATED to the passes where a fault would actually be localised. The bracket only tells you
    // where execution stopped if the lines BEFORE the stop were emitted, and all three crashes
    // were during hideout load - the first few passes. Printing all of it forever turns the
    // diagnostic into a 12-line-per-second heartbeat that buries everything else in the log,
    // which is strictly worse than useless: it is what made the recipe list unreadable.
    // After the opening passes, the single summary line at the end carries the steady state.
    const bool bracket = passes_since_open_++ < 4;
    if (bracket) log_areas("pass " + std::to_string(passes_since_open_) + " (bracketed)");

    // ---- what this pass actually costs ------------------------------------------
    //
    // The reported symptom is a ~130 ms stall once a second, and it happens with both hideout
    // knobs on or off, so it is not the recipe fetch and not the game's UpdateViews. The log
    // puts the whole 130 ms inside these two walks - the lines bracketing them are ~1 ms
    // apart - but "which walk" is not "why". Both are dominated by addressability probing
    // (~600 VirtualQuery calls a second between them), and whether that is the cost or is
    // innocent depends entirely on what ONE probe costs in this process. 600 probes in 130 ms
    // means ~200 us each, which is ~1000x a normal VirtualQuery and would mean something is
    // intercepting queries; 600 probes in 0.5 ms would mean they are not the problem at all.
    //
    // Those two readings need opposite fixes, so each walk is timed on its own and the probe
    // time is pulled out of it separately. The figures go on the one summary line, which is
    // where a per-pass cost belongs now that the step brackets are gated.
    //
    // The drain immediately before the first walk discards whatever OTHER threads accumulated
    // since the last one, so these describe the hideout refresh rather than a process-wide
    // total that an unrelated module could inflate.
    eft_api::drain_probe_stats();
    qpc_stopwatch areas_clock;
    qpc_stopwatch productions_clock;

    areas_clock.start();
    refresh_areas(hideout, *next);
    areas_clock.stop();
    const eft_api::probe_stats areas_probes = eft_api::drain_probe_stats();
    if (bracket) log_areas("step: areas done -> productions");

    productions_clock.start();
    next->productions = hideout_read_productions(hideout);
    productions_clock.stop();
    const eft_api::probe_stats production_probes = eft_api::drain_probe_stats();
    // Overlay the game's LIVE production state over the DTO's, before anything reads it.
    //
    // The DTO is a snapshot and it does not move: measured 2026-09-29, "7 producing" and
    // m_i_count=7 for 37 unbroken seconds while finished items were collected, and raw_progress
    // pinned at 244.202026 with in_progress=no for the whole session. The game's own
    // ProducingItemController does move - ProductionController.UpdateProductions(...) is the call
    // the game makes when an item is taken - and we are handed one of those on every
    // ShowProduceView. Rows with no live entry are left as they were; see apply_live_productions.
    if (bracket) log_areas("step: " + std::to_string(next->productions.size())
        + " production(s) -> recipes");

    // Sweep the live controller for EVERY station's productions, then overlay the result onto the
    // DTO rows. Two steps, in that order: the sweep fills the map, the overlay consumes it.
    //
    // This has to run here, on the 1 Hz refresh, and not off the ShowProduceView hook. That hook
    // only ever carries the producer for the station the player is currently LOOKING AT: measured
    // 2026-09-29 22:59, it fired 27 times and reported "LIVE producing (count=0)" every time, with
    // "0 from live/0 known" across all 68 passes, while six productions ran on other stations. A
    // per-station hook cannot cover the hideout however often it fires.
    //
    // The controller pointer still comes from ShowProduceView - that hook is where a
    // HideoutRepresentation is first reachable at all - but it is only a CAPTURE now. The sweep
    // reads ProductionController._areaProducers, which holds every station's producers, so what
    // happens to be on screen stops mattering. The hideout pointer itself is no longer read by the
    // sweep and is fetched only to report whether the representation is there.
    size_t live_patched = 0;
    // THE SWEEP IS TIMED AND COUNTED, and it was not, which is why the stall was invisible.
    //
    // The two clocks above stop at `productions_clock.stop()`, so everything from
    // here to the summary line was outside every timer the summary line reported. Measured
    // 2026-10-03 from the log's own timestamps over 89 steady-state passes: full pass p50 104 ms
    // / max 144 ms, and 91.2% of that sat between the end of the production walk and this line -
    // i.e. in this block. The summary line was reporting "walk 9.7ms" while the pass it was
    // describing took 104 ms, so it described 9% of the cost and named it as if it were all of it.
    //
    // drain_probe_stats() counts probe_readable(), which is the point: the sweep's dominant cost
    // used to be invisible even to the counters because hideout_address_readable() called
    // VirtualQuery itself. That is memoised now, so the probe count below is a real number.
    qpc_stopwatch sweep_clock;
    sweep_clock.start();
    static constexpr ULONGLONG kLiveSweepIntervalMs = 10000;
    static ULONGLONG last_live_sweep_ms = 0;
    const ULONGLONG now_sweep = GetTickCount64();
    if (production_panel_probe::live_controller_handle() && (now_sweep - last_live_sweep_ms >= kLiveSweepIntervalMs))
    {
        last_live_sweep_ms = now_sweep;
        production_panel_probe::refresh_live_productions(
            production_panel_probe::live_controller_handle());
        // The label vectors come from the PREVIOUS snapshot, not this pass's. The recipe list is
        // fetched later in this pass and lands on `next`, so at this point `next` has no labels yet
        // and a newly-added row would fall back to its raw id. `previous` is the same list the card
        // is currently drawing from, so a recipe the player can already see keeps its name.
        live_patched = production_panel_probe::apply_live_productions(
            next->productions, previous->recipe_ids, previous->recipe_labels);
        if (bracket) log_areas("live sweep: " + std::to_string(live_patched)
            + "/" + std::to_string(next->productions.size()) + " production(s) from live");
    }
    else if (bracket)
    {
        log_areas("live sweep: no ProductionController captured yet "
                  "(ShowProduceView has not fired) - using the DTO");
    }
    sweep_clock.stop();
    const eft_api::probe_stats sweep_probes = eft_api::drain_probe_stats();

    // The fuel/water gauges drain in real time, so they ride the FAST refresh rather than the
    // recipe clock — a countdown sampled every 30 s would be worse than no countdown. The
    // scheme half of the walk is skipped here; the station memo it fills was already gathered
    // and is only read on the recipe path.
    //
    // The stage is logged because this walk has four hops and any of them can be not-ready
    // rather than broken; "controller-null (not ready yet)" and "walked, 0 consumers" call
    // for completely different fixes and used to be indistinguishable in the log.
    const char* graph_stage = hideout_refresh_production_graph(hideout, /*want_schemes=*/false);
    if (bracket) log_areas(std::string("graph: ") + graph_stage);
    // Carry the previous resource list forward unless this pass actually walked. A not-ready
    // pass must not blank a gauge that was populated a second ago.
    if (std::strcmp(graph_stage, "walked") == 0)
        next->resources = hideout_resource_facilities();
    else
        next->resources = previous->resources;

    // Move fuel/water facilities out of the crafting list.
    //
    // The water plant and the generator appear in HideoutInfo.Production like any other
    // producer, but they do not produce an item — they hold a resource that drains. Showing
    // one as a crafting job with a product and a progress bar is simply the wrong shape, and
    // the row's Collect button would offer to take something that does not exist.
    //
    // The link is AreaInfo.LastRecipe, the only mapping from a running production back to
    // the station that owns it: match the production's recipe id against each area's last
    // recipe, and if that area is one of the resource consumers, it is a gauge, not a job.
    {
        std::unordered_map<std::string, int> consumer_areas;
        for (const hideout_resource& res : next->resources)
            consumer_areas.emplace(std::to_string(res.area_type), res.area_type);
        const std::unordered_map<std::string, int> recipe_to_area = hideout_last_recipe_to_area(*next);

        // ---- station cross-check ---------------------------------------
        //
        // Two independent routes to "which station does this recipe belong to", compared
        // against each other on the recipes we can line up:
        //
        //   A  AreaInfo.LastRecipe -> AreaInfo.Type. An area says which scheme it last ran, so
        //      a RUNNING production's recipe id maps back to exactly one area, and that area's
        //      Type is its station. Derived from the HideoutInfo DTO, which we can read.
        //   B  BaseHideoutScheme.areaType, read off the recipe payload itself.
        //
        // Where a recipe is running, BOTH are available for the same id, so they can be
        // checked against each other — which is the only way to tell whether areaType MEANS
        // the station rather than merely being a number that looks plausible. Agreement
        // across the running set is strong evidence; disagreement means areaType is something
        // else and the station has to come from route A.
        //
        // A recipe that is not running has no route A, so it is not checked — that is a
        // property of the data, not a gap in the check, and it is why the verdict covers the
        // running set only.
        {
            int agree = 0, disagree = 0, no_scheme = 0, no_area = 0, unresolved = 0;
            for (const ProductionInfo& prod : next->productions)
            {
                const auto from_area = recipe_to_area.find(prod.recipe_id);
                if (from_area == recipe_to_area.end())
                {
                    ++no_area;
                    continue;
                }
                const auto from_scheme = hideout_scheme_area_types().find(prod.recipe_id);
                if (from_scheme == hideout_scheme_area_types().end())
                {
                    ++no_scheme;
                    continue;
                }
                if (from_scheme->second < 0)
                {
                    ++unresolved;
                    continue;
                }
                if (from_scheme->second == from_area->second)
                    ++agree;
                else
                {
                    ++disagree;
                    log_areas("station MISMATCH for " + prod.recipe_id
                        + ": scheme.areaType=" + std::to_string(from_scheme->second)
                        + " but AreaInfo.LastRecipe implies "
                        + std::to_string(from_area->second));
                }
            }
            const int checked = agree + disagree;
            // MISMATCH lines above are NOT gated: a disagreement is a real finding and there
            // should never be one in a passing build, so printing one is the point. The verdict
            // line is a per-pass constant, so it is only interesting while bracketing.
            if (bracket) log_areas("station cross-check: " + std::to_string(checked)
                + " comparable, " + std::to_string(agree) + " agree, "
                + std::to_string(disagree) + " disagree ("
                + std::to_string(no_area) + " not running, "
                + std::to_string(no_scheme) + " scheme not in list, "
                + std::to_string(unresolved) + " areaType unresolved)"
                + (checked > 0 && agree == checked ? "  -> areaType IS the station" : ""));
        }

        const size_t before = next->productions.size();
        next->productions.erase(std::remove_if(next->productions.begin(),
                                    next->productions.end(), [&](const ProductionInfo& prod) {
                                        const auto area = recipe_to_area.find(prod.recipe_id);
                                        return area != recipe_to_area.end()
                                            && consumer_areas.count(std::to_string(area->second)) > 0;
                                    }),
            next->productions.end());
        const size_t moved = before - next->productions.size();
        if (moved)
            log_areas("moved " + std::to_string(moved)
                + " resource-draining production(s) out of the crafting list");
    }

    // ---- stick the list to the station being viewed -------------------------
    //
    // Third stage, and the only one that changes WHICH rows exist rather than moving rows between
    // sections. The player opens the Medblock and the list narrows to what the Medblock makes; the
    // production six areas away stops being a row they have to read past. The set comes from the
    // open panel's own producer (<Schemes>k__BackingField, latched in note_live_hideout), which is
    // the game telling us directly rather than us inferring the station from a recipe id.
    //
    // Applied AFTER the resource filter so the two stages compose in a fixed order and neither has
    // to know about the other: a gauge is not a job, and a job is only a row if this bench owns it.
    //
    // An empty latch means NOT STICKING rather than "this station offers nothing", and those need
    // different behaviour - see hideout_viewed_station_schemes. So an empty set draws everything,
    // which is also what makes the knob safe to leave on before the player has opened any station.
    if (hideout_stick_station())
    {
        const auto& schemes = hideout_viewed_station_schemes();
        if (!schemes.empty())
        {
            const size_t before = next->productions.size();
            next->productions.erase(std::remove_if(next->productions.begin(),
                                        next->productions.end(),
                                        [&](const ProductionInfo& prod) {
                                            return !schemes.count(prod.recipe_id);
                                        }),
                next->productions.end());

            // CHANGE-gated, not bracketed. The bracketed passes all run in the first few seconds
            // after the hideout opens, and the station is not latched until the player actually
            // opens a bench - so gating this on `bracket` meant the line could never fire in a
            // session, which is what happened: 2790f790 shipped a filter whose only evidence of
            // working was a line that was structurally incapable of printing. A diagnostic that
            // cannot fire is not a diagnostic.
            static size_t last_before = static_cast<size_t>(-1);
            static int last_area = -2;
            static size_t last_offered = static_cast<size_t>(-1);
            const int area = hideout_viewed_station_area();
            if (before != last_before || area != last_area || schemes.size() != last_offered)
            {
                last_before = before;
                last_area = area;
                last_offered = schemes.size();
                log_areas("station filter: " + std::to_string(before) + " -> "
                    + std::to_string(next->productions.size()) + " row(s) for area "
                    + std::to_string(area) + " ("
                    + std::to_string(schemes.size()) + " scheme(s) offered)");
            }
        }
        else
        {
            // Same reasoning as above: this fires on every bracketed pass, which is the only
            // window in which "no station" is interesting, so it stays bracketed.
            if (bracket)
                log_areas("station filter: no station latched - showing the whole hideout");
        }
    }

    // Recipes run on their own, much slower clock than the areas walk.
    //
    // The two are not the same kind of work. Areas and productions are pure local field
    // reads off a Profile the menu operation already holds — cheap, and they must stay
    // lively because an area finishing a level or a production advancing is exactly what
    // the player is watching. Recipes are a managed round trip: GetProductionRecipes()
    // returns a Task, and the settled result is ~260 scheme objects that each get walked,
    // and for the uncached ones a further managed call chain to produce a label. Running
    // that on the 1 s cadence meant the module spent nearly all of its time re-entering
    // game code to recompute a list that does not change while you stand in the hideout.
    //
    // So the cadences are decoupled. Recipes are fetched when the hideout OPENS (the only
    // moment the list can have changed as far as the player is concerned), on a slow
    // background tick as a safety net, and after any recipe action. An in-flight task is
    // always polled regardless of the clock, or a slow endpoint would strand it.
    static constexpr ULONGLONG kRecipesIntervalMs = 30000;
    // The upgrade list rides the same clock. See the collect block below for why it is not on the
    // 1 Hz areas clock.
    static constexpr ULONGLONG kUpgradesIntervalMs = 30000;
    const bool just_opened = !previous->ready;
    const bool task_outstanding = schemes_task_ != nullptr;
    const bool clock_due = now - last_recipes_ms_ >= kRecipesIntervalMs;
    bool recipes_due = just_opened || task_outstanding || force_recipes_ || clock_due;

    // The "pin the list" knob. Unticking it stops the re-fetch, which is worth having on its
    // own merits: GetProductionRecipes is a managed round trip returning ~260 scheme objects,
    // and re-running it on a clock recomputes something that does not change while the player
    // stands in the hideout.
    //
    // Two things deliberately still run while it is off, because neither re-fetches anything:
    //   * an OUTSTANDING task is still polled, or a request already in flight would be
    //     abandoned and its result thrown away;
    //   * force_recipes_ is still honoured, so an explicit refresh request still works.
    // What is suppressed is the periodic clock term. The open edge is deliberately KEPT, since
    // reopening the hideout is the one moment the list can genuinely have changed, and a knob
    // that silently served stale data across a reopen would be worse than a slow one.
    //
    // Nothing else is affected: areas, productions and resources are read on their own 1 Hz
    // cadence and never came through this branch.
    // Named, because it is the only condition that can hold a refetch off while the clock has
    // ALREADY expired, and the summary line downstream needs to be able to say that rather than
    // print a countdown pinned at zero. Captured here because force_recipes_ is cleared below
    // and the answer would change if it were recomputed at the summary.
    const bool reload_held_by_knob = !hideout_recipe_reload() && !task_outstanding
        && !force_recipes_ && !just_opened;
    if (reload_held_by_knob)
        recipes_due = false;

    if (recipes_due)
    {
        // WHICH term fired, and how long since the last run. "Recalculated every tick" has
        // several very different causes and they need different fixes, so this names the term
        // rather than leaving it to be inferred from the volume of the log:
        //   just-opened - the previous snapshot was not ready. Benign on the open edge, but if
        //                it appears on EVERY pass then areas are never reaching ready, and
        //                the "areas done" step line is what says so.
        //   task-stuck  - a GetProductionRecipes task has not settled. hideout_poll_task
        //                returns `pending` forever when IsCompleted is unresolvable, and this
        //                term then fires on every pass with no upper bound.
        //   clock       - the ordinary 30 s tick. A gap near 1000 ms instead of ~30000 means
        //                last_recipes_ms_ was zeroed to re-arm the label budget (see
        //                refresh_recipes), which is bounded by the cache draining and is
        //                expected only for the first few passes after opening.
        //   forced      - a recipe action asked for it.
        std::string why;
        auto add_reason = [&why](const char* reason) {
            if (!why.empty()) why += '+';
            why += reason;
        };
        if (just_opened) add_reason("just-opened");
        if (task_outstanding) add_reason("task-stuck");
        if (force_recipes_) add_reason("forced");
        if (clock_due) add_reason("clock");
        log_areas("recipes: due via " + (why.empty() ? std::string("?") : why)
            + ", gap=" + std::to_string(now - last_recipes_ms_) + "ms");
        last_recipes_ms_ = now;
        force_recipes_ = false;
        // Station attribution comes off the hideout's own producer graph and covers every
        // scheme, so it is gathered on the same schedule as the recipes it labels. It is
        // memoised inside hideout_refresh_production_graph, and the whole walk is three
        // managed calls per area on the open edge rather than per refresh.
        //
        // The stage is logged here too. If this reports "controller-null" while the fast pass
        // above reports "walked", the controllers came up between the two and the station map
        // is merely one pass stale — retried 30 s later. If both report "controller-null",
        // the controllers are not being wired up at all and the accessor name is wrong.
        const char* scheme_stage =
            hideout_refresh_production_graph(hideout, /*want_schemes=*/true);
        if (bracket) log_areas(std::string("graph(schemes): ") + scheme_stage);
        refresh_recipes(session, next->productions, *next);
        if (bracket) log_areas("step: " + std::to_string(next->recipe_ids.size())
            + " recipe(s) -> publish");
    }
    else
    {
        // next->recipe_ids / recipe_labels were seeded from `previous` above, so skipping
        // this is a carry-forward and not a drop: the dropdown keeps what it had.
        //
        // This is the line that was actively misleading: it reads like a fetch happened, and on
        // a 30 s clock this is the COMMON case, not the exception. The summary line at the end
        // now says "cached" instead, which is the truth.
        if (bracket) log_areas("step: recipes carried -> publish");
    }

    // ---- THE UPGRADE LIST, collected HERE and now, before next is moved ----
    //
    // On the recipe clock rather than the 1 Hz areas clock, and the reason is that walking every
    // area's next Stage costs a MANAGED CALL per area (AreaData.StageAt is a method, and the stage
    // list is computed by it - there is no field to read instead). At ~27 areas that is worth doing
    // every 30 s and not every second.
    //
    // It changes only when the player spends materials or completes an upgrade, so 30 s is already
    // generous, and the steady state is a cached list rather than a fresh walk - which is what
    // makes this affordable to keep on the card permanently instead of behind a button.
    {
        const ULONGLONG now_u = GetTickCount64();
        const bool first_fill = !upgrades_collected_;
        // RETRY FAST UNTIL THE FIRST SUCCESSFUL READ, then back off to the 30 s clock.
        //
        // Both inputs to the upgrade plan arrive AFTER the hideout opens, not with it: the
        // HideoutRepresentation's area list is allocated lazily, and the live controller only
        // exists once ShowProduceView has fired. On a flat 30 s clock that gap is up to a full
        // interval of the card confidently claiming something false - measured 2026-10-03, the
        // hideout opened 17:49:21 and the first reachable collect was 17:51:22, with four
        // consecutive 30 s attempts all returning reachable=0. For those two minutes the card
        // read "Reach the hideout to read upgrade requirements" to a player standing in the
        // hideout with the areas list populated one row above it.
        //
        // Derived from the PREVIOUS pass rather than a new flag, so there is no state to keep in
        // step: if the last publish reached, the expensive steady-state clock applies, and the
        // moment it stops reaching we drop straight back to retrying. collect_upgrade_plan costs
        // ~8 ms (Tracy, 2026-10-03), so a 2 s retry during a 2 minute catch-up is ~0.5 s of work
        // spread over two minutes, and it converges within 2 s of the data actually existing.
        static constexpr ULONGLONG kUpgradesRetryMs = 2000;
        const bool reached_before = previous->upgrades.reachable;
        const ULONGLONG upgrades_interval =
            reached_before ? kUpgradesIntervalMs : kUpgradesRetryMs;
        if (first_fill || now_u - last_upgrades_ms_ >= upgrades_interval)
        {
            TA_ZONE_N("hideout::Upgrades::collect");
            // No arguments: it reaches the area list through a producer the live sweep already holds, so
            // there is nothing to hand it. It used to take `application` for a
            // HideoutController.Areas route that turned out to be pointed at
            // EFT.TarkovApplication+HideoutController - the hideout LOADER, which has no such
            // member. See the note on collect_upgrade_plan for the whole misdiagnosis.
            const upgrade_plan plan = production_panel_probe::collect_upgrade_plan();
            last_upgrades_ms_ = now_u;
            // Latch on ATTEMPTED, not on the result. It used to be `plan.reachable`, which is a
            // count, so it stayed 0 whenever the walk could not reach the hideout graph - and
            // reachable=0 is the normal case here, because Profile.Hideout is the HideoutInfo DTO
            // and has no ProductionController (the WARN at first open says so). So first_fill
            // above never went false and the whole collect ran EVERY pass on the 1 Hz clock
            // instead of the 30 s clock above, forever. Measured 2026-10-03: 105 of 105
            // "upgrades:" lines carry "(first fill)".
            upgrades_collected_ = true;
            // A PLAN THAT NEVER REACHED THE GRAPH IS A FAILED READ, NOT A RESULT.
            //
            // Assigning it unconditionally is what emptied this card. Measured on the
            // 2026-10-05 session: source=none on 185 of 202 logged refreshes, and every one
            // of those overwrote a good per-area requirement list with a default-constructed
            // one - which is why itemTotals read 0 and the zones showed no requirements while
            // standing in the hideout.
            //
            // The saved plan is our own copy of Stage data read through a producer the sweep
            // held. Losing the producer makes it un-REFRESHABLE, not invalid, so the right
            // move is to keep the last plan that actually reached and retry on the clock
            // above. `previous` is the snapshot this pass is replacing, so this is the
            // carry-forward the else-branch below already does, reached from the other side.
            const bool reached_now = plan.representation_found;
            next->upgrades = reached_now ? plan : previous->upgrades;
            log_areas("upgrades: reachable=" + std::to_string(plan.reachable)
                + " source=" + plan.source
                + " areas=" + std::to_string(plan.areas_considered)
                + " withNext=" + std::to_string(plan.areas_with_next)
                + " maxed=" + std::to_string(plan.areas_maxed)
                + " unknown=" + std::to_string(plan.areas_unknown)
                + " itemTotals=" + std::to_string(plan.totals.size())
                + (reached_now ? "" : " (read failed — keeping saved requirements)")
                + (first_fill ? " (first fill)" : std::string()));
        }
        else
        {
            // Carried forward, and UNCONDITIONALLY - the condition this replaced was
            // `!upgrades_collected_`, which is wrong now that the flag latches on attempt: an
            // empty result is a result, and gating the carry on "was the last one non-empty"
            // would leave next->upgrades default-constructed (i.e. blank) for 29 passes out of
            // 30, because `next` is a fresh snapshot and nothing seeds upgrades from
            // `previous` the way recipe_ids is seeded a few lines up. Reachability is a
            // separate question and is re-tried on the 30 s clock above, so an unreachable
            // graph costs one attempt per 30 s rather than one per pass.
            //
            // Named rather than silently absent, for the same reason the recipe line above
            // says "cached": a list that is missing and a list that is unchanged look
            // identical on the card otherwise.
            next->upgrades = snapshot()->upgrades;
        }
    }

    // Ready flag FIRST, then the snapshot it describes - the mirror of publish_empty above. A
    // reader that sees true is guaranteed to find a ready snapshot behind it.
    published_ready_.store(next->ready, std::memory_order_release);
    published_.store(std::move(next));

    // `next` IS NULL from here down. It is a shared_ptr and the line above MOVED it into
    // published_, so any `next->` past this point dereferences a null pointer.
    //
    // That is not hypothetical - it is the 2026-09-29 20:08 crash. The summary line below read
    // next->area_ids.size() on the first hideout pass, so the very first execution of it faulted:
    // ACCESS_VIOLATION reading 0xC8, which is _Mylast of a vector<std::string> at snapshot
    // offset 0xC0, with the faulting instruction computing ([0xC8] - [0xC0]) >> 5 for a 32-byte
    // element. It only ever showed up on the open edge because that is when the summary line runs
    // for the first time; the bracket lines above it had already printed "step: published".
    //
    // So everything below reads the PUBLISHED snapshot. Same object, const, and the only one
    // still alive - and it is already where the recipe count and the queued-requirement lookup
    // get their data, so this is not a new access pattern.
    const std::shared_ptr<const hideout_snapshot> pub = snapshot();

    // Published for the Hideout Improvements card's readout. Kept in step with the publish
    // rather than derived from the recipe arrays, so a list that loaded but published nothing
    // reads as zero instead of looking loaded.
    hideout_set_recipe_count(pub->recipe_ids.size());
    if (bracket) log_areas("step: published");

    // ONE line per pass, and it says what actually happened.
    //
    // The step lines above are the diagnostic that earned its place: three crashes landed in
    // this module and the log only said "areas loaded", so the boundaries matter. But they are
    // BRACKET lines, and printing all of them every second turns a diagnostic into a heartbeat
    // - roughly a dozen lines a second, which is most of the log file and buries anything real.
    //
    // So the per-tick output is this single line, and it leads with the outcome rather than
    // the narration. In particular it distinguishes a recipe PASS from a recipe CARRY, which the
    // old "step: recipes carried -> publish" did not: that line reads like a fetch happened, and
    // on a 30 s clock most ticks are a carry. `refetch` names the reason the fetch was due when
    // one was, and is absent otherwise.
    log_areas("summary: " + std::to_string(pub->area_ids.size()) + " areas, "
        + std::to_string(pub->productions.size()) + " producing ("
        + std::to_string(live_patched) + " from live"
        + "/" + std::to_string(production_panel_probe::live_production_count()) + " known), "
        + std::string(recipes_due ? "refetch" : "cached") + "("
        + std::to_string(pub->recipe_ids.size()) + ")"
        + (recipes_due ? ""
                // "reload off" rather than a countdown, because with the knob unticked the clock
                // expires and stays expired, so a clamped "next in 0ms" repeating once a second
                // reads as "a fetch is imminent" when the truth is "nothing will fire until the
                // knob comes back on". That is a claim about the future, and the log should not
                // make a false one.
                : reload_held_by_knob ? ", reload off"
                                      : ", next in " + std::to_string(
                                            // Clamped: see next_recipes_in_ms for why the raw subtraction wraps.
                                            next_recipes_in_ms(now, last_recipes_ms_, kRecipesIntervalMs))
                    + "ms")
        // walk=<total>ms (areas <ms>/<n> probes <ms>ms, prod <ms>/<n> probes <ms>ms)
        //     | sweep <ms>ms/<n> probes <ms>ms | total <ms>ms
        //
        // This is the stall line, and it now accounts for the whole pass.
        //
        // The stall is real work on this thread once a second. It is NOT log volume (three of
        // these lines are written inside the same millisecond, so write_line is
        // sub-millisecond), and it is NOT the recipe clock or the game's UpdateViews (it
        // happens with both knobs either way, and the panel counters tick on a completely
        // different cadence). Each walk is timed on its own with its addressability-probe
        // share broken out - that share says whether the walk is doing 600 cheap kernel
        // transitions or 600 expensive ones.
        //
        // `walk` and `total` were the same number for a long time, and that was the bug this
        // line now exists to prevent: `walk` covers only refresh_areas and
        // hideout_read_productions, so on the 2026-10-03 capture it read 9.7 ms at p50 for a
        // pass that took 104 ms at p50, and the missing 91% - the live sweep - was reported
        // nowhere. `sweep` is that block, `total` is the pass, and if `total` and
        // walk+sweep ever disagree again then something unmeasured has been added between
        // them, which is the failure this reporting shape is here to make visible.
        + ", walk " + ta_ms(areas_clock.ms() + productions_clock.ms())
        + "ms (areas " + ta_ms(areas_clock.ms()) + "/" + std::to_string(areas_probes.calls)
        + "p " + ta_ms(areas_probes.ms) + "ms"
        + ", prod " + ta_ms(productions_clock.ms()) + "/"
        + std::to_string(production_probes.calls) + "p " + ta_ms(production_probes.ms)
        + "ms"
        + " | sweep " + ta_ms(sweep_clock.ms()) + "ms/"
        + std::to_string(sweep_probes.calls) + "p " + ta_ms(sweep_probes.ms) + "ms"
        // The number to watch. `total` is the whole measured pass on this thread; it is what has
        // to fit in a frame, and it is the figure the walk/sweep split exists to explain. On the
        // 2026-10-03 capture this would have read total ~104ms while walk read 9.7ms.
        + " | total " + ta_ms(areas_clock.ms() + productions_clock.ms() + sweep_clock.ms())
        + "ms)");
}

void HideoutModule::log_areas(const std::string& message) {
    if (logger::debug_enabled()) logger::debug("hideout/areas: " + message);
}

void HideoutModule::log_areas_once(const std::string& message) {
    static std::unordered_map<std::string, bool> reported;
    if (reported.emplace(message, true).second) logger::warn("hideout/areas: " + message);
}

void HideoutModule::refresh_areas(Il2CppObject* hideout, HideoutModule::hideout_snapshot& next) {
    Il2CppObject* areas = hideout_areas(hideout);
    if (!areas)
    {
        log_areas_once("'Areas' field not found (or null) on HideoutInfo");
        ++next.area_revision;
        return;
    }

    const char* areas_cls = (areas->klass && areas->klass->name) ? areas->klass->name : "?";
    if (logger::debug_enabled())
    {
        // A per-pass constant (the class never changes), so it is only useful on the opening
        // passes. The `hideout areas is array` line it used to accompany was likewise a
        // constant, and together they were two of the dozen lines a second.
        if (passes_since_open_ <= 4)
            log_areas(std::string("Areas resolved, class=") + areas_cls);
        static bool dumped = false;
        if (!dumped)
        {
            dumped = true;
            log_areas(std::string("reading AreaInfo fields: Active/Type/Level/CompleteTime/"
                                  "Constructing/PassiveBonusesEnabled/LastRecipe/Slots"));
        }
    }

    int skipped = 0;
    int constructing_count = 0;
    int with_recipe = 0;
    std::vector<std::string>& names = next.area_names;
    std::vector<std::string>& ids = next.area_ids;
    std::vector<int>& levels = next.area_levels;
    std::vector<bool>& active_flags = next.area_active;
    // Kept in step with the four above. NOT a parallel array by accident: it is the only
    // mapping from a running production back to its station, and the consumer filter in
    // refresh_hideout_state indexes it positionally against area_ids.
    std::vector<std::string>& last_recipes = next.area_last_recipe;
    // Split from the body below because 15-19 ms for 27 objects is 600 us each, which no memoised
    // field read accounts for. The candidates are the iterator's own addressability probing, the
    // managed-string conversion for LastRecipe, and hideout_localize_area_name - and they are very
    // different fixes, so attributing the cost is the whole point of the split. The per-object work
    // is nested one level deeper inside, so Tracy's exclusive time on THIS zone is the iterator's
    // own overhead with the lambda's cost attributed to the child.
    {
        TA_ZONE_N("hideout::Areas::iterate");
        hideout_iterate_collection(areas, "hideout areas", [&](Il2CppObject* area_data) {
            // Field reads, resolved through the memo so a rename is a cache miss rather than
            // a silent zero.
            const int type = hideout_read_field<int>(area_data, "Type", -1);
            if (type < 0)
            {
                ++skipped;
                return;
            }

            const int level = hideout_read_field<int>(area_data, "Level");
            const bool active = hideout_read_field<bool>(area_data, "Active");
            const bool constructing = hideout_read_field<bool>(area_data, "Constructing");
            const std::string last_recipe = il2utils::conv_string(
                hideout_read_field<Il2CppString*>(area_data, "LastRecipe"));
            if (constructing) ++constructing_count;
            if (!last_recipe.empty()) ++with_recipe;

            // The two candidates that are NOT memoised field reads, zoned apart because they have
            // completely different fixes. conv_string allocates and transcodes a managed string 27
            // times per walk; hideout_localize_area_name is an i18n lookup keyed on an int that takes
            // only 27 distinct values, so it should be trivially cacheable and may not be.
            std::string name;
            {
                TA_ZONE_N("hideout::Areas::localize");
                name = hideout_localize_area_name(type);
            }
            names.push_back(name);
            ids.push_back(std::to_string(type));
            levels.push_back(level);
            active_flags.push_back(active);
            last_recipes.push_back(last_recipe);
        });
    }

    if (skipped)
        log_areas("skipped " + std::to_string(skipped) + " area(s) without a readable Type");

    size_t active_count = 0;
    for (const bool a : active_flags) active_count += a ? 1 : 0;
    // The per-area dump this replaced was 27 of the ~100 lines a refresh emitted, and
    // logger::write_line opens/flushed/closes the log FILE per line (util/logger.cpp:81), so
    // per-element traces are a frame-time cost rather than free diagnostics.
    //
    // What this printed - how many areas, how many active, how many constructing - is per-pass
    // state and genuinely distinguishes a good read from a bad one, so it is NOT thrown away. It
    // moved up into the caller's single `summary:` line, which is emitted once per pass from
    // where the whole picture is in scope (areas, productions, recipe provenance, clock). One
    // line a second now instead of the same counts twice.
    //
    // active_count / constructing_count stay computed and used below for the revision bump, so
    // removing the emit did not orphan them.

    // Bump unconditionally rather than only when the count moved: a level change with an
    // unchanged area count still changes the "[Lv 1->2]" prefix in the dropdown. This runs
    // about once a second, which is what the revision exists to avoid repeating per FRAME.
    ++next.area_revision;
}

void HideoutModule::refresh_recipes(Il2CppObject* session, const std::vector<ProductionInfo>& productions,
    HideoutModule::hideout_snapshot& next) {
    if (!session)
        return;

    // How many never-before-seen schemes one pass may pay managed calls for. Each one costs
    // a get_RequiredItems() call plus a call per requirement, so resolving all ~260 in one
    // go would be a visible stall on the frame the hideout opens. 32 per pass keeps each
    // pass small; refresh_recipes then asks to be called again immediately, so the whole
    // set is named within a few 1 s ticks and the cost is never paid twice.
    static constexpr int kLabelBudget = 32;

    if (!schemes_task_)
    {
        schemes_task_ = hideout_request_production_schemes(session);
        log_areas(std::string("recipes: request -> ")
            + (schemes_task_ ? "task issued" : "NO TASK (method missing or call returned null)"));
        if (!schemes_task_)
        {
            log_areas_once("IEftSession.GetProductionRecipes is unavailable on the session");
            return;
        }
    }

    // Resolve the outstanding request. A fresh one goes out only after the previous
    // settled, so a slow or failing endpoint cannot turn this into a request loop.
    std::string error;
    Il2CppObject* collection = nullptr;
    const hideout_task_state state = hideout_poll_task(schemes_task_, collection, error);
    log_areas(std::string("recipes: poll -> ")
        + (state == hideout_task_state::pending ? "pending" : "settled")
        + (error.empty() ? "" : " (" + error + ")"));
    if (state == hideout_task_state::pending)
        return; // keep the task; the next refresh picks the result up

    schemes_task_ = nullptr;
    if (state == hideout_task_state::failed)
    {
        logger::warn("hideout: GetProductionRecipes failed: " + error);
        return;
    }
    if (!eft_api::is_il2cpp_object_likely_valid(collection))
    {
        log_areas_once("recipes: task succeeded but the result collection is not a live object");
        return;
    }
    log_areas(std::string("recipes: result class=")
        + (collection->klass && collection->klass->name ? collection->klass->name : "?"));

    // Learn labels from the live productions: a scheme that is running right now has a
    // Product list, and the template id in it localizes to the item's name. That is the
    // authoritative RESULT, so it wins over the scheme's own RequiredItems label.
    // Everything not currently running falls back to the label resolved from the scheme
    // itself, which is why the dropdown is no longer mostly raw ids.
    std::unordered_map<std::string, std::string> labels;
    for (const ProductionInfo& prod : productions)
        if (!prod.product_label.empty()) labels[prod.recipe_id] = prod.product_label;

    bool labels_pending = false;
    const std::vector<hideout_scheme> schemes =
        hideout_read_schemes(collection, kLabelBudget, &labels_pending);
    if (schemes.empty()) return;

    std::vector<std::string> ids;
    std::vector<std::string> labels_out;
    ids.reserve(schemes.size());
    labels_out.reserve(schemes.size());
    int still_raw_id = 0;
    int with_station = 0;
    for (const hideout_scheme& scheme : schemes)
    {
        ids.push_back(scheme.id);
        // Precedence, and it is deliberately strict:
        //   1. the live production's result (ProductionData.Products) — authoritative, but
        //      only exists while the recipe is actually going, which is why it covers ~6 of
        //      ~260 schemes;
        //   2. the scheme's own requirement — always present, but it is what you HAND OVER,
        //      not what you get, so it is never dressed up as a product;
        //   3. the raw id, which is still better than an empty string because an empty
        //      dropdown entry is indistinguishable from a loading state.
        std::string text;
        const auto running = labels.find(scheme.id);
        if (running != labels.end() && !running->second.empty())
            text = running->second;
        else if (!scheme.label.empty())
            text = scheme.label;
        else
            text = scheme.id;

        // The station prefix is independent of the above, because it comes from the
        // producer graph and is available for EVERY scheme, running or not. That is the
        // "which station" half of the label; the requirement is the "what do I hand over"
        // half. A running production shows its actual product instead.
        const auto station = hideout_scheme_stations().find(scheme.id);
        if (station != hideout_scheme_stations().end())
        {
            const std::string area = hideout_localize_area_name(station->second);
            labels_out.push_back(area + "  \xC2\xB7  " + text);
            ++with_station;
        }
        else
        {
            labels_out.push_back(text);
        }
        // "Still a MongoID" is the exact symptom, so count it: a dropdown full of ids is one
        // number in the log rather than something to be eyeballed in game.
        if (labels_out.back() == scheme.id) ++still_raw_id;
    }

    log_areas("labels: " + std::to_string(labels_out.size()) + " recipe(s), "
        + std::to_string(schemes.size() - still_raw_id) + " named, "
        + std::to_string(still_raw_id) + " still a raw id, "
        + std::to_string(with_station) + " with a station prefix");

    // Only publish new labels when something a user can see actually changed. Comparing
    // the LABELS is the point: a recipe that just gained a resolved item name must repaint
    // even though its id and position are identical.
    if (ids == next.recipe_ids && labels_out == next.recipe_labels && !next.recipe_ids.empty())
    {
        // Nothing new to show, but the label pass may still have work queued behind its
        // budget. Come back on the next tick rather than waiting out kRecipesIntervalMs,
        // so the dropdown finishes naming itself within a few seconds of opening instead of
        // over the following half-minute.
        if (labels_pending) last_recipes_ms_ = 0;
        return;
    }

    next.recipe_ids = std::move(ids);
    next.recipe_labels = std::move(labels_out);

    logger::info("hideout: loaded " + std::to_string(next.recipe_ids.size()) + " production recipes");
    if (labels_pending) last_recipes_ms_ = 0;
}


Il2CppObject* HideoutModule::get_object_field(Il2CppObject* object, const char* name) {
    return hideout_read_field<Il2CppObject*>(object, name);
}

[[nodiscard]] bool HideoutModule::has_pending_menu_actions() const {
    return open_hideout_action_.pending();
}

void HideoutModule::set_menu_status(const std::string& status) {
    {
        const std::lock_guard<std::mutex> lock(status_mutex_);
        if (status == status_) return;
        status_ = status;
    }
    logger::info("Hideout: " + status);
}

[[nodiscard]] std::string HideoutModule::current_status() const {
    const std::lock_guard<std::mutex> lock(status_mutex_);
    return status_;
}

void HideoutModule::request_open_hideout() {
    if (open_hideout_action_.request(!game_state::is_in_raid))
        set_menu_status("Hideout opening queued.");
}

[[nodiscard]] std::string HideoutModule::describe_recipe(const std::string& id) const {
    const std::shared_ptr<const hideout_snapshot> snap = snapshot();
    for (size_t i = 0; i < snap->recipe_ids.size(); ++i)
    {
        if (snap->recipe_ids[i] != id) continue;
        const std::string& label = snap->recipe_labels[i];
        if (!label.empty() && label != id) return label;
        break;
    }
    return id.size() > 8 ? id.substr(0, 8) : id;
}

void HideoutModule::discard_menu_actions(const std::string& reason) {
    const bool had_open_request = open_hideout_action_.pending();
    open_hideout_action_.clear();
    if (had_open_request)
        set_menu_status(reason);
}

void HideoutModule::open_hideout_at_main_point(Il2CppObject* menu_operation) {
    const MethodInfo* method = hideout_cached_method(menu_operation->klass, "OpenHideoutAtMainPointSync", 0);
    if (!method || !method->methodPointer)
    {
        set_menu_status("OpenHideoutAtMainPointSync is unavailable.");
        return;
    }
    static_cast<void (*)(Il2CppObject*)>(method->methodPointer)(menu_operation);
    set_menu_status("Hideout opening requested.");
}
