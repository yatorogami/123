#include "common.h"
#include "EspModule.h"
#include "../../util/tracy_bridge.h"

#include <string_view>

namespace
{
// Screen-space bound for a section 7 skeleton piece, as a multiple of the viewport
// dimension. Deliberately loose: the job is to catch a projection blow-up (which lands at
// 1e3-1e6 px), not to clip a bone that is legitimately a little off-screen. The
// non-optic path uses 10x for the same reason (EspModule.cpp:905); this is tighter
// because the section 7 complement is projected by a camera known to disagree with the
// one that fitted the mask, so its error is larger by construction.
inline constexpr float kS7ScreenBoundFactor = 4.f;

// Pieces dropped by that bound, split by kind. Counters rather than silence, so the next
// capture can say whether the guard ever fires: if these stay at zero the bound is slack
// and costs one comparison per piece, and if they climb the guard is doing real work.
inline unsigned long long g_s7_pieces_dropped_inside = 0;
inline unsigned long long g_s7_pieces_dropped_outside = 0;

// ===========================================================================
// TEMPORARY DIAGNOSTIC -- the 469.8 ms gameworld_update frame. REMOVE ONCE
// EXPLAINED. Not a feature; nothing depends on it.
// ===========================================================================
//
// WHAT THIS IS FOR. The 2026-10-03 capture (next_next_day.tracy) has
// frame::EspModule::gameworld_update at mean 1.64 ms, std 2.97 ms, and a single
// call at 469.8 ms -- roughly a 157-sigma outlier, so almost certainly one frame
// rather than a distribution. Two earlier notes mis-described it and this is the
// correction: it is NOT the skeleton bone resolution.
//
//   frame::EspModule::gameworld_update   max 469.8 ms   (self max 447.0 ms)
//     EspModule::collect_skeleton        max  13.6 ms
//       esp_bones::collect_skeleton_bones max 12.7 ms
//         esp_bones::get_bone_transform_by_name max 12.5 ms
//
// collect_skeleton accounts for 13.6 ms of 469.8 ms -- 2.9%. The other ~456 ms is
// SELF time in gameworld_update, i.e. code with no zone on it: the per-player row
// (get_Nickname + build_player_label + try_get_head_position + try_get_player_health),
// is_player_any_part_visible, and every post-loop scan (grenades, tripwires, loot,
// containers). The capture cannot apportion those, which is the same unattributable-
// cost problem collect_skeleton's own zone was added to solve.
//
// WHY A LOG AND NOT ONLY ZONES. Zones answer this from a capture, which costs a
// raid. The phase timers below answer it in one raid and do not depend on the Tracy
// pipeline at all -- and the profile is a week old and was taken on a different
// session, so the outlier may not even recur. Both are here: the zones (added
// alongside, permanent, free when Tracy is compiled out) attribute it in future
// captures, and these timers give the answer now.
//
// COST. Four steady_clock reads per player plus two per frame. That is ~20-40 ns
// each against a mean frame of 1.64 ms, i.e. well under 1% of a normal frame, and
// it is the price of not guessing. The REPORT is the expensive part -- it builds
// strings -- and it runs at most kSlowFrameReports times in the life of the
// process, behind a threshold 24x the mean so an ordinary frame can never reach it.
struct slow_frame_probe
{
    // 40 ms. Chosen against the measured shape rather than by taste: mean 1.64 ms,
    // std 2.97 ms, so this is >13 sigma and no ordinary frame can trip it, while
    // sitting well under the 469.8 ms outlier this exists to explain.
    static constexpr long long kThresholdUs = 40000;
    static constexpr int kMaxReports = 6;

    using clock = std::chrono::steady_clock;
    static inline long long since_us(clock::time_point t0)
    {
        return std::chrono::duration_cast<std::chrono::microseconds>(clock::now() - t0).count();
    }

    clock::time_point t_frame{};
    long long us_setup = 0;
    long long us_row = 0;     // per-player identity/label/health work
    long long us_box = 0;     // is_player_any_part_visible
    long long us_skel = 0;    // collect_skeleton
    long long us_loop = 0;    // whole player enumeration
    long long us_tail = 0;    // post-loop scans
    long long us_stats = 0;   // refresh_cache_stats, the O(entries) walk inside tail
    long long us_loot = 0;    // the loot/container scan, the other big tail block
    long long us_poi = 0;     // quest POI scan
    long long us_misc = 0;    // grenade/tripwire/keypanel scans
    long long us_corpse = 0;  // bot corpse scan
    long long us_publish = 0; // the publish() group, which takes the cross-thread lock
    int players = 0;
    int rows_over_1ms = 0; // rows that alone cost more than 1 ms
    long long us_worst_row = 0;

    inline void begin()
    {
        t_frame = clock::now();
        // Resets EVERY per-frame accumulator, not just the clock. These are file-global
        // (gameworld_update has no instance state to hang them off), so without this a
        // reported frame inherits the previous frame's row/box/skel totals and every
        // number in the line becomes a lifetime sum rather than this frame's cost. It
        // also covers a frame that returns before reaching the loop: it must not report
        // the previous frame's loop time either.
        us_setup = us_row = us_box = us_skel = us_loop = us_tail = 0;
        us_stats = 0;
        us_loot = us_poi = us_misc = us_corpse = us_publish = 0;
        players = 0;
        rows_over_1ms = 0;
        us_worst_row = 0;
    }
    inline void add_row(long long us)
    {
        us_row += us;
        if (us > us_worst_row)
            us_worst_row = us;
        if (us > 1000)
            ++rows_over_1ms;
    }

    // Called once at the end of gameworld_update. `unaccounted` is whatever is left
    // after the named phases, which is the point: if it dominates, the cost is in
    // code this probe does not name, and the zones will.
    inline void report(long long unaccounted)
    {
        static int s_reports = 0;
        const long long total = since_us(t_frame);
        if (total < kThresholdUs)
            return;
        if (s_reports >= kMaxReports)
            return;
        ++s_reports;
        const long long loop_us = us_loop;
        logger::info(std::format("esp-slow-frame[{}/{}]: gameworld_update total={}us "
                                 "setup={}us loop={}us row={}us box={}us skel={}us tail={}us "
                                 "cacheStats={}us lootScan={}us poiScan={}us miscScan={}us corpseScan={}us "
                                 "publish={}us unaccounted={}us "
                                 "| players={} rowsOver1ms={} worstRow={}us",
                                 s_reports, kMaxReports, total, us_setup, loop_us, us_row, us_box, us_skel, us_tail,
                                 us_stats, us_loot, us_poi, us_misc, us_corpse, us_publish, unaccounted, players,
                                 rows_over_1ms, us_worst_row));
    }
};
inline slow_frame_probe g_slow_frame{};

// ===========================================================================
// Shared helpers, each of which was written out TWICE (or, for is_valid_pos,
// three times) in this file. dup_scan's SAME-FILE bucket for EspModule is
// eight pairs; these five cover six of them, and the two that are left are
// named at the bottom rather than merged.
//
// WHY A NAMED HELPER AND NOT A LAMBDA. A lambda is a fresh type at every
// definition site, so two copies of the same lambda are two unrelated closures
// that happen to agree -- which is exactly the duplication being removed, and
// the reason the copies can drift without anything noticing.
// ===========================================================================

// A world position is drawable when it is finite AND inside the world's
// plausible bounds. Three copies of this existed: two in the skeleton draw
// paths and one inline at the second to_screen. The bounds half is not
// decoration -- a bone at 1e30 projects to a screen coordinate instead of
// being dropped, and that is a visible artefact, not a slow one.
inline bool is_valid_pos(const unity::vector3& pos) {
    const auto finite = [](float v) {
        return v == v && v != std::numeric_limits<float>::infinity() &&
               v != -std::numeric_limits<float>::infinity();
    };
    return finite(pos.x) && finite(pos.y) && finite(pos.z) &&
           std::abs(pos.x) < 1e6f && std::abs(pos.y) < 1e6f && std::abs(pos.z) < 1e6f;
}

// The head bone's index in a link list, or nullopt when the rig has no head.
// Duplicated verbatim in both skeleton draw paths.
inline std::optional<size_t> find_head_link_index(
    const std::vector<esp_bones::bone_link>& links) {
    for (size_t i = 0; i < links.size(); ++i)
        if (links[i].to.src == esp_bones::bone_src::player_bone &&
            links[i].to.name == esp_bones::pb::head)
            return i;
    return std::nullopt;
}

// Distance from the player to every entry in a registry, and the in-range flag
// that the distance gate reads. The container and corpse registries ran this
// loop twice, identical apart from which vector they walked.
template <typename Entry>
inline void update_registry_distances(std::vector<Entry>& entries, const unity::vector3& player_pos,
    const float min_dist_sq, const float max_dist_sq) {
    for (auto& entry : entries) {
        if (!entry.has_pos)
            continue;
        const float dx = player_pos.x - entry.pos3d.x;
        const float dy = player_pos.y - entry.pos3d.y;
        const float dz = player_pos.z - entry.pos3d.z;
        entry.dist_sq = dx * dx + dy * dy + dz * dz;
        entry.distance = sqrtf(entry.dist_sq);
        entry.in_range = entry.dist_sq >= min_dist_sq && entry.dist_sq <= max_dist_sq;
    }
}

// Resolve an object's world position, or false when it is not drawable. The
// container and corpse registry position updaters were byte-identical apart
// from the entry TYPE, which is what makes this a template rather than a
// second copy.
template <typename Entry>
inline bool update_registry_position(Entry& entry) {
    Il2CppObject* obj = reinterpret_cast<Il2CppObject*>(entry.obj_key);
    if (!eft_api::is_il2cpp_object_likely_valid(obj))
        return false;
    Il2CppObject* game_object = unity::component_get_game_object(obj);
    if (!game_object)
        return false;
    Il2CppObject* transform = unity::gameobject_get_transform(game_object);
    if (!transform)
        return false;
    entry.pos3d = unity::transform_get_pos(transform);
    entry.has_pos = true;
    return true;
}

// The bot-names label's measurements. `show_names` is passed in rather than read
// from the config because the call sites are members and this is not, and the two
// copies used to each re-read it and re-derive the same three numbers -- the
// fallback to ImGui::CalcTextSize when the HUD font is missing, the line gap, and
// the empty-name rule are the parts that were worth having once.
struct bot_names_metrics {
    ImVec2 prefix_size{};
    float name_h = 0.f;
    float total_h = 0.f;
};

inline bot_names_metrics measure_bot_names_line(const EspModule::player& entry,
    const bool show_names, const float font, ImFont* hud_font) {
    if (!show_names || !entry.show_name_line)
        return {};
    const auto text_size = [&](const std::string& text) -> ImVec2 {
        if (hud_font)
            return hud_font->CalcTextSizeA(font, FLT_MAX, 0.f, text.c_str());
        return ImGui::CalcTextSize(text.c_str());
    };
    const ImVec2 prefix_size = text_size(entry.prefix_utf8);
    const float line_gap = 2.f * menu::get_scale_factor();
    const float name_h = entry.name_utf8.empty() ? 0.f : text_size(entry.name_utf8).y;
    return { prefix_size, name_h, prefix_size.y + (name_h > 0.f ? line_gap + name_h : 0.f) };
}

// ===========================================================================
// THE TWO PAIRS DELIBERATELY NOT MERGED, and why:
//
// EspModule.cpp:5768 == 5842 -- the player-label dispatch. The two copies
// differ in that one calls draw_player_label_text_optic and the other
// draw_player_label_text, and the branch between them is the `dual_active`
// guard. Dual ADS is permanently OFF (toggle removed 2026-09-27) and the
// guard is dead, but removing it is a BEHAVIOUR CHANGE, which is a different
// decision from removing a duplicate. Left alone.
//
// EspModule.cpp:2062 == 6759 -- the corpse/loot scan distance gate. The
// heads match and the tails do not: one ends at the distance check, the other
// goes on to extract a quest-item name and push a row. Extracting the head
// would leave a helper whose only shared part is four lines of setup.
// ===========================================================================
} // namespace

EspModule::EspModule()
    : Module("ESP", Exploit, "esp_mod"), section_world_(conf(new MenuSectionValue("world_sec"))),
      extracts(conf(new CheckboxValue(false, "extracts_cb"))),
      extracts_color(conf(new ColorpickerValue({0, 1, 0, 1}, "extract_color_clr"))),
      transits(conf(new CheckboxValue(false, "transits_cb"))),
      transits_color(conf(new ColorpickerValue({1, 1, 0, 1}, "transit_color_clr"))),
      // Group separators. The card is one flat column of ~60 registered values;
      // these mark the boundaries between the groups the values actually belong
      // to, so exfil+transit, grenade+tripwire, and keypanel read as three
      // instead of one run. They are values rather than a bespoke draw order
      // because menu.cpp draws the card as a straight walk over config_values --
      // see SeparatorValue.h. Inserted at the START of each group (not the end)
      // so the rule sits between groups and never after the last control.
      sep_world_grenade(conf(new SeparatorValue("esp_sep_world_grenade"))),
      grenade_esp(conf(new CheckboxValue(false, "grenade_esp_cb"))),
      grenade_esp_distance(conf(new FloatSliderEditableValue(200.f, 25.f, 800.f, "grenade_esp_distance_itm"))),
      grenade_color(conf(new ColorpickerValue({1.f, 0.35f, 0.f, 1.f}, "grenade_color_clr"))),
      grenade_show_fuse(conf(new CheckboxValue(true, "grenade_show_fuse_cb"))),
      tripwire_esp(conf(new CheckboxValue(false, "tripwire_esp_cb"))),
      tripwire_color(conf(new ColorpickerValue({1.f, 0.65f, 0.f, 1.f}, "tripwire_color_clr"))),
      sep_world_keypanel(conf(new SeparatorValue("esp_sep_world_keypanel"))),
      keypanel_esp(conf(new CheckboxValue(false, "keypanel_esp_cb"))),
      keypanel_esp_distance(conf(new FloatSliderEditableValue(80.f, 15.f, 300.f, "keypanel_esp_distance_itm"))),
      keypanel_color(conf(new ColorpickerValue({0.35f, 0.85f, 1.f, 1.f}, "keypanel_color_clr"))),
      sep_world_players(conf(new SeparatorValue("esp_sep_world_players"))),
      section_players_(conf(new MenuSectionValue("players_npc_sec"))),
      players(conf(new CheckboxValue(false, "players_cb"))),
      player_color(conf(new ColorpickerValue({1, 0, 0, 1}, "player_color_clr"))),
      npc(conf(new CheckboxValue(false, "npc_cb"))),
      scav_color(conf(new ColorpickerValue({1, 1, 0, 1}, "scav_color_clr"))),
      boss_color(conf(new ColorpickerValue({1, 0, 1, 1}, "boss_color_clr"))),
      guard_color(conf(new ColorpickerValue({1, 0.5f, 0, 1}, "guard_color_clr"))),
      cultist_color(conf(new ColorpickerValue({0.8f, 0, 0.2f, 1}, "cultist_color_clr"))),
      raider_color(conf(new ColorpickerValue({0, 0.6f, 1, 1}, "raider_color_clr"))),
      defector_color(conf(new ColorpickerValue({0.7f, 0.3f, 1, 1}, "defector_color_clr"))),
      civilian_color(conf(new ColorpickerValue({0.55f, 0.85f, 0.55f, 1}, "civilian_color_clr"))),
      black_division_color(conf(new ColorpickerValue({0.85f, 0.15f, 0.2f, 1}, "black_division_color_clr"))),
      btr_color(conf(new ColorpickerValue({0.9f, 0.25f, 0.1f, 1}, "btr_color_clr"))),
      show_bot_names(conf(new CheckboxValue(false, "show_bot_names_cb"))),
      player_distance(conf(new FloatSliderEditableValue(200.f, 50.f, 1500.f, "player_distance_itm"))),
      sep_players_optic(conf(new SeparatorValue("esp_sep_players_optic"))),
      section_optic_(conf(new MenuSectionValue("esp_optic_sec"))),
      esp_optic(conf(new CheckboxValue(false, "esp_optic_cb"))),
      esp_optic_s7(conf(new CheckboxValue(true, "esp_optic_s7_cb"))),
      esp_optic_periphery(
          conf(new SelectValue(0, {"optic_periphery_cull_sel", "optic_periphery_main_sel"}, "optic_periphery_sel"))),
      // ACTIVE INVESTIGATION: A/B switch for the optic root-position
      // outlier filter in module/optics_lens_pipeline.h. ON = applies,
      // which is the shipped behaviour. See EspModule.h for why it
      // exists. Registered only -- menu.cpp:732 draws every registered
      // ConfigValue on the module's own card, so there is no ->draw()
      // call to add here.
      optic_root_corrector(conf(new CheckboxValue(true, "optic_root_corrector_cb"))),
      sep_optic_overlay(conf(new SeparatorValue("esp_sep_optic_overlay"))),
      section_overlay_(conf(new MenuSectionValue("overlay_sec"))),
      player_box(conf(new CheckboxValue(false, "esp_box_cb"))),
      box_distance(conf(new FloatSliderEditableValue(200.f, 50.f, 1500.f, "box_distance_itm"))),
      box_color(conf(new ColorpickerValue({1.f, 1.f, 0.f, 1.f}, "box_color_clr"))),
      box_thickness(conf(new FloatSliderEditableValue(2.f, 1.f, 5.f, "box_thickness_itm"))),
      box_visibility(conf(new CheckboxValue(false, "box_visibility_cb"))),
      box_visible_color(conf(new ColorpickerValue({0.f, 1.f, 0.f, 1.f}, "box_visible_color_clr"))),
      box_occluded_color(conf(new ColorpickerValue({1.f, 0.f, 0.f, 1.f}, "box_occluded_color_clr"))),
      player_health(conf(new CheckboxValue(false, "health_bar_cb"))),
      health_color(conf(new ColorpickerValue({0.f, 1.f, 0.f, 1.f}, "health_high_color_clr"))),
      health_low_color(conf(new ColorpickerValue({1.f, 0.f, 0.f, 1.f}, "health_low_color_clr"))),
      sep_overlay_skeleton(conf(new SeparatorValue("esp_sep_overlay_skeleton"))),
      section_skeleton_(conf(new MenuSectionValue("skeleton_sec"))),
      skeleton(conf(new CheckboxValue(false, "skeleton_cb"))),
      skeleton_health_colors(conf(new CheckboxValue(false, "health_color_limbs_cb"))),
      skeleton_distance(conf(new FloatSliderEditableValue(200.f, 50.f, 1500.f, "skeleton_distance_itm"))),
      // Default 75 m is a judgement call, not a measurement -- see the note on the member.
      // It is deliberately well under skeleton_distance's 200 m default: over two full raids
      // the ESP cast 5,420,982 rays at targets 62-86 m away and 97.6% of them concluded
      // "occluded", almost always against a prop ~3 m from the camera (AGENTS_TODO.md 5.7i).
      // Skipping those rays is close to behaviour-preserving because the occluded branch is
      // what they were selecting anyway.
      skeleton_vis_distance(conf(
          new FloatSliderEditableValue(75.f, 25.f, 1500.f, "skeleton_vis_distance_itm", "skeleton_vis_distance_tip"))),
      skeleton_color(conf(new ColorpickerValue({0.5f, 0.5f, 0.5f, 1.f}, "skeleton_color_clr"))),
      skeleton_thickness(conf(new FloatSliderEditableValue(1.7f, 0.5f, 5.f, "skeleton_thickness_itm"))),
      skeleton_head_circle(conf(new CheckboxValue(false, "skeleton_head_circle_cb"))),
      skeleton_visibility(conf(new CheckboxValue(false, "skeleton_visibility_cb"))),
      skeleton_visible_color(conf(new ColorpickerValue({0.f, 1.f, 0.f, 1.f}, "skeleton_visible_color_clr"))),
      skeleton_occluded_color(conf(new ColorpickerValue({1.f, 0.f, 0.f, 1.f}, "skeleton_occluded_color_clr"))),
      skeleton_vis_health_mode(conf(new SelectValue(0, {"health_on_visible_sel", "blend_sel", "dim_occluded_sel"},
                                                    "visibility_health_mode_sel"))),
      sep_skeleton_loot(conf(new SeparatorValue("esp_sep_skeleton_loot"))),
      section_loot_(conf(new MenuSectionValue("loot_sec"))), loot_esp(conf(new CheckboxValue(false, "loot_cb"))),
      loot_min_distance(conf(new FloatSliderEditableValue(0.f, 0.f, 50.f, "loot_min_distance_itm"))),
      loot_distance(conf(new FloatSliderEditableValue(50.f, 1.f, 1500.f, "loot_max_distance_itm"))),
      loot_min_value(conf(new IntSliderEditableValue(10000, 0, 500000, "loot_min_value_itm"))),
      show_loot_prices(conf(new CheckboxValue(false, "show_loot_prices_cb"))),
      loot_price_gradient(conf(new CheckboxValue(false, "loot_price_gradient_cb"))),
      loot_high_value_max_range(conf(new CheckboxValue(false, "loot_high_value_max_range_cb"))),
      loot_gradient_cheap(conf(new ColorpickerValue({0.45f, 0.45f, 0.45f, 0.85f}, "gradient_cheap_color_clr"))),
      loot_gradient_expensive(conf(new ColorpickerValue({0.85f, 0.7f, 0.2f, 1.f}, "gradient_expensive_color_clr"))),
      loot_gradient_above_max(conf(new ColorpickerValue({0.85f, 0.7f, 0.2f, 1.f}, "gradient_above_max_color_clr"))),
      loot_gradient_max(conf(new IntSliderEditableValue(10000, 0, 1000000, "gradient_max_value_itm"))),
      loot_color(conf(new ColorpickerValue({0, 1, 1, 1}, "loot_color_clr"))),
      loot_hideout_color(conf(new ColorpickerValue({0.3f, 0.85f, 0.45f, 1.f}, "loot_hideout_color_clr"))),
      loot_wishlist_color(conf(new ColorpickerValue({1.f, 0.55f, 0.2f, 1.f}, "loot_wishlist_color_clr"))),
      section_loot_item_filter_(conf(new MenuSectionValue("loot_item_filter_sec"))),
      sep_loot_item_filter(conf(new SeparatorValue("esp_sep_loot_item_filter"))),
      loot_selected_items_only(conf(new CheckboxValue(false, "loot_selected_items_only_cb"))),
      loot_selected_item(conf(new ItemSearchValue("loot_item_search_txt", nullptr, false, /*multi=*/true))),
      section_loot_category_filter_(conf(new MenuSectionValue("loot_category_filter_sec"))),
      loot_category_filter(conf(new SelectValue(0,
                                                {
                                                    "loot_category_all_sel",
                                                    "loot_category_valuables_sel",
                                                    "loot_category_barter_sel",
                                                    "loot_category_medical_sel",
                                                    "loot_category_food_sel",
                                                    "loot_category_ammo_sel",
                                                    "loot_category_weapons_sel",
                                                    "loot_category_armor_sel",
                                                    "loot_category_keys_sel",
                                                },
                                                "loot_category_sel"))),
      loot_category_filter_enabled(conf(new CheckboxValue(false, "loot_category_filter_enabled_cb"))),
      loot_wl_filter(conf(new SelectValue(0,
                                          {
                                              "loot_wl_all_sel",
                                              "loot_wl_quests_sel",
                                              "loot_wl_hideout_sel",
                                              "loot_wl_trading_sel",
                                              "loot_wl_equipment_sel",
                                              "loot_wl_other_sel",
                                          },
                                          "loot_wl_filter_sel"))),
      loot_wishlist_filter_enabled(conf(new CheckboxValue(false, "loot_wishlist_filter_enabled_cb"))),
      show_provisions(conf(new CheckboxValue(true, "show_food_water_cb"))),
      corpse_show_loot(conf(new CheckboxValue(false, "show_corpse_loot_cb"))),
      sep_loot_containers(conf(new SeparatorValue("esp_sep_loot_containers"))),
      section_containers_(conf(new MenuSectionValue("containers_sec"))),
      container_esp(conf(new CheckboxValue(false, "containers_laggy_cb"))),
      container_show_loot(conf(new CheckboxValue(false, "show_container_loot_cb"))),
      container_show_value(conf(new CheckboxValue(false, "show_container_prices_cb"))),
      container_distance(conf(new FloatSliderEditableValue(100.f, 1.f, 1500.f, "container_distance_itm"))),
      container_color(conf(new ColorpickerValue({1, 0.5f, 0, 1}, "container_color_clr"))),
      sep_containers_quest(conf(new SeparatorValue("esp_sep_containers_quest"))),
      section_quest_(conf(new MenuSectionValue("quest_sec"))),
      quest_items(conf(new CheckboxValue(false, "quest_items_cb"))),
      quest_item_distance(conf(new FloatSliderEditableValue(300.f, 1.f, 1500.f, "quest_item_distance_itm"))),
      quest_item_color(conf(new ColorpickerValue({0.7f, 0.3f, 1.f, 1.f}, "quest_item_color_clr"))),
      quest_esp_enabled(conf(new CheckboxValue(false, "quest_esp_cb"))),
      quest_esp_descriptions(conf(new CheckboxValue(false, "quest_descriptions_cb"))),
      quest_esp_distance(conf(new FloatSliderEditableValue(500.f, 50.f, 2000.f, "quest_esp_dist_itm"))),
      quest_visit_color(conf(new ColorpickerValue({0, 1, 1, 1}, "quest_visit_color_clr"))),
      quest_find_color(conf(new ColorpickerValue({1, 1, 0, 1}, "quest_find_color_clr"))),
      quest_place_color(conf(new ColorpickerValue({1, 0, 1, 1}, "quest_place_color_clr")))
{
    // show_loot_prices->set_hidden_in_owner_menu(true);
    // loot_min_value->set_hidden_in_owner_menu(true);
}

ImVec4 EspModule::lerp_color(const ImVec4 &a, const ImVec4 &b, const float t)
{
    const float clamped = t < 0.f ? 0.f : (t > 1.f ? 1.f : t);
    return {a.x + (b.x - a.x) * clamped, a.y + (b.y - a.y) * clamped, a.z + (b.z - a.z) * clamped,
            a.w + (b.w - a.w) * clamped};
}

item_categories::wishlist_mask EspModule::wishlist_mask() const
{
    // loot_wl_filter SelectValue indices:
    //   0 = All (admit all groups)
    //   1 = Quests   -> wishlist_group::quests (0)
    //   2 = Hideout  -> wishlist_group::hideout (1)
    //   3 = Trading  -> wishlist_group::trading (2)
    //   4 = Equipment-> wishlist_group::equipment (3)
    //   5 = Other    -> wishlist_group::other (4)
    const auto idx = loot_wl_filter->get_value();
    if (idx == 0) return 0;
    return item_categories::group_bit(static_cast<item_categories::wishlist_group>(idx - 1));
}

bool EspModule::any_loot_category_filter() const
{
    // Each axis is gated by its own toggle now, so "is a filter active" asks the
    // toggles, not the dropdowns. A dropdown set to something other than All with its
    // toggle off is an inactive restriction, and treating it as active would keep
    // hiding items the user has switched off.
    return loot_category_filter_enabled->get_value() || loot_wishlist_filter_enabled->get_value();
}

// Only one loot-filter axis may be active at a time. This is the single place that
// decides it, and it is called from the draw path so the decision is applied before
// either predicate can read a value -- leaving both checkboxes live and hoping the
// predicates disagree would make "exclusive" advisory rather than enforced.
bool EspModule::enforce_loot_filter_exclusivity()
{
    const bool cat = loot_category_filter_enabled->get_value();
    const bool wl = loot_wishlist_filter_enabled->get_value();
    if (cat == wl)
        return false; // both off, or (defensively) both on
    if (cat && wl)
    {
        // Unreachable while the UI only ever turns one on, but a stale config file can
        // carry both. Drop the wishlist one: the category axis is the broader
        // question and its dropdown is the one with more granularity.
        loot_wishlist_filter_enabled->set_value(false);
        return true;
    }
    return false;
}

bool EspModule::loot_category_allowed(const item_categories::kind cat,
                                      const item_categories::wishlist_group group) const
{
    // The wishlist axis, gated on its own toggle. With the toggle off this returns
    // true unconditionally so it cannot hide anything.
    //
    // The comment that used to live here claimed gating on any_loot_category_filter()
    // would hide every non-wishlist item the moment the category dropdown was set;
    // that was true of the OLD shape, where both axes were applied together. It is not
    // true of this one, where each axis is decided alone.
    if (!loot_wishlist_filter_enabled->get_value())
        return true;
    if (loot_wl_filter->get_value() == 0)
        return true;
    if (cat == item_categories::kind::hideout || cat == item_categories::kind::wishlist)
        return item_categories::wishlist_allows(group, wishlist_mask());
    return false;
}

// database_name_for_template is gone.
//
// It existed only to recover an item's display name when the caller passed an empty
// one, so that the category switch had something to substring-match. The switch is
// gone, so there is nothing to match. game_items::name_by_id is still there for the
// callers that genuinely want a name (labels, pricing, the item-search dropdown);
// this was a wrapper around it that had exactly one caller, and that caller is the
// branch above.

bool EspModule::loot_ui_filter_allowed(const std::string &template_id, const std::string &name) const
{
    (void)name; // no longer read: the category comes from the item's class, not its name

    if (loot_selected_items_only->get_value())
    {
        // Multi-select: "Enable Individual Loot ESP" now admits every id the
        // query matched, not just the one the user clicked. It used to require a
        // pick, which meant a query with several results labelled only one.
        if (loot_selected_item->is_multi())
        {
            // Held by value-const-ref, which EXTENDS the temporary's lifetime
            // for the block -- this must not be a reference into the search
            // box, whose member is swapped on the render thread while this
            // runs on the game thread. See get_matched_ids().
            const auto matched = loot_selected_item->get_matched_ids();
            if (!matched || matched->empty() || matched->find(template_id) == matched->end())
                return false;
        }
        else
        {
            const std::string selected = loot_selected_item->get_selected_id();
            if (selected.empty() || template_id != selected)
                return false;
        }
    }

    // The category axis, gated on its own toggle. With the toggle off there is no
    // category restriction at all, so everything is allowed.
    //
    // The category is the ItemTemplate's concrete CLASS, resolved once at db build
    // time into entry::loot_kind (item_categories::loot_from_ancestry), not a
    // substring test against the display name.
    //
    // This replaces ~40 lines of English needle lists that had five provable
    // defects: Valuables was a strict subset of Barter; Barter had no positive
    // requirement, so Bolts, Duct tape and Car Battery all passed it; Ammo could
    // not see a calibre because none of its six needles contained a digit while EFT
    // ammo is named "7.62x51 M80"; buckets overlapped ("SURV-12 Sniper Rifle" was
    // both Medical and Weapons); and the needles were English against a name the
    // game localizes, so on a non-English client the whole feature silently matched
    // almost nothing. The class name is never localized.
    //
    // LootTeleportModule had already been moved onto this in the same way; see
    // item_categories::loot_category_allows, which is now the single implementation
    // and holds the "unknown allows" policy both copies must agree on.
    if (!loot_category_filter_enabled->get_value())
        return true;
    return item_categories::loot_category_allows(game_items::loot_kind_by_id(template_id),
                                                 loot_category_filter->get_value());
}

ImVec4 EspModule::color_for_loot_category(const item_categories::kind cat) const
{
    switch (cat)
    {
    case item_categories::kind::hideout:
        return loot_hideout_color->get_value();
    case item_categories::kind::wishlist:
        return loot_wishlist_color->get_value();
    default:
        return loot_color->get_value();
    }
}

void EspModule::ensure_wishlist_sets(Il2CppObject *profile, const bool force)
{
    if (!any_loot_category_filter())
        return;
    if (wishlist_sets_.ready && !force)
        return;
    eft_api::refresh_wishlist_filter_sets(profile, wishlist_sets_);
    wishlist_sets_refresh_ms_ = GetTickCount64();
}

item_categories::kind EspModule::classify_template(const std::string &template_id) const
{
    return item_categories::classify_id(template_id, wishlist_sets_);
}

ImVec4 EspModule::color_for_loot_price(const int price, const bool is_quest, const bool is_provision) const
{
    if (!loot_price_gradient->get_value())
        return loot_color->get_value();

    const ImVec4 cheap = loot_gradient_cheap->get_value();
    const ImVec4 expensive = loot_gradient_expensive->get_value();
    const ImVec4 above_max = loot_gradient_above_max->get_value();

    if (price <= 0)
        return cheap;

    const int max_val = loot_gradient_max->get_value();
    if (max_val <= 0 || price >= max_val)
        return above_max;

    const float t = static_cast<float>(price) / static_cast<float>(max_val);
    return lerp_color(cheap, expensive, t);
}

ImVec4 EspModule::get_npc_color(const eft_api::npc_kind kind) const
{
    switch (kind)
    {
    case eft_api::npc_kind::boss:
        return boss_color->get_value();
    case eft_api::npc_kind::guard:
        return guard_color->get_value();
    case eft_api::npc_kind::cultist:
        return cultist_color->get_value();
    case eft_api::npc_kind::raider:
        return raider_color->get_value();
    case eft_api::npc_kind::defector:
        return defector_color->get_value();
    case eft_api::npc_kind::civilian:
        return civilian_color->get_value();
    case eft_api::npc_kind::black_division:
        return black_division_color->get_value();
    case eft_api::npc_kind::btr:
        return btr_color->get_value();
    case eft_api::npc_kind::scav:
    default:
        return scav_color->get_value();
    }
}

void EspModule::draw_corner_box(ImDrawList *draw_list, const ImVec2 &pos, const ImVec2 &size, const ImU32 color,
                                const float thickness, const float corner_len, const bool drawn_scoped)
{
    const float x = pos.x;
    const float y = pos.y;
    const float w = size.x;
    const float h = size.y;

    // Clip each corner line against the real lens opening so a MAGNIFIED box crossing
    // the boundary is cut at the glass.
    //
    // `drawn_scoped` is what makes this correct rather than merely present
    // (2026-09-27, "drift away multiplied by lens" in main-camera mode). A box that
    // was already drawn through the MAIN camera lies outside the glass by
    // construction, so clipping it to the mask would erase it -- the failure was not
    // a missing clip but a clip applied to geometry that was not magnified.
    const bool optic_pass = game_state::esp_optic_proj && drawn_scoped;
    auto add_line = [&](const ImVec2 &a, const ImVec2 &b) {
        ImVec2 pa = a, pb = b;
        float t0 = 0.f, t1 = 1.f;
        if (optic_pass && eft_api::optic_lens_segment_interval({a.x, a.y, 0.f}, {b.x, b.y, 0.f}, t0, t1))
        {
            if (t1 <= t0)
                return;
            pa = {a.x + (b.x - a.x) * t0, a.y + (b.y - a.y) * t0};
            pb = {a.x + (b.x - a.x) * t1, a.y + (b.y - a.y) * t1};
        }
        draw_list->AddLine(pa, pb, color, thickness);
    };

    add_line({x, y}, {x + corner_len, y});
    add_line({x, y}, {x, y + corner_len});
    add_line({x + w - corner_len, y}, {x + w, y});
    add_line({x + w, y}, {x + w, y + corner_len});
    add_line({x, y + h - corner_len}, {x, y + h});
    add_line({x, y + h}, {x + corner_len, y + h});
    add_line({x + w - corner_len, y + h}, {x + w, y + h});
    add_line({x + w, y + h - corner_len}, {x + w, y + h});
}

void EspModule::draw_player_health_bar(ImDrawList *draw_list, const ImVec2 &box_pos, const ImVec2 &box_size,
                                       const EspModule::player &entry) const
{
    if (entry.health_max <= 0.01f)
        return;

    const float sf = menu::get_scale_factor();
    const float bar_w = 4.f * sf;
    const float bar_x = box_pos.x - 6.f * sf;
    const float bar_top = box_pos.y;
    const float bar_bottom = box_pos.y + box_size.y;

    draw_list->AddRectFilled({bar_x, bar_top}, {bar_x + bar_w, bar_bottom}, IM_COL32(0, 0, 0, 180));

    float ratio = 1.f;
    if (!entry.is_alive)
        ratio = 0.f;
    else
        ratio = (std::max)(0.f, (std::min)(1.f, entry.health_current / entry.health_max));

    const float filled_h = box_size.y * ratio;
    const ImVec4 col = ratio < 0.5f ? health_low_color->get_value() : health_color->get_value();
    draw_list->AddRectFilled({bar_x, bar_bottom - filled_h}, {bar_x + bar_w, bar_bottom}, ImGui::GetColorU32(col));
}

void EspModule::draw_player_label_text(ImDrawList *draw_list, const ImVec2 &anchor, const ImVec4 &color,
                                       const EspModule::player &entry, const float distance) const
{
    const float font = esp_text::esp_font_size();
    ImFont *hud_font = menu::get_hud_font();

    if (show_bot_names->get_value() && entry.show_name_line)
    {
        // Was: a text_size lambda plus three measurement lines, written out TWICE --
        // once in the plain label path and once in the optic one. Now one helper,
        // and the locals keep their names so the drawing below is untouched.
        //
        // THE GUARD STAYS, and it is not redundant: it is what stops the drawing
        // below from running when bot names are off. The helper checks the same
        // condition, but only for its own measurements.
        const auto names = measure_bot_names_line(entry, show_bot_names->get_value(), font, hud_font);
        const ImVec2 prefix_size = names.prefix_size;
        const float line_gap = 2.f * menu::get_scale_factor();
        const float name_h = names.name_h;
        const float total_h = names.total_h;
        const float top_y = anchor.y - total_h * 0.5f;

        // Combat layer: player/NPC labels always above loot/world ESP text.
        esp_text::draw_simple(draw_list, hud_font, font, {anchor.x, top_y + prefix_size.y * 0.5f}, color,
                              entry.prefix_utf8, distance, esp_text::draw_layer::combat);

        if (!entry.name_utf8.empty())
        {
            esp_text::draw_simple(draw_list, hud_font, font,
                                  {anchor.x, top_y + prefix_size.y + line_gap + name_h * 0.5f}, color, entry.name_utf8,
                                  distance, esp_text::draw_layer::combat);
        }
        return;
    }

    esp_text::draw_simple(draw_list, hud_font, font, anchor, color, entry.label_utf8, distance,
                          esp_text::draw_layer::combat);
}

bool EspModule::is_player_any_part_visible(const unity::vector3 &vis_origin, Il2CppObject *player_obj,
                                           Il2CppObject *shooter_obj) const
{
    // Zoned because this REBUILDS THE ENTIRE BONE MAP from scratch
    // (EspModule.cpp:373-374, collect_skeleton_bones) and then raycasts once per resolved
    // bone with no cap on the plain path. When box visibility and the skeleton are both
    // on, a player therefore has its bones resolved and raycast TWICE per tick -- once
    // here and once in collect_skeleton. This zone is how that duplication would show up.
    TA_ZONE_N("EspModule::is_player_any_part_visible");
    if (!skeleton_vis::is_ready() || !player_obj)
        return true;

    std::unordered_map<std::string, unity::vector3> bones;
    esp_bones::collect_skeleton_bones(player_obj, bones);
    if (bones.empty())
    {
        unity::vector3 head{};
        unity::vector3 feet{};
        if (!eft_api::try_get_head_position(player_obj, head))
            return true;

        Il2CppObject *player_tr = skeleton_vis::get_player_transform(player_obj);
        if (player_tr)
            feet = unity::transform_get_pos(player_tr);
        else
            feet = head;

        if (skeleton_vis::is_target_visible(vis_origin, head, player_obj, shooter_obj))
            return true;
        return skeleton_vis::is_target_visible(vis_origin, feet, player_obj, shooter_obj);
    }

    for (const auto &bone : bones)
    {
        if (skeleton_vis::is_target_visible(vis_origin, bone.second, player_obj, shooter_obj))
            return true;
    }
    return false;
}

bool EspModule::compute_player_box_layout(Il2CppObject *cam, const EspModule::player &entry, ImVec2 &box_pos,
                                          ImVec2 &box_size, ImVec2 &label_anchor, ImVec4 &color,
                                          bool *drawn_scoped) const
{
    // Section 7 (2026-09-27): head and feet MUST come from the same projection.
    //
    // The user report -- "if an ESP skeleton goes past the scope it gets stretched
    // and placed in both places" -- has the same root cause here: `world_to_screen`
    // dispatches per point, so a straddling body resolved head through the optic
    // chain and feet through the main camera, and then
    //
    //     height = fabsf(head_screen.y - feet_screen.y)
    //
    // subtracted one projection's y from the other's. The box tore apart.
    //
    // Interim rule: choose the camera ONCE for the whole box, by its centre, and
    // project both ends with it. That is "a choice made once per player", which
    // optic_idea.md line 574 explicitly says NOT to do -- but the alternative is a
    // per-segment split of a rectangle whose horizontal edges have no world-space
    // endpoints (the width is a screen-space constant), which is real work and is
    // still outstanding. A coherent box beats a torn one, and this is the one place
    // the spec's rule is knowingly bent.
    //
    // The skeleton, which DOES have world endpoints per segment, uses the spec's
    // two-pass split instead -- see draw_skeleton_entry_optic.
    //
    // `drawn_scoped` is not cosmetic. draw_corner_box clips its corner segments to the
    // lens opening, which is correct for a MAGNIFIED box but actively wrong for one
    // already drawn with the main camera: that box sits outside the glass by
    // construction, so clipping it to the mask erases it. That was the second half of
    // the "drift away multiplied by lens" report in main-camera mode.
    const bool s7 = game_state::esp_optic_proj && game_state::esp_optic_s7;
    eft_api::region_pick pick{};
    pick.draw = true;
    pick.scoped = true;
    if (s7)
    {
        const optics::lens::packet *p = eft_api::optic_lens_packet();
        if (p && p->mask.size() >= 3)
        {
            const unity::vector3 probe{static_cast<float>((entry.head_pos.x + entry.pos3d.x) * 0.5),
                                       static_cast<float>((entry.head_pos.y + entry.pos3d.y) * 0.5),
                                       static_cast<float>((entry.head_pos.z + entry.pos3d.z) * 0.5)};
            const float w = static_cast<float>(menu::get_width());
            const float h = static_cast<float>(menu::get_height());
            optics::lens::v2 px{};
            const bool inside =
                !optics::lens::project_point(*p, optics::lens::v3{probe.x, probe.y, probe.z}, w, h, px) ||
                optics::lens::point_in_mask(*p, optics::lens::v2{px.x / w * 2.f - 1.f, 1.f - px.y / h * 2.f});
            pick = eft_api::optic_pick_region(inside);
            if (!pick.draw)
            {
                // Centre is out past the glass and the mode is cull: the game shows
                // scope housing there, so the box goes. Dropping it whole is coarse --
                // a straddling box could instead be clipped edge by edge, which is
                // still outstanding -- but it is COHERENT.
                ++optics::lens::g_s7.box_culled;
                return false;
            }
        }
    }
    if (drawn_scoped)
        *drawn_scoped = pick.scoped;

    const auto project = [&](const unity::vector3 &wp) {
        return eft_api::optic_project_region(pick, cam, wp, game_state::esp_draw_zoom);
    };
    const unity::vector3 head_screen = project(entry.head_pos);
    const unity::vector3 feet_screen = project(entry.pos3d);
    if (!eft_api::is_visible(head_screen) && !eft_api::is_visible(feet_screen))
        return false;

    const float sf = menu::get_scale_factor();
    const float top = head_screen.y - 10.f * sf;
    const float height = fabsf(head_screen.y - feet_screen.y) + 10.f * sf;
    const float width = height * 0.65f;
    box_pos = {feet_screen.x - width * 0.5f, top};
    box_size = {width, height};
    label_anchor = {feet_screen.x, top - 12.f * sf};
    color = entry.kind == eft_api::npc_kind::pmc ? player_color->get_value() : get_npc_color(entry.kind);
    return true;
}

void EspModule::draw_player_box_geometry(ImDrawList *draw_list, const ImVec2 &box_pos, const ImVec2 &box_size,
                                         const ImVec4 &color, const EspModule::player &entry,
                                         const bool drawn_scoped) const
{
    const float sf = menu::get_scale_factor();
    ImVec4 box_tint = color;
    if (player_box->get_value())
    {
        box_tint = box_visibility->get_value()
                       ? (entry.any_part_visible ? box_visible_color->get_value() : box_occluded_color->get_value())
                       : box_color->get_value();
    }
    const ImU32 box_col = player_box->get_value() ? ImGui::GetColorU32(box_tint) : ImGui::GetColorU32(color);

    if (player_box->get_value())
    {
        draw_corner_box(draw_list, box_pos, box_size, box_col, box_thickness->get_value() * sf, 5.f * sf, drawn_scoped);
    }

    // The health bar is a filled rect, not a line set, so it cannot be clipped the way
    // the corner segments are. It is gated on the same decision instead: a magnified
    // bar whose midpoint has fallen out past the glass is dropped rather than drawn
    // magnified over the scope housing. Coarse in the same way the box centre test is,
    // and for the same reason -- see the note on compute_player_box_layout.
    if (player_health->get_value())
    {
        bool draw_bar = true;
        if (drawn_scoped && game_state::esp_optic_proj && game_state::esp_optic_s7)
        {
            const float bar_x = box_pos.x - 6.f * sf;
            const float bar_y = (box_pos.y + (box_pos.y + box_size.y)) * 0.5f;
            if (!eft_api::optic_point_inside_menu(bar_x, bar_y))
            {
                ++optics::lens::g_s7.box_culled;
                draw_bar = false;
            }
        }
        if (draw_bar)
            draw_player_health_bar(draw_list, box_pos, box_size, entry);
    }
}

void EspModule::draw_skeleton_entry_optic(ImDrawList *draw_list, Il2CppObject *cam,
                                          const EspModule::skeleton_entry &entry) const
{
    // The other of the two variants, and the one taken whenever the optic projection is
    // live. Zoned so the two can be compared: if this dominates, the cost is in the
    // section 7 split and the per-bone world_to_screen_scoped_only, not in bone resolution.
    TA_ZONE_N("EspModule::draw_skeleton_entry_optic");
    const auto &links = esp_bones::skeleton_links();
    const float thickness = skeleton_thickness->get_value() * menu::get_scale_factor();

    // World-position sanity check, SHARED with draw_skeleton_entry (EspModule.cpp:867).
    //
    // The non-optic variant has always had this; the optic variant is the one actually
    // taken whenever the optic projection is live (EspModule.cpp:4919), and it had none.
    // That asymmetry is not a style point: `world_to_screen_scoped_only` can return
    // coordinates from either the lens projection or the main-camera fallback inside the
    // SAME frame (world_to_screen_optic_scoped falls back on a failed lens ensure,
    // eft_api.h:2657-2661), and is_visible only rejects points off the screen. A bone
    // whose position is wrong-but-finite therefore survived both and was drawn, which is
    // the "lines all over screen" report.
    //
    // The bound is 1e6 because that is what the non-optic path has always used and real
    // EFT world coordinates are three orders of magnitude below it -- so the check
    // cannot reject a legitimate bone, and can only catch a position that was never a
    // bone position at all.
    // The lambda is is_valid_pos above: this used to carry its own copy, which is
    // the third time the same test had been written out in this file. A lambda is a
    // fresh type per definition site, so two copies of it are two unrelated closures
    // that merely agree.
    auto to_screen = [&](const esp_bones::bone_ref &ref) -> std::optional<ImVec2> {
        const auto it = entry.bones.find(esp_bones::bone_key(ref));
        if (it == entry.bones.end())
            return std::nullopt;
        if (!is_valid_pos(it->second))
            return std::nullopt;
        // Scoped-only, deliberately. The two-pass split below decides which camera
        // each PIECE of a bone is drawn with, and it needs both endpoints in ONE
        // projection to compute the inside interval. Letting `world_to_screen` also
        // dispatch per point would mix the two, which is what made a straddling
        // skeleton appear "stretched and placed in both places" (user report
        // 2026-09-27). Standalone geometry -- labels, symbols -- keeps the per-point
        // dispatch, because an independent point has nothing to be consistent with.
        const unity::vector3 screen_pos =
            eft_api::world_to_screen_scoped_only(cam, it->second, game_state::esp_draw_zoom);
        if (!eft_api::is_visible(screen_pos))
            return std::nullopt;
        return ImVec2(screen_pos.x, screen_pos.y);
    };

    // World-space position of a bone reference, for the section 7 segment split.
    // The split needs world endpoints because the two cameras disagree off-mask:
    // interpolating in one projection's screen space and re-projecting with the
    // other would be wrong.
    const auto to_world = [&](const esp_bones::bone_ref &ref) -> std::optional<unity::vector3> {
        const auto it = entry.bones.find(esp_bones::bone_key(ref));
        if (it == entry.bones.end())
            return std::nullopt;
        // Same gate as to_screen. Without it the section 7 path is a HOLE in the check:
        // it reads to_world, not to_screen, so a bad position that to_screen would have
        // rejected still reached optic_lens_segment_s7 and was drawn from seg.in_a /
        // seg.out_a -- which is why this needed fixing here and not only in to_screen.
        if (!is_valid_pos(it->second))
            return std::nullopt;
        return it->second;
    };

    for (size_t link_index = 0; link_index < links.size(); ++link_index)
    {
        const auto &link = links[link_index];
        const int body_part = esp_bones::body_part_for_link(link);
        const ImU32 link_color = skeleton_link_color(entry, body_part, link_index);

        // ---- section 7 (optic_idea.md line 574): two passes, disjoint geometry --
        // Inside the lens mask the bone is drawn with the optic chain; outside it is
        // drawn with the MAIN camera, and the inside interval is removed from that
        // pass so the two never overlap and never leave a gap. Up to three screen
        // pieces come out of one bone.
        if (game_state::esp_optic_s7)
        {
            const auto wa = to_world(link.from);
            const auto wb = to_world(link.to);
            if (wa && wb)
            {
                eft_api::s7_segment seg{};
                if (eft_api::optic_lens_segment_s7(*wa, *wb, seg))
                {
                    // BOUNDS CHECK, and it is missing everywhere else in this block.
                    //
                    // The section 7 pieces are the only skeleton geometry in the module that
                    // reaches AddLine without passing through to_screen, and to_screen is
                    // where the discipline lives: is_visible rejects anything outside the
                    // viewport (plus 100px), and a max_coord clamp of 10x the screen
                    // dimension catches a projection blow-up. These pieces bypass both.
                    //
                    // The complement pieces are the exposure. optic_lens_segment_s7 lerps the
                    // off-mask intervals in WORLD space and projects each end with the MAIN
                    // camera (eft_api.h:2592-2609), and the two cameras are documented there
                    // as not agreeing off-mask. Its only geometric guard is z <= 0.01f, which
                    // is a weak bound against division blow-up: a point just in front of the
                    // near plane has a tiny w, so a modest lateral offset projects to an
                    // enormous coordinate. The user reports exactly this -- "glitches when on
                    // a border and drawing goes past screen boundary" -- and it was invisible
                    // while the whole bone map was still mis-resolving.
                    //
                    // A piece is dropped rather than clipped. Clipping to the viewport is not
                    // obviously right here: a bone genuinely off-screen should still show a
                    // stub running to the edge, and ImGui already clips the raster. What must
                    // not happen is a segment endpoint landing far outside any plausible
                    // screen position, which is a projection failure rather than geometry.
                    //
                    // Counted rather than silent, because the bound is a judgement: if these
                    // counters stay at zero the bound is slack and costs nothing, and if they
                    // climb, the guard is doing real work and the optic-perf line is where to
                    // look next.
                    const auto piece_in_bounds = [](const ImVec2 &a, const ImVec2 &b) {
                        const float w = static_cast<float>(menu::get_width());
                        const float h = static_cast<float>(menu::get_height());
                        if (w < 1.f || h < 1.f)
                            return false;
                        const float bound_x = w * kS7ScreenBoundFactor;
                        const float bound_y = h * kS7ScreenBoundFactor;
                        const auto finite = [](float v) { return v == v && v < 1e7f && v > -1e7f; };
                        if (!finite(a.x) || !finite(a.y) || !finite(b.x) || !finite(b.y))
                            return false;
                        return std::abs(a.x) <= bound_x && std::abs(a.y) <= bound_y && std::abs(b.x) <= bound_x &&
                               std::abs(b.y) <= bound_y;
                    };
                    using ::g_s7_pieces_dropped_inside;
                    using ::g_s7_pieces_dropped_outside;

                    if (seg.has_inside)
                    {
                        if (piece_in_bounds(seg.in_a, seg.in_b))
                            draw_list->AddLine(seg.in_a, seg.in_b, link_color, thickness);
                        else
                            ++g_s7_pieces_dropped_inside;
                    }
                    // In cull mode the complement is the scope housing, so it is not
                    // drawn at all. In main-camera mode it is the eye view, drawn at 1x.
                    if (game_state::esp_optic_periphery == game_state::optic_periphery::main_camera)
                    {
                        for (int i = 0; i < seg.outside_count; ++i)
                        {
                            if (piece_in_bounds(seg.out_a[i], seg.out_b[i]))
                                draw_list->AddLine(seg.out_a[i], seg.out_b[i], link_color, thickness);
                            else
                                ++g_s7_pieces_dropped_outside;
                        }
                    }
                    continue;
                }
            }
        }

        const auto start = to_screen(link.from);
        const auto end = to_screen(link.to);
        if (!start || !end)
            continue;

        // Single-pass fallback (section 7 off, or no world position): clip the bone
        // link against the REAL lens opening (pipeline-fitted mask) so lines crossing
        // the scope boundary are cut at the glass instead of spilling over the scope
        // picture.
        ImVec2 a = *start, b = *end;
        float t0 = 0.f, t1 = 1.f;
        if (eft_api::optic_lens_segment_interval({a.x, a.y, 0.f}, {b.x, b.y, 0.f}, t0, t1))
        {
            if (t1 <= t0)
                continue;
            a = {start->x + (end->x - start->x) * t0, start->y + (end->y - start->y) * t0};
            b = {start->x + (end->x - start->x) * t1, start->y + (end->y - start->y) * t1};
        }

        draw_list->AddLine(a, b, link_color, thickness);
    }

    if (!skeleton_head_circle->get_value())
        return;

    // The head circle is a STANDALONE piece, not a bone, so the section 7 segment split
    // above never sees it, and `to_screen` is scoped-only. Two reports pinned this down
    // in one session:
    //
    //  1. "heads are displaced" -- with cull on, the circle was still drawn at the
    //     MAGNIFIED position when the head sat out past the glass.
    //  2. "in case where we're not culling (second mode, both) ESP objects still
    //     drift away multiplied by lens" -- because the fix for (1) was a cull, and a
    //     cull is only one of the two answers. In main-camera mode the head circle had
    //     NO periphery handling at all, so it stayed magnified unconditionally.
    //
    // So decide the camera from the head point, then project head AND neck with it --
    // the radius is |head - neck| in screen space, so the two must share a projection
    // or the radius is a subtraction across two cameras (the tearing defect again).
    const auto head_world = to_world(esp_bones::pb_ref(esp_bones::pb::head));
    const auto neck_world = to_world(esp_bones::pb_ref(esp_bones::pb::neck));
    if (!head_world || !neck_world)
        return;

    // Probe the head in the optic projection, which is the space the mask lives in.
    const bool inside = [&] {
        const optics::lens::packet *p = eft_api::optic_lens_packet();
        if (!p || p->mask.size() < 3)
            return true;
        const float w = static_cast<float>(menu::get_width());
        const float h = static_cast<float>(menu::get_height());
        if (w < 1.f || h < 1.f)
            return true;
        optics::lens::v2 px{};
        if (!optics::lens::project_point(*p, optics::lens::v3{head_world->x, head_world->y, head_world->z}, w, h, px))
            return true;
        return optics::lens::point_in_mask(*p, optics::lens::v2{px.x / w * 2.f - 1.f, 1.f - px.y / h * 2.f});
    }();
    const eft_api::region_pick pick = eft_api::optic_pick_region(inside);
    if (!pick.draw)
    {
        ++optics::lens::g_s7.head_culled;
        return;
    }

    const unity::vector3 head_screen = eft_api::optic_project_region(pick, cam, *head_world, game_state::esp_draw_zoom);
    const unity::vector3 neck_screen = eft_api::optic_project_region(pick, cam, *neck_world, game_state::esp_draw_zoom);
    if (!eft_api::is_visible(head_screen) || !eft_api::is_visible(neck_screen))
        return;

    const float head_radius = sqrtf((head_screen.x - neck_screen.x) * (head_screen.x - neck_screen.x) +
                                    (head_screen.y - neck_screen.y) * (head_screen.y - neck_screen.y)) *
                              1.15f;
    if (head_radius < 1.f)
        return;

    const int segments = entry.distance < 20.f ? 48 : 24;
    const std::optional<size_t> head_link_index = find_head_link_index(links);
    draw_list->AddCircle(ImVec2(head_screen.x, head_screen.y), head_radius,
                         skeleton_link_color(entry,
                                             esp_bones::body_part_for_bone(esp_bones::pb_ref(esp_bones::pb::head)),
                                             head_link_index),
                         segments, thickness);
}

void EspModule::draw_player_label_text_optic(ImDrawList *draw_list, Il2CppObject *cam, const EspModule::player &entry,
                                             const ImVec4 &color, Il2CppObject *lens_renderer) const
{
    const float font = esp_text::esp_font_size();
    ImFont *hud_font = menu::get_hud_font();

    // Was: a text_size lambda plus three measurement lines, written out TWICE --
    // once in the plain label path and once in the optic one. Now one helper, and
    // the locals keep their names so the drawing below is untouched.
    //
    // THE GUARD IS NOT OPTIONAL and this replaceAll is why: it removed the
    // `if (show_bot_names...)` from BOTH sites, which would have measured and drawn
    // bot names with the feature off -- a behaviour change in the costume of a
    // deduplication. The helper checks the same condition, but the guard is what
    // keeps the drawing below from running. Restored on both sites.
    if (show_bot_names->get_value() && entry.show_name_line)
    {
        const auto names = measure_bot_names_line(entry, show_bot_names->get_value(), font, hud_font);
        const ImVec2 prefix_size = names.prefix_size;
        const float line_gap = 2.f * menu::get_scale_factor();
        const float name_h = names.name_h;
        const float total_h = names.total_h;

        unity::vector3 label_screen =
            eft_api::world_to_screen(cam, entry.pos3d, game_state::esp_draw_zoom, lens_renderer);

        if (!eft_api::is_visible(label_screen))
            return;

        const float top_y = label_screen.y - total_h * 0.5f;

        // Combat layer: player/NPC labels always above loot/world ESP text.
        esp_text::draw_simple(draw_list, hud_font, font, {label_screen.x, top_y + prefix_size.y * 0.5f}, color,
                              entry.prefix_utf8, entry.distance, esp_text::draw_layer::combat);

        if (!entry.name_utf8.empty())
        {
            esp_text::draw_simple(draw_list, hud_font, font,
                                  {label_screen.x, top_y + prefix_size.y + line_gap + name_h * 0.5f}, color,
                                  entry.name_utf8, entry.distance, esp_text::draw_layer::combat);
        }
        return;
    }

    // Use optic-aware projection for label anchor
    unity::vector3 label_screen = eft_api::world_to_screen(cam, entry.pos3d, game_state::esp_draw_zoom, lens_renderer);

    if (!eft_api::is_visible(label_screen))
        return;

    esp_text::draw_simple(draw_list, hud_font, font, {label_screen.x, label_screen.y}, color, entry.label_utf8,
                          entry.distance, esp_text::draw_layer::combat);
}

ImVec4 EspModule::limb_health_color(const eft_api::health_value &part, const bool destroyed) const
{
    if (destroyed || part.maximum <= 0.01f || part.current <= 0.01f)
        return {0.22f, 0.22f, 0.24f, 1.f};

    const float ratio = part.current / part.maximum;
    const float t = 1.f - (std::max)(0.f, (std::min)(1.f, ratio));
    const ImVec4 healthy = {0.68f, 0.68f, 0.68f, 1.f};
    const ImVec4 critical = {0.88f, 0.14f, 0.10f, 1.f};
    return {healthy.x + (critical.x - healthy.x) * t, healthy.y + (critical.y - healthy.y) * t,
            healthy.z + (critical.z - healthy.z) * t, 1.f};
}

ImU32 EspModule::skeleton_link_color(const EspModule::skeleton_entry &entry, const int body_part,
                                     const std::optional<size_t> link_index) const
{
    const bool health_on = skeleton_health_colors->get_value() && entry.has_limb_health && body_part >= 0 &&
                           body_part < static_cast<int>(entry.limb_health.size());
    const ImVec4 health_col = health_on ? limb_health_color(entry.limb_health[static_cast<size_t>(body_part)],
                                                            entry.limb_destroyed[static_cast<size_t>(body_part)])
                                        : skeleton_color->get_value();

    const bool vis_on = skeleton_visibility->get_value() && link_index && *link_index < entry.link_visible.size();
    const bool link_visible = vis_on && entry.link_visible[*link_index];

    if (vis_on && health_on)
    {
        switch (skeleton_vis_health_mode->get_value())
        {
        case 0: // Health on Visible — visible limb uses HP color, occluded uses red
            return ImGui::GetColorU32(link_visible ? health_col : skeleton_occluded_color->get_value());
        case 1: // Blend — mix HP color with visibility tint
            return ImGui::GetColorU32(link_visible
                                          ? lerp_color(health_col, skeleton_visible_color->get_value(), 0.35f)
                                          : lerp_color(health_col, skeleton_occluded_color->get_value(), 0.55f));
        case 2: // Dim Occluded — visible full HP, hidden limb is darkened HP
        default:
            if (link_visible)
                return ImGui::GetColorU32(health_col);
            return ImGui::GetColorU32(
                {health_col.x * 0.4f, health_col.y * 0.4f, health_col.z * 0.4f, health_col.w * 0.65f});
        }
    }

    if (vis_on)
    {
        return ImGui::GetColorU32(link_visible ? skeleton_visible_color->get_value()
                                               : skeleton_occluded_color->get_value());
    }

    if (health_on)
        return ImGui::GetColorU32(health_col);

    return ImGui::GetColorU32(skeleton_color->get_value());
}

EspModule::skeleton_entry EspModule::collect_skeleton(Il2CppObject *player_obj, const eft_api::npc_kind kind,
                                                      const float distance, const bool check_visibility,
                                                      const unity::vector3 &vis_origin, Il2CppObject *shooter_obj,
                                                      const float vis_check_max_dist) const
{
    // The whole per-player skeleton build: bone resolution plus the visibility raycasts.
    // Nothing below this was zoned before, so it was unattributable -- the draw half has
    // its own zones but the game-thread half that PRODUCES the skeleton had none at all.
    // Its child, skeleton_vis::is_target_visible, is already zoned, so (total - self)
    // isolates bone resolution from occlusion raycasting, which are different problems
    // with different fixes.
    TA_ZONE_N("EspModule::collect_skeleton");
    skeleton_entry entry{};
    entry.kind = kind;
    entry.distance = distance;
    esp_bones::collect_skeleton_bones(player_obj, entry.bones);
    {
        // The last unattributed piece of the module's largest function. 34.97 s total,
        // of which collect_skeleton_bones is 5.57 s and is_target_visible 27.68 s,
        // leaving ~1.7 s that was previously spread across the whole span and could
        // not be pinned on anything. Limb health is one call into eft_api over a fixed
        // limb array per player per tick, so it is either trivial or the thing worth
        // finding -- and right now it is indistinguishable from the bone lookup it
        // sits next to.
        TA_ZONE_N("EspModule::collect_skeleton:limb_health");
        entry.has_limb_health =
            eft_api::try_get_limb_health(player_obj, entry.limb_health.data(), entry.limb_destroyed.data(),
                                         static_cast<int>(entry.limb_health.size()));
    }

    // --- skeleton visibility ESP (rollback: remove this block) ---
    if (check_visibility && !entry.bones.empty())
    {
        const auto &links = esp_bones::skeleton_links();
        entry.link_visible.assign(links.size(), false);

        // VISIBILITY-CHECK DISTANCE CAP. Skips the raycasts for distant targets while
        // keeping every link marked occluded.
        //
        // WHY A CAP AND NOT `skeleton_distance`. Lowering `skeleton_distance` would also
        // stop the skeleton being drawn at all past the limit, which is a bigger change
        // than the measurement justifies. This caps only the physics.
        //
        // WHY ALL-FALSE IS THE CORRECT ANSWER HERE, and it is not "unknown". The draw
        // path decides visibility at EspModule.cpp:994:
        //
        //   const bool vis_on = skeleton_visibility->get_value() && link_index
        //       && *link_index < entry.link_visible.size();
        //
        // so an EMPTY link_visible makes vis_on FALSE, which falls through to plain
        // `skeleton_color` -- a full-colour silhouette. Bailing out early and leaving the
        // vector empty would therefore draw an enemy behind a wall as if fully visible.
        // The `assign(links.size(), false)` above has already run, so we are in the
        // occluded branch, which is what 97.6% of rays concluded anyway
        // (AGENTS_TODO.md 5.7i: 5,420,982 rays over two raids, hit_target = 0).
        //
        // So this is close to behaviour-preserving: beyond the cap the skeleton renders
        // in `skeleton_occluded_color`, which is what the rays were reporting for almost
        // every target, and we stop paying ~10.9 us per avoided ray.
        const bool cast_rays = distance <= vis_check_max_dist;
        skeleton_vis::record_vis_distance(cast_rays, entry.bones.size() > 0);
        if (!cast_rays)
        {
            // Deliberately NOT a `return`: the memo below must keep its shape, and the
            // only thing being skipped is the physics.
        }
        else
        {

            // FRAME-GATED, per player, serving the previous result. See the note on
            // vis_frame_serial_ for why the gate is a draw-frame counter rather than a rate.
            //
            // The previous answer is reused rather than leaving link_visible at its all-false
            // default: resetting would repaint every limb as occluded on the ticks we skip, which
            // at this ratio is most of them -- a flicker, not a throttle.
            const unsigned long long frame_now = vis_frame_serial_.load(std::memory_order_relaxed);
            auto &memo = vis_memo_[reinterpret_cast<uintptr_t>(player_obj)];
            if (memo.frame == frame_now && memo.link_visible.size() == links.size())
            {
                // HIT: no physics at all, just a vector copy. Zoned separately from the
                // miss branch below because the ratio between them is the one number
                // that says whether the 2,533,776 occlusion raycasts are necessary.
                //
                // This function is 34.97 s of the session and is_target_visible is 27.68 s
                // of that -- the raycasts are the cost, and every one avoided is ~10.9 us
                // of game-thread time. But "cut the raycasts" is not an available fix: they
                // are the feature. What IS available is raising the memo hit rate, and that
                // is unmeasurable while both paths sit inside one unzoned span. calls(hit)
                // and calls(miss) give the hit rate directly; mean_us(miss) gives the cost
                // of the frames that actually raycast.
                TA_ZONE_N("EspModule::collect_skeleton:vis_memo_hit");
                entry.link_visible = memo.link_visible;
            }
            else
            {
                TA_ZONE_N("EspModule::collect_skeleton:vis_rays");
                std::unordered_map<std::string, bool> bone_visible_cache;
                for (size_t i = 0; i < links.size(); ++i)
                {
                    const std::string to_key = esp_bones::bone_key(links[i].to);
                    const auto bone_it = entry.bones.find(to_key);
                    if (bone_it == entry.bones.end())
                        continue;

                    bool visible = false;
                    if (const auto cached = bone_visible_cache.find(to_key); cached != bone_visible_cache.end())
                    {
                        visible = cached->second;
                    }
                    else
                    {
                        visible = skeleton_vis::is_target_visible(vis_origin, bone_it->second, player_obj, shooter_obj);
                        bone_visible_cache[to_key] = visible;
                    }

                    entry.link_visible[i] = visible;
                }
                memo.frame = frame_now;
                memo.link_visible = entry.link_visible;
            }
        } // cast_rays
    }
    // --- end skeleton visibility ESP ---

    return entry;
}

void EspModule::draw_skeleton_entry(ImDrawList *draw_list, Il2CppObject *cam, const EspModule::skeleton_entry &entry,
                                    Il2CppObject *lens_renderer) const
{
    TA_ZONE_N("EspModule::draw_skeleton_entry");
    const auto &links = esp_bones::skeleton_links();
    const float thickness = skeleton_thickness->get_value() * menu::get_scale_factor();

    // Get screen dimensions for clamping
    ImVec2 screen_size = ImGui::GetIO().DisplaySize;
    const float max_coord = (screen_size.x > screen_size.y ? screen_size.x : screen_size.y) * 10.f; // generous clamp

    auto to_screen = [&](const esp_bones::bone_ref &ref) -> std::optional<ImVec2> {
        const auto it = entry.bones.find(esp_bones::bone_key(ref));
        if (it == entry.bones.end())
            return std::nullopt;
        // Validate bone world position before projection
        if (!is_valid_pos(it->second))
            return std::nullopt;
        // Pass lens_renderer to optic-aware projection
        const unity::vector3 screen_pos =
            eft_api::world_to_screen(cam, it->second, game_state::esp_draw_zoom, lens_renderer);
        if (!eft_api::is_visible(screen_pos))
            return std::nullopt;
        // Clamp to prevent wild lines from near-plane/infinite projections
        auto finite = [](float v) {
            return v == v && v != std::numeric_limits<float>::infinity() &&
                   v != -std::numeric_limits<float>::infinity();
        };
        if (!finite(screen_pos.x) || !finite(screen_pos.y) || !finite(screen_pos.z))
            return std::nullopt;
        if (std::abs(screen_pos.x) > max_coord || std::abs(screen_pos.y) > max_coord)
            return std::nullopt;
        return ImVec2(screen_pos.x, screen_pos.y);
    };

    for (size_t link_index = 0; link_index < links.size(); ++link_index)
    {
        const auto &link = links[link_index];
        const auto start = to_screen(link.from);
        const auto end = to_screen(link.to);
        if (!start || !end)
            continue;

        const int body_part = esp_bones::body_part_for_link(link);
        // draw_list->AddLine(*start, *end, skeleton_link_color(entry, body_part), thickness);
        draw_list->AddLine(*start, *end, skeleton_link_color(entry, body_part, link_index), thickness);
    }

    if (!skeleton_head_circle->get_value())
        return;

    const auto head_screen = to_screen(esp_bones::pb_ref(esp_bones::pb::head));
    const auto neck_screen = to_screen(esp_bones::pb_ref(esp_bones::pb::neck));
    if (!head_screen || !neck_screen)
        return;

    const float head_radius = sqrtf((head_screen->x - neck_screen->x) * (head_screen->x - neck_screen->x) +
                                    (head_screen->y - neck_screen->y) * (head_screen->y - neck_screen->y)) *
                              1.15f;
    if (head_radius < 1.f || head_radius > max_coord)
        return;

    const int segments = entry.distance < 20.f ? 48 : 24;
    const std::optional<size_t> head_link_index = find_head_link_index(links);
    // draw_list->AddCircle(*head_screen, head_radius,
    //     skeleton_link_color(entry, esp_bones::body_part_for_bone(esp_bones::pb_ref(esp_bones::pb::head))),
    //     segments, thickness);
    draw_list->AddCircle(*head_screen, head_radius,
                         skeleton_link_color(entry,
                                             esp_bones::body_part_for_bone(esp_bones::pb_ref(esp_bones::pb::head)),
                                             head_link_index),
                         segments, thickness);
}

float EspModule::get_transform_yaw_y(Il2CppObject *transform)
{
    float yaw = 0.f;
    (void)try_get_transform_yaw_y(transform, yaw);
    return yaw;
}

// WHY THIS EXISTS ALONGSIDE get_transform_yaw_y. The float version cannot express
// failure: it returns 0.f for a null transform, for an unresolved `get_eulerAngles`,
// and for a genuine 0 degrees, and a caller has no way to tell those apart.
//
// That ambiguity is not academic. The 2026-10-04 06:56 raid used a view-cone cull whose
// DIRECTION came from this read, and the first three 30 s windows reported
//
//   vis-cone: built=0 culled=29544 of=29544 culledPct=100%
//   vis-cone: built=0 culled=28800 of=28800 culledPct=100%
//   vis-cone: built=0 culled=29132 of=29132 culledPct=100%
//
// -- every skeleton culled, in every direction, for the first ~90 s of the raid, which is
// exactly "the cull cannot tell which way is forward and is therefore pointing somewhere
// arbitrary". A cull that cannot establish the view direction must NOT fire, and that
// requires being able to say "I could not read it".
bool EspModule::try_get_transform_yaw_y(Il2CppObject *transform, float &out_deg)
{
    out_deg = 0.f;
    if (!transform || !transform->klass)
        return false;

    const MethodInfo *method = il2utils::resolve_method(transform->klass, "get_eulerAngles", 0);
    if (!method || !method->methodPointer)
        return false;

    const auto get_euler = reinterpret_cast<unity::vector3 (*)(Il2CppObject *)>(method->methodPointer);
    out_deg = get_euler(transform).y;
    return std::isfinite(out_deg);
}

float EspModule::get_view_yaw(Il2CppObject *cam)
{
    if (!cam)
        return 0.f;

    Il2CppObject *cam_go = unity::component_get_game_object(cam);
    if (!cam_go)
        return 0.f;

    Il2CppObject *cam_tr = unity::gameobject_get_transform(cam_go);
    return get_transform_yaw_y(cam_tr);
}

float EspModule::normalize_degrees(float deg)
{
    while (deg < 0.f)
        deg += 360.f;
    while (deg >= 360.f)
        deg -= 360.f;
    return deg;
}

float EspModule::shortest_angle_delta(float from_deg, float to_deg)
{
    float delta = to_deg - from_deg;
    while (delta > 180.f)
        delta -= 360.f;
    while (delta < -180.f)
        delta += 360.f;
    return delta;
}

void EspModule::update_compass_anim(const float target_yaw) const
{
    const ULONGLONG now = GetTickCount64();
    if (!compass_anim_initialized_)
    {
        compass_anim_yaw_ = target_yaw;
        compass_anim_initialized_ = true;
        compass_anim_last_ms_ = now;
        return;
    }

    float dt = static_cast<float>(now - compass_anim_last_ms_) * 0.001f;
    compass_anim_last_ms_ = now;
    dt = (std::min)(dt, 0.1f);

    const float delta = shortest_angle_delta(compass_anim_yaw_, target_yaw);
    const float smooth = 1.f - expf(-dt * 14.f);
    compass_anim_yaw_ = normalize_degrees(compass_anim_yaw_ + delta * smooth);
}

bool EspModule::world_to_radar_point(const unity::vector3 &pos, const float view_yaw, const float cx, const float cy,
                                     const float range, const float scale, ImVec2 &out) const
{
    const float dx = pos.x - my_pos.x;
    const float dz = pos.z - my_pos.z;
    const float horiz_dist = sqrtf(dx * dx + dz * dz);
    if (horiz_dist < 0.01f)
        return false;

    constexpr float deg2rad = 3.14159265f / 180.f;
    const float rel = atan2f(dx, dz) - view_yaw * deg2rad;
    const float sin_r = sinf(rel);
    const float cos_r = cosf(rel);
    const float axis_denom = fmaxf(fabsf(sin_r), fabsf(cos_r));
    if (axis_denom < 0.0001f)
        return false;

    const float max_horiz_dist = range / axis_denom;
    if (horiz_dist > max_horiz_dist)
        return false;

    const float off_x = horiz_dist * sin_r * scale;
    const float off_y = -horiz_dist * cos_r * scale;
    out = {cx + off_x, cy + off_y};
    return true;
}

bool EspModule::player_moved_on_map(const unity::vector3 &current, const unity::vector3 &previous)
{
    constexpr float eps = 0.015f;
    const float dx = current.x - previous.x;
    const float dz = current.z - previous.z;
    return dx * dx + dz * dz > eps * eps;
}

ImU32 EspModule::col_alpha(const ImU32 col, const float opacity)
{
    const int a = static_cast<int>(((col >> IM_COL32_A_SHIFT) & 0xFF) * opacity);
    return (col & ~IM_COL32_A_MASK) | (static_cast<ImU32>(a) << IM_COL32_A_SHIFT);
}

ImU32 EspModule::col4_alpha(const ImVec4 &color, const float opacity)
{
    return ImGui::GetColorU32(ImVec4(color.x, color.y, color.z, color.w * opacity));
}

float EspModule::minimap_glyph_half_extent(ImFont *hud_font, const float font_size, const char *symbol)
{
    const ImVec2 size =
        hud_font ? hud_font->CalcTextSizeA(font_size, FLT_MAX, 0.f, symbol) : ImGui::CalcTextSize(symbol);
    return (std::max)(size.x, size.y) * 0.5f;
}

float EspModule::minimap_label_anchor_y(const ImVec2 &point, const float icon_font, const float height_dy,
                                        const float sf, ImFont *hud_font, const char *marker_symbol)
{
    const esp_text::minimap_marker_settings &mm = esp_text::minimap_markers();
    const float gap = 0.5f * sf;
    const char *sym = (marker_symbol && marker_symbol[0]) ? marker_symbol : mm.exfil.c_str();
    const float sym_half = minimap_glyph_half_extent(hud_font, icon_font, sym);
    float stack_bottom = point.y + sym_half;

    if (height_dy <= -1.f)
    {
        const float height_half = minimap_glyph_half_extent(hud_font, mm.size_height_down, mm.height_down.c_str());
        stack_bottom = point.y + sym_half + gap + height_half * 2.f;
    }

    return stack_bottom + gap;
}

void EspModule::draw_minimap_player_marker(ImDrawList *draw_list, const ImVec2 &origin, const float dir_x,
                                           const float dir_y, const float sf, const float opacity,
                                           const bool rotate_map) const
{
    float rotation_rad = 0.f;
    if (!rotate_map)
    {
        const float dir_len_sq = dir_x * dir_x + dir_y * dir_y;
        if (dir_len_sq > 0.0001f)
            rotation_rad = atan2f(dir_x, -dir_y);
    }

    // Draw the local player as a normal minimap arrow instead of a font glyph.
    // North-up maps rotate the arrow with the player; rotating maps keep it upright.
    const float size = 11.f * sf;
    const float sine = sinf(rotation_rad);
    const float cosine = cosf(rotation_rad);
    const auto point = [&](const float x, const float y) {
        return ImVec2(origin.x + x * cosine - y * sine, origin.y + x * sine + y * cosine);
    };

    const ImVec2 arrow[] = {point(0.f, -size), point(size * 0.74f, size * 0.78f), point(0.f, size * 0.36f),
                            point(-size * 0.74f, size * 0.78f)};
    const float clamped_opacity = (std::max)(0.f, (std::min)(1.f, opacity));
    const int alpha = static_cast<int>(255.f * clamped_opacity);
    const ImU32 fill = IM_COL32(72, 181, 222, alpha); // menu steel blue
    const ImU32 outline = IM_COL32(5, 19, 31, alpha);

    draw_list->AddConvexPolyFilled(arrow, IM_ARRAYSIZE(arrow), fill);
    draw_list->AddPolyline(arrow, IM_ARRAYSIZE(arrow), outline, 2.f * sf, ImDrawFlags_Closed);
}

void EspModule::rotate_draw_list_verts(ImDrawList *draw_list, const int vtx_start, const ImVec2 &center,
                                       const float rad)
{
    if (rad == 0.f)
        return;

    const float s = sinf(rad);
    const float c = cosf(rad);
    for (int i = vtx_start; i < draw_list->VtxBuffer.Size; ++i)
    {
        ImDrawVert &v = draw_list->VtxBuffer[i];
        const ImVec2 rel = {v.pos.x - center.x, v.pos.y - center.y};
        v.pos.x = center.x + rel.x * c - rel.y * s;
        v.pos.y = center.y + rel.x * s + rel.y * c;
    }
}

void EspModule::draw_minimap_symbol_marker(ImDrawList *draw_list, const ImVec2 &center, const char *symbol,
                                           const float font_size, const float opacity, const ImVec4 &color,
                                           const float rotation_rad) const
{
    if (!symbol || !symbol[0])
        return;

    ImFont *hud_font = menu::get_hud_font();
    const ImVec2 text_size =
        hud_font ? hud_font->CalcTextSizeA(font_size, FLT_MAX, 0.f, symbol) : ImGui::CalcTextSize(symbol);

    const ImVec2 top_left = {center.x - text_size.x * 0.5f, center.y - text_size.y * 0.5f};

    const ImVec4 tinted = ImVec4(color.x, color.y, color.z, color.w * opacity);
    const int vtx_start = draw_list->VtxBuffer.Size;

    if (esp_text::minimap_marker_outline_enabled())
    {
        esp_text::draw_outlined(draw_list, hud_font, font_size, top_left, tinted, symbol);
        rotate_draw_list_verts(draw_list, vtx_start, center, rotation_rad);
        return;
    }

    const ImU32 shadow_col = col_alpha(IM_COL32(0, 0, 0, 210), opacity);
    const ImU32 fill_col = col4_alpha(color, opacity);
    const ImVec2 shadow_offset = {0.8f, 0.8f};

    if (hud_font)
    {
        draw_list->AddText(hud_font, font_size, {top_left.x + shadow_offset.x, top_left.y + shadow_offset.y},
                           shadow_col, symbol);
        draw_list->AddText(hud_font, font_size, top_left, fill_col, symbol);
    }
    else
    {
        draw_list->AddText({top_left.x + shadow_offset.x, top_left.y + shadow_offset.y}, shadow_col, symbol);
        draw_list->AddText(top_left, fill_col, symbol);
    }

    rotate_draw_list_verts(draw_list, vtx_start, center, rotation_rad);
}

float EspModule::pick_grid_spacing(const float range)
{
    if (range >= 450.f)
        return 100.f;
    if (range >= 280.f)
        return 50.f;
    if (range >= 140.f)
        return 25.f;
    return 10.f;
}

void EspModule::draw_minimap_grid(ImDrawList *draw_list, const bool use_map, const minimap::map_bounds &display_bounds,
                                  const minimap::map_view_transform &view, const float map_yaw_deg, const float cx,
                                  const float cy, const float range, const float radar_scale, const float rx,
                                  const float ry, const float size, const float sf, const float opacity,
                                  const bool rotate_map) const
{
    // 2026-09-30. Crash #3 (00:15:41) faulted with a NULL read inside this function,
    // reached from draw_skeleton_entry_optic <- gameworld_update: i.e. while drawing a
    // radar point for a skeleton entry, which is what an NPC death triggers. Every
    // draw_list dereference below (AddLine in draw_world_line, and the frame rectangles)
    // was unguarded.
    //
    // This is also the radar branch, which is the ONLY branch that runs when the built-in
    // map assets are unavailable: with no map, use_map is false and the grid draws in
    // radar mode. The RCDATA reader was failing 22/22 on that run, so this was the common
    // case rather than the edge case, and it had no guard at all.
    //
    // The exact null is NOT established. The innermost frame resolved only to an unnamed
    // static (the PDB global stream carries no entry for a lambda), so this is defence in
    // depth on the one pointer every line here needs, not a proven fix.
    if (!draw_list)
        return;

    const float spacing = pick_grid_spacing(range);
    const float extent_scale = rotate_map ? 1.48f : 1.08f;
    const float extent = range * extent_scale;

    float grid_center_x = my_pos.x;
    float grid_center_z = my_pos.z;
    if (use_map && !minimap_follow_player_)
    {
        const float world_w = display_bounds.max_x - display_bounds.min_x;
        const float world_h = display_bounds.max_z - display_bounds.min_z;
        grid_center_x = display_bounds.min_x + minimap_center_u_ * world_w;
        grid_center_z = display_bounds.min_z + (1.f - minimap_center_v_) * world_h;
    }

    const auto draw_world_line = [&](const float x0, const float z0, const float x1, const float z1, const ImU32 col,
                                     const float thickness) {
        ImVec2 p0{};
        ImVec2 p1{};
        if (use_map)
        {
            if (!minimap::world_to_map_point(display_bounds, x0, z0, view, p0) ||
                !minimap::world_to_map_point(display_bounds, x1, z1, view, p1))
                return;
        }
        else
        {
            const unity::vector3 w0{x0, my_pos.y, z0};
            const unity::vector3 w1{x1, my_pos.y, z1};
            if (!world_to_radar_point(w0, map_yaw_deg, cx, cy, range, radar_scale, p0) ||
                !world_to_radar_point(w1, map_yaw_deg, cx, cy, range, radar_scale, p1))
                return;
        }

        draw_list->AddLine(p0, p1, col, thickness);
    };

    const auto is_major_line = [&](const float value) {
        const float major = spacing * 2.f;
        const float mod = fmodf(fabsf(value), major);
        return mod < 0.05f || major - mod < 0.05f;
    };

    const float start_x = floorf((grid_center_x - extent) / spacing) * spacing;
    for (float wx = start_x; wx <= grid_center_x + extent + 0.01f; wx += spacing)
    {
        const bool major = is_major_line(wx);
        const ImU32 col = col_alpha(major ? IM_COL32(210, 220, 230, 95) : IM_COL32(180, 190, 200, 45), opacity);
        const float thickness = (major ? 1.15f : 0.75f) * sf;
        draw_world_line(wx, grid_center_z - extent, wx, grid_center_z + extent, col, thickness);
    }

    const float start_z = floorf((grid_center_z - extent) / spacing) * spacing;
    for (float wz = start_z; wz <= grid_center_z + extent + 0.01f; wz += spacing)
    {
        const bool major = is_major_line(wz);
        const ImU32 col = col_alpha(major ? IM_COL32(210, 220, 230, 95) : IM_COL32(180, 190, 200, 45), opacity);
        const float thickness = (major ? 1.15f : 0.75f) * sf;
        draw_world_line(grid_center_x - extent, wz, grid_center_x + extent, wz, col, thickness);
    }
}

ImVec2 EspModule::square_compass_ring_point(const float cx, const float cy, const float outer_half, const float deg)
{
    float d = normalize_degrees(deg);
    const float side = outer_half * 2.f;

    if (d < 45.f)
    {
        const float t = (d + 45.f) / 90.f;
        return {cx - outer_half + t * side, cy - outer_half};
    }
    if (d < 135.f)
    {
        const float t = (d - 45.f) / 90.f;
        return {cx + outer_half, cy - outer_half + t * side};
    }
    if (d < 225.f)
    {
        const float t = (d - 135.f) / 90.f;
        return {cx + outer_half - t * side, cy + outer_half};
    }
    if (d < 315.f)
    {
        const float t = (d - 225.f) / 90.f;
        return {cx - outer_half, cy + outer_half - t * side};
    }

    const float t = (d - 315.f) / 90.f;
    return {cx - outer_half + t * side, cy - outer_half};
}

void EspModule::minimap_compass_padding(const float sf, float &pad_h, float &pad_v)
{
    const float frame = 20.f * sf;
    const float label_ring = 12.f * sf;
    const ImVec2 cardinal_sz = ImGui::CalcTextSize("N");
    const ImVec2 deg_sz = ImGui::CalcTextSize("315");
    const float label_half_w = (std::max)(cardinal_sz.x, deg_sz.x) * 0.5f;
    const float label_half_h = cardinal_sz.y * 0.5f;
    const float edge = frame + label_ring;
    pad_h = edge + label_half_w;
    pad_v = edge + label_half_h;
}

void EspModule::draw_minimap_compass_frame(ImDrawList *draw_list, const float rx, const float ry, const float size,
                                           const float sf, const float opacity, const float heading_deg,
                                           const bool rotate_map, const bool draw_backdrop,
                                           const ImVec4 &backdrop_color) const
{
    const float cx = rx + size * 0.5f;
    const float cy = ry + size * 0.5f;
    const float inner_half = size * 0.5f;
    const float pad = 20.f * sf;
    const float outer_half = inner_half + pad;
    const float frame_l = cx - outer_half;
    const float frame_t = cy - outer_half;
    const float frame_r = cx + outer_half;
    const float frame_b = cy + outer_half;
    const float inner_l = cx - inner_half;
    const float inner_t = cy - inner_half;
    const float inner_r = cx + inner_half;
    const float inner_b = cy + inner_half;

    const float flow_offset = rotate_map ? heading_deg : 0.f;
    const auto ring_pt = [&](const float deg, const float radius) -> ImVec2 {
        return square_compass_ring_point(cx, cy, radius, deg - flow_offset);
    };

    const ImU32 frame_bg = col4_alpha(backdrop_color, opacity);
    const ImU32 frame_line = col_alpha(IM_COL32(220, 228, 235, 220), opacity);
    const ImU32 tick_col = col_alpha(IM_COL32(190, 198, 208, 180), opacity);
    const ImU32 major_tick_col = col_alpha(IM_COL32(235, 240, 245, 230), opacity);
    const ImU32 north_col = col_alpha(IM_COL32(255, 70, 70, 220), opacity);

    if (draw_backdrop)
    {
        draw_list->AddRectFilled({frame_l, frame_t}, {frame_r, inner_t}, frame_bg);
        draw_list->AddRectFilled({frame_l, inner_b}, {frame_r, frame_b}, frame_bg);
        draw_list->AddRectFilled({frame_l, inner_t}, {inner_l, inner_b}, frame_bg);
        draw_list->AddRectFilled({inner_r, inner_t}, {frame_r, inner_b}, frame_bg);
    }
    draw_list->AddRect({frame_l, frame_t}, {frame_r, frame_b}, frame_line, 5.f * sf, 0, 1.4f * sf);

    for (int deg_i = 0; deg_i < 360; deg_i += 5)
    {
        const float deg = static_cast<float>(deg_i);
        const bool major = (deg_i % 15) == 0;
        const float tick_outer = outer_half;
        const float tick_inner = outer_half - (major ? 7.f : 4.f) * sf;

        const ImVec2 p_out = ring_pt(deg, tick_outer);
        const ImVec2 p_in = ring_pt(deg, tick_inner);
        draw_list->AddLine(p_in, p_out, major ? major_tick_col : tick_col, (major ? 1.4f : 0.9f) * sf);

        if (major && (deg_i % 90) != 0)
        {
            char deg_buf[8];
            snprintf(deg_buf, sizeof(deg_buf), "%d", deg_i);
            const ImVec2 label_pos = ring_pt(deg, outer_half + 10.f * sf);
            const ImVec2 text_size = ImGui::CalcTextSize(deg_buf);
            draw_list->AddText({label_pos.x - text_size.x * 0.5f, label_pos.y - text_size.y * 0.5f},
                               col_alpha(IM_COL32(200, 206, 214, 170), opacity), deg_buf);
        }
    }

    static const char *cardinals[] = {"N", "E", "S", "W"};
    static const float cardinal_deg[] = {0.f, 90.f, 180.f, 270.f};
    for (int i = 0; i < 4; ++i)
    {
        const ImVec2 pos = ring_pt(cardinal_deg[i], outer_half + 12.f * sf);
        const ImVec2 text_size = ImGui::CalcTextSize(cardinals[i]);
        const ImU32 col = i == 0 ? north_col : col_alpha(IM_COL32(220, 225, 232, 220), opacity);
        draw_list->AddText({pos.x - text_size.x * 0.5f, pos.y - text_size.y * 0.5f}, col, cardinals[i]);
    }

    const ImU32 marker_col = col_alpha(IM_COL32(255, 90, 70, 240), opacity);
    const ImVec2 marker_outer = ring_pt(heading_deg, outer_half - 1.f * sf);
    const ImVec2 marker_inner = ring_pt(heading_deg, inner_half + 3.f * sf);
    draw_list->AddLine(marker_inner, marker_outer, marker_col, 2.4f * sf);
    draw_list->AddCircleFilled(marker_outer, 2.6f * sf, marker_col);
}

void EspModule::draw_minimap_height_indicator(ImDrawList *draw_list, const ImVec2 &point, const float marker_y,
                                              const float player_y, const float marker_font, const char *marker_symbol,
                                              const float sf, const ImVec4 &color, const float opacity) const
{
    const float dy = marker_y - player_y;
    if (dy > -1.f && dy < 1.f)
        return;

    const bool above = dy >= 1.f;
    const esp_text::minimap_marker_settings &mm = esp_text::minimap_markers();
    ImFont *hud_font = menu::get_hud_font();
    const float gap = 0.5f * sf;
    const float sym_half = minimap_glyph_half_extent(hud_font, marker_font, marker_symbol);
    const char *height_symbol = above ? mm.height_up.c_str() : mm.height_down.c_str();
    const float glyph_font = above ? mm.size_height_up : mm.size_height_down;
    const float height_half = minimap_glyph_half_extent(hud_font, glyph_font, height_symbol);
    const float offset = sym_half + height_half + gap;
    const ImVec2 glyph_center = above ? ImVec2{point.x, point.y - offset} : ImVec2{point.x, point.y + offset};

    draw_minimap_symbol_marker(draw_list, glyph_center, height_symbol, glyph_font, opacity, color);
}

bool EspModule::is_point_inside_minimap(const ImVec2 &point, const float rx, const float ry, const float size,
                                        const float pad)
{
    return point.x >= rx - pad && point.x <= rx + size + pad && point.y >= ry - pad && point.y <= ry + size + pad;
}

void EspModule::draw_radar_marker_label(ImDrawList *draw_list, const ImVec2 &point, const ImVec4 &color,
                                        const std::string &text, const float font_size, const float opacity,
                                        const float clip_rx, const float clip_ry, const float clip_size,
                                        const float marker_icon_font, const float height_dy, const float sf) const
{
    if (text.empty())
        return;

    ImFont *hud_font = menu::get_hud_font();
    const ImVec2 text_size =
        hud_font ? hud_font->CalcTextSizeA(font_size, FLT_MAX, 0.f, text.c_str()) : ImGui::CalcTextSize(text.c_str());

    const float anchor_y = marker_icon_font > 0.f
                               ? minimap_label_anchor_y(point, marker_icon_font, height_dy, sf, hud_font)
                               : point.y + 5.f;
    ImVec2 top_left = {point.x - text_size.x * 0.5f, anchor_y};

    if (clip_size > 0.f)
    {
        const float clip_max_x = clip_rx + clip_size;
        const float clip_max_y = clip_ry + clip_size;
        top_left.x = (std::max)(clip_rx, (std::min)(top_left.x, clip_max_x - text_size.x));
        top_left.y = (std::max)(clip_ry, (std::min)(top_left.y, clip_max_y - text_size.y));
    }

    const ImVec4 tinted = ImVec4(color.x, color.y, color.z, color.w * opacity);
    esp_text::draw_simple_topleft(draw_list, hud_font, font_size, top_left, tinted, text);
}

bool EspModule::resolve_minimap_marker_point(const bool use_map, const minimap::map_bounds &display_bounds,
                                             const minimap::map_view_transform &view, const unity::vector3 &pos,
                                             const float map_yaw, const float cx, const float cy, const float range,
                                             const float radar_scale, const float rx, const float ry, const float size,
                                             ImVec2 &out) const
{
    if (use_map)
    {
        float u = 0.f;
        float v = 0.f;
        if (!minimap::world_to_uv(display_bounds, pos.x, pos.z, u, v))
            return false;
        if (u < 0.f || u > 1.f || v < 0.f || v > 1.f)
            return false;
        if (!minimap::world_to_map_point(display_bounds, pos.x, pos.z, view, out))
            return false;
    }
    else if (!world_to_radar_point(pos, map_yaw, cx, cy, range, radar_scale, out))
    {
        return false;
    }

    return is_point_inside_minimap(out, rx, ry, size, 2.f);
}

void EspModule::draw_radar_header_label(ImDrawList *draw_list, const ImVec2 &top_left, const std::string &text,
                                        const float font_size, const float opacity) const
{
    if (text.empty())
        return;

    // Always draw immediately — never via depth_sort queue (begin_frame clears pending).
    const ImVec4 color = ImVec4(1.f, 1.f, 1.f, 0.9f * opacity);
    ImFont *font = menu::get_hud_font();
    const ImU32 col = ImGui::GetColorU32(color);
    if (font)
        draw_list->AddText(font, font_size, top_left, col, text.c_str());
    else
        draw_list->AddText(top_left, col, text.c_str());
}

std::string EspModule::read_location_id(const Il2CppClass *game_world_class, Il2CppObjectInstance &game_world_instance)
{
    // The field scan is eft_api::read_location_id, shared with RaidDashboard,
    // MapModule, Teleport, MarkedRooms and AiLimit since 2026-10-14.
    if (std::string id = eft_api::read_location_id(game_world_class, game_world_instance); !id.empty())
        return id;

    // THE ONE THING THIS COPY DID THAT THE SHARED ONE DOES NOT, and the reason
    // this wrapper still exists rather than every caller going straight to
    // eft_api: when no FIELD resolves, fall back to the get_LocationId METHOD.
    // A build where the id is exposed only through a property has no field to
    // read, and this is the only caller that has ever needed to survive that.
    const Il2CppClass *classes[] = {
        game_world_class, game_world_instance.get_instance() ? game_world_instance.get_instance()->klass : nullptr};

    for (const Il2CppClass *clazz : classes)
    {
        if (!clazz)
            continue;

        const MethodInfo *location_method = il2utils::resolve_method(clazz, "get_LocationId", 0);
        if (location_method && location_method->methodPointer)
        {
            const auto get_location =
                reinterpret_cast<Il2CppString *(*)(Il2CppObject *)>(location_method->methodPointer);
            Il2CppString *value = get_location(game_world_instance.get_instance());
            if (value)
                return il2utils::conv_string(value);
        }
    }

    return {};
}

EspModule::minimap_layout EspModule::compute_minimap_layout(const float sf) const
{
    minimap_layout layout{};
    const float screen_w = menu::get_width();
    constexpr float fixed_margin = 24.f;

    float compass_pad_h = 0.f;
    float compass_pad_v = 0.f;
    if (minimap_module_self->radar_minimap_compass->get_value())
        minimap_compass_padding(sf, compass_pad_h, compass_pad_v);

    layout.size = eft_api::is_external_loot_inventory_open_cached() ? 120.f * sf
                                                                    : minimap_module_self->radar_size->get_value() * sf;

    // The layout controls are hidden.  Do not allow old saved values to
    // move the overlay away from its intended fixed upper-right anchor.
    layout.rx = screen_w - fixed_margin * sf - compass_pad_h - layout.size;
    layout.ry = fixed_margin * sf + compass_pad_v;

    return layout;
}

float EspModule::minimap_header_label_y(const float ry, const float size, const int corner)
{
    if (corner == 1)
        return ry + size + 4.f;
    return ry - 18.f;
}

void EspModule::handle_radar_window_input(const float rx, const float ry, const float size,
                                          const minimap::map_view_transform *view) const
{
    ImGuiIO &io = ImGui::GetIO();
    const ImVec2 mouse = io.MousePos;
    const bool hovered = mouse.x >= rx && mouse.x <= rx + size && mouse.y >= ry && mouse.y <= ry + size;

    if (!hovered)
    {
        minimap_dragging_ = false;
        return;
    }

    if (io.MouseWheel != 0.f)
    {
        const float step = io.MouseWheel * 5.f;
        minimap_module_self->radar_range->set_value(minimap_module_self->radar_range->get_value() - step);
    }

    if (!view)
    {
        minimap_dragging_ = false;
        return;
    }

    if (io.MouseDown[0])
    {
        if (!minimap_dragging_)
        {
            minimap_dragging_ = true;
            minimap_drag_last_ = mouse;
        }
        else if (view->map_w > 1.f && view->map_h > 1.f)
        {
            const ImVec2 delta = {mouse.x - minimap_drag_last_.x, mouse.y - minimap_drag_last_.y};

            constexpr float drag_threshold = 4.f;
            if (fabsf(delta.x) > drag_threshold || fabsf(delta.y) > drag_threshold)
                minimap_follow_player_ = false;

            const ImVec2 uv_last = minimap::screen_to_map_uv(*view, minimap_drag_last_);
            const ImVec2 uv_now = minimap::screen_to_map_uv(*view, mouse);
            minimap_drag_last_ = mouse;

            minimap_center_u_ += uv_last.x - uv_now.x;
            minimap_center_v_ += uv_last.y - uv_now.y;
        }
    }
    else
    {
        minimap_dragging_ = false;
    }
}

void EspModule::scan_bot_corpses_for_minimap(Il2CppObjectInstance &game_world_instance,
                                             std::vector<EspModule::bot_corpse_marker> &out) const
{
    out.clear();
    if (!minimap_module_self || !minimap_module_self->radar->get_value() ||
        !minimap_module_self->radar_minimap_bot_corpses->get_value())
        return;

    Il2CppObject *loot_hydra_obj = game_world_instance.get_field<Il2CppObject *>("LootItems");
    if (!loot_hydra_obj)
        return;

    Il2CppObjectInstance loot_hydra(loot_hydra_obj);
    unity::list *loot_list = loot_hydra.get_field<unity::list *>("_iteration");
    if (!loot_list || !loot_list->m_p_list_array)
        return;

    Il2CppArray *loot_array = loot_list->m_p_list_array;
    const int count = static_cast<int>(loot_array->max_length);
    const float range = minimap_module_self->radar_range->get_value();
    const float max_dist_sq = range * range;
    Il2CppObject *game_world = game_world_instance.get_instance();
    const ULONGLONG now = GetTickCount64();
    constexpr ULONGLONG ai_profile_refresh_ms = 3000;
    if (now - bot_corpse_ai_profiles_ms_ >= ai_profile_refresh_ms)
    {
        eft_api::collect_ai_profile_ids(game_world, bot_corpse_ai_profiles_);
        bot_corpse_ai_profiles_ms_ = now;
    }

    out.reserve(16);
    for (int i = 0; i < count; ++i)
    {
        Il2CppObject *loot_obj = reinterpret_cast<Il2CppObject **>(&loot_array->data)[i];
        if (!loot_obj || !eft_api::class_name_contains(loot_obj, "Corpse"))
            continue;
        if (!eft_api::try_is_bot_corpse(loot_obj, game_world, &bot_corpse_ai_profiles_))
            continue;

        Il2CppObject *game_object = unity::component_get_game_object(loot_obj);
        if (!game_object)
            continue;
        Il2CppObject *transform = unity::gameobject_get_transform(game_object);
        if (!transform)
            continue;

        const unity::vector3 pos = unity::transform_get_pos(transform);
        const float dx = my_pos.x - pos.x;
        const float dy = my_pos.y - pos.y;
        const float dz = my_pos.z - pos.z;
        const float dist_sq = dx * dx + dy * dy + dz * dz;
        if (dist_sq > max_dist_sq)
            continue;

        out.push_back({pos, sqrtf(dist_sq)});
    }
}

// The three categories the shipped map configs carry. Colours match the
// DynamicMaps source (door_with_lock yellow, the teal switch/secret pair) so a
// screenshot of one is readable against the other. Anything unrecognised draws
// white rather than not at all: a new category in the data should be visible
// and mis-coloured, never invisible.
static ImVec4 static_marker_color(const std::string& category) {
    if (category == "LockedDoor")
        return {1.f, 0.92f, 0.02f, 1.f};
    if (category == "Switch")
        return {0.1f, 0.6f, 0.6f, 1.f};
    if (category == "Secret")
        return {0.75f, 0.35f, 0.85f, 1.f};
    return {1.f, 1.f, 1.f, 1.f};
}

// ---------------------------------------------------------------------------
// Static marker placement check -- added 2026-10-14.
//
// The one thing the step-5 integrity tests CANNOT prove is the question that
// matters: a marker whose position is inside the map bounds can still be metres
// from the door it names. The bounds check proves "on the right map"; only a
// comparison against the game's own doors proves "on the right door". That was
// left as a first-raid eyeball check, and an eyeball check on 34 markers across
// eleven maps is exactly the kind of thing that quietly never happens.
//
// So the module answers it: once per map entry (DEBUG-gated), enumerate
// EFT.Interactive.Door -- the same enumeration DoorsModule uses to unlock them
// -- and report each LockedDoor marker's nearest door and the distance. The
// per-map summary line is the gate: a map where every marker sits within a few
// metres of a door is verified; the worst-case line says where to look.
//
// DEBUG-GATED so the default build pays nothing: the door enumeration plus a
// world position per door is a few hundred managed calls, which is free once
// per raid and not free per frame. With DEBUG off this function's first line
// returns and none of its arguments are built.
// ---------------------------------------------------------------------------
static void verify_static_marker_placement(const std::string& location_id,
                                           const Il2CppClass* game_world_class) {
    if (!logger::debug_enabled() || location_id.empty() || !game_world_class)
        return;

    const std::shared_ptr<const minimap::map_config> cfg = minimap::find_config(location_id);
    if (!cfg)
        return;

    std::size_t door_markers = 0;
    for (const auto& m : cfg->static_markers)
        if (m.category == "LockedDoor")
            ++door_markers;
    if (door_markers == 0)
        return; // nothing this check knows how to verify on this map

    // The game's own door list, via the same type DoorsModule unlocks.
    Il2CppObject* door_type =
        il2utils::get_system_type(game_world_class->image, "EFT.Interactive", "Door");
    if (!door_type) {
        logger::debug("marker-door: map=" + location_id + " doors=UNKNOWN -- EFT.Interactive.Door "
                      "did not resolve; placement unverified this session");
        return;
    }
    size_t door_count = 0;
    Il2CppObject** doors = unity::find_objects_of_type(door_type, &door_count);
    if (!doors || door_count == 0) {
        logger::debug("marker-door: map=" + location_id
                      + " doors=0 -- no Door objects in the scene; placement unverified");
        return;
    }

    struct door_ref {
        unity::vector3 pos{};
        std::string name;
    };
    std::vector<door_ref> door_refs;
    door_refs.reserve(door_count);
    for (size_t i = 0; i < door_count; ++i) {
        Il2CppObject* go = unity::component_get_game_object(doors[i]);
        if (!go)
            continue;
        Il2CppObject* tr = unity::gameobject_get_transform(go);
        if (!tr)
            continue;
        door_refs.push_back({unity::transform_get_pos(tr), unity::get_name(go)});
    }
    if (door_refs.empty()) {
        logger::debug("marker-door: map=" + location_id + " doors=0 -- no door transforms read; "
                      "placement unverified");
        return;
    }

    // Same mapping the draw path uses (read_dynamic_maps_position is the single
    // place it lives), so a disagreement here is a data disagreement and not a
    // convention mismatch between the two paths.
    std::size_t within_2m = 0;
    std::size_t within_5m = 0;
    std::size_t no_door = 0;
    float worst_dist = -1.f;
    std::string worst_text;
    for (const auto& marker : cfg->static_markers) {
        if (marker.category != "LockedDoor")
            continue;
        const unity::vector3 pos{marker.x, marker.y, marker.z};

        float best = 1e30f;
        const door_ref* best_ref = nullptr;
        for (const auto& d : door_refs) {
            const float dx = pos.x - d.pos.x;
            const float dy = pos.y - d.pos.y;
            const float dz = pos.z - d.pos.z;
            const float dist_sq = dx * dx + dy * dy + dz * dz;
            if (dist_sq < best) {
                best = dist_sq;
                best_ref = &d;
            }
        }
        const float dist = sqrtf(best);
        if (dist <= 2.f)
            ++within_2m;
        if (dist <= 5.f)
            ++within_5m;
        if (!best_ref) {
            ++no_door;
            continue;
        }
        if (dist > worst_dist) {
            worst_dist = dist;
            worst_text = marker.text;
        }
        logger::debug("marker-door: map=" + location_id + " '" + marker.text + "' at ("
                      + std::format("{:.0f} {:.0f} {:.0f}", pos.x, pos.y, pos.z) + ") nearest='"
                      + best_ref->name + "' dist=" + std::format("{:.1f}", dist) + "m");
    }

    logger::debug("marker-door: map=" + location_id + " markers=" + std::to_string(door_markers)
                  + " doors=" + std::to_string(door_refs.size()) + " within_2m="
                  + std::to_string(within_2m) + " within_5m=" + std::to_string(within_5m)
                  + " unmatched=" + std::to_string(no_door) + " worst="
                  + std::format("{:.1f}", worst_dist) + "m ('" + worst_text + "')");
}

void EspModule::draw_radar_overlay(ImDrawList *draw_list, const std::vector<EspModule::player> &players,
                                   const std::vector<EspModule::exfil> &exfils,
                                   const std::vector<EspModule::transit> &transits,
                                   const std::vector<quest_esp::poi_entry> &quest_pois,
                                   const std::vector<EspModule::bot_corpse_marker> &bot_corpses,
                                   const float view_yaw) const
{
    const float sf = menu::get_scale_factor();
    const minimap_layout layout = compute_minimap_layout(sf);
    const float size = layout.size;
    const float rx = layout.rx;
    const float ry = layout.ry;
    const float opacity =
        (std::min)(1.f, (std::max)(0.f, minimap_module_self->radar_minimap_opacity->get_value() / 100.f));
    // The range control is hidden. Use a close fixed render radius so
    // map detail fills the overlay instead of the old 400m-wide view.
    constexpr float range = 75.f;
    // Map Display is hidden in the streamlined UI.  Always render the
    // available abstract map instead of inheriting a legacy false value.
    const bool show_map_texture = true;
    const bool rotate = minimap_module_self->radar_minimap_rotate->get_value();
    const bool calibrate = minimap::editor_state().minimap_calibrate;
    const float map_yaw = rotate ? view_yaw : 0.f;
    const float cx = rx + size * 0.5f;
    const float cy = ry + size * 0.5f;
    const float half = size * 0.5f;
    const float radar_scale = half / range;
    const esp_text::minimap_marker_settings &mm = esp_text::minimap_markers();
    const float label_font = esp_text::minimap_label_font_size();

    const minimap::map_floor *floor = nullptr;
    minimap::map_bounds display_bounds{};
    minimap::map_view_transform view{};
    bool use_map = false;

    {
        const int style_idx = minimap_module_self->radar_minimap_style->get_value();
        minimap::set_map_style(style_idx >= 1 ? minimap::map_style::satellite_style
                                              : minimap::map_style::abstract_style);
        minimap::request_active_map(current_location_id);

        uint32_t map_w = 0;
        uint32_t map_h = 0;
        if (minimap::get_active_floor(my_pos.x, my_pos.y, my_pos.z, floor) && minimap::is_map_ready() && floor &&
            minimap::get_active_display_bounds(display_bounds) && minimap::get_map_size(map_w, map_h))
        {
            float player_u = 0.5f;
            float player_v = 0.5f;
            minimap::world_to_uv(display_bounds, my_pos.x, my_pos.z, player_u, player_v);

            if (!minimap_follow_player_ && minimap_has_last_player_pos_ &&
                player_moved_on_map(my_pos, minimap_last_player_pos_))
                minimap_follow_player_ = true;

            if (minimap_follow_player_)
            {
                minimap_center_u_ = player_u;
                minimap_center_v_ = player_v;
            }

            minimap_last_player_pos_ = my_pos;
            minimap_has_last_player_pos_ = true;

            if (minimap::build_map_view(display_bounds, map_w, map_h, rx, ry, size, minimap_center_u_,
                                        minimap_center_v_, range, map_yaw, rotate, view))
            {
                use_map = true;
                handle_radar_window_input(rx, ry, size, &view);
            }
        }
    }

    if (!use_map)
        handle_radar_window_input(rx, ry, size, nullptr);

    // Same call path as the crash, guarded for the same reason: minimap_module_self is a
    // module pointer and radar_minimap_backdrop is a ConfigValue*, so each of these two
    // lines is a double dereference with nothing in front of it. And draw_list is about
    // to be dereferenced immediately below and again inside draw_minimap_grid.
    if (!minimap_module_self || !draw_list)
        return;

    const bool draw_backdrop = minimap_module_self->radar_minimap_backdrop->get_value();
    const ImVec4 backdrop_color = minimap_module_self->radar_minimap_backdrop_color->get_value();

    draw_list->PushClipRect({rx, ry}, {rx + size, ry + size}, true);
    if (draw_backdrop)
    {
        draw_list->AddRectFilled({rx, ry}, {rx + size, ry + size}, col4_alpha(backdrop_color, opacity), 4.f);
    }

    if (use_map && show_map_texture)
        minimap::draw_active_map(draw_list, view, opacity);

    if (minimap_module_self->radar_minimap_grid->get_value())
    {
        const float grid_opacity = opacity * (minimap_module_self->radar_minimap_grid_opacity->get_value() / 100.f);
        draw_minimap_grid(draw_list, use_map && floor, display_bounds, view, map_yaw, cx, cy, range, radar_scale, rx,
                          ry, size, sf, grid_opacity, rotate);
    }

    if (use_map && floor && minimap::editor_show_zone_outlines())
    {
        const minimap::map_editor_state &map_editor = minimap::editor_state();
        minimap::draw_overlay_zone_outlines(draw_list, *floor, view, map_editor.overlay_layers, opacity,
                                            map_editor.selected_overlay);
    }

    constexpr float deg2rad = 3.14159265f / 180.f;
    const float view_yaw_rad = view_yaw * deg2rad;

    if (use_map && floor)
    {
        ImVec2 player_point{};
        if (minimap::world_to_map_point(display_bounds, my_pos.x, my_pos.z, view, player_point))
        {
            float dir_x = sinf(view_yaw_rad);
            float dir_y = -cosf(view_yaw_rad);
            const float ahead_x = my_pos.x + sinf(view_yaw_rad) * 6.f;
            const float ahead_z = my_pos.z + cosf(view_yaw_rad) * 6.f;
            ImVec2 ahead_point{};
            if (minimap::world_to_map_point(display_bounds, ahead_x, ahead_z, view, ahead_point))
            {
                dir_x = ahead_point.x - player_point.x;
                dir_y = ahead_point.y - player_point.y;
            }

            draw_minimap_player_marker(draw_list, player_point, dir_x, dir_y, sf, opacity, rotate);
            if (calibrate)
            {
                char buf[128];
                snprintf(buf, sizeof(buf), "You [%.0f,%.1f,%.0f]", my_pos.x, my_pos.y, my_pos.z);
                draw_radar_marker_label(draw_list, player_point, ImVec4(1.f, 1.f, 1.f, 1.f), buf, label_font, opacity,
                                        0.f, 0.f, 0.f, mm.size_player, 0.f, sf);
            }
        }
    }
    else
    {
        draw_minimap_player_marker(draw_list, {cx, cy}, sinf(view_yaw_rad), -cosf(view_yaw_rad), sf, opacity, rotate);
        if (calibrate)
        {
            char buf[128];
            snprintf(buf, sizeof(buf), "You [%.0f,%.1f,%.0f]", my_pos.x, my_pos.y, my_pos.z);
            draw_radar_marker_label(draw_list, {cx, cy}, ImVec4(1.f, 1.f, 1.f, 1.f), buf, label_font, opacity, 0.f, 0.f,
                                    0.f, mm.size_player, 0.f, sf);
        }
    }

    if (minimap_module_self->radar_minimap_quest_esp->get_value())
    {
        const float max_dist = quest_esp_distance->get_value();
        for (const auto &poi : quest_pois)
        {
            if (my_pos.distance(poi.pos) > max_dist)
                continue;

            const ImVec4 color = quest_poi_color(poi.type);

            ImVec2 point{};
            if (!resolve_minimap_marker_point(use_map && floor, display_bounds, view, poi.pos, map_yaw, cx, cy, range,
                                              radar_scale, rx, ry, size, point))
                continue;

            draw_minimap_symbol_marker(draw_list, point, mm.quest.c_str(), mm.size_quest, opacity, color);
            draw_minimap_height_indicator(draw_list, point, poi.pos.y, my_pos.y, mm.size_quest, mm.quest.c_str(), sf,
                                          color, opacity);

            if (minimap_module_self->radar_minimap_quest_names->get_value() || calibrate)
            {
                char buf[160];
                if (calibrate)
                    snprintf(buf, sizeof(buf), "%s [%.0f,%.0f]", poi.quest_name.c_str(), poi.pos.x, poi.pos.z);
                else
                    snprintf(buf, sizeof(buf), "%s", poi.quest_name.c_str());
                draw_radar_marker_label(draw_list, point, color, buf, label_font, opacity, rx, ry, size, mm.size_quest,
                                        poi.pos.y - my_pos.y, sf);
            }
        }
    }

    if (minimap_module_self->radar_exfils->get_value())
    {
        for (const auto &exfil : exfils)
        {
            ImVec2 point{};
            if (!resolve_minimap_marker_point(use_map && floor, display_bounds, view, exfil.pos3d, map_yaw, cx, cy,
                                              range, radar_scale, rx, ry, size, point))
                continue;

            const ImVec4 color = extracts_color->get_value();
            draw_minimap_symbol_marker(draw_list, point, mm.exfil.c_str(), mm.size_exfil, opacity, color);
            draw_minimap_height_indicator(draw_list, point, exfil.pos3d.y, my_pos.y, mm.size_exfil, mm.exfil.c_str(),
                                          sf, color, opacity);

            std::string label = exfil.name;
            if (calibrate)
            {
                char buf[128];
                snprintf(buf, sizeof(buf), "%s [%.0f,%.0f]", exfil.name.c_str(), exfil.pos3d.x, exfil.pos3d.z);
                label = buf;
            }
            draw_radar_marker_label(draw_list, point, color, label, label_font, opacity, rx, ry, size, mm.size_exfil,
                                    exfil.pos3d.y - my_pos.y, sf);
        }

        for (const auto &transit : transits)
        {
            ImVec2 point{};
            if (!resolve_minimap_marker_point(use_map && floor, display_bounds, view, transit.pos3d, map_yaw, cx, cy,
                                              range, radar_scale, rx, ry, size, point))
                continue;

            const ImVec4 color = transits_color->get_value();
            draw_minimap_symbol_marker(draw_list, point, mm.transit.c_str(), mm.size_transit, opacity, color);
            draw_minimap_height_indicator(draw_list, point, transit.pos3d.y, my_pos.y, mm.size_transit,
                                          mm.transit.c_str(), sf, color, opacity);

            std::string label = transit.name;
            if (calibrate)
            {
                char buf[128];
                snprintf(buf, sizeof(buf), "%s [%.0f,%.0f]", transit.name.c_str(), transit.pos3d.x, transit.pos3d.z);
                label = buf;
            }
            draw_radar_marker_label(draw_list, point, color, label, label_font, opacity, rx, ry, size, mm.size_transit,
                                    transit.pos3d.y - my_pos.y, sf);
        }
    }

    if (minimap_module_self->radar_minimap_bots->get_value())
    {
        for (const auto &p : players)
        {
            ImVec2 point{};
            if (!resolve_minimap_marker_point(use_map && floor, display_bounds, view, p.pos3d, map_yaw, cx, cy, range,
                                              radar_scale, rx, ry, size, point))
                continue;

            const ImVec4 col = p.kind == eft_api::npc_kind::pmc ? player_color->get_value() : get_npc_color(p.kind);
            draw_minimap_symbol_marker(draw_list, point, mm.entity.c_str(), mm.size_entity, opacity, col);
            draw_minimap_height_indicator(draw_list, point, p.pos3d.y, my_pos.y, mm.size_entity, mm.entity.c_str(), sf,
                                          col, opacity);

            if (minimap_module_self->radar_minimap_bot_names->get_value())
            {
                const std::string &name_text = !p.name_utf8.empty() ? p.name_utf8 : p.label_utf8;
                if (!name_text.empty())
                {
                    draw_radar_marker_label(draw_list, point, col, name_text, label_font, opacity, rx, ry, size,
                                            mm.size_entity, p.pos3d.y - my_pos.y, sf);
                }
            }
            else if (calibrate)
            {
                char buf[128];
                snprintf(buf, sizeof(buf), "%s [%.0f,%.0f]", p.name_utf8.c_str(), p.pos3d.x, p.pos3d.z);
                draw_radar_marker_label(draw_list, point, col, buf, label_font, opacity, rx, ry, size, mm.size_entity,
                                        p.pos3d.y - my_pos.y, sf);
            }
        }
    }

    if (minimap_module_self->radar_minimap_bot_corpses->get_value())
    {
        const ImVec4 corpse_col = minimap_module_self->radar_minimap_bot_corpse_color->get_value();
        for (const auto &corpse : bot_corpses)
        {
            ImVec2 point{};
            if (!resolve_minimap_marker_point(use_map && floor, display_bounds, view, corpse.pos3d, map_yaw, cx, cy,
                                              range, radar_scale, rx, ry, size, point))
                continue;

            draw_minimap_symbol_marker(draw_list, point, mm.entity.c_str(), mm.size_entity, opacity, corpse_col);
            draw_minimap_height_indicator(draw_list, point, corpse.pos3d.y, my_pos.y, mm.size_entity, mm.entity.c_str(),
                                          sf, corpse_col, opacity);
        }
    }

    // ---------------------------------------------------------------------------
    // Static markers and labels -- bigmap plan step 5.
    //
    // Both come from the active map's CONFIG, so this is the one radar layer
    // with no live game state behind it and nothing that can desync. That is
    // also why Extracts and Transits are not here: those are read live above,
    // and a static copy would silently disagree with them.
    //
    // find_config returns an OWNING shared_ptr (its own comment explains why),
    // so a map reload on the game thread mid-draw cannot invalidate the vectors
    // being iterated -- the render thread holds the config alive.
    // ---------------------------------------------------------------------------
    if (minimap_module_self->radar_minimap_static_markers->get_value())
    {
        const std::shared_ptr<const minimap::map_config> static_cfg =
            minimap::find_config(current_location_id);
        if (static_cfg)
        {
            for (const auto& marker : static_cfg->static_markers)
            {
                unity::vector3 pos{};
                pos.x = marker.x;
                pos.y = marker.y;
                pos.z = marker.z;

                ImVec2 point{};
                if (!resolve_minimap_marker_point(use_map && floor, display_bounds, view, pos, map_yaw, cx, cy,
                                                  range, radar_scale, rx, ry, size, point))
                    continue;

                const ImVec4 color = static_marker_color(marker.category);
                draw_list->AddCircleFilled(point, (std::max)(1.5f, 2.5f * sf), ImGui::GetColorU32(color), 8);
                // height_dy is the same offset the exfil labels use: it pushes
                // the text down when the marker sits above the player, so a
                // door on another floor reads as "not on my level" rather than
                // as a wrong position.
                draw_radar_marker_label(draw_list, point, color, marker.text, label_font, opacity, rx, ry, size,
                                        0.f, marker.y - my_pos.y, sf);
            }

            if (minimap_module_self->radar_minimap_labels->get_value())
            {
                // Dimmer than a marker label on purpose: place names are context,
                // not state, and at Streets' 46 labels they must not compete with
                // the things that can kill you.
                const ImVec4 name_color = {0.78f, 0.78f, 0.78f, 0.9f * opacity};
                for (const auto& label : static_cfg->labels)
                {
                    unity::vector3 pos{};
                    pos.x = label.x;
                    pos.y = label.y;
                    pos.z = label.z;

                    ImVec2 point{};
                    if (!resolve_minimap_marker_point(use_map && floor, display_bounds, view, pos, map_yaw, cx, cy,
                                                      range, radar_scale, rx, ry, size, point))
                        continue;

                    draw_radar_marker_label(draw_list, point, name_color, label.text, label_font, opacity, rx, ry,
                                            size, 0.f, 0.f, sf);
                }
            }
        }
    }

    draw_list->PopClipRect();

    if (minimap_module_self->radar_minimap_compass->get_value())
    {
        update_compass_anim(view_yaw);
        draw_minimap_compass_frame(draw_list, rx, ry, size, sf, opacity, compass_anim_yaw_, rotate, draw_backdrop,
                                   backdrop_color);
    }
    else
    {
        draw_list->AddRect({rx, ry}, {rx + size, ry + size}, col_alpha(IM_COL32(255, 255, 255, 200), opacity), 4.f);
    }

    const std::string floor_label = use_map ? minimap::get_minimap_floor_label() : std::string();
    const std::string &location_label =
        !current_location_display_name.empty() ? current_location_display_name : current_location_id;
    const std::string &map_status = minimap::get_status_message();
    // Soft bg failures still leave use_map=true; surface the note in the header.
    const bool bg_warn =
        map_status.find("SVG") != std::string::npos || map_status.find("tile") != std::string::npos ||
        map_status.find("Satellite") != std::string::npos || map_status.find("not found") != std::string::npos ||
        map_status.find("unavailable") != std::string::npos || map_status.find("failed") != std::string::npos;
    char label[320];
    if (use_map && calibrate)
    {
        if (bg_warn)
            snprintf(label, sizeof(label), "Entities: %zu | %s | %s | Y:%.1f | Range: %dm | %s", players.size(),
                     location_label.c_str(), floor_label.c_str(), my_pos.y, static_cast<int>(range),
                     map_status.c_str());
        else
            snprintf(label, sizeof(label), "Entities: %zu | %s | %s | Y:%.1f | Range: %dm", players.size(),
                     location_label.c_str(), floor_label.c_str(), my_pos.y, static_cast<int>(range));
    }
    else if (use_map)
    {
        if (bg_warn)
            snprintf(label, sizeof(label), "Entities: %zu | %s | %s | Range: %dm | %s", players.size(),
                     location_label.c_str(), floor_label.c_str(), static_cast<int>(range), map_status.c_str());
        else
            snprintf(label, sizeof(label), "Entities: %zu | %s | %s | Range: %dm", players.size(),
                     location_label.c_str(), floor_label.c_str(), static_cast<int>(range));
    }
    else
    {
        snprintf(label, sizeof(label), "Entities: %zu | Range: %dm | %s", players.size(), static_cast<int>(range),
                 map_status.c_str());
    }

    draw_radar_header_label(draw_list, {rx, minimap_header_label_y(ry, size, 1)}, label, label_font, opacity);
}

// ---------------------------------------------------------------------------
// Big-map markers -- bigmap plan 4.3.
//
// Every line below has a counterpart in draw_radar_overlay, and that is
// deliberate: the two views must not disagree about what an extract looks like,
// how high off the floor a marker is, or which side a label sits on. The only
// things that differ are the ones that CANNOT be shared:
//
//   1. There is no no-map-loaded fallback. The radar can draw entities with no
//      map at all (radially around its centre), which is what resolve_minimap_-
//      marker_point's else-branch is for. MapModule::draw_overlay returns before
//      calling this when no map is loaded, so that path would be dead code here.
//   2. The clip rectangle is the map window, not the radar square. The radar's
//      helpers take a SQUARE clip (rx, ry, clip_size), and the window is square,
//      so the same call shape works -- but the numbers differ and that is the
//      caller's, not ours.
//   3. No distance cull. The radar hides anything past quest_esp_distance
//      because a 75 m window cannot show it usefully; a whole-map view exists
//      precisely to show it, so culling there would make the map lie about what
//      is on it.
// ---------------------------------------------------------------------------
void EspModule::draw_big_map_markers(const big_map_marker_context &ctx, const std::string &location_id) const
{
    if (!ctx.draw_list)
        return;

    const float sf = menu::get_scale_factor();
    const esp_text::minimap_marker_settings &mm = esp_text::minimap_markers();
    const float label_font = esp_text::minimap_label_font_size();
    constexpr float opacity = 1.f;

    // Same shape as the radar's: the map bounds are the clip test, so a marker
    // outside the published map is not drawn at all rather than drawn at a
    // wrapped or clamped position.
    const float clip_rx = ctx.clip_min.x;
    const float clip_ry = ctx.clip_min.y;
    const float clip_size = ctx.clip_max.x - ctx.clip_min.x;

    const auto to_point = [&](const unity::vector3 &pos, ImVec2 &out) {
        float u = 0.f;
        float v = 0.f;
        if (!minimap::world_to_uv(ctx.bounds, pos.x, pos.z, u, v))
            return false;
        if (u < 0.f || u > 1.f || v < 0.f || v > 1.f)
            return false;
        if (!minimap::world_to_map_point(ctx.bounds, pos.x, pos.z, ctx.view, out))
            return false;
        return is_point_inside_minimap(out, clip_rx, clip_ry, clip_size, 2.f);
    };

    const auto draw_label = [&](const ImVec2 &point, const ImVec4 &color, const std::string &text,
                                const float marker_font, const float height_dy) {
        draw_radar_marker_label(ctx.draw_list, point, color, text, label_font, opacity, clip_rx, clip_ry, clip_size,
                                marker_font, height_dy, sf);
    };

    if (ctx.show_quest && quest_poi_store)
    {
        for (const auto &poi : *quest_poi_store)
        {
            ImVec2 point{};
            if (!to_point(poi.pos, point))
                continue;

            const ImVec4 color = quest_poi_color(poi.type);
            draw_minimap_symbol_marker(ctx.draw_list, point, mm.quest.c_str(), mm.size_quest, opacity, color);
            draw_minimap_height_indicator(ctx.draw_list, point, poi.pos.y, ctx.player_pos.y, mm.size_quest,
                                          mm.quest.c_str(), sf, color, opacity);

            if (ctx.show_quest_names)
                draw_label(point, color, poi.quest_name, mm.size_quest, poi.pos.y - ctx.player_pos.y);
        }
    }

    if (ctx.show_exfils)
    {
        const ImVec4 exfil_color = extracts_color->get_value();
        if (exfil_store)
        {
            for (const auto &exfil : *exfil_store)
            {
                ImVec2 point{};
                if (!to_point(exfil.pos3d, point))
                    continue;

                draw_minimap_symbol_marker(ctx.draw_list, point, mm.exfil.c_str(), mm.size_exfil, opacity, exfil_color);
                draw_minimap_height_indicator(ctx.draw_list, point, exfil.pos3d.y, ctx.player_pos.y, mm.size_exfil,
                                              mm.exfil.c_str(), sf, exfil_color, opacity);
                draw_label(point, exfil_color, exfil.name, mm.size_exfil, exfil.pos3d.y - ctx.player_pos.y);
            }
        }

        const ImVec4 transit_color = transits_color->get_value();
        if (transits_store)
        {
            for (const auto &transit : *transits_store)
            {
                ImVec2 point{};
                if (!to_point(transit.pos3d, point))
                    continue;

                draw_minimap_symbol_marker(ctx.draw_list, point, mm.transit.c_str(), mm.size_transit, opacity,
                                           transit_color);
                draw_minimap_height_indicator(ctx.draw_list, point, transit.pos3d.y, ctx.player_pos.y,
                                              mm.size_transit, mm.transit.c_str(), sf, transit_color, opacity);
                draw_label(point, transit_color, transit.name, mm.size_transit, transit.pos3d.y - ctx.player_pos.y);
            }
        }
    }

    if (ctx.show_players && player_store)
    {
        for (const auto &p : *player_store)
        {
            ImVec2 point{};
            if (!to_point(p.pos3d, point))
                continue;

            const ImVec4 col = p.kind == eft_api::npc_kind::pmc ? player_color->get_value() : get_npc_color(p.kind);
            draw_minimap_symbol_marker(ctx.draw_list, point, mm.entity.c_str(), mm.size_entity, opacity, col);
            draw_minimap_height_indicator(ctx.draw_list, point, p.pos3d.y, ctx.player_pos.y, mm.size_entity,
                                          mm.entity.c_str(), sf, col, opacity);

            // The name gate is the same as the radar's: an unlabelled dot is a
            // cleaner map, and the label is the expensive part at map scale.
            if (ctx.show_player_names)
            {
                const std::string &name_text = !p.name_utf8.empty() ? p.name_utf8 : p.label_utf8;
                if (!name_text.empty())
                    draw_label(point, col, name_text, mm.size_entity, p.pos3d.y - ctx.player_pos.y);
            }
        }
    }

    if (ctx.show_corpse && bot_corpse_store_)
    {
        const ImVec4 corpse_col = minimap_module_self ? minimap_module_self->radar_minimap_bot_corpse_color->get_value()
                                                      : ImVec4(0.6f, 0.6f, 0.6f, 1.f);
        for (const auto &corpse : *bot_corpse_store_)
        {
            ImVec2 point{};
            if (!to_point(corpse.pos3d, point))
                continue;

            draw_minimap_symbol_marker(ctx.draw_list, point, mm.entity.c_str(), mm.size_entity, opacity, corpse_col);
            draw_minimap_height_indicator(ctx.draw_list, point, corpse.pos3d.y, ctx.player_pos.y, mm.size_entity,
                                          mm.entity.c_str(), sf, corpse_col, opacity);
        }
    }

    // Static markers and labels come from the map CONFIG, so find_config is the
    // same owning-pointer call the radar makes and the vectors cannot be pulled
    // out from under this loop by a reload on the game thread.
    if ((ctx.show_static_markers || ctx.show_labels) && !location_id.empty())
    {
        const std::shared_ptr<const minimap::map_config> cfg = minimap::find_config(location_id);
        if (cfg)
        {
            if (ctx.show_static_markers)
            {
                for (const auto &marker : cfg->static_markers)
                {
                    unity::vector3 pos{};
                    pos.x = marker.x;
                    pos.y = marker.y;
                    pos.z = marker.z;

                    ImVec2 point{};
                    if (!to_point(pos, point))
                        continue;

                    const ImVec4 color = static_marker_color(marker.category);
                    ctx.draw_list->AddCircleFilled(point, (std::max)(1.5f, 2.5f * sf), ImGui::GetColorU32(color), 8);
                    draw_label(point, color, marker.text, 0.f, marker.y - ctx.player_pos.y);
                }
            }

            if (ctx.show_labels)
            {
                // Dimmer than a marker label for the same reason the radar dims
                // it: place names are context, not state.
                const ImVec4 name_color = {0.78f, 0.78f, 0.78f, 0.9f};
                for (const auto &label : cfg->labels)
                {
                    unity::vector3 pos{};
                    pos.x = label.x;
                    pos.y = label.y;
                    pos.z = label.z;

                    ImVec2 point{};
                    if (!to_point(pos, point))
                        continue;

                    draw_radar_marker_label(ctx.draw_list, point, name_color, label.text, label_font, opacity, clip_rx,
                                            clip_ry, clip_size, 0.f, 0.f, sf);
                }
            }
        }
    }
}

void EspModule::format_price_suffix(char *buf, const size_t buf_size, const int price)
{
    if (price >= 1000)
        snprintf(buf, buf_size, "[%dK]", price / 1000);
    else
        snprintf(buf, buf_size, "(%d \xE2\x82\xBD)", price);
}

bool EspModule::should_show_container_item(const EspModule::container_item_entry &item) const
{
    const bool wants_provisions = show_provisions->get_value();
    if (item.is_provision && !wants_provisions)
        return false;
    if (any_loot_category_filter() && !loot_category_allowed(item.cat, item.wl))
        return false;
    if (!loot_ui_filter_allowed(item.template_id, item.name))
        return false;
    if (item.is_quest)
        return true;
    if (item.is_money)
        return true; // cash always visible (not flea-priced)
    if (!item_pricing::has_prices())
        return true;
    if (item.price <= 0)
        return true;
    return item.price >= loot_min_value->get_value();
}

bool EspModule::should_show_corpse_item(const EspModule::container_item_entry &item) const
{
    if (item.is_provision && !show_provisions->get_value())
        return false;
    if (any_loot_category_filter() && !loot_category_allowed(item.cat, item.wl))
        return false;
    if (!loot_ui_filter_allowed(item.template_id, item.name))
        return false;
    return true;
}

EspModule::container_item_cache *EspModule::find_container_item_cache(const uintptr_t obj_key)
{
    const auto found = container_item_caches_.find(obj_key);
    return found == container_item_caches_.end() ? nullptr : &found->second;
}

std::string EspModule::resolve_localized_item_name(Il2CppObject *item_obj,
                                                   Il2CppString *(*localized_short_name)(Il2CppObject *),
                                                   Il2CppString *(*localized_name)(Il2CppObject *))
{
    if (!eft_api::is_il2cpp_object_strict(item_obj))
        return "item_mod";

    const std::string template_id = eft_api::try_get_item_template_id(item_obj);
    // Pre-calculate cached name for early return, avoiding repeated lookups in loop
    const auto cached_it = template_name_cache_.find(template_id);

    if (!template_id.empty() && cached_it != template_name_cache_.end())
    {
        // Template known — cache resolved name to avoid recomputing.
        // Audit #6: a cache entry that is empty or "item_mod" is a FAILURE
        // marker. Previously the retry branch re-ran the whole resolution on
        // every subsequent occurrence of the same template, forever, because
        // nothing ever recorded that the attempt had already failed. Now a
        // failure is written back as-is (no second operator[] lookup, no
        // self-move-assign through a reference into the same slot) and left
        // alone on later hits.
        std::string &cached_name = cached_it->second;
        if (cached_name.empty() || cached_name == "item_mod")
        {
            std::string resolved = eft_api::try_get_item_localized_name(item_obj, localized_short_name, localized_name);
            if (resolved.empty() || resolved == "item_mod")
                resolved = eft_api::try_get_item_display_name(item_obj);

            // Assign through the existing reference, not a fresh operator[].
            cached_name = std::move(resolved);
        }
        return cached_name;
    }

    // No cache hit — resolve once and store
    std::string name = eft_api::try_get_item_localized_name(item_obj, localized_short_name, localized_name);
    if (name.empty() || name == "item_mod")
        name = eft_api::try_get_item_display_name(item_obj);

    if (!template_id.empty())
    {
        // Assign through the reference and return what was stored -- NOT the
        // moved-from local. `template_name_cache_[template_id] = std::move(name);`
        // followed by `return name;` returned an EMPTY string on every call where
        // the template id is non-empty, because MSVC's STL leaves a moved-from
        // string empty. The symptom was a blank ESP label for every templated item
        // while the cache itself looked perfectly healthy, which is why it
        // survived: clang-tidy bugprone-use-after-move, AGENTS_TODO.md section
        // 5.7ag, "THE REAL BUG". Written to match the cache-hit block above, which
        // already does this correctly.
        std::string &stored = template_name_cache_[template_id];
        stored = std::move(name);
        return stored;
    }

    return name;
}

void EspModule::fill_item_cache_entries(
    EspModule::container_item_cache &entry, Il2CppObject *root_item,
    const std::function<bool(const std::function<bool(Il2CppObject *)> &)> &foreach_items)
{
    entry.items.clear();
    entry.items_ptr.reset();
    entry.cached_item_count = 0;
    entry.total_price = 0;

    if (!eft_api::is_il2cpp_object_strict(root_item))
        return;

    static auto *localization_assembly = il2utils::resolve_image("Assembly-CSharp.dll");
    static auto *localization_class = il2utils::resolve_class(localization_assembly, "EFT", "LocalizationExtensions");
    static auto localized_short_name =
        il2utils::get_method<Il2CppString *(*)(Il2CppObject *)>(localization_class, "LocalizedShortName", 1);
    static auto localized_name =
        il2utils::get_method<Il2CppString *(*)(Il2CppObject *)>(localization_class, "LocalizedName", 1);

    const std::string root_name = resolve_localized_item_name(root_item, localized_short_name, localized_name);
    if (!root_name.empty() && root_name != "item_mod")
        entry.name = root_name;

    std::unordered_map<std::string, size_t> merged_indices;
    int raw_item_count = 0;

    // Cache per-item template names for this refresh to avoid repeated resolve_localized_item_name calls
    std::unordered_map<Il2CppObject *, std::string> item_name_cache_;

    foreach_items([&](Il2CppObject *item_obj) -> bool {
        if (!eft_api::is_inventory_item_valid(item_obj))
            return true;

        const int stack_count = eft_api::try_get_item_stack_count(item_obj);
        const int stack_max = eft_api::try_get_item_stack_max(item_obj);
        const bool is_money = eft_api::try_get_item_is_money(item_obj);
        // Old cap stack_count > 100 dropped cash stacks (RUB often 500–50000).
        if (!is_money && (stack_count > stack_max || stack_count > 100))
            return true;
        if (is_money && stack_count <= 0)
            return true;

        // Use cached name if available — only resolve once per item for this frame
        std::string cached_name;
        auto cache_it = item_name_cache_.find(item_obj);
        if (cache_it != item_name_cache_.end())
            cached_name = cache_it->second;

        if (!cached_name.empty())
        {
            cached_name = resolve_localized_item_name(item_obj, localized_short_name, localized_name);
            // Cache the result for this frame
            item_name_cache_[item_obj] = cached_name;
        }

        ++raw_item_count;

        const std::string template_id = eft_api::try_get_item_template_id(item_obj);
        // QuestItem template flag + active-quest membership: loot whose quest
        // is completed/never-started is bogus — the game keeps the loot object
        // in the world but hides/ignores it, so SKIP the entry entirely
        // (demoting to a regular item still lists something ungrabable).
        const bool quest_flagged = eft_api::try_get_item_is_quest(item_obj);
        if (quest_flagged && !template_id.empty() && !eft_api::is_active_quest_item_id(template_id))
            return true;
        const bool is_quest = quest_flagged;
        const bool is_provision = eft_api::try_get_item_is_provision(item_obj);
        int add_count = 1;
        if (stack_count > 1)
            add_count += stack_count - 1;

        // Money: resolve_item_sell_price = face*stack (full stack). Other items: unit flea price.
        int line_price = item_pricing::resolve_item_sell_price(item_obj, template_id);
        if (!is_money && line_price > 0 && add_count > 1)
            line_price *= add_count;

        const auto found = merged_indices.find(template_id);
        if (!template_id.empty() && found != merged_indices.end())
        {
            auto &existing = entry.items[found->second];
            existing.count += add_count;
            existing.price += line_price;
            entry.total_price += line_price;
            return true;
        }

        container_item_entry loot_item{};
        if (!cached_name.empty())
            loot_item.name = cached_name;
        else
        {
            // Inline name resolution to avoid extra function call overhead
            std::string inline_name = resolve_localized_item_name(item_obj, localized_short_name, localized_name);
            if (!inline_name.empty())
                loot_item.name = inline_name;
        }
        loot_item.count = add_count;
        loot_item.price = line_price;
        loot_item.is_quest = is_quest;
        loot_item.is_provision = is_provision;
        loot_item.is_money = is_money;
        loot_item.template_id = template_id;
        loot_item.cat = classify_template(template_id);
        loot_item.wl = item_categories::classify_group(template_id, wishlist_sets_);

        if (!template_id.empty())
            merged_indices.emplace(template_id, entry.items.size());

        entry.total_price += loot_item.price;
        entry.items.push_back(std::move(loot_item));
        return true;
    });

    entry.cached_item_count = raw_item_count;
    entry.items_ptr = std::make_shared<std::vector<container_item_entry>>(entry.items);
}

void EspModule::refresh_container_item_cache(EspModule::container_item_cache &entry, Il2CppObject *container_obj)
{
    entry.last_refresh = GetTickCount64();

    if (!eft_api::is_il2cpp_object_strict(container_obj))
        return;
    if (!eft_api::is_container_object_alive(container_obj))
        return;
    if (!eft_api::is_lootable_container_valid(container_obj))
        return;

    Il2CppObject *item_owner = eft_api::try_get_container_item_owner(container_obj);
    Il2CppObject *root_item = eft_api::try_get_controller_root_item(item_owner);
    if (!eft_api::is_il2cpp_object_strict(root_item))
        return;

    fill_item_cache_entries(entry, root_item,
                            [&](const auto &visitor) { return eft_api::foreach_container_item(root_item, visitor); });
}

void EspModule::refresh_corpse_item_cache(EspModule::container_item_cache &entry, Il2CppObject *inventory_root)
{
    if (!eft_api::is_corpse_lootable_inventory(inventory_root))
        return;

    fill_item_cache_entries(entry, inventory_root, [&](const auto &visitor) {
        return eft_api::foreach_corpse_lootable_item(inventory_root, visitor);
    });
    entry.last_refresh = GetTickCount64();
}

EspModule::container_item_cache *EspModule::find_corpse_item_cache(const uintptr_t obj_key)
{
    const auto found = corpse_item_caches_.find(obj_key);
    return found == corpse_item_caches_.end() ? nullptr : &found->second;
}

// Both of these were byte-identical apart from the entry TYPE -- same four
// guards, same field writes, same return. The template above is the body; these
// are the two names the call sites already use, kept so the API does not move.
bool EspModule::update_container_registry_position(EspModule::container_registry_entry &entry)
{
    return update_registry_position(entry);
}

std::string EspModule::colocation_key(const unity::vector3 &pos)
{
    constexpr float cell = 0.25f; // 25 cm — drawers / cash registers share origin
    const int x = static_cast<int>(std::floor(pos.x / cell + (pos.x >= 0.f ? 0.5f : -0.5f)));
    const int y = static_cast<int>(std::floor(pos.y / cell + (pos.y >= 0.f ? 0.5f : -0.5f)));
    const int z = static_cast<int>(std::floor(pos.z / cell + (pos.z >= 0.f ? 0.5f : -0.5f)));
    char buf[64];
    snprintf(buf, sizeof(buf), "%d|%d|%d", x, y, z);
    return buf;
}

void EspModule::merge_colocated_container_markers(std::vector<EspModule::loot_entry> &markers)
{
    if (markers.size() < 2)
        return;

    std::unordered_map<std::string, std::vector<size_t>> groups;
    groups.reserve(markers.size());
    for (size_t i = 0; i < markers.size(); ++i)
        groups[colocation_key(markers[i].pos3d)].push_back(i);

    std::vector<loot_entry> out;
    out.reserve(markers.size());
    std::vector<char> used(markers.size(), 0);

    for (size_t i = 0; i < markers.size(); ++i)
    {
        if (used[i])
            continue;
        auto &indices = groups[colocation_key(markers[i].pos3d)];
        if (indices.size() < 2)
        {
            out.push_back(std::move(markers[i]));
            used[i] = 1;
            continue;
        }

        std::sort(indices.begin(), indices.end(), [&](const size_t a, const size_t b) {
            const int cmp = markers[a].name.compare(markers[b].name);
            if (cmp != 0)
                return cmp < 0;
            return a < b;
        });

        loot_entry merged = markers[indices.front()];
        // Keep exact shared origin (first) — no Y fan that multiplies sway on screen.
        std::string name = merged.name;
        // Deduplicate display names
        std::unordered_set<std::string> seen;
        seen.insert(name);
        for (size_t s = 1; s < indices.size(); ++s)
        {
            const std::string &n = markers[indices[s]].name;
            if (seen.insert(n).second)
            {
                name += " / ";
                name += n;
            }
        }
        if (indices.size() > 1)
        {
            name += " (x";
            name += std::to_string(indices.size());
            name += ")";
        }
        merged.name = std::move(name);
        out.push_back(std::move(merged));
        for (const size_t idx : indices)
            used[idx] = 1;
    }

    markers = std::move(out);
}

void EspModule::merge_colocated_container_lists(std::vector<EspModule::container_esp_entry> &list)
{
    if (list.size() < 2)
        return;

    std::unordered_map<std::string, std::vector<size_t>> groups;
    groups.reserve(list.size());
    for (size_t i = 0; i < list.size(); ++i)
        groups[colocation_key(list[i].pos3d)].push_back(i);

    std::vector<container_esp_entry> out;
    out.reserve(list.size());
    std::vector<char> used(list.size(), 0);

    for (size_t i = 0; i < list.size(); ++i)
    {
        if (used[i])
            continue;
        auto &indices = groups[colocation_key(list[i].pos3d)];
        if (indices.size() < 2)
        {
            out.push_back(std::move(list[i]));
            used[i] = 1;
            continue;
        }

        std::sort(indices.begin(), indices.end(), [&](const size_t a, const size_t b) {
            const int cmp = list[a].container_name.compare(list[b].container_name);
            if (cmp != 0)
                return cmp < 0;
            return a < b;
        });

        container_esp_entry merged = list[indices.front()];
        std::string name = merged.container_name;
        std::unordered_set<std::string> seen_names;
        seen_names.insert(name);

        std::vector<container_item_entry> items;
        if (merged.items)
            items = *merged.items;
        int total = merged.total_price;

        for (size_t s = 1; s < indices.size(); ++s)
        {
            const auto &other = list[indices[s]];
            if (seen_names.insert(other.container_name).second)
            {
                name += " / ";
                name += other.container_name;
            }
            total += other.total_price;
            if (other.items)
            {
                for (const auto &it : *other.items)
                    items.push_back(it);
            }
        }
        name += " (x";
        name += std::to_string(indices.size());
        name += ")";
        merged.container_name = std::move(name);
        merged.total_price = total;
        if (!items.empty())
            merged.items = std::make_shared<const std::vector<container_item_entry>>(std::move(items));
        out.push_back(std::move(merged));
        for (const size_t idx : indices)
            used[idx] = 1;
    }

    list = std::move(out);
}

bool EspModule::show_esp_distance_labels()
{
    return !game_state::esp_manual_refresh_mode;
}

void EspModule::refresh_container_registry_distances(const unity::vector3 &player_pos, const float min_dist_sq,
                                                     const float max_dist_sq)
{
    for (auto &entry : container_registry_)
    {
        if (!entry.has_pos)
            continue;

        const float dx = player_pos.x - entry.pos3d.x;
        const float dy = player_pos.y - entry.pos3d.y;
        const float dz = player_pos.z - entry.pos3d.z;
        entry.dist_sq = dx * dx + dy * dy + dz * dz;
        entry.distance = sqrtf(entry.dist_sq);
        entry.in_range = entry.dist_sq >= min_dist_sq && entry.dist_sq <= max_dist_sq;
    }
}

bool EspModule::update_corpse_registry_position(EspModule::corpse_registry_entry &entry)
{
    return update_registry_position(entry);
}

bool EspModule::is_active_thrown_grenade(Il2CppObject *obj)
{
    if (!obj || !obj->klass || !obj->klass->name)
        return false;

    const char *cls = obj->klass->name;
    if (strstr(cls, "Flare") != nullptr)
        return false;
    if (strstr(cls, "Grenade") == nullptr)
        return false;

    Il2CppObjectInstance inst(obj);
    if (!inst.get_field<bool>("_live"))
        return false;
    if (inst.get_field<bool>("_isDestroyed"))
        return false;

    if (const FieldInfo *planted_field = il2utils::resolve_field(obj->klass, "_isPlantedItem"))
    {
        const bool planted = *reinterpret_cast<bool *>(reinterpret_cast<uintptr_t>(obj) + planted_field->offset);
        if (planted)
            return false;
    }

    return true;
}

float EspModule::try_get_grenade_fuse_remaining(Il2CppObject *grenade_obj)
{
    if (!grenade_obj)
        return -1.f;

    Il2CppObjectInstance grenade_inst(grenade_obj);
    const auto get_weapon = grenade_inst.get_method<Il2CppObject *(*)(Il2CppObject *)>("get_WeaponSource", 0);
    if (!get_weapon)
        return -1.f;

    Il2CppObject *weapon = get_weapon(grenade_obj);
    if (!weapon)
        return -1.f;

    Il2CppObjectInstance weapon_inst(weapon);
    const auto get_delay = weapon_inst.get_method<float (*)(Il2CppObject *)>("get_GetExplDelay", 0);
    if (!get_delay)
        return -1.f;

    const float expl_delay = get_delay(weapon);
    if (expl_delay <= 0.f)
        return -1.f;

    const FieldInfo *time_field = il2utils::resolve_field(grenade_obj->klass, "_timeSpent");
    if (!time_field)
        return -1.f;

    const float time_spent = *reinterpret_cast<float *>(reinterpret_cast<uintptr_t>(grenade_obj) + time_field->offset);
    return (std::max)(0.f, expl_delay - time_spent);
}

std::string EspModule::resolve_grenade_label(Il2CppObject *grenade_obj,
                                             Il2CppString *(*localized_short_name)(Il2CppObject *))
{
    if (!grenade_obj)
        return i18n::tr("grenade_lbl");

    Il2CppObjectInstance grenade_inst(grenade_obj);
    const auto get_weapon = grenade_inst.get_method<Il2CppObject *(*)(Il2CppObject *)>("get_WeaponSource", 0);
    Il2CppObject *weapon = get_weapon ? get_weapon(grenade_obj) : nullptr;

    if (weapon && localized_short_name)
    {
        Il2CppString *name_str = localized_short_name(weapon);
        if (name_str)
        {
            std::string name = eft_api::to_display_utf8(il2utils::conv_wstring(name_str));
            if (!name.empty())
                return name;
        }
    }

    if (const FieldInfo *ammo_field = il2utils::resolve_field(grenade_obj->klass, "_grenadeAmmo"))
    {
        Il2CppObject *ammo =
            *reinterpret_cast<Il2CppObject **>(reinterpret_cast<uintptr_t>(grenade_obj) + ammo_field->offset);
        if (ammo && localized_short_name)
        {
            Il2CppString *name_str = localized_short_name(ammo);
            if (name_str)
            {
                std::string name = eft_api::to_display_utf8(il2utils::conv_wstring(name_str));
                if (!name.empty())
                    return name;
            }
        }
    }

    return i18n::tr("grenade_lbl");
}

void EspModule::scan_grenade_esp(Il2CppObjectInstance &game_world_instance, const unity::vector3 &player_pos,
                                 std::vector<EspModule::grenade_entry> &out_grenades)
{
    Il2CppObject *grenades_hydra_obj = game_world_instance.get_field<Il2CppObject *>("Grenades");
    if (!grenades_hydra_obj)
        return;

    Il2CppObjectInstance grenades_hydra(grenades_hydra_obj);
    unity::list *grenade_list = grenades_hydra.get_field<unity::list *>("_iteration");
    if (!grenade_list || !grenade_list->m_p_list_array)
        return;

    static auto *assembly_csharp = il2utils::resolve_image("Assembly-CSharp.dll");
    static auto *localization_extensions_class =
        il2utils::resolve_class(assembly_csharp, "EFT", "LocalizationExtensions");
    static auto localized_short_name =
        il2utils::get_method<Il2CppString *(*)(Il2CppObject *)>(localization_extensions_class, "LocalizedShortName", 1);

    Il2CppArray *grenade_array = grenade_list->m_p_list_array;
    const int count = static_cast<int>(grenade_array->max_length);
    out_grenades.reserve(static_cast<size_t>(count));

    const float max_dist = grenade_esp_distance->get_value();
    const float max_dist_sq = max_dist * max_dist;

    for (int i = 0; i < count; ++i)
    {
        Il2CppObject *grenade_obj = reinterpret_cast<Il2CppObject **>(&grenade_array->data)[i];
        if (!is_active_thrown_grenade(grenade_obj))
            continue;

        Il2CppObject *game_object = unity::component_get_game_object(grenade_obj);
        if (!game_object)
            continue;
        Il2CppObject *transform = unity::gameobject_get_transform(game_object);
        if (!transform)
            continue;

        const unity::vector3 pos = unity::transform_get_pos(transform);
        const float dx = player_pos.x - pos.x;
        const float dy = player_pos.y - pos.y;
        const float dz = player_pos.z - pos.z;
        const float dist_sq = dx * dx + dy * dy + dz * dz;
        if (dist_sq > max_dist_sq)
            continue;

        grenade_entry entry;
        entry.label = resolve_grenade_label(grenade_obj, localized_short_name);
        entry.pos3d = pos;
        entry.distance = sqrtf(dist_sq);
        entry.fuse_remaining = try_get_grenade_fuse_remaining(grenade_obj);
        out_grenades.push_back(std::move(entry));
    }
}

void EspModule::for_each_il2cpp_list(Il2CppObject *list_obj, const std::function<void(Il2CppObject *)> &fn)
{
    if (!eft_api::is_il2cpp_object_likely_valid(list_obj) || !list_obj->klass)
        return;

    Il2CppArray *items = nullptr;
    int size = -1;
    if (FieldInfo *items_f = il2utils::resolve_field(list_obj->klass, "_items"))
    {
        if (items_f->offset > 0)
            items = *reinterpret_cast<Il2CppArray **>(reinterpret_cast<uintptr_t>(list_obj) + items_f->offset);
    }
    if (!items)
    {
        // Fallback to our unity::list layout (items at first managed field).
        auto *ul = reinterpret_cast<unity::list *>(list_obj);
        items = ul->m_p_list_array;
    }
    if (!items)
        return;

    if (FieldInfo *size_f = il2utils::resolve_field(list_obj->klass, "_size"))
    {
        if (size_f->offset > 0)
            size = *reinterpret_cast<int *>(reinterpret_cast<uintptr_t>(list_obj) + size_f->offset);
    }
    int count = size >= 0 ? size : static_cast<int>(items->max_length);
    if (count < 0)
        count = 0;
    if (count > static_cast<int>(items->max_length))
        count = static_cast<int>(items->max_length);
    if (count > 512)
        count = 512;

    for (int i = 0; i < count; ++i)
    {
        Il2CppObject *el = reinterpret_cast<Il2CppObject **>(&items->data)[i];
        if (eft_api::is_il2cpp_object_likely_valid(el) && el->klass)
            fn(el);
    }
}

bool EspModule::try_tripwire_world_pos(Il2CppObject *obj, unity::vector3 &out)
{
    if (!obj || !obj->klass)
        return false;

    // Prefer planted wire endpoints (TripwireSynchronizableObject).
    Il2CppObjectInstance tw(obj);
    if (const auto get_from = tw.get_method<unity::vector3 (*)(Il2CppObject *)>("get_FromPosition", 0, false))
    {
        if (const auto get_to = tw.get_method<unity::vector3 (*)(Il2CppObject *)>("get_ToPosition", 0, false))
        {
            const unity::vector3 a = get_from(obj);
            const unity::vector3 b = get_to(obj);
            const float span = std::fabs(a.x - b.x) + std::fabs(a.y - b.y) + std::fabs(a.z - b.z);
            if (span > 0.05f)
            {
                out = {(a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f + 0.15f, (a.z + b.z) * 0.5f};
                return true;
            }
        }
    }

    // Stakes / line mesh often sit at better positions than the root (0,0,0).
    if (FieldInfo *line_f = il2utils::resolve_field(obj->klass, "_line"))
    {
        if (line_f->offset > 0)
        {
            Il2CppObject *line = *reinterpret_cast<Il2CppObject **>(reinterpret_cast<uintptr_t>(obj) + line_f->offset);
            if (eft_api::is_il2cpp_object_likely_valid(line))
            {
                if (Il2CppObject *go = unity::component_get_game_object(line))
                {
                    if (Il2CppObject *tr = unity::gameobject_get_transform(go))
                    {
                        out = unity::transform_get_pos(tr);
                        if (std::fabs(out.x) + std::fabs(out.z) > 0.01f)
                            return true;
                    }
                }
            }
        }
    }

    Il2CppObject *go = unity::component_get_game_object(obj);
    if (!go)
        return false;
    Il2CppObject *tr = unity::gameobject_get_transform(go);
    if (!tr)
        return false;
    out = unity::transform_get_pos(tr);
    return true;
}

void EspModule::scan_tripwire_esp(Il2CppObjectInstance &game_world_instance, const unity::vector3 &player_pos,
                                  std::vector<EspModule::tripwire_entry> &out_tripwires)
{
    out_tripwires.clear();
    if (!game_world_instance.get_instance())
        return;

    Il2CppObject *processor = nullptr;
    if (const auto get_p = game_world_instance.get_method<Il2CppObject *(*)(Il2CppObject *)>(
            "get_SynchronizableObjectLogicProcessor", 0, false))
        processor = get_p(game_world_instance.get_instance());
    if (!eft_api::is_il2cpp_object_likely_valid(processor) || !processor->klass)
    {
        processor = game_world_instance.get_field<Il2CppObject *>("SynchronizableObjectLogicProcessor");
        if (!eft_api::is_il2cpp_object_likely_valid(processor))
            processor =
                game_world_instance.get_field<Il2CppObject *>("<SynchronizableObjectLogicProcessor>k__BackingField");
    }
    if (!eft_api::is_il2cpp_object_likely_valid(processor) || !processor->klass)
        return;

    const float max_dist = grenade_esp_distance->get_value();
    const float max_dist_sq = max_dist * max_dist;
    constexpr int k_tripwire_type = 2; // SynchronizableObjectType.Tripwire

    std::unordered_set<uintptr_t> seen;
    seen.reserve(32);
    out_tripwires.reserve(16);

    auto consider = [&](Il2CppObject *obj, const bool trust_tripwire_type) {
        if (!eft_api::is_il2cpp_object_likely_valid(obj) || !obj->klass)
            return;
        const uintptr_t key = reinterpret_cast<uintptr_t>(obj);
        if (seen.count(key))
            return;

        if (!trust_tripwire_type)
        {
            int type_val = -1;
            // Walk klass chain — Type lives on SynchronizableObject base.
            for (Il2CppClass *k = obj->klass; k; k = k->parent)
            {
                if (FieldInfo *tf = il2utils::resolve_field(k, "Type"))
                {
                    if (tf->offset > 0)
                    {
                        type_val = *reinterpret_cast<int *>(reinterpret_cast<uintptr_t>(obj) + tf->offset);
                        break;
                    }
                }
            }
            // Also accept objects whose class name contains Tripwire.
            bool name_ok = false;
            if (obj->klass->name && strstr(obj->klass->name, "Tripwire"))
                name_ok = true;
            if (type_val != k_tripwire_type && !name_ok)
                return;
        }

        // Skip clearly inactive / not inited when flags exist.
        for (Il2CppClass *k = obj->klass; k; k = k->parent)
        {
            if (FieldInfo *af = il2utils::resolve_field(k, "IsActive"))
            {
                if (af->offset > 0 && !*reinterpret_cast<bool *>(reinterpret_cast<uintptr_t>(obj) + af->offset))
                {
                    // Still show if inited/static — planted wires may flip IsActive.
                }
                break;
            }
        }

        unity::vector3 pos{};
        if (!try_tripwire_world_pos(obj, pos))
            return;

        const float dx = player_pos.x - pos.x;
        const float dy = player_pos.y - pos.y;
        const float dz = player_pos.z - pos.z;
        const float dist_sq = dx * dx + dy * dy + dz * dz;
        if (dist_sq > max_dist_sq)
            return;

        seen.insert(key);
        tripwire_entry e;
        e.pos3d = pos;
        e.distance = sqrtf(dist_sq);
        out_tripwires.push_back(e);
    };

    // 1) Authoritative planted list: TripwireManager._tripwires
    Il2CppObject *trip_mgr = nullptr;
    if (FieldInfo *tm_f = il2utils::resolve_field(processor->klass, "TripwireManager"))
    {
        if (tm_f->offset > 0)
            trip_mgr = *reinterpret_cast<Il2CppObject **>(reinterpret_cast<uintptr_t>(processor) + tm_f->offset);
    }
    if (eft_api::is_il2cpp_object_likely_valid(trip_mgr) && trip_mgr->klass)
    {
        Il2CppObject *tw_list = nullptr;
        if (FieldInfo *lf = il2utils::resolve_field(trip_mgr->klass, "_tripwires"))
        {
            if (lf->offset > 0)
                tw_list = *reinterpret_cast<Il2CppObject **>(reinterpret_cast<uintptr_t>(trip_mgr) + lf->offset);
        }
        for_each_il2cpp_list(tw_list, [&](Il2CppObject *el) { consider(el, /*trust_tripwire_type=*/true); });
    }

    // 2) Both processor lists (planted wires often leave active → static)
    for (const char *list_name : {"_activeSynchronizableObjects", "_staticSynchronizableObjects"})
    {
        Il2CppObject *list_obj = nullptr;
        if (FieldInfo *f = il2utils::resolve_field(processor->klass, list_name))
        {
            if (f->offset > 0)
                list_obj = *reinterpret_cast<Il2CppObject **>(reinterpret_cast<uintptr_t>(processor) + f->offset);
        }
        for_each_il2cpp_list(list_obj, [&](Il2CppObject *el) { consider(el, /*trust_tripwire_type=*/false); });
    }
}

std::string EspModule::read_il2cpp_string_field(Il2CppObject *obj, const char *field_name)
{
    if (!obj || !obj->klass || !field_name)
        return {};
    for (Il2CppClass *k = obj->klass; k; k = k->parent)
    {
        if (FieldInfo *f = il2utils::resolve_field(k, field_name))
        {
            if (f->offset <= 0)
                continue;
            Il2CppString *s = *reinterpret_cast<Il2CppString **>(reinterpret_cast<uintptr_t>(obj) + f->offset);
            if (!s)
                return {};
            return eft_api::try_read_il2cpp_string(s);
        }
    }
    return {};
}

bool EspModule::looks_like_door_code(const std::string &id)
{
    if (id.empty() || id.size() > 12)
        return false;
    // Pure numeric codes (dorms 481516, etc.) and short alnum codes.
    bool any_digit = false;
    for (unsigned char c : id)
    {
        if (std::isdigit(c))
        {
            any_digit = true;
            continue;
        }
        if (std::isalpha(c))
            continue;
        return false;
    }
    // 24-hex mongo ids never fit size <= 12; codes are typically 4–8 chars.
    return any_digit && !quest_esp::is_pure_template_id(id);
}

std::string EspModule::lookup_item_db_name(const std::string &template_id)
{
    if (template_id.empty())
        return {};
    std::string name = game_items::name_by_id(template_id);
    return name.empty() ? template_id : name;
}

std::string EspModule::resolve_key_requirement_name(const std::string &key_id)
{
    if (key_id.empty())
        return {};

    // Door code: show the digits as-is.
    if (looks_like_door_code(key_id))
        return key_id;

    const std::string normalized =
        quest_esp::is_pure_template_id(key_id) ? quest_esp::normalize_template_id(key_id) : key_id;

    const auto cached = template_name_cache_.find(normalized);
    if (cached != template_name_cache_.end() && !cached->second.empty())
        return cached->second;

    std::string name;
    if (quest_esp::is_pure_template_id(normalized))
    {
        name = quest_esp::resolve_template_display_name(normalized);
        if (name.empty())
            name = lookup_item_db_name(normalized);
        if (name.empty())
        {
            // Localization keys often live as "<id> Name" / "Name/<id>".
            if (const std::string loc = eft_api::try_localize_with_suffix(normalized, "Name");
                eft_api::is_plausible_localized_result(normalized, loc))
                name = loc;
        }
    }

    if (name.empty())
        name = key_id;

    template_name_cache_[normalized] = name;
    return name;
}

void EspModule::collect_string_array_ids(Il2CppArray *arr, std::vector<std::string> &out)
{
    if (!arr || arr->max_length <= 0)
        return;
    auto **strings = reinterpret_cast<Il2CppString **>(&arr->data);
    for (il2cpp_array_size_t i = 0; i < arr->max_length; ++i)
    {
        if (!strings[i])
            continue;
        std::string s = eft_api::try_read_il2cpp_string(strings[i]);
        if (!s.empty())
            out.push_back(std::move(s));
    }
}

void EspModule::collect_card_reader_key_ids(Il2CppObject *reader, std::vector<std::string> &out)
{
    if (!reader || !reader->klass)
        return;
    FieldInfo *map_f = il2utils::resolve_field(reader->klass, "_keyMap");
    if (!map_f || map_f->offset <= 0)
        return;

    Il2CppArray *arr = *reinterpret_cast<Il2CppArray **>(reinterpret_cast<uintptr_t>(reader) + map_f->offset);
    if (!arr || arr->max_length <= 0)
        return;

    constexpr size_t k_pair_stride = 0x18;
    auto *base = reinterpret_cast<uint8_t *>(&arr->data);
    for (il2cpp_array_size_t i = 0; i < arr->max_length; ++i)
    {
        uint8_t *el = base + static_cast<size_t>(i) * k_pair_stride;
        Il2CppString *key_str = *reinterpret_cast<Il2CppString **>(el + 0);
        if (!key_str)
            continue;
        std::string s = eft_api::try_read_il2cpp_string(key_str);
        if (!s.empty())
            out.push_back(std::move(s));
    }
}

bool EspModule::try_component_world_pos(Il2CppObject *component, unity::vector3 &out)
{
    if (!component)
        return false;
    Il2CppObject *go = unity::component_get_game_object(component);
    if (!go)
        return false;
    Il2CppObject *tr = unity::gameobject_get_transform(go);
    if (!tr)
        return false;
    out = unity::transform_get_pos(tr);
    return std::fabs(out.x) + std::fabs(out.y) + std::fabs(out.z) > 0.001f;
}

void EspModule::collect_panel_positions(Il2CppObject *wio, std::vector<unity::vector3> &out_pos)
{
    out_pos.clear();
    if (!wio || !wio->klass)
        return;

    for (const char *fname : {"Proxies", "_proxies"})
    {
        FieldInfo *pf = nullptr;
        for (Il2CppClass *k = wio->klass; k && !pf; k = k->parent)
            pf = il2utils::resolve_field(k, fname);
        if (!pf || pf->offset <= 0)
            continue;

        Il2CppArray *arr = *reinterpret_cast<Il2CppArray **>(reinterpret_cast<uintptr_t>(wio) + pf->offset);
        if (!arr || arr->max_length <= 0)
            continue;

        auto **proxies = reinterpret_cast<Il2CppObject **>(&arr->data);
        for (il2cpp_array_size_t i = 0; i < arr->max_length; ++i)
        {
            Il2CppObject *proxy = proxies[i];
            if (!eft_api::is_il2cpp_object_likely_valid(proxy))
                continue;
            unity::vector3 pos{};
            if (try_component_world_pos(proxy, pos))
                out_pos.push_back(pos);
        }
        if (!out_pos.empty())
            return;
    }

    unity::vector3 pos{};
    if (try_component_world_pos(wio, pos))
        out_pos.push_back(pos);
}

void EspModule::consider_key_interactive(Il2CppObject *obj, std::unordered_set<uintptr_t> &seen_objs,
                                         std::vector<EspModule::keypanel_entry> &out)
{
    if (!eft_api::is_il2cpp_object_likely_valid(obj) || !obj->klass)
        return;
    const uintptr_t key = reinterpret_cast<uintptr_t>(obj);
    if (seen_objs.count(key))
        return;

    std::vector<std::string> key_ids;
    key_ids.reserve(4);

    const std::string primary = read_il2cpp_string_field(obj, "KeyId");
    if (!primary.empty())
        key_ids.push_back(primary);

    // KeycardDoor extras
    for (Il2CppClass *k = obj->klass; k; k = k->parent)
    {
        if (FieldInfo *f = il2utils::resolve_field(k, "_additionalKeys"))
        {
            if (f->offset > 0)
            {
                Il2CppArray *arr = *reinterpret_cast<Il2CppArray **>(reinterpret_cast<uintptr_t>(obj) + f->offset);
                collect_string_array_ids(arr, key_ids);
            }
            break;
        }
    }

    // CardReader map
    if (obj->klass->name && strstr(obj->klass->name, "CardReader"))
        collect_card_reader_key_ids(obj, key_ids);

    if (key_ids.empty())
        return;

    // Dedup key ids while preserving order
    {
        std::unordered_set<std::string> seen_ids;
        std::vector<std::string> unique;
        unique.reserve(key_ids.size());
        for (auto &id : key_ids)
        {
            if (seen_ids.insert(id).second)
                unique.push_back(std::move(id));
        }
        key_ids = std::move(unique);
    }

    bool any_code = false;
    bool any_key = false;
    std::string label;
    for (const auto &id : key_ids)
    {
        const bool is_code = looks_like_door_code(id);
        any_code = any_code || is_code;
        any_key = any_key || !is_code;
        const std::string part = resolve_key_requirement_name(id);
        if (part.empty())
            continue;
        if (!label.empty())
            label += " / ";
        label += part;
    }
    if (label.empty())
        return;

    std::vector<unity::vector3> positions;
    collect_panel_positions(obj, positions);
    if (positions.empty())
        return;

    seen_objs.insert(key);
    // Keep every panel (open or closed). Distance is applied only when drawing.
    for (const auto &pos : positions)
    {
        keypanel_entry e;
        e.label = label;
        e.pos3d = pos;
        e.distance = 0.f;
        e.is_code = any_code && !any_key;
        out.push_back(std::move(e));
    }
}

void EspModule::collect_string_string_dict(Il2CppObject *dict_obj, std::unordered_map<std::string, std::string> &out)
{
    if (!eft_api::is_il2cpp_object_likely_valid(dict_obj))
        return;
    auto *d = reinterpret_cast<unity::dict<Il2CppString *, Il2CppString *> *>(dict_obj);
    if (!d || !d->m_p_entries || d->m_p_entries->max_length == 0)
        return;

    const int n = static_cast<int>(d->m_p_entries->max_length);
    auto *entries = d->get_entry();
    if (!entries)
        return;

    for (int i = 0; i < n; ++i)
    {
        if (entries[i].m_i_hash_code < 0)
            continue;
        const std::string key = eft_api::try_read_il2cpp_string(entries[i].m_t_key);
        const std::string val = eft_api::try_read_il2cpp_string(entries[i].m_t_value);
        if (key.empty() || val.empty())
            continue;
        out[key] = val;
    }
}

Il2CppObject *EspModule::resolve_passcode_controller(Il2CppObjectInstance &game_world_instance)
{
    if (!game_world_instance.get_instance())
        return nullptr;

    // GameWorld.PasscodeController (property backing field).
    if (Il2CppObject *pc = game_world_instance.get_field<Il2CppObject *>("<PasscodeController>k__BackingField"))
    {
        if (eft_api::is_il2cpp_object_likely_valid(pc))
            return pc;
    }
    if (Il2CppObject *pc = game_world_instance.get_field<Il2CppObject *>("PasscodeController"))
    {
        if (eft_api::is_il2cpp_object_likely_valid(pc))
            return pc;
    }
    if (const auto get_pc =
            game_world_instance.get_method<Il2CppObject *(*)(Il2CppObject *)>("get_PasscodeController", 0, false))
    {
        Il2CppObject *pc = get_pc(game_world_instance.get_instance());
        if (eft_api::is_il2cpp_object_likely_valid(pc))
            return pc;
    }

    // ClientPasscodeController.Exist(out controller)
    static const Il2CppImage *assembly = il2utils::resolve_image("Assembly-CSharp.dll");
    if (!assembly)
        return nullptr;
    static const Il2CppClass *cls = il2utils::resolve_class(assembly, "EFT.Passcodes", "ClientPasscodeController");
    if (!cls)
        return nullptr;
    using exist_fn = bool (*)(Il2CppObject **);
    static auto exist = il2utils::get_method<exist_fn>(cls, "Exist", 1);
    if (!exist)
        return nullptr;

    Il2CppObject *out_ctrl = nullptr;
    if (!exist(&out_ctrl) || !eft_api::is_il2cpp_object_likely_valid(out_ctrl))
        return nullptr;
    return out_ctrl;
}

void EspModule::build_generated_passcode_map(Il2CppObject *controller,
                                             std::unordered_map<std::string, std::string> &out)
{
    out.clear();
    if (!eft_api::is_il2cpp_object_likely_valid(controller) || !controller->klass)
        return;

    // ClientLocalPasscodeController._generatedPasscodes (Dictionary<string,string>).
    // Walk class hierarchy — field only on local controller, not network base.
    for (Il2CppClass *k = controller->klass; k; k = k->parent)
    {
        if (FieldInfo *f = il2utils::resolve_field(k, "_generatedPasscodes"))
        {
            if (f->offset > 0)
            {
                Il2CppObject *dict =
                    *reinterpret_cast<Il2CppObject **>(reinterpret_cast<uintptr_t>(controller) + f->offset);
                collect_string_string_dict(dict, out);
            }
            break;
        }
    }
}

void EspModule::foreach_passcode_terminal_from_controller(Il2CppObject *controller,
                                                          const std::function<void(Il2CppObject *)> &fn)
{
    if (!eft_api::is_il2cpp_object_likely_valid(controller) || !controller->klass || !fn)
        return;

    Il2CppObject *dict_obj = nullptr;
    for (Il2CppClass *k = controller->klass; k; k = k->parent)
    {
        if (FieldInfo *f = il2utils::resolve_field(k, "_passcodeTerminals"))
        {
            if (f->offset > 0)
                dict_obj = *reinterpret_cast<Il2CppObject **>(reinterpret_cast<uintptr_t>(controller) + f->offset);
            break;
        }
    }
    if (!eft_api::is_il2cpp_object_likely_valid(dict_obj))
        return;

    // Dictionary<string, List<PasscodeTerminal>>
    auto *d = reinterpret_cast<unity::dict<Il2CppString *, Il2CppObject *> *>(dict_obj);
    if (!d || !d->m_p_entries || d->m_p_entries->max_length == 0)
        return;

    const int n = static_cast<int>(d->m_p_entries->max_length);
    auto *entries = d->get_entry();
    if (!entries)
        return;

    for (int i = 0; i < n; ++i)
    {
        if (entries[i].m_i_hash_code < 0)
            continue;
        Il2CppObject *list_obj = entries[i].m_t_value;
        if (!eft_api::is_il2cpp_object_likely_valid(list_obj))
            continue;

        // List<T>: _items / m_p_list_array
        Il2CppArray *arr = nullptr;
        if (FieldInfo *items_f = il2utils::resolve_field(list_obj->klass, "_items"))
        {
            if (items_f->offset > 0)
                arr = *reinterpret_cast<Il2CppArray **>(reinterpret_cast<uintptr_t>(list_obj) + items_f->offset);
        }
        if (!arr)
        {
            auto *as_list = reinterpret_cast<unity::list *>(list_obj);
            arr = as_list->m_p_list_array;
        }
        if (!arr || arr->max_length <= 0)
            continue;

        int size = static_cast<int>(arr->max_length);
        if (FieldInfo *size_f = il2utils::resolve_field(list_obj->klass, "_size"))
        {
            if (size_f->offset > 0)
            {
                const int s = *reinterpret_cast<int *>(reinterpret_cast<uintptr_t>(list_obj) + size_f->offset);
                if (s >= 0 && s < size)
                    size = s;
            }
        }

        auto **items = reinterpret_cast<Il2CppObject **>(&arr->data);
        for (int j = 0; j < size; ++j)
        {
            if (eft_api::is_il2cpp_object_likely_valid(items[j]))
                fn(items[j]);
        }
    }
}

void EspModule::consider_passcode_terminal(Il2CppObject *terminal,
                                           const std::unordered_map<std::string, std::string> &passcodes,
                                           std::unordered_set<uintptr_t> &seen_objs,
                                           std::vector<EspModule::keypanel_entry> &out)
{
    if (!eft_api::is_il2cpp_object_likely_valid(terminal) || !terminal->klass)
        return;
    const uintptr_t key = reinterpret_cast<uintptr_t>(terminal);
    if (seen_objs.count(key))
        return;

    std::string passcode_id = read_il2cpp_string_field(terminal, "_passcodeId");
    if (passcode_id.empty())
    {
        Il2CppObjectInstance term(terminal);
        if (const auto get_id = term.get_method<Il2CppString *(*)(Il2CppObject *)>("get_PasscodeId", 0, false))
            passcode_id = eft_api::try_read_il2cpp_string(get_id(terminal));
    }
    if (passcode_id.empty())
        return;

    std::string code;
    if (const auto it = passcodes.find(passcode_id); it != passcodes.end())
        code = it->second;

    // Prefer real generated code; keep passcode_id for late resolve if codes not ready yet.
    std::string label = !code.empty() ? code : passcode_id;

    unity::vector3 pos{};
    if (!try_component_world_pos(terminal, pos))
        return;

    seen_objs.insert(key);
    keypanel_entry e;
    e.label = std::move(label);
    e.passcode_id = std::move(passcode_id);
    e.pos3d = pos;
    e.distance = 0.f;
    e.is_code = true;
    out.push_back(std::move(e));
}

void EspModule::refresh_passcode_labels(Il2CppObjectInstance &game_world_instance)
{
    // CALLER MUST HOLD data_mutex. See the note at the call site.
    //
    // 2026-10-01. This function locked data_mutex itself, at the old lines 3200
    // and 3234, while its only caller already held it (old line 5261). std::mutex
    // is not recursive, so that is a self-deadlock -- and on MSVC it is a THROW,
    // not a hang, because the standard requires lock() to raise
    // std::system_error when the calling thread already owns the mutex.
    //
    // That is what killed the game at 09:01 on 2026-10-01. The crash probe named
    // the type directly -- ".?AVsystem_error@std@@" -- thrown 5900+ times on the
    // game's update thread, in a chain of hk_game_world_update ->
    // ModuleManager::apply -> refresh_passcode_labels. The frames are in
    // TarkovAddons/Workstream_status_2026-09-24.md, 2026-10-01 entry.
    //
    // The lock is the CALLER's to take, because the caller needs the critical
    // section to span both the read and the write-back: taking it only around
    // each individual access would let the render thread observe a snapshot and
    // a published vector that disagree about which pass produced them.
    //
    // Copy-on-write. The published snapshot is const and the render thread may
    // be iterating it right now, so labels are applied to a private copy which
    // is then published back. Mutating the shared vector in place was a second
    // race in this file, independent of the pointer escape.
    //
    // The snapshot is copied under the lock the caller already holds. That copy
    // is the point of the shared_ptr: it keeps the vector alive after the lock
    // is dropped, so the expensive work below runs unlocked.
    std::shared_ptr<const std::vector<keypanel_entry>> snapshot = keypanel_store;
    if (snapshot->empty())
        return;

    bool any_pending = false;
    for (const auto &e : *snapshot)
    {
        if (!e.passcode_id.empty() && (e.label == e.passcode_id || e.label.empty()))
        {
            any_pending = true;
            break;
        }
    }
    if (!any_pending)
        return;

    Il2CppObject *controller = resolve_passcode_controller(game_world_instance);
    if (!controller)
        return;

    std::unordered_map<std::string, std::string> passcodes;
    build_generated_passcode_map(controller, passcodes);
    if (passcodes.empty())
        return;

    auto labelled = std::make_shared<std::vector<keypanel_entry>>(*snapshot);
    for (auto &e : *labelled)
    {
        if (e.passcode_id.empty())
            continue;
        const auto it = passcodes.find(e.passcode_id);
        if (it == passcodes.end() || it->second.empty())
            continue;
        e.label = it->second;
        e.is_code = true;
    }
    // Publish under the caller's lock -- no second acquisition. See the header
    // note: this function no longer locks data_mutex itself.
    keypanel_store = std::move(labelled);
}

void EspModule::scan_passcode_terminals(Il2CppObjectInstance &game_world_instance, std::unordered_set<uintptr_t> &seen,
                                        std::vector<EspModule::keypanel_entry> &out_panels)
{
    Il2CppObject *controller = resolve_passcode_controller(game_world_instance);
    std::unordered_map<std::string, std::string> passcodes;
    if (controller)
        build_generated_passcode_map(controller, passcodes);

    // Prefer controller registry (already discovered terminals) — no FindObjectsOfType.
    if (controller)
    {
        foreach_passcode_terminal_from_controller(
            controller, [&](Il2CppObject *term) { consider_passcode_terminal(term, passcodes, seen, out_panels); });
    }

    // Fallback: scene search if controller list empty / not ready yet.
    if (out_panels.empty() || passcodes.empty())
    {
        static const Il2CppImage *assembly = il2utils::resolve_image("Assembly-CSharp.dll");
        if (!assembly)
            return;
        Il2CppObject *type = il2utils::get_system_type(assembly, "EFT.Passcodes", "PasscodeTerminal");
        if (!type)
            return;
        size_t found = 0;
        Il2CppObject **objects = unity::find_objects_of_type(type, &found);
        if (!objects || found == 0)
            return;
        for (size_t i = 0; i < found; ++i)
            consider_passcode_terminal(objects[i], passcodes, seen, out_panels);
    }
}

void EspModule::scan_keypanel_esp(Il2CppObjectInstance &game_world_instance,
                                  std::vector<EspModule::keypanel_entry> &out_panels)
{
    out_panels.clear();

    static const Il2CppImage *assembly = il2utils::resolve_image("Assembly-CSharp.dll");
    if (!assembly)
        return;

    std::unordered_set<uintptr_t> seen;
    seen.reserve(64);
    out_panels.reserve(32);

    auto scan_type = [&](const char *ns, const char *name) {
        Il2CppObject *type = il2utils::get_system_type(assembly, ns, name);
        if (!type)
            return;
        size_t found = 0;
        Il2CppObject **objects = unity::find_objects_of_type(type, &found);
        if (!objects || found == 0)
            return;
        for (size_t i = 0; i < found; ++i)
            consider_key_interactive(objects[i], seen, out_panels);
    };

    // Door includes KeycardDoor (subclass). CardReader is separate (WIO base).
    scan_type("EFT.Interactive", "Door");
    scan_type("EFT.Interactive", "KeycardDoor");
    scan_type("EFT.Interactive", "CardReader");

    // Modern keypad locks (Ground Zero / Terminal / etc.) — PasscodeTerminal.
    scan_passcode_terminals(game_world_instance, seen, out_panels);
}

void EspModule::refresh_corpse_registry_distances(const unity::vector3 &player_pos, const float min_dist_sq,
                                                  const float max_dist_sq)
{
    for (auto &entry : corpse_registry_)
    {
        if (!entry.has_pos)
            continue;

        const float dx = player_pos.x - entry.pos3d.x;
        const float dy = player_pos.y - entry.pos3d.y;
        const float dz = player_pos.z - entry.pos3d.z;
        entry.dist_sq = dx * dx + dy * dy + dz * dz;
        entry.distance = sqrtf(entry.dist_sq);
        entry.in_range = entry.dist_sq >= min_dist_sq && entry.dist_sq <= max_dist_sq;
    }
}

void EspModule::scan_corpse_registry(Il2CppObjectInstance &game_world_instance, const unity::vector3 &player_pos,
                                     const float min_dist_sq, const float max_dist_sq)
{
    Il2CppObject *loot_hydra_obj = game_world_instance.get_field<Il2CppObject *>("LootItems");
    if (!loot_hydra_obj)
        return;

    Il2CppObjectInstance loot_hydra(loot_hydra_obj);
    unity::list *loot_list = loot_hydra.get_field<unity::list *>("_iteration");
    if (!loot_list || !loot_list->m_p_list_array)
        return;

    Il2CppArray *loot_array = loot_list->m_p_list_array;
    const int count = static_cast<int>(loot_array->max_length);

    std::unordered_map<uintptr_t, corpse_registry_entry> existing;
    existing.reserve(corpse_registry_.size());
    for (auto &entry : corpse_registry_)
        existing.emplace(entry.obj_key, std::move(entry));

    std::vector<corpse_registry_entry> merged;
    merged.reserve(16);

    for (int i = 0; i < count; ++i)
    {
        Il2CppObject *loot_obj = reinterpret_cast<Il2CppObject **>(&loot_array->data)[i];
        if (!loot_obj || !eft_api::class_name_contains(loot_obj, "Corpse"))
            continue;

        Il2CppObject *game_object = unity::component_get_game_object(loot_obj);
        if (!game_object)
            continue;
        Il2CppObject *transform = unity::gameobject_get_transform(game_object);
        if (!transform)
            continue;

        unity::vector3 pos = unity::transform_get_pos(transform);
        const float dx = player_pos.x - pos.x;
        const float dy = player_pos.y - pos.y;
        const float dz = player_pos.z - pos.z;
        const float dist_sq = dx * dx + dy * dy + dz * dz;
        if (dist_sq < min_dist_sq || dist_sq > max_dist_sq)
            continue;

        Il2CppObjectInstance loot_instance(loot_obj);
        Il2CppObject *item_obj = loot_instance.get_field<Il2CppObject *>("_item");
        if (!item_obj)
            continue;

        Il2CppObject *inventory_root = eft_api::try_resolve_corpse_inventory_root(loot_obj, item_obj);
        if (!inventory_root)
            continue;

        const uintptr_t obj_key = reinterpret_cast<uintptr_t>(loot_obj);
        const auto prev = existing.find(obj_key);
        if (prev != existing.end())
        {
            corpse_registry_entry entry = std::move(prev->second);
            existing.erase(prev);
            entry.inventory_root = inventory_root;
            entry.pos3d = pos;
            entry.has_pos = true;
            entry.dist_sq = dist_sq;
            entry.distance = sqrtf(dist_sq);
            entry.in_range = true;
            merged.push_back(std::move(entry));
            continue;
        }

        merged.push_back({obj_key, inventory_root, "Corpse", pos, sqrtf(dist_sq), dist_sq, true, true});
    }

    corpse_registry_ = std::move(merged);
    refresh_corpse_registry_distances(player_pos, min_dist_sq, max_dist_sq);
}

void EspModule::update_corpse_loot_esp(Il2CppObjectInstance &game_world_instance,
                                       std::vector<EspModule::container_esp_entry> &out_corpses, bool &store_dirty,
                                       const bool force_full_refresh)
{
    const ULONGLONG now = GetTickCount64();
    constexpr ULONGLONG corpse_tick_interval_ms = 150;
    constexpr ULONGLONG corpse_scan_interval_ms = 500;
    constexpr int max_corpse_refreshes_per_tick = 1;
    constexpr ULONGLONG corpse_refresh_interval_ms = 5000;
    constexpr size_t max_tracked_corpses = 16;

    if (!force_full_refresh && now - corpse_last_tick_ms_ < corpse_tick_interval_ms)
        return;
    corpse_last_tick_ms_ = now;

    const float loot_min = loot_min_distance->get_value();
    const float min_dist_sq = loot_min * loot_min;
    const float max_dist = loot_distance->get_value();
    const float max_dist_sq = max_dist * max_dist;

    if (force_full_refresh || now - corpse_last_scan_ms_ >= corpse_scan_interval_ms || corpse_registry_.empty())
    {
        scan_corpse_registry(game_world_instance, my_pos, min_dist_sq, max_dist_sq);
        corpse_last_scan_ms_ = now;

        std::unordered_set<uintptr_t> live_keys;
        live_keys.reserve(corpse_registry_.size());
        for (const auto &entry : corpse_registry_)
            live_keys.insert(entry.obj_key);

        for (auto it = corpse_item_caches_.begin(); it != corpse_item_caches_.end();)
        {
            if (live_keys.find(it->first) == live_keys.end())
                it = corpse_item_caches_.erase(it);
            else
                ++it;
        }
    }
    else
    {
        for (auto &entry : corpse_registry_)
            update_corpse_registry_position(entry);
        refresh_corpse_registry_distances(my_pos, min_dist_sq, max_dist_sq);
    }

    std::vector<corpse_registry_entry *> nearby;
    nearby.reserve(corpse_registry_.size());
    for (auto &entry : corpse_registry_)
    {
        if (entry.in_range)
            nearby.push_back(&entry);
    }

    if (nearby.size() > max_tracked_corpses)
    {
        std::partial_sort(
            nearby.begin(), nearby.begin() + static_cast<std::ptrdiff_t>(max_tracked_corpses), nearby.end(),
            [](const corpse_registry_entry *a, const corpse_registry_entry *b) { return a->dist_sq < b->dist_sq; });
        nearby.resize(max_tracked_corpses);
    }

    if (!nearby.empty())
    {
        if (force_full_refresh)
        {
            // Manual refresh: rebuild inventory for every nearby corpse in one press.
            for (corpse_registry_entry *reg_ptr : nearby)
            {
                corpse_registry_entry &reg = *reg_ptr;
                if (!eft_api::is_il2cpp_object_strict(reg.inventory_root))
                    continue;
                container_item_cache &cache = corpse_item_caches_[reg.obj_key];
                cache.obj_key = reg.obj_key;
                if (cache.name.empty())
                    cache.name = reg.name;
                refresh_corpse_item_cache(cache, reg.inventory_root);
            }
        }
        else
        {
            int refreshed = 0;
            for (size_t n = 0; n < nearby.size() && refreshed < max_corpse_refreshes_per_tick; ++n)
            {
                const size_t idx = (corpse_loot_refresh_cursor_ + n) % nearby.size();
                corpse_registry_entry &reg = *nearby[idx];
                if (!eft_api::is_il2cpp_object_strict(reg.inventory_root))
                    continue;

                container_item_cache &cache = corpse_item_caches_[reg.obj_key];
                cache.obj_key = reg.obj_key;
                if (cache.name.empty())
                    cache.name = reg.name;

                const bool needs_items = !cache.items_ptr || cache.items_ptr->empty();
                const bool stale = cache.last_refresh == 0 || now - cache.last_refresh >= corpse_refresh_interval_ms;
                if (!stale && !needs_items)
                    continue;

                refresh_corpse_item_cache(cache, reg.inventory_root);
                ++refreshed;
            }
            corpse_loot_refresh_cursor_ = (corpse_loot_refresh_cursor_ + 1) % nearby.size();
        }
    }

    out_corpses.clear();
    out_corpses.reserve(nearby.size());
    for (const corpse_registry_entry *reg : nearby)
    {
        container_esp_entry visible{};
        visible.container_name = reg->name;
        visible.pos3d = reg->pos3d;
        visible.distance = reg->distance;

        if (container_item_cache *cache_ptr = find_corpse_item_cache(reg->obj_key))
        {
            visible.total_price = cache_ptr->total_price;
            visible.items = cache_ptr->items_ptr;
            if (!cache_ptr->name.empty())
                visible.container_name = cache_ptr->name;
        }

        if (any_loot_category_filter())
        {
            bool any_match = false;
            if (visible.items)
            {
                for (const auto &it : *visible.items)
                {
                    if (should_show_corpse_item(it))
                    {
                        any_match = true;
                        break;
                    }
                }
            }
            if (!any_match)
                continue;
        }

        out_corpses.push_back(std::move(visible));
    }

    store_dirty = true;
}

void EspModule::draw_inventory_list_entry(ImDrawList *draw_list, Il2CppObject *cam,
                                          const EspModule::container_esp_entry &entry, char *text_buf,
                                          const size_t text_buf_size, const ImVec4 &header_color,
                                          const bool show_total_price, const bool show_item_prices,
                                          const bool corpse_list, const float screen_y_offset) const
{
    const float sf = menu::get_scale_factor();
    ImFont *hud_font = menu::get_hud_font();
    const float hud_font_size = esp_text::esp_font_size();
    const float line_h = esp_text::text_size(hud_font, hud_font_size, "Ay").y + 2.f * menu::get_scale_factor();
    const float line_w = 2.f * sf;
    const float text_gap = 4.f * sf;
    const float initial_y_offset = line_h + 4.f * sf;
    const float line_x = 10.f * sf;

    std::vector<const container_item_entry *> visible_items;
    if (entry.items)
    {
        visible_items.reserve(entry.items->size());
        for (const auto &item : *entry.items)
        {
            const bool visible = corpse_list ? should_show_corpse_item(item) : should_show_container_item(item);
            if (visible)
                visible_items.push_back(&item);
        }
    }

    unity::vector3 screen_pos = eft_api::world_to_screen(cam, entry.pos3d, game_state::esp_draw_zoom);
    if (!eft_api::is_visible(screen_pos))
        return;
    screen_pos.y += screen_y_offset;

    const int distance_m = static_cast<int>(entry.distance);
    const bool show_dist = show_esp_distance_labels();
    const float sort_dist = show_dist ? entry.distance : 0.f;

    if (visible_items.empty())
    {
        if (show_dist)
            snprintf(text_buf, text_buf_size, "[%dm] %s", distance_m, entry.container_name.c_str());
        else
            snprintf(text_buf, text_buf_size, "%s", entry.container_name.c_str());
        esp_text::draw_simple(draw_list, hud_font, hud_font_size, ImVec2(screen_pos.x, screen_pos.y), header_color,
                              text_buf, sort_dist);
        return;
    }

    const ImVec2 anchor = {screen_pos.x, screen_pos.y};
    const float bar_top = anchor.y - initial_y_offset;
    const float bar_height = static_cast<float>(visible_items.size()) * line_h + line_h * 0.5f;
    const float bar_left = anchor.x - line_x;
    const float text_right = bar_left - line_w - text_gap;

    draw_list->AddRectFilled({bar_left, bar_top}, {bar_left + line_w, bar_top + bar_height},
                             IM_COL32(255, 220, 0, 220));

    if (show_total_price && entry.total_price > 0)
    {
        char price_suffix[32]{};
        format_price_suffix(price_suffix, sizeof(price_suffix), entry.total_price);
        if (show_dist)
            snprintf(text_buf, text_buf_size, "[%dm] %s %s", distance_m, entry.container_name.c_str(), price_suffix);
        else
            snprintf(text_buf, text_buf_size, "%s %s", entry.container_name.c_str(), price_suffix);
    }
    else if (show_dist)
    {
        snprintf(text_buf, text_buf_size, "[%dm] %s", distance_m, entry.container_name.c_str());
    }
    else
    {
        snprintf(text_buf, text_buf_size, "%s", entry.container_name.c_str());
    }

    {
        const ImVec2 header_size = esp_text::text_size(hud_font, hud_font_size, text_buf);
        esp_text::draw_simple_topleft(draw_list, hud_font, hud_font_size,
                                      {text_right - header_size.x, bar_top - line_h}, header_color, text_buf,
                                      sort_dist);
    }

    float item_y = bar_top;
    for (const container_item_entry *item : visible_items)
    {
        const ImVec4 item_color = color_for_loot_price(item->price, item->is_quest, item->is_provision);

        if (show_item_prices && item->price > 0)
        {
            char price_suffix[32]{};
            format_price_suffix(price_suffix, sizeof(price_suffix), item->price);

            if (item->count > 1)
            {
                snprintf(text_buf, text_buf_size, "%s %s (%d)", item->name.c_str(), price_suffix, item->count);
            }
            else
            {
                snprintf(text_buf, text_buf_size, "%s %s", item->name.c_str(), price_suffix);
            }
        }
        else if (item->count > 1)
        {
            snprintf(text_buf, text_buf_size, "%s (%d)", item->name.c_str(), item->count);
        }
        else
        {
            snprintf(text_buf, text_buf_size, "%s", item->name.c_str());
        }

        const ImVec2 item_size = esp_text::text_size(hud_font, hud_font_size, text_buf);
        esp_text::draw_simple_topleft(draw_list, hud_font, hud_font_size, {text_right - item_size.x, item_y},
                                      item_color, text_buf, entry.distance);
        item_y += line_h;
    }
}

void EspModule::draw_container_entry(ImDrawList *draw_list, Il2CppObject *cam,
                                     const EspModule::container_esp_entry &entry, char *text_buf,
                                     const size_t text_buf_size, const float screen_y_offset) const
{
    const bool show_prices = container_show_value->get_value();
    draw_inventory_list_entry(draw_list, cam, entry, text_buf, text_buf_size, container_color->get_value(), show_prices,
                              show_prices, false, screen_y_offset);
}

void EspModule::draw_corpse_entry(ImDrawList *draw_list, Il2CppObject *cam, const EspModule::container_esp_entry &entry,
                                  char *text_buf, const size_t text_buf_size) const
{
    const bool show_prices = show_loot_prices->get_value();
    draw_inventory_list_entry(draw_list, cam, entry, text_buf, text_buf_size, loot_color->get_value(), show_prices,
                              show_prices, true);
}

ImVec4 EspModule::quest_poi_color(const quest_esp::poi_type type) const
{
    switch (type)
    {
    case quest_esp::poi_type::visit:
        return quest_visit_color->get_value();
    case quest_esp::poi_type::find:
        return quest_find_color->get_value();
    case quest_esp::poi_type::place:
        return quest_place_color->get_value();
    }
    return quest_visit_color->get_value();
}

std::string EspModule::quest_poi_group_key(const unity::vector3 &pos, const std::string &name)
{
    char buf[320];
    snprintf(buf, sizeof(buf), "%d|%d|%d|%s", static_cast<int>(pos.x * 10.f), static_cast<int>(pos.y * 10.f),
             static_cast<int>(pos.z * 10.f), name.c_str());
    return buf;
}

void EspModule::draw_quest_esp_overlay(ImDrawList *draw_list, Il2CppObject *cam,
                                       const std::vector<quest_esp::poi_entry> &pois, char *text_buf,
                                       const size_t text_buf_size) const
{
    if (!quest_esp_enabled->get_value())
        return;

    const float max_dist = quest_esp_distance->get_value();
    const float font = esp_text::quest_esp_font_size();
    ImFont *hud_font = menu::get_hud_font();

    std::unordered_map<std::string, std::vector<const quest_esp::poi_entry *>> groups;
    groups.reserve(pois.size());

    for (const auto &poi : pois)
    {
        const float live_dist = my_pos.distance(poi.pos);
        if (live_dist > max_dist)
            continue;
        groups[quest_poi_group_key(poi.pos, poi.quest_name)].push_back(&poi);
    }

    for (const auto &[key, group] : groups)
    {
        (void)key;
        if (group.empty())
            continue;

        const quest_esp::poi_entry &anchor_poi = *group.front();
        unity::vector3 screen_pos = eft_api::world_to_screen(cam, anchor_poi.pos, game_state::esp_draw_zoom);
        if (!eft_api::is_visible(screen_pos))
            continue;

        const float live_dist = my_pos.distance(anchor_poi.pos);
        if (show_esp_distance_labels())
            snprintf(text_buf, text_buf_size, "[QUEST] [%dm] %s", static_cast<int>(live_dist),
                     anchor_poi.quest_name.c_str());
        else
            snprintf(text_buf, text_buf_size, "[QUEST] %s", anchor_poi.quest_name.c_str());

        esp_text::draw_simple(draw_list, hud_font, font, {screen_pos.x, screen_pos.y}, quest_poi_color(anchor_poi.type),
                              text_buf, show_esp_distance_labels() ? live_dist : 0.f);

        // Descriptions pre-filled on game thread (fill_poi_descriptions). Draw is string-only —
        // never call IL2CPP from ImGui/present (caused Runtime abort when Descriptions ON).
        if (quest_esp_descriptions->get_value())
        {
            std::vector<std::string> descriptions;
            descriptions.reserve(group.size());
            for (const quest_esp::poi_entry *poi : group)
            {
                if (!poi || poi->description.empty())
                    continue;

                const auto duplicate = std::find(descriptions.begin(), descriptions.end(), poi->description);
                if (duplicate != descriptions.end())
                    continue;

                descriptions.push_back(poi->description);
            }

            if (!descriptions.empty())
            {
                const float sf = menu::get_scale_factor();
                const float desc_font = font * 0.85f;
                const ImVec4 desc_color = {0.92f, 0.92f, 0.92f, 0.88f};
                float line_y = screen_pos.y + esp_text::text_size(hud_font, font, text_buf).y + 2.f * sf;

                for (const std::string &description : descriptions)
                {
                    esp_text::draw_simple(draw_list, hud_font, desc_font, {screen_pos.x, line_y}, desc_color,
                                          description, live_dist);
                    line_y += esp_text::text_size(hud_font, desc_font, description).y + 1.f * sf;
                }
            }
        }
    }
}

// Shared by the Loot Teleporter card.  These deliberately use the selected
// controls even when the corresponding ESP-only toggle is off.
//
// The predicate itself now lives in item_categories::matches_teleport_filter,
// because LootTeleportModule had a verbatim copy of this switch and the two had
// already drifted: the copy there had been moved onto the class taxonomy, this one
// was still delegating to the substring category_allows. What stays here is the
// part that genuinely is per-module -- which ConfigValues to read, and the lazy
// wishlist refresh, which needs a live Il2CppObject*.
//
// Deliberate difference from the ESP draw path below: this filter picks ONE
// option, so each option decides alone -- option 2 asks category OR wishlist,
// never "is this the selected item too". loot_ui_filter_allowed has two
// independent checkboxes and applies the "selected items only" gate BEFORE the
// category gate, so with both on it shows only the selected item if it is in the
// category. Different UI shape, different answer; not a drift.
bool EspModule::matches_loot_teleport_filter(const int filter, const std::string &template_id, std::string name,
                                             const bool is_quest, Il2CppObject *local_player)
{
    (void)name; // the shared predicate does not match on the display name

    if (filter == 2 && local_player && !wishlist_sets_.ready)
    {
        Il2CppObjectInstance player(local_player);
        const auto get_profile = player.get_method<Il2CppObject *(*)(Il2CppObject *)>("get_Profile", 0);
        if (get_profile)
            ensure_wishlist_sets(get_profile(local_player));
    }

    const std::string selected = loot_selected_item->get_selected_id();
    item_categories::teleport_filter_input in;
    in.is_quest = is_quest;
    in.wishlist = classify_template(template_id);
    // The group and the user's selection, so the shared predicate can answer "is this in
    // the wishlist group I picked" rather than only "is this on the wishlist at all".
    in.wl_group = item_categories::classify_group(template_id, wishlist_sets_);
    in.wl_mask = wishlist_mask();
    in.category_kind = game_items::loot_kind_by_id(template_id);
    in.category = loot_category_filter->get_value();
    in.selected_id = selected.c_str();
    if (loot_selected_item->is_multi())
        in.selected_ids = loot_selected_item->get_matched_ids();
    in.template_id = template_id.c_str();
    return item_categories::matches_teleport_filter(filter, in);
}

void EspModule::export_exfil_coords()
{
    if (!game_state::is_in_raid)
    {
        logger::warn("Export exfils: enter a raid first.");
        return;
    }

    std::vector<exfil> local_exfils;
    std::vector<transit> local_transits;
    unity::vector3 player_pos{};
    std::string location = current_location_id;

    {
        std::lock_guard<std::mutex> lock(data_mutex);
        local_exfils = *exfil_store;
        local_transits = *transits_store;
        player_pos = my_pos;
        if (location.empty())
            location = current_location_id;
    }

    if (local_exfils.empty() && local_transits.empty())
    {
        logger::warn("Export exfils: no data yet. Enable Extracts & Transits and wait ~1s in raid.");
        return;
    }

    using json = nlohmann::json;
    json root;
    root["location"] = location.empty() ? "unknown" : location;
    root["player"] = json::array({player_pos.x, player_pos.y, player_pos.z});

    json exfils_json = json::array();

    for (const auto &exfil : local_exfils)
    {
        exfils_json.push_back(
            {{"name", exfil.name}, {"world", json::array({exfil.pos3d.x, exfil.pos3d.z})}, {"y", exfil.pos3d.y}});

        logger::debug("Exfil '" + exfil.name + "' world=[" + std::to_string(static_cast<int>(exfil.pos3d.x)) + "," +
                      std::to_string(static_cast<int>(exfil.pos3d.z)) +
                      "] y=" + std::to_string(static_cast<int>(exfil.pos3d.y)));
    }

    json transits_json = json::array();
    for (const auto &transit : local_transits)
    {
        transits_json.push_back({{"name", transit.name},
                                 {"world", json::array({transit.pos3d.x, transit.pos3d.z})},
                                 {"y", transit.pos3d.y}});
        logger::debug("Transit '" + transit.name + "' world=[" + std::to_string(static_cast<int>(transit.pos3d.x)) +
                      "," + std::to_string(static_cast<int>(transit.pos3d.z)) + "]");
    }

    root["exfils"] = exfils_json;
    root["transits"] = transits_json;
    root["note"] = "Exfil world coordinates for minimap calibration.";

    const std::string maps_dir = minimap::get_maps_directory();
    std::error_code ec;
    if (!maps_dir.empty())
        std::filesystem::create_directories(maps_dir, ec);

    const std::string file_name = "exfil_coords_" + (location.empty() ? "unknown" : location) + ".json";
    const std::string out_path = maps_dir.empty() ? file_name : item_pricing::join_path(maps_dir, file_name);

    std::ofstream out(out_path);
    if (!out.is_open())
    {
        logger::error("Export exfils: failed to write " + out_path);
        return;
    }

    out << root.dump(2);
    logger::info("Export exfils: saved " + out_path);
    logger::info("Player pos: x=" + std::to_string(static_cast<int>(player_pos.x)) +
                 " y=" + std::to_string(static_cast<int>(player_pos.y)) +
                 " z=" + std::to_string(static_cast<int>(player_pos.z)));
}

void EspModule::clear_runtime_cache()
{
    // Cleared here rather than left to run for the session: the keys are raw player pointers,
    // and a stale entry whose address is reused by a different object would serve one
    // player's visibility for another's skeleton.
    vis_memo_.clear();
    {
        std::lock_guard<std::mutex> lock(data_mutex);
        item_info_cache.clear();
        template_name_cache_.clear();
        eft_api::clear_localization_cache();
        container_registry_.clear();
        container_item_caches_.clear();
        corpse_registry_.clear();
        corpse_item_caches_.clear();
        container_marker_snapshot_.clear();
        container_position_cursor_ = 0;
        container_loot_refresh_cursor_ = 0;
        corpse_loot_refresh_cursor_ = 0;
        corpse_last_tick_ms_ = 0;
        corpse_last_scan_ms_ = 0;
        container_registry_scan_ms_ = 0;
        container_first_scan_ms_ = 0;
        container_last_tick_ms_ = 0;
        quest_esp_last_refresh_ms_ = 0;
        quest_poi_sweep_ms_ = 0;
        loot_esp_last_scan_ms_ = 0;
        quest_items_last_scan_ms_ = 0;
        wishlist_sets_ = {};
        wishlist_sets_refresh_ms_ = 0;
        // Publish EMPTY snapshots rather than resetting the pointers. A reset
        // shared_ptr would make `*store` undefined for every reader, and these
        // are dereferenced from the render thread with no lock held.
        exfil_store = publish_empty<exfil>();
        transits_store = publish_empty<transit>();
        player_store = publish_empty<player>();
        loot_store = publish_empty<loot_entry>();
        quest_item_store = publish_empty<loot_entry>();
        grenade_store = publish_empty<grenade_entry>();
        tripwire_store = publish_empty<tripwire_entry>();
        keypanel_store = publish_empty<keypanel_entry>();
        keypanel_scanned_once_ = false;
        container_store_ = publish_empty<container_esp_entry>();
        corpse_store_ = publish_empty<container_esp_entry>();
        skeleton_store = publish_empty<skeleton_entry>();
        quest_poi_store = publish_empty<quest_esp::poi_entry>();
        bot_corpse_store_ = publish_empty<bot_corpse_marker>();
        bot_corpse_ai_profiles_.clear();
        bot_corpse_last_scan_ms_ = 0;
        bot_corpse_ai_profiles_ms_ = 0;
    }

    quest_esp::clear_caches();
    last_prices_version_ = 0;
    // Zero the published numbers now rather than letting the panel show a
    // freshly emptied cache as non-empty for up to a second.
    stats_entries_.store(0, std::memory_order_relaxed);
    stats_bytes_.store(0, std::memory_order_relaxed);
    stats_last_computed_ms_ = 0;
}

// Walks every cache. GAME THREAD ONLY -- the containers below are game-thread
// confined, and this is what keeps it that way. Called at most once a second
// from gameworld_update(), and unconditionally from clear_runtime_cache() so
// the numbers drop to zero the moment the caches are emptied.
void EspModule::refresh_cache_stats()
{
    // Zoned, and it is the answer to the 469.8 ms frame.
    //
    // The 2026-10-03 capture put EspModule::gameworld_update at mean 1.64 ms / max
    // 469.8 ms, and the phase probe showed 457 ms of that (94.2%) in `tail` -- the
    // post-loop block this call sits in. Four unbounded containers are walked here
    // (item_info_cache, template_name_cache_, container_item_caches_,
    // corpse_item_caches_), plus quest_esp's two counters, on the GAME THREAD, once
    // per second. A cache that grows without bound walked once a second is exactly the
    // shape that produces one lone multi-hundred-millisecond frame, and until now it
    // had no zone, so nothing in any capture could name it.
    TA_ZONE_N("esp_scan::refresh_cache_stats");
    size_t count = item_info_cache.size() + template_name_cache_.size();
    size_t bytes = 0;

    for (const auto &[_, info] : item_info_cache)
        bytes += info.name.size() + 64;
    for (const auto &[_, name] : template_name_cache_)
        bytes += name.size() + 32;

    for (const auto &[_, cache] : container_item_caches_)
    {
        count += 1 + cache.items.size();
        bytes += 48;
        for (const auto &item : cache.items)
            bytes += item.name.size() + 48;
    }
    for (const auto &[_, cache] : corpse_item_caches_)
    {
        count += 1 + cache.items.size();
        bytes += 48;
        for (const auto &item : cache.items)
            bytes += item.name.size() + 48;
    }

    count += quest_esp::get_runtime_cache_count();
    bytes += quest_esp::get_runtime_cache_bytes();

    stats_entries_.store(count, std::memory_order_relaxed);
    stats_bytes_.store(bytes, std::memory_order_relaxed);
    stats_last_computed_ms_ = GetTickCount64();
}

// Render thread. A plain atomic load: no lock, no map iteration, and therefore
// no way to collide with the game thread's inserts. A second of staleness on a
// diagnostics readout costs nothing.
[[nodiscard]] size_t EspModule::get_runtime_cache_count()
{
    return stats_entries_.load(std::memory_order_relaxed);
}

[[nodiscard]] size_t EspModule::get_runtime_cache_bytes()
{
    return stats_bytes_.load(std::memory_order_relaxed);
}

bool EspModule::prices_feature_enabled() const
{
    return show_loot_prices->get_value() || container_show_value->get_value() || loot_price_gradient->get_value();
}

void EspModule::init()
{
    // Retain these implementations but omit their controls from Visuals.
    /*grenade_esp->set_hidden_in_owner_menu(true);
        grenade_esp_distance->set_hidden_in_owner_menu(true);
        grenade_color->set_hidden_in_owner_menu(true);
        grenade_show_fuse->set_hidden_in_owner_menu(true);
        tripwire_esp->set_hidden_in_owner_menu(true);
        tripwire_color->set_hidden_in_owner_menu(true);
        keypanel_esp->set_hidden_in_owner_menu(true);
        keypanel_esp_distance->set_hidden_in_owner_menu(true);
        keypanel_color->set_hidden_in_owner_menu(true);
        loot_price_gradient->set_hidden_in_owner_menu(true);
        loot_high_value_max_range->set_hidden_in_owner_menu(true);
        loot_gradient_cheap->set_hidden_in_owner_menu(true);
        loot_gradient_expensive->set_hidden_in_owner_menu(true);
        loot_gradient_above_max->set_hidden_in_owner_menu(true);
        loot_gradient_max->set_hidden_in_owner_menu(true);*/

    // Keep the visual features active while simplifying their card UI.
    ConfigValue *hidden_visual_values[] = {
        extracts_color,
        transits_color,
        player_color,
        scav_color,
        boss_color,
        guard_color,
        cultist_color,
        raider_color,
        defector_color,
        civilian_color,
        black_division_color,
        btr_color,
        box_color,
        box_thickness,
        box_visible_color,
        box_occluded_color,
        health_color,
        health_low_color,
        skeleton_health_colors,
        skeleton_color,
        skeleton_thickness,
        skeleton_visible_color,
        skeleton_occluded_color,
        loot_color,
        loot_hideout_color,
        loot_wishlist_color,
        container_color,
        quest_item_color,
        quest_visit_color,
        quest_find_color,
        quest_place_color,
    };
    for (ConfigValue *value : hidden_visual_values)
        value->set_hidden_in_owner_menu(true);
    extracts->set_master_toggle(true);
    transits->set_master_toggle(true);
    players->set_master_toggle(true);
    npc->set_master_toggle(true);
    player_box->set_master_toggle(true);
    player_health->set_master_toggle(true);
    skeleton->set_master_toggle(true);
    esp_optic->set_master_toggle(true);
    loot_esp->set_master_toggle(true);
    container_esp->set_master_toggle(true);
    quest_items->set_master_toggle(true);
    quest_esp_enabled->set_master_toggle(true);
    grenade_esp->set_master_toggle(true);
    keypanel_esp->set_master_toggle(true);
}

void EspModule::prepare_menu_draw()
{
    const auto dis = [](ConfigValue *v, const bool disabled) { v->set_disabled(disabled); };

    const bool world_extracts = extracts->get_value();
    const bool world_transits = transits->get_value();
    const bool grenades_on = grenade_esp->get_value();
    const bool players_on = players->get_value();
    const bool npc_on = npc->get_value();
    const bool player_labels_on = players_on || npc_on;
    const bool box_on = player_box->get_value();
    const bool health_on = player_health->get_value();
    const bool skeleton_on = skeleton->get_value();
    const bool loot_on = loot_esp->get_value();
    const bool gradient_on = loot_on && loot_price_gradient->get_value();
    const bool high_value_range_on = loot_on && loot_high_value_max_range->get_value();
    // Gradient Max Value is shared by price gradient colors and high-value max-range threshold.
    const bool gradient_max_needed = gradient_on || high_value_range_on;
    const bool containers_on = container_esp->get_value();
    const bool quest_items_on = quest_items->get_value();
    const bool quest_overlay_on = quest_esp_enabled->get_value();
    // Map quest markers only count when the minimap master toggle is on (no silent work).
    const bool quest_map_on = minimap_module_self && minimap_module_self->radar->get_value() &&
                              minimap_module_self->radar_minimap_quest_esp->get_value();
    const bool quest_poi_on = quest_overlay_on || quest_map_on;
    const bool quest_section_on = quest_items_on || quest_poi_on;

    const bool trip_on = tripwire_esp->get_value();
    const bool keypanels_on = keypanel_esp->get_value();
    section_world_->set_section_active(world_extracts || world_transits || grenades_on || trip_on || keypanels_on);
    dis(extracts_color, !world_extracts);
    dis(transits_color, !world_transits);
    dis(grenade_esp_distance, !grenades_on);
    dis(grenade_color, !grenades_on);
    dis(grenade_show_fuse, !grenades_on);
    dis(tripwire_color, !trip_on);
    dis(keypanel_esp_distance, !keypanels_on);
    dis(keypanel_color, !keypanels_on);

    section_players_->set_section_active(player_labels_on);
    dis(player_color, !players_on);
    dis(scav_color, !npc_on);
    dis(boss_color, !npc_on);
    dis(guard_color, !npc_on);
    dis(cultist_color, !npc_on);
    dis(raider_color, !npc_on);
    dis(defector_color, !npc_on);
    dis(civilian_color, !npc_on);
    dis(black_division_color, !npc_on);
    dis(btr_color, !npc_on);
    dis(show_bot_names, !player_labels_on);
    dis(player_distance, !player_labels_on);

    const bool optic_on = esp_optic->get_value();
    section_optic_->set_section_active(optic_on);
    dis(esp_optic_s7, !optic_on);
    dis(esp_optic_periphery, !optic_on || !esp_optic_s7->get_value());
    section_overlay_->set_section_active(box_on || health_on);
    dis(box_distance, !box_on);
    const bool box_vis_on = box_on && box_visibility->get_value();
    dis(box_color, !box_on || box_vis_on);
    dis(box_thickness, !box_on);
    dis(box_visibility, !box_on);
    dis(box_visible_color, !box_vis_on);
    dis(box_occluded_color, !box_vis_on);
    dis(health_color, !health_on);
    dis(health_low_color, !health_on);

    section_skeleton_->set_section_active(skeleton_on);
    dis(skeleton_health_colors, !skeleton_on);
    dis(skeleton_distance, !skeleton_on);
    dis(skeleton_color, !skeleton_on);
    dis(skeleton_thickness, !skeleton_on);
    dis(skeleton_head_circle, !skeleton_on);
    // --- skeleton visibility ESP (rollback: remove block) ---
    const bool skeleton_vis_on = skeleton_on && skeleton_visibility->get_value();
    const bool skeleton_vis_health_on = skeleton_vis_on && skeleton_health_colors->get_value();
    dis(skeleton_visibility, !skeleton_on);
    dis(skeleton_visible_color, !skeleton_vis_on);
    dis(skeleton_vis_distance, !skeleton_vis_on);
    dis(skeleton_occluded_color, !skeleton_vis_on);
    dis(skeleton_vis_health_mode, !skeleton_vis_health_on);
    // --- end skeleton visibility ESP ---

    section_loot_->set_section_active(loot_on);
    dis(loot_min_distance, !loot_on);
    dis(loot_distance, !loot_on);
    dis(loot_min_value, !loot_on);
    // Exclusive loot-filter toggles, decided before any dropdown is disabled or any
    // predicate reads a value. Order matters: enforce first, then gate on the result.
    enforce_loot_filter_exclusivity();
    const bool cat_filter_on = loot_on && loot_category_filter_enabled->get_value();
    const bool wl_filter_on = loot_on && loot_wishlist_filter_enabled->get_value();
    dis(loot_category_filter_enabled, !loot_on);
    dis(loot_wishlist_filter_enabled, !loot_on || loot_category_filter_enabled->get_value());
    dis(loot_category_filter, !cat_filter_on);
    // The wishlist dropdown both disables on its own toggle and greys out when the
    // category toggle is on, so the user can see WHY it is unavailable rather than
    // finding it silently inert.
    dis(loot_wl_filter, !wl_filter_on || loot_category_filter_enabled->get_value());
    dis(show_loot_prices, !loot_on);
    dis(loot_price_gradient, !loot_on);
    dis(loot_high_value_max_range, !loot_on);
    dis(loot_gradient_cheap, !gradient_on);
    dis(loot_gradient_expensive, !gradient_on);
    dis(loot_gradient_above_max, !gradient_on);
    dis(loot_gradient_max, !gradient_max_needed);
    dis(loot_color, !loot_on);
    dis(show_provisions, !loot_on);
    dis(loot_wl_filter, !loot_on);
    dis(loot_hideout_color, !loot_on);
    dis(loot_wishlist_color, !loot_on);
    section_loot_item_filter_->set_section_active(loot_on);
    section_loot_category_filter_->set_section_active(loot_on);
    dis(loot_category_filter, !loot_on);

    section_containers_->set_section_active(containers_on);
    dis(container_show_loot, !containers_on);
    dis(container_show_value, !containers_on);
    dis(corpse_show_loot, !loot_on);
    dis(container_distance, !containers_on);
    dis(container_color, !containers_on);

    section_quest_->set_section_active(quest_section_on);
    dis(quest_item_distance, !quest_items_on);
    dis(quest_item_color, !quest_items_on);
    dis(quest_esp_distance, !quest_poi_on);
    dis(quest_esp_descriptions, !quest_overlay_on);
    dis(quest_visit_color, !quest_poi_on);
    dis(quest_find_color, !quest_poi_on);
    dis(quest_place_color, !quest_poi_on);

    // Keep these settings visible but unavailable in the Visuals card.
    /*grenade_esp->set_disabled(true);
        grenade_esp_distance->set_disabled(true);
        grenade_color->set_disabled(true);
        grenade_show_fuse->set_disabled(true);
        tripwire_esp->set_disabled(true);
        tripwire_color->set_disabled(true);
        keypanel_esp->set_disabled(true);
        keypanel_esp_distance->set_disabled(true);
        keypanel_color->set_disabled(true);*/
}

void EspModule::draw_optic_region_debug(ImDrawList *draw_list)
{
    if (!logger::debug_enabled())
        return;
    const optics::lens::packet *const p = eft_api::optic_lens_packet();
    if (!p || p->mask.size() < 3)
        return;

    const float w = static_cast<float>(menu::get_width());
    const float h = static_cast<float>(menu::get_height());
    if (w < 1.f || h < 1.f)
        return;

    auto to_px = [&](const optics::lens::v2 &n) { return ImVec2((n.x + 1.f) * w * 0.5f, (1.f - n.y) * h * 0.5f); };

    // --- cyan: the cull region polygon, as the code sees it -------------------
    std::vector<ImVec2> ring;
    ring.reserve(p->mask.size());
    for (const auto &n : p->mask)
        ring.push_back(to_px(n));
    draw_list->AddPolyline(ring.data(), static_cast<int>(ring.size()), IM_COL32(0, 255, 255, 255), 2.f,
                           ImDrawFlags_Closed);

    // --- yellow: the image quad ----------------------------------------------
    if (p->image_quad[0].x != 0.f || p->image_quad[0].y != 0.f)
    {
        ImVec2 q[4];
        for (int i = 0; i < 4; ++i)
            q[i] = to_px(p->image_quad[i]);
        draw_list->AddPolyline(q, 4, IM_COL32(255, 255, 0, 255), 1.f, ImDrawFlags_Closed);

        // --- magenta: full-lens reference circle at the quad's half-height ----
        const float qx0 = (std::min<float>)(q[0].x, (std::min<float>)(q[1].x, (std::min<float>)(q[2].x, q[3].x)));
        const float qx1 = (std::max<float>)(q[0].x, (std::max<float>)(q[1].x, (std::max<float>)(q[2].x, q[3].x)));
        const float qy0 = (std::min<float>)(q[0].y, (std::min<float>)(q[1].y, (std::min<float>)(q[2].y, q[3].y)));
        const float qy1 = (std::max<float>)(q[0].y, (std::max<float>)(q[1].y, (std::max<float>)(q[2].y, q[3].y)));
        const float rcx = (qx0 + qx1) * 0.5f;
        const float rcy = (qy0 + qy1) * 0.5f;
        const float r_ref = (std::min<float>)((qx1 - qx0) * 0.5f, (qy1 - qy0) * 0.5f);

        // measured region radius: mean distance from the quad centre to the polygon
        double sum = 0.0;
        for (const ImVec2 &v : ring)
            sum += std::hypot(static_cast<double>(v.x - rcx), static_cast<double>(v.y - rcy));
        const double r_meas = sum / static_cast<double>(ring.size());

        draw_list->AddCircle(ImVec2(rcx, rcy), static_cast<float>(r_ref), IM_COL32(255, 0, 255, 255), 24, 2.f);
        // crosshair at the reference centre, so a displaced region is obvious
        draw_list->AddLine(ImVec2(rcx - 12.f, rcy), ImVec2(rcx + 12.f, rcy), IM_COL32(255, 0, 255, 255), 1.f);
        draw_list->AddLine(ImVec2(rcx, rcy - 12.f), ImVec2(rcx, rcy + 12.f), IM_COL32(255, 0, 255, 255), 1.f);

        char buf[224];
        std::snprintf(buf, sizeof(buf),
                      "optic region  cyan=cull  yellow=imageQuad  magenta=ref\n"
                      "  region r=%.0f px   ref r=%.0f px   ratio=%.2f   cover=%.1f%%\n"
                      "  centre offset=(%.0f,%.0f) px   quads=%d",
                      static_cast<double>(r_meas), static_cast<double>(r_ref), r_ref > 1.0 ? r_meas / r_ref : 0.0,
                      static_cast<double>(optics::lens::g_region.mask_cover_frac) * 100.0,
                      static_cast<double>(rcx - w * 0.5f), static_cast<double>(rcy - h * 0.5f),
                      static_cast<int>(p->mask.size()));
        draw_list->AddText(ImVec2(24.f, 24.f), IM_COL32(255, 255, 255, 255), buf);
    }
}

void EspModule::draw_overlay(ImDrawList *draw_list)
{
    // The render half of the frame. draw_overlay and gameworld_update below are
    // separate zones because they run on different sides of the frame: gameworld
    // reads game state, draw_overlay consumes the stores it filled. A profile
    // that shows draw_overlay expensive with gameworld_update cheap points at
    // the stores or the ImGui submission, not at the reflection.
    TA_ZONE_N("frame::EspModule::draw_overlay");
    if (!game_state::is_in_raid)
        return;

    // Hide the minimap when a UI screen is open over it. The out-of-raid gate
    // above is unchanged; this adds the inventory case. The bug: opening your
    // own backpack is screen type 15 with no LootItem, so
    // is_external_loot_inventory_open_cached() returned false and the minimap
    // stayed full-size over the inventory. See query_ui_blocking_screen_open().
    if (eft_api::is_ui_blocking_screen_open_cached())
        return;

    // The visibility gate's clock. Incremented once per PRESENTED frame on the render thread
    // and read by collect_skeleton on the game thread, so "once per frame" means once per
    // drawn frame rather than once per tick.
    //
    // THAT distinction is the whole design, and it was measured: the 2026-10-02 nextday+1
    // capture ran hk_game_world_update 1.67x per drawn frame. A tick-rate throttle would have
    // let through 1.67 evaluations per displayed frame -- i.e. it would not have throttled
    // anything the user can see. relaxed is sufficient and all that is needed here: this is a
    // change-detector, not a synchronisation point, and a stale read costs one extra
    // evaluation at worst.
    vis_frame_serial_.fetch_add(1, std::memory_order_relaxed);

    // Camera choice, reported from here because this is where the resolver is called.
    // See the cam_source block in eft_api.h for what the numbers mean.
    eft_api::maybe_report_camera_choice();

    // Use const references instead of copying vectors every frame.
    // The stores are only read during draw_overlay, never modified.
    // The mutex is still needed because gameworld_update (game thread) writes
    // to these stores while draw_overlay (render thread) reads them.
    // SNAPSHOTS, not raw pointers. Copying the shared_ptr under the lock pins
    // the immutable vector for the rest of this frame, so the ~500 lines of
    // drawing below need no lock. Taking `&store` here -- as this did until
    // 2026-09-30 -- handed the render thread a pointer the game thread was free
    // to free, and it did: the fault was a READ of 0x288 inside
    // `entry.bones.find()`. See the store block in EspModule.h.
    exfil_snapshot local_exfils;
    transit_snapshot local_transits;
    player_snapshot local_players;
    loot_snapshot local_loots;
    loot_snapshot local_quest_items;
    std::shared_ptr<const std::vector<container_esp_entry>> local_containers;
    std::shared_ptr<const std::vector<container_esp_entry>> local_corpses;
    skeleton_snapshot local_skeletons;
    quest_poi_snapshot local_quest_poi;
    grenade_snapshot local_grenades;
    tripwire_snapshot local_tripwires;
    keypanel_snapshot local_keypanels;
    bot_corpse_snapshot local_bot_corpses;

    {
        std::lock_guard<std::mutex> lock(data_mutex);
        local_exfils = exfil_store;
        local_transits = transits_store;
        local_grenades = grenade_store;
        local_tripwires = tripwire_store;
        local_keypanels = keypanel_store;
        local_players = player_store;
        local_loots = loot_store;
        local_quest_items = quest_item_store;
        local_containers = container_store_;
        local_corpses = corpse_store_;
        local_skeletons = skeleton_store;
        local_quest_poi = quest_poi_store;
        local_bot_corpses = bot_corpse_store_;
    }

    // Cameras: FPS (eyes) always; optic when ADS and BaseOpticCamera is live.
    // Dual rear layer always uses zoom=1 (no ADS fake zoom on eye ESP).
    // Cache esp_camera state once for the entire render pass to avoid repeated IL2CPP calls

    // main_player_ is passed so the resolver can (a) break ties when the scene holds more
    // than one camera named "FPS Camera" and (b) refuse a camera that is nowhere near us.
    // It is the same pointer this function already hands to setup_esp_optic_frame below,
    // on this same thread, so neither call introduces a lifetime question.
    // ---- IS THE SCENE STILL SAFE TO TOUCH? ----
    //
    // Measured 2026-10-04, two runs: a managed (non-std) exception thrown from inside this
    // function ~0.6 s after `Local Raid Ended`, out of find_camera_if_best ->
    // camera_get_all_internal(), which is Unity's `Camera.all`. The overlay stage named the
    // module (ESP::draw_overlay); per-widget instrumentation named nothing, so the throw is
    // here rather than in any ConfigValue.
    //
    // WHY is_in_raid IS NOT ENOUGH: the raid is over from the game's side while our flag is
    // still true, because the flag drops on the LocalRaidEnded event / InRaid poll and there
    // is a window before that lands. ISIL confirms `InGameStatus.InRaid` is the game's OWN
    // gate (TarkovApplication.txt:5865 -- `typeof(EFT.InGameStatus)`, null-check, read
    // `v33.InRaid`), so this is not a proxy we invented; it is simply too coarse for teardown.
    //
    // WHAT THIS GATE IS, after being cut down on 2026-10-04. It was
    // `main_player_ resolves AND try_get_health_controller() returns non-null`, on the theory
    // that a dying player would stop resolving. MEASURED WRONG. The throw line carries its own
    // state:
    //
    //     esp: camera resolution threw (managed) -- ... scene_objects_live=true is_in_raid=true
    //
    // Both the player and its health controller resolved, and `Camera.all` threw anyway. So the
    // health-controller half cannot see this window -- 5.7r repeating one level out, where that
    // guard tested a managed WRAPPER rather than the object behind it and this one tested a
    // managed PLAYER rather than whether calling into Unity is safe.
    //
    // It is gone for two reasons, and the second is the one that mattered:
    //
    //   1. It is the expensive half. `main_player_ && main_player_->klass` is pointer
    //      arithmetic; try_get_health_controller is two MANAGED calls on the render thread,
    //      once per draw_overlay. (The parallel session added a per-object memo to it for
    //      exactly this reason -- which is a fix for a cost this gate should not have created.)
    //   2. It sat OUTSIDE the try block. The local `catch (...)` exists so a managed throw
    //      cannot escape to menu::draw, and the gate was putting a managed call back into the
    //      one path with no protection -- on a dying player, which is precisely when it can
    //      throw. It did not throw in either run; that is luck, not design.
    //
    // What remains is the free half, and it does earn its place: it fired on both runs during
    // transits, and skipping the resolve then is correct and costs nothing.
    //
    // NOT IsAlive, deliberately, and no longer consulted at all: a DEAD player is still in a
    // raid with a perfectly working camera, so any liveness test that drops the ESP would also
    // drop it for corpses and for anyone spectating a death.
    static std::atomic<int> s_scene_gone_reported{0};
    // ---- CAMERA CIRCUIT BREAKER ----
    //
    // Measured 2026-10-04, run pid 27460: 6,913 managed throws from the two resolve calls
    // between 18:34:19 and 18:38:33 -- 27.3/second, unbroken, for 253 seconds, every
    // sampled line reading `scene_objects_live=true is_in_raid=true`. The raid had ended at
    // 18:32:40, so both the RATE and the reason it kept firing were visible at once.
    //
    // They are CHEAP, and that decides the shape of the fix: the whole camera path
    // (`eft_api::resolve_esp_camera_frame`) totals 22.6 ms over 2,107 calls, mean 10.7 us,
    // so ~6,900 caught managed exceptions cost tens of milliseconds. **This is NOT the
    // 4-second freeze** -- that is the game's own MoveNext, measured at 99.8% of
    // `hk_on_game_end` by the ::orig zones.
    //
    // So this is not a performance fix either. It is 6,913 pointless trips into a Unity
    // subsystem that has already gone away, on the render thread, every frame -- and the
    // reporter capped at 5 lines, so from the log it did not look like 6,913 at all.
    //
    // A camera that has thrown N times running is not going to recover inside the same raid,
    // so stop asking. Keyed on the PLAYER pointer, because a new raid has a new player
    // object and a fresh camera: a process-lifetime latch would disarm the overlay for
    // every raid after the first bad one, which is the opposite of what is wanted.
    //
    // Render-thread state only. draw_overlay is called from menu::draw on the render thread,
    // so plain statics are correct here and an atomic would imply a cross-thread contract
    // that does not exist.
    static Il2CppObject *s_breaker_player = nullptr;
    static int s_cam_consecutive_throws = 0;
    if (s_breaker_player != main_player_) // new player, i.e. new raid: re-arm
    {
        s_breaker_player = main_player_;
        s_cam_consecutive_throws = 0;
    }
    // 8 consecutive is ~0.3 s at the measured 27.3/s. Low enough to stop promptly, high
    // enough that one unlucky frame in normal play does not disarm the overlay all raid.
    constexpr int kEspCamConsecutiveThrowLimit = 8;
    const bool cameras_are_gone = s_cam_consecutive_throws >= kEspCamConsecutiveThrowLimit;
    const bool scene_objects_live = (main_player_ != nullptr && main_player_->klass != nullptr);

    // Cameras are resolved INSIDE A CATCH, and that is the point of the block.
    //
    // menu::draw already wraps this function in a catch, so the throw was never fatal -- but
    // the parallel session's poison pill stops calling menu::draw after 120 consecutive
    // throws, which means an exception from ONE subsystem costs the ENTIRE overlay: skeletons,
    // boxes and labels all stop. Catching here makes the failure local -- no cameras this
    // frame, everything else drawn -- and it lets the poison pill's counter reset, because
    // menu::draw then completes cleanly.
    //
    // `catch (...)` rather than `catch (const std::exception&)` because the thrower is a
    // MANAGED exception, which is not a std::exception and would sail past the typed arm.
    Il2CppObject *fps_cam = nullptr;
    Il2CppObject *optic_cam = nullptr;
    float optic_zoom = 1.f;
    bool optic_live = false;
    if (scene_objects_live && !cameras_are_gone)
    {
        try
        {
            fps_cam = eft_api::resolve_esp_camera(false, 1.f, nullptr, nullptr, nullptr, main_player_);
            optic_cam = eft_api::resolve_esp_camera(true, game_state::current_zoom, &optic_zoom, &optic_live, nullptr,
                                                    main_player_);
            s_cam_consecutive_throws = 0; // a resolve worked; re-arm
        }
        catch (...)
        {
            // The first three, then every 256th, and the number printed is always the
            // RUNNING TOTAL.
            //
            // This was a hard cap of 5 lines. That answered "does it happen" and then made
            // the rate unquotable: the 2026-10-04 runs logged exactly five lines each, and
            // nothing in the log distinguishes 5 throws from 500. Same failure as the
            // probe-memo line that cried wolf -- a counter that stops counting cannot report
            // a magnitude. Suppressing the FLOOD is right; suppressing the RATE is not,
            // because the rate is the thing being measured.
            static std::atomic<int> s_cam_throws{0};
            const int n = s_cam_throws.fetch_add(1, std::memory_order_relaxed);
            ++s_cam_consecutive_throws;
            if (s_cam_consecutive_throws == kEspCamConsecutiveThrowLimit)
            {
                logger::warn(std::format("esp: camera resolution has now thrown {} times in a row on this "
                                         "player; not asking again for the rest of this raid "
                                         "(throw #{} total)",
                                         s_cam_consecutive_throws, n + 1));
            }
            if (n < 3 || (n % 256) == 0)
            {
                // game_state::is_in_raid is std::atomic<bool> and std::format has no
                // formatter for it, so it is loaded into a plain bool first.
                const bool in_raid_now = game_state::is_in_raid.load(std::memory_order_relaxed);
                logger::warn(std::format("esp: camera resolution threw (managed) -- throw #{} so far (first 3, "
                                         "then every 256); drawing without cameras this frame; "
                                         "scene_objects_live={} is_in_raid={}",
                                         n + 1, scene_objects_live, in_raid_now));
            }
        }
    }
    else
    {
        // Same reporting policy as the throw counter above, and for the same reason: the
        // 2026-10-04 runs logged five of these and the real count is unknown.
        const int m = s_scene_gone_reported.fetch_add(1, std::memory_order_relaxed);
        if (m < 3 || (m % 256) == 0)
            logger::warn(std::format("esp: the player no longer resolves (scene_objects_live=false) while "
                                     "is_in_raid is still true -- skipping camera resolution; frame #{} since "
                                     "the player stopped resolving (first 3, then every 256); the raid has "
                                     "ended and our flag has not caught up yet",
                                     m + 1));
    }

    // Dual ADS is permanently OFF (toggle removed 2026-09-27). The name is
    // kept so the residual `dual_active` guards in the draw body below stay
    // self-documenting, and so the draw body reads as "single pass, plus the
    // removed second pass" rather than as an unexplained block.
    //
    // Section 7 (optic_idea.md line 574) is a CORRECTNESS requirement and is
    // NOT this: it wants a per-segment clip so that nothing is drawn twice
    // and nothing vanishes, not a per-object cull producing a split view.
    const bool dual_active = false;
    game_state::esp_dual_ads_active = dual_active;
    game_state::esp_optic_user_scale = kFallbackRadialScale;

    // Section 7 region split (optic_idea.md line 574), and the main camera the
    // outside region is drawn through. Published here because this is the only place
    // that resolves BOTH cameras: the projection path is handed only the optic one,
    // and the optic camera's projection is exactly what must not be used outside the
    // lens mask.
    game_state::esp_optic_s7 = esp_optic_s7->get_value();
    // ACTIVE INVESTIGATION: publish the A/B switch for the root-position outlier
    // filter. Polled here, next to the other optic flags, so the menu toggle is live
    // mid-raid. Inverted on the way in because the checkbox reads as the filter
    // being ENABLED while the consumer wants to know whether it is DISABLED -- and
    // the failure mode of getting that backwards is silent: the switch would appear
    // to work while the corrector kept running.
    game_state::optic_root_corrector_off.store(!optic_root_corrector->get_value(), std::memory_order_relaxed);
    game_state::esp_optic_periphery = esp_optic_periphery->get_value() == 0 ? game_state::optic_periphery::cull
                                                                            : game_state::optic_periphery::main_camera;
    eft_api::note_esp_fps_camera(fps_cam);

    // Single mode: optic transfer if enabled, else eyes. Reuse cached cameras to avoid redundant calls.
    float draw_zoom = game_state::current_zoom;
    bool using_optic = false;
    Il2CppObject *cam;
    if (esp_optic->get_value() && optic_live)
    {
        // Single-mode optic projection: ADS with a live optic camera draws
        // through the lens pipeline (exact scope magnification). The old
        // `!optic_live` condition was inverted — it fell through to the eye
        // camera with fake zoom, so skeletons/boxes stayed 1x inside a 4x
        // scope picture (user report 2026-09-24 night 2).
        cam = optic_cam;
        using_optic = true;
        draw_zoom = 1.f;
    }
    else
    {
        cam = fps_cam;
    }
    if (!cam && fps_cam)
        cam = fps_cam;
    if (!cam)
        return;

    game_state::esp_draw_zoom = draw_zoom;
    eft_api::setup_esp_optic_frame(using_optic, cam, game_state::current_zoom, kFallbackRadialScale, main_player_);

    // Fallback mask geometry (screen center, size from shorter half-side). Only
    // consulted when the fitted mask is unavailable — see kFallbackMaskSize above.
    // With no culling pass there is no user-facing circle, so esp_ads_mask_half
    // is pinned to 0.
    //
    // CORRECTION 2026-10-01. The comment here used to say `esp_ads_mask_allows()`
    // "short-circuits true on half <= 0 and nothing is hidden". That named the wrong
    // variable and was never checked. The actual short-circuit is the first line of
    // that function: `if (esp_ads_mask_mode == 0) return true;` — and the very next
    // line below this block, `clear_esp_ads_mask()`, sets esp_ads_mask_mode = 0. So
    // mode is 0 on every frame and the function always returns true. `half` is never
    // read on this path at all; it is only consulted inside esp_ads_mask_contains,
    // which this path never reaches.
    //
    // Left as measured rather than "tidied", because the consequence is the point: the
    // cull counters reported by `optic-cull` (checks/rejected) are structurally always
    // zero, and the real clipping happens through optic_lens_segment_interval against
    // the FITTED polygon. The `optic-maskgate` line added in eft_api.h prints mode,
    // half and fitted_pts so this is checkable instead of a comment nobody re-reads.
    //
    // `mask_half`/`mask_circle` went with the Dual ADS outline (2026-09-27): it
    // drew the *guessed* fallback circle, which by construction did not match the
    // real scope opening. Outlining the FITTED mask from the packet would be
    // accurate and is a candidate for a future control; guessing was not.
    const float menu_w = menu::get_width();
    const float menu_h = menu::get_height();
    const float mask_cx = menu_w * 0.5f;
    const float mask_cy = menu_h * 0.5f;
    game_state::esp_ads_mask_cx = mask_cx;
    game_state::esp_ads_mask_cy = mask_cy;
    game_state::esp_ads_mask_half = 0.f;
    game_state::esp_ads_mask_circle = kFallbackMaskCircle;
    game_state::clear_esp_ads_mask();

    // Optic region rings, right after the packet is live and the mask state is
    // published, and before any geometry is drawn. No-op unless the Show Debug Log
    // toggle is on. See the header comment on draw_optic_region_debug.
    draw_optic_region_debug(draw_list);

    const float player_max_dist = player_distance->get_value();
    const float hud_font_size = esp_text::esp_font_size();
    ImFont *hud_font = menu::get_hud_font();
    const esp_text::settings text_settings = esp_text::current_settings();
    const bool batch_loot_labels = text_settings.clustering || text_settings.depth_sort;
    std::vector<esp_text::label> loot_labels;

    char text_buf[256];

    // depth_sort queue must start BEFORE minimap so marker labels are not wiped by begin_frame.
    if (text_settings.depth_sort)
        esp_text::begin_frame();

    // Minimap once from eye camera (not dual-scoped).
    Il2CppObject *minimap_cam = fps_cam ? fps_cam : cam;
    if (minimap_module_self->radar->get_value())
        draw_radar_overlay(draw_list, *local_players, *local_exfils, *local_transits, *local_quest_poi,
                           *local_bot_corpses, get_view_yaw(minimap_cam));

    // Optic projection: lens pipeline via eft_api::world_to_screen
    const bool use_optic_projection = esp_optic->get_value();
    Il2CppObject *lens_renderer = nullptr;
    if (use_optic_projection)
        lens_renderer = eft_api::get_lens_renderer_from_weapon(main_player_);

    // ===================================================================
    // DRAW BODY. A bare scope, not a pass loop.
    //
    // This WAS `for (int pass = 0; pass < (dual_active ? 2 : 1); ++pass)`
    // with pass 0 = eye/outside-mask and pass 1 = optic/inside-mask. Removed
    // 2026-09-27 with the Dual ADS toggle. The `if (dual_active)` guards still
    // below are the remainder of that scaffolding.
    //
    // Note the two passes are NOT what optic_idea.md section 7 (line 574)
    // wants. Section 7 is a PER-SEGMENT CLIP: "For the main-camera pass,
    // remove the interval inside the mask; the remaining zero, one or two
    // pieces stay visible." That is line-level clipping via
    // optic_lens_segment_interval, and the two passes draw DISJOINT
    // geometry at the SAME magnification.
    //
    // What the removed passes did instead was a whole-OBJECT cull
    // (esp_ads_mask_mode 1/2 -> esp_ads_mask_allows) at DIFFERENT
    // magnifications per region -- a deliberate divergence from the game,
    // which is why it removed ~50% of objects. The shape looks reusable
    // for section 7 and is not; the masking semantics are inverted.
    // Section 7 needs a rewrite, not a flag.
    // ===================================================================
    {

        // Do NOT call begin_frame here — would clear minimap labels queued above.
        loot_labels.clear();
        if (batch_loot_labels)
            loot_labels.reserve(local_loots->size());

        // World ESP text first (extracts/loot/…). Combat geometry + player/NPC labels draw after
        // so boxes/skeletons/names always sit on top of other ESP text (incl. depth sort).
        const bool show_player_esp = players->get_value() || npc->get_value();
        const float box_max_dist = box_distance->get_value();

        if (extracts->get_value())
        {
            // `eligibility` entered this binding on 2026-10-05 (5th member); `secret` and
            // `scav_coop` on 2026-10-07 (6th and 7th). All three are properties of the extract
            // that the LABEL needs, not draw state, so they belong on the entry.
            for (const auto &[name, status, pos3d, requirement, secret, scav_coop, eligibility] : *local_exfils)
            {
                // Unified projection: in the optic pass `cam` IS the optic
                // camera and world_to_screen routes through the lens pipeline
                // (radial fallback when the pipeline rejects the frame).
                unity::vector3 screen_pos = eft_api::world_to_screen(cam, pos3d, game_state::esp_draw_zoom);

                if (!eft_api::is_visible(screen_pos))
                    continue;

                const float distance = my_pos.distance(pos3d);

                // ELIGIBILITY DECIDES THE WORD. Status says what phase an extract is in;
                // eligibility says whether THIS PLAYER may leave by it. They are different
                // questions, and reading the status alone is what made an unusable extract read
                // "Open" (user report, 2026-10-05).
                //
                // NEW SINCE THEN, and the report came back: membership in `EligiblePoints` is
                // not availability either. It answers "does this point EXIST for my entry
                // point" and never reads `_status`. So `exfil_eligibility_of` is now the
                // conjunction of membership AND a live status of `RegularMode (4)`.
                //
                // Fail-open on `unknown`: if the snapshot could not be taken we keep the status
                // label, because a possibly-stale word is better than no word at all. Treating a
                // failed snapshot as authoritative is how the original bug shipped.
                const char *status_string = nullptr;
                switch (eligibility)
                {
                case eft_api::exfil_eligibility::eligible:
                    // Eligible AND item-gated: the item is still needed, and saying so is the
                    // point -- but "Available" is now earned rather than assumed.
                    status_string = requirement.empty() ? "Open" : "Open: need Item";
                    break;
                case eft_api::exfil_eligibility::not_eligible:
                    status_string = requirement.empty() ? "Not available" : "Blocked: need Item";
                    break;
                case eft_api::exfil_eligibility::unknown:
                default:
                    break; // fall through to the status label below
                }

                if (!status_string)
                {
                    // THE STATUS ENUM, as the game defines it. The previous table here was
                    // wrong from 2 down because it was read off a decompiler's enum NAME list
                    // rather than its values; corrected 2026-10-10 against
                    // GameDump/120047965/dump.cs `enum EExfiltrationStatus` and the branch
                    // structure of `set_Status`/`SetInitialStatus`. See the enum block in
                    // eft_api.h for the per-value derivation.
                    //
                    // Only `RegularMode` (4) is rendered "Open", which is why the eligibility
                    // verdict above is the only thing that can produce that word: this switch
                    // deliberately does NOT claim it, so a point at `Countdown` (3) or
                    // `AwaitsManualActivation` (6) -- present but not open -- cannot read "Open".
                    switch (status)
                    {
                    case static_cast<int>(eft_api::exfil_status::hidden): // 7
                        status_string = "Hidden";
                        break;
                    case static_cast<int>(eft_api::exfil_status::awaits_manual_activation): // 6
                        status_string = "Awaiting activation";
                        break;
                    case static_cast<int>(eft_api::exfil_status::pending): // 5
                        status_string = "Extracted";
                        break;
                    case static_cast<int>(eft_api::exfil_status::regular_mode): // 4
                        status_string = "Open";
                        break;
                    case static_cast<int>(eft_api::exfil_status::countdown): // 3
                        status_string = "Countdown";
                        break;
                    case static_cast<int>(eft_api::exfil_status::uncomplete_requirements): // 2
                        status_string = "Not available";
                        break;
                    case static_cast<int>(eft_api::exfil_status::not_present): // 1
                        status_string = "Closed";
                        break;
                    default:
                        // 0 (never initialised) and anything a newer build adds. NOT "Open":
                        // an unrecognised status must not be reported usable.
                        status_string = "Unknown";
                        break;
                    }
                }

                // WHAT KIND OF EXIT, in the user's words:
                //     "Exfil: <name>"  /  "Co-op Exfil: <name>"  /  "Secret Exfil: <name>"
                //
                // Derived from the OBJECT (its class and its Requirements), not from which
                // array it was found in, so the prefix stays right if a different caller hands
                // over a point it did not discover there.
                const char *prefix = secret ? "Secret Exfil" : (scav_coop ? "Co-op Exfil" : "Exfil");

                snprintf(text_buf, sizeof(text_buf), "[%dm] %s: %s (%s)", static_cast<int>(distance), prefix,
                         name.c_str(), status_string);

                // A SECRET exit's item goes on its own line rather than being appended to the
                // status. Two reasons, both against the alternative: "Note with code word Voron"
                // is 24 characters, so "(Open Note with code word Voron)" pushes the label past
                // a readable width; and the item is a different KIND of fact from the status, so
                // burying it in a status suffix is what made the old label confusing.
                //
                // ImGui::AddText does NOT honour \n -- it is not a wrapping call -- so the
                // second line is a second draw at a y-offset, not an embedded newline. That
                // helper now exists (esp_text::draw_simple_two_line, esp_text.h:299) and is
                // called just below; while esp_text.h was under the [CLEANUP-PENDING:OPTICS]
                // freeze (lifted 2026-10-13) it could not be added there, and this comment
                // said so. The freeze is gone and the helper is in place, so the note is kept
                // only for the \n reasoning above.
                char item_buf[192];
                item_buf[0] = '\0';
                if (secret && !requirement.empty())
                    snprintf(item_buf, sizeof(item_buf), "Item: %s", requirement.c_str());

                // draw_simple_two_line centres the PAIR on the anchor, which two offset
                // draw_simple calls do not: draw_simple centres one line, so the pair would sit
                // half a line low, and under depth_sort the two would be separate queue entries
                // sorting independently against every other label at the same distance.
                esp_text::draw_simple_two_line(draw_list, hud_font, hud_font_size, {screen_pos.x, screen_pos.y},
                                               extracts_color->get_value(), text_buf, item_buf, distance);
            }
        }

        if (transits->get_value())
        {
            for (const auto &[name, pos3d] : *local_transits)
            {
                // Use optic-aware projection when in dual mode and inside mask
                unity::vector3 screen_pos;
                if (dual_active && game_state::esp_ads_mask_mode == 2)
                {
                    // Optic layer: use optic camera with lens renderer
                    screen_pos = eft_api::world_to_screen(cam, pos3d, game_state::esp_draw_zoom, lens_renderer);
                }
                else
                {
                    // Eye layer or single mode: standard projection
                    screen_pos = eft_api::world_to_screen(cam, pos3d, game_state::esp_draw_zoom);
                }

                if (!eft_api::is_visible(screen_pos))
                    continue;

                const float distance = my_pos.distance(pos3d);
                snprintf(text_buf, sizeof(text_buf), "[%dm] %s", static_cast<int>(distance), name.c_str());

                esp_text::draw_simple(draw_list, hud_font, hud_font_size, {screen_pos.x, screen_pos.y},
                                      transits_color->get_value(), text_buf, distance);
            }
        }

        if (grenade_esp->get_value())
        {
            const float grenade_max = grenade_esp_distance->get_value();
            const ImVec4 grenade_col = grenade_color->get_value();
            const bool show_fuse = grenade_show_fuse->get_value();

            for (const auto &entry : *local_grenades)
            {
                if (entry.distance > grenade_max)
                    continue;

                // Use optic-aware projection when in dual mode and inside mask
                unity::vector3 screen_pos;
                if (dual_active && game_state::esp_ads_mask_mode == 2)
                {
                    // Optic layer: use optic camera with lens renderer
                    screen_pos = eft_api::world_to_screen(cam, entry.pos3d, game_state::esp_draw_zoom, lens_renderer);
                }
                else
                {
                    // Eye layer or single mode: standard projection
                    screen_pos = eft_api::world_to_screen(cam, entry.pos3d, game_state::esp_draw_zoom);
                }

                if (!eft_api::is_visible(screen_pos))
                    continue;

                if (show_fuse && entry.fuse_remaining >= 0.f)
                {
                    snprintf(text_buf, sizeof(text_buf), "[%dm] %s (%.1fs)", static_cast<int>(entry.distance),
                             entry.label.c_str(), entry.fuse_remaining);
                }
                else
                {
                    snprintf(text_buf, sizeof(text_buf), "[%dm] %s", static_cast<int>(entry.distance),
                             entry.label.c_str());
                }

                esp_text::draw_simple(draw_list, hud_font, hud_font_size, {screen_pos.x, screen_pos.y}, grenade_col,
                                      text_buf, entry.distance);
            }
        }

        if (tripwire_esp->get_value())
        {
            const float trip_max = grenade_esp_distance->get_value();
            for (const auto &entry : *local_tripwires)
            {
                if (entry.distance > trip_max)
                    continue;
                unity::vector3 screen_pos = eft_api::world_to_screen(cam, entry.pos3d, game_state::esp_draw_zoom);
                if (!eft_api::is_visible(screen_pos))
                    continue;
                const ImVec4 col = entry.distance <= 5.f ? ImVec4{1.f, 0.f, 0.f, 1.f} : tripwire_color->get_value();
                snprintf(text_buf, sizeof(text_buf), "[%dm] ! Trip Wire !", static_cast<int>(entry.distance));
                esp_text::draw_simple(draw_list, hud_font, hud_font_size, {screen_pos.x, screen_pos.y}, col, text_buf,
                                      entry.distance);
            }
        }

        if (keypanel_esp->get_value())
        {
            const float key_max = keypanel_esp_distance->get_value();
            const ImVec4 key_col = keypanel_color->get_value();
            for (const auto &entry : *local_keypanels)
            {
                const float distance = my_pos.distance(entry.pos3d);
                if (distance > key_max)
                    continue;

                unity::vector3 screen_pos = eft_api::world_to_screen(cam, entry.pos3d, game_state::esp_draw_zoom);
                if (!eft_api::is_visible(screen_pos))
                    continue;

                if (entry.is_code)
                {
                    snprintf(text_buf, sizeof(text_buf), "[%dm] Code: %s", static_cast<int>(distance),
                             entry.label.c_str());
                }
                else
                {
                    snprintf(text_buf, sizeof(text_buf), "[%dm] %s", static_cast<int>(distance), entry.label.c_str());
                }

                esp_text::draw_simple(draw_list, hud_font, hud_font_size, {screen_pos.x, screen_pos.y}, key_col,
                                      text_buf, distance);
            }
        }

        const bool show_loot = loot_esp->get_value();
        const bool show_containers = container_esp->get_value();
        const bool show_container_loot = show_containers && container_show_loot->get_value();
        const bool show_corpse_loot = show_loot && corpse_show_loot->get_value();
        const float loot_max = loot_distance->get_value();
        const float container_max = container_distance->get_value();
        const bool high_value_max_range = show_loot && loot_high_value_max_range->get_value();
        const int high_value_threshold = loot_gradient_max->get_value();
        const float high_value_max = k_loot_distance_slider_max;
        const float high_value_max_sq = high_value_max * high_value_max;

        if (show_container_loot && local_containers)
        {
            // Already merged by world colocation at scan time — single stable label per stack.
            for (const auto &container : *local_containers)
            {
                if (container.distance > container_max)
                    continue;
                draw_container_entry(draw_list, cam, container, text_buf, sizeof(text_buf));
            }
        }

        if (show_corpse_loot && local_corpses)
        {
            for (const auto &corpse : *local_corpses)
            {
                if (corpse.distance > loot_max)
                    continue;
                draw_corpse_entry(draw_list, cam, corpse, text_buf, sizeof(text_buf));
            }
        }

        if (show_loot || show_containers)
        {
            const bool show_dist = show_esp_distance_labels();

            for (const auto &l : *local_loots)
            {
                if (l.is_container && show_container_loot)
                    continue;
                if (l.is_corpse_loot && show_corpse_loot)
                    continue;
                if (l.is_quest)
                    continue;

                float dist_sq = 0.f;
                if (l.is_container && l.distance > 0.f)
                    dist_sq = l.distance * l.distance;
                else
                {
                    const float dx = my_pos.x - l.pos3d.x;
                    const float dy = my_pos.y - l.pos3d.y;
                    const float dz = my_pos.z - l.pos3d.z;
                    dist_sq = dx * dx + dy * dy + dz * dz;
                }

                const float normal_max = l.is_container ? container_max : loot_max;
                const bool within_normal = dist_sq <= normal_max * normal_max;
                const bool high_value_extended = !l.is_container && high_value_max_range && high_value_threshold > 0 &&
                                                 l.price >= high_value_threshold && dist_sq <= high_value_max_sq;
                const bool show_normal =
                    (l.is_container ? show_containers : show_loot) && (within_normal || high_value_extended);

                if (!show_normal)
                    continue;

                unity::vector3 screen_pos = eft_api::world_to_screen(cam, l.pos3d, game_state::esp_draw_zoom);
                if (!eft_api::is_visible(screen_pos))
                    continue;

                const int distance = l.is_container && l.distance > 0.f ? static_cast<int>(l.distance)
                                                                        : static_cast<int>((float)sqrtf(dist_sq));

                {
                    if (show_loot_prices->get_value() && !l.is_container && l.price > 0)
                    {
                        if (show_dist)
                            snprintf(text_buf, sizeof(text_buf), "[%dm] %s (%d\xE2\x82\xBD)", distance, l.name.c_str(),
                                     l.price);
                        else
                            snprintf(text_buf, sizeof(text_buf), "%s (%d\xE2\x82\xBD)", l.name.c_str(), l.price);
                    }
                    else if (show_dist)
                    {
                        snprintf(text_buf, sizeof(text_buf), "[%dm] %s", distance, l.name.c_str());
                    }
                    else
                    {
                        snprintf(text_buf, sizeof(text_buf), "%s", l.name.c_str());
                    }

                    ImVec4 color = l.is_container
                                       ? container_color->get_value()
                                       : (l.is_corpse_loot ? loot_color->get_value()
                                                           : color_for_loot_price(l.price, l.is_quest, false));
                    if (!l.is_container && !l.is_corpse_loot &&
                        (l.cat == item_categories::kind::hideout || l.cat == item_categories::kind::wishlist) &&
                        !loot_price_gradient->get_value())
                    {
                        color = color_for_loot_category(l.cat);
                    }

                    const float sort_dist = show_dist ? static_cast<float>(distance) : 0.f;
                    if (batch_loot_labels)
                    {
                        esp_text::label entry;
                        entry.pos = {screen_pos.x, screen_pos.y};
                        entry.color = color;
                        entry.text = text_buf;
                        entry.distance = sort_dist;
                        entry.price = l.price;
                        loot_labels.push_back(std::move(entry));
                    }
                    else
                    {
                        esp_text::draw_simple(draw_list, hud_font, hud_font_size, {screen_pos.x, screen_pos.y}, color,
                                              text_buf, sort_dist);
                    }
                }
            }
        }

        if (batch_loot_labels && !loot_labels.empty())
            esp_text::draw_labels(draw_list, hud_font, hud_font_size, loot_labels, text_settings);

        // Quest Item ESP — GameWorld.QuestItemsList (independent of loot / quest POI ESP)
        if (quest_items->get_value() && !local_quest_items->empty())
        {
            const float quest_item_max = quest_item_distance->get_value();
            const float quest_item_max_sq = quest_item_max * quest_item_max;
            const ImVec4 q_color = quest_item_color->get_value();
            for (const auto &l : *local_quest_items)
            {
                const float dx = my_pos.x - l.pos3d.x;
                const float dy = my_pos.y - l.pos3d.y;
                const float dz = my_pos.z - l.pos3d.z;
                const float dist_sq = dx * dx + dy * dy + dz * dz;
                if (dist_sq > quest_item_max_sq)
                    continue;

                // Use optic-aware projection when in dual mode and inside mask
                unity::vector3 screen_pos;
                if (dual_active && game_state::esp_ads_mask_mode == 2)
                {
                    // Optic layer: use optic camera with lens renderer
                    screen_pos = eft_api::world_to_screen(cam, l.pos3d, game_state::esp_draw_zoom, lens_renderer);
                }
                else
                {
                    // Eye layer or single mode: standard projection
                    screen_pos = eft_api::world_to_screen(cam, l.pos3d, game_state::esp_draw_zoom);
                }

                if (!eft_api::is_visible(screen_pos))
                    continue;

                const int distance = static_cast<int>(sqrtf(dist_sq));
                if (show_esp_distance_labels())
                    snprintf(text_buf, sizeof(text_buf), "[QUEST] [%dm] %s", distance, l.name.c_str());
                else
                    snprintf(text_buf, sizeof(text_buf), "[QUEST] %s", l.name.c_str());
                esp_text::draw_simple(draw_list, hud_font, hud_font_size, {screen_pos.x, screen_pos.y}, q_color,
                                      text_buf, show_esp_distance_labels() ? static_cast<float>(distance) : 0.f);
            }
        }

        draw_quest_esp_overlay(draw_list, cam, *local_quest_poi, text_buf, sizeof(text_buf));

        // --- Combat layer (always above world ESP text) ---
        // Flush depth-sorted world labels first so boxes/skeletons/names paint over them.
        if (text_settings.depth_sort)
            esp_text::flush_pending_layer(draw_list, hud_font, esp_text::draw_layer::world);

        if (show_player_esp)
        {
            for (const auto &entry : *local_players)
            {
                if (entry.distance > player_max_dist)
                    continue;

                if (entry.kind == eft_api::npc_kind::pmc)
                {
                    if (!players->get_value())
                        continue;
                }
                else if (!npc->get_value())
                {
                    continue;
                }

                // Use optic-aware projection for player boxes when in dual mode and inside mask
                ImVec2 box_pos{}, box_size{}, label_anchor{};
                ImVec4 color{};

                if ((player_box->get_value() || player_health->get_value()) && entry.distance <= box_max_dist)
                {
                    // One box layout, and it is optic-aware: it picks the camera for the
                    // whole box by its centre. The former `use_optic_projection` branch
                    // here selected a second, optic-specific layout, but the condition
                    // behind it (`dual_active && esp_ads_mask_mode == 2`) was a hard
                    // `const bool = false` against a mode nothing ever sets, so the
                    // branch had been compiled away. It was not harmless: that second
                    // layout projected head and feet independently and so could mix
                    // two projections into the box height. See the note where it used
                    // to live.
                    bool drawn_scoped = true;
                    // Honour the return value. It was ignored here while the layout was
                    // void, and became meaningful when cull mode started returning false
                    // for a box centred out past the glass -- ignoring it drew a
                    // zero-size box at the origin for every culled player.
                    if (compute_player_box_layout(cam, entry, box_pos, box_size, label_anchor, color, &drawn_scoped))
                    {
                        draw_player_box_geometry(draw_list, box_pos, box_size, color, entry, drawn_scoped);
                    }
                }
            }
        }

        if (skeleton->get_value())
        {
            const float skel_max_dist = skeleton_distance->get_value();
            for (const auto &entry : *local_skeletons)
            {
                if (entry.distance > skel_max_dist)
                    continue;

                // Route through the optic-aware path whenever the optic projection is
                // live, NOT on `dual_active`.
                //
                // 2026-09-27: this was still gated on `dual_active && mode == 2`,
                // permanently false since Dual ADS was removed -- so the section 7
                // SEGMENT split inside draw_skeleton_entry_optic was UNREACHABLE and
                // logged `segs inside=0` on every single drain, while the section 7
                // POINT dispatch worked fine (it lives in world_to_screen_optic,
                // which both variants reach). My error: I put the segment split in
                // the dual-gated copy.
                //
                // Behaviour-preserving for the point path -- both variants call
                // world_to_screen with the same lens_renderer, so they differ only in
                // the segment handling this branch now selects.
                if (game_state::esp_optic_proj)
                    draw_skeleton_entry_optic(draw_list, cam, entry);
                else
                    draw_skeleton_entry(draw_list, cam, entry, lens_renderer);
            }
        }

        if (show_player_esp)
        {
            for (const auto &entry : *local_players)
            {
                if (entry.distance > player_max_dist)
                    continue;

                if (entry.kind == eft_api::npc_kind::pmc)
                {
                    if (!players->get_value())
                        continue;
                }
                else if (!npc->get_value())
                {
                    continue;
                }

                const ImVec4 color =
                    entry.kind == eft_api::npc_kind::pmc ? player_color->get_value() : get_npc_color(entry.kind);

                if ((player_box->get_value() || player_health->get_value()) && entry.distance <= box_max_dist)
                {
                    ImVec2 box_pos{};
                    ImVec2 box_size{};
                    ImVec2 label_anchor{};
                    ImVec4 box_color{};
                    if (!compute_player_box_layout(cam, entry, box_pos, box_size, label_anchor, box_color, nullptr))
                        continue;

                    // Use optic-aware projection for player labels when in dual mode and inside mask
                    if (dual_active && game_state::esp_ads_mask_mode == 2)
                    {
                        draw_player_label_text_optic(draw_list, cam, entry, color, lens_renderer);
                    }
                    else
                    {
                        draw_player_label_text(draw_list, label_anchor, color, entry, entry.distance);
                    }
                    continue;
                }

                unity::vector3 screen_pos = eft_api::world_to_screen(cam, entry.pos3d, game_state::esp_draw_zoom);
                if (!eft_api::is_visible(screen_pos))
                    continue;

                draw_player_label_text(draw_list, {screen_pos.x, screen_pos.y + 10 * menu::get_scale_factor()}, color,
                                       entry, entry.distance);
            }
        }

        if (text_settings.depth_sort)
            esp_text::flush_pending_layer(draw_list, hud_font, esp_text::draw_layer::combat);
    } // ESP draw body (was the dual/single pass loop; single pass since 2026-09-27)

    // Safety: any leftover pending text (e.g. minimap-queued) world→combat.
    if (text_settings.depth_sort)
        esp_text::flush_pending(draw_list, hud_font);

    game_state::clear_esp_ads_mask();
    eft_api::setup_esp_optic_frame(false, nullptr, 1.f, 1.f);
}

void EspModule::reset_raid_context()
{
    minimap_center_u_ = 0.5f;
    minimap_center_v_ = 0.5f;
    minimap_follow_player_ = true;
    minimap_has_last_player_pos_ = false;
    minimap_dragging_ = false;
    compass_anim_initialized_ = false;
    compass_anim_last_ms_ = 0;

    // DROP THE PLAYER POINTER. Added 2026-10-12 after the crash in pid 24116 (dump
    // EscapeFromTarkov.exe.24116.dmp), which is the first evidence that this was needed.
    //
    // The camera-resolve gate in draw_overlay() is `scene_objects_live && !cameras_are_gone`,
    // and scene_objects_live is derived ONLY from this pointer:
    //
    //     const bool scene_objects_live = (main_player_ != nullptr && main_player_->klass != nullptr);
    //
    // It is not gated on is_in_raid -- the comment above that gate explains why on purpose,
    // because is_in_raid lags the game by a window. So before this change, a pointer captured
    // in a finished raid stayed truthy for as long as the object read as non-null, and
    // draw_overlay kept calling resolve_esp_camera() on a dead raid's player from the RENDER
    // thread. The stack from that dump is unambiguous and every frame of it is a genuine
    // return address (verified against a preceding call):
    //
    //     dxhook::dxPresent11 -> dxhook::draw_imgui -> menu::draw -> ModuleManager::apply
    //       -> EspModule::draw_overlay+0x33A -> eft_api::resolve_esp_camera+0xA1
    //       -> UnityPlayer.dll+0xB97C8D          <- fault, READ of 0xFFFFFFFFFFFFFFFF
    //
    // NOT in a raid at all: zero cam-choice / vis-breakdown / vis-cone lines in that session,
    // and the fault is in UnityPlayer rather than in GameAssembly -- a different subsystem from
    // the 0x5B1DA4 crashes, reached from the render path rather than the game thread.
    //
    // Clearing here rather than adding an is_in_raid term to the gate is deliberate. The gate
    // comment records that is_in_raid was MEASURED INSUFFICIENT for teardown, and adding it
    // back would reintroduce the very window that produced the 6,913-throw incident documented
    // there (camera resolution throwing 27x/second for 253 s because the raid was over and the
    // flag had not caught up). Clearing the pointer makes scene_objects_live mean what it says:
    // "this raid has a player". One term, one meaning, no new window.
    //
    // This also covers the gap between raids without needing a second reset: draw_overlay
    // runs every PRESENTED frame while gameworld_update only runs in a raid, so the pointer is
    // null for the whole out-of-raid window, which is exactly when the crash happened.
    main_player_ = nullptr;

    clear_runtime_cache();

    if (chams_module_self)
        chams_module_self->applied_players.clear();
}

void EspModule::application_update()
{
    TA_ZONE_N("frame::EspModule::application_update");

    const uint64_t prices_version = item_pricing::get_version();
    if (prices_version != last_prices_version_)
    {
        item_info_cache.clear();
        container_item_caches_.clear();
        corpse_item_caches_.clear();
        last_prices_version_ = prices_version;
    }

    if (!game_state::is_in_raid && (last_game_world_ptr || !last_raid_location_id_.empty()))
    {
        reset_raid_context();
        last_game_world_ptr = nullptr;
        last_raid_location_id_.clear();
        current_location_id.clear();
        current_location_display_name.clear();
    }
}

void EspModule::gameworld_update(const Il2CppClass *game_world_class, Il2CppObjectInstance game_world_instance,
                                 Il2CppObjectInstance main_player)
{
    // The read half of the frame -- see the note on draw_overlay. This is also
    // the function that crashed on 2026-10-01 (the recursive data_mutex in
    // refresh_passcode_labels, called from here), so a zone on it is also how a
    // future profile would show that path's cost rather than only its existence.
    TA_ZONE_N("frame::EspModule::gameworld_update");
    // TEMPORARY (slow_frame_probe) -- must precede every timed region below.
    g_slow_frame.begin();
    // Keep the active-quest item id cache warm (10 s throttle inside).
    eft_api::refresh_active_quest_item_ids(main_player.get_instance());
    main_player_ = main_player.get_instance();

    // Reported from HERE on purpose: gameworld_update is the game thread, which is the same
    // thread is_target_visible runs on, so the counters are read by the writer and need no
    // synchronisation. Calling it from the render thread would be reading counters another
    // thread is incrementing.
    skeleton_vis::maybe_report_hit_breakdown();

    if (!minimap_configs_scanned)
    {
        minimap::scan_configs();
        minimap_configs_scanned = true;
    }

    if (prices_feature_enabled())
        item_pricing::ensure_loaded();

    current_location_id = read_location_id(game_world_class, game_world_instance);
    current_location_display_name = eft_api::try_get_location_display_name(current_location_id);
    eft_api::update_external_loot_inventory_open_cached();
    eft_api::update_ui_blocking_screen_open_cached();

    const Il2CppObject *game_world_ptr = game_world_instance.get_instance();
    const bool world_changed = game_world_ptr != last_game_world_ptr;
    const bool location_changed = !current_location_id.empty() && !last_raid_location_id_.empty() &&
                                  current_location_id != last_raid_location_id_;

    if (world_changed || location_changed)
    {
        reset_raid_context();
        if (!current_location_id.empty())
            minimap::notify_location_changed(current_location_id);
        // Once per map entry: the radar's LockedDoor markers against the game's
        // own door list (DEBUG-gated, see the function). Runs here because this
        // is the one place that knows both the map and that it just changed,
        // and because it is a game-thread read of game data.
        if (!current_location_id.empty())
            verify_static_marker_placement(current_location_id, game_world_class);
        last_game_world_ptr = game_world_ptr;
    }

    if (!current_location_id.empty())
        last_raid_location_id_ = current_location_id;

    // NO LOCAL PLAYER THIS FRAME. Added 2026-10-12 after the crash in pid 15628
    // (EscapeFromTarkov.exe.15628.dmp), where this function called
    // `Player.get_Profile()` with a null `this`.
    //
    //     GameAssembly+0x419B0E0   mov rax, qword ptr [rcx + 0x9c0]   ; rcx == NULL
    //
    // +0x9C0 is `Player.<Profile>k__BackingField` (dump.cs:276606), which is why the
    // faulting address is exactly 0x9C0 rather than the 0xFFFFFFFFFFFFFFFF sentinel the
    // other crash family reads. The game's stub does not null-check `this`.
    //
    // main_player_ is assigned from the hook argument two dozen lines above, so a null here
    // means the GAME passed a null player -- not that our cache went stale.
    //
    // SCOPE, and why it is a `return` rather than a skip of the next few lines. Everything
    // from here to the end of the function is anchored on this player: my_pos becomes the
    // viewer's origin, main_profile the inventory scope, and every projection below divides
    // by a camera resolved from them. With no player those values are not "slightly wrong",
    // they are the origin and a null profile, and the existing degenerate-origin guards
    // downstream would cull every player in the raid against the world origin -- a wrong
    // picture rather than no picture. Returning publishes nothing this frame, which is what
    // draw_overlay already does when there is no player (scene_objects_live), so the two
    // halves agree.
    //
    // NOT AN EARLY RETURN AT THE TOP: the work above this point is not player-dependent
    // and is wanted on a playerless frame -- refresh_active_quest_item_ids, the minimap
    // config scan, price loading, and the location/world change detection that drives
    // reset_raid_context(). Putting the guard at the top would silently stop all of it.
    if (!main_player_)
        return;

    const auto main_player_game_object = unity::component_get_game_object(main_player_);
    const auto main_player_transform = unity::gameobject_get_transform(main_player_game_object);
    my_pos = unity::transform_get_pos(main_player_transform);

    // get_method returns null rather than throwing on a miss, but the resolved
    // pointer was then invoked UNCONDITIONALLY at two sites below (this one and the
    // per-player profile fetch in the alive-player scan). A rename on a future build
    // turns that into a call through null, so the call is routed through one
    // null-safe shim rather than testing the pointer at each of its uses.
    //
    // The shim also tests `p`: the two call sites pass different receivers, and only
    // this one is known to be non-null (main_player_ was tested above).
    const auto get_profile = main_player.get_method<Il2CppObject *(*)(Il2CppObject *)>("get_Profile", 0);
    const auto profile_of = [get_profile](Il2CppObject* p) -> Il2CppObject* {
        return (get_profile && p) ? get_profile(p) : nullptr;
    };
    Il2CppObjectInstance main_profile(profile_of(main_player_));

    const bool skeleton_vis_enabled =
        skeleton->get_value() && skeleton_visibility->get_value() && skeleton_vis::is_ready();
    const bool box_vis_enabled = player_box->get_value() && box_visibility->get_value() && skeleton_vis::is_ready();
    // ---- FIREPORT GATE PROBE (temporary; remove once the regime is characterised) ----
    //
    // TWO QUESTIONS, and the second is about MY change rather than the game's.
    //
    // Q1, the user's: this getter runs while we are not properly placed in the world and it hogs
    // the CPU. Answered, and worse than "slow" -- duty cycle = rate_hz x mean, from pid 27516:
    //
    //     21:10:34   12 Hz  41,022 us   49% of the game thread
    //     21:16:14   24 Hz  32,652 us   78%
    //     21:18:44   25 Hz  29,815 us   75%   <- five straight minutes
    //     21:21:21  141 Hz       2 us    0%   <- and then it is gone
    //
    // At 60 fps a frame is 16.7 ms, so ONE of those calls overruns it by roughly 2x, 24 times a
    // second, on the GAME thread. That is three quarters of a core in a single managed getter,
    // and it is the whole of "slows down everything else".
    //
    // Q2, mine: the gate below is `!is_degenerate_origin(my_pos)`, TRUE only for a position
    // essentially {0,0,0}. That rests on the callee's note (an unpopulated rig must not become
    // the yardstick), NOT on a measurement of the ESP's own gate -- and the log cannot settle it,
    // because `pen-origin` is the AIMBOT's origin walk, not this one. **If my_pos is not
    // near-zero while these calls are slow, the gate does nothing and is decorative.** So the
    // probe prints my_pos and the predicate as the CALL saw them, and those two lines either
    // vindicate the gate or refute it.
    //
    // CAPTURED BEFORE THE CALL, deliberately: the gate is evaluated inside the call's own
    // expression, so sampling afterwards would report the wrong instant.
    //
    // NOT per-frame. 24 Hz for five minutes is 7,200 lines and this repo has already paid for a
    // 16,964-line flood (59% of a log). So: the first slow call of a raid, then every 64th, plus
    // ALWAYS the first fast call after a slow one -- that recovery edge is what identifies what
    // actually changed when the cost stopped.
    //
    // Game-thread state only, like the accumulator in skeleton_visibility.h. The frequency is
    // fetched ONCE, not per call: it cannot change while the process runs.
    static const long long s_fp_freq = [] {
        LARGE_INTEGER f{};
        return (QueryPerformanceFrequency(&f) && f.QuadPart > 0) ? (long long)f.QuadPart : 1LL;
    }();
    static std::atomic<unsigned> s_fp_probe_slow{0};
    static thread_local bool s_fp_probe_was_slow = false;
    static constexpr unsigned kFpProbeEveryNthSlow = 64;
    // 100 us: the healthy regime is ~1 us and the loading regime 30,000-38,000 us, so nothing
    // in between is miscounted and the first slow call of a raid always reports.
    static constexpr long long kFpProbeSlowNs = 100'000LL;

    const bool s_fp_rig_degenerate = skeleton_vis::is_degenerate_origin(my_pos);
    LARGE_INTEGER s_fp_t0{}, s_fp_t1{};
    QueryPerformanceCounter(&s_fp_t0);

    unity::vector3 vis_origin{};
    const bool has_vis_origin =
        (skeleton_vis_enabled || box_vis_enabled) &&
        skeleton_vis::try_get_visibility_origin(
            main_player.get_instance(), vis_origin, skeleton_vis::vis_origin_preference::camera_first, nullptr,
            // THE 234 s. `+12+raid+transit+crash(optic)` measured this call at 234.3 s
            // over 41,992 calls -- 91% of this function -- at 5,579 us mean, while the
            // SAME function from the aimbot's caller measured 0.5 us over 34,814 calls in
            // the same capture. 10,200x apart, same code: this is a fast function called at
            // the wrong time, and the two callers differ only in WHEN.
            //
            // Not transit, specifically. `fireport-cost` per window: raid 1 (factory4_day,
            // no transit) ran 41,022 us mean for 15.9 s starting 35 s after `Loading in at:`;
            // the transit to bigmap ran 32,652 us mean for 24.0 s x 5 windows starting 37 s
            // after its own. The shared variable is ~35-40 s of world streaming, i.e.
            // "not placed in the world yet", and 98.8% of all fireport time in the
            // session sits in that regime -- so it is essentially the whole cost.
            //
            // THE FLAG ALREADY EXISTS for this and the aimbot already passes it
            // (`!hands_not_firearm`, AimbotModule.cpp:502). The callee's own note at
            // skeleton_visibility.h:1782 calls this parameter "the ONE remaining path to
            // the 200 s, and it needs the caller to be able to say there is nothing to
            // read yet". So this is one missing argument at one call site, not a new
            // mechanism.
            //
            // `is_degenerate_origin(my_pos)` is the callee's own `has_rig` test
            // (skeleton_visibility.h:1814: the cost "is expensive exactly when has_rig
            // is false: an unpopulated rig IS the loading screen"). has_rig is computed
            // inside the callee, so it is recomputed here from the my_pos assigned at
            // :5598 -- deliberately the SAME predicate on the SAME value rather than a
            // second way of asking "is the rig populated".
            //
            // What it gives up, per the callee's note at :1817: with no reference point
            // `has_ref` stays false and the camera trust test cannot run, so the camera
            // stands unranked. That is the existing house rule for that case ("cannot
            // rank it, do not guess"), now reached deliberately instead of after a
            // 40-80 ms managed call whose answer was going to be discarded. On a
            // loading screen there is no camera to rank and no target to test.
            skeleton_vis::is_ready() && !skeleton_vis::is_degenerate_origin(my_pos));
    QueryPerformanceCounter(&s_fp_t1);
    {
        const long long s_fp_ns =
            ((s_fp_t1.QuadPart - s_fp_t0.QuadPart) * 1000000000LL) / (s_fp_freq > 0 ? s_fp_freq : 1);
        const bool s_fp_slow = s_fp_ns > kFpProbeSlowNs;
        const unsigned s_fp_n = s_fp_probe_slow.fetch_add(1, std::memory_order_relaxed);
        // Report the verdict the CALL actually used, not a recomputation of it. The call is only
        // reached when skeleton_vis_enabled || box_vis_enabled, so `has_vis_origin` already
        // carries that half of the truth.
        if (s_fp_slow ? (s_fp_n == 0 || (s_fp_n % kFpProbeEveryNthSlow) == 0) : (s_fp_probe_was_slow && !s_fp_slow))
        {
            logger::debug(std::format("esp fireport gate: {} | {:.1f} us | my_pos=({:.2f},{:.2f},{:.2f}) "
                                      "rig_degenerate={} allow_fireport_read={} | slow_calls={} vis_origin={}",
                                      s_fp_slow ? "SLOW" : "RECOVERED (fast after slow)",
                                      static_cast<double>(s_fp_ns) / 1000.0, static_cast<double>(my_pos.x),
                                      static_cast<double>(my_pos.y), static_cast<double>(my_pos.z), s_fp_rig_degenerate,
                                      !s_fp_rig_degenerate, s_fp_n, has_vis_origin ? "yes" : "no"));
        }
        s_fp_probe_was_slow = s_fp_slow;
    }

    // Read ONCE per frame here and passed into collect_skeleton, rather than re-read per
    // player per frame inside it. Declared in gameworld_update, NOT next to the
    // `skel_max_dist` of the same name in draw_overlay -- two functions in this file carry
    // near-identical tail blocks, and an earlier attempt at this line landed in
    // draw_overlay and gave `C2065: vis_check_max_dist: undeclared identifier` at the call
    // site 400 lines away.
    const float vis_check_max_dist = skeleton_vis_distance->get_value();

    // ---- view-cone cull for skeleton work ----
    //
    // THE ASYMMETRY THIS FIXES. Every other ESP item projects and culls BEFORE doing its
    // per-item work -- exfils, transits, grenades, keycards, loot, quest POIs, bot corpses,
    // and the player label at EspModule.cpp:5313 all do
    //
    //     world_to_screen(cam, pos3d, ...); if (!is_visible(screen_pos)) continue;
    //
    // The skeleton was the exception. Its gate was 3D distance only, so a skeleton -- ~17
    // bone resolutions plus ~17.6 occlusion raycasts, ~0.22 ms of game-thread time -- was
    // built for every player inside a 200 m SPHERE, including players directly behind the
    // camera, and the screen-space cull happened afterwards and PER BONE on the render
    // thread (EspModule.cpp:1188). All of that work, for a figure that draws nothing.
    //
    // YAW-ONLY, DELIBERATELY. A cone that ignored pitch would keep a target directly
    // overhead or underfoot whenever it happens to be in front horizontally, which is the
    // generous direction; adding pitch would need the camera's full rotation and would
    // cull more for no measurable gain.
    //
    // WHY THE CAMERA AND NOT THE PLAYER BODY. `my_pos` is the player transform, but the
    // view can be an optic camera -- the log shows cam='BaseOpticCamera(Clone)', a
    // different object from the player while scoped, and it is what actually frames the
    // shot. Using the player's body yaw would be wrong precisely when scoped.
    //
    // FALLS BACK TO NO CULLING if the camera or its transform is unavailable, or if the
    // target is directly overhead (horizontal length ~0), where the angle is undefined.
    // A cull that cannot prove the target is off-screen must not fire.
    //
    // 70 degrees FULL cone, as a half-angle of 35. That is 19% of a circle, so the
    // arithmetic ceiling is ~81% of skeletons skipped. The cost is pop-in at the cone
    // edge, and the edge is chosen to sit at or outside a typical 70-90 degree horizontal
    // FOV -- widen kSkeletonConeHalfAngleDeg if skeletons flicker on-screen when you turn,
    // which is the symptom, and `vis-cone:` in the 30 s report is what tells you what the
    // change is actually buying.
    constexpr float kSkeletonConeHalfAngleDeg = 50.f;
    const float cone_cos = std::cos(kSkeletonConeHalfAngleDeg * 3.14159265f / 180.f);

    // ---- WHY THE CONE DECISION IS NOT A RAW ANGLE TEST ----
    //
    // Reported on 2026-10-04: "when looking in one direction the ESP-drawn skeletons can
    // drastically change their draw-status". That is the pop-in 5.7l predicted, and the
    // prediction understated it -- a bare instantaneous angle test has NO MEMORY, so a
    // target sitting a few degrees outside the edge flips on and off every time the player
    // breathes. Two independent mechanisms remove it, and both are needed because they cover
    // different motions:
    //
    // 1. WIDER DEFAULT (50 deg half-angle = 100 deg full, was 35/70). The edge now sits
    //    OUTSIDE a typical 70-90 deg horizontal game FOV, so the boundary crossing happens
    //    off-screen where it cannot be seen. This is the fix for SLOW rotation, and it is
    //    also why the saving falls: the arithmetic ceiling goes from ~81% to ~72%.
    // 2. A FRAME GRACE. A target that leaves the cone keeps being processed for
    //    kConeGraceFrames consecutive frames before it is dropped, which absorbs quick
    //    flicks and momentary corrections -- the overwhelming majority of what a player
    //    actually does. The memo is keyed on the player POINTER, so a recycled or freed
    //    player cannot inherit a previous entity's grace, and it is cleared when a player
    //    returns inside the cone.
    //
    // Both constants are named and both are reported in `esp-cone-init:` so a tuning change
    // is visible in the log rather than inferred from culledPct.
    constexpr int kConeGraceFrames = 30; // ~0.25 s at the ~118 updates/s measured

    // 3. A STALE SWEEP, which is a CORRECTNESS measure rather than hygiene. An entity that
    //    is freed and a new one allocated at the same address would inherit the previous
    //    occupant's grace and render with someone else's hysteresis for up to 0.25 s. Keying
    //    on the pointer alone does not prevent that, only a sweep does.
    //
    //    The threshold is deliberately far above kConeGraceFrames: dropping a memo early
    //    means the player gets a FRESH full grace next time it crosses the edge, which
    //    delays a cull by 0.25 s and never causes a pop. Dropping it late costs only map
    //    space. So this is set to be cheap rather than tight -- ~40 s at the measured rate.
    constexpr unsigned long long kConeStaleTicks = 4800;
    constexpr int kConePrunePeriodTicks = 240; // ~2 s between sweeps

    // Game-thread only, in gameworld_update, and only ever advanced there -- so this is a
    // plain local static with no atomic and no cross-thread reader. Deliberately NOT
    // vis_frame_serial_: that one is the visibility gate's draw-gate clock and borrowing it
    // here would couple two unrelated things under one name.
    static unsigned long long cone_tick = 0;
    ++cone_tick;

    if ((cone_tick % kConePrunePeriodTicks) == 0 && !cone_memo_.empty())
    {
        for (auto it = cone_memo_.begin(); it != cone_memo_.end();)
            it = (cone_tick - it->second.seen > kConeStaleTicks) ? cone_memo_.erase(it) : std::next(it);
    }

    // THE CONE DIRECTION IS THE PLAYER'S OWN FORWARD, NOT A CAMERA'S.
    //
    // The first version of this took its yaw from `unity::get_current_camera()` --
    // `Camera.current` -- and that was wrong in a way the profile could not show. This
    // module does NOT draw with `Camera.current`: it resolves its own camera, which the
    // 30 s report shows succeeding every time (`cam-choice: resolves=25696 named=25696
    // fallback=0 none=0`). `Camera.current` is a different object and is not guaranteed to
    // be the one framing the shot, so its rotation is not the view direction at all. On
    // 2026-10-04 that produced, for the first ~90 s of a raid:
    //
    //   vis-cone: built=0 culled=29544 of=29544 culledPct=100%
    //
    // -- every skeleton culled, because the cone was pointing wherever that camera
    // happened to face. `Camera.current` was the only `get_current_camera()` call in this
    // whole file; it was mine, added for this cull.
    //
    // The player's body faces where the player aims, which is what "in front of the player"
    // means, and it comes from `main_player_transform` -- already resolved, already proven
    // good, since it is the transform `my_pos` was read from. No camera, no second object
    // to disagree with, and when scoped the body still faces the optic.
    //
    // READ FAILURE MUST BE DISTINGUISHABLE, or a failed read becomes a confidently wrong
    // direction -- see try_get_transform_yaw_y, which exists only for this. `false` here
    // disables the cone for the frame (fail open) rather than defaulting to +Z.
    float cone_yaw_deg = 0.f;
    const bool cone_dir_ok = try_get_transform_yaw_y(main_player_transform, cone_yaw_deg);

    // THE CONE ORIGIN, and the degenerate-read guard it needs.
    //
    // `my_pos` is `unity::transform_get_pos(main_player_transform)`, and that returns
    // exactly {0,0,0} for THREE distinct cases the caller cannot tell apart (unity.h:760):
    // a null transform, an unresolved `get_position`, and a rig that is still being placed.
    // The third is real and is raid start -- the same window in which CHANGELOG 0.9 records
    // Camera.current being independently reported to belong to a BOT.
    //
    // Left unguarded, the cone would be centred on the WORLD ORIGIN: every player's angle
    // measured from (0,0,0) somewhere arbitrary in the map, so legitimate players get
    // culled and illegitimate ones survive. A cull that cannot establish where the viewer
    // is must not fire.
    //
    // THE FIREPORT is the fallback, and it is the right one: it is resolved from
    // main_player.get_Fireport() and is therefore anchored to the local player BY
    // CONSTRUCTION, which is the property that matters here. try_get_fireport_position
    // already rejects a degenerate muzzle itself, so a `true` return is a real position.
    //
    // It is called ONLY on the degenerate path, because it performs an UNCACHED
    // resolve_method (il2utils::resolve_method has no cache, unlike resolve_field) and
    // would be a poor per-frame cost if paid every frame. Degenerate is a raid-start
    // transient, so this branch is close to never taken.
    //
    // If both fail, the cone is disabled for the frame (fail open) rather than guessing.
    unity::vector3 cone_origin = my_pos;
    bool cone_origin_ok = !skeleton_vis::is_degenerate_origin(my_pos);
    if (!cone_origin_ok)
    {
        unity::vector3 fp_pos{};
        // main_player_ is already an Il2CppObject*, NOT an Il2CppObjectInstance --
        // it is assigned from main_player.get_instance() at the top of this function.
        FIREPORT_SITE("esp/view_cone_origin");
        if (skeleton_vis::try_get_fireport_position(main_player_, fp_pos))
            cone_origin = fp_pos;
        else
            cone_origin_ok = false;
    }

    const bool cone_active = cone_dir_ok && cone_origin_ok;
    // Unity yaw: forward is (sin(yaw), 0, cos(yaw)).
    const float fwd_x = std::sin(cone_yaw_deg * 3.14159265f / 180.f);
    const float fwd_z = std::cos(cone_yaw_deg * 3.14159265f / 180.f);

    // ONE-SHOT, so a wrong direction is VISIBLE in the log on the first frame instead of
    // having to be inferred from `culledPct=100%` a minute later. This is the line whose
    // absence would have made the 06:56 bug obvious immediately.
    {
        static bool logged = false;
        if (!logged)
        {
            logged = true;
            logger::info(std::format("esp-cone-init: dirOk={} originOk={} active={} yaw={:.1f}deg "
                                     "fwd=({:.2f},{:.2f}) origin=({:.1f},{:.1f},{:.1f}) halfAngle={}deg "
                                     "graceFrames={} source=player-transform :: dirOk=false means the cone is "
                                     "OFF for this frame and nothing is culled",
                                     cone_dir_ok, cone_origin_ok, cone_active, cone_yaw_deg, fwd_x, fwd_z,
                                     cone_origin.x, cone_origin.y, cone_origin.z, kSkeletonConeHalfAngleDeg,
                                     kConeGraceFrames));
        }
    }

    // TEMPORARY (slow_frame_probe): everything above this line is the per-frame setup.
    g_slow_frame.us_setup = slow_frame_probe::since_us(g_slow_frame.t_frame);
    const auto t_loop_begin = std::chrono::steady_clock::now();

    std::vector<exfil> temp_exfils;
    std::vector<transit> temp_transits;
    std::vector<player> temp_players;
    std::vector<loot_entry> temp_loots;
    std::vector<loot_entry> temp_quest_items;
    std::vector<container_esp_entry> temp_containers;
    std::vector<container_esp_entry> temp_corpses;
    std::vector<skeleton_entry> temp_skeletons;
    std::vector<quest_esp::poi_entry> temp_quest_poi;
    std::vector<grenade_entry> temp_grenades;
    bool container_store_dirty = false;
    bool corpse_store_dirty = false;
    bool quest_poi_dirty = false;

    const bool need_exfils = extracts->get_value() || (minimap_module_self->radar->get_value() &&
                                                       minimap_module_self->radar_exfils->get_value());

    if (need_exfils)
    {
        Il2CppObjectInstance exfiltration_controller(
            game_world_instance.get_field<Il2CppObject *>("<ExfiltrationController>k__BackingField"));

        // RAW ExfiltrationPoints array, not EligiblePoints(profile): the game's
        // filter hides requirement-gated/hidden points the user wants listed.
        // Hidden item-gated extracts are labelled via their TransferItemRequirement.
        Il2CppArray *exfils = nullptr;
        {
            Il2CppObject *controller_obj = exfiltration_controller.get_instance();
            if (eft_api::is_il2cpp_object_likely_valid(controller_obj))
            {
                if (const FieldInfo *pts_field =
                        il2utils::resolve_field(controller_obj->klass, "<ExfiltrationPoints>k__BackingField"))
                {
                    exfils = *reinterpret_cast<Il2CppArray **>(reinterpret_cast<uintptr_t>(controller_obj) +
                                                               pts_field->offset);
                }
            }
        }

        // Secret (hidden) exfils live in a SEPARATE controller array —
        // <SecretExfiltrationPoints>k__BackingField — never in EligiblePoints
        // or ExfiltrationPoints. Merge them: same status/requirement handling,
        // so item-gated secret extracts read "Available: need Item X".
        Il2CppArray *secret_exfils = nullptr;
        if (eft_api::is_il2cpp_object_likely_valid(exfiltration_controller.get_instance()))
        {
            if (const FieldInfo *sf = il2utils::resolve_field(exfiltration_controller.get_instance()->klass,
                                                              "<SecretExfiltrationPoints>k__BackingField"))
            {
                secret_exfils = *reinterpret_cast<Il2CppArray **>(
                    reinterpret_cast<uintptr_t>(exfiltration_controller.get_instance()) + sf->offset);
            }
        }

        const size_t total_exfils = (exfils ? exfils->max_length : 0) + (secret_exfils ? secret_exfils->max_length : 0);
        if (total_exfils > 0)
        {
            temp_exfils.reserve(total_exfils);
            // ONCE per frame here, ABOVE the loop -- both EligiblePoints(Profile) and
            // SecretEligiblePoints() build a filtered array, so calling either per exfil would
            // be quadratic in the number of extracts for no benefit. Previously this sat
            // inside the two-iteration loop below while a comment claimed it did not.
            //
            // `main_player_` supplies the Profile that `EligiblePoints` requires; without it
            // the regular list is not taken and eligibility stays `unknown`, so the labels
            // fall back to the status byte rather than reporting everything "Blocked".
            eft_api::refresh_exfil_eligibility(exfiltration_controller.get_instance(), main_player_);

            for (size_t array_i = 0; array_i < 2; ++array_i)
            {
                Il2CppArray *arr = array_i == 0 ? exfils : secret_exfils;
                if (!arr)
                    continue;
                for (size_t i = 0; i < arr->max_length; ++i)
                {
                    Il2CppObject *exfil = reinterpret_cast<Il2CppObject **>(&arr->data)[i];
                    if (!exfil)
                        continue;
                    Il2CppObjectInstance exfiltration_point(exfil);

                    // Status is a BYTE (ISIL: movzx eax,byte ptr [rcx+58h]) and, more
                    // importantly, status is not eligibility. `EligiblePoints()` is the game's
                    // own answer to "may this player leave by it right now"; see
                    // eft_api::exfil_eligibility_of for the full reasoning. One refresh here,
                    // because this is the only per-frame site that already holds the controller.
                    const int status = eft_api::get_exfil_status(exfil);
                    // ONE pass over the point for its name, its kind, and its required item. This replaces two
                    // separate calls (display name + item requirement) because adding a third for
                    // the scav-coop test would have meant three walks of `Requirements`.
                    const eft_api::exfil_label_parts parts = eft_api::try_get_exfil_label_parts(exfil);

                    const eft_api::exfil_eligibility eligibility = eft_api::exfil_eligibility_of(exfil);
                    Il2CppObject *game_object = unity::component_get_game_object(exfiltration_point.get_instance());
                    Il2CppObject *tranform = unity::gameobject_get_transform(game_object);

                    temp_exfils.push_back({parts.name, status, unity::transform_get_pos(tranform), parts.item,
                                           parts.secret, parts.scav_coop, eligibility});
                }
            }
        }
    }

    const bool need_transits = transits->get_value() || (minimap_module_self->radar->get_value() &&
                                                         minimap_module_self->radar_exfils->get_value());

    if (need_transits)
    {
        Il2CppObjectInstance transit_controller(
            game_world_instance.get_field<Il2CppObject *>("<TransitController>k__BackingField"));
        const auto transits_by_id = transit_controller.get_field<unity::dict<int, Il2CppObject *> *>("pointsById");

        if (transits_by_id && transits_by_id->m_i_count > 0)
        {
            temp_transits.reserve(transits_by_id->m_i_count);
            for (int i = 0; i < transits_by_id->m_i_count; ++i)
            {
                Il2CppObjectInstance transit(transits_by_id->get_value_by_index(i));
                const std::string location = eft_api::try_get_transit_display_name(transit.get_instance());

                Il2CppObject *transit_game_object = unity::component_get_game_object(transit.get_instance());
                Il2CppObject *transit_transform = unity::gameobject_get_transform(transit_game_object);

                temp_transits.push_back({location, unity::transform_get_pos(transit_transform)});
            }
        }
    }

    const bool need_players = players->get_value() || npc->get_value() || minimap_module_self->radar->get_value() ||
                              skeleton->get_value() || player_box->get_value() || player_health->get_value();

    if (need_players)
    {
        Il2CppArray *alive_players =
            game_world_instance.get_field<unity::list *>("AllAlivePlayersList")->m_p_list_array;

        if (alive_players && alive_players->max_length > 0)
        {
            temp_players.reserve(alive_players->max_length);
            for (size_t i = 0; i < alive_players->max_length; ++i)
            {
                Il2CppObject *player_object = reinterpret_cast<Il2CppObject **>(&alive_players->data)[i];
                if (!player_object)
                    continue;
                Il2CppObjectInstance player_instance(player_object);

                Il2CppObject *profile_ptr = profile_of(player_instance.get_instance());
                if (!profile_ptr)
                    continue;
                Il2CppObjectInstance profile_instance(profile_ptr);

                // Swept to the checked accessor 2026-10-14 -- the last of the
                // audit's 96. A null Nickname resolve used to be a call to
                // address 0x0 on the ESP's own draw path; the fail-closed value
                // is an empty string, which the code below already tolerates
                // (a nickname is a label, not an identity -- see the comment
                // that follows).
                const std::wstring nickname_wide =
                    il2utils::conv_wstring(profile_instance.call_or<Il2CppString*>(
                        "get_Nickname", 0, nullptr));
                // Do not use a nickname to identify the local player:
                // AI can share a generated name and new spawns may have an
                // empty name briefly, which used to hide them from ESP.
                if (player_object == main_player_)
                    continue;

                Il2CppObject *player_game_object = unity::component_get_game_object(player_instance.get_instance());
                if (!player_game_object)
                    continue;
                Il2CppObject *player_transform = unity::gameobject_get_transform(player_game_object);
                if (!player_transform)
                    continue;

                // TEMPORARY (slow_frame_probe): the per-player identity/label/health work
                // below is the largest unzoned block on this path and is what the 447 ms
                // self-time outlier most plausibly is.
                const auto t_row = std::chrono::steady_clock::now();

                const bool is_pmc = eft_api::try_detect_is_pmc(player_object);
                const int profile_side = eft_api::get_profile_side(profile_ptr);
                const unity::vector3 player_pos = unity::transform_get_pos(player_transform);
                const float distance = my_pos.distance(player_pos);
                const bool minimap_bot_names = minimap_module_self && minimap_module_self->radar->get_value() &&
                                               minimap_module_self->radar_minimap_bot_names->get_value();
                const eft_api::player_label label = eft_api::build_player_label(
                    is_pmc, nickname_wide, static_cast<int>(distance), show_bot_names->get_value() || minimap_bot_names,
                    profile_ptr, player_object, profile_side);

                unity::vector3 head_pos = player_pos;
                eft_api::try_get_head_position(player_object, head_pos);

                eft_api::health_value health{};
                bool is_alive = true;
                if (player_health->get_value() && distance <= box_distance->get_value())
                    eft_api::try_get_player_health(player_object, health, is_alive);

                // THE VIEW-CONE DECISION, made ONCE per player per frame and carried on the
                // entry (player::in_view_cone). Both consumers -- the skeleton build gate
                // below and the store-side filter before publish -- read that flag instead
                // of recomputing the angle, so they cannot disagree.
                bool in_cone = true;
                if (cone_active)
                {
                    const float dx = player_pos.x - cone_origin.x;
                    const float dz = player_pos.z - cone_origin.z;
                    const float horiz = std::sqrt(dx * dx + dz * dz);
                    // horiz ~0 means directly above or below: the horizontal angle is
                    // undefined, and a cull that cannot prove "off-screen" must not fire.
                    if (horiz > 0.01f)
                    {
                        const auto key = reinterpret_cast<uintptr_t>(player_object);
                        if (((fwd_x * dx + fwd_z * dz) / horiz) >= cone_cos)
                        {
                            in_cone = true;
                            // Back inside, so the grace is spent: DROP the entry rather than
                            // storing a zero. Most players are inside the cone most of the
                            // time, so this is the path that must not allocate -- an
                            // unconditional cone_memo_[key] here (the first version) inserts
                            // an entry for every player entity every tick and never releases
                            // one, which grows for the whole raid for no benefit.
                            if (auto it = cone_memo_.find(key); it != cone_memo_.end())
                                cone_memo_.erase(it);
                        }
                        else
                        {
                            // Outside: this is the only path that creates state. The entity
                            // stays in the map while it remains outside -- including after its
                            // grace is exhausted -- which is what makes cone_prune_stale()
                            // below necessary rather than optional.
                            auto &memo = cone_memo_[key];
                            memo.seen = cone_tick;
                            if (memo.outside_frames < kConeGraceFrames)
                            {
                                // Inside the grace window: keep processing a target that has
                                // only just left the cone, so a quick flick cannot make it
                                // vanish.
                                in_cone = true;
                                ++memo.outside_frames;
                            }
                            else
                            {
                                in_cone = false;
                            }
                        }
                    }
                }

                bool any_part_visible = true;
                if (box_vis_enabled && has_vis_origin && distance <= box_distance->get_value())
                {
                    // TEMPORARY (slow_frame_probe): timed apart from the row because it is
                    // the one part of the row that calls into the visibility raycaster.
                    const auto t_box = std::chrono::steady_clock::now();
                    any_part_visible = is_player_any_part_visible(vis_origin, player_object, main_player_);
                    g_slow_frame.us_box += slow_frame_probe::since_us(t_box);
                }

                g_slow_frame.add_row(slow_frame_probe::since_us(t_row));

                temp_players.push_back({label.text_wide, label.prefix_utf8, label.name_utf8, label.text_utf8,
                                        label.show_name_line, label.kind, player_pos, head_pos, distance,
                                        health.current, health.maximum, is_alive, any_part_visible, in_cone});

                ++g_slow_frame.players;

                if (skeleton->get_value() && distance <= skeleton_distance->get_value())
                {
                    if (in_cone)
                    {
                        ++skeleton_vis::g_vis_cone_built();
                        // TEMPORARY (slow_frame_probe)
                        const auto t_skel = std::chrono::steady_clock::now();
                        // auto skel = collect_skeleton(player_object, label.kind, distance);
                        auto skel = collect_skeleton(player_object, label.kind, distance,
                                                     skeleton_vis_enabled && has_vis_origin, vis_origin, main_player_,
                                                     vis_check_max_dist);
                        g_slow_frame.us_skel += slow_frame_probe::since_us(t_skel);
                        if (!skel.bones.empty())
                            temp_skeletons.push_back(std::move(skel));
                    }
                    else
                    {
                        ++skeleton_vis::g_vis_cone_culled();
                    }
                }
            }
        }
    }

    // TEMPORARY (slow_frame_probe): the enumeration is done; everything after here is
    // the post-loop scan block, which has no zones on it either.
    g_slow_frame.us_loop = slow_frame_probe::since_us(t_loop_begin);

    // TEMPORARY (slow_frame_probe): t_misc brackets the small unzoned scans below, which
    // are candidates for the tail remainder that quest_poi_scan and
    // loot_and_container_scan did not explain. One bucket for all three because they are
    // individually cheap and separately uninteresting -- if this is not the answer, the
    // publish() group is.
    const auto t_misc = std::chrono::steady_clock::now();
    if (grenade_esp->get_value())
        scan_grenade_esp(game_world_instance, my_pos, temp_grenades);

    std::vector<tripwire_entry> temp_tripwires;
    if (tripwire_esp->get_value())
        scan_tripwire_esp(game_world_instance, my_pos, temp_tripwires);

    // Keycard/code panels: FindObjectsOfType once when enabled (no periodic rescan).
    // Passcode codes may arrive late — cheap label refresh only (no FOT).
    std::vector<keypanel_entry> temp_keypanels;
    bool keypanel_dirty = false;
    {
        TA_ZONE_N("esp_scan::keypanel_scan");
        if (keypanel_esp->get_value())
        {
            if (!keypanel_scanned_once_)
            {
                scan_keypanel_esp(game_world_instance, temp_keypanels);
                keypanel_scanned_once_ = true;
                keypanel_dirty = true;
            }
            else
            {
                // Update Code labels from controller without re-scanning the scene.
                //
                // The lock is taken HERE and spans the whole call, because
                // refresh_passcode_labels reads and republishes keypanel_store and
                // no longer locks it itself. It used to lock internally as well,
                // which with this outer lock was a recursive acquisition of a
                // non-recursive std::mutex -- the crash of 2026-10-01 09:01, which
                // the probe reported as std::system_error thrown from this path.
                std::lock_guard<std::mutex> lock(data_mutex);
                refresh_passcode_labels(game_world_instance);
            }
        }
        else if (keypanel_scanned_once_ || !keypanel_store->empty())
        {
            temp_keypanels.clear();
            keypanel_scanned_once_ = false;
            keypanel_dirty = true;
        }
    } // esp_scan::keypanel_scan
    // TEMPORARY (slow_frame_probe): closes the grenade/tripwire/keypanel bucket.
    g_slow_frame.us_misc += slow_frame_probe::since_us(t_misc);

    // ESP scan pacing (Configs → game_state). Manual mode freezes list rebuild until refresh.
    const ULONGLONG now_esp = GetTickCount64();
    const bool manual_esp = game_state::esp_manual_refresh_mode;
    const bool force_esp_refresh = game_state::esp_manual_refresh_request;
    if (force_esp_refresh)
        game_state::esp_manual_refresh_request = false;
    bool loot_scanned = false;
    bool quest_items_scanned = false;
    bool containers_scanned = false;

    // Dedicated quest-item list (HashSet<LootItem> QuestItemsList) — own toggle, not loot ESP.
    const ULONGLONG quest_items_interval = eft_api::esp_scaled_interval_ms(500, game_state::esp_loot_update_rate);
    const bool do_quest_items = quest_items->get_value() && (!manual_esp || force_esp_refresh) &&
                                (force_esp_refresh || quest_items_last_scan_ms_ == 0 ||
                                 now_esp - quest_items_last_scan_ms_ >= quest_items_interval);
    if (do_quest_items)
    {
        // Zoned with the rest of the unzoned post-loop blocks. The phase probe has left a
        // stable 209-214 us-per-ms remainder unattributed across three sessions, and the
        // candidates are exactly the blocks in this half of the function that carry no
        // zone: this one, the publish() group, scan_bot_corpses_for_minimap, and the
        // grenade/tripwire/keypanel scans. Naming them is cheaper than another guess.
        TA_ZONE_N("esp_scan::quest_items_scan");
        quest_items_last_scan_ms_ = now_esp;
        quest_items_scanned = true;
        static auto *qi_assembly = il2utils::resolve_image("Assembly-CSharp.dll");
        static auto *qi_loc_class =
            qi_assembly ? il2utils::resolve_class(qi_assembly, "EFT", "LocalizationExtensions") : nullptr;
        static auto qi_short_name =
            qi_loc_class
                ? il2utils::get_method<Il2CppString *(*)(Il2CppObject *)>(qi_loc_class, "LocalizedShortName", 1)
                : nullptr;

        auto *quest_set = game_world_instance.get_field<unity::hashset<Il2CppObject *> *>("QuestItemsList");
        if (quest_set && quest_set->m_p_slots)
        {
            const float qmax = quest_item_distance->get_value();
            const float qmax_sq = qmax * qmax;
            auto *slots = quest_set->get_slots();
            const int last = quest_set->m_i_last_index;
            if (last > 0)
                temp_quest_items.reserve(static_cast<size_t>(last));

            for (int i = 0; i < last; ++i)
            {
                if (slots[i].m_i_hash_code < 0)
                    continue;
                Il2CppObject *loot_obj = slots[i].m_t_value;
                if (!eft_api::is_il2cpp_object_likely_valid(loot_obj))
                    continue;

                Il2CppObject *game_object = unity::component_get_game_object(loot_obj);
                if (!game_object)
                    continue;
                Il2CppObject *transform = unity::gameobject_get_transform(game_object);
                if (!transform)
                    continue;

                const unity::vector3 pos = unity::transform_get_pos(transform);
                const float dx = my_pos.x - pos.x;
                const float dy = my_pos.y - pos.y;
                const float dz = my_pos.z - pos.z;
                const float dist_sq = dx * dx + dy * dy + dz * dz;
                if (dist_sq > qmax_sq)
                    continue;

                std::string name = "Quest Item";
                Il2CppObjectInstance quest_loot_instance(loot_obj);
                Il2CppObject *item_obj = quest_loot_instance.get_field<Il2CppObject *>("_item");
                if (item_obj && qi_short_name)
                {
                    if (Il2CppString *name_str = qi_short_name(item_obj))
                    {
                        name = eft_api::to_display_utf8(il2utils::conv_wstring(name_str));
                        if (name.empty())
                            name = "Quest Item";
                    }
                }

                temp_quest_items.push_back({std::move(name), pos, false, 0, true, sqrtf(dist_sq), false});
            }
        }
    }

    const ULONGLONG loot_scan_interval = eft_api::esp_scaled_interval_ms(250, game_state::esp_loot_update_rate);
    // True while there's loot-scan work to do this tick: either a fresh cycle is
    // due to start, or one is already in flight and must keep advancing (a cycle
    // spans multiple ticks — see the chunked loop below).
    const bool do_loot_scan = loot_esp->get_value() && (!manual_esp || force_esp_refresh) &&
                              (loot_scan_active_ || force_esp_refresh || loot_esp_last_scan_ms_ == 0 ||
                               now_esp - loot_esp_last_scan_ms_ >= loot_scan_interval);

    const ULONGLONG container_tick_base = eft_api::esp_scaled_interval_ms(2000, game_state::esp_container_update_rate);
    const ULONGLONG container_discovery_base =
        eft_api::esp_scaled_interval_ms(30000, game_state::esp_container_update_rate);
    // Early-raid ramp for container discovery. `container_discovery_base` is 120 s, and the
    // registry is FROZEN between scans -- so at t=0 the first scan runs against a map whose
    // containers mostly have not had Init() called yet (is_container_actually_placed rejects
    // them as ghosts), and the ones the game initialises over the next two minutes stay
    // invisible until the 120 s rescan. That is the "containers appear late" report.
    //
    // So: scan fast while the registry is still filling, then back off to the steady state.
    // The first scan is NOT delayed -- it already runs on the first tick, because
    // `container_registry_.empty()` is one of the conditions below. Delaying it would make
    // this strictly worse, which is why the ramp shortens the WAIT rather than lengthening
    // the start.
    constexpr ULONGLONG kContainerRampWindowMs = 30000;
    // 2000 -> 3500 on 2026-10-09. Measured: `esp_scan::container_find_objects`
    // averages 85.8 ms over 12 calls and peaks at 95.8 ms, and it is 97.4% of
    // container_scan -- unity::find_objects_of_type is a scene-wide search
    // returning every LootableContainer prefab in the scene, ghosts included.
    // At 2 s over a 30 s window that is ~15 discoveries, so ~1.3 s of stalls
    // concentrated in the first 30 seconds of every raid, which is the worst
    // possible moment for one.
    //
    // This does NOT make the search cheaper, it makes it rarer, and that is a
    // straight trade: fewer discoveries inside the window means a later
    // registry. The window exists because a flat 120 s "froze the registry
    // while the game was still filling it" (AGENTS_TODO), so the interval
    // cannot simply go back up. 3.5 s still fires ~8 times inside the window.
    //
    // The structural fix is not available from here: find_objects_of_type is a
    // single atomic IL2CPP call returning the whole array, so it cannot be
    // chunked across frames the way the ground-loot scan is. A cheaper
    // discovery source would have to come from the game side.
    constexpr ULONGLONG kContainerRampIntervalMs = 3500;
    const ULONGLONG container_loot_refresh_base =
        eft_api::esp_scaled_interval_ms(60000, game_state::esp_container_update_rate);
    const bool do_container_scan =
        container_esp->get_value() && (!manual_esp || force_esp_refresh) &&
        (force_esp_refresh || container_last_tick_ms_ == 0 || now_esp - container_last_tick_ms_ >= container_tick_base);

    // TEMPORARY (slow_frame_probe): t_loot spans the loot/container scan below, the
    // only large block left in `tail` now that refresh_cache_stats is measured at 4 us.
    const auto t_loot = std::chrono::steady_clock::now();
    if (do_loot_scan || do_container_scan || (container_esp->get_value() && !do_container_scan))
    {
        // Zoned because this is the only large block in gameworld_update's post-loop
        // half that had no zone on it at all, and the phase probe put 514 of the frame's
        // 538 ms in `tail`. Its first candidate -- refresh_cache_stats -- was measured
        // at 4 us and is innocent (esp_scan::refresh_cache_stats: 14 calls, max 4.19 us),
        // which leaves this 573-line block as the only thing in `tail` big enough to
        // account for it. Whether it IS the cost is what this zone answers.
        TA_ZONE_N("esp_scan::loot_and_container_scan");
        const float loot_min = loot_min_distance->get_value();
        const float min_dist_sq = loot_min * loot_min;

        if (do_loot_scan)
        {
            static auto *assembly_csharp = il2utils::resolve_image("Assembly-CSharp.dll");
            static auto *localization_extensions_class =
                il2utils::resolve_class(assembly_csharp, "EFT", "LocalizationExtensions");
            static auto localized_short_name = il2utils::get_method<Il2CppString *(*)(Il2CppObject *)>(
                localization_extensions_class, "LocalizedShortName", 1);

            // Re-bind every tick — the game may reallocate the backing array while
            // a multi-tick cycle is in flight (loot despawning/spawning mid-scan).
            Il2CppArray *loot_array = nullptr;
            Il2CppObject *loot_hydra_obj = game_world_instance.get_field<Il2CppObject *>("LootItems");
            if (loot_hydra_obj)
            {
                Il2CppObjectInstance loot_hydra(loot_hydra_obj);
                if (unity::list *loot_list = loot_hydra.get_field<unity::list *>("_iteration"))
                    loot_array = loot_list->m_p_list_array;
            }

            if (!loot_array)
            {
                // Matches the pre-chunking behavior: treat "no list yet" (e.g. not
                // in raid) as a completed empty scan and restart the interval clock.
                loot_scanned = true;
                loot_esp_last_scan_ms_ = now_esp;
                loot_scan_active_ = false;
                loot_scan_cursor_ = 0;
                loot_scan_accum_.clear();
            }
            else
            {
                if (!loot_scan_active_)
                {
                    loot_scan_active_ = true;
                    loot_scan_cursor_ = 0;
                    loot_cycle_start_seq_ = loot_sweep_seq_;
                    loot_scan_accum_.clear();
                    loot_scan_accum_.reserve(static_cast<size_t>(loot_array->max_length));
                    ensure_wishlist_sets(main_profile.get_instance(), force_esp_refresh);
                }

                const size_t bound = static_cast<size_t>(loot_array->max_length);
                if (loot_scan_cursor_ > bound)
                    loot_scan_cursor_ = bound;

                const float loot_normal_max = loot_distance->get_value();
                const float loot_normal_max_sq = loot_normal_max * loot_normal_max;
                const bool high_value_max_range = loot_high_value_max_range->get_value();
                const int high_value_threshold = loot_gradient_max->get_value();
                // When high-value max-range is on, scan up to slider max so expensive items beyond normal distance are
                // found.
                const float loot_scan_max = high_value_max_range ? k_loot_distance_slider_max : loot_normal_max;
                const float loot_max_dist_sq = loot_scan_max * loot_scan_max;
                const bool scan_corpse_loot = corpse_show_loot->get_value();

                // Background scans are spread over multiple ticks so a loot-dense map
                // never stalls a single frame. Force-refresh drains the whole list
                // this tick since the user explicitly asked for an immediate update
                // (same one-shot contract as the quest-item POI scan's force path).
                constexpr size_t loot_scan_chunk = 256;
                const size_t chunk_end =
                    force_esp_refresh ? bound : (std::min)(loot_scan_cursor_ + loot_scan_chunk, bound);

                TA_ZONE_N("esp_scan::loot_scan");
                const uint64_t sweep_seq = ++loot_sweep_seq_;
                for (size_t i = loot_scan_cursor_; i < chunk_end; ++i)
                {
                    Il2CppObject *loot_obj = reinterpret_cast<Il2CppObject **>(&loot_array->data)[i];
                    if (!loot_obj)
                        continue;

                    // ------------------------------------------------------------------
                    // Cached pointer chain.
                    //
                    // THREE managed-side operations per item per cycle are cached
                    // here: class_name_contains, component_get_game_object and
                    // gameobject_get_transform. Their RESULTS are immutable for a
                    // given object -- only the POSITION moves, so it is deliberately
                    // NOT cached and is still re-read every cycle below. That is the
                    // distinction that makes this safe on a map where loot shifts:
                    // caching the position would need a staleness bound tied to
                    // player movement, and would be wrong whenever it guessed.
                    //
                    // gameobject_get_transform is GetComponent(Type), which walks the
                    // component list comparing types; it is the most expensive of the
                    // three and is now paid once per object rather than once per cycle.
                    // ------------------------------------------------------------------
                    auto &node = loot_node_cache_[loot_obj];
                    node.last_seen = sweep_seq;
                    Il2CppObject *transform = nullptr;
                    const bool cached = loot_node_cache_valid(node, loot_obj, scan_corpse_loot);
                    if (cached)
                    {
                        if (scan_corpse_loot && node.is_corpse)
                            continue;
                        transform = node.transform;
                    }
                    else
                    {
                        {
                            TA_ZONE_N("esp_scan::loot_chain_resolve");
                            const bool is_corpse = eft_api::class_name_contains(loot_obj, "Corpse");
                            node.is_corpse = is_corpse;
                            node.corpse_tested = scan_corpse_loot;
                            if (scan_corpse_loot && is_corpse)
                                continue;

                            Il2CppObject *game_object = unity::component_get_game_object(loot_obj);
                            if (!game_object)
                                continue;
                            transform = unity::gameobject_get_transform(game_object);
                            if (!transform)
                                continue;
                            node.klass = loot_obj->klass;
                            node.transform = transform;
                            node.chain_ok = true;
                        }
                    }

                    unity::vector3 pos;
                    {
                        TA_ZONE_N("esp_scan::loot_pos_read");
                        pos = unity::transform_get_pos(transform);
                    }

                    const float dx = my_pos.x - pos.x;
                    const float dy = my_pos.y - pos.y;
                    const float dz = my_pos.z - pos.z;
                    const float dist_sq = dx * dx + dy * dy + dz * dz;

                    if (dist_sq < min_dist_sq || dist_sq > loot_max_dist_sq)
                        continue;

                    // Only items that survived the distance gate reach here. Zoned
                    // separately because this is the only part of the scan that
                    // allocates and calls into managed localisation -- and because
                    // "the rejected items cost nothing" is a claim worth being able
                    // to check rather than assume.
                    TA_ZONE_N("esp_scan::loot_identify");
                    Il2CppObjectInstance loot_instance(loot_obj);
                    Il2CppObject *item_obj = loot_instance.get_field<Il2CppObject *>("_item");
                    if (!item_obj)
                        continue;

                    const bool is_corpse_loot = eft_api::is_bot_corpse_loot(loot_obj, item_obj);

                    std::string item_name = "item_mod";
                    int item_market_price = 0;
                    bool is_provision = false;

                    const bool is_money = eft_api::try_get_item_is_money(item_obj);
                    std::string item_template_id;

                    auto cache_it = item_info_cache.find(item_obj);
                    if (cache_it != item_info_cache.end())
                    {
                        item_name = cache_it->second.name;
                        item_market_price = cache_it->second.price;
                        is_provision = cache_it->second.is_provision;

                        // Reuse the cached template id; resolve+store once if absent.
                        item_template_id = cache_it->second.template_id;
                        if (item_template_id.empty())
                        {
                            item_template_id = eft_api::try_get_item_template_id(item_obj);
                            cache_it->second.template_id = item_template_id;
                        }

                        // Money stacks can change — always re-resolve face*stack.
                        if (is_money || (item_market_price == 0 && item_pricing::has_prices()))
                        {
                            item_market_price = item_pricing::resolve_item_sell_price(item_obj, item_template_id);
                            cache_it->second.price = item_market_price;
                        }
                    }
                    else
                    {
                        // Cache the provision flag per class name to avoid strstr on every
                        // uncached item. Class names are the same for all items of the same type.
                        static std::unordered_map<std::string, bool> provision_class_cache;
                        if (item_obj->klass && item_obj->klass->name)
                        {
                            const char *cls_name = item_obj->klass->name;
                            auto it = provision_class_cache.find(cls_name);
                            if (it != provision_class_cache.end())
                            {
                                is_provision = it->second;
                            }
                            else
                            {
                                is_provision =
                                    (strstr(cls_name, "Food") != nullptr || strstr(cls_name, "Drink") != nullptr);
                                provision_class_cache.emplace(cls_name, is_provision);
                            }
                        }

                        // Resolve the template id ONCE per first encounter (audit 09-25 #3:
                        // it used to be resolved a second time below for classify/filter).
                        item_template_id = eft_api::try_get_item_template_id(item_obj);
                        // Money: always resolve (no flea). Others: only if price table loaded.
                        if (is_money || item_pricing::has_prices())
                            item_market_price = item_pricing::resolve_item_sell_price(item_obj, item_template_id);

                        if (localized_short_name)
                        {
                            Il2CppString *name_str = localized_short_name(item_obj);
                            if (name_str)
                            {
                                item_name = eft_api::to_display_utf8(il2utils::conv_wstring(name_str));
                                if (item_name.empty())
                                    item_name = "item_mod";
                            }
                        }

                        item_info_cache[item_obj] = {item_name, item_market_price, is_provision, is_corpse_loot,
                                                     item_template_id};
                    }

                    // "Food & Drink" (category index 4) is also filtered later by
                    // loot_ui_filter_allowed(), but this check runs first — without this
                    // OR, explicitly picking that category while Show Food & Water stays
                    // off (its default) always yielded zero results, silently, since every
                    // provision item was already skipped here before the category switch
                    // was ever reached.
                    bool wants_provisions = show_provisions->get_value() ||
                                            (loot_category_filter->get_value() == 4);

                    if (is_provision && !wants_provisions)
                        continue;
                    // Cash always shown; corpse loot / provisions bypass min-value.
                    bool bypass_filter = is_money || is_corpse_loot || (is_provision && wants_provisions);
                    // price==0 with flea loaded used to hide everything unlisted (incl. cash).
                    if (!bypass_filter && item_pricing::has_prices() && item_market_price > 0 &&
                        item_market_price < loot_min_value->get_value())
                        continue;

                    // Beyond normal loot distance: keep only high-value items (price >= gradient max).
                    if (dist_sq > loot_normal_max_sq)
                    {
                        if (!high_value_max_range || high_value_threshold <= 0 ||
                            item_market_price < high_value_threshold)
                            continue;
                    }

                    // Already resolved above (cache hit or first encounter) — no re-walk.
                    const std::string &template_id = item_template_id;
                    const item_categories::kind cat = classify_template(template_id);
                    // One more question asked of the same resolved set -- classify_template is
                    // a hash probe, so this costs no second walk of the wishlist.
                    const item_categories::wishlist_group wl_group =
                        item_categories::classify_group(template_id, wishlist_sets_);
                    if (!loot_category_allowed(cat, wl_group))
                        continue;
                    if (!loot_ui_filter_allowed(template_id, item_name))
                        continue;

                    // Dormant quest spawns: the game keeps the loot object in
                    // the world but hides it until the quest starts — skip
                    // quest-flagged items that no started quest targets.
                    const bool quest_flagged = eft_api::try_get_item_is_quest(item_obj);
                    if (quest_flagged && !template_id.empty() && !eft_api::is_active_quest_item_id(template_id))
                        continue;

                    loot_entry le;
                    le.name = std::move(item_name);
                    le.pos3d = pos;
                    le.is_container = false;
                    le.price = item_market_price;
                    le.is_quest = quest_flagged;
                    le.distance = 0.f;
                    le.is_corpse_loot = is_corpse_loot;
                    le.cat = cat;
                    le.wl = wl_group;
                    le.template_id = template_id;
                    loot_scan_accum_.push_back(std::move(le));
                }
                loot_scan_cursor_ = chunk_end;

                if (loot_scan_cursor_ >= bound)
                {
                    // Cycle complete: publish the accumulated results and start the
                    // interval countdown for the next cycle.
                    loot_scanned = true;

                    // Evict chain-cache entries for objects that did not appear ANYWHERE in
                    // the cycle that just finished. Without this the cache is a slow
                    // leak: looted, despawned and map-transitioned objects would stay
                    // resident for the life of the raid.
                    //
                    // The horizon is the cycle's starting sweep sequence, NOT a fixed
                    // number of chunks back. The first version used `sweep_seq - 2` and
                    // measured a 79% miss rate, because a cycle is a variable number of
                    // chunks: with an 80-per-chunk average against a ~417-item array a
                    // cycle is ~5 chunks, so a 2-chunk horizon evicted every item ~3
                    // chunks before its next scheduled visit. The cache could not hit
                    // even in principle.
                    for (auto it = loot_node_cache_.begin(); it != loot_node_cache_.end();)
                        it = (it->second.last_seen <= loot_cycle_start_seq_)
                                ? loot_node_cache_.erase(it)
                                : std::next(it);
                    temp_loots.insert(temp_loots.end(), std::make_move_iterator(loot_scan_accum_.begin()),
                                      std::make_move_iterator(loot_scan_accum_.end()));
                    loot_scan_accum_.clear();
                    loot_scan_active_ = false;
                    loot_scan_cursor_ = 0;
                    loot_esp_last_scan_ms_ = now_esp;

                    if (scan_corpse_loot)
                    {
                        ensure_wishlist_sets(main_profile.get_instance(), force_esp_refresh);
                        update_corpse_loot_esp(game_world_instance, temp_corpses, corpse_store_dirty,
                                               force_esp_refresh);
                    }
                }
            }
        }
        else if (!loot_esp->get_value() && corpse_show_loot->get_value())
        {
            // Only clear when loot ESP is fully off (not when rate/manual skipped a tick).
            loot_scan_active_ = false;
            loot_scan_cursor_ = 0;
            loot_scan_accum_.clear();
            corpse_registry_.clear();
            corpse_item_caches_.clear();
            corpse_loot_refresh_cursor_ = 0;
            corpse_last_tick_ms_ = 0;
            corpse_last_scan_ms_ = 0;
            if (!temp_corpses.empty())
            {
                temp_corpses.clear();
                corpse_store_dirty = true;
            }
        }

        if (container_esp->get_value())
        {
            const bool show_container_loot = container_show_loot->get_value();
            const float container_max_dist = container_distance->get_value();
            const float container_max_dist_sq = container_max_dist * container_max_dist;
            const ULONGLONG now = now_esp;
            constexpr int position_updates_far_per_tick = 24;
            constexpr int max_loot_refreshes_per_tick = 1;
            const ULONGLONG loot_refresh_interval_ms = container_loot_refresh_base;
            const ULONGLONG container_discovery_interval_ms = container_discovery_base;

            // Between container ticks (or manual freeze): reuse last snapshot markers.
            if (!do_container_scan)
            {
                temp_loots.insert(temp_loots.end(), container_marker_snapshot_.begin(),
                                  container_marker_snapshot_.end());
            }
            else
            {
                containers_scanned = true;
                container_last_tick_ms_ = now;
                if (show_container_loot || any_loot_category_filter())
                    ensure_wishlist_sets(main_profile.get_instance(), force_esp_refresh);

                static auto *container_assembly = il2utils::resolve_image("Assembly-CSharp.dll");
                static Il2CppObject *lootable_container_type = nullptr;
                if (!lootable_container_type)
                {
                    lootable_container_type =
                        il2utils::get_system_type(container_assembly, "EFT.Interactive", "LootableContainer");
                }

                // Manual refresh always rediscovers containers so new boxes appear too.
                // 1 s while the first 30 s of the raid are still filling the registry,
                // 120 s after that. `container_first_scan_ms_` is 0 only before the very
                // first scan, in which case the ramp window reads as already elapsed and
                // the steady state applies -- which is right, because the condition below
                // already fires on an empty registry anyway.
                const ULONGLONG into_raid_ms =
                    container_first_scan_ms_ == 0 ? container_discovery_interval_ms : (now - container_first_scan_ms_);
                const ULONGLONG discovery_interval_ms = (into_raid_ms < kContainerRampWindowMs)
                                                            ? kContainerRampIntervalMs
                                                            : container_discovery_interval_ms;

                TA_ZONE_N("esp_scan::container_scan");
                if (lootable_container_type &&
                    (force_esp_refresh || now - container_registry_scan_ms_ >= discovery_interval_ms ||
                     container_registry_.empty()))
                {
                    std::unordered_map<uintptr_t, container_registry_entry> existing;
                    existing.reserve(container_registry_.size());
                    for (auto &entry : container_registry_)
                        existing.emplace(entry.obj_key, std::move(entry));

                    size_t found = 0;
                    Il2CppObject **objects = nullptr;
                    {
                        // Split from the per-object loop on purpose. This is a
                        // scene-wide search, so its cost scales with the whole
                        // scene rather than with the container count, and the
                        // per-object loop below does two validity checks per
                        // result. Measured 2026-10-09: container_scan averages
                        // 8.4 ms over 184 calls and peaks at 135 ms, and that
                        // 135 ms was the entire `lootScan=` bucket on the
                        // slow-frame line -- not the ground-loot scan.
                        TA_ZONE_N("esp_scan::container_find_objects");
                        objects = unity::find_objects_of_type(lootable_container_type, &found);
                    }

                    std::vector<container_registry_entry> merged;
                    merged.reserve(found);

                    TA_ZONE_N("esp_scan::container_filter");
                    for (size_t i = 0; i < found; ++i)
                    {
                        Il2CppObject *obj = objects[i];
                        if (!eft_api::is_il2cpp_object_likely_valid(obj))
                            continue;

                        // GHOST FILTER. find_objects_of_type sees every container prefab in the
                        // scene, including the many the loot spawner did not roll this raid.
                        // They are indistinguishable from real ones by position or renderer, so
                        // without this they draw as boxes on empty floor.
                        //
                        // This sits ABOVE the reuse branch on purpose: a ghost that was admitted
                        // by an earlier scan is carried in `existing`, and dropping it only on
                        // the new-object path would let the registry keep it for the whole raid.
                        if (!eft_api::is_container_actually_placed(obj))
                            continue;

                        const uintptr_t obj_key = reinterpret_cast<uintptr_t>(obj);
                        const auto prev = existing.find(obj_key);
                        if (prev != existing.end())
                        {
                            container_registry_entry entry = std::move(prev->second);
                            existing.erase(prev);
                            if (entry.name.empty() || entry.name == "LootableContainer" || entry.name == "Container")
                            {
                                entry.name = eft_api::try_get_lootable_container_display_name(obj);
                            }
                            merged.push_back(std::move(entry));
                            continue;
                        }

                        std::string name = eft_api::try_get_lootable_container_display_name(obj);
                        if (name.empty())
                            name = obj->klass->name ? obj->klass->name : "Container";
                        merged.push_back({obj_key, std::move(name), {}, 0.f, 0.f, false, false});
                    }

                    container_registry_ = std::move(merged);
                    container_registry_scan_ms_ = now;
                    // Set once. Every later scan must leave it alone or the ramp never ends.
                    if (container_first_scan_ms_ == 0)
                        container_first_scan_ms_ = now;
                    container_position_cursor_ = 0;

                    for (auto &entry : container_registry_)
                    {
                        if (!entry.has_pos)
                            update_container_registry_position(entry);
                    }
                }

                {
                    int bootstrapped = 0;
                    for (auto &entry : container_registry_)
                    {
                        if (entry.has_pos)
                            continue;
                        // Manual: resolve every missing position; auto: cap cost.
                        if (!force_esp_refresh && bootstrapped >= 32)
                            break;
                        update_container_registry_position(entry);
                        ++bootstrapped;
                    }
                }

                refresh_container_registry_distances(my_pos, min_dist_sq, container_max_dist_sq);

                std::vector<size_t> in_range_indices;
                in_range_indices.reserve(32);
                for (size_t i = 0; i < container_registry_.size(); ++i)
                {
                    if (container_registry_[i].in_range)
                        in_range_indices.push_back(i);
                }

                for (const size_t index : in_range_indices)
                    update_container_registry_position(container_registry_[index]);

                refresh_container_registry_distances(my_pos, min_dist_sq, container_max_dist_sq);

                if (!container_registry_.empty())
                {
                    const size_t registry_size = container_registry_.size();
                    if (force_esp_refresh)
                    {
                        for (size_t index = 0; index < registry_size; ++index)
                        {
                            if (container_registry_[index].in_range)
                                continue;
                            update_container_registry_position(container_registry_[index]);
                        }
                    }
                    else
                    {
                        for (int updated = 0; updated < position_updates_far_per_tick && registry_size > 0; ++updated)
                        {
                            container_position_cursor_ %= registry_size;
                            const size_t index = container_position_cursor_++;
                            if (container_registry_[index].in_range)
                                continue;

                            update_container_registry_position(container_registry_[index]);
                        }
                    }

                    refresh_container_registry_distances(my_pos, min_dist_sq, container_max_dist_sq);
                }

                std::vector<const container_registry_entry *> nearby;
                nearby.reserve(in_range_indices.size());
                for (const auto &entry : container_registry_)
                {
                    if (!entry.has_pos || !entry.in_range)
                        continue;
                    nearby.push_back(&entry);
                }

                if (show_container_loot && !nearby.empty())
                {
                    if (force_esp_refresh)
                    {
                        // One button press: rebuild loot lists for ALL nearby containers.
                        for (const container_registry_entry *nearby_entry : nearby)
                        {
                            Il2CppObject *obj = reinterpret_cast<Il2CppObject *>(nearby_entry->obj_key);
                            if (!eft_api::is_il2cpp_object_likely_valid(obj))
                                continue;

                            container_item_cache &cache = container_item_caches_[nearby_entry->obj_key];
                            cache.obj_key = nearby_entry->obj_key;
                            cache.name = nearby_entry->name;
                            refresh_container_item_cache(cache, obj);
                        }
                    }
                    else
                    {
                        int refreshed = 0;
                        for (size_t n = 0; n < nearby.size() && refreshed < max_loot_refreshes_per_tick; ++n)
                        {
                            const size_t idx = (container_loot_refresh_cursor_ + n) % nearby.size();
                            const container_registry_entry &nearby_entry = *nearby[idx];
                            Il2CppObject *obj = reinterpret_cast<Il2CppObject *>(nearby_entry.obj_key);
                            if (!eft_api::is_il2cpp_object_likely_valid(obj))
                                continue;

                            container_item_cache &cache = container_item_caches_[nearby_entry.obj_key];
                            cache.obj_key = nearby_entry.obj_key;
                            if (cache.name.empty())
                                cache.name = nearby_entry.name;

                            const bool stale =
                                cache.last_refresh == 0 || now - cache.last_refresh >= loot_refresh_interval_ms;
                            if (!stale)
                                continue;

                            cache.name = nearby_entry.name;
                            refresh_container_item_cache(cache, obj);
                            ++refreshed;
                        }
                        container_loot_refresh_cursor_ = (container_loot_refresh_cursor_ + 1) % nearby.size();
                    }

                    std::unordered_set<uintptr_t> live_keys;
                    live_keys.reserve(nearby.size());
                    for (const container_registry_entry *entry : nearby)
                        live_keys.insert(entry->obj_key);

                    for (auto it = container_item_caches_.begin(); it != container_item_caches_.end();)
                    {
                        if (live_keys.find(it->first) == live_keys.end())
                            it = container_item_caches_.erase(it);
                        else
                            ++it;
                    }
                }
                else if (!show_container_loot)
                {
                    container_item_caches_.clear();
                }

                container_marker_snapshot_.clear();
                container_marker_snapshot_.reserve(nearby.size());
                temp_containers.clear();
                temp_containers.reserve(nearby.size());

                for (const container_registry_entry *entry : nearby)
                {
                    if (show_container_loot)
                    {
                        container_esp_entry visible{};
                        visible.container_name = entry->name;
                        visible.pos3d = entry->pos3d;
                        visible.distance = entry->distance;

                        if (container_item_cache *cache_ptr = find_container_item_cache(entry->obj_key))
                        {
                            visible.total_price = cache_ptr->total_price;
                            visible.items = cache_ptr->items_ptr;
                            if (!cache_ptr->name.empty())
                                visible.container_name = cache_ptr->name;
                        }

                        // Wishlist/hideout filter: only keep boxes that still show matching items.
                        if (any_loot_category_filter())
                        {
                            bool any_match = false;
                            if (visible.items)
                            {
                                for (const auto &it : *visible.items)
                                {
                                    if (should_show_container_item(it))
                                    {
                                        any_match = true;
                                        break;
                                    }
                                }
                            }
                            if (!any_match)
                                continue;
                        }

                        temp_containers.push_back(std::move(visible));
                    }
                    else
                    {
                        // Marker-only mode: if category filter on, require cache hit with match.
                        if (any_loot_category_filter())
                        {
                            container_item_cache *cache_ptr = find_container_item_cache(entry->obj_key);
                            if (!cache_ptr)
                                continue;
                            bool any_match = false;
                            for (const auto &it : cache_ptr->items)
                            {
                                if (should_show_container_item(it))
                                {
                                    any_match = true;
                                    break;
                                }
                            }
                            if (!any_match)
                                continue;
                        }

                        loot_entry marker{};
                        marker.name = entry->name;
                        marker.pos3d = entry->pos3d;
                        marker.is_container = true;
                        marker.price = 0;
                        marker.is_quest = false;
                        marker.distance = entry->distance;
                        marker.is_corpse_loot = false;
                        container_marker_snapshot_.push_back(std::move(marker));
                    }
                }

                // Drawers/cash registers share one origin — one stable marker (no fan-out jump).
                if (show_container_loot && temp_containers.size() >= 2)
                    merge_colocated_container_lists(temp_containers);
                else if (!show_container_loot && container_marker_snapshot_.size() >= 2)
                    merge_colocated_container_markers(container_marker_snapshot_);

                temp_loots.insert(temp_loots.end(), container_marker_snapshot_.begin(),
                                  container_marker_snapshot_.end());
                container_store_dirty = true;
            }
        }
        else
        {
            container_registry_.clear();
            container_item_caches_.clear();
            container_marker_snapshot_.clear();
            container_position_cursor_ = 0;
            container_loot_refresh_cursor_ = 0;
            container_registry_scan_ms_ = 0;
            container_first_scan_ms_ = 0;
            container_last_tick_ms_ = 0;
            container_store_dirty = true;
            temp_containers.clear();
        }
    }

    // TEMPORARY (slow_frame_probe): closes the loot/container bucket placed above the
    // `if`, because the scan is conditional and this runs whether or not it entered.
    g_slow_frame.us_loot += slow_frame_probe::since_us(t_loot);

    // Quest ESP pipeline from Icebreaker Test (full collect + authoritative publish).
    const bool need_quest_poi =
        quest_esp_enabled->get_value() || (minimap_module_self && minimap_module_self->radar->get_value() &&
                                           minimap_module_self->radar_minimap_quest_esp->get_value());

    const auto t_poi = std::chrono::steady_clock::now(); // TEMPORARY (slow_frame_probe)
    if (need_quest_poi)
    {
        // Same reasoning as esp_scan::loot_and_container_scan above: a second sizeable
        // unzoned block in the post-loop half, and the other candidate for `tail`.
        TA_ZONE_N("esp_scan::quest_poi_scan");
        const ULONGLONG now = now_esp;
        constexpr ULONGLONG quest_collect_timeout_ms = 12000;
        constexpr size_t quest_loot_per_tick = 64;
        Il2CppObject *game_world_obj = game_world_instance.get_instance();

        const bool allow_quest_auto = !manual_esp || force_esp_refresh;

        if (quest_esp::is_collect_stale(now, quest_collect_timeout_ms))
            quest_esp::force_collect_ready();

        // One full collect until cache clear / manual refresh (no periodic rescan).
        // force_esp_refresh or first enable (quest_esp_last_refresh_ms_ == 0).
        if (allow_quest_auto && quest_esp::is_collect_idle() && (force_esp_refresh || quest_esp_last_refresh_ms_ == 0))
        {
            // Zoned because this is a FULL collect, not a step. It fires once on
            // first enable (quest_esp_last_refresh_ms_ == 0) and on force refresh,
            // and it walks every quest spawn in the location -- which is the
            // remaining candidate for quest_poi_scan's 213 ms max, now that
            // quest_poi_force_drain turned out never to fire at all.
            TA_ZONE_N("esp_scan::quest_collect_start");
            quest_esp::start_collect_cycle(game_world_obj, main_player_, my_pos, current_location_id);

            // Mark as scanned even if collect immediately idle (no quests / fail).
            quest_esp_last_refresh_ms_ = now ? now : 1;
        }

        // Always advance an in-flight collect (started before manual freeze or by force).
        // Manual refresh: drain the whole quest loot scan this frame (one press = full update).
        if (quest_esp::is_collect_scanning_loot())
        {
            if (force_esp_refresh)
            {
                // Zoned apart from the steady-state path because it is a
                // different shape of work, not a bigger version of the same:
                // this drains the ENTIRE quest-loot scan into one frame
                // (up to 400 x 512 items) on an explicit user refresh.
                //
                // CORRECTION 2026-10-09: this was asserted to be the source of
                // quest_poi_scan's 213 ms max on the strength of the zone's 1.88 us
                // mean. It is wrong -- the zone recorded ZERO entries across a full
                // capture while the parent still maxed at 213 ms. Kept because the
                // path is real and one press of manual refresh does drain 400x512
                // items into one frame; but it is not what was measured.
                TA_ZONE_N("esp_scan::quest_poi_force_drain");
                int guard = 0;
                while (quest_esp::is_collect_scanning_loot() && guard++ < 400)
                    quest_esp::advance_collect(game_world_obj, 512);
            }
            else
            {
                // The steady-state path: 64 items per tick. Zoned separately from
                // the drain because the two have nothing in common but a callee.
                TA_ZONE_N("esp_scan::quest_poi_advance");
                quest_esp::advance_collect(game_world_obj, quest_loot_per_tick);
            }
        }

        // Descriptions ON → next collect fills on game thread (never from ImGui draw).
        {
            static bool was_descriptions = false;
            const bool want_desc = quest_esp_descriptions->get_value();
            if (want_desc && !was_descriptions)
            {
                quest_esp_last_refresh_ms_ = 0;
                quest_esp::persistent_desc_cache().clear();
            }
            was_descriptions = want_desc;
        }

        if (quest_esp::is_collect_ready())
        {
            bool authoritative = false;
            std::vector<quest_esp::poi_entry> fresh = quest_esp::take_collect_result(&authoritative);
            // Authoritative: always publish (incl. empty after complete).
            // Partial/timeout empty: keep previous store.
            if (authoritative || !fresh.empty() || quest_poi_store->empty())
            {
                if (quest_esp_descriptions->get_value() && !fresh.empty())
                    quest_esp::fill_poi_descriptions(fresh);
                temp_quest_poi = std::move(fresh);
                quest_poi_dirty = true;
                // The set has just been filtered against live completion state, so the
                // sweep below has nothing to learn until an objective finishes. Stamping
                // here rather than letting quest_poi_sweep_ms_ sit at 0 is what makes the
                // interval mean "since the last known-clean reading" instead of "since the
                // collect", which would otherwise sweep again on the very next frame.
                quest_poi_sweep_ms_ = now ? now : 1;
            }
        }

        // RE-FILTER THE PUBLISHED MARKERS. The collect above runs once per raid and says
        // so, which leaves every marker on screen for the rest of the raid whatever happens
        // to its objective — clear the kill counter, place the beacon, find the item, hand
        // the quest in at a trader — so "Quest ESP shows tasks that are already completed"
        // was a property of the design rather than a bug in one of the probes. This asks
        // the game again and retires the markers it says are finished.
        //
        // The interval is 5 s because the work is O(markers), not O(profile):
        // quest_esp::drop_completed_pois looks up the owners table the collect recorded
        // and runs its completion probes only on conditions a published marker names.
        // It must never re-walk the quest book — see what that cost on the comment above
        // quest_esp::foreach_outstanding_condition. Compare
        // refresh_active_quest_item_ids, which walks every condition of every started
        // quest and is on a 10 s clock (eft_api.h) — this is strictly cheaper.
        //
        // GATED ON A COLLECT HAVING RUN. `owners.empty()` inside the sweep already
        // returns 0, but the frame's copy of the store is also only meaningful if the
        // collect finished; a collect that died part-way leaves a stale set behind it,
        // and this is the second gate that stops it. The first is the store being
        // empty, which is what it was when a raid-2 collect wedged on 2026-10-15.
        {
            constexpr ULONGLONG quest_poi_sweep_interval_ms = 5000;
            const bool sweep_due = quest_poi_sweep_ms_ == 0
                || now == 0
                || now - quest_poi_sweep_ms_ >= quest_poi_sweep_interval_ms;

            if (sweep_due && main_player_ && !quest_poi_store->empty())
            {
                TA_ZONE_N("esp_scan::quest_poi_completed_sweep");
                quest_poi_sweep_ms_ = now ? now : 1;

                // Stage into the SAME buffer the publish reads, and only when there is no
                // fresh collect already staged in it — otherwise this would publish last
                // frame's set over the collect that is landing this frame. Order matters:
                // the collect runs first above, and an empty `temp_quest_poi` here means
                // no collect claimed the slot this frame, so copying the live set in is
                // correct rather than a resurrection of something the collect just
                // legitimately emptied.
                if (temp_quest_poi.empty())
                    temp_quest_poi = *quest_poi_store;

                if (quest_esp::drop_completed_pois(temp_quest_poi) > 0)
                    quest_poi_dirty = true;
            }
        }
    }
    else
    {
        quest_esp::reset_incremental();
        if (!quest_poi_store->empty())
        {
            temp_quest_poi.clear();
            quest_poi_dirty = true;
        }
        quest_esp_last_refresh_ms_ = 0;
        quest_poi_sweep_ms_ = 0;
    }
    g_slow_frame.us_poi += slow_frame_probe::since_us(t_poi); // TEMPORARY (slow_frame_probe)

    // TEMPORARY (slow_frame_probe): t_corpse brackets the bot-corpse scan. `t_publish` is
    // deliberately NOT aliased to it -- doing that made us_publish span the corpse scan
    // as well, so the two buckets overlapped and the log line could not be read.
    const auto t_corpse = std::chrono::steady_clock::now();
    std::vector<bot_corpse_marker> temp_bot_corpses;
    bool bot_corpse_dirty = false;
    if (minimap_module_self && minimap_module_self->radar->get_value() &&
        minimap_module_self->radar_minimap_bot_corpses->get_value())
    {
        const ULONGLONG now = GetTickCount64();
        constexpr ULONGLONG bot_corpse_scan_interval_ms = 1500;
        if (now - bot_corpse_last_scan_ms_ >= bot_corpse_scan_interval_ms)
        {
            scan_bot_corpses_for_minimap(game_world_instance, temp_bot_corpses);
            bot_corpse_last_scan_ms_ = now;
            bot_corpse_dirty = true;
        }
    }
    else if (!bot_corpse_store_->empty() || bot_corpse_last_scan_ms_ != 0)
    {
        temp_bot_corpses.clear();
        bot_corpse_ai_profiles_.clear();
        bot_corpse_last_scan_ms_ = 0;
        bot_corpse_ai_profiles_ms_ = 0;
        bot_corpse_dirty = true;
    }
    g_slow_frame.us_corpse += slow_frame_probe::since_us(t_corpse); // TEMPORARY
    // Declared out here, assigned immediately before the lock below. A `const auto`
    // declared inside the publish block would be scoped to it, and the accumulation
    // happens after the closing brace -- which is exactly the mistake this comment is
    // here to prevent.
    std::chrono::steady_clock::time_point t_publish{};

    {
        // Zoned, and separately worth watching for a reason the others are not: this is
        // the one block in gameworld_update's tail that takes a CROSS-THREAD lock. The
        // render thread reads the same mutex to publish its snapshot, so a stall here is
        // contention, not work -- and contention would look exactly like the stable
        // 209-214 us remainder that quest_poi_scan and loot_and_container_scan did not
        // explain. The zone covers the wait as well as the publishes, which is the point:
        // if this shows ~200 ms with almost no self time, the answer is the lock.
        TA_ZONE_N("esp_scan::publish_group");
        // TEMPORARY (slow_frame_probe): stamped HERE, immediately before the lock, so the
        // bucket measures the lock wait and not the preceding corpse scan.
        t_publish = std::chrono::steady_clock::now();
        std::lock_guard<std::mutex> lock(data_mutex);
        exfil_store = publish(std::move(temp_exfils));
        transits_store = publish(std::move(temp_transits));
        grenade_store = publish(std::move(temp_grenades));
        tripwire_store = publish(std::move(temp_tripwires));
        if (keypanel_dirty)
            keypanel_store = publish(std::move(temp_keypanels));
        // VIEW CONE, applied to the PLAYER store -- so it covers the box, the label and
        // (via its own gate) the skeleton, from one place.
        //
        // This reads `entry.in_view_cone`, DECIDED ONCE in the game loop and carried on the
        // entry. It used to recompute the angle here, which meant the two sites could
        // disagree -- an entry built and then dropped, or dropped and then built -- and it
        // is also what made the grace window impossible: hysteresis needs per-player state
        // keyed on identity, and this loop has only the finished struct.
        //
        // Fails open via the same flag: cone_active false means in_view_cone was set true
        // for every player, so this filter removes nothing.
        temp_players.erase(
            std::remove_if(temp_players.begin(), temp_players.end(), [](const player &e) { return !e.in_view_cone; }),
            temp_players.end());
        player_store = publish(std::move(temp_players));
        // Keep previous loot/quest-item lists when scan was skipped (rate limit / manual).
        if (loot_scanned || containers_scanned)
        {
            // When only containers scanned, still rebuild loot_store from ground loot cache + markers.
            // If ground loot was not scanned this frame, re-append previous ground loot entries.
            if (!loot_scanned && loot_esp->get_value())
            {
                // Preserve non-container ground loot from previous frame.
                std::vector<loot_entry> merged;
                merged.reserve(loot_store->size() + temp_loots.size());
                for (const auto &e : *loot_store)
                {
                    if (!e.is_container)
                        merged.push_back(e);
                }
                for (auto &e : temp_loots)
                    merged.push_back(std::move(e));
                loot_store = publish(std::move(merged));
            }
            else
            {
                loot_store = publish(std::move(temp_loots));
            }
        }
        if (quest_items_scanned)
            quest_item_store = publish(std::move(temp_quest_items));
        if (container_store_dirty)
        {
            container_store_ = std::make_shared<std::vector<container_esp_entry>>(std::move(temp_containers));
        }
        if (corpse_store_dirty)
        {
            corpse_store_ = std::make_shared<std::vector<container_esp_entry>>(std::move(temp_corpses));
        }
        // The store that faulted. Published, never mutated in place, so the
        // render thread's snapshot stays valid for the whole frame.
        skeleton_store = publish(std::move(temp_skeletons));
        if (quest_poi_dirty)
            quest_poi_store = publish(std::move(temp_quest_poi));
        if (bot_corpse_dirty)
            bot_corpse_store_ = publish(std::move(temp_bot_corpses));
    }
    // TEMPORARY (slow_frame_probe): closes the publish bucket. Placed after the closing
    // brace on purpose -- the timer must include the data_mutex WAIT, not just the
    // publishes, or a contention stall would be attributed to whatever ran next.
    g_slow_frame.us_publish += slow_frame_probe::since_us(t_publish);

    // Walking every cache is O(entries), so once a second is plenty for a
    // diagnostics panel -- and it keeps the work off the render thread.
    {
        const ULONGLONG stats_now = GetTickCount64();
        if (stats_now - stats_last_computed_ms_ >= 1000)
        {
            // TEMPORARY (slow_frame_probe): timed separately from `tail`, because the
            // first run of the phase probe put 457 of the 485 ms in the tail and this
            // is the only O(entries) walk in it. One more bucket either confirms it or
            // points at the publish()/loot-scan work instead.
            const auto t_stats = std::chrono::steady_clock::now();
            refresh_cache_stats();
            g_slow_frame.us_stats += slow_frame_probe::since_us(t_stats);
        }
    }

    // TEMPORARY (slow_frame_probe): tail = everything after the enumeration, and
    // `unaccounted` is the residual inside the loop that the named phases do not
    // explain -- which is the whole point. If unaccounted dominates, the cost is in
    // code this probe does not name and the zones will; if `row` or `tail` dominates,
    // this line already says which one, without needing a capture at all.
    //
    // refresh_cache_stats() above is the reason `tail` is worth a bucket of its own:
    // it is documented as walking EVERY cache and is throttled to once per second, so
    // it is the single most plausible source of a lone 400 ms+ frame in a function
    // whose mean is 1.64 ms -- and it has no zone, which is why nothing in the profile
    // could name it.
    g_slow_frame.us_tail = slow_frame_probe::since_us(t_loop_begin) - g_slow_frame.us_loop;
    g_slow_frame.report(g_slow_frame.us_loop - g_slow_frame.us_row - g_slow_frame.us_box - g_slow_frame.us_skel);
}
