#include "common.h"
#include "QuestResetModule.h"

QuestResetModule::QuestResetModule(QuestModule* quest_module) : Module("Quest Reset", QuestCompleter, "quest_reset_mod"), quest_module_(quest_module),
                                                                completed_search_(conf(new TextboxValue("", "quest_completed_search_txt"))),
                                                                completed_quests_(conf(new SelectValue(0, {}, "quest_completed_sel", true, true))),
                                                                reset_(conf(new ActionRowValue([this] {
                                                                    const int idx = completed_quests_->get_value();
                                                                    if (quest_module_ && idx >= 0 && idx < static_cast<int>(filtered_completed_ids_.size()))
                                                                        quest_module_->revert_completed_from_picker(filtered_completed_ids_[idx]);
                                                                },
                                                                    "quest_reset_btn"))) {
}

void QuestResetModule::prepare_menu_draw() {
    std::string search_lower = completed_search_->get();
    std::transform(search_lower.begin(), search_lower.end(), search_lower.begin(), ::tolower);

    std::vector<std::string> new_display_names = {};
    std::vector<std::string> new_filtered_ids = {};
    if (quest_module_)
    {
        // An immutable published snapshot, not QuestModule's own members. It used to be
        // the members directly, and they are filled by two separate push_back calls on the
        // game thread while this reads them on the render thread with no lock. The
        // min(names.size(), ids.size()) bound that guarded it prevented an out-of-bounds
        // read and nothing else -- the two vectors can be momentarily out of STEP, which
        // pairs one quest's NAME with a DIFFERENT quest's id, and that id is what
        // revert_completed_from_picker then reverts. See quest_list_snapshot in
        // QuestModule.h.
        const std::shared_ptr<const quest_list_snapshot> list = quest_module_->completed_quests();
        const size_t count = (std::min)(list->completed_names.size(), list->completed_ids.size());
        for (size_t i = 0; i < count; ++i)
        {
            const std::string& name = list->completed_names[i];

            std::string name_lower = name;
            std::transform(name_lower.begin(), name_lower.end(), name_lower.begin(), ::tolower);
            if (!search_lower.empty() && name_lower.find(search_lower) == std::string::npos) continue;

            new_display_names.push_back(name);
            new_filtered_ids.push_back(list->completed_ids[i]);
        }
    }

    std::vector<const char*> names;
    names.reserve(new_display_names.size());
    for (const std::string& name : new_display_names)
        names.push_back(name.c_str());

    filtered_completed_ids_ = std::move(new_filtered_ids);
    completed_quests_->set_options(names);
}

void QuestResetModule::draw_overlay(ImDrawList*) {}

void QuestResetModule::application_update() {}

void QuestResetModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) {}

void QuestResetModule::init() {}
