#pragma once

#include <string>
#include <Windows.h>
#include <imgui.h>

#include "../Module.h"
#include "../ModuleCategory.h"
#include "DebugLogModule.h"
#include "../game_state.h"
#include "../eft_api.h"
#include "../../il2cpp/Il2CppObjectInstance.h"
#include "../../il2cpp/il2utils.h"
#include "../../il2cpp/unity.h"
#include "../../gui/menu/menu.h"
#include "../../gui/menu/imgui_addons.h"
#include "../../config/CheckboxValue.h"
#include "../always_on.h"

// A light, read-only status overview. It samples only existing game-world
// collections and deliberately does not enable or alter any gameplay feature.
class RaidDashboardModule final : public Module
{
  public:
    RaidDashboardModule();

    // Kept on the visible dashboard card so the diagnostic card itself can
    // stay completely hidden until it is needed.
    //
    // 2026-09-26: this is now the ONLY debug-log toggle. It both reveals the Debug
    // Log card and enables DEBUG-level output (pushed into DebugLogModule here,
    // because ModuleManager includes DebugLogModule and the dependency cannot be
    // inverted). The card's former own "DebugLogging" checkbox is gone.
    CheckboxValue* show_debug_log;
    CheckboxValue* keep_orig_hash;
    CheckboxValue* keep_orig_server_id;

    // Bisect switch for the whole post-RPC localRaidSettings write. See the flag's
    // comment in always_on.h for the log evidence that motivated it.
    //
    // Deliberately NOT sampled in gameworld_update() alongside the two checkboxes
    // above: that function only runs once a GameWorld exists, and this setting has to
    // be live BEFORE a raid is started -- which is the whole point of using it as a
    // bisect. Read in application_update() instead, which runs every frame.
    CheckboxValue* write_local_raid_settings;

    void draw_overlay(ImDrawList*) override;
    void application_update() override;
    void init() override;

    void draw_menu_extra() override;

    void gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world,
        Il2CppObjectInstance main_player) override;

    void
    clear_runtime_cache() override;

  private:
    std::string location_display_;
    unity::vector3 player_pos_{};
    int loose_loot_count_ = 0;
    ULONGLONG last_sample_ms_ = 0;

    static std::string read_location_id(const Il2CppClass* world_class, Il2CppObjectInstance& world);
};
