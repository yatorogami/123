#pragma once

// The `[CLEANUP-PENDING:OPTICS]` freeze that used to open this file is GONE:
// the optics rework landed and the user lifted the freeze on 2026-10-13
// (AGENTS.md, "Do not touch"). While it was in flight, a dead-code pass found
// the following here; ALL of it was left in place on purpose until optics
// landed, and that deferral has now expired -- each item below is an ordinary
// cleanup candidate, with the cautions kept verbatim:
//
//   * draw_player_box_overlay  - an orphan of the two-pass optic split. Both
//     real call sites call draw_player_box_geometry directly, so the wrapper
//     is unreachable. Most likely a casualty of the optic rework itself.
//   * normalize_dir            - no callers.
//   * the 5 surviving `if (dual_active && game_state::esp_ads_mask_mode == 2)`
//     guards, where `const bool dual_active = false`. CAREFUL: in the
//     box/skeleton/label sites these are the ONLY optic-aware branch, so
//     deleting them makes the non-optic path unconditional. That is a
//     behaviour change, not a cleanup.
//   * the commented-out per-frame grenade_esp/tripwire_esp/keypanel_esp
//     set_value(false) block, whose comment still claims the code enforces
//     "saved configs cannot reactivate their world scans" -- it no longer does.
//   * the duplicated `#include "../../config/FloatSliderEditableValue.h"`
//     (plus duplicated <algorithm>, <unordered_set>, <unordered_map>).
//
// **2026-10-13 — freeze lifted, and the deletions below were made.** The
// include duplication above was already gone by then (one of each remains, and
// that item is CLOSED without needing an edit). Deleted this day:
// `draw_player_box_overlay` (orphan of the two-pass optic split — both real
// call sites call `draw_player_box_geometry` directly), `normalize_dir`, and
// the commented-out per-frame grenade_esp/tripwire_esp/keypanel_esp
// `set_value(false)` block, whose comment claimed the code enforced "saved
// configs cannot reactivate their world scans" — it was commented out, so it
// enforced nothing and the claim was false.
//
// **KEPT deliberately, and this is a decision rather than a leftover:** the 5
// surviving `if (dual_active && game_state::esp_ads_mask_mode == 2)` guards
// (now 4 — see below), where `const bool dual_active = false`. They are the
// ONLY optic-aware branch at the box/skeleton/label sites, `dual_active` has
// been permanently false since the Dual ADS toggle was removed on 2026-09-27,
// and `game_state::esp_ads_mask_mode` is still a user-settable config. Deleting
// the branches would make that knob silently inert with nothing in the menu
// saying so, which is a config-schema decision (what the knob now means, and
// whether it should exist), not a code cleanup. The history comments at the
// draw body and at `application_update` were kept with them. Count re-derived
// 2026-10-13: 4 guards, not the 5 the audit recorded.
//
// Full detail and the rest of the audit: CLEANUP_AUDIT.md.

#include "../../config/ActionRowValue.h"
#include "../../config/CheckboxValue.h"
#include "../../config/ColorpickerValue.h"
#include "../../config/MenuSectionValue.h"
#include "../Module.h"
#include "../ModuleCategory.h"
#include "../eft_api.h"
#include "../game_state.h"
#include <algorithm>
#include <array>
#include <cfloat>
#include <cmath>
#include <functional>
#include <map>
#include <mutex>
#include <optional>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <windows.h>
// Optic projection system - see optic_idea.md for algorithm details and OPTICS_IMPLEMENTATION.md for implementation
// summary
#include "../../config/FloatSliderEditableValue.h"
#include "../../config/IntSliderEditableValue.h"
#include "../../config/ItemSearchValue.h"
#include "../../config/SelectValue.h"
#include "../../config/SeparatorValue.h"
#include "../../gui/menu/menu.h"
#include "../../il2cpp/Il2CppObjectInstance.h"
#include "../../il2cpp/exports.h"
#include "../../il2cpp/il2utils.h"
#include "../../il2cpp/unity.h"
#include "../esp_text.h"
#include "../item_categories.h"
#include "../item_pricing.h"
#include "../minimap.h"
#include "../quest_esp.h"
#include "../skeleton_visibility.h"
#include "ChamsModule.h"
#include "MinimapModule.h"

#include <cstring>
#include <filesystem>
#include <fstream>

#include <nlohmann/json.hpp>

#include "../../../shared/module_paths.h"
#include "../../util/i18n.h"
#include "../../util/logger.h"
#include "../game_item_db.h"
#include <cctype>
#include <memory>
#include <thread>
namespace esp_bones {
    // REMOVED: the Skeleton._values index constants (l_collarbone = 94, l_forearm1 = 96,
    // ... r_palm = 120). They claimed to come from a "Stupid.Solutions HumanBones enum",
    // but no such enum exists in the dump -- GameDump/115147510/dump.cs has zero hits for
    // HumanBones. Ten hardcoded indices into a list whose order depends on the Unity
    // asset, with nothing to re-derive them from, is exactly the situation where a bone
    // silently binds to the wrong joint and draws a line across the screen.
    //
    // Every one of those ten has a named source on PlayerBones instead. See pb:: below.
    //
    // Skeleton._values index lookup (get_bone_by_index) is kept, because the sk_index arm
    // of bone_src is still reachable and I would rather leave one working path than
    // delete code on a hunch. Nothing uses it now.

    // PlayerBones fields — dump-verified against GameDump/115147510/dump.cs:99438.
    //
    // Neck is a UnityEngine.Transform (0x50) and LeftPalm/RightPalm are Transforms
    // (0xB0/0xB8); everything else named here is an EFT.BifacialTransform, which is
    // why get_player_bone_field special-cases neck and BifacialTransforms the rest.
    //
    // The four thigh fields are the important addition. LeftThigh1 (0x190),
    // RightThigh1 (0x198), LeftThigh2 (0x168) and RightThigh2 (0x170) are plain
    // fields on PlayerBones, and they are the same four joints this module used to
    // hunt for by substring-scanning Skeleton._keys ("Base HumanLThigh1" and friends).
    // The game already holds them at a fixed offset; reading them is two field reads.
    //
    // SHOULDERS AND PALMS. LeftShoulder (0x158) and RightShoulder (0x160) are
    // BifacialTransform, LeftPalm (0xB0) and RightPalm (0xB8) are Transform. These are
    // the joints the removed index constants 94/99/115/120 were reaching for, and the
    // names are the game's own.
    //
    // UPPERARM AND FOREARM ARE ARRAYS, NOT FIELDS: Upperarms (0xA0) and Forearms (0xA8)
    // are Transform[]. The ISIL shows the game reading element 0 of Upperarms directly
    // (Player.txt:52501-52580: Upperarms.Length check, then Upperarms[0] null-checked),
    // and CorpseRagdoll reads playerBones.Forearms the same way. Index order is
    // [left, right] -- see the pb_array helper for how that is established rather than
    // assumed, and what happens if it is ever wrong.
    namespace pb {
        inline constexpr const char *pelvis = "Pelvis";
        inline constexpr const char *spine3 = "Spine3";
        inline constexpr const char *neck = "Neck";
        inline constexpr const char *head = "Head";
        inline constexpr const char *l_thigh1 = "LeftThigh1";
        inline constexpr const char *l_thigh2 = "LeftThigh2";
        inline constexpr const char *r_thigh1 = "RightThigh1";
        inline constexpr const char *r_thigh2 = "RightThigh2";
        inline constexpr const char *l_shoulder = "LeftShoulder";
        inline constexpr const char *r_shoulder = "RightShoulder";
        inline constexpr const char *l_palm = "LeftPalm";
        inline constexpr const char *r_palm = "RightPalm";
        inline constexpr const char *upperarms = "Upperarms";
        inline constexpr const char *forearms = "Forearms";
    } // namespace pb

    // Index into PlayerBones' Transform[] arm arrays.
    //
    // [left, right] is the order, and it is worth being explicit that this is the one
    // structural assumption in the file that no reference proves outright. What the
    // references DO establish: both arrays are two-element Transform[] in practice, the
    // game reads element 0 as the interesting one, and the field is named
    // "Upperarms"/"Forearms" (plural, unordered by name). EFT's own mirrored naming
    // elsewhere -- LeftPalm/RightPalm, LeftThigh1/RightThigh1, the L-then-R order of
    // BifacialTransforms' keys (PlayerBoneType LeftShoulder = 1, RightShoulder = 2,
    // dump.cs:99401-99402) -- is consistent with [left, right].
    //
    // The consequence of getting it backwards is bounded, and deliberately so: an arm
    // chain drawn left-shoulder to right-palm is wrong but still anatomically coherent,
    // unlike the pelvis-to-hand lines the substring bug produced. And the sanity check
    // below turns even that into a dropped bone rather than a drawn one.
    enum class pb_arm {
        left = 0,
        right = 1
    };

    // Skeleton._keys LEAF NAMES — the final path component, matched for EQUALITY.
    //
    // Only the lower leg lives here. Calf/foot/toe are not PlayerBones fields at all:
    // the game reaches them through RootMotion.FinalIK.BipedReferences
    // (leftCalf/leftFoot/rightCalf/rightFoot, dump.cs:213735), which the ObservedPlayer
    // reaction path passes to TryBuildFrameInput (dump.cs:419539). There is no field to
    // read, so the skeleton is the right source.
    //
    // WHY THE LEAF AND NOT THE WHOLE KEY. `_keys` is keyed by the FULL transform path
    // from the rig root, not by leaf name. Sampled live on 2026-10-01 22:19 (log:
    // "esp-bones: key sample", 138 entries):
    //
    //   [22]='Root_Joint/Base HumanPelvis/Base HumanRThigh1/Base HumanRThigh2/Base HumanRCalf'
    //   [23]='.../Base HumanRCalf/Base HumanRFoot'
    //
    // so "Base HumanRCalf" is a substring of that key but IS NOT a key, and an equality
    // test against the whole key could never match. I had taken these names from
    // AnimationSnatcher's constants (dump.cs:14827-14832) and extrapolated the rest,
    // which was wrong: AnimationSnatcher passes them to TransformTools.FindTransformRecursive,
    // which matches HIERARCHY names, while _keys is keyed by whatever Unity serialization
    // wrote. Two namespaces, and I treated one as evidence for the other. The consequence
    // was measured, not guessed -- the 2026-10-01 current+4 capture showed
    // lookup_bone_in_skeleton_dict and lookup_bone_in_skeleton_lists at EXACTLY equal call
    // counts (673,740 each), i.e. the dictionary missed 100% of the time and the substring
    // fallback did all the work.
    //
    // WHY LEAF-COMPONENT EQUALITY RATHER THAN FULL-PATH EQUALITY. It is exact either way,
    // but leaf matching survives the rig being reparented (a path under a different
    // ancestor still resolves) whereas full-path matching silently drops every bone on
    // such a build -- the same failure mode, one level up.
    //
    // WHY THIS RULES OUT THE DECOYS, which is what makes it worth more than the perf. The
    // right leg carries body-part swap attachment points as children of the thigh:
    //
    //   [25]='Root_Joint/Base HumanPelvis/Base HumanRThigh1/Bear_Feet'
    //   [26]='Root_Joint/Base HumanPelvis/Base HumanRThigh1/USEC_Feet'
    //   [27]='Root_Joint/Base HumanPelvis/Base HumanRThigh1/BEAR_feet_1'
    //
    // Those are NPC archetype body bundles, not humanoid joints -- dump.cs:249905 gives
    // BEAR_FEET_BUNDLE_NAME = "assets/content/characters/character/prefabs/bear_feet.bundle",
    // and the ISIL of EFT/InGameBundles builds that path (InGameBundles.txt:5207, and
    // :5117 for usec_feet.bundle). The family is unambiguous: BEAR_HEAD_0 / BEAR_BODY /
    // BEAR_FEET / BEAR_HANDS, WILD_FEET, WILD_DEALMAKER_FEET.
    //
    // So with first-match-wins substring search, "Base HumanRFoot" could bind to a Bear's
    // foot attachment instead of the foot -- and the decoys sit at indices 25-27, BETWEEN
    // the right thigh (20) and the right calf (21), so the match depended on array order.
    // That is a bone in the thigh region, which is what draws a line across the screen.
    // Note the left leg has no such decoys (indices 15-19 are clean), so a defect of this
    // shape shows on the right leg only.
    //
    // Leaf EQUALITY cannot select them: "Bear_Feet" is a whole component, not a substring
    // of "Base HumanRFoot", so it fails a component-exact test outright.
    namespace sk_name {
        inline constexpr const char *l_calf = "Base HumanLCalf";
        inline constexpr const char *l_foot = "Base HumanLFoot";
        inline constexpr const char *l_toe = "Base HumanLToe";
        inline constexpr const char *r_calf = "Base HumanRCalf";
        inline constexpr const char *r_foot = "Base HumanRFoot";
        inline constexpr const char *r_toe = "Base HumanRToe";
    } // namespace sk_name

    // sk_named, not sk_suffix. The value is a full bone name matched for EQUALITY
    // against Skeleton.Bones, and the rename is deliberate: "suffix" is what the old
    // substring search matched on, and leaving the name would misdescribe the contract
    // for the next reader.
    //
    // player_bone_array is for PlayerBones' Transform[] fields (Upperarms, Forearms): the
    // field name goes in bone_ref::name and the element index in bone_ref::index, which is
    // why it is a distinct src instead of a field-name encoding.
    enum class bone_src {
        sk_index,
        player_bone,
        sk_named,
        player_bone_array
    };

    struct bone_ref
    {
        bone_src src;
        int index;
        const char *name;
    };

    struct bone_link
    {
        bone_ref from;
        bone_ref to;
    };

    inline bone_ref sk_ref(const int idx) {
        return {bone_src::sk_index, idx, nullptr};
    }
    inline bone_ref pb_ref(const char *field) {
        return {bone_src::player_bone, 0, field};
    }
    inline bone_ref named_ref(const char *name) {
        return {bone_src::sk_named, 0, name};
    }
    inline bone_ref pb_arm_ref(const char *field, pb_arm arm) {
        return {bone_src::player_bone_array, static_cast<int>(arm), field};
    }

    inline const std::vector<bone_link> &skeleton_links() {
        static const std::vector<bone_link> links = {
            // Left leg: thigh chain from PlayerBones fields, lower leg from the
            // skeleton's Bones dictionary. See the pb / sk_name notes above.
            {pb_ref(pb::pelvis), pb_ref(pb::l_thigh1)},
            {pb_ref(pb::l_thigh1), pb_ref(pb::l_thigh2)},
            {pb_ref(pb::l_thigh2), named_ref(sk_name::l_calf)},
            {named_ref(sk_name::l_calf), named_ref(sk_name::l_foot)},
            {named_ref(sk_name::l_foot), named_ref(sk_name::l_toe)},
            {pb_ref(pb::pelvis), pb_ref(pb::r_thigh1)},
            {pb_ref(pb::r_thigh1), pb_ref(pb::r_thigh2)},
            {pb_ref(pb::r_thigh2), named_ref(sk_name::r_calf)},
            {named_ref(sk_name::r_calf), named_ref(sk_name::r_foot)},
            {named_ref(sk_name::r_foot), named_ref(sk_name::r_toe)},
            {pb_ref(pb::pelvis), pb_ref(pb::spine3)},
            {pb_ref(pb::spine3), pb_ref(pb::neck)},
            {pb_ref(pb::neck), pb_ref(pb::head)},
            // Arms: spine3 -> shoulder -> upperarm -> forearm -> palm, every joint from a
            // named PlayerBones field. This REPLACES a five-segment chain built from
            // hardcoded _values indices (94/96/97/98/99 and 115/117/118/119/120) whose
            // only justification was a "HumanBones enum" that does not exist in the dump.
            //
            // One fewer joint than before, deliberately. The old chain had
            // forearm1 -> forearm2 -> forearm3, i.e. three elbow-ish segments per arm,
            // but PlayerBones exposes exactly one Forearms transform per side. A
            // three-segment arm out of one forearm joint means two of the three segments
            // were either degenerate or reaching for a joint that was never there.
            // shoulder -> upperarm -> forearm -> palm is the real chain and it is drawn
            // from real transforms throughout.
            {pb_ref(pb::spine3), pb_ref(pb::l_shoulder)},
            {pb_ref(pb::l_shoulder), pb_arm_ref(pb::upperarms, pb_arm::left)},
            {pb_arm_ref(pb::upperarms, pb_arm::left), pb_arm_ref(pb::forearms, pb_arm::left)},
            {pb_arm_ref(pb::forearms, pb_arm::left), pb_ref(pb::l_palm)},
            {pb_ref(pb::spine3), pb_ref(pb::r_shoulder)},
            {pb_ref(pb::r_shoulder), pb_arm_ref(pb::upperarms, pb_arm::right)},
            {pb_arm_ref(pb::upperarms, pb_arm::right), pb_arm_ref(pb::forearms, pb_arm::right)},
            {pb_arm_ref(pb::forearms, pb_arm::right), pb_ref(pb::r_palm)},
        };
        return links;
    }

    // Zoned because it is called 2x per link per collection AND once per endpoint per
    // draw, so it is the highest-frequency function in this namespace, and it allocates a
    // std::string every single time. Two allocations per link in collect_skeleton_bones,
    // two more per link in each of the two draw variants. The count is what tells us
    // whether the string keys are worth replacing with precomputed constants.
    inline std::string bone_key(const bone_ref &ref) {
        TA_ZONE_N("esp_bones::bone_key");
        switch (ref.src)
        {
        case bone_src::sk_index:
            return "i:" + std::to_string(ref.index);
        case bone_src::sk_named:
            return std::string("n:") + ref.name;
        case bone_src::player_bone:
            return std::string("p:") + ref.name;
        // The index is part of the IDENTITY here, not decoration: Upperarms[0] and
        // Upperarms[1] are different bones and must not collide on one map key.
        case bone_src::player_bone_array:
            return std::string("a:") + std::to_string(ref.index) + ":" + ref.name;
        }
        return {};
    }

    // EBodyPart: Head=0, Chest=1, Stomach=2, LeftArm=3, RightArm=4, LeftLeg=5, RightLeg=6
    inline int body_part_for_bone(const bone_ref &ref) {
        if (ref.src == bone_src::player_bone)
        {
            if (ref.name == pb::head || ref.name == pb::neck)
                return 0;
            if (ref.name == pb::spine3)
                return 1;
            if (ref.name == pb::pelvis)
                return 2;
            // Thighs and shoulders are limbs, not torso. Without these two the thigh and
            // shoulder bones fall through to the Chest default below and get torso
            // colouring, which is wrong in a way that is easy to miss because the
            // geometry still looks right.
            if (ref.name == pb::l_thigh1 || ref.name == pb::l_thigh2)
                return 5;
            if (ref.name == pb::r_thigh1 || ref.name == pb::r_thigh2)
                return 6;
            if (ref.name == pb::l_shoulder || ref.name == pb::l_palm)
                return 3;
            if (ref.name == pb::r_shoulder || ref.name == pb::r_palm)
                return 4;
        }

        // Arm arrays carry their side in the index, so the classification reads the index
        // rather than the field name.
        if (ref.src == bone_src::player_bone_array)
        {
            return ref.index == static_cast<int>(pb_arm::right) ? 4 : 3;
        }

        if (ref.src == bone_src::sk_index)
        {
            // The old index-range test named sk:: constants that no longer exist. sk_index
            // has no callers left, so there is nothing honest to range-check against; a
            // raw index carries no side information of its own.
            return 1;
        }

        if (ref.src == bone_src::sk_named && ref.name)
        {
            // Only calf/foot/toe reach here now, all lower-leg, so the L/R prefix is the
            // whole of the classification.
            if (strncmp(ref.name, "Base HumanL", 11) == 0)
                return 5;
            if (strncmp(ref.name, "Base HumanR", 11) == 0)
                return 6;
        }

        return 1;
    }

    inline int body_part_for_link(const bone_link &link) {
        const int to_part = body_part_for_bone(link.to);
        const int from_part = body_part_for_bone(link.from);
        if (to_part != from_part)
            return to_part;
        return to_part;
    }

    inline Il2CppObject *get_player_body(Il2CppObject *player_obj) {
        // Zoned because this is the top of a chain that runs 2-3 times per bone lookup
        // (get_skeleton_root, then get_skeleton_values_array again) -- so ~1 M times per
        // capture -- and it opens with an UNCACHED resolve_method (il2utils::resolve_method
        // has no cache, unlike resolve_field; see skeleton_visibility.h). The whole chain
        // was inside get_bone_transform_by_name's 12.5 ms max with no way to apportion it.
        TA_ZONE_N("esp_bones::get_player_body");
        if (!player_obj || !player_obj->klass)
            return nullptr;

        const MethodInfo *get_body = il2utils::resolve_method(player_obj->klass, "get_PlayerBody", 0);
        if (get_body && get_body->methodPointer)
        {
            const auto fn = reinterpret_cast<Il2CppObject *(*)(Il2CppObject *)>(get_body->methodPointer);
            Il2CppObject *body = fn(player_obj);
            if (body)
                return body;
        }

        const FieldInfo *body_field = il2utils::resolve_field(player_obj->klass, "_playerBody");
        if (!body_field)
            return nullptr;
        return *reinterpret_cast<Il2CppObject **>(reinterpret_cast<UINT64>(player_obj) + body_field->offset);
    }

    inline Il2CppObject *get_body_player_bones(Il2CppObject *player_obj) {
        Il2CppObject *body = get_player_body(player_obj);
        if (!body || !body->klass)
            return nullptr;

        const FieldInfo *bones_field = il2utils::resolve_field(body->klass, "PlayerBones");
        if (!bones_field)
            return nullptr;
        return *reinterpret_cast<Il2CppObject **>(reinterpret_cast<UINT64>(body) + bones_field->offset);
    }

    inline Il2CppObject *get_skeleton_root(Il2CppObject *player_obj) {
        // Zoned for the same reason as get_player_body above, and because this one is
        // called from THREE places per lookup: directly from get_bone_transform_by_name,
        // and again inside get_skeleton_values_array, which the fallback path and
        // get_bone_by_index each reach. Its child zone is get_player_body, so
        // (total - self) is this function's own resolve_field + offset work.
        TA_ZONE_N("esp_bones::get_skeleton_root");
        Il2CppObject *body = get_player_body(player_obj);
        if (!body || !body->klass)
            return nullptr;

        const FieldInfo *skeleton_field = il2utils::resolve_field(body->klass, "SkeletonRootJoint");
        if (!skeleton_field)
            return nullptr;

        Il2CppObject *skeleton_root =
            *reinterpret_cast<Il2CppObject **>(reinterpret_cast<UINT64>(body) + skeleton_field->offset);
        if (!skeleton_root || !skeleton_root->klass)
            return nullptr;
        return skeleton_root;
    }

    inline Il2CppArray *get_skeleton_values_array(Il2CppObject *player_obj) {
        Il2CppObject *skeleton_root = get_skeleton_root(player_obj);
        if (!skeleton_root)
            return nullptr;

        const FieldInfo *values_field = il2utils::resolve_field(skeleton_root->klass, "_values");
        if (!values_field)
            return nullptr;

        auto *values_list =
            *reinterpret_cast<unity::list **>(reinterpret_cast<UINT64>(skeleton_root) + values_field->offset);
        if (!values_list || !values_list->m_p_list_array)
            return nullptr;
        return values_list->m_p_list_array;
    }

    // Compares a managed PATH KEY against a narrow ASCII leaf literal, WITHOUT allocating.
    //
    // Compares only the final '/'-separated component. `key` is
    // "Root_Joint/Base HumanPelvis/Base HumanRCalf/Base HumanRFoot" and `leaf` is
    // "Base HumanRFoot"; the prefix is skipped rather than matched, so the lookup is
    // independent of where in the rig the joint hangs.
    //
    // NOT a substring test, and the distinction is the entire fix. The old code asked
    // "does this key CONTAIN the name", which matched "Base HumanRFoot" against the
    // NPC body-bundle attachment points Bear_Feet / USEC_Feet / BEAR_feet_1 sitting at
    // indices 25-27 of the right leg (see the sk_name note for what those are). Testing
    // the LAST COMPONENT FOR EQUALITY cannot match them: "Bear_Feet" is a whole component,
    // not a substring of "Base HumanRFoot".
    //
    // Equality also makes a trailing-suffix decoy impossible in the other direction -- a
    // key ending "...XYZ" or "...Weapon_root" cannot be mistaken for a joint -- which
    // substring matching allowed.
    //
    // This is the whole reason the old loop cost what it did: `conv_string` per key is a
    // wstring reserve, a per-char push_back, a WideCharToMultiByte sizing call, and a
    // std::string construction -- roughly 138 of each per lookup. Comparing the wide buffer
    // in place removes all of it.
    //
    // ASCII-only is asserted rather than assumed: every leaf this module asks for is
    // "Base Human<Side><Joint>", all < 0x80. A non-ASCII byte in the literal cannot match
    // a wide char, so the byte-wise comparison is exact for these names and cannot silently
    // truncate. A key with a non-ASCII leaf simply fails to match, which drops the bone.
    //
    // ZONED, and the zone is the measurement this file was missing. The 2026-10-01
    // current+3 capture blamed `eft_api::is_readable_address` (91.62 s, 7.64%) on the probe
    // call below. That was wrong: the zone sits in is_readable_address, which calls
    // probe_readable DIRECTLY, while this function calls is_readable_address_cached --
    // a different function, with no zone of its own and therefore no line in the trace.
    // The uncached callers are always_on.h, hideout_reflection.h and production_panel_probe.h.
    //
    // So the cost of this file's own probing was invisible, and the only honest way to
    // size it is to measure it here. The memo lookup's cost lands as SELF time in this
    // zone, which is what we want: it answers "does the bone path probe expensively?"
    // without instrumenting shared code on eft_api.h's behalf.
    //
    // The probe-memo log line corroborates that the lookup itself is cheap -- 18,606,500
    // hits against 17,219 misses across 28 windows, 99.91% -- but a hit rate is not a
    // cost. This zone is.
    inline bool managed_string_equals_leaf(const Il2CppString *str, const char *leaf) {
        TA_ZONE_N("esp_bones::managed_string_equals_leaf");
        if (!str || !leaf || !leaf[0])
            return false;
        const int len = str->length;
        // 512, not 256: a full path like
        // "Root_Joint/Base HumanPelvis/Base HumanRThigh1/Base HumanRThigh2/Base HumanRCalf"
        // is 74 chars and the digit-bearing ones run longer, so the old 256 ceiling was
        // close enough to be a latent truncation rather than a safe bound.
        if (len <= 0 || len > 512)
            return false;

        size_t want = 0;
        while (leaf[want])
            ++want;
        if (want == 0)
            return false;

        // The leaf must be at least as long as the key, and then the key's last `want`
        // chars must equal it. Requires want <= len, checked by the length test below.
        if (static_cast<size_t>(len) < want)
            return false;
        const int leaf_start = len - static_cast<int>(want);

        // ONE readability probe for the whole comparison, not one per candidate. The chars
        // buffer is contiguous, so proving the range readable proves every char in it.
        if (!eft_api::is_readable_address_cached(str->chars, static_cast<size_t>(len) * sizeof(wchar_t)))
            return false;

        // A separator immediately before the leaf is REQUIRED. Without it, "HumanRFoot"
        // would match the tail of "Base HumanRFoot" and, worse, any key that merely ends
        // with the same characters. The root key "Root_Joint" has no separator and no
        // leading slash, which is exactly why this test is on the boundary and not merely
        // a search from the end.
        if (leaf_start == 0)
            return false;
        if (str->chars[leaf_start - 1] != static_cast<wchar_t>('/'))
            return false;

        for (int i = 0; i < static_cast<int>(want); ++i)
        {
            // High byte of the wide char must be zero for this to be an ASCII match.
            if (str->chars[leaf_start + i] != static_cast<wchar_t>(static_cast<unsigned char>(leaf[i])))
                return false;
        }
        return true;
    }

    // Exact-name bone lookup in Skeleton.Bones (Dictionary<string, Transform>).
    //
    // WHY THE DICTIONARY AND NOT _keys. `Skeleton` (GameDump/115147510/dump.cs:205960)
    // declares:
    //
    //     public Dictionary<string, Transform> Bones;  // 0x20
    //     private List<string> _keys;                  // 0x28
    //     private List<Transform> _values;             // 0x30
    //
    // and its OnAfterDeserialize rebuilds Bones by zipping _keys[i] -> _values[i]
    // (IsilDump/Assembly-CSharp/Diz/Skinning/Skeleton.txt:596-673: Clear, then
    // _keys.get_Item(i) / _values.get_Item(i) / Bones.Add(key, value) per entry). So the
    // name -> Transform mapping this module needs already exists, maintained by the game,
    // and the old code re-derived it from the two parallel lists by substring search.
    //
    // Every other consumer in the game reads this dictionary by exact key:
    // PluggableBone uses ContainsKey(BonePath) then get_Item (PluggableBone.txt:194,213),
    // Skin uses TryGetValue then get_Item (Skin.txt:301,390), CutsceneActionDressLoaclPlayerActor
    // likewise. Nothing in the game substring-searches _keys. That asymmetry was the bug:
    // the only substring search in the codebase was ours.
    //
    // The OLD BEHAVIOUR WAS AMBIGUOUS, not merely slow. `key.find(suffix) == npos` with
    // first-match-wins binds a bone to the first key CONTAINING the name, so any sibling
    // joint whose name extends it wins over the exact one. The user-visible symptom was a
    // skeleton drawn as lines across the whole screen: both endpoints of a link are real
    // transforms, so every existing guard passes, they are just hundreds of millimetres
    // apart in the rig. Equality removes the class of defect rather than tuning it.
    //
    // IL2CPP Dictionary layout is the one in il2cpp/unity.h: m_p_buckets, m_p_entries,
    // m_i_count (LIVE entries), m_i_version, m_i_free_list, m_i_free_count. Entries are
    // walked to m_i_count and no further: m_p_entries->max_length is the CAPACITY, and
    // the slots past the live count are free-list or uninitialised. See the same warning
    // in hideout_reflection.h:406-410.
    // BONE TRANSFORM CACHE -- one lookup per (skeleton_root, bone name) per raid.
    //
    // WHAT THIS FIXES, measured. lookup_bone_in_skeleton_dict is a LINEAR WALK of
    // the game's Dictionary<Il2CppString, Transform> doing a managed string
    // compare per entry that survives the hash-code rejection. On the 09-10
    // captures:
    //
    //   esp_bones::lookup_bone_in_skeleton_dict  917,640 calls  1.852 s  2.02 us
    //   esp_bones::managed_string_equals_leaf  19,722,793 calls  0.876 s
    //   esp_bones::get_bone_transform_by_name   917,640 calls  2.261 s  2.46 us
    //
    // 19.7M string compares to resolve 917k bones is ~21 compares per lookup, and
    // each one is an IL2CPP call crossing into managed code. The SAME
    // (skeleton_root, bone name) pair is asked for repeatedly across a raid --
    // a player's bone layout does not change mid-raid -- so the walk is pure
    // repeated work.
    //
    // WHY IT IS SAFE, and this is the part that matters more than the speed.
    //
    // The cache stores what the walk FOUND, not an interpretation of it:
    //   the dictionary's own entries array base, the slot index, and the key and
    //   value pointers stored in that slot.
    // A hit is only accepted when all of those still agree with the live
    // dictionary, checked cheaply before the value is used:
    //
    //   * entries array base unchanged  -- the dict was not reallocated;
    //   * the slot index is in range and its hash code is still >= 0 -- the slot
    //     is still a live entry, not free-listed;
    //   * the key pointer in that slot is the one we cached -- and the key is an
    //     Il2CppString*, whose ADDRESS is the game's own identity for that
    //     string. This is the load-bearing check: it catches a slot being reused
    //     for a different bone after a removal, which a position check alone
    //     would happily accept.
    //
    // None of those reads can fault: they offset from the same live object the
    // walk itself just dereferenced.
    //
    // WHAT IS NOT CACHED. The position, deliberately. A Transform for a bone is a
    // stable object identity within a raid but its POSITION changes every frame,
    // and the caller only ever wants the position -- so caching the position
    // would need a staleness bound tied to the model's animation, which is a
    // guess. Returning the cached Transform lets the caller do the one
    // transform_get_pos it always did, and nothing else is trusted.
    //
    // EVICTION is by generation, not by size: entries carry the raid-outside
    // generation they were resolved in and are dropped when it changes, so a new
    // raid starts cold rather than trusting a skeleton from the last one. The
    // map itself is sized for a raid's bone sets and never evicts on pressure,
    // because a raid's bone set is bounded and an eviction policy that guesses
    // wrong is how this kind of cache hands back a stale Transform.
    //
    // ABA, explicitly: the key pointer identity check is what closes it. An
    // address freed and reused by a different Il2CppString leaves the cached key
    // pointer equal to the live one only if the game handed us the SAME object,
    // which is what we verified.
    constexpr int kMaxCachedBoneTransforms = 512;

    // The entry OWNS its name. std::array rather than a raw char buffer and a
    // pointer: a pointer would have to point at the caller's `leaf`, which is a
    // stack or temporary buffer at some call sites, and aliasing that is the
    // use-after-free this cache is otherwise built to avoid. An array also needs
    // no length bookkeeping, so there is no field to get out of step with the
    // buffer.
    //
    // It is a buffer, not a std::string, deliberately: this is a per-lookup
    // structure on the render thread and a std::string would allocate for every
    // entry. 64 bytes covers every bone name in the dump with room to spare; a
    // longer one is simply not cached, and the caller falls back to the walk.
    static constexpr size_t kMaxBoneNameLen = 64;

    struct BoneTransformCacheEntry {
        Il2CppObject *skeleton_root = nullptr;
        std::array<char, kMaxBoneNameLen> name{};
        Il2CppArray *entries = nullptr; // the dictionary's own entries array
        int slot = -1;
        Il2CppString *key = nullptr;
        Il2CppObject *value = nullptr;
        uint64_t generation = 0;

        bool name_is(const char *leaf) const {
            return std::strncmp(name.data(), leaf, kMaxBoneNameLen) == 0;
        }
    };

    // Bumped when a raid ends so the next one starts cold. Set from wherever the
    // raid boundary is already known rather than polled here.
    inline uint64_t &bone_transform_generation() {
        static uint64_t g = 0;
        return g;
    }

    // The cache itself, per the block comment above. Fixed-size and never
    // evicted on pressure: a raid's bone set is bounded by player count x bone
    // count, and a wrong eviction guess is how this class of bug hands back a
    // stale pointer.
    inline BoneTransformCacheEntry *bone_transform_table() {
        static BoneTransformCacheEntry table[kMaxCachedBoneTransforms];
        return table;
    }
    inline int &bone_transform_used() {
        static int used = 0;
        return used;
    }

    // Find an existing entry, or -1. Linear scan is deliberate: the working set
    // is a few hundred (skeleton_root, bone) pairs and kMaxCachedBoneTransforms
    // is 512, so this is a few hundred name compares against the ~21 managed
    // calls it replaces. A hashed container was slower at this size and is not
    // worth an allocation on the render path.
    inline int find_bone_slot(Il2CppObject *skeleton_root, const char *leaf) {
        const BoneTransformCacheEntry *table = bone_transform_table();
        const int used = bone_transform_used();
        for (int i = 0; i < used; ++i)
            if (table[i].skeleton_root == skeleton_root && table[i].name_is(leaf))
                return i;
        return -1;
    }

    // A hit is only a hit if the dictionary still says so. See the contract in
    // the block comment on BoneTransformCacheEntry -- every check here is one
    // that failing means "walk", never "trust".
    inline Il2CppObject *lookup_cached_bone_transform(
        Il2CppObject *skeleton_root, unity::dict<Il2CppString *, Il2CppObject *> *dict,
        int limit, const char *leaf) {
        const int slot = find_bone_slot(skeleton_root, leaf);
        if (slot < 0) return nullptr;
        const BoneTransformCacheEntry &e = bone_transform_table()[slot];

        if (e.generation != bone_transform_generation()) return nullptr;
        // The dictionary was reallocated: every slot index is meaningless now.
        if (e.entries != dict->m_p_entries) return nullptr;
        if (e.slot < 0 || e.slot >= limit) return nullptr;

        auto *entries = reinterpret_cast<unity::dict<Il2CppString *, Il2CppObject *>::entry *>(
            &dict->m_p_entries->data);
        // Free-listed or otherwise no longer a live entry.
        if (entries[e.slot].m_i_hash_code < 0) return nullptr;
        // THE LOAD-BEARING CHECK. The key is an Il2CppString*, and its address
        // is the game's identity for that string. If the slot was reused for a
        // different bone after a removal, this is where it is caught.
        if (entries[e.slot].m_t_key != e.key) return nullptr;
        if (entries[e.slot].m_t_value != e.value) return nullptr;
        return e.value;
    }

    inline void cache_bone_transform(Il2CppObject *skeleton_root,
        unity::dict<Il2CppString *, Il2CppObject *> *dict, const char *leaf,
        int slot_index, Il2CppString *key, Il2CppObject *value) {
        int &used = bone_transform_used();
        int slot = find_bone_slot(skeleton_root, leaf);
        if (slot < 0) {
            if (used >= kMaxCachedBoneTransforms) return; // full: walk, do not evict
            slot = used++;
        }
        // A name that does not fit is not cached, and the caller falls back to
        // the full walk. Truncating it instead would let two different bone names
        // collide on one cache slot -- the wrong-value failure this cache is
        // otherwise sealed against.
        const size_t leaf_len = std::strlen(leaf);
        if (leaf_len >= kMaxBoneNameLen) return;

        BoneTransformCacheEntry &e = bone_transform_table()[slot];
        e.skeleton_root = skeleton_root;
        std::memcpy(e.name.data(), leaf, leaf_len + 1);   // copies the NUL
        e.entries = dict->m_p_entries;
        e.slot = slot_index;
        e.key = key;
        e.value = value;
        e.generation = bone_transform_generation();
    }
    inline Il2CppObject *lookup_bone_in_skeleton_dict(Il2CppObject *skeleton_root, const char *leaf) {
        // Zoned so the walk's real cost -- ~138 entry comparisons per lookup, 6 lookups per
        // player per tick -- is a number rather than an argument. Its self time EXCLUDES the
        // child zone below, so this is the loop and the managed_string_equals_leaf is
        // attributed separately; the pair is what says whether the walk or the probing
        // dominates.
        TA_ZONE_N("esp_bones::lookup_bone_in_skeleton_dict");
        if (!skeleton_root || !skeleton_root->klass || !leaf)
            return nullptr;
        const FieldInfo *bones_field = il2utils::resolve_field(skeleton_root->klass, "Bones");
        if (!bones_field)
            return nullptr;

        auto *bones = *reinterpret_cast<Il2CppObject **>(reinterpret_cast<UINT64>(skeleton_root) + bones_field->offset);
        if (!bones)
            return nullptr;
        auto *dict = reinterpret_cast<unity::dict<Il2CppString *, Il2CppObject *> *>(bones);
        if (!dict->m_p_entries)
            return nullptr;
        const int live = dict->m_i_count;
        const int capacity = static_cast<int>(dict->m_p_entries->max_length);
        if (live <= 0 || capacity <= 0)
            return nullptr;
        const int limit = live < capacity ? live : capacity;

        // --- cache probe -------------------------------------------------------
        //
        // Placed HERE, after the dictionary is known good and before the walk.
        // A hit skips the walk entirely; a miss does exactly the work it did
        // before, and the result is then remembered.
        //
        // The identity checks are the contract in the block comment on
        // BoneTransformCacheEntry: any one of them failing means "do the walk",
        // never "trust the cache". See that comment for why the key pointer
        // comparison is the load-bearing one.
        if (Il2CppObject *hit = lookup_cached_bone_transform(skeleton_root, dict, limit, leaf))
            return hit;

        auto *entries = reinterpret_cast<unity::dict<Il2CppString *, Il2CppObject *>::entry *>(&dict->m_p_entries->data);
        for (int i = 0; i < limit; ++i)
        {
            // m_i_next < 0 marks a free slot; m_i_hash_code < 0 likewise. Checking the
            // hash is the cheap rejection, and it is what the standard layout guarantees.
            if (entries[i].m_i_hash_code < 0)
                continue;
            if (!managed_string_equals_leaf(entries[i].m_t_key, leaf))
                continue;
            cache_bone_transform(skeleton_root, dict, leaf, i, entries[i].m_t_key,
                entries[i].m_t_value);
            return entries[i].m_t_value;
        }
        return nullptr;
    }

    // Formats a field offset as real hex.
    //
    // Exists because this diagnostic once got it wrong in the most misleading way
    // available: "0x" concatenated with std::to_string() prints DECIMAL digits behind a hex
    // prefix, so a correct offset of 0x20 was logged as "0x32" and read as a layout
    // discrepancy between the ISIL and the running build. A whole capture cycle was spent
    // chasing a difference that did not exist. std::to_string has no hex overload, so the
    // wrongness was silent and looked authoritative.
    inline std::string hex_of(const int offset) {
        static const char *digits = "0123456789ABCDEF";
        // Negative is nonsense for a field offset, but to_string would render it as
        // "-80000000" and the loop below would never terminate on a shifted value.
        if (offset <= 0)
            return "0x0";
        const auto v = static_cast<unsigned int>(offset);
        std::string out = "0x";
        // Skip leading zeros so an offset reads as 0x20 rather than 0x00000020.
        bool started = false;
        for (int shift = 28; shift >= 0; shift -= 4)
        {
            const unsigned nibble = (v >> shift) & 0xF;
            if (!nibble && !started)
                continue;
            started = true;
            out += digits[nibble];
        }
        return out;
    }

    // -----------------------------------------------------------------------

    // -----------------------------------------------------------------------
    // THE ONE-SHOT DIAGNOSTIC IS DISABLED. Flip this to true to re-arm it.
    //
    // WHY IT IS OFF, measured 2026-10-11. This block walks `Skeleton`'s `Bones`
    // dictionary and its `_keys` list by RAW IL2CPP offsets -- no managed call, no
    // validity gate on the objects it reinterprets -- and calls conv_string() on
    // every key. It runs exactly once per session, and on 2026-10-11 the log holds
    // exactly two occurrences of it, in two separate sessions:
    //
    //   pid 27316  23:00:03.175 tid 7816  esp-bones: end of key sample
    //   pid 10316  23:04:57.078 tid 9296  esp-bones: end of key sample
    //
    // and BOTH processes died within a second of that line, on that same thread, with
    // the same fault: 0xC0000005, READ of 0xFFFFFFFFFFFFFFFF, at
    // GameAssembly.dll+0x5B1DA4 (a shared generic-instantiation body that dump.cs
    // attributes to Dictionary<object,...>.ContainsKey). Read of an all-ones sentinel,
    // not a wild pointer.
    //
    // WHAT THAT DOES AND DOES NOT SHOW. It is 2 occurrences out of 2, on one build,
    // with the diagnostic as the last thing logged before death each time -- strong
    // enough to stop shipping the walk, far too small to call proven causation. What
    // makes the call independent of the correlation: this is debug instrumentation
    // doing unchecked raw pointer walks of live game memory in a shipping DLL, with
    // no ongoing investigative value. It already did its job -- the 138 keys it
    // captured are quoted in the comments below and in lookup_bone_in_skeleton_dict,
    // including the Bear_Feet/USEC_Feet/BEAR_feet_1 prefab entries at [25]-[27] that
    // are the stated reason the substring pass was deleted.
    //
    // So the WALK is what is switched off. The lookup paths it sits next to
    // (lookup_bone_in_skeleton_dict, the BoneTransformCacheEntry checks) are NOT
    // implicated and are deliberately untouched -- the cache validates generation,
    // entries-array identity, slot bounds, hash sign, key pointer and value pointer,
    // and no defect was found in it.
    //
    // Re-arming it for a future patch means flipping this one constant; the code
    // below is unchanged and still compiles.
    inline constexpr bool kEnableSkeletonBoneKeyDiagnostic = false;

    // -----------------------------------------------------------------------
    // ONE-SHOT DIAGNOSTIC: why the dictionary path never matches, and what the keys
    // actually are.
    //
    // WHY THIS EXISTS, as a measurement rather than a hunch. The 2026-10-01 current+4
    // capture zones say:
    //
    //   lookup_bone_in_skeleton_dict   673,740 calls
    //   lookup_bone_in_skeleton_lists  673,740 calls
    //   get_bone_transform_by_name     673,740 calls
    //
    // All three exactly equal, which means the dictionary returned null on 100% of
    // lookups and the _keys fallback ran every time. At 275.6 string compares per lookup
    // against ~260 for two bare full walks, the SUBSTRING pass is running too -- so the
    // exact pass failed as well. "Base HumanLCalf" is not a key.
    //
    // I took those names from AnimationSnatcher's constants (dump.cs:14827-14832,
    // "Base HumanLPalm" / "Base HumanLCollarbone") and extrapolated the rest. That was
    // wrong: AnimationSnatcher passes them to TransformTools.FindTransformRecursive, which
    // matches HIERARCHY names, and Skeleton.Bones is keyed by whatever Unity serialization
    // wrote. Two different namespaces, and I treated one as evidence for the other.
    //
    // THE CONSEQUENCE IS NOT PERFORMANCE. The substring fallback is first-match-wins over
    // "contains", which is the exact ambiguity that drew lines across the screen, so the
    // defect I was asked to remove is still live. is_valid_pos catches positions that are
    // wildly wrong; it does not catch a wrong-but-plausible joint.
    //
    // So the names have to come from the object rather than from a reference: _keys is
    // populated by Unity prefab serialization and appears in no dump, no ISIL listing and
    // no string table. One runtime sample is the only way to learn it.
    //
    // Fires ONCE per session. It is deliberately inside the dictionary path rather than
    // the fallback, because "why did the dictionary miss" and "what are the keys" are one
    // question, and the dictionary is where the miss happened.
    inline void dump_skeleton_bone_keys_once(Il2CppObject *skeleton_root) {
        // Off by default -- see kEnableSkeletonBoneKeyDiagnostic above for the two
        // crashes that motivated it. `if constexpr` so the body is not merely skipped
        // but never compiled: the raw walk stays in the tree for the next patch that
        // needs it, without shipping a call to it.
        if constexpr (!kEnableSkeletonBoneKeyDiagnostic)
            return;

        static bool dumped = false;
        if (dumped || !skeleton_root || !skeleton_root->klass)
            return;
        dumped = true;

        const FieldInfo *bones_field = il2utils::resolve_field(skeleton_root->klass, "Bones");
        const FieldInfo *keys_field = il2utils::resolve_field(skeleton_root->klass, "_keys");
        const FieldInfo *values_field = il2utils::resolve_field(skeleton_root->klass, "_values");

        logger::debug("esp-bones: key sample -- class=" + std::string(skeleton_root->klass->name ? skeleton_root->klass->name : "?"));

        // The dictionary, with the shape that decides whether the fast path is even
        // reachable. A null Bones here is the single most likely explanation for a 100%
        // miss rate, and it is worth distinguishing from "populated but differently named".
        if (bones_field)
        {
            auto *bones = *reinterpret_cast<Il2CppObject **>(reinterpret_cast<UINT64>(skeleton_root) + bones_field->offset);
            if (!bones)
            {
                logger::debug("esp-bones: Bones field present (0x" + std::to_string(bones_field->offset) + ") but the OBJECT IS NULL");
            }
            else
            {
                auto *dict = reinterpret_cast<unity::dict<Il2CppString *, Il2CppObject *> *>(bones);
                const int live = dict->m_i_count;
                const int cap = dict->m_p_entries ? static_cast<int>(dict->m_p_entries->max_length) : -1;
                // HEX, explicitly. The first version of this diagnostic printed
                // "offset=0x" + std::to_string(offset), i.e. DECIMAL digits behind a hex
                // prefix, and it read "offset=0x32" for a correct 0x20 field. I spent a
                // capture investigating a layout discrepancy that did not exist. Both
                // offsets below are now formatted through a real hex conversion.
                logger::debug("esp-bones: Bones offset=" + hex_of(bones_field->offset) + " live=" + std::to_string(live) + " entries_cap=" + std::to_string(cap));
            }
        }
        else
        {
            logger::debug("esp-bones: NO 'Bones' field on this class -- dictionary path is dead");
        }

        if (!keys_field)
        {
            logger::debug("esp-bones: NO '_keys' field either");
            return;
        }
        auto *keys_list = *reinterpret_cast<unity::list **>(reinterpret_cast<UINT64>(skeleton_root) + keys_field->offset);
        if (!keys_list || !keys_list->m_p_list_array)
        {
            logger::debug("esp-bones: _keys list is null or has no backing array");
            return;
        }

        Il2CppArray *keys = keys_list->m_p_list_array;
        const int managed = eft_api::try_get_list_count(keys_list);
        const int cap = static_cast<int>(keys->max_length);
        // Walk the LIVE count when it reads sanely, else the capacity, so the dump shows
        // what the fallback itself would have walked. Both are reported because the
        // disagreement between them is itself a possible cause of a bad match.
        const int count = (managed > 0 && managed <= cap) ? managed : cap;
        logger::debug("esp-bones: _keys managed_size=" + std::to_string(managed) + " capacity=" + std::to_string(cap) + " keys_offset=" + hex_of(keys_field->offset) + " values_offset=" + hex_of(values_field ? values_field->offset : 0));

        // One line per key: index and exact spelling. This list IS the fix -- the names in
        // sk_name:: get corrected from it rather than from another extrapolation.
        std::string line;
        for (int i = 0; i < count; ++i)
        {
            Il2CppString *k = reinterpret_cast<Il2CppString **>(&keys->data)[i];
            // conv_string here, deliberately: this is a one-shot diagnostic where clarity
            // beats the allocation-avoidance the lookup path is built around.
            const std::string text = il2utils::conv_string(k);
            line += "[" + std::to_string(i) + "]='" + text + "' ";
            if (line.size() > 512)
            {
                logger::debug("esp-bones: " + line);
                line.clear();
            }
        }
        if (!line.empty())
            logger::debug("esp-bones: " + line);
        logger::debug("esp-bones: end of key sample");
    }

    // Fallback for a skeleton whose Bones dictionary is absent or empty.
    //
    // OnAfterDeserialize is what fills Bones, and it runs on DESERIALIZATION, so a skeleton
    // built at runtime may never have had it called and `Bones` can be null on a live
    // object. Per the decision on this change: fall back rather than drop, so behaviour is
    // unchanged on any build where the dictionary is unpopulated.
    //
    // Same leaf-equality test as the dictionary path, over the two parallel lists instead
    // of the hash table. `_keys` and `Bones` hold the same strings -- OnAfterDeserialize
    // builds the dictionary by zipping them -- so one comparison routine serves both.
    inline Il2CppObject *lookup_bone_in_skeleton_lists(Il2CppObject *skeleton_root, Il2CppArray *values, const char *leaf) {
        // Zoned separately from the dictionary path above so "did the fallback run, and
        // what did it cost" is answerable. A non-trivial count here means Bones was null or
        // empty on a live skeleton -- which is the one runtime behaviour of this change
        // that a reference cannot settle.
        TA_ZONE_N("esp_bones::lookup_bone_in_skeleton_lists");
        if (!skeleton_root || !values || !leaf)
            return nullptr;
        const FieldInfo *keys_field = il2utils::resolve_field(skeleton_root->klass, "_keys");
        if (!keys_field)
            return nullptr;
        auto *keys_list = *reinterpret_cast<unity::list **>(reinterpret_cast<UINT64>(skeleton_root) + keys_field->offset);
        if (!keys_list || !keys_list->m_p_list_array)
            return nullptr;

        Il2CppArray *keys = keys_list->m_p_list_array;
        // min(capacity) as a hard bound, then the live count as the real one. Walking to
        // capacity alone reads stale slots; walking to the live count alone trusts _size.
        const size_t cap = keys->max_length < values->max_length ? keys->max_length : values->max_length;
        if (cap == 0)
            return nullptr;
        const int managed = eft_api::try_get_list_count(keys_list);
        const size_t count = managed > 0 ? (static_cast<size_t>(managed) < cap ? managed : cap) : cap;

        Il2CppString **key_arr = reinterpret_cast<Il2CppString **>(&keys->data);
        Il2CppObject **val_arr = reinterpret_cast<Il2CppObject **>(&values->data);

        // NO SUBSTRING PASS. This is a deletion, not a deprioritisation, and the reason is
        // that the substring search is now known to select the WRONG BONE rather than
        // merely a sloppy one. The rig carries NPC body-bundle attachment points as
        // children of the right thigh -- Bear_Feet, USEC_Feet, BEAR_feet_1 at indices 25-27,
        // i.e. BETWEEN the thigh (20) and the calf (21). Those are prefabs, not joints
        // (dump.cs:249905, BEAR_FEET_BUNDLE_NAME = ".../bear_feet.bundle"; ISIL
        // InGameBundles.txt:5207), and first-match-wins on "contains" can bind a foot to
        // one of them. Keeping the pass as a fallback would preserve precisely the defect
        // this change exists to remove, behind a comment calling it cautious.
        //
        // Consequence, stated plainly: if a joint is renamed on a future build, that
        // segment disappears from the skeleton instead of being drawn to the wrong place.
        // That is the intended trade -- a missing segment is visible and harmless, a line
        // across the screen is neither -- and the one-shot dump above is what tells you
        // the name changed.
        for (size_t i = 0; i < count; ++i)
        {
            if (managed_string_equals_leaf(key_arr[i], leaf))
                return val_arr[i];
        }
        return nullptr;
    }

    // Resolve one named skeleton bone to a Transform, or null when it cannot be resolved.
    //
    // UNRESOLVABLE BONES ARE DROPPED, not guessed. The caller (collect_skeleton_bones)
    // simply does not insert a key for a bone that returns false here, and the draw
    // paths skip any link whose two endpoints are not both present. So a name that does
    // not resolve on some build removes that segment from the figure instead of
    // producing a line to an arbitrary joint. That is the failure mode worth having:
    // a missing segment is visible and harmless, a line across the screen is neither.
    inline Il2CppObject *get_bone_transform_by_name(Il2CppObject *player_obj, const char *leaf) {
        TA_ZONE_N("esp_bones::get_bone_transform_by_name");
        if (!player_obj || !leaf || !leaf[0])
            return nullptr;
        Il2CppObject *skeleton_root = get_skeleton_root(player_obj);
        if (!skeleton_root)
            return nullptr;

        // Moved HERE from lookup_bone_in_skeleton_lists, where it stopped firing.
        //
        // The dump was attached to the fallback, and the 2026-10-01 current+6 capture
        // measured that fallback at ZERO calls -- the dictionary now resolves every bone, so
        // the instrument went silent in the same capture that proved it obsolete. That is
        // the wrong place for it: this dump is the only way a game update renaming a joint
        // becomes VISIBLE, and with the substring pass deleted an unrecognised name now
        // drops a limb silently. An instrument that disables itself when it succeeds is not
        // an instrument. This path runs unconditionally.
        //
        // IT NO LONGER DOES ANYTHING, deliberately -- see
        // kEnableSkeletonBoneKeyDiagnostic for the two crashes that switched it off. The
        // "runs unconditionally" argument above is what made it fire on every bone of every
        // skeleton, which is also what made the raw walk expensive enough to matter. The
        // call stays so the rename-visibility intent is still one flag-flip away; with the
        // constant false this compiles to nothing.
        dump_skeleton_bone_keys_once(skeleton_root);

        Il2CppObject *transform = lookup_bone_in_skeleton_dict(skeleton_root, leaf);
        if (transform)
            return transform;

        Il2CppArray *values = get_skeleton_values_array(player_obj);
        return lookup_bone_in_skeleton_lists(skeleton_root, values, leaf);
    }

    inline bool get_bone_by_name(Il2CppObject *player_obj, const char *name, unity::vector3 &out) {
        Il2CppObject *transform = get_bone_transform_by_name(player_obj, name);
        if (!transform)
            return false;
        out = unity::transform_get_pos(transform);
        return true;
    }

    inline bool get_bone_by_index(Il2CppObject *player_obj, const int bone_idx, unity::vector3 &out) {
        Il2CppArray *values = get_skeleton_values_array(player_obj);
        if (!values || bone_idx < 0 || bone_idx >= static_cast<int>(values->max_length))
            return false;

        Il2CppObject *transform = reinterpret_cast<Il2CppObject **>(&values->data)[bone_idx];
        if (!transform)
            return false;

        out = unity::transform_get_pos(transform);
        return true;
    }

    inline bool get_bifacial_pos(Il2CppObject *bifacial, unity::vector3 &out) {
        // Was a duplicate of this resolve+call sequence, and the one WITHOUT the finiteness
        // check that its sibling copies had. Delegates to the single implementation now.
        return eft_api::try_get_managed_position(bifacial, out);
    }

    inline bool get_player_bone_field(Il2CppObject *player_obj, const char *field_name, unity::vector3 &out) {
        TA_ZONE_N("esp_bones::get_player_bone_field");
        Il2CppObject *pb = get_body_player_bones(player_obj);
        if (!pb || !pb->klass || !field_name)
            return false;

        // Hoisted out of the per-bone path. Measured 2026-10-09: this function runs
        // 1,502,892 times per capture, and each call did a resolve_field memo
        // probe (0.20 us) plus three strcmp against pb:: literals -- all keyed on
        // field_name, which is one of a small fixed set of literals at every call
        // site. One probe here replaces both. resolve_field's own memo already
        // made this correct; this makes it cheap.
        struct Resolved {
            const FieldInfo *field;
            bool is_plain_transform;
        };
        static std::unordered_map<std::string, Resolved> field_cache;
        auto fit = field_cache.find(field_name);
        if (fit == field_cache.end())
        {
            // Transform-typed fields, not BifacialTransform. Neck (0x50), LeftPalm (0xB0) and
            // RightPalm (0xB8) are UnityEngine.Transform in the dump; everything else named in
            // pb:: is an EFT.BifacialTransform, whose get_position is a real IL2CPP call that
            // reads Original.transform. Confusing the two means calling a managed method on a
            // Transform object -- an IL2CPP method pointer invoked with the wrong `this`.
            //
            // Was a single strcmp against pb::neck. LeftPalm and RightPalm are new callers and
            // are Transforms too, so the comparison is a set rather than an equality.
            fit = field_cache
                      .emplace(field_name,
                               Resolved{il2utils::resolve_field(pb->klass, field_name),
                                        strcmp(field_name, pb::neck) == 0 ||
                                            strcmp(field_name, pb::l_palm) == 0 ||
                                            strcmp(field_name, pb::r_palm) == 0})
                      .first;
        }
        const FieldInfo *field = fit->second.field;
        if (!field)
            return false;
        const bool is_plain_transform = fit->second.is_plain_transform;

        Il2CppObject *value = *reinterpret_cast<Il2CppObject **>(reinterpret_cast<UINT64>(pb) + field->offset);
        if (!value)
            return false;

        if (is_plain_transform)
        {
            out = unity::transform_get_pos(value);
            return true;
        }
        return get_bifacial_pos(value, out);
    }

    // PlayerBones.Upperarms[side] / PlayerBones.Forearms[side].
    //
    // Bounds are enforced on the live array length and the element is null-checked, both
    // because a Transform[] read past its end is garbage rather than a fault. The length
    // check is what makes a shorter-than-expected array (a different rig, a stripped
    // build) drop the bone instead of binding it to whatever follows in memory.
    inline bool get_player_bone_array_element(Il2CppObject *player_obj, const char *field_name, int index,
        unity::vector3 &out) {
        TA_ZONE_N("esp_bones::get_player_bone_array_element");
        Il2CppObject *pb = get_body_player_bones(player_obj);
        if (!pb || !pb->klass || !field_name || index < 0)
            return false;

        const FieldInfo *field = il2utils::resolve_field(pb->klass, field_name);
        if (!field)
            return false;

        auto *arr = *reinterpret_cast<Il2CppArray **>(reinterpret_cast<UINT64>(pb) + field->offset);
        if (!arr)
            return false;
        if (index >= static_cast<int>(arr->max_length))
            return false;
        // 64 KiB is a generous ceiling for a Transform[] and well under anything that
        // would make the count check below meaningless; it only exists so a misread
        // `arr` cannot produce an enormous bound.
        if (arr->max_length == 0 || arr->max_length > 16384)
            return false;

        Il2CppObject *transform = reinterpret_cast<Il2CppObject **>(&arr->data)[index];
        if (!transform)
            return false;

        out = unity::transform_get_pos(transform);
        return true;
    }

    inline bool resolve_bone(Il2CppObject *player_obj, const bone_ref &ref, unity::vector3 &out) {
        switch (ref.src)
        {
        case bone_src::sk_index:
            return get_bone_by_index(player_obj, ref.index, out);
        case bone_src::player_bone:
            return get_player_bone_field(player_obj, ref.name, out);
        case bone_src::sk_named:
            return get_bone_by_name(player_obj, ref.name, out);
        case bone_src::player_bone_array:
            return get_player_bone_array_element(player_obj, ref.name, ref.index, out);
        }
        return false;
    }

    inline void collect_skeleton_bones(Il2CppObject *player_obj, std::unordered_map<std::string, unity::vector3> &bones) {
        // The aggregate for the whole bone build, and the number that answers "is this
        // path worth optimising at all". Its children account for the resolution work, so
        // (total - self) is the cost of everything the children do NOT cover: the link
        // walk, bone_key's two allocations per link, and the map inserts.
        TA_ZONE_N("esp_bones::collect_skeleton_bones");
        for (const auto &link : skeleton_links())
        {
            const std::string from_key = bone_key(link.from);
            const std::string to_key = bone_key(link.to);

            if (!bones.contains(from_key))
            {
                unity::vector3 pos{};
                if (resolve_bone(player_obj, link.from, pos))
                    bones[from_key] = pos;
            }
            if (!bones.contains(to_key))
            {
                unity::vector3 pos{};
                if (resolve_bone(player_obj, link.to, pos))
                    bones[to_key] = pos;
            }
        }
    }
} // namespace esp_bones

class EspModule : Module
{
  public:
    EspModule();

    MenuSectionValue *section_world_;
    CheckboxValue *extracts;
    ColorpickerValue *extracts_color;
    CheckboxValue *transits;
    ColorpickerValue *transits_color;
    // Group separators. Pure layout: each draws one ImGui separator so the world
    // section reads as exfil+transit / grenade+tripwire / keypanel rather than one
    // flat run, and so the card's other sections are separated too. Registered in
    // the ctor's initialiser list at the START of each group, which is the only
    // place the ordering that matters is visible. See SeparatorValue.h.
    SeparatorValue *sep_world_grenade;
    CheckboxValue *grenade_esp;
    FloatSliderEditableValue *grenade_esp_distance;
    ColorpickerValue *grenade_color;
    CheckboxValue *grenade_show_fuse;
    CheckboxValue *tripwire_esp;
    ColorpickerValue *tripwire_color;
    SeparatorValue *sep_world_keypanel;
    // Keycard / code panels: show required keycard name or door code at the panel.
    CheckboxValue *keypanel_esp;
    FloatSliderEditableValue *keypanel_esp_distance;
    ColorpickerValue *keypanel_color;
    SeparatorValue *sep_world_players;

    MenuSectionValue *section_players_;
    CheckboxValue *players;
    ColorpickerValue *player_color;
    CheckboxValue *npc;
    ColorpickerValue *scav_color;
    ColorpickerValue *boss_color;
    ColorpickerValue *guard_color;
    ColorpickerValue *cultist_color;
    ColorpickerValue *raider_color;
    // Military (VSRF) — game ScavRole/VSRF, often localized as "Военный"
    ColorpickerValue *defector_color;
    // Peaceful civilians — game ScavRole/Civilian, often localized as "Мирный"
    ColorpickerValue *civilian_color;
    ColorpickerValue *black_division_color;
    ColorpickerValue *btr_color;
    CheckboxValue *show_bot_names;
    FloatSliderEditableValue *player_distance;
    SeparatorValue *sep_players_optic;

    // Optic ESP — own section (like Box / Skeleton headers).
    MenuSectionValue *section_optic_;
    // ADS: project ESP via BaseOpticCamera. Magnification and the lens opening come from
    // the lens pipeline (module/optics_lens_pipeline.h) when its packet is valid.
    CheckboxValue *esp_optic;
    // Section 7 region split (optic_idea.md line 574). See game_state::esp_optic_s7 for
    // why this exists and why it is a toggle rather than hard-wired.
    //
    // It started as a single binary "split the periphery onto the main camera", which
    // came from an architectural argument about ScopeMaskRenderer building a full-screen
    // mask. The user report (2026-09-27) showed the argument was wrong for the optics
    // actually in use: a magnified scope is a camera-in-camera with a CUTOUT, so the
    // surround is scope housing, not a second view, and ESP drawn there is ESP over the
    // housing. `esp_optic_periphery` below is the corrected form of the choice.
    CheckboxValue *esp_optic_s7;
    // What to do with ESP that lands outside the lens mask. Cull (default) matches a
    // magnified scope; Main Camera matches a 1x optic, where the game does render the
    // eye view around the glass and optic_idea.md line 574 is literally correct.
    // These are genuinely different optics, not a tuning range, so this is a select
    // rather than a slider or a bool.
    SelectValue *esp_optic_periphery;
    // ACTIVE INVESTIGATION (2026-10-05): the optic root-position outlier filter,
    // which lives in module/optics_lens_pipeline.h (optic_idea.md section 6,
    // line 476). ON = filter applies (current shipped behaviour). OFF = the
    // filter is skipped entirely and the lens matrix is left uncorrected.
    //
    // This exists to attribute a VISIBLE symptom: the scope picture shakes
    // violently when the optic centre is not at screen centre. Two candidates
    // exist for it -- this filter and the per-frame lens-mask refit -- and a
    // visible artefact cannot be attributed between two candidates without the
    // ability to turn one off. A shake that survives with this OFF is not this
    // filter, which is the whole point.
    //
    // It was an environment variable first (TA_OPTIC_ROOT_CORRECTOR_OFF=1) and
    // that was the wrong call: the switch is only useful if it can be thrown
    // MID-RAID, because setting up an off-centre magnified optic takes minutes
    // and an env var needs a relaunch. The env var is kept as an override that
    // still wins, so a scripted A/B remains possible.
    //
    // Default ON: the filter's shipped behaviour is not in question, only
    // whether it is the cause. Current evidence says the suspect is narrower
    // than the filter -- it applies on ~48 of 96 frames and snaps to zero on
    // the rest, which is a discontinuity, while the per-frame motion it is
    // cancelling is smooth (dt a steady 16 ms, 1-6 sign reversals per 95
    // frames). That is a real argument for shipping it OFF, and it is the
    // user's call, not this comment's.
    CheckboxValue *optic_root_corrector;
    SeparatorValue *sep_optic_overlay;
    // `Dual ADS ESP (Optic + Eyes)` REMOVED 2026-09-27, along with the
    // `ADS Mask Outline` colour that only existed to draw its boundary circle.
    // The Optic section is now a single checkbox, which is honest: everything
    // else about the projection is automatic.
    //
    // What dual mode did: rendered the world TWICE — pass 0 drew objects OUTSIDE the
    // lens circle through the FPS camera at 1x, pass 1 drew objects INSIDE it through
    // the optic camera magnified. A split view, not a fix.
    //
    // Why it could go: its original purpose was compensating for the absence of correct
    // magnification. The old radial path could not magnify, so "magnified in the circle,
    // normal outside" was a workaround. The section 7 primary chain now magnifies
    // correctly across the whole screen, so there was nothing left to compensate for.
    //
    // What remained was a deliberate DIVERGENCE from the game: real Tarkov shows only
    // the scope view and never renders the periphery, so dual mode made the ESP
    // disagree with the game image — which defeats the purpose of the optics rework. It
    // was also the source of the "everything is hidden" reports: it is the only thing
    // that sets game_state::esp_ads_mask_mode, hence the only thing that turned the lens
    // mask into a hard visibility cull, rejecting ~50% of checks.
    //
    // NOT the same thing as the section 7 dual-pass (optic_idea.md line 574), which is a
    // CORRECTNESS requirement: "For the main-camera pass, remove the interval inside the
    // mask; the remaining zero, one or two pieces stay visible." That is a per-SEGMENT
    // clip, and the two passes draw DISJOINT geometry at the SAME magnification. The
    // removed passes instead did a per-OBJECT cull at DIFFERENT magnifications per
    // region. Same loop shape, inverted semantics — section 7 needs a rewrite, and
    // the residual `dual_active` guards in the draw body are the record of what it must
    // NOT be.

    // Fallback-only appearance. These were user-facing sliders/select
    // (`esp_optic_scale_itm`, `esp_optic_mask_shape_sel`, `esp_optic_mask_size_itm`) and
    // were removed 2026-09-26 because each is DEAD whenever the lens pipeline is valid:
    //   - the mask shape and size are ignored by esp_ads_mask_contains, which prefers
    //     game_state::esp_lens_mask_px (the real fitted opening) whenever count >= 3
    //   - the radial scale is ignored outright by world_to_screen_optic's project_point
    //     path, which takes the magnification from the packet
    // So they only ever styled the legacy radial fallback, while reading as pipeline
    // controls. Defaults are carried here so restoring a control is a one-line change if
    // the pipeline turns out to be unreliable long-term — which is a live possibility,
    // since the packet is still invalid on many frames.
    inline static constexpr float kFallbackRadialScale = 1.0f;
    inline static constexpr float kFallbackMaskSize = 0.7f;
    inline static constexpr bool kFallbackMaskCircle = true;

    MenuSectionValue *section_overlay_;
    CheckboxValue *player_box;
    FloatSliderEditableValue *box_distance;
    ColorpickerValue *box_color;
    FloatSliderEditableValue *box_thickness;
    CheckboxValue *box_visibility;
    ColorpickerValue *box_visible_color;
    ColorpickerValue *box_occluded_color;
    CheckboxValue *player_health;
    ColorpickerValue *health_color;
    ColorpickerValue *health_low_color;
    SeparatorValue *sep_overlay_skeleton;

    MenuSectionValue *section_skeleton_;
    CheckboxValue *skeleton;
    CheckboxValue *skeleton_health_colors;
    FloatSliderEditableValue *skeleton_distance;
    // Distance within which the ESP casts its per-bone occlusion rays. Beyond it every
    // link is marked occluded and no physics is done. SEPARATE from skeleton_distance on
    // purpose: that one decides whether a skeleton is drawn at all, this one only whether
    // we pay ~10.9 us per bone to decide the colour. See EspModule.cpp collect_skeleton,
    // and note the draw path's empty-link_visible branch before changing what is left
    // unfilled. 75 m is a judgement, not a measurement -- `vis-dist-cap:` in the 30 s
    // report is what should replace it.
    FloatSliderEditableValue *skeleton_vis_distance;
    ColorpickerValue *skeleton_color;
    FloatSliderEditableValue *skeleton_thickness;
    CheckboxValue *skeleton_head_circle;
    // --- skeleton visibility ESP (rollback: remove block through skeleton_occluded_color) ---
    CheckboxValue *skeleton_visibility;
    ColorpickerValue *skeleton_visible_color;
    ColorpickerValue *skeleton_occluded_color;
    SelectValue *skeleton_vis_health_mode;
    SeparatorValue *sep_skeleton_loot;
    // --- end skeleton visibility ESP ---

    MenuSectionValue *section_loot_;
    CheckboxValue *loot_esp;
    FloatSliderEditableValue *loot_min_distance;
    FloatSliderEditableValue *loot_distance;
    IntSliderEditableValue *loot_min_value;
    CheckboxValue *show_loot_prices;
    CheckboxValue *loot_price_gradient;
    // When on: items with price >= Gradient Max Value are scanned/drawn at loot distance slider max (1500m).
    CheckboxValue *loot_high_value_max_range;
    ColorpickerValue *loot_gradient_cheap;
    ColorpickerValue *loot_gradient_expensive;
    ColorpickerValue *loot_gradient_above_max;
    IntSliderEditableValue *loot_gradient_max;
    ColorpickerValue *loot_color;
    ColorpickerValue *loot_hideout_color;
    ColorpickerValue *loot_wishlist_color;
    MenuSectionValue *section_loot_item_filter_;
    SeparatorValue *sep_loot_item_filter;
    CheckboxValue *loot_selected_items_only;
    ItemSearchValue *loot_selected_item;
    MenuSectionValue *section_loot_category_filter_;
    SelectValue *loot_category_filter;

    // Each loot-filter dropdown now sits behind its own toggle, and the two toggles are
    // EXCLUSIVE: only one may be on at a time. Enforcing that here, in the draw path,
    // rather than leaving both predicates live is what makes "only one allowed" true
    // instead of advisory -- both axes were previously applied together, so a caller
    // that picked a category also silently restricted to the wishlist group.
    CheckboxValue *loot_category_filter_enabled;
    // Wishlist / Hideout only (Profile.WishlistManager). All OFF → no category filter.
    // Registered directly AFTER loot_category_filter_enabled so the Wishlist Group
    // dropdown renders immediately above its own toggle, keeping each filter pair
    // visually adjacent instead of split across the card.
    SelectValue *loot_wl_filter;
    CheckboxValue *loot_wishlist_filter_enabled;
    // Enforces exclusivity. Called from draw_menu_extra before either predicate can
    // observe the values; returns true when it changed something, so the caller can
    // reset the now-disabled dropdown to All and not leave a stale selection behind.
    bool enforce_loot_filter_exclusivity();
    // Must match loot_distance slider upper bound (FloatSliderEditableValue max).
    static constexpr float k_loot_distance_slider_max = 1500.f;
    CheckboxValue *show_provisions;
    CheckboxValue *corpse_show_loot;
    SeparatorValue *sep_loot_containers;

    MenuSectionValue *section_containers_;
    CheckboxValue *container_esp;
    CheckboxValue *container_show_loot;
    CheckboxValue *container_show_value;
    FloatSliderEditableValue *container_distance;
    ColorpickerValue *container_color;
    SeparatorValue *sep_containers_quest;

    MenuSectionValue *section_quest_;
    // Ground quest items (GameWorld.QuestItemsList) — separate from Quest ESP POI / loot ESP.
    CheckboxValue *quest_items;
    FloatSliderEditableValue *quest_item_distance;
    ColorpickerValue *quest_item_color;
    CheckboxValue *quest_esp_enabled;
    CheckboxValue *quest_esp_descriptions;
    FloatSliderEditableValue *quest_esp_distance;
    ColorpickerValue *quest_visit_color;
    ColorpickerValue *quest_find_color;
    ColorpickerValue *quest_place_color;

    struct exfil
    {
        std::string name;
        int status;
        unity::vector3 pos3d;
        std::string requirement; // "Item name" when the point needs an item

        // What KIND of exit this is, which the label has to say and did not before.
        //
        //   secret     a SecretExfiltrationPoint. Its required item is settings->Id --
        //              already human-readable prose, NOT a locale key, so it is used verbatim.
        //   scav_coop  carries a ScavCooperationRequirement, i.e. it needs a scav partner.
        //
        // Both are properties of the OBJECT, resolved once per frame by
        // eft_api::try_get_exfil_label_parts, not of which array the point was found in.
        bool secret = false;
        bool scav_coop = false;

        // Whether THIS PLAYER may leave by this extract right now, as opposed to what phase
        // the extract is in. The two are different questions and conflating them is the bug
        // the user reported on 2026-10-05: an extract reads "Open" while being unusable
        // because the player is Scav, a requirement is unmet, or it is entry-point gated.
        //
        // `unknown` means the snapshot could not be taken, and the draw pass then falls back
        // to the status label it always had. Deliberate: a stale "Open" is bad, showing nothing
        // would be worse, and treating a failed snapshot as authoritative is what shipped the
        // original bug.
        eft_api::exfil_eligibility eligibility = eft_api::exfil_eligibility::unknown;
    };
    struct transit
    {
        std::string name;
        unity::vector3 pos3d;
    };
    struct grenade_entry
    {
        std::string label;
        unity::vector3 pos3d{};
        float distance = 0.f;
        float fuse_remaining = -1.f;
    };
    struct tripwire_entry
    {
        unity::vector3 pos3d{};
        float distance = 0.f;
    };
    struct keypanel_entry
    {
        std::string label;       // keycard name(s) and/or door code
        std::string passcode_id; // PasscodeTerminal id — resolve code lazily (may arrive late)
        unity::vector3 pos3d{};
        float distance = 0.f;
        bool is_code = false;
    };
    struct bot_corpse_marker
    {
        unity::vector3 pos3d{};
        float distance = 0.f;
    };

    struct player
    {
        std::wstring label_wide;
        std::string prefix_utf8;
        std::string name_utf8;
        std::string label_utf8;
        bool show_name_line = false;
        eft_api::npc_kind kind = eft_api::npc_kind::scav;
        unity::vector3 pos3d{};
        unity::vector3 head_pos{};
        float distance = 0.f;
        float health_current = 0.f;
        float health_max = 0.f;
        bool is_alive = true;
        bool any_part_visible = true;
        // The view-cone decision for this player, COMPUTED ONCE per frame in the game
        // loop and carried here.
        //
        // It exists so the two consumers cannot disagree. The skeleton build gate and the
        // store-side filter used to each recompute the angle independently, which is a race
        // waiting to happen -- an entry could be built and then dropped, or dropped and
        // then built -- and it is also what makes hysteresis possible at all, since the
        // grace state is per-player and has to be looked up by identity.
        bool in_view_cone = true;
    };

    struct skeleton_entry
    {
        std::unordered_map<std::string, unity::vector3> bones;
        eft_api::npc_kind kind = eft_api::npc_kind::scav;
        float distance = 0.f;
        std::array<eft_api::health_value, 7> limb_health{};
        std::array<bool, 7> limb_destroyed{};
        bool has_limb_health = false;
        // --- skeleton visibility ESP (rollback: remove link_visible) ---
        std::vector<bool> link_visible;
        // --- end skeleton visibility ESP ---
    };

    struct loot_entry
    {
        std::string name;
        unity::vector3 pos3d;
        bool is_container;
        int price;
        bool is_quest = false;
        float distance = 0.f;
        bool is_corpse_loot = false;
        item_categories::kind cat = item_categories::kind::other;
        // Which wishlist GROUP, alongside the flat `cat`. Resolved at the same moment and
        // for the same lookup, so the draw path never re-hashes a template id.
        item_categories::wishlist_group wl = item_categories::wishlist_group::none;
        std::string template_id;
    };

    struct container_item_entry
    {
        std::string name;
        int count = 1;
        int price = 0;
        bool is_quest = false;
        bool is_provision = false;
        bool is_money = false;
        std::string template_id;
        item_categories::kind cat = item_categories::kind::other;
        // Which wishlist GROUP, alongside the flat `cat`. Resolved at the same moment and
        // for the same lookup, so the draw path never re-hashes a template id.
        item_categories::wishlist_group wl = item_categories::wishlist_group::none;
    };

    struct container_esp_entry
    {
        std::string container_name;
        unity::vector3 pos3d;
        float distance = 0.f;
        std::shared_ptr<const std::vector<container_item_entry>> items;
        int total_price = 0;
    };

    unity::vector3 my_pos = {};

    // Per-frame ESP data is published from gameworld_update() (the IL2CPP thread)
    // and consumed by draw_overlay() (the render thread). These are therefore
    // IMMUTABLE SNAPSHOTS, not live vectors: a writer builds a fresh vector and
    // swaps the pointer under data_mutex, and a reader copies the pointer out and
    // iterates it with no lock held at all.
    //
    // This was not the shape before 2026-09-30. draw_overlay() captured
    // `&store` for eleven of these under the lock, released it, and dereferenced
    // the pointer ~530 lines later while drawing. gameworld_update() meanwhile
    // ran `store = std::move(temp)`, which frees the buffer. That is a
    // use-after-free, and it killed the process: the fault was a READ of 0x288
    // inside `entry.bones.find()` -- an unordered_map walking a bucket pointer
    // read out of freed memory. Tracked as SOLVED.md 13.
    //
    // The rule, and it is not optional: under no circumstances may a raw pointer
    // to one of these escape the lock scope. A pointer escape is invisible in
    // review and only shows up as a crash minutes into a raid.
    //
    // They are never null. clear_runtime_cache() publishes an EMPTY vector rather
    // than resetting the pointer, so `*store` is always safe to dereference and a
    // future reader cannot reintroduce a null-deref by forgetting a null check.
    using exfil_snapshot = std::shared_ptr<const std::vector<exfil>>;
    using transit_snapshot = std::shared_ptr<const std::vector<transit>>;
    using grenade_snapshot = std::shared_ptr<const std::vector<grenade_entry>>;
    using tripwire_snapshot = std::shared_ptr<const std::vector<tripwire_entry>>;
    using keypanel_snapshot = std::shared_ptr<const std::vector<keypanel_entry>>;
    using player_snapshot = std::shared_ptr<const std::vector<player>>;
    using loot_snapshot = std::shared_ptr<const std::vector<loot_entry>>;
    using skeleton_snapshot = std::shared_ptr<const std::vector<skeleton_entry>>;
    using quest_poi_snapshot = std::shared_ptr<const std::vector<quest_esp::poi_entry>>;
    using bot_corpse_snapshot = std::shared_ptr<const std::vector<bot_corpse_marker>>;

    template <typename T>
    static std::shared_ptr<const std::vector<T>> publish(std::vector<T> &&data) {
        return std::make_shared<const std::vector<T>>(std::move(data));
    }

    template <typename T>
    static std::shared_ptr<const std::vector<T>> publish_empty() {
        return std::make_shared<const std::vector<T>>();
    }

    exfil_snapshot exfil_store = publish_empty<exfil>();
    transit_snapshot transits_store = publish_empty<transit>();
    grenade_snapshot grenade_store = publish_empty<grenade_entry>();
    tripwire_snapshot tripwire_store = publish_empty<tripwire_entry>();
    std::shared_ptr<const std::vector<keypanel_entry>> keypanel_store = publish_empty<keypanel_entry>();
    // FindObjectsOfType is expensive — scan once per enable/raid, never on a timer.
    bool keypanel_scanned_once_ = false;
    player_snapshot player_store = publish_empty<player>();
    // The player object this raid's ESP is drawn around, captured by gameworld_update on the
    // game thread and READ by draw_overlay on the render thread.
    //
    // nullptr-INITIALISED (it was not, before 2026-10-12). This is not a theoretical
    // initialisation nit: the module is HEAP allocated -- ModuleManager.h:122 is
    // `module(new EspModule())`, and the module() helper only pushes the pointer, so this is
    // default-initialisation, not value-initialisation. `EspModule() = default` plus an
    // initialiser-less pointer member leaves it INDETERMINATE, where a global or a static
    // would have been zero-filled by the loader.
    //
    // And it is reachable before it is ever assigned. gameworld_update only runs in a raid,
    // but draw_overlay runs from dxPresent11 -> draw_imgui -> menu::draw -> ModuleManager::apply
    // on the RENDER thread, every presented frame from process start. So the first raid's
    // first gameworld_update is strictly later than the first draw_overlay, and the guard at
    // EspModule.cpp:5029 dereferences this pointer's ->klass.
    //
    // That said: this is a latent defect with NO observed crash behind it. Every crash
    // investigated so far that this pointer is implicated in involved a STALE pointer after a
    // finished raid (pid 24116), not this one. The initialiser and the reset are both cheap
    // and both remove a whole class, which is why they are here -- but do not read this
    // comment as claiming the pre-raid window has crashed anything.
    //
    // The CLEARING is the load-bearing half: see reset_raid_context() for the crash it fixes.
    Il2CppObject *main_player_ = nullptr;
    loot_snapshot loot_store = publish_empty<loot_entry>();
    loot_snapshot quest_item_store = publish_empty<loot_entry>(); // dedicated Quest Item ESP (QuestItemsList)
    std::shared_ptr<const std::vector<container_esp_entry>> container_store_;
    std::shared_ptr<const std::vector<container_esp_entry>> corpse_store_;
    skeleton_snapshot skeleton_store = publish_empty<skeleton_entry>();
    quest_poi_snapshot quest_poi_store = publish_empty<quest_esp::poi_entry>();
    bot_corpse_snapshot bot_corpse_store_ = publish_empty<bot_corpse_marker>();
    mutable std::unordered_set<std::string> bot_corpse_ai_profiles_;
    ULONGLONG bot_corpse_last_scan_ms_ = 0;
    mutable ULONGLONG bot_corpse_ai_profiles_ms_ = 0;

    struct container_registry_entry
    {
        uintptr_t obj_key = 0;
        std::string name;
        unity::vector3 pos3d{};
        float distance = 0.f;
        float dist_sq = 0.f;
        bool has_pos = false;
        bool in_range = false;
    };

    struct corpse_registry_entry
    {
        uintptr_t obj_key = 0;
        Il2CppObject *inventory_root = nullptr;
        std::string name;
        unity::vector3 pos3d{};
        float distance = 0.f;
        float dist_sq = 0.f;
        bool has_pos = false;
        bool in_range = false;
    };

    struct container_item_cache
    {
        uintptr_t obj_key = 0;
        std::string name;
        std::vector<container_item_entry> items;
        std::shared_ptr<const std::vector<container_item_entry>> items_ptr;
        int cached_item_count = 0;
        int total_price = 0;
        ULONGLONG last_refresh = 0;
    };
    inline static std::vector<container_registry_entry> container_registry_{};
    inline static std::unordered_map<uintptr_t, container_item_cache> container_item_caches_{};
    inline static std::vector<loot_entry> container_marker_snapshot_{};
    inline static size_t container_position_cursor_ = 0;
    inline static size_t container_loot_refresh_cursor_ = 0;
    inline static std::vector<corpse_registry_entry> corpse_registry_{};
    inline static std::unordered_map<uintptr_t, container_item_cache> corpse_item_caches_{};
    inline static size_t corpse_loot_refresh_cursor_ = 0;
    inline static ULONGLONG corpse_last_tick_ms_ = 0;
    inline static ULONGLONG corpse_last_scan_ms_ = 0;
    inline static ULONGLONG container_registry_scan_ms_ = 0;
    // When the FIRST container discovery ran this raid. Anchors the early-ramp interval
    // below; `container_registry_scan_ms_` moves on every scan and so cannot serve.
    // Reset per raid alongside the others in clear_runtime_cache().
    ULONGLONG container_first_scan_ms_ = 0;
    inline static ULONGLONG container_last_tick_ms_ = 0;

  private:
    struct ItemCacheData
    {
        std::string name;
        int price;
        bool is_provision;
        bool is_corpse_loot = false;
        // Resolved once per item object (audit 09-25 #3) — pricing, classify and
        // the quest filter all reuse this instead of re-walking Template per scan.
        std::string template_id;
    };
    // ---- GAME-THREAD-ONLY CACHES ------------------------------------------
    // item_info_cache, template_name_cache_, container_item_caches_ and
    // corpse_item_caches_ are written only from gameworld_update /
    // application_update / clear_runtime_cache. Nothing else may touch them.
    //
    // They used to have one more reader: get_runtime_cache_count() and
    // get_runtime_cache_bytes() walked all four from the render thread (via
    // ConfigModule::draw_cache_info) while holding data_mutex -- a mutex no
    // writer of these four maps ever took. The lock therefore protected
    // nothing, and the render thread rehashed-iterate the same containers the
    // game thread was inserting into. The statistics are now computed on the
    // game thread and published as atomics, so the render thread no longer
    // reads a cache at all. If you add a reader here, that invariant breaks.
    std::unordered_map<Il2CppObject *, ItemCacheData> item_info_cache;
    std::unordered_map<std::string, std::string> template_name_cache_;
    std::atomic<size_t> stats_entries_{0};
    std::atomic<size_t> stats_bytes_{0};
    ULONGLONG stats_last_computed_ms_ = 0;
    void refresh_cache_stats();
    const Il2CppObject *last_game_world_ptr = nullptr;
    std::string last_raid_location_id_;
    std::string current_location_id;
    std::string current_location_display_name;
    bool minimap_configs_scanned = false;
    mutable float minimap_center_u_ = 0.5f;
    mutable float minimap_center_v_ = 0.5f;
    mutable bool minimap_follow_player_ = true;
    mutable bool minimap_has_last_player_pos_ = false;
    mutable unity::vector3 minimap_last_player_pos_{};
    mutable bool minimap_dragging_ = false;
    mutable ImVec2 minimap_drag_last_{};
    mutable float compass_anim_yaw_ = 0.f;
    mutable bool compass_anim_initialized_ = false;
    mutable ULONGLONG compass_anim_last_ms_ = 0;
    uint64_t last_prices_version_ = 0;
    ULONGLONG quest_esp_last_refresh_ms_ = 0;
    // When the last "these objectives are finished now" sweep ran. NOT the same clock as
    // quest_esp_last_refresh_ms_: that one gates the full collect and fires once per raid,
    // this one gates the re-filter that keeps the collected markers honest for the rest of
    // it. Reset wherever the collect clock is reset — a stale stamp across a raid boundary
    // would delay the first sweep of the new raid by up to one interval, which is harmless,
    // but resetting them together is the thing that stays true.
    ULONGLONG quest_poi_sweep_ms_ = 0;
    ULONGLONG loot_esp_last_scan_ms_ = 0;
    // Ground-loot scan is amortized across ticks (see do_loot_scan below): processing
    // the whole loot list synchronously in one frame was the dominant per-tick cost
    // on loot-dense maps. loot_scan_accum_ holds results until a cycle completes.
    size_t loot_scan_cursor_ = 0;
    bool loot_scan_active_ = false;
    std::vector<loot_entry> loot_scan_accum_;

    // Cached per-loot-object pointer chain. See the block at the head of the scan
    // loop in EspModule.cpp for why only this and not the position is cached.
    struct LootNodeCacheEntry {
        Il2CppObject *transform = nullptr;
        const Il2CppClass *klass = nullptr;   // ABA guard: see loot_node_cache_valid
        uint64_t last_seen = 0;               // sweep sequence, for eviction
        bool chain_ok = false;
        bool is_corpse = false;
        bool corpse_tested = false;           // which corpse_show_loot value is_corpse reflects
    };
    std::unordered_map<Il2CppObject *, LootNodeCacheEntry> loot_node_cache_;
    uint64_t loot_sweep_seq_ = 0;
    // Sweep sequence at which the CURRENT cycle began. Eviction compares against
    // this rather than against sweep_seq - N: a cycle is a variable number of
    // chunks (loot_scan_chunk is 256 but the array length is not a multiple of
    // it, and the array length itself changes as loot spawns), so a fixed
    // chunk-count horizon can be shorter than one cycle and evict an item
    // before its next scheduled visit -- which is exactly what a chunk-based
    // horizon did, at a measured 79% miss rate.
    uint64_t loot_cycle_start_seq_ = 0;

    // A cached chain is only trusted when the object's class is unchanged AND the
    // corpse-toggle that produced is_corpse is still the one in force. The class
    // compare is what catches the freed-then-reallocated case (same address, new
    // object) for the cost of one pointer compare; without it a stale transform
    // would be read and the process would fault.
    bool loot_node_cache_valid(const LootNodeCacheEntry &e, const Il2CppObject *o,
                               bool scan_corpse_loot) const {
        return e.chain_ok && e.klass == o->klass && e.corpse_tested == scan_corpse_loot;
    }
    ULONGLONG quest_items_last_scan_ms_ = 0;
    item_categories::filter_sets wishlist_sets_{};
    ULONGLONG wishlist_sets_refresh_ms_ = 0;

    std::mutex data_mutex;

    static ImVec4 lerp_color(const ImVec4 &a, const ImVec4 &b, const float t);

    // The user's wishlist selection as a bitmask, in wishlist_group order. The single
    // place that reads loot_wl_filter: both loot_category_allowed() and
    // matches_loot_teleport_filter() need it, and two copies of a predicate is how
    // this file ended up with two disagreeing copies of the filter in the first place.
    //
    // Index 0 (All) returns 0, which item_categories::wishlist_allows defines as
    // "no group selection expressed" -- admits everything. So All behaves as before
    // and never hides loot.
    item_categories::wishlist_mask wishlist_mask() const;
    // kind AND group. The group travels on the entry rather than being looked up again:
    // classify_template() is a hash lookup and this is called per item per frame.
    bool loot_category_allowed(const item_categories::kind cat, const item_categories::wishlist_group group) const;
    bool any_loot_category_filter() const;

    // `name` is no longer READ. It was taken by const reference rather than by value
    // because this runs per cached item per FRAME and a by-value std::string
    // heap-copied every container/corpse item's name every frame -- that fix stands.
    //
    // The parameter itself is now dead: the category comes from the item's
    // ItemTemplate class (item_categories::loot), resolved once at db build time,
    // rather than from substring-matching the display name. The signature is kept so
    // the call sites do not have to change -- several of them pass an empty string
    // already -- but it is ignored, and the `(void)name` at the definition says so.
    // Removing it is a follow-up that touches every call site for no behaviour gain.
    bool loot_ui_filter_allowed(const std::string &template_id, const std::string &name) const;

    ImVec4 color_for_loot_category(const item_categories::kind cat) const;

    // Wishlist/hideout template IDs from API — once until cache clear or manual refresh.
    void ensure_wishlist_sets(Il2CppObject *profile, const bool force = false);

    item_categories::kind classify_template(const std::string &template_id) const;

    ImVec4 color_for_loot_price(const int price, const bool is_quest, const bool is_provision) const;

    ImVec4 get_npc_color(const eft_api::npc_kind kind) const;

    static void draw_corner_box(ImDrawList *draw_list, const ImVec2 &pos, const ImVec2 &size, const ImU32 color,
        const float thickness, const float corner_len, const bool drawn_scoped = true);

    void draw_player_health_bar(ImDrawList *draw_list, const ImVec2 &box_pos, const ImVec2 &box_size,
        const player &entry) const;

    void draw_player_label_text(ImDrawList *draw_list, const ImVec2 &anchor, const ImVec4 &color, const player &entry,
        const float distance) const;

    // shooter_obj is the LOCAL player, threaded through so the occlusion walk can tell a
    // hit on our own body apart from a hit on the target's. Null disables the shooter test
    // and restores the old two-outcome behaviour.
    bool is_player_any_part_visible(const unity::vector3 &vis_origin, Il2CppObject *player_obj,
        Il2CppObject *shooter_obj = nullptr) const;

    bool compute_player_box_layout(Il2CppObject *cam, const player &entry, ImVec2 &box_pos, ImVec2 &box_size,
        ImVec2 &label_anchor, ImVec4 &color, bool *drawn_scoped) const;

    void draw_player_box_geometry(ImDrawList *draw_list, const ImVec2 &box_pos, const ImVec2 &box_size,
        const ImVec4 &color, const player &entry, const bool drawn_scoped = true) const;

    // `compute_player_box_layout_optic` REMOVED 2026-09-27.
    //
    // It was the *second*, optic-specific box layout, and it had the exact defect the
    // "stretched and placed in both places" report traced to: head and feet projected
    // INDEPENDENTLY through `world_to_screen`, whose section 7 dispatch is per point, so
    //
    //     height = fabsf(head_screen.y - feet_screen.y)
    //
    // could subtract an optic-chain y from a main-camera y. The live layout fixed that by
    // choosing one camera for the whole box.
    //
    // It was unreachable anyway -- its only call site sat behind
    // `if (dual_active && esp_ads_mask_mode == 2)`, and `dual_active` is a hard
    // `const bool = false`, so the compiler had already deleted it. Leaving a broken
    // duplicate wired to the one call site that looks optic-specific was a trap: it read
    // like the optic box path, and it was the wrong one. Deleted rather than fixed,
    // because fixing it would have produced two divergent box layouts.

    // Optic-aware skeleton entry drawing
    // `lens_renderer` was dropped 2026-09-27. It became unused when `to_screen` moved to
    // world_to_screen_scoped_only, and leaving a parameter that reads like it selects the
    // projection while selecting nothing is worse than removing it.
    void draw_skeleton_entry_optic(ImDrawList *draw_list, Il2CppObject *cam, const skeleton_entry &entry) const;

    // Optic-aware player label text drawing
    void draw_player_label_text_optic(ImDrawList *draw_list, Il2CppObject *cam, const player &entry,
        const ImVec4 &color, Il2CppObject *lens_renderer) const;

    ImVec4 limb_health_color(const eft_api::health_value &part, const bool destroyed) const;

    ImU32 skeleton_link_color(const skeleton_entry &entry, const int body_part,
        const std::optional<size_t> link_index = std::nullopt) const;

    skeleton_entry collect_skeleton(Il2CppObject *player_obj, const eft_api::npc_kind kind, const float distance,
        const bool check_visibility, const unity::vector3 &vis_origin,
        Il2CppObject *shooter_obj = nullptr, const float vis_check_max_dist = 0.f) const;

    // Frame counter for the visibility gate: bumped once per drawn frame in draw_overlay,
    // compared per player in collect_skeleton. A drawn-frame clock and not a tick clock,
    // because the two differ by 1.67x and only one of them is what the user sees.
    std::atomic<unsigned long long> vis_frame_serial_{0};

    // Last computed link_visible per player, keyed on the player pointer, so a gated tick
    // serves the previous answer instead of repainting every limb as occluded.
    struct vis_memo_entry
    {
        unsigned long long frame = 0;
        std::vector<bool> link_visible;
    };
    // Game-thread only (written and read in collect_skeleton), so no lock is needed -- the
    // render thread never touches it.
    //
    // mutable because collect_skeleton is const: this is a cache keyed on an input, not part
    // of the module's observable state, and the const there is about not mutating the
    // published snapshots. vis_frame_serial_ is NOT mutable because it is bumped from
    // draw_overlay, which is non-const.
    mutable std::unordered_map<uintptr_t, vis_memo_entry> vis_memo_;

    // Per-player view-cone grace state, keyed on the player object pointer.
    //
    // Exists ONLY to stop skeletons flickering as the player turns. A bare angle test has no
    // memory, so a target a few degrees outside the edge flips on and off with every mouse
    // movement -- reported on 2026-10-04 as skeletons "drastically change their
    // draw-status" when looking around. This gives the decision a short memory: a target
    // that leaves the cone is still processed for kConeGraceFrames frames before it is
    // dropped.
    //
    // Keyed on the POINTER, not on distance or name, so a recycled or freed player entity
    // can never inherit the previous occupant's grace. The map is pruned of entries that
    // have been outside for longer than the grace, so it cannot grow without bound across a
    // raid.
    //
    // Game thread only -- written and read inside gameworld_update, like vis_memo_ above,
    // and for the same reason: the render thread never touches it.
    struct cone_memo_entry
    {
        int outside_frames = 0;
        unsigned long long seen = 0; // cone tick of the last update, for the stale sweep
    };
    std::unordered_map<uintptr_t, cone_memo_entry> cone_memo_;
    void draw_skeleton_entry(ImDrawList *draw_list, Il2CppObject *cam, const skeleton_entry &entry,
        Il2CppObject *lens_renderer = nullptr) const;

    static float get_transform_yaw_y(Il2CppObject *transform);

    // The failure-explicit form, which get_transform_yaw_y cannot be: that one returns
    // 0.f for a null transform, an unresolved `get_eulerAngles`, AND a genuine 0 degrees.
    // Anything that GATES on the yaw must use this, or a failed read becomes a
    // confidently wrong direction. See the note at the definition.
    static bool try_get_transform_yaw_y(Il2CppObject *transform, float &out_deg);

    static float get_view_yaw(Il2CppObject *cam);

    static float normalize_degrees(float deg);

    static float shortest_angle_delta(float from_deg, float to_deg);

    void update_compass_anim(const float target_yaw) const;

    bool world_to_radar_point(const unity::vector3 &pos, const float view_yaw, const float cx, const float cy,
        const float range, const float scale, ImVec2 &out) const;

    static bool player_moved_on_map(const unity::vector3 &current, const unity::vector3 &previous);

    static ImU32 col_alpha(const ImU32 col, const float opacity);

    static ImU32 col4_alpha(const ImVec4 &color, const float opacity);

    static float minimap_glyph_half_extent(ImFont *hud_font, const float font_size, const char *symbol);

    static float minimap_label_anchor_y(const ImVec2 &point, const float icon_font, const float height_dy,
        const float sf, ImFont *hud_font, const char *marker_symbol = nullptr);

    void draw_minimap_player_marker(ImDrawList *draw_list, const ImVec2 &origin, const float dir_x, const float dir_y,
        const float sf, const float opacity, const bool rotate_map) const;

    static void rotate_draw_list_verts(ImDrawList *draw_list, const int vtx_start, const ImVec2 &center,
        const float rad);

    void draw_minimap_symbol_marker(ImDrawList *draw_list, const ImVec2 &center, const char *symbol,
        const float font_size, const float opacity, const ImVec4 &color,
        const float rotation_rad = 0.f) const;

    static float pick_grid_spacing(const float range);

    void draw_minimap_grid(ImDrawList *draw_list, const bool use_map, const minimap::map_bounds &display_bounds,
        const minimap::map_view_transform &view, const float map_yaw_deg, const float cx,
        const float cy, const float range, const float radar_scale, const float rx, const float ry,
        const float size, const float sf, const float opacity, const bool rotate_map) const;

    static ImVec2 square_compass_ring_point(const float cx, const float cy, const float outer_half, const float deg);

    static void minimap_compass_padding(const float sf, float &pad_h, float &pad_v);

    void draw_minimap_compass_frame(ImDrawList *draw_list, const float rx, const float ry, const float size,
        const float sf, const float opacity, const float heading_deg, const bool rotate_map,
        const bool draw_backdrop, const ImVec4 &backdrop_color) const;

    void draw_minimap_height_indicator(ImDrawList *draw_list, const ImVec2 &point, const float marker_y,
        const float player_y, const float marker_font, const char *marker_symbol,
        const float sf, const ImVec4 &color, const float opacity) const;

    static bool is_point_inside_minimap(const ImVec2 &point, const float rx, const float ry, const float size,
        const float pad = 0.f);

    void draw_radar_marker_label(ImDrawList *draw_list, const ImVec2 &point, const ImVec4 &color,
        const std::string &text, const float font_size, const float opacity,
        const float clip_rx = 0.f, const float clip_ry = 0.f, const float clip_size = 0.f,
        const float marker_icon_font = 0.f, const float height_dy = 0.f,
        const float sf = 1.f) const;

    bool resolve_minimap_marker_point(const bool use_map, const minimap::map_bounds &display_bounds,
        const minimap::map_view_transform &view, const unity::vector3 &pos,
        const float map_yaw, const float cx, const float cy, const float range,
        const float radar_scale, const float rx, const float ry, const float size,
        ImVec2 &out) const;

    void draw_radar_header_label(ImDrawList *draw_list, const ImVec2 &top_left, const std::string &text,
        const float font_size, const float opacity) const;

    static std::string read_location_id(const Il2CppClass *game_world_class, Il2CppObjectInstance &game_world_instance);

    struct minimap_layout
    {
        float rx = 0.f;
        float ry = 0.f;
        float size = 0.f;
    };

    minimap_layout compute_minimap_layout(const float sf) const;

    static float minimap_header_label_y(const float ry, const float size, const int corner);

    void handle_radar_window_input(const float rx, const float ry, const float size,
        const minimap::map_view_transform *view) const;

    void scan_bot_corpses_for_minimap(Il2CppObjectInstance &game_world_instance,
        std::vector<bot_corpse_marker> &out) const;

    void draw_radar_overlay(ImDrawList *draw_list, const std::vector<player> &players, const std::vector<exfil> &exfils,
        const std::vector<transit> &transits, const std::vector<quest_esp::poi_entry> &quest_pois,
        const std::vector<bot_corpse_marker> &bot_corpses, const float view_yaw) const;

    static void format_price_suffix(char *buf, const size_t buf_size, const int price);

    bool should_show_container_item(const container_item_entry &item) const;

    bool should_show_corpse_item(const container_item_entry &item) const;

    container_item_cache *find_container_item_cache(const uintptr_t obj_key);

    std::string resolve_localized_item_name(Il2CppObject *item_obj,
        Il2CppString *(*localized_short_name)(Il2CppObject *),
        Il2CppString *(*localized_name)(Il2CppObject *));

    void fill_item_cache_entries(container_item_cache &entry, Il2CppObject *root_item,
        const std::function<bool(const std::function<bool(Il2CppObject *)> &)> &foreach_items);

    void refresh_container_item_cache(container_item_cache &entry, Il2CppObject *container_obj);

    void refresh_corpse_item_cache(container_item_cache &entry, Il2CppObject *inventory_root);

    container_item_cache *find_corpse_item_cache(const uintptr_t obj_key);

    bool update_container_registry_position(container_registry_entry &entry);

    // Quantize world position so co-located containers (same furniture) share a key.
    // Language-independent: drawers share one transform regardless of locale name.
    static std::string colocation_key(const unity::vector3 &pos);

    // Merge co-located container markers into ONE label at the shared origin.
    // Fan-out caused far-distance "jumping" with breath/sway (labels fought over pixels).
    static void merge_colocated_container_markers(std::vector<loot_entry> &markers);

    // Merge co-located container loot lists into one stack at shared origin.
    static void merge_colocated_container_lists(std::vector<container_esp_entry> &list);

    // Hide [Nm] on loot/containers/quests while manual refresh freezes world data.
    static bool show_esp_distance_labels();

    void refresh_container_registry_distances(const unity::vector3 &player_pos, const float min_dist_sq,
        const float max_dist_sq);

    bool update_corpse_registry_position(corpse_registry_entry &entry);

    static bool is_active_thrown_grenade(Il2CppObject *obj);

    static float try_get_grenade_fuse_remaining(Il2CppObject *grenade_obj);

    static std::string resolve_grenade_label(Il2CppObject *grenade_obj,
        Il2CppString *(*localized_short_name)(Il2CppObject *));

    void scan_grenade_esp(Il2CppObjectInstance &game_world_instance, const unity::vector3 &player_pos,
        std::vector<grenade_entry> &out_grenades);

    // Walk System.Collections.Generic.List`1: _items + _size (IL2CPP layout).
    static void for_each_il2cpp_list(Il2CppObject *list_obj, const std::function<void(Il2CppObject *)> &fn);

    static bool try_tripwire_world_pos(Il2CppObject *obj, unity::vector3 &out);

    // Tripwires after plant leave _active and live in:
    //   TripwireManager._tripwires  AND/OR  _staticSynchronizableObjects
    // (Stupid.Solutions iterates GetSynchronizableObjects() which yields BOTH lists.)
    void scan_tripwire_esp(Il2CppObjectInstance &game_world_instance, const unity::vector3 &player_pos,
        std::vector<tripwire_entry> &out_tripwires);

    // ---------------------------------------------------------------------------
    // Keycard / code panel ESP
    // WorldInteractiveObject.KeyId  — key template id (or legacy numeric KeyId)
    // KeycardDoor._additionalKeys    — extra accepted keycard template ids
    // CardReader._keyMap             — KeyTriggerPair[].KeyId per card
    // PasscodeTerminal (EFT.Passcodes) — modern keypad; code lives in
    //   ClientLocalPasscodeController._generatedPasscodes[passcodeId]
    // Prefer InteractiveProxy positions (the physical panel) when present.
    // ---------------------------------------------------------------------------

    static std::string read_il2cpp_string_field(Il2CppObject *obj, const char *field_name);

    static bool looks_like_door_code(const std::string &id);

    static std::string lookup_item_db_name(const std::string &template_id);

    std::string resolve_key_requirement_name(const std::string &key_id);

    static void collect_string_array_ids(Il2CppArray *arr, std::vector<std::string> &out);

    // CardReader.KeyTriggerPair: string KeyId@0, string TriggerId@8, bool Success@10 → stride 0x18
    static void collect_card_reader_key_ids(Il2CppObject *reader, std::vector<std::string> &out);

    static bool try_component_world_pos(Il2CppObject *component, unity::vector3 &out);

    // Collect proxy panel positions; if none, fall back to the interactive object itself.
    static void collect_panel_positions(Il2CppObject *wio, std::vector<unity::vector3> &out_pos);

    void consider_key_interactive(Il2CppObject *obj, std::unordered_set<uintptr_t> &seen_objs,
        std::vector<keypanel_entry> &out);

    // Dictionary<string,string> — passcodeId → generated code (local/offline controller).
    static void collect_string_string_dict(Il2CppObject *dict_obj, std::unordered_map<std::string, std::string> &out);

    static Il2CppObject *resolve_passcode_controller(Il2CppObjectInstance &game_world_instance);

    static void build_generated_passcode_map(Il2CppObject *controller,
        std::unordered_map<std::string, std::string> &out);

    // Dictionary<string, List<PasscodeTerminal>> → every terminal instance.
    static void foreach_passcode_terminal_from_controller(Il2CppObject *controller,
        const std::function<void(Il2CppObject *)> &fn);

    void consider_passcode_terminal(Il2CppObject *terminal,
        const std::unordered_map<std::string, std::string> &passcodes,
        std::unordered_set<uintptr_t> &seen_objs, std::vector<keypanel_entry> &out);

    // Cheap: re-read _generatedPasscodes and patch labels (codes generate after raid start).
    //
    // REQUIRES data_mutex HELD BY THE CALLER. This function does not lock it.
    // It used to, and its only caller already held it -- a recursive acquisition
    // of a non-recursive std::mutex, which MSVC's lock() reports by throwing
    // std::system_error. That killed the game on 2026-10-01 09:01; the crash
    // probe named the type and the call chain. Keep the lock at the call site,
    // where it also has to span both the read and the republish so a reader
    // cannot see a snapshot and a published vector from different passes.
    void refresh_passcode_labels(Il2CppObjectInstance &game_world_instance);

    void scan_passcode_terminals(Il2CppObjectInstance &game_world_instance, std::unordered_set<uintptr_t> &seen,
        std::vector<keypanel_entry> &out_panels);

    // Full-scene scan once; results cached until toggle off / leave raid.
    void scan_keypanel_esp(Il2CppObjectInstance &game_world_instance, std::vector<keypanel_entry> &out_panels);

    void refresh_corpse_registry_distances(const unity::vector3 &player_pos, const float min_dist_sq,
        const float max_dist_sq);

    void scan_corpse_registry(Il2CppObjectInstance &game_world_instance, const unity::vector3 &player_pos,
        const float min_dist_sq, const float max_dist_sq);

    void update_corpse_loot_esp(Il2CppObjectInstance &game_world_instance,
        std::vector<container_esp_entry> &out_corpses, bool &store_dirty,
        const bool force_full_refresh = false);

    void draw_inventory_list_entry(ImDrawList *draw_list, Il2CppObject *cam, const container_esp_entry &entry,
        char *text_buf, const size_t text_buf_size, const ImVec4 &header_color,
        const bool show_total_price, const bool show_item_prices,
        const bool corpse_list = false, const float screen_y_offset = 0.f) const;

    void draw_container_entry(ImDrawList *draw_list, Il2CppObject *cam, const container_esp_entry &entry,
        char *text_buf, const size_t text_buf_size, const float screen_y_offset = 0.f) const;

    void draw_corpse_entry(ImDrawList *draw_list, Il2CppObject *cam, const container_esp_entry &entry, char *text_buf,
        const size_t text_buf_size) const;

    ImVec4 quest_poi_color(const quest_esp::poi_type type) const;

    static std::string quest_poi_group_key(const unity::vector3 &pos, const std::string &name);

    void draw_quest_esp_overlay(ImDrawList *draw_list, Il2CppObject *cam, const std::vector<quest_esp::poi_entry> &pois,
        char *text_buf, const size_t text_buf_size) const;

  public:
    // ---------------------------------------------------------------------------
    // Big-map markers -- bigmap plan 4.3, shared with MapModule.
    //
    // WHY THIS LIVES HERE AND NOT IN MapModule: every marker it draws is already
    // drawn by draw_radar_overlay() from these same snapshots, through these
    // same helpers, with these same fonts and glyphs. A second renderer in
    // MapModule would be a second set of colours, sizes and anchor rules that
    // could drift from the radar's, and the whole point of a shared visual
    // language is that an extract is the same glyph in both views. So the big
    // map calls ONE more method here and the two views cannot disagree.
    //
    // WHAT IS DIFFERENT, and why the context struct exists rather than a copy
    // of draw_radar_overlay's signature: the radar has a no-map-loaded
    // fallback that places markers radially around its centre, which the big
    // map has no use for (it returns before drawing when no map is loaded) and
    // which would need seven more parameters to plumb through. Everything the
    // two views actually share -- bounds, view transform, clip rect, player
    // position for the height indicators, the four layer switches -- is here.
    struct big_map_marker_context
    {
        ImDrawList *draw_list = nullptr;
        minimap::map_bounds bounds{};
        minimap::map_view_transform view{};
        // Clip rect in screen space. The big map clips to its window; the radar
        // clips to its square. Same reason, different rectangle.
        ImVec2 clip_min{};
        ImVec2 clip_max{};
        // Only used to decide whether a label is drawn ABOVE or BELOW its
        // marker and to render the height indicator. Never used to position the
        // view -- the big map's view is built by MapModule, not here.
        unity::vector3 player_pos{};
        // Each of these gates one whole layer, so the two views can disagree
        // per layer without either one asking the other what to draw.
        bool show_quest = true;
        bool show_quest_names = true;
        bool show_exfils = true;
        bool show_players = true;
        bool show_player_names = false;
        bool show_corpse = false;
        bool show_static_markers = true;
        bool show_labels = true;
    };

    void draw_big_map_markers(const big_map_marker_context &ctx, const std::string &location_id) const;

    // Shared by the Loot Teleporter card.  These deliberately use the selected
    // controls even when the corresponding ESP-only toggle is off.
    bool matches_loot_teleport_filter(const int filter, const std::string &template_id, std::string name,
        const bool is_quest, Il2CppObject *local_player = nullptr);

    void export_exfil_coords();

    void clear_runtime_cache() override;

    [[nodiscard]] size_t get_runtime_cache_count() override;

    [[nodiscard]] size_t get_runtime_cache_bytes() override;

    bool prices_feature_enabled() const;

    void init() override;

    // Drives application_update / gameworld_update / draw_overlay for this
    // module (ModuleManager::apply). The invariant is: if ANY master toggle is
    // on, the module must run.
    //
    // This list was hand-written and drifted out of sync with init()'s
    // set_master_toggle() calls, which is how a user could tick the skeleton
    // box, turn everything else off, and get a completely inert ESP with no
    // indication why. When you add a master toggle to init(), add it here.
    [[nodiscard]] bool is_active() const override {
        return players->get_value() || npc->get_value() || loot_esp->get_value() || grenade_esp->get_value() || tripwire_esp->get_value() || keypanel_esp->get_value() || container_esp->get_value() || quest_items->get_value() || quest_esp_enabled->get_value() || extracts->get_value() || transits->get_value()
            // Masters that were missing. player_box / player_health / skeleton /
            // esp_optic are all set_master_toggle(true) in init().
            || player_box->get_value() || player_health->get_value() || skeleton->get_value() || esp_optic->get_value();
    }

    void prepare_menu_draw() override;

    // ===================================================================
    // Optic region debug rings (TEMPORARY, gated on the Show Debug Log toggle).
    //
    // 2026-09-27. The lens "cut-out" is a 48-gon ellipse fitted to the screen-space
    // bounding box of the lens renderer's world AABB (optics_lens_pipeline.h:1996-2040).
    // It is NOT the game's aperture, and the log measures it as systematically wrong:
    // from `optic-region`'s cover, the region radius is 0.571..0.608 NDC against a lens
    // image half-height of 0.748 NDC -- i.e. 76-81% of the lens radius, wobbling ~5%,
    // and the wobble is INDEPENDENT of zoom (the region is 808x808 px at every FOV from
    // 4.42 to 26.5 deg). Words were not converging on where the boundary actually sits,
    // so these rings make one screenshot decisive instead.
    //
    // Rings, deliberately in three distinct colours:
    //   CYAN    the cull region polygon itself -- the boundary ESP actually uses
    //   YELLOW  the image quad (the 808 px letterbox footprint)
    //   MAGENTA a circle at the quad's half-height, centred on the quad -- the "full
    //           lens" reference. If cyan sits visibly inside magenta, and magenta lands
    //           on the visible housing edge, the region simply has to grow.
    //
    // Drawn from the packet, so it shows what the code BELIEVES, not a guess. The
    // guessed fallback circle was removed with Dual ADS earlier today for the same
    // reason (see the comment above game_state::esp_ads_mask_half).
    // ===================================================================
    static void draw_optic_region_debug(ImDrawList *draw_list);

    void draw_overlay(ImDrawList *draw_list) override;
    void reset_raid_context();

    void application_update() override;

    void gameworld_update(const Il2CppClass *game_world_class, Il2CppObjectInstance game_world_instance,
        Il2CppObjectInstance main_player) override;
};
