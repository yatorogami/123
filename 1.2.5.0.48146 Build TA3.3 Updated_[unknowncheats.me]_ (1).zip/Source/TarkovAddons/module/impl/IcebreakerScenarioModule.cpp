#include "common.h"
#include "IcebreakerScenarioModule.h"

// Moved off ModuleCategory::Misc onto the "Map Stuff" tab. Misc has no nav entry
// and this module is not hidden_in_category_menu, so its card could not be
// reached from the menu at all -- the category was a dead end rather than a home.
IcebreakerScenarioModule::IcebreakerScenarioModule() : Module("Icebreaker Scenario", MapStuff, "icebreaker_mod"),
                                                       skip_cutscene(conf(new ActionRowValue([this] { skip_cutscene_impl(); }, "icebreaker_skip_cutscene_btn"))) {
}

void IcebreakerScenarioModule::skip_cutscene_impl() {
    queue_skip_cutscene_ = true;
}

void IcebreakerScenarioModule::draw_overlay(ImDrawList *draw_list) {
    if (!cutscene_active_ || !draw_list)
        return;

    const bool held = skip_hold_key != 0 && (GetAsyncKeyState(skip_hold_key) & 0x8000) != 0;
    const float delta = ImGui::GetIO().DeltaTime;
    skip_hold_ = held ? std::min<float>(skip_hold_ + delta, skip_hold_seconds)
                      : std::max<float>(skip_hold_ - delta * 2.0f, 0.0f);
    if (skip_hold_ >= skip_hold_seconds)
    {
        skip_hold_ = 0.0f;
        queue_skip_cutscene_ = true;
    }

    draw_skip_prompt(draw_list, skip_hold_ / skip_hold_seconds);
}

void IcebreakerScenarioModule::application_update() {
}

void IcebreakerScenarioModule::gameworld_update(const Il2CppClass *, Il2CppObjectInstance game_world, Il2CppObjectInstance main_player) {
    TA_ZONE_N("icebreaker::gameworld_update");
    const std::string location = string_field(game_world.get_instance(), "<LocationId>k__BackingField");
    if (!game_state::is_in_raid || !equals_ignore_case(location, "icebreaker"))
    {
        reset_raid();
        return;
    }

    Il2CppObject *world = game_world.get_instance();
    const char *world_type = world && world->klass && world->klass->name ? world->klass->name : "(null)";
    const bool local_world = is_class_or_parent(world, "ClientLocalGameWorld");
    if (!local_world)
    {
        if (!online_world_logged_)
        {
            logger::warn("Icebreaker scenario disabled: non-local GameWorld type=" + std::string(world_type) + "; no online raid action allowed.");
            online_world_logged_ = true;
        }
        return;
    }

    if (raid_world_ != world)
    {
        reset_raid();
        raid_world_ = world;
    }

    resolve_runtime_api();
    if (!runtime_api_ready_)
        return;

    auto *server = game_world.get_field<Il2CppObject *>("<CutscenesServerController>k__BackingField");
    auto *client = game_world.get_field<Il2CppObject *>("<CutscenesClientController>k__BackingField");
    if (!controllers_logged_ || server != last_server_ || client != last_client_)
    {
        logger::info("Icebreaker scenario controllers: GameWorld=" + std::string(world_type) + ", server=" + (server ? "available" : "missing")
            + ", client=" + (client ? "available" : "missing"));
        controllers_logged_ = true;
        last_server_ = server;
        last_client_ = client;
    }

    Il2CppObject *server_bank = server ? object_field(server, "_timelinesMapBank") : nullptr;
    Il2CppObject *client_bank = client ? object_field(client, "_timelinesMapBank") : nullptr;
    Il2CppObject *bank = server_bank ? server_bank : client_bank;
    if (!bank)
        return;

    if (bank != logged_bank_)
    {
        log_timelines(bank);
        log_cutscene_objects();
        logged_bank_ = bank;
    }
    if (scenario_trigger_id_.empty())
        discover_scenario_trigger();
    log_trigger_emitter();
    log_rally_zones();

    if (!o_start_cutscene_ || !server || !client || !server_bank || !client_bank || !main_player.get_instance())
        return;

    constexpr const char *cutscene_id = "Icebreaker_1";
    constexpr const char *scene_id = "Icebreaker_cutscene_01";
    if (!has_timeline(server_bank, cutscene_id, scene_id))
        return;
    if (!ensure_directors_registered(client, scene_id))
        return;
    try_activate_rally_zone(world, main_player.get_instance());
    poll_cutscene_phase(client);
    run_queued_skip(client);
    if (!scenario_ready_logged_ && !trigger_pending_)
    {
        logger::info("Icebreaker scenario armed: waiting for HandlerStartCutscene; no raid-start playback.");
        scenario_ready_logged_ = true;
    }
    if (!trigger_pending_ || start_attempted_)
        return;

    const int player_id = get_player_id(main_player.get_instance());
    Il2CppObject *player_ids = make_player_id_list(server, player_id);
    if (!player_ids)
    {
        logger::warn("Icebreaker scenario start blocked: failed to construct List<int> from controller type.");
        start_attempted_ = true;
        return;
    }

    start_attempted_ = true;
    logger::info("Icebreaker scenario trigger start: id=" + std::string(cutscene_id) + ", scene=" + std::string(scene_id) + ", playerId=" + std::format("{}", player_id));
    Il2CppObject *process = o_start_cutscene_(server, il2cpp::il2cpp_string_new(cutscene_id), player_ids, false,
        false, 0.0f);
    if (process)
        logger::info("Icebreaker scenario StartCutscene result=started, process="
            + std::string((process->klass && process->klass->name ? process->klass->name : "(null)")));
    else
        logger::warn("Icebreaker scenario StartCutscene result=null");
}

void IcebreakerScenarioModule::init() {
    logger::info("Icebreaker scenario inactive until local Icebreaker raid.");
}

void IcebreakerScenarioModule::resolve_runtime_api() {
    if (runtime_api_ready_)
        return;

    if (!assembly_csharp_)
        assembly_csharp_ = il2utils::resolve_image("Assembly-CSharp.dll");
    if (!assembly_csharp_)
        return;

    constexpr const char *ns = "CommonAssets.Scripts.Cutscenes";

    const Il2CppClass *server_controller =
        il2utils::resolve_class(assembly_csharp_, ns, "CutscenesServerController");
    o_start_cutscene_ =
        il2utils::get_method<start_cutscene_sig>(server_controller, "StartCutscene", 5, true, false);

    const Il2CppClass *client_controller =
        il2utils::resolve_class(assembly_csharp_, ns, "CutscenesClientController");
    o_register_playable_director_ = il2utils::get_method<register_director_sig>(
        client_controller, "RegisterPlayableDirector", 2, true, false);
    o_register_cutscene_director_ = il2utils::get_method<register_director_sig>(
        client_controller, "RegisterCutscenePlayableDirector", 2, true, false);

    const Il2CppClass *triggers_emitter =
        il2utils::resolve_class(assembly_csharp_, "EFT.GameTriggers", "TriggersEmitter");
    get_trigger_emitter_ =
        il2utils::get_method<get_trigger_emitter_sig>(triggers_emitter, "get_Instance", 0, true, false);

    const Il2CppClass *rally_zone =
        il2utils::resolve_class(assembly_csharp_, "EFT.GameTriggers", "TriggerRallyZone");
    emit_rally_trigger_ =
        il2utils::get_method<emit_rally_trigger_sig>(rally_zone, "EmitTrigger", 1, true, false);

    logger::info("Icebreaker scenario local APIs resolved: StartCutscene=" + std::string((o_start_cutscene_ ? "yes" : "no"))
        + ", playable-register=" + std::string((o_register_playable_director_ ? "yes" : "no"))
        + ", cutscene-register=" + std::string((o_register_cutscene_director_ ? "yes" : "no"))
        + ", emitter-instance=" + std::string((get_trigger_emitter_ ? "yes" : "no"))
        + ", rally-emit=" + std::string((emit_rally_trigger_ ? "yes" : "no")));
    runtime_api_ready_ = o_start_cutscene_ && o_register_playable_director_ && o_register_cutscene_director_ && get_trigger_emitter_ && emit_rally_trigger_;
}

bool IcebreakerScenarioModule::equals_ignore_case(std::string value, std::string expected) {
    auto lower = [](std::string &text) {
        std::transform(text.begin(), text.end(), text.begin(),
            [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    };
    lower(value);
    lower(expected);
    return value == expected;
}

bool IcebreakerScenarioModule::is_class_or_parent(Il2CppObject *object, const char *name) {
    for (const Il2CppClass *klass = object ? object->klass : nullptr; klass; klass = klass->parent)
    {
        if (klass->name && std::string(klass->name) == name)
            return true;
    }
    return false;
}

Il2CppObject *IcebreakerScenarioModule::object_field(Il2CppObject *object, const char *name) {
    if (!object || !object->klass)
        return nullptr;
    const FieldInfo *field = il2utils::resolve_field(object->klass, name);
    if (!field || field->offset <= 0)
        return nullptr;
    return *reinterpret_cast<Il2CppObject **>(reinterpret_cast<std::uintptr_t>(object) + field->offset);
}

std::string IcebreakerScenarioModule::string_field(Il2CppObject *object, const char *name) {
    return il2utils::conv_string(reinterpret_cast<Il2CppString *>(object_field(object, name)));
}

std::string IcebreakerScenarioModule::string_array(Il2CppArray *array) {
    if (!array || array->max_length == 0)
        return "[]";
    std::ostringstream out;
    out << '[';
    auto **strings = reinterpret_cast<Il2CppString **>(&array->data);
    for (il2cpp_array_size_t i = 0; i < array->max_length; ++i)
    {
        if (i)
            out << ", ";
        out << il2utils::conv_string(strings[i]);
    }
    out << ']';
    return out.str();
}

const IcebreakerScenarioModule::timeline_data *IcebreakerScenarioModule::find_timeline(Il2CppObject *bank, const char *cutscene_id) {
    auto *timelines = reinterpret_cast<timeline_list *>(object_field(bank, "timelines"));
    if (!timelines || !timelines->items || timelines->size <= 0)
        return nullptr;

    const auto count =
        std::min<std::int32_t>(timelines->size, static_cast<std::int32_t>(timelines->items->max_length));
    const auto *entries = reinterpret_cast<const timeline_data *>(&timelines->items->data);
    for (std::int32_t i = 0; i < count; ++i)
    {
        if (il2utils::conv_string(entries[i].cutscene_id) == cutscene_id)
            return &entries[i];
    }
    return nullptr;
}

bool IcebreakerScenarioModule::has_timeline(Il2CppObject *bank, const char *cutscene_id, const char *scene_id) {
    const timeline_data *entry = find_timeline(bank, cutscene_id);
    return entry && il2utils::conv_string(entry->scene_name) == scene_id;
}

void IcebreakerScenarioModule::poll_cutscene_phase(Il2CppObject *client) {
    const std::string cutscene_id = string_field(client, "_cutsceneId");
    if (state_seen_ && cutscene_id == last_cutscene_id_)
        return;

    const bool started = !cutscene_id.empty() && last_cutscene_id_.empty();
    const bool ended = state_seen_ && !last_cutscene_id_.empty() && cutscene_id.empty();
    state_seen_ = true;
    last_cutscene_id_ = cutscene_id;
    cutscene_active_ = !cutscene_id.empty();
    if (!cutscene_active_)
        skip_hold_ = 0.0f;
    if (started)
        log_skip_ui(client);
    if (ended)
        deactivate_cinematic_objects();
}

void IcebreakerScenarioModule::log_skip_ui(Il2CppObject *client) {
    Il2CppObject *skip_ui = object_field(client, "_cutsceneSkipUI");
    const MethodInfo *stop = find_method(client ? client->klass : nullptr, "StopCutscene");
    logger::info("Icebreaker skip UI: _cutsceneSkipUI=" + std::string((skip_ui ? "available" : "null"))
        + ", offlineMode=" + std::to_string(static_cast<int>(value_field<std::uint8_t>(client, "_offlineMode")))
        + ", StopCutscene arity=" + std::to_string((stop ? static_cast<int>(stop->parameters_count) : -1))
        + ", paramTypes=" + param_types(stop));
}

void IcebreakerScenarioModule::draw_skip_prompt(ImDrawList *draw_list, const float progress) const {
    const float sf = menu::get_scale_factor();
    const float radius = 22.0f * sf;
    const ImVec2 display = ImGui::GetIO().DisplaySize;
    const ImVec2 center{display.x - 120.0f * sf, display.y - 130.0f * sf};

    draw_list->AddCircleFilled(center, radius, IM_COL32(0, 0, 0, 130), 48);
    draw_list->AddCircle(center, radius, IM_COL32(255, 255, 255, 60), 48, 2.0f * sf);
    if (progress > 0.0f)
    {
        constexpr float two_pi = 6.28318530718f;
        constexpr float top = -two_pi * 0.25f;
        draw_list->PathArcTo(center, radius, top, top + progress * two_pi, 48);
        draw_list->PathStroke(IM_COL32(255, 255, 255, 235), 0, 3.0f * sf);
    }

    const std::string key =
        skip_hold_key > 0 && skip_hold_key < 165 ? menu::KeyNames[skip_hold_key] : std::string("?");
    const ImVec2 key_size = ImGui::CalcTextSize(key.c_str());
    draw_list->AddText({center.x - key_size.x * 0.5f, center.y - key_size.y * 0.5f},
        IM_COL32(255, 255, 255, 235), key.c_str());

    const std::string label = i18n::tr("Hold To Skip");
    const ImVec2 label_size = ImGui::CalcTextSize(label.c_str());
    draw_list->AddText({center.x - label_size.x * 0.5f, center.y + radius + 6.0f * sf},
        IM_COL32(255, 255, 255, 170), label.c_str());
}

const MethodInfo *IcebreakerScenarioModule::find_method(const Il2CppClass *klass, const char *name) {
    for (std::uint16_t i = 0; klass && klass->methods && i < klass->method_count; ++i)
    {
        const MethodInfo *method = klass->methods[i];
        if (method && method->name && std::string(method->name) == name)
            return method;
    }
    return nullptr;
}

std::string IcebreakerScenarioModule::param_types(const MethodInfo *method) {
    if (!method || !method->parameters)
        return "[]";

    std::ostringstream out;
    out << '[';
    for (std::uint8_t i = 0; i < method->parameters_count; ++i)
    {
        if (i)
            out << ", ";
        const Il2CppType *type = method->parameters[i];
        out << "0x" << std::hex << (type ? static_cast<int>(type->type) : -1) << std::dec;
    }
    out << ']';
    return out.str();
}

void IcebreakerScenarioModule::run_queued_skip(Il2CppObject *client) {
    if (!queue_skip_cutscene_)
        return;

    const std::string running = string_field(client, "_cutsceneId");
    if (running != "Icebreaker_1" || !value_field<bool>(client, "_offlineMode"))
    {
        queue_skip_cutscene_ = false;
        logger::info("Icebreaker skip ignored: no local Icebreaker cutscene running.");
        return;
    }

    // A queued hotkey can arrive before StartShowTimeline has initialized the graph.
    // Keep it pending until the real director is playing and the t=0 signal has run.
    if (value_field<bool>(client, "_needStartTimeline") || !playable_director_)
        return;

    const Il2CppClass *director_class = il2utils::resolve_class(
        il2utils::resolve_image("UnityEngine.DirectorModule.dll"), "UnityEngine.Playables", "PlayableDirector");
    const Il2CppType *director_type = il2cpp::il2cpp_class_get_type(const_cast<Il2CppClass *>(director_class));
    const MethodInfo *method = il2utils::resolve_method(client->klass, "StopCutscene", 2);
    const int arity = method ? static_cast<int>(method->parameters_count) : -1;
    const Il2CppType *first = arity >= 1 && method->parameters ? method->parameters[0] : nullptr;
    const Il2CppType *second = arity >= 2 && method->parameters ? method->parameters[1] : nullptr;
    if (arity != 2 || !first || !second || first->type != IL2CPP_TYPE_CLASS || second->type != IL2CPP_TYPE_BOOLEAN || first->byref || second->byref || !director_type || first->data.typeHandle != director_type->data.typeHandle || playable_director_->klass != director_class)
    {
        queue_skip_cutscene_ = false;
        logger::warn("Icebreaker skip unavailable: expected StopCutscene(PlayableDirector,bool), arity=" + std::to_string(arity) + ", paramTypes=" + param_types(method));
        return;
    }

    const auto get_state = il2utils::get_method<int (*)(Il2CppObject *)>(director_class, "get_state", 0, false, false);
    const auto get_time = il2utils::get_method<double (*)(Il2CppObject *)>(director_class, "get_time", 0, false, false);
    const auto get_asset = il2utils::get_method<Il2CppObject *(*)(Il2CppObject *)>(
        director_class, "get_playableAsset", 0, false, false);
    Il2CppObject *signal_type = il2utils::get_system_type(
        assembly_csharp_, "CommonAssets.Scripts.Cutscenes", "CutscenePlayableDirector");
    Il2CppObject *director_object = unity::component_get_game_object(playable_director_);
    Il2CppObject *signal_director = director_object && signal_type
        ? unity::gameobject_get_component(director_object, signal_type)
        : nullptr;
    const auto signal = il2utils::get_method<void (*)(Il2CppObject *, Il2CppString *)>(
        signal_director ? signal_director->klass : nullptr, "OnSignalEmit", 1, false, false);
    const auto stop = il2utils::get_method<void (*)(Il2CppObject *, Il2CppObject *, bool)>(
        client->klass, "StopCutscene", 2, false, false);
    if (!get_state || !get_time || !get_asset || !signal || !stop)
    {
        queue_skip_cutscene_ = false;
        logger::warn("Icebreaker skip unavailable: director/completion APIs unresolved; playback retained.");
        return;
    }
    if (get_state(playable_director_) != 1 || !get_asset(playable_director_)) // PlayState.Playing
        return;

    const double time = get_time(playable_director_);
    if (!std::isfinite(time) || time <= 0.0)
        return;

    queue_skip_cutscene_ = false;
    const int process_id = value_field<int>(client, "_cutsceneProcessId");
    // Icebreaker_Cutscene_00 / Audio_Signals: switch_to_outdoor at 0, then
    // reset_environment at 29.15 (non-retroactive). All 39 animation clips have no events.
    // Complete only the remaining signal, before the native client/server end path.
    constexpr double reset_environment_time = 29.15;
    if (time < reset_environment_time)
    {
        logger::info("Icebreaker skip pending signal: id=reset_environment, timelineTime=" + std::to_string(time));
        signal(signal_director, il2cpp::il2cpp_string_new("reset_environment"));
    }

    logger::info("Icebreaker cutscene skip: StopCutscene(director,false), id=" + running + ", processId=" + std::to_string(process_id) + ", timelineTime=" + std::to_string(time));
    stop(client, playable_director_, false);
    logger::info("Icebreaker skip completion: clientId=" + string_field(client, "_cutsceneId") + ", clientProcessId=" + std::to_string(value_field<int>(client, "_cutsceneProcessId")));
}

bool IcebreakerScenarioModule::ensure_directors_registered(Il2CppObject *client, const char *scene_id) {
    if (playable_director_client_ == client && cutscene_director_client_ == client)
        return true;

    Il2CppObject *cutscene_type =
        il2utils::get_system_type(assembly_csharp_, "CommonAssets.Scripts.Cutscenes", "CutscenePlayableDirector");
    size_t count = 0;
    Il2CppObject **objects = unity::find_objects_of_type(cutscene_type, &count, true);
    if (!objects || count != 1 || !objects[0])
        return false;

    Il2CppObject *cutscene_director = objects[0];
    Il2CppObject *game_object = unity::component_get_game_object(cutscene_director);
    if (!game_object)
        return false;
    Il2CppImage *director_image = il2utils::resolve_image("UnityEngine.DirectorModule.dll");
    Il2CppObject *playable_type =
        il2utils::get_system_type(director_image, "UnityEngine.Playables", "PlayableDirector");
    if (!playable_type)
        return false;
    Il2CppObject *playable_director = unity::gameobject_get_component(game_object, playable_type);
    if (!playable_director || !o_register_playable_director_ || !o_register_cutscene_director_)
        return false;

    Il2CppString *scene = il2cpp::il2cpp_string_new(scene_id);
    playable_director_ = playable_director;
    o_register_playable_director_(client, scene, playable_director);
    o_register_cutscene_director_(client, scene, cutscene_director);
    playable_director_client_ = client;
    cutscene_director_client_ = client;
    cutscene_root_ = resolve_root_game_object(game_object);
    logger::info("Icebreaker directors locally registered through controller APIs: scene=" + std::string(scene_id) + ", cutsceneRoot=" + std::string((cutscene_root_ ? unity::get_name(cutscene_root_) : "(unresolved)")));
    return true;
}

Il2CppObject *IcebreakerScenarioModule::resolve_root_game_object(Il2CppObject *game_object) {
    Il2CppObject *transform = unity::gameobject_get_transform(game_object);
    if (!transform)
        return nullptr;
    for (Il2CppObject *parent = unity::transform_get_parent(transform); parent;
        parent = unity::transform_get_parent(transform))
        transform = parent;
    return unity::transform_get_game_object(transform);
}

void IcebreakerScenarioModule::log_cinematic_hierarchy(Il2CppObject *root_transform) {
    const int count = unity::transform_get_child_count(root_transform);
    std::ostringstream out;
    out << '[';
    for (int i = 0; i < count; ++i)
    {
        Il2CppObject *child = unity::transform_get_child(root_transform, i);
        if (i)
            out << ", ";
        out << (child ? unity::get_name(unity::transform_get_game_object(child)) : "(null)");
    }
    out << ']';
    logger::info("Icebreaker CutsceneRoot children before cleanup: count=" + std::to_string(count) + ", names=" + out.str());

    for (int i = 0; i < count; ++i)
    {
        Il2CppObject *child = unity::transform_get_child(root_transform, i);
        Il2CppObject *object = child ? unity::transform_get_game_object(child) : nullptr;
        if (!object || unity::get_name(object) != "HelipadCenter")
            continue;
        log_branch(child, "HelipadCenter");
    }
}

void IcebreakerScenarioModule::log_branch(Il2CppObject *transform, const std::string &path) {
    const int count = unity::transform_get_child_count(transform);
    std::ostringstream out;
    out << '[';
    for (int i = 0; i < count; ++i)
    {
        Il2CppObject *child = unity::transform_get_child(transform, i);
        Il2CppObject *object = child ? unity::transform_get_game_object(child) : nullptr;
        if (i)
            out << ", ";
        out << (object ? unity::get_name(object) : "(null)") << '('
            << (child ? unity::transform_get_child_count(child) : 0) << ')';
    }
    out << ']';
    logger::info("Icebreaker branch " + path + ": count=" + std::to_string(count) + ", names=" + out.str());
}

void IcebreakerScenarioModule::deactivate_cinematic_objects() {
    const std::string name = cutscene_root_ ? unity::get_name(cutscene_root_) : std::string();
    if (name != "CutsceneRoot")
    {
        logger::warn("Icebreaker cinematic cleanup skipped: root=" + std::string((name.empty() ? "(unresolved)" : name)));
        return;
    }

    Il2CppObject *root_transform = unity::gameobject_get_transform(cutscene_root_);
    log_cinematic_hierarchy(root_transform);

    const Il2CppImage *unity_engine = il2utils::resolve_image("UnityEngine.CoreModule.dll");
    const Il2CppClass *game_object_class = il2utils::resolve_class(unity_engine, "UnityEngine", "GameObject");
    const auto set_active =
        il2utils::get_method<void (*)(Il2CppObject *, bool)>(game_object_class, "SetActive", 1, true, false);
    if (!set_active)
        return;

    // Allowlist only. CutsceneCamera holds the reparented player camera rig, and HelipadCenter
    // anchors the extraction helicopter call; both must stay active after the cutscene.
    const int count = unity::transform_get_child_count(root_transform);
    for (int i = 0; i < count; ++i)
    {
        Il2CppObject *child = unity::transform_get_child(root_transform, i);
        Il2CppObject *object = child ? unity::transform_get_game_object(child) : nullptr;
        if (!object)
            continue;

        const std::string child_name = unity::get_name(object);
        if (child_name == "HelipadCenter")
        {
            // The pad anchors the extraction call; only its cinematic actors and props go.
            const int props = unity::transform_get_child_count(child);
            for (int j = 0; j < props; ++j)
            {
                Il2CppObject *prop = unity::transform_get_child(child, j);
                Il2CppObject *prop_object = prop ? unity::transform_get_game_object(prop) : nullptr;
                if (!prop_object)
                    continue;

                const std::string prop_name = unity::get_name(prop_object);
                if (prop_name != "HelipadActors" && prop_name != "HelipadProps")
                    continue;

                set_active(prop_object, false);
                logger::info("Icebreaker cinematic object deactivated: object=HelipadCenter/" + prop_name);
            }
            continue;
        }

        if (child_name != "Helicopter_00" && child_name != "Helicopter_01" && child_name.rfind("VFX_Icebreaker_Cutscene", 0) != 0)
            continue;

        set_active(object, false);
        logger::info("Icebreaker cinematic object deactivated: object=" + child_name);
    }
}

int IcebreakerScenarioModule::get_player_id(Il2CppObject *player) {
    const auto getter = Il2CppObjectInstance(player).get_method<int (*)(Il2CppObject *)>("get_Id", 0, false,
        false);
    return getter ? getter(player) : 0;
}

int IcebreakerScenarioModule::get_player_raid_id(Il2CppObject *player) {
    const auto getter = Il2CppObjectInstance(player).get_method<int (*)(Il2CppObject *)>(
        "get_RaidId", 0, false, false);
    return getter ? getter(player) : 0;
}

void IcebreakerScenarioModule::try_activate_rally_zone(Il2CppObject *game_world, Il2CppObject *main_player) {
    if (trigger_pending_ || start_attempted_ || !scenario_rally_zone_ || !scenario_rally_collider_ || !emit_rally_trigger_ || !get_trigger_emitter_ || !game_world || !main_player)
        return;

    if (value_field<bool>(scenario_rally_zone_, "_wasTriggered"))
    {
        logger::info("Icebreaker natural rally activation observed: triggerId=" + scenario_trigger_id_);
        trigger_pending_ = true;
        return;
    }

    Il2CppObject *emitter = get_trigger_emitter_();
    if (!is_class_or_parent(emitter, "LocalTriggersEmitter") && !is_class_or_parent(emitter, "ServerTriggersEmitter"))
        return;

    Il2CppImage *physics_image = il2utils::resolve_image("UnityEngine.PhysicsModule.dll");
    const Il2CppClass *collider_class =
        il2utils::resolve_class(physics_image, "UnityEngine", "Collider");
    const Il2CppClass *physics_class =
        il2utils::resolve_class(physics_image, "UnityEngine", "Physics");
    const auto get_bounds =
        il2utils::get_method<collider_bounds (*)(Il2CppObject *)>(collider_class, "get_bounds", 0, false,
            false);
    const auto overlap_box = il2utils::get_method<Il2CppArray *(*)(unity::vector3, unity::vector3,
        unity::quaternion, int, int)>(
        physics_class, "OverlapBox", 5, false, false);
    const auto get_player_by_collider = Il2CppObjectInstance(game_world).get_method<Il2CppObject *(*)(Il2CppObject *, Il2CppObject *)>("GetPlayerByCollider", 1, false, false);
    if (!get_bounds || !overlap_box || !get_player_by_collider)
        return;

    const collider_bounds bounds = get_bounds(scenario_rally_collider_);
    const unity::quaternion identity{0.0f, 0.0f, 0.0f, 1.0f};
    Il2CppArray *overlaps = overlap_box(bounds.center, bounds.extents, identity, -1, 2);
    auto **colliders = overlaps ? reinterpret_cast<Il2CppObject **>(&overlaps->data) : nullptr;
    for (il2cpp_array_size_t i = 0; colliders && i < overlaps->max_length; ++i)
    {
        Il2CppObject *collider = colliders[i];
        if (!collider || collider == scenario_rally_collider_ || get_player_by_collider(game_world, collider) != main_player)
            continue;

        const int raid_id = get_player_raid_id(main_player);
        if (raid_id <= 0 || !set_value_field(scenario_rally_zone_, "_wasTriggered", true))
            return;

        logger::info("Icebreaker rally boundary activated locally: triggerId=" + scenario_trigger_id_
            + ", originPlayerRaidId=" + std::format("{}", raid_id) + ", collider=" + unity::get_name(collider));
        emit_rally_trigger_(scenario_rally_zone_, raid_id);
        trigger_pending_ = true;
        return;
    }
}

Il2CppObject *IcebreakerScenarioModule::make_player_id_list(Il2CppObject *server, int player_id) {
    Il2CppObject *source = object_field(server, "_playersToRemoveFromProcess");
    auto *source_items = reinterpret_cast<Il2CppArray *>(object_field(source, "_items"));
    if (!source || !source->klass || !source_items || !source_items->klass || !source_items->klass->element_class || player_id <= 0)
        return nullptr;

    Il2CppArray *items = il2cpp::il2cpp_array_new(source_items->klass->element_class, 1);
    Il2CppObject *list = il2cpp::il2cpp_object_new(source->klass);
    if (!items || !list)
        return nullptr;

    *reinterpret_cast<int *>(&items->data) = player_id;
    if (!set_value_field(list, "_items", items) || !set_value_field(list, "_size", 1) || !set_value_field(list, "_version", 1))
        return nullptr;
    return list;
}

void IcebreakerScenarioModule::log_timelines(Il2CppObject *bank) {
    auto *timelines = reinterpret_cast<timeline_list *>(object_field(bank, "timelines"));
    if (!timelines || !timelines->items || timelines->size <= 0)
    {
        logger::warn("Icebreaker MapTimelinesBank available; timeline list empty.");
        return;
    }

    const auto count =
        std::min<std::int32_t>(timelines->size, static_cast<std::int32_t>(timelines->items->max_length));
    logger::info("Icebreaker MapTimelinesBank: timeline count=" + std::to_string(count));
    const auto *entries = reinterpret_cast<const timeline_data *>(&timelines->items->data);
    for (std::int32_t i = 0; i < count; ++i)
    {
        const auto &entry = entries[i];
        logger::info("Icebreaker timeline[" + std::to_string(i) + "]: id=" + il2utils::conv_string(entry.cutscene_id)
            + ", scene=" + il2utils::conv_string(entry.scene_name) + ", duration=" + std::to_string(entry.duration)
            + ", canSkip=" + std::to_string(entry.can_skip) + ", startActions=" + string_array(entry.start_actions)
            + ", endActions=" + string_array(entry.end_actions));
    }
}

void IcebreakerScenarioModule::log_cutscene_objects() {
    Il2CppObject *type =
        il2utils::get_system_type(assembly_csharp_, "CommonAssets.Scripts.Cutscenes", "CutsceneObjects");
    size_t count = 0;
    Il2CppObject **objects = unity::find_objects_of_type(type, &count, true);
    logger::info("Icebreaker CutsceneObjects: count=" + std::to_string(count));
    for (size_t i = 0; objects && i < count; ++i)
    {
        Il2CppObject *object = objects[i];
        if (!object)
            continue;
        logger::info("Icebreaker CutsceneObjects[" + std::to_string(i) + "]: id=" + string_field(object, "cutsceneId"));
    }

    Il2CppObject *director_type =
        il2utils::get_system_type(assembly_csharp_, "CommonAssets.Scripts.Cutscenes", "CutscenePlayableDirector");
    size_t director_count = 0;
    unity::find_objects_of_type(director_type, &director_count, true);
    logger::info("Icebreaker CutscenePlayableDirector: count=" + std::to_string(director_count));

    Il2CppObject *trigger_type =
        il2utils::get_system_type(assembly_csharp_, "EFT.GameTriggers", "HandlerStartCutscene");
    size_t trigger_count = 0;
    Il2CppObject **triggers = unity::find_objects_of_type(trigger_type, &trigger_count, true);
    logger::info("Icebreaker HandlerStartCutscene: count=" + std::to_string(trigger_count));
    for (size_t i = 0; triggers && i < trigger_count; ++i)
    {
        Il2CppObject *trigger = triggers[i];
        if (!trigger)
            continue;
        logger::info("Icebreaker scenario trigger[" + std::to_string(i) + "]: triggerId="
            + string_field(trigger, "_triggerId")
            + ", cutsceneId=" + string_field(trigger, "_cutsceneId")
            + ", object=" + unity::get_name(trigger));
    }
}

void IcebreakerScenarioModule::discover_scenario_trigger() {
    Il2CppObject *trigger_type =
        il2utils::get_system_type(assembly_csharp_, "EFT.GameTriggers", "HandlerStartCutscene");
    size_t trigger_count = 0;
    Il2CppObject **triggers = unity::find_objects_of_type(trigger_type, &trigger_count, true);
    for (size_t i = 0; triggers && i < trigger_count; ++i)
    {
        Il2CppObject *trigger = triggers[i];
        if (!trigger || string_field(trigger, "_cutsceneId") != "Icebreaker_1")
            continue;
        scenario_trigger_id_ = string_field(trigger, "_triggerId");
        scenario_rally_zone_ = nullptr;
        scenario_rally_collider_ = nullptr;

        Il2CppObject *rally_type =
            il2utils::get_system_type(assembly_csharp_, "EFT.GameTriggers", "TriggerRallyZone");
        Il2CppObject *box_type = il2utils::get_system_type(
            il2utils::resolve_image("UnityEngine.PhysicsModule.dll"), "UnityEngine", "BoxCollider");
        Il2CppObject *game_object = unity::component_get_game_object(trigger);
        if (game_object && rally_type && box_type)
        {
            scenario_rally_zone_ = unity::gameobject_get_component(game_object, rally_type);
            scenario_rally_collider_ = unity::gameobject_get_component(game_object, box_type);
        }
        logger::info("Icebreaker scenario boundary resolved: triggerId=" + scenario_trigger_id_
            + ", cutsceneId=Icebreaker_1, object=" + unity::get_name(trigger)
            + ", rallyZone=" + std::string((scenario_rally_zone_ ? "available" : "missing"))
            + ", boxCollider=" + std::string((scenario_rally_collider_ ? "available" : "missing")));
        return;
    }
}

void IcebreakerScenarioModule::log_trigger_emitter() {
    if (trigger_emitter_logged_ || !get_trigger_emitter_)
        return;

    Il2CppObject *emitter = get_trigger_emitter_();
    if (!emitter)
        return;

    logger::info("Icebreaker TriggersEmitter.Instance: type="
        + std::string((emitter->klass && emitter->klass->name ? emitter->klass->name : "(null)")));
    trigger_emitter_logged_ = true;
}

void IcebreakerScenarioModule::log_rally_zones() {
    if (rally_zones_logged_)
        return;

    Il2CppObject *type = il2utils::get_system_type(assembly_csharp_, "EFT.GameTriggers", "TriggerRallyZone");
    size_t count = 0;
    Il2CppObject **zones = unity::find_objects_of_type(type, &count, true);
    if (!zones)
        return;

    logger::info("Icebreaker TriggerRallyZone: count=" + std::to_string(count));
    for (size_t i = 0; i < count; ++i)
    {
        Il2CppObject *zone = zones[i];
        if (!zone)
            continue;
        logger::info("Icebreaker rally zone[" + std::to_string(i) + "]: triggerId=" + string_field(zone, "_triggerId")
            + ", object=" + unity::get_name(zone)
            + ", wasTriggered=" + std::to_string(value_field<bool>(zone, "_wasTriggered"))
            + ", localPlayerInZone=" + std::to_string(value_field<bool>(zone, "_localPlayerInZone")));
    }
    rally_zones_logged_ = true;
}

void IcebreakerScenarioModule::reset_raid() {
    controllers_logged_ = false;
    online_world_logged_ = false;
    last_server_ = nullptr;
    last_client_ = nullptr;
    raid_world_ = nullptr;
    logged_bank_ = nullptr;
    scenario_ready_logged_ = false;
    start_attempted_ = false;
    trigger_emitter_logged_ = false;
    rally_zones_logged_ = false;
    state_seen_ = false;
    queue_skip_cutscene_ = false;
    cutscene_active_ = false;
    skip_hold_ = 0.0f;
    last_cutscene_id_.clear();
    trigger_pending_ = false;
    scenario_trigger_id_.clear();
    playable_director_client_ = nullptr;
    playable_director_ = nullptr;
    cutscene_director_client_ = nullptr;
    cutscene_root_ = nullptr;
    scenario_rally_zone_ = nullptr;
    scenario_rally_collider_ = nullptr;
}
