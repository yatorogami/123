#pragma once

#include <Windows.h>
#include <algorithm>
#include <cctype>
#include <string>
#include <vector>

#include "../Module.h"
#include "WorldModule.h"
#include "../eft_api.h"
#include "../game_item_db.h"
#include "../item_categories.h"
#include "../../config/ActionRowValue.h"
#include "../../config/CheckboxValue.h"
#include "../../config/ItemSearchValue.h"
#include "../../config/SelectValue.h"
#include "../../il2cpp/Il2CppObjectInstance.h"
#include "../../gui/menu/imgui_addons.h"

// UI bridge: WorldModule continues to own the runtime teleport logic and the shared
// map/ring settings. This module presents the Loot TP controls in Teleport and owns a
// self-contained copy of the item-selection filter logic (wishlist / selected item /
// handbook category) that previously lived behind EspModule::matches_loot_teleport_filter.
// The card must not depend on the ESP renderer module, so the selection logic and its
// settings are duplicated here instead (config keys prefixed "ltp_*").
class LootTeleportModule final : public Module
{
  public:
    explicit LootTeleportModule(WorldModule* world);

    void draw_overlay(ImDrawList*) override;
    void application_update() override;
    void gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) override;
    void init() override;
    [[nodiscard]] bool draw_menu_extra_before_values() const override;

    void draw_menu_extra() override;

  private:
    WorldModule* world_ = nullptr;

    // --- Item-selection settings (self-contained; no EspModule dependency) ---
    ItemSearchValue* loot_selected_item_;
    SelectValue* loot_category_filter_;
    SelectValue* loot_wl_filter_;
    item_categories::wishlist_mask wishlist_mask() const;
    item_categories::filter_sets wishlist_sets_{};
    ULONGLONG wishlist_sets_refresh_ms_ = 0;

    // --- Filter helpers (duplicated from EspModule, kept self-contained) ---

    // The ItemTemplate subclass-derived loot bucket for a template id, or
    // loot::unknown. A thin wrapper so the filter reads in module terms rather than
    // reaching into game_items at three call sites.
    item_categories::loot loot_kind_for_template(const std::string& template_id) const;

    // Wishlist/hideout template IDs from Profile.WishlistManager, refreshed on demand.
    // Unlike the old EspModule path this does not gate on ESP's category toggles, so
    // wishlist teleports work regardless of the ESP loot-filters state.
    void ensure_wishlist_sets(Il2CppObject* profile, const bool force = false);

    item_categories::kind classify_template(const std::string& template_id) const;

    // Item-selection predicate used by the World module teleport actions. Same
    // semantics as the former EspModule::matches_loot_teleport_filter.
    bool matches_filter(const int filter, const std::string& template_id,
        std::string name, const bool is_quest, Il2CppObject* local_player = nullptr);

    ActionRowValue* teleport_quest_loot_;
    // The old combined option 2 asked "category OR wishlist", so a caller that wanted
    // only one of them got the other's items too. Split into two buttons, each on its
    // own filter number (item_categories::matches_teleport_filter cases 4 and 5).
    ActionRowValue* teleport_category_loot_;
    ActionRowValue* teleport_wishlist_loot_;
    ActionRowValue* teleport_selected_loot_;
};

// UI bridge: keeps the World module's bot-control behavior but presents it as
// a dedicated Bot Spawner card.
class BotControlModule final : public Module
{
  public:
    explicit BotControlModule(WorldModule* world);

    void draw_overlay(ImDrawList*) override;
    void application_update() override;
    void gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) override;
    void init() override;

    void draw_menu_extra() override;

  private:
    WorldModule* world_ = nullptr;
};
