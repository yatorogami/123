#include "common.h"
#include "AiLimitModule.h"

AiLimitModule::AiLimitModule(WorldModule* world, PlayerModule* player) : Module("AI Limit", BotSpawner, "ai_limit_sec"), world_(world), player_(player),
                                                 section_ai_limit_(conf(new MenuSectionValue("ai_limit_sec"))),
                                                 ai_limit_enabled(conf(new CheckboxValue(false, "ai_limit_enabled_cb"))),
                                                 ai_limit_auto_map(conf(new CheckboxValue(true, "ai_limit_auto_map_cb"))),
                                                 ai_limit_deactivate(conf(new CheckboxValue(false, "ai_limit_deactivate_cb"))),
                                                 ai_limit_active(conf(new IntSliderEditableValue(6, 0, 20, "ai_limit_active_itm"))),
                                                 ai_limit_distance(conf(new IntSliderEditableValue(150, 50, 400, "ai_limit_distance_itm"))),
                                                 ai_limit_grace(conf(new FloatSliderEditableValue(10.f, 0.f, 60.f, "ai_limit_grace_itm"))),
                                                 ai_limit_interval(conf(new IntSliderEditableValue(300, 30, 600, "ai_limit_interval_itm"))),
                                                 ai_limit_info_(conf(new InfoDrawValue([this] {
                                                     ai_limit_draw_info();
                                                 },
                                                     "ai_limit_info"))),
                                                 section_invisible_(conf(new MenuSectionValue("ai_limit_invisible_sec"))),
                                                 invisible_to_bots_neutral(conf(new CheckboxValue(false, "invisible_to_bots_neutral_cb"))),
                                                 invisible_to_bots_ally(conf(new CheckboxValue(false, "invisible_to_bots_ally_cb"))) {
    // Keep these three out of the framework's automatic value list.
    //
    // Two reasons, and the first one is a bug that shipped: menu.cpp's apply()
    // draws every conf()-registered value, and draw_menu_extra() below drew
    // these three AGAIN, so the card rendered the two toggles twice -- once on
    // top and once at the bottom, in swapped order, both sharing one ImGui ID.
    // The hidden flag is the pattern the other hand-laid cards use
    // (LootTeleportModule, HideoutAutomationModule, BotControlModule) for
    // exactly this; see config/ConfigValue.h.
    //
    // The second is order. The framework draws values in DECLARATION order, not
    // in the order this initializer list names them, and the two toggles are
    // declared public (hotkeys bind them) while everything else is private. So
    // the toggles happened to register FIRST and land on top by accident --
    // which is the order we want, but only by accident. Drawing them
    // explicitly from draw_menu_extra_before_values() pins it, so moving a
    // member across the public/private boundary can no longer silently
    // reshuffle the card.
    section_invisible_->set_hidden_in_owner_menu(true);
    invisible_to_bots_ally->set_hidden_in_owner_menu(true);
    invisible_to_bots_neutral->set_hidden_in_owner_menu(true);
}

void AiLimitModule::draw_overlay(ImDrawList*) {}

void AiLimitModule::application_update() {
    // Mutual exclusion, also in prepare_menu_draw() below. This call is not the
    // load-bearing one -- see that comment -- it only keeps the hotkey path
    // from going stale while the menu is shut. Two get_value() and two
    // set_value()/set_disabled(), no managed code, so not behind the cadence.
    sync_invis_state();
}

void AiLimitModule::prepare_menu_draw() {
    // The mutual exclusion MUST live on an ungated path.
    //
    // It used to live only in application_update(), which ModuleManager::apply()
    // gates on is_active() -- and is_active() is exactly "one of these three
    // toggles is on". So turning the LAST toggle off stopped the very code that
    // has to react to that turn-off: the peer stayed greyed out until the game
    // was restarted, and the card read as broken. commit 601a79179 added the
    // missing else-branch and it changed nothing, because the branch was never
    // reached. Same structural class as the ally-ing-behind-the-limit-gate bug
    // one commit earlier: a feature whose only liveness check is one of the
    // values it is meant to police cannot observe that value going false.
    //
    // prepare_menu_draw() runs from menu.cpp's apply_all(), which is
    // is_active()-independent and is exactly where a row's clickability is
    // decided. The card is the only place disabled_ is observable, so this is
    // the only place that has to be right.
    sync_invis_state();
}

void AiLimitModule::init() {}

[[nodiscard]] bool AiLimitModule::draw_menu_extra_before_values() const { return true; }

void AiLimitModule::draw_menu_extra() {
    // Ally-ing first, on purpose: these are two rows with no sliders, no map
    // lookup and no raid dependency, and they are what most people reach for on
    // this tab. They sit above the limit's own knobs rather than under them.
    //
    // Drawn HERE, before the framework's value list, rather than left where the
    // automatic renderer happened to put them -- see the ctor comment for why
    // that position was an accident of the public/private boundary.
    //
    // The two are OWNED here now (the move), so these are the card's own values,
    // not a bridge. The `player_` handle only remains to satisfy the ctor
    // signature the rest of the codebase uses for card cross-references.
    (void)player_;
    section_invisible_->draw();
    invisible_to_bots_ally->draw();
    invisible_to_bots_neutral->draw();
}

// Unity Time.time, so a field the game compares against Time.time can be
// written with a value on the same clock. WorldModule had this as an overload of
// a private helper for the spawn queue; this is the copy for the standby field.
namespace {
    float ai_limit_unity_time() {
        static const Il2CppImage* img = il2utils::resolve_image("UnityEngine.CoreModule.dll");
        if (!img) return 0.f;
        const Il2CppClass* time_class = il2utils::resolve_class(img, "UnityEngine", "Time");
        if (!time_class) return 0.f;
        const MethodInfo* get_time = il2utils::resolve_method(time_class, "get_time", 0);
        if (!get_time || !get_time->methodPointer) return 0.f;
        return reinterpret_cast<float (*)(const MethodInfo*)>(get_time->methodPointer)(get_time);
    }
}

//
// This is AI-perception behaviour, so it lives on the AI Limit card rather than
// in the middle of the Player card's misc section. It was MOVED, not bridged:
// the two ConfigValues, the InvisibleToBots enum, the chain walk, the reporter
// and the cadence all rehomed together, and hotkeys_register.cpp was repointed.
// The config keys therefore change from `##Player` to `##AI Limit`, which means
// a saved value under the old key is not found and falls back to the default --
// accepted deliberately, and the reason no migration exists here.
//
// THE LAG, AND WHY THE FIX BELOW IS THE WHOLE POINT.
//
// The ally path has no game API for "make this player an ally" -- verified in
// the dump: BotGroupHostility has no AddAlly, the surviving AddAlly on EFT/Player
// is an empty `ret 0` stub, and the real method is private and takes a struct.
// So it writes BotGroupHostility.Allies directly, and to do that it must supply
// a BotGroupEnemyInfo as the dictionary's VALUE, because the dictionary is
// typed. That meant constructing one object per bot per call.
//
//   Dictionary<IPlayer, BotGroupEnemyInfo>.Add(local_player, info)
//
// and `Add` THROWS on a key that is already there. From the game's own binary:
//
//   mscorlib Dictionary`2.Add:  mov r9b,2   <- InsertionBehavior
//                               call <TryInsert>
//   InsertionBehavior.cs:      ThrowOnExisting = 2
//
// .NET's contract is the same: Add throws ArgumentException on a duplicate.
//
// So the first call inserted the player and every later call -- 4 Hz, per bot
// group, forever -- threw a managed exception, complete with an object
// allocation and a 24-frame stack capture, unwinding out through our native
// hook frames. That is the lag. It is also why it never crashed: the exception
// propagates into the game's own managed frame, which catches it, so the cost
// is paid and nothing appears to go wrong.
//
// The 2026-10-11 log corroborates it without being able to prove it: the crash
// probe's 24-entry ring held 18 consecutive `0xE06D7363` events -- a C++/IL2CPP
// exception was thrown -- as the dominant recent activity, at the moment the
// feature was applying. The frames are a stack-word scan through GameAssembly
// and UnityPlayer with none in this module, which is what a managed throw out
// of a methodPointer call looks like from outside.
//
// THE FIX: ask before writing. ContainsKey is one managed call with no throw,
// so a bot group the player is already an ally of costs one lookup instead of
// an allocation, a constructor and a thrown exception. Add is now reached only
// when it cannot throw.

#include "common.h"
#include "AiLimitModule.h"

#include <Windows.h>

// Bit flags naming each link in the invisible-to-bots chain, so a break can be
// named instead of being a silent no-op. See report_invisible_link_state().
enum : unsigned {
    inv_world_list = 1u << 0, // GameWorld.AllAlivePlayersList missing/empty
    inv_is_your_player = 1u << 1,
    inv_ai_data = 1u << 2,
    inv_bot_owner = 1u << 3,
    inv_bots_group = 1u << 4,
    inv_hostility = 1u << 5,    // BotsGroup.get_BotGroupHostility missing/null
    inv_remove_enemy = 1u << 6, // BotGroupHostility.RemoveEnemyAction missing
    inv_add_neutral = 1u << 7,  // BotGroupHostility.AddNeutralAction missing
    inv_args = 1u << 8,         // hostility/local_player/group contains null
    inv_allies_dict = 1u << 9,  // BotGroupHostility.Allies field missing/null
    inv_enemy_info = 1u << 10,  // BotGroupEnemyInfo class/ctor unavailable
    inv_dict_add = 1u << 11,    // Dictionary.Add unavailable
    inv_no_methods = 1u << 12,  // hostility object found, no method for the mode resolved
    inv_already_ally = 1u << 13, // player was already in Allies -- no write needed
};

static const char* invisible_flag_name(unsigned f) {
    switch (f)
    {
    case inv_world_list: return "AllAlivePlayersList";
    case inv_is_your_player: return "get_IsYourPlayer";
    case inv_ai_data: return "get_AIData";
    case inv_bot_owner: return "get_BotOwner";
    case inv_bots_group: return "get_BotsGroup";
    case inv_hostility: return "get_BotGroupHostility";
    case inv_remove_enemy: return "RemoveEnemyAction";
    case inv_add_neutral: return "AddNeutralAction";
    case inv_args: return "null argument";
    case inv_allies_dict: return "Allies";
    case inv_enemy_info: return "BotGroupEnemyInfo";
    case inv_dict_add: return "Dictionary.Add";
    case inv_no_methods: return "no method for this mode";
    case inv_already_ally: return "already in Allies";
    default: return "?";
    }
}

// reports only on CHANGE, so the steady state is one line per raid rather than
// one per cadence tick -- and a bitmask still surfaces a rename the moment it
// gets through, which a plain `static bool warned` would swallow.
static void report_invisible_link_state(unsigned mask, bool applied) {
    static unsigned reported_mask = ~0u; // sentinel: force a report on the 1st call
    static bool reported_applied = false;

    const bool changed = mask != reported_mask || applied != reported_applied;
    if (!changed) return;
    reported_mask = mask;
    reported_applied = applied;

    std::string detail = "invisible_to_bots: ";
    detail += applied ? "applied to at least one bot"
                      : "applied to NO bots (this feature is inert)";

    if (mask)
    {
        detail += "; unresolved links: ";
        bool first = true;
        for (unsigned f = 1u; f; f <<= 1)
        {
            if (!(mask & f)) continue;
            if (!first) detail += ", ";
            detail += invisible_flag_name(f);
            first = false;
        }
    }
    else
    {
        detail += "; every link resolved";
    }
    logger::warn(detail);
}

// ALLY PATH. There is no game API for this.
//
// BotGroupHostility has no AddAlly method and no OnAddAlly event -- only
// OnAddNeutral, OnEnemyAdd and OnEnemyRemove. The one surviving AddAlly, on
// EFT/Player, is an empty `ret 0` stub (EFT/Player.txt:158351). And the method
// that would do it properly, BotGroupHostility.UpdatePlayerHostilityCollection,
// is private and takes a HostilityEvaluationResult -- a 16-byte STRUCT. Calling
// a struct-taking method through methodPointer means guessing the value-type
// calling convention, which is exactly the kind of thing that fails silently.
// So the Allies dictionary is written directly instead.
//
// Field offset from GameDump/120047888/dump.cs:70684 -- Allies is a public
// Dictionary<IPlayer, BotGroupEnemyInfo> at +0x38 on BotGroupHostility.
// BotsGroup.IsAlly reads exactly this field (ISIL: mov rax,[rbx+18h] ; mov
// rax,[rax+38h]), so a player present in it is an ally as far as the game's
// own checks are concerned.
//
// The dictionary value only has to be non-null -- IsAlly is a lookup keyed on
// the player -- but it must be a real BotGroupEnemyInfo because the dictionary
// is typed. Constructed via the same il2cpp_object_new + .ctor pattern as
// InventoryEditorModule::create_and_attach_buff.
//
// Returns true if the player is in Allies afterwards, whether it was already
// there or this call added it. Sets mask bits naming what failed.

// Resolve `name` on inst's class as a function pointer whose type ALREADY ends
// in the hidden trailing const MethodInfo* (il2utils::with_methodinfo). il2cpp
// shared-generic bodies read that argument from whatever register a bare
// methodPointer call leaves behind: the 2026-10-12 19:27 crash (dump
// EscapeFromTarkov.exe.21808.dmp) was ContainsKey's shared body at
// GameAssembly+0x5B1DA0 faulting on its FIRST instruction, mov rax,[r8+0x20],
// with r8 = leftover 0xFFFFFFFFFFFFFFDF, so the read landed at
// 0xFFFFFFFFFFFFFFFF. The 2026-10-08 Dictionary<object,object>::Add AV is the
// same ABI (see il2utils.h with_methodinfo). Null inst or a miss resolves to
// nullptr, matching get_method's contract.
template <typename FP>
static il2utils::with_methodinfo_t<FP> resolve_mi(Il2CppObject* inst, const char* name, int args, const MethodInfo** mi) {
    *mi = nullptr;
    return inst
        ? il2utils::get_method<il2utils::with_methodinfo_t<FP>>(inst->klass, name, args, false, true, mi)
        : nullptr;
}

static bool add_player_to_allies(Il2CppObject* hostility, Il2CppObject* local_player,
    Il2CppObject* group, unsigned& mask) {
    if (!hostility || !local_player || !group)
    {
        mask |= inv_args;
        return false;
    }

    Il2CppObject* allies = nullptr;
    {
        Il2CppObjectInstance h(hostility);
        allies = h.get_field<Il2CppObject*>("Allies");
    }
    if (!allies)
    {
        mask |= inv_allies_dict;
        return false;
    }

    // VALIDATE THE DICTIONARY BEFORE CALLING INTO IT. Added 2026-10-12.
    //
    // CORRECTED 2026-10-12 against the 19:27 dump (pid 21808,
    // EscapeFromTarkov.exe.21808.dmp, build 0x6ACD08AE): the earlier attribution
    // below was WRONG. The same GameAssembly RVA 0x5B1DA4 had faulted across
    //
    //   pid 27316  23:00:03  build 0x6ACBE6E1
    //   pid 10316  23:04:57  build 0x6ACBE6E1
    //   pid 22580  08:13:11  build 0x6ACC6B59
    //
    // and this session -- with the validation below COMPILED IN and every check
    // PASSING -- faulted there again, reading the all-ones sentinel
    // 0xFFFFFFFFFFFFFFFF. minidump_read + pe_disasm on the dump show why: 0x5B1DA4
    // is the FIRST instruction of the shared generic-instantiation body at
    // 0x5B1DA0 (dump.cs: Dictionary<object, Vector3>.ContainsKey and
    // Dictionary<object, EventFilter...>.ContainsKey share it), and it is
    //   mov rax, [r8+0x20]
    // i.e. the body reads its hidden trailing MethodInfo* ARGUMENT. Our bare
    // 2-argument methodPointer call never sets r8, so it held leftover resolver
    // garbage (0xFFFFFFFFFFFFFFDF). The stale-dictionary theory predicted a fault
    // LATER, inside FindEntry's bucket walk; all four sessions faulted at the
    // same instruction #2. The 2026-10-08 Dictionary<object,object>::Add AV is
    // the same ABI. The actual fix is resolve_mi()'s trailing MethodInfo* on
    // every managed call in this chain; this block stays as defense in depth.
    //
    // WHY THE CHECKS STAY ANYWAY. A non-null Il2CppObject* from a field read is
    // not a live dictionary: the field can hold a pointer to an object whose own
    // fields (m_p_buckets / m_p_entries / m_i_count) are stale, because the GC
    // reuses freed memory rather than unmapping it. This is the SAME shape as
    // production_panel_probe.h:1915, which gates its dictionary walk on
    // `is_readable_address(dict->m_p_entries, sizeof(Il2CppArray))` before
    // reading entries, and as the skeleton Bones walk in EspModule.h.
    //
    // WHAT IT COSTS: pointer tests only, no managed call, and it runs on the
    // 250 ms cadence path -- not per frame. is_il2cpp_object_likely_valid is the
    // cheap form (obj && klass && klass->name), deliberately NOT
    // is_il2cpp_object_strict, which memoises page readability and whose own
    // comment records 289,255 calls costing 42.3 s on a path like this one.
    //
    // WHAT IT BUYS: a skip instead of a fault when the dictionary is not in a
    // shape the managed method can walk. The feature degrades to "this bot group
    // is not handled this tick", which is the same outcome as any other inv_*
    // bit here, and it retries on the next cadence tick once the game has
    // rebuilt the dictionary.
    if (!eft_api::is_il2cpp_object_likely_valid(allies))
    {
        mask |= inv_allies_dict;
        return false;
    }
    {
        const auto* allies_dict =
            reinterpret_cast<const unity::dict<Il2CppObject*, Il2CppObject*>*>(allies);
        // m_p_entries is what ContainsKey indexes; a null or unreadable one is the shape that
        // produced the fault. m_i_count is sanity-bounded against capacity so a half-torn
        // dictionary cannot claim more live entries than it has slots.
        if (!allies_dict->m_p_entries
            || !eft_api::is_readable_address(allies_dict->m_p_entries, sizeof(Il2CppArray))
            || allies_dict->m_i_count < 0
            || allies_dict->m_i_count > allies_dict->m_p_entries->max_length)
        {
            mask |= inv_allies_dict;
            return false;
        }
    }

    // THE FIX. Ask first. ContainsKey is one managed call that cannot throw;
    // Add on an existing key raises ArgumentException, and raising it 4 times a
    // second per bot group is what made this feature lag the game. See the
    // block comment at the top of this section for the binary that proves it.
    const MethodInfo* contains_mi = nullptr;
    const auto contains = resolve_mi<bool (*)(Il2CppObject*, Il2CppObject*)>(
        allies, "ContainsKey", 1, &contains_mi);
    if (contains && contains_mi)
    {
        if (contains(allies, local_player, contains_mi))
        {
            // Already an ally as far as every game-side check is concerned.
            // Nothing to write, and nothing is allocated or thrown.
            mask |= inv_already_ally;
            return true;
        }
    }

    const Il2CppImage* img = il2utils::resolve_image("Assembly-CSharp.dll");
    const Il2CppClass* info_class = img ? il2utils::resolve_class(img, "", "BotGroupEnemyInfo") : nullptr;
    if (!info_class)
    {
        mask |= inv_enemy_info;
        return false;
    }
    il2cpp::il2cpp_runtime_class_init(const_cast<Il2CppClass*>(info_class));
    Il2CppObject* info = il2cpp::il2cpp_object_new(info_class);
    if (!info)
    {
        mask |= inv_enemy_info;
        return false;
    }

    {
        Il2CppObjectInstance info_inst(info);
        info_inst.call_or_void<void (*)(Il2CppObject*, Il2CppObject*, Il2CppObject*)>(
            ".ctor", 2, local_player, group);
    }

    // Only reached when ContainsKey said the key is absent (or ContainsKey did
    // not resolve, in which case the write is the old behaviour). Add cannot
    // throw here, because the key is not present.
    const MethodInfo* add_mi = nullptr;
    const auto add = resolve_mi<void (*)(Il2CppObject*, Il2CppObject*, Il2CppObject*)>(
        allies, "Add", 3, &add_mi);
    if (!add || !add_mi)
    {
        mask |= inv_dict_add;
        return false;
    }
    add(allies, local_player, info, add_mi);
    return true;
}

// Cadence for the invisible-to-bots chain, in ms.
//
// This ran EVERY FRAME while the toggle was on, and that is the reported lag.
// Per bot it walks IsYourPlayer -> AIData -> BotOwner -> BotsGroup ->
// BotGroupHostility and then calls RemoveEnemyAction plus AddNeutralAction (or
// writes the Allies dictionary at +0x38) -- six managed lookups and two
// collection MUTATIONS, per bot, per frame. On a 40-bot raid at 60 fps that is
// ~2,400 managed calls a second of which ~800 are list/dict operations.
//
// 250 ms (4 Hz) is the cadence: it is far below the rate at which a bot's
// perception can re-acquire the local player, so the feature is unaffected, and
// it cuts the cost by roughly the frame rate divided by four. The first call
// still happens immediately (last_ms_ == 0), so turning the toggle on takes
// effect at once rather than after a delay.
//
// The cadence was NOT what made it lag, which is worth recording: even at 4 Hz
// the ally path threw an exception per bot group per tick, and fixing the
// cadence only reduced the rate of the throwing. See add_player_to_allies.
constexpr ULONGLONG kInvisibleBotsIntervalMs = 250;

// --- AI limit (port of the `ailimit` submodule) ----------------------------
//
// WHAT ailimit DOES. It walks every bot in the raid, sorts them by how far the
// nearest human is, and lets the first N within D metres keep working AI; the
// rest are parked, so a map that would run 25 thinking bots runs 6 plus 19
// idle bodies. Bots younger than the grace period are never parked, and the
// scan re-runs on a frame interval rather than every frame. All four knobs are
// on the Bot Controls card of the Bot Spawner tab.
//
// EVERY MEMBER NAME BELOW IS READ OUT OF THE GAME. All three IsilDump trees
// (115147510, 120047888, 120047965) were checked, which is why each link below
// tries a getter AND a field: the oldest keeps BotOwner.Settings / .Memory as
// plain public fields, the two newer ones moved them behind
// <Name>k__BackingField behind a getter.
//
//   BotOwner.Settings                get_Settings() | <Settings>k__BackingField | Settings
//   BotSettings.FileSettings         get_FileSettings() | <FileSettings>k__BackingField
//   BotSettingsComponents.Mind       field
//   BotGlobalsMindSettings.CAN_STAND_BY  bool field -- DoStay() returns without it
//   BotOwner.StandBy                 get_StandBy()
//   BotStandBy.CanDoStandBy          bool property
//   BotStandBy._nextCheckTime        float field -- Update() returns early while
//                                    Time.time <= it, which is what makes a
//                                    large value park the bot
//   BotStandBy.Activate()            standByType = active (3)
//   BotStandBy.DoStay()              standByType = paused (1) + BotMover.SetPose(0f)
//   BotOwner.BotState                set_BotState(EBotState): NonActive 0, Active 2
//   BotOwner.IsDead                  get_IsDead()
//   BotMemory.GoalEnemy              via WorldModule::bot_clear_goals
//
// DIVERGENCE FROM ailimit, ON PURPOSE. ailimit ends the park with
// `player.gameObject.SetActive(false)`. It is a server-side SPT plugin, so that
// removes the bot from the authoritative simulation. This DLL is a client guest
// in a live raid: SetActive(false) on a bot cannot be exercised here and cannot
// be recovered cleanly if the server re-activates it, so the park stops at
// DoStay -- the game's own idle path -- and the wake is its exact mirror. The
// consequence is real and worth stating: a parked bot still costs its renderer,
// it just stops thinking.
//
// A chain link that fails to resolve is reported ONCE PER RAID rather than once
// per scan. tools/tests/test_invisible_bots_chain.py exists because a
// best-effort chain that fails silently is indistinguishable from one that works.
namespace {
    // BotStandByType (diffable cs): none 0, paused 1, goToSave 2, active 3.
    constexpr int ai_limit_standby_paused = 1;
    constexpr int ai_limit_standby_active = 3;
    // EBotState (diffable cs): NonActive 0, PreActive 1, Active 2, ActiveFail 3,
    // Disposed 4.
    constexpr int ai_limit_bot_state_nonactive = 0;
    constexpr int ai_limit_bot_state_active = 2;

    struct ai_limit_map_row {
        const char* location; // EFT LocationId, lowercased
        int active;          // bots that keep working AI at once
        int distance;        // metres after which a bot is parked
    };

    // ailimit's per-map table, verbatim. A map that is not listed keeps whatever
    // the sliders hold: ailimit's own default branch is 6 / 200, but silently
    // overwriting a manual setting on a map it never names (Labyrinth) is worse
    // than leaving it alone.
    const ai_limit_map_row ai_limit_map_rows[] = {
        {"factory4_day", 6, 150},
        {"factory4_night", 6, 150},
        {"laboratory", 6, 150},
        {"sandbox", 6, 210},
        {"sandbox_high", 6, 210},
        {"bigmap", 6, 270},
        {"rezervbase", 6, 225},
        {"interchange", 6, 300},
        {"tarkovstreets", 6, 270},
        {"woods", 6, 275},
        {"shoreline", 6, 275},
        {"lighthouse", 6, 270},
    };

    enum class ai_limit_link {
        settings = 0,
        file_settings,
        mind,
        standby,
        count,
    };

    // Main-thread only (gameworld_update), so a plain static is enough.
    void ai_limit_report_unresolved(const ai_limit_link link, const char* what) {
        static bool reported[static_cast<int>(ai_limit_link::count)] = {};
        const int slot = static_cast<int>(link);
        if (reported[slot])
            return;
        reported[slot] = true;
        logger::warn(std::string("AI limit: unresolved ") + what
            + " -- the feature is inert on this game build until it resolves");
    }

    // A member that is a property on this build and a public field on another.
    // Order is getter, IL2CPP backing field, plain field. A miss reports itself
    // through `link` once; a hit never logs.
    Il2CppObject* ai_limit_prop_or_field(Il2CppObjectInstance& inst, const char* getter,
        const char* backing_field, const char* plain_field, const ai_limit_link link) {
        if (Il2CppObject* via_method = inst.call_or<Il2CppObject*>(getter, 0, nullptr))
            return via_method;
        if (Il2CppObject* via_backing = inst.get_field<Il2CppObject*>(backing_field))
            return via_backing;
        if (plain_field)
            if (Il2CppObject* via_plain = inst.get_field<Il2CppObject*>(plain_field))
                return via_plain;
        ai_limit_report_unresolved(link, getter);
        return nullptr;
    }

    bool ai_limit_owner_is_dead(Il2CppObject* bot_owner) {
        if (!bot_owner)
            return false;
        Il2CppObjectInstance owner(bot_owner);
        return owner.call_or<bool>("get_IsDead", 0, false);
    }

    // UnityEngine.GameObject.SetActive(bool), resolved once and reported once.
    //
    // This is ailimit's second half, and it is NOT part of the game's own standby
    // protocol -- worth being precise about that, because it is easy to assume it
    // is. EFT.Player has no SetActive member (checked in all three IsilDump
    // trees), and the virtual bool call inside BotStandBy.DoStay() / Activate()
    // (vtable +0xEC8) is one of Player's own setters, not a GameObject toggle. So
    // nothing in the game ever turns a bot's GameObject off; DoStay() parks the
    // AI and the body keeps updating. That extra half is what makes a parked bot
    // stop costing frames entirely, and it is safe in a session with no server to
    // disagree with. On a live raid it is a local lie, which is why it is behind
    // its own checkbox.
    bool ai_limit_set_game_object_active(Il2CppObject* game_object, const bool active) {
        static const MethodInfo* set_active = nullptr;
        static bool resolved = false;
        if (!resolved)
        {
            resolved = true;
            const Il2CppImage* unity_engine = il2utils::resolve_image("UnityEngine.CoreModule.dll");
            const Il2CppClass* game_object_class = unity_engine
                ? il2utils::resolve_class(unity_engine, "UnityEngine", "GameObject")
                : nullptr;
            if (game_object_class)
            {
                const MethodInfo* method = il2utils::resolve_method(game_object_class, "SetActive", 1);
                if (method && method->methodPointer)
                    set_active = method;
            }
            if (!set_active)
                logger::warn("AI limit: UnityEngine.GameObject.SetActive unresolved -- parked bots stay active, which is the safe behaviour anyway");
        }
        if (!set_active || !game_object)
            return false;
        reinterpret_cast<void (*)(Il2CppObject*, bool, const MethodInfo*)>(
            set_active->methodPointer)(game_object, active, set_active);
        return true;
    }

    void ai_limit_set_bot_state(Il2CppObject* bot_owner, const bool active) {
        if (!bot_owner)
            return;
        Il2CppObjectInstance owner(bot_owner);
        owner.call_or_void<void (*)(Il2CppObject*, int)>("set_BotState", 1,
            active ? ai_limit_bot_state_active : ai_limit_bot_state_nonactive);
    }

    // LocationId, LOWERCASED. The probe itself is now eft_api::read_location_id --
    // this was the fifth copy, and the note that used to sit here is the one the
    // consolidation fulfils: it was "consolidation-eligible rather than
    // load-bearing" once the optics freeze lifted on 2026-10-13, and map_icf was
    // right that it saves no bytes (only EspModule's survived as a symbol; this
    // one was inlined). What is left is the part that was genuinely this
    // module's own: the AI comparison is case-insensitive, so the fold is the
    // one behavioural difference among the copies and it stays here.
    std::string ai_limit_read_location(Il2CppObjectInstance& game_world) {
        std::string id = eft_api::read_location_id(nullptr, game_world);
        for (char& ch : id)
            if (ch >= 'A' && ch <= 'Z')
                ch = static_cast<char>(ch - 'A' + 'a');
        return id;
    }
} // namespace

bool AiLimitModule::ai_limit_fill_from_map(const std::string& location_id) {
    if (location_id.empty())
        return false;
    for (const ai_limit_map_row& row : ai_limit_map_rows)
    {
        if (location_id != row.location)
            continue;
        // set() is the only writer a ConfigValue offers, and it does not clamp --
        // both preset values are inside their slider's range by construction.
        ai_limit_active->set(std::to_string(row.active));
        ai_limit_distance->set(std::to_string(row.distance));
        return true;
    }
    return false;
}

bool AiLimitModule::ai_limit_chain_resolves(Il2CppObject* bot_owner) {
    if (!bot_owner || !bot_owner->klass)
        return false;

    Il2CppObjectInstance owner(bot_owner);
    Il2CppObjectInstance settings(ai_limit_prop_or_field(owner, "get_Settings", "<Settings>k__BackingField", "Settings", ai_limit_link::settings));
    if (!settings.get_instance())
        return false;
    Il2CppObject* file_settings = ai_limit_prop_or_field(settings, "get_FileSettings", "<FileSettings>k__BackingField", nullptr, ai_limit_link::file_settings);
    if (!file_settings)
        return false;

    // The chain is only useful if we can WRITE the flag, not just see it, so the
    // FieldInfo is resolved here and the write itself is left to the park path.
    Il2CppObject* mind = Il2CppObjectInstance(file_settings).get_field<Il2CppObject*>("Mind");
    if (!mind || !mind->klass || !il2utils::resolve_field(mind->klass, "CAN_STAND_BY"))
    {
        ai_limit_report_unresolved(ai_limit_link::mind, "BotSettingsComponents.Mind / CAN_STAND_BY");
        return false;
    }

    Il2CppObject* stand_by = ai_limit_get_standby(bot_owner);
    if (!stand_by || !stand_by->klass)
        return false;
    Il2CppObjectInstance standby(stand_by);
    if (!il2utils::resolve_field(stand_by->klass, "_nextCheckTime")
        || !il2utils::resolve_field(stand_by->klass, "<CanDoStandBy>k__BackingField")
        || !il2utils::resolve_method(stand_by->klass, "Activate", 0)
        || !il2utils::resolve_method(stand_by->klass, "DoStay", 0)
        || standby.call_or<int>("get_StandByType", 0, -1) < 0)
    {
        ai_limit_report_unresolved(ai_limit_link::standby, "BotStandBy");
        return false;
    }
    return true;
}

Il2CppObject* AiLimitModule::ai_limit_get_standby(Il2CppObject* bot_owner) {
    if (!bot_owner)
        return nullptr;
    Il2CppObjectInstance owner(bot_owner);
    return owner.call_or<Il2CppObject*>("get_StandBy", 0, nullptr);
}

void AiLimitModule::ai_limit_set_bot_standby(Il2CppObject* bot_owner, Il2CppObject* player, const bool park) {
    if (!bot_owner || !bot_owner->klass)
        return;

    Il2CppObject* stand_by = ai_limit_get_standby(bot_owner);
    if (!stand_by || !stand_by->klass)
        return;
    Il2CppObjectInstance standby(stand_by);

    const float now = ai_limit_unity_time();
    const int type = standby.call_or<int>("get_StandByType", 0, -1);
    const bool needs_doing = park ? type != ai_limit_standby_paused
                                  : type != ai_limit_standby_active;

    if (park)
    {
        // Mind.CAN_STAND_BY is what DoStay() checks before it will do anything,
        // so it has to be written even for a bot that is already parked.
        Il2CppObjectInstance owner(bot_owner);
        Il2CppObjectInstance settings(ai_limit_prop_or_field(owner, "get_Settings", "<Settings>k__BackingField", "Settings", ai_limit_link::settings));
        if (settings.get_instance())
        {
            Il2CppObject* file_settings = ai_limit_prop_or_field(settings, "get_FileSettings", "<FileSettings>k__BackingField", nullptr, ai_limit_link::file_settings);
            Il2CppObject* mind = file_settings ? Il2CppObjectInstance(file_settings).get_field<Il2CppObject*>("Mind") : nullptr;
            if (mind)
                Il2CppObjectInstance(mind).set_field<bool>("CAN_STAND_BY", true);
        }

        // The cheap half runs every scan regardless: two field writes, and it is
        // what keeps the game's own Update() from re-evaluating a bot we have
        // already parked. Without it, Update() would put the bot back to
        // "active" as soon as it next ran, because the nearest enemy is far.
        standby.set_field<bool>("<CanDoStandBy>k__BackingField", true);
        standby.set_field<float>("_nextCheckTime", now + 1000.f);

        if (!needs_doing)
            return;

        // DoStay() parks it (standByType = paused, BotMover.SetPose(0f)); the
        // goal clear and the state change stop it engaging whatever it had
        // already decided to shoot at.
        standby.call_or_void<void (*)(Il2CppObject*)>("DoStay", 0);
        WorldModule::bot_clear_goals(bot_owner);
        ai_limit_set_bot_state(bot_owner, false);

        // And then the half that actually saves the frames: stop updating the
        // body at all. Only bots we did this to are ever switched back on, and
        // the IsDead re-check is here because a bot can die between the caller's
        // liveness test and this line -- deactivating a corpse mid-animation is
        // the one case nobody asked for. Keyed on the PLAYER, not the owner, so
        // the per-pass prune can match it against AllAlivePlayersList.
        if (ai_limit_deactivate->get_value() && !ai_limit_owner_is_dead(bot_owner))
        {
            Il2CppObject* game_object = unity::component_get_game_object(player);
            if (game_object && ai_limit_set_game_object_active(game_object, false))
                ai_limit_deactivated_.insert(player);
        }
        return;
    }

    // Waking one we deactivated: the GameObject goes back on BEFORE anything is
    // called on it. ailimit does SetActive(true) last, after Activate(); doing it
    // first means Activate() and BotPersonalStats.SetStandByState() never run
    // against a disabled object, which is the difference between a bot revived on
    // paper and a bot revived at all.
    if (ai_limit_deactivated_.erase(player) == 1)
    {
        Il2CppObject* game_object = unity::component_get_game_object(player);
        if (game_object)
            ai_limit_set_game_object_active(game_object, true);
    }

    standby.set_field<bool>("<CanDoStandBy>k__BackingField", true);
    standby.set_field<float>("_nextCheckTime", now + 10.f);
    if (!needs_doing)
        return;

    standby.call_or_void<void (*)(Il2CppObject*)>("Activate", 0);
    ai_limit_set_bot_state(bot_owner, true);
}

void AiLimitModule::update_invisible_to_bots(Il2CppObjectInstance game_world_instance,
    Il2CppObject* local_player) {
    // NOT gated on ai_limit_enabled, and it must stay that way.
    //
    // It was gated, and the 2026-10-11 log caught it: the limit was off, so
    // gameworld_update returned before reaching the invisibility cadence, and
    // ally-ing silently did nothing for a whole 18-minute raid while the card's
    // checkbox still read 'on'. No log line at all, because the reporter only
    // speaks when it runs -- which is the same invisible-failure shape the rest of
    // this file is written against.
    //
    // The structural cause is worth naming: two independent features share one
    // per-frame entry point, so any gate that RETURNS disables the other half.
    // This is called first and unconditionally, and nothing ahead of it returns.
    if (invisible_to_bots_neutral->get_value())
    {
        const ULONGLONG now = GetTickCount64();
        if (invisible_bots_last_ms_ == 0 || now - invisible_bots_last_ms_ >= kInvisibleBotsIntervalMs)
        {
            invisible_bots_last_ms_ = now;
            apply_invisible_to_bots(game_world_instance, local_player,
                InvisibleToBots::neutral);
        }
    }
    if (invisible_to_bots_ally->get_value())
    {
        const ULONGLONG now = GetTickCount64();
        if (invisible_bots_last_ms_ == 0 || now - invisible_bots_last_ms_ >= kInvisibleBotsIntervalMs)
        {
            invisible_bots_last_ms_ = now;
            apply_invisible_to_bots(game_world_instance, local_player,
                InvisibleToBots::ally);
        }
    }
}

void AiLimitModule::gameworld_update(const Il2CppClass*, Il2CppObjectInstance game_world_instance,
    Il2CppObjectInstance main_player) {
    // The raid is over: drop every cached bot. gameworld_update is only
    // called during one, so a stale location is the only thing that could
    // otherwise carry the previous raid's grace timestamps into this one.
    if (!game_state::is_in_raid)
    {
        ai_limit_first_seen_ms_.clear();
        ai_limit_slots_.clear();
        ai_limit_deactivated_.clear();
        ai_limit_awake_ = 0;
        ai_limit_total_ = 0;
        ai_limit_frame_ = 0;
        ai_limit_chain_checked_ = false;
        ai_limit_chain_broken_ = false;
        ai_limit_was_enabled_ = false;
        ai_limit_reported_ = false;
        return;
    }

    // Distances are measured from every human on the map, not from the local
    // player alone -- the same rule ailimit uses, and what makes a co-op player
    // keep the bots around THEM awake.
    (void)main_player;
    // Ally-ing runs FIRST and unconditionally. It has its own toggle and its own
    // cadence, so the limit being off must not disable it.
    update_invisible_to_bots(game_world_instance, main_player.get_instance());

    const bool enabled = ai_limit_enabled->get_value();

    // Turning it off restores what it parked. A raid that ends with frozen bots
    // is indistinguishable from a broken raid, so this is not optional.
    if (!enabled)
    {
        if (ai_limit_was_enabled_)
        {
            ai_limit_was_enabled_ = false;
            for (const ai_limit_slot& slot : ai_limit_slots_)
            {
                Il2CppObject* bot_owner = WorldModule::try_get_bot_owner_from_player(slot.player);
                if (bot_owner)
                    ai_limit_set_bot_standby(bot_owner, slot.player, false);
            }
        }
        ai_limit_frame_ = 0;
        return;
    }

    if (!ai_limit_was_enabled_)
    {
        ai_limit_was_enabled_ = true;
        ai_limit_frame_ = 0;
        ai_limit_first_seen_ms_.clear();
        ai_limit_slots_.clear();
        logger::info("AI limit: enabled");
    }

    // ailimit re-checks every "frames to check"; same gate here.
    ++ai_limit_frame_;
    const int interval = (std::max)(30, ai_limit_interval->get_value());
    if (ai_limit_frame_ < interval)
        return;
    ai_limit_frame_ = 0;

    unity::list* alive_list = game_world_instance.get_field<unity::list*>("AllAlivePlayersList");
    if (!alive_list || !alive_list->m_p_list_array)
        return;
    Il2CppArray* alive_players = alive_list->m_p_list_array;
    if (alive_players->max_length == 0)
        return;

    // --- per-raid setup ---------------------------------------------------
    const std::string location = ai_limit_read_location(game_world_instance);
    if (!location.empty() && location != ai_limit_location_)
    {
        ai_limit_location_ = location;
        // Everything cached is about the bots of the raid we just left.
        ai_limit_first_seen_ms_.clear();
        ai_limit_chain_checked_ = false;
        ai_limit_chain_broken_ = false;
        ai_limit_reported_ = false;
        if (ai_limit_auto_map->get_value() && ai_limit_fill_from_map(location))
            logger::info("AI limit: " + location + " -> keep " + std::to_string(ai_limit_active->get_value())
                + " awake within " + std::to_string(ai_limit_distance->get_value()) + " m");
        else if (ai_limit_auto_map->get_value())
            logger::info("AI limit: " + location + " has no preset row; keeping the sliders as set");
    }

    const auto player_pos = [](Il2CppObject* player, unity::vector3& out) -> bool {
        if (!player)
            return false;
        Il2CppObject* game_object = unity::component_get_game_object(player);
        Il2CppObject* transform = game_object ? unity::gameobject_get_transform(game_object) : nullptr;
        if (!transform)
            return false;
        out = unity::transform_get_pos(transform);
        return true;
    };

    ai_limit_slots_.clear();
    ai_limit_slots_.reserve(alive_players->max_length);

    std::vector<unity::vector3> anchors;
    anchors.reserve(4);
    for (size_t i = 0; i < alive_players->max_length; ++i)
    {
        Il2CppObject* player = reinterpret_cast<Il2CppObject**>(&alive_players->data)[i];
        if (!player)
            continue;
        if (eft_api::try_player_is_ai(player))
        {
            ai_limit_slot slot;
            slot.player = player;
            ai_limit_slots_.push_back(slot);
            continue;
        }
        unity::vector3 pos{};
        if (player_pos(player, pos))
            anchors.push_back(pos);
    }

    ai_limit_awake_ = 0;
    ai_limit_total_ = static_cast<int>(ai_limit_slots_.size());
    if (anchors.empty() || ai_limit_slots_.empty())
        return;

    // --- distances and the spawn grace window ----------------------------
    const ULONGLONG now = GetTickCount64();
    const ULONGLONG grace_ms = static_cast<ULONGLONG>((std::max)(0.f, ai_limit_grace->get_value()) * 1000.f);
    const float limit_dist = static_cast<float>(ai_limit_distance->get_value());
    const float limit_dist_sq = limit_dist * limit_dist;
    const int active_limit = (std::max)(0, ai_limit_active->get_value());

    for (ai_limit_slot& slot : ai_limit_slots_)
    {
        unity::vector3 pos{};
        if (!player_pos(slot.player, pos))
        {
            slot.dist_sq = 1e30f;
            continue;
        }
        float best = 1e30f;
        for (const unity::vector3& anchor : anchors)
        {
            const float dx = pos.x - anchor.x;
            const float dy = pos.y - anchor.y;
            const float dz = pos.z - anchor.z;
            const float dist_sq = dx * dx + dy * dy + dz * dz;
            if (dist_sq < best)
                best = dist_sq;
        }
        slot.dist_sq = best;

        if (const auto seen = ai_limit_first_seen_ms_.find(slot.player);
            seen != ai_limit_first_seen_ms_.end())
            slot.eligible = now - seen->second >= grace_ms;
        else
            ai_limit_first_seen_ms_.emplace(slot.player, now);
    }

    // Drop bots that are no longer in the list. Without this the map grows for
    // the whole raid, and a dead bot's address keeps its timestamp for a bot
    // that inherits the address later.
    for (auto it = ai_limit_first_seen_ms_.begin(); it != ai_limit_first_seen_ms_.end();)
    {
        bool still_live = false;
        for (const ai_limit_slot& slot : ai_limit_slots_)
            if (slot.player == it->first)
            {
                still_live = true;
                break;
            }
        if (still_live)
            ++it;
        else
            it = ai_limit_first_seen_ms_.erase(it);
    }

    // Same for the deactivated set, and this one matters more: a bot that
    // despawned or died while its GameObject was off must stop being remembered,
    // because the pointer dies with it.
    for (auto it = ai_limit_deactivated_.begin(); it != ai_limit_deactivated_.end();)
    {
        bool still_live = false;
        for (const ai_limit_slot& slot : ai_limit_slots_)
            if (slot.player == *it)
            {
                still_live = true;
                break;
            }
        if (still_live)
            ++it;
        else
            it = ai_limit_deactivated_.erase(it);
    }

    // --- who stays awake --------------------------------------------------
    std::stable_sort(ai_limit_slots_.begin(), ai_limit_slots_.end(),
        [](const ai_limit_slot& a, const ai_limit_slot& b) { return a.dist_sq < b.dist_sq; });

    int awake = 0;
    for (ai_limit_slot& slot : ai_limit_slots_)
    {
        slot.keep_awake = awake < active_limit && slot.dist_sq <= limit_dist_sq && slot.eligible;
        if (slot.keep_awake)
            ++awake;
    }
    ai_limit_awake_ = awake;

    // --- apply ------------------------------------------------------------
    // The chain is resolved once per raid, on the first bot we are about to
    // touch, so a renamed link costs one warning and an inert feature rather
    // than a per-bot, per-scan stream of them.
    if (!ai_limit_chain_checked_)
    {
        for (const ai_limit_slot& slot : ai_limit_slots_)
        {
            if (!WorldModule::try_get_bot_owner_from_player(slot.player))
                continue;
            ai_limit_chain_checked_ = true;
            ai_limit_chain_broken_ = !ai_limit_chain_resolves(WorldModule::try_get_bot_owner_from_player(slot.player));
            if (ai_limit_chain_broken_)
                logger::warn("AI limit: pausing for this raid -- no bots will be parked this session");
            break;
        }
    }
    if (ai_limit_chain_broken_)
        return;

    for (const ai_limit_slot& slot : ai_limit_slots_)
    {
        Il2CppObject* bot_owner = WorldModule::try_get_bot_owner_from_player(slot.player);
        if (!bot_owner)
            continue;

        // Dead bots are left completely alone. A corpse costs no AI to ignore,
        // so there is nothing for the limit to save, and ailimit's habit of
        // reactivating corpses exists only to undo its own SetActive(false).
        if (ai_limit_owner_is_dead(bot_owner))
            continue;

        if (slot.keep_awake)
            ai_limit_set_bot_standby(bot_owner, slot.player, false);
        else if (slot.eligible)
            ai_limit_set_bot_standby(bot_owner, slot.player, true);
    }

    // One line per raid, once there is something to report.
    //
    // This exists because the first launch of this feature produced NO log
    // output at all with auto-map and deactivate both off, and every failure
    // path had exactly that. So the log could not distinguish "worked" from
    // "did nothing" -- and it was in fact working. A feature whose only
    // logging is on failure cannot be verified from the log, which is the
    // same defect class as a checker that cannot fail.
    if (!ai_limit_reported_ && !ai_limit_slots_.empty())
    {
        ai_limit_reported_ = true;
        logger::info("AI limit: " + ai_limit_location_
            + " -- " + std::to_string(ai_limit_awake_) + " of "
            + std::to_string(ai_limit_total_) + " bot(s) keep AI within "
            + std::to_string(ai_limit_distance->get_value()) + " m (limit "
            + std::to_string(ai_limit_active->get_value()) + ", every "
            + std::to_string(interval) + " frames, grace "
            + std::to_string(static_cast<int>(ai_limit_grace->get_value())) + " s"
            + (ai_limit_deactivate->get_value() ? ", parked bots deactivated)" : ")"));
    }
}

void AiLimitModule::ai_limit_draw_info() {
    ImGui::Dummy(ImVec2(0, 4.f));

    if (!ai_limit_was_enabled_)
    {
        ImGui::TextWrapped("%s", i18n::tr("ai_limit_off_inf").c_str());
        return;
    }

    const std::string map = ai_limit_location_.empty() ? i18n::tr("ai_limit_unknown_map_inf") : ai_limit_location_;
    if (ai_limit_total_ == 0)
    {
        ImGui::Text("%s %s", i18n::tr("ai_limit_map_inf").c_str(), map.c_str());
        return;
    }

    ImGui::Text("%s %s -- %d %s / %d %s @ %d m",
        i18n::tr("ai_limit_map_inf").c_str(), map.c_str(),
        ai_limit_awake_, i18n::tr("ai_limit_awake_inf").c_str(),
        ai_limit_total_, i18n::tr("ai_limit_bots_inf").c_str(),
        ai_limit_distance->get_value());
}

void AiLimitModule::apply_invisible_to_bots(Il2CppObjectInstance& game_world, Il2CppObject* local_player,
    InvisibleToBots mode) {
    // Drops the local player out of every bot group's enemy map, so bots never
    // acquire it. Ported from Stupid.Solutions' "make all bots friendly".
    //
    // THE CHAIN. Hostility lives in a BotGroupHostility object, not on BotsGroup
    // itself -- BSG moved it there in 120047888:
    //
    //   GameWorld.AllAlivePlayersList
    //     -> per bot: get_IsYourPlayer (skip the local player)
    //     -> get_AIData -> get_BotOwner -> get_BotsGroup
    //     -> BotsGroup.get_BotGroupHostility()   (field at +0x18)
    //     -> BotGroupHostility.RemoveEnemyAction(IPlayer)
    //     -> then, by mode:
    //          neutral -> BotGroupHostility.AddNeutralAction(IPlayer)
    //          ally    -> write into BotGroupHostility.Allies (field +0x38)
    //
    // 115147510 put the last two on BotsGroup directly and is no longer supported,
    // so there is no fallback: if a link stops resolving the feature is inert and
    // the report says which link.
    //
    // WHY ALLY IS A DICTIONARY WRITE. There is no game API for it -- see
    // add_player_to_allies() above. Briefly: BotGroupHostility has no AddAlly
    // method and no OnAddAlly event, the surviving AddAlly on EFT/Player is an
    // empty `ret 0` stub (EFT/Player.txt:158351), and the method that would do it
    // properly is private and takes a struct.
    unsigned mask = 0;
    bool applied = false;

    TA_ZONE_N("ailimit::invisible_to_bots");

    const auto is_not_a_bot = [](Il2CppObject* b, Il2CppObject* me, bool you) {
        return !b || b == me || you;
    };

    unity::list* alive_list = game_world.get_field<unity::list*>("AllAlivePlayersList");
    if (!alive_list || !alive_list->m_p_list_array || !local_player)
    {
        mask |= inv_world_list;
    }
    else
    {
        Il2CppArray* arr = alive_list->m_p_list_array;
        for (size_t i = 0; i < arr->max_length; ++i)
        {
            Il2CppObject* bot = reinterpret_cast<Il2CppObject**>(&arr->data)[i];

            const MethodInfo* is_you_mi = nullptr;
            const auto is_you = resolve_mi<bool (*)(Il2CppObject*)>(
                bot, "get_IsYourPlayer", 0, &is_you_mi);
            if (!is_you || !is_you_mi)
            {
                mask |= inv_is_your_player;
                continue;
            }
            // The one `continue` allowed to set no bit. It is a SKIP, not a
            // failed link: the slot is empty, or the entry is not a bot we should
            // touch. It is a named predicate rather than an inline condition so
            // the "every continue records why" check can tell the two apart
            // structurally -- an inline `if (is_you(bot)) continue;` is
            // indistinguishable from a silent failure to a reader, which is the
            // whole failure mode this function exists to prevent.
            if (is_not_a_bot(bot, local_player, is_you(bot, is_you_mi))) continue;

            const MethodInfo* get_ai_mi = nullptr;
            const auto get_ai = resolve_mi<Il2CppObject* (*)(Il2CppObject*)>(
                bot, "get_AIData", 0, &get_ai_mi);
            if (!get_ai || !get_ai_mi)
            {
                mask |= inv_ai_data;
                continue;
            }
            Il2CppObject* ai = get_ai(bot, get_ai_mi);
            if (!ai)
            {
                mask |= inv_ai_data;
                continue;
            }

            const MethodInfo* get_owner_mi = nullptr;
            const auto get_owner = resolve_mi<Il2CppObject* (*)(Il2CppObject*)>(
                ai, "get_BotOwner", 0, &get_owner_mi);
            if (!get_owner || !get_owner_mi)
            {
                mask |= inv_bot_owner;
                continue;
            }
            Il2CppObject* owner = get_owner(ai, get_owner_mi);
            if (!owner)
            {
                mask |= inv_bot_owner;
                continue;
            }

            const MethodInfo* get_group_mi = nullptr;
            const auto get_group = resolve_mi<Il2CppObject* (*)(Il2CppObject*)>(
                owner, "get_BotsGroup", 0, &get_group_mi);
            if (!get_group || !get_group_mi)
            {
                mask |= inv_bots_group;
                continue;
            }
            Il2CppObject* group = get_group(owner, get_group_mi);
            if (!group)
            {
                mask |= inv_bots_group;
                continue;
            }

            Il2CppObject* hostility = nullptr;
            const MethodInfo* get_h_mi = nullptr;
            if (const auto get_h = resolve_mi<Il2CppObject* (*)(Il2CppObject*)>(
                    group, "get_BotGroupHostility", 0, &get_h_mi))
                hostility = get_h(group, get_h_mi);
            if (!hostility)
            {
                mask |= inv_hostility;
                continue;
            }

            bool handled = false;
            const MethodInfo* rem_mi = nullptr;
            if (const auto rem = resolve_mi<void (*)(Il2CppObject*, Il2CppObject*)>(
                    hostility, "RemoveEnemyAction", 1, &rem_mi))
            {
                rem(hostility, local_player, rem_mi);
                handled = true;
            }
            else
                mask |= inv_remove_enemy;

            if (mode == InvisibleToBots::ally)
            {
                // No game API for this -- see add_player_to_allies().
                if (add_player_to_allies(hostility, local_player, group, mask))
                    handled = true;
            }
            else
            {
                const MethodInfo* add_neutral_mi = nullptr;
                if (const auto add = resolve_mi<void (*)(Il2CppObject*, Il2CppObject*)>(
                        hostility, "AddNeutralAction", 1, &add_neutral_mi))
                {
                    add(hostility, local_player, add_neutral_mi);
                    handled = true;
                }
                else
                    mask |= inv_add_neutral;
            }

            if (handled)
                applied = true;
            else
            {
                // The hostility object exists but no method for the selected mode
                // resolved. That is a rename we have not seen, not a build
                // difference, and it is the case worth shouting about.
                mask |= inv_no_methods;
            }
        }
    }

    report_invisible_link_state(mask, applied);
}

void AiLimitModule::sync_invis_state() {
    const bool invis_neutral = invisible_to_bots_neutral->get_value();
    const bool invis_ally = invisible_to_bots_ally->get_value();

    if (invis_neutral)
    {
        invisible_to_bots_ally->set_value(!invis_neutral);
        invisible_to_bots_ally->set_disabled(invis_neutral);
    }
    else if (invis_ally)
    {
        invisible_to_bots_neutral->set_value(!invis_ally);
        invisible_to_bots_neutral->set_disabled(invis_ally);
    }
    else {
        invisible_to_bots_neutral->set_disabled(false);
        invisible_to_bots_ally->set_disabled(false);
    }
}
