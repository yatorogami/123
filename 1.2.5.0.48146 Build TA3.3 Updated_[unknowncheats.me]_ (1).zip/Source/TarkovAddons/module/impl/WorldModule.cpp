#include "common.h"
#include "WorldModule.h"

// throw_item_in_world, the one wrapper around GameWorld.ThrowItem this project has.
// Included rather than re-declared: the container pass needs the exact same call the
// item-spawn path already proves works, and a second copy of a 9-argument IL2CPP
// signature is how the two drift.
#include "ItemModule.h"

namespace {

	// Only the non-zero failure counters, so a clean run reads as clean and the line
	// stays short enough for the Loot Teleporter card.
	//
	// Placed up here, apart from the container pass it reports on, because it has two
	// callers on two threads: get_loot_tp_container_report() formats on the render
	// thread and the pass formats for its own log line on the game thread. Both need it
	// before the anonymous namespace holding the pass, and a second anonymous namespace
	// block in one TU is the same namespace, so the pass below still sees it.
	std::string format_container_report(const container_loot_stats& st) {
		std::string s = std::to_string(st.thrown) + " moved / " + std::to_string(st.matched)
			+ " matched / " + std::to_string(st.walked) + " of " + std::to_string(st.found)
			+ " boxes, " + std::to_string(st.elapsed_ms) + " ms";
		const auto add = [&s](const char* label, const int n) {
			if (n > 0) s += ", " + std::to_string(n) + " " + label;
			};
		add("detach-refused", st.detach_refused);
		add("detach-faulted", st.detach_faulted);
		add("no-template", st.no_template);
		add("throw-refused", st.throw_refused);
		add("throw-faulted", st.throw_faulted);
		if (st.capped) s += ", CAPPED";
		if (st.timed_out) s += ", BUDGET";
		return s;
	}

} // namespace

WorldModule::WorldModule() : Module("World", BotSpawner, "bot_spawner_mod"),
section_spawn_(conf(new MenuSectionValue("spawn_bots_sec"))),
spawn_bot_type(conf(new SelectValue(0, {
	// Regular / scav
	"Scav",
	"Sniper Scav",
	"Cursed Scav",
	"Assault Group",
	// PMC / raiders
	"Raider",
	"Rogue",
	"USEC PMC",
	"BEAR PMC",
	// Reshala
	"Reshala",
	"Reshala Guard",
	// Killa / Shturman
	"Killa",
	"Shturman",
	"Shturman Guard",
	// Glukhar + guards
	"Glukhar",
	"Glukhar Assault",
	"Glukhar Security",
	"Glukhar Scout",
	"Glukhar Sniper",
	// Sanitar
	"Sanitar",
	"Sanitar Guard",
	// Tagilla
	"Tagilla",
	"Tagilla Guard",
	// Goons
	"Knight",
	"Big Pipe",
	"BirdEye",
	// Kaban
	"Kaban",
	"Kaban Guard",
	"Kaban Sniper",
	"Kaban Gus",
	"Kaban Basmach",
	// Kolontay
	"Kollontay",
	"Kollontay Assault",
	"Kollontay Security",
	// Zryachiy
	"Zryachiy",
	"Zryachiy Guard",
	"Peaceful Zryachiy",
	"Revenge Zryachiy",
	// Partisan
	"Partisan",
	// Cultists
	"Cultist Priest",
	"Cultist Warrior",
	"Cultist Priest Event",
	"Predvestnik",
	"Prizrak",
	"Oni",
	// Events / misc
	"Santa",
	"Spirit Winter",
	"Spirit Spring",
	"Peacemaker",
	"Skier",
	"Arena Fighter",
	"Arena Cleanup",
	"Crazy Assault",
	"BTR Gunner",
	// Infected
	"Infected Assault",
	"Infected PMC",
	"Infected Civil",
	"Infected Laborant",
	"Infected Tagilla",
	// Labyrinth
	"Shadow of Tagilla",
	"Shadow of Killa",
	"Labyrinth Guard",
	// Black Division
	"Black Division",
	"Reshala BlackDiv",
	"Reshala Guard BlackDiv",
	"Raider BlackDiv",
	// VSRF / defectors
	"vsRF",
	"vsRF Sniper",
	"vsRF Fight",
	// Other
	"Sentry",
	"Civilian",
	"Boss Wedge",
	"Boss Wedge Lab",
	"Wedge Lab Guard",
	},
	"spawn_bot_type_sel", /*translate_options=*/false))),
	spawn_bot_count(conf(new IntSliderEditableValue(1, 1, 8, "spawn_bot_count_itm"))), spawn_bot_difficulty(conf(new SelectValue(1, { "Easy", "Normal", "Hard", "Impossible" }, "spawn_bot_diff_sel", /*translate_options=*/false))), spawn_bot(conf(new ActionRowValue([&] {
	spawn_bot_impl();
		},
		"spawn_bot_btn"))),
	show_game_delayed(conf(new CheckboxValue(false, "show_game_delayed_cb"))), spawn_queue_info_(conf(new InfoDrawValue([this] {
	draw_spawn_queue_info();
		},
		"spawn_queue_info"))),
	section_loot_tp_(conf(new MenuSectionValue("loot_tp_sec"))), loot_circle_radius(conf(new FloatSliderEditableValue(2.5f, 1.f, 10.f, "loot_circle_radius_itm"))), loot_height_offset(conf(new FloatSliderEditableValue(0.5f, -2.f, 5.f, "loot_height_offset_itm"))), loot_to_me(conf(new ActionRowValue([&] {
	loot_to_me_impl();
		},
		"loot_to_me_btn"))),
	loot_tp_from_containers(conf(new CheckboxValue(false, "ltp_from_containers_cb"))),
	loot_tp_container_cap(conf(new IntSliderEditableValue(150, 10, 1000, "ltp_container_cap_itm"))),
	section_bot_tp_(conf(new MenuSectionValue("bot_tp_sec"))), kill_all(conf(new ActionRowValue([&] {
	kill_all_impl();
		},
		"kill_all_btn"))),
	tp_all(conf(new ActionRowValue([&] {
	tp_all_impl();
		},
		"tp_all_btn"))),
	tp_one_mode(conf(new SelectValue(1, {
											"tp_one_closest_sel",
											"tp_one_crosshair_sel",
		},
		"tp_one_mode_sel"))),
		tp_one(conf(new ActionRowValue([&] {
	tp_one_impl();
			},
			"tp_one_btn"))),
	tp_scav(conf(new CheckboxValue(false, "tp_scav_cb"))), tp_boss(conf(new CheckboxValue(false, "tp_boss_cb"))), tp_guard(conf(new CheckboxValue(false, "tp_guard_cb"))), tp_cultist(conf(new CheckboxValue(false, "tp_cultist_cb"))), tp_raider(conf(new CheckboxValue(false, "tp_raider_cb"))), tp_defector(conf(new CheckboxValue(false, "tp_defector_cb"))), tp_black_division(conf(new CheckboxValue(false, "tp_black_division_cb"))),
	tp_pmc(conf(new CheckboxValue(false, "tp_pmc_cb"))) {
	show_game_delayed->set_hidden_in_owner_menu(true);
	spawn_bot_difficulty->set_hidden_in_owner_menu(true);

}

void WorldModule::application_update() {}

void WorldModule::spawn_bot_impl() {
	if (!game_state::is_in_raid) return;
	queue_spawn_bot = true;
}

void WorldModule::loot_to_me_impl(const int filter) {
	if (!game_state::is_in_raid) return;
	queued_loot_filter_ = filter;
	queue_loot_to_me = true;
}

void WorldModule::set_loot_teleport_filter_matcher(
	std::function<bool(int, const std::string&, const std::string&, bool, Il2CppObject*)> matcher) {
	loot_teleport_filter_matcher_ = std::move(matcher);
}

[[nodiscard]] int WorldModule::get_loot_teleport_preview_count(const int filter) const {
	return filter >= 0 && filter < static_cast<int>(loot_teleport_preview_counts_.size())
		? loot_teleport_preview_counts_[filter]
		: 0;
}

[[nodiscard]] std::string WorldModule::get_loot_tp_container_report() const {
	// Formatted HERE, on the render thread, rather than cached as a string by the pass
	// on the game thread -- see container_loot_stats in WorldModule.h for why a string
	// crossing that boundary is a freed-pointer read rather than a stale number.
	if (!loot_tp_container_has_run_) return "Not run yet";
	return format_container_report(loot_tp_container_stats_);
}

void WorldModule::refresh_loot_teleport_preview(Il2CppObjectInstance game_world_instance,
	Il2CppObjectInstance main_player) {
	// Zoned 2026-10-12. Called from gameworld_update on every world update, and
	// called BEFORE the gate on the next line -- so the gate is inside the zone,
	// which is the point. A zone placed after the early return would read cheap
	// forever and prove nothing.
	//
	// The comment below says this used to cost a full-map pass plus an uncached
	// string allocation per item, and was throttled for that reason. Whether the
	// throttle is actually holding is a measurement, not an assertion, and this is
	// the zone that makes it one.
	TA_ZONE_N("world::loot_teleport_preview");
	// This only feeds a UI counter ("All loot: N / Quest item loot: N / ...")
	// that's invisible whenever the addon's own menu is closed — but it used to
	// run unconditionally every 500ms regardless: a full loot-list scan (the same
	// full-map pass EspModule's loot ESP does) plus a full QuestItemsList scan,
	// several IL2CPP calls and an uncached string allocation per item. Skipping it
	// while nobody can see the result removes that cost for the vast majority of
	// actual raid time (menu closed), independent of any ESP toggle.
	if (!menu::is_active()) return;

	const ULONGLONG now = GetTickCount64();
	if (now - loot_teleport_preview_refresh_ms_ < 500)
		return;
	loot_teleport_preview_refresh_ms_ = now;
	loot_teleport_preview_counts_.fill(0);

	Il2CppObject* loot_hydra_obj = game_world_instance.get_field<Il2CppObject*>("LootItems");
	if (!loot_hydra_obj) return;
	Il2CppObjectInstance loot_hydra(loot_hydra_obj);
	unity::list* loot_list = loot_hydra.get_field<unity::list*>("_iteration");
	if (!loot_list || !loot_list->m_p_list_array) return;

	const auto count_match = [&](Il2CppObject* loot_obj, const bool force_quest = false) {
		if (!loot_obj) return;
		++loot_teleport_preview_counts_[0];
		if (!loot_teleport_filter_matcher_) return;

		Il2CppObjectInstance loot_instance(loot_obj);
		Il2CppObject* item_obj = loot_instance.get_field<Il2CppObject*>("_item");
		const std::string template_id = item_obj
			? eft_api::try_get_item_template_id(item_obj)
			: std::string{};
		const bool is_quest = force_quest || (item_obj && eft_api::try_get_item_is_quest(item_obj) && (template_id.empty() || eft_api::is_active_quest_item_id(template_id)));
		// Filters 1..5. The combined category-or-wishlist option 2 is still a valid
		// filter number and is still counted, so any caller that has not been moved to
		// the split halves keeps working; 4 and 5 are the halves, counted separately.
		for (int filter = 1; filter <= 5; ++filter)
		{
			if (loot_teleport_filter_matcher_(
				filter, template_id, {}, is_quest, main_player.get_instance()))
			{
				++loot_teleport_preview_counts_[filter];
			}
		}
		};

	Il2CppArray* loot_array = loot_list->m_p_list_array;
	for (int i = 0; i < static_cast<int>(loot_array->max_length); ++i)
		count_match(reinterpret_cast<Il2CppObject**>(&loot_array->data)[i]);

	// QuestItemsList is not part of the normal loose-loot action, but the
	// quest-only action also moves it, so include it in that action's preview.
	auto* quest_set = game_world_instance
		.get_field<unity::hashset<Il2CppObject*>*>("QuestItemsList");
	if (!quest_set || !quest_set->m_p_slots) return;
	auto* slots = quest_set->get_slots();
	for (int i = 0; i < quest_set->m_i_last_index; ++i)
	{
		if (slots[i].m_i_hash_code < 0) continue;
		Il2CppObject* loot_obj = slots[i].m_t_value;
		if (!loot_obj || !loot_teleport_filter_matcher_) continue;
		Il2CppObjectInstance loot_instance(loot_obj);
		Il2CppObject* item_obj = loot_instance.get_field<Il2CppObject*>("_item");
		const std::string template_id = item_obj
			? eft_api::try_get_item_template_id(item_obj)
			: std::string{};
		if (loot_teleport_filter_matcher_(
			1, template_id, {}, true, main_player.get_instance()))
		{
			++loot_teleport_preview_counts_[1];
		}
	}
}

void WorldModule::kill_all_impl() {
	if (!game_state::is_in_raid) return;
	queue_kill_all = true;
}

void WorldModule::tp_all_impl() {
	if (!game_state::is_in_raid) return;
	queue_tp_all = true;
}

void WorldModule::tp_one_impl() {
	if (!game_state::is_in_raid) return;
	queue_tp_one = true;
}

void WorldModule::draw_overlay(ImDrawList* draw_list) {
	(void)draw_list;
}

bool WorldModule::is_local_player(Il2CppObjectInstance& player_instance) {
	const auto is_your_player = player_instance.get_method<bool (*)(Il2CppObject*)>("get_IsYourPlayer", 0);
	if (is_your_player)
		return is_your_player(player_instance.get_instance());
	return false;
}

bool WorldModule::try_teleport_pos_in_front(Il2CppObjectInstance& main_player, unity::vector3& out,
	unity::vector3* out_right, const float distance) {
	Il2CppObject* mp_go = unity::component_get_game_object(main_player.get_instance());
	Il2CppObject* mp_tr = mp_go ? unity::gameobject_get_transform(mp_go) : nullptr;
	if (!mp_tr) return false;

	const unity::vector3 pos = unity::transform_get_pos(mp_tr);
	Il2CppObjectInstance tr_inst(mp_tr);
	const auto get_forward = tr_inst.get_method<unity::vector3(*)(Il2CppObject*)>("get_forward", 0);
	if (!get_forward) return false;

	const unity::vector3 forward = get_forward(mp_tr);
	float fx = forward.x;
	float fz = forward.z;
	float flat_len = sqrtf(fx * fx + fz * fz);
	if (flat_len < 1e-4f)
	{
		// Looking straight up/down — fall back to transform right → forward on XZ.
		const auto get_right = tr_inst.get_method<unity::vector3(*)(Il2CppObject*)>("get_right", 0);
		if (get_right)
		{
			const unity::vector3 right = get_right(mp_tr);
			fx = -right.z;
			fz = right.x;
			flat_len = sqrtf(fx * fx + fz * fz);
		}
		if (flat_len < 1e-4f)
		{
			fx = 0.f;
			fz = 1.f;
			flat_len = 1.f;
		}
	}
	fx /= flat_len;
	fz /= flat_len;

	// Keep feet at player height (+tiny lift to avoid floor clip), never apply pitch to Y.
	constexpr float y_lift = 0.05f;
	out = {
		pos.x + fx * distance,
		pos.y + y_lift,
		pos.z + fz * distance };
	if (out_right)
		*out_right = { fz, 0.f, -fx };
	return true;
}

void WorldModule::try_teleport_bot_path(Il2CppObject* player_object, const unity::vector3& dest) {
	if (!player_object) return;

	// Cache get_AIData MethodInfo after first resolution.
	static const MethodInfo* get_ai_data_method = nullptr;
	if (!get_ai_data_method)
		get_ai_data_method = il2utils::resolve_method(player_object->klass, "get_AIData", 0);
	if (!get_ai_data_method || !get_ai_data_method->methodPointer) return;

	Il2CppObject* ai_data = reinterpret_cast<Il2CppObject * (*)(Il2CppObject*)>(
		get_ai_data_method->methodPointer)(player_object);
	if (!ai_data) return;

	// Cache get_BotOwner MethodInfo after first resolution.
	static const MethodInfo* get_bot_owner_method = nullptr;
	if (!get_bot_owner_method)
		get_bot_owner_method = il2utils::resolve_method(ai_data->klass, "get_BotOwner", 0);
	if (!get_bot_owner_method || !get_bot_owner_method->methodPointer) return;

	Il2CppObject* bot_owner = reinterpret_cast<Il2CppObject * (*)(Il2CppObject*)>(
		get_bot_owner_method->methodPointer)(ai_data);
	if (!bot_owner) return;

	// Cancel active goal so boss brain does not path-snap back immediately.
	static const MethodInfo* get_memory_method = nullptr;
	if (!get_memory_method)
		get_memory_method = il2utils::resolve_method(bot_owner->klass, "get_Memory", 0);

	if (get_memory_method && get_memory_method->methodPointer)
	{
		if (Il2CppObject* memory = reinterpret_cast<Il2CppObject * (*)(Il2CppObject*)>(
			get_memory_method->methodPointer)(bot_owner))
		{
			static const MethodInfo* lose_goal_method = nullptr;
			if (!lose_goal_method)
				lose_goal_method = il2utils::resolve_method(memory->klass, "LoseGoal", 0);
			if (lose_goal_method && lose_goal_method->methodPointer)
				reinterpret_cast<void (*)(Il2CppObject*)>(lose_goal_method->methodPointer)(memory);
			else
			{
				static const MethodInfo* delete_goal_method = nullptr;
				if (!delete_goal_method)
					delete_goal_method = il2utils::resolve_method(memory->klass, "DeleteGoal", 0);
				if (delete_goal_method && delete_goal_method->methodPointer)
					reinterpret_cast<void (*)(Il2CppObject*)>(delete_goal_method->methodPointer)(memory);
			}
		}
	}

	static const MethodInfo* get_mover_method = nullptr;
	if (!get_mover_method)
		get_mover_method = il2utils::resolve_method(bot_owner->klass, "get_Mover", 0);
	if (!get_mover_method || !get_mover_method->methodPointer) return;

	Il2CppObject* mover = reinterpret_cast<Il2CppObject * (*)(Il2CppObject*)>(
		get_mover_method->methodPointer)(bot_owner);
	if (!mover) return;

	static const MethodInfo* stop_method = nullptr;
	if (!stop_method)
		stop_method = il2utils::resolve_method(mover->klass, "Stop", 0);
	if (stop_method && stop_method->methodPointer)
		reinterpret_cast<void (*)(Il2CppObject*)>(stop_method->methodPointer)(mover);

	static const MethodInfo* stop_move_method = nullptr;
	if (!stop_move_method)
		stop_move_method = il2utils::resolve_method(mover->klass, "StopMove", 0);
	if (stop_move_method && stop_move_method->methodPointer)
		reinterpret_cast<void (*)(Il2CppObject*)>(stop_move_method->methodPointer)(mover);

	// Longer pause for bosses — brain re-issues GoToPoint quickly otherwise.
	constexpr float pause_sec = 2.5f;
	static const MethodInfo* movement_pause_2_method = nullptr;
	if (!movement_pause_2_method)
		movement_pause_2_method = il2utils::resolve_method(mover->klass, "MovementPause", 2);
	if (movement_pause_2_method && movement_pause_2_method->methodPointer)
		reinterpret_cast<void (*)(Il2CppObject*, float, bool)>(movement_pause_2_method->methodPointer)(mover, pause_sec, true);
	else
	{
		static const MethodInfo* movement_pause_1_method = nullptr;
		if (!movement_pause_1_method)
			movement_pause_1_method = il2utils::resolve_method(mover->klass, "MovementPause", 1);
		if (movement_pause_1_method && movement_pause_1_method->methodPointer)
			reinterpret_cast<void (*)(Il2CppObject*, float)>(movement_pause_1_method->methodPointer)(mover, pause_sec);
	}

	static const MethodInfo* teleport_2_method = nullptr;
	if (!teleport_2_method)
		teleport_2_method = il2utils::resolve_method(mover->klass, "Teleport", 2);
	if (teleport_2_method && teleport_2_method->methodPointer)
		reinterpret_cast<void (*)(Il2CppObject*, unity::vector3, bool)>(teleport_2_method->methodPointer)(mover, dest, true);
	else
	{
		static const MethodInfo* teleport_1_method = nullptr;
		if (!teleport_1_method)
			teleport_1_method = il2utils::resolve_method(mover->klass, "Teleport", 1);
		if (teleport_1_method && teleport_1_method->methodPointer)
			reinterpret_cast<void (*)(Il2CppObject*, unity::vector3)>(teleport_1_method->methodPointer)(mover, dest);
	}
}

void WorldModule::try_set_movement_transform_pos(Il2CppObject* player_object, const unity::vector3& dest) {
	if (!player_object) return;

	// Cache get_MovementContext MethodInfo after first resolution.
	static const MethodInfo* get_mc_method = nullptr;
	if (!get_mc_method)
		get_mc_method = il2utils::resolve_method(player_object->klass, "get_MovementContext", 0);
	if (!get_mc_method || !get_mc_method->methodPointer) return;

	Il2CppObject* movement_ctx = reinterpret_cast<Il2CppObject * (*)(Il2CppObject*)>(
		get_mc_method->methodPointer)(player_object);
	if (!movement_ctx) return;

	// Cache set_TransformPosition MethodInfo after first resolution.
	static const MethodInfo* set_pos_method = nullptr;
	if (!set_pos_method)
		set_pos_method = il2utils::resolve_method(movement_ctx->klass, "set_TransformPosition", 1);
	if (set_pos_method && set_pos_method->methodPointer)
		reinterpret_cast<void (*)(Il2CppObject*, unity::vector3)>(set_pos_method->methodPointer)(movement_ctx, dest);
}

void WorldModule::teleport_player_to(Il2CppObject* player_object, const unity::vector3& dest) {
	if (!player_object) return;

	// Clear AI path first so the mover cannot pull the body back to the old waypoint.
	try_teleport_bot_path(player_object, dest);

	// Cache Player.Teleport MethodInfo after first resolution.
	static const MethodInfo* teleport_method = nullptr;
	if (!teleport_method)
		teleport_method = il2utils::resolve_method(player_object->klass, "Teleport", 2);
	if (teleport_method && teleport_method->methodPointer)
		reinterpret_cast<void (*)(Il2CppObject*, unity::vector3, bool)>(teleport_method->methodPointer)(player_object, dest, true);

	// Keep MovementContext / bifacial transform in sync with the new feet position.
	try_set_movement_transform_pos(player_object, dest);

	// Re-apply BotMover.Teleport after Player.Teleport so path state matches final pose.
	try_teleport_bot_path(player_object, dest);
}

void WorldModule::kill_all_players(Il2CppObjectInstance& game_world_instance) {
	unity::list* alive_list = game_world_instance.get_field<unity::list*>("AllAlivePlayersList");
	if (!alive_list || !alive_list->m_p_list_array) return;

	Il2CppArray* alive_players = alive_list->m_p_list_array;
	constexpr int damage_type_landmine = 2048;
	int killed = 0;

	for (size_t i = 0; i < alive_players->max_length; ++i)
	{
		Il2CppObject* player_object = reinterpret_cast<Il2CppObject**>(&alive_players->data)[i];
		if (!player_object) continue;

		Il2CppObjectInstance player_instance(player_object);
		if (is_local_player(player_instance)) continue;

		// Cache get_ActiveHealthController MethodInfo after first resolution.
		static const MethodInfo* get_health_controller_method = nullptr;
		if (!get_health_controller_method)
			get_health_controller_method = il2utils::resolve_method(player_object->klass, "get_ActiveHealthController", 0);

		Il2CppObject* health_controller_obj = nullptr;
		if (get_health_controller_method && get_health_controller_method->methodPointer)
			health_controller_obj = reinterpret_cast<Il2CppObject * (*)(Il2CppObject*)>(
				get_health_controller_method->methodPointer)(player_object);
		if (!health_controller_obj) continue;

		// Cache Kill MethodInfo after first resolution.
		static const MethodInfo* kill_method = nullptr;
		if (!kill_method)
			kill_method = il2utils::resolve_method(health_controller_obj->klass, "Kill", 1);
		if (kill_method && kill_method->methodPointer)
			reinterpret_cast<void (*)(Il2CppObject*, int)>(kill_method->methodPointer)(health_controller_obj, damage_type_landmine);
		killed++;
	}

	logger::info("Kill All: killed " + std::to_string(killed) + " players");
}

Il2CppObject* WorldModule::try_get_bot_memory(Il2CppObject* bot_owner) {
	if (!bot_owner || !bot_owner->klass) return nullptr;

	// Cache the Memory field offset after first resolution.
	static FieldInfo* memory_field = nullptr;
	static bool memory_field_resolved = false;
	if (!memory_field_resolved)
	{
		memory_field = il2utils::resolve_field(bot_owner->klass, "Memory");
		memory_field_resolved = true;
	}
	if (memory_field && memory_field->offset > 0)
	{
		Il2CppObject* mem = *reinterpret_cast<Il2CppObject**>(
			reinterpret_cast<uintptr_t>(bot_owner) + memory_field->offset);
		if (eft_api::is_il2cpp_object_likely_valid(mem))
			return mem;
	}

	// Cache get_Memory MethodInfo after first resolution.
	static const MethodInfo* get_memory_method = nullptr;
	if (!get_memory_method)
		get_memory_method = il2utils::resolve_method(bot_owner->klass, "get_Memory", 0);

	if (get_memory_method && get_memory_method->methodPointer)
	{
		Il2CppObject* mem = reinterpret_cast<Il2CppObject * (*)(Il2CppObject*)>(
			get_memory_method->methodPointer)(bot_owner);
		if (eft_api::is_il2cpp_object_likely_valid(mem))
			return mem;
	}
	return nullptr;
}

void WorldModule::bot_clear_goals(Il2CppObject* bot_owner) {
	Il2CppObject* memory = try_get_bot_memory(bot_owner);
	if (!memory || !memory->klass) return;

	// GoalTarget is a public field (BotGoalTarget), not a property.
	static FieldInfo* goal_target_field = nullptr;
	static bool goal_target_field_resolved = false;
	if (!goal_target_field_resolved)
	{
		goal_target_field = il2utils::resolve_field(memory->klass, "GoalTarget");
		goal_target_field_resolved = true;
	}
	Il2CppObject* goal_target = nullptr;
	if (goal_target_field && goal_target_field->offset > 0)
		goal_target = *reinterpret_cast<Il2CppObject**>(
			reinterpret_cast<uintptr_t>(memory) + goal_target_field->offset);
	if (!goal_target)
	{
		static const MethodInfo* get_goal_target_method = nullptr;
		if (!get_goal_target_method)
			get_goal_target_method = il2utils::resolve_method(memory->klass, "get_GoalTarget", 0);
		if (get_goal_target_method && get_goal_target_method->methodPointer)
			goal_target = reinterpret_cast<Il2CppObject * (*)(Il2CppObject*)>(
				get_goal_target_method->methodPointer)(memory);
	}
	if (eft_api::is_il2cpp_object_likely_valid(goal_target) && goal_target->klass)
	{
		static const MethodInfo* clear_method = nullptr;
		if (!clear_method)
			clear_method = il2utils::resolve_method(goal_target->klass, "Clear", 0);
		if (clear_method && clear_method->methodPointer)
			reinterpret_cast<void (*)(Il2CppObject*)>(clear_method->methodPointer)(goal_target);
	}

	// GoalEnemy = null via setter (preferred) or backing field.
	static const MethodInfo* set_goal_enemy_method = nullptr;
	if (!set_goal_enemy_method)
		set_goal_enemy_method = il2utils::resolve_method(memory->klass, "set_GoalEnemy", 1);
	if (set_goal_enemy_method && set_goal_enemy_method->methodPointer)
		reinterpret_cast<void (*)(Il2CppObject*, Il2CppObject*)>(set_goal_enemy_method->methodPointer)(memory, nullptr);
	else
	{
		static FieldInfo* goal_enemy_field = nullptr;
		static bool goal_enemy_field_resolved = false;
		if (!goal_enemy_field_resolved)
		{
			goal_enemy_field = il2utils::resolve_field(memory->klass, "_goalEnemy");
			if (!goal_enemy_field)
				goal_enemy_field = il2utils::resolve_field(memory->klass, "GoalEnemy");
			goal_enemy_field_resolved = true;
		}
		if (goal_enemy_field && goal_enemy_field->offset > 0)
			*reinterpret_cast<Il2CppObject**>(
				reinterpret_cast<uintptr_t>(memory) + goal_enemy_field->offset) = nullptr;
	}
}

bool WorldModule::bot_make_ally(Il2CppObject* bot_owner, Il2CppObject* local_player) {
	if (!bot_owner || !local_player || !bot_owner->klass) return false;

	// Cache get_BotsGroup MethodInfo after first resolution.
	static const MethodInfo* get_group_method = nullptr;
	if (!get_group_method)
		get_group_method = il2utils::resolve_method(bot_owner->klass, "get_BotsGroup", 0);
	if (!get_group_method || !get_group_method->methodPointer) return false;

	Il2CppObject* group = reinterpret_cast<Il2CppObject * (*)(Il2CppObject*)>(
		get_group_method->methodPointer)(bot_owner);
	if (!eft_api::is_il2cpp_object_likely_valid(group) || !group->klass) return false;

	// Skip if already ally (IsAlly(IPlayer)).
	static const MethodInfo* is_ally_method = nullptr;
	if (!is_ally_method)
		is_ally_method = il2utils::resolve_method(group->klass, "IsAlly", 1);
	if (is_ally_method && is_ally_method->methodPointer)
	{
		if (reinterpret_cast<bool (*)(Il2CppObject*, Il2CppObject*)>(is_ally_method->methodPointer)(group, local_player))
		{
			bot_clear_goals(bot_owner);
			return true;
		}
	}

	// RemoveEnemy(IPlayer, EBotEnemyCause=1) — try 1-arg then 2-arg.
	static const MethodInfo* remove_enemy_1_method = nullptr;
	if (!remove_enemy_1_method)
		remove_enemy_1_method = il2utils::resolve_method(group->klass, "RemoveEnemy", 1);
	if (remove_enemy_1_method && remove_enemy_1_method->methodPointer)
		reinterpret_cast<void (*)(Il2CppObject*, Il2CppObject*)>(remove_enemy_1_method->methodPointer)(group, local_player);
	else
	{
		static const MethodInfo* remove_enemy_2_method = nullptr;
		if (!remove_enemy_2_method)
			remove_enemy_2_method = il2utils::resolve_method(group->klass, "RemoveEnemy", 2);
		if (remove_enemy_2_method && remove_enemy_2_method->methodPointer)
			reinterpret_cast<void (*)(Il2CppObject*, Il2CppObject*, int)>(remove_enemy_2_method->methodPointer)(group, local_player, 1);
	}

	// AddAlly(Player)
	static const MethodInfo* add_ally_method = nullptr;
	if (!add_ally_method)
		add_ally_method = il2utils::resolve_method(group->klass, "AddAlly", 1);
	if (add_ally_method && add_ally_method->methodPointer)
		reinterpret_cast<void (*)(Il2CppObject*, Il2CppObject*)>(add_ally_method->methodPointer)(group, local_player);
	else
		return false;

	bot_clear_goals(bot_owner);
	return true;
}

Il2CppObject* WorldModule::try_get_bot_owner_from_player(Il2CppObject* player_object) {
	if (!player_object) return nullptr;

	// Cache get_AIData MethodInfo after first resolution.
	static const MethodInfo* get_ai_data_method = nullptr;
	if (!get_ai_data_method)
		get_ai_data_method = il2utils::resolve_method(player_object->klass, "get_AIData", 0);

	Il2CppObject* ai_data = nullptr;
	if (get_ai_data_method && get_ai_data_method->methodPointer)
		ai_data = reinterpret_cast<Il2CppObject * (*)(Il2CppObject*)>(get_ai_data_method->methodPointer)(player_object);
	if (!eft_api::is_il2cpp_object_likely_valid(ai_data)) return nullptr;

	// Cache get_BotOwner MethodInfo after first resolution.
	static const MethodInfo* get_bot_owner_method = nullptr;
	if (!get_bot_owner_method)
		get_bot_owner_method = il2utils::resolve_method(ai_data->klass, "get_BotOwner", 0);

	Il2CppObject* bot_owner = nullptr;
	if (get_bot_owner_method && get_bot_owner_method->methodPointer)
		bot_owner = reinterpret_cast<Il2CppObject * (*)(Il2CppObject*)>(get_bot_owner_method->methodPointer)(ai_data);
	return eft_api::is_il2cpp_object_likely_valid(bot_owner) ? bot_owner : nullptr;
}

bool WorldModule::tp_role_allowed(const eft_api::npc_kind kind) const {
	// BTR never teleports (vehicle body / shooter special-case).
	if (kind == eft_api::npc_kind::btr)
		return false;

	const bool any_filter =
		tp_scav->get_value()
		|| tp_boss->get_value()
		|| tp_guard->get_value()
		|| tp_cultist->get_value()
		|| tp_raider->get_value()
		|| tp_defector->get_value()
		|| tp_black_division->get_value()
		|| tp_pmc->get_value();

	// No filters selected → everyone except BTR (and self, checked elsewhere).
	if (!any_filter)
		return true;

	switch (kind)
	{
	case eft_api::npc_kind::scav: return tp_scav->get_value();
	case eft_api::npc_kind::boss: return tp_boss->get_value();
	case eft_api::npc_kind::guard: return tp_guard->get_value();
	case eft_api::npc_kind::cultist: return tp_cultist->get_value();
	case eft_api::npc_kind::raider: return tp_raider->get_value();
	case eft_api::npc_kind::defector: return tp_defector->get_value();
	case eft_api::npc_kind::civilian: return tp_scav->get_value(); // peaceful map to scav filter
	case eft_api::npc_kind::black_division: return tp_black_division->get_value();
	case eft_api::npc_kind::pmc: return tp_pmc->get_value();
	case eft_api::npc_kind::btr: return false;
	default: return false;
	}
}

void WorldModule::tp_all_players(Il2CppObjectInstance& game_world_instance, Il2CppObjectInstance& main_player) {
	unity::list* alive_list = game_world_instance.get_field<unity::list*>("AllAlivePlayersList");
	if (!alive_list || !alive_list->m_p_list_array) return;

	unity::vector3 base_dest;
	unity::vector3 right_h{};
	if (!try_teleport_pos_in_front(main_player, base_dest, &right_h, 6.f)) return;

	Il2CppArray* alive_players = alive_list->m_p_list_array;
	int moved = 0;
	int skipped_btr = 0;
	int skipped_filter = 0;
	constexpr float bot_spacing = 1.1f;

	for (size_t i = 0; i < alive_players->max_length; ++i)
	{
		Il2CppObject* player_object = reinterpret_cast<Il2CppObject**>(&alive_players->data)[i];
		if (!player_object) continue;

		Il2CppObjectInstance player_instance(player_object);
		if (is_local_player(player_instance)) continue;

		const eft_api::npc_kind kind = eft_api::classify_player_kind(player_object);
		if (kind == eft_api::npc_kind::btr)
		{
			skipped_btr++;
			continue;
		}
		if (!tp_role_allowed(kind))
		{
			skipped_filter++;
			continue;
		}

		// Spread bots left/right so they do not stack into one point / geometry.
		const float side = (moved % 2 == 0 ? 1.f : -1.f)
			* static_cast<float>((moved + 1) / 2) * bot_spacing;
		const float row = static_cast<float>(moved / 6) * 0.6f; // extra depth every 6 bots
		const unity::vector3 dest = {
			base_dest.x + right_h.x * side,
			base_dest.y,
			base_dest.z + right_h.z * side + row };

		teleport_player_to(player_object, dest);
		moved++;
	}

	logger::info(
		"TP All: moved " + std::to_string(moved)
		+ " (skip filter=" + std::to_string(skipped_filter)
		+ " btr=" + std::to_string(skipped_btr) + ")");
}

void WorldModule::tp_one_player(Il2CppObjectInstance& game_world_instance, Il2CppObjectInstance& main_player) {
	unity::list* alive_list = game_world_instance.get_field<unity::list*>("AllAlivePlayersList");
	if (!alive_list || !alive_list->m_p_list_array) return;

	unity::vector3 dest;
	if (!try_teleport_pos_in_front(main_player, dest, nullptr, 5.f)) return;

	Il2CppObject* mp_go = unity::component_get_game_object(main_player.get_instance());
	Il2CppObject* mp_tr = mp_go ? unity::gameobject_get_transform(mp_go) : nullptr;
	if (!mp_tr) return;
	const unity::vector3 my_pos = unity::transform_get_pos(mp_tr);

	const int mode = tp_one_mode->get_value(); // 0 world-closest, 1 crosshair
	Il2CppObject* cam = (mode == 1) ? unity::get_current_camera() : nullptr;
	const float screen_cx = menu::get_width() * 0.5f;
	const float screen_cy = menu::get_height() * 0.5f;

	Il2CppArray* alive_players = alive_list->m_p_list_array;
	Il2CppObject* best = nullptr;
	float best_score = 1e30f;

	for (size_t i = 0; i < alive_players->max_length; ++i)
	{
		Il2CppObject* player_object = reinterpret_cast<Il2CppObject**>(&alive_players->data)[i];
		if (!player_object) continue;

		Il2CppObjectInstance player_instance(player_object);
		if (is_local_player(player_instance)) continue;

		const eft_api::npc_kind kind = eft_api::classify_player_kind(player_object);
		if (kind == eft_api::npc_kind::btr) continue;
		if (!tp_role_allowed(kind)) continue;

		Il2CppObject* go = unity::component_get_game_object(player_object);
		Il2CppObject* tr = go ? unity::gameobject_get_transform(go) : nullptr;
		if (!tr) continue;
		const unity::vector3 pos = unity::transform_get_pos(tr);

		float score = 1e30f;
		if (mode == 1 && cam)
		{
			const unity::vector3 screen = eft_api::world_to_screen(cam, pos, game_state::current_zoom);
			if (!eft_api::is_visible(screen)) continue;
			const float dx = screen.x - screen_cx;
			const float dy = screen.y - screen_cy;
			score = dx * dx + dy * dy;
		}
		else
		{
			const float dx = pos.x - my_pos.x;
			const float dy = pos.y - my_pos.y;
			const float dz = pos.z - my_pos.z;
			score = dx * dx + dy * dy + dz * dz;
		}

		if (score < best_score)
		{
			best_score = score;
			best = player_object;
		}
	}

	if (!best)
	{
		logger::warn("TP One: no eligible target");
		return;
	}

	teleport_player_to(best, dest);
	logger::info("TP One: teleported target to front (mode=" + std::to_string(mode) + ")");
}

namespace {

	// Wall-clock budget for ONE container pass. The item cap bounds how many items get
	// moved; this bounds how long SEARCHING for them may take, which a cap cannot do --
	// a filter that matches nothing still walks every container in the scene before it
	// knows that. The 2026-10-15 attempt had neither bound and stalled 19.9 s on a map
	// holding 733 live containers, logging nothing from inside the pass.
	constexpr ULONGLONG kContainerPassBudgetMs = 2000;

	// The same ceiling ChamsModule::discover_containers puts on its cache
	// (ChamsModule.cpp:1005-1008): find_objects_of_type can hand back a pathological
	// count on a scene that has not finished loading.
	constexpr size_t kContainerWalkLimit = 4096;

	// One candidate: the item plus its template id, read ONCE during collection. The
	// sort below then compares strings already in memory instead of re-crossing the
	// IL2CPP boundary twice per comparison -- the anti-pattern the comment on
	// `world::loot_to_me:sort` exists to warn about, and the one the reverted container
	// pass reintroduced verbatim.
	struct container_candidate {
		std::string template_id;
		Il2CppObject* item = nullptr;
	};

	// GameWorld.ThrowItem under an SEH guard. Returns 1 on success, 0 when the game
	// refused, -1 when the call faulted.
	//
	// WHY GUARDED HERE AND NOT AT throw_item_in_world. The 9-argument ThrowItem this
	// reaches (GameWorld.txt:21658) has explicit managed throw sites in its own body --
	// Exception("Prefab is null") at ISIL offset 1126 and
	// Exception("Singleton<ObjectsFactory>.Instance is null") at 1143 -- plus a tail of
	// NullReferenceException throws. ItemModule hands it
	// items the item factory just built; this path hands it items that were sitting in
	// a crate, which is input nobody validated. A managed throw crossing into a native
	// frame arrives as 0xE06D7363 and ends the process, so it is caught here instead.
	//
	// The __try frame holds no destructible object (AGENTS.md, MSVC traps) -- the body
	// one call down is where unity::vector3 and the std::function live.
	inline int throw_item_guarded_body(Il2CppObject* game_world, Il2CppObject* player,
		Il2CppObject* item, const unity::vector3& position) {
		return throw_item_in_world(game_world, player, item, position) ? 1 : 0;
	}

	inline int throw_item_guarded(Il2CppObject* game_world, Il2CppObject* player,
		Il2CppObject* item, const unity::vector3& position) {
		__try {
			return throw_item_guarded_body(game_world, player, item, position);
		} __except (EXCEPTION_EXECUTE_HANDLER) {
			return -1;
		}
	}

	container_loot_stats teleport_container_loot(
		Il2CppObjectInstance game_world_instance, Il2CppObjectInstance main_player,
		const std::function<bool(Il2CppObject*)>& item_matches,
		const std::function<unity::vector3()>& next_ring_pos, const int item_cap) {
		container_loot_stats st;
		if (item_cap <= 0) return st;

		const ULONGLONG t0 = GetTickCount64();
		const auto budget_left = [&] { return GetTickCount64() - t0 <= kContainerPassBudgetMs; };
		const auto finish = [&] {
			st.elapsed_ms = GetTickCount64() - t0;
			return st;
			};

		// One scene-wide FindObjectsOfType per button press. EspModule measured this
		// call at 8.4 ms average / 135 ms peak (EspModule.cpp:7633-7641), which is why
		// it runs on a 2 s discovery clock there and ChamsModule's on a 15 s one. Once
		// per explicit user action it needs no clock at all. The System.Type itself is
		// process-lifetime, so it is memoised the way EspModule.cpp:7600-7606 memoises it.
		static auto* container_assembly = il2utils::resolve_image("Assembly-CSharp.dll");
		static Il2CppObject* container_type = nullptr;
		if (!container_type)
		{
			if (container_assembly)
				container_type = il2utils::get_system_type(container_assembly, "EFT.Interactive",
					"LootableContainer");
			if (!container_type) return finish();
		}

		size_t found = 0;
		Il2CppObject** objects = nullptr;
		{
			TA_ZONE_N("world::loot_to_me:containers_find");
			objects = unity::find_objects_of_type(container_type, &found);
		}
		st.found = static_cast<int>(found);
		if (!objects || found == 0) return finish();

		std::vector<container_candidate> candidates;
		candidates.reserve(static_cast<size_t>((std::min)(item_cap, 1024)));

		const size_t walk_limit = (std::min)(found, kContainerWalkLimit);
		for (size_t i = 0; i < walk_limit; ++i)
		{
			if (static_cast<int>(candidates.size()) >= item_cap) { st.capped = true; break; }
			if (!budget_left()) { st.timed_out = true; break; }

			Il2CppObject* container = objects[i];
			if (!eft_api::is_il2cpp_object_likely_valid(container)) continue;
			// GHOST FILTER, for the reason eft_api.h gives in full above
			// is_container_actually_placed: every map ships far more LootableContainer
			// prefabs than one raid rolls, and the un-rolled ones keep a live component,
			// a position and a renderer with nothing about them distinguishable from a
			// real container except that Init() never ran on them.
			if (!eft_api::is_container_actually_placed(container)) continue;
			++st.walked;

			Il2CppObject* item_owner = eft_api::try_get_container_item_owner(container);
			Il2CppObject* root_item = eft_api::try_get_controller_root_item(item_owner);
			if (!root_item) continue;

			TA_ZONE_N("world::loot_to_me:containers_collect");
			// foreach_container_item, not a new collector. It skips the container's own
			// root CompoundItem and re-validates every entry it yields; the hand-rolled
			// walk the reverted pass used did neither, which contributes the root itself
			// as a candidate -- and throwing a crate's root item is how you get a second
			// crate on the floor where the crate already is.
			eft_api::foreach_container_item(root_item, [&](Il2CppObject* item_obj) {
				++st.seen;
				if (!item_matches(item_obj)) return true;
				if (static_cast<int>(candidates.size()) >= item_cap)
				{
					st.capped = true;
					return false; // stop this container; the outer loop stops next turn
				}
				candidates.push_back({ eft_api::try_get_item_template_id(item_obj), item_obj });
				return true;
				});
		}

		st.matched = static_cast<int>(candidates.size());
		{
			TA_ZONE_N("world::loot_to_me:containers_sort");
			std::sort(candidates.begin(), candidates.end(),
				[](const container_candidate& a, const container_candidate& b) {
					return a.template_id < b.template_id;
					});
		}

		{
			TA_ZONE_N("world::loot_to_me:containers_move");
			for (const container_candidate& c : candidates)
			{
				if (!budget_left()) { st.timed_out = true; break; }

				// PRE-FLIGHT. ThrowItem builds the loot view from the item's prefab,
				// which comes off its template, and throws "Prefab is null" when there
				// is none. Asking first is the fix AiLimitModule.cpp:152 records for the
				// same class of problem: make the throwing call unreachable rather than
				// surviving it.
				if (!eft_api::try_get_item_template(c.item)) { ++st.no_template; continue; }

				// DETACH FIRST, and verify it took. An item still owned by a crate
				// cannot be thrown: ThrowItem roots a brand-new ItemController in
				// whatever it is handed, so the crate would keep the item AND the ground
				// loot would claim it.
				const auto detached = eft_api::detach_item_from_owner(c.item);
				if (detached == eft_api::detach_result::refused) { ++st.detach_refused; continue; }
				if (detached == eft_api::detach_result::faulted)
				{
					// A managed throw out of ItemAddress.Remove means our model of this
					// item is wrong. Stop rather than repeat it a few hundred times.
					++st.detach_faulted;
					logger::warn("Loot Teleporter: ItemAddress.Remove faulted, stopping the "
						"container pass");
					break;
				}
				++st.detached;

				const int thrown = throw_item_guarded(game_world_instance.get_instance(),
					main_player.get_instance(), c.item, next_ring_pos());
				if (thrown > 0) { ++st.thrown; continue; }

				if (thrown < 0)
				{
					++st.throw_faulted;
					logger::warn("Loot Teleporter: GameWorld.ThrowItem faulted on '"
						+ c.template_id + "', stopping the container pass");
					break;
				}

				// Refused AFTER a successful detach: the item is out of its container and
				// not in the world. That is the orphan ItemModule.cpp:413-419 warns
				// about, and it is counted separately from a pre-detach refusal so the
				// log distinguishes "the game kept it where it was" from "we lost it".
				++st.throw_refused;
				logger::warn("Loot Teleporter: container item orphaned -- detached but "
					"GameWorld.ThrowItem refused it, template '" + c.template_id + "'");
			}
		}

		return finish();
	}

} // namespace

void WorldModule::gameworld_update(const Il2CppClass* game_world_class, Il2CppObjectInstance game_world_instance,
	Il2CppObjectInstance main_player) {
	eft_api::refresh_active_quest_item_ids(main_player.get_instance());
	refresh_loot_teleport_preview(game_world_instance, main_player);
	if (queue_loot_to_me)
	{
		// Zoned 2026-10-12. This block was 194 lines with no zone anywhere inside it,
		// which is the state fireport_resolve was in before eleven zones were added:
		// the whole cost lands on `frame::module` and cannot be split.
		//
		// IT IS GATED, and that is the reason to instrument it rather than ignore it.
		// `queue_loot_to_me` is set by an action, so this block is free on most frames
		// and expensive on the frames it runs -- the bimodal shape that made
		// fireport_resolve read as 1.44 us/call for 3.5 minutes and 37,343 us/call for
		// 6, and whose aggregate mean was two populations averaged.
		//
		// The parent zone answers "is this feature expensive at all". The four children
		// answer which part, and the hypothesis one of them exists to test is in the
		// comment on `world::loot_to_me:sort` below.
		//
		// Braces because TA_ZONE_N is a bare local named `ta_zone` -- two in one scope
		// is C2374, and MSBuild reports it against an innocent line.
		{
			TA_ZONE_N("world::loot_to_me");
		}
		queue_loot_to_me = false;
		const int loot_filter = queued_loot_filter_;
		queued_loot_filter_ = 0;

		// player position (ring centre)
		Il2CppObject* mp_go = unity::component_get_game_object(main_player.get_instance());
		Il2CppObject* mp_tr = mp_go ? unity::gameobject_get_transform(mp_go) : nullptr;
		if (!mp_tr) return;
		const unity::vector3 center = unity::transform_get_pos(mp_tr);

		Il2CppObject* loot_hydra_obj = game_world_instance.get_field<Il2CppObject*>("LootItems");
		if (!loot_hydra_obj) return;
		Il2CppObjectInstance loot_hydra(loot_hydra_obj);
		unity::list* loot_list = loot_hydra.get_field<unity::list*>("_iteration");
		if (!loot_list || !loot_list->m_p_list_array) return;

		Il2CppArray* loot_array = loot_list->m_p_list_array;
		const int count = static_cast<int>(loot_array->max_length);

		constexpr float pi = 3.14159265f;
		const float spacing = 0.7f; // gap between items
		float ring_r = loot_circle_radius->get_value();
		int in_ring = 0;
		int per_ring = (std::max)(8, static_cast<int>(2.f * pi * ring_r / spacing));
		int moved = 0;

		// The predicate over a bare Item. Split out of matches_filter below because the
		// container pass already holds Item objects -- a LootItem's `_item` -- and would
		// otherwise carry a second copy of this body that could drift from the first.
		const auto item_matches = [&](Il2CppObject* item_obj, const bool force_quest) {
			if (loot_filter == 0) return true;
			if (!loot_teleport_filter_matcher_) return false;

			const std::string template_id = item_obj
				? eft_api::try_get_item_template_id(item_obj)
				: std::string{};
			const bool is_quest = force_quest || (item_obj && eft_api::try_get_item_is_quest(item_obj) && (template_id.empty() || eft_api::is_active_quest_item_id(template_id)));
			return loot_teleport_filter_matcher_(
				loot_filter, template_id, {}, is_quest, main_player.get_instance());
			};

		const auto matches_filter = [&](Il2CppObject* loot_obj, const bool force_quest = false) {
			// loot_filter == 0 short-circuits here rather than inside item_matches only
			// because that is the one case where reading `_item` would be wasted work;
			// every other guard lives in item_matches alone, so the two cannot drift.
			if (loot_filter == 0) return true;
			Il2CppObjectInstance loot_instance(loot_obj);
			return item_matches(loot_instance.get_field<Il2CppObject*>("_item"), force_quest);
			};

		const auto get_template_id = [&](Il2CppObject* loot_obj) -> std::string {
			Il2CppObjectInstance loot_instance(loot_obj);
			Il2CppObject* item_obj = loot_instance.get_field<Il2CppObject*>("_item");
			return item_obj ? eft_api::try_get_item_template_id(item_obj) : std::string{};
			};

		const auto move_to_ring = [&](Il2CppObject* loot_obj) {
			Il2CppObject* game_object = unity::component_get_game_object(loot_obj);
			if (!game_object) return;
			Il2CppObject* transform = unity::gameobject_get_transform(game_object);
			if (!transform) return;

			if (in_ring >= per_ring)
			{
				ring_r += spacing;
				in_ring = 0;
				per_ring = (std::max)(8, static_cast<int>(2.f * pi * ring_r / spacing));
			}
			const float angle = 2.f * pi * static_cast<float>(in_ring) / static_cast<float>(per_ring);
			unity::transform_set_pos(transform, { center.x + cosf(angle) * ring_r, center.y + loot_height_offset->get_value(), center.z + sinf(angle) * ring_r });
			++in_ring;
			++moved;
			};

		// The same ring walk WITHOUT moving anything, for the container pass: a
		// container item is a bare Item with no LootItem and no transform to reposition,
		// so what it needs is the coordinate to hand to GameWorld.ThrowItem. Sharing
		// ring_r/in_ring/per_ring with move_to_ring is the point -- container items
		// continue the rings the loose loot started instead of landing on top of them.
		const auto next_ring_pos = [&]() -> unity::vector3 {
			if (in_ring >= per_ring)
			{
				ring_r += spacing;
				in_ring = 0;
				per_ring = (std::max)(8, static_cast<int>(2.f * pi * ring_r / spacing));
			}
			const float angle = 2.f * pi * static_cast<float>(in_ring) / static_cast<float>(per_ring);
			++in_ring;
			return { center.x + cosf(angle) * ring_r, center.y + loot_height_offset->get_value(), center.z + sinf(angle) * ring_r };
			};

		// Collect matching items first, then sort by template ID for grouped order
		std::vector<Il2CppObject*> matching_items;
		matching_items.reserve(count);

		for (int i = 0; i < count; ++i)
		{
			// One managed read per entry: matches_filter resolves the item's template
			// id and its quest flag. n calls for n loot entries, once per invocation.
			TA_ZONE_N("world::loot_to_me:scan");
			Il2CppObject* loot_obj = reinterpret_cast<Il2CppObject**>(&loot_array->data)[i];
			if (!loot_obj) continue;
			if (!matches_filter(loot_obj)) continue;
			matching_items.push_back(loot_obj);
		}

		// Sort by template ID (ascending)
		//
		// THE HYPOTHESIS THIS ZONE EXISTS TO TEST. The comparator calls get_template_id
		// twice per comparison, and each call is `get_field("_item")` plus
		// `try_get_item_template_id` -- two IL2CPP boundary crossings. A sort is
		// O(n log n) comparisons, so for a raid with several hundred loot entries this
		// is thousands of managed reads to order a vector, and it re-derives values
		// `matches_filter` already read one loop earlier.
		//
		// That is the same shape as the camera finding recorded in
		// tools/tracy/README.md: 154,544 resolutions for 22,431 picks, where making
		// the lookup faster would have touched nothing and calling it less fixed it.
		// If this zone dominates the block the fix is to carry the id alongside the
		// pointer, NOT to micro-optimise the comparator.
		{
			TA_ZONE_N("world::loot_to_me:sort");
			std::sort(matching_items.begin(), matching_items.end(), [&](Il2CppObject* a, Il2CppObject* b) {
				return get_template_id(a) < get_template_id(b);
				});
		}

		// Process in sorted order
		{
			TA_ZONE_N("world::loot_to_me:place");
			for (Il2CppObject* loot_obj : matching_items)
			{
				move_to_ring(loot_obj);
			}
		}

		// QuestItemsList is independent of LootItems in EFT. Only the quest-only
		// action touches it, avoiding unexpected movement of objective objects.
		if (loot_filter == 1)
		{
			// A SECOND independent walk of a second managed collection, with its own
			// sort whose comparator re-reads template ids the same way. Zoned separately
			// from the LootItems path above because they are different collections with
			// different sizes, and averaging them is how one row becomes the
			// meaningless mean the split exists to prevent.
			TA_ZONE_N("world::loot_to_me:quest");
			auto* quest_set = game_world_instance
				.get_field<unity::hashset<Il2CppObject*>*>("QuestItemsList");
			if (quest_set && quest_set->m_p_slots)
			{
				// Collect matching quest items first, then sort by template ID
				std::vector<Il2CppObject*> matching_quest_items;

				auto* slots = quest_set->get_slots();
				for (int i = 0; i < quest_set->m_i_last_index; ++i)
				{
					if (slots[i].m_i_hash_code < 0) continue;
					Il2CppObject* loot_obj = slots[i].m_t_value;
					if (loot_obj && matches_filter(loot_obj, true))
						matching_quest_items.push_back(loot_obj);
				}

				// Sort by template ID (ascending)
				std::sort(matching_quest_items.begin(), matching_quest_items.end(), [&](Il2CppObject* a, Il2CppObject* b) {
					return get_template_id(a) < get_template_id(b);
					});

				// Process in sorted order
				for (Il2CppObject* loot_obj : matching_quest_items)
				{
					move_to_ring(loot_obj);
				}
			}
		}

		// Containers. Gated on its own checkbox, default OFF, and skipped for the
		// quest-only action, which walks QuestItemsList rather than LootItems and has
		// never touched anything else.
		//
		// Zoned inside teleport_container_loot rather than here, split four ways
		// (find / collect / sort / move), because those four have wildly different
		// costs and one aggregate number over them is the meaningless mean the split
		// exists to prevent.
		if (loot_tp_from_containers->get_value() && loot_filter != 1)
		{
			const container_loot_stats cs = teleport_container_loot(
				game_world_instance, main_player,
				[&](Il2CppObject* item_obj) { return item_matches(item_obj, false); },
				next_ring_pos, loot_tp_container_cap->get_value());

			// ONE summary line per press, carrying every counter, so the first in-game
			// run is a measurement rather than a silence to be reconstructed from a
			// timestamp gap. The reverted pass logged nothing at all from inside itself,
			// which is the entire reason its failure had to be diagnosed from a 19.9 s
			// hole in the log with a crash-probe note after it.
			//
			// Published as counters, not as this string. There is no fence here, so the
			// card can still catch a mixed set for one frame -- the same benign staleness
			// loot_teleport_preview_counts_ already accepts, and the reason the struct is
			// POD rather than a string (WorldModule.h). The flag exists only to tell "never
			// run" apart from "ran and moved nothing"; it is not a publish barrier.
			loot_tp_container_stats_ = cs;
			loot_tp_container_has_run_ = true;
			logger::info("Loot Teleporter containers: " + format_container_report(cs));
			moved += cs.thrown;
		}

		logger::info("Loot Teleporter: moved " + std::to_string(moved) + " items into rings");
	}

	if (queue_kill_all)
	{
		queue_kill_all = false;
		kill_all_players(game_world_instance);
	}

	if (queue_tp_all)
	{
		queue_tp_all = false;
		tp_all_players(game_world_instance, main_player);
	}

	if (queue_tp_one)
	{
		queue_tp_one = false;
		tp_one_player(game_world_instance, main_player);
	}

	if (!game_state::is_in_raid)
	{
		pending_spawns_.clear();
		clear_game_delay_snapshot();
		cached_spawner_ = nullptr;
		empty_poll_streak_ = 0;
	}
	else
	{
		const ULONGLONG now = GetTickCount64();
		prune_pending_spawns(now);

		// Game delay poll only when toggle is on (slower = less flicker from mid-frame lists).
		if (show_game_delayed->get_value() && now - last_queue_poll_ms_ >= 1000)
		{
			last_queue_poll_ms_ = now;
			refresh_game_spawn_queue();
		}
		else if (!show_game_delayed->get_value())
		{
			clear_game_delay_snapshot();
			empty_poll_streak_ = 0;
		}
	}

	if (queue_spawn_bot)
	{
		queue_spawn_bot = false;
		const int type_idx = spawn_bot_type->get_value();
		const int count = spawn_bot_count->get_value();
		const int difficulty = spawn_bot_difficulty->get_value(); // 0..3 = BotDifficulty
		if (try_spawn_bot_by_type(type_idx, count, difficulty))
		{
			pending_spawn_entry e{};
			e.label = role_label(type_idx);
			e.role = spawn_bot_roles_[type_idx];
			e.count = count;
			e.difficulty = difficulty;
			e.request_ms = GetTickCount64();
			pending_spawns_.push_back(e);
			if (pending_spawns_.size() > 24)
				pending_spawns_.erase(pending_spawns_.begin());
		}
		else
			logger::warn("Spawn Bot: failed (need local raid / bots controller ready)");
	}
}

void WorldModule::init() {}

bool WorldModule::is_infected_role(const int wild_spawn_type) {
	return wild_spawn_type == 60 || wild_spawn_type == 61
		|| wild_spawn_type == 62 || wild_spawn_type == 63
		|| wild_spawn_type == 64;
}

Il2CppObject* WorldModule::try_get_local_game() {
	static const Il2CppImage* img = il2utils::resolve_image("Assembly-CSharp.dll");
	if (!img) return nullptr;
	Il2CppObject* type = il2utils::get_system_type(img, "EFT", "LocalGame");
	if (!type) return nullptr;
	Il2CppObject* local = unity::find_object_of_type(type);
	return eft_api::is_il2cpp_object_likely_valid(local) ? local : nullptr;
}

Il2CppObject* WorldModule::try_get_bots_controller(Il2CppObject* local_game) {
	if (!local_game || !local_game->klass) return nullptr;

	// Public get_BotsController on LocalGame / base (IBotGame).
	for (Il2CppClass* k = local_game->klass; k; k = k->parent)
	{
		if (const MethodInfo* mi = il2utils::resolve_method(k, "get_BotsController", 0))
		{
			if (!mi->methodPointer) continue;
			using fn_t = Il2CppObject * (*)(Il2CppObject*, const MethodInfo*);
			Il2CppObject* bc = reinterpret_cast<fn_t>(mi->methodPointer)(local_game, mi);
			if (eft_api::is_il2cpp_object_likely_valid(bc))
				return bc;
		}
	}

	// Fallback: BaseLocalGame has protected field "BotsController".
	static const char* field_names[] = {
		"BotsController",
		"<BotsController>k__BackingField",
		"_botsController",
	};
	for (const char* fn : field_names)
	{
		if (FieldInfo* f = il2utils::resolve_field(local_game->klass, fn))
		{
			if (f->offset <= 0) continue;
			Il2CppObject* bc = *reinterpret_cast<Il2CppObject**>(
				reinterpret_cast<uintptr_t>(local_game) + f->offset);
			if (eft_api::is_il2cpp_object_likely_valid(bc))
				return bc;
		}
	}
	return nullptr;
}

Il2CppObject* WorldModule::try_get_bot_spawner(Il2CppObject* bots_controller) {
	if (!bots_controller || !bots_controller->klass) return nullptr;
	const MethodInfo* mi = il2utils::resolve_method(
		bots_controller->klass, "GetSpawner", 0);
	if (!mi || !mi->methodPointer) return nullptr;
	using fn_t = Il2CppObject * (*)(Il2CppObject*, const MethodInfo*);
	Il2CppObject* spawner = reinterpret_cast<fn_t>(mi->methodPointer)(bots_controller, mi);
	return eft_api::is_il2cpp_object_likely_valid(spawner) ? spawner : nullptr;
}

Il2CppObject* WorldModule::try_create_bot_spawn_params(const int trigger_type) {
	static const Il2CppImage* img = il2utils::resolve_image("Assembly-CSharp.dll");
	if (!img) return nullptr;

	// Dump: public class BotSpawnParams (global namespace)
	const Il2CppClass* klass = il2utils::resolve_class(img, "", "BotSpawnParams");
	if (!klass) return nullptr;

	il2cpp::il2cpp_runtime_class_init(const_cast<Il2CppClass*>(klass));
	Il2CppObject* params = il2cpp::il2cpp_object_new(klass);
	if (!params) return nullptr;

	// .ctor()
	if (const MethodInfo* ctor = il2utils::resolve_method(klass, ".ctor", 0))
	{
		if (ctor->methodPointer)
		{
			using ctor_t = void (*)(Il2CppObject*, const MethodInfo*);
			reinterpret_cast<ctor_t>(ctor->methodPointer)(params, ctor);
		}
	}

	// Id_spawn = ""
	if (FieldInfo* id_field = il2utils::resolve_field(klass, "Id_spawn"))
	{
		if (id_field->offset > 0)
		{
			*reinterpret_cast<Il2CppString**>(
				reinterpret_cast<uintptr_t>(params) + id_field->offset) =
				il2cpp::il2cpp_string_new("");
		}
	}

	// TriggerType: none=0, botEvent=3 (infected)
	if (const MethodInfo* set_tt = il2utils::resolve_method(klass, "set_TriggerType", 1))
	{
		if (set_tt->methodPointer)
		{
			using set_t = void (*)(Il2CppObject*, int, const MethodInfo*);
			reinterpret_cast<set_t>(set_tt->methodPointer)(params, trigger_type, set_tt);
		}
	}
	else if (FieldInfo* tt_field = il2utils::resolve_field(klass, "<TriggerType>k__BackingField"))
	{
		if (tt_field->offset > 0)
		{
			*reinterpret_cast<int*>(
				reinterpret_cast<uintptr_t>(params) + tt_field->offset) = trigger_type;
		}
	}

	return params;
}

bool WorldModule::try_spawn_bot_by_type(const int type_index, int count, int difficulty) {
	constexpr int role_count = static_cast<int>(sizeof(spawn_bot_roles_) / sizeof(spawn_bot_roles_[0]));
	if (type_index < 0 || type_index >= role_count) return false;
	if (count < 1) count = 1;
	if (count > 8) count = 8;
	if (difficulty < 0) difficulty = 0;
	if (difficulty > 3) difficulty = 3;

	const int role = spawn_bot_roles_[type_index];
	const int trigger = is_infected_role(role) ? 3 : 0; // botEvent : none

	Il2CppObject* local_game = try_get_local_game();
	if (!local_game)
	{
		logger::warn("Spawn Bot: LocalGame not found (online/client-only?)");
		return false;
	}

	Il2CppObject* bots_controller = try_get_bots_controller(local_game);
	if (!bots_controller)
	{
		logger::warn("Spawn Bot: BotsController null");
		return false;
	}

	Il2CppObject* spawner = try_get_bot_spawner(bots_controller);
	if (!spawner || !spawner->klass)
	{
		logger::warn("Spawn Bot: GetSpawner failed");
		return false;
	}

	Il2CppObject* params = try_create_bot_spawn_params(trigger);
	if (!params)
	{
		logger::warn("Spawn Bot: BotSpawnParams create failed");
		return false;
	}

	// Task SpawnBotByTypeForce(int count, WildSpawnType botType, BotDifficulty dif, BotSpawnParams spawnParams)
	const MethodInfo* mi = il2utils::resolve_method(
		spawner->klass, "SpawnBotByTypeForce", 4);
	if (!mi || !mi->methodPointer)
	{
		// Walk parents — method is on abstract BotSpawner
		for (Il2CppClass* k = spawner->klass; k && (!mi || !mi->methodPointer); k = k->parent)
		{
			mi = il2utils::resolve_method(k, "SpawnBotByTypeForce", 4);
		}
	}
	if (!mi || !mi->methodPointer)
	{
		logger::warn("SpawnBotByTypeForce not found");
		return false;
	}

	using spawn_fn = void (*)(Il2CppObject*, int, int, int, Il2CppObject*, const MethodInfo*);
	reinterpret_cast<spawn_fn>(mi->methodPointer)(spawner, count, role, difficulty, params, mi);
	return true;
}

const char* WorldModule::role_label(const int type_index) {
	static const char* labels[] = {
		"Scav", "Sniper Scav", "Cursed Scav", "Assault Group",
		"Raider", "Rogue", "USEC PMC", "BEAR PMC",
		"Reshala", "Reshala Guard",
		"Killa", "Shturman", "Shturman Guard",
		"Glukhar", "Glukhar Assault", "Glukhar Security", "Glukhar Scout", "Glukhar Sniper",
		"Sanitar", "Sanitar Guard",
		"Tagilla", "Tagilla Guard",
		"Knight", "Big Pipe", "BirdEye",
		"Kaban", "Kaban Guard", "Kaban Sniper", "Kaban Gus", "Kaban Basmach",
		"Kollontay", "Kollontay Assault", "Kollontay Security",
		"Zryachiy", "Zryachiy Guard", "Peaceful Zryachiy", "Revenge Zryachiy",
		"Partisan",
		"Cultist Priest", "Cultist Warrior", "Cultist Priest Event", "Predvestnik", "Prizrak", "Oni",
		"Santa", "Spirit Winter", "Spirit Spring", "Peacemaker", "Skier", "Arena Fighter", "Arena Cleanup", "Crazy Assault", "BTR Gunner",
		"Infected Assault", "Infected PMC", "Infected Civil", "Infected Laborant", "Infected Tagilla",
		"Shadow of Tagilla", "Shadow of Killa", "Labyrinth Guard",
		"Black Division", "Reshala BlackDiv", "Reshala Guard BlackDiv", "Raider BlackDiv",
		"vsRF", "vsRF Sniper", "vsRF Fight",
		"Sentry", "Civilian", "Boss Wedge", "Boss Wedge Lab", "Wedge Lab Guard",
	};
	constexpr int count = static_cast<int>(sizeof(labels) / sizeof(labels[0]));
	if (type_index < 0 || type_index >= count) return "Unknown";
	return labels[type_index];
}

const char* WorldModule::difficulty_label(const int d) {
	switch (d)
	{
	case 0: return "Easy";
	case 1: return "Normal";
	case 2: return "Hard";
	case 3: return "Impossible";
	default: return "Unknown";
	}
}

float WorldModule::try_unity_time() {
	static const Il2CppImage* img = il2utils::resolve_image("UnityEngine.CoreModule.dll");
	if (!img) return 0.f;
	const Il2CppClass* time_class = il2utils::resolve_class(img, "UnityEngine", "Time");
	if (!time_class) return 0.f;
	const MethodInfo* get_time = il2utils::resolve_method(time_class, "get_time", 0);
	if (!get_time || !get_time->methodPointer) return 0.f;
	return reinterpret_cast<float (*)(const MethodInfo*)>(get_time->methodPointer)(get_time);
}

void WorldModule::prune_pending_spawns(const ULONGLONG now) {
	while (!pending_spawns_.empty() && now - pending_spawns_.front().request_ms > k_pending_max_age_ms)
		pending_spawns_.erase(pending_spawns_.begin());
}

void WorldModule::clear_game_delay_snapshot() {
	game_delay_lines_.clear();
	game_bots_delayed_ = 0;
	game_in_spawn_process_ = 0;
	game_wait_count_ = 0;
}

void WorldModule::commit_game_delay_snapshot(
	const bool ok,
	const int wait_count,
	const int bots_delayed,
	const int in_process,
	std::vector<game_delay_entry>&& lines) {
	if (!ok)
	{
		++empty_poll_streak_;
		if (empty_poll_streak_ >= 3)
		{
			clear_game_delay_snapshot();
		}
		return;
	}
	empty_poll_streak_ = 0;
	game_wait_count_ = wait_count;
	game_bots_delayed_ = bots_delayed;
	game_in_spawn_process_ = in_process;
	game_delay_lines_ = std::move(lines);
}

void WorldModule::refresh_game_spawn_queue() {
	// This is a placeholder for the actual implementation that would poll
	// the game's SpawnDelaysService queue. The actual implementation would
	// depend on the specific game version and offsets.
	// For now, this just clears the snapshot.
	clear_game_delay_snapshot();
}

void WorldModule::draw_spawn_queue_info() {
	// This draws the spawn queue info in the menu.
	// The actual implementation would show the game_delay_lines_ and
	// pending_spawns_ data.
}

