#pragma once

#include "ItemModule.h"

// Reuses the primary item-spawner controls in Weapon Builder. Runtime spawning
// remains owned by ItemModule; this is only an additional view of its settings.
class ItemSpawnerBridgeModule final : public Module
{
  public:
    explicit ItemSpawnerBridgeModule(ItemModule* items);

    void draw_overlay(ImDrawList*) override;
    void application_update() override;
    void gameworld_update(const Il2CppClass*, Il2CppObjectInstance, Il2CppObjectInstance) override;
    void init() override;
    [[nodiscard]] bool draw_menu_extra_before_values() const override;
    void draw_menu_extra() override;

  private:
    ItemModule* items_ = nullptr;
};
