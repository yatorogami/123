#pragma once
// Optic lens pipeline — full reproduction of the game's scope-image placement,
// per optic_idea.md (all native offsets are for the current UnityPlayer build).
//
//   World point -> optic VP -> optic NDC -> mesh UV (NDC*0.05+0.5)
//     -> validated affine map -> lens-local point
//     -> material _Scales.x/_Shifts.x adjust -> shader-adjusted lens matrix
//     -> main VP -> screen
//
// Static route (mesh decode, affine map, material-vector addresses, FOV nodes)
// is cached per optic change; moving inputs (cameras, TRS nodes, material
// vectors, bounds) are re-acquired per frame and validated before use. If any
// validation fails the packet is invalid and callers fall back to the legacy
// radial-fit path.

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

#include "../il2cpp/unity.h"
#include "../util/linalg.h"
#include "../il2cpp/il2utils.h"
#include "../il2cpp/Il2CppObjectInstance.h"
#include "../util/logger.h"
#include "../util/tracy_bridge.h"
// game_state.h, for game_state::optic_root_corrector_off -- the published value of
// EspModule::optic_root_corrector, which is the live A/B switch for the
// root-position outlier filter (see root_corrector_disabled).
//
// ADDED 2026-10-05 and it was a build break on the first attempt: the reference
// was added to root_corrector_disabled() without the include, so every TU that
// pulled this header in failed with
//     error C2653: game_state is not a class or namespace name
//     error C2065: optic_root_corrector_off: undeclared identifier
// Two green test suites had not caught it, which AGENTS.md predicts outright: the
// harness and pytest compile headers standalone or read text, and neither builds
// the artefact that ships. Included here rather than via the PCH because every
// other module/ header that uses game_state includes it explicitly -- common_hooks.h,
// eft_api.h, game_item_db.h, quest_esp.h -- and relying on a transitive PCH include
// is how this sort of thing goes missing on the next PCH edit.
#include "game_state.h"

namespace optics::lens {

    // Math types + algebra come from util/linalg.h (unity::vector2/3/4 as v2/v3/v4,
    // column-major mat4, TRS, polygon/segment clipping) — the shared math header.
    using namespace linalg;

    // ------------------------------------------------------------- per-section timing
    //
    // Uses QueryPerformanceCounter, NOT GetTickCount64. The first attempt at
    // measuring acquire_packet used GetTickCount64, which on this machine ticks at
    // the system timer interval (~15.6 ms) -- COARSER than the entire function under
    // investigation. It reported a suspiciously stable "47 ms", which is simply
    // 3 timer ticks; the raw readings were only ever {31, 47, 94} ms, all exact
    // multiples of 15.625. That quantisation is what exposed the flaw, and it is why
    // this uses QPC.
    //
    // Accumulated across calls; the caller drains and logs it (see the rate-limited
    // block in eft_api::optic_lens_ensure_frame) so there is no logging cost here.
    enum perf_section {
        perf_metadata = 0, // resolve_* + managed field reads + native_of
        perf_matrices,     // read_camera_matrices x2
        perf_pose,         // camera_transform_pose + camera_consistent, x2 each
        perf_lens_chain,   // hierarchy walk + FOV normalisation
        perf_mask,         // shader adjust, mask polygon, clip_polygon
        perf_section_count
    };

    struct perf_accum
    {
        double micros[perf_section_count] = {0};
        double total_micros = 0.0;
        unsigned long long calls = 0;
    };

    inline perf_accum& perf_sections() {
        static perf_accum a{};
        return a;
    }

    // Counters for the memory-validity probe.
    //
    // Tracked because "the range memo makes reads free" is a claim, and the last two
    // attempts at that claim were both wrong while looking plausible in the timings.
    // The syscall count is unambiguous: if the region memo works, this goes to
    // roughly one probe per distinct region per interval instead of two per read.
    struct perf_counter_set
    {
        std::atomic<unsigned long long> virtual_queries{0};
        std::atomic<unsigned long long> range_hits{0};
        std::atomic<unsigned long long> range_misses{0};
    };
    inline perf_counter_set& perf_counters() {
        static perf_counter_set c{};
        return c;
    }

    inline double qpc_us() {
        static LARGE_INTEGER freq = [] {
            LARGE_INTEGER f{};
            QueryPerformanceFrequency(&f);
            return f;
        }();
        LARGE_INTEGER c{};
        QueryPerformanceCounter(&c);
        return static_cast<double>(c.QuadPart) * 1e6 / static_cast<double>(freq.QuadPart);
    }

    // Times a whole acquire_packet call INCLUDING the early-return paths.
    //
    // This exists because the first version only counted on the SUCCESS path
    // (`++perf.calls` sat next to `out.valid = true`). Once the packet began failing
    // every frame -- which is exactly the condition most worth measuring -- `calls`
    // stayed 0, so the entire optic-perf line silently stopped appearing and took the
    // lag measurement with it. Observed 2026-09-26: the failing build produced no perf
    // line at all, and the 1x-only stutter had to be diagnosed without it.
    struct scoped_call_timer
    {
        scoped_call_timer();
        ~scoped_call_timer();
        scoped_call_timer(const scoped_call_timer&) = delete;
        scoped_call_timer& operator=(const scoped_call_timer&) = delete;
        double start;
    };

    // ------------------------------------------------------------- safe reads
    // In-process reads of game memory. A page-range check via VirtualQuery keeps
    // stale-pointer samples from crashing; a failed check aborts the sample.
    //
    // The verified-range memo is DIRECT-MAPPED over 64 slots keyed by page number,
    // and each slot holds an entire verified VirtualQuery REGION -- not just the
    // byte range of the read that populated it.
    //
    // That distinction is the whole ballgame, and getting it wrong was a real
    // measured regression here. Attempt 1 replaced a single-entry cache with 64
    // page-keyed slots but still stored only the individual read's byte range: a
    // 4-byte probe at cam+0xA8 cached 4 bytes, so the next read at cam+0xE8 missed,
    // and the next, and the next. It moved the thrash around without removing it --
    // measured 2026-09-26 at 46 ms per acquire_packet with every section still slow.
    //
    // Storing the region means every subsequent read anywhere inside it is free.
    // That matters because this path reads a whole camera object (0xA8..0x780) and
    // walks component arrays of up to 256 entries 16 bytes apart, all inside one
    // region.
    //
    // 4096 slots, page-keyed with Fibonacci hashing on the high bits. Direct mapping
    // means no probing or eviction policy. Not thread-safe, exactly as the original
    // single static was; a torn slot can only cause a spurious re-probe, never a false
    // "readable", because a region is only stored after VirtualQuery validated it and
    // the write order below publishes size before base.
    //
    // WHY 4096 AND NOT 256 (2026-10-01). This table was the single most expensive thing
    // in a Tracy capture: 29.385 s, 6.13% of wall clock, 790,199 calls, 37.2 us per call.
    // The log says why --
    //
    //     optic-perf: ... range hit/miss=7242/324 vq=648      (per 600 ms window)
    //
    // 324 misses per 600 ms window, each miss being 2 VirtualQuery calls at ~37 us. The
    // working set is larger than 256 slots, so every miss evicts a different region and
    // the region that just lost its slot misses again on its next probe. That is steady
    // state, not a cold cache, and no amount of waiting would have fixed it.
    //
    // The same defect was already found and fixed in the sibling table,
    // eft_api::is_readable_address_cached, which went from evict/miss=100.0% to a 100%
    // hit rate. This was the same design at the old size.
    struct range_slot
    {
        uintptr_t base = 0;
        size_t size = 0;
    };

    // 256 -> 4096 slots, 2026-10-01. See the comment block above for why the old size
    // was a steady-state thrash rather than a cold cache.
    inline constexpr size_t kRangeSlots = 4096;

    // Fibonacci hashing on the high bits, masked to the table.
    //
    // The OLD expression was `((page * 2654435761) >> 20) & 255`, and the obvious "widen
    // the shift to match a bigger mask" edit to `>> 52 & 4095` is a CATASTROPHE, not a
    // tuning change. Measured over 4096 consecutive pages:
    //
    //     >> 20 & 255   (256 slots)     256 distinct  -- saturates its own table
    //     >> 20 & 4095  (4096 slots)   3689 distinct  -- would also have worked
    //     >> 52 & 4095  (DO NOT DO)       1 distinct  -- COLLAPSED to a single slot
    //
    // The reason is that `page * K` advances by a CONSTANT per page, so a run of
    // consecutive pages walks a fixed arithmetic progression and the top bits never
    // move: (1087*K)>>52 and (1088*K)>>52 are both 0. Bits 20..27 moved every page, and
    // that is the only reason the original expression worked at all. `>> 20` was
    // load-bearing, not stale, and the number 20 was doing real work.
    //
    // Taking the high bits of a 64-bit Fibonacci product scatters the low-entropy input
    // across the whole index space instead, so the shift no longer has to be tuned to the
    // stride. Measured: 2831 distinct slots from 4096 consecutive pages, 69.1%.
    //
    // THE MASK IS NOT OPTIONAL. `>> 32` alone yields 32 bits, so the index runs to
    // 4,294,967,295 against a 4096-entry array. Measured on this same page range the
    // unmasked value reaches 13,524,350,245,588 -- an out-of-bounds write three billion
    // elements past the end. The static_assert below catches a non-power-of-two table,
    // and the mask is what makes the width correct.
    inline size_t range_slot_index(uintptr_t page) {
        static_assert((kRangeSlots & (kRangeSlots - 1)) == 0,
            "kRangeSlots must be a power of two for the mask to be a valid index bound");
        return static_cast<size_t>((page * 11400714819323198485ull) >> 32) & (kRangeSlots - 1);
    }

    inline range_slot& range_readable_slot(uintptr_t addr) {
        static range_slot slots[kRangeSlots];
        return slots[range_slot_index(addr >> 12)];
    }

    // Drop every cached region. Called on the raid-boundary transition, for the same
    // reason eft_api::clear_probe_region_memo() exists.
    //
    // 2026-10-01. A cached entry is a VERIFIED REGION -- base and size as VirtualQuery
    // reported them -- and its size goes stale when the object behind it is freed and the
    // region is reused or unmapped. The string-path memo is cleared on every raid
    // boundary; this table was not, and it is the same class of cache over the same kind
    // of data.
    //
    // The optics path makes it worse than "same risk". It reads camera objects, component
    // arrays of up to 256 entries, and Transform parent chains, all of which the game
    // REBUILDS on every transit. So across an extraction the addresses this table has
    // verified can start belonging to a different object entirely, and a stale-but-still-
    // committed region would answer "readable" for a pointer that no longer means what it
    // did. Not a fault -- the read is of a mapped page either way -- but a silent read of
    // the wrong object, which is worse to diagnose than a crash.
    //
    // Resizing to 4096 slots did not create this, but it extended every entry's lifetime
    // by making the table hold more of them, so the deferral stopped being free.
    //
    // Zeroing is safe in the worst case: a cleared table costs one VirtualQuery pair per
    // probe until it refills, which is the pre-memo behaviour and strictly correct. There
    // is no ordering hazard in clearing, only in publishing (see range_readable's write
    // order: size before base).
    // How many times the table has been dropped since process start.
    //
    // Added 2026-10-04 to answer ONE question, because the capture showed two hypotheses
    // that need different fixes and the log could not tell them apart:
    //
    //   hit/miss went 8008/0 -> 5868/240 and range_readable's mean_ns went 135 -> 29,165
    //   (216x worse per call at the same order of workload; total_perc 0.017% -> 4.38%).
    //
    //   (a) The table is being CLEARED mid-raid. game_state::set_in_raid owns the clear
    //       and now has two writers on two threads, so a spurious transition would drop
    //       4,096 slots and force a full VirtualQuery refill.
    //   (b) The working set genuinely outgrew 4,096 slots, so it is colliding on its own.
    //
    // (a) is a bug in code written hours ago and (b) is a tuning problem, and resizing the
    // table would make (a) WORSE rather than better -- more slots to refill. So the
    // clear count is printed beside the miss count in the same optic-perf line: clears
    // non-zero during steady state means (a) and the size is the wrong lever.
    //
    // Not atomic on purpose. The clear runs on the raid-boundary path (game thread) and
    // the read of this counter runs inside the same perf dump on that thread, so a
    // relaxed race here would at worst report a stale count -- the same class of
    // imprecision as the hit/miss figures beside it.
    inline unsigned long long g_range_clears = 0;

    inline void clear_range_readable_table() {
        static range_slot* const slots = &range_readable_slot(0);
        for (size_t i = 0; i < kRangeSlots; ++i) {
            slots[i].size = 0;
            slots[i].base = 0;
        }
        ++g_range_clears;
    }

    inline bool range_readable(uintptr_t addr, size_t bytes) {
        TA_ZONE_N("optics::lens::range_readable");
        if (addr == 0 || bytes == 0) return false;
        const uintptr_t first = addr;
        const uintptr_t last = addr + bytes - 1; // inclusive last byte
        range_slot& slot = range_readable_slot(first);
        if (slot.size != 0 && first >= slot.base && last < slot.base + slot.size)
        {
            perf_counters().range_hits.fetch_add(1, std::memory_order_relaxed);
            return true;
        }
        perf_counters().range_misses.fetch_add(1, std::memory_order_relaxed);
        constexpr DWORD ok = PAGE_READWRITE | PAGE_READONLY | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_WRITECOPY;
        MEMORY_BASIC_INFORMATION mbi_first{};
        bool have_first = false;
        // Probe the FIRST and LAST byte pages — a start-page-only check misses
        // ranges whose tail crosses into an uncommitted page (buffer reads).
        for (const uintptr_t probe : {first, last})
        {
            MEMORY_BASIC_INFORMATION mbi{};
            perf_counters().virtual_queries.fetch_add(1, std::memory_order_relaxed);
            if (!VirtualQuery(reinterpret_cast<LPCVOID>(probe), &mbi, sizeof(mbi))) return false;
            if (mbi.State != MEM_COMMIT) return false;
            if (!(mbi.Protect & ok)) return false;
            const uintptr_t region_end =
                reinterpret_cast<uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;
            if (last >= region_end) return false;
            if (!have_first)
            {
                mbi_first = mbi;
                have_first = true;
            }
        }
        // Cache the whole region, not this read's bytes. The loop above has just
        // proven `last` lies inside BOTH probed regions, so the first probe's region
        // safely covers [first, last].
        //
        // Write order: size FIRST, then base. A concurrent reader that observes the new
        // base with the OLD size can be handed a false positive -- the new region might
        // start low and the stale size might be large, so `first >= base && last < base
        // + size` can pass for a range no syscall in this function ever approved.
        // Zeroing size before publishing the new base means any interleaving a reader can
        // observe fails the `slot.size != 0` guard and re-probes, which is always safe.
        //
        // The handoff memo for this task described this as an existing property to leave
        // alone. It was not present: the code was `base = ...; size = ...;` with no
        // zeroing at all. Fixed here rather than deferred, because resizing the table
        // makes slots live 16x longer and a false positive is a wild read.
        slot.size = 0;
        slot.base = reinterpret_cast<uintptr_t>(mbi_first.BaseAddress);
        slot.size = mbi_first.RegionSize;
        return true;
    }

    template <typename T>
    inline bool read_pod(uintptr_t addr, T& out) {
        if (!range_readable(addr, sizeof(T))) return false;
        std::memcpy(&out, reinterpret_cast<const void*>(addr), sizeof(T));
        return true;
    }
    inline bool read_u8(uintptr_t a, uint8_t& v) { return read_pod(a, v); }
    inline bool read_u16(uintptr_t a, uint16_t& v) { return read_pod(a, v); }
    inline bool read_u32(uintptr_t a, uint32_t& v) { return read_pod(a, v); }
    inline bool read_i32(uintptr_t a, int32_t& v) { return read_pod(a, v); }
    inline bool read_u64(uintptr_t a, uint64_t& v) { return read_pod(a, v); }
    inline bool read_f32(uintptr_t a, float& v) { return read_pod(a, v); }
    inline bool read_ptr(uintptr_t a, uintptr_t& v) { return read_pod(a, v); }
    inline bool read_v3(uintptr_t a, v3& v) { return read_pod(a, v); }
    inline bool read_v4(uintptr_t a, v4& v) { return read_pod(a, v); }

    inline uintptr_t unity_player_base() {
        static uintptr_t base = reinterpret_cast<uintptr_t>(GetModuleHandleW(L"UnityPlayer.dll"));
        return base;
    }

    // Resolve a UnityEngine class by NAME and return its Il2CppClass*.
    //
    // The route used to gate on hardcoded UnityPlayer class-ID constants
    // (u + 0x17B0FC8 etc.). Those are build-specific: every BSG/Unity update that
    // reshuffles the type table moves them, and the route then rejected with
    // "not MeshRenderer" / "no Transform" on a perfectly valid scope. Names are
    // stable across builds, and UnityEngine.CoreModule.dll is already resolved by
    // name elsewhere in this codebase (unity.h, skeleton_visibility.h, ChamsModule).
    //
    // The caller still accepts the legacy constant as a fallback via
    // `matches_class_native`, so an unusual build that hides these classes from the
    // managed image still works the old way.
    inline uintptr_t unity_engine_class(const char* namespaze, const char* name) {
        static std::unordered_map<std::string, uintptr_t> cache;
        const std::string key = std::string(namespaze ? namespaze : "") + "|" + (name ? name : "");
        const auto cached = cache.find(key);
        if (cached != cache.end()) return cached->second;

        uintptr_t result = 0;
        if (const Il2CppImage* image = il2utils::resolve_image("UnityEngine.CoreModule.dll"))
        {
            if (const Il2CppClass* klass = il2utils::resolve_class(image, namespaze, name))
                result = reinterpret_cast<uintptr_t>(klass);
        }
        cache.emplace(key, result);
        return result;
    }

    // Read a native object's class NAME out of its Il2CppClass.
    //
    // Makes every class-identity rejection self-describing: "not MeshRenderer
    // (class='X', name_lookup=ok/miss)" distinguishes a build that MOVED the class
    // (lookup miss -> the legacy fallback is stale) from an object that simply is
    // not what the route assumed.
    // Read a MANAGED class's name out of its Il2CppClass.
    //
    // IMPORTANT: this is only valid for a *managed* Il2CppClass pointer (i.e. an
    // Il2CppObject's ->klass). A Unity NATIVE engine object's first word is Unity's
    // own internal class pointer, whose layout is NOT the managed Il2CppClass — reading
    // ->name at +0x10 from one yields x86 code bytes, which is what produced
    // `class='@WH   H   "S'`. That garbage was the diagnostic lying about its own
    // input, and it survived a fix that changed an unrelated pointer.
    //
    // Non-printable bytes abort the read: a type name is always printable ASCII, so
    // anything else means we were handed the wrong kind of pointer and must say so
    // rather than emit mojibake that reads like real data.
    inline std::string class_name_of(uintptr_t klass_managed) {
        if (!klass_managed) return {};
        const auto* klass = reinterpret_cast<const Il2CppClass*>(klass_managed);
        if (!range_readable(reinterpret_cast<uintptr_t>(klass), sizeof(const char*))) return "<unreadable>";
        const char* name = klass->name;
        if (!name || !range_readable(reinterpret_cast<uintptr_t>(name), 1)) return "<unreadable>";
        std::string out;
        for (int i = 0; i < 128; ++i)
        {
            if (!range_readable(reinterpret_cast<uintptr_t>(name + i), 1)) return "<unreadable>";
            const unsigned char c = static_cast<unsigned char>(name[i]);
            if (c == '\0') return out;
            if (c < 0x20 || c > 0x7E) return "<non-ascii: not a managed class>";
            out.push_back(static_cast<char>(c));
        }
        return out;
    }

    // MANAGED-domain identity check: `managed_klass` must be a managed Il2CppClass*
    // (e.g. some Il2CppObject's ->klass). Walks ->parent so a subclass satisfies a
    // base-class test.
    //
    // Do NOT call this with a class pointer read out of a NATIVE engine object: native
    // class pointers are not Il2CppClass, so ->parent reads an unrelated field. Native
    // identity is a plain compare against the native type-descriptor address.
    inline bool class_is_a(uintptr_t managed_klass, uintptr_t target) {
        if (!target || !managed_klass) return false;
        const Il2CppClass* klass = reinterpret_cast<const Il2CppClass*>(managed_klass);
        for (int depth = 0; klass && depth < 32; ++depth)
        {
            if (reinterpret_cast<uintptr_t>(klass) == target) return true;
            if (!range_readable(reinterpret_cast<uintptr_t>(klass), sizeof(void*))) return false;
            klass = klass->parent;
        }
        return false;
    }

    // MANAGED-domain helper: matches a managed class against a name-resolved target.
    inline bool matches_managed_class(uintptr_t managed_klass, uintptr_t target_klass) {
        if (!target_klass) return false;
        return class_is_a(managed_klass, target_klass);
    }

    // NATIVE-domain identity check: `native` is a class pointer read out of a native
    // engine object, so the only valid comparison is against the native type-descriptor
    // address. There is no name-based or subclass-walking equivalent in this domain.
    inline bool matches_native_class(uintptr_t native, uintptr_t legacy_id) {
        const uintptr_t u = unity_player_base();
        return u != 0 && native == u + legacy_id;
    }

    // Component lookup for a NATIVE GameObject. Declared here, defined after
    // find_component (which takes native pointers).
    inline bool find_component_named(uintptr_t game_object, const char* name, uintptr_t legacy_id,
        uintptr_t& out_native, int limit = 128);

    // -------------------------------------------------- managed-object helpers
    // Offset of UnityEngine.Object.m_CachedPtr, resolved DYNAMICALLY.
    //
    // The route previously hardcoded +0x10. unity.h resolves this field by name
    // (is_unity_object_alive) precisely because the offset is not guaranteed to be
    // stable across builds — a wrong offset yields a pointer into unrelated memory,
    // whose first word is then read as an Il2CppClass*. That is what produced the
    // garbage reject `not MeshRenderer (class='@WH   H   "S')`: the "class name"
    // was x86 bytes of code, not a string.
    //
    // Cached after the first successful resolve: the field is a fixed instance offset
    // for the process lifetime.
    inline int32_t cached_ptr_offset(Il2CppObject* probe) {
        static int32_t offset = -1;
        if (offset != -1) return offset;
        // A null/classless probe cannot resolve anything. Return WITHOUT latching:
        // latching 0 here would permanently poison the cache for every later caller,
        // so asking for the value purely to log it must be side-effect free.
        if (!probe || !probe->klass) return 0;
        offset = 0;
        if (const FieldInfo* f = il2utils::resolve_field(probe->klass, "m_CachedPtr"))
        {
            if (f->offset > 0) offset = f->offset;
        }
        // optic_idea.md section 1 states the native pointer is read at object + 0x10
        // and that this applies to both cameras and LensRenderer. Resolving by name is
        // the more robust form, but it is a DEVIATION from the spec, so report what it
        // actually resolved to instead of silently assuming it agrees.
        if (offset > 0 && offset != 0x10)
        {
            logger::warn(std::format(
                "unity m_CachedPtr resolves to +0x{:X} but optic_idea.md specifies +0x10 -- "
                "every managed->native read in the optic route uses the resolved value",
                offset));
        }
        return offset;
    }

    inline uintptr_t native_of(Il2CppObject* obj) {
        if (!obj) return 0;
        const int32_t offset = cached_ptr_offset(obj);
        // No offset resolved (class not walked yet / field absent): fall back to the
        // historical 0x10 rather than returning 0, but the route's own readability
        // guards downstream will reject a wrong pointer instead of trusting it.
        const uintptr_t field = reinterpret_cast<uintptr_t>(obj) + (offset > 0 ? offset : 0x10);
        uintptr_t p = 0;
        if (!read_ptr(field, p)) return 0;
        return p;
    }

    // Field resolver that walks the class hierarchy (il2utils::resolve_field may
    // only search the given class).
    //
    // Memoised on (class, name). FieldInfo records are fixed once IL2CPP has
    // initialised, and this sits on the per-frame path via read_managed_ref_field:
    // the unwound walk is a strcmp against every field of every class in the
    // hierarchy, repeated up to 250x/second. Only successes are cached, so a
    // not-yet-resolvable name still retries.
    inline const FieldInfo* field_in_hierarchy(const Il2CppClass* cls, const char* name) {
        static std::unordered_map<std::string, const FieldInfo*> cache;
        static std::mutex mutex;

        const std::string key = std::to_string(reinterpret_cast<uintptr_t>(cls)) + "." + name;
        {
            std::lock_guard<std::mutex> lock(mutex);
            if (const auto it = cache.find(key); it != cache.end())
                return it->second;
        }
        for (const Il2CppClass* c = cls; c; c = c->parent)
        {
            if (const FieldInfo* f = il2utils::resolve_field(c, name))
            {
                std::lock_guard<std::mutex> lock(mutex);
                cache.emplace(key, f);
                return f;
            }
        }
        return nullptr;
    }

    inline uintptr_t read_managed_ref_field(Il2CppObject* obj, const char* name) {
        if (!obj || !obj->klass) return 0;
        // Auto-properties store their value in '<Name>k__BackingField' — try the
        // backing field FIRST (the project-wide convention; plain names virtually
        // never exist for these — dump 2026-09-25:
        // CameraManager.<OpticCameraManager>k__BackingField, not 'OpticCameraManager').
        // Built in a stack buffer, not a std::string: this is per-frame and the
        // concatenation was a heap allocation on every call.
        char backing[128];
        const int n = std::snprintf(backing, sizeof(backing), "<%s>k__BackingField", name);
        const FieldInfo* f = (n > 0 && static_cast<size_t>(n) < sizeof(backing))
            ? field_in_hierarchy(obj->klass, backing)
            : nullptr;
        if (!f)
            f = field_in_hierarchy(obj->klass, name);
        if (!f || f->offset == 0) return 0;
        uintptr_t v = 0;
        if (!read_ptr(reinterpret_cast<uintptr_t>(obj) + f->offset, v)) return 0;
        return v;
    }

    // --------------------------------------------- Unity instance-ID lookup
    inline uint32_t instance_hash(uint32_t id) {
        uint32_t x = id * 0x1001u + 0x7ED55D16u;
        x = x ^ (x >> 19) ^ 0xC761C23Cu;
        x = x * 0x21u + 0x165667B1u;
        x = (x + 0xD3A2646Cu) ^ (x << 9);
        x = x * 9u + 0xFD7046C5u;
        return x ^ (x >> 16) ^ 0xB55A4F09u;
    }

    inline bool instance_from_id(uint32_t id, uintptr_t& out) {
        if (id == 0) return false;
        const uintptr_t u = unity_player_base();
        uintptr_t root = 0;
        if (!read_ptr(u + 0x1A237F8, root) || !root) return false;
        uintptr_t table = 0;
        if (!read_ptr(root, table) || !table) return false;
        uint32_t mask = 0;
        if (!read_u32(root + 8, mask)) return false;
        if (mask < 8 || mask > (1u << 27) || (mask & 7) != 0) return false;
        const uint32_t m8 = mask / 8;
        if ((m8 & (m8 + 1)) != 0) return false;

        const uint32_t hash = instance_hash(id);
        uint32_t index = hash & mask;
        for (uint32_t step = 8; step <= 512; step += 8)
        {
            const uintptr_t entry = table + static_cast<uintptr_t>(index) * 3;
            uint32_t stored = 0;
            if (!read_u32(entry, stored)) return false;
            if (stored == (hash & 0xFFFFFFFCu))
            {
                uint32_t stored_id = 0;
                if (!read_u32(entry + 8, stored_id)) return false;
                if (stored_id == id) return read_ptr(entry + 16, out) && out != 0;
            }
            if (stored == 0xFFFFFFFFu) break;
            index = (index + step) & mask;
        }
        return false;
    }

    // Find a native component of the type described by `descriptor` inside a
    // GameObject's component array.
    inline bool find_component(uintptr_t game_object, uintptr_t descriptor, uintptr_t& out,
        uint32_t limit = 64) {
        uintptr_t entries = 0;
        uint64_t count = 0;
        if (!read_ptr(game_object + 0x58, entries) || !entries) return false;
        if (!read_u64(game_object + 0x68, count) || count == 0 || count > limit) return false;
        uint32_t first_type = 0, type_count = 0;
        if (!read_u32(descriptor + 0x30, first_type)) return false;
        if (!read_u32(descriptor + 0x34, type_count) || type_count == 0 || type_count > 1024)
            return false;
        for (uint64_t i = 0; i < count; ++i)
        {
            const uintptr_t entry = entries + i * 16;
            uint32_t type_id = 0;
            if (!read_u32(entry, type_id)) return false;
            if (static_cast<uint32_t>(type_id - first_type) < type_count)
            {
                uintptr_t p = 0;
                if (!read_ptr(entry + 8, p) || !p) return false;
                out = p;
                return true;
            }
        }
        return false;
    }

    // System.Type for a UnityEngine class, cached. Built the way the ballistic walk
    // builds g_ballistic_type: resolve class -> class type -> Type object.
    // MANAGED only — the returned Type is for unity::gameobject_get_component, which
    // requires a MANAGED GameObject.
    inline Il2CppObject* system_type_for(const char* namespaze, const char* name) {
        static std::unordered_map<std::string, Il2CppObject*> cache;
        const std::string key = std::string(namespaze ? namespaze : "") + "|" + (name ? name : "");
        const auto cached = cache.find(key);
        if (cached != cache.end()) return cached->second;
        Il2CppObject* type = nullptr;
        if (const Il2CppImage* image = il2utils::resolve_image("UnityEngine.CoreModule.dll"))
            type = il2utils::get_system_type(image, namespaze, name);
        cache.emplace(key, type);
        return type;
    }

    // UnityEngine.Object.GetInstanceID() — MANAGED. Replaces native `+0x60` reads,
    // whose offset was an unverified assumption.
    inline uint32_t managed_instance_id(Il2CppObject* obj) {
        if (!obj || !obj->klass) return 0;
        using get_id_sig = int32_t (*)(Il2CppObject*);
        const auto get_id = il2utils::get_method<get_id_sig>(
            const_cast<Il2CppClass*>(obj->klass), "GetInstanceID", 0, /*log_fail=*/false);
        if (!get_id) return 0;
        return static_cast<uint32_t>(get_id(obj));
    }

    // Component lookup for a NATIVE GameObject.
    //
    // `game_object` here is a native engine pointer (e.g. `read_ptr(lens_native + 0x58)`),
    // so this MUST stay in the native domain. find_component() walks the GameObject's
    // native component array and matches each entry's type id against a range read from
    // a *Unity native type descriptor* (first_type @+0x30, type_count @+0x34) — the
    // legacy constant is exactly that address.
    //
    // DO NOT "improve" this to unity::gameobject_get_component(name): that is a MANAGED
    // call expecting a managed GameObject*, and passing a native pointer makes the
    // managed method dereference it as an Il2CppObject and walk into unrelated memory.
    // That was tried on 2026-09-26 and crashed the game. The route now gets Transform /
    // MeshFilter through the managed chain instead, so this is only used for
    // native-only lookups.
    inline bool find_component_named(uintptr_t game_object, const char* name, uintptr_t legacy_id,
        uintptr_t& out_native, int limit) {
        (void)name;
        const uintptr_t u = unity_player_base();
        return u != 0 && find_component(game_object, u + legacy_id, out_native, limit);
    }

    // ------------------------------------------------------------- mesh decode
    struct mesh_data
    {
        std::vector<v3> positions;
        std::vector<v2> uvs;
        std::vector<uint32_t> indices;
    };

    inline bool read_channel(uintptr_t data, uint32_t vertex_count, uint32_t channel,
        uint32_t wanted_dim, std::vector<v3>* as_v3,
        std::vector<v2>* as_v2) {
        uint8_t desc[4];
        if (!range_readable(data + 8 + channel * 4, 4)) return false;
        std::memcpy(desc, reinterpret_cast<const void*>(data + 8 + channel * 4), 4);
        const uint8_t stream = desc[0], offset = desc[1], format = desc[2], dim = desc[3] & 15;
        if (stream > 3 || format != 0 || dim != wanted_dim) return false;

        const uintptr_t stream_info = data + 0x40 + stream * 12;
        uint32_t channel_mask = 0, stream_offset = 0;
        uint8_t stride = 0;
        if (!read_u32(stream_info, channel_mask)) return false;
        if (!read_u32(stream_info + 4, stream_offset)) return false;
        if (!read_u8(stream_info + 8, stride)) return false;
        if (!(channel_mask & (1u << channel))) return false;
        if (stride < offset + dim * 4) return false;

        uintptr_t buffer_base = 0;
        if (!read_ptr(data + 0xA0, buffer_base) || !buffer_base) return false;
        const size_t bytes = static_cast<size_t>(vertex_count) * stride;
        if (!range_readable(buffer_base + stream_offset, bytes)) return false;
        const uint8_t* buf = reinterpret_cast<const uint8_t*>(buffer_base + stream_offset);

        auto finite4 = [](const uint8_t* p) {
            float f;
            std::memcpy(&f, p, 4);
            return std::isfinite(f);
        };
        for (uint32_t i = 0; i < vertex_count; ++i)
        {
            const uint8_t* p = buf + static_cast<size_t>(i) * stride + offset;
            for (uint32_t d = 0; d < dim; ++d)
                if (!finite4(p + d * 4)) return false;
            if (as_v3)
            {
                float f[3] = {0, 0, 0};
                std::memcpy(f, p, dim * 4);
                (*as_v3)[i] = {f[0], f[1], f[2]};
            }
            else if (as_v2)
            {
                float f[2] = {0, 0};
                std::memcpy(f, p, dim * 4);
                (*as_v2)[i] = {f[0], f[1]};
            }
        }
        return true;
    }

    inline bool read_mesh(uintptr_t mesh_native, mesh_data& out) {
        uintptr_t data = 0;
        if (!read_ptr(mesh_native + 0x60, data) || !data) return false;
        uint32_t vertex_count = 0;
        if (!read_u32(data + 0x78, vertex_count) || vertex_count < 3 || vertex_count > 4096)
            return false;
        uint64_t submesh_count = 0;
        if (!read_u64(data + 0xE0, submesh_count) || submesh_count != 1) return false;

        out.positions.assign(vertex_count, {});
        out.uvs.assign(vertex_count, {});
        if (!read_channel(data, vertex_count, 0, 3, &out.positions, nullptr)) return false;
        if (!read_channel(data, vertex_count, 4, 2, nullptr, &out.uvs)) return false;

        uint32_t index_format = 0;
        if (!read_u32(data + 0xC8, index_format)) return false;
        if (index_format > 1) return false;
        const uint32_t index_size = index_format == 0 ? 2 : 4;

        uintptr_t submesh = 0;
        if (!read_ptr(data + 0xD0, submesh) || !submesh) return false;
        uint32_t first_byte = 0, index_count = 0, topology = 0, base_vertex = 0;
        if (!read_u32(submesh + 0x20, first_byte)) return false;
        if (!read_u32(submesh + 0x24, index_count)) return false;
        if (!read_u32(submesh + 0x28, topology)) return false;
        if (!read_u32(submesh + 0x2C, base_vertex)) return false;
        if (topology != 0 || index_count == 0 || index_count > 24576 || index_count % 3 != 0)
            return false;
        uint64_t index_buffer_bytes = 0;
        if (!read_u64(data + 0xB8, index_buffer_bytes)) return false;
        if (static_cast<uint64_t>(first_byte) + static_cast<uint64_t>(index_count) * index_size > index_buffer_bytes)
            return false;
        uintptr_t index_buffer = 0;
        if (!read_ptr(data + 0xA8, index_buffer) || !index_buffer) return false;
        if (!range_readable(index_buffer + first_byte,
                static_cast<size_t>(index_count) * index_size))
            return false;

        out.indices.reserve(index_count);
        for (uint32_t i = 0; i < index_count; ++i)
        {
            const uint8_t* p = reinterpret_cast<const uint8_t*>(index_buffer + first_byte) + static_cast<size_t>(i) * index_size;
            uint32_t idx = 0;
            if (index_size == 2)
            {
                uint16_t v;
                std::memcpy(&v, p, 2);
                idx = v;
            }
            else
            {
                std::memcpy(&idx, p, 4);
            }
            idx += base_vertex;
            if (idx >= vertex_count) return false;
            out.indices.push_back(idx);
        }
        return true;
    }

    // ----------------------------------------------------------- static route
    struct affine_map
    {
        v3 center{}, u_axis{}, v_axis{};
        bool valid = false;
        v3 local_from_uv(const v2& uv) const;
    };

    // ---- DEFECT A measurement ------------------------------------------------
    // The standing report is "the mask covers ~1.16-1.22x too much". That has been a
    // hypothesis for several runs with no number attached, which is the same failure mode
    // as a diagnostic that reports a placeholder: everyone reasons about the cause and
    // nobody can check. This records the two radii that decide it.
    //
    // The competing explanations, and what each predicts:
    //   1. The AABB circumscribes the mesh (a box is always >= the geometry inside it).
    //      Predicts aabb_rx/mesh_rx > 1 and aabb_ry/mesh_ry > 1, roughly equal.
    //   2. The aperture is smaller than the lens MESH -- a real scope's glass is inset
    //      inside its housing, and the renderer's bounds cover the housing.
    //      Predicts both ratios > 1 EVEN IF the AABB were tight, and constant per optic.
    //   3. A units or axis error in the extents read.
    //      Predicts the ratios moving around between frames of the same optic.
    //
    // (1) and (2) are told apart by the extents, which are in the same log line: if the
    // extents say the AABB is already tight around the mesh and the ratio is still > 1,
    // the excess is the housing, not the box. The log prints all of it in one line
    // precisely so the next run can decide rather than debate.
    //
    // A ratio near 1.0 falsifies all three at once, and would send the search to the
    // clipping step instead. That outcome is worth as much as the others.
    struct defect_a
    {
        int valid = 0;
        int mesh_available = 0;
        // Semi-axes in main-screen NDC. NDC, not pixels: pixels change with window size
        // and the ratios below must not move when the user resizes.
        float aabb_rx = 0.f, aabb_ry = 0.f;
        float aabb_cx = 0.f, aabb_cy = 0.f;
        float mesh_rx = 0.f, mesh_ry = 0.f;
        float mesh_cx = 0.f, mesh_cy = 0.f;
        // Raw world-space AABB extents as read, kept so the axes stay identifiable.
        float extents[3] = {0, 0, 0};
        // Which source the cull ellipse was built from: 0 = validated AABB (spec's route),
        // 1 = mesh silhouette fallback. A non-zero `source` means the AABB read failed
        // containment and the region came from the geometry instead.
        int source = 0;
        // Running count of frames where the AABB was rejected. The honest measure of how
        // often the +0xE8 read is wrong, as opposed to inferring it from an impossible ratio.
        unsigned long long aabb_rejected = 0;
        // This frame's extents failed the magnitude floor. Kept separate from the
        // cumulative aabb_rejected so a run with 30 bad reads and 30 containment misses
        // is distinguishable from one with 30 bad reads and 0 containment misses.
        int extents_rejected = 0;
        // Running mean of mask_cover_frac split by which source produced the ellipse.
        //
        // This is the most robust form of the over-coverage measurement, and it was added
        // because it does not depend on the containment test at all. Both figures describe
        // the same lens geometry and differ only in where the ellipse's bounding rect came
        // from, so their area ratio IS the over-coverage -- where the semi-axis ratio needs
        // two valid projections AND is compared against a box that may not be the one being
        // used.
        //
        // REWRITTEN 2026-10-03. The first version accumulated coverage into two buckets by
        // SOURCE and divided them, and the log line even admitted the result was
        // uncontrolled:
        //
        //     optic-defectA: COVER aabb=24.16% (n=73) mesh=21.49% (n=154) -> over=1.124x
        //     ... groups are different frames, so pose is NOT controlled
        //
        // That is not a weak measurement, it is not a measurement. The buckets were
        // DISJOINT frame sets -- mesh coverage was only ever accumulated on frames where
        // the AABB had been rejected and the fallback used -- so once the AABB stopped
        // being rejected (154 rejections, then zero for the rest of the run) the mesh
        // bucket froze at its last value while the aabb bucket kept growing. Dividing
        // those two numbers divides a live distribution by a stale one.
        //
        // The 2026-10-03 capture made the consequence concrete. Reported over was
        // 1.124x -> 1.145x -> 1.161x -> 1.176x, which reads as over-coverage rising
        // smoothly as the scope tilts. It was not rising at all: mesh=21.49% and n=154
        // were byte-identical on every one of those lines while aabb n went 73 -> 151 ->
        // 228 -> 304. The "trend" was the denominator's sample count growing.
        //
        // Both coverages are now measured on the SAME frame, from the same projected quad,
        // differing only in which rect the ellipse was fitted to. That is a controlled
        // A/B and the caveat is gone because it is no longer true.
        double cover_pair_aabb_sum = 0.0;
        double cover_pair_mesh_sum = 0.0;
        unsigned long long cover_pair_n = 0;
        // How many frames offered a usable pair, and how many were skipped for want of a
        // second source. Printed, because a ratio over an unknown denominator is the same
        // mistake as a ratio over a wrong one.
        unsigned long long cover_pair_skipped = 0;
        // World-space containment margin per axis: how far the mesh's AABB pokes OUTSIDE
        // the box claiming to contain it. Positive = contained.
        float contain[3] = {0, 0, 0};
        int mesh_verts_projected = 0;
        int mesh_verts_behind = 0;
        int mask_points = 0;
        float cover_frac = 0.f;
    };
    inline defect_a g_defect_a{};

    // Tolerance for the containment test, in metres.
    //
    // 2026-10-01, revised after measurement. This was 1e-3 m, chosen as "large enough to
    // absorb float32 noise at 40 m from the origin". That reasoning was wrong in effect:
    // the real noise floor is the WHOLE TRANSFORM CHAIN, not one multiply. Composing the
    // lens parent chain and then transforming 61 vertices accumulates to ~1e-3 m, which is
    // exactly the tolerance. So the test was a coin flip against its own noise, and it
    // rejected 34% of frames (2720 of 8083) on margins of 0.3-0.6 mm.
    //
    // The observed margins on ACCEPTED frames, from the run that produced them:
    //     c0: -0.00098 .. +0.00283
    //     c1: -0.00076 .. -0.00001     <- Y is always negative
    //     c2: -0.00098 .. +0.00293
    // The AABB is a TIGHT fit. Every margin is inside +/-3 mm on a ~20 mm object, so this
    // is a well-behaved box and the rejections were entirely spurious.
    //
    // The test's actual job is to catch a box that describes a DIFFERENT OBJECT, which is
    // what the genuinely bad reads looked like: an extent of 0.00005 m on a lens whose real
    // extents are ~0.02 m -- three orders of magnitude out, not a rounding question. Those
    // are caught off by kBoundsMinExtent below, which is an unambiguous magnitude test.
    //
    // So containment is now a gross-error guard only: at 1e-2 m a violation means the mesh
    // pokes more than half the lens width outside the box claiming to contain it, which
    // cannot be rounding. Anything smaller is treated as float32 and ignored.
    inline constexpr float kBoundsContainEps = 1e-2f;

    // Floor on a single AABB extent, in metres. A real lens is ~0.02 m across; the bad
    // reads produced 0.00005 m. One millimetre sits an order of magnitude below the real
    // thing and two above the garbage, so it separates them without needing to know the
    // lens size in advance. Unambiguous, unlike the containment margin.
    inline constexpr float kBoundsMinExtent = 1e-3f;

    // Sentinel for the world-space mesh bounds accumulator.
    //
    // 2026-10-01. This was the first version's bug, and it is worth writing down because
    // it produced convincing garbage rather than an obvious failure. The accumulator was
    // `v3 mesh_wlo{}, mesh_whi{}` -- ZERO-initialised -- and then min/max-accumulated. A
    // min/max seeded at the origin silently INCLUDES the origin, so the "mesh bounds" were
    // really the bounds of the mesh union {0,0,0}.
    //
    // The lens sits near the world origin in X and Y, so two of the three axes came out
    // barely positive (~+0.0009 m) and looked like they were passing. Z is tens of metres
    // from the origin, so it failed by metres:
    //     contain=(+0.00108,+0.00004,-0.11555)m
    //     contain=(+0.00116,+0.00002,-1.23366)m
    // The margins were not a property of the data at all -- contain[2] was just the lens's
    // own world Z, which is why it tracked the player's position across the raid.
    //
    // The lesson is the one this whole file keeps relearning: an accumulator seeded with a
    // value that is also a plausible datum cannot be distinguished from correct output by
    // looking at the output. It was caught only because two axes disagreed by three orders
    // of magnitude, which is a shape no real geometry produces.
    inline constexpr float kWorldInf = 1e30f;

    struct route
    {
        bool valid = false;
        std::string reason;
        uintptr_t lens_native = 0;
        uintptr_t lens_transform_native = 0;
        uintptr_t optic_sight_managed = 0;
        uint32_t mesh_id = 0;
        uintptr_t material_native = 0;
        affine_map map{};
        uintptr_t scales_addr = 0, shifts_addr = 0, shift_dir_addr = 0;
        uintptr_t fov_nodes[3] = {0, 0, 0}; // HandsHierarchy.Self, Ribcage.Original, Weapon_Root_Third
        float lens_bounds_center[3] = {0, 0, 0};
        float lens_bounds_extents[3] = {0, 0, 0};

        // The lens MESH's own vertex positions, in the renderer's LOCAL space, kept so the
        // AABB-derived ellipse can be compared against the real projected silhouette.
        //
        // Why this exists. The cull region is an ellipse fitted to the renderer's world
        // AABB (spec line 533), but an AABB encloses the mesh: its corners stick out past
        // the geometry, and for a disc-shaped lens the box is the square around the circle.
        // Both make the fitted ellipse larger than the real opening, which is the shape of
        // the standing "mask covers ~1.16-1.22x too much" report. That has been a hypothesis
        // for several runs; this is the number that settles it. Over-coverage == 1.0 means
        // the AABB is tight and the excess is elsewhere (a clipping or a units error);
        // a ratio near sqrt(2) means it is the AABB circumscribing a round lens.
        //
        // Local space is correct and not a compromise: the AABB read at +0xE8 is in the
        // same local frame, and transforming both by the same matrix keeps the comparison
        // exact regardless of where the lens sits. Cached with the route because the mesh
        // is static; only the CAMERA moves per frame, and the projection is redone live.
        std::vector<v3> lens_mesh_local{};

        // Provenance, logged once when the route is accepted. Every value here took
        // a name-based or spec-constant lookup to obtain, so a single accepted-route
        // line is enough to re-derive the whole thing on a future build without
        // re-instrumenting. Cheap to carry (the route is cached), and it is the
        // difference between diagnosing a regression in one run and a week of it.
        int32_t cached_ptr_offset = 0; // resolved m_CachedPtr; optic_idea.md says 0x10
        // Which route produced the accepted shader name: 0 = spec's native path,
        // 1 = managed-API fallback. Printed on the accepted line so a fallback that never
        // fires is distinguishable from one that was never wired up.
        int32_t shader_name_source = 0;
        uint32_t mesh_vertices = 0;
        uint32_t mesh_indices = 0;
        uint32_t affine_pieces = 0;   // triangles clipped against the image square
        double affine_coverage = 0.0; // summed piece area; spec requires 0.01
        uint32_t mask_points = 0;     // filled per frame by the caller
    };

    // A compact identity signature for a route, for comparing two OpticSight objects that
    // the game appears to swap between.
    //
    // 2026-09-27: the route alternated on every rebuild (throttled to 1 Hz) between two
    // OpticSight objects 128 bytes apart, with DIFFERENT lens natives, DIFFERENT mesh
    // instance ids, and the SAME world bounds to within 0.0004 units. The staleness
    // predicate is pointer inequality, so each alternation dropped a good route and cost
    // a frame of fallback. Serialising the refresh removed the torn-packet half of the
    // race but cannot fix a predicate that is itself wrong.
    //
    // Whether the twins are genuinely interchangeable is not guessable from pointers --
    // every pointer-derived field differs. What IS comparable is the one thing both
    // instances agree on: the lens's world-space position. So this signature mixes both:
    // the identity fields expected to differ, and the bounds expected to match. One run
    // then shows which hypothesis holds.
    inline std::string route_signature(const route& r) {
        if (!r.valid) return "<invalid route>";
        return std::format(
            "lens=0x{:X} xform=0x{:X} mat=0x{:X} mesh={} bounds=({:.5f},{:.5f},{:.5f})",
            r.lens_native, r.lens_transform_native, r.material_native, r.mesh_id,
            static_cast<double>(r.lens_bounds_center[0]),
            static_cast<double>(r.lens_bounds_center[1]),
            static_cast<double>(r.lens_bounds_center[2]));
    }

    // Are two routes INTERCHANGEABLE for everything a route is actually consumed for?
    //
    // 2026-09-27, the fix for "ESP zoom takes a few ticks to switch, but it is still
    // visible". Measured cause, from the live log rather than inference:
    //
    //   The game alternates `CurrentOpticSight` between two adjacent instances roughly
    //   twice a second. `auto_k` -- which is 1/magnification -- flips between 0.166 and
    //   0.761 in lockstep, i.e. the two instances are DIFFERENT OPTICS (1.3x vs 6.0x), not
    //   two views of one optic. Each alternation trips the pointer-inequality staleness
    //   check, drops the route, and costs up to one second of radial fallback at the 1 Hz
    //   rebuild throttle. The ESP zoom is therefore stepping once or twice a second, and
    //   the user can see it switch.
    //
    //   Crucially the FOV difference is NOT part of the route: `combined` is rebuilt from
    //   the LIVE optic camera matrices every acquire (the route contributes only the
    //   affine map and the lens bounds). So a route built from either instance produces
    //   the same mask, and the magnification follows the camera regardless. Keeping the
    //   older route is therefore not a staleness compromise -- it is the correct answer,
    //   and it removes the fallback windows where the zoom is driven by a differently
    //   calibrated `auto_k`.
    //
    // The test is on the quantities the route CONSUMES, never on pointers, and the mesh
    // instance id is deliberately excluded: both instances instantiate the same asset
    // (`verts=66 indices=216 tris=72`, `affine pieces=24`, `coverage=0.01`) at
    // effectively the same place, so a different instance id is not a difference in the
    // mask. Tolerances are tight enough that a genuinely different scope -- different
    // geometry, or moved -- fails and the old pointer-inequality behaviour returns.
    inline bool routes_interchangeable(const route& a, const route& b) {
        if (!a.valid || !b.valid) return false;
        if (a.mesh_vertices != b.mesh_vertices) return false;
        if (a.mesh_indices != b.mesh_indices) return false;
        if (a.affine_pieces != b.affine_pieces) return false;
        if (std::fabs(a.affine_coverage - b.affine_coverage) > 1e-9) return false;
        constexpr float kPosTol = 0.01f; // 1 cm; observed twin delta was 0.0004
        for (int i = 0; i < 3; ++i)
        {
            if (std::fabs(a.lens_bounds_center[i] - b.lens_bounds_center[i]) > kPosTol)
                return false;
            if (std::fabs(a.lens_bounds_extents[i] - b.lens_bounds_extents[i]) > kPosTol)
                return false;
        }
        return true;
    }

    inline bool build_affine_map(const mesh_data& mesh, affine_map& out, std::string& why,
        uint32_t* out_pieces = nullptr, double* out_coverage = nullptr) {
        // Everything from the clip through the final comparison runs in double, and
        // the clipped vertices are STORED in double. Widening the mesh's float32 UVs
        // is lossless, so this cannot disagree with the game's data; it only stops
        // our own arithmetic from being the limiting factor.
        //
        // Why the storage matters (observed 2026-09-26): a clip vertex computed to sit
        // exactly on the image square's boundary is stored up to 0.5 ULP away from it
        // (~3e-8 at UV magnitude 0.55), and the barycentric inside-test divides that by
        // the triangle area, amplifying it by 1/|d|. At the observed |d|=5.778e-02 the
        // input alone contributed ~5e-7 -- already past the spec's -1e-7 tolerance.
        // Hence: no conditioning-scaled tolerance, and the spec's -1e-7 is kept as-is.
        using poly_t = std::vector<vd2>;

        // `min_bary` and `area` are diagnostics only. The reject is spec-mandated
        // (section 5) but the bare message conflates two very different worlds:
        //   min_bary just below -1e-7 with a tiny `d`  -> numerically ill-conditioned
        //                                               triangle, not a wrong result
        //   min_bary far from 0                        -> the mesh/UV decode genuinely
        //                                               disagrees with the spec's model
        auto point_on_triangle = [](const vd2& uv, const vd2& a, const vd2& b, const vd2& c,
                                     const vd3& A, const vd3& B, const vd3& C, vd3& r,
                                     double* min_bary = nullptr, double* area = nullptr) {
            const double d = cross2(b - a, c - a);
            if (min_bary) *min_bary = 0.0;
            if (area) *area = d;
            if (std::fabs(d) < 1e-12) return false;
            const double wb = cross2(uv - a, c - a) / d;
            const double wc = cross2(b - a, uv - a) / d;
            const double wa = 1.0 - wb - wc;
            if (min_bary)
                // Explicit template arg keeps the Windows `min` macro from expanding:
                // it is function-like, so it only fires when `(` follows the name.
                *min_bary = std::min<double>(wa, std::min<double>(wb, wc));

            // The spec's flat -1e-7, unmodified. It was unreachable in float32 because
            // the clip's own rounding dominated; with the clip and this blend in double
            // the achieved value is ~1e-15, so the spec's tolerance is now honest
            // rather than something to be negotiated upwards.
            if (wa < -1e-7 || wb < -1e-7 || wc < -1e-7) return false;
            r = A * wa + B * wb + C * wc;
            return true;
        };

        // First pass: candidate triangles that intersect the image square.
        const vd2 square[4] = {{0.45, 0.45}, {0.55, 0.45}, {0.55, 0.55}, {0.45, 0.55}};
        struct piece
        {
            poly_t uv;
            vd2 a, b, c;
            vd3 A, B, C;
        };
        std::vector<piece> pieces;
        pieces.reserve(16);

        for (size_t i = 0; i + 2 < mesh.indices.size(); i += 3)
        {
            const uint32_t ia = mesh.indices[i], ib = mesh.indices[i + 1], ic = mesh.indices[i + 2];
            // float32 -> double is exact, so these are the game's stored values, not
            // approximations of them.
            const vd2 a{mesh.uvs[ia].x, mesh.uvs[ia].y};
            const vd2 b{mesh.uvs[ib].x, mesh.uvs[ib].y};
            const vd2 c{mesh.uvs[ic].x, mesh.uvs[ic].y};
            const vd3 A{mesh.positions[ia].x, mesh.positions[ia].y, mesh.positions[ia].z};
            const vd3 B{mesh.positions[ib].x, mesh.positions[ib].y, mesh.positions[ib].z};
            const vd3 C{mesh.positions[ic].x, mesh.positions[ic].y, mesh.positions[ic].z};
            poly_t tri = {a, b, c};
            // counterclockwise
            if (poly_signed_area(tri) < 0.0) std::reverse(tri.begin(), tri.end());
            poly_t clipped = clip_polygon(tri, {square[0], square[1], square[2], square[3]});
            if (clipped.size() < 3 || std::fabs(poly_signed_area(clipped)) <= 1e-12) continue;
            if (pieces.size() >= 256)
            {
                why = "too many pieces";
                return false;
            }
            pieces.push_back({std::move(clipped), a, b, c, A, B, C});
        }
        if (pieces.empty())
        {
            why = "no triangle intersects image square";
            return false;
        }

        // Build the affine map from the first piece's triangle. Kept in double for
        // the validation below and narrowed once into `out` at the end, so there is a
        // single source of truth rather than a float map and a parallel double one.
        const piece& p0 = pieces.front();
        const vd2 duv_b = p0.b - p0.a, duv_c = p0.c - p0.a;
        const double d = cross2(duv_b, duv_c);
        if (std::fabs(d) < 1e-12)
        {
            why = "degenerate uv triangle";
            return false;
        }
        const vd3 AB = p0.B - p0.A, AC = p0.C - p0.A;
        const vd3 u_axis = (AB * duv_c.y - AC * duv_b.y) * (1.0 / d);
        const vd3 v_axis = (AC * duv_b.x - AB * duv_c.x) * (1.0 / d);
        const vd3 center = p0.A + u_axis * (0.5 - p0.a.x) + v_axis * (0.5 - p0.a.y);
        const auto local_from_uv = [&](const vd2& uv) {
            return center + u_axis * (uv.x - 0.5) + v_axis * (uv.y - 0.5);
        };

        // Validate every clipped vertex against the affine map; reject overlaps;
        // require the pieces to cover the full 0.01 area square.
        double total_area = 0.0;
        std::vector<poly_t> accepted;
        accepted.reserve(pieces.size());
        for (size_t pi = 0; pi < pieces.size(); ++pi)
        {
            const piece& pc = pieces[pi];
            for (size_t vi = 0; vi < pc.uv.size(); ++vi)
            {
                const vd2& uv = pc.uv[vi];
                vd3 tri_local{};
                double min_bary = 0.0, area = 0.0;
                if (!point_on_triangle(uv, pc.a, pc.b, pc.c, pc.A, pc.B, pc.C, tri_local,
                        &min_bary, &area))
                {
                    // Name the magnitude: that single number separates an
                    // ill-conditioned triangle from a genuine model mismatch.
                    why = std::format(
                        "vertex outside triangle (piece {}/{} v{}: minBary={:.3e} d={:.3e} "
                        "uv=({:.4f},{:.4f}) triUV=({:.4f},{:.4f})/({:.4f},{:.4f})/({:.4f},{:.4f}))",
                        pi, pieces.size(), vi, min_bary, area, uv.x, uv.y,
                        pc.a.x, pc.a.y, pc.b.x, pc.b.y, pc.c.x, pc.c.y);
                    return false;
                }
                const vd3 affine_local = local_from_uv(uv);
                const vd3 diff = tri_local - affine_local;
                // spec tolerance 1e-7 m, squared
                const double dist2 = diff.x * diff.x + diff.y * diff.y + diff.z * diff.z;
                if (dist2 > 1e-14)
                {
                    // Same ambiguity as above: report the magnitude so a marginal
                    // disagreement is distinguishable from a real mismatch.
                    why = std::format(
                        "triangle disagrees with affine map (piece {}/{} v{}: "
                        "dist={:.3e} m, spec tolerance 1e-7 m)",
                        pi, pieces.size(), vi, std::sqrt(dist2));
                    return false;
                }
            }
            for (const poly_t& prev : accepted)
            {
                poly_t overlap = clip_polygon(pc.uv, prev);
                if (overlap.size() >= 3 && std::fabs(poly_signed_area(overlap)) > 1e-10)
                {
                    why = "overlapping pieces";
                    return false;
                }
            }
            total_area += std::fabs(poly_signed_area(pc.uv));
            accepted.push_back(pc.uv);
        }
        if (std::fabs(total_area - 0.01) > 1e-8)
        {
            why = "pieces do not cover image square";
            return false;
        }
        const vd3 nrm = cross3(u_axis, v_axis);
        if (nrm.x * nrm.x + nrm.y * nrm.y + nrm.z * nrm.z < 1e-16)
        {
            why = "zero-area lens surface";
            return false;
        }
        // Single narrowing point: the route's consumers (the lens mask axes at the
        // projection site) want float v3s, and 0.5 ULP of a ~0.05 m lens position is
        // ~1e-9 m -- far below the 1e-7 m accuracy this map is validated to.
        out.u_axis = {static_cast<float>(u_axis.x), static_cast<float>(u_axis.y),
            static_cast<float>(u_axis.z)};
        out.v_axis = {static_cast<float>(v_axis.x), static_cast<float>(v_axis.y),
            static_cast<float>(v_axis.z)};
        out.center = {static_cast<float>(center.x), static_cast<float>(center.y),
            static_cast<float>(center.z)};
        out.valid = true;
        if (out_pieces) *out_pieces = static_cast<uint32_t>(pieces.size());
        if (out_coverage) *out_coverage = total_area;
        return true;
    }

    // Property-name registry lookup (section 4 of the doc).
    inline bool property_name(uint32_t id, std::string& out) {
        const uintptr_t u = unity_player_base();
        const uint32_t tag = id >> 30;
        const uint32_t index = id & 0x3FFFFFFFu;
        uintptr_t slot = 0;
        if (tag == 0)
        {
            uintptr_t root = 0;
            if (!read_ptr(u + 0x1A8E910, root) || !root) return false;
            uint32_t count = 0;
            if (!read_u32(root + 0x10, count) || index >= count || index > (1u << 20)) return false;
            uintptr_t slots = 0;
            if (!read_ptr(root, slots) || !slots) return false;
            slot = slots + static_cast<uintptr_t>(index) * 8;
        }
        else
        {
            uintptr_t table = 0;
            uint32_t last = 0;
            if (tag == 1)
            {
                table = u + 0x19FE2C0;
                last = 122;
            }
            else if (tag == 2)
            {
                table = u + 0x19FE6A0;
                last = 20;
            }
            else if (tag == 3)
            {
                table = u + 0x19FE750;
                last = 25;
            }
            else
                return false;
            if (index > last) return false;
            slot = table + static_cast<uintptr_t>(index) * 8;
        }
        uintptr_t name_ptr = 0;
        if (!read_ptr(slot, name_ptr) || !name_ptr) return false;
        char buf[129]{};
        if (!range_readable(name_ptr, 128)) return false;
        size_t n = 0;
        const char* s = reinterpret_cast<const char*>(name_ptr);
        while (n < 128 && s[n] != '\0') ++n;
        if (n == 0 || n >= 128) return false;
        std::memcpy(buf, s, n);
        out.assign(buf, n);
        return true;
    }

    inline bool resolve_material_vectors(uintptr_t material, route& r) {
        uintptr_t sheet_base = 0;
        if (!read_ptr(material + 0x108, sheet_base) || !sheet_base) return false;
        const uintptr_t sheet = sheet_base + 0x60;
        uintptr_t ids = 0, descriptors = 0, values = 0;
        uint64_t begin = 0, end = 0;
        int32_t bias = 0;
        if (!read_ptr(sheet + 0x10, ids) || !ids) return false;
        if (!read_ptr(sheet + 0x30, descriptors) || !descriptors) return false;
        if (!read_ptr(sheet + 0x50, values) || !values) return false;
        if (!read_u64(sheet + 0x80, begin) || !read_u64(sheet + 0x88, end)) return false;
        if (!read_i32(sheet + 0xC0, bias)) return false;
        if (begin > end || end > 256) return false;

        int found = 0;
        for (uint64_t i = begin; i < end; ++i)
        {
            uint32_t id = 0;
            if (!read_u32(ids + i * 4, id)) return false;
            std::string name;
            if (!property_name(id, name)) continue;
            if (name != "_Scales" && name != "_Shifts" && name != "_ShiftDirection") continue;
            uint64_t descriptor = 0;
            if (!read_u64(descriptors + i * 8, descriptor)) return false;
            if (descriptor & (1ull << 40)) return false; // color conversion
            const uint32_t off = static_cast<uint32_t>(descriptor & 0xFFFFFull);
            const uintptr_t addr = values + static_cast<uintptr_t>(bias + static_cast<int32_t>(off));
            if (name == "_Scales")
            {
                r.scales_addr = addr;
                ++found;
            }
            else if (name == "_Shifts")
            {
                r.shifts_addr = addr;
                ++found;
            }
            else
            {
                r.shift_dir_addr = addr;
                ++found;
            }
        }
        return found == 3;
    }

    // The one shader whose image-placement math section 5 of optic_idea.md reproduces.
    // Section 3 is emphatic that this must be checked by name, not inferred from the
    // presence of familiar properties: "a different shader may place or distort the image
    // differently." Section 4's `require len(addresses) == 3` is a decent secondary
    // signal but is not a substitute.
    inline constexpr const char* kOpticSightShaderName = "CW FX/OpticSight";

    inline bool shader_name(uintptr_t shader, std::string& out) {
        auto native_string = [](uintptr_t addr, std::string& s) {
            uint8_t inline_flag = 0;
            if (!read_u8(addr + 0x20, inline_flag)) return false;
            if (inline_flag == 1)
            {
                int8_t len_byte = 0;
                if (!read_pod(addr + 0x18, len_byte)) return false;
                const int length = 24 - static_cast<int>(len_byte);
                if (length < 0 || length > 24) return false;
                if (length == 0)
                {
                    s.clear();
                    return true;
                }
                if (!range_readable(addr, static_cast<size_t>(length))) return false;
                s.assign(reinterpret_cast<const char*>(addr), static_cast<size_t>(length));
                return true;
            }
            uint64_t length = 0;
            if (!read_u64(addr + 0x10, length) || length > 128) return false;
            if (length == 0)
            {
                s.clear();
                return true;
            }
            uintptr_t data = 0;
            if (!read_ptr(addr, data) || !data) return false;
            if (!range_readable(data, static_cast<size_t>(length))) return false;
            s.assign(reinterpret_cast<const char*>(data), static_cast<size_t>(length));
            return true;
        };

        const uintptr_t u = unity_player_base();
        uintptr_t klass = 0;
        // Native object -> native class pointer: compare against the native
        // type-descriptor address. A name lookup is not possible here (and a managed
        // class check would read ->parent off the wrong layout).
        if (!read_ptr(shader, klass) || !matches_native_class(klass, 0x1743CD0))
            return false;
        uintptr_t parsed = 0;
        if (read_ptr(shader + 0x3D0, parsed) && parsed)
        {
            if (native_string(parsed + 0x80, out)) return true;
        }
        return native_string(shader + 0x78, out);
    }

    // The shader name through Unity's own managed API, as a FALLBACK for the native
    // read above.
    //
    // 2026-09-28. The spec (section 3) specifies the native route and this file
    // implements it faithfully: material+0x60 -> instance-table hash -> shader+0x3D0
    // -> native byte string at +0x80, falling back to +0x78. That is four
    // build-fragile offsets plus a hand-rolled hash walk. This is the same question
    // asked through the managed ABI, which cannot drift when an offset moves:
    //
    //     Renderer.get_sharedMaterial() -> Material
    //     Material.get_shader()         -> Shader
    //     Shader.get_name()             -> System.String*  (managed UTF-16)
    //     il2utils::conv_string()       -> std::string     (already in il2utils.h)
    //
    // It is deliberately a FALLBACK and not a replacement. The native path is what the
    // spec asks for and it is verified working; churning a verified check for a
    // robustness argument is how Defect B happened. What this buys is that a game update
    // which invalidates +0x60/+0x3D0/+0x80/+0x78 degrades to "slower, noisier" instead of
    // "silently accepts a different shader" -- and the route's own diagnostic already
    // admits (+0x170/+0x180/+0xE8/+0x122/+0x25C are unverified on this build), so that
    // day is not hypothetical.
    //
    // NOTE this resolves the name only. resolve_material_vectors() still needs the
    // native material pointer for the property sheet, and that continues to come from
    // the instance table; see the call site for how the two paths are reconciled.
    inline std::string shader_name_via_managed(Il2CppObject* lens_renderer_managed) {
        if (!lens_renderer_managed || !lens_renderer_managed->klass) return {};
        // A dead managed wrapper keeps a valid klass after the native side is gone
        // (scene unload), which is exactly how a stale route looks. Do not call into it.
        if (!unity::is_unity_object_alive(lens_renderer_managed, "optics/lens_renderer")) return {};

        Il2CppObjectInstance lens_inst(lens_renderer_managed);
        // sharedMaterial, never material: `material` INSTANTIATES a copy, which is a
        // side effect on a renderer we do not own and can return null in edit mode.
        const auto get_shared_material =
            lens_inst.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_sharedMaterial", 0, false);
        if (!get_shared_material) return {};
        Il2CppObject* material = get_shared_material(lens_renderer_managed);
        if (!material || !unity::is_unity_object_alive(material, "optics/material")) return {};

        Il2CppObjectInstance mat_inst(material);
        const auto get_shader =
            mat_inst.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_shader", 0, false);
        if (!get_shader) return {};
        Il2CppObject* shader = get_shader(material);
        if (!shader || !unity::is_unity_object_alive(shader, "optics/shader")) return {};

        Il2CppObjectInstance shader_inst(shader);
        const auto get_name =
            shader_inst.get_method<Il2CppString* (*)(Il2CppObject*)>("get_name", 0, false);
        if (!get_name) return {};
        return il2utils::conv_string(get_name(shader));
    }

    // FOV-node addresses from the local player (managed reads only).
    inline bool resolve_fov_nodes(Il2CppObject* local_player, route& r) {
        if (!local_player || !local_player->klass) return false;
        auto node_of = [](Il2CppObject* transform_obj, uintptr_t& node) {
            if (!transform_obj) return false;
            const uintptr_t nt = native_of(transform_obj);
            if (!nt) return false;
            uintptr_t hierarchy = 0;
            uint32_t index = 0;
            if (!read_ptr(nt + 0x70, hierarchy) || !hierarchy) return false;
            if (!read_u32(nt + 0x78, index) || index >= 65536) return false;
            uintptr_t nodes = 0;
            if (!read_ptr(hierarchy + 0x68, nodes) || !nodes) return false;
            node = nodes + static_cast<uintptr_t>(index) * 48;
            return true;
        };

        Il2CppObjectInstance player(local_player);
        const auto get_hands = player.get_method<Il2CppObject* (*)(Il2CppObject*)>(
            "get_HandsController", 0, false);
        Il2CppObject* hands = get_hands ? get_hands(local_player) : nullptr;
        uintptr_t hands_self_native = 0;
        if (hands)
        {
            const uintptr_t hierarchy_managed =
                read_managed_ref_field(hands, "_handsHierarchy");
            if (hierarchy_managed)
                hands_self_native = read_managed_ref_field(
                    reinterpret_cast<Il2CppObject*>(hierarchy_managed), "Self");
        }

        Il2CppObject* player_body = nullptr;
        if (const auto get_body = player.get_method<Il2CppObject* (*)(Il2CppObject*)>(
                "get_PlayerBody", 0, false))
            player_body = get_body(local_player);
        Il2CppObject* player_bones = player_body
            ? reinterpret_cast<Il2CppObject*>(read_managed_ref_field(player_body, "PlayerBones"))
            : nullptr;
        Il2CppObject* ribcage_orig = nullptr;
        Il2CppObject* weapon_root = nullptr;
        if (player_bones)
        {
            Il2CppObject* ribcage = reinterpret_cast<Il2CppObject*>(
                read_managed_ref_field(player_bones, "Ribcage"));
            if (ribcage)
                ribcage_orig = reinterpret_cast<Il2CppObject*>(
                    read_managed_ref_field(ribcage, "Original"));
            weapon_root = reinterpret_cast<Il2CppObject*>(
                read_managed_ref_field(player_bones, "Weapon_Root_Third"));
        }

        const auto transform_of = [](Il2CppObject* component) -> Il2CppObject* {
            if (!component) return nullptr;
            Il2CppObject* go = unity::component_get_game_object(component);
            return go ? unity::gameobject_get_transform(go) : nullptr;
        };

        uintptr_t n0 = 0, n1 = 0, n2 = 0;
        const bool ok =
            node_of(transform_of(reinterpret_cast<Il2CppObject*>(hands_self_native)), n0) & node_of(ribcage_orig, n1) & node_of(weapon_root, n2);
        if (!ok) return false;
        r.fov_nodes[0] = n0;
        r.fov_nodes[1] = n1;
        r.fov_nodes[2] = n2;
        return true;
    }

    // Build/refresh the static route from the active optic sight.
    inline bool build_route(Il2CppObject* local_player, route& r, std::string& why) {
        const uintptr_t u = unity_player_base();
        if (!local_player)
        {
            why = "no local player";
            return false;
        }

        // CameraManager singleton -> OpticCameraManager -> CurrentOpticSight.
        Il2CppImage* img = il2utils::resolve_image("Assembly-CSharp.dll");
        if (!img)
        {
            why = "no Assembly-CSharp";
            return false;
        }
        const Il2CppClass* cm_class = il2utils::resolve_class(img, "EFT.CameraControl", "CameraManager");
        if (!cm_class)
        {
            why = "no CameraManager class";
            return false;
        }
        uintptr_t cm_managed = 0;
        if (cm_class->static_fields)
            std::memcpy(&cm_managed, cm_class->static_fields, sizeof(void*));
        if (!cm_managed)
        {
            why = "CameraManager singleton null";
            return false;
        }

        uintptr_t optic_cam_manager_managed =
            read_managed_ref_field(reinterpret_cast<Il2CppObject*>(cm_managed), "OpticCameraManager");
        if (!optic_cam_manager_managed)
        {
            why = "no OpticCameraManager";
            return false;
        }
        uintptr_t sight_managed =
            read_managed_ref_field(reinterpret_cast<Il2CppObject*>(optic_cam_manager_managed),
                "<CurrentOpticSight>k__BackingField");
        if (!sight_managed)
        {
            why = "no CurrentOpticSight";
            return false;
        }

        uintptr_t lens_renderer_managed =
            read_managed_ref_field(reinterpret_cast<Il2CppObject*>(sight_managed), "LensRenderer");
        if (!lens_renderer_managed)
        {
            why = "no LensRenderer";
            return false;
        }
        const uintptr_t lens_native = native_of(reinterpret_cast<Il2CppObject*>(lens_renderer_managed));
        if (!lens_native)
        {
            why = "LensRenderer native null";
            return false;
        }

        // ---- NATIVE LAYOUT FINGERPRINT (optic_idea.md section 2) ----------------
        // The spec hard-requires:
        //     require readPtr(lens)       == U + 0x17B0FC8   // MeshRenderer
        //     require readPtr(lens + 0x60) == U + 0x17B1100   // material-array subobject
        //
        // These are the ONLY checks that prove the native Renderer layout is what the
        // rest of this route assumes, because everything below reads +0x170/+0x180
        // (material ids), +0xE8/+0xF4 (bounds), +0x122 (static batch) and +0x25C
        // (vertex stream) straight off that object.
        //
        // They were dropped on 2026-09-26 while chasing an unrelated garbage-class-name
        // bug, and replaced with a MANAGED type check — which says nothing about the
        // native layout. That was the wrong trade: it removed the only guard against a
        // layout shift and would let the route proceed and read wrong values.
        //
        // Restored as a WARNING rather than a hard reject. A hard reject would either
        // work (constants current) or leave the route permanently dead with the same
        // information; warning reports the observed value either way, so the constants
        // can be re-derived from the log if BSG moved them.
        //
        // Note the downstream checks still provide partial protection: mat_count==1
        // and the mesh decode both read the same object, so a moved layout is likely
        // to fail there too — but with a far less informative reason.
        {
            static bool s_fingerprint_logged = false;
            uintptr_t native_klass = 0, mat_sub_raw = 0;
            const bool have_klass = read_ptr(lens_native, native_klass) && native_klass != 0;
            const bool have_sub = read_ptr(lens_native + 0x60, mat_sub_raw) && mat_sub_raw != 0;
            const bool klass_ok = have_klass && native_klass == u + 0x17B0FC8;
            const bool sub_ok = have_sub && mat_sub_raw == u + 0x17B1100;
            if (!klass_ok || !sub_ok)
            {
                if (!s_fingerprint_logged)
                {
                    s_fingerprint_logged = true;
                    logger::warn(std::format(
                        "optic native layout MISMATCH (spec 2): {}",
                        std::string("lens[0x00]=") + (have_klass ? std::format("U+0x{:X} (expected U+0x17B0FC8)", native_klass - u) : std::string("unreadable"))
                            + ", " + "lens[0x60]=" + (have_sub ? std::format("U+0x{:X} (expected U+0x17B1100)", mat_sub_raw - u) : std::string("unreadable"))
                            + " -- +0x170/+0x180/+0xE8/+0x122/+0x25C are unverified on this build"));
                }
            }
            else if (!s_fingerprint_logged)
            {
                s_fingerprint_logged = true;
                logger::debug("optic native layout fingerprint OK (spec 2 constants current)");
            }
        }

        // Class + material-array sanity (doc section 2).
        //
        // Identity is checked on the MANAGED object (->klass), never on the native
        // one. A native engine object's leading word is Unity's internal class
        // pointer, not a managed Il2CppClass, so reading ->name from it returns code
        // bytes. unity_engine_class() returns a real managed Il2CppClass*, so the
        // comparison (and the ->parent walk for subclasses) is layout-safe on both
        // sides.
        //
        // The declared type is UnityEngine.Renderer, NOT MeshRenderer: the ISIL shows
        // OpticSight using `this.LensRenderer (UnityEngine.Renderer)` in every access
        // (Renderer.GetSharedMaterial, Component.get_transform). matches_class_native
        // is subclass-accepting, so the base class accepts MeshRenderer and friends.
        const uintptr_t managed_klass =
            reinterpret_cast<uintptr_t>(reinterpret_cast<Il2CppObject*>(lens_renderer_managed)->klass);
        const uintptr_t renderer_klass = unity_engine_class("UnityEngine", "Renderer");
        if (!matches_managed_class(managed_klass, renderer_klass))
        {
            why = "not a Renderer (managed class='" + class_name_of(managed_klass)
                + "', name_lookup=" + (renderer_klass ? "ok" : "MISS") + ")";
            return false;
        }

        // Native material array. The class is NOT identity-checked here: this is a
        // native sub-object whose layout is Unity-internal, and the old check
        // (compare to a hardcoded class id) was both build-fragile and unsound. The
        // read stays guarded, and the mesh/material/affine validation downstream is
        // what actually proves the object is usable.
        uintptr_t mat_sub = 0;
        if (!read_ptr(lens_native + 0x60, mat_sub) || !mat_sub)
        {
            why = "material-array subobject null";
            return false;
        }
        // Reject extra geometry handling routes.
        uint16_t static_batch = 0;
        uint32_t stream_id = 0;
        if (read_u16(lens_native + 0x122, static_batch) && static_batch != 0)
        {
            why = "static-batch submeshes unsupported";
            return false;
        }
        if (read_u32(lens_native + 0x25C, stream_id) && stream_id != 0)
        {
            why = "extra vertex stream unsupported";
            return false;
        }

        // ---- MANAGED chain (name-resolved, build-stable) ----------------------
        // Everything reachable from a managed Il2CppObject* is fetched through the
        // managed API rather than by walking native component arrays. The previous
        // approach needed a Unity *native type descriptor* (a build-specific address
        // with no by-name search) just to find a Transform, and it rejected on the
        // current build as `no Transform`.
        //
        // OpticSight's own code does exactly this (ISIL: `Component.get_transform,
        // this.LensRenderer (UnityEngine.Renderer)`), so following the same chain is
        // the verified path, not a guess.
        auto* lens_comp = reinterpret_cast<Il2CppObject*>(lens_renderer_managed);
        Il2CppObject* lens_go_managed = unity::component_get_game_object(lens_comp);
        if (!lens_go_managed)
        {
            why = "no lens GameObject (managed)";
            return false;
        }

        Il2CppObject* transform_managed = unity::gameobject_get_transform(lens_go_managed);
        if (!transform_managed)
        {
            why = "no Transform (managed get_transform)";
            return false;
        }
        const uintptr_t transform_native = native_of(transform_managed);
        if (!transform_native)
        {
            why = "Transform native null";
            return false;
        }

        Il2CppObject* mesh_filter_managed = nullptr;
        if (Il2CppObject* mf_type = system_type_for("UnityEngine", "MeshFilter"))
            mesh_filter_managed = unity::gameobject_get_component(lens_go_managed, mf_type);
        if (!mesh_filter_managed)
        {
            why = "no MeshFilter (managed)";
            return false;
        }
        const uintptr_t mesh_filter_native = native_of(mesh_filter_managed);
        if (!mesh_filter_native)
        {
            why = "MeshFilter native null";
            return false;
        }

        // Mesh via MeshFilter.get_mesh(), instance id via Object.GetInstanceID() —
        // both managed, so neither depends on a native field offset.
        Il2CppObjectInstance mesh_filter_inst(mesh_filter_managed);
        const auto get_mesh = mesh_filter_inst.get_method<Il2CppObject* (*)(Il2CppObject*)>(
            "get_mesh", 0);
        Il2CppObject* mesh_managed = get_mesh ? get_mesh(mesh_filter_managed) : nullptr;
        if (!mesh_managed)
        {
            why = "MeshFilter.get_mesh() null";
            return false;
        }
        const uint32_t mesh_id = managed_instance_id(mesh_managed);
        if (mesh_id == 0)
        {
            why = "mesh GetInstanceID() == 0";
            return false;
        }
        uintptr_t mesh_native = 0;
        if (!instance_from_id(mesh_id, mesh_native) || !mesh_native)
        {
            why = "mesh instance missing";
            return false;
        }

        // ---- NATIVE chain (no managed equivalent) -----------------------------
        // Only what the managed API does not expose. lens_go is the NATIVE GameObject
        // (Component.m_GameObject) and is used solely for native-only reads.
        uintptr_t lens_go = 0;
        if (!read_ptr(lens_native + 0x58, lens_go) || !lens_go)
        {
            why = "no lens GO";
            return false;
        }
        uintptr_t back = 0;
        if (!read_ptr(transform_native + 0x58, back) || back != lens_go)
        {
            why = "transform backref";
            return false;
        }
        if (!read_ptr(mesh_filter_native + 0x58, back) || back != lens_go)
        {
            why = "meshfilter backref";
            return false;
        }

        uint32_t mat_count = 0;
        if (!read_u32(lens_native + 0x180, mat_count) || mat_count != 1)
        {
            why = "expected 1 material";
            return false;
        }
        uintptr_t mat_ids = 0;
        if (!read_ptr(lens_native + 0x170, mat_ids) || !mat_ids)
        {
            why = "no material ids";
            return false;
        }
        uint32_t material_id = 0;
        if (!read_u32(mat_ids, material_id))
        {
            why = "no material id";
            return false;
        }
        uintptr_t material_native = 0;
        if (!instance_from_id(material_id, material_native) || !material_native)
        {
            why = "material instance missing";
            return false;
        }

        // Shader must be CW FX/OpticSight (instance ID at material +0x60).
        //
        // Primary is the spec's native route. The managed fallback exists so that a build
        // which moves those offsets still gets a correct verdict instead of a silent
        // accept -- see shader_name_via_managed(). Which path produced the accepted name is
        // recorded in the route and printed on the accepted-route line, because a fallback
        // that quietly never fires is indistinguishable from one that is not wired up.
        int32_t shader_source = 0; // 0 native, 1 managed fallback
        std::string shname;
        {
            // Spec section 3: shader instance ID at material +0x60, resolved through the
            // object-instance table. If ANY of that fails the native route simply yields no
            // name and the managed fallback below decides -- which is the whole point.
            uint32_t shader_id = 0;
            uintptr_t shader_native = 0;
            if (read_u32(material_native + 0x60, shader_id) && shader_id != 0 && instance_from_id(shader_id, shader_native) && shader_native)
            {
                if (!shader_name(shader_native, shname)) shname.clear();
            }
        }
        if (shname != kOpticSightShaderName)
        {
            // Stored as uintptr_t by the caller (L1144), so the cast is the same one
            // native_of() already applies a few hundred lines above.
            const std::string managed = shader_name_via_managed(
                reinterpret_cast<Il2CppObject*>(lens_renderer_managed));
            if (managed == kOpticSightShaderName)
            {
                shname = managed;
                shader_source = 1;
            }
            else
            {
                // Both names in the reason: if a game update renames the shader, the
                // reject line says so outright instead of leaving us to re-instrument.
                why = "shader is not CW FX/OpticSight (native='" + shname + "' managed='" + managed + "')";
                return false;
            }
        }
        r.shader_name_source = shader_source;

        if (!resolve_material_vectors(material_native, r))
        {
            why = "material vectors missing";
            return false;
        }

        mesh_data mesh;
        if (!read_mesh(mesh_native, mesh))
        {
            why = "mesh decode failed";
            return false;
        }
        if (!build_affine_map(mesh, r.map, why, &r.affine_pieces, &r.affine_coverage)) return false;
        r.mesh_vertices = static_cast<uint32_t>(mesh.positions.size());
        r.mesh_indices = static_cast<uint32_t>(mesh.indices.size());

        if (!resolve_fov_nodes(local_player, r))
        {
            why = "fov nodes missing";
            return false;
        }

        // Renderer world bounds: center XYZ at +0xE8, extents XYZ at +0xF4.
        if (!range_readable(lens_native + 0xE8, 24))
        {
            why = "no bounds";
            return false;
        }
        std::memcpy(r.lens_bounds_center, reinterpret_cast<const void*>(lens_native + 0xE8), 12);
        std::memcpy(r.lens_bounds_extents, reinterpret_cast<const void*>(lens_native + 0xF4), 12);

        // Retain the mesh for the AABB-vs-silhouette measurement (see lens_mesh_local).
        // Best-effort: the ellipse does not depend on it, so a failure here must not
        // reject the route. The count is reported so "empty because the read failed" is
        // distinguishable from "empty because the mesh really has no vertices".
        r.lens_mesh_local = mesh.positions;
        if (r.lens_mesh_local.empty())
            logger::warn(std::format(
                "optic-defectA: mesh silhouette UNAVAILABLE on this route (lens=U+0x{:X} "
                "id={} verts={} indices={}) -- the AABB-vs-silhouette over-coverage ratio "
                "cannot be measured this run, so treat the mask over-coverage number as "
                "unattributed",
                static_cast<unsigned>(lens_native - unity_player_base()),
                mesh_id, r.mesh_vertices, r.mesh_indices));

        r.lens_native = lens_native;
        r.lens_transform_native = transform_native;
        r.optic_sight_managed = sight_managed;
        r.mesh_id = mesh_id;
        r.material_native = material_native;
        r.cached_ptr_offset = cached_ptr_offset(nullptr);
        r.valid = true;
        r.reason = "ok";

        // Accepted-route provenance. Fires once per accepted route (the caller caches
        // on r.valid), so this is an on-change diagnostic, not a per-frame log.
        //
        // Rationale: getting here took four rounds of misdiagnosis, and every input
        // below was obtained by a name-based lookup or a hand-derived spec constant.
        // If a future build regresses this, the reject reason alone will not say what
        // the values WERE on the last good build -- and re-deriving them means
        // re-instrumenting and another in-game round. One accepted line is a complete
        // baseline. Native pointers are printed as offsets from their module base so
        // they stay comparable across runs and ASLR.
        {
            const uintptr_t u = unity_player_base();
            const auto off = [u](uintptr_t p) -> const char* {
                static thread_local char buf[4][32];
                static thread_local int slot = 0;
                char* b = buf[slot = (slot + 1) & 3];
                if (p > u)
                    std::snprintf(b, 32, "U+0x%X", static_cast<unsigned>(p - u));
                else
                    std::snprintf(b, 32, "0x%llX", static_cast<unsigned long long>(p));
                return b;
            };
            logger::info(std::format(
                "optic-route: mesh id={} verts={} indices={} tris={} | affine pieces={} "
                "coverage={:.9f} (spec 0.01) | m_CachedPtr=+0x{:X} (spec 0x10)\n"
                "optic-route:   lens={} transform={} material={} sight=0x{:X}\n"
                "optic-route:   map center=({:.6f},{:.6f},{:.6f}) u=({:.5f},{:.5f},{:.5f}) "
                "v=({:.5f},{:.5f},{:.5f})\n"
                "optic-route:   bounds c=({:.5f},{:.5f},{:.5f}) e=({:.5f},{:.5f},{:.5f})\n"
                "optic-route:   fov nodes=0x{:X}/0x{:X}/0x{:X} scales={} shifts={} shiftDir={}\n"
                "optic-route:   shader='{}' name_via={}",
                r.mesh_id, r.mesh_vertices, r.mesh_indices, r.mesh_indices / 3,
                r.affine_pieces, r.affine_coverage, static_cast<unsigned>(r.cached_ptr_offset),
                off(r.lens_native), off(r.lens_transform_native), off(r.material_native),
                static_cast<unsigned>(r.optic_sight_managed),
                r.map.center.x, r.map.center.y, r.map.center.z,
                r.map.u_axis.x, r.map.u_axis.y, r.map.u_axis.z,
                r.map.v_axis.x, r.map.v_axis.y, r.map.v_axis.z,
                r.lens_bounds_center[0], r.lens_bounds_center[1], r.lens_bounds_center[2],
                r.lens_bounds_extents[0], r.lens_bounds_extents[1], r.lens_bounds_extents[2],
                static_cast<unsigned>(r.fov_nodes[0]), static_cast<unsigned>(r.fov_nodes[1]),
                static_cast<unsigned>(r.fov_nodes[2]),
                off(r.scales_addr), off(r.shifts_addr), off(r.shift_dir_addr),
                kOpticSightShaderName,
                r.shader_name_source == 1 ? "managed-fallback" : "native"));
        }
        return true;
    }

    // Managed optic Camera straight from the CameraManager singleton — immune to
    // Unity object naming differences across scopes/builds.
    inline Il2CppObject* optic_camera_from_manager() {
        Il2CppImage* img = il2utils::resolve_image("Assembly-CSharp.dll");
        if (!img) return nullptr;
        const Il2CppClass* cm_class = il2utils::resolve_class(img, "EFT.CameraControl", "CameraManager");
        if (!cm_class || !cm_class->static_fields) return nullptr;
        uintptr_t cm_managed = 0;
        std::memcpy(&cm_managed, cm_class->static_fields, sizeof(void*));
        if (!cm_managed) return nullptr;
        const uintptr_t optic_mgr = read_managed_ref_field(
            reinterpret_cast<Il2CppObject*>(cm_managed), "OpticCameraManager");
        if (!optic_mgr) return nullptr;
        const uintptr_t cam = read_managed_ref_field(
            reinterpret_cast<Il2CppObject*>(optic_mgr), "Camera");
        return reinterpret_cast<Il2CppObject*>(cam);
    }

    // -------------------------------------------------------- per-frame sample
    struct packet
    {
        bool valid = false;
        mat4 combined{};      // optic NDC -> main screen mapping (rows 0,1,3)
        mat4 optic_vp{};      // paired optic view-projection (point entry)
        v2 image_quad[4]{};   // main-screen NDC corners of the optic image
        std::vector<v2> mask; // visible region polygon in main-screen NDC

        // Descriptive scoped-mapping values, recomputed every frame because the material
        // vectors they depend on are live and animated.
        //
        // CORRECTION (2026-09-26): these were previously published as
        // `centre_error_ndc` / `corner_error_ndc` and treated as a pass/fail self-check
        // derived from optic_idea.md line 578 ("optic NDC (0,0) must land at the
        // shader-adjusted mesh-UV center, and the four NDC corners must agree with
        // imageQuad"). That was wrong, and the large values it reported were
        // meaningless.
        //
        // The spec's own construction (lines 510-529) is:
        //     combined.row(r) = (HU[r]*opticVP.row(0) + HV[r]*opticVP.row(1)
        //                        + HC[r]*opticVP.row(3)) / HC.w
        //     imageQuad[i]    = (HC + HU*cx + HV*cy).xy / corner.w
        //                        with corner.w = HC.w + HU.w*cx + HV.w*cy
        // `combined` divides by the CONSTANT HC.w; `imageQuad` divides by the
        // PER-CORNER corner.w. So combined*(+/-1,+/-1,0,1) is not an identity for
        // imageQuad[i] even when the implementation is a faithful port -- and a large
        // "corner error" is the expected consequence of the spec's formulas, not
        // evidence of a broken mapping. Reporting it as a verdict sent this whole
        // investigation down a false path.
        //
        // What is kept is descriptive only: where optic NDC (0,0) actually lands, and
        // the extent of the projected lens image. Those are unambiguous and useful for
        // eyeballing whether the scope picture is plausibly sized and centred.
        v2 centre_landing{}; // combined * (0,0,0,1), normalised
        v2 quad_lo{};        // image_quad bounding box, NDC
        v2 quad_hi{};

        // Live material vectors, captured per accepted packet. The route-acceptance log
        // prints their ADDRESSES but never their values, yet the whole section 7
        // placement is driven by them -- and since the affine map's centre is exactly
        // (0,0,0) on this build, the on-screen position of the scope picture is decided
        // entirely by `shift_dir * shifts.x`. Without the values there is no way to tell
        // a correct offset from a wrong one.
        v4 scales{}, shifts{}, shift_dir{};
        v4 lens_basis_hc{}; // HC, the projected mesh-UV centre
        v4 lens_basis_hu{}, lens_basis_hv{};
        // Section 7 conditioning. `combined` divides by row 3, whose value is
        // (HU.w*vp.m3 + HV.w*vp7 + HC.w*vp.m15) / HC.w, while the numerator is the
        // analogous row 0. When the two are nearly equal the ratio is catastrophically
        // cancelling, and because the camera matrices are live the result swings wildly
        // frame to frame. Observed 2026-09-26: the scope picture's landing point ranged
        // over +/-32000 px between samples with CONSTANT material vectors, which is this.
        float w_gate_margin = 0.f; // HC.w - |HU.w| - |HV.w|; the spec's own gate
        float combined_w = 0.f;    // combined.at(3,3) -- the divisor

        // Elements of the two view-projection matrices that decide section 7.
        //
        // Working hypothesis for the observed sign flip (combined.w = +45 vs -3.465):
        // since HC[3] == HC.w, the third term of the spec's row-3 formula collapses to
        // exactly vp.at(3,3), while vp.at(0,3) and vp.at(1,3) are ~0 for a perspective
        // projection and HU.w/HV.w are ~1e-5. So
        //     combined.at(3,3) ~= optic_vp.at(3,3)
        // and for VP = P*V, row 3 of VP is -row 2 of V, so at(3,3) is (minus) the
        // camera's view-space Z translation -- i.e. its distance from the WORLD ORIGIN,
        // which passes through zero as the player moves. That would make the divisor
        // scene-origin dependent, which is a hole in the spec rather than in the port.
        //
        // These five numbers confirm or kill that in one run. m11 is included as a
        // sanity check: for a real projection matrix it is -1 (GL-style) or +1/far
        // (reversed-Z), so a value that is neither means the read at +0xE8 is not a
        // projection matrix at all and everything downstream is suspect.
        float optic_vp_m15 = 0.f; // at(3,3) -- dominant term of the row-3 divisor
        float optic_vp_m03 = 0.f; // at(0,3)
        float optic_vp_m13 = 0.f; // at(1,3)
        float optic_vp_m11 = 0.f; // at(1,1) -- projection signature
        float main_vp_m15 = 0.f;

        // Section 7's PRIMARY mapping chain, carried in the packet so projection does
        // not need the route.
        //
        // The spec offers TWO constructions and they are NOT equivalent:
        //   primary  (lines 492-493):  meshUV = opticNDC * 0.05 + 0.5
        //                               local  = localFromUV(meshUV)
        //   shortcut (lines 516-523):  combined.row(r) = (...)/HC.w
        //
        // `localFromUV(u,v) = center + Uaxis*(u-0.5) + Vaxis*(v-0.5)`, so the primary
        // chain for an arbitrary optic NDC `n` is a lens-local point
        //     A + B*n.x + C*n.y,   A = center*sx + shift*shifts,  B = Uaxis*sx*0.05,
        //                                C = Vaxis*sx*0.05
        // projected through `lens_view` with w = 1. At the four corners that is exactly
        // `HC +/- HU +/- HV`, i.e. `imageQuad` -- which is precisely the agreement the
        // spec's own line-578 test demands ("the four NDC corners must agree with
        // imageQuad") and precisely what the `combined` shortcut does NOT deliver.
        //
        // MEASURED (2026-09-27): with `combined`, the scope picture landed at ndc x
        // -1.55 to -1.97 (px -528 to -929) while `image_quad` stayed centred on the
        // origin. So the shortcut projected ESP to off-screen coordinates, which is the
        // reported "1x hides everything". The shortcut's row-3 divisor is also
        // scene-origin dependent (it collapses to optic_vp.m15, the camera's distance
        // from the world origin), which is why it drifts and flips sign.
        v3 map_center{}, map_u{}, map_v{};
        mat4 lens_view{}; // main_vp * lens_m

        // Residual of the line-578 corner test under the PRIMARY chain. Should be ~0
        // (float rounding only); a large value means the chain does not reproduce
        // imageQuad and projection would again disagree with the fitted mask.
        float corner_agreement_ndc = 0.f;
    };

    // Records the descriptive scoped-mapping values. Takes `packet&` because it writes
    // them back into the packet. `corners` is the CCW quad {(-1,-1),(1,-1),(1,1),(-1,1)}.
    inline void record_scoped_mapping(packet& p, const float (&corners)[4][2],
        const v3& map_center, const v3& map_u, const v3& map_v,
        const mat4& lens_view) {
        // RETRACTION (2026-09-29 20:05). This used to open with `if (!p.valid) return;`
        // and the guard was LOAD-BEARING in the most dangerous way imaginable: it looked
        // like defensive hygiene and was actually the only reason the diagnostics below
        // ever ran at all.
        //
        // What happened: `out.valid` was set true before this call and false on every
        // rejection after it. That looked like a plain contradiction -- a struct
        // claiming validity while the function was on its way to returning false -- and
        // moving the assignment to the success path "fixed" it. In the same run
        // (19:55) this function returned on its first line every frame, so it set
        // nothing, and therefore:
        //     centre_landing        stayed 0     -> the 1.25 bound passed trivially
        //     corner_agreement_ndc  stayed 0     -> the 1e-3 bound passed trivially
        //     quad_lo / quad_hi     stayed 0     -> every dump printed "0x0 px"
        // All three packet guards were silently no-ops for the whole run, and the
        // lens-size gate added that day rejected 16 packets on a size of 0.
        //
        // `valid` is decided AFTER this runs. A diagnostic that consults a validity flag
        // it does not itself set is not defensive, it is a way to make the flag mean
        // "has this been measured yet" while it actually means "was this accepted".
        // Nothing here needs it: the inputs (image_quad, scales, shifts, shift_dir) are
        // all assigned by the caller before the call.
        p.map_center = map_center;
        p.map_u = map_u;
        p.map_v = map_v;
        p.lens_view = lens_view;

        // The PRIMARY chain, for arbitrary optic NDC (see the packet field comments).
        const float sx = p.scales.x;
        const v3 anchor = map_center * sx
            + v3{p.shift_dir.x, p.shift_dir.y, p.shift_dir.z} * p.shifts.x;
        const v3 bx = map_u * (sx * 0.05f);
        const v3 by = map_v * (sx * 0.05f);
        const auto chain = [&](float nx, float ny, v2& out_ndc) {
            const v3 lp = anchor + bx * nx + by * ny;
            const v4 c = mat_mul_v(lens_view, v4{lp.x, lp.y, lp.z, 1.f});
            if (!all_finite4(c) || std::fabs(c.w) < 1e-9f) return false;
            out_ndc = v2{c.x / c.w, c.y / c.w};
            return true;
        };

        if (chain(0.f, 0.f, p.centre_landing))
        {
            // The spec's own line-578 corner test — the one `combined` fails.
            float worst = 0.f;
            for (int i = 0; i < 4; ++i)
            {
                v2 n{};
                if (!chain(corners[i][0], corners[i][1], n))
                {
                    worst = 1e9f;
                    break;
                }
                const float dx = n.x - p.image_quad[i].x, dy = n.y - p.image_quad[i].y;
                worst = (std::max<float>)(worst, std::sqrt(dx * dx + dy * dy));
            }
            p.corner_agreement_ndc = worst;
        }

        // Componentwise: unity::vector2 has member +-/* but no free vector/vector forms.
        p.quad_lo = v2{1e9f, 1e9f};
        p.quad_hi = v2{-1e9f, -1e9f};
        for (const auto& q : p.image_quad)
        {
            p.quad_lo.x = (std::min<float>)(p.quad_lo.x, q.x);
            p.quad_lo.y = (std::min<float>)(p.quad_lo.y, q.y);
            p.quad_hi.x = (std::max<float>)(p.quad_hi.x, q.x);
            p.quad_hi.y = (std::max<float>)(p.quad_hi.y, q.y);
        }
    }

    inline bool read_camera_matrices(uintptr_t native_cam, mat4& view, mat4& vp) {
        auto read_mat = [](uintptr_t a, mat4& m) {
            if (!range_readable(a, 64)) return false;
            std::memcpy(m.m, reinterpret_cast<const void*>(a), 64);
            return true;
        };
        mat4 active{};
        mat4 nonjittered{};
        uint8_t flag = 0;
        if (!read_mat(native_cam + 0xA8, view)) return false;
        if (!read_mat(native_cam + 0xE8, active)) return false;
        if (!read_u8(native_cam + 0x57C, flag)) return false;
        if (flag)
        {
            if (!read_mat(native_cam + 0x780, nonjittered)) return false;
            vp = mat_mul(nonjittered, view);
        }
        else
        {
            vp = mat_mul(active, view);
        }
        for (float f : vp.m)
            if (!std::isfinite(f)) return false;
        // Non-degenerate check. isfinite alone accepts an ALL-ZERO matrix, which was
        // observed on 2026-09-26: every element read back 0.0, the finite check passed,
        // and an all-zero packet propagated until the section 7 guard caught it.
        //
        // CORRECTION, same day: the first version of this tested `vp.at(1,1)`, reasoning
        // about the PROJECTION's m11 = 1/tan(fovY/2) (measured +4.164, fovY ~ 27 deg).
        // That was wrong — `vp` here is projection * VIEW, and (PV).at(1,1) is
        // P11 * V11, i.e. the fov coefficient times cos(pitch). It is legitimately ZERO
        // whenever the camera looks straight up or down, so the check rejected valid
        // packets at extreme pitch. The test now applies to the projection matrix itself,
        // where m11 is the fov coefficient and cannot be zero for any usable FOV.
        const mat4& proj = flag ? nonjittered : active;
        if (std::fabs(proj.at(1, 1)) < 1e-6f) return false;
        return true;
    }

    inline bool camera_transform_pose(uintptr_t native_cam, v3& pos, float quat[4]) {
        uintptr_t go = 0;
        if (!read_ptr(native_cam + 0x58, go) || !go) return false;
        uintptr_t tr = 0;
        if (!find_component_named(go, "Transform", 0x19CEBC0, tr, 256)) return false;
        uintptr_t hierarchy = 0;
        uint32_t index = 0;
        if (!read_ptr(tr + 0x70, hierarchy) || !hierarchy) return false;
        if (!read_u32(tr + 0x78, index) || index >= 65536) return false;
        uintptr_t parents = 0, nodes = 0;
        if (!read_ptr(hierarchy + 0x40, parents) || !read_ptr(hierarchy + 0x68, nodes)) return false;

        pos = {0, 0, 0};
        float q[4] = {0, 0, 0, 1};
        uint32_t chain_index = index;
        int guard = 0;
        while (chain_index != 0xFFFFFFFFu && guard++ < 64)
        {
            if (chain_index >= 65536) return false;
            const uintptr_t node = nodes + static_cast<uintptr_t>(chain_index) * 48;
            v3 p;
            v4 qq;
            v3 s;
            if (!read_v3(node, p) || !read_v4(node + 16, qq) || !read_v3(node + 32, s))
                return false;
            if (!all_finite3(p) || !all_finite4(qq) || !all_finite3(s)) return false;
            const float lensq = qq.x * qq.x + qq.y * qq.y + qq.z * qq.z + qq.w * qq.w;
            if (lensq < 0.5f || lensq > 1.5f) return false;
            // compose: parentRotation * childRotation; accumulate position via child TRS
            const mat4 child = trs(p, qq, s);
            const v4 acc = mat_mul_v(child, v4{pos.x, pos.y, pos.z, 1.f});
            pos = {acc.x, acc.y, acc.z};
            // quaternion compose (qa * qb)
            const float ax = qq.x, ay = qq.y, az = qq.z, aw = qq.w;
            const float bx = q[0], by = q[1], bz = q[2], bw = q[3];
            q[0] = aw * bx + ax * bw + ay * bz - az * by;
            q[1] = aw * by - ax * bz + ay * bw + az * bx;
            q[2] = aw * bz + ax * by - ay * bx + az * bw;
            q[3] = aw * bw - ax * bx - ay * by - az * bz;
            if (!read_u32(parents + static_cast<uintptr_t>(chain_index) * 4, chain_index))
                return false;
        }
        std::memcpy(quat, q, sizeof(float) * 4);
        return true;
    }

    // Out-params report the worst axis disagreement in DEGREES and the origin error, so
    // a rejection can say HOW FAR off it was rather than only that it exceeded the
    // bound. 0.05 degrees is the spec's gate and is extremely tight for a live,
    // animated game camera — this is the stage that failed first on 2026-09-26.
    //
    // Declared ahead of the gate so the gate and its diagnostic can share one source
    // of truth for the tolerances; a mismatch between the number enforced and the
    // number printed would make the log actively misleading.
    inline constexpr float kPoseAxisTolDeg = 0.05f;
    inline constexpr float kPoseOriginTol = 0.001f;

    // Why the pose gate rejected, for the caller's diagnostic line.
    //
    // 2026-09-28 CORRECTION. This comment previously read: "an axis disagreement is a
    // read-timing skew ... an origin error is a genuinely wrong Transform and wants a
    // different field." That attribution is wrong for the data we actually have, and it
    // was steering the diagnosis.
    //
    // Observed on every run: main_deg = 0.0000 (EXACTLY zero) with main_org = 0.05674 m.
    // Zero rotation disagreement with 5.7 cm of position disagreement is the signature
    // of TRANSLATION-ONLY skew: the player is moving without turning, so the two reads
    // of the same camera straddle some real travel. A genuinely wrong Transform would
    // displace the node in all three axes and would not leave the rotation bit-exact.
    //
    // 5.7 cm at Tarkov sprint speed (~5.5-6.5 m/s) is ~9-10 ms, which is about one frame
    // at 100 Hz. So the likeliest cause is read ORDER/TIMING between the view matrix
    // (+0xA8) and the Transform node walk, not a wrong field.
    //
    // What would settle it, and is not yet measured: the tick delta between those two
    // reads, correlated against main_org. If org ~= speed * skew the hypothesis holds.
    // Until that is logged, treat the cause as unconfirmed and do not go looking for a
    // different field to read.
    //
    // 2026-09-29, SECOND CORRECTION -- the translation-skew reading above does not cover
    // the whole log, and pretending otherwise would be worse than the original error.
    // That same day produced a THIRD magnitude:
    //
    //     main(deg=0.0000 org=59.47223) optic(deg=0.0000 org=0.00000)
    //     main(deg=0.0000 org=0.00000)  optic(deg=0.0000 org=59.34403)
    //
    // 59.4 m is not travel -- at 6 m/s it would be ten seconds of sprint. And note the
    // structure: one camera reads PERFECTLY while the other is 59 m out, and it
    // ALTERNATES which one is bad. A read-timing skew displaces both readings of a
    // shared view matrix together; it cannot make exactly one camera wrong. So the
    // origin error is at least two distinct failures, and only the 5.7 cm one is
    // characterised.
    //
    // The decisive fact, and the reason this is instrumentation rather than another
    // hypothesis: `pos` and `quat` are read from the SAME Transform, in the same call.
    // The rotation agreeing bit-exactly therefore PROVES that read was self-consistent,
    // which means the disagreement lives in the view matrix's own translation column.
    // Two candidates remain and they are not distinguished by the magnitude:
    //   (a) the view matrix's translation is stale or belongs to another camera
    //   (b) the position is fine and the view matrix is from a different camera entirely
    // Logging both sides settles it: if `pos` is near the player and `view.m[12..14]` is
    // 59 m away, it is (a). If `pos` itself is 59 m out, the Transform read is the liar.
    struct pose_axis_detail
    {
        v3 world_pos{};   // pos as read from the Transform
        v3 view_origin{}; // view.m[12..14], the camera origin the view matrix implies
        v3 local{};       // view * (world_pos, 1) .xyz -- the error, per axis
    };
    struct pose_reject_detail
    {
        float main_deg = 0.f, main_org = 0.f;
        float optic_deg = 0.f, optic_org = 0.f;
        bool valid = false;
        // Per-axis, for whichever camera failed, so the log can say WHICH axis is 59 m
        // out instead of leaving it to be inferred from a magnitude.
        pose_axis_detail main_axis{}, optic_axis{};
        // The camera POSITIONS the check used, 2026-09-30.
        //
        // Without these, the failing-camera position had to be reconstructed
        // arithmetically from the error magnitude. On 2026-09-30 that reconstruction
        // showed |view translation| = 46.31768 against a reported org of 46.31783 --
        // i.e. the error was exactly the magnitude of the view matrix's own
        // translation column, which for err = R_view.pos + view_org with orthonormal R
        // happens ONLY when pos == (0,0,0). So the diagnosis was "the Transform walk
        // returned a zero position", and the matrix was innocent.
        //
        // That is arithmetic on a printed magnitude, i.e. an inference, and it also
        // OVERTURNED the previous theory (an identity worldToCameraMatrix on the main
        // camera), because the same run showed zero=0/0/0 -- a non-zero translation.
        // Printing pos directly settles it on the next occurrence instead of
        // reconstructing it.
        float main_pos[3]{};
        float optic_pos[3]{};
        // Same for the view translation each camera was read with, so the "is |org| just
        // |view_org| again" question is answerable from the log rather than re-derived.
        float main_vorg[3]{};
        float optic_vorg[3]{};
    };
    inline pose_reject_detail g_pose_reject{};

    // The single re-read that follows a pose-consistency failure.
    //
    // optic_idea.md line 474 asks for a 6 ms retry bound. I previously declined that, on
    // the grounds that GetTickCount64 updates only every ~15.6 ms here so the bound could
    // not be honoured. That was aimed at the wrong mechanism: the bound exists to stop an
    // unbounded spin, and a SINGLE retry cannot spin. So the bound is kept as a REPORTED
    // quantity rather than a control one -- the retry's elapsed time is measured and the
    // worst value printed, which settles empirically whether one retry fits inside 6 ms
    // instead of arguing about timer granularity.
    //
    // Why a retry is the right shape for THIS failure, established by measurement on
    // 2026-09-29: the view matrix's translation column reads as exactly (0,0,0) on the
    // failing frames while its rotation is bit-exact, and the reported origin error is then
    // exactly |camera position| (31.91912 and 16.65188, matching to five decimals). That
    // is a torn read of a matrix the game is midway through writing -- not a wrong field
    // and not a wrong camera. A later read of the same bytes sees the finished matrix.
    struct pose_retry_note
    {
        unsigned long long attempts = 0;
        unsigned long long recovered = 0;  // retry produced a consistent packet
        double last_us = 0.0;
        double max_us = 0.0;
    };
    inline pose_retry_note g_pose_retry{};

    // The spec's own bound, reported but not enforced. See above.
    inline constexpr double kPoseRetryBoundUs = 6000.0;

    // -----------------------------------------------------------------------
    // Which matrix are we actually holding?
    //
    // 2026-09-29, after the retry failed to explain the observed data. The measured
    // fact: on failing frames the view matrix's translation column reads exactly
    // (0,0,0) while its rotation is bit-exact, and the reported origin error is then
    // exactly |camera position| (matched to five decimals on three separate days). The
    // zero state PERSISTS for ~25 s while the player stands still, so it is not a torn
    // read -- the bytes really are zero.
    //
    // A projection matrix has m[12..14] exactly zero, always. And the camera struct's
    // +0xE8 slot is a projection matrix -- read_camera_matrices multiplies it by the view
    // to form `vp`. So "the view's translation is zero" and "we are holding a projection
    // where the view should be" are the SAME observation, and I had been explaining away
    // the second in terms of the first.
    //
    // The two are distinguishable in one read, with no assumption: the view matrix's
    // upper 3x3 is a rotation and therefore has unit row length, while a projection's
    // rows carry 1/fov and the aspect term and are NOT unit length. `r0` below is the
    // length of row 0. r0 == 1 => a view matrix. r0 != 1 => whatever this is, it is not.
    //
    // This is the measurement I should have made before writing a retry for it.
    struct camera_matrix_probe
    {
        bool ok = false;
        uint8_t flag = 0;          // +0x57C, selects the non-jittered projection
        float view_t[3]{};         // +0xA8 translation column
        float view_r0 = 0.f;       // +0xA8 row-0 length
        float act_t[3]{};          // +0xE8
        float act_r0 = 0.f;
        float nj_t[3]{};           // +0x780
        float nj_r0 = 0.f;
    };
    inline camera_matrix_probe probe_camera_matrices(uintptr_t native_cam) {
        camera_matrix_probe p{};
        auto grab = [](uintptr_t base, float (&t)[3], float& r0) {
            float row[16] = {};
            if (!range_readable(base, 64)) return false;
            std::memcpy(row, reinterpret_cast<const void*>(base), 64);
            t[0] = row[12]; t[1] = row[13]; t[2] = row[14];
            r0 = std::sqrt(row[0] * row[0] + row[1] * row[1] + row[2] * row[2]);
            return true;
        };
        if (!read_u8(native_cam + 0x57C, p.flag)) return p;
        if (!grab(native_cam + 0xA8, p.view_t, p.view_r0)) return p;
        if (!grab(native_cam + 0xE8, p.act_t, p.act_r0)) return p;
        // +0x780 is only meaningful when the flag selects it, and reading it when the
        // flag is clear would report whatever unrelated field sits at that offset.
        if (p.flag && !grab(native_cam + 0x780, p.nj_t, p.nj_r0)) return p;
        p.ok = true;
        return p;
    }
    // A short signature so the line is emitted once per distinct observation rather than
    // on every rejected frame. Quantised: these are "is it 1.0 or not" questions, not
    // "what is the exact FOV" questions.
    inline std::string camera_matrix_signature(const camera_matrix_probe& p) {
        if (!p.ok) return "unreadable";
        const auto q = [](float v) { return static_cast<int>(v * 100.0f + 0.5f); };
        return std::format("flag={} r0={}/{}/{} zero={}/{}/{}",
            static_cast<int>(p.flag), q(p.view_r0), q(p.act_r0), q(p.nj_r0),
            (p.view_t[0] == 0.f && p.view_t[1] == 0.f && p.view_t[2] == 0.f) ? 1 : 0,
            (p.act_t[0] == 0.f && p.act_t[1] == 0.f && p.act_t[2] == 0.f) ? 1 : 0,
            (p.nj_t[0] == 0.f && p.nj_t[1] == 0.f && p.nj_t[2] == 0.f) ? 1 : 0);
    }

    // Why the section-6 root-position outlier filter did or did not engage.
    //
    // This exists because the filter is EXPECTED TO BE A NO-OP on this build: the
    // consistency gate rejects the packet first (org ~0.057 m against a 0.001 m
    // tolerance), and the spec forbids a root filter from repairing an inconsistent
    // packet. A filter that silently never runs is indistinguishable from one that was
    // never wired up, so its outcome is recorded and reported rather than inferred from
    // the absence of symptoms.
    struct root_filter_note
    {
        bool applied = false;
        // The magnitude the filter CONSIDERED, in mm, or -1 when no candidate was
        // computed at all (no hands-self sample, or the sample was untrusted).
        //
        // This was previously a single `applied_mm` field, assigned only on the accept
        // path. On the refusal path it therefore kept its initialiser and the log read
        //     applied=0 corr=0.00mm ... -- correction over 20 mm budget (not suppressed)
        // i.e. a candidate that was refused for exceeding 20 mm was reported as 0.00 mm,
        // which reads as "no correction was needed". The number and the sentence were
        // describing different quantities, and the number was the one that contradicted
        // the finding. Same defect class as the `why_not` lie fixed at 20:40 -- a
        // diagnostic that is routinely false is worse than no diagnostic.
        //
        // `applied_mm` is retained as the value actually written into the matrix, which
        // is 0 exactly when `applied` is false, and is therefore never a useful thing to
        // print on its own.
        float cand_mm = -1.f;
        float applied_mm = 0.f;
        const char* why_not = "not evaluated";
        bool packet_consistent = false;
        bool have_hands_self = false;
    };
    inline root_filter_note g_root_filter_note{};

    // ---- root-corrector frame ring (ACTIVE INVESTIGATION) -------------------
    //
    // DECLARED HERE, NOT AT ITS FIRST USE. `root_frame_summary()` below reads
    // `g_root_ring*`, and the ring was originally declared ~780 lines further
    // down, inside the corrector. That does not compile: `root_frame_summary` is
    // an ordinary namespace-scope function, not a template, so name lookup in its
    // body happens at the point of definition rather than at instantiation.
    // Reading a namespace-scope variable declared later in the same namespace is
    // C2065 "undeclared identifier" -- 24 errors, and `Prod|x64` does not build.
    //
    // Two mistakes are visible here and both are worth naming, because either one
    // alone would have looked like the other's:
    //
    //   1. The lambda `record_root_frame` below is declared with an EMPTY capture
    //      list, `[](const v3* local, ...)`. That is correct for a namespace-scope
    //      variable -- no capture is needed -- but only once the variable is
    //      visible at the lambda's own definition point. Reported as C2326
    //      ("a function cannot access g_root_ring") and C2888 ("a symbol cannot be
    //      defined in namespace lens"), neither of which names declaration order
    //      as the cause. Adding a capture list does not fix it and is the wrong
    //      fix; MSVC reports these on the lambda's operator(), which is what makes
    //      the capture theory so plausible.
    //
    //   2. `record_root_frame` is a `static`-storage local lambda holding the ring
    //      index, and the errors point at both the lambda AND at
    //      `root_corrector_disabled`. The getenv there is a second, unrelated
    //      defect: C4996, and `pch.h` does not define `_CRT_SECURE_NO_WARNINGS`.
    //      Left alone deliberately -- it is a warning on a diagnostic kill switch,
    //      not a build break, and this project holds itself to 0 warnings, so it is
    //      noted here rather than silently fixed by whoever is already in this
    //      file.
    //
    // WHY A RING AND NOT PER-FRAME LINES. ~60 lines/s is the mistake
    // tracy_bridge.h documents. This costs four stores per frame and prints a
    // summary on the cadence the dump already uses.
    // ---------------------------------------------------------------------
    struct root_frame_sample {
        float local_x, local_y, local_z; // camera-local mm
        float corr_mm;                   // magnitude actually written, mm
        unsigned long long dt;           // ms since the prior sample
        unsigned char applied;
        unsigned char had_local;         // 0 when `local` could not be formed
        // ---- WHY A FRAME IS SUSPICIOUS (2026-10-05, corrected 2026-10-06) ---
        // The A/B run answered the first question: with the corrector switched OFF
        // for 95 consecutive windows the shake persisted, so the corrector is not
        // the cause.
        //
        // It also produced `move` readings that looked damning -- 56,557 mm while
        // OFF, 1,087 mm while ON -- and I wrote here that the READING must be bad
        // because a node the spec calls "rigidly attached to the camera" cannot
        // move 56 m between two frames.
        //
        // THAT WAS WRONG, and it is the same shape as RETRACTION 8 in
        // tools/optics_status.md: a statistic quoted without the axis it was
        // computed over. There the median stood in for a tail; here the delta
        // stood alone without the interval it was taken over. Three of these
        // now, all mine, all the same omission.
        //
        // The fact, since it is the whole correction: the 56,557 mm reading sits
        // in a window whose longest gap is 45,360 ms. It is not a 56 m step, it is
        // the difference between the last sample before the optic stopped running
        // and the first one after. The path only runs while the scope is up, so
        // gaps are inherent to the sampling. See tools/optics_status.md sec 7 for
        // the re-derivation and tools/measure_move_vs_dt.py to recompute it.
        //
        // These four fields are what make that distinguishable NEXT time, instead
        // of by re-reading the summary and finding the same ambiguity in it:
        //   - dt on the worst frame, so the reader can see the interval the delta
        //     was taken over without reconstructing it;
        //   - node identity, so "the node was replaced" is separable from "the
        //     same node moved".
        // Captured on every frame, because the interesting one is gone by the time a
        // summary runs.
        //
        //   node_ptr     the managed object the position came from. Changing across
        //                frames means the node was re-resolved, destroyed or
        //                recreated -- the stale-read candidate.
        //   parent_depth hops walked to reach it. A jump means re-parenting.
        //   raw_len      length of the camera-local vector as read, BEFORE it is
        //                differenced. A node intact but 56 m out is a different
        //                failure from a corrupt read of a nearby one.
        //   finite       0 if any component was NaN/Inf, sampled rather than
        //                assumed, so a NaN is reported instead of silently
        //                poisoning the differencing.
        unsigned long long node_ptr;
        unsigned int parent_depth;
        float raw_len;
        unsigned char finite;
    };
    inline constexpr int kRootRing = 96;
    // What counts as a SUSPICIOUS single-frame move, in mm.
    //
    // The justification for this number changed on 2026-10-06, and the first
    // justification was wrong. It said "weapon sway peaked at 216 mm/frame, so
    // 1000 is above every physical reading seen". Measured across the 114 windows
    // of the 2026-10-05 capture, 6 of the 19 corrector=on windows exceeded
    // 216 mm, so that was false as stated.
    //
    // What the measurement actually supports: `move` is a delta between
    // consecutive samples and `dt` is the interval between those same samples,
    // and the two track hard. Restricted to the 94 windows with no gap longer
    // than 250 ms, the largest `move` in any of them is 245.6 mm (p50 of window
    // maxima 68.8 mm). All eight largest moves in the whole capture came from
    // windows containing a gap of at least 312 ms, the largest being 56,556.84 mm
    // in a window whose longest gap was 45,360 ms.
    //
    // So 1000 mm is chosen because it NEVER fires on a per-frame-valid window in
    // this capture (0 of 94) and fires on 3 of 114 windows overall, all of which
    // contain a gap. That is the behaviour wanted: report the frame, and print
    // its dt so the reader can see it is a hole in the sampling rather than
    // motion. The optic path only runs while the scope is up, so gaps are
    // inherent -- un-scoping for 45 s and scoping again is not a defect.
    //
    // NOT chosen as "above every physical reading": 245.6 mm of per-frame motion
    // is already more than a node the spec calls rigidly attached to the camera
    // ought to show, and that remains unexplained. Deliberately not the spec's
    // 20 mm either -- that budget is on the CORRECTION, and reusing it here flags
    // 58 of the 94 valid windows, i.e. everything.
    inline constexpr float kSuspiciousMoveMm = 1000.f;


    inline void mark_pose_reject(float main_deg, float main_org,
        float optic_deg, float optic_org) {
        g_pose_reject = {main_deg, main_org, optic_deg, optic_org, true};
    }

    // ---- section 7 region accounting -----------------------------------------
    //
    // optic_idea.md line 574 asks for TWO passes: scoped projection inside the lens
    // mask, main-camera projection outside it, drawing DISJOINT geometry at the SAME
    // magnification. We run one pass through the optic camera for everything, so ESP
    // can be drawn over the scope housing where the game shows the mask.
    //
    // Whether the main-camera pass is needed is EMPIRICAL, and the architecture says
    // yes: ScopeMaskRenderer builds a FULL-SCREEN mask texture
    // (CreateMaskTexture(width, height) -> DrawOptic / DrawCollimators through a
    // CommandBuffer on `currentCamera`). A mask is only meaningful if the region
    // outside it shows something else -- if the whole screen were the optic picture
    // there would be nothing to mask. The periphery is therefore rendered, by the main
    // camera (OpticComponentUpdater exposes get_MainCamera() and does
    // CopyComponentFromOptic -- a component transfer, not a second render target).
    //
    // These counters measure how much ESP actually lands outside the fitted mask, and
    // how far outside, so the decision is made on data rather than on that argument.
    // inside==0 for a whole run means the main-camera pass has nothing to do.
    struct region_counters
    {
        unsigned long long inside = 0;  // point fell within the fitted mask
        unsigned long long outside = 0; // point fell outside it
        unsigned long long no_mask = 0; // packet valid but mask empty
        float max_outside_px = 0.f;     // worst distance outside, pixels
        float mask_cover_frac = 0.f;    // mask area / screen area, 0..1

        // ---- packet rejection duty cycle, per STAGE STRING --------------------
        //
        // 2026-10-01, second version. The first version classified the stage into an
        // enum, and the enum was built from the four strings that happened to appear in
        // one log. The pipeline has 22 distinct mark_stage strings, so 18 of them fell
        // into a catch-all `other` -- and `other` turned out to be 90% of all packet
        // rejections (1,129 of 1,254), so the one number that would explain a 28% packet
        // failure rate sat in a bucket labelled "everything else".
        //
        // That is the third time this session a classifier built from observed cases
        // rather than from the source of truth has hidden the answer -- after bare=716
        // and the two-caller fell_back. So this version removes the classification. The
        // stage is ALREADY a string where the failure happens, so it is counted as one.
        // No mapping to keep in sync with the code, and no bucket to hide in: a stage
        // that appears gets a row automatically, including one added next year.
        //
        // Cost is a strcmp across a short table, on the rejection path only. Rejections
        // run at order 1e3 per session against 1e5 acquires, so this is not a hot path.
        // Not thread-safe, consistent with the rest of this region state.
        struct reject_table
        {
            // 22 pipeline stages, plus the nine sub-stages the lens chain walk was split
            // into on 2026-10-02. 48 gives headroom for the next split rather than landing
            // on the overflow path and reporting it as a finding about something else.
            // Overflow is counted and REPORTED rather than dropped, because an overflow
            // would itself be the finding.
            static constexpr int kSlots = 48;
            static constexpr int kNameLen = 56;
            char name[kSlots][kNameLen] = {};
            unsigned long long count[kSlots] = {};
            int used = 0;
            unsigned long long overflow = 0;
            unsigned long long packets_built = 0;

            void record(const char* stage) {
                for (int i = 0; i < used; ++i) {
                    if (std::strcmp(name[i], stage) == 0) { ++count[i]; return; }
                }
                if (used < kSlots) {
                    std::snprintf(name[used], kNameLen, "%s", stage);
                    count[used] = 1;
                    ++used;
                } else {
                    ++overflow;
                }
            }
            unsigned long long total() const {
                unsigned long long t = 0;
                for (int i = 0; i < used; ++i) t += count[i];
                return t;
            }
            void reset() {
                for (int i = 0; i < used; ++i) { name[i][0] = '\0'; count[i] = 0; }
                used = 0;
                overflow = 0;
                packets_built = 0;
            }
        };
        reject_table rejects{};
    };
    // Declared up here rather than beside the mask helpers because acquire_packet
    // writes mask_cover_frac and it appears before those helpers in the file.
    inline region_counters g_region{};

    // -----------------------------------------------------------------------
    // Lens-image size tracker, and the gate that uses it.
    //
    // 2026-09-29. Measured on that run: FOUR times in 73 dumps (5.5%) the packet was
    // accepted with a lens image of 347-394 px where the median is 808 px, `cover`
    // collapsed from 26.8% to 0.8-1.7%, and the centre landing wandered to (1107,576),
    // (1091,589) and (843,539) instead of sitting at (960,540). Every one of the four
    // landed 4-38 ms after a completed route rebuild -- never during the invalid window
    // the route rebuild already guards.
    //
    // So: the route rebuild is announced and then the FIRST packet published after it
    // carries a half-composed lens matrix.
    //
    // Why the existing guards cannot see it, and why no amount of tightening them
    // would help: `centre_landing` and `corner_agreement_ndc` are BOTH derived from the
    // same HC/HU/HV quadruple that produces `image_quad`. A matrix that is uniformly
    // half-sized is perfectly self-consistent, so it passes a landing bound and passes
    // a corner-agreement bound simultaneously. This is the same common-mode blindness
    // that made the magenta reference ring useless as a check on 2026-09-28: comparing
    // a quantity against itself-derived quantities cannot detect a shared error.
    //
    // The gate therefore uses an INDEPENDENT invariant: the projected size of the lens
    // image is a physical property of the lens object, not of the mapping. Scoping
    // magnifies the picture's CONTENTS; it does not resize the lens. So across a
    // zoom sweep, a stance change, or a route rebuild of the SAME optic, the projected
    // image size should hold. Measured spread over a normal run is 808-861 px, i.e. 6%.
    // A drop to 0.49x of the baseline is not a zoom change.
    //
    // The baseline is deliberately NOT reset on route rebuild. All four rebuilds in the
    // measured run were the same mesh id (4292436884) -- the same lens, re-resolved. A
    // baseline that reset on rebuild would let the very first post-rebuild packet
    // define the expected size, which is precisely the collapsed packet. Carrying the
    // baseline across the rebuild is what makes this a check rather than a tautology.
    //
    // Escape hatch, because a gate that can only ever reject is a deadlock: if packets
    // keep failing this gate for longer than kRebaselineMs, the size IS the new normal
    // (a genuinely different optic) and the baseline is re-taken from it. That cannot
    // latch on a transient, because a transient does not last 500 ms.
    struct lens_image_size_gate
    {
        bool have = false;
        float ref_w = 0.f, ref_h = 0.f;   // baseline, NDC half-extent
        float seen_w = 0.f, seen_h = 0.f; // the value that just failed
        ULONGLONG reject_since = 0;       // 0 = not currently rejecting
        unsigned long long rejects = 0;
        unsigned long long rebaselines = 0;
        // Subset of `rejects` with a degenerate (zero/near-zero) bbox. Kept separate
        // because it is a categorically different fault -- no baseline, no re-baseline
        // -- and a run that only ever accumulates these has a broken UPSTREAM diagnostic
        // rather than a collapse, which is what happened at 19:55.
        unsigned long long degenerate = 0;
    };
    // Thread-local because two threads (main + render) evaluate the gate on
    // different frames. The mutex serializes the CALL but the STATE must not
    // mix timelines: a rebaseline must adopt the measurement from the SAME
    // frame that started the rejection streak, not whichever thread happens
    // to hold the mutex when the timer expires. 2026-10-06 capture proved
    // this: thread 17796 measured 0.3863x0.6862 (53 rejections, rebase=0),
    // thread 11220 measured 0.8521x1.5149 (55 rejections, rebase=1) -- the
    // rebaseline adopted the second thread's 2.2x larger measurement.
    inline thread_local lens_image_size_gate g_lens_size{};

    // Baseline is a NDC half-extent; accept anything inside this ratio of it. Derived
    // from the measured 6% normal spread, rounded well out so ordinary breathing has
    // headroom, while staying far inside the 0.49x collapse.
    inline constexpr float kLensSizeMinRatio = 0.70f;
    inline constexpr float kLensSizeMaxRatio = 1.45f;
    // How long a size disagreement may persist before it is declared the new normal.
    inline constexpr ULONGLONG kRebaselineMs = 500;

    // ---- LENS-SIZE GATE, PER FRAME (2026-10-06) ---------------------------
    // Same shape of instrument as the root ring above, and for the same reason: the
    // gate reports cumulative counters on a 600 ms cadence, and a cumulative counter
    // cannot answer a question about ALTERNATION.
    //
    // What is already known (tools/measure_lenssize_gate.py, over the 2026-10-05
    // capture): 56 rejections and ZERO re-baselines. The escape hatch at the
    // `kRebaselineMs` branch requires 500 ms of CONTINUOUS rejection, and the accept
    // path sets `reject_since = 0`, so interleaved accepts reset the timer before it
    // can expire. Three bursts of 14, 14 and 9 rejections arrived inside 603-604 ms
    // windows -- bursts that span the 500 ms threshold and still never re-baselined.
    //
    // What is NOT known, and is what these fields exist for: the per-frame decision.
    // Whether 14 rejections inside 603 ms means 14 rejects among ~36 frames (39% duty,
    // alternating, timer starved) or 14 out of 14 (the path is not running at 60 Hz)
    // changes the diagnosis completely, and 603 ms is a gap between two printed
    // lines -- it bounds WHERE the rejections fell, not how they were spaced.
    //
    // So: run lengths of consecutive rejects and accepts, which settle it directly
    // without needing the invocation rate; and the ratio to the band edge per frame,
    // which shows whether the measurement is hugging the threshold.
    struct lenssize_frame_sample {
        float ratio;         // size / baseline, i.e. measured extent vs what is expected
        float delta_ratio;   // |ratio - previous frame's ratio|
        float lo_edge;       // kLensSizeMinRatio, the accept threshold being straddled
        float size;          // measured max quad extent, NDC
        float baseline;      // max(ref_w, ref_h) at this frame
        unsigned long long dt;   // ms since the prior evaluation
        unsigned char rejected;  // 1 = this evaluation rejected the packet
        unsigned char lo_side;   // 1 = rejected on the LOW edge (size < lo)
        unsigned char hi_side;   // 1 = rejected on the HIGH edge (size > hi)
        unsigned char degenerate;// 1 = bbox was degenerate, a separate counter
    };
    inline constexpr int kLensSizeRing = 256;
    // Thread-local: same reasoning as g_lens_size above. Two threads evaluate on
    // different frames; the ring must not mix their samples.
    inline thread_local lenssize_frame_sample g_lens_ring[kLensSizeRing]{};
    inline thread_local int g_lens_ring_head = 0;
    inline thread_local int g_lens_ring_filled = 0;

    // Consecutive-run bookkeeping, live rather than derived from the ring. The ring
    // is a window and a run can be longer than the window, so these are the honest
    // numbers for "how long did it stay rejected", which is the quantity the
    // `kRebaselineMs` timer actually competes with.
    // Thread-local: each thread tracks its own run lengths.
    inline thread_local int g_lens_reject_run = 0, g_lens_accept_run = 0;
    inline thread_local int g_lens_reject_run_max = 0, g_lens_accept_run_max = 0;

    // Clock per ring slot, so `dt` is the gap to the previous EVALUATION rather than
    // to whatever happens to sit one slot behind after a wrap. Declared before the
    // recorder that reads it, which is not negotiable at namespace scope.
    // Thread-local: each thread has its own clock.
    inline thread_local unsigned long long g_lens_tick[kLensSizeRing]{};

    inline void record_lens_size_frame(float size, float baseline,
                                       bool rejected, bool lo_side, bool hi_side,
                                       bool degenerate) {
        lenssize_frame_sample& s = g_lens_ring[g_lens_ring_head];
        const unsigned long long now = GetTickCount64();
        const float r = (baseline > 1e-6f) ? (size / baseline) : 0.f;
        // delta against the PREVIOUS frame, which may be a different ring slot after
        // wrap, so it is read from the slot before this one rather than a local.
        if (g_lens_ring_filled > 0) {
            const int prev = (g_lens_ring_head + kLensSizeRing - 1) % kLensSizeRing;
            s.dt = now - g_lens_tick[prev];
            s.delta_ratio = std::fabs(r - g_lens_ring[prev].ratio);
        } else {
            s.dt = 0;
            s.delta_ratio = 0.f;
        }
        g_lens_tick[g_lens_ring_head] = now;
        s.ratio = r;
        s.lo_edge = kLensSizeMinRatio;
        s.size = size;
        s.baseline = baseline;
        s.rejected = rejected ? 1 : 0;
        s.lo_side = lo_side ? 1 : 0;
        s.hi_side = hi_side ? 1 : 0;
        s.degenerate = degenerate ? 1 : 0;

        if (rejected) {
            ++g_lens_reject_run;
            g_lens_accept_run = 0;
            if (g_lens_reject_run > g_lens_reject_run_max)
                g_lens_reject_run_max = g_lens_reject_run;
        } else {
            ++g_lens_accept_run;
            g_lens_reject_run = 0;
            if (g_lens_accept_run > g_lens_accept_run_max)
                g_lens_accept_run_max = g_lens_accept_run;
        }

        g_lens_ring_head = (g_lens_ring_head + 1) % kLensSizeRing;
        if (g_lens_ring_filled < kLensSizeRing) ++g_lens_ring_filled;
    }

    inline root_frame_sample g_root_ring[kRootRing]{};
    inline int g_root_ring_head = 0;
    inline int g_root_ring_filled = 0;

    // Kill switch, and the SECOND instance of the same declaration-order defect,
    // so it is moved here for the same reason. `root_frame_summary()` below calls
    // it; it was declared inside `camera_consistent()`'s body, several hundred
    // lines further down, which MSVC reports as C3861 ("identifier not found") at
    // the call and C2601 ("invalid local function definitions") at the
    // definition. Same root cause as the ring above, and the same shape: a
    // namespace-scope function reaching into a function body.
    //
    // An environment variable rather than a settings field, so it needs no UI
    // and no shared-struct change: set TA_OPTIC_ROOT_CORRECTOR_OFF=1 and start
    // the game. There is no getenv precedent elsewhere in this tree, which is
    // why GetEnvironmentVariableA is used rather than `std::getenv` -- the latter
    // is C4996 in this project (`_CRT_SECURE_NO_WARNINGS` is not defined) and
    // this project holds itself to zero warnings.
    inline bool root_corrector_disabled() {
        // THE CHECKBOX IS THE LIVE SWITCH. EspModule publishes
        // EspModule::optic_root_corrector into game_state each frame, so this can
        // be thrown MID-RAID. That is the whole reason this is not env-var-only:
        // setting up an off-centre magnified optic takes minutes, so a switch that
        // can only be set before launching makes the one A/B that decides this
        // investigation cost two relaunches instead of two clicks.
        //
        // Checked before the cached read so the checkbox wins when set, while the
        // env var still overrides when it disagrees (a launch script capturing a
        // state explicitly).
        if (game_state::optic_root_corrector_off.load(std::memory_order_relaxed))
            return true;

        // CACHED, and it must stay that way. The first version of this read the
        // environment on every call, which is wrong for where it is called:
        // `acquire_packet`'s corrector consults it once per accepted sample, i.e.
        // every frame, and `GetEnvironmentVariableA` walks the process environment
        // block each time. `static const` does the read exactly once, which is
        // also what the original `std::getenv` version did -- the caching was
        // never the problem, the C4996 warning was, and fixing the warning by
        // swapping the API dropped a property the original had for free.
        //
        // A kill switch that can change mid-session would be less useful, and the
        // comment above says "set it and start the game", so once-per-process is
        // the intended semantics rather than a compromise.
        static const bool off = [] {
            char buf[8] = {};
            const DWORD n = GetEnvironmentVariableA("TA_OPTIC_ROOT_CORRECTOR_OFF",
                buf, static_cast<DWORD>(sizeof(buf)));
            // n == 0 means unset, OR the variable exists and is empty. Both mean
            // "not disabled". n >= sizeof(buf) means the value did not fit, which
            // for this switch can only be a non-"0" value, so treat it as SET
            // rather than silently running the corrector the operator asked to
            // turn off.
            if (n == 0) return false;
            if (n >= sizeof(buf)) return true;
            return std::strcmp(buf, "0") != 0;
        }();
        return off;
    }

    // ---- root-corrector per-frame summary (ACTIVE INVESTIGATION) -------------
    //
    // Turns the frame ring into the numbers that actually discriminate between the
    // candidate causes of the reported shake, and returns them as printable text.
    //
    // The central number is `move`: the per-frame change in the camera-local root
    // position, in mm. The spec says this should be near-constant, i.e. `move`
    // near zero. Everything else is read against that:
    //
    //   move smooth and oscillating, corr tracking it  -> the game's weapon sway,
    //     faithfully passed through. Compensating it is intended; smooth it.
    //   move jagged, sign reversing frame to frame      -> our sampling is noisy.
    //   corr spikes on stale-sample frames              -> the zero-to-nothing
    //     discontinuity, which the 9-in-102 stale frames show happening.
    //
    // `reversals` is the cheap discriminator for the second case: genuine sway at
    // 60 Hz reverses every half cycle (~30 frames), so a sign flip roughly every
    // few frames means noise rather than sway. `dt_spread` catches the other
    // candidate -- a zero-order hold evaluated at irregular intervals injects
    // jitter on its own, and dt has never been logged.
    //
    // Uses insertion sort rather than std::sort because n <= 96 and this runs on
    // the 600 ms dump cadence; no allocation, no recursion.
    inline int root_frame_summary(char* out, int out_size) {
        const int n = g_root_ring_filled;
        if (n < 2) {
            return std::snprintf(out, out_size,
                "root-frame: only %d frame(s) recorded; nothing to summarise", n);
        }
        int start = (g_root_ring_head - n + kRootRing) % kRootRing;

        float move[kRootRing], corr[kRootRing], dts[kRootRing];
        int nm = 0, nc = 0, nd = 0;
        int applied_n = 0, reversals = 0, stale_drops = 0;
        int move_over_1mm = 0, move_over_5mm = 0;
        float last_sign = 0.f;
        float prev_x = 0.f, prev_y = 0.f, prev_z = 0.f;
        bool have_prev = false;
        int prev_applied = 0;
        // Suspicious-frame tracking. `worst_*` describes the WORST single frame of the
        // window; the `prev_*` pair is the frame immediately before it, because
        // "the node changed between these two" is the comparison that matters.
        float worst_move_mm = 0.f;
        int worst_idx = -1;
        unsigned long long worst_prev_ptr = 0, prev_node_ptr = 0;
        unsigned int worst_prev_depth = 0, prev_depth = 0;
        bool have_prev_node = false, worst_have_prev = false;
        int nonfinite_frames = 0;

        for (int i = 0; i < n; ++i) {
            const root_frame_sample& s = g_root_ring[(start + i) % kRootRing];
            applied_n += s.applied;
            if (s.applied) corr[nc++] = s.corr_mm;
            if (s.had_local && s.dt) dts[nd++] = (float)s.dt;

            if (s.had_local) {
                float dx = s.local_x - prev_x;
                float dy = s.local_y - prev_y;
                float dz = s.local_z - prev_z;
                if (have_prev) {
                    const float m = std::sqrt(dx * dx + dy * dy + dz * dz);
                    move[nm++] = m;
                    if (m > 1.f) ++move_over_1mm;
                    if (m > 5.f) ++move_over_5mm;
                    const float sign = (dx != 0.f) ? (dx > 0.f ? 1.f : -1.f) : 0.f;
                    if (sign != 0.f) {
                        if (last_sign != 0.f && sign != last_sign) ++reversals;
                        last_sign = sign;
                    }
                    // ---- SUSPICIOUS FRAME (2026-10-05, corrected 2026-10-06) ----
                    // Keep the single worst frame of the window, verbatim, with the
                    // identity of the node behind it. A summary of the distribution
                    // cannot answer "which frame, and over what interval" -- the
                    // 56,557 mm reading survived every median and every percentile
                    // because it is one frame among ninety-six, AND it meant nothing
                    // until someone paired it with dt and found a 45 s gap.
                    //
                    // dt is the reason this records a frame rather than just a
                    // magnitude. `move` alone cannot distinguish a step from a hole
                    // in the sampling; the pair can. See kSuspiciousMoveMm above for
                    // why that threshold was chosen from measurement rather than from
                    // the (wrong) 216 mm figure.
                    if (m > kSuspiciousMoveMm && m > worst_move_mm) {
                        worst_move_mm = m;
                        worst_idx = (start + i) % kRootRing;
                        worst_prev_ptr = have_prev_node ? prev_node_ptr : 0;
                        worst_prev_depth = have_prev_node ? prev_depth : 0;
                        worst_have_prev = have_prev;
                    }
                }
                prev_x = s.local_x; prev_y = s.local_y; prev_z = s.local_z;
                have_prev = true;
                prev_node_ptr = s.node_ptr;
                prev_depth = s.parent_depth;
                have_prev_node = true;
            }
            if (!s.finite) ++nonfinite_frames;
            // A frame that applied nothing immediately after one that did is the
            // snap-to-zero discontinuity. Counted separately from `stale` because
            // it is the only one of the two that is visible as a jump.
            if (prev_applied && !s.applied) ++stale_drops;
            prev_applied = s.applied;
        }

        auto median = [](float* v, int c) -> float {
            if (c <= 0) return -1.f;
            for (int i = 1; i < c; ++i) {
                const float key = v[i];
                int j = i - 1;
                while (j >= 0 && v[j] > key) { v[j + 1] = v[j]; --j; }
                v[j + 1] = key;
            }
            return v[c / 2];
        };

        float move_med = median(move, nm);
        float move_max = 0.f;
        for (int i = 0; i < nm; ++i) if (move[i] > move_max) move_max = move[i];
        float corr_med = median(corr, nc);
        float corr_max = 0.f;
        for (int i = 0; i < nc; ++i) if (corr[i] > corr_max) corr_max = corr[i];
        float dt_med = median(dts, nd);
        float dt_max = 0.f;
        for (int i = 0; i < nd; ++i) if (dts[i] > dt_max) dt_max = dts[i];

        // snprintf returns the length it WOULD have written, so a truncated first write
        // can exceed out_size. Clamping before using it as an offset is the whole
        // reason this is not one expression -- an unclamped return value here would
        // push `out + written_len` past the end on a long window.
        int written_len = std::snprintf(out, out_size,
            "root-frame: %d frames, applied=%d | local move mm med=%.2f max=%.2f "
            "(>1mm:%d >5mm:%d of %d, sign-reversals:%d) | corr mm med=%.2f max=%.2f | "
            "dt ms med=%.0f max=%.0f | applied->dropped:%d | corrector=%s",
            n, applied_n, move_med, move_max, move_over_1mm, move_over_5mm, nm,
            reversals, corr_med, corr_max, dt_med, dt_max, stale_drops,
            root_corrector_disabled() ? "DISABLED" : "on");
        if (written_len < 0) written_len = 0;
        if (written_len >= out_size) written_len = out_size - 1;

        // The suspicious-frame report. APPENDED, not folded into the line above,
        // and printed only when there is one: a permanent "worst=none" on every
        // window is noise that trains the reader to skip the field, which is the
        // failure mode half the comments in this file are about.
        //
        // 512 bytes was the caller's buffer and is not enough for both halves on a
        // long window, so the caller was widened too (see eft_api.h).
        if (worst_idx >= 0) {
            const root_frame_sample& w = g_root_ring[worst_idx];
            const bool node_changed = worst_have_prev
                && have_prev_node && w.node_ptr != worst_prev_ptr;
            const bool depth_changed = worst_have_prev
                && have_prev_node && w.parent_depth != worst_prev_depth;
            int wrote = std::snprintf(out + written_len, out_size - written_len,
                " | worst: move=%.1fmm local=(%.1f,%.1f,%.1f) |pos|=%.1fmm dt=%llums "
                "node=%llx/%u prev=%llx/%u node_changed=%d depth_changed=%d finite=%u",
                worst_move_mm, w.local_x, w.local_y, w.local_z, w.raw_len,
                w.dt, w.node_ptr, w.parent_depth, worst_prev_ptr, worst_prev_depth,
                node_changed ? 1 : 0, depth_changed ? 1 : 0, w.finite);
            if (wrote > 0) written_len += (written_len + wrote < out_size) ? wrote : (out_size - 1 - written_len);
        }
        if (nonfinite_frames) {
            int wrote = std::snprintf(out + written_len, out_size - written_len,
                " | NONFINITE local in %d of %d frames", nonfinite_frames, n);
            if (wrote > 0) written_len += (written_len + wrote < out_size) ? wrote : (out_size - 1 - written_len);
        }
        return written_len;
    }

    // ------------------------------------------------------------ lens size gate
    // Reports the PER-FRAME decisions, which is the part the cumulative
    // `optic-lenssize:` counters cannot express. Read `reject_run_max` against
    // `kRebaselineMs`: that pair is the finding. A long reject run and a zero
    // re-baseline count cannot both be true unless accepts are interleaved, because
    // the accept path zeroes `reject_since`.
    inline int lens_size_frame_summary(char* out, int out_size) {
        const int n = g_lens_ring_filled;
        if (n < 2) {
            return std::snprintf(out, out_size,
                "lenssize-frame: only %d evaluation(s) recorded", n);
        }
        const int start = (g_lens_ring_head - n + kLensSizeRing) % kLensSizeRing;

        int rejected = 0, lo_side = 0, hi_side = 0, degenerate = 0;
        float worst_dr = 0.f;
        int worst_idx = -1;
        float worst_prev = 0.f;
        unsigned long long worst_dt = 0;
        // How many frames sat within 1% of the accept edge. The three marginal
        // rejections in the 2026-10-05 capture were 0.41-0.86% under it, which is
        // the signature of a measurement straddling its own threshold rather than a
        // measurement that is simply too small.
        int near_edge = 0;
        float rmin = 1e30f, rmax = -1e30f;

        for (int i = 0; i < n; ++i) {
            const lenssize_frame_sample& s = g_lens_ring[(start + i) % kLensSizeRing];
            rejected += s.rejected;
            lo_side += s.lo_side;
            hi_side += s.hi_side;
            degenerate += s.degenerate;
            if (s.ratio < rmin) rmin = s.ratio;
            if (s.ratio > rmax) rmax = s.ratio;
            if (std::fabs(s.ratio - s.lo_edge) <= 0.01f * s.lo_edge) ++near_edge;
            if (i > 0 && s.delta_ratio > worst_dr) {
                worst_dr = s.delta_ratio;
                worst_idx = (start + i) % kLensSizeRing;
                worst_prev = g_lens_ring[(start + i - 1 + kLensSizeRing)
                    % kLensSizeRing].ratio;
                worst_dt = s.dt;
            }
        }

        int len = std::snprintf(out, out_size,
            "lenssize-frame: %d evals, rejected=%d (lo:%d hi:%d degen:%d) "
            "| ratio %.3f..%.3f, near-edge(+-1%%):%d | "
            "runs: reject max=%d accept max=%d | kRebaselineMs=%d rebaselines=%llu",
            n, rejected, lo_side, hi_side, degenerate,
            rmin, rmax, near_edge,
            g_lens_reject_run_max, g_lens_accept_run_max,
            static_cast<int>(kRebaselineMs),
            static_cast<unsigned long long>(g_lens_size.rebaselines));
        if (len < 0) len = 0;
        if (len >= out_size) len = out_size - 1;

        // The verdict the other line cannot make. Reported as a sentence rather than
        // a field because it is an inference, and a reader should see that it is one.
        if (len + 1 < out_size) {
            const bool starved = rejected > 0
                && g_lens_size.rebaselines == 0
                && g_lens_accept_run_max > 0;
            const int w = std::snprintf(out + len, out_size - len,
                " | %s",
                starved ? "TIMER STARVED: rejected>0, rebaselines=0, and accepts "
                          "occurred, so reject_since was reset before kRebaselineMs"
                        : (rejected == 0 ? "clean" : "see runs above"));
            if (w > 0) len += (len + w < out_size) ? w : (out_size - 1 - len);
        }
        if (worst_idx >= 0 && len + 1 < out_size) {
            const lenssize_frame_sample& s = g_lens_ring[worst_idx];
            const int w = std::snprintf(out + len, out_size - len,
                " | worst d_ratio=%.4f (%.4f->%.4f) dt=%llums size=%.4f",
                worst_dr, worst_prev, s.ratio, worst_dt,
                static_cast<double>(s.size));
            if (w > 0) len += (len + w < out_size) ? w : (out_size - 1 - len);
        }
        return len;
    }

    // Section 7 dispatch accounting, so it is visible whether the main-camera pass is
    // actually doing the work the spec asks for. `outside_left_scoped` climbing while
    // `outside_drawn_main` stays at zero would mean the main camera was never published
    // and the periphery silently stayed magnified.
    // Sight-flap counters (2026-09-27). The game alternates CurrentOpticSight between
    // two adjacent instances about twice a second; each alternation used to drop the
    // route and cost up to a second of radial fallback, which showed up as the ESP zoom
    // visibly switching (auto_k 1/magnification flipping 0.166 <-> 0.761).
    struct flap_counters
    {
        unsigned long long suppressed = 0; // mismatch seen, routes proven interchangeable
        unsigned long long rebuilds = 0;   // route rebuilds actually performed
    };

    struct s7_counters
    {
        unsigned long long inside_drawn_scoped = 0;
        unsigned long long outside_drawn_main = 0;
        unsigned long long outside_culled = 0;      // outside the glass, not drawn
        unsigned long long outside_left_scoped = 0; // no main camera -> stayed magnified
        unsigned long long seg_inside = 0;          // segments clipped to the mask
        unsigned long long seg_outside_pieces = 0;  // 0..2 pieces per segment
        unsigned long long seg_dropped_nearplane = 0;
        unsigned long long box_culled = 0;  // box centre outside the glass
        unsigned long long head_culled = 0; // head circle outside the glass
    };
    inline s7_counters g_s7{};
    inline flap_counters g_flap{};

    inline bool camera_consistent(const mat4& view, const v3& pos, const float quat[4],
        float* worst_deg = nullptr, float* origin_err_out = nullptr,
        pose_axis_detail* axis_out = nullptr) {
        if (worst_deg) *worst_deg = 0.f;
        const v4 local = mat_mul_v(view, v4{pos.x, pos.y, pos.z, 1.f});
        const float origin_err = std::sqrt(local.x * local.x + local.y * local.y + local.z * local.z);
        if (origin_err_out) *origin_err_out = origin_err;
        // Capture both sides of the disagreement whenever asked, BEFORE the early return,
        // so a rejection is as informative as an acceptance. Recording only the
        // magnitude is what left the 59.4 m case uncharacterised on 2026-09-29.
        if (axis_out) {
            axis_out->world_pos = pos;
            axis_out->view_origin = v3{view.m[12], view.m[13], view.m[14]};
            axis_out->local = v3{local.x, local.y, local.z};
        }
        if (origin_err > kPoseOriginTol) return false;

        // View rows -> world axes (row2 negated per Unity view convention).
        const v3 view_axes[3] = {
            {view.m[0], view.m[4], view.m[8]},
            {view.m[1], view.m[5], view.m[9]},
            {-view.m[2], -view.m[6], -view.m[10]},
        };
        const float x = quat[0], y = quat[1], z = quat[2], w = quat[3];
        const v3 t_axes[3] = {
            {1.f - 2.f * (y * y + z * z), 2.f * (x * y + w * z), 2.f * (x * z - w * y)},
            {2.f * (x * y - w * z), 1.f - 2.f * (x * x + z * z), 2.f * (y * z + w * x)},
            {2.f * (x * z + w * y), 2.f * (y * z - w * x), 1.f - 2.f * (x * x + y * y)},
        };
        for (int i = 0; i < 3; ++i)
        {
            const v3 cr = cross3(t_axes[i], view_axes[i]);
            const float cross_len = std::sqrt(len2_3(cr));
            const float ang = std::atan2(cross_len, dot3(t_axes[i], view_axes[i]));
            const float deg = ang * 57.29577951308232f;
            if (worst_deg && deg > *worst_deg) *worst_deg = deg;
            if (deg > kPoseAxisTolDeg) return false;
        }
        return true;
    }

    // Acquire one paired sample and build the packet. Returns false when any
    // validation fails (callers fall back to the legacy path).
    //
    // `stage` receives the name of the last checkpoint reached, which for a linear
    // function like this one identifies the failing step exactly. This exists
    // because acquire_packet failed SILENTLY for a whole session: build_route has
    // always reported *why* it rejected (which is how the route bugs were found at
    // all), but every one of ~20 `return false` sites here was anonymous. The symptom
    // was only ever "pipeline=fallback" plus objects at the wrong size, with the
    // accepted-route log sitting right next to it looking like success.
    inline bool acquire_packet(const route& r, Il2CppObject* local_player, packet& out,
        const char** stage = nullptr, uintptr_t* sight_seen = nullptr,
        bool* route_stale = nullptr,
        const bool* sight_interchangeable = nullptr) {
        // Assign through a helper so `stage` stays correct even if the caller passed
        // nullptr, and so every checkpoint below is a single line.
        const char* st = "start";
        const auto mark_stage = [&st, &stage](const char* s) {
            st = s;
            if (stage) *stage = s;
        };
        // Sight pointer seen this call, reported to the caller so a mismatch can show
        // both values rather than just "it didn't match".
        if (sight_seen) *sight_seen = 0;
        mark_stage("route invalid");

        out.valid = false;
        if (!r.valid) return false;
        // Times every call including the early returns; see scoped_call_timer.
        const scoped_call_timer call_timer{};
        perf_accum& perf = perf_sections();
        double t_mark = qpc_us();
        const auto mark = [&perf, &t_mark](perf_section s) {
            const double now = qpc_us();
            perf.micros[s] += now - t_mark;
            t_mark = now;
        };

        // Cameras from the managed singleton (identity re-checked against route).
        mark_stage("managed metadata (image/class/CameraManager)");
        Il2CppImage* img = il2utils::resolve_image("Assembly-CSharp.dll");
        if (!img) return false;
        const Il2CppClass* cm_class = il2utils::resolve_class(img, "EFT.CameraControl", "CameraManager");
        if (!cm_class || !cm_class->static_fields) return false;
        uintptr_t cm_managed = 0;
        std::memcpy(&cm_managed, cm_class->static_fields, sizeof(void*));
        if (!cm_managed) return false;
        uintptr_t optic_cam_manager_managed =
            read_managed_ref_field(reinterpret_cast<Il2CppObject*>(cm_managed), "OpticCameraManager");
        if (!optic_cam_manager_managed) return false;
        // Pass the BARE name. read_managed_ref_field wraps it as
        // "<name>k__BackingField" and falls back to the bare form, so passing an
        // already-wrapped name here made it build
        // "<<CurrentOpticSight>k__BackingField>k__BackingField", miss, and only then
        // try the correct string -- a wasted snprintf plus a wasted memo lookup on
        // every single per-frame call.
        uintptr_t sight_managed = read_managed_ref_field(
            reinterpret_cast<Il2CppObject*>(optic_cam_manager_managed),
            "CurrentOpticSight");
        // Its OWN stage, and it INVALIDATES THE ROUTE.
        //
        // This used to share "managed metadata", and it used to merely return false.
        // Both were wrong, and together they were fatal:
        //   - the route is only ever rebuilt inside `if (!route_valid)` in
        //     optic_lens_ensure_frame, and nothing set route_valid back to false, so
        //     once a route was accepted it was pinned FOREVER;
        //   - acquire_packet demands an exact match against the sight pointer captured
        //     at build time, so a single post-build change to the game's
        //     <CurrentOpticSight> backing field made every subsequent packet fail
        //     permanently, with the ESP silently on the radial fallback.
        //
        // Observed 2026-09-26 23:25-23:26: route sight 0x94924480 vs live sight
        // 0x94924580 — both perfectly stable, differing by exactly 0x100, never
        // reconciling. The game appears to ALTERNATE between two adjacent OpticSight
        // instances, which fits the ISIL evidence of explicit collimator
        // enable/disable/update lifecycles. `scoped` was 0 in nearly every window, with
        // an occasional valid packet when the game's value happened to line up.
        //
        // Reporting staleness lets the caller drop route_valid and rebuild (throttled to
        // 1x/s), which re-resolves the mesh, material and transform chain for whichever
        // sight is actually in use.
        mark_stage("optic sight object changed (route rebuild pending)");
        if (sight_managed != r.optic_sight_managed)
        {
            if (sight_seen) *sight_seen = sight_managed;
            // Interchangeable-sights verdict (2026-09-27). The caller passes whether the
            // two alternating instances have been MEASURED to produce the same route --
            // same mesh geometry, same affine pieces and coverage, same lens bounds.
            //
            // When they have, the mismatch is not staleness and the packet must still be
            // built. This has to happen HERE rather than at the caller, because this
            // branch returns early: clearing `route_stale` afterwards would stop the
            // rebuild but still leave the packet unbuilt, i.e. still on the radial
            // fallback, i.e. no observable change at all. That was the first attempt.
            //
            // Continuing is correct, not a compromise: the route contributes the affine
            // map and the lens bounds, and the camera -- which carries the magnification
            // -- is read live below regardless of which instance the route came from.
            // The old instance stays alive (the game swaps which of two it calls
            // current), and if it ever did not, the all_finite and HC.w gates below
            // reject the packet rather than drawing garbage.
            if (sight_interchangeable && *sight_interchangeable)
            {
                ++g_flap.suppressed;
            }
            else
            {
                if (route_stale) *route_stale = true;
                return false;
            }
        }
        mark_stage("camera components");

        uintptr_t main_cam_managed =
            read_managed_ref_field(reinterpret_cast<Il2CppObject*>(cm_managed), "Camera");
        uintptr_t optic_cam_managed = read_managed_ref_field(
            reinterpret_cast<Il2CppObject*>(optic_cam_manager_managed), "Camera");
        if (!main_cam_managed || !optic_cam_managed) return false;
        const uintptr_t main_native = native_of(reinterpret_cast<Il2CppObject*>(main_cam_managed));
        const uintptr_t optic_native = native_of(reinterpret_cast<Il2CppObject*>(optic_cam_managed));
        if (!main_native || !optic_native) return false;
        mark(perf_metadata);

        mat4 main_view{}, main_vp{}, optic_view{}, optic_vp{};
        mark_stage("camera matrices read");
        if (!read_camera_matrices(main_native, main_view, main_vp)) return false;
        if (!read_camera_matrices(optic_native, optic_view, optic_vp)) return false;
        mark(perf_matrices);

        // Camera pose consistency (doc section 6). The two sub-checks are staged
        // separately: "transform pose" is finding the Transform and walking the
        // hierarchy, "pose consistency" is the numeric agreement gate, and they fail
        // for entirely different reasons.
        v3 main_pos;
        float main_quat[4];
        mark_stage("camera transform pose (main)");
        if (!camera_transform_pose(main_native, main_pos, main_quat)) return false;
        v3 optic_pos;
        float optic_quat[4];
        mark_stage("camera transform pose (optic)");
        if (!camera_transform_pose(optic_native, optic_pos, optic_quat)) return false;
        mark_stage("camera pose consistency");
        {
            // Log the numbers this gate rejects on. They were computed and discarded,
            // so a "camera pose consistency" rejection said only THAT it failed, never
            // by how much -- and the two sub-checks (a 0.05-degree axis disagreement
            // and a 1e-3 world-unit origin error) have completely different causes and
            // completely different fixes.
            float worst_deg = 0.f, origin_err = 0.f;
            float main_deg = 0.f, main_org = 0.f;
            float optic_deg = 0.f, optic_org = 0.f;
            // Per-axis capture, so the reject line can name the offending axis instead
            // of printing a magnitude that has to be re-derived by hand.
            pose_axis_detail main_axis{}, optic_axis{};
            const bool main_ok = camera_consistent(main_view, main_pos, main_quat, &main_deg,
                &main_org, &main_axis);
            const bool optic_ok = camera_consistent(optic_view, optic_pos, optic_quat, &optic_deg,
                &optic_org, &optic_axis);
            if (!main_ok || !optic_ok)
            {
                // ---- one re-read, then decide (2026-09-29) ------------------------
                //
                // On a failing frame the view matrix is being written by the game while
                // we read it: its translation column comes back exactly zero and its
                // rotation is bit-exact, so `origin_err` degenerates to |camera position|.
                // Re-reading the same bytes microseconds later sees the finished matrix.
                //
                // Everything is re-read, not just the matrix. The inconsistency could
                // equally be a half-updated Transform node walk, and pairing a fresh
                // matrix against the stale pose would only move the error around -- which
                // is exactly the class of bug that produced the contradictory `optic-root`
                // line fixed earlier today.
                //
                // Cost is zero on the happy path: this block is unreachable unless the
                // first read already failed. No managed Unity API is called, so this
                // introduces no new thread-safety exposure -- it is the same native read
                // already performed, which is the distinction that matters after the
                // ScopeMaskRenderer crash.
                const double t0 = qpc_us();
                const bool re_read =
                    read_camera_matrices(main_native, main_view, main_vp) &&
                    read_camera_matrices(optic_native, optic_view, optic_vp) &&
                    camera_transform_pose(main_native, main_pos, main_quat) &&
                    camera_transform_pose(optic_native, optic_pos, optic_quat);
                const double us = qpc_us() - t0;

                float r_main_deg = 0.f, r_main_org = 0.f;
                float r_optic_deg = 0.f, r_optic_org = 0.f;
                pose_axis_detail r_main_axis{}, r_optic_axis{};
                const bool r_main_ok = re_read &&
                    camera_consistent(main_view, main_pos, main_quat, &r_main_deg,
                        &r_main_org, &r_main_axis);
                const bool r_optic_ok = re_read &&
                    camera_consistent(optic_view, optic_pos, optic_quat, &r_optic_deg,
                        &r_optic_org, &r_optic_axis);

                ++g_pose_retry.attempts;
                g_pose_retry.last_us = us;
                if (us > g_pose_retry.max_us) g_pose_retry.max_us = us;

                if (r_main_ok && r_optic_ok)
                {
                    // Recovered. The retried values are already in the locals the rest of
                    // the function reads, so there is nothing to copy and nothing to
                    // invalidate -- the packet simply continues.
                    ++g_pose_retry.recovered;
                    main_deg = r_main_deg;
                    main_org = r_main_org;
                    optic_deg = r_optic_deg;
                    optic_org = r_optic_org;
                }
                else
                {
                    // Still inconsistent. Report the RETRIED numbers, not the first
                    // read's: they are what the reject is about, and the first read's were
                    // a torn sample.
                    // Explicit template argument, not (std::max)(...) : windows.h defines
                    // max/min as macros, and a bare std::max(a, b) gets macro-expanded.
                    // std::max<float>(...) is safe because `max` is followed by `<`.
                    worst_deg = std::max<float>(r_main_deg, r_optic_deg);
                    origin_err = std::max<float>(r_main_org, r_optic_org);
                    mark_pose_reject(r_main_deg, r_main_org, r_optic_deg, r_optic_org);
                    g_pose_reject.main_axis = r_main_axis;
                    g_pose_reject.optic_axis = r_optic_axis;
                    // The positions and view translations the check actually used, so the
                    // log can answer "is org just |view_org| again, i.e. did pos come back
                    // zero?" by reading rather than by reconstructing it from a magnitude.
                    // See the note on pose_reject_detail.
                    g_pose_reject.main_pos[0] = main_pos.x;
                    g_pose_reject.main_pos[1] = main_pos.y;
                    g_pose_reject.main_pos[2] = main_pos.z;
                    g_pose_reject.optic_pos[0] = optic_pos.x;
                    g_pose_reject.optic_pos[1] = optic_pos.y;
                    g_pose_reject.optic_pos[2] = optic_pos.z;
                    g_pose_reject.main_vorg[0] = main_view.m[12];
                    g_pose_reject.main_vorg[1] = main_view.m[13];
                    g_pose_reject.main_vorg[2] = main_view.m[14];
                    g_pose_reject.optic_vorg[0] = optic_view.m[12];
                    g_pose_reject.optic_vorg[1] = optic_view.m[13];
                    g_pose_reject.optic_vorg[2] = optic_view.m[14];

                    // Which matrix are we holding? See camera_matrix_probe. Emitted
                    // once per distinct signature so a 25-second bad stretch produces
                    // one line rather than one per frame.
                    for (int i = 0; i < 2; ++i)
                    {
                        const uintptr_t cam = i == 0 ? main_native : optic_native;
                        const camera_matrix_probe pr = probe_camera_matrices(cam);
                        const std::string sig = camera_matrix_signature(pr);
                        static std::string s_main, s_optic;
                        std::string& last = i == 0 ? s_main : s_optic;
                        if (sig != last)
                        {
                            last = sig;
                            logger::debug(std::format(
                                "optic-matrix: {} sig={} |r0| view={:.4f} +0xE8={:.4f} "
                                "+0x780={:.4f} (view must be 1.0000) | t view=({:.3f},"
                                "{:.3f},{:.3f}) +0xE8=({:.3f},{:.3f},{:.3f})",
                                i == 0 ? "main" : "optic", sig,
                                static_cast<double>(pr.view_r0),
                                static_cast<double>(pr.act_r0),
                                static_cast<double>(pr.nj_r0),
                                static_cast<double>(pr.view_t[0]),
                                static_cast<double>(pr.view_t[1]),
                                static_cast<double>(pr.view_t[2]),
                                static_cast<double>(pr.act_t[0]),
                                static_cast<double>(pr.act_t[1]),
                                static_cast<double>(pr.act_t[2])));
                        }
                    }
                    return false;
                }
            }
        }
        mark(perf_pose);

        // Live material vectors.
        v4 scales{}, shifts{}, shift_dir{};
        mark_stage("live material vectors");
        if (!read_v4(r.scales_addr, scales) || !read_v4(r.shifts_addr, shifts) || !read_v4(r.shift_dir_addr, shift_dir))
            return false;
        if (!all_finite4(scales) || !all_finite4(shifts) || !all_finite4(shift_dir)) return false;

        // Lens chain composition with FOV normalization (doc section 6).
        mark_stage("lens transform hierarchy");
        uintptr_t hierarchy = 0;
        uint32_t index = 0;
        if (!read_ptr(r.lens_transform_native + 0x70, hierarchy) || !hierarchy) return false;
        if (!read_u32(r.lens_transform_native + 0x78, index) || index >= 65536) return false;
        uintptr_t parents = 0, nodes = 0;
        if (!read_ptr(hierarchy + 0x40, parents) || !read_ptr(hierarchy + 0x68, nodes)) return false;

        float ribcage_scale = 0.f;
        {
            // Player.RibcageScaleCurrent (managed float field).
            if (local_player && local_player->klass)
            {
                if (const FieldInfo* f = field_in_hierarchy(local_player->klass, "RibcageScaleCurrent"))
                {
                    std::memcpy(&ribcage_scale,
                        reinterpret_cast<const void*>(
                            reinterpret_cast<uintptr_t>(local_player) + f->offset),
                        4);
                }
            }
        }
        const bool fov_scale_ok = ribcage_scale > 0.1f && ribcage_scale < 3.f;

        mat4 lens_m{};
        bool hands_self_is_ancestor = false;
        bool captured_hands_self = false;
        v3 hands_self_world{};
        // Which node produced hands_self_world, and how far down the chain it sat.
        // Set at the same moment as the position above. Read by the suspicious-frame
        // report to tell a REPLACED node from an impossible position on the SAME
        // node; see the note at that assignment.
        unsigned long long hands_self_node_ptr = 0;
        unsigned int hands_self_depth = 0;
        // Each exit below gets its OWN stage name.
        //
        // 2026-10-02. This block was nine distinct `return false` paths under one
        // "lens chain walk" label, and that label then turned out to be 77% of all packet
        // rejections (880 of 1,146) -- so the instrument said "the chain walk is the
        // problem" and stopped there. Which is the same failure as the `other` bucket,
        // one level up: a coarse label hides the answer inside itself. Nine exits, nine
        // names, and the 880 splits into something actionable.
        //
        // Read failures are distinguished from value rejections on purpose. "It could not
        // read the node" is a stale-pointer problem and "the FOV node is not in the chain"
        // is a scene-graph-shape problem, and they have nothing in common as fixes.
        mark_stage("lens chain walk: enter");
        {
            uint32_t chain_index = index;
            int guard = 0;
            bool saw_fov_self = false;
            while (chain_index != 0xFFFFFFFFu && guard++ < 64)
            {
                if (chain_index >= 65536) {
                    mark_stage("lens chain walk: node index out of range");
                    return false;
                }
                const uintptr_t node = nodes + static_cast<uintptr_t>(chain_index) * 48;
                v3 p;
                v4 q;
                v3 s;
                if (!read_v3(node, p) || !read_v4(node + 16, q) || !read_v3(node + 32, s)) {
                    mark_stage("lens chain walk: node read failed");
                    return false;
                }
                if (!all_finite3(p) || !all_finite4(q) || !all_finite3(s)) {
                    mark_stage("lens chain walk: non-finite TRS");
                    return false;
                }
                const float lensq = q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w;
                if (lensq < 0.5f || lensq > 1.5f) {
                    mark_stage("lens chain walk: quaternion magnitude out of family");
                    return false;
                }

                for (int fi = 0; fi < 3; ++fi)
                {
                    if (r.fov_nodes[fi] && node == r.fov_nodes[fi])
                    {
                        if (std::fabs(s.x - 1.f) > 0.001f || std::fabs(s.y - 1.f) > 0.001f) {
                            mark_stage("lens chain walk: FOV node xy scale != 1");
                            return false;
                        }
                        if (fov_scale_ok && (s.z < 0.1f || s.z > 3.f)) {
                            mark_stage("lens chain walk: FOV node z scale out of family");
                            return false;
                        }
                        if (fov_scale_ok) s.z = ribcage_scale;
                        if (fi == 0)
                        {
                            saw_fov_self = true;
                            // HandsHierarchy.Self is ancestor #0; after the multiply
                            // below, lens_m's translation IS this node's world position.
                            // That is the point the spec's root filter needs.
                            hands_self_is_ancestor = true;
                        }
                    }
                }
                lens_m = mat_mul(trs(p, q, s), lens_m);
                if (hands_self_is_ancestor && !captured_hands_self)
                {
                    hands_self_world = {lens_m.m[12], lens_m.m[13], lens_m.m[14]};
                    captured_hands_self = true;
                    // Identity and depth of the node that produced this position,
                    // for the suspicious-frame report. `chain_index` is the walk's
                    // own hop counter and `node` the pointer it read at this hop, so
                    // both are already in hand -- no extra traversal, and nothing
                    // that can itself fault.
                    //
                    // The point is to distinguish "the node was replaced" from "the same
                    // node reported an impossible position". The 2026-10-05 A/B
                    // produced a 56,557 mm reading in camera-local space, which
                    // looked like the second case -- except it turned out to be the
                    // first sample after a 45 s gap, so it was neither. A changing
                    // `node` or a changing `chain_index` on a bad frame is what
                    // separates the two, and dt (already in the ring) is what
                    // separates a step from a hole in the sampling. Both are needed:
                    // the identity fields without dt still left the 2026-10-05
                    // capture ambiguous.
                    hands_self_node_ptr = static_cast<unsigned long long>(node);
                    hands_self_depth = static_cast<unsigned int>(chain_index);
                }
                if (!read_u32(parents + static_cast<uintptr_t>(chain_index) * 4, chain_index)) {
                    mark_stage("lens chain walk: parent read failed");
                    return false;
                }
            }
            if (guard >= 64) {
                mark_stage("lens chain walk: depth guard (64) exhausted");
                return false;
            }
            // HandsHierarchy.Self must be a lens ancestor (not the lens itself).
            if (!saw_fov_self) {
                mark_stage("lens chain walk: FOV node not found in chain");
                return false;
            }
        }
        mark(perf_lens_chain);

        // ---------------------------------------------------------------------
        // Root-position outlier filter (optic_idea.md section 6, line 476).
        //
        // The HandsHierarchy.Self node is rigidly attached to the camera, so its
        // position expressed in CAMERA-LOCAL space is near-constant. When the two
        // representations of the camera disagree by more than the consistency gate
        // allows, that local position jumps, and the lens matrix inherits the jump.
        // The spec's remedy: extrapolate the local position from recent TRUSTED
        // history and correct only the translation.
        //
        // Deliberately faithful to the spec's guardrails, all of which exist because
        // the naive version of this filter is worse than no filter:
        //   - never train on a predicted value (that compounds and drifts)
        //   - never extend the deadline (that turns a 50 ms window into unbounded lag)
        //   - never suppress genuine sustained movement (so the trend must agree)
        //   - reset on rig or zoom change (history across two optics is meaningless)
        //   - DO NOT run when the packet is already inconsistent: the spec says
        //     outright that a root filter cannot repair that, and on this build the
        //     gate rejects with org~0.057 m, so the filter is expected to be a no-op
        //     until the ORIGIN disagreement is understood. It is instrumented to say
        //     so rather than to be quietly absent.
        //
        // The 20 mm / 50 ms bounds are the spec's own values, not tuned constants.
        // ---------------------------------------------------------------------
        mark_stage("root-position outlier filter");

        // ---------------------------------------------------------------------
        // ACTIVE INVESTIGATION (2026-10-05): per-frame root-corrector telemetry.
        //
        // REPORTED SYMPTOM: when the optic centre is not at screen centre the
        // picture shakes violently.
        //
        // WHY THE EXISTING DIAGNOSTIC CANNOT ANSWER THAT. `optic-root:` is
        // printed on the 600 ms dump cadence, and consecutive lines were measured
        // at a median 611 ms apart. So every per-frame quantity in this file has
        // never been observed -- the log only ever showed the 600 ms DRIFT, which
        // is a different quantity from the jitter someone is looking at. An
        // earlier analysis of mine computed "frame-to-frame |delta| mean 4.25 mm"
        // from those lines; that was wrong by construction, because the samples
        // are 600 ms apart, not one frame.
        //
        // WHAT TO MEASURE INSTEAD. The spec's premise for this filter (section 6,
        // line 476) is that the HandsHierarchy.Self node is rigidly attached to the
        // camera, so its CAMERA-LOCAL position is near-constant, and a filter is
        // only needed when that position jumps. Measured on 6ac2b1f3 the premise
        // is FALSE: the applied correction had a median magnitude of 1.32 mm and
        // reached 19.62 mm over 84 applied frames, which can only happen if
        // `local` itself is moving by millimetres. The corrector then cancels that
        // motion every frame.
        //
        // So the question splits cleanly, and `local` settles it:
        //   - `local` moves smoothly and sinusoidally  -> the game's weapon sway,
        //     faithfully passed through. Compensating it is intended; it needs
        //     smoothing, not removal.
        //   - `local` moves jaggedly / reverses per frame -> noise in how we
        //     SAMPLE it, and that is ours.
        // Either way `local` per frame is the measurement that discriminates, and
        // it has never been logged.
        //
        // The ring itself (`root_frame_sample`, `kRootRing`, `g_root_ring*`) is
        // declared with `root_frame_summary()` near the top of this namespace,
        // because that function reads it and namespace-scope lookup is
        // definition-order. See the note there for the whole diagnosis; this is
        // only the pointer.
        // ---------------------------------------------------------------------

        // `root_corrector_disabled()` is declared with the ring at the top of this
        // namespace. It used to live here, inside `camera_consistent()`'s body,
        // which is the same declaration-order defect the ring had: a namespace
        // scope function (`root_frame_summary`) calling something declared inside
        // a function body.

        // Records one frame. Called on EVERY path through the corrector, including
        // the ones that apply nothing: a frame where the sample went stale is
        // exactly the frame that produces a visible pop, so it is the one most
        // worth keeping.
        auto record_root_frame = [](const v3* local, float corr_mm,
                                    ULONGLONG dt, bool applied,
                                    unsigned long long node_ptr = 0,
                                    unsigned int parent_depth = 0) {
            root_frame_sample& s = g_root_ring[g_root_ring_head];
            s.local_x = local ? local->x * 1000.f : 0.f;
            s.local_y = local ? local->y * 1000.f : 0.f;
            s.local_z = local ? local->z * 1000.f : 0.f;
            s.corr_mm = corr_mm;
            s.dt = dt;
            s.applied = applied ? 1 : 0;
            s.had_local = local ? 1 : 0;
            s.node_ptr = node_ptr;
            s.parent_depth = parent_depth;
            s.raw_len = local ? std::sqrt(local->x * local->x
                + local->y * local->y + local->z * local->z) * 1000.f : 0.f;
            // isfinite, not a comparison against a threshold: a NaN fails every
            // comparison, so `len < kSaneLen` would classify it as fine. That is
            // the whole reason this is a separate flag.
            s.finite = (local
                && std::isfinite(local->x)
                && std::isfinite(local->y)
                && std::isfinite(local->z)) ? 1u : 0u;
            g_root_ring_head = (g_root_ring_head + 1) % kRootRing;
            if (g_root_ring_filled < kRootRing) ++g_root_ring_filled;
        };

        {
            static constexpr float kRootCorrMax = 0.020f; // 20 mm
            static constexpr int kRootWindowMs = 50;      // 50 ms
            // History of camera-local root positions. Deliberately a small fixed ring:
            // this is a latency-bounded predictor, not a filter bank.
            struct sample
            {
                ULONGLONG t;
                v3 local;
                bool valid;
            };
            static sample hist[4]{};
            static int head = 0;
            static int have = 0;

            const bool packet_consistent = !g_pose_reject.valid;
            bool applied = false;
            float cand_mm = -1.f;    // magnitude considered; -1 = none computed
            float applied_mm = 0.f;  // magnitude actually written into the matrix
            const char* why_not = "no hands-self sample";
            // Per-frame telemetry. `local` is only valid in the else-branch below,
            // so these carry the sample through to record_root_frame on every exit.
            const v3* local_ptr = nullptr;
            ULONGLONG sample_dt = 0;

            if (!captured_hands_self)
            {
                why_not = "hands-self world position not captured";
            }
            else if (!packet_consistent)
            {
                // The spec's explicit rule. Also the expected steady state on this
                // build, which is precisely why this is logged rather than hidden.
                why_not = "packet inconsistent (spec: a root filter cannot repair this)";
            }
            else
            {
                // main_vp is projection*view; the view's rotation is what maps world
                // deltas into camera-local. Rows 0/1/-row2 give the world axes implied
                // by the view, per section 6.
                const mat4& V = main_view;
                const v3 cam_world{V.m[12], V.m[13], V.m[14]};
                const v3 d{hands_self_world.x - cam_world.x,
                    hands_self_world.y - cam_world.y,
                    hands_self_world.z - cam_world.z};
                // local = R_view^T * d, with R_view^T rows = columns of R_view.
                const v3 local{
                    V.m[0] * d.x + V.m[1] * d.y + V.m[2] * d.z,
                    V.m[4] * d.x + V.m[5] * d.y + V.m[6] * d.z,
                    V.m[8] * d.x + V.m[9] * d.y + V.m[10] * d.z};

                const ULONGLONG now = GetTickCount64();
                // Predict from the most recent TRUSTED sample only, and only if it is
                // recent enough to be informative. With a 50 ms window and a ~16 ms
                // timer, a single prior sample is the only thing usually available.
                if (have > 0)
                {
                    const sample& prev = hist[(head + 3) % 4];
                    const ULONGLONG dt = now - prev.t;
                    local_ptr = &local;
                    sample_dt = dt;
                    if (prev.valid && dt > 0 && dt <= static_cast<ULONGLONG>(kRootWindowMs))
                    {
                        // Zero-order hold on the last TRUSTED camera-local position.
                        // Only one prior sample is retained inside the 50 ms window, so
                        // no velocity can be estimated here; this is the conservative
                        // form of the spec's "compare against trusted recent motion" --
                        // "where the root was <=50 ms ago" -- and it cannot overshoot,
                        // which an extrapolated velocity could.
                        const v3 corr{prev.local.x - local.x,
                            prev.local.y - local.y,
                            prev.local.z - local.z};
                        const float mag = std::sqrt(corr.x * corr.x + corr.y * corr.y + corr.z * corr.z);
                        if (mag <= kRootCorrMax)
                        {
                            // back to world: local axes are R_view columns, so
                            // world = R_view * local for the rotation part.
                            const v3 world{
                                V.m[0] * corr.x + V.m[4] * corr.y + V.m[8] * corr.z,
                                V.m[1] * corr.x + V.m[5] * corr.y + V.m[9] * corr.z,
                                V.m[2] * corr.x + V.m[6] * corr.y + V.m[10] * corr.z};
                            // KILL SWITCH. See root_corrector_disabled(): the corrector
                            // is skipped entirely rather than scaled down, so a shake
                            // that survives with this set is NOT this filter.
                            if (!root_corrector_disabled()) {
                                lens_m.m[12] += world.x;
                                lens_m.m[13] += world.y;
                                lens_m.m[14] += world.z;
                                applied = true;
                                applied_mm = mag * 1000.f;
                            } else {
                                why_not = "correction computed but SUPPRESSED by "
                                          "TA_OPTIC_ROOT_CORRECTOR_OFF";
                            }
                            cand_mm = mag * 1000.f;
                            // BUG FIX (2026-09-29 20:40). This was left at its
                            // initialiser, "no hands-self sample", on the success path.
                            // The log therefore read
                            //     applied=1 corr=15.67mm hands_self=1 -- no hands-self sample
                            // i.e. it claimed there was no sample while reporting a
                            // correction derived from one. The string is printed
                            // unconditionally, so every positive result was contradicted
                            // by its own reason field. A diagnostic that is routinely
                            // false is worse than no diagnostic: it trains the reader to
                            // ignore the field.
                            why_not = "applied (within 20 mm budget)";
                        }
                        else
                        {
                            // Report what the candidate actually was. Without this the
                            // refusal path prints 0.00 mm and reads as "nothing to
                            // correct" rather than "a correction was needed and was
                            // rejected for being too large" -- which is the whole point
                            // of the budget.
                            cand_mm = mag * 1000.f;
                            why_not = "correction over 20 mm budget (not suppressed)";
                        }
                    }
                    else
                    {
                        why_not = (dt > static_cast<ULONGLONG>(kRootWindowMs))
                            ? "no trusted sample within 50 ms"
                            : "prior sample invalid";
                    }
                }
                // Record the MEASURED value only -- never a corrected one. This is the
                // spec's "never train on predicted replacements" rule, and it is the
                // difference between a bounded corrector and a runaway one.
                hist[head] = {now, local, true};
                head = (head + 1) % 4;
                if (have < 4) ++have;
            }
            // Every frame, on every exit path. A frame that applied nothing is not
            // a frame to discard: the 9-in-102 stale-sample frames are where the
            // correction snaps to zero, and that discontinuity is a candidate cause
            // of the visible pop.
            record_root_frame(local_ptr, applied_mm, sample_dt, applied,
                hands_self_node_ptr, hands_self_depth);
            g_root_filter_note = {applied, cand_mm, applied_mm, why_not, packet_consistent,
                captured_hands_self};
        }

        // Pre-adjust copy of the lens local->world matrix, for the Defect A silhouette
        // measurement only. Taken HERE because the shader adjustment immediately below
        // rescales lens_m's Y basis by k = |X|/|Y|, and a silhouette measured through an
        // adjusted matrix would be reporting the shader's distortion rather than the
        // geometry's shape -- which is the opposite of what the comparison needs.
        const mat4 lens_world_unadjusted = lens_m;

        // Shader lens-matrix adjustment: Y-axis length := X-axis length.
        mark_stage("shader lens-matrix adjust");
        {
            const float xl = std::sqrt(lens_m.m[0] * lens_m.m[0] + lens_m.m[1] * lens_m.m[1] + lens_m.m[2] * lens_m.m[2]);
            const float yl = std::sqrt(lens_m.m[4] * lens_m.m[4] + lens_m.m[5] * lens_m.m[5] + lens_m.m[6] * lens_m.m[6]);
            if (xl <= 1e-6f || yl <= 1e-6f) return false;
            const float k = xl / yl;
            lens_m.m[4] *= k;
            lens_m.m[5] *= k;
            lens_m.m[6] *= k;
        }

        // Combined matrix (doc section 7): rows 0,1,3 replaced.
        const float sx = scales.x;
        const v3 shift{shift_dir.x, shift_dir.y, shift_dir.z};
        const v3 cu = r.map.u_axis * (sx * 0.05f);
        const v3 cv = r.map.v_axis * (sx * 0.05f);
        const v3 cc = r.map.center * sx + shift * shifts.x;
        const mat4 lens_view = mat_mul(main_vp, lens_m);
        const v4 HU = mat_mul_v(lens_view, v4{cu.x, cu.y, cu.z, 0.f});
        const v4 HV = mat_mul_v(lens_view, v4{cv.x, cv.y, cv.z, 0.f});
        const v4 HC = mat_mul_v(lens_view, v4{cc.x, cc.y, cc.z, 1.f});
        if (!all_finite4(HU) || !all_finite4(HV) || !all_finite4(HC)) return false;
        mark_stage("lens image basis (HC.w-|HU.w|-|HV.w| > 0.001)");
        if (!(HC.w - std::fabs(HU.w) - std::fabs(HV.w) > 0.001f)) return false;

        mat4 combined = optic_vp;
        for (int row : {0, 1, 3})
        {
            float v[4];
            for (int c = 0; c < 4; ++c)
                v[c] = (vcomp(HU, row) * optic_vp.at(0, c) + vcomp(HV, row) * optic_vp.at(1, c) + vcomp(HC, row) * optic_vp.at(3, c)) / HC.w;
            combined.set_row(row, v);
        }
        // column 2 (depth) left as optic_vp copy — mapping is for X/Y/W only.
        //
        // `combined` is still BUILT and still logged (optic-vp / optic-cond), but it is
        // no longer the projection path: measured on 2026-09-27 its landing sat at ndc x
        // -1.55..-1.97 while image_quad stayed centred on the origin, so routing
        // project_point through it put ESP off-screen. project_point now uses the
        // spec's primary chain instead, which reproduces imageQuad at the four corners
        // by construction. Retained for the diagnostics that made the divergence
        // visible — optic_cond's gate_margin and combined.w are what exposed the
        // scene-origin dependence in the row-3 divisor.

        out.combined = combined;
        out.optic_vp = optic_vp;

        // Image quad in main-screen NDC (doc order: CCW).
        mark_stage("image quad corners");
        const float corners[4][2] = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
        for (int i = 0; i < 4; ++i)
        {
            const float cx = corners[i][0], cy = corners[i][1];
            const v4 corner{HC.x + HU.x * cx + HV.x * cy, HC.y + HU.y * cx + HV.y * cy,
                HC.z + HU.z * cx + HV.z * cy, HC.w + HU.w * cx + HV.w * cy};
            if (!all_finite4(corner) || std::fabs(corner.w) < 1e-9f) return false;
            out.image_quad[i] = {corner.x / corner.w, corner.y / corner.w};
        }

        // Ellipse from projected renderer bounds (doc section 7).
        mark_stage("ellipse: renderer bounds not in front of main camera");
        {
            // RE-READ the world bounds every frame. They were cached in the route at
            // build time, which is wrong: the lens is part of the weapon and moves with
            // the player, so a cached AABB is a snapshot of a world position the player
            // has since left. Projecting it with the CURRENT camera is what produced the
            // constant "renderer bounds not in front of main camera" rejection.
            //
            // The spec is explicit (line 576): "Guard identities and array
            // pointers/counts, not the contents of animated material vectors or
            // transforms." The bounds are an animated transform, not an identity, so they
            // belong with the material vectors -- re-acquired per frame, like them.
            float b_center[3] = {0, 0, 0}, b_extents[3] = {0, 0, 0};
            if (!range_readable(r.lens_native + 0xE8, 24)) return false;
            std::memcpy(b_center, reinterpret_cast<const void*>(r.lens_native + 0xE8), 12);
            std::memcpy(b_extents, reinterpret_cast<const void*>(r.lens_native + 0xF4), 12);

            // ---- DEFECT A FIX 1: validate the AABB against the mesh it claims to bound.
            //
            // Measured 2026-10-01 over 91 samples: the +0xE8/+0xF4 read is not always a
            // box around this mesh. 5 samples read a degenerate axis --
            //     ext=(0.02836, 0.00005, 0.02836)   ey effectively zero
            //     ext=(0.00023, 0.02103, 0.02102)   ex effectively zero
            // -- and those frames still produced a live mask (mask_pts=4, cover=30%),
            // because range_readable() only checks that the ADDRESS range is readable and
            // never that the VALUES are sane. A degenerate box projects to a line, and a
            // cull region built from a line is arbitrary.
            //
            // The check is containment, not a magic threshold: a real AABB must contain
            // every mesh vertex, so if the mesh escapes the box the box is wrong (or
            // describes a different object) and cannot be trusted for the region. A
            // threshold like "extent > 1e-4" would be a guess about lens size; containment
            // is an invariant the data either satisfies or does not.
            //
            // Ordering matters: the mesh is projected FIRST so the AABB has something to be
            // judged against. Previously the mesh was only projected afterwards, for the
            // diagnostic, which is why the first run produced ratios below 1.0 -- a ratio
            // that is geometrically impossible for a true circumscribing box, and was the
            // signal that these were not the same object.
            v2 mlo{1e9f, 1e9f}, mhi{-1e9f, -1e9f};
            int mesh_projected = 0, mesh_behind = 0;
            bool mesh_world_ok = false;
            v3 mesh_wlo{kWorldInf, kWorldInf, kWorldInf};
            v3 mesh_whi{-kWorldInf, -kWorldInf, -kWorldInf};
            if (!r.lens_mesh_local.empty())
            {
                for (const v3& p : r.lens_mesh_local)
                {
                    // mesh.positions is the renderer's LOCAL vertex stream, so it goes
                    // through lens_m before anything world-space means anything.
                    const v4 wpos = mat_mul_v(lens_world_unadjusted, v4{p.x, p.y, p.z, 1.f});
                    if (!all_finite4(wpos)) { ++mesh_behind; continue; }
                    const v4 clip = mat_mul_v(main_vp, wpos);
                    if (!all_finite4(clip)) { ++mesh_behind; continue; }
                    if (clip.w <= 0.001f) { ++mesh_behind; continue; }
                    // World-space bounds too: the containment test is in world space,
                    // because that is the space the AABB is expressed in.
                    mesh_wlo = {std::min<float>(mesh_wlo.x, wpos.x),
                        std::min<float>(mesh_wlo.y, wpos.y),
                        std::min<float>(mesh_wlo.z, wpos.z)};
                    mesh_whi = {std::max<float>(mesh_whi.x, wpos.x),
                        std::max<float>(mesh_whi.y, wpos.y),
                        std::max<float>(mesh_whi.z, wpos.z)};
                    const v2 ndc{clip.x / clip.w, clip.y / clip.w};
                    mlo = {std::min<float>(mlo.x, ndc.x), std::min<float>(mlo.y, ndc.y)};
                    mhi = {std::max<float>(mhi.x, ndc.x), std::max<float>(mhi.y, ndc.y)};
                    ++mesh_projected;
                }
                mesh_world_ok = mesh_projected >= 3;
            }

            // Containment margin, per axis: how far the mesh's world AABB pokes outside the
            // box that claims to contain it. Positive = contained. Reported either way, so a
            // near-miss is visible before it becomes a rejection.
            float contain[3] = {0, 0, 0};
            bool aabb_valid = false;
            if (mesh_world_ok)
            {
                const v3 blo{b_center[0] - b_extents[0], b_center[1] - b_extents[1],
                    b_center[2] - b_extents[2]};
                const v3 bhi{b_center[0] + b_extents[0], b_center[1] + b_extents[1],
                    b_center[2] + b_extents[2]};
                contain[0] = std::min<float>(blo.x - mesh_wlo.x, bhi.x - mesh_whi.x);
                contain[1] = std::min<float>(blo.y - mesh_wlo.y, bhi.y - mesh_whi.y);
                contain[2] = std::min<float>(blo.z - mesh_wlo.z, bhi.z - mesh_whi.z);
                aabb_valid = contain[0] > -kBoundsContainEps && contain[1] > -kBoundsContainEps
                    && contain[2] > -kBoundsContainEps;

                // The magnitude test, which is what actually catches a bad read. Containment
                // above is a relative/positional check and can pass a box that is tight
                // around nothing; this is an absolute one. A degenerate extent on a real
                // lens is off by three orders of magnitude, so there is no ambiguity here
                // the way there was in the margin comparison.
                //
                // Checked before containment matters, not after, so the rejection reason a
                // reader sees is the one that applies. A box with a 0.05 mm extent that also
                // fails containment would otherwise be reported as a containment failure,
                // which is the wrong lesson to learn from it.
                const bool extents_sane =
                    b_extents[0] >= kBoundsMinExtent && b_extents[1] >= kBoundsMinExtent
                    && b_extents[2] >= kBoundsMinExtent;
                if (!extents_sane)
                {
                    aabb_valid = false;
                    g_defect_a.extents_rejected = 1;
                }
            }

            v2 lo{1e9f, 1e9f}, hi{-1e9f, -1e9f};
            bool any = false;
            // The AABB's projected rect is kept separately because the mesh fallback below
            // overwrites lo/hi. Without this the paired Defect A measurement cannot ask
            // "what would the coverage have been had the AABB been used?" on a frame where
            // it was not, which is the whole measurement.
            v2 aabb_lo{1e9f, 1e9f}, aabb_hi{-1e9f, -1e9f};
            if (aabb_valid)
            {
                for (int i = 0; i < 8; ++i)
                {
                    const v3 corner{
                        b_center[0] + ((i & 1) ? b_extents[0] : -b_extents[0]),
                        b_center[1] + ((i & 2) ? b_extents[1] : -b_extents[1]),
                        b_center[2] + ((i & 4) ? b_extents[2] : -b_extents[2])};
                    const v4 clip = mat_mul_v(main_vp, v4{corner.x, corner.y, corner.z, 1.f});
                    if (!all_finite4(clip) || clip.w <= 0.001f) continue;
                    const v2 ndc{clip.x / clip.w, clip.y / clip.w};
                    lo = {std::min<float>(lo.x, ndc.x), std::min<float>(lo.y, ndc.y)};
                    hi = {std::max<float>(hi.x, ndc.x), std::max<float>(hi.y, ndc.y)};
                    aabb_lo = lo;
                    aabb_hi = hi;
                    any = true;
                }
            }

            // ---- DEFECT A FIX 2: fall back to the mesh, never to a box that failed.
            //
            // The spec fits an ellipse to "the renderer's projected bounds" (line 533).
            // The projected MESH RECT is the same quantity computed from the actual geometry
            // instead of a box around it, so using it as the source is faithful to the spec
            // and strictly more accurate -- it cannot over-cover, because it IS the extent
            // of the thing being culled.
            //
            // Before this, a bad AABB silently became the cull region. Now it is rejected
            // and counted, so `aabb_rej` in the log is the honest measure of how often the
            // read is wrong, rather than something to be inferred from a nonsense ratio.
            int aabb_src = 0;  // 0 = validated AABB, 1 = mesh fallback, 2 = neither
            if (!any && mesh_projected >= 3)
            {
                lo = mlo;
                hi = mhi;
                any = true;
                aabb_src = 1;
            }
            else
            {
                aabb_src = 0;
            }
            if (!any) { mark_stage("ellipse: no usable source (AABB rejected and no mesh)"); return false; }

            const v2 center{(lo.x + hi.x) * 0.5f, (lo.y + hi.y) * 0.5f};
            const v2 radius{(hi.x - lo.x) * 0.5f, (hi.y - lo.y) * 0.5f};
            // A zero-radius ellipse collapses the mask to a segment and clip_polygon then
            // returns an empty polygon, which is a silent reject further down. Caught here
            // so the reason is the real one.
            if (!(radius.x > 1e-4f) || !(radius.y > 1e-4f))
            {
                mark_stage("ellipse: degenerate radius from chosen source");
                return false;
            }
            g_defect_a.source = aabb_src;
            g_defect_a.contain[0] = contain[0];
            g_defect_a.contain[1] = contain[1];
            g_defect_a.contain[2] = contain[2];
            if (!aabb_valid) ++g_defect_a.aabb_rejected;

            std::vector<v2> ellipse;
            ellipse.reserve(48);
            for (int i = 0; i < 48; ++i)
            {
                const float a = 6.2831853071795864f * static_cast<float>(i) / 48.f;
                ellipse.push_back({center.x + radius.x * std::cos(a),
                    center.y + radius.y * std::sin(a)});
            }
            std::vector<v2> screen = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
            std::vector<v2> quad(out.image_quad, out.image_quad + 4);
            std::vector<v2> mask = clip_polygon(ellipse, quad);
            mask = clip_polygon(mask, screen);
            // Staged apart from the bounds projection: "no corner in front" and
            // "the clipped polygon is empty/degenerate" are different failures with
            // different fixes, and both were previously one anonymous stage.
            mark_stage("lens mask polygon empty after clip");
            if (mask.size() < 3 || std::fabs(poly_signed_area(mask)) <= 1e-12f) return false;
            // How much of the screen the lens opening actually covers, in NDC units
            // where the full screen is 4.0 (2x2). Reported as `cover` in optic-region so
            // the section 7 decision rests on measurement: a small cover means most of
            // the screen is "outside" and the main-camera pass has a lot to do.
            g_region.mask_cover_frac =
                std::clamp(std::fabs(poly_signed_area(mask)) * 0.25f, 0.f, 1.f);
            out.mask = std::move(mask);

            // ---- DEFECT A: is the AABB bigger than the mesh it encloses? ---------
            // The ellipse above is fitted to an axis-aligned BOX (spec line 533), not to
            // the lens geometry. A box circumscribes the geometry that generated it, so
            // the region is systematically larger than the real opening. "The mask covers
            // ~1.16-1.22x too much" is consistent with that and with several other causes,
            // so this projects the ACTUAL mesh vertices with the same matrix and compares.
            //
            // The two radii are reported, not a single ratio, because a ratio alone cannot
            // distinguish a uniform scale error from an off-centre one. If both radii are
            // inflated by the same factor the AABB is the whole story; if they disagree the
            // lens is not round, or the extents are being read on the wrong axes.
            //
            // Ratios are computed on the SEMI-AXES (not areas). An area ratio would fold
            // in the aspect change and read as a different number from the linear
            // over-coverage people report, which is how a correct measurement gets argued
            // with as a wrong one.
            g_defect_a.aabb_rx = radius.x;
            g_defect_a.aabb_ry = radius.y;
            g_defect_a.aabb_cx = center.x;
            g_defect_a.aabb_cy = center.y;
            g_defect_a.mesh_available = r.lens_mesh_local.empty() ? 0 : 1;
            g_defect_a.mesh_rx = 0.f;
            g_defect_a.mesh_ry = 0.f;
            g_defect_a.mesh_cx = 0.f;
            g_defect_a.mesh_cy = 0.f;
            g_defect_a.mesh_verts_projected = mesh_projected;
            g_defect_a.mesh_verts_behind = mesh_behind;
            g_defect_a.mask_points = static_cast<int>(out.mask.size());
            g_defect_a.cover_frac = g_region.mask_cover_frac;
            g_defect_a.extents_rejected = 0;
            g_defect_a.extents[0] = b_extents[0];
            g_defect_a.extents[1] = b_extents[1];
            g_defect_a.extents[2] = b_extents[2];
            if (mesh_projected >= 3)
            {
                g_defect_a.mesh_rx = (mhi.x - mlo.x) * 0.5f;
                g_defect_a.mesh_ry = (mhi.y - mlo.y) * 0.5f;
                g_defect_a.mesh_cx = (mlo.x + mhi.x) * 0.5f;
                g_defect_a.mesh_cy = (mlo.y + mhi.y) * 0.5f;
            }
            // ---- Defect A: measure BOTH sources on THIS frame ---------------------
            //
            // The mask above was fitted to one rect. Fit a second mask to the other rect,
            // on the same frame, against the same projected quad and the same screen, and
            // the ratio of the two areas is the over-coverage with nothing uncontrolled
            // about it. This replaces the two-bucket accumulation that divided disjoint
            // frame sets -- see the field's comment for what that produced.
            //
            // Cost is one 48-point clip. `mask=` is 11 us of a 21-37 us acquire, so this is
            // inside the noise of a number that is already being reported every window.
            {
                // rect_for(src) -> the projected rect that source would have used.
                const auto cover_of = [&](int src) -> float {
                    v2 r_lo, r_hi;
                    if (src == 0)
                    {
                        if (!any) return -1.f;
                        r_lo = aabb_lo;
                        r_hi = aabb_hi;
                    }
                    else
                    {
                        if (mesh_projected < 3) return -1.f;
                        r_lo = mlo;
                        r_hi = mhi;
                    }
                    const float rx = (r_hi.x - r_lo.x) * 0.5f;
                    const float ry = (r_hi.y - r_lo.y) * 0.5f;
                    if (!(rx > 1e-4f) || !(ry > 1e-4f)) return -1.f;
                    const v2 c{(r_lo.x + r_hi.x) * 0.5f, (r_lo.y + r_hi.y) * 0.5f};
                    std::vector<v2> e;
                    e.reserve(48);
                    for (int i = 0; i < 48; ++i)
                    {
                        const float a = 6.2831853071795864f * static_cast<float>(i) / 48.f;
                        e.push_back({c.x + rx * std::cos(a), c.y + ry * std::sin(a)});
                    }
                    std::vector<v2> m = clip_polygon(e, quad);
                    m = clip_polygon(m, screen);
                    if (m.size() < 3) return -1.f;
                    return std::clamp(std::fabs(poly_signed_area(m)) * 0.25f, 0.f, 1.f);
                };
                const float ca = cover_of(0);
                const float cm = cover_of(1);
                if (ca >= 0.f && cm >= 0.f)
                {
                    g_defect_a.cover_pair_aabb_sum += ca;
                    g_defect_a.cover_pair_mesh_sum += cm;
                    ++g_defect_a.cover_pair_n;
                }
                else
                {
                    // Counted, not silently ignored: a ratio whose denominator is "however
                    // many frames happened to offer both sources" is the exact failure
                    // this replaced.
                    ++g_defect_a.cover_pair_skipped;
                }
            }
            g_defect_a.valid = 1;
        }

        // `out.valid` is left FALSE from here to the success path. The landing bound,
        // the corner-agreement bound and the lens-size gate all run after this point and
        // can each return false, and on those paths the struct must not claim validity.
        //
        // The trap, hit on 2026-09-29: setting it FALSE here used to be a no-op in
        // practice, because record_scoped_mapping() above gates on `p.valid` and so did
        // nothing at all. That guard is now removed, so the ordering here is what it
        // looks like. If a `p.valid` check is ever reintroduced into a diagnostic that
        // runs before the guards, all three guards go silently inert again -- see the
        // retraction at the top of record_scoped_mapping.
        out.valid = false;
        out.scales = scales;
        out.shifts = shifts;
        out.shift_dir = shift_dir;
        out.lens_basis_hc = HC;
        out.lens_basis_hu = HU;
        out.lens_basis_hv = HV;
        out.w_gate_margin = HC.w - std::fabs(HU.w) - std::fabs(HV.w);
        out.combined_w = combined.at(3, 3);
        out.optic_vp_m15 = optic_vp.at(3, 3);
        out.optic_vp_m03 = optic_vp.at(0, 3);
        out.optic_vp_m13 = optic_vp.at(1, 3);
        out.optic_vp_m11 = optic_vp.at(1, 1);
        out.main_vp_m15 = main_vp.at(3, 3);
        // Descriptive, and now also runs the spec's line-578 corner test on the PRIMARY
        // chain. Must be called BEFORE the projection guard, so a bad corner agreement
        // can reject the packet.
        record_scoped_mapping(out, corners, r.map.center, r.map.u_axis, r.map.v_axis,
            lens_view);
        // The guard below now tests the primary chain's landing, which is centred.
        // Tightened from 4 to 1.25: the game never draws the scope picture more than
        // about a quarter of a screen off centre, and the broken `combined` shortcut
        // landed at 1.55-1.97 -- outside this bound, so a regression to that path is
        // rejected instead of projecting ESP off-screen (the reported "1x hides
        // everything"). Measured on the primary chain this should sit near 0.
        mark_stage("scoped mapping off screen (primary chain landing outside 1.25)");
        if (std::fabs(out.centre_landing.x) > 1.25f || std::fabs(out.centre_landing.y) > 1.25f)
            return false;
        if (out.corner_agreement_ndc > 1e-3f) return false;

        // ---- lens image size gate (2026-09-29) ------------------------------
        // Placed after every other guard, immediately before `valid = true`, so it is
        // the LAST thing that can reject: if any earlier guard was going to fire, that
        // is the more informative failure and it wins.
        mark_stage("lens image size out of family with baseline");
        {
            // bbox in NDC, from the same quad the mask was clipped against. Resolution
            // independent, which is the point -- the same band holds at any resolution.
            const float w = out.quad_hi.x - out.quad_lo.x;
            const float h = out.quad_hi.y - out.quad_lo.y;
            // Use the LARGER extent as the size measure. A scope seen at an angle
            // projects to a non-square quad, and using the smaller one would let a
            // legitimately foreshortened frame read as a collapse.
            const float size = std::max<float>(w, h);

            if (!(size > 1e-4f)) {
                // Degenerate bbox: not a size-AGREEMENT question, so it gets its own
                // counter and deliberately no re-baseline path. Re-baselining onto a
                // zero would make the gate define "correct" as "broken" after 500 ms.
                //
                // Counted, though, and the first version did not. It returned silently,
                // so a run in which the bbox was zero on EVERY frame reported rej=0 --
                // indistinguishable from a gate that never fired. That is precisely how
                // the 19:55 regression hid for a whole run: the gate was rejecting the
                // bulk of packets while its own counter read zero.
                ++g_lens_size.rejects;
                ++g_lens_size.degenerate;
                g_lens_size.seen_w = w;
                g_lens_size.seen_h = h;
                record_lens_size_frame(size, std::max<float>(g_lens_size.ref_w,
                    g_lens_size.ref_h), true, true, false, true);
                return false;
            }

            if (!g_lens_size.have) {
                g_lens_size.have = true;
                g_lens_size.ref_w = w;
                g_lens_size.ref_h = h;
                g_lens_size.reject_since = 0;
            } else {
                const float rw = g_lens_size.ref_w, rh = g_lens_size.ref_h;
                const bool lo = size < kLensSizeMinRatio * std::max<float>(rw, rh);
                const bool hi = size > kLensSizeMaxRatio * std::max<float>(rw, rh);
                if (lo || hi) {
                    const ULONGLONG now = GetTickCount64();
                    if (g_lens_size.reject_since == 0) g_lens_size.reject_since = now;
                    ++g_lens_size.rejects;
                    g_lens_size.seen_w = w;
                    g_lens_size.seen_h = h;
                    // Recorded BEFORE the re-baseline branch below, deliberately: this
                    // evaluation WAS a rejection by the band, and the re-baseline that
                    // may follow it does not undo that. Recording after would silently
                    // drop every frame the escape hatch actually caught -- which is the
                    // subset most worth seeing.
                    record_lens_size_frame(size,
                        std::max<float>(g_lens_size.ref_w, g_lens_size.ref_h),
                        true, lo, hi, false);
                    if (now - g_lens_size.reject_since >= kRebaselineMs) {
                        // It has been wrong for long enough to be the new normal.
                        g_lens_size.ref_w = w;
                        g_lens_size.ref_h = h;
                        g_lens_size.reject_since = 0;
                        ++g_lens_size.rebaselines;
                    } else {
                        return false;
                    }
                } else {
                    // Agreeing: the baseline drifts toward the accepted value, but only
                    // very slowly, and the rate is a SAFETY property, not a nicety.
                    //
                    // The gate's margin is the distance from the band's edge (0.70) to
                    // the measured collapse (0.43-0.49), i.e. the baseline would have to
                    // walk ~40% before a real collapse started passing. At 0.02/frame
                    // that margin is gone in roughly half a second of clean frames, which
                    // is the same timescale as the rebuild transient the gate exists to
                    // catch. At 0.005/frame it takes several seconds, which no transient
                    // in this pipeline has ever spanned. Collapses are instantaneous and
                    // the baseline is only ever moved by ACCEPTED frames, so this can
                    // never mask the thing it is looking for.
                    g_lens_size.ref_w += (w - g_lens_size.ref_w) * 0.005f;
                    g_lens_size.ref_h += (h - g_lens_size.ref_h) * 0.005f;
                    g_lens_size.reject_since = 0;
                    // Recorded after the drift, so `ratio` on this sample is against the
                    // baseline this frame will leave behind rather than the one it
                    // arrived with.
                    record_lens_size_frame(size,
                        std::max<float>(g_lens_size.ref_w, g_lens_size.ref_h),
                        false, false, false, false);
                }
            }
        }
        mark_stage("ok");
        mark(perf_mask);
        // Every guard above has passed; only NOW is the packet valid.
        out.valid = true;
        return true;
    }

    // ------------------------------------------------------------- public API
    // Project a world point to screen pixels of a width x height target
    // (optics NDC -> pixels). Returns false when the point is invalid/behind.
    // Counters for project_point's rejection paths. Step 1 (behind the OPTIC camera)
    // and step 4 (behind the MAIN camera) are different failures with different
    // causes, and until now step 4 accepted NEGATIVE w, so a lens-local point behind
    // the main camera divided through and produced a mirrored, plausible-looking but
    // wrong position. The spec forbids exactly this (line 574): "Never connect a
    // behind-camera endpoint to a projected endpoint."
    struct project_counters
    {
        unsigned long long ok = 0;
        unsigned long long bad_packet = 0;
        unsigned long long behind_optic = 0; // step 1: clip.w <= 0.001
        unsigned long long behind_main = 0;  // step 4: s.w <= 0.001  (was: fabs)
        unsigned long long nonfinite = 0;
    };
    inline project_counters g_project{};

    inline bool project_point(const packet& p, const v3& world,
        float width, float height, v2& out_px) {
        if (!p.valid)
        {
            ++g_project.bad_packet;
            return false;
        }
        // 1. world -> optic NDC
        const v4 clip = mat_mul_v(p.optic_vp, v4{world.x, world.y, world.z, 1.f});
        if (!all_finite4(clip))
        {
            ++g_project.nonfinite;
            return false;
        }
        // Strictly positive, matching step 4. A negative w means the point is behind
        // the optic camera; dividing by it would mirror the NDC.
        if (clip.w <= 0.001f)
        {
            ++g_project.behind_optic;
            return false;
        }
        const v2 ndc{clip.x / clip.w, clip.y / clip.w};

        // 2+3. optic NDC -> meshUV -> lens-local via the validated section 5 affine map
        //      (spec 492-493: meshUV = opticNDC*0.05 + 0.5; local = localFromUV(meshUV)).
        //      localFromUV(u,v) = center + Uaxis*(u-0.5) + Vaxis*(v-0.5), and
        //      meshUV - 0.5 == ndc * 0.05, so the UV step folds into the axes below.
        //
        //      This replaces the `combined` shortcut, which measured a landing at
        //      ndc x -1.55..-1.97 (px -528..-929) while image_quad sat centred on the
        //      origin — i.e. it projected ESP off-screen. See the packet field comments.
        const float sx = p.scales.x;
        const v3 anchor = p.map_center * sx
            + v3{p.shift_dir.x, p.shift_dir.y, p.shift_dir.z} * p.shifts.x;
        const v3 lp = anchor + p.map_u * (sx * 0.05f * ndc.x)
            + p.map_v * (sx * 0.05f * ndc.y);

        // 4. lens-local -> main screen (p.lens_view is main_vp * lens_m)
        const v4 s = mat_mul_v(p.lens_view, v4{lp.x, lp.y, lp.z, 1.f});
        if (!all_finite4(s))
        {
            ++g_project.nonfinite;
            return false;
        }
        // NOT fabs(). A negative w is a point behind the MAIN camera; dividing by it
        // mirrors the NDC and yields a wrong position rather than a failure, which is
        // how a bad frame looks merely "slightly off" instead of obviously broken.
        // 2026-09-27: was `std::fabs(s.w) < 1e-9f`.
        if (s.w <= 0.001f)
        {
            ++g_project.behind_main;
            return false;
        }
        const v2 sndc{s.x / s.w, s.y / s.w};
        out_px = {(sndc.x + 1.f) * width * 0.5f, (1.f - sndc.y) * height * 0.5f};
        ++g_project.ok;
        return true;
    }

    // Is this main-screen NDC point inside the fitted lens mask? Uses the same
    // polygon the draw path clips against, so the region split and the clipping can
    // never disagree.
    inline bool point_in_mask(const packet& p, const v2& ndc) {
        const size_t n = p.mask.size();
        if (n < 3) return false;
        bool inside = false;
        for (size_t i = 0, j = n - 1; i < n; j = i++)
        {
            const v2 a = p.mask[i], b = p.mask[j];
            if ((a.y > ndc.y) != (b.y > ndc.y))
            {
                const float t = (ndc.y - a.y) / (b.y - a.y);
                if (ndc.x < a.x + t * (b.x - a.x)) inside = !inside;
            }
        }
        return inside;
    }

    // Signed-ish distance outside the mask: 0 when inside, else the shortest distance
    // to any mask edge in NDC. Only used for the diagnostic magnitude.
    inline float distance_outside_mask(const packet& p, const v2& ndc) {
        const size_t n = p.mask.size();
        if (n < 2) return 0.f;
        float best = 1e9f;
        for (size_t i = 0; i < n; ++i)
        {
            const v2 a = p.mask[i], b = p.mask[(i + 1) % n];
            const v2 ab = b - a, ap = ndc - a;
            const float len2 = ab.x * ab.x + ab.y * ab.y;
            float t = len2 > 1e-12f ? (ap.x * ab.x + ap.y * ab.y) / len2 : 0.f;
            t = std::clamp(t, 0.f, 1.f);
            const v2 q{a.x + ab.x * t, a.y + ab.y * t};
            const float dx = ndc.x - q.x, dy = ndc.y - q.y;
            best = std::min<float>(best, std::sqrt(dx * dx + dy * dy));
        }
        return best;
    }

    // Clip a screen-space segment against the visible mask (NDC space).
    // Returns the visible [t0, t1] within [0, 1]; false when fully hidden.
    inline bool clip_segment(const packet& p, const v2& a_ndc, const v2& b_ndc,
        float& t0, float& t1) {
        if (!p.valid) return false;
        float low = 0.f, high = 1.f;
        const size_t n = p.mask.size();
        for (size_t i = 0; i < n; ++i)
        {
            const v2 a = p.mask[i];
            const v2 b = p.mask[(i + 1) % n];
            const v2 edge = b - a;
            const float start = cross2(edge, a_ndc - a);
            const float slope = cross2(edge, b_ndc - a_ndc);
            if (std::fabs(slope) < 1e-12f)
            {
                if (start < 0.f) return false;
                continue;
            }
            const float t = -start / slope;
            if (slope > 0.f)
                low = (std::max<float>)(low, t);
            else
                high = (std::min<float>)(high, t);
            if (low > high) return false;
        }
        t0 = low;
        t1 = high;
        return true;
    }
} // namespace optics::lens
