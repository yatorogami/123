#pragma once

// What a quest actually asks for, as a short checklist.
//
// WHY THIS EXISTS. The Quest Completer card's dropdown listed quest NAMES and
// nothing else, so the one thing that decides which quest to hand in next --
// what the quest requires -- was only visible in the game's own journal, which
// an overlay cannot reach. This turns one quest's Conditions into a line of
// text per objective, with its current/target count and whether it is done.
//
// The text is the game's own, not ours: Condition.get_FormattedDescription is
// the same call the quest journal's ObjectiveView makes, so "Hand over a
// Golden Star Balalaika" reads the way the journal reads rather than the way a
// condition class name would.
//
// GAME THREAD ONLY, like quest_esp.h, which this builds on and reuses for the
// description pipeline. Every line here invokes managed code
// (get_FormattedDescription, IsConditionDone, the progress checker's own
// getters) and reads the item factory to turn a template id into an item name.
// None of that belongs on the render thread.

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstring>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "../il2cpp/Il2CppObjectInstance.h"
#include "../il2cpp/exports.h"
#include "../il2cpp/il2utils.h"
#include "../il2cpp/unity.h"
#include "eft_api.h"
#include "quest_esp.h"
#include "quest_objective_text.h" // objective, plan_for, join_labels, merge_duplicates, ...

namespace quest_objectives {

    // WHICH MANAGED CALL IS CURRENTLY BEING MADE, as a plain "const char*".
    //
    // This exists because collect() is four different IL2CPP calls deep into the game's
    // object model and any of them can throw: get_Conditions, IsConditionDone,
    // get_CurrentValue, get_FormattedDescription. A caller that catches the exception and
    // reports "collect() failed" has narrowed it to four candidates, and picking between
    // them by reasoning is how the last two rounds went wrong -- the symptom was real,
    // the explanation was not.
    //
    // A bare pointer rather than a std::string so the assignment cannot itself throw: this
    // is written immediately before the call it names, and a throwing assignment inside a
    // diagnostic would replace a useful failure with a useless one. Null means "not inside
    // a collect", which is the state between calls.
    inline const char* detail_stage_ = nullptr;

    // A quest with more objectives than this is truncated rather than allowed
    // to push the card's other cards off the page. The longest observed is well
    // under it; it is a bound, not a policy.
    inline constexpr size_t kMaxLines = 32;

    // How many quests the "All" view will read in one pass.
    //
    // A bound, not a policy: the "All" summary is collect() over every active quest, and
    // on a late-wipe profile that is 40+ quests of managed calls every scan.
//
// IT NO LONGER PICKS WHICH QUESTS. It used to take the first kAllQuestCap in dropdown
// order, which was stable but arbitrary: dropdown order is the PROFILE's quest order, not
    // the raid's, so the cap could drop the location-bound quests that are actually doable on
    // the current map and keep twelve that are not. The cap is now a bound on the whole set
    // and the grouping below decides what is shown first, so the quests that survive are the
    // relevant ones rather than the alphabetically lucky.
//
// Kept at a number that is generous for a real raid: on the profile this was measured on
// the ACTIVE set was 8 quests, and the point of grouping is that a map rarely has more than
// a handful of location-bound ones. It is a backstop against a pathological profile, not a
// routine limit, and the card says so when it bites.
//
// RAISED 24 -> 64 on 2026-10-08, because the paragraph above stopped being true. 24 "was
// chosen to be above anything observed, so hitting it means the shape of the data changed
// rather than that a raid was busy" -- and a later-wipe profile lists 36 ACTIVE quests, so 24
// was inside the ordinary range and the cap was hiding a third of them, chosen in profile
// order because the caller applied it to the input list. 64 is roughly twice the largest set
// observed.
//
// The premise has EXPIRED rather than this number needing to be forever larger, and that is
// the part worth keeping. This cap existed to bound a 300 ms-throttled PER-PUBLISH scan, and
// there is no per-publish scan any more: build_snapshot() runs ONCE at raid entrance, and each
// condition's FormattedDescription is memoised in text_cache() for the life of the raid, so
// the marginal quest costs one pass and nothing thereafter. If a real profile ever reaches 64,
// the correct response is to MEASURE what collect_all() costs per quest rather than raise this
// again -- a constant that has to keep moving is a measurement that was never taken.
//
// 2026-10-14: the live limit is no longer this constant but QuestModule's
// `quest_all_cap` slider (IntSliderEditableValue, default read from here, range 24-256), so a
// player who hits the ceiling can see the trade instead of filing a report about a missing
// quest. This remains the DEFAULT and the value the harness and its tests reason about; the
// production code reads the slider.
inline constexpr size_t kAllQuestCap = 64;

    // quest_esp's description buffer. kMaxTextLen in quest_objective_text.h is
    // the length bound; this is the buffer the game's own text is read into
    // before that bound is applied.
    inline constexpr size_t kDescriptionBuffer = 512;

    // il2cpp_class_get_method_from_name searches ONE class's own method array --
    // hideout_reflection.h:133-146 read the unwrapped body to establish that, and
    // implemented an explicit parent walk for exactly this reason. Every method
    // the objectives need is declared on a BASE class:
    //
    //   get_Conditions, get_ProgressCheckers, IsConditionDone  -> Conditional<T>
    //   get_value, get_IsNecessary                               -> Condition
    //
    // so a leaf-only lookup misses all of them. Walking explicitly is correct
    // whether or not the runtime also walks; resolve_method is memoised, so this
    // costs a handful of map lookups per call.
    //
    // The il2cpp_runtime_class_init call is load-bearing and was missing. Il2CppClass.methods
    // is documented in the runtime as "Initialized in SetupMethods" (il2cpp-class-internals.h),
    // which class initialisation drives, so a class the runtime has not set up has a null or
    // empty methods array and EVERY lookup on it misses. A miss here is worse than a wasted
    // call: resolve_method memoises successes only (il2utils.h:236-239), deliberately, because
    // "not initialised yet" must be allowed to resolve later -- so a lookup that loses this race
    // is re-attempted, but a member that genuinely never appears leaves the caller with a
    // nullptr and no way to tell that apart from a member that was not found because its class
    // was not ready. hideout_cached_method does this for exactly this reason and cites the
    // 2026-09-27 log's `GetEnumerator/0 not found on <>OfTypeIterator>d__97`1` as the failure
    // it prevents. It is also harmless on a class that is already live.
    inline const MethodInfo* resolve_up(const Il2CppClass* klass, const char* name, int args) {
        for (const Il2CppClass* current = klass; current; current = current->parent) {
            // NO il2cpp_runtime_class_init HERE, and its absence is the fix.
            //
            // It was added on 2026-10-03 to force SetupMethods, copying
            // hideout_cached_method (hideout_reflection.h:189-194), and it is why
            // publish_objectives began throwing a non-std -- i.e. an il2cpp managed --
            // exception, taking the whole quest-objectives publish down with it.
            //
            // The two uses are NOT equivalent, which is what the copy glossed over:
            //
            //  - hideout calls it on classes it has already validated with
            //    hideout_class_usable(), on its own periodic refresh, for classes it
            //    selected by name. A miss there costs one look-up.
            //  - this ran it on EVERY class in the inheritance walk of a LIVE quest object,
            //    every 300 ms, mid-raid -- and il2cpp_runtime_class_init does not read
            //    metadata, it RUNS THE CLASS'S STATIC CONSTRUCTOR. Forcing a cctor on a
            //    quest class that the game has not initialised yet executes arbitrary
            //    managed code, and a cctor that throws does exactly what was observed.
            //
            // The ISIL settles that every method this file actually calls is a trivial
            // field read, so SetupMethods was never the problem it was supposed to solve:
            //
            //   get_ProgressCheckers   mov rax,[rcx+40h]; ret
            //   Condition.get_value    movss xmm0,[rcx+28h]; ret
            //   get_IsNecessary         cmp byte ptr [rcx+61h],0 / sete al
            //
            // get_Conditions is abstract on Conditional<T> and overridden in Quest
            // (Slot 22, RVA 0x420E7E0), and IsConditionDone is declared on Conditional<T>
            // where it genuinely needs the MethodInfo's rgctx -- which this file passes.
            // Both are found correctly by the parent walk below without any cctor.
            //
            // If a future build does hide a method behind an uninitialised class, the right
            // answer is to name that class in a startup probe, not to force a cctor on a live
            // object from a per-frame path.
            detail_stage_ = "resolve_method";
            const MethodInfo* found = il2utils::resolve_method(current, name, args);
            detail_stage_ = nullptr;
            if (found)
                if (found->methodPointer) return found;
        }
        return nullptr;
    }

    // INVARIANT: every managed call below is declared with a trailing
    // `const MethodInfo*` and is passed the MethodInfo it was resolved from.
    //
    // This DIVERGES from the rest of the project, which mostly calls
    // methodPointer through a signature with no MethodInfo -- see the
    // `static_cast<bool (*)(Il2CppObject*)>(...)(task)` calls throughout
    // hideout_reflection.h. Both spellings work for a method that does not read
    // the argument, because x64 puts it in a register the callee ignores. They
    // are NOT equivalent for one that does, and the three methods here declared on
    // Conditional<TConditional> are exactly that -- it is a GENERIC type. The one
    // this file calls most, IsConditionDone, is unambiguous in the disassembly:
    //
    //   mov rdi, r8                    ; the MethodInfo
    //   ...
    //   mov rax, [rdi+20h]             ; rgctx, dereferenced unconditionally
    //   mov r8, [rax+0C0h]
    //   mov r8, [r8+0D8h]              ; CheckConditionDone
    //
    // (Conditional`1.txt, IsConditionDone.) So omitting the argument there hands
    // the callee whatever the caller left in r8 -- a garbage pointer read. Not a
    // compile error, and not reliably a crash either: it reads a small offset
    // from a near-null address, which is the kind of fault that shows up much
    // later and somewhere else. Passing it always is correct in both cases and
    // costs nothing where it is ignored.

    // All three of these are declared on Conditional<TConditional>, not Quest.
    struct quest_calls
    {
        const MethodInfo* conditions = nullptr;
        const MethodInfo* progress_checkers = nullptr;
        const MethodInfo* is_condition_done = nullptr;

        // conditions alone is enough to ENUMERATE, which is all usable() ever needed for.
        // It is not enough to answer the question the card exists to answer.
        [[nodiscard]] bool usable() const { return conditions != nullptr; }

        // The two that decide "done" and "how far along".
        //
        // This distinction is the whole point of the split, and it did not exist when
        // this shipped. usable() tested one of the three, so a quest whose class could
        // not supply IsConditionDone or get_ProgressCheckers still produced a
        // well-formed snapshot -- one with every row done == false and current == 0,
        // and a header reading 0/N. That is byte-for-byte what "this quest has not
        // started" looks like, so the failure was invisible: no row missing, no error,
        // no log line, and a number that never moved. is_done() and current_value()
        // each return a zero on an unresolved method for exactly that reason, and the
        // caller was in no position to tell those zeros from real ones.
        [[nodiscard]] bool progress_readable() const {
            return is_condition_done != nullptr && progress_checkers != nullptr;
        }
    };

    inline quest_calls resolve_quest_calls(Il2CppObject* quest) {
        quest_calls calls{};
        if (!quest || !quest->klass) return calls;
        calls.conditions = resolve_up(quest->klass, "get_Conditions", 0);
        calls.progress_checkers = resolve_up(quest->klass, "get_ProgressCheckers", 0);
        calls.is_condition_done = resolve_up(quest->klass, "IsConditionDone", 1);
        return calls;
    }

    // The same three lookups, for a caller that has a quest but no quest_calls to hand
    // -- the snapshot builder, which needs to answer "was this readable?" about a quest
    // it is not currently collecting.
    inline bool progress_readable(Il2CppObject* quest) {
        return resolve_quest_calls(quest).progress_readable();
    }

    // WHY THIS EXISTS. The whole reason a broken read of "done" is worth a log line: the
    // failure and the answer look identical. A quest that has genuinely not started and a
    // quest whose IsConditionDone could not be resolved both render as unchecked boxes
    // and a 0/N tally, and the difference is only knowable from inside here. So it is
    // said out loud, once per distinct quest class, naming which member is missing -- an
    // unresolved member is a build property, not a transient, so there is no time-based
    // rate limit and the count stays at one line per class however many quests derive
    // from it.
    //
    // Game thread only, like everything else in this file.
    inline void report_unreadable_progress(Il2CppObject* quest, const quest_calls& calls) {
        if (calls.progress_readable()) return;

        const char* class_name = (quest && quest->klass && quest->klass->name) ? quest->klass->name : "?";

        std::string key = class_name;
        if (!calls.is_condition_done) key += "|IsConditionDone";
        if (!calls.progress_checkers) key += "|get_ProgressCheckers";

        static std::unordered_map<std::string, bool> reported;
        if (!reported.emplace(std::move(key), true).second) return;

        std::string missing;
        if (!calls.is_condition_done) missing += "IsConditionDone ";
        if (!calls.progress_checkers) missing += "get_ProgressCheckers ";

        logger::warn("quest objectives: " + std::string(class_name) + " has no " + missing
            + "-- every objective on it reads 0/N with an unticked box until this is fixed. "
              "The boxes are unreadable, not unticked.");
    }

    // Quest.Conditions is a ConditionsDict -- Dictionary<int, ConditionCollection> --
    // and ConditionCollection is an UpdatableBindableList whose List field is a
    // Mono List<Condition>. Both hops are field reads on an object the caller
    // has already validated.
    //
    // `fn` receives every condition in every collection, INCLUDING the child
    // ones; the caller decides, because only the caller knows it wants the
    // necessary subset.
    template <typename Fn>
    inline bool for_each_condition(Il2CppObject* quest, const quest_calls& calls, const Fn& fn) {
        if (!quest || !calls.usable()) return false;

        detail_stage_ = "get_Conditions";
        Il2CppObject* dict_object = reinterpret_cast<Il2CppObject* (*)(Il2CppObject*, const MethodInfo*)>(
            calls.conditions->methodPointer)(quest, calls.conditions);
        detail_stage_ = nullptr;
        if (!dict_object) return false;

        auto* dict = reinterpret_cast<unity::dict<int, Il2CppObject*>*>(dict_object);
        if (!dict || !dict->m_p_entries) return false;

        for (int i = 0; i < dict->m_i_count; ++i) {
            Il2CppObject* collection = dict->get_value_by_index(i);
            if (!collection) continue;

            unity::list* list = Il2CppObjectInstance(collection).get_field<unity::list*>("List");
            if (!list || !list->m_p_list_array) continue;

            // live_count() is _size clamped into _items. Walking max_length
            // instead -- which is what the condition-walking code in
            // quest_esp.h and QuestModule's own complete path does -- is safe,
            // because the unused tail is nulled and skipped, but it reports
            // capacity as population and makes the kMaxLines bound fire early
            // on a list that has grown.
            const size_t limit = list->live_count();
            for (size_t j = 0; j < limit; ++j) {
                Il2CppObject* condition = reinterpret_cast<Il2CppObject**>(&list->m_p_list_array->data)[j];
                if (!condition || !condition->klass) continue;
                fn(condition);
            }
        }
        return true;
    }

    // Conditional<T>.ProgressCheckers is
    // Dictionary<Condition, ConditionProgressChecker>, and the keys are the very
    // Condition instances the collections above hold: the factory walks the same
    // ConditionsDict to fill it (Conditional`1.txt ISIL line 4464). So a lookup
    // by pointer hits, and no id-matching fallback is needed.
    inline unity::dict<Il2CppObject*, Il2CppObject*>* progress_checkers(
        Il2CppObject* quest, const quest_calls& calls) {
        if (!calls.progress_checkers || !calls.progress_checkers->methodPointer) return nullptr;

        // Marked, and it matters that this is marked at all: the 2026-10-04 throw reported
        // stage 'badge pass' with detail_stage_ NULL, which places the throw BEFORE the
        // first marker that existed at the time -- get_Conditions. In the badge pass the
        // only things ahead of that are resolve_quest_calls (which reaches resolve_up) and
        // this call. resolve_up was already marked by then and stayed null, so the other
        // unmarked candidate is right here.
        //
        // It is also the one call here that is NOT wrapped in the SEH guard
        // write_condition_description_seh applies to the description path, and the one that
        // runs on a quest with an uninitialised Conditions dictionary -- a getter on
        // Conditional<T> that touches ProgressCheckers, which Conditional`1.cs:57-58
        // records as a readonly backing field the factory fills in CreateConditionHandlers.
        detail_stage_ = "get_ProgressCheckers";
        Il2CppObject* object = reinterpret_cast<Il2CppObject* (*)(Il2CppObject*, const MethodInfo*)>(
            calls.progress_checkers->methodPointer)(quest, calls.progress_checkers);
        detail_stage_ = nullptr;
        if (!object) return nullptr;

        auto* dict = reinterpret_cast<unity::dict<Il2CppObject*, Il2CppObject*>*>(object);
        return (dict && dict->m_p_entries) ? dict : nullptr;
    }

    // Conditional<T>.IsConditionDone is the game's own answer: CompletedConditions
    // (persisted) OR the live progress checker. Reimplementing it here would be
    // the quest_esp::is_condition_completed shape, which is three probes where
    // the game will answer in one call.
    inline bool is_done(Il2CppObject* quest, const quest_calls& calls, Il2CppObject* condition) {
        if (!calls.is_condition_done || !calls.is_condition_done->methodPointer) return false;
        detail_stage_ = "IsConditionDone";
        const bool done = reinterpret_cast<bool (*)(Il2CppObject*, Il2CppObject*, const MethodInfo*)>(
            calls.is_condition_done->methodPointer)(quest, condition, calls.is_condition_done);
        detail_stage_ = nullptr;
        return done;
    }

    // ConditionProgressChecker.CurrentValue, which is the counter's own value for
    // a counter-backed condition and 0 for one with no getter. NaN and negatives
    // both fail the `> 0.0` test, which is the wanted answer for both.
    inline int current_value(Il2CppObject* checker) {
        if (!checker || !checker->klass) return 0;

        // HasGetter() BEFORE get_CurrentValue(), and the order is the whole point.
        //
        // get_CurrentValue is not a passive read (ConditionProgressChecker.txt ISIL):
        //
        //   movups xmm0,[rbx+28h]     ; _currentValue, a Nullable<double>
        //   movd   eax,xmm0
        //   test   al,al
        //   je     -> get_GetCurrentValue
        //
        // and get_GetCurrentValue INVOKES _currentValueGetter, a managed Func:
        //
        //   cmp qword ptr [rbx+18h],0
        //   jbe  -> return 0
        //   mov  rcx,[rbx+18h]
        //   mov  rax,[rcx+18h]        ; the Func's invoke
        //   call rax                   ; MANAGED CALL, can throw
        //
        // So calling it lazily EVALUATES and CACHES game state -- it mutates the checker --
        // and the delegate it invokes is game code that can throw. That is the second
        // candidate for the non-std exception, and the only one on this path that is not a
        // field read.
        //
        // HasGetter is three instructions and answers the question without any call:
        //
        //   cmp qword ptr [rcx+18h],0 / seta al / ret
        //
        // A checker with no getter has no current value to report, so 0 is the correct
        // answer for it and the lazy path is never entered. The game's own
        // ConditionalHelper.GetConditionCurrentValue checks IsCompleted() before calling
        // get_CurrentValue for the same reason (ConditionalHelper.txt ISIL lines 33-40).
        const MethodInfo* has_getter = resolve_up(checker->klass, "HasGetter", 0);
        if (!has_getter || !has_getter->methodPointer) return 0;
        if (!reinterpret_cast<bool (*)(Il2CppObject*, const MethodInfo*)>(
                has_getter->methodPointer)(checker, has_getter))
            return 0;

        const MethodInfo* method = resolve_up(checker->klass, "get_CurrentValue", 0);
        if (!method || !method->methodPointer) return 0;

        detail_stage_ = "get_CurrentValue";
        const double value = reinterpret_cast<double (*)(Il2CppObject*, const MethodInfo*)>(
            method->methodPointer)(checker, method);
        detail_stage_ = nullptr;
        if (!(value > 0.0)) return 0;
        if (value > 1e9) return 1000000000;
        return static_cast<int>(std::lround(value));
    }

    // Condition.value, a float with [DefaultValue(1)] -- which is why so many
    // conditions legitimately read as 1 and the checklist decides on its own
    // whether that 1 is worth showing.
    inline int condition_value(Il2CppObject* condition) {
        if (!condition || !condition->klass) return 0;
        const MethodInfo* method = resolve_up(condition->klass, "get_value", 0);
        if (!method || !method->methodPointer) return 0;

        // AFTER resolve_up, for the same reason as get_IsNecessary above: resolve_up() clears
        // detail_stage_ on the way out, so a marker set before it is erased before the managed
        // call and a throw here would report stage "(unset)".
        detail_stage_ = "Condition.get_value";
        const float value = reinterpret_cast<float (*)(Il2CppObject*, const MethodInfo*)>(
            method->methodPointer)(condition, method);
        detail_stage_ = nullptr;
        if (!(value > 0.0f)) return 0;
        if (value > 1e9f) return 1000000000;
        return static_cast<int>(std::lroundf(value));
    }

    // Condition.IsNecessary is `_isNecessary || ParentId == null`
    // (Condition.txt, get_IsNecessary ISIL lines 10-19 and 42), and that is
    // literally the filter ConditionCollection.NecessaryConditions applies -- its
    // predicate is inlined to the same two-term test rather than calling this
    // property (ConditionCollection_NestedType___c.txt,
    // <get_NecessaryConditions>b__5_0, ISIL lines 22-25 and the identical
    // ParentId.HasValue sequence after it). So this is the journal's own objective
    // list. Conditions with a
    // ParentId are the nested children of an "or" group and would double-count
    // the parent.
    inline bool is_necessary(Il2CppObject* condition) {
        if (!condition || !condition->klass) return false;
        const MethodInfo* method = resolve_up(condition->klass, "get_IsNecessary", 0);
        // No answer means a build that renamed it; keeping the condition is the
        // safe direction, because a missing objective is worse than an extra one.
        if (!method || !method->methodPointer) return true;
        // AFTER resolve_up, not before. resolve_up() sets detail_stage_ = "resolve_method"
        // and clears it on the way out, so a marker set ahead of it is gone by the time the
        // MANAGED CALL is made -- and a throw here would then be reported as stage "(unset)"
        // and look like the marker was incomplete rather than like this call failed.
        // is_done() and current_value() already place theirs after the resolve for this reason.
        detail_stage_ = "get_IsNecessary";
        const bool necessary = reinterpret_cast<bool (*)(Il2CppObject*, const MethodInfo*)>(
            method->methodPointer)(condition, method);
        detail_stage_ = nullptr;
        return necessary;
    }

    // ---------------------------------------------------------------- text

    // plan_for / split_token_list / join_labels / truncate_text / merge_duplicates
    // / order_by_outstanding live in quest_objective_text.h, which has no
    // IL2CPP in it and is covered by tools/harness/test_quest_objectives_text.cpp.
    // The class-name -> verb table is there; the rest of this section is the part
    // that has to reach into a live quest.

    // A condition's targets, as raw ids or readable tokens.
    //
    // `target` is `string` on ConditionOneTarget and `string[]` on
    // ConditionMultipleTargets, and the FieldInfo does not say which -- so the
    // distinction comes from the base class, which also survives a rename of the
    // concrete class (the reason quest_esp's is_multiple_targets_condition is
    // written the same way).
    //
    // `zoneIds` is spelled out as an array instead. It is `string[]` on BOTH
    // ConditionZone and ConditionInZone, and ConditionInZone derives from
    // Condition directly rather than from ConditionMultipleTargets -- so a
    // class-based test would read the array as a string and hand a live
    // Il2CppArray* to conv_string. That is the whole reason this is a
    // per-field decision and not one flag for the condition.
    inline void read_targets(Il2CppObject* condition, std::vector<std::string>& out) {
        if (!condition || !condition->klass) return;

        struct target_field
        {
            const char* name;
            bool is_array;
        };
        const bool many = quest_esp::class_inherits_from(condition, "ConditionMultipleTargets");
        const target_field fields[] = {
            {"target", many},
            {"zoneIds", true},
        };

        for (const target_field& field : fields) {
            if (!il2utils::resolve_field(condition->klass, field.name)) continue;

            if (field.is_array) {
                for (const std::string& value : quest_esp::read_string_array_field(condition, field.name))
                    out.push_back(value);
            }
            else {
                Il2CppString* value = Il2CppObjectInstance(condition).get_field<Il2CppString*>(field.name);
                if (value) out.push_back(il2utils::conv_string(value));
            }
            if (!out.empty()) return;
        }
    }

    // A target becomes a label, or nothing. A bare 24-hex template id is not a
    // label: quest_esp::resolve_template_display_name turns an item template id
    // into its localized name, and an enemy id that the item factory does not
    // know comes back empty -- in which case showing the hex is worse than
    // showing the condition's generic label.
    inline std::string target_label(const std::string& id) {
        if (id.empty()) return {};

        if (!quest_esp::is_pure_template_id(id)) return id;

        if (const std::string name = quest_esp::resolve_template_display_name(id); !name.empty())
            return name;
        return {};
    }

    inline std::unordered_map<Il2CppObject*, std::string>& text_cache() {
        static std::unordered_map<Il2CppObject*, std::string> cache;
        return cache;
    }

    // The label for one condition. Never empty: a condition whose description
    // cannot be read still gets its class-derived label, because an objective
    // the player cannot name is the case this whole file exists to fix.
    //
    // Cached per Condition object. FormattedDescription is the most expensive
    // thing here -- it is a managed property that formats and localizes -- and
    // it cannot change while the quest object is alive, so it is resolved once
    // per condition per raid. clear_caches() drops the table at the raid
    // boundary, which also disposes of the pointer identity problem: a new raid
    // can hand a new condition the address of a freed one.
    //
    // The cache is NOT thread-safe and is not made so. It is game-thread-only by
    // the rule at the top of this file, and QuestModule clears it from
    // draw_overlay -- which is the render thread -- at the raid boundary, so this
    // is the one place the two threads meet. That is safe only because the raid
    // boundary is a point where neither side touches it: the render thread's
    // clear happens when !is_in_raid, and the game thread's reads happen only
    // from gameworld_update, which is not running then. A second caller from the
    // render thread mid-raid would need a lock, and the comment here is the thing
    // that tells the next reader why there isn't one.
    inline std::string text_of(Il2CppObject* condition) {
        if (!condition) return {};

        auto& cache = text_cache();
        const auto cached = cache.find(condition);
        if (cached != cache.end()) return cached->second;

        char buffer[kDescriptionBuffer];
        buffer[0] = '\0';
        // SEH-guarded inside quest_esp, and it is the game's own text: localized,
        // with embedded item template ids substituted for item names, and empty
        // rather than garbage when the description is unusable.
        quest_esp::write_condition_description_seh(condition, buffer, sizeof(buffer));

        std::string text = buffer;
        if (text.empty()) {
            const char* klass_name = condition->klass ? condition->klass->name : "";
            const text_plan plan = plan_for(klass_name);

            std::vector<std::string> raw;
            read_targets(condition, raw);

            std::vector<std::string> labels;
            for (const std::string& token : raw) {
                split_token_list(token, labels);
            }

            std::vector<std::string> named;
            for (const std::string& token : labels) {
                if (std::string label = target_label(token); !label.empty())
                    named.push_back(std::move(label));
            }

            const std::string joined = join_labels(named);
            text = joined.empty() ? std::string(plan.fallback)
                                  : std::string(plan.verb) + " " + joined;
        }

        truncate_text(text);
        cache.emplace(condition, text);
        return text;
    }

    // ------------------------------------------------------------------ unreadable quests
    //
    // Quests already known to yield no readable rows this raid, so they are not read again.
    //
    // WHY THIS IS NOT A LOG LATCH, because the two look identical and only one of them costs
    // anything. The per-condition catch in collect() has its own `static reported` map, and it
    // makes the log line appear once per quest -- but the latch is on the LOGGING. The
    // try/catch still runs, the managed exception is still thrown, and IL2CPP still unwinds
    // through its frames on every single read. A quiet log is not a cheap operation.
    //
    // That was free until 2026-10-04, when publish_all_objectives went from once per raid to
    // every kProgressIntervalMs (500 ms). Five dormant SideQuests whose conditions throw, on
    // the DEFAULT view, is ten managed exceptions per second -- each one a two-phase unwind
    // through the game's own frames. And the profile could not see it: the per-publish mean
    // was 13 us, which is the cost of everything EXCEPT the unwinds, because a thrown
    // exception does not bill its own time to the zone it was thrown in.
    //
    // So this memo is not an optimisation. It is the difference between paying for a fact we
    // already know and paying for it ten times a second.
    //
    // THE TRADE, stated rather than buried: a quest recorded here stays hidden until the next
    // raid. That is only a problem for a quest whose conditions became readable LATER in the
    // same raid, and such a quest is not distinguishable from a dormant one by anything
    // measured here -- both present as "no rows". Scoped per raid by clear_caches() so the
    // set cannot outlive the Il2Cpp objects it is keyed by.
    //
    // Placed ABOVE clear_caches() because it is called from it, and MSVC will not resolve a
    // name that appears later in the same namespace scope.
    inline std::unordered_set<Il2CppObject*>& no_row_quests() {
        static std::unordered_set<Il2CppObject*> quests;
        return quests;
    }

    [[nodiscard]] inline bool known_to_have_no_rows(Il2CppObject* quest) {
        return quest && no_row_quests().count(quest) != 0;
    }

    inline void note_no_rows(Il2CppObject* quest) {
        if (quest) no_row_quests().insert(quest);
    }

    // ------------------------------------------------------- condition fault reporting
    //
    // WHY THIS SECTION EXISTS. The line this replaced was
    //
    //   quest objectives: a condition of SideQuest threw a non-std exception while being read
    //
    // which named a BASE CLASS seventeen times over (2026-10-08: 17 SideQuest, 2 MainQuest,
    // 2 QuestChapter) and nothing else. It was uninformative for three separate reasons,
    // all of which are fixed below rather than worked around:
    //
    //  1. THE STAGE WAS DESTROYED ONE LINE ABOVE THE LOG CALL. detail_stage_ names the
    //     managed call in flight and is set immediately before each of the five calls that
    //     can throw -- but both handlers did `detail_stage_ = previous_stage` BEFORE
    //     logger::warn, and never passed it on. The one piece of information that says
    //     *which* call failed was computed and discarded. The comment above the guard
    //     claimed the handler gave "the condition's name AND the call that failed"; it gave
    //     neither, and the claim is the reason nobody noticed for a week.
    //  2. NO CONDITION. `condition` is in scope at both handlers and its class name is a
    //     plain field read, so "which of the twelve" was answerable for free and was not
    //     answered.
    //  3. NO QUEST ID. quest->klass->name is the base class, shared by every quest of that
    //     kind, so seventeen lines were mutually indistinguishable. collect_all already
    //     holds the template id next to the pointer it passes in, so the id is now threaded
    //     down rather than re-derived -- a managed get_Id inside a fault handler is a second
    //     chance to fault on the path that just faulted once.
    //
    // The latch is once per quest per RAID, and the per-raid scoping is the fix rather than
    // a detail: it was a function-local static that nothing cleared, so it was a
    // PROCESS-lifetime latch keyed on an Il2CppObject* that dies with the raid. A quest that
    // began throwing in the third raid said nothing at all, and a new quest landing on a
    // recycled address was silent for the rest of the process. Keying a set by a raw managed
    // pointer across a raid boundary is the identity mistake clear_caches() exists to undo for
    // text_cache() and no_row_quests(); this set is now dropped with them.
    //
    // Once per QUEST rather than per CONDITION stays, because it is what stops a
    // twelve-condition quest writing twelve identical lines -- the flood AGENTS_TODO.md 1.5
    // records -- and it now costs no diagnosis, because the line names the stage and the
    // condition class.
    inline std::unordered_set<Il2CppObject*>& faulted_quests() {
        static std::unordered_set<Il2CppObject*> quests;
        return quests;
    }

    inline void clear_faulted_quests() {
        faulted_quests().clear();
    }

    // The managed exception's own class name and message, as Il2CppString*, read out of the
    // interop wrapper IL2CPP throws when a managed exception crosses into a native frame.
    //
    // WHY A __try AND NOT catch(...). These pointers come out of an object we did not create,
    // on a path that has already faulted once. A bad read here is an ACCESS VIOLATION, which
    // catch(...) does not catch under /EHsc -- it would take the process with it, and a
    // diagnostic that can crash the game is worse than the diagnostic it replaced. So the
    // DEREFERENCE is guarded.
    //
    // WHY THE STRINGS ARE NOT CONVERTED HERE. __try is illegal in a frame with destructible
    // objects (AGENTS.md, MSVC traps), and wide_to_utf8 has one. So this returns the two raw
    // Il2CppString* and the caller converts, exactly as crash_probe.h's convention requires.
    // The residual read in conv_string is the same exposure every quest name and every
    // condition target already takes in this project.
    //
    // Returns false on a fault, a null ex, or a null message. The caller reports which,
    // because "the payload was not one of these" is the answer that would falsify the whole
    // premise and must not be silently folded into the same sentence as a real message.
    inline bool managed_exception_strings(const Il2CppExceptionWrapper* wrapper,
                                          Il2CppString** class_name, Il2CppString** message) {
        if (class_name) *class_name = nullptr;
        if (message) *message = nullptr;
        if (!wrapper) return false;
        __try {
            const Il2CppException* ex = wrapper->ex;
            if (!ex) return false;
            // className exists only in the full layout (il2cpp-object-internals.h:516 guards it
            // behind !IL2CPP_TINY); `message` is in both. Nothing defines IL2CPP_TINY in this
            // project, so the guard is inert today and exists so that a future --TINY vendoring
            // degrades this to "no class name" instead of failing to compile on a diagnostic.
#if !IL2CPP_TINY
            if (class_name) *class_name = ex->className;
#endif
            if (message) *message = ex->message;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
        return message != nullptr && *message != nullptr;
    }

    // One line per quest per raid for a condition that could not be read. Game thread only.
    inline void report_condition_fault(Il2CppObject* quest, const char* quest_id,
                                       Il2CppObject* condition, const char* stage,
                                       const std::string& detail) {
        if (!quest) return;
        if (!faulted_quests().insert(quest).second) return;

        const char* klass_name = (quest->klass && quest->klass->name) ? quest->klass->name : "?";
        const char* cond_name = (condition && condition->klass && condition->klass->name)
            ? condition->klass->name : "?";

        std::string line = "quest objectives: condition read failed -- quest ";
        if (quest_id && *quest_id) {
            line += quest_id;
            line += " (";
            line += klass_name;
            line += ")";
        }
        else {
            line += klass_name;
        }
        line += ", condition ";
        line += cond_name;
        line += ", stage ";
        line += (stage && *stage) ? stage : "(unset)";
        line += ": ";
        line += detail;
        line += ". The row is dropped; every other condition on this quest is still read.";
        logger::debug(std::move(line));
    }

    // The same, for a fault that escaped a whole collect() rather than one condition -- the
    // three probes above the per-condition guard, where resolve_quest_calls,
    // get_ProgressCheckers or get_Conditions threw. Shares the per-raid latch and the id.
    inline void report_quest_fault(Il2CppObject* quest, const char* quest_id,
                                   const char* stage, const std::string& detail) {
        if (!quest) return;
        if (!faulted_quests().insert(quest).second) return;

        const char* klass_name = (quest->klass && quest->klass->name) ? quest->klass->name : "?";

        std::string line = "quest objectives: whole-quest read failed -- quest ";
        if (quest_id && *quest_id) {
            line += quest_id;
            line += " (";
            line += klass_name;
            line += ")";
        }
        else {
            line += klass_name;
        }
        line += ", stage ";
        line += (stage && *stage) ? stage : "(unset)";
        line += ": ";
        line += detail;
        line += ". Its checklist is empty this raid; every other quest is unaffected.";
        logger::warn(std::move(line));
    }

    inline void clear_caches() {
        text_cache().clear();
        no_row_quests().clear();
        clear_faulted_quests();
    }

    // ---------------------------------------------------------------- location binding
    //
    // Whether a quest can be done where the player is standing, and what that is called.
    //
    // WHY THIS EXISTS, which is a correction rather than an addition. The "All" view was
    // capped at kAllQuestCap quests taken in DROPDOWN ORDER, on the reasoning that a stable
    // subset beats a shifting one. That is right about stability and wrong about WHICH
    // quests: dropdown order is the profile's quest order, not the raid's, so on a map with
    // 14 location-bound quests the cap can drop the two that are actually doable here and
    // keep twelve that cannot be. The player sees a list that is short, arbitrary, and
    // unrelated to the map they are on.
    //
    // The signal is the quest's own conditions. A location-bound objective is a
    // ConditionZone, and ConditionZone carries `string[] zoneIds` (ConditionZone.cs:0xE8)
    // -- the zones the objective must be reached in. That is the game's own statement of
    // "this is here", read from the same Conditions the checklist is already built from, so
    // grouping by it needs no new call path and cannot disagree with the rows below it.
    //
    // A quest with NO zone-bound condition is not location-bound: it is a kill, a handover, a
    // skill, a level. Those are doable anywhere, which is why they are reported as such
    // rather than lumped in with the local ones -- they are the quests most likely to be
    // worth the raid, and burying them under a location filter would be the opposite of
    // useful.
    //
    // The zone strings are the game's internal zone identifiers, NOT the map name, so they
    // are reported rather than compared against `location_id`. Deciding whether a given zone
    // id belongs to the current map needs the game's own zone-to-map table, and guessing at
    // it here would put quests in the wrong group -- which is worse than an honest "here are
    // the zones this quest names".
    struct location_binding
    {
        // True when at least one condition names a zone. False means "not location-bound".
        bool zone_bound = false;
        // The distinct zone ids, in first-seen order. Empty when !zone_bound.
        std::vector<std::string> zones;
    };

    // Reads the zone binding off a quest's conditions. Returns false when the conditions
    // cannot be walked at all, which the caller must treat as "unknown", NOT as
    // "not location-bound" -- conflating them puts an unreadable quest in the everywhere
    // group and claims it is doable anywhere.
    inline bool location_binding_of(Il2CppObject* quest, location_binding& out) {
        out = location_binding{};

        const quest_calls calls = resolve_quest_calls(quest);
        if (!calls.usable()) return false;

        bool walked = false;
        for_each_condition(quest, calls, [&](Il2CppObject* condition) {
            walked = true;
            if (!condition || !condition->klass || !condition->klass->name) return;

            // Substring, deliberately, and the inheritance chain is the reason: the
            // location-bound conditions are ConditionZone and its subclasses
            // (ConditionLeaveItemAtLocation, ConditionPlaceBeacon, ConditionInZone), and
            // ConditionZone itself does not derive from them. The same ordered-substring
            // rule quest_objective_text.h's plan_for uses for the same class names.
            const char* name = condition->klass->name;
            if (!strstr(name, "Zone") && !strstr(name, "LocationTrigger")
                && !strstr(name, "VisitPlace"))
                return;

            // zoneIds is `string[]` on BOTH ConditionZone and ConditionInZone, which is why
            // read_targets() treats it as an array rather than by class. Read through the
            // same helper, so a class that renames the field is handled the same way
            // everywhere.
            for (const std::string& zone : quest_esp::read_string_array_field(condition, "zoneIds")) {
                if (zone.empty()) continue;
                out.zone_bound = true;
                if (std::find(out.zones.begin(), out.zones.end(), zone) == out.zones.end())
                    out.zones.push_back(zone);
            }
        });

        // Conditions walked but none named a zone is a real answer: not location-bound.
        return walked;
    }

    // The whole checklist for one quest: text, counts, done, merged, ordered.
    //
    // `quest_id` is the quest's template id, used ONLY by the fault report so a fault names a
    // quest rather than a base class (see report_condition_fault). It is passed in because the
    // caller already holds it: collect_all keeps it next to the pointer, and re-deriving it
    // here would mean a managed get_Id on the path that has just thrown. Null is legal and
    // means "the caller does not know", in which case the report falls back to the class name.
    inline void collect(Il2CppObject* quest, std::vector<objective>& out, const char* quest_id = nullptr) {
        out.clear();
        if (!quest || !quest->klass) return;

        // WHY collect() IS PER-CONDITION FAULT-TOLERANT, which is a change of policy and
        // not an optimisation.
        //
        // A managed throw anywhere in here used to abandon the ENTIRE publish, because the
        // exception unwound straight through collect() and out of publish_objectives()
        // before objectives_published_.store() -- so one quest that cannot be read cost
        // the card every quest's checklist and every dropdown tally, silently, forever.
        // That is the 2026-10-04 observation: the scan healthy, 8 listed quests, the
        // selection matched, and nothing ever published.
        //
        // Containing it per CONDITION rather than per collect() call is the finer grain and
        // the right one: a quest's conditions are independent objects, and one condition
        // that throws says nothing about the other eleven. The rows already collected stay
        // in `out`, so a partially-readable quest shows what it could be read rather than
        // nothing -- which is also the honest rendering, and matches what the fallback text
        // path in text_of() already intends.
        //
        // The three probes BELOW the per-condition guard still run on the quest object itself,
        // so they get their own. They are the calls that reach a live quest before any
        // condition is touched, which is exactly where the 2026-10-04 throw landed --
        // 'badge pass' with detail_stage_ null, meaning ahead of the get_Conditions marker
        // that existed at the time.
        //
        // Contained separately, and for a different reason than the per-condition guard:
        // these are per-QUEST, so a throw here costs that quest's whole checklist rather
        // than one row. It must not cost the publish, or every other quest on the card
        // goes blank with it -- which is the original bug, one level up.
        quest_calls calls{};
        try {
            detail_stage_ = "resolve_quest_calls";
            calls = resolve_quest_calls(quest);
            if (!calls.usable()) { detail_stage_ = nullptr; return; }
            detail_stage_ = nullptr;
            report_unreadable_progress(quest, calls);

            detail_stage_ = "get_ProgressCheckers";
            auto* checkers = progress_checkers(quest, calls);
            detail_stage_ = nullptr;

        for_each_condition(quest, calls, [&](Il2CppObject* condition) {
            if (out.size() >= kMaxLines) return;

            // The guard the comment above this function describes. A managed throw from any
            // of the five calls below is contained to THIS condition: the row is dropped and
            // the walk continues. One condition that cannot be read is a missing row, which
            // is strictly better than losing every quest on the card.
            //
            // The stage marker is set for the whole body and READ OUT by the handler before it
            // is restored, so the report names the condition class AND the call that failed,
            // which together identify the row to look at in a dump.
            //
            // It used to say "cleared in the handler, so a caller reporting a fault gets ..." and
            // then not pass it on, which is how a line reading "a condition of SideQuest threw
            // a non-std exception" survived a week: the comment asserted a diagnostic the code
            // did not emit. If you change the handlers, the claim above has to stay true.
            const char* previous_stage = detail_stage_;
            try {
                detail_stage_ = "is_necessary";
                if (!is_necessary(condition)) { detail_stage_ = previous_stage; return; }

                objective line;
                detail_stage_ = "text_of";
                line.text = text_of(condition);
                if (line.text.empty()) { detail_stage_ = previous_stage; return; }

                detail_stage_ = "IsConditionDone";
                line.done = is_done(quest, calls, condition);
                detail_stage_ = "get_CurrentValue";
                line.current = checkers ? current_value(checkers->get_value_by_key(condition)) : 0;
                detail_stage_ = "Condition.get_value";
                line.target = condition_value(condition);

                // current_value never returns negative, but a summed row can exceed
                // its own target, and "14/10" is read as a bug rather than as
                // overshoot. Clamped at display time instead so the raw number is
                // still available.
                line.has_count = line.target > 1 || line.current > 0;
                out.push_back(std::move(line));
            }
            catch (const std::exception& e) {
                // Read the stage BEFORE restoring it. Restoring first and logging second is
                // what discarded the only field that named the failing call.
                const char* failed_stage = detail_stage_;
                detail_stage_ = previous_stage;
                report_condition_fault(quest, quest_id, condition, failed_stage,
                                       std::string("std::exception: ") + e.what());
            }
            catch (const Il2CppExceptionWrapper& wrapper) {
                // The interop shape IL2CPP throws across a native frame. This clause is a
                // HYPOTHESIS, not a known fact, and the report is written so that a miss is
                // visible rather than folded into the same sentence as a hit: if this never
                // fires, every fault lands in catch(...) below and says so in as many words.
                const char* failed_stage = detail_stage_;
                detail_stage_ = previous_stage;

                Il2CppString* klass = nullptr;
                Il2CppString* message = nullptr;
                std::string detail;
                if (managed_exception_strings(&wrapper, &klass, &message)) {
                    detail = "managed exception";
                    if (klass) detail += " " + il2utils::conv_string(klass);
                    if (message) detail += ": " + il2utils::conv_string(message);
                }
                else {
                    detail = "an Il2CppExceptionWrapper, but no readable message on it";
                }
                report_condition_fault(quest, quest_id, condition, failed_stage, std::move(detail));
            }
            catch (...) {
                const char* failed_stage = detail_stage_;
                detail_stage_ = previous_stage;
                report_condition_fault(quest, quest_id, condition, failed_stage,
                                       "non-std exception, and the payload was not an "
                                       "Il2CppExceptionWrapper -- so the managed type and "
                                       "message are unavailable here");
            }
        });
        }
        catch (const std::exception& e) {
            // Per-QUEST, and deliberately NOT fatal to the caller. see the comment at the
            // top of this function: losing one quest's rows must not cost every other
            // quest's, which is what an escaping exception does -- it abandons the whole
            // publish and leaves the card on "Reading objectives..." indefinitely.
            const char* failed_stage = detail_stage_;
            detail_stage_ = nullptr;
            report_quest_fault(quest, quest_id, failed_stage, std::string("std::exception: ") + e.what());
        }
        catch (const Il2CppExceptionWrapper& wrapper) {
            const char* failed_stage = detail_stage_;
            detail_stage_ = nullptr;

            Il2CppString* klass = nullptr;
            Il2CppString* message = nullptr;
            std::string detail;
            if (managed_exception_strings(&wrapper, &klass, &message)) {
                detail = "managed exception";
                if (klass) detail += " " + il2utils::conv_string(klass);
                if (message) detail += ": " + il2utils::conv_string(message);
            }
            else {
                detail = "an Il2CppExceptionWrapper, but no readable message on it";
            }
            report_quest_fault(quest, quest_id, failed_stage, std::move(detail));
        }
        catch (...) {
            const char* failed_stage = detail_stage_;
            detail_stage_ = nullptr;
            report_quest_fault(quest, quest_id, failed_stage,
                               "non-std exception, and the payload was not an "
                               "Il2CppExceptionWrapper -- so the managed type and "
                               "message are unavailable here");
        }

        // Both merges run even if the guarded block above bailed, because `out` may hold
        // the rows collected before the throw and those are still worth showing and
        // counting. merge_duplicates and order_by_outstanding are pure C++ over
        // std::vector<std::string> and cannot themselves throw a managed exception.
        merge_duplicates(out);
        order_by_outstanding(out);
    }

    // The tally, counted over the SAME rows the card draws.
    //
    // THIS USED TO BE A SECOND, CHEAPER COUNTER, and having two was the bug. It walked the
    // conditions and counted raw necessary ones, while collect() merges duplicates first --
    // so the same quest reported two different totals in two places on the same card. A
    // quest that asks for the same handover three times is three raw conditions and ONE
    // drawn row: the header said 1/1 and the dropdown badge said 0/3. And because
    // publish_objectives() overwrote the selected quest's badge with the header's number,
    // the badge CHANGED WHEN YOU SELECTED THE QUEST, then reverted on its own schedule
    // when you moved away. A number that moves when you highlight a row, and disagrees with
    // the row above it, is what "the summary is not updating" looks like.
    //
    // The cheap pass was not buying much, either. The expensive part of collect() is
    // text_of() -- get_FormattedDescription plus the item factory -- and that is memoised
    // per Condition for the life of the raid (see text_cache()). A second visit to a quest
    // costs the IsConditionDone and CurrentValue calls the cheap pass was making anyway,
    // and only for the one quest this runs on.
    //
    // `scratch` is caller-owned and reused across quests so the round-robin pass does not
    // allocate per scan; collect() clears it.
    inline bool summarise(Il2CppObject* quest, std::vector<objective>& scratch, int& done, int& total) {
        done = 0;
        total = 0;
        collect(quest, scratch);
        for (const objective& line : scratch) {
            total++;
            if (line.done) done++;
        }
        return total > 0;
    }

    // ---------------------------------------------------------------- grouped

    // Per-quest rows, for the "All" selection on the card.
    //
    // A struct rather than parallel vectors precisely because the group boundary IS the
    // data: every row has to stay attached to its quest, and parallel vectors can be
    // momentarily out of step in exactly the way quest_list_snapshot's comment describes.
    // The moment they are out of step, a requirement is attributed to the wrong quest and
    // the player acts on that.
    struct quest_group
    {
        std::string id;
        std::string name;
        std::vector<objective> lines;
        int done = 0;
        int total = 0;

        // The quest's location binding, read from its own conditions. See
        // location_binding_of() for why this is the game's statement rather than a guess,
        // and why `known` is separate from `zone_bound`.
        quest_objectives::location_binding location;
        // FALSE when the conditions could not be walked at all. Distinct from
        // "zone_bound == false", which means "walked, and none named a zone": the first is
        // unknown and the second is a real answer, and rendering them identically would
        // claim an unreadable quest is doable anywhere.
        bool known = false;

        // Whether the quest's PROGRESS could be resolved, as opposed to its conditions.
        // quest_calls::progress_readable() answers whether IsConditionDone and the
        // progress checkers resolved on this quest's class, which is a different question
        // from whether any condition was readable: a quest can have readable condition
        // text and still be unable to say whether any of it is done. Carried here so the
        // card can say which, instead of drawing an unstarted quest and an unreadable one
        // identically.
        bool readable = true;
    };

    // Whether the quest's PROGRESS could be resolved. Named to avoid colliding with the
    // free progress_readable() above, which is the same question spelled differently; a
    // local alias would be ambiguous at the call site because both are in scope.
    inline bool calls_readable(Il2CppObject* quest) {
        return progress_readable(quest);
    }

    // Every listed quest's checklist, one group per quest; quests with no readable
    // objective are omitted rather than shown as an empty heading.
    //
    // NOT CAPPED HERE, which is a change and not an oversight. It used to stop at
    // kAllQuestCap quests in the order they were passed in. That order was the DROPDOWN's,
    // which is the profile's quest order rather than the map's -- so on a map with 14
    // location-bound quests the cap kept twelve that cannot be done here and dropped the
    // ones that can. A cap that picks the wrong quests is worse than no cap, because the
    // player cannot tell it truncated.
    //
    // The cost is bounded instead by the caller's own scan throttle (300 ms) and by
    // collect()'s per-quest text cache, which memoises the expensive FormattedDescription
    // work per Condition for the life of the raid. kAllQuestCap remains as a backstop on
    // pathological profiles and is applied by the caller, where the shortfall can be
    // reported.
    //
    // Groups, not one merged list, because the entire value of "All" is knowing WHICH quest
    // a requirement belongs to. Flattened, "Locate the lever" and "Hand over 3 shells"
    // become siblings with no context -- less information than the single-quest view has,
    // not more.
    //
    // This is the expensive call in the file: it is collect() once per active quest, and on
    // a late-wipe profile that is 40+ quests of get_FormattedDescription and IsConditionDone
    // every scan. It is bounded by kAllQuestCap below rather than by the 300 ms throttle,
    // because a cap that silently drops quests reads as "these are all of them" when it is
    // not. The caller passes the CAP FIRST, so the quests shown are the ones the dropdown
    // lists first -- a stable subset, not a shifting one.
    //
    // `out` is caller-owned and reused across scans.
    inline void collect_all(const std::vector<std::pair<std::string, Il2CppObject*>>& quests,
                            std::vector<quest_group>& out) {
        out.clear();
        // Reused across quests so a 40-quest pass allocates once rather than 40 times.
        std::vector<objective> lines;

        for (size_t i = 0; i < quests.size(); ++i) {
            Il2CppObject* quest = quests[i].second;
            if (!quest) continue;

            // Already known to yield nothing. Skipping here rather than after the call is the
            // whole point: collect() would throw a managed exception per condition and unwind
            // out of it, and that is the cost being avoided, so it has to be avoided BEFORE
            // the call rather than cached after it.
            if (known_to_have_no_rows(quest)) continue;

            lines.clear();
            // The id comes along for the fault report only. It is already in hand here, and
            // collect() must never go looking for it: a managed get_Id on the path that has
            // just thrown is a second chance to fault, and a fault inside a fault handler
            // escapes to the per-quest guard and is reported as a whole-quest fault, which is
            // a different and wrong diagnosis of the same quest.
            collect(quest, lines, quests[i].first.c_str());
            if (lines.empty()) {
                note_no_rows(quest);
                continue;
            }

            quest_group group;
            group.id = quests[i].first;
            // The game's own name is not reachable from here without a second call per
            // quest, and the caller already has the display name it put in the dropdown --
            // so it is passed in rather than re-derived. An empty name is legal here (see
            // the blank-name handling in QuestModule::draw_overlay) and renders as the id.
            group.name = quests[i].first;
            // Counted over the MERGED rows, exactly as the single-quest header counts, so
            // "All" and any one quest never disagree about what a total means.
            for (const objective& line : lines) {
                group.total++;
                if (line.done) group.done++;
            }
            group.known = location_binding_of(quest, group.location);
            // Read once here rather than by each consumer. The card needs it per quest, and
            // the alternative -- a caller resolving it per group -- is three method lookups
            // per quest that this loop already has the object for.
            group.readable = calls_readable(quest);
            group.lines = std::move(lines);
            out.push_back(std::move(group));
        }
    }

} // namespace quest_objectives
