#pragma once

#include <Windows.h>
#include <imgui.h>
#include <algorithm>
#include <functional>
#include <string>
#include <unordered_map>
#include <vector>

#include "../config/CheckboxValue.h"
#include "../config/SelectValue.h"
#include "../gui/menu/hotkey_conflicts.h"
#include "../gui/menu/imgui_addons.h"
#include "../gui/menu/menu.h"
#include "../util/i18n.h"

class EspModule;
class MinimapModule;
class MapModule;
class PlayerModule;
class AiLimitModule;
class AmmoHudModule;
class DoorsModule;
class WeaponModule;
class WorldModule;
class IcebreakerScenarioModule;
class ConfigModule;
#ifdef INCLUDE_AIMBOT
class AimbotModule;
#endif

namespace hotkeys {
    // The pure grouping lives in hotkey_conflicts.h so tools/harness can test
    // it; this line is the one place the two can drift, so it is pinned. The
    // literal exists because that header deliberately does not include
    // <Windows.h> -- see its comment.
    static_assert(VK_INSERT == hotkey_conflicts::k_menu_toggle_key,
        "hotkey_conflicts::k_menu_toggle_key no longer names VK_INSERT");

    // The warm amber the safety tooltips use, reused for conflicts so
    // "this needs your attention" is one colour across the menu.
    inline const ImVec4 warn_col = ImVec4(0.92f, 0.42f, 0.10f, 1.0f);

    enum class section {
        aimbot,
        esp,
        exploits
    };

    struct binding
    {
        std::string id;
        const char* label = "";
        section sec = section::esp;
        int key = 0;
        int* key_storage = nullptr;
        CheckboxValue* toggle = nullptr;
        // A mutually-exclusive dropdown this key drives, and the option it
        // selects. Distinct from `toggle` on purpose: a dropdown is not a set of
        // independent switches, so pressing the key must SET the option rather
        // than flip between "on" and "off". try_toggle() would also have been
        // wrong for the second reason that it consults is_disabled() -- there is
        // no disabled dropdown to decline a switch.
        SelectValue* select = nullptr;
        int select_option = 0;
        std::function<void()> action;
        std::function<bool()> can_enable;
        bool hidden_in_config_panel = false;
    };

    inline int& binding_key(binding& b) {
        return b.key_storage ? *b.key_storage : b.key;
    }

    inline int binding_key_value(const binding& b) {
        return b.key_storage ? *b.key_storage : b.key;
    }

    inline std::vector<binding>& all() {
        static std::vector<binding> bindings;
        return bindings;
    }

    // Written by draw_keybind_button() on the RENDER thread and read by tick()
    // on the GAME thread (ConfigModule::application_update calls tick()). It was
    // a plain int* shared by the two with no synchronisation, which is both a
    // data race and the reason a rebind could not be ordered against the key
    // value it writes.
    //
    // The release/acquire pair is what makes the rebind safe, and the code order
    // is already right for it: draw_keybind_button() stores nullptr with release
    // AFTER writing key_var, and tick() loads it with acquire BEFORE reading
    // key_var (it returns early when non-null). So the new key value is visible
    // to the game thread before it can act on it.
    inline std::atomic<int*> waiting_for_key{nullptr};

    // Game thread only: tick() is its sole accessor.
    inline std::unordered_map<int, bool>& key_pressed() {
        static std::unordered_map<int, bool> pressed;
        return pressed;
    }

    inline std::string get_key_name(const int key_code) {
        if (key_code == 0) return i18n::tr("none_inf");
        if (key_code > 0 && key_code < 165) return menu::KeyNames[key_code];
        return "Key " + std::to_string(key_code);
    }

    inline void add_toggle(const std::string& id, const char* label, section sec, CheckboxValue* toggle,
        const int default_key = 0, std::function<bool()> can_enable = nullptr,
        const bool hidden_in_config_panel = false) {
        binding b;
        b.id = id;
        b.label = label;
        b.sec = sec;
        b.key = default_key;
        b.toggle = toggle;
        b.can_enable = std::move(can_enable);
        b.hidden_in_config_panel = hidden_in_config_panel;
        all().push_back(std::move(b));
    }

    inline void add_action(const std::string& id, const char* label, section sec,
        std::function<void()> action, const int default_key = 0,
        const bool hidden_in_config_panel = false) {
        binding b;
        b.id = id;
        b.label = label;
        b.sec = sec;
        b.key = default_key;
        b.action = std::move(action);
        b.hidden_in_config_panel = hidden_in_config_panel;
        all().push_back(std::move(b));
    }

    // One key per option of a mutually-exclusive dropdown. Register N of them
    // against the same SelectValue and every mode becomes reachable without
    // opening the menu; which key belongs to which mode is the user's business
    // and is drawn/saved exactly like any other binding.
    inline void add_select(const std::string& id, const char* label, section sec, SelectValue* select,
        const int option, const int default_key = 0, const bool hidden_in_config_panel = false) {
        binding b;
        b.id = id;
        b.label = label;
        b.sec = sec;
        b.key = default_key;
        b.select = select;
        b.select_option = option;
        b.hidden_in_config_panel = hidden_in_config_panel;
        all().push_back(std::move(b));
    }

    inline void add_keybind(const std::string& id, const char* label, section sec, int* key_var,
        const int default_key = 0) {
        binding b;
        b.id = id;
        b.label = label;
        b.sec = sec;
        b.key_storage = key_var;
        b.key = default_key;
        if (key_var)
            *key_var = default_key;
        all().push_back(std::move(b));
    }

    void register_esp(EspModule* esp);
    void register_minimap(MinimapModule* minimap);
    void register_map(MapModule* map);
    void register_player(PlayerModule* player, AiLimitModule* ai_limit);
    void register_weapon(WeaponModule* weapon);
    void register_doors(DoorsModule* doors);
    void register_world(WorldModule* world);
    void register_ammo_hud(AmmoHudModule* ammo_hud);
    void register_icebreaker_scenario(IcebreakerScenarioModule* module);
    void register_config(ConfigModule* config);
#ifdef INCLUDE_AIMBOT
    void register_aimbot(AimbotModule* aimbot);
#endif

    inline void clear_bindings() {
        all().clear();
    }

    inline bool try_toggle(CheckboxValue* toggle, const std::function<bool()>& can_enable) {
        if (!toggle) return false;

        const bool enabling = !toggle->get_value();
        if (enabling)
        {
            if (toggle->is_disabled()) return false;
            if (can_enable && !can_enable()) return false;
        }

        toggle->set_value(!toggle->get_value());
        return true;
    }

    inline void tick() {
        // Acquire: pairs with the release store in draw_keybind_button, so
        // everything that thread wrote before clearing this flag -- including the
        // new key value -- is visible here before key_var is read below.
        if (waiting_for_key.load(std::memory_order_acquire) != nullptr) return;

        auto& pressed = key_pressed();
        for (auto& b : all())
        {
            if (b.key_storage) continue;

            const int key_code = binding_key(b);
            if (key_code == 0) continue;

            if (GetAsyncKeyState(key_code) & 0x8000)
            {
                if (!pressed[key_code])
                {
                    if (b.toggle)
                        try_toggle(b.toggle, b.can_enable);
                    else if (b.select)
                    {
                        // can_enable is honoured here even though there is no
                        // disabled state to check, so a binding that needs a
                        // condition (e.g. "only while in a raid") can still
                        // express one.
                        if (!b.can_enable || b.can_enable()) b.select->set_value(b.select_option);
                    }
                    else if (b.action)
                        b.action();
                    pressed[key_code] = true;
                }
            }
            else
            {
                pressed[key_code] = false;
            }
        }
    }

    // `warn` marks a binding whose key another binding also uses (or which
    // sits on the menu toggle). It tints the row and nothing else -- the
    // report is advisory, so the button still rebinds normally.
    inline void draw_keybind_button(const char* label, int& key_var, const bool warn = false) {
        const float sf = menu::get_scale_factor();
        if (warn) ImGui::PushStyleColor(ImGuiCol_Text, warn_col);
        ImGui::TextColored(menu::with_alpha(menu::palette::txt, 0.9f), "%s", i18n::tr(label).c_str());

        constexpr float btn_width = 85.0f;
        ImGui::SameLine(ImGui::GetContentRegionAvail().x - btn_width * sf - 4.f * sf);

        int* const waiting = waiting_for_key.load(std::memory_order_relaxed);
        std::string btn_text;
        if (waiting == &key_var)
            btn_text = "[ ... ]";
        else
            btn_text = "[ " + get_key_name(key_var) + " ]";

        ImGui::PushID(label);
        // Mono on the keycap: key names are short, uppercase and full of
        // 1/l/I/O ambiguity, which is exactly what a mono face disambiguates.
        const bool mono = imgui_addons::push_mono_font();
        if (ImGui::Button(btn_text.c_str(), ImVec2(btn_width * sf, 0)))
            waiting_for_key.store(&key_var, std::memory_order_relaxed);
        imgui_addons::pop_mono_font(mono);
        ImGui::PopID();

        if (warn) ImGui::PopStyleColor();

        if (waiting_for_key.load(std::memory_order_relaxed) == &key_var)
        {
            for (int i = 3; i < 256; ++i)
            {
                if (GetAsyncKeyState(i) & 0x8000)
                {
                    // Write the value FIRST, then release-publish the cleared
                    // flag. tick() acquires that flag before reading key_var, so
                    // it can never observe the new key with the old value.
                    key_var = i == VK_ESCAPE ? 0 : i;
                    waiting_for_key.store(nullptr, std::memory_order_release);
                    break;
                }
            }
        }
    }

    inline void draw_section_header(const char* title) {
        ImGui::Dummy(ImVec2(0, 6.f));
        ImGui::Separator();
        ImGui::TextColored(menu::palette::accent2, "%s", i18n::tr(title).c_str());
        ImGui::Dummy(ImVec2(0, 2.f));
    }

    inline void draw_bindings_for_section(const section sec, const std::vector<int>& conflict_keys) {
        for (auto& b : all())
        {
            if (b.sec != sec || b.hidden_in_config_panel) continue;
            const int key = binding_key_value(b);
            const bool warn = std::find(conflict_keys.begin(), conflict_keys.end(), key)
                != conflict_keys.end();
            draw_keybind_button(b.label, binding_key(b), warn);
        }
    }

    inline void draw_panel() {
        // The conflict report, rebuilt every frame it is visible. A rebind
        // lands inside draw_keybind_button below, so a cached set would be
        // one frame stale -- the block would describe the panel as it was,
        // which for a report is worse than no report. find() is O(rows^2)
        // over ~40 bindings, once per frame, on a panel the user is looking
        // at while they rebind.
        std::vector<hotkey_conflicts::row> rows;
        rows.reserve(all().size());
        for (const auto& b : all())
        {
            if (b.hidden_in_config_panel) continue;
            rows.push_back({binding_key_value(b), b.label, b.id.c_str()});
        }
        const std::vector<hotkey_conflicts::group> conflicts = hotkey_conflicts::find(rows);
        std::vector<int> conflict_keys;
        conflict_keys.reserve(conflicts.size());
        for (const auto& g : conflicts)
            conflict_keys.push_back(g.key);

        if (!conflicts.empty())
        {
            draw_section_header("hotkey_conflicts_sec");
            for (const auto& g : conflicts)
            {
                // "F2 -- God Mode, Noclip": one line per key, the actions in
                // panel order, which is the order the key fires them in. The
                // key itself in mono, for the same reason as the button.
                std::string line;
                const bool mono = imgui_addons::push_mono_font();
                line = hotkeys::get_key_name(g.key);
                ImGui::TextColored(warn_col, "%s", line.c_str());
                imgui_addons::pop_mono_font(mono);
                ImGui::SameLine();
                ImGui::TextColored(warn_col, "-- ");
                for (size_t i = 0; i < g.labels.size(); ++i)
                {
                    if (i) ImGui::TextColored(warn_col, ", ");
                    ImGui::TextColored(warn_col, "%s", i18n::tr(g.labels[i]).c_str());
                    if (i + 1 < g.labels.size())
                        ImGui::SameLine();
                }
            }
            ImGui::PushStyleColor(ImGuiCol_TextDisabled,
                menu::with_alpha(warn_col, 0.85f));
            ImGui::TextWrapped("%s", i18n::tr("hotkey_conflicts_inf").c_str());
            ImGui::PopStyleColor();
            ImGui::Dummy(ImVec2(0, 4.f));
        }

#ifdef INCLUDE_AIMBOT
        draw_section_header("aimbot_sec");
        draw_bindings_for_section(section::aimbot, conflict_keys);
#endif

        draw_section_header("esp_sec");
        draw_bindings_for_section(section::esp, conflict_keys);

        draw_section_header("exploits_sec");
        draw_bindings_for_section(section::exploits, conflict_keys);
    }

    inline std::string config_prefix() {
        return "HK:";
    }

    inline void load(const std::unordered_map<std::string, std::string>& values) {
        const std::string prefix = config_prefix();
        for (auto& b : all())
        {
            std::string lookup_id = b.id;
            if (lookup_id == "esp.show_loot_prices")
                lookup_id = "esp.show_prices";
            // "exploit.god_mode2" was renamed to "exploit.buddha_mode" when
            // god_mode2 became Buddha Mode. The old spelling is still honoured on
            // the way in, so a saved keybind is not silently dropped; nothing
            // writes it any more.
            else if (lookup_id == "exploit.buddha_mode")
                lookup_id = "exploit.god_mode2";

            auto iter = values.find(prefix + lookup_id);
            if (iter == values.end())
                iter = values.find(prefix + b.id);
            if (iter == values.end()) continue;
            try
            {
                binding_key(b) = std::stoi(iter->second);
            } catch (...)
            {
            }
        }
    }

    inline void append_save(std::string& value) {
        const std::string prefix = config_prefix();
        for (const auto& b : all())
        {
            value.append(prefix);
            value.append(b.id);
            value.append(";");
            value.append(std::to_string(binding_key_value(b)));
            value.append(";");
        }
    }

    inline void append_defaults(std::string& value) {
        append_save(value);
    }
} // namespace hotkeys
