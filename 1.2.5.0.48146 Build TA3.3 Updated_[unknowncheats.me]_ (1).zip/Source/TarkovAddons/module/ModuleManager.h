#pragma once
#include <functional>

#include "../util/logger.h"
#include "hotkeys.h"
#include "Module.h"
#include "impl/AiLimitModule.h"
// Guarded because AimbotModule.h guards its whole contents. Including it
// unconditionally would defeat the flavour -- every consumer of this header
// would still be able to see the type and the shared aim state.
#ifdef INCLUDE_AIMBOT
#include "impl/AimbotModule.h"
#endif
#include "impl/ChamsModule.h"
#include "impl/ConfigModule.h"
#include "impl/DoorsModule.h"
#include "impl/DebugLogModule.h"
#include "impl/EspModule.h"
#include "impl/MapEditorModule.h"
#include "impl/MapModule.h"
#include "impl/MinimapModule.h"
#include "impl/ItemModule.h"
#include "impl/HideoutAutomationModule.h"
#include "impl/HideoutModule.h"
#include "impl/InventoryEditorModule.h"
#include "impl/WeaponBuilderModule.h"
#include "impl/PlayerModule.h"
#include "impl/ProfileModifiersModule.h"
#include "impl/ExperienceEditorModule.h"
#include "impl/FavoritesModule.h"
#include "impl/RaidDashboardModule.h"
#include "impl/TeleportModule.h"
#include "impl/QuestModule.h"
#include "impl/QuestResetModule.h"
#include "impl/AmmoHudModule.h"
#include "impl/WatermarkModule.h"
#include "impl/WeaponModule.h"
#include "impl/WorldModule.h"
#include "impl/LootTeleportModule.h"
#include "impl/ItemSpawnerBridgeModule.h"
#include "impl/IcebreakerScenarioModule.h"

class ModuleManager;
inline static ModuleManager* instance = nullptr;

class ModuleManager
{
  public:
    ~ModuleManager();

    ModuleManager() = default;

    void init() const;

    std::vector<PVOID> modules = std::vector<PVOID>();

    // Visits every REGISTERED module whose is_active() is true.
    //
    // is_active() answers "does this module want to do work right now", and that
    // is the right question for the three hook paths (application_update,
    // gameworld_update, draw_overlay). It is the WRONG question for drawing a
    // module's settings card: the card is where the toggles that make the module
    // active live, so gating the card on is_active() means a module whose every
    // toggle is off hides the only control that can turn it back on. Use
    // apply_all() for that.
    void apply(const std::function<void(Module*)>& function) const;

    // Visits every registered module regardless of is_active(). For UI that must
    // stay reachable -- currently the category card in the menu.
    void apply_all(const std::function<void(Module*)>& function) const;

    template <typename T>
    T* module(T* value) {
        modules.push_back(static_cast<PVOID>(value));
        return value;
    }

    std::vector<Module*> get_modules() const;

    // register modules here
    //
    // Raid Dashboard column order — the menu draws cards in registration order and
    // splits the columns exactly once, on the Debug Log card, so the three cards
    // on this tab have to straddle it. That fixes the order below:
    //
    //   left  : Raid Dashboard, Debug Log
    //   right : Favorites, Configs (+ the hotkey panel)
    //
    // Debug Log is registered BEFORE Favorites purely for that split, and it used
    // to sit between Favorites and Configs instead. That put it on the left of the
    // boundary while pushing Favorites left with it, so switching "Show Debug Log"
    // on moved BOTH cards and left the right column holding only Configs. The
    // request was for Favorites -> Configs -> Hotkeys to stay put and Debug Log to
    // be the last card on the left, which is exactly the order above.
    //
    // It also means the layout no longer depends on the toggle: with the card
    // hidden the split fires at the same slot (menu.cpp handles that case
    // explicitly), so the right column is the same either way.
    //
    // Neither module is referenced by pointer anywhere else, and neither depends on
    // the other — see DebugLogModule, which takes its enabled state from the
    // dashboard each frame rather than from Favorites. ConfigModule below still
    // comes last, because it enumerates every module registered before it.
    RaidDashboardModule* raid_dashboard_module = module(new RaidDashboardModule());
    DebugLogModule* debug_log_module = module(new DebugLogModule());
    FavoritesModule* favorites_module = module(new FavoritesModule());

    // aimbot -- only in the flavours that define INCLUDE_AIMBOT. See the guard
    // on the include above: a no-aimbot build has no AimbotModule type at all,
    // so this member must not exist either.
#ifdef INCLUDE_AIMBOT
    AimbotModule* aimbot_module = module(new AimbotModule());
#endif
    DoorsModule* doors_module = module(new DoorsModule());
    WeaponModule* weapon_module = module(new WeaponModule());
    PlayerModule* player_module = module(new PlayerModule());
    ProfileModifiersModule* profile_modifiers_module = module(new ProfileModifiersModule(player_module));

    // Visual cards are intentionally presented on the Exploit tab after the
    // core exploit cards: Minimap, Chams, then ESP.
    MinimapModule* minimap_module = module(new MinimapModule());
    ChamsModule* chams_module = module(new ChamsModule());
    EspModule* esp_module = module(new EspModule());
    MapEditorModule* map_editor_module = module(new MapEditorModule());
    // esp_module, and not a global: the big map's markers are drawn by
    // EspModule::draw_big_map_markers so the radar and the full-screen map share
    // ONE renderer and cannot drift apart (see MapModule.h). This MUST stay
    // declared after esp_module -- C++ initialises members in declaration order,
    // and passing a not-yet-constructed pointer here would compile and then be
    // read as a valid-but-garbage EspModule*.
    MapModule* map_module = module(new MapModule(esp_module));

    WorldModule* world_module = module(new WorldModule());
    // Between World and Bot Controls on purpose: the draw order comes from this
    // declaration order, and the AI Limit card's place in the LEFT column of the
    // Bot Spawner tab depends on it sitting before the first right-column card.
    // See gui/menu/column_layout.h. player_module supplies the two
    // invisible-to-AI toggles this card presents.
    AiLimitModule* ai_limit_module = module(new AiLimitModule(world_module, player_module));
    BotControlModule* bot_control_module = module(new BotControlModule(world_module));
    InventoryEditorModule* inventory_editor_module = module(new InventoryEditorModule());
    ItemModule* item_module = module(new ItemModule());
    // Profile page column order — the menu draws cards in registration order and splits the
    // columns exactly once, on the Experience Editor card. So the two hideout cards have to
    // straddle it, which fixes the order below:
    //
    //   left  : Trader Editor, Hideout
    //   right : Experience Editor, Hideout Automation
    //
    // Hideout is registered BEFORE ExperienceEditorModule purely for that split; the two have
    // no dependency on each other. ExperienceEditorModule still only needs player_module,
    // registered above.
    HideoutModule* hideout_module = module(new HideoutModule());
    ExperienceEditorModule* experience_editor_module = module(new ExperienceEditorModule(player_module));
    HideoutAutomationModule* hideout_automation_module = module(new HideoutAutomationModule());
    WeaponBuilderModule* weapon_builder_module = module(new WeaponBuilderModule(inventory_editor_module));
    ItemSpawnerBridgeModule* weapon_item_spawner_module = module(new ItemSpawnerBridgeModule(item_module));
    TeleportModule* teleport_module = module(new TeleportModule());
    MarkedRoomsModule* marked_rooms_module = module(new MarkedRoomsModule());
    LootTeleportModule* loot_teleport_module = module(new LootTeleportModule(world_module));
    QuestModule* quest_module = module(new QuestModule());
    QuestResetModule* quest_reset_module = module(new QuestResetModule(quest_module));
    IcebreakerScenarioModule* icebreaker_scenario_module = module(new IcebreakerScenarioModule());

    // misc
    AmmoHudModule* ammo_hud_module = module(new AmmoHudModule());
    WatermarkModule* watermark_module = module(new WatermarkModule());

    // this has to get instantiated last
    ConfigModule* config_module = module(new ConfigModule(get_modules()));

    static ModuleManager* get_instance();

    bool has_module(const std::string& name) const;
};
