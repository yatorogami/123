#pragma once
#include <cstdint>

// The decision and the arithmetic behind the three survival modes. No il2cpp, no
// windows.h, no reflection: this is a pure function of (mode, body part,
// current health, delta), which is why it lives here rather than inside the
// semi_god namespace in PlayerModule.h. That namespace keeps the parts that DO
// need the game -- the two hooks, the controller tracking, and the walk that
// reads a part's current health out of _bodyState -- and calls in here.
//
//   god_mode      (god_mode_cb)       nothing is protected. The per-frame
//                                    SetDamageCoeff(-1)/RestoreFullHealth path in
//                                    PlayerModule.cpp does the denying, so this
//                                    table returns false for every part and the
//                                    ChangeHealth hook is a passthrough.
//   god_mode2     (Buddha Mode)       EVERY body part stops at 1 HP: limbs thin
//                                    out and bleed, but none is ever blacked out.
//   semi_god_mode (semi_god_mode_cb)  only Head(0) and Thorax(1) stop at 1 HP;
//                                    every other part may black out normally.
//                                    That is what makes it "semi" -- you keep
//                                    your vitals and lose your mobility.
//
// Semi-God Mode is the original of the three and the idea is BerkaTO6's: take
// the damage everywhere, including the vitals, but never actually die.
//
// The difference between buddha and semi is exactly the `semi` arm of
// part_is_protected. Everything else -- the hook, the floor, the kill gate, the
// controller tracking -- is shared, which is the reason all three live in one
// namespace rather than three.
namespace survival_clamp {
    enum class mode : uint8_t
    {
        off,
        god,    // god_mode: nothing clamped
        buddha, // god_mode2: every part clamped
        semi,   // semi_god_mode: only the vitals clamped
    };

    // EBodyPart (dump.cs 1525196, build 1.1.5.47510):
    //   Head=0, Chest=1, Stomach=2, LeftArm=3, RightArm=4, LeftLeg=5, RightLeg=6,
    //   Common=7
    // The game labels Chest=1 "Thorax" in every menu, so both spellings below
    // mean the same index; the constants use the dump's names.
    inline constexpr int k_body_part_head = 0;
    inline constexpr int k_body_part_thorax = 1;
    inline constexpr int k_body_part_right_leg = 6;

    // Common(7) is the whole-body aggregate rather than a limb, and _bodyState
    // does carry an entry for it. It is excluded from buddha mode so that a
    // non-limb health change is never clamped against a per-limb floor.
    inline constexpr int k_body_part_last = 6;

    // The floor a protected part is held at. 1 HP rather than 0, because 0 IS the
    // blackout: the game reads current <= 0 as destroyed and flips IsDestroyed,
    // and a part restored out of that state fights the game's own bookkeeping
    // rather than undoing it.
    inline constexpr float k_protected_floor_hp = 1.0f;

    // Sentinel for "this part's health could not be read". Distinct from 0 HP,
    // which is a real, reachable value and means the game already blacked the
    // part out.
    inline constexpr float k_unknown_hp = -1.0f;

    inline constexpr bool part_is_protected(const mode m, const int body_part) {
        switch (m) {
            case mode::buddha:
                return body_part >= k_body_part_head && body_part <= k_body_part_last;
            case mode::semi:
                return body_part == k_body_part_head || body_part == k_body_part_thorax;
            case mode::god:
            case mode::off:
            default:
                return false;
        }
    }

    // The delta to actually forward to ActiveHealthController.ChangeHealth.
    //
    // `current` is the part's health BEFORE the change. The game's delta sign is
    // preserved: negative is damage, positive is healing.
    //
    // Every guard fails OPEN, returning the caller's delta untouched. That is
    // deliberate for a hook in front of the game's own health system: passing a
    // damage event through un-clamped is exactly what the game would have done
    // anyway, whereas clamping on a bad read would freeze a limb at a number
    // nobody asked for. The kill gate in semi_god is the backstop for the case
    // where the clamp cannot help.
    inline constexpr float apply(const mode m, const int body_part, const float current, const float delta) {
        if (!part_is_protected(m, body_part)) return delta;
        if (delta >= 0.0f) return delta;            // healing is never clamped

        // Unknown, or already blacked out. A part the game has destroyed is not
        // restored by writing its health back up: that state lives in IsDestroyed
        // and NetworkSyncDestroyedBodyPart, so healing the number here would
        // leave the part at 1 HP and still broken.
        if (!(current > 0.0f)) return delta;

        // The ONLY overshoot test. There is deliberately no "is it already above
        // the floor" early return: a part at 100 HP taking 500 damage is exactly
        // the case this function exists for, and such a guard would pass every
        // boundary test while never clamping anything at all.
        if (current + delta >= k_protected_floor_hp) return delta;

        return k_protected_floor_hp - current;
    }

    inline constexpr const char* name(const mode m) {
        switch (m) {
            case mode::god: return "god_mode";
            case mode::buddha: return "buddha";
            case mode::semi: return "semi_god";
            case mode::off:
            default: return "off";
        }
    }
} // namespace survival_clamp