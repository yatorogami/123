#pragma once
// ============================================================================
//  always_on_deprecated.h  --  ARCHIVE. NOT COMPILED. NOT INCLUDED ANYWHERE.
//
//  This file preserves code that was moved out of module/always_on.h during a
//  dead-code cleanup pass. Nothing here is referenced by always_on.h, and
//  nothing here should be reintroduced without a fresh reason.
//
//  WHY THIS EXISTS RATHER THAN DELETING
//  ------------------------------------
//  A long time was spent chasing the transit screen-hang: the window would
//  stall between location selection and the destination raid, and the cause
//  was not in the game but in a cluster of interacting async state machines on
//  EFT.TarkovApplication. The investigation left a lot of instrumentation
//  behind -- awaiter dumps, state-transition logs, per-field state-machine
//  scans. Most of that was worth keeping. Some of it is the debris of
//  hypotheses that turned out to be wrong, and the comments inside record why
//  each idea was abandoned.
//
//  Preserving it costs nothing at runtime (this header is never included, so
//  it is never parsed) and it means nobody has to re-derive the dead ends. The
//  value is in the COMMENTS as much as the code: most of these paths were
//  tried, failed, and are known dead ends. Please read the comments before
//  re-attempting any of it.
//
//  ---------------------------------------------------------------------------
//  WHAT IS HERE, AND WHY EACH ITEM IS INACTIVE
//  ---------------------------------------------------------------------------
//  1. o_transit_point_move_next
//     The original-function pointer for the hook below. Never assigned: the
//     hook is never registered.
//
//  2. hk_transit_point_move_next  (~130 lines, the bulk of this file)
//     A MoveNext hook for TransitPoint+<Transit>d__38.MoveNext, i.e. the async
//     state machine that performs the transit after the screen closes. It scans
//     the state-machine struct's fields for a live TransitPoint reference and
//     for a completed awaiter, to work out where the machine was stuck.
//
//     It was NEVER HOOKED. It is not among the 24 registrations in
//     always_on::init(). The state machine it targets is created and consumed
//     while the transit screen is up, which is before the hooks are installed
//     and in a context where the detour could not be kept alive.
//
//     It is also known to crash. Its own comments record that walking the
//     Dictionary field inside the machine segfaulted, and that the Controller /
//     async-op fields inside TransitPoint are the likely blocker. Note that it
//     dereferences the state-machine struct at hardcoded offsets (+0x10 for the
//     state, +0x18..+0x80 for fields) with NO readability guard -- unlike the
//     rest of always_on.h, which routes every read through
//     eft_api::is_readable_address. Re-enabling it as-is would reintroduce an
//     unguarded read of a moving target.
//
//  3. get_bots_controller_sig / o_get_bots_controller
//  4. on_ep_interaction_sig / o_on_ep_interaction
//     Declared while chasing whether the hang was bot-side or extract-point
//     side. Neither was ever hooked or called; neither original was ever
//     resolved.
//
//  ---------------------------------------------------------------------------
//  IF YOU RESURRECT ANY OF THIS
//  ---------------------------------------------------------------------------
//  * Hook it explicitly in always_on::init() and verify the registration count
//    changes -- "defined" is not "installed", which is exactly how all of this
//    became dead in the first place.
//  * Route raw reads through eft_api::is_readable_address / read_guarded.
//  * Do not hardcode state-machine field offsets. always_on.h now probes a
//    delta set ({0, +/-0x8, +/-0x10, +/-0x20}) per call via resolve_sm_base,
//    because the OnGameEnd crash showed the header shifts between builds.
// ============================================================================

namespace always_on {

// --- (1) original pointer, never assigned ----------------------------------
using async_state_machine_move_next_sig = void* (*)(void* state_machine);
inline async_state_machine_move_next_sig o_transit_point_move_next = nullptr;

// --- (2) the hook body, never registered -----------------------------------
    // hk_transit_point_move_next: Hook for TransitPoint+<Transit>d__38.MoveNext.
    // This is the actual async state machine that executes the transit after the screen.
    // State machines are structs containing captured variables as fields:
    //   <>1__state: current state (int)
    //   <>4__this: reference to TransitPoint instance
    //   other fields: local variables, awaited tasks, etc.
    inline void hk_transit_point_move_next(void* state_machine) {
        logger::debug("hk_transit_point_move_next CALLED");

        // Get the actual class of the state machine from the method's understanding
        // We need to be careful - state_machine is a pointer to the struct data
        // The class info should be available through the hook framework

        // Read state field - in IL2CPP async state machines, <>1__state is typically at offset 0x10
        // But we should verify this is safe first
        if (state_machine == nullptr)
        {
            logger::warn("hk_transit_point_move_next: state_machine is null!");
            return;
        }

        int state = *reinterpret_cast<int*>(static_cast<char*>(state_machine) + 0x10);
        logger::debug(std::format("hk_transit_point_move_next: Current state = {}", state));

        // For state 0, we're about to start the transit - dump the state machine fields
        if (state == 0)
        {
            logger::debug("hk_transit_point_move_next: About to execute first iteration of transit state machine");
            logger::debug(std::format("hk_transit_point_move_next: State machine struct @ 0x{:x}",
                reinterpret_cast<uintptr_t>(state_machine)));

            Il2CppObject* transit_point_instance = nullptr;
            Il2CppObject* awaited_task_obj = nullptr;

            // Use IL2CPP reflection to get the actual field layout of this state machine
            // The state_machine pointer points to the struct data, but we need the class info
            // Async state machines generated by C# compiler have predictable field names:
            //   <>1__state (int), <>1__builder, <>4__this (this pointer), etc.

            logger::debug("hk_transit_point_move_next: Scanning state machine fields for captured variables...");

            // Try to get field info using common state machine field patterns
            // Field offsets in IL2CPP structs: first field after header (0x10 for state) starts at 0x18
            // Each reference field is 8 bytes (64-bit), value types vary

            bool found_valid_object = false;
            for (int offset = 0x18; offset < 0x80; offset += 0x8)
            {
                Il2CppObject* potential_obj = *reinterpret_cast<Il2CppObject**>(static_cast<char*>(state_machine) + offset);

                // Validate the pointer before using it
                if (potential_obj == nullptr)
                {
                    continue;
                }

                // Basic sanity check - try to read the klass pointer safely
                Il2CppClass* potential_klass = potential_obj->klass;
                if (potential_klass == nullptr)
                {
                    logger::debug(std::format("hk_transit_point_move_next: Field @ 0x{:x} -> invalid klass pointer", offset));
                    continue;
                }

                const char* type_name_cstr = potential_klass->name;
                if (type_name_cstr == nullptr)
                {
                    logger::debug(std::format("hk_transit_point_move_next: Field @ 0x{:x} -> null type name", offset));
                    continue;
                }

                std::string type_name(type_name_cstr);
                if (type_name.empty() || type_name.length() > 200)
                {
                    logger::debug(std::format("hk_transit_point_move_next: Field @ 0x{:x} -> suspicious type name length", offset));
                    continue;
                }

                logger::debug(std::format("hk_transit_point_move_next: Field @ 0x{:x} -> {} @ 0x{:x}",
                    offset, type_name, reinterpret_cast<uintptr_t>(potential_obj)));
                found_valid_object = true;

                // Look for TransitPoint reference (<>4__this)
                if (type_name.find("TransitPoint") != std::string::npos)
                {
                    transit_point_instance = potential_obj;
                    logger::debug(std::format("hk_transit_point_move_next: >>> Found TransitPoint instance @ 0x{:x}",
                        reinterpret_cast<uintptr_t>(transit_point_instance)));

                    // CRITICAL: Based on crash logs, iterating TransitPoint fields causes crash at Dictionary field
                    // The crash happened when accessing field @ 0x90 (Dictionary`2)
                    // We must NOT iterate fields - just note we found it and continue
                    logger::debug("hk_transit_point_move_next: Skipping TransitPoint field dump (previous crash at Dictionary field)");
                    logger::debug("hk_transit_point_move_next: Controller/async op inside TransitPoint is likely the blocker");
                }

                // Also check if this field itself is a Task being awaited
                if (type_name.find("Task`") != std::string::npos || type_name.find("Awaiter") != std::string::npos || type_name.find("Async") != std::string::npos)
                {
                    awaited_task_obj = potential_obj;
                    logger::debug(std::format("hk_transit_point_move_next: >>> Found awaited operation: {} @ 0x{:x}",
                        type_name, reinterpret_cast<uintptr_t>(awaited_task_obj)));

                    // Try to check completion status
                    FieldInfo* completed_field = il2utils::resolve_field(awaited_task_obj->klass, "m_completed");
                    if (completed_field != nullptr)
                    {
                        int* completed_ptr = reinterpret_cast<int*>(reinterpret_cast<char*>(awaited_task_obj) + completed_field->offset);
                        if (completed_ptr != nullptr)
                        {
                            int completed = *completed_ptr;
                            logger::debug(std::format("hk_transit_point_move_next: >>> Task m_completed = {} (0=pending, 1=done)", completed));
                        }
                    }
                }
            }

            if (!found_valid_object)
            {
                logger::warn("hk_transit_point_move_next: No valid object references found in state machine fields");
            }
            else if (transit_point_instance == nullptr)
            {
                logger::warn("hk_transit_point_move_next: Could not locate TransitPoint instance in state machine fields");
            }
        }

        o_transit_point_move_next(state_machine);

        int new_state = *reinterpret_cast<int*>(static_cast<char*>(state_machine) + 0x10);
        logger::debug(std::format("hk_transit_point_move_next: New state = {}", new_state));

        // If state didn't change, we're likely stuck in a loop or waiting forever
        if (state == new_state)
        {
            logger::warn(std::format("hk_transit_point_move_next: WARNING - State did not change (stuck at {})", state));
        }
    }

// --- (3)/(4) signature pairs, never hooked or resolved ---------------------
using get_bots_controller_sig = Il2CppObject* (*)(Il2CppObject*);
inline get_bots_controller_sig o_get_bots_controller = nullptr;

using on_ep_interaction_sig = void (*)(Il2CppObject*, Il2CppObject*, bool);
inline on_ep_interaction_sig o_on_ep_interaction = nullptr;

} // namespace always_on
