#pragma once
#include <string>
#include <string_view>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <locale>
#include <format>
#include <source_location>
#include "../il2cpp/Il2CppObjectInstance.h"
#include "../il2cpp/il2utils.h"
#include "../il2cpp/exports.h"
#include "../util/logger.h"
#include "../il2cpp/unity.h"
#include "eft_api.h"
#include "../util/globals.h"
#include "../util/tracy_bridge.h"
#include "hotkeys.h"

namespace always_on {
    inline Il2CppImage* assembly_csharp;

    using display_location_sig = bool (*)(Il2CppObject*, Il2CppObject*);
    inline display_location_sig o_display_location = nullptr;

    using try_get_location_sig = bool (*)(Il2CppObject*, Il2CppString*, Il2CppObject**);
    inline try_get_location_sig o_try_get_location = nullptr;

    using try_get_location_by_id_sig = bool (*)(Il2CppObject*, Il2CppString*, Il2CppObject**);
    inline try_get_location_by_id_sig o_try_get_location_by_id = nullptr;

    using transit_sig = Il2CppObject* (*)(Il2CppObject*, Il2CppObject*, int, Il2CppString*, Il2CppObject*,
        Il2CppObject*);
    inline transit_sig o_transit = nullptr;

    using local_raid_started_sig = Il2CppObject* (*)(Il2CppObject*, Il2CppObject*);
    inline local_raid_started_sig o_local_raid_started = nullptr;

    using async_state_machine_move_next_sig = void* (*)(void* state_machine);
    inline async_state_machine_move_next_sig o_on_ready_to_start_matching_async = nullptr;
    inline async_state_machine_move_next_sig o_local_game_create = nullptr;
    inline async_state_machine_move_next_sig o_local_game_matching = nullptr;
    inline async_state_machine_move_next_sig o_start_online_transit_matching = nullptr;
    inline async_state_machine_move_next_sig o_await_game_over_save_status_move_next = nullptr;
    inline async_state_machine_move_next_sig o_show_transit_save_wait_screen_move_next = nullptr;
    inline async_state_machine_move_next_sig o_on_game_end_move_next = nullptr;
    inline async_state_machine_move_next_sig o_comeback_to_main_menu_move_next = nullptr;
    inline async_state_machine_move_next_sig o_prepare_game_job_move_next = nullptr;
    inline async_state_machine_move_next_sig o_run_move_next = nullptr;

    // get_bots_controller_sig / on_ep_interaction_sig and the
    // hk_transit_point_move_next hook body were moved to
    // module/always_on_deprecated.h (archive, not compiled, not included).
    // They were never hooked or called. Read the comments there before
    // re-attempting any of it -- the reasoning behind abandoning them is
    // worth more than the code.

    using bool_from_object_sig = bool (*)(Il2CppObject*);
    inline bool_from_object_sig o_ta_is_local_transit_hop = nullptr;
    inline bool_from_object_sig o_rs_need_to_go_online_in_pve = nullptr;
    inline bool_from_object_sig o_rs_need_to_go_offline_in_pve = nullptr;

    using apply_game_over_save_status_sig = void (*)(Il2CppObject*, Il2CppObject*);
    inline apply_game_over_save_status_sig o_apply_game_over_save_status = nullptr;

    using fail_game_over_save_status_sig = void (*)(Il2CppObject*, Il2CppString*);
    inline fail_game_over_save_status_sig o_fail_game_over_save_status = nullptr;

    // ---- transit save-status diagnostics helpers (used by the hooks below) ----
    inline Il2CppObject* g_last_ta = nullptr;

    // resolve_sm_class: finds TarkovApplication's nested async state-machine class
    // (e.g. "<AwaitGameOverSaveStatusAsync>d__169") by name substring.
    inline const Il2CppClass* resolve_sm_class(const char* method_name) {
        const Il2CppClass* ta_class = il2utils::resolve_class(assembly_csharp, "EFT", "TarkovApplication");
        if (!ta_class) return nullptr;
        if (ta_class->nested_type_count == 0)
            il2cpp::il2cpp_runtime_class_init(const_cast<Il2CppClass*>(ta_class));
        if (ta_class->nestedTypes == nullptr) return nullptr;
        // Exact "<Method>d__" first: a loose substring would match siblings such as
        // <RunCharacterSelectionFlow>d__142 when resolving "Run".
        const std::string exact_name = std::string("<") + method_name + ">d__";
        for (uint16_t i = 0; i < ta_class->nested_type_count; i++)
        {
            Il2CppClass* nested = ta_class->nestedTypes[i];
            if (!nested || !nested->name) continue;
            if (std::string(nested->name).find(exact_name) != std::string::npos)
                return nested;
        }
        for (uint16_t i = 0; i < ta_class->nested_type_count; i++)
        {
            Il2CppClass* nested = ta_class->nestedTypes[i];
            if (!nested || !nested->name) continue;
            std::string nested_name(nested->name);
            if (nested_name.find(method_name) != std::string::npos && nested_name.find("d__") != std::string::npos)
                return nested;
        }
        return nullptr;
    }

    // Guarded field read from a possibly-unmapped address (offset may be negative).
    //
    // The zone is on the TEMPLATE, not on a call site, so all 35 of its call
    // sites share one bucket. That is the point: the 2026-10-01 profile measured
    // eft_api::is_readable_address at 78.0 s over 680,325 calls -- 14.35% of the
    // session, and pure self time, so it was genuinely 114 us per VirtualQuery
    // rather than a preemption artifact. What the profile could not say is which
    // readers drove those 680,325 calls. This splits them into guarded field
    // reads versus the string path versus everything else, at the cost of one
    // zone, without a zone per call site.
    template <typename T>
    inline bool read_guarded(const void* base, const intptr_t offset, T& out) {
        TA_ZONE_N("always_on::read_guarded");
        if (base == nullptr) return false;
        const auto* address = static_cast<const uint8_t*>(base) + offset;
        if (!eft_api::is_readable_address(address, sizeof(T))) return false;
        out = *reinterpret_cast<const T*>(address);
        return true;
    }

    inline std::string safe_string(const Il2CppString* string) {
        if (string == nullptr || !eft_api::is_readable_address(string, sizeof(Il2CppString))) return {};
        const int length = string->length;
        if (length <= 0 || length > 512) return {};
        if (!eft_api::is_readable_address(string->chars, static_cast<size_t>(length) * sizeof(wchar_t)))
            return {};
        return il2utils::conv_string(string);
    }

    // Class name of a live object, without dereferencing anything unverified.
    inline std::string safe_class_name(const Il2CppObject* object) {
        if (object == nullptr || !eft_api::is_readable_address(object, sizeof(Il2CppObject))) return {};
        const Il2CppClass* klass = object->klass;
        if (klass == nullptr || !eft_api::is_readable_address(klass, sizeof(Il2CppClass))) return {};
        if (klass->name == nullptr || !eft_api::is_readable_address(klass->name, 8)) return {};
        std::string name = klass->namespaze != nullptr && eft_api::is_readable_address(klass->namespaze, 8)
            ? std::string(klass->namespaze) + "."
            : std::string();
        name += klass->name;
        return name;
    }

    inline const Il2CppClass* ta_klass() {
        static const Il2CppClass* cached = nullptr;
        if (cached == nullptr)
            cached = il2utils::resolve_class(assembly_csharp, "EFT", "TarkovApplication");
        return cached;
    }

    // ta_is_valid: TarkovApplication-instance check that never dereferences an
    // untrusted klass pointer (the old `ta->klass` guard AV'd on a bogus ta).
    inline bool ta_is_valid(Il2CppObject* ta) {
        const Il2CppClass* klass = ta_klass();
        if (klass == nullptr) return false;
        if (ta == nullptr || !eft_api::is_readable_address(ta, sizeof(Il2CppObject))) return false;
        return ta->klass == klass;
    }

    // MoveNext receives a pointer to the raw state-machine struct (verified in the
    // d__239 disassembly: <>1__state @0x0, <>4__this @0x20), so the struct has no
    // object header and Il2CppObjectInstance's klass auto-detect cannot be used here.
    // The OnGameEnd crash showed the field reads landing one object header (0x10) off,
    // so the base is detected per call instead of trusted: probe a small window of
    // candidate bases and keep the one whose <>4__this reads a live `owner_klass`
    // instance. Field offsets are then used as returned by resolve_field.
    struct sm_view
    {
        void* base = nullptr;          // raw struct base whose field offsets line up
        Il2CppObject* owner = nullptr; // validated <>4__this
        bool ok() const;
    };

    inline void* resolve_sm_base(const Il2CppClass* sm_klass, void* sm, const Il2CppClass* owner_klass) {
        if (sm_klass == nullptr || sm == nullptr || owner_klass == nullptr) return nullptr;
        FieldInfo* this_field = il2utils::resolve_field(sm_klass, "<>4__this");
        if (this_field == nullptr) return nullptr;

        static constexpr intptr_t kDeltas[] = {0, -0x10, 0x10, -0x8, 0x8, -0x20, 0x20};
        for (const intptr_t delta : kDeltas)
        {
            Il2CppObject* candidate_owner = nullptr;
            if (!read_guarded(sm, delta + this_field->offset, candidate_owner)) continue;
            if (candidate_owner == nullptr || !eft_api::is_readable_address(candidate_owner, sizeof(Il2CppObject))) continue;
            if (candidate_owner->klass == owner_klass) return static_cast<uint8_t*>(sm) + delta;
        }
        return nullptr;
    }

    inline sm_view make_sm_view(const Il2CppClass* sm_klass, void* sm, const Il2CppClass* owner_klass) {
    // Zoned separately from the hook entry because THIS is the per-iteration work:
    // resolve_sm_base() probes a window of candidate bases looking for the one whose
    // <>4__this reads a live owner, then two guarded field reads follow. It is the
    // AV-sensitive part of the transit path -- the one the OnGameEnd crash investigation
    // was about -- and it was completely invisible. A zone on the hook entry alone would
    // show the boundary cost and not this.
        TA_ZONE_N("always_on::make_sm_view");        sm_view view;
        view.base = resolve_sm_base(sm_klass, sm, owner_klass);
        if (view.base == nullptr) return view;
        FieldInfo* this_field = il2utils::resolve_field(sm_klass, "<>4__this");
        if (this_field != nullptr)
            read_guarded(view.base, this_field->offset, view.owner);
        return view;
    }

    // One-shot layout dump: reports the chosen base/offsets and the raw qwords around
    // the received pointer, so a future log alone can confirm which shift the runtime used.
    inline void log_sm_shape(const char* tag, const Il2CppClass* sm_klass, const void* sm, const sm_view& view) {
        FieldInfo* state_field = sm_klass ? il2utils::resolve_field(sm_klass, "<>1__state") : nullptr;
        FieldInfo* this_field = sm_klass ? il2utils::resolve_field(sm_klass, "<>4__this") : nullptr;
        const intptr_t delta = view.ok()
            ? static_cast<intptr_t>(reinterpret_cast<uintptr_t>(view.base) - reinterpret_cast<uintptr_t>(sm))
            : 0;
        logger::debug(std::format(
            "[transitdbg] {} shape: sm=0x{:x} base=0x{:x} delta={:+} off_state=0x{:x} off_this=0x{:x} owner=0x{:x}",
            tag, reinterpret_cast<uintptr_t>(sm), reinterpret_cast<uintptr_t>(view.base), delta,
            state_field ? state_field->offset : -1, this_field ? this_field->offset : -1,
            reinterpret_cast<uintptr_t>(view.owner)));
        for (intptr_t offset = -0x20; offset <= 0x78; offset += 8)
        {
            uint64_t qword = 0;
            if (read_guarded(sm, offset, qword))
                logger::debug(std::format("[transitdbg] {}{:+} = 0x{:016x}", tag, offset, qword));
        }
    }

    // Field accessors take the RESOLVED base from make_sm_view, never the raw sm.
    inline int sm_state(const Il2CppClass* sm_klass, const void* sm_base) {
        if (sm_klass == nullptr || sm_base == nullptr) return -9999;
        FieldInfo* state_field = il2utils::resolve_field(sm_klass, "<>1__state");
        if (state_field == nullptr) return -9999;
        int state = -9999;
        read_guarded(sm_base, state_field->offset, state);
        return state;
    }

    // Shared prologue for the six MoveNext hooks. All six opened with the same
    // five steps -- resolve the state machine class once, dump its layout once,
    // warn if the base did not resolve, read the enter state, publish the owner
    // to g_last_ta -- and a fix to any of them (a new guard, a different warn
    // wording) had to be made six times, or silently applied to five.
    //
    // The per-hook `static sm_klass` / `logged_shape` state stays with the
    // CALLER: those statics are per-hook by design (each machine logs its own
    // shape exactly once), so they are passed in rather than made static here.
    //
    // WHY THESE HOOKS ARE ZONED, stated once. Each of the six MoveNext hooks is a
    // per-ITERATION boundary, not a per-frame one: the TarkovApplication state
    // machine yields and resumes many times inside a single frame, and during a
    // transit it can spin. Nothing in the profile could say how often any of these
    // six fire or what they cost, which is why the 1,688-lines-per-minute
    // transitdbg flood had to be diagnosed by reading the log by hand.
    //
    // And why they are CHEAP in normal play, bounded in a transit: every per-call
    // read goes through always_on::read_guarded, which sm_state() calls once per
    // iteration, and that measured 21 calls/min in the 20-minute capture -- so the
    // hooks themselves were near-idle outside a transit.
    struct sm_hook_ctx {
        const Il2CppClass* sm_klass = nullptr;
        bool logged_shape = false;
    };

    // Per-hook transition-dedupe state. Kept separate from sm_hook_ctx because
    // three of the six hooks track transitions (Run, StartOnlineTransitMatching,
    // PrepareGameJob) and three do not, so making it unconditional would give
    // every hook three unused statics. -9999 is the same sentinel sm_state()
    // returns when it cannot read, so a first call always logs.
    struct sm_transition_state {
        int last_enter = -9999;
        int last_exit = -9999;
        uint32_t repeat = 0;
    };

    inline sm_view begin_move_next(const char* tag, sm_hook_ctx& ctx, void* sm, int& state) {
        if (ctx.sm_klass == nullptr) ctx.sm_klass = resolve_sm_class(tag);
        const sm_view view = make_sm_view(ctx.sm_klass, sm, ta_klass());
        if (!ctx.logged_shape)
        {
            ctx.logged_shape = true;
            log_sm_shape(tag, ctx.sm_klass, sm, view);
        }
        if (!view.ok())
            logger::warn(std::format("[transitdbg] {}: state machine base not resolved (sm=0x{:x})",
                tag, reinterpret_cast<uintptr_t>(sm)));

        state = sm_state(ctx.sm_klass, view.base);
        if (view.owner != nullptr) g_last_ta = view.owner;
        return view;
    }

    // Shared epilogue: identical consecutive transitions repeat while the machine
    // spins, so the debug line is emitted on change, for the first three, and every
    // 200th. `state` is the value read before o_*_move_next; `exit_state` after.
    //
    // Returns whether the line was emitted, so a caller that wants to do MORE on
    // the same condition (hk_run_move_next dumps every awaiter field with it)
    // can gate that off the same decision rather than re-deriving it from
    // counters that have already been overwritten.
    inline bool log_move_next_transition(const char* tag, int state, int exit_state,
        int& last_enter, int& last_exit, uint32_t& repeat) {
        const bool same_as_last = state == last_enter && exit_state == last_exit;
        repeat = same_as_last ? repeat + 1 : 1;
        last_enter = state;
        last_exit = exit_state;
        const bool emit = !same_as_last || repeat <= 3 || repeat % 200 == 0;
        if (emit) logger::debug(std::format(
            "[transitdbg] {}.MoveNext enter state={} exit state={} (same transition x{})",
            tag, state, exit_state, repeat));
        return emit;
    }

    // The suspended awaiter fields use the compiled layout: <>u__1 TaskAwaiter, <>u__2
    // YieldAwaiter, <>u__3 TaskAwaiter<bool>. TaskAwaiter<T> is a single Task reference,
    // so the field payload read as a pointer is the awaited Task. m_stateFlags shows
    // whether that task ever completed: a completed task with no resumption points at the
    // continuation scheduler, a pending one at the awaited operation itself.
    inline void dump_pending_awaiter(const char* tag, const Il2CppClass* sm_klass, const void* sm_base,
        const std::initializer_list<const char*>& field_names = {"<>u__1", "<>u__3"}) {
        if (sm_klass == nullptr || sm_base == nullptr) return;
        for (const char* name : field_names)
        {
            FieldInfo* field = il2utils::resolve_field(sm_klass, name);
            if (field == nullptr) continue;
            Il2CppObject* task = nullptr;
            if (!read_guarded(sm_base, field->offset, task) || task == nullptr) continue;
            if (!eft_api::is_readable_address(task, sizeof(Il2CppObject))) continue;
            int state_flags = -1;
            FieldInfo* flags_field = il2utils::resolve_field(task->klass, "m_stateFlags");
            if (flags_field != nullptr) read_guarded(task, flags_field->offset, state_flags);
            logger::debug(std::format("[transitdbg] {} pending {}: task=0x{:x} klass={} stateFlags=0x{:x}",
                tag, name, reinterpret_cast<uintptr_t>(task), safe_class_name(task),
                static_cast<uint32_t>(state_flags)));
        }
    }

    // Generic variant for machines whose awaiter fields are unknown at compile time
    // (e.g. Run d__201, whose ISIL shows raw-offset stores): scans every <>u__ field and
    // prints the ones whose payload looks like a Task (has m_stateFlags). YieldAwaiter
    // fields are empty structs, so their garbage payload fails the m_stateFlags probe and
    // is skipped instead of being printed as a bogus task.
    inline void dump_all_awaiter_fields(const char* tag, const Il2CppClass* sm_klass, const void* sm_base) {
        if (sm_klass == nullptr || sm_base == nullptr || sm_klass->fields == nullptr) return;
        for (uint16_t i = 0; i < sm_klass->field_count; i++)
        {
            const FieldInfo& field = sm_klass->fields[i];
            if (field.name == nullptr || !std::string_view(field.name).starts_with("<>u__")) continue;
            Il2CppObject* task = nullptr;
            if (!read_guarded(sm_base, field.offset, task) || task == nullptr) continue;
            if (!eft_api::is_readable_address(task, sizeof(Il2CppObject))) continue;
            FieldInfo* flags_field = task->klass != nullptr
                ? il2utils::resolve_field(task->klass, "m_stateFlags")
                : nullptr;
            if (flags_field == nullptr) continue;
            int state_flags = -1;
            read_guarded(task, flags_field->offset, state_flags);
            logger::debug(std::format("[transitdbg] {} pending {}: task=0x{:x} klass={} stateFlags=0x{:x}",
                tag, field.name, reinterpret_cast<uintptr_t>(task), safe_class_name(task),
                static_cast<uint32_t>(state_flags)));
        }
    }

    inline bool ta_save_status_received(Il2CppObject* ta) {
        if (!ta_is_valid(ta)) return false;
        FieldInfo* received_field =
            il2utils::resolve_field(ta->klass, "<GameOverSaveStatusReceived>k__BackingField");
        if (received_field == nullptr) return false;
        bool received = false;
        read_guarded(ta, received_field->offset, received);
        return received;
    }

    // dump_ta_state: prints the transit-critical TarkovApplication fields.
    // Offsets from dump.cs TarkovApplication: <CurrentTotalRaidNum>k__BackingField 0x1FC,
    // <TransitionStatus>k__BackingField 0x210 (struct: InTransition@0, Location@0x8,
    // Training@0x10, Side@0x14, Mode@0x18, Time@0x1C), _raidSettings 0xD8
    // (RaidSettings.isInTransition@0x3C), <GameOverSaveStatusReceived>k__BackingField 0x240.
    inline void dump_ta_state(Il2CppObject* ta, const char* tag) {
        // RATE LIMIT, per tag, with the suppressed count reported rather than dropped.
        //
        // WHY. The only caller with a state-change gate is Run:resume, and the gate does not
        // hold: TarkovApplication's state machine oscillates between two states, so
        // `state != last_enter` is true on every iteration and the dump fires every frame.
        // Measured 2026-10-01: 1,688 log lines in one minute, every one of them
        // [transitdbg], which is the failure this repo has already had once. A log that is
        // 99% one repeated diagnostic cannot be used to hear anything else -- and the people
        // who most need it (a stuck transit, or the chams investigation) are the ones who
        // cannot read it.
        //
        // The suppressed count is reported on the next dump that IS emitted. A diagnostic that
        // silently under-reports is worse than none, because "the log was quiet" then reads as
        // "nothing was happening" when in fact it was happening 60 times a second.
        //
        // 1 s per tag: an oscillation still shows once a second, with a count of how many
        // times it actually flipped, which is MORE diagnostic than the raw flood.
        {
            struct entry { ULONGLONG last = 0; unsigned long long suppressed = 0; };
            static entry s_tags[8]{};
            // tag is a string literal at every call site, so a small hash is enough and it
            // avoids a std::string and a map on a per-frame path.
            const size_t slot = (reinterpret_cast<uintptr_t>(tag) >> 4) & 7u;
            entry& e = s_tags[slot];
            const ULONGLONG now_ms = GetTickCount64();
            constexpr ULONGLONG kDumpMinIntervalMs = 1000;
            if (e.last != 0 && now_ms - e.last < kDumpMinIntervalMs)
            {
                ++e.suppressed;
                return;
            }
            if (e.suppressed != 0 && logger::debug_enabled())
                logger::debug(std::format(
                    "[transitdbg] {}: {} dump(s) suppressed in the last {}ms",
                    tag, e.suppressed, now_ms - e.last));
            e.suppressed = 0;
            e.last = now_ms;
        }

        if (!ta_is_valid(ta))
        {
            logger::debug(std::format("[transitdbg] {}: TarkovApplication not validated (ta=0x{:x})",
                tag, reinterpret_cast<uintptr_t>(ta)));
            return;
        }

        FieldInfo* ts_field = il2utils::resolve_field(ta->klass, "<TransitionStatus>k__BackingField");
        FieldInfo* raid_num_field = il2utils::resolve_field(ta->klass, "<CurrentTotalRaidNum>k__BackingField");
        FieldInfo* raid_settings_field = il2utils::resolve_field(ta->klass, "_raidSettings");

        int raid_num = -1;
        if (raid_num_field != nullptr) read_guarded(ta, raid_num_field->offset, raid_num);

        if (ts_field != nullptr)
        {
            const intptr_t ts_offset = ts_field->offset;
            bool in_transition = false;
            Il2CppString* location = nullptr;
            bool training = false;
            int side = 0;
            int mode = 0;
            int time = 0;
            read_guarded(ta, ts_offset, in_transition);
            read_guarded(ta, ts_offset + 0x8, location);
            read_guarded(ta, ts_offset + 0x10, training);
            read_guarded(ta, ts_offset + 0x14, side);
            read_guarded(ta, ts_offset + 0x18, mode);
            read_guarded(ta, ts_offset + 0x1C, time);
            logger::debug(std::format(
                "[transitdbg] {}: InTransition={} location='{}' training={} side={} mode={} time={} raidNum={} saveStatusReceived={}",
                tag, in_transition, safe_string(location), training, side, mode, time, raid_num,
                ta_save_status_received(ta)));
        }

        if (raid_settings_field != nullptr)
        {
            Il2CppObject* raid_settings = nullptr;
            read_guarded(ta, raid_settings_field->offset, raid_settings);
            if (raid_settings != nullptr && eft_api::is_readable_address(raid_settings, sizeof(Il2CppObject)) && raid_settings->klass != nullptr)
            {
                FieldInfo* in_transit_field = il2utils::resolve_field(raid_settings->klass, "isInTransition");
                Il2CppObjectInstance raid_settings_instance(raid_settings);
                int raid_mode = 0;
                auto m_get_raid_mode = raid_settings_instance.get_method<int (*)(Il2CppObject*)>("get_RaidMode", 0);
                if (m_get_raid_mode != nullptr) raid_mode = m_get_raid_mode(raid_settings);
                bool is_in_transition = false;
                if (in_transit_field != nullptr)
                    read_guarded(raid_settings, in_transit_field->offset, is_in_transition);
                logger::debug(std::format("[transitdbg] {}: RaidSettings.isInTransition={} RaidMode={}",
                    tag, is_in_transition, raid_mode));
            }
        }
    }

    inline bool keep_original_transition_hash = true;

    inline void assign_keep_transition_hash(bool value) {
        keep_original_transition_hash = value;
        return;
    }

    inline bool keep_original_server_id = true;

    inline void assign_keep_server_id(bool value) {
        keep_original_server_id = value;
        return;
    }

    // 2026-10-04: kill switch for the whole post-RPC settings write.
    //
    // Named `write_` rather than `apply_` on purpose. `apply_local_raid_settings_after_rpc`
    // is already a FUNCTION in this namespace; a flag of the same name would shadow it
    // for every unqualified call after this point, which is exactly the kind of
    // declaration that compiles and then silently calls the wrong thing.
    //
    // WHY IT EXISTS, from the 15:24-15:30 session log (both raids observed):
    //
    //   15:24:42.830  Loading in at: bigmap
    //   15:24:42.830  [transitdbg] LoadingIn: selectedLocation=null get_Local=true
    //   15:24:45.114  apply_local_raid_settings_after_rpc call #3: APPLIED
    //
    //   15:30:09.788  Loading in at: factory4_day
    //   15:30:09.788  [transitdbg] LoadingIn: selectedLocation=null get_Local=true
    //   15:30:10.709  apply_local_raid_settings_after_rpc call #6: APPLIED
    //
    // So the function's own comment -- "re-assert the mode and configure the selected
    // location immediately", before a load -- is not what happens on this build. The
    // `selectedLocation != null` gate is "after the RPC result has been unpacked",
    // which lands 0.9-2.3 s AFTER hk_local_raid_started and after "Loading in at".
    // configure_pve_location() is then mutating a location object the game has
    // already committed to, and the reported symptom is a load that stalls.
    //
    // This is a BISECT, not a fix. It answers one question -- is the post-RPC write
    // implicated -- and the answer decides whether the fix belongs here at all.
    inline bool write_local_raid_settings_after_rpc = true;

    inline void assign_write_local_raid_settings(bool value) {
        write_local_raid_settings_after_rpc = value;
        return;
    }

    inline bool force_offline_raid_states = false;

    inline void print_instance_info(Il2CppObject* instance, std::source_location loc) {
        auto instance_name = instance && instance->klass && instance->klass->name
            ? instance->klass->name
            : "Not available";
        logger::debug(std::format("{} entered. instance is {} and is at 0x{:x}", std::string(loc.function_name()), instance_name, reinterpret_cast<uintptr_t>(instance)));
    }

    // dump_inheritance_chain: Debug helper that walks the full inheritance chain of an
    // Il2CppObject, from the object's own class up through each parent class to nullptr.
    // Il2CppObject has no parent pointer of its own; the parent relationship lives in the
    // class hierarchy, so we walk instance->klass->parent. Each level prints the class
    // name and the pointer address, and reports which class is the parent of which.
    inline void dump_inheritance_chain(Il2CppObject* instance, std::source_location loc = std::source_location::current()) {
        if (!instance)
        {
            logger::debug(std::format("dump_inheritance_chain (from {}: {}): instance is nullptr", std::string(loc.function_name()), reinterpret_cast<uintptr_t>(instance)));
            return;
        }

        logger::debug(std::format("dump_inheritance_chain (from {}: instance @ 0x{:x})", std::string(loc.function_name()), reinterpret_cast<uintptr_t>(instance)));

        // Walk the chain from the object's own class upward to nullptr.
        Il2CppClass* klass = instance->klass;
        int depth = 0;
        while (klass != nullptr)
        {
            auto name = klass->name ? klass->name : "<unnamed>";
            logger::debug(std::format("  [{}] {} @ 0x{:x}", depth, name, reinterpret_cast<uintptr_t>(klass)));

            // If this class has a parent, that parent is the parent OF this class.
            if (klass->parent)
            {
                logger::debug(std::format("    parent of {} is {} @ 0x{:x}", name, klass->parent->name ? klass->parent->name : "<unnamed>", reinterpret_cast<uintptr_t>(klass->parent)));
            }
            else
            {
                logger::debug(std::format("    parent of {} is nullptr (base of hierarchy)", name));
            }

            ++depth;
            klass = klass->parent;
        }
    }

    // configure_pve_location: Sets location flags to force PVE offline mode.
    // These flags must be set on both the menu location and the runtime
    // transit destination. Transit destinations do not pass through the
    // matchmaker menu's DisplayLocation method.
    inline void configure_pve_location(Il2CppObject* location) {
        // The null check was the ONLY guard until 2026-10-05, and that is sufficient for
        // every case actually observed -- the object is always live by the time we are
        // called. So this is a guard, not a fix. Raised by another session
        // (tools/handoff_hideout_premises.md:62), who also recorded that it did not cause
        // the crash they were chasing and retracted that attribution themselves.
        //
        // WHAT IS ACTUALLY MISSING, precisely, because "no klass check" undersells it:
        // Il2CppObjectInstance::set_field checks instance_, clazz_ and field for null, so
        // those are covered. What nothing checks is that `instance_ + field->offset` is
        // MAPPED. A stale-but-mapped object therefore passes every existing check and is
        // still written to, and an unmapped one faults inside set_field with no guard at
        // this level to stop it.
        //
        // HERE, not inside set_field. That is the generic accessor on the write path for
        // the whole codebase, and the readable probe is memoised for a measured reason:
        // eft_api.h:4297 records it at 64.3% of all probes and 64.87 s of wall clock.
        // This function runs ~4x per transit, so the probe is free here and would be a
        // measured-regression risk in the accessor. Note the file's local convention is
        // the UNCACHED variant (10+ sites above), which this follows deliberately rather
        // than the stricter reading of that note.
        if (location == nullptr) return;
        if (!eft_api::is_readable_address(location, sizeof(Il2CppObject))) return;

        Il2CppObjectInstance location_instance(location); // LocationSettings.cs
        //logger::info(std::format("configure_pve_location: Setting up location: ID: {}, Name: {}",
        //    il2utils::conv_string(location_instance.get_field<Il2CppString*>("Id")),
        //    il2utils::conv_string(location_instance.get_field<Il2CppString*>("Name"))));
        // These flags must be set on both the menu location and the runtime
        // transit destination. Transit destinations do not pass through the
        // matchmaker menu's DisplayLocation method.
        location_instance.set_field("HiddenWhenLockedByQuest", false);
        location_instance.set_field("ForceOnlineRaidInPVE", false);
        location_instance.set_field("ForceOfflineRaidInPVE", true);
        location_instance.set_field("SavageForceOnlineRaidInPVE", false);
        location_instance.set_field("SavageForceOfflineRaidInPVE", true);
        if (il2utils::conv_string(location_instance.get_field<Il2CppString*>("Name")).contains("Icebreaker")) return; // Show IB, no unlock
        location_instance.set_field("Locked", false);
        location_instance.set_field("LockedByQuest", false);
        return;
    }

    // setup_target_location: Extracts and configures target location from transit data.
    // Called when resolving a transit destination, including for locations like Icebreaker
    // that bypass the normal matchmaker flow.
    inline void setup_target_location(Il2CppObject* controller, Il2CppObject* transit_point) {
        FieldInfo* settings_field = il2utils::resolve_field(controller->klass, "_localRaidSettings");
        if (settings_field)
        {
            auto* settings = *reinterpret_cast<Il2CppObject**>(reinterpret_cast<uintptr_t>(controller) + settings_field->offset);
            if (settings != nullptr && settings->klass != nullptr)
            {
                Il2CppObjectInstance raid_settings(settings);
                {
                    FieldInfo* parameters_field = il2utils::resolve_field(transit_point->klass, "parameters");
                    if (!parameters_field || parameters_field->offset <= 0) return;
                    auto* parameters = *reinterpret_cast<Il2CppObject**>(
                        reinterpret_cast<uintptr_t>(transit_point) + parameters_field->offset);
                    if (parameters == nullptr || parameters->klass == nullptr) return;
                    FieldInfo* target_field = il2utils::resolve_field(parameters->klass, "target");
                    auto* target = target_field ? *reinterpret_cast<Il2CppString**>(reinterpret_cast<uintptr_t>(parameters) + target_field->offset)
                                                : nullptr;
                    if (target != nullptr)
                    {
                        auto* selected_location = raid_settings.get_field<Il2CppObject**>("selectedLocation");

                        if (o_try_get_location && o_try_get_location(controller, target, selected_location)
                            && selected_location != nullptr)
                        {
                            configure_pve_location(*selected_location);
                        }
                    }
                }
            }
        }
    }

    // ELocalMode, EFT. Named because every site that used to carry a bare 1 here
    // was writing PVE_OFFLINE over whatever the game had chosen -- including
    // TRAINING, which is 0. From GameDump/115147510/dump.cs:257034.
    //
    //   TRAINING = 0, PVE_OFFLINE = 1, NARRATE = 2, TUTORIAL = 3
    //
    // Named because every site that used to carry a bare 1 here was writing
    // PVE_OFFLINE over whatever the game had chosen. The value actually clobbered
    // in the report that prompted this was 3 (TUTORIAL) -- loading a tutorial came
    // out as an offline local raid. From GameDump/115147510/dump.cs:257034.
    //
    // Both writers are now inert: dump_local_raid_settings() reads instead of
    // writing, and setup_local_player_object() is commented out. So this enum and
    // local_mode_name() exist to make the value LEGIBLE in the log, which is the
    // only reason anything could tell a tutorial from an offline raid before --
    // the dump used to overwrite the field immediately before printing it.
    //
    // 0 being both TRAINING and an uninitialised int is worth keeping in mind if
    // anyone ever writes this field again: a "default to 0" would read as TRAINING.
    enum class local_mode : int {
        training = 0,
        pve_offline = 1,
        narrate = 2,
        tutorial = 3,
    };

    inline const char* local_mode_name(int m) {
        switch (static_cast<local_mode>(m)) {
            case local_mode::training:   return "TRAINING";
            case local_mode::pve_offline: return "PVE_OFFLINE";
            case local_mode::narrate:    return "NARRATE";
            case local_mode::tutorial:   return "TUTORIAL";
            default:                     return "<unknown>";
        }
    }

    // The mode the GAME chose, read out of LocalTransitController._localRaidSettings.
    //
    // Returns false rather than a default when the settings or the field are not
    // readable, so the caller can decline to write instead of guessing. Guessing
    // is what produced this bug.
    inline bool try_read_local_mode(Il2CppObject* controller, int& out_mode) {
        out_mode = -1;
        if (controller == nullptr || controller->klass == nullptr) return false;
        FieldInfo* settings_field = il2utils::resolve_field(controller->klass, "_localRaidSettings");
        if (!settings_field || settings_field->offset <= 0) return false;
        auto* settings = *reinterpret_cast<Il2CppObject**>(
            reinterpret_cast<uintptr_t>(controller) + settings_field->offset);
        if (settings == nullptr || settings->klass == nullptr) return false;
        const int mode = Il2CppObjectInstance(settings).get_field<int>("mode");
        if (mode < 0) return false;
        out_mode = mode;
        return true;
    }

    // setup_local_player_object: the ELocalMode replacement, COMMENTED OUT.
    //
    // Original body, which is now inert:
    //
    //     Il2CppObjectInstance local_player(player);
    //     local_player.set_field<int>("_playerInMode", 1); // ELocalMode.PVE_OFFLINE
    //
    // WHY IT IS OFF, 2026-10-07.
    //
    // 1. IT WAS WRONG. 1 is PVE_OFFLINE and the mode it overwrote was 3
    //    (TUTORIAL). Loading a tutorial came out as an offline local raid.
    // 2. IT WAS NEVER NEEDED. LocalPlayer.Create(...) takes an `ELocalMode
    //    localMode` parameter and assigns the field itself --
    //    `Move v2406._playerInMode, this.localMode`
    //    (IsilDump/.../LocalPlayer_NestedType__Create_d__0.txt:1666). The game
    //    owns this value and sets it from a parameter we do not control.
    // 3. AND IT DID NOT EVEN DO THE ONE THING IT LOOKED LIKE IT DID. Whether the
    //    online or offline path is taken is decided by ForceOnlineRaidInPVE /
    //    ForceOfflineRaidInPVE on LocationSettings -- configure_pve_location()
    //    above -- and by ERaidMode, not by ELocalMode. So this write bought
    //    nothing on the path it appeared to be steering, and cost correctness on
    //    the one field the game actually reads.
    // 4. IT IS NOT COSMETIC. LocalPlayer.IsNonTrainingPlayer() is, in raw
    //    disassembly, `cmp dword ptr [rcx+0CB0h],0 ; seta al` -- i.e.
    //    `_playerInMode > 0`. Writing 1 makes the game take its non-training
    //    branch for a player the player was not created as.
    //
    // Kept as a comment rather than deleted so the value that was there, and why
    // it went, are both in the file. Deleting the function outright is the only
    // further change this would need -- nothing calls it that needs it to do
    // anything.
    inline void setup_local_player_object(Il2CppObject* player) {
        // Il2CppObjectInstance local_player(player);
        // local_player.set_field<int>("_playerInMode", 1); // ELocalMode.PVE_OFFLINE
        // (void)player;
    }

    // dump_transit_settings: Dumps the transit settings data (TransitSettings struct).
    // TransitSettings contains the server ID chain for transit operations.
    inline void dump_transit_settings(Il2CppObject* settings) {
        Il2CppObjectInstance raid_settings(settings);
        Il2CppObject* transition = raid_settings.get_field<Il2CppObject*>("transition");
        if (transition == nullptr) return;
        auto visited_locations = eft_api::try_get_array_field(transition, "visitedLocations");
        if (visited_locations == nullptr)
            return;
        else
        {
            for (int i = 0; i < visited_locations->max_length; i++)
            {
                Il2CppObject* location = reinterpret_cast<Il2CppObject**>(&visited_locations->data)[i];
                logger::debug(std::format("Visited: {}", il2utils::conv_string(reinterpret_cast<Il2CppString*>(location))));
            }
        }
    }

    // dump_local_raid_settings: Debug helper to inspect raid settings via ToString().
    // Called when detailed diagnostics are needed (e.g., during transit setup).
    //
    // THIS USED TO WRITE. It opened with
    //
    //     local_raid_settings.set_field("mode", 1); // ELocalMode.PVE_OFFLINE
    //
    // in a function whose entire job is to print the state, immediately before
    // printing it. Two consequences, and the second is why it was not merely
    // untidy:
    //
    //   * a TUTORIAL raid (mode 3) was rewritten to PVE_OFFLINE on every transit,
    //     because LocalRaidSettings.mode is ELocalMode and 1 is PVE_OFFLINE;
    //   * the dump could never show the real mode. It read "mode-PVE_OFFLINE" for
    //     every raid in every session, so the log line that would have revealed
    //     the overwrite was itself produced by the overwrite, and a tutorial load
    //     was indistinguishable from an offline one.
    //
    // A diagnostic that reports from a field it has just written is the same
    // defect as the `item-chams` "shader=ok" line, recorded in this repo already.
    //
    // The mode is now read and logged, not written, so ToString() shows the game's
    // own value and the line below is a second, independent copy of it.
    inline void dump_local_raid_settings(Il2CppObject* settings) {
        if (settings == nullptr || settings->klass == nullptr) return;
        Il2CppObjectInstance local_raid_settings(settings);
        const int mode = local_raid_settings.get_field<int>("mode");
        logger::debug(std::format("local_raid_settings: mode={} ({}) -- read, not written",
            mode, local_mode_name(mode)));
        Il2CppString* local_raid_settings_dump = nullptr;
        const MethodInfo* dump_local_raid_settings_m =
            il2utils::resolve_method(settings->klass, "ToString", 0);
        if (dump_local_raid_settings_m && dump_local_raid_settings_m->methodPointer)
        {
            local_raid_settings_dump = reinterpret_cast<Il2CppString* (*)(Il2CppObject*)>(
                dump_local_raid_settings_m->methodPointer)(settings);
        }
        if (local_raid_settings_dump != nullptr)
        {
            logger::debug("local_raid_settings_dump: " + il2utils::conv_string(local_raid_settings_dump));
        }
        dump_transit_settings(settings);
    }

    // Force ERaidMode Local, tolerating an unresolved getter or setter. Written once
    // for the two call sites that both need it (modify_raid_settings and
    // hk_on_ready_to_start_matching_async); the copies had already drifted apart
    // in how they obtained the Il2CppObjectInstance, which is exactly the bug a
    // duplicated block is for.
    inline void force_local_raid_mode(Il2CppObject* settings) {
        if (settings == nullptr) return;
        Il2CppObjectInstance raid_settings(settings);   // non-const: get_method() mutates it
        int raid_mode = 0;
        auto m_get_raid_mode = raid_settings.get_method<int (*)(Il2CppObject*)>("get_RaidMode", 0);
        if (m_get_raid_mode != nullptr)
        {
            raid_mode = m_get_raid_mode(settings);
        }
        if (raid_mode != 1) // not ERaidMode Local
        {
            auto m_set_raid_mode = raid_settings.get_method<void (*)(Il2CppObject*, int)>("set_RaidMode", 1);
            if (m_set_raid_mode != nullptr)
            {
                m_set_raid_mode(settings, 1); //ERaidMode enum, 0 == Online, 1 == Local
            }
        }
    }

    // dump_raid_settings: Debug helper to inspect raid settings via ToString().
    // Called when detailed diagnostics are needed (e.g., during transit setup).
    inline void modify_raid_settings(Il2CppObject* settings) {
        Il2CppObjectInstance raid_settings(settings);
        logger::debug("modify_raid_settings");

        auto pve_raid_states = raid_settings.get_field<unity::dict<Il2CppString*, bool>*>("_onlinePveRaidStates");
        // Guard against a null/empty dict - the previous code dereferenced it directly, which is a
        // clean ACCESS_VIOLATION if the field is absent or null at this point.
        if (pve_raid_states != nullptr && pve_raid_states->m_i_count > 0)
        {
            // `m_i_count` is the number of LIVE entries; the index one past it is
            // either a free-list slot (corrupting the free list) or past the end
            // of m_p_entries entirely when the dictionary is full. Iterate the
            // live range only -- unity::dict's index accessors now bounds-check.
            for (int i = 0; i < pve_raid_states->m_i_count; ++i)
            {
                auto location_online = pve_raid_states->get_value_by_index(i);
                if (location_online)
                {
                    auto location = pve_raid_states->get_key_by_index(i);
                    //logger::info("modify_raid_settings: pve_raid_states: Location: " + il2utils::conv_string(location) + " was: " + std::format("{}", location_online));
                }
                pve_raid_states->set_value_by_index(i, false);
            }
            raid_settings.set_field("_onlinePveRaidStates", pve_raid_states);
            if (pve_raid_states->m_i_count > 0)
            {
                force_offline_raid_states = true;
            }
        }

        bool is_online_pve_raid = false;
        auto m_get_online_pve_raid = raid_settings.get_method<bool (*)(Il2CppObject*)>("get_OnlinePveRaid", 0);
        if (m_get_online_pve_raid != nullptr)
        {
            is_online_pve_raid = m_get_online_pve_raid(settings);
        }
        if (is_online_pve_raid)
        {
            auto m_set_online_pve_raid = raid_settings.get_method<void (*)(Il2CppObject*, bool)>("set_OnlinePveRaid", 0);
            if (m_set_online_pve_raid != nullptr)
            {
                m_set_online_pve_raid(settings, false);
            }
        }

        force_local_raid_mode(settings);

        dump_transit_settings(settings);
        return;
    }

    inline void get_local_raid_settings(Il2CppObject* instance) {
        FieldInfo* settings_field = il2utils::resolve_field(instance->klass, "_localRaidSettings");
        if (!settings_field || settings_field->offset <= 0) return;
        auto* settings = *reinterpret_cast<Il2CppObject**>(
            reinterpret_cast<uintptr_t>(instance) + settings_field->offset);
        //print_instance_info(settings, std::source_location::current());
        if (settings == nullptr || settings->klass == nullptr) return;
        dump_local_raid_settings(settings);
    }

    inline void get_raid_settings(Il2CppObject* instance) {
        FieldInfo* settings_field = il2utils::resolve_field(instance->klass, "_raidSettings");
        if (!settings_field || settings_field->offset <= 0) return;
        auto* settings = *reinterpret_cast<Il2CppObject**>(
            reinterpret_cast<uintptr_t>(instance) + settings_field->offset);
        print_instance_info(settings, std::source_location::current());
        if (settings == nullptr || settings->klass == nullptr) return;
        modify_raid_settings(settings);
    }

    // hk_display_location: Hook for MatchMakerSelectionLocationScreen.DisplayLocation.
    // Called when selecting a location in the matchmaker menu. Used to configure
    // PVE flags and add locations like Labyrinth/Icebreaker.
    inline bool hk_display_location(Il2CppObject* instance, Il2CppObject* location) {
        //print_instance_info(instance, std::source_location::current());
        const bool res = o_display_location(instance, location);
        if (location != nullptr)
        {
            Il2CppObjectInstance location_instance(location);
            configure_pve_location(location);
            //location_instance.set_field("AccessKeys", nullptr);

            // No Terminal
            if (il2utils::conv_string(location_instance.get_field<Il2CppString*>("Name")).contains("Terminal")) return false;
            // Add Labyrinth
            if (il2utils::conv_string(location_instance.get_field<Il2CppString*>("Name")).contains("Labyrinth")) return true;
            // Add Icebreaker
            if (il2utils::conv_string(location_instance.get_field<Il2CppString*>("Name")).contains("Icebreaker")) return true;
        }

        return res;
    }

    // hk_try_get_location: Hook for ClientTransitController.TryGetLocation.
    // Called when resolving a transit destination, including for locations like Icebreaker
    // that bypass the normal matchmaker flow. May be called during active transit.
    inline bool hk_try_get_location(Il2CppObject* instance, Il2CppString* location_id, Il2CppObject** location) {
        const bool found = o_try_get_location(instance, location_id, location);
        logger::debug("hk_try_get_location");
        //print_instance_info(instance, std::source_location::current());
        //dump_inheritance_chain(instance);
        if (found && location != nullptr)
        {
            get_local_raid_settings(instance);
            get_raid_settings(instance);
            configure_pve_location(*location);
        }
        return found;
    }

    // hk_try_get_location_by_id: Hook for TarkovApplication.TryGetLocationById.
    // Called during in-menu location resolution (not in-raid). Captures the selected
    // location and configures PVE flags before transit begins.
    inline bool hk_try_get_location_by_id(Il2CppObject* instance, Il2CppString* location_id, Il2CppObject** location) {
        // DO NOT CALL IN-RAID, ONLY IN-MENU
        const bool found = o_try_get_location_by_id(instance, location_id, location);
        logger::debug(std::format("[transitdbg] hk_try_get_location_by_id id='{}' found={} (Run d__201 ISIL 2089 skips the transit branch when found==false)",
            il2utils::conv_string(location_id), found));
        g_last_ta = instance;
        //print_instance_info(instance, std::source_location::current());
        //dump_inheritance_chain(instance);
        if (found && location != nullptr)
        {
            get_local_raid_settings(instance);
            get_raid_settings(instance);
            configure_pve_location(*location);
            dump_ta_state(instance, "TryGetLocationById");
        }
        return found; // called inside TarkovApplication
    }

    inline void raid_start_guard_disarm(const char* reason);

    // Caller identification for the transit hooks.
    //
    // 2026-10-04: transit comebacks have never loaded (9 menu raids loaded, 4 transit
    // comebacks did not) and nothing in the log says WHO drives the transit. This is the
    // cheapest way to get an answer: the immediate return address plus a few frames.
    //
    // RtlCaptureStackBackTrace is resolved from ntdll by name rather than declared, because
    // it is NOT in this DLL's import table (Workstream_status 2026-09-24 :7586 checked) and
    // adding the import would change the loader-facing surface for a diagnostic. Resolved
    // once, cached; a null result degrades to logging the return address alone.
    using rtl_capture_stack_backtrace_fn = USHORT(WINAPI*)(ULONG, PVOID*, ULONG, PULONG);

    inline rtl_capture_stack_backtrace_fn resolve_stack_capture() {
        static rtl_capture_stack_backtrace_fn fn = [] {
            const HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
            return ntdll ? reinterpret_cast<rtl_capture_stack_backtrace_fn>(
                GetProcAddress(ntdll, "RtlCaptureStackBackTrace")) : nullptr;
        }();
        return fn;
    }

    inline void log_transit_callers(const char* label) {
        if (!logger::debug_enabled()) return;
        void* frames[6] = {};
        // ULONG, not USHORT: RtlCaptureStackBackTrace's 4th parameter is a PULONG, and
        // passing USHORT* here is a C2664, not a silent truncation.
        ULONG got = 0;
        if (const auto fn = resolve_stack_capture()) {
            // Skip this helper and its caller so frame 0 is the hook, frame 1 the game's
            // call site -- the thing we actually want to name.
            if (fn(6, frames, 6, &got) == 0 && got > 2) {
                std::string text = std::string(label) + " callers:";
                for (ULONG i = 2; i < got && i < 6; ++i) {
                    char buf[32];
                    _snprintf_s(buf, sizeof(buf), _TRUNCATE, " 0x%llX",
                        static_cast<unsigned long long>(reinterpret_cast<uintptr_t>(frames[i])));
                    text += buf;
                }
                logger::debug(text + "   (GameAssembly RVAs: subtract its base)");
            }
        } else {
            logger::debug(std::string(label) + " callers: <RtlCaptureStackBackTrace unavailable>");
        }
    }

    // One-line identity for a managed object: class, pointer, and instance id when it can
    // be read. Used for the transit parameters, which were previously only dumped as raw
    // pointers -- so "which point, which player" was unanswerable from the log.
    inline std::string describe_managed(const char* label, Il2CppObject* obj) {
        if (obj == nullptr) return std::string(label) + "=null";
        if (!eft_api::is_readable_address(obj, sizeof(Il2CppObject)) || obj->klass == nullptr) {
            char buf[64];
            _snprintf_s(buf, sizeof(buf), _TRUNCATE, "%s=0x%llX(unreadable)", label,
                static_cast<unsigned long long>(reinterpret_cast<uintptr_t>(obj)));
            return buf;
        }
        std::string out = std::string(label) + "=";
        out += obj->klass->name ? obj->klass->name : "?";
        char buf[48];
        _snprintf_s(buf, sizeof(buf), _TRUNCATE, "@0x%llX", static_cast<unsigned long long>(
            reinterpret_cast<uintptr_t>(obj)));
        out += buf;
        return out;
    }

    // hk_transit: Hook for LocalTransitController.Transit.
    // The main transit entry point called when starting a local (offline) raid. This is
    // where we set up the target location, player object, and forge the server ID.
    //
    // WHAT THIS HOOK IS RELATIVE TO THE GAME'S OWN STATE MACHINES (2026-10-04, from
    // ISIL-references): `LocalTransitController.Transit` is the OUTER entry. It drives
    // `TransitPoint.Transit`, whose compiler-generated body is
    // `EFT.Interactive.TransitPoint+<Transit>d__38` (ISIL dump:
    // Assembly-CSharp/EFT/Interactive/TransitPoint_NestedType__Transit_d__38.txt). That
    // state machine builds the transitionHash (Guid.NewGuid), the profileKeys dictionary,
    // walks the players HashSet calling GameWorld.GetAlivePlayerByProfileID, and calls
    // TransitPoint.GroupExit -- and it does NOT call back into LocalTransitController.
    //
    // So <Transit>d__38 is DOWNSTREAM of this hook, not the caller of it. That is the
    // important consequence: the game has an async state machine with a TaskAwaiter
    // (<>u__1) on the far side of o_transit, and until now NOTHING logged what happened
    // after this hook handed control over. `res` below is that Task, and its state is the
    // single most informative number this hook can produce.
    inline Il2CppObject* hk_transit(Il2CppObject* instance, Il2CppObject* transit_point, int player_count, Il2CppString* hash,
        Il2CppObject* keys, Il2CppObject* player) {
        logger::info("hk_transit CALLED");
        logger::debug(std::format("hk_transit: transit_point @ 0x{:x}", reinterpret_cast<uintptr_t>(transit_point)));

        // ---- parameters, resolved rather than left as bare pointers -------------
        logger::debug("hk_transit params: "
            + describe_managed("controller", instance) + " "
            + describe_managed("point", transit_point) + " "
            + describe_managed("player", player)
            + " player_count=" + std::to_string(player_count)
            + " hash=" + (hash != nullptr ? il2utils::conv_string(hash) : std::string("<null>"))
            + " " + describe_managed("keys", keys));
        log_transit_callers("hk_transit");

        // Dump transit_point info if available
        if (transit_point != nullptr && transit_point->klass != nullptr)
        {
            print_instance_info(transit_point, std::source_location::current());

            // Try to get the Controller field from TransitPoint
            FieldInfo* controller_field = il2utils::resolve_field(transit_point->klass, "<Controller>k__BackingField");
            if (controller_field != nullptr)
            {
                Il2CppObject* controller = *reinterpret_cast<Il2CppObject**>(reinterpret_cast<char*>(transit_point) + controller_field->offset);
                if (controller != nullptr && controller->klass != nullptr)
                {
                    logger::debug(std::format("hk_transit: TransitPoint.Controller = {} @ 0x{:x}",
                        controller->klass->name ? controller->klass->name : "unknown",
                        reinterpret_cast<uintptr_t>(controller)));

                    // Check if Controller has any async/task fields
                    for (int i = 0; i < controller->klass->field_count; i++)
                    {
                        FieldInfo* field = &controller->klass->fields[i];
                        if (field != nullptr && field->name != nullptr)
                        {
                            void* field_value = reinterpret_cast<char*>(controller) + field->offset;
                            if (field->type->type == IL2CPP_TYPE_OBJECT || field->type->type == IL2CPP_TYPE_CLASS)
                            {
                                Il2CppObject* field_obj = *reinterpret_cast<Il2CppObject**>(field_value);
                                if (field_obj != nullptr && eft_api::is_readable_address(field_obj, sizeof(Il2CppObject)) && field_obj->klass != nullptr)
                                {
                                    std::string field_type(field_obj->klass->name ? field_obj->klass->name : "");
                                    if (field_type.find("Task") != std::string::npos || field_type.find("Async") != std::string::npos || field_type.find("Coroutine") != std::string::npos)
                                    {
                                        logger::debug(std::format("hk_transit: >>> Controller field '{}' is {} @ 0x{:x}",
                                            field->name, field_type, reinterpret_cast<uintptr_t>(field_obj)));

                                        // Check completion status
                                        FieldInfo* completed_field = il2utils::resolve_field(field_obj->klass, "m_completed");
                                        if (completed_field != nullptr)
                                        {
                                            int completed = *reinterpret_cast<int*>(reinterpret_cast<char*>(field_obj) + completed_field->offset);
                                            logger::debug(std::format("hk_transit: >>> Task m_completed = {} (0=pending, 1=done)", completed));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    logger::warn("hk_transit: TransitPoint.Controller is null or invalid");
                }
            }
            else
            {
                logger::warn("hk_transit: Could not find <Controller>k__BackingField in TransitPoint");
            }
        }

        //print_instance_info(instance, std::source_location::current());
        //dump_inheritance_chain(instance, std::source_location::current());

        // Configure the destination and player BEFORE the original Transit runs. The
        // original LocalTransitController.Transit evaluates ForceOnlineRaidInPVE
        // (ISIL instr 176) before any later mod configuration, so the old post-call
        // setup_target_location was always too late for the offline-transit branch
        // (transcript 2026-09-24).
        // setup_target_location(instance, transit_point);

        // ELocalMode is READ here and logged. It is not written, anywhere.
        //
        // Both writers that used to exist are inert: the `set_field("mode", 1)` in
        // dump_local_raid_settings() is gone, and setup_local_player_object() is
        // commented out. See those two for why -- briefly, 1 is PVE_OFFLINE, the
        // value being clobbered was 3 (TUTORIAL), the game assigns the field itself
        // from LocalPlayer.Create's `localMode` parameter, and ELocalMode does not
        // decide the online/offline path in any case.
        //
        // The read stays because it is the only place the real value is visible.
        // It used to be invisible: the dump overwrote the field immediately before
        // printing it, so every raid in every session logged
        // "[mode-PVE_OFFLINE]" and a tutorial was indistinguishable from an
        // offline raid in the log.
        {
            int mode = -1;
            if (try_read_local_mode(instance, mode)) {
                logger::debug(std::format(
                    "hk_transit: ELocalMode={} ({}) -- read only, not written",
                    mode, local_mode_name(mode)));
            } else {
                logger::debug("hk_transit: ELocalMode unreadable; nothing is written "
                              "either way, so there is nothing to report");
            }
        }

        // LocalTransitController carries _localRaidSettings (not _raidSettings), so the
        // old get_raid_settings(instance) here was a no-op. Force RaidMode=Local on the
        // owning TarkovApplication (g_last_ta) instead, so IsLocalTransitHop() and the
        // Run d__201 guard agree with the local path about to be taken.
        if (ta_is_valid(g_last_ta))
        {
            get_raid_settings(g_last_ta);
        }

        Il2CppObject* res = nullptr;
        // Callers, so we can see whether the game re-enters this hook on a resumption of
        // <Transit>d__38 or whether there is exactly one call per transit attempt. The
        // per-resumption counter is deliberately NOT used here: the transit is rare enough
        // that a per-call line is affordable, and "how many times" is the question.
        log_transit_callers("hk_transit/o_transit BEFORE");

        const ULONGLONG transit_start = GetTickCount64();
        if (keep_original_transition_hash)
        {
            res = o_transit(instance, transit_point, player_count, hash, keys, player);
        }
        else
        {
            res = o_transit(instance, transit_point, player_count, il2cpp::il2cpp_string_new(""), keys, player);
        }
        const ULONGLONG transit_ms = GetTickCount64() - transit_start;

        // ---- what came back, and how long it took -------------------------------
        //
        // o_transit returns the game's Task for the transit. NOTHING logged this before,
        // which is the gap that matters: the stall is always downstream of this hook, and
        // the state of this Task is what an awaiter on the far side would be waiting on.
        //
        // m_stateFlags is Task's authoritative internal state (Faulted = 0x2,
        // Canceled = 0x4, RanToCompletion = 0x10); m_completed is the async-method flag
        // and can disagree with it, so BOTH are printed rather than one being trusted.
        // (RanToCompletion is deliberately NOT printed as a positive: this hook returns
        // while the Task is still in flight -- o_transit returned in 63 ms on 2026-10-04
        // while the transit was still resolving -- so a completed Task here would mean
        // something else entirely and needs its own line, not a label on this one.)
        std::string task_state = "n/a";
        if (res != nullptr && eft_api::is_readable_address(res, sizeof(Il2CppObject)) && res->klass != nullptr)
        {
            // A MISSING field and an UNREADABLE one are different failures and must not
            // print the same thing. The 2026-10-04 run printed a bare "m_completed=-1",
            // which reads as a measurement rather than as "we did not get it" -- so each
            // case now says which of the three it was.
            auto read_task_int = [](const Il2CppObject* obj, const char* name) -> std::string {
                const FieldInfo* f = il2utils::resolve_field(obj->klass, name);
                if (f == nullptr) return std::string(name) + "=<field not found>";
                const auto* at = reinterpret_cast<const char*>(obj) + f->offset;
                if (!eft_api::is_readable_address(at, sizeof(int)))
                    return std::string(name) + "=<unreadable>";
                char buf[48];
                _snprintf_s(buf, sizeof(buf), _TRUNCATE, "%s=0x%X", name, *reinterpret_cast<const int*>(at));
                return buf;
            };
            // m_stateFlags is the authoritative Task state (Faulted 0x2, Canceled 0x4).
            // Printed as hex because the high bits are set too and decimal hides that.
            const std::string state_text = read_task_int(res, "m_stateFlags");
            const bool faulted = state_text.find("0x2") != std::string::npos
                || state_text.find("0x6") != std::string::npos;
            const bool canceled = state_text.find("0x4") != std::string::npos
                || state_text.find("0xC") != std::string::npos;
            task_state = state_text + " " + read_task_int(res, "m_completed")
                + (faulted ? " FAULTED" : "") + (canceled ? " CANCELED" : "")
                + (state_text.find('=') != std::string::npos && !faulted && !canceled
                    ? " (neither Faulted 0x2 nor Canceled 0x4)" : "");
        }

        logger::info("hk_transit: o_transit returned after " + std::to_string(transit_ms) + " ms; task "
            + describe_managed("", res) + " " + task_state
            + " keep_original_transition_hash=" + (keep_original_transition_hash ? "true" : "false"));
        log_transit_callers("hk_transit/o_transit AFTER");

        get_local_raid_settings(instance);
        return res;
    }

    // ---- raid-start in-flight guard (post-transit load crash fix) ----
    // Model (user-confirmed): hk_local_raid_started (EftClientBackendSession.
    // LocalRaidStarted) is the definitive "raid is launching" point, and the crash is
    // game re-running startMatching while already in-raid/loading: 14:55 factory4_day
    // logged matching/create again ~24 s after raid_started and died natively inside
    // IL2CPP metadata lookups; the healthy 12:38 run repeated the pipeline only AFTER
    // load finished (benign). Guard is armed ONLY for sessions that entered a raid
    // through the transit patch (profile-status Free(0) write records transit_patched):
    // menu-initiated starts that never transited stay 100% vanilla. Arming itself is
    // deferred to hk_local_raid_started (2026-09-23 finding: arming mid-transit made
    // Transit -> Exfil -> Infil impossible to test) — the guard is "set in stone" once
    // the raid actually started. Arming clears when a new menu flow begins
    // (hk_rs_need_to_go_online_in_pve = fresh PLAY press); the load WINDOW closes when
    // the destination actually loads (GameWorld live — raid_start_guard_load_complete)
    // or the raid ends (hk_local_raid_ended), with a 6-min failsafe cap; a re-armed
    // guard at a later raid_started renews it.
    //
    // Suppression rule (2026-09-24 11:23 finding — guard starved the destination raid):
    // In every healthy pipeline (transit: Run d__201; menu: OnReadyToStartMatchingAsync)
    // LocalGameMatching completes BEFORE LocalRaidStarted opens the window, and the
    // raid's own LocalGameCreate fires ~3 s after raid_started (right after the
    // match/local/start response). So:
    //   - in-window "matching" = a re-entry round (always safe to suppress);
    //   - in-window "create" is suppressed ONLY if an in-window matching was suppressed
    //     first — the 14:55 crash was matching-then-create run a second time. The first
    //     create in a window (no in-window matching before it) is the destination raid's
    //     own and MUST run, or the destination raid never loads (game parks on the load
    //     screen — exactly the 11:22:58 -> 11:23:01 Streets park).
    struct raid_start_guard_t
    {
        std::atomic<bool> armed{false};           // guard active (only after a raid actually started)
        std::atomic<bool> in_flight{false};       // raid_started seen, load window open
        std::atomic<bool> transit_patched{false}; // this session entered a raid via the transit patch
        std::atomic<long long> started_ms{0};
        std::atomic<int> suppressed_matching{0};
        std::atomic<int> suppressed_create{0};
        std::atomic<bool> suppression_logged{false};
        std::atomic<bool> create_passthrough_logged{false};
    };
    inline raid_start_guard_t g_raid_start_guard;
    // Failsafe only: the window normally closes on load-complete (GameWorld live) or
    // raid end. A 6-min guard is long enough for any transit load (Streets took >70 s
    // yet the old 40 s cap expired mid-load, letting the duplicate matching round
    // through -> the 2026-09-24 12:44 crash) while still freeing matching if the
    // destination never loads (no GameWorld ever appears) or raid-end never fires.
    static constexpr long long kRaidStartGuardCapMs = 360000;

    inline long long raid_guard_now_ms() {
        return std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch())
            .count();
    }

    inline void raid_start_guard_arm() {
        if (!g_raid_start_guard.armed.exchange(true, std::memory_order_acq_rel))
            logger::debug("[transitdbg] raid-start guard armed (session used transit patch)");
    }

    inline void raid_start_guard_disarm(const char* reason) {
        if (g_raid_start_guard.armed.exchange(false, std::memory_order_acq_rel))
            logger::debug(std::format("[transitdbg] raid-start guard disarmed ({})", reason));
        // A fresh menu flow must never run inside a stale load window.
        g_raid_start_guard.in_flight.store(false, std::memory_order_release);
    }

    // raid_start_guard_load_complete: called from hk_game_world_update when the
    // destination raid's GameWorld is live = the load finished. Only the duplicate
    // matching/create round the game re-runs WHILE loading is lethal (native crash);
    // once the world is up the post-load pipeline is the healthy 12:38 flow and must
    // be allowed. Closing the window on this event instead of a time cap is what keeps
    // slow transit loads (Streets: 12:43:12 -> 12:44:22 on 2026-09-24, load still
    // running when the old 40 s cap expired and let the duplicate round through) safe.
    inline void raid_start_guard_load_complete() {
        if (g_raid_start_guard.in_flight.exchange(false, std::memory_order_release))
            logger::debug("[transitdbg] raid-start guard: load complete, matching/create flow restored (GameWorld live)");
    }

    inline void raid_start_guard_begin() {
        if (!g_raid_start_guard.armed.load(std::memory_order_acquire)) return;
        g_raid_start_guard.in_flight.store(true, std::memory_order_release);
        g_raid_start_guard.started_ms.store(raid_guard_now_ms(), std::memory_order_relaxed);
        g_raid_start_guard.suppressed_matching.store(0, std::memory_order_relaxed);
        g_raid_start_guard.suppressed_create.store(0, std::memory_order_relaxed);
        g_raid_start_guard.suppression_logged.store(false, std::memory_order_relaxed);
        g_raid_start_guard.create_passthrough_logged.store(false, std::memory_order_relaxed);
        logger::debug("[transitdbg] raid-start guard: in flight (suppressing duplicate matching/create while load completes)");
    }

    inline bool raid_start_guard_should_suppress(const char* what) {
        if (!g_raid_start_guard.in_flight.load(std::memory_order_acquire)) return false;
        if (raid_guard_now_ms() - g_raid_start_guard.started_ms.load(std::memory_order_relaxed) > kRaidStartGuardCapMs)
        {
            g_raid_start_guard.in_flight.store(false, std::memory_order_release);
            logger::warn("[transitdbg] raid-start guard: failsafe cap expired (6 min), matching/create flow restored (no load-complete in time)");
            return false;
        }
        // The raid's own create: its matching ran before raid_started opened this
        // window, so no in-window matching precedes it. Only a create that follows a
        // suppressed in-window matching is a re-entry round (14:55 crash signature).
        if (what[0] == 'c' && g_raid_start_guard.suppressed_matching.load(std::memory_order_acquire) == 0)
        {
            bool expected = false;
            if (g_raid_start_guard.create_passthrough_logged.compare_exchange_strong(expected, true))
                logger::info("[transitdbg] raid-start guard: create passthrough (destination raid's own create — no in-window matching before it)");
            return false;
        }
        (what[0] == 'm' ? g_raid_start_guard.suppressed_matching
                        : g_raid_start_guard.suppressed_create)
            .fetch_add(1, std::memory_order_relaxed);
        bool expected = false;
        if (g_raid_start_guard.suppression_logged.compare_exchange_strong(expected, true))
            logger::info(std::format(
                "[transitdbg] raid-start guard: suppressing duplicate {} pipeline while the raid loads (post-transit sessions crash here natively)", what));
        return true;
    }

    // What <InternalStartGame>d__104 needs before a load can proceed, observed from outside.
    //
    // ADDED 2026-10-04 after the transit-exfil comeback investigation, and the reason is a
    // gap rather than a theory: that session's whole comeback completed correctly --
    // ComebackToMainMenu to -2, PrepareGameJob to -2 in 6 s, Run to -2 -- and then
    // "Loading in at: bigmap" printed and no GameWorld ever appeared. Nothing in the transit
    // fixtures looks at the load's own inputs, so a parked load is indistinguishable from a
    // slow one in the log. These are the three operations that decide it.
    //
    // ISIL (TarkovApplication_NestedType__InternalStartGame_d__104.txt):
    //   179  RaidSettings.set_SelectedLocation(_raidSettings, v922)
    //   411  RaidSettings.get_Local(_raidSettings)   -> bool
    //   450/495  Task.GetAwaiter ... AwaitUnsafeOnCompleted
    // It writes SelectedLocation, reads get_Local, then awaits.
    //
    // get_Local is the one worth watching, and the reason is that <Run>d__201's NotImplemented
    // path is gated on the same idea -- the native shape recorded at :1129 is
    // `_raidSettings.get_Local() -> true -> JNE 0x182B8EE17` -- so "the game still believes
    // this is an ONLINE raid" is the hypothesis that would explain a comeback that never
    // reaches GameWorld. That is a hypothesis, not a finding, and this is the only place it
    // can be observed without a new hook. It is worth one line per raid start to find out.
    //
    // Reads _raidSettings off g_last_ta, the validated TarkovApplication, for the same reason
    // apply_local_raid_settings_after_rpc does (:1055-1057): the field lives on the owner, not
    // on the state-machine struct, so resolving it against a sm class returns null.
    inline void log_load_gate_inputs(const char* tag) {
        Il2CppObject* ta = g_last_ta;
        if (ta == nullptr || ta->klass == nullptr) {
            logger::debug(std::string("[transitdbg] ") + tag
                + ": no validated TarkovApplication; load-gate inputs unavailable");
            return;
        }

        FieldInfo* rs_field = il2utils::resolve_field(ta->klass, "_raidSettings");
        Il2CppObject* raid_settings = nullptr;
        if (rs_field != nullptr) read_guarded(ta, rs_field->offset, raid_settings);
        if (raid_settings == nullptr || raid_settings->klass == nullptr) {
            logger::debug(std::string("[transitdbg] ") + tag + ": _raidSettings null or unreadable");
            return;
        }

        Il2CppObjectInstance rs(raid_settings);
        Il2CppObject* selected = rs.get_field<Il2CppObject*>("selectedLocation");
        std::string selected_desc = "null";
        if (selected != nullptr && selected->klass != nullptr
            && eft_api::is_readable_address(selected, sizeof(Il2CppObject)))
            selected_desc = "set";
        else if (selected != nullptr)
            selected_desc = "non-null but unreadable";

        std::string local = "unresolved";
        if (const auto m_get_local = rs.get_method<bool (*)(Il2CppObject*)>("get_Local", 0))
            local = m_get_local(raid_settings) ? "true" : "false";

        logger::debug(std::string("[transitdbg] ") + tag + ": selectedLocation=" + selected_desc
            + " get_Local=" + local);
    }

    // hk_local_raid_started: Hook for EftClientBackendSession.LocalRaidStarted.
    // The request side of a local raid start, not the response: ISIL <LocalGameCreate>d__229 calls
    // it at 913/919 and only unpacks the RPC result into the settings at 991-1036, after an await
    // that usually suspends. So nothing about the destination is knowable here.
    //
    // What this hook is actually FOR is the raid-start guard below, and that part works: it is pure
    // mod state with no dependency on the settings having been populated. The two settings writes
    // that used to be here were silently dead (configure_pve_location got a null selectedLocation;
    // the keep_original_server_id "" was overwritten by v187.serverId 91 ISIL later) and now live in
    // apply_local_raid_settings_after_rpc, gated on selectedLocation being populated. See that
    // function for the full ISIL ordering.
    inline Il2CppObject* hk_local_raid_started(Il2CppObject* instance, Il2CppObject* settings) {
        print_instance_info(instance, std::source_location::current());
        Il2CppObjectInstance local_raid_settings(settings);
        dump_local_raid_settings(settings);

        // location/mode are already set at this point (ISIL 799/816), so this line is honest.
        logger::info("Loading in at: " + il2utils::conv_string(local_raid_settings.get_field<Il2CppString*>("location")));
        // The other two things <InternalStartGame>d__104 reads. See log_load_gate_inputs for
        // why: "Loading in at" alone cannot distinguish a load that is about to complete from
        // one that has parked, because both print exactly this line.
        log_load_gate_inputs("LoadingIn");
        // "Set in stone after raid started": only arm the guard here, when
        // LocalRaidStarted actually fires. Arming during transit made the
        // Transit -> Exfil -> Infil flow untestable; a transit-patched session
        // now arms once per raid start (transit_patched stays true for the app
        // session, so post-transit menu starts are covered by the 40 s cap).
        if (g_raid_start_guard.transit_patched.load(std::memory_order_acquire))
            raid_start_guard_arm();
        raid_start_guard_begin();
        // Exfil eligibility: two passes per raid, the second one 30 s after THIS call.
        // Placed here because this is the user's definition of "raid start", and because a
        // reference that only becomes available once we can already resolve an
        // ExfiltrationController cannot bound the frames before that.
        //
        // Deliberately NOT raid_start_guard_begin(): that returns early unless the guard is
        // ARMED, and arming happens only on the transit-patched path above -- so on an ordinary
        // menu start it does nothing and the exfil timer would have no reference at all.
        // refresh_exfil_eligibility falls back to its own snapshot stamp in that case, but
        // anchoring on the game's event is what makes the count exactly two.
        eft_api::note_local_raid_started();
        return o_local_raid_started(instance, settings);
    }

    inline void hk_on_ready_to_start_matching_async(void* sm) {
        logger::debug("hk_on_ready_to_start_matching_async");
        static const Il2CppClass* sm_klass = nullptr;
        if (sm_klass == nullptr) sm_klass = resolve_sm_class("OnReadyToStartMatchingAsync");
        static bool logged_shape = false;

        const sm_view view = make_sm_view(sm_klass, sm, ta_klass());
        if (!logged_shape)
        {
            logged_shape = true;
            log_sm_shape("OnReadyToStartMatchingAsync", sm_klass, sm, view);
        }

        Il2CppObject* instance = view.owner;
        if (instance == nullptr)
        {
            Il2CppObject* raw = nullptr;
            if (read_guarded(sm, 0x20, raw) && ta_is_valid(raw)) instance = raw;
        }
        if (instance != nullptr)
        {
            Il2CppObjectInstance instanced(instance);
            auto settings = instanced.get_field<Il2CppObject*>("_raidSettings");
            force_local_raid_mode(settings);
        }
        o_on_ready_to_start_matching_async(sm);
    }

    inline void hk_local_game_matching(void* sm) {
        logger::debug("hk_local_game_matching");
        if (raid_start_guard_should_suppress("matching")) return;
        o_local_game_matching(sm);
    }

    // apply_local_raid_settings_after_rpc: the two LocalRaidSettings mutations that used to live in
    // hk_local_raid_started, moved to the only point where the fields they touch actually exist.
    //
    // WHY NOT IN hk_local_raid_started (ISIL <LocalGameCreate>d__229, the sole caller of
    // LocalRaidStarted -- it is reached through IEftSession slot 62 at ISIL 913/919):
    //
    //   770/774  new LocalRaidSettings()          -> location, timeVariant, mode, playerSide,
    //   799-844                                    transitionType are filled from _raidSettings
    //   845       _localRaidSettings = the new object
    //   913/919   LocalRaidStarted(_localRaidSettings)          <-- the old hook ran HERE
    //   933/948   GetAwaiter + get_IsCompleted; ConditionalJump SUSPENDS if not already complete
    //   951       GetResult() -> v187 (JsonType.LocalSettings), the RPC response
    //  1004       _localRaidSettings.serverId         = v187.serverId
    //  1020       _localRaidSettings.selectedLocation = v187.locationLoot
    //  1036       _localRaidSettings.transition       = v187.transitionSettings
    //
    // (Each of those three is a Nop-padded operand annotation of the Move that precedes it at 991,
    // 1007 and 1023 respectively; 991-1036 is the span.)
    //
    // Scope, so it is not overclaimed: LocalTransitController._localRaidSettings is the SAME object,
    // not a copy. Raw disassembly of LocalGameCreate d__229 loads it as LocalGame.Create's 18th
    // parameter (`mov rax,[r14+118h]` / `mov [rsp+88h],rax`, rsp = entry-0x1F8), and BaseLocalGame`1
    // +<Run>d__61 hands the game instance's 0xE8 field back as the controller ctor's 4th
    // (`mov rax,[rbx+0E8h]` / `mov [rsp+20h],rax`, then `call 0x182378490`). dump.cs prints
    // BaseLocalGame._raidSettings as 0x0 only because BaseLocalGame<T> is an open generic and its
    // field offsets are not emitted; the instantiated layout is 0xE8. That identity does NOT widen
    // this fix: Transit reads only _localRaidSettings.mode and .timeVariant, neither of which the
    // RPC populates nor this function writes. See CLEANUP_AUDIT.md 19.6c.
    //
    // LocalRaidStarted is the request, not the response: both fields were still null when the hook
    // body ran. configure_pve_location() therefore early-returned on a null location, and the
    // keep_original_server_id write of "" was overwritten 91 ISIL later by v187.serverId. Both were
    // silent no-ops -- the "re-assert the mode and configure the selected location immediately"
    // comment on the old hook described an effect it never had.
    //
    // Note the await at 948: the first MoveNext that reaches here usually SUSPENDS, so simply
    // running this once after o_local_game_create(sm) returns would still be too early. MoveNext is
    // re-entered on every resumption and the one that runs GetResult is the one that leaves
    // selectedLocation populated, so gating on that field is what makes this fire at the right
    // moment. Both operations are idempotent -- configure_pve_location writes seven fixed bools and
    // the serverId write is one fixed string -- so re-running on any later MoveNext is harmless.
    inline void apply_local_raid_settings_after_rpc(void* sm) {
        // EVERY EXIT IS LOGGED, which is the whole point of this being here in 2026-10-04.
        //
        // The investigation asked "why did the load-gate diagnostics never appear", and the
        // honest answer turned out to be that this function had no logging on any path -- so
        // "never called" and "called and bailed at guard #3" produced the identical absence in
        // the log. A function whose job is to mutate settings before a load, reachable only
        // through one caller with a suppression early-return above it, cannot be allowed to
        // be mute.
        //
        // The call counter is here because this re-runs on every LocalGameCreate resumption.
        // Seeing the count is what tells you whether a raid had one attempt or many, which is
        // the difference between "settings applied once" and "settings applied on the fourth
        // resumption after three silent bails".
        static unsigned call_count = 0;
        const unsigned nth = ++call_count;
        auto bail = [&](const char* why) {
            logger::debug(std::string("[transitdbg] apply_local_raid_settings_after_rpc call #")
                + std::to_string(nth) + ": bailed, " + why);
        };

        static const Il2CppClass* sm_klass = nullptr;
        if (sm_klass == nullptr) sm_klass = resolve_sm_class("LocalGameCreate");
        if (sm_klass == nullptr) { bail("LocalGameCreate sm class unresolved"); return; }

        const sm_view view = make_sm_view(sm_klass, sm, ta_klass());
        if (!view.ok() || view.owner == nullptr) { bail("sm view unresolved"); return; }

        // _localRaidSettings is a field of TarkovApplication itself (dump.cs:311891, 0x118), so it
        // lives on the validated <>4__this owner, NOT on the state-machine struct. Resolving it
        // against sm_klass returns null and this would silently never run.
        FieldInfo* settings_field = il2utils::resolve_field(view.owner->klass, "_localRaidSettings");
        if (settings_field == nullptr) { bail("_localRaidSettings field not found on owner"); return; }
        Il2CppObject* local_raid_settings = nullptr;
        if (!read_guarded(view.owner, settings_field->offset, local_raid_settings)) {
            bail("_localRaidSettings unreadable");
            return;
        }
        if (!eft_api::is_readable_address(local_raid_settings, sizeof(Il2CppObject))
            || local_raid_settings->klass == nullptr) { bail("_localRaidSettings null or no klass"); return; }

        Il2CppObjectInstance settings(local_raid_settings);
        // Non-null only after ISIL 1007/1020, i.e. only once the RPC result has been unpacked.
        //
        // THIS IS THE ONLY SILENT EXIT THAT MATTERS, and it is silent because it is SUPPOSED to
        // be: this function re-runs on every LocalGameCreate resumption and only the one that
        // leaves selectedLocation populated should apply. So "it logged nothing" was never
        // evidence it did not run -- it has no logging at all. That is a hole in the record,
        // not a finding, and the one-line note closes it without turning a per-resumption
        // function into a flood.
        Il2CppObject* selected_location = settings.get_field<Il2CppObject*>("selectedLocation");
        if (selected_location == nullptr) {
            // The expected bail, not a fault: this re-runs on every resumption and only the
            // one that leaves selectedLocation populated should act. It is logged because
            // "expected" and "never ran" look identical otherwise.
            bail("selectedLocation still null (RPC result not unpacked yet?)");
            return;
        }

        configure_pve_location(selected_location);
        if (!keep_original_server_id) settings.set_field("serverId", il2cpp::il2cpp_string_new(""));
        logger::debug("[transitdbg] apply_local_raid_settings_after_rpc call #" + std::to_string(nth)
            + ": APPLIED (selectedLocation set, keep_original_server_id="
            + (keep_original_server_id ? "true" : "false") + ")");
    }

    inline void hk_local_game_create(void* sm) {
        logger::debug("hk_local_game_create");
        // The suppression early-return skips BOTH the game's own create and
        // apply_local_raid_settings_after_rpc, so a suppressed create is a create whose
        // selectedLocation/serverId were never written. Until 2026-10-04 that was silent,
        // and it was silent for a structural reason rather than an accident: the guard had
        // never armed, so should_suppress could not return true and this line was
        // unreachable. Arming the guard from hk_ta_is_local_transit_hop makes it reachable
        // for the first time, so the branch now says which way it went. Without this, a
        // transit comeback whose create gets suppressed looks exactly like one where the
        // settings writer simply never ran.
        if (raid_start_guard_should_suppress("create")) {
            logger::debug("[transitdbg] hk_local_game_create: SUPPRESSED by raid-start guard -- "
                "o_local_game_create and apply_local_raid_settings_after_rpc both skipped");
            return;
        }
        o_local_game_create(sm);

        // The config gate, AFTER o_local_game_create and not before it.
        //
        // After, because o_local_game_create is the game's own call and must never be
        // gated by one of our toggles -- the suppression above already owns the cases
        // where we deliberately do not create a raid.
        //
        // At the CALL SITE rather than inside the function because the question is
        // whether to call it at all, and there is exactly ONE caller today (this
        // file, verified). If a second caller ever appears it MUST gate here too, or
        // the checkbox will read as "off" while that caller still writes -- which is
        // the false-negative this whole switch exists to rule out.
        //
        // Logged at DEBUG on every call, like every bail inside the function, so a run
        // with it off is distinguishable from a run where the function was never
        // reached. That distinction is the entire result this switch is being added
        // for, and "no APPLIED line" alone would not tell them apart.
        if (!write_local_raid_settings_after_rpc)
        {
            logger::debug("[transitdbg] hk_local_game_create: apply_local_raid_settings_after_rpc "
                          "NOT CALLED (write_local_raid_settings_after_rpc=false)");
            return;
        }

        apply_local_raid_settings_after_rpc(sm);
    }

    // hk_start_online_transit_matching: d__238, the transit-block entry that Run d__201
    // awaits. Two await points: state 0 = StartTransitMatchingPrepareAsync (TaskAwaiter<bool>
    // <>u__1, returns false -> "Transit matching aborted"), state 1 = NetworkGameMatching
    // (TaskAwaiter <>u__2). A park here with a pending awaiter names the exact stuck call.
    inline void hk_start_online_transit_matching(void* sm) {
        static sm_hook_ctx ctx;
        static sm_transition_state trans;

        int state = -9999;
        const sm_view view = begin_move_next("StartOnlineTransitMatching", ctx, sm, state);

        // Do NOT call the original StartOnlineTransitMatching: its first await is
        // StartTransitMatchingPrepareAsync (TaskAwaiter<bool> <>u__1), which never
        // completes offline and is the exact hang point (Run d__201 instr 2204, transcript
        // 2026-09-24). IsLocalTransitHop now returns true so this branch should not be
        // reached at all; if it still fires, swallow it instead of parking the client.
        logger::warn(std::format("[transitdbg] StartOnlineTransitMatching: suppressing original call (offline-hang guard), sm=0x{:x} state={}",
            reinterpret_cast<uintptr_t>(sm), state));

        const int exit_state = sm_state(ctx.sm_klass, view.base);
        dump_pending_awaiter("StartOnlineTransitMatching", ctx.sm_klass, view.base, {"<>u__1", "<>u__2"});
        log_move_next_transition("StartOnlineTransitMatching", state, exit_state,
            trans.last_enter, trans.last_exit, trans.repeat);
    }

    // The <Run>d__201 guard (native, ISIL TarkovApplication_NestedType__Run_d__201):
    //   prologue (state -1 ONLY): object_new(<>c__DisplayClass201_0) -> sm.<>8__1 = rsi;
    //     closure.profileStatus [0x10] = [raw sm+0x20]; closure.<>4__this [0x18] = [raw sm+0x28]
    //   guard: closure.profileStatus.status [obj+0x20] == Free(0) -> normal local path
    //     0x182B8E278; else _raidSettings.get_Local() -> true -> JNE 0x182B8EE17 ->
    //     NotImplementedException("Invalid profile status:" + status), builder.SetException,
    //     state=-2, closure nulled -> task dies, client parks in the menu.
    // KEY FACT (2026-09-23 retest): the closure is CREATED inside MoveNext's state -1
    // prologue, so pre-call <>8__1 is ALWAYS null ("state=4" log line) and patching
    // through the closure can never fire before the guard on first entry - which is the
    // only entry that reaches the guard. The closure's profileStatus is a reference copy
    // of the Run() PARAMETER object stored at raw sm+0x20 (dump.cs offset 0x20, boxed
    // +0x10 -> resolver offset 0x30; the earlier "different, unused copy" note was wrong:
    // the prologue literally copies [sm+0x20] into the closure). Patching THAT object
    // pre-call pre-empts the prologue's copy and the guard sees Free(0).
    // Layout cross-check (dump.cs + runtime logs): <Run>d__201 raw fields state@0x0,
    // builder@0x8, profileStatus param@0x20, <>4__this@0x28, <>8__1@0x40; boxed base =
    // raw+0x10, so resolver offsets are 0x10/0x18/0x30/0x38/0x50 (off_this=0x38 observed).
    // The throw landing's epilogue nulls closure@0x40 but NOT the parameter slots, so a
    // post-fault retry (state 0) can still patch; the game's own re-entry paths
    // (OnReadyToStartMatchingAsync d__212 etc.) re-call Run and give the patch a live
    // second chance without any forced restart.
    inline void run_keep_profile_status_free(const sm_view& view) {
        constexpr intptr_t kProfileStatusSlotOffset = 0x30; // raw sm+0x20 + boxed header 0x10
        constexpr int kStageComplete = 1;
        constexpr int kStageBaseMissing = 2;
        constexpr int kStageParamSlotNull = 4;
        constexpr int kStageProfileStatusInvalid = 6;
        constexpr int kStageNoStatusField = 7;
        constexpr int kStageStatusAlreadyFree = 8;
        constexpr int kStageNoRaidSettingsField = 9;
        constexpr int kStageRaidSettingsNull = 10;
        constexpr int kStageNotLocal = 11;
        constexpr int kStageGetLocalMissing = 12;
        constexpr int kStageLayoutMismatch = 13;

        auto report_once = [](const int stage, const bool in_transition, std::string_view detail = {}) {
            static std::atomic<int> last_stage{-1};
            const int previous = last_stage.exchange(stage);
            // In-transition entries are one-shot per transit: never dedupe them away,
            // or the single line that matters during the park would be lost because a
            // menu-phase call landed on the same stage earlier in the process.
            if (previous != stage || in_transition)
            {
                const std::string extra = detail.empty() ? std::string() : std::string(" [") + std::string(detail) + "]";
                logger::debug(std::format(
                    "[transitdbg] run_keep_profile_status_free: state={} ({}), continuing Run normally{}",
                    stage,
                    stage == kStageComplete                   ? "status patched to Free(0)"
                        : stage == kStageBaseMissing          ? "sm base/owner unresolved"
                        : stage == kStageParamSlotNull        ? "profileStatus param slot [raw sm+0x20] null"
                        : stage == kStageProfileStatusInvalid ? "profileStatus object invalid"
                        : stage == kStageNoStatusField        ? "ProfileStatus.status field missing"
                        : stage == kStageStatusAlreadyFree    ? "status already Free(0)"
                        : stage == kStageNoRaidSettingsField  ? "_raidSettings field missing on TarkovApplication"
                        : stage == kStageRaidSettingsNull     ? "_raidSettings null"
                        : stage == kStageNotLocal             ? "raid settings NOT Local - online path left alone (gating working)"
                        : stage == kStageLayoutMismatch       ? "layout mismatch"
                                                              : "get_Local unresolvable - gating is off, patch SKIPPED for safety",
                    extra));
            }
        };

        if (view.base == nullptr || view.owner == nullptr)
        {
            report_once(kStageBaseMissing, false);
            return;
        }

        bool in_transition = false;
        if (FieldInfo* ts_field = il2utils::resolve_field(view.owner->klass, "<TransitionStatus>k__BackingField"))
            read_guarded(view.owner, ts_field->offset, in_transition);

        static const Il2CppClass* sm_klass = nullptr;
        static FieldInfo* state_field = nullptr;
        static FieldInfo* this_field = nullptr;
        static FieldInfo* status_value_field = nullptr;
        static FieldInfo* raid_settings_field = nullptr;

        if (sm_klass == nullptr)
        {
            sm_klass = resolve_sm_class("Run");
            if (sm_klass != nullptr)
            {
                state_field = il2utils::resolve_field(sm_klass, "<>1__state");
                this_field = il2utils::resolve_field(sm_klass, "<>4__this");
            }
        }

        // The Run() profileStatus PARAMETER slot - populated by the async stub BEFORE
        // the first MoveNext (unlike <>8__1, which the prologue creates too late).
        // Prefer the resolver field (<Run>d__201.profileStatus, boxed 0x30 = raw 0x20);
        // fall back to the raw slot constant in case the field is renamed upstream.
        Il2CppObject* profile_status = nullptr;
        if (sm_klass != nullptr)
        {
            if (FieldInfo* param_field = il2utils::resolve_field(sm_klass, "profileStatus"))
                read_guarded(view.base, param_field->offset, profile_status);
        }
        if (profile_status == nullptr)
            read_guarded(view.base, kProfileStatusSlotOffset, profile_status);

        if (profile_status == nullptr)
        {
            report_once(kStageParamSlotNull, in_transition);
            return;
        }
        if (!eft_api::is_readable_address(profile_status, sizeof(Il2CppObject)) || profile_status->klass == nullptr)
        {
            report_once(kStageProfileStatusInvalid, in_transition);
            return;
        }

        if (status_value_field == nullptr)
            status_value_field = il2utils::resolve_field(profile_status->klass, "status");
        if (status_value_field == nullptr)
        {
            report_once(kStageNoStatusField, in_transition);
            return;
        }

        // Layout tripwires: if these fire, the resolver offsets are not the boxed
        // dump.cs offsets and the patch below would write to the wrong slot.
        if (this_field != nullptr && this_field->offset != 0x38)
            report_once(kStageLayoutMismatch, in_transition,
                std::format("<>4__this@0x{:x}, expected 0x38", this_field->offset));
        if (state_field != nullptr && state_field->offset != 0x10)
            report_once(kStageLayoutMismatch, in_transition,
                std::format("<>1__state@0x{:x}, expected 0x10", state_field->offset));

        int status = 0;
        if (!read_guarded(profile_status, status_value_field->offset, status) || status == 0)
        {
            report_once(kStageStatusAlreadyFree, in_transition);
            return;
        }

        // Only the local path reaches the throwing landing; online settings take the
        // game's own reconciliation branch and must be left alone.
        if (raid_settings_field == nullptr)
            raid_settings_field = il2utils::resolve_field(view.owner->klass, "_raidSettings");
        if (raid_settings_field == nullptr)
        {
            report_once(kStageNoRaidSettingsField, in_transition);
            return;
        }

        Il2CppObject* raid_settings = nullptr;
        if (!read_guarded(view.owner, raid_settings_field->offset, raid_settings) || raid_settings == nullptr)
        {
            report_once(kStageRaidSettingsNull, in_transition);
            return;
        }
        if (!eft_api::is_readable_address(raid_settings, sizeof(Il2CppObject)) || raid_settings->klass == nullptr)
        {
            report_once(kStageRaidSettingsNull, in_transition);
            return;
        }

        Il2CppObjectInstance raid_settings_instance(raid_settings);
        auto m_get_local = raid_settings_instance.get_method<bool (*)(Il2CppObject*)>("get_Local", 0);
        if (m_get_local == nullptr)
        {
            report_once(kStageGetLocalMissing, in_transition);
            return;
        }
        if (!m_get_local(raid_settings))
        {
            report_once(kStageNotLocal, in_transition);
            return;
        }

        *reinterpret_cast<int*>(reinterpret_cast<uint8_t*>(profile_status) + status_value_field->offset) = 0;
        report_once(kStageComplete, in_transition);
        // This session entered its raid through the transit patch: record it so the
        // raid-start guard can arm once the destination raid ACTUALLY started
        // (hk_local_raid_started). Arming here (mid-transit) is what made the
        // Transit -> Exfil -> Infil flow hard to test — the guard should only be
        // "set in stone" when the raid has genuinely started.
        g_raid_start_guard.transit_patched.store(true, std::memory_order_release);

        std::string location;
        if (FieldInfo* location_field = il2utils::resolve_field(profile_status->klass, "location"))
        {
            Il2CppString* raw = nullptr;
            if (read_guarded(profile_status, location_field->offset, raw))
                location = safe_string(raw);
        }
        std::string sid;
        if (FieldInfo* sid_field = il2utils::resolve_field(profile_status->klass, "sid"))
        {
            Il2CppString* raw = nullptr;
            if (read_guarded(profile_status, sid_field->offset, raw))
                sid = safe_string(raw);
        }
        logger::warn(std::format(
            "[transitdbg] run_keep_profile_status_free: captured ProfileStatus.status {} -> Free(0) (location='{}' sid='{}') so <Run>d__201 cannot reach the 0x182B8EE17 NotImplementedException landing",
            status, location, sid));
    }

    // hk_handle_exceptions: TasksExtensions.HandleExceptions(Task[, object]) is the
    // swallow point for the transit-path task - Run d__201 is launched through it and
    // the 2026-09-22 evidence chain ends there. Hooking it names an actual fault with
    // its real exception type and message, which beats probing undocumented builder
    // struct internals. Healthy tasks log nothing.
    using handle_exceptions_sig = void (*)(Il2CppObject*, Il2CppObject*);

    inline void log_seh_trip(const char* tag) {
        logger::warn(std::format("[transitdbg] {}: SEH caught a fault while dumping the task", tag));
    }

    inline void log_faulted_task_body(const char* tag, Il2CppObject* task) {
        if (task == nullptr || !eft_api::is_readable_address(task, sizeof(Il2CppObject)) || task->klass == nullptr)
            return;
        Il2CppObject* exception = nullptr;
        if (auto get_exception = Il2CppObjectInstance(task).get_method<Il2CppObject* (*)(Il2CppObject*)>("get_Exception", 0))
            exception = get_exception(task);
        if (exception == nullptr || !eft_api::is_readable_address(exception, sizeof(Il2CppObject)) || exception->klass == nullptr)
            return; // not faulted - normal completion path, stay silent

        Il2CppObject* base_exception = exception;
        if (auto get_base = Il2CppObjectInstance(exception).get_method<Il2CppObject* (*)(Il2CppObject*)>("GetBaseException", 0))
        {
            Il2CppObject* inner = get_base(exception);
            if (inner != nullptr && eft_api::is_readable_address(inner, sizeof(Il2CppObject)) && inner->klass != nullptr)
                base_exception = inner;
        }
        std::string message;
        if (auto get_message = Il2CppObjectInstance(base_exception).get_method<Il2CppString* (*)(Il2CppObject*)>("get_Message", 0))
        {
            Il2CppString* raw = get_message(base_exception);
            if (raw != nullptr && eft_api::is_readable_address(raw, sizeof(Il2CppString)))
                message = safe_string(raw);
        }
        logger::warn(std::format("[transitdbg] {} FAULT: task=0x{:x} exception {}('{}')",
            tag, reinterpret_cast<uintptr_t>(task), safe_class_name(base_exception), message));
    }

    // SEH-safe wrapper (no C++ objects in this frame; see quest_esp.h convention).
    inline void log_faulted_task(const char* tag, Il2CppObject* task) {
        __try
        {
            log_faulted_task_body(tag, task);
        } __except (EXCEPTION_EXECUTE_HANDLER)
        {
            log_seh_trip(tag);
        }
    }

    inline handle_exceptions_sig o_handle_exceptions = nullptr;
    inline handle_exceptions_sig o_handle_exceptions_with_message = nullptr;
    using handle_finished_task_sig = void (*)(Il2CppObject*);
    using handle_finished_task_msg_sig = void (*)(Il2CppObject*, Il2CppObject*);
    inline handle_finished_task_sig o_handle_finished_task = nullptr;
    inline handle_finished_task_msg_sig o_handle_finished_task_with_message = nullptr;

    // HandleExceptions is the LAUNCH-time path: the same handleFinishedTask callback is
    // registered as a task continuation, and the 13:37 retest showed zero FAULT lines
    // even though Run d__201 provably faulted (exit -2 via SetException) - at launch the
    // task is never faulted yet. HandleFinishedTask(Task[, object]) is that continuation
    // itself: it runs AFTER completion, so a real fault is visible here.
    inline void hk_handle_finished_task(Il2CppObject* task) {
        log_faulted_task("HandleFinishedTask", task);
        o_handle_finished_task(task);
    }

    inline void hk_handle_finished_task_with_message(Il2CppObject* task, Il2CppObject* error_message) {
        log_faulted_task("HandleFinishedTask(msg)", task);
        o_handle_finished_task_with_message(task, error_message);
    }

    static inline void hk_handle_exceptions(Il2CppObject* task, Il2CppObject* error_message) {
        log_faulted_task("HandleExceptions", task);
        o_handle_exceptions(task, error_message);
    }

    static inline void hk_handle_exceptions_with_message(Il2CppObject* task, Il2CppObject* error_message) {
        log_faulted_task("HandleExceptions(msg)", task);
        o_handle_exceptions_with_message(task, error_message);
    }

    // hk_run_move_next: d__201, TarkovApplication's main dispatch loop. Its transit
    // block (ISIL ops 2060-2236) is the in-session transit restart path: gate on
    // TransitionStatus.InTransition [TA+0x210] -> TryGetLocationById -> MarkAsTransit ->
    // IsLocalTransitHop -> StartOnlineTransitMatching (awaited). The stuck sessions show
    // this machine never re-entering after ComebackToMainMenu completes, so per-resume
    // TransitionStatus dumps + the pending awaiter scan name what the loop is parked on.
    // Enter-state gating keeps the dumps off YieldAwaiter spin iterations.
    inline void hk_run_move_next(void* sm) {
    // Zoned and profiled as a per-ITERATION hook, not a per-frame one -- see the
    // shared comment on begin_move_next() below for the reasoning and the numbers.
        TA_ZONE_N("always_on::hk_run_move_next");        static sm_hook_ctx ctx;
        static sm_transition_state trans;

        int state = -9999;
        const sm_view view = begin_move_next("Run", ctx, sm, state);
        if (view.owner != nullptr && state != trans.last_enter)
            dump_ta_state(view.owner, "Run:resume");

        run_keep_profile_status_free(view);

        o_run_move_next(sm);

        const int exit_state = sm_state(ctx.sm_klass, view.base);
        // A first entry (state -1) that exits -2 is ambiguous (completion vs the
        // NotImplementedException landing); builder-internal layouts are undocumented,
        // so the HandleExceptions hook names a real fault instead. When InTransition is
        // set and the machine exits -2, say so once so the log states the suspicion.
        if (state == -1 && exit_state == -2 && ta_is_valid(view.owner))        {
            FieldInfo* ts_field = il2utils::resolve_field(view.owner->klass, "<TransitionStatus>k__BackingField");
            bool in_transition = false;
            if (ts_field != nullptr)
                read_guarded(view.owner, ts_field->offset, in_transition);
            if (in_transition)
            {
                static bool logged_once = false;
                if (!logged_once)
                {
                    logged_once = true;
                    logger::warn("[transitdbg] Run.MoveNext: first entry exited -2 while InTransition=true (fault suspected; see HandleExceptions FAULT line and run_keep_profile_status_free state)");
                }
            }
        }

                // hk_run_move_next's extra dump rides on the SAME decision the shared
        // helper made, so it cannot drift from the transition line it accompanies.
        if (log_move_next_transition("Run", state, exit_state,
                trans.last_enter, trans.last_exit, trans.repeat))
        {
            dump_all_awaiter_fields("Run", ctx.sm_klass, view.base);
        }
    }

    // ------------------------------------------------------------------------
    // MOVED OUT (dead-code cleanup): hk_transit_point_move_next and its
    // o_transit_point_move_next pointer now live in
    // module/always_on_deprecated.h. That hook was defined here but never
    // registered in init(), so it never ran. It also dereferenced the
    // state-machine struct at hardcoded offsets with no readability guard,
    // and its own comments record a segfault while walking the Dictionary
    // field. A large amount of time went into the transit screen-hang
    // investigation that produced it; the reasoning is preserved in that
    // file rather than discarded with the code. Do not re-add it blind.
    // ------------------------------------------------------------------------

    inline bool hk_ta_is_local_transit_hop(Il2CppObject* instance) {
        // WHY THE OVERRIDE EXISTS, from ISIL rather than inference.
        // TarkovApplication_NestedType__Run_d__201.txt ISIL 2161-2187 is the ONLY call site of
        // this method in the entire game, and it reads:
        //
        //     2161  Call TarkovApplication.IsLocalTransitHop -> bool
        //     2173  ConditionalJump @b320, <that bool>     // true  -> skip the block
        //     2174  Move v5235, [_raidSettings]
        //     2183  CheckEqual v2770, [_raidSettings], 0
        //     2186  ConditionalJump @b459, v2770           // null  -> skip
        //     2187  NotImplemented "psrldq xmm1,8"        // the landing
        //
        // i.e. `if (!IsLocalTransitHop()) { if (_raidSettings != null) throw NotImplemented; }`.
        // Returning true is the only thing keeping <Run>d__201 off that landing, so the
        // override is load-bearing and stays. It was NOT a suspect in the 2026-10-04
        // transit-load investigation and the earlier guess that it was is recorded as wrong.
        //
        // The real body is not a constant, for the record: `mov rax,[rcx+228h]; cmp eax,1` then
        // either returns that field or tails into `_raidSettings.<method>(false)`. So we
        // permanently skip the _raidSettings call. It has always been so and the game has run,
        // which is why it is recorded rather than changed. (The ISIL's own type annotation for
        // field 0x228 is garbage -- d__239 reads it as `ShiftRight ... JsonType.EDateTime` --
        // so treat the native form as the truth and the ISIL type as noise.)
        //
        // ---------------------------------------------------------------------------------
        // AND IT IS THE ONLY REACHABLE "THIS IS A TRANSIT" SIGNAL IN THE GAME, which is what
        // the raid-start guard was missing. MEASURED 2026-10-04 over two sessions and four
        // <Run>d__201 invocations: this fired twice, 13:05:59 and 14:27:27, and both were
        // transit comebacks (`Run:resume InTransition=true location='bigmap'`). The two
        // menu-initiated starts, 13:00:19 and 14:20:56, both `InTransition=false`, never called
        // it. So arming HERE keeps the documented "menu-initiated starts stay 100% vanilla"
        // property, which arming on a weaker signal would have thrown away.
        //
        // WHY transit_patched WAS DEAD, since this is the second attempt at the same flag and
        // the first one is why nobody noticed. It was set at exactly one place, as a side effect
        // of run_keep_profile_status_free's ProfileStatus -> Free(0) patch: the store is at :1304
        // and the `status == 0` early return is at :1258, i.e. BELOW the return that skips it.
        // A transit EXFIL is precisely the case where the status is already Free(0), so the
        // store was unreachable on the only flow the guard exists for. That shape is unchanged
        // since the flag was introduced in f0ec04a7 (09-23 22:04, "broken again"), where the
        // return is at :1069-1072 and the store at :1117. It has therefore never armed, which
        // is why no log has ever contained "raid-start guard armed".
        //
        // WHY THAT WAS NEVER CAUGHT: SOLVED.md records the guard as SOLVED at lines 13, 99 and
        // 163, and line 99 claims "12:41-12:44 Streets trace confirms passthrough works
        // end-to-end". The passthrough rule only runs inside should_suppress, which needs the
        // window open, which needs armed -- but "no duplicate matching happened" is equally
        // consistent with a guard that never armed at all. The two states are indistinguishable
        // from a trace, so an inert mechanism passes the same test as a working one.
        //
        // ---------------------------------------------------------------------------------
        // DIAGNOSTIC 2026-10-04: the REAL answer, next to ours. See the note above on the real
        // body (`mov rax,[rcx+228h]; cmp eax,1`, then either return that field or TAIL INTO
        // `_raidSettings.<method>(false)`). Our unconditional `return true` therefore does
        // not merely assert a value the game might already hold -- it SKIPS that
        // `_raidSettings` call entirely, which the note above already records twice.
        //
        // Why it matters now: 9 menu-initiated raids loaded and 4 transit comebacks did not
        // (2026-10-04, measured from "Loading in at" to the first playable frame). On a menu
        // start the game's own answer is false and skipping the throw is exactly what we
        // want. On a transit comeback it may be TRUE -- and then we are discarding the
        // game's decision rather than agreeing with it, and the distinction has never been
        // in the log. This line is the only thing that settles it.
        //
        // SAFETY. Calling the original was checked before doing it: `_raidSettings` and
        // `get_RaidMode` are only ever READ here (:350-390), and the hooked `get_raidSettings`
        // is a TarkovApplication PROPERTY, not a RaidSettings method -- so the tail cannot
        // re-enter `modify_raid_settings` or any other hook of ours, and cannot mutate the
        // state this comparison is reading. It is still an unknown managed call on the game's
        // own thread, so it is wrapped: an exception escaping into <Run>d__201 would be a
        // behaviour change caused by a diagnostic, which is the failure mode this repo keeps
        // paying for.
        //
        // The RETURN VALUE IS UNCHANGED -- this observes, it does not experiment. We still
        // force true, because letting a real `false` reach the NotImplemented landing is a
        // different and much less safe test than reading what the game would have said.
        bool real_answer = false;
        bool real_answered = false;
        if (o_ta_is_local_transit_hop != nullptr) {
            try {
                real_answer = o_ta_is_local_transit_hop(instance);
                real_answered = true;
            } catch (...) {
                real_answered = false;
            }
        }

        const bool first = !g_raid_start_guard.transit_patched.exchange(true, std::memory_order_acq_rel);
        logger::debug(std::string("hk_ta_is_local_transit_hop; ret true")
            + (first ? " (transit_patched armed)" : " (transit_patched already set)"));

        // Once per DISTINCT answer, not once per call. <Run>d__201 spins during a transit --
        // that is why hk_run_move_next is zoned as a per-ITERATION boundary -- and a per-call
        // line here is how the 1,688-lines-per-minute transitdbg flood happened. Keying on the
        // pair also guarantees the interesting case is logged even if it is the common one:
        // if the real answer is constant, this prints once; if it flips mid-session, the flip
        // is exactly what needs recording.
        static int last_reported = -1;
        const int key = (real_answered ? 2 : 0) + (real_answer ? 1 : 0);
        if (key != last_reported) {
            last_reported = key;
            std::string verdict;
            if (!real_answered) {
                verdict = "could not read the original (hook pointer null, or it threw) -- "
                          "the comparison is unavailable, not evidence of agreement";
            } else if (real_answer) {
                verdict = "AGREE: the game would have returned true as well, so forcing true is "
                          "harmless here -- but our override still skips the _raidSettings "
                          "call its real body makes";
            } else {
                verdict = "DISAGREE: the game returned false and we override it. That override is "
                          "the only thing keeping <Run>d__201 off the NotImplemented landing, so "
                          "this cannot be relaxed without a different test.";
            }
            logger::debug("hk_ta_is_local_transit_hop: REAL="
                + std::string(!real_answered ? "<unavailable>" : (real_answer ? "true" : "false"))
                + " FORCED=true : " + verdict);
        }
        return true;
    }

    inline bool hk_rs_need_to_go_online_in_pve(Il2CppObject* instance) {
        logger::debug("hk_rs_need_to_go_online_in_pve; ret false");
        // Fresh PLAY flow starting: close any stale load window so this new session's
        // matching/create run untouched.
        raid_start_guard_disarm("fresh PLAY flow (need_to_go_online)");
        return false;
        //return o_rs_need_to_go_online_in_pve(instance);
    }

    inline bool hk_rs_need_to_go_offline_in_pve(Il2CppObject* instance) {
        logger::debug("hk_rs_need_to_go_offline_in_pve; ret true");
        return true;
        //return o_rs_need_to_go_offline_in_pve(instance);
    }

    // ===================== transit save-status diagnostics =====================
    // Post-raid flow seen during transit hangs:
    //   ShowTransitSaveWaitScreen (d__239) -> fade to black ->
    //   AwaitGameOverSaveStatusAsync (d__169, while(!received) await Task.Yield(), no
    //   timeout) -> ComebackToMainMenu (d__236). OnGameEnd (d__232) zeroes TransitionStatus
    //   and calls RaidSettings.ClearTransit whenever result != ExitStatus.Transit, which
    //   is what silently disables the transit branch in Run d__201.
    // If the server game-over-save RPC never arrives, the app parks behind the black
    // screen at d__169 with no way out. These hooks log where it parks; the two hotkey
    // actions dump state / force-unblock the wait.

    // hk_await_game_over_save_status_move_next: d__169. Re-entry with state==0 while
    // saveStatusReceived==false means the server RPC never arrived and the app is parked
    // here forever (the loop has no timeout).
    inline void hk_await_game_over_save_status_move_next(void* sm) {
    // Zoned because this hook is a per-ITERATION boundary, not a per-frame one: the
    // TarkovApplication state machine yields and resumes many times inside a single frame,
    // and during a transit it can spin. Nothing in the profile could say how often any of
    // these six fire or what they cost, which is why the 1,688-lines-per-minute transitdbg
    // flood had to be diagnosed by reading the log by hand.
    //
    // Cheap in normal play and bounded in a transit: always_on::read_guarded, which
    // sm_state() calls once per iteration, measured 21 calls/min in the 20-minute capture,
    // so the hook itself was near-idle outside a transit.
        TA_ZONE_N("always_on::hk_await_game_over_save_status");        static const Il2CppClass* sm_klass = nullptr;
        if (sm_klass == nullptr) sm_klass = resolve_sm_class("AwaitGameOverSaveStatusAsync");
        static bool logged_shape = false;
        static int poll_count = 0;

        const sm_view view = make_sm_view(sm_klass, sm, ta_klass());
        if (!logged_shape)
        {
            logged_shape = true;
            log_sm_shape("AwaitGameOverSaveStatus", sm_klass, sm, view);
        }

        const int state = sm_state(sm_klass, view.base);
        if (view.owner != nullptr) g_last_ta = view.owner;
        const bool received = ta_save_status_received(view.owner);
        ++poll_count;

        if (received || state != 0 || poll_count <= 3 || poll_count % 120 == 0)
        {
            logger::debug(std::format("[transitdbg] AwaitGameOverSaveStatus.MoveNext enter state={} polls={} received={}",
                state, poll_count, received));
            dump_ta_state(view.owner, "AwaitGameOverSaveStatus");
        }

        o_await_game_over_save_status_move_next(sm);
    }

    // hk_show_transit_save_wait_screen_move_next: d__239. Fades to black, then awaits
    // AwaitGameOverSaveStatusAsync.
    inline void hk_show_transit_save_wait_screen_move_next(void* sm) {
    // Zoned because this hook is a per-ITERATION boundary, not a per-frame one: the
    // TarkovApplication state machine yields and resumes many times inside a single frame,
    // and during a transit it can spin. Nothing in the profile could say how often any of
    // these six fire or what they cost, which is why the 1,688-lines-per-minute transitdbg
    // flood had to be diagnosed by reading the log by hand.
    //
    // Cheap in normal play and bounded in a transit: always_on::read_guarded, which
    // sm_state() calls once per iteration, measured 21 calls/min in the 20-minute capture,
    // so the hook itself was near-idle outside a transit.
        TA_ZONE_N("always_on::hk_show_transit_save_wait_screen");        static sm_hook_ctx ctx;
        int state = -9999;
        const sm_view view = begin_move_next("ShowTransitSaveWaitScreen", ctx, sm, state);
        logger::debug(std::format("[transitdbg] ShowTransitSaveWaitScreen.MoveNext enter state={}", state));
        dump_ta_state(view.owner, "ShowTransitSaveWaitScreen:enter");

        o_show_transit_save_wait_screen_move_next(sm);

        logger::debug(std::format("[transitdbg] ShowTransitSaveWaitScreen.MoveNext exit state={}",
            sm_state(ctx.sm_klass, view.base)));
    }

    // hk_on_game_end_move_next: d__232. result[0] == 5 (ExitStatus.Transit) keeps the
    // TransitionStatus; anything else zeroes it and calls RaidSettings.ClearTransit
    // (ISIL 669/672: ConditionalJump skips the clear block when result == 5).
    inline void hk_on_game_end_move_next(void* sm) {
    // Zoned because this hook is a per-ITERATION boundary, not a per-frame one: the
    // TarkovApplication state machine yields and resumes many times inside a single frame,
    // and during a transit it can spin. Nothing in the profile could say how often any of
    // these six fire or what they cost, which is why the 1,688-lines-per-minute transitdbg
    // flood had to be diagnosed by reading the log by hand.
    //
    // Cheap in normal play and bounded in a transit: always_on::read_guarded, which
    // sm_state() calls once per iteration, measured 21 calls/min in the 20-minute capture,
    // so the hook itself was near-idle outside a transit.
        TA_ZONE_N("always_on::hk_on_game_end");        static sm_hook_ctx ctx;
        int state = -9999;
        const sm_view view = begin_move_next("OnGameEnd", ctx, sm, state);

        int result_raw = -1;
        FieldInfo* result_field = ctx.sm_klass ? il2utils::resolve_field(ctx.sm_klass, "result") : nullptr;
        if (result_field != nullptr) read_guarded(view.base, result_field->offset, result_raw);
        Il2CppString* profile_id = nullptr;
        FieldInfo* profile_field = ctx.sm_klass ? il2utils::resolve_field(ctx.sm_klass, "profileId") : nullptr;
        if (profile_field != nullptr) read_guarded(view.base, profile_field->offset, profile_id);

        logger::debug(std::format(
            "[transitdbg] OnGameEnd.MoveNext enter state={} result[0]={} (5==Transit) profileId='{}'",
            state, result_raw, safe_string(profile_id)));
        dump_ta_state(view.owner, "OnGameEnd:enter");

        // Attribution for the 2026-10-04 capture: this hook measured 7479 ms in ONE
        // call on the stuck run, and nothing inside it was accounted for. This zone
        // separates the game's own MoveNext from our per-iteration resolve_field and
        // transitdbg logging -- the two candidates are unrelated bugs, and which one it
        // is decides who fixes it. TA_ZONE_N, so it costs nothing when Tracy is detached.
        { TA_ZONE_N("always_on::hk_on_game_end::orig"); o_on_game_end_move_next(sm); }

        logger::debug(std::format("[transitdbg] OnGameEnd.MoveNext exit state={}", sm_state(ctx.sm_klass, view.base)));
        dump_ta_state(view.owner, "OnGameEnd:exit");
    }

    // hk_comeback_to_main_menu_move_next: d__236. Return-to-menu path; waitForGameOverSaveStatus
    // tells whether it will wait for the save status again.
    inline void hk_comeback_to_main_menu_move_next(void* sm) {
    // Zoned because this hook is a per-ITERATION boundary, not a per-frame one: the
    // TarkovApplication state machine yields and resumes many times inside a single frame,
    // and during a transit it can spin. Nothing in the profile could say how often any of
    // these six fire or what they cost, which is why the 1,688-lines-per-minute transitdbg
    // flood had to be diagnosed by reading the log by hand.
    //
    // Cheap in normal play and bounded in a transit: always_on::read_guarded, which
    // sm_state() calls once per iteration, measured 21 calls/min in the 20-minute capture,
    // so the hook itself was near-idle outside a transit.
        TA_ZONE_N("always_on::hk_comeback_to_main_menu");        static sm_hook_ctx ctx;
        int state = -9999;
        const sm_view view = begin_move_next("ComebackToMainMenu", ctx, sm, state);

        bool wait_for_save = false;
        FieldInfo* wait_field = ctx.sm_klass ? il2utils::resolve_field(ctx.sm_klass, "waitForGameOverSaveStatus") : nullptr;
        if (wait_field != nullptr) read_guarded(view.base, wait_field->offset, wait_for_save);

        logger::debug(std::format(
            "[transitdbg] ComebackToMainMenu.MoveNext enter state={} waitForGameOverSaveStatus={}",
            state, wait_for_save));
        dump_ta_state(view.owner, "ComebackToMainMenu:enter");

        // Attribution for the 2026-10-04 capture: this hook measured 7479 ms in ONE
        // call on the stuck run, and nothing inside it was accounted for. This zone
        // separates the game's own MoveNext from our per-iteration resolve_field and
        // transitdbg logging -- the two candidates are unrelated bugs, and which one it
        // is decides who fixes it. TA_ZONE_N, so it costs nothing when Tracy is detached.
        { TA_ZONE_N("always_on::hk_comeback_to_main_menu::orig"); o_comeback_to_main_menu_move_next(sm); }

        logger::debug(std::format("[transitdbg] ComebackToMainMenu.MoveNext exit state={}",
            sm_state(ctx.sm_klass, view.base)));
    }

    // hk_prepare_game_job_move_next: d__183. The transit-comeback park resolves here:
    // d__236 state 5 awaits PrepareGame (d__151), which awaits PrepareGameJob; nothing
    // upstream resumes until this machine completes, so its last suspended state names
    // the operation the comeback is stuck behind. Identical consecutive transitions are
    // suppressed because the YieldAwaiter states repeat while the machine spins.
    inline void hk_prepare_game_job_move_next(void* sm) {
    // See hk_run_move_next for why this hook is zoned; same reasoning, same numbers.
        TA_ZONE_N("always_on::hk_prepare_game_job");        static sm_hook_ctx ctx;
        static sm_transition_state trans;

        int state = -9999;
        const sm_view view = begin_move_next("PrepareGameJob", ctx, sm, state);

        // Attribution for the 2026-10-04 capture: this hook measured 7479 ms in ONE
        // call on the stuck run, and nothing inside it was accounted for. This zone
        // separates the game's own MoveNext from our per-iteration resolve_field and
        // transitdbg logging -- the two candidates are unrelated bugs, and which one it
        // is decides who fixes it. TA_ZONE_N, so it costs nothing when Tracy is detached.
        { TA_ZONE_N("always_on::hk_prepare_game_job::orig"); o_prepare_game_job_move_next(sm); }

        const int exit_state = sm_state(ctx.sm_klass, view.base);
        dump_pending_awaiter("PrepareGameJob", ctx.sm_klass, view.base);
        log_move_next_transition("PrepareGameJob", state, exit_state,
            trans.last_enter, trans.last_exit, trans.repeat);
    }

    // hk_apply_game_over_save_status: arrival of the server save-status RPC. ErrorCode != 0
    // takes the destructive branch: TransitionStatus = default + RaidSettings.ClearTransit
    // (TarkovApplication.txt ISIL 58-82).
    inline void hk_apply_game_over_save_status(Il2CppObject* instance, Il2CppObject* message) {
        g_last_ta = instance;

        int error_code = -1;
        bool has_aggressor = false;
        int experience = 0;
        if (message != nullptr && eft_api::is_readable_address(message, sizeof(Il2CppObject)) && message->klass != nullptr)
        {
            FieldInfo* error_field = il2utils::resolve_field(message->klass, "<ErrorCode>k__BackingField");
            if (error_field) read_guarded(message, error_field->offset, error_code);
            FieldInfo* aggressor_field = il2utils::resolve_field(message->klass, "<HasAggressor>k__BackingField");
            if (aggressor_field) read_guarded(message, aggressor_field->offset, has_aggressor);
            FieldInfo* exp_field = il2utils::resolve_field(message->klass, "<Experience>k__BackingField");
            if (exp_field) read_guarded(message, exp_field->offset, experience);
        }

        logger::warn(std::format(
            "[transitdbg] ApplyGameOverSaveStatus ErrorCode={} hasAggressor={} experience={} (ErrorCode!=0 zeroes TransitionStatus + ClearTransit)",
            error_code, has_aggressor, experience));

        o_apply_game_over_save_status(instance, message);

        dump_ta_state(instance, "ApplyGameOverSaveStatus:after");
    }

    // hk_fail_game_over_save_status: local failure path (e.g. disconnect) also releases
    // the d__169 wait, but the save is lost.
    inline void hk_fail_game_over_save_status(Il2CppObject* instance, Il2CppString* reason) {
        g_last_ta = instance;
        logger::warn(std::format("[transitdbg] FailGameOverSaveStatus reason='{}'",
            safe_string(reason)));
        o_fail_game_over_save_status(instance, reason);
        dump_ta_state(instance, "FailGameOverSaveStatus:after");
    }

    // Manual probe: force-release the GameOverSaveStatus wait to see whether the flow
    // resumes (diagnostic hammer, bound from the hotkeys panel).
    inline void probe_force_save_status_received() {
        Il2CppObject* ta = g_last_ta;
        if (!ta_is_valid(ta))
        {
            logger::warn(std::format("[transitdbg] force_save_status: no valid TarkovApplication captured (ta=0x{:x})",
                reinterpret_cast<uintptr_t>(ta)));
            return;
        }

        FieldInfo* received_field =
            il2utils::resolve_field(ta->klass, "<GameOverSaveStatusReceived>k__BackingField");
        if (received_field == nullptr)
        {
            logger::warn("[transitdbg] force_save_status: <GameOverSaveStatusReceived> not found");
            return;
        }

        const auto address = reinterpret_cast<uintptr_t>(ta) + received_field->offset;
        if (!eft_api::is_readable_address(reinterpret_cast<const void*>(address), sizeof(bool)))
        {
            logger::warn(std::format("[transitdbg] force_save_status: field address 0x{:x} not readable", address));
            return;
        }
        *reinterpret_cast<bool*>(address) = true;
        logger::warn("[transitdbg] force_save_status: GameOverSaveStatusReceived forced to true");
        dump_ta_state(ta, "force_save_status");
    }

    inline void init() {
        // set assembly csharp image
        while (!il2utils::resolve_image("Assembly-CSharp.dll"))
        {
            Sleep(100);
        }
        assembly_csharp = il2utils::resolve_image("Assembly-CSharp.dll");

        // always offline raid and location unlock
        const Il2CppClass* match_maker_selection_location_screen = il2utils::resolve_class(
            assembly_csharp, "EFT.UI.Matchmaker", "MatchMakerSelectionLocationScreen");
        il2utils::hook_method(match_maker_selection_location_screen, "DisplayLocation", 1,
            hk_display_location,
            &o_display_location);

        // Transit resolves its target directly, bypassing the selection screen.
        // Apply the same PvE-local flags here so destinations such as Icebreaker
        // cannot fall back to the online matchmaking route.
        const Il2CppClass* client_transit_controller = il2utils::resolve_class(
            assembly_csharp, "EFT", "ClientTransitController");
        il2utils::hook_method(client_transit_controller, "TryGetLocation", 2,
            hk_try_get_location,
            &o_try_get_location);

        const Il2CppClass* tarkov_application = il2utils::resolve_class(
            assembly_csharp, "EFT", "TarkovApplication");
        il2utils::hook_async_method(tarkov_application, "OnReadyToStartMatchingAsync", 0,
            hk_on_ready_to_start_matching_async,
            &o_on_ready_to_start_matching_async);
        il2utils::hook_async_method(tarkov_application, "LocalGameCreate", 5,
            hk_local_game_create,
            &o_local_game_create);
        il2utils::hook_async_method(tarkov_application, "LocalGameMatching", 2,
            hk_local_game_matching,
            &o_local_game_matching);
        il2utils::hook_async_method(tarkov_application, "StartOnlineTransitMatching", 0,
            hk_start_online_transit_matching,
            &o_start_online_transit_matching);
        il2utils::hook_async_method(tarkov_application, "Run", 4,
            hk_run_move_next,
            &o_run_move_next);
        il2utils::hook_method(tarkov_application, "TryGetLocationById", 2,
            hk_try_get_location_by_id,
            &o_try_get_location_by_id);
        il2utils::hook_method(tarkov_application, "IsLocalTransitHop", 0,
            hk_ta_is_local_transit_hop,
            &o_ta_is_local_transit_hop);

        // Transit save-status diagnostics: the game parks behind the black screen when the
        // server game-over-save RPC never completes. These hooks expose where it parks.
        il2utils::hook_async_method(tarkov_application, "AwaitGameOverSaveStatusAsync", 0,
            hk_await_game_over_save_status_move_next,
            &o_await_game_over_save_status_move_next);
        il2utils::hook_async_method(tarkov_application, "ShowTransitSaveWaitScreen", 0,
            hk_show_transit_save_wait_screen_move_next,
            &o_show_transit_save_wait_screen_move_next);
        il2utils::hook_async_method(tarkov_application, "OnGameEnd", 4,
            hk_on_game_end_move_next,
            &o_on_game_end_move_next);
        il2utils::hook_async_method(tarkov_application, "ComebackToMainMenu", 2,
            hk_comeback_to_main_menu_move_next,
            &o_comeback_to_main_menu_move_next);
        il2utils::hook_async_method(tarkov_application, "PrepareGameJob", 0,
            hk_prepare_game_job_move_next,
            &o_prepare_game_job_move_next);
        il2utils::hook_method(tarkov_application, "ApplyGameOverSaveStatus", 1,
            hk_apply_game_over_save_status,
            &o_apply_game_over_save_status);
        il2utils::hook_method(tarkov_application, "FailGameOverSaveStatus", 1,
            hk_fail_game_over_save_status,
            &o_fail_game_over_save_status);

        // Swallow-point visibility: any faulted task the game "handles" (Run d__201's
        // transit restart included) logs its exception type+message here.
        // HandleExceptions* fire at LAUNCH (task never faulted yet); HandleFinishedTask*
        // is the registered continuation that runs at COMPLETION, where a real fault is
        // observable - the 13:37 retest proved the completion-side hook is required.
        if (const Il2CppClass* tasks_extensions = il2utils::resolve_class(assembly_csharp, "", "TasksExtensions"))
        {
            il2utils::hook_method(tasks_extensions, "HandleExceptions", 1,
                hk_handle_exceptions, &o_handle_exceptions);
            il2utils::hook_method(tasks_extensions, "HandleExceptions", 2,
                hk_handle_exceptions_with_message, &o_handle_exceptions_with_message);
            il2utils::hook_method(tasks_extensions, "HandleFinishedTask", 1,
                hk_handle_finished_task, &o_handle_finished_task);
            il2utils::hook_method(tasks_extensions, "HandleFinishedTask", 2,
                hk_handle_finished_task_with_message, &o_handle_finished_task_with_message);
        }

        // Temporary diagnostic binds (unbound by default, set them in the hotkeys panel):
        // dump the captured TarkovApplication state / force-release the save-status wait.
        hotkeys::add_action("debug.dump_ta_state", "Dump TarkovApplication state",
            hotkeys::section::exploits,
            []() { dump_ta_state(g_last_ta, "hotkey"); });
        hotkeys::add_action("debug.force_save_status", "Force GameOverSaveStatus received",
            hotkeys::section::exploits,
            []() { probe_force_save_status_received(); });

        // offline transits
        const Il2CppClass* transit_controller = il2utils::resolve_class(
            assembly_csharp, "EFT", "LocalTransitController");
        il2utils::hook_method(transit_controller, "Transit", 5,
            hk_transit,
            &o_transit);

        // The transition's session can clone/rewrite LocalRaidSettings after
        // LocalTransitController.Transit has returned. Hook the final local
        // launch entry point as well so Icebreaker cannot revert to online.
        const Il2CppClass* backend_session = il2utils::resolve_class(
            assembly_csharp, "EFT", "EftClientBackendSession");
        il2utils::hook_method(backend_session, "LocalRaidStarted", 1,
            hk_local_raid_started,
            &o_local_raid_started);

        const Il2CppClass* raid_settings = il2utils::resolve_class(
            assembly_csharp, "EFT", "RaidSettings");
        il2utils::hook_method(raid_settings, "NeedToGoOnlineInPve", 1,
            hk_rs_need_to_go_online_in_pve,
            &o_rs_need_to_go_online_in_pve);
        il2utils::hook_method(raid_settings, "NeedToGoOfflineInPve", 1,
            hk_rs_need_to_go_offline_in_pve,
            &o_rs_need_to_go_offline_in_pve);

        // =======================================================

        logger::info("Always-Offline module loaded.");
    }
} // namespace always_on
