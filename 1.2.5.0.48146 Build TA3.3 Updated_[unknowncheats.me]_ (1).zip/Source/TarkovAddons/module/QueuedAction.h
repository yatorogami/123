#pragma once

#include <Windows.h>

// A one-shot action requested by the UI and consumed only by the game thread.
// It prevents duplicate clicks from queuing repeated game mutations in the same
// frame while keeping each module's actual action implementation unchanged.
class QueuedAction
{
  public:
    bool request(const bool allowed, const ULONGLONG cooldown_ms = 150);

    bool take(const bool allowed);

    [[nodiscard]] bool pending() const;

    void clear();

  private:
    bool pending_ = false;
    ULONGLONG last_request_ms_ = 0;
};
