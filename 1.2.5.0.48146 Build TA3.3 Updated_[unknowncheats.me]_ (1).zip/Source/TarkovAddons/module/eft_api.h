#pragma once
#include <algorithm>
#include <atomic>
#include <cctype>
#include <chrono>
#include <cmath>
#include <cstring>
#include <format>
#include <functional>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "../il2cpp/unity.h"
#include "../il2cpp/il2utils.h"
#include "../il2cpp/Il2CppObjectInstance.h"
#include "../il2cpp/exports.h"
#include "../gui/menu/menu.h"
#include "optics_lens_pipeline.h"
#include "game_state.h"
#include "item_categories.h"
#include "../util/tracy_bridge.h"

#ifndef TARKOV_MONGO_ID_DEFINED
#define TARKOV_MONGO_ID_DEFINED
struct mongo_id
{
    unsigned int time_stamp;
    unsigned long long counter;
    void* string_id;
};
#endif

namespace eft_api {
    using ObjPtr = Il2CppObject*;
    using StrPtr = Il2CppString*;

    inline bool is_bot_corpse_loot(Il2CppObject* loot_obj, Il2CppObject* item_obj);

    enum class npc_kind : char {
        pmc,
        scav,
        boss,
        guard,
        cultist,
        raider,
        defector, // VSRF / military (ScavRole/VSRF)
        civilian, // peaceful civilians (ScavRole/Civilian)
        black_division,
        btr,
    };

    inline constexpr int wild_spawn_shooter_btr = 46;
    inline constexpr int wild_spawn_black_division = 68;
    inline constexpr int wild_spawn_boss_bully_black_div = 77;
    inline constexpr int wild_spawn_follower_bully_black_div = 78;
    inline constexpr int wild_spawn_pmc_bot_black_div = 79;
    // 46221 WildSpawnType — military (VSRF) + peaceful
    inline constexpr int wild_spawn_vsrf = 69;
    inline constexpr int wild_spawn_vsrf_sniper = 70;
    inline constexpr int wild_spawn_vsrf_fight = 73;
    inline constexpr int wild_spawn_civilian = 74;
    inline constexpr int wild_spawn_peacemaker = 50;

    // Per-(klass, field name) memoization for hot reflection paths (workstream audit
    // 09-25: per-item resolve_field walks dominated the loot scan). Class layout is fixed
    // for the process lifetime, so a cached FieldInfo* — including a NOT_FOUND marker —
    // stays valid. The name must be a string literal (only its pointer is compared).
    // Only for per-item hot paths; cold/one-shot call sites keep plain resolve_field.
    //
    // SATURATION IS A CACHE MISS, NOT A MISSING FIELD. The table is process-wide and
    // has no eviction, so it fills after a few hundred distinct (klass, name) pairs —
    // and the per-item loot lookups alone (StackObjectsCount/StackMaxSize/QuestItem/
    // <_id>k__BackingField, one key per concrete Item/ItemTemplate class) get there
    // early in any raid. It used to `return nullptr` on a full table, which is
    // indistinguishable from "this class has no such field" and silently disabled
    // every UNSEEN key from that point on. That is the Item Editor / Weapon Builder
    // regression of 2026-09-27: `try_get_field_object(item, "Repairable"/"Armor"/
    // "Buff"/"Components")` and `try_get_array_field(item, "Slots"/"Grids")` all read
    // through here, so nested-object traversal returned null and
    // restore_durability / apply_enchantment reported nothing found. Correctness
    // therefore never depends on the table having room: a full table resolves
    // uncached, exactly as this did before the memo existed.
    inline const FieldInfo* cached_field(const Il2CppClass* klass, const char* field_name) {
        if (!klass || !field_name) return nullptr;
        struct entry
        {
            const void* klass_key = nullptr;
            const char* name_key = nullptr;
            const FieldInfo* field = nullptr;
        };
        static constexpr size_t k_slots = 1024;
        static entry slots[k_slots] = {};
        static const FieldInfo* const not_found = reinterpret_cast<const FieldInfo*>(1);

        // Direct-mapped slots: hash of (klass, name-literal) -> slot, linear probe on
        // collision. All call sites pass string literals, so pointer identity is stable.
        const uintptr_t hash = (reinterpret_cast<uintptr_t>(klass) >> 4)
            ^ (reinterpret_cast<uintptr_t>(field_name) >> 4);
        const size_t start = static_cast<size_t>(hash) % k_slots;
        size_t insert_slot = k_slots; // first empty slot seen while probing

        for (size_t i = 0; i < k_slots; ++i)
        {
            const size_t idx = (start + i) % k_slots;
            entry& e = slots[idx];
            if (!e.klass_key && !e.name_key)
            {
                if (insert_slot == k_slots) insert_slot = idx;
                break; // empty slot: key was never cached
            }
            if (e.klass_key == klass && e.name_key == field_name)
                return e.field == not_found ? nullptr : e.field;
        }

        if (insert_slot == k_slots)
        {
            // Table full of other keys. Fall THROUGH to the real resolver rather than
            // reporting a phantom missing field. Slower (this is the pre-memo cost) but
            // correct, and it is the only behaviour that is correct in every state.
            // Reported once so a table too small for the session's key count is visible
            // rather than inferred from a feature quietly doing nothing.
            static bool s_reported_full = false;
            if (!s_reported_full)
            {
                s_reported_full = true;
                logger::warn(std::format(
                    "cached_field: memo table full ({} slots) — resolving uncached. "
                    "Harmless for correctness; raise k_slots if this repeats.",
                    k_slots));
            }
            return il2utils::resolve_field(klass, field_name);
        }
        const FieldInfo* resolved = il2utils::resolve_field(klass, field_name);
        slots[insert_slot] = {klass, field_name, resolved ? resolved : not_found};
        return resolved;
    }

    inline Il2CppObject* try_get_field_object(Il2CppObject* obj, const char* field_name) {
        if (!obj || !obj->klass) return nullptr;
        const FieldInfo* field = cached_field(obj->klass, field_name);
        if (!field) return nullptr;
        return *reinterpret_cast<Il2CppObject**>(reinterpret_cast<UINT64>(obj) + field->offset);
    }

    inline int try_get_field_int(Il2CppObject* obj, const char* field_name) {
        if (!obj || !obj->klass) return -1;
        const FieldInfo* field = cached_field(obj->klass, field_name);
        if (!field) return -1;
        return *reinterpret_cast<int*>(reinterpret_cast<UINT64>(obj) + field->offset);
    }

    inline int get_profile_side(Il2CppObject* profile) {
        Il2CppObject* info = try_get_field_object(profile, "Info");
        if (!info) return -1;
        return try_get_field_int(info, "Side");
    }

    inline int get_wild_spawn_role(Il2CppObject* profile) {
        if (!profile) return -1;

        // Cached per profile, and the key is what makes the answer a constant: the
        // wild-spawn role is set at spawn and cannot change during a raid, so the
        // walk below -- Info -> Settings -> Role, with two fallback field names, so
        // up to six cached_field lookups and three dereferences -- is repeated work.
        //
        // THREAD_LOCAL, and that is a correctness requirement rather than a style
        // choice. This is called from the game thread
        // (AimbotModule::gameworld_update) AND the render thread
        // (build_player_label, from EspModule::draw_overlay). A shared map would be a
        // data race whose failure mode is a WRONG role, not a lost count. That is
        // exactly why probe_memo_stats() being a plain counter is defensible and this
        // is not.
        //
        // Only SUCCESSES are cached, for the policy il2utils::resolve_field gives for
        // the same choice: a -1 can mean "not initialised yet", which would resolve
        // later, and caching the failure would pin it for the rest of the raid.
        static thread_local std::unordered_map<const Il2CppObject*, int> s_roles;
        if (const auto cached = s_roles.find(profile); cached != s_roles.end())
            return cached->second;

        Il2CppObject* info = try_get_field_object(profile, "Info");
        if (!info) return -1;

        Il2CppObject* settings = try_get_field_object(info, "Settings");
        if (!settings) settings = try_get_field_object(info, "<Settings>k__BackingField");
        if (!settings) settings = try_get_field_object(info, "profileInfoSettingsClass");
        if (!settings) return -1;

        const int role = try_get_field_int(settings, "Role");
        if (role >= 0) s_roles.emplace(profile, role);
        return role;
    }

    struct health_value
    {
        float current = 0.f;
        float maximum = 0.f;
    };

    // EFT.HealthSystem.ValueStruct — dump-verified 20 bytes
    struct value_struct
    {
        float current = 0.f;
        float maximum = 0.f;
        float minimum = 0.f;
        float over_damage_received_multiplier = 0.f;
        float environment_damage_multiplier = 0.f;
    };

    struct player_label
    {
        std::wstring prefix_wide;
        std::string prefix_utf8;
        std::string name_utf8;
        std::wstring text_wide;
        std::string text_utf8;
        bool show_name_line = false;
        npc_kind kind = npc_kind::scav;
    };

    inline std::string wstring_to_utf8(const std::wstring& input) {
        if (input.empty()) return {};
        const int size = WideCharToMultiByte(CP_UTF8, 0, input.data(), static_cast<int>(input.size()),
            nullptr, 0, nullptr, nullptr);
        if (size <= 0) return {};
        std::string out(static_cast<size_t>(size), '\0');
        WideCharToMultiByte(CP_UTF8, 0, input.data(), static_cast<int>(input.size()),
            out.data(), size, nullptr, nullptr);
        return out;
    }

    static std::unordered_map<wchar_t, std::string> converted_letters =
        {
            {L'\u0430', "a"}, {L'\u0431', "b"}, {L'\u0432', "v"}, {L'\u0433', "g"}, {L'\u0434', "d"},
            {L'\u0435', "e"}, {L'\u0451', "yo"}, {L'\u0436', "zh"}, {L'\u0437', "z"}, {L'\u0438', "i"},
            {L'\u0439', "j"}, {L'\u043a', "k"}, {L'\u043b', "l"}, {L'\u043c', "m"}, {L'\u043d', "n"},
            {L'\u043e', "o"}, {L'\u043f', "p"}, {L'\u0440', "r"}, {L'\u0441', "s"}, {L'\u0442', "t"},
            {L'\u0443', "u"}, {L'\u0444', "f"}, {L'\u0445', "h"}, {L'\u0446', "c"}, {L'\u0447', "ch"},
            {L'\u0448', "sh"}, {L'\u0449', "sch"}, {L'\u044a', "j"}, {L'\u044b', "i"}, {L'\u044c', "j"},
            {L'\u044d', "e"}, {L'\u044e', "yu"}, {L'\u044f', "ya"},
            {L'\u0410', "A"}, {L'\u0411', "B"}, {L'\u0412', "V"}, {L'\u0413', "G"}, {L'\u0414', "D"},
            {L'\u0415', "E"}, {L'\u0401', "Yo"}, {L'\u0416', "Zh"}, {L'\u0417', "Z"}, {L'\u0418', "I"},
            {L'\u0419', "J"}, {L'\u041a', "K"}, {L'\u041b', "L"}, {L'\u041c', "M"}, {L'\u041d', "N"},
            {L'\u041e', "O"}, {L'\u041f', "P"}, {L'\u0420', "R"}, {L'\u0421', "S"}, {L'\u0422', "T"},
            {L'\u0423', "U"}, {L'\u0424', "F"}, {L'\u0425', "H"}, {L'\u0426', "C"}, {L'\u0427', "Ch"},
            {L'\u0428', "Sh"}, {L'\u0429', "Sch"}, {L'\u042a', "J"}, {L'\u042b', "I"}, {L'\u042c', "J"},
            {L'\u042d', "E"}, {L'\u042e', "Yu"}, {L'\u042f', "Ya"},
            {L'\u03b1', "a"}, {L'\u03b2', "b"}, {L'\u03b3', "g"}, {L'\u03b4', "d"}, {L'\u03b5', "e"},
            {L'\u03b6', "z"}, {L'\u03b7', "i"}, {L'\u03b8', "th"}, {L'\u03b9', "i"}, {L'\u03ba', "k"},
            {L'\u03bb', "l"}, {L'\u03bc', "m"}, {L'\u03bd', "n"}, {L'\u03be', "x"}, {L'\u03bf', "o"},
            {L'\u03c0', "p"}, {L'\u03c1', "r"}, {L'\u03c2', "s"}, {L'\u03c3', "s"}, {L'\u03c4', "t"},
            {L'\u03c5', "y"}, {L'\u03c6', "f"}, {L'\u03c7', "ch"}, {L'\u03c8', "ps"}, {L'\u03c9', "o"},
            {L'\u0391', "A"}, {L'\u0392', "B"}, {L'\u0393', "G"}, {L'\u0394', "D"}, {L'\u0395', "E"},
            {L'\u0396', "Z"}, {L'\u0397', "I"}, {L'\u0398', "Th"}, {L'\u0399', "I"}, {L'\u039a', "K"},
            {L'\u039b', "L"}, {L'\u039c', "M"}, {L'\u039d', "N"}, {L'\u039e', "X"}, {L'\u039f', "O"},
            {L'\u03a0', "P"}, {L'\u03a1', "R"}, {L'\u03a3', "S"}, {L'\u03a4', "T"}, {L'\u03a5', "Y"},
            {L'\u03a6', "F"}, {L'\u03a7', "Ch"}, {L'\u03a8', "Ps"}, {L'\u03a9', "O"}};

    inline std::string to_display_utf8(const std::wstring& input) {
        return wstring_to_utf8(input);
    }

    inline std::string to_display_utf8(const Il2CppString* str) {
        if (!str) return {};
        return wstring_to_utf8(il2utils::conv_wstring(str));
    }

    inline std::string to_english(const std::wstring& input) {
        std::stringstream out;
        for (const wchar_t c : input)
        {
            if (converted_letters.contains(c))
            {
                out << converted_letters.at(c);
                continue;
            }

            if (c <= 0x7F)
            {
                out << static_cast<char>(c);
                continue;
            }

            wchar_t single[] = {c, L'\0'};
            out << wstring_to_utf8(single);
        }
        return out.str();
    }

    // wstring_contains() was removed: no callers in either project. Consumers
    // call std::wstring::find directly.
    struct wild_spawn_api
    {
        bool ready = false;
        bool (*is_boss)(int) = nullptr;
        bool (*is_follower)(int) = nullptr;
        bool (*is_ex_usec)(int) = nullptr;
        bool (*is_vsrf)(int) = nullptr;
        bool (*is_pmc_bot)(int) = nullptr;
        bool (*is_sectant)(int) = nullptr;
        Il2CppString* (*get_scav_role_key)(int) = nullptr;
        Il2CppString* (*localized)(Il2CppString*, int) = nullptr;
    };

    inline wild_spawn_api& wild_spawn_methods() {
        static wild_spawn_api api{};
        if (api.ready) return api;

        static auto* assembly = il2utils::resolve_image("Assembly-CSharp.dll");
        if (!assembly) return api;

        if (const Il2CppClass* ext = il2utils::resolve_class(assembly, "", "WildSpawnTypeExtension"))
        {
            api.is_boss = il2utils::get_method<bool (*)(int)>(ext, "IsBoss", 1);
            api.is_follower = il2utils::get_method<bool (*)(int)>(ext, "IsFollower", 1);
            api.is_ex_usec = il2utils::get_method<bool (*)(int)>(ext, "IsExUsec", 1);
            api.is_vsrf = il2utils::get_method<bool (*)(int)>(ext, "IsVSRF", 1);
            api.is_pmc_bot = il2utils::get_method<bool (*)(int)>(ext, "IsPmcBot", 1);
            api.is_sectant = il2utils::get_method<bool (*)(int)>(ext, "IsSectant", 1);
            api.get_scav_role_key = il2utils::get_method<Il2CppString* (*)(int)>(ext, "GetScavRoleKey", 1);
        }

        if (const Il2CppClass* loc = il2utils::resolve_class(assembly, "EFT", "LocalizationExtensions"))
            api.localized = il2utils::get_method<Il2CppString* (*)(Il2CppString*, int)>(loc, "Localized", 2);

        api.ready = api.get_scav_role_key != nullptr && api.localized != nullptr;
        return api;
    }

    inline bool is_black_division_role(const int role) {
        return role == wild_spawn_black_division
            || role == wild_spawn_boss_bully_black_div
            || role == wild_spawn_follower_bully_black_div
            || role == wild_spawn_pmc_bot_black_div;
    }

    // VSRF / military — dump 69/70/73 + IsVSRF extension.
    inline bool is_vsrf_role_by_enum(const int role) {
        return role == wild_spawn_vsrf
            || role == wild_spawn_vsrf_sniper
            || role == wild_spawn_vsrf_fight;
    }

    // Peaceful civilians — dump civilian/peacemaker + ScavRole/Civilian.
    inline bool is_civilian_role_by_enum(const int role) {
        return role == wild_spawn_civilian
            || role == wild_spawn_peacemaker;
    }

    // Fallback when WildSpawnTypeExtension.IsBoss is not resolved yet / returns false negatives.
    // Values from EFT 1.0.6.5.46221 WildSpawnType dump (boss* + event boss variants).
    inline bool is_boss_role_by_enum(const int role) {
        switch (role)
        {
        case 2:  // bossTest
        case 3:  // bossBully
        case 6:  // bossKilla
        case 7:  // bossKojaniy
        case 11: // bossGluhar
        case 17: // bossSanitar
        case 22: // bossTagilla
        case 25: // gifter (santa — treated as boss-like)
        case 26: // bossKnight
        case 29: // bossZryachiy
        case 32: // bossBoar
        case 36: // bossBoarSniper
        case 38: // peacefullZryachiyEvent
        case 40: // ravangeZryachiyEvent
        case 43: // bossKolontay
        case 47: // bossPartisan
        case 65: // bossTagillaAgro
        case 66: // bossKillaAgro
        case 76: // bossWedge
        case 77: // bossBullyBlackDiv
        case 80: // bossWedgeLab
            return true;
        default:
            return false;
        }
    }

    inline bool is_boss_role(const int role) {
        if (role < 0) return false;
        const wild_spawn_api& api = wild_spawn_methods();
        // Trust the game's own live IsBoss() once it's resolved — it always
        // matches the running game's actual WildSpawnType mapping. The static
        // table below was dumped from build 1.0.6.5.46221; WildSpawnType
        // ordinals can shift between game versions, so once the live method
        // is available, falling through to that stale table on a "false"
        // answer turned ordinary Scavs whose role number happened to match
        // an old boss value into false-positive bosses (pink instead of
        // yellow). Only consult it when the live method never resolved.
        if (api.is_boss)
            return api.is_boss(role);
        return is_boss_role_by_enum(role);
    }

    // is_follower_role() was removed: no callers. The wild_spawn_api::is_follower
    // hook it read is still resolved below and still consulted by is_boss_role's
    // sibling paths, so the API surface is unchanged -- only this unused
    // convenience wrapper is gone.

    // ScavRole key from game (e.g. "ScavRole/VSRF", "ScavRole/Civilian") when extension is ready.
    inline std::string try_get_scav_role_key_utf8(const int role) {
        if (role < 0) return {};
        const wild_spawn_api& api = wild_spawn_methods();
        if (!api.get_scav_role_key) return {};
        Il2CppString* key = api.get_scav_role_key(role);
        if (!key) return {};
        return il2utils::conv_string(key);
    }

    inline bool is_vsrf_role(const int role) {
        if (role < 0) return false;
        if (is_vsrf_role_by_enum(role)) return true;
        const wild_spawn_api& api = wild_spawn_methods();
        if (api.is_vsrf && api.is_vsrf(role)) return true;
        const std::string key = try_get_scav_role_key_utf8(role);
        return key.find("VSRF") != std::string::npos || key.find("vsRF") != std::string::npos;
    }

    inline bool is_civilian_role(const int role) {
        if (role < 0) return false;
        if (is_civilian_role_by_enum(role)) return true;
        const std::string key = try_get_scav_role_key_utf8(role);
        return key.find("Civilian") != std::string::npos;
    }

    inline npc_kind classify_wild_spawn_role(const int role) {
        if (role < 0) return npc_kind::scav;
        if (role == wild_spawn_shooter_btr) return npc_kind::btr;
        if (is_black_division_role(role)) return npc_kind::black_division;

        const wild_spawn_api& api = wild_spawn_methods();
        // Boss BEFORE follower — IsFollower must not steal boss roles.
        if (is_boss_role(role)) return npc_kind::boss;
        // Military (VSRF) and peaceful civilians — before generic scav.
        if (is_vsrf_role(role)) return npc_kind::defector;
        if (is_civilian_role(role)) return npc_kind::civilian;
        if (api.is_ex_usec && api.is_ex_usec(role)) return npc_kind::raider;
        if (api.is_pmc_bot && api.is_pmc_bot(role)) return npc_kind::raider;
        if (api.is_sectant && api.is_sectant(role)) return npc_kind::cultist;
        if (api.is_follower && api.is_follower(role)) return npc_kind::guard;

        return npc_kind::scav;
    }

    inline std::wstring kind_label_fallback_wide(const npc_kind kind) {
        switch (kind)
        {
        case npc_kind::boss: return L"Boss";
        case npc_kind::guard: return L"Guard";
        case npc_kind::cultist: return L"Cultist";
        case npc_kind::raider: return L"Raider";
        case npc_kind::defector: return L"Military";
        case npc_kind::civilian: return L"Civilian";
        case npc_kind::black_division: return L"Black Division";
        case npc_kind::btr: return L"BTR";
        case npc_kind::scav:
        default: return L"Scav";
        }
    }

    namespace detail {
        // Declared here, next to the first memo table, because
        // get_localized_role_label_wide() below is the first user and it sits
        // above the detail block that holds the other seven.
        //
        // Every localization memo table in this header is reached from three
        // threads: the game thread (ESP scans), the render thread (module menus)
        // and the DETACHED thread in game_items::prewarm(), which localizes one
        // name per ItemTemplate. clear_localization_cache() empties all of them
        // from the game thread. None synchronised anything, so a concurrent
        // insert could reallocate the bucket array out from under a reader --
        // the same use-after-free shape as the ESP skeleton crash.
        //
        // One mutex for all of them, held only across the map operations. The
        // IL2CPP work between a lookup and its store runs unlocked, so a menu
        // frame is never blocked behind a template lookup.
        inline std::mutex& localization_cache_mutex() {
            static std::mutex m;
            return m;
        }

        inline std::unordered_map<int, std::wstring>& role_label_cache() {
            static std::unordered_map<int, std::wstring> cache;
            return cache;
        }
    } // namespace detail

    inline std::wstring get_localized_role_label_wide(const int role) {
        if (role < 0) return kind_label_fallback_wide(npc_kind::scav);

        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            const auto& cache = detail::role_label_cache();
            if (const auto it = cache.find(role); it != cache.end())
                return it->second;
        }

        const npc_kind kind = classify_wild_spawn_role(role);
        std::wstring label = kind_label_fallback_wide(kind);

        // Roles we classify ourselves keep OUR label, not the game's.
        //
        // The game's key is "ScavRole/<Name>" (verified: shooterBTR == 46 ->
        // "ScavRole/ShooterBTR", WildSpawnTypeExtension's settings table). Asking
        // LocalizationExtensions.Localized for it returns that key unresolved, because
        // the game ships translations for only four of them -- SCAV_ROLE_BOSS,
        // SCAV_ROLE_FOLLOWER, SCAV_ROLE_SECTANT, SCAV_ROLE_CIVILIAN are the whole
        // const list in WildSpawnTypeExtension.cs. "ScavRole/ShooterBTR" is a literal
        // in the settings table but not a translated key, so the overlay drew
        // "[ScavRole/ShooterBTR]" where "[BTR]" was intended.
        //
        // LocalizationExtensions.Localized is documented by this repo (WORKFLOW.md,
        // ISIL notes) to echo the input key when it has no entry, which is exactly
        // what happens here. So an unresolved result is detectable: if the returned
        // text still looks like the key we passed in, it was not translated.
        //
        // Only applied to kinds whose label WE own. Boss/Follower/Sectant/Civilian
        // are the four the game does translate, and those keep the game's wording --
        // including its localisation, which is a feature, not a bug.
        const bool label_is_game_translated = kind == npc_kind::boss
            || kind == npc_kind::guard
            || kind == npc_kind::cultist
            || kind == npc_kind::civilian;

        const wild_spawn_api& api = wild_spawn_methods();
        if (label_is_game_translated && api.get_scav_role_key && api.localized)
        {
            Il2CppString* key = api.get_scav_role_key(role);
            if (key)
            {
                Il2CppString* localized = api.localized(key, 0);
                if (localized)
                {
                    const std::wstring resolved = il2utils::conv_wstring(localized);
                    // Reject an echo of the key: that is "no translation", and using
                    // it would put the raw key on screen.
                    const std::wstring key_wide = il2utils::conv_wstring(key);
                    const bool echoed = !resolved.empty() && resolved == key_wide;
                    if (!resolved.empty() && !echoed) label = resolved;
                }
            }
        }

        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            detail::role_label_cache().emplace(role, label);
        }
        return label;
    }

    inline std::wstring role_tag_wide(const int role) {
        return L"[" + get_localized_role_label_wide(role) + L"]";
    }

    inline std::wstring pmc_tag_wide(const int side) {
        if (side == 1) return L"[USEC]";
        if (side == 2) return L"[BEAR]";
        return L"[PMC]";
    }

    inline std::wstring format_distance_suffix(const int distance_m) {
        wchar_t dist_buf[32];
        swprintf_s(dist_buf, L"[%dm]", distance_m);
        return dist_buf;
    }

    inline void finalize_player_label(player_label& result) {
        // AI profile nicknames and role labels can arrive in the game's
        // currently selected locale. Keep ESP/minimap labels readable even
        // when the live profile supplies Cyrillic text.
        //result.prefix_utf8 = to_english(result.prefix_wide);
        result.prefix_utf8 = wstring_to_utf8(result.prefix_wide);
        result.text_wide = result.prefix_wide;
        result.text_utf8 = result.prefix_utf8;
    }

    inline bool try_is_btr_by_weapon(Il2CppObject* player_obj);

    inline player_label build_player_label(const bool is_pmc, const std::wstring& nickname_wide,
        const int distance_m, const bool show_bot_names,
        Il2CppObject* profile_ptr, Il2CppObject* player_obj,
        const int side = -1) {
        player_label result{};
        const std::wstring dist_suffix = format_distance_suffix(distance_m);
        const int role = profile_ptr ? get_wild_spawn_role(profile_ptr) : -1;

        if (is_pmc)
            result.kind = npc_kind::pmc;
        else if (role == wild_spawn_shooter_btr || try_is_btr_by_weapon(player_obj))
            result.kind = npc_kind::btr;
        else
            result.kind = classify_wild_spawn_role(role);

        if (show_bot_names)
        {
            result.prefix_wide = (is_pmc ? pmc_tag_wide(side) : role_tag_wide(role)) + L" " + dist_suffix;
            result.show_name_line = true;
            //result.name_utf8 = to_english(nickname_wide);
            result.name_utf8 = to_display_utf8(nickname_wide);
            finalize_player_label(result);
            return result;
        }

        if (is_pmc)
        {
            result.text_utf8 = wstring_to_utf8(pmc_tag_wide(side)) + " "
                + to_display_utf8(nickname_wide) + " " + wstring_to_utf8(dist_suffix);
            //result.text_utf8 = to_english(pmc_tag_wide(side) + L" "
            //    + nickname_wide + L" " + dist_suffix);
            result.text_wide = std::wstring(result.text_utf8.begin(), result.text_utf8.end());
            return result;
        }

        result.text_utf8 = wstring_to_utf8(get_localized_role_label_wide(role))
            + " " + wstring_to_utf8(dist_suffix);
        //result.text_utf8 = to_english(get_localized_role_label_wide(role)
        //    + L" " + dist_suffix);
        result.text_wide = std::wstring(result.text_utf8.begin(), result.text_utf8.end());
        return result;
    }

    // THE single reader for a managed `get_position`.
    //
    // This logic existed FIVE times and had drifted:
    //
    //   eft_api::try_get_head_position       no finiteness check
    //   esp_bones::get_bifacial_pos          no finiteness check
    //   aimbot::get_bifacial_pos             finiteness check on all three axes
    //   skeleton_vis::get_bifacial_position  no finiteness check, plus the cheap-door gate
    //                                         and the TA_ZONE_SITE instrumentation
    //   PlayerModule::try_get_movement_position  no finiteness check (bifacial branch only;
    //                                         its get_TransformPosition branch is a DIFFERENT
    //                                         method on a different object and stays put)
    //
    // FOUR of the five disagreed with the other one on whether a non-finite position is a
    // success. It is not: a NaN bone coordinate reaches world_to_screen and puts a box at an
    // invented screen position, which is the same class of wrong-answer-the-player-sees as
    // dereferencing something stale. So the check is part of the contract now, and the one
    // caller that already had it is unchanged in behaviour.
    //
    // NO caching of the resolved method pointer at THIS call site, and the reason is
    // redundancy rather than lifetime -- which is the correction to an earlier version of
    // this comment, which claimed the cached key might be recycled. It cannot:
    //
    //   * `Il2CppClass` is allocated when an assembly's metadata loads into the domain and
    //     is never collected for the life of the process, so a class-keyed static would
    //     actually be SAFE. See the same claim for methodPointer at unity.h:934 and for
    //     the FieldInfo offsets at il2utils.h:209.
    //   * `il2utils::resolve_method` already memoises on (class, arity, name) and hands back
    //     that same stable pointer. A second cache here would store a value that is already
    //     cached, to no end.
    //
    // The lifetime hazard is real but belongs to the OTHER object at this call site: the
    // `Il2CppObject*` argument. Objects are GC-allocated and recycled, so a cache keyed on
    // the bone transform would be the genuinely unsound one. Nothing here keys on it, and the
    // next person to add such a cache should read this paragraph first.
    //
    // `out` is written ONLY on success, so a caller that ignores the return value cannot
    // read a half-assigned vector.
    inline bool try_get_managed_position(Il2CppObject* obj, unity::vector3& out) {
        if (!obj || !obj->klass) return false;

        const MethodInfo* method = il2utils::resolve_method(obj->klass, "get_position", 0);
        if (!method || !method->methodPointer) return false;

        const unity::vector3 result =
            reinterpret_cast<unity::vector3 (*)(Il2CppObject*)>(method->methodPointer)(obj);
        if (!std::isfinite(result.x) || !std::isfinite(result.y) || !std::isfinite(result.z))
            return false;

        out = result;
        return true;
    }

    inline bool try_get_head_position(Il2CppObject* player_obj, unity::vector3& out) {
        Il2CppObject* body = try_get_field_object(player_obj, "_playerBody");
        if (!body) return false;

        Il2CppObject* bones = try_get_field_object(body, "PlayerBones");
        if (!bones) return false;

        Il2CppObject* head = try_get_field_object(bones, "Head");
        if (!head || !head->klass) return false;

        return try_get_managed_position(head, out);
    }

    inline bool try_detect_is_pmc(Il2CppObject* player_obj) {
        if (!player_obj || !player_obj->klass) return false;

        Il2CppObject* inventory_controller = try_get_field_object(player_obj, "_inventoryController");
        if (!inventory_controller || !inventory_controller->klass) return false;

        Il2CppObjectInstance ic(inventory_controller);
        const auto get_inventory = ic.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_Inventory", 0);
        if (!get_inventory) return false;

        Il2CppObject* inventory = get_inventory(inventory_controller);
        if (!inventory || !inventory->klass) return false;

        Il2CppObject* equipment = try_get_field_object(inventory, "Equipment");
        if (!equipment || !equipment->klass) return false;

        Il2CppObjectInstance eq(equipment);
        const auto get_slot = eq.get_method<Il2CppObject* (*)(Il2CppObject*, int)>("GetSlot", 1);
        if (!get_slot) return false;

        Il2CppObject* slot = get_slot(equipment, 13);
        if (!slot || !slot->klass) return false;

        Il2CppObjectInstance slot_inst(slot);
        const auto get_item = slot_inst.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_ContainedItem", 0);
        if (!get_item) return false;

        return get_item(slot) != nullptr;
    }

    // Same kind used by ESP labels — preferred for world TP filters.
    inline npc_kind classify_player_kind(Il2CppObject* player_obj) {
        if (!player_obj) return npc_kind::scav;

        if (try_detect_is_pmc(player_obj))
            return npc_kind::pmc;

        Il2CppObject* profile = try_get_field_object(player_obj, "Profile");
        if (!profile)
        {
            Il2CppObjectInstance inst(player_obj);
            if (const auto get_profile = inst.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_Profile", 0, false))
                profile = get_profile(player_obj);
        }

        const int role = profile ? get_wild_spawn_role(profile) : -1;
        if (role == wild_spawn_shooter_btr || try_is_btr_by_weapon(player_obj))
            return npc_kind::btr;

        return classify_wild_spawn_role(role);
    }

    inline Il2CppObject* try_get_health_controller(Il2CppObject* player_obj) {
        if (!player_obj || !player_obj->klass) return nullptr;

        // REVERTED 2026-10-06. This function was never a call-through-null site.
        // 6b35fe8b claimed it as one and rewrote it anyway; `git show 6b35fe8b^` shows the
        // original already resolved into a local and tested it (`if (get_active)` /
        // `if (!get_health) return nullptr`). Nothing here could call through null, so the
        // commit's premise did not hold for this function.
        //
        // What 6b35fe8b added instead was a single-slot per-object memo, justified by a
        // caller -- `scene_objects_live` in EspModule::draw_overlay -- that was subsequently
        // REFUTED AND CUT (0d065f29). So the justification is gone and the memo stayed. It
        // is also the exact hazard the localization caches document elsewhere in this file:
        // it memoises FAILURES as well as successes, so a transient miss (player mid-teardown)
        // is cached permanently for that pointer. Worse, the slot is never cleared on a raid
        // boundary, so a recycled player address can be served the previous player's
        // controller -- a stale pointer handed to managed code.
        //
        // Restored to the original guarded form. `cached_method` is KEPT, because that part
        // is sound on its own terms: il2utils::get_method has no cache and walks the method
        // table per call, and it was already the established idiom in unity.h before
        // 6c8435ff. The class keying matters because the ESP alternates player subclasses.
        Il2CppObjectInstance player(player_obj);
        const auto get_active = unity::cached_method<Il2CppObject* (*)(Il2CppObject*)>(
            player_obj->klass, "get_ActiveHealthController", 0);
        if (get_active)
        {
            Il2CppObject* active = get_active(player_obj);
            if (active) return active;
        }

        const auto get_health = unity::cached_method<Il2CppObject* (*)(Il2CppObject*)>(
            player_obj->klass, "get_HealthController", 0);
        if (!get_health) return nullptr;
        return get_health(player_obj);
    }

    inline bool is_valid_health_pair(const float current, const float maximum) {
        return maximum > 0.01f
            && maximum < 10000.f
            && current >= 0.f
            && current <= maximum * 1.05f;
    }

    inline bool is_valid_health_value(const value_struct& value) {
        return is_valid_health_pair(value.current, value.maximum);
    }

    inline bool try_read_health_from_health_value(Il2CppObject* health_value_obj, health_value& out) {
        if (!health_value_obj || !health_value_obj->klass) return false;

        Il2CppObjectInstance health_value_instance(health_value_obj);
        const auto get_current = health_value_instance.get_method<float (*)(Il2CppObject*)>("get_Current", 0);
        const auto get_maximum = health_value_instance.get_method<float (*)(Il2CppObject*)>("get_Maximum", 0);
        if (get_current && get_maximum)
        {
            const float current = get_current(health_value_obj);
            const float maximum = get_maximum(health_value_obj);
            if (is_valid_health_pair(current, maximum))
            {
                out.current = current;
                out.maximum = maximum;
                return true;
            }
        }

        const FieldInfo* value_field = il2utils::resolve_field(health_value_obj->klass, "Value");
        if (!value_field) return false;

        const auto* value = reinterpret_cast<const value_struct*>(
            reinterpret_cast<UINT64>(health_value_obj) + value_field->offset);
        if (!is_valid_health_value(*value)) return false;

        out.current = value->current;
        out.maximum = value->maximum;
        return true;
    }

    inline bool try_read_health_from_part_state(Il2CppObject* part_state, health_value& out) {
        if (!part_state || !part_state->klass) return false;
        return try_read_health_from_health_value(try_get_field_object(part_state, "Health"), out);
    }

    // Dictionary<EBodyPart, BodyPartState> entry — int key + object value needs 4-byte pad on x64
    struct body_state_dict_entry
    {
        int hash_code;
        int next;
        int key;
        int padding;
        Il2CppObject* part_state;
    };

    inline bool try_is_part_destroyed(Il2CppObject* part_state) {
        if (!part_state || !part_state->klass) return false;
        const FieldInfo* field = il2utils::resolve_field(part_state->klass, "IsDestroyed");
        if (!field) return false;
        return *reinterpret_cast<bool*>(reinterpret_cast<UINT64>(part_state) + field->offset);
    }

    inline bool try_read_part_state_health(Il2CppObject* part_state, health_value& out, bool& destroyed) {
        destroyed = try_is_part_destroyed(part_state);
        if (!try_read_health_from_part_state(part_state, out))
        {
            if (destroyed)
            {
                out = {};
                return true;
            }
            return false;
        }

        if (out.current <= 0.01f) destroyed = true;
        return true;
    }

    inline bool try_collect_limbs_from_entries(const body_state_dict_entry* entries, const int entry_count,
        health_value* parts, bool* destroyed, const int part_count) {
        if (!entries || !parts || !destroyed || part_count <= 0) return false;

        bool any = false;
        for (int i = 0; i < entry_count; ++i)
        {
            const auto& entry = entries[i];
            if (entry.hash_code < 0) continue;

            const int part = entry.key;
            if (part < 0 || part >= part_count) continue;

            if (try_read_part_state_health(entry.part_state, parts[part], destroyed[part]))
                any = true;
        }
        return any;
    }

    inline bool try_collect_limbs_from_compact(unity::dict<int, Il2CppObject*>* body_state,
        health_value* parts, bool* destroyed, const int part_count) {
        if (!body_state || !body_state->m_p_entries || body_state->m_p_entries->max_length == 0)
            return false;

        const int entry_count = static_cast<int>(body_state->m_p_entries->max_length);
        if (entry_count <= 0 || entry_count > 64) return false;

        const auto* entries = body_state->get_entry();
        if (!entries) return false;

        bool any = false;
        for (int i = 0; i < entry_count; ++i)
        {
            const auto& entry = entries[i];
            if (entry.m_i_hash_code < 0) continue;

            const int part = entry.m_t_key;
            if (part < 0 || part >= part_count) continue;

            if (try_read_part_state_health(entry.m_t_value, parts[part], destroyed[part]))
                any = true;
        }
        return any;
    }

    inline bool try_get_limb_health(Il2CppObject* player_obj, health_value* parts, bool* destroyed,
        const int part_count = 7) {
        if (!player_obj || !parts || !destroyed || part_count <= 0) return false;

        for (int i = 0; i < part_count; ++i)
        {
            parts[i] = {};
            destroyed[i] = false;
        }

        Il2CppObject* health_controller = try_get_health_controller(player_obj);
        if (!health_controller) return false;

        Il2CppObject* body_state_obj = nullptr;
        for (const char* field_name : {"_bodyState", "BodyState", "<BodyState>k__BackingField"})
        {
            body_state_obj = try_get_field_object(health_controller, field_name);
            if (body_state_obj) break;
        }

        if (!body_state_obj || !body_state_obj->klass) return false;

        auto* body_state = reinterpret_cast<unity::dict<int, Il2CppObject*>*>(body_state_obj);
        if (!body_state->m_p_entries || body_state->m_p_entries->max_length == 0) return false;

        const int entry_count = static_cast<int>(body_state->m_p_entries->max_length);
        if (entry_count <= 0 || entry_count > 64) return false;

        const auto* entries = reinterpret_cast<const body_state_dict_entry*>(&body_state->m_p_entries->data);
        if (entries && try_collect_limbs_from_entries(entries, entry_count, parts, destroyed, part_count))
            return true;

        return try_collect_limbs_from_compact(body_state, parts, destroyed, part_count);
    }

    inline bool try_sum_body_state_entries(unity::dict<int, Il2CppObject*>* body_state, health_value& out) {
        if (!body_state || !body_state->m_p_entries || body_state->m_p_entries->max_length == 0)
            return false;

        const int entry_count = static_cast<int>(body_state->m_p_entries->max_length);
        if (entry_count <= 0 || entry_count > 64) return false;
        if (body_state->m_i_count < 0 || body_state->m_i_count > entry_count) return false;

        const auto* entries = reinterpret_cast<const body_state_dict_entry*>(&body_state->m_p_entries->data);
        if (!entries) return false;

        float total_current = 0.f;
        float total_maximum = 0.f;

        for (int i = 0; i < entry_count; ++i)
        {
            const auto& entry = entries[i];
            if (entry.hash_code < 0) continue;

            const int part = entry.key;
            Il2CppObject* part_state = entry.part_state;
            if (!part_state) continue;

            health_value part_health{};
            if (!try_read_health_from_part_state(part_state, part_health)) continue;

            if (part == 7)
            {
                out = part_health;
                return true;
            }

            if (part >= 0 && part <= 6)
            {
                total_current += part_health.current;
                total_maximum += part_health.maximum;
            }
        }

        if (!is_valid_health_pair(total_current, total_maximum)) return false;
        out.current = total_current;
        out.maximum = total_maximum;
        return true;
    }

    inline bool try_sum_body_state_entries_compact(unity::dict<int, Il2CppObject*>* body_state, health_value& out) {
        if (!body_state || !body_state->m_p_entries || body_state->m_p_entries->max_length == 0)
            return false;

        const int entry_count = static_cast<int>(body_state->m_p_entries->max_length);
        if (entry_count <= 0 || entry_count > 64) return false;

        const auto* entries = body_state->get_entry();
        if (!entries) return false;

        float total_current = 0.f;
        float total_maximum = 0.f;

        for (int i = 0; i < entry_count; ++i)
        {
            const auto& entry = entries[i];
            if (entry.m_i_hash_code < 0) continue;

            health_value part_health{};
            if (!try_read_health_from_part_state(entry.m_t_value, part_health)) continue;

            if (entry.m_t_key == 7)
            {
                out = part_health;
                return true;
            }

            if (entry.m_t_key >= 0 && entry.m_t_key <= 6)
            {
                total_current += part_health.current;
                total_maximum += part_health.maximum;
            }
        }

        if (!is_valid_health_pair(total_current, total_maximum)) return false;
        out.current = total_current;
        out.maximum = total_maximum;
        return true;
    }

    inline bool try_invoke_get_body_part_health(Il2CppObject* health_controller, const int body_part, health_value& out) {
        if (!health_controller || !health_controller->klass) return false;

        const MethodInfo* method = il2utils::resolve_method(health_controller->klass, "GetBodyPartHealth", 1);
        if (!method || !method->methodPointer) return false;

        value_struct buffer{};
        using sig = void (*)(Il2CppObject*, value_struct*, int);
        reinterpret_cast<sig>(method->methodPointer)(health_controller, &buffer, body_part);

        if (!is_valid_health_value(buffer)) return false;
        out.current = buffer.current;
        out.maximum = buffer.maximum;
        return true;
    }

    inline bool try_read_health_from_body_state(Il2CppObject* health_controller, health_value& out) {
        if (!health_controller || !health_controller->klass) return false;

        Il2CppObject* body_state_obj = nullptr;
        for (const char* field_name : {"_bodyState", "BodyState", "<BodyState>k__BackingField"})
        {
            body_state_obj = try_get_field_object(health_controller, field_name);
            if (body_state_obj) break;
        }

        if (body_state_obj && body_state_obj->klass)
        {
            auto* body_state = reinterpret_cast<unity::dict<int, Il2CppObject*>*>(body_state_obj);
            if (try_sum_body_state_entries(body_state, out)) return true;
            if (try_sum_body_state_entries_compact(body_state, out)) return true;
        }

        constexpr int body_part_common = 7;
        return try_invoke_get_body_part_health(health_controller, body_part_common, out);
    }

    inline bool try_get_player_health(Il2CppObject* player_obj, health_value& out, bool& is_alive) {
        if (!player_obj || !player_obj->klass) return false;

        Il2CppObject* health_controller = try_get_health_controller(player_obj);
        if (!health_controller || !health_controller->klass) return false;

        Il2CppObjectInstance hc(health_controller);
        const auto get_is_alive = hc.get_method<bool (*)(Il2CppObject*)>("get_IsAlive", 0);
        if (get_is_alive)
            is_alive = get_is_alive(health_controller);

        if (!is_alive) return false;
        return try_read_health_from_body_state(health_controller, out);
    }
    // FPS / generic: Camera.WorldToScreenPoint (bottom-left) → ImGui (top-left).
    // Separate X/Y scales so non-16:9 RTs do not shift left.
    /// `pre_cam_w` / `pre_cam_h`, added 2026-10-05: pass the values from
    /// `esp_camera_frame` to take the two `cached_method` lookups off the
    /// per-point path. Default -1 means "resolve them here", which is what all
    /// nine existing call sites do and what this function did unconditionally
    /// before. A supplied 0 is honoured, not retried -- see esp_camera_frame.
    inline unity::vector3 world_to_screen_fps(Il2CppObject* camera, unity::vector3 world_point, float zoom,
        const float pre_cam_w = -1.f, const float pre_cam_h = -1.f) {
        unity::vector3 screen_point = unity::world_to_screen_point(camera, world_point);
        if (!camera)
            return screen_point;

        const float cam_w = pre_cam_w >= 0.f ? pre_cam_w
            : static_cast<float>(unity::camera_pixel_width(camera));
        const float cam_h = pre_cam_h >= 0.f ? pre_cam_h
            : static_cast<float>(unity::camera_pixel_height(camera));
        const float menu_w = menu::get_width();
        const float menu_h = menu::get_height();
        if (cam_w < 1.f || cam_h < 1.f || menu_w < 1.f || menu_h < 1.f)
            return screen_point;

        screen_point.x = screen_point.x * (menu_w / cam_w);
        screen_point.y = menu_h - screen_point.y * (menu_h / cam_h);

        // Legacy fake zoom from eye camera (magnified ADS without optic cam).
        if (zoom > 1.f)
        {
            screen_point.x -= menu_w * 0.5f;
            screen_point.y -= menu_h * 0.5f;
            screen_point.x *= zoom;
            screen_point.y *= zoom;
            screen_point.x += menu_w * 0.5f;
            screen_point.y += menu_h * 0.5f;
        }

        return screen_point;
    }

    // Optic RT → screen: center-aligned letterbox + radial scale.
    // Full-screen stretch of the optic RT over-expands off-axis points (lens is PIP / smaller
    // than the whole monitor). radial_scale shrinks offset-from-center to match on-screen lens.
    inline unity::vector3 map_optic_pixels_to_menu(const float px, const float py, const float pz,
        const float cam_w, const float cam_h,
        const float radial_scale) {
        const float menu_w = menu::get_width();
        const float menu_h = menu::get_height();
        unity::vector3 out{px, py, pz};
        if (cam_w < 1.f || cam_h < 1.f || menu_w < 1.f || menu_h < 1.f)
            return out;

        // Unity bottom-left → NDC relative to center (-0.5 .. +0.5).
        const float nx = (px / cam_w) - 0.5f;
        const float ny = (py / cam_h) - 0.5f;

        const float optic_aspect = cam_w / cam_h;
        const float screen_aspect = menu_w / menu_h;
        float fit_w;
        float fit_h;
        if (optic_aspect > screen_aspect)
        {
            fit_w = menu_w;
            fit_h = menu_w / optic_aspect;
        }
        else
        {
            fit_h = menu_h;
            fit_w = menu_h * optic_aspect;
        }

        const float rs = radial_scale > 0.01f ? radial_scale : 1.f;
        fit_w *= rs;
        fit_h *= rs;

        out.x = menu_w * 0.5f + nx * fit_w;
        out.y = menu_h * 0.5f - ny * fit_h; // ImGui y grows downward
        out.z = pz;
        return out;
    }

    inline Il2CppObject* camera_get_transform(Il2CppObject* camera) {
        if (!camera) return nullptr;
        Il2CppObject* go = unity::component_get_game_object(camera);
        return go ? unity::gameobject_get_transform(go) : nullptr;
    }

    // Measure how much the OPTIC camera's narrow FOV magnifies a lateral probe, relative to
    // the eye camera. Probe LEFT and RIGHT of reticle, average k — single-side probe biased
    // scale with strafe.
    //
    // The parameter is named `scope_zoom` and is DELIBERATELY UNUSED. See the probe body and
    // the FOV fallback below: passing the game's magnification in here is what pinned this
    // whole quantity at ~0.73 for the entire session.
    //
    // The returned k is 1/magnification: the spec's own line 40 ("Magnification already comes
    // from the optic projection, so changing from 1x to 5x does not require another
    // multiplication by five") means the caller must NOT fold the scope zoom in a second time.
    //
    // Count of suspicious calibration events, for the rate limiter's summary.
    inline unsigned long long g_kcal_count = 0;

    inline float calibrate_optic_radial_scale_impl(Il2CppObject* optic, Il2CppObject* fps,
        [[maybe_unused]] const float scope_zoom) {
        // Zoned 2026-10-05, and it was invisible until this.
        //
        // Four call sites, and one of them -- world_to_screen_with_frame -- ran it
        // PER PROJECTED POINT. With no zone, that entire cost was
        // `aimbot::project_to_screen` SELF time, which is why a 39.7 ms
        // self-time outlier had no explanation anywhere in the export: the
        // function that caused it was not a row.
        //
        // Placed above the `!optic` early return so the cheap rejection is
        // counted too -- otherwise the row would read as "cost of calibrating"
        // when most calls did not calibrate at all.
        TA_ZONE_N("eft_api::calibrate_optic_radial_scale");
        if (!optic) return 1.f;
        Il2CppObject* otr = camera_get_transform(optic);
        if (!otr) return 1.f;

        Il2CppObjectInstance ti(otr);
        const auto get_fwd = ti.get_method<unity::vector3 (*)(Il2CppObject*)>("get_forward", 0, false);
        const auto get_right = ti.get_method<unity::vector3 (*)(Il2CppObject*)>("get_right", 0, false);
        if (!get_fwd || !get_right) return 1.f;

        const unity::vector3 pos = unity::transform_get_pos(otr);
        const unity::vector3 fwd = get_fwd(otr);
        const unity::vector3 right = get_right(otr);

        constexpr float k_dist = 45.f;
        constexpr float k_side = 1.25f;
        const float cam_w = static_cast<float>(unity::camera_pixel_width(optic));
        const float cam_h = static_cast<float>(unity::camera_pixel_height(optic));
        const float cx = menu::get_width() * 0.5f;
        const float cy = menu::get_height() * 0.5f;

        // ---- probe diagnostics (2026-09-27) --------------------------------
        // `auto_k` was observed bimodal: an exact 0.200 against 0.76-0.81. The exact
        // 0.200 is NOT a -1 contaminating the average -- the caller already filters
        // those -- it is the `if (k < 0.2f) k = 0.2f;` floor at the end of this
        // function. So the computed ratio was genuinely BELOW 0.2 and the clamp hid
        // it. Every input that could explain that was being discarded, so each probe
        // now records why it failed and what it measured.
        struct probe_rec {
            float ratio = -1.f;
            const char* fail = "ok";
            float raw_o[3]{};
            float p_opt[3]{};
            float p_fps[3]{};
            float lo = 0.f, lf = 0.f;
        } probes[2];

        auto probe_k = [&](const float side_sign, probe_rec& rec) -> float {
            const unity::vector3 probe{
                pos.x + fwd.x * k_dist + right.x * k_side * side_sign,
                pos.y + fwd.y * k_dist + right.y * k_side * side_sign,
                pos.z + fwd.z * k_dist + right.z * k_side * side_sign};

            const unity::vector3 raw_o = unity::world_to_screen_point(optic, probe);
            rec.raw_o[0] = raw_o.x; rec.raw_o[1] = raw_o.y; rec.raw_o[2] = raw_o.z;
            if (raw_o.z < 0.01f) { rec.fail = "optic_z"; return -1.f; }

            const unity::vector3 p_opt = map_optic_pixels_to_menu(
                raw_o.x, raw_o.y, raw_o.z, cam_w, cam_h, 1.f);
            rec.p_opt[0] = p_opt.x; rec.p_opt[1] = p_opt.y; rec.p_opt[2] = p_opt.z;
            if (!fps) { rec.fail = "no_fps"; return -1.f; }

            const unity::vector3 p_fps = world_to_screen_fps(fps, probe, 1.f);
            //                    ^^^^ 1.f, NOT scope_zoom. 2026-09-27, and this was the
            // single worst bug of the session.
            //
            // `lo` is the probe through the OPTIC camera, whose narrow FOV already magnifies
            // it by the scope's magnification. `world_to_screen_fps` applies a legacy fake
            // zoom about the screen centre when `zoom > 1`, so passing scope_zoom multiplied
            // the numerator by the same factor -- and the ratio below, which exists precisely
            // to measure that magnification, divided it straight back out. What survived was
            // the letterbox aspect term, a constant.
            //
            // The log proves it. `optic-fov` over one zoomable-scope run, one sight, FOV
            // 4.42..26.50: k stayed in [0.7322, 0.7508] while the correct 1/mag swept
            // [0.1224, 0.7468] -- 2.5% spread against a factor of 6.1, i.e. 6.0x wrong at
            // maximum zoom. And `k * mag` recovers a MONOTONE 0.997 -> 5.994 ramp across the
            // 14 samples, in run order, with no outliers: that is the scope's own 1x..6x
            // zoom ladder, appearing exactly once, which is the signature of a single
            // multiply by scope_zoom. Removing it makes k equal 1/mag by construction.
            rec.p_fps[0] = p_fps.x; rec.p_fps[1] = p_fps.y; rec.p_fps[2] = p_fps.z;
            if (p_fps.z < 0.01f) { rec.fail = "fps_z"; return -1.f; }

            const float dx_o = p_opt.x - cx;
            const float dy_o = p_opt.y - cy;
            const float dx_f = p_fps.x - cx;
            const float dy_f = p_fps.y - cy;
            rec.lo = std::sqrt(dx_o * dx_o + dy_o * dy_o);
            rec.lf = std::sqrt(dx_f * dx_f + dy_f * dy_f);
            if (rec.lo <= 2.f || rec.lf <= 2.f) { rec.fail = "degenerate"; return -1.f; }
            rec.ratio = rec.lf / rec.lo;
            return rec.ratio;
        };

        // Average left (-right) and right (+right) samples when both valid.
        const float k_r = probe_k(+1.f, probes[0]);
        const float k_l = probe_k(-1.f, probes[1]);
        float k = 1.f;
        int n = 0;
        float sum = 0.f;
        if (k_r > 0.f) { sum += k_r; ++n; }
        if (k_l > 0.f) { sum += k_l; ++n; }
        if (n > 0)
            k = sum / static_cast<float>(n);

        const float k_probe = k;
        const int probes_used = n;

        // FOV fallback if both probes failed or ratio is nonsense.
        //
        // 2026-09-27, first pass: this was `(f_fov / zoom) / o_fov`, which returns the
        // MAGNIFICATION (35/6 = 5.83 in the measured run) where the quantity required is its
        // RECIPROCAL (0.171). Two implementations of `k` disagreed by a factor of ~34, and the
        // clamp below belonged to the magnification convention -- which is why a correct
        // probe reading of 0.165 was clamped UP to 0.2 on 97.5% of frames (4599/4717).
        //
        // The direction is not a guess: `map_optic_pixels_to_menu` computes
        // `out = centre + nx * fit * rs` with `fit` starting at the full menu size, so
        // `rs` must SHRINK the optic frame. And the probe measures the multiplier
        // directly -- `lo` is the same world point projected with rs=1, `lf` the same
        // point through the FPS camera, so `lf/lo` is exactly the factor mapping one to
        // the other. Hence `k` is 1/magnification and belongs in (0, 1].
        //
        // 2026-09-27, second pass: the reciprocal was right but the `* zoom` was the SAME
        // double count as the probe above, in a different disguise -- and it is worse here,
        // because this branch is what runs when the probe has already failed, i.e. exactly
        // when a wrong answer cannot be cross-checked. The two camera FOVs ALREADY ARE the
        // magnification; there is nothing left to multiply by. So the term goes entirely,
        // and the linear o_fov/f_fov ratio becomes the tan ratio that a perspective
        // projection actually implies:
        //
        //     1/mag = tan(o_fov/2) / tan(f_fov/2)
        //
        // At o=4.42, f=35 that is 0.1224 against the measured 1/mag of 0.1224. The old
        // linear form without the zoom term gives 0.1263 -- 3% high, because FOV-to-tan is
        // not linear and the error grows as the scope narrows. (That 3% is the whole reason
        // this is not simply `o_fov / f_fov`.)
        bool used_fov = false;
        if (n == 0 || k < 0.05f || k > 1.2f)
        {
            used_fov = true;
            const float o_fov = unity::camera_fov(optic);
            const float f_fov = fps ? unity::camera_fov(fps) : o_fov;
            if (o_fov > 0.1f && f_fov > 0.1f)
            {
                constexpr float kDeg2Rad = 3.14159265358979f / 180.0f;
                const double o_half = static_cast<double>(o_fov) * 0.5 * kDeg2Rad;
                const double f_half = static_cast<double>(f_fov) * 0.5 * kDeg2Rad;
                const double t_o = std::tan(o_half);
                const double t_f = std::tan(f_half);
                k = (t_o > 1e-9 && t_f > 1e-9)
                    ? static_cast<float>(t_o / t_f)
                    : 1.f;
            }
            else
                k = 1.f;
        }

        const float k_preclamp = k;
        // Bounds for a 1/magnification quantity: 1.0 is a 1x optic (no shrink), 1/16 a
        // 16x scope. The old [0.2, 1.35] was a MAGNIFICATION-shaped window: its 0.2
        // floor doubled the size of everything at 8x or beyond, and its 1.35 ceiling
        // turned the inverted FOV fallback into a 1.35x blow-up. The old `k < 0.15`
        // fallback trigger was the same mistake -- it routed every scope at 8x or beyond
        // straight into that inverted branch.
        if (k < 0.0625f) k = 0.0625f;
        if (k > 1.f) k = 1.f;

        // Emitted only when something is actually suspicious: a probe failed, a clamp
        // fired, or the FOV fallback was taken. A clean two-probe agreement in range
        // stays silent.
        //
        // That condition was not enough on its own. With the OLD clamp, 97.5% of
        // calibrations clamped, so "suspicious" was the normal case and this produced
        // 4,717 lines in one 3-minute session -- the same log-spam failure as the
        // cull_mode banner. Rate-limited as well as filtered: the first few events log
        // in full, then at most one line per 2 s, with a count of what was suppressed.
        // The periodic summary below keeps the steady state visible without the volume.
        const bool clamp_lo = k_preclamp < 0.0625f;
        const bool clamp_hi = k_preclamp > 1.f;
        if (probes_used < 2 || clamp_lo || clamp_hi || used_fov)
        {
            ++g_kcal_count;
            const ULONGLONG now_ms = GetTickCount64();
            static ULONGLONG s_kcal_last_ms = 0;
            static unsigned long long s_kcal_suppressed = 0;
            const bool first = g_kcal_count <= 5;
            const bool due = (now_ms - s_kcal_last_ms) >= 2000;
            if (first || due)
            {
                if (!first && s_kcal_suppressed)
                    logger::info(std::format(
                        "optic-kcal: {} further events suppressed (rate limit 2s)",
                        s_kcal_suppressed));
                s_kcal_suppressed = 0;
                s_kcal_last_ms = now_ms;
                const auto fmt_probe = [](const probe_rec& r) {
                    return std::format(
                        "[{} rawO=({:.1f},{:.1f},{:.3f}) pOpt=({:.1f},{:.1f},{:.3f}) "
                        "pFps=({:.1f},{:.1f},{:.3f}) lo={:.1f} lf={:.1f} ratio={:.3f}]",
                        r.fail, r.raw_o[0], r.raw_o[1], r.raw_o[2],
                        r.p_opt[0], r.p_opt[1], r.p_opt[2],
                        r.p_fps[0], r.p_fps[1], r.p_fps[2], r.lo, r.lf, r.ratio);
                };
                logger::info(std::format(
                    "optic-kcal: source={} probes={} R {} L {} | raw_probe={:.4f} "
                    "preclamp={:.4f} final={:.4f}{}{} dist={:.1f} side={:.2f} zoom={:.2f} "
                    "opticFov={:.2f} fpsFov={:.2f} centre=({:.0f},{:.0f})",
                    used_fov ? "fov_fallback" : "probe", probes_used,
                    fmt_probe(probes[0]), fmt_probe(probes[1]),
                    k_probe, k_preclamp, k,
                    clamp_lo ? " CLAMP_LO[0.0625]" : "", clamp_hi ? " CLAMP_HI[1.0]" : "",
                static_cast<double>(k_dist), static_cast<double>(k_side),
                static_cast<double>(scope_zoom),
                static_cast<double>(unity::camera_fov(optic)),
                static_cast<double>(fps ? unity::camera_fov(fps) : 0.f),
                static_cast<double>(cx), static_cast<double>(cy)));
            }
            else
            {
                ++s_kcal_suppressed;
            }
        }
        return k;
    }

    // ---- Optic lens pipeline (optic_idea.md full reproduction) --------------
    // Exact scope-image placement: world -> optic VP -> mesh UV -> lens local
    // (material _Scales/_Shifts) -> shader-adjusted lens matrix -> main VP.
    // Validated per sample; falls back to the radial-fit path when any check
    // fails. Packet refresh throttled to ~4 ms (effectively per frame).
    //
    // CONCURRENCY. Two threads reach this path -- measured 2026-09-27, optic-kcal
    // firing 3,656x on tid=21080 and 1,061x on tid=21032 in one session -- and the
    // state was a single mutable struct with no synchronisation at all. Both threads
    // passed the 4 ms throttle, both ran acquire_packet into the SAME packet, and
    // each compared its own `sight_seen` against a route the other had just
    // rewritten. That is the mechanism behind the pointer flapping logged as
    // `route sight=0xA709B000 live sight=0xA709B080` and back, every 1-2 s, costing
    // one frame of mis-sized ESP each time (two sight objects 128 bytes apart).
    //
    // Two changes, together implementing the spec's line 576 requirement to
    // "Publish one immutable accepted packet so drawing cannot mix a new camera with
    // an old lens mapping":
    //
    // 1. A 3-slot packet pool with an atomic published index. The refreshing thread
    //    builds into a slot that is not published and then release-stores the index;
    //    readers acquire-load the index. A reader therefore never observes a
    //    half-written packet, and takes no lock -- which matters because
    //    world_to_screen_optic calls this once per PROJECTED POINT (30k+ per drain),
    //    so a mutex on this path would cost more than the pipeline it protects.
    //    3 slots rather than 2 so a reader only has to be preempted across two whole
    //    refreshes to collide, instead of one.
    // 2. A mutex around the refresh itself, so route rebuilds are serialised and only
    //    one thread does the work per tick. The throttle stamp is per-thread so the
    //    common case does not even contend on the mutex.
    inline constexpr int kPacketPoolSize = 3;

    // ---- optics diagnostic cadences (2026-09-27) -------------------------------
    //
    // Two rates, not one, because they answer different questions and have very
    // different costs.
    //
    // `kOpticFovTraceMs` (120 ms) drives the one-line live FOV trace. It is cheap -- two
    // `get_fieldOfView` calls and a format -- and it is the only way to see the scope
    // actually ANIMATE. A Tarkov ADS transition is a few hundred ms, so the previous
    // 2 s cadence could not resolve one; it only ever caught settled endpoints, which is
    // why the FOV looked like a discrete 27.00/6.00 toggle rather than a sweep.
    //
    // `kOpticDumpMs` (600 ms) drives the full descriptive dump (perf / proj / map / mat
    // / cond / vp / corner / cull / pipeline / region / s7 / flap). Lowered from 2000 ms,
    // but deliberately kept well above the trace rate: it is ~12 lines per emission and
    // runs inside the refresh mutex, so matching the trace rate would multiply the whole
    // set for no extra information about the animation.
    //
    // Both are floored well above the ~15.6 ms granularity of GetTickCount64 on this
    // machine -- a sub-16 ms "cadence" is not a cadence, it is a coin toss.
    inline constexpr ULONGLONG kOpticFovTraceMs = 120;
    inline constexpr ULONGLONG kOpticDumpMs = 600;
    inline optics::lens::packet g_pkt_pool[kPacketPoolSize];
    inline std::atomic<int> g_pkt_published{-1};   // -1 = nothing published yet
    inline std::atomic<int> g_pkt_next{0};
    inline std::atomic<bool> g_route_valid{false};
    inline std::atomic<Il2CppObject*> g_local_player{nullptr};
    // Serialises build_route + acquire_packet + publish. Held only for the refresh,
    // never while drawing.
    inline std::mutex g_optic_refresh_mutex;

    inline struct optic_lens_frame_state {
        optics::lens::route route{};   // guarded by g_optic_refresh_mutex

        // ---- sight-interchangeability verdict (2026-09-27) --------------------
        //
        // The route staleness predicate used to be plain pointer inequality, which was
        // WRONG rather than merely racy: the game alternates `CurrentOpticSight` between
        // two adjacent instances about twice a second, and each alternation dropped a
        // perfectly good route and cost up to a second of radial fallback at the 1 Hz
        // rebuild throttle. Previously that was written off as a ~200 ms performance nit.
        // The live log says otherwise -- `auto_k` (1/magnification) flips 0.166 <-> 0.761
        // in lockstep, a 4.6x zoom swing, and the user sees the ESP zoom switch.
        //
        // The verdict is not assumed, it is MEASURED: the first time a rebuild produces a
        // route from the other instance, the two are compared on the quantities a route
        // is actually consumed for (mesh geometry, affine pieces, coverage, lens bounds).
        // See optics::lens::routes_interchangeable for why the instance id and the
        // pointer are excluded, and why the FOV difference is not part of the answer.
        optics::lens::route prev_accepted{};  // last accepted route, for the comparison
        uintptr_t equiv_sight_a = 0;          // the two sights found interchangeable
        uintptr_t equiv_sight_b = 0;
        bool equiv_measured = false;          // has a comparison ever been made?
        bool equiv_same = false;              // and what did it say?
    } g_optic_lens;

    // The published packet, or nullptr when none has been published. Validity lives in
    // the packet's own `valid` flag, so a reader can never pair a new camera with an
    // old mapping the way a separately-stored bool allowed.
    inline const optics::lens::packet* optic_lens_published() {
        const int s = g_pkt_published.load(std::memory_order_acquire);
        if (s < 0) return nullptr;
        const optics::lens::packet* p = &g_pkt_pool[s];
        return p->valid ? p : nullptr;
    }

    inline void optic_lens_note_local_player(Il2CppObject* player) {
        g_local_player.store(player, std::memory_order_release);
    }

    // The main/FPS camera, published by EspModule each frame. The section 7 main-camera
    // pass needs it and nothing else in this header resolves it: world_to_screen_optic
    // is handed only the OPTIC camera, and the optic camera's own projection is exactly
    // what must not be used outside the mask. Atomic because EspModule's frame thread
    // publishes it and both projection threads read it.
    inline std::atomic<Il2CppObject*> g_esp_fps_cam{nullptr};
    inline void note_esp_fps_camera(Il2CppObject* cam) {
        g_esp_fps_cam.store(cam, std::memory_order_release);
    }

    // Counters for the optic projection path. "No magnification" has two causes that
    // look identical on screen: the scoped matrix in use but wrong, or project_point
    // failing so everything falls through to the legacy radial fit whose scale is
    // CLAMPED to [0.15, 1.5] (4x is unreachable through a 1.5x cap). Counted rather
    // than guessed. Declared here because the drain in optic_lens_ensure_frame reads it.
    struct optic_proj_counters {
        std::atomic<unsigned long long> attempts{0};
    // Split from fell_back, which counted BOTH "no packet" and "project_point refused
    // the point" in one number. That conflation is what made a 56.7% fallback rate read
    // as packet unavailability for two runs, when the packet is available 98.4% of the
    // time and the real cause is individual points failing projection (20.4% of all
    // project_point calls are behind_optic). Same shape as the interval-decline
    // omission: one total covering two different fixes.
    std::atomic<unsigned long long> fell_back_no_packet{0};
    std::atomic<unsigned long long> fell_back_proj_failed{0};
    // The per-point dispatch path (world_to_screen_optic) reaching the fallback, as
    // distinct from the connected-segment path (world_to_screen_optic_scoped). Both
    // share `attempts` and `fell_back`; without this the split covered only one of them
    // and the total did not reconcile. See the increment site.
    std::atomic<unsigned long long> fell_back_pointwise{0};
    // Fallbacks that arrived because the PIPELINE had no packet for this frame, as
    // opposed to a fallback that arrived because the packet was fine and refused this
    // one point (which is the legitimate outside-the-lens case). Before 2026-10-04 the
    // two shared one counter, so the "NO PACKET ... drawn UNCLIPPED" warning counted
    // refusals as packet failures and overstated the damage.
    //
    // Measured 2026-10-04 10:03-10:04, the distinction mattered: of 9,690 fallbacks in
    // one raid, 7,642 were genuine ensure failures -- and every one of them landed in
    // the ~4 s after an ADS transition, where the route had just been accepted and no
    // packet had been published yet. Refusals were 0 in those windows.
    std::atomic<unsigned long long> fell_back_ensure_culled{0};
    // Of the points that reached the fallback, how many came back in front of the camera
    // and therefore get DRAWN, versus behind it and rejected by is_visible(). Without
    // this, "fallback" reads as "misplaced geometry" when it may be almost entirely
    // geometry that is correctly culled a moment later.
    std::atomic<unsigned long long> fallback_drawn{0};
    std::atomic<unsigned long long> fallback_culled{0};
        std::atomic<unsigned long long> scoped_ok{0};
        std::atomic<unsigned long long> fell_back{0};
        std::atomic<unsigned long long> ensure_failed{0};
    };
    inline optic_proj_counters& optic_proj_stats() { static optic_proj_counters c{}; return c; }

    inline bool optic_lens_ensure_frame() {
        const ULONGLONG now = GetTickCount64();
        // Throttle BOTH outcomes, not just success. This used to short-circuit only when
        // `packet_valid` was true, so a FAILING pipeline got no throttling at all -- and
        // failing is exactly when it is most expensive. world_to_screen_optic calls this
        // once per PROJECTED POINT, not once per frame, so with the guard bypassed the
        // whole of acquire_packet ran per point: measured 2026-09-26 at 14,144 calls in
        // 2 s (7,072/s) x 107 us = ~76% of a core, which was the 1x-only stutter.
        //
        // Caching a failure for the window also matches the spec (line 576): "Publish
        // one immutable accepted packet so drawing cannot mix a new camera with an old
        // lens mapping." GetTickCount64 only updates every ~15.6 ms, so a 4 ms window
        // behaves as "once per timer tick" (~64 Hz) -- ample, since the inputs it reads
        // are refreshed by the game every frame.
        //
        // The stamp is now PER THREAD. It used to be a field of the shared struct, so
        // two threads racing through here could each see the other's stamp as stale and
        // both proceed -- which is how the same packet got built twice per tick from two
        // threads reading the game at different instants. Per-thread, each thread
        // throttles itself correctly, and the mutex below arbitrates the actual work.
        static thread_local ULONGLONG s_last_attempt_ms = 0;
        if (now - s_last_attempt_ms < 4)
            return optic_lens_published() != nullptr;
        s_last_attempt_ms = now;

        // Build into a slot that is NOT published, so a concurrent reader keeps using
        // the last good packet for the whole build rather than observing a torn one.
        const int slot = g_pkt_next.fetch_add(1, std::memory_order_relaxed) % kPacketPoolSize;
        optics::lens::packet& out = g_pkt_pool[slot];
        out.valid = false;

        Il2CppObject* const local_player =
            g_local_player.load(std::memory_order_acquire);
        if (!local_player) {
            // Not a rejection: the route needs a local player, and the optic frame is
            // evaluated before one exists (loading, menu, death). Same "idle" class as
            // "no CurrentOpticSight" below. Logged once at DEBUG, and ASCII-only so it
            // never reintroduces a non-ASCII byte into the log.
            static bool s_logged_missing_player = false;
            if (!s_logged_missing_player)
            {
                s_logged_missing_player = true;
                logger::debug("optic-route: idle (no local player yet)");
            }
            return false;
        }
        // Serialise the refresh. Everything from here to the publish is one
        // read-the-game-and-build unit; two threads running it concurrently is what
        // produced the pointer flapping. Held across build_route and acquire_packet
        // only -- never while drawing, and readers take no lock at all.
        std::lock_guard<std::mutex> refresh_lock(g_optic_refresh_mutex);

        // Whether the PREVIOUS acquire failed because the optic sight object changed.
        // Hoisted to function scope because the rebuild below needs to READ it and the
        // `route_stale` handling further down needs to WRITE it -- they are the two ends
        // of one decision, and a static declared inside the rebuild block is unreachable
        // from the writer.
        static bool s_fail_was_sight_change = false;

        if (!g_route_valid.load(std::memory_order_relaxed)) {
            // Retry the route and REPORT why it is rejected — the pipeline fell back
            // silently every frame in-game (esp-path log 2026-09-25) and the failing step
            // was invisible. The stamp moved under the refresh mutex (it guards the
            // rebuild), and the "why" string with it -- both were function-local statics
            // shared by two threads, so a thread could suppress another's report.
            static ULONGLONG s_last_route_try_ms = 0;
            static std::string s_last_route_why;
            const ULONGLONG now_route = GetTickCount64();

            // The throttle is NOT one number, and that is the fix for the visible zoom
            // switch (2026-09-27).
            //
            // Measured this run: the two alternating OpticSight instances are the SAME
            // mesh asset (66 verts / 216 indices, extents within 0.00026) but their lens
            // CENTRES sit ~0.041 units -- 4.1 cm -- apart, stably, at the same player
            // position. That is 4x the 1 cm tolerance, so routes_interchangeable
            // correctly says DISTINCT: these are two genuinely different optics (the
            // auto_k bimodality, 0.166 vs 0.761, is the same fact seen from the camera
            // side). Pointer inequality is therefore the RIGHT predicate, and the old
            // "treat the flap as equivalent" fix was standing on a bad measurement.
            //
            // With that settled, the visible switch is simply the 1 s throttle: the game
            // changes optic about twice a second, we waited up to a second to follow, and
            // the ESP spent the gap on the radial fallback, whose `auto_k` is calibrated
            // against whichever optic is current. So a sight change -- and ONLY a sight
            // change -- gets a short retry interval. Cost: build_route measures
            // 1.5-4.6 ms, at ~2 flaps/s that is well under 1% of a second.
            //
            // Every other rejection (mask polygon empty, ellipse gate, no local player)
            // keeps the 1 s interval, because those are not optic changes and hammering
            // the build for them is what the throttle was for.
            const bool sight_change = s_fail_was_sight_change;
            const ULONGLONG interval = sight_change ? 60 : 1000;
            if (now_route - s_last_route_try_ms < interval) {
                g_pkt_published.store(slot, std::memory_order_release);
                return false;
            }
            s_last_route_try_ms = now_route;
            std::string why;
            const bool built =
                optics::lens::build_route(local_player, g_optic_lens.route, why);
            g_route_valid.store(built, std::memory_order_relaxed);
            if (built) {
                s_last_route_why.clear();
                // Only compare routes built from DIFFERENT sights.
                //
                // This is a correction of my own bug, and the log caught it. The first
                // version compared `prev_accepted` against the new route unconditionally,
                // but rebuilds are not only caused by a sight change -- "lens mask polygon
                // empty after clip" and the ellipse gate also drop the route. So two
                // consecutive rebuilds can both come from the SAME sight, and comparing a
                // route with itself is trivially true:
                //
                //   optic-equivalence: sights 0xE85CD200/0xE85CD200 now INTERCHANGEABLE
                //   optic-flap: suppressed=92 rebuilds=0 verdict=interchangeable
                //
                // That verdict was about a pair that was never compared, and it then
                // suppressed 92 real mismatches against a sight it knew nothing about.
                // A self-comparison carries no information, so it must not form a verdict
                // and must not be allowed to stand as the last measurement either.
                const bool had_previous = g_optic_lens.prev_accepted.valid;
                const bool cross_sight = had_previous
                    && g_optic_lens.prev_accepted.optic_sight_managed
                        != g_optic_lens.route.optic_sight_managed;
                if (cross_sight) {
                    const bool same_now = optics::lens::routes_interchangeable(
                        g_optic_lens.prev_accepted, g_optic_lens.route);
                    g_optic_lens.equiv_sight_a = g_optic_lens.prev_accepted.optic_sight_managed;
                    g_optic_lens.equiv_sight_b = g_optic_lens.route.optic_sight_managed;
                    g_optic_lens.equiv_measured = true;
                    if (same_now != g_optic_lens.equiv_same) {
                        g_optic_lens.equiv_same = same_now;
                        logger::info(std::format(
                            "optic-equivalence: sights 0x{:X}/0x{:X} {} "
                            "(mesh {}/{} verts, pieces {}/{}, dCentre {:.4f} units, tol {:.2f})",
                            static_cast<unsigned>(g_optic_lens.equiv_sight_a),
                            static_cast<unsigned>(g_optic_lens.equiv_sight_b),
                            same_now ? "now INTERCHANGEABLE - rebuild flap suppressed"
                                     : "now DISTINCT - pointer staleness applies again",
                            g_optic_lens.prev_accepted.mesh_vertices,
                            g_optic_lens.route.mesh_vertices,
                            g_optic_lens.prev_accepted.affine_pieces,
                            g_optic_lens.route.affine_pieces,
                            static_cast<double>(std::sqrt(
                                std::pow(g_optic_lens.prev_accepted.lens_bounds_center[0]
                                         - g_optic_lens.route.lens_bounds_center[0], 2.0f) +
                                std::pow(g_optic_lens.prev_accepted.lens_bounds_center[1]
                                         - g_optic_lens.route.lens_bounds_center[1], 2.0f) +
                                std::pow(g_optic_lens.prev_accepted.lens_bounds_center[2]
                                         - g_optic_lens.route.lens_bounds_center[2], 2.0f))),
                            0.01));
                    }
                }
                g_optic_lens.prev_accepted = g_optic_lens.route;
                ++optics::lens::g_flap.rebuilds;
                logger::info("optic-route: accepted");
            } else {
                if (why != s_last_route_why)
                {
                    s_last_route_why = why;
                    // "Not applicable yet" is not a rejection: there is simply no
                    // optic to build a route for (hipfire, menu, scope not raised).
                    // These were logged at INFO, which made a transient state look
                    // like a failure and buried the reasons that actually matter.
                    const bool not_applicable = why.find("no CurrentOpticSight") != std::string::npos
                        || why.find("no local player") != std::string::npos
                        || why.find("no OpticCameraManager") != std::string::npos;
                    if (not_applicable)
                        logger::debug(std::format("optic-route: idle ({})", why));
                    else
                        logger::info(std::format("optic-route: rejected ({})", why));
                }
                g_pkt_published.store(slot, std::memory_order_release);
                return false;
            }
        }
        // Timing drain for the FPS regression reported 2026-09-26 (route accepted,
        // pipeline=valid, FPS collapsed to near zero). acquire_packet is the only
        // thing newly on the per-frame path now that the route validates.
        //
        // Replaces a first attempt that timed the call with GetTickCount64 and
        // reported a stable "47 ms" -- which was 3 timer ticks, because
        // GetTickCount64 only updates every ~15.6 ms on this machine. The accumulator
        // in optics::lens uses QueryPerformanceCounter and is drained here.
        const char* acq_stage = "start";
        uintptr_t sight_seen = 0;
        bool route_stale = false;
        // The verdict has to be handed IN, because acquire_packet returns early on a
        // sight mismatch: a mismatch it is told is benign is built through rather than
        // dropped. Passing it as an out-of-band flag to be cleared afterwards was the
        // first attempt and does nothing at all.
        const bool sights_interchangeable =
            g_optic_lens.equiv_measured && g_optic_lens.equiv_same;
        const bool built = optics::lens::acquire_packet(
            g_optic_lens.route, local_player, out, &acq_stage, &sight_seen, &route_stale,
            &sights_interchangeable);
        // Publish only now. Everything above wrote into `slot`, which no reader could
        // see; this release-store is the single point where the new packet becomes
        // visible, so a reader sees either the whole previous packet or the whole new
        // one. That is the spec's "one immutable accepted packet".
        g_pkt_published.store(slot, std::memory_order_release);
        // ---- the staleness verdict (2026-09-27) --------------------------------
        //
        // The old behaviour dropped the route on any pointer inequality, which was wrong
        // rather than merely racy: the game alternates CurrentOpticSight between two
        // adjacent instances roughly twice a second, so this fired ~2x/s, each time
        // costing up to a second of radial fallback at the 1 Hz rebuild throttle. The
        // live log put a number on what that looked like -- auto_k (1/magnification)
        // flipping 0.166 <-> 0.761 in lockstep, a 4.6x swing, which is the "ESP zoom
        // takes a few ticks to switch" the user reported.
        //
        // It was previously written off as a ~200 ms performance nit. That was an
        // underestimate of the wrong kind: it cost not milliseconds but a visible
        // discontinuity, and the reason was visible in the data all along.
        //
        // The verdict is applied inside acquire_packet (see the call above), because
        // that is where the early return on a mismatch lives. Here it is only
        // reported.
        if (route_stale) {
            // The cached route was built against a different OpticSight object. Drop it
            // so the block above rebuilds on its next pass. Without this the route stays
            // pinned to a stale pointer forever: nothing else set route_valid back to
            // false, so acquire_packet failed every frame against a pointer the game had
            // already moved on from. Observed 2026-09-26 23:25 as route sight 0x94924480
            // vs live 0x94924580, both stable, never reconciling.
            //
            // This is the WRITER half of the throttle decision. A sight change is the one
            // rejection that is not a transient failure but a genuine state change, so it
            // earns the short rebuild interval; every other reason keeps the 1 s one.
            // Recording it here rather than inferring it is what makes the distinction
            // real -- `acq_stage` is the game's own verdict on why the packet failed.
            s_fail_was_sight_change = std::string_view(acq_stage)
                .find("optic sight object changed") != std::string_view::npos;
            //
            // 2026-09-27: this is also where the two-threaded build made things worse.
            // Each thread compared its OWN sight_seen against a route the other may
            // have just rebuilt, so a thread that lost the race saw a "changed" sight
            // that was merely the other thread's fresh route -- dropping a perfectly good
            // route and re-invalidating the packet. Serialising the refresh (above) is
            // what removes that feedback loop; the check itself is unchanged.
            g_route_valid.store(false, std::memory_order_relaxed);
        }
        // NO return here. An earlier revision of the concurrency fix put `return built;`
        // at this point, which silently made the ENTIRE remainder of this function dead
        // code: the `optic-packet: invalid` report, the whole diagnostic drain
        // (optic-perf / -map / -mat / -cond / -vp / -corner / -cull / -pipeline /
        // -region / -s7 / -pose) and -- worst of all -- the lens-mask publish that sets
        // game_state::esp_lens_mask_count. Symptom observed 2026-09-27 15:13-15:15: a log
        // with no optic diagnostics at all and `maskN=0` on every esp-path line despite
        // `pipeline=valid`, because the mask was never published.
        //
        // /W4 did NOT flag it -- C4702 did not fire on this shape, so "0 errors 0
        // warnings" was not evidence. The control flow had to be read.
        //
        // Report WHY the packet is invalid. An accepted route with an invalid packet
        // means the ESP silently runs the legacy radial fit, whose scale is capped at
        // 1.5 -- which looks exactly like "not zoomed enough".
        // Rate-limited as well as on-change: two stages were observed ALTERNATING within
        // a frame, so a pure on-change guard logged ~5 lines/second.
        if (!built)
        {
            // Counted here rather than on the rate-limited log below, because that log
            // fires on CHANGE and at most once per 2 s, so its counts are "how many times
            // did the reason change", not "how long did this reason hold the packet down".
            optics::lens::g_region.rejects.record(acq_stage);

            // `cover` must not outlive the packet that produced it.
            //
            // 2026-10-01. mask_cover_frac is written inside the ellipse block, which runs
            // BEFORE the landing-bound, corner-agreement and lens-size gates. A packet
            // rejected by any of those has already published its area, and nothing cleared
            // it, so `optic-region: cover=` reported a confident number for a mask that
            // was thrown away -- observed as "cover=23.4%" in a window where the packet was
            // invalid and 100% of section 7 calls drew unclipped.
            //
            // Zeroed here so the line reads 0 rather than a stale value. Zero is honest
            // here in a way it is not elsewhere: there is no valid mask, so there is no
            // coverage, and the drain prints the reason alongside it.
            optics::lens::g_region.mask_cover_frac = 0.f;

            static ULONGLONG s_last_stage_log = 0;
            const ULONGLONG now_stage = GetTickCount64();
            if (now_stage - s_last_stage_log >= 2000)
            {
                s_last_stage_log = now_stage;
                if (sight_seen && sight_seen != g_optic_lens.route.optic_sight_managed)
                    logger::info(std::format(
                        "optic-packet: invalid at [{}] | route sight=0x{:X} live sight=0x{:X} "
                        "(rebuilt at most 1x/s) | route[{}]", acq_stage,
                        static_cast<unsigned>(g_optic_lens.route.optic_sight_managed),
                        static_cast<unsigned>(sight_seen),
                        optics::lens::route_signature(g_optic_lens.route)));
                else
                    logger::info(std::format("optic-packet: invalid at [{}] (route accepted, "
                                             "ESP on radial fallback)", acq_stage));
            }
        }
        else
        {
            ++optics::lens::g_region.rejects.packets_built;
            static bool s_reported_valid = false;
            if (!s_reported_valid)
            {
                s_reported_valid = true;
                logger::info("optic-packet: valid (section 7 scoped projection active)");
            }
        }
        {
            // ---- live FOV trace, at a deliberately much higher cadence ----------
            //
            // 2026-09-27, for the zoomable (1x-6x) test. The previous single 2 s gate
            // for the whole optics dump is why the FOV only ever appeared as EXACTLY
            // 27.00 deg or 6.00 deg: at 2 s sampling, a sub-second ADS transition is
            // simply never caught in flight, so "two clusters" looked like a discrete
            // toggle and was read as two different optics. It was the sampling rate
            // hiding the animation, not the absence of one.
            //
            // `mag` is the number the whole calibration should agree with: the game
            // computes it, we recompute it from the two live cameras, and `k` is our
            // radial calibration for the same instant. Printing them together turns
            // "does the zoom look right" into a per-sample numeric check -- and
            // `1/mag` is what `auto_k` is supposed to be, so any disagreement is
            // immediately visible rather than having to be eyeballed.
            static ULONGLONG s_last_fov_log = 0;
            const ULONGLONG now_fov = GetTickCount64();
            if (now_fov - s_last_fov_log >= kOpticFovTraceMs) {
                s_last_fov_log = now_fov;
                // 2026-09-30. This read `game_state::esp_optic_cam` alone, which is
                // structurally null here: optic_lens_ensure_frame() is called from
                // setup_esp_optic_frame() twice, and both calls sit BETWEEN that
                // function's unconditional `esp_optic_cam = nullptr` and its final
                // `esp_optic_cam = cam`. The `if (optic_cam)` gate was therefore false
                // on the hot paths, and the trace printed ZERO lines for an entire raid
                // on 2026-09-30 while the optics pipeline was demonstrably running (369
                // `esp-path` lines, 41 `optic-radial` samples in the same session).
                //
                // That is the failure mode this project keeps hitting: a diagnostic
                // that is silent when it fails, so its absence reads as "nothing to
                // report" rather than "I never ran". Hence the fallback AND the
                // one-shot notice below.
                Il2CppObject* const optic_cam = game_state::esp_optic_cam
                    ? game_state::esp_optic_cam
                    : game_state::esp_optic_cam_cached;
                if (!optic_cam) {
                    // Still nothing. Say so ONCE and loudly enough to find, rather
                    // than staying silent, because silence here is indistinguishable
                    // from "no optic was in use".
                    static bool s_reported_no_cam = false;
                    if (!s_reported_no_cam) {
                        s_reported_no_cam = true;
                        logger::warn("optic-fov: trace suppressed -- neither esp_optic_cam nor "
                            "esp_optic_cam_cached is set, so kerr cannot be measured. The optics "
                            "pipeline may be idle, or the camera cache is not being written.");
                    }
                }
                if (optic_cam) {
                    const float fov_o = unity::camera_fov(optic_cam);
                    Il2CppObject* const eye_cam =
                        g_esp_fps_cam.load(std::memory_order_acquire);
                    const float fov_e = eye_cam ? unity::camera_fov(eye_cam) : 0.f;
                    constexpr float kDeg2Rad = 3.14159265358979f / 180.0f;
                    const double mag =
                        (fov_e > 1.0f && fov_o > 0.01f)
                            ? std::tan(static_cast<double>(fov_e) * 0.5 * kDeg2Rad) /
                                  std::tan(static_cast<double>(fov_o) * 0.5 * kDeg2Rad)
                            : 0.0;
                    const optics::lens::packet* const pk = optic_lens_published();
                    // `kerr` is the acceptance number for the whole calibration: k should
                    // equal 1/mag, so kerr = k*mag should be 1.0. Before the 2026-09-27 fix
                    // it was the scope's zoom ladder instead -- 0.997 at 1x climbing to 5.994
                    // at 6x, monotone across all 14 samples -- which is how the double count
                    // was identified rather than guessed at. If kerr is not ~1.0 across a zoom
                    // sweep, the calibration is wrong again, and this says so per sample.
                    const double k =
                        static_cast<double>(game_state::esp_zoom_final_k);
                    const double kerr = (mag > 0.0) ? k * mag : 0.0;
                    logger::debug(std::format(
                        "optic-fov: fov={:.3} eye={:.3} mag={:.3}x | 1/mag={:.4} "
                        "k={:.4} kerr={:.3} user={:.4} | pkt={} cam={} sight=0x{:X} mesh={}",
                        static_cast<double>(fov_o), static_cast<double>(fov_e), mag,
                        mag > 0.0 ? 1.0 / mag : 0.0,
                        k, kerr,
                        static_cast<double>(game_state::esp_zoom_user_k),
                        pk ? "valid" : "FALLBACK",
                        // Which camera the FOV came from, so a stale cache is visible.
                        // `eye` is the one that can silently zero the whole line: with
                        // no FPS camera, fov_e is 0, mag is 0, and kerr prints 0.000 --
                        // which looks like a calibration failure rather than a missing
                        // reference camera.
                        game_state::esp_optic_cam ? "live" : "cached",
                        static_cast<unsigned>(g_optic_lens.route.optic_sight_managed),
                        g_optic_lens.route.mesh_id));
                }
            }
        }
        {
            using namespace optics::lens;
            static ULONGLONG s_last_perf_log = 0;
            const ULONGLONG now_perf = GetTickCount64();
            perf_accum& perf = perf_sections();
            if (now_perf - s_last_perf_log >= kOpticDumpMs && perf.calls) {
                s_last_perf_log = now_perf;
                const double n = static_cast<double>(perf.calls);
                auto& pc = perf_counters();
                const auto vq = pc.virtual_queries.exchange(0, std::memory_order_relaxed);
                const auto rh = pc.range_hits.exchange(0, std::memory_order_relaxed);
                const auto rm = pc.range_misses.exchange(0, std::memory_order_relaxed);
                logger::debug(std::format(
                    "optic-perf: {} calls, {:.0f} us/call | meta={:.0f} matrix={:.0f} "
                    "pose={:.0f} chain={:.0f} mask={:.0f} | range hit/miss={}/{} vq={} "
                    "({:.1f}/call) clears={}",
                    perf.calls, perf.total_micros / n,
                    perf.micros[perf_metadata] / n, perf.micros[perf_matrices] / n,
                    perf.micros[perf_pose] / n, perf.micros[perf_lens_chain] / n,
                    perf.micros[perf_mask] / n,
                    rh, rm, vq, static_cast<double>(vq) / n,
                    // Cumulative since process start, NOT per-window: the question is
                    // whether the table is ever dropped mid-raid at all, and a per-window
                    // delta would read 0 in exactly the steady state we care about. A
                    // non-zero total on a line whose miss count is also non-zero means the
                    // misses are refill, not collision -- and resizing the table would make
                    // that worse, because there would be more slots to refill.
                    optics::lens::g_range_clears));
                auto& op = optic_proj_stats();
                const auto att = op.attempts.exchange(0, std::memory_order_relaxed);
                const auto ok = op.scoped_ok.exchange(0, std::memory_order_relaxed);
                const auto fb = op.fell_back.exchange(0, std::memory_order_relaxed);
                const auto ef = op.ensure_failed.exchange(0, std::memory_order_relaxed);
                const optics::lens::packet* const pk_pub = optic_lens_published();
                const optics::lens::packet& pk = pk_pub ? *pk_pub : g_pkt_pool[0];
                const float scr_w = static_cast<float>(menu::get_width());
                const float scr_h = static_cast<float>(menu::get_height());
                const int scr_wi = static_cast<int>(scr_w);
                const int scr_hi = static_cast<int>(scr_h);
                const int land_px = static_cast<int>((pk.centre_landing.x + 1.f) * 0.5f * scr_w);
                const int land_py = static_cast<int>((1.f - pk.centre_landing.y) * 0.5f * scr_h);
                const char* stale = pk.valid ? "" : " [STALE: last packet was REJECTED]";
                // Previous sample of the setup_esp_optic_frame invocation counter, so the
                // radial diagnostic can report how many times the function ran since the
                // last dump. It is reset and re-clamped independently of esp_optic_radial,
                // so the two counters move together ONLY when the calibration path is the
                // one that ran -- which is the whole question.
                static unsigned long long s_radial_calls_last = 0;
                // A counter that jumped backwards would mean the dump and the writer are
                // looking at different processes/threads' copies; assert-by-observation
                // rather than trusting the subtraction.
                const unsigned long long calls_now = game_state::esp_optic_frame_calls;
                const unsigned long long calls_delta =
                    calls_now >= s_radial_calls_last ? calls_now - s_radial_calls_last : 0ull;
                logger::debug(std::format(
                    "optic-proj: attempts={} scoped={} fell_back={} ensure_failed={} | "
                    "fell_back no_packet={} proj_failed={} pointwise={} | "
                    "fallback drawn={} culled={} | "
                    "fail_closed={} | "
                    "mask {}x{} of {}x{} | radK_drawn={:.3f} radK_atdump={:.3f} route={}",
                    att, ok, fb, ef,
                    op.fell_back_no_packet.exchange(0, std::memory_order_relaxed),
                    op.fell_back_proj_failed.exchange(0, std::memory_order_relaxed),
                    op.fell_back_pointwise.exchange(0, std::memory_order_relaxed),
                    op.fallback_drawn.exchange(0, std::memory_order_relaxed),
                    op.fallback_culled.exchange(0, std::memory_order_relaxed),
                    // Subset of `drawn + culled` that was refused outright instead of
                    // being drawn from the radial fit. This is the number that should
                    // now carry the ADS-transition cost: `drawn` was 7,342 in the
                    // 2026-10-04 capture and should be 0 across the same windows, with
                    // this taking them instead. If `drawn` is still large while this
                    // stays small, the unclipped draws are coming from somewhere other
                    // than an ensure failure and the guard is in the wrong place.
                    op.fell_back_ensure_culled.exchange(0, std::memory_order_relaxed),
                    pk.valid ? static_cast<int>(pk.mask.size()) : 0,
                    game_state::esp_lens_mask_count, scr_wi, scr_hi,
                    static_cast<double>(game_state::esp_optic_radial_drawn),
                    static_cast<double>(game_state::esp_optic_radial),
                    g_optic_lens.route.mesh_id));
                // `radK_drawn` vs `radK_atdump`, and why both are here.
                //
                // This line used to print one field, `radK`, bound to esp_optic_radial. On the
                // 10-03 capture that read `radK=1.000` on every window while the very next
                // line showed `drawn_k=0.1220 final_k=0.1220` for the same window. The
                // conclusion a reader draws from `radK=1.000` -- "the radial fallback draws
                // unzoomed" -- is the opposite of the truth: the fallback draws at k=0.122.
                //
                // The cause is that esp_optic_radial is reset to 1.f UNCONDITIONALLY at the
                // top of setup_esp_optic_frame (game_state.h:33, two writers, one of them the
                // reset) and only then set to k if the optic is actually being used. This
                // 600 ms dump can fire in the window between those two writes, where the
                // value is definitionally the reset and no projection has used it.
                //
                // esp_optic_radial_drawn is the sample taken at the FIRST world_to_screen call
                // of each epoch, which is the value the projection actually consumed. It is
                // sampled once per epoch, not averaged over the window, so treat it as one
                // frame's reading -- but it is the right frame, where esp_optic_radial is not.
                //
                // Both are printed because the pair is what makes the trap checkable. A
                // single field with a plausible name is what let this sit unnoticed.
                //
                // The `optic-radial` line below carries the full writer/consumer cross-check,
                // and it supersedes the `radK`-based reading of the epochs:
                //   ep != set_ep                      -> the unconditional reset was last,
                //                                              so the calibration's k is not
                //                                              what the current frame used
                // and `radK_drawn` is the value that answers it.
                // `calls` is the setup_esp_optic_frame invocation count since the last dump,
                // next to the number of acquire calls -- more calls than overlay frames means
                // a non-ADS pass is resetting the global out from under the consumer.
                logger::debug(std::format(
                    "optic-radial: drawn_k={:.4f} drawn_set={:.4f} | atdump_k={:.4f} "
                    "set_k={:.4f} final_k={:.4f} ep={} set_ep={} calls={} calls_since_dump={}",
                    static_cast<double>(game_state::esp_optic_radial_drawn),
                    static_cast<double>(game_state::esp_optic_radial_drawn_set),
                    static_cast<double>(game_state::esp_optic_radial),
                    static_cast<double>(game_state::esp_optic_radial_set),
                    static_cast<double>(game_state::esp_zoom_final_k),
                    game_state::esp_optic_radial_epoch,
                    game_state::esp_optic_radial_set_epoch,
                    game_state::esp_optic_frame_calls,
                    calls_delta));
                s_radial_calls_last = calls_now;
                // NDC spans 2.0 across the screen, so a delta converts with width/2, not
                // width. An earlier version omitted the /2 and reported the lens image
                // as 1316x1316 px on a 1920x1080 screen -- a box taller than the display,
                // which is impossible and briefly read as a real defect.
                logger::debug(std::format(
                    "optic-map{}: opticNDC(0,0) lands ndc=({:.4f},{:.4f}) px=({},{} of {}x{}, "
                    "centre {}x{}) | lens image ndc [{:.3f},{:.3f}]..[{:.3f},{:.3f}] "
                    "= {:.0f}x{:.0f} px",
                    stale, static_cast<double>(pk.centre_landing.x),
                    static_cast<double>(pk.centre_landing.y), land_px, land_py, scr_wi, scr_hi,
                    scr_wi / 2, scr_hi / 2,
                    static_cast<double>(pk.quad_lo.x), static_cast<double>(pk.quad_lo.y),
                    static_cast<double>(pk.quad_hi.x), static_cast<double>(pk.quad_hi.y),
                    (pk.quad_hi.x - pk.quad_lo.x) * scr_w * 0.5f,
                    (pk.quad_hi.y - pk.quad_lo.y) * scr_h * 0.5f));
                logger::debug(std::format(
                    "optic-mat{}: scales=({:.2f},{:.2f},{:.2f},{:.2f}) shifts=({:.3f},{:.3f},"
                    "{:.3f},{:.3f}) shiftDir=({:.2f},{:.2f},{:.2f},{:.2f})",
                    stale, static_cast<double>(pk.scales.x), static_cast<double>(pk.scales.y),
                    static_cast<double>(pk.scales.z), static_cast<double>(pk.scales.w),
                    static_cast<double>(pk.shifts.x), static_cast<double>(pk.shifts.y),
                    static_cast<double>(pk.shifts.z), static_cast<double>(pk.shifts.w),
                    static_cast<double>(pk.shift_dir.x), static_cast<double>(pk.shift_dir.y),
                    static_cast<double>(pk.shift_dir.z), static_cast<double>(pk.shift_dir.w)));
                logger::debug(std::format(
                    "optic-cond{}: HC.w={:.5f} |HU.w|={:.5f} |HV.w|={:.5f} gate_margin={:.2e} "
                    "(spec >1e-3) combined.w={:.3e}", stale,
                    static_cast<double>(pk.lens_basis_hc.w),
                    std::fabs(static_cast<double>(pk.lens_basis_hu.w)),
                    std::fabs(static_cast<double>(pk.lens_basis_hv.w)),
                    static_cast<double>(pk.w_gate_margin),
                    static_cast<double>(pk.combined_w)));
                // The scene-origin diagnostic: combined.w tracks optic_vp.m15, i.e. the
                // camera's distance from the WORLD ORIGIN. m11 is the sanity check that
                // +0xE8 really holds a projection matrix.
                logger::debug(std::format(
                    "optic-vp{}: optic m15={:+.5f} m03={:+.5f} m13={:+.5f} m11={:+.5f} | "
                    "main m15={:+.5f} | combined.w={:+.5f}", stale,
                    static_cast<double>(pk.optic_vp_m15), static_cast<double>(pk.optic_vp_m03),
                    static_cast<double>(pk.optic_vp_m13), static_cast<double>(pk.optic_vp_m11),
                    static_cast<double>(pk.main_vp_m15), static_cast<double>(pk.combined_w)));
                // The spec's line-578 corner test, evaluated on the PRIMARY chain.
                logger::debug(std::format(
                    "optic-corner{}: agreement={:.2e} ndc (line 578: four optic-NDC corners "
                    "must match imageQuad)", stale,
                    static_cast<double>(pk.corner_agreement_ndc)));
                {
                    const auto checks = game_state::esp_mask_cull_checks;
                    const auto rej = game_state::esp_mask_cull_rejected;
                    logger::debug(std::format(
                        "optic-cull: mode={} checks={} rejected={} ({:.0f}%) "
                        "fitted_mask_used={} lens_mask_pts={}",
                        game_state::esp_mask_cull_mode_at_count, checks, rej,
                        checks ? 100.0 * static_cast<double>(rej) / static_cast<double>(checks) : 0.0,
                        game_state::esp_mask_cull_fitted_used, game_state::esp_lens_mask_count));
                    game_state::esp_mask_cull_checks = 0;
                    game_state::esp_mask_cull_rejected = 0;
                    game_state::esp_mask_cull_fitted_used = 0;
                }
                // ---- Defect A: mask over-coverage, attributed -------------------
                // The one number the "mask covers too much" report has never had. See
                // optics::lens::defect_a for what each ratio would prove.
                //
                // Printed only when both radii are non-degenerate. A run where the mesh
                // silhouette is unavailable prints a WARN once from the route instead; if
                // both are missing, silence here is correct and the WARN is the signal.
                if (optics::lens::g_defect_a.valid && optics::lens::g_defect_a.mesh_available)
                {
                    const auto& d = optics::lens::g_defect_a;
                    const double rx = d.mesh_rx > 1e-6f ? d.aabb_rx / d.mesh_rx : 0.0;
                    const double ry = d.mesh_ry > 1e-6f ? d.aabb_ry / d.mesh_ry : 0.0;
                    // The ratio is only meaningful when the AABB was actually the source
                    // AND it passed containment. On a fallback frame the "ratio" compares
                    // the mesh against itself and is 1.0 by construction, which reads like
                    // a result and is not one, so it is suppressed rather than printed.
                    const bool ratio_valid = (d.source == 0)
                        && d.contain[0] > 0.f && d.contain[1] > 0.f && d.contain[2] > 0.f;
                    logger::debug(std::format(
                        "optic-defectA: src={} over={} | aabb r=({:.4f},{:.4f}) "
                        "mesh r=({:.4f},{:.4f}) | contain=({:+.5f},{:+.5f},{:+.5f})m | "
                        "ext=({:.5f},{:.5f},{:.5f}) verts={}/{} behind={} rej={}"
                        "{} mask_pts={} cover={:.1f}%",
                        d.source == 0 ? "aabb" : "MESH-FALLBACK",
                        ratio_valid ? std::format("Rx{:.3f}/Ry{:.3f}", rx, ry)
                                    : std::string("n/a"),
                        static_cast<double>(d.aabb_rx), static_cast<double>(d.aabb_ry),
                        static_cast<double>(d.mesh_rx), static_cast<double>(d.mesh_ry),
                        static_cast<double>(d.contain[0]), static_cast<double>(d.contain[1]),
                        static_cast<double>(d.contain[2]),
                        static_cast<double>(d.extents[0]), static_cast<double>(d.extents[1]),
                        static_cast<double>(d.extents[2]),
                        d.mesh_verts_projected, d.mesh_verts_projected + d.mesh_verts_behind,
                        d.mesh_verts_behind, d.aabb_rejected,
                        d.extents_rejected ? " BAD-EXTENTS" : "",
                        d.mask_points,
                        static_cast<double>(d.cover_frac) * 100.0));
                    // The area-based over-coverage, which needs neither the semi-axis ratio
                    // nor the containment verdict. Now a CONTROLLED measurement: both figures
                    // come from the same frame, the same projected quad and the same screen,
                    // differing only in which rect the ellipse was fitted to (see
                    // defect_a::cover_pair_*). The previous version divided two DISJOINT frame
                    // sets and carried a caveat saying so -- on the 10-03 capture it printed a
                    // smooth 1.124x -> 1.176x "rise" that was only the aabb sample count
                    // growing while the mesh side sat frozen at 21.49% / n=154.
                    //
                    // `used=aabb|mesh` names which rect the LIVE mask actually used this
                    // window. The ratio is a property of the geometry, not of the choice.
                    if (d.cover_pair_n >= 5)
                    {
                        const double ca = d.cover_pair_aabb_sum / static_cast<double>(d.cover_pair_n);
                        const double cm = d.cover_pair_mesh_sum / static_cast<double>(d.cover_pair_n);
                        logger::debug(std::format(
                            "optic-defectA: COVER aabb={:.2f}% mesh={:.2f}% -> over={:.3f}x "
                            "SAME-FRAME n={} skipped={} used={} rej={}",
                            ca * 100.0, cm * 100.0,
                            cm > 1e-6 ? ca / cm : 0.0,
                            d.cover_pair_n, d.cover_pair_skipped,
                            d.source == 0 ? "aabb" : "mesh", d.aabb_rejected));
                    }
                    else if (d.cover_pair_skipped > 0)
                    {
                        // Better one honest line than a ratio that will be quoted.
                        logger::debug(std::format(
                            "optic-defectA: COVER unavailable n={} skipped={} -- only one "
                            "ellipse source was usable on these frames, so no ratio exists",
                            d.cover_pair_n, d.cover_pair_skipped));
                    }
                }
                // ---- which mask is actually gating the draw ---------------------
                // `esp_ads_mask_allows` short-circuits on esp_ads_mask_mode == 0, and
                // EspModule calls clear_esp_ads_mask() every frame, so mode is 0 and the
                // function is a no-op: the cull counters ABOVE can only ever read zero
                // from is_visible(). The clipping that does happen runs through
                // optic_lens_segment_interval against the FITTED polygon instead.
                //
                // That distinction is the whole reason this line exists. An earlier
                // comment attributed the no-op to esp_ads_mask_half being 0, which is not
                // the gate: half is never read on this path, and a future reader fixing
                // the wrong variable would change nothing while looking busy. The numbers
                // are printed so the claim is checkable rather than believed.
                {
                    const int mode = game_state::esp_ads_mask_mode;
                    const int pts = game_state::esp_lens_mask_count;
                    static int s_last_mode = -1, s_last_pts = -1;
                    static float s_last_half = -1.f;
                    const float half = game_state::esp_ads_mask_half;
                    if (mode != s_last_mode || pts != s_last_pts || half != s_last_half)
                    {
                        s_last_mode = mode;
                        s_last_pts = pts;
                        s_last_half = half;
                        logger::debug(std::format(
                            "optic-maskgate: mode={} half={:.2f} fitted_pts={} -> "
                            "esp_ads_mask_allows={} (mode==0 short-circuits), fitted_polygon="
                            "{} is the only live clip",
                            mode, static_cast<double>(half), pts,
                            mode == 0 ? "ALWAYS-TRUE (never culls)" : "active",
                            pts >= 3 ? "present" : "ABSENT (draws unclipped)"));
                    }
                }
                // ---- the ONE live clip path, counted --------------------------------
                // Everything above reports on the region GEOMETRY. This reports on whether
                // the geometry is actually being APPLIED, which had never been measured:
                // esp_mask_cull_* is structurally zero, so until this line there was no
                // evidence in any log that section 7 clipping ran at all.
                //
                // `interval_full` and `s7_bare` are the two to watch. A high full-pass
                // count means segments are crossing the glass without being cut, which is
                // the over-coverage symptom arriving by a route that has nothing to do with
                // the ellipse: the mask would be right and the clipping still not happen.
                {
                    const auto& c = game_state::esp_s7;
                    if (c.interval_calls || c.s7_calls) {
                        logger::debug(std::format(
                            "optic-s7: interval calls={} ok={} full={} none={} | "
                            "s7 calls={} inside={} outside={} none={} | "
                            "no-complement: fully_inside={} complement_lost={} | "
                            "declined proj={} s7off={} nopacket={} size={} | "
                            "interval declined proj={} nopacket={} size={}",
                            c.interval_calls, c.interval_ok, c.interval_full, c.interval_none,
                            c.s7_calls, c.s7_inside, c.s7_outside, c.s7_none,
                            c.s7_fully_inside, c.s7_complement_lost,
                            c.s7_decl_proj, c.s7_decl_s7, c.s7_decl_nopacket, c.s7_decl_size,
                            c.interval_decl_proj, c.interval_decl_nopacket, c.interval_decl_size));
                        // Only worth saying out loud when it happens. A single lost
                        // complement among thousands is noise; a rising count is a defect
                        // and should not have to be diffed by hand to notice.
                        if (c.s7_complement_lost > 0)
                            logger::warn(std::format(
                                "optic-s7: {} segment(s) CROSSED the lens mask but produced no "
                                "outside piece -- the outside half of that geometry is being "
                                "dropped or resolved from the wrong camera. inside={} "
                                "fully_inside={} complement_lost={}",
                                c.s7_complement_lost, c.s7_inside, c.s7_fully_inside,
                                c.s7_complement_lost));
                        // The no-packet decline, which is a DIFFERENT failure from a lost
                        // complement and was the more consequential of the two.
                        //
                        // Measured 2026-10-01 over four boots: 5198 declines out of 80960
                        // calls, 6.4%, and every other decline cause was zero. When the
                        // packet is absent the caller draws the segment UNCLIPPED, so the
                        // section 7 split does not happen at all and geometry crossing the
                        // glass is resolved from one camera -- the same visible defect as
                        // the 2026-09-27 tearing bug, reached by a missing mask rather than
                        // a wrong one.
                        //
                        // It was invisible: one integer inside a counter list, and finding
                        // it meant aggregating the whole log by hand.
                        //
                        // Threshold, not any. The distribution is bursty, not sustained:
                        // 53 of 66 drain windows had nopacket=0, and the 13 that did ran
                        // 1.7% to 100%. A couple of scattered misses are just the packet not
                        // being ready yet, so warning on every one would train the reader to
                        // ignore the line exactly when a 100% window shows up.
                        if (c.s7_calls > 0)
                        {
                            const double miss_pct = 100.0 * static_cast<double>(c.s7_decl_nopacket)
                                / static_cast<double>(c.s7_calls);
                            if (miss_pct >= 10.0)
                                logger::warn(std::format(
                                    "optic-s7: NO PACKET for {}/{} calls ({:.0f}%) -- the section 7 "
                                    "split did not run and that geometry was drawn UNCLIPPED, so "
                                    "it crosses the lens glass boundary uncorrected",
                                    c.s7_decl_nopacket, c.s7_calls, miss_pct));
                        }
                        game_state::esp_s7 = {};
                    }
                    // ---- packet rejection duty cycle, per STAGE ------------------
                    // Reported by stage STRING, so there is no classifier to be wrong and
                    // no catch-all bucket to hide 90% of the answer in. The first version
                    // of this classified into four named reasons and the other 18 of the
                    // pipeline's 22 stages landed in `other`, which turned out to be where
                    // the answer was. See region_counters::reject_table.
                    {
                        auto& g = optics::lens::g_region.rejects;
                        const auto total = g.total();
                        const auto built = g.packets_built;
                        if (total > 0 || built > 0)
                        {
                            // Sorted by count, top 6, so the dominant stage is the first
                            // thing on the line rather than whatever happened to be first
                            // in the table.
                            int order[optics::lens::region_counters::reject_table::kSlots];
                            int n = 0;
                            for (int i = 0; i < g.used; ++i) order[n++] = i;
                            for (int a = 0; a < n; ++a)
                                for (int b = a + 1; b < n; ++b)
                                    if (g.count[order[b]] > g.count[order[a]]) {
                                        const int t = order[a]; order[a] = order[b]; order[b] = t;
                                    }
                            std::string top;
                            const int shown = n < 6 ? n : 6;
                            for (int i = 0; i < shown; ++i) {
                                if (i) top += " | ";
                                top += std::format("{}={} ({:.0f}%)", g.name[order[i]],
                                    g.count[order[i]],
                                    100.0 * static_cast<double>(g.count[order[i]])
                                        / static_cast<double>(total));
                            }
                            if (n > shown)
                                top += std::format(" | +{} more stages", n - shown);
                            logger::debug(std::format(
                                "optic-rejectcycle: built={} failed={} ({:.0f}% fail) "
                                "stages={}{} :: {}",
                                built, total,
                                100.0 * static_cast<double>(total)
                                    / static_cast<double>(built + total),
                                n, g.overflow ? " OVERFLOW" : "", top));
                            g.reset();
                        }
                    }
                }
                // ---- project_point rejection split (2026-09-27) ---------------
                // behind_optic and behind_main are different failures: the first is a
                // target outside the optic frustum, the second is a lens-local point
                // that ended up behind the MAIN camera. Until now step 4 used fabs(s.w)
                // and silently returned mirrored positions for the latter.
                logger::debug(std::format(
                    "optic-pipeline: proj ok={} behind_optic={} behind_main={} "
                    "nonfinite={} bad_packet={}",
                    optics::lens::g_project.ok, optics::lens::g_project.behind_optic,
                    optics::lens::g_project.behind_main, optics::lens::g_project.nonfinite,
                    optics::lens::g_project.bad_packet));
                optics::lens::g_project = {};
                // ---- section 7 region split (2026-09-27) ----------------------
                // How much ESP actually lands OUTSIDE the fitted lens mask. What happens
                // there is a mode choice, not a constant: a magnified scope shows HOUSING
                // outside the glass so that region must be culled, while a 1x optic renders
                // the eye view so the spec's second main-camera pass applies. `periph`
                // echoes which is active, because the two produce completely different
                // correct-looking output and the log has to tell them apart.
                logger::debug(std::format(
                    "optic-region: inside={} outside={} no_mask={} cover={:.1f}% "
                    "max_outside={:.0f}px (periphery={})",
                    optics::lens::g_region.inside, optics::lens::g_region.outside,
                    optics::lens::g_region.no_mask,
                    100.0 * static_cast<double>(optics::lens::g_region.mask_cover_frac),
                    static_cast<double>(optics::lens::g_region.max_outside_px),
                    game_state::esp_optic_periphery
                        == game_state::optic_periphery::cull ? "cull" : "main_camera"));
                optics::lens::g_region = {};

                // ---- lens image size gate (2026-09-29) -------------------------
                // Reported only on CHANGE, because the baseline drifts by design and
                // printing it every dump would bury the number that matters.
                //
                // `rej` climbing while `rebase` stays 0 is the healthy state: the gate
                // is catching post-rebuild collapses and dropping them. `rebase`
                // climbing would mean it is firing on genuine optic changes and had to
                // re-learn the baseline -- which is the escape hatch doing its job, but
                // loudly enough to notice if it happens every rebuild.
                {
                    const optics::lens::lens_image_size_gate& g = optics::lens::g_lens_size;
                    static unsigned long long s_rej = ~0ull, s_reb = ~0ull, s_deg = ~0ull;
                    static bool s_have = false;
                    // Suppressed until a baseline exists. The first version printed
                    // unconditionally on its first sighting, so on a run where the bbox
                    // was zero every frame the ONLY line this gate ever emitted was
                    // `baseline=0.0000x0.0000 ... rej=0` -- actively misleading, and the
                    // one line that had to be read carefully to notice the gate was
                    // rejecting the bulk of packets while its own counter said zero.
                    if ((g.have || g.degenerate) &&
                        (!s_have || g.rejects != s_rej || g.rebaselines != s_reb ||
                            g.degenerate != s_deg))
                    {
                        s_have = true;
                        s_rej = g.rejects;
                        s_reb = g.rebaselines;
                        s_deg = g.degenerate;
                        logger::debug(std::format(
                            "optic-lenssize: baseline={:.4f}x{:.4f} ndc rej={} degen={} "
                            "rebase={} last_bad={:.4f}x{:.4f}",
                            static_cast<double>(g.ref_w), static_cast<double>(g.ref_h),
                            g.rejects, g.degenerate, g.rebaselines,
                            static_cast<double>(g.seen_w), static_cast<double>(g.seen_h)));
                    }
                }
                // ---- section 7 dispatch (2026-09-27) ---------------------------
                // `left_scoped` climbing while `main_outside` stays at zero would mean
                // the main camera was never published, so the periphery silently stayed
                // magnified -- the entire point of the pass lost. The toggle is echoed
                // here so a run is attributable.
                //
                // `culled` is the number that says whether the boundary is doing
                // anything. It expresses the check the main-camera-only version could not:
                // routing proves the pass RAN, not that its result is right, which is how
                // a wrong periphery read as success for a day. If `culled` stays at zero
                // while `segs inside` climbs, something is still drawing past the glass.
                logger::debug(std::format(
                    "optic-s7: on={} periph={} pts scoped_inside={} culled={}"
                    " main_outside={} left_scoped={} | segs inside={} outside_pieces={}"
                    " nearplane_drop={} | box_culled={} head_culled={}",
                    game_state::esp_optic_s7 ? 1 : 0,
                    game_state::esp_optic_periphery
                        == game_state::optic_periphery::cull ? 0 : 1,
                    optics::lens::g_s7.inside_drawn_scoped,
                    optics::lens::g_s7.outside_culled,
                    optics::lens::g_s7.outside_drawn_main,
                    optics::lens::g_s7.outside_left_scoped,
                    optics::lens::g_s7.seg_inside,
                    optics::lens::g_s7.seg_outside_pieces,
                    optics::lens::g_s7.seg_dropped_nearplane,
                    optics::lens::g_s7.box_culled,
                    optics::lens::g_s7.head_culled));
                optics::lens::g_s7 = {};
                // ---- sight flap (2026-09-27) -----------------------------------
                // The user-visible symptom this retires was "ESP zoom takes a few ticks
                // to switch". `suppressed` is the direct measurement: it counts the
                // pointer mismatches that were NOT treated as staleness because the two
                // sights were measured to produce interchangeable routes. Non-zero while
                // `optic-packet: invalid` is absent means the flap is being absorbed
                // instead of costing a rebuild each time.
                if (optics::lens::g_flap.suppressed || optics::lens::g_flap.rebuilds) {
                    logger::debug(std::format(
                        "optic-flap: suppressed={} rebuilds={} verdict={} (a={} b={})",
                        optics::lens::g_flap.suppressed, optics::lens::g_flap.rebuilds,
                        !g_optic_lens.equiv_measured ? "unmeasured"
                            : (g_optic_lens.equiv_same ? "interchangeable" : "distinct"),
                        static_cast<unsigned>(g_optic_lens.equiv_sight_a),
                        static_cast<unsigned>(g_optic_lens.equiv_sight_b)));
                    optics::lens::g_flap = {};
                }
                // ---- pose gate detail (2026-09-27) ----------------------------
                // Printed only on frames where the gate actually rejected, and only
                // when the numbers have not simply not changed since the last
                // rejection -- otherwise a persistently failing gate floods the log at
                // the throttle rate with the same two numbers.
                if (optics::lens::g_pose_reject.valid)
                {
                    static float s_last_deg = -1.f, s_last_org = -1.f;
                    const auto& pr = optics::lens::g_pose_reject;
                    if (pr.main_deg != s_last_deg || pr.main_org != s_last_org ||
                        pr.optic_deg != s_last_deg || pr.optic_org != s_last_org)
                    {
                        logger::debug(std::format(
                            "optic-pose: REJECT main(deg={:.4f} org={:.5f}) "
                            "optic(deg={:.4f} org={:.5f})  [tol deg={:.2f} org={:.4f}]\n"
                            "  main  pos=({:.3f},{:.3f},{:.3f}) |pos|={:.4f}  view_org=({:.3f},{:.3f},{:.3f}) |vorg|={:.4f}\n"
                            "  optic pos=({:.3f},{:.3f},{:.3f}) |pos|={:.4f}  view_org=({:.3f},{:.3f},{:.3f}) |vorg|={:.4f}\n"
                            "  If org ~= |view_org| then R_view.pos contributed nothing, i.e. pos is (0,0,0):"
                            " the Transform read failed, not the matrix.",
                            static_cast<double>(pr.main_deg),
                            static_cast<double>(pr.main_org),
                            static_cast<double>(pr.optic_deg),
                            static_cast<double>(pr.optic_org),
                            static_cast<double>(optics::lens::kPoseAxisTolDeg),
                            static_cast<double>(optics::lens::kPoseOriginTol),
                            static_cast<double>(pr.main_pos[0]), static_cast<double>(pr.main_pos[1]),
                            static_cast<double>(pr.main_pos[2]),
                            static_cast<double>(std::sqrt(
                                pr.main_pos[0] * pr.main_pos[0] + pr.main_pos[1] * pr.main_pos[1]
                                + pr.main_pos[2] * pr.main_pos[2])),
                            static_cast<double>(pr.main_vorg[0]), static_cast<double>(pr.main_vorg[1]),
                            static_cast<double>(pr.main_vorg[2]),
                            static_cast<double>(std::sqrt(
                                pr.main_vorg[0] * pr.main_vorg[0] + pr.main_vorg[1] * pr.main_vorg[1]
                                + pr.main_vorg[2] * pr.main_vorg[2])),
                            static_cast<double>(pr.optic_pos[0]), static_cast<double>(pr.optic_pos[1]),
                            static_cast<double>(pr.optic_pos[2]),
                            static_cast<double>(std::sqrt(
                                pr.optic_pos[0] * pr.optic_pos[0] + pr.optic_pos[1] * pr.optic_pos[1]
                                + pr.optic_pos[2] * pr.optic_pos[2])),
                            static_cast<double>(pr.optic_vorg[0]), static_cast<double>(pr.optic_vorg[1]),
                            static_cast<double>(pr.optic_vorg[2]),
                            static_cast<double>(std::sqrt(
                                pr.optic_vorg[0] * pr.optic_vorg[0] + pr.optic_vorg[1] * pr.optic_vorg[1]
                                + pr.optic_vorg[2] * pr.optic_vorg[2]))));
                        // Per-axis, for whichever camera actually failed.
                        //
                        // 2026-09-29: added because `org` was a bare magnitude, and a
                        // magnitude cannot distinguish the two live hypotheses. Reading
                        // `local` (the error in view space) alongside `pos` (the
                        // Transform's world position) and `view_org` (the origin the
                        // view matrix implies) separates them immediately:
                        //   pos near the player, view_org 59 m away -> the view matrix's
                        //       own translation is stale or belongs to another camera
                        //   pos itself 59 m out -> the Transform read is the liar
                        // A dominant Z component in `local` means the two disagree along
                        // the view axis, which is a different fault from lateral drift.
                        //
                        // The prose interpretation deliberately stays in the code comment
                        // on pose_reject_detail rather than in the log: it was seven
                        // lines of speculation printed on every rejection, and it went
                        // stale the moment a second magnitude appeared.
                        {
                            const char* names[2] = { "main", "optic" };
                            const optics::lens::pose_axis_detail* ax[2] = {
                                &pr.main_axis, &pr.optic_axis };
                            const float orgs[2] = { pr.main_org, pr.optic_org };
                            for (int i = 0; i < 2; ++i)
                            {
                                // Only the camera that failed. A camera that agreed
                                // contributes a row of zeros, which reads as noise.
                                if (orgs[i] <= optics::lens::kPoseOriginTol) continue;
                                const auto& a = *ax[i];
                                logger::debug(std::format(
                                    "optic-pose:   {} pos=({:.3f},{:.3f},{:.3f}) "
                                    "view_org=({:.3f},{:.3f},{:.3f}) "
                                    "err=({:.3f},{:.3f},{:.3f})",
                                    names[i],
                                    static_cast<double>(a.world_pos.x),
                                    static_cast<double>(a.world_pos.y),
                                    static_cast<double>(a.world_pos.z),
                                    static_cast<double>(a.view_origin.x),
                                    static_cast<double>(a.view_origin.y),
                                    static_cast<double>(a.view_origin.z),
                                    static_cast<double>(a.local.x),
                                    static_cast<double>(a.local.y),
                                    static_cast<double>(a.local.z)));
                            }
                        }
                        s_last_deg = pr.main_deg;
                        s_last_org = pr.main_org;
                    }
                    optics::lens::g_pose_reject.valid = false;
                }

                // ---- pose retry (2026-09-29) --------------------------------------
                // Reported on change. `recovered` climbing is the whole point: it counts
                // frames that used to be rejected outright -- putting ESP on the radial
                // fallback -- and now go through the scoped path.
                //
                // `max_us` is the empirical answer to the 6 ms question that was previously
                // settled by argument. A retry is ~5 native reads; if `max_us` ever
                // approaches 6000 the spec's bound is a real constraint rather than a
                // formality, and the OVER/within tag says so without anyone having to
                // compute it.
                {
                    const optics::lens::pose_retry_note& r = optics::lens::g_pose_retry;
                    static unsigned long long s_att = 0, s_rec = 0;
                    if (r.attempts != s_att || r.recovered != s_rec)
                    {
                        s_att = r.attempts;
                        s_rec = r.recovered;
                        logger::debug(std::format(
                            "optic-retry: attempts={} recovered={} last={:.0f}us "
                            "max={:.0f}us (spec {:.0f}us: {})",
                            r.attempts, r.recovered, r.last_us, r.max_us,
                            optics::lens::kPoseRetryBoundUs,
                            r.max_us > optics::lens::kPoseRetryBoundUs ? "OVER" : "within"));
                    }
                }

                // ---- root-position filter outcome (2026-09-28) -------------------
                // DELIBERATELY OUTSIDE the `g_pose_reject.valid` branch above.
                //
                // It was originally placed inside, which was wrong in a way that made the
                // instrumentation useless: the note only printed when the pose gate
                // REJECTED, and the filter only ever runs when the packet is CONSISTENT
                // (the spec forbids repairing an inconsistent one). So the two conditions
                // are mutually exclusive and the line could never have fired. First run
                // confirmed it: zero `optic-root` lines in 47109 log lines, on a run where
                // the gate never rejected.
                {
                    const optics::lens::root_filter_note& rf =
                        optics::lens::g_root_filter_note;
                    static bool s_last_applied = false;
                    static float s_last_mm = -1.f;
                    static bool s_last_consistent = false;
                    static const char* s_last_why = nullptr;
                    // Separate flag rather than a sentinel in s_last_consistent.
                    // The int -1 that used to sit there was doing this job: it can
                    // never equal a bool, so the first sample always logged. A bool
                    // cannot hold that state, and quietly dropping the first-run
                    // guarantee would be a worse defect than the warning this
                    // replaces (C4805, 34 instances across the TUs reaching here).
                    static bool s_have_sample = false;
                    if (!s_have_sample ||
                        rf.applied != s_last_applied ||
                        rf.cand_mm != s_last_mm ||
                        rf.packet_consistent != s_last_consistent ||
                        rf.why_not != s_last_why)
                    {
                        s_have_sample = true;
                        s_last_applied = rf.applied;
                        s_last_mm = rf.cand_mm;
                        s_last_consistent = rf.packet_consistent;
                        s_last_why = rf.why_not;
                        // `cand` is the magnitude considered; `applied_mm` is what was
                        // written. They differ on the refusal path, and printing only
                        // the latter made every over-budget rejection read as 0.00 mm.
                        // cand_mm is -1 when no candidate was computed at all.
                        const std::string cand = rf.cand_mm < 0.f
                            ? "n/a"
                            : std::format("{:.2f}mm", static_cast<double>(rf.cand_mm));
                        logger::debug(std::format(
                            "optic-root: applied={} cand={} applied_mm={:.2f}mm "
                            "hands_self={} packet_ok={} -- {}",
                            rf.applied ? 1 : 0,
                            cand,
                            static_cast<double>(rf.applied_mm),
                            rf.have_hands_self ? 1 : 0,
                            rf.packet_consistent ? 1 : 0,
                            rf.why_not));
                        // ACTIVE INVESTIGATION: the per-frame series behind the
                        // 600 ms line above. `optic-root:` is sampled on the dump
                        // cadence, so it can only ever show DRIFT; the reported
                        // symptom is per-frame shake, which this is the first
                        // measurement of. See root_frame_summary() for what each
                        // column decides.
                        {
                            // 1024, not 512: the summary now appends a
                            // suspicious-frame report after the distribution, and with
                            // a worst-frame record present the two together exceed 512.
                            // The function clamps rather than overflowing, but a
                            // truncated diagnostic is worse than none -- the half that
                            // gets cut is the half that answers the question.
                            char buf[1024];
                            optics::lens::root_frame_summary(buf, sizeof(buf));
                            logger::debug(buf);
                            // The lens-size gate's PER-FRAME decisions, on its own
                            // buffer: `reject_run_max` against `kRebaselineMs` is the
                            // finding, and folding it into the root line would bury it
                            // in an unrelated summary.
                            char lbuf[768];
                            optics::lens::lens_size_frame_summary(lbuf, sizeof(lbuf));
                            logger::debug(lbuf);
                        }
                    }
                }
                perf = perf_accum{};   // drain
            }

            // State-change banner: makes a combined multi-experiment run attributable.
            //
            // cull_mode is deliberately NOT part of the dedupe key. In dual mode the two
            // passes alternate mode 1 and 2 on every single frame, so including it made
            // this "on change" banner fire twice per frame -- observed 2026-09-27 as a
            // wall of near-identical lines. The cull counters already report it.
            {
                static std::string s_last_state;
                const std::string state = std::format(
                    "dual={} using_optic={} scope_zoom={:.2f} packet={}",
                    game_state::esp_zoom_dual ? 1 : 0,
                    game_state::esp_zoom_using_optic ? 1 : 0,
                    static_cast<double>(game_state::esp_zoom_scope_zoom),
                    game_state::esp_zoom_packet_valid ? "valid" : "FALLBACK");
                if (state != s_last_state)
                {
                    s_last_state = state;
                    logger::info(std::format(
                        "optic-state: {} cull_mode={} | auto_k={:.3f} user_k={:.3f} "
                        "final_k={:.3f}{}",
                        state, game_state::esp_mask_cull_mode_at_count,
                        static_cast<double>(game_state::esp_zoom_auto_k),
                        static_cast<double>(game_state::esp_zoom_user_k),
                        static_cast<double>(game_state::esp_zoom_final_k),
                        game_state::esp_zoom_k_clamped ? " CLAMPED[0.0625,1.0]" : ""));
                }
            }
        }

        // Publish the real lens opening as the ESP/aim mask (menu pixels, CCW).
        // The NDC polygon is CCW y-up; the pixel conversion flips Y, so the point
        // order is reversed to keep the polygon CCW for game_state's test.
        const optics::lens::packet* const pub = optic_lens_published();
        if (pub) {
            const float w = static_cast<float>(menu::get_width());
            const float h = static_cast<float>(menu::get_height());
            int n = 0;
            const auto& mask = pub->mask;
            for (int i = static_cast<int>(mask.size()) - 1; i >= 0 && n < 64; --i, ++n) {
                game_state::esp_lens_mask_px[n * 2] = (mask[i].x + 1.f) * w * 0.5f;
                game_state::esp_lens_mask_px[n * 2 + 1] = (1.f - mask[i].y) * h * 0.5f;
            }
            game_state::esp_lens_mask_count = n;
        } else {
            game_state::esp_lens_mask_count = 0;
        }
        return pub != nullptr;
    }

    // Expose the visible-region mask (main-screen NDC) for module-side clipping.
    inline const optics::lens::packet* optic_lens_packet() {
        optic_lens_ensure_frame();
        return optic_lens_published();
    }

    // Visible interval [t0, t1] (within [0,1]) of a menu-space segment inside the
    // real lens mask (fitted to the scope opening). Only meaningful while the
    // optic pass is active — returns false otherwise or when the pipeline has no
    // valid packet this frame (caller draws unclipped, legacy behavior).
    inline bool optic_lens_segment_interval(const unity::vector3& a, const unity::vector3& b,
        float& t0, float& t1) {
        ++game_state::esp_s7.interval_calls;
        if (!game_state::esp_optic_proj) { ++game_state::esp_s7.interval_decl_proj; return false; }
        const optics::lens::packet* p = optic_lens_packet();
        if (!p) { ++game_state::esp_s7.interval_decl_nopacket; return false; }
        const float w = static_cast<float>(menu::get_width());
        const float h = static_cast<float>(menu::get_height());
        if (w < 1.f || h < 1.f) { ++game_state::esp_s7.interval_decl_size; return false; }
        const auto to_ndc = [w, h](const unity::vector3& s) {
            return optics::lens::v2{s.x / w * 2.f - 1.f, 1.f - s.y / h * 2.f};
        };
        const bool clipped = optics::lens::clip_segment(*p, to_ndc(a), to_ndc(b), t0, t1);
        if (!clipped) {
            // Returned false means the segment has no inside portion, so the caller draws
            // it unclipped. That is the correct outcome for a segment entirely outside the
            // glass -- but it is indistinguishable from "the mask is wrong" without a count.
            ++game_state::esp_s7.interval_none;
            return false;
        }
        ++game_state::esp_s7.interval_ok;
        // "Nothing was actually cut" is a distinct outcome from "cut down to a sliver",
        // and it is the one that would make an over-coverage report look like a
        // projection problem instead of a mask problem. 1e-3 in t is a fraction of a
        // pixel on any realistic ESP segment, so treat it as a full pass.
        if (t0 <= 1e-3f && t1 >= 1.f - 1e-3f)
            ++game_state::esp_s7.interval_full;
        return true;
    }

    // ---- section 7 segment split (optic_idea.md line 574) --------------------
    //
    //   "For the main-camera pass, remove the interval inside the mask; the remaining
    //    zero, one or two pieces stay visible. A segment crossing a camera's near plane
    //    needs homogeneous near-plane clipping before perspective division. Never
    //    connect a behind-camera endpoint to a projected endpoint."
    //
    // So one segment yields up to THREE screen pieces from two different cameras:
    //   * the INSIDE interval, projected with the optic chain (what
    //     optic_lens_segment_interval already returns);
    //   * the COMPLEMENT -- [0,t0] and [t1,1] -- projected with the MAIN camera, giving
    //     the "zero, one or two pieces".
    //
    // The complement is derived from the SAME parametric interval the inside clip
    // returns, so the pieces meet exactly at the mask boundary with no gap and no
    // overlap. Endpoints behind the main camera are DROPPED, not divided through, per
    // the near-plane rule -- the same class of defect as the `fabs(s.w)` in
    // project_point.
    struct s7_segment {
        bool has_inside = false;
        ImVec2 in_a{}, in_b{};                       // optic chain, menu pixels
        int outside_count = 0;
        ImVec2 out_a[2]{}, out_b[2]{};               // main camera, menu pixels
    };

    // Section 7 dispatch, as a decision the CALLER can decline.
    //
    // 2026-09-27, user report: "if an ESP skeleton goes past the scope it gets stretched
    // and placed in both places". Cause, and it is a design error rather than a tuning
    // one: the per-point dispatch inside world_to_screen_optic fires INDEPENDENTLY for
    // every world point. Any geometry built from more than one point therefore mixes
    // coordinate systems whenever its points straddle the mask --
    //
    //   compute_player_box_layout:  height = |head_screen.y - feet_screen.y|
    //   with head inside  -> optic-chain y
    //        and feet outside -> main-camera y
    //
    // which is a subtraction across two different projections. The box tears, and a
    // skeleton straddling the glass has every bone resolved independently, so the figure
    // appears in both regions and the segments between them stretch across the screen.
    //
    // Per-point dispatch is only meaningful for genuinely INDEPENDENT points -- a text
    // label, a radar symbol -- where there is nothing to be consistent with. For anything
    // connected the two endpoints of a piece must come from the SAME camera, and that is
    // exactly what the spec's two-pass language describes. So connected geometry asks for
    // `world_to_screen_scoped_only` (defined below, next to the scoped projection) and
    // applies the two-pass segment split; standalone points keep the per-point dispatch.
    // Boxes take a middle road -- one camera chosen per box -- which is coherent but not
    // yet the spec's per-segment split; see EspModule::compute_player_box_layout.


    inline bool optic_lens_segment_s7(const unity::vector3& wa, const unity::vector3& wb,
                                      s7_segment& out) {
        out = s7_segment{};
        ++game_state::esp_s7.s7_calls;
        if (!game_state::esp_optic_proj) { ++game_state::esp_s7.s7_decl_proj; return false; }
        if (!game_state::esp_optic_s7) { ++game_state::esp_s7.s7_decl_s7; return false; }
        const optics::lens::packet* p = optic_lens_packet();
        // The one decline cause that silently degrades the picture: no packet means the
        // caller falls back to drawing the whole segment, so the section 7 split does not
        // happen and geometry crosses the glass boundary. Counted on its own because it is
        // the only one of the four that is a data problem rather than a toggle.
        if (!p) { ++game_state::esp_s7.s7_decl_nopacket; return false; }
        const float w = static_cast<float>(menu::get_width());
        const float h = static_cast<float>(menu::get_height());
        if (w < 1.f || h < 1.f) { ++game_state::esp_s7.s7_decl_size; return false; }

        // The mask is defined in the OPTIC projection's screen space, so both ends are
        // projected with the optic chain before the inside test.
        optics::lens::v2 oa{}, ob{};
        if (!optics::lens::project_point(*p, optics::lens::v3{wa.x, wa.y, wa.z}, w, h, oa))
            return false;
        if (!optics::lens::project_point(*p, optics::lens::v3{wb.x, wb.y, wb.z}, w, h, ob))
            return false;
        const auto to_ndc = [w, h](float x, float y) {
            return optics::lens::v2{x / w * 2.f - 1.f, 1.f - y / h * 2.f};
        };

        float t0 = 0.f, t1 = 1.f;
        const bool has_inside =
            optics::lens::clip_segment(*p, to_ndc(oa.x, oa.y), to_ndc(ob.x, ob.y), t0, t1)
            && t1 > t0;
        if (has_inside) {
            out.has_inside = true;
            out.in_a = {oa.x + (ob.x - oa.x) * t0, oa.y + (ob.y - oa.y) * t0};
            out.in_b = {oa.x + (ob.x - oa.x) * t1, oa.y + (ob.y - oa.y) * t1};
            ++optics::lens::g_s7.seg_inside;
        }

        // Main camera, needed for the complement. Without it there is no second pass.
        Il2CppObject* const fps = g_esp_fps_cam.load(std::memory_order_acquire);
        if (!fps) return has_inside;

        // The complement of [t0,t1] within [0,1]: the two outside intervals.
        const float a_lo[2] = {0.f, has_inside ? t1 : 0.f};
        const float a_hi[2] = {has_inside ? t0 : 0.f, 1.f};
        for (int piece = 0; piece < 2; ++piece) {
            const float a = a_lo[piece], b = a_hi[piece];
            if (!(b > a)) continue;
            // Lerp in WORLD space, then project each end with the main camera. Lerping
            // world endpoints rather than screen pixels is what makes these pieces
            // correct: the two projections do not agree off-mask, so interpolating in
            // one projection's screen space and re-projecting would be wrong.
            const unity::vector3 p0{wa.x + (wb.x - wa.x) * a, wa.y + (wb.y - wa.y) * a,
                                     wa.z + (wb.z - wa.z) * a};
            const unity::vector3 p1{wa.x + (wb.x - wa.x) * b, wa.y + (wb.y - wa.y) * b,
                                     wa.z + (wb.z - wa.z) * b};
            const unity::vector3 s0 = world_to_screen_fps(fps, p0, 1.f);
            const unity::vector3 s1 = world_to_screen_fps(fps, p1, 1.f);
            const bool nonfinite = !std::isfinite(s0.x) || !std::isfinite(s0.y)
                || !std::isfinite(s1.x) || !std::isfinite(s1.y);
            if (nonfinite) continue;
            // Near-plane rule: never connect a behind-camera endpoint to a projected one.
            // Drop the whole piece instead of drawing a smear to the screen edge.
            if (s0.z <= 0.01f || s1.z <= 0.01f) {
                ++optics::lens::g_s7.seg_dropped_nearplane;
                continue;
            }
            out.out_a[out.outside_count] = {s0.x, s0.y};
            out.out_b[out.outside_count] = {s1.x, s1.y};
            ++out.outside_count;
            ++optics::lens::g_s7.seg_outside_pieces;
        }
        const bool produced = out.has_inside || out.outside_count > 0;
        if (out.has_inside) ++game_state::esp_s7.s7_inside;
        if (out.outside_count > 0) ++game_state::esp_s7.s7_outside;
        // Split the "inside but no complement" case, because it is two different outcomes
        // and 97% of them being one of them is exactly the kind of thing worth checking
        // rather than assuming. See s7_counters for the distinction and why it matters.
        //
        // 1e-3 in t is a fraction of a pixel on any realistic ESP segment, so it separates
        // "the whole segment was inside" from "a real piece was cut" without a judgement
        // call about what counts as a crossing.
        if (out.has_inside && out.outside_count == 0)
        {
            if (t0 <= 1e-3f && t1 >= 1.f - 1e-3f) ++game_state::esp_s7.s7_fully_inside;
            else ++game_state::esp_s7.s7_complement_lost;
        }
        if (!produced) ++game_state::esp_s7.s7_none;
        return produced;
    }

    // Always the optic chain — no section 7 per-point dispatch. This is the coherent
    // primitive for building geometry out of several world points: every point comes
    // from the same projection, so a box's height or a bone's length is a real distance.
    // The two-pass split is then applied to the resulting SEGMENTS, not to the points.
    inline unity::vector3 world_to_screen_optic_scoped(Il2CppObject* optic,
        unity::vector3 world_point) {
        optic_proj_stats().attempts.fetch_add(1, std::memory_order_relaxed);
        // Fail-closed flag, and deliberately NOT named `no_packet`: it is also set when
        // ensure_frame() itself returns false, which is a different condition with the
        // same consequence. Both mean "no packet for this frame".
        bool ensure_broke = false;
        if (optic_lens_ensure_frame()) {
            const optics::lens::packet* const pk = optic_lens_published();
            if (!pk) {
                ensure_broke = true;
                optic_proj_stats().ensure_failed.fetch_add(1, std::memory_order_relaxed);
            } else {
                optics::lens::v2 px{};
                const float w = static_cast<float>(menu::get_width());
                const float h = static_cast<float>(menu::get_height());
                if (optics::lens::project_point(*pk,
                        optics::lens::v3{world_point.x, world_point.y, world_point.z},
                        w, h, px)) {
                    optic_proj_stats().scoped_ok.fetch_add(1, std::memory_order_relaxed);
                    ++optics::lens::g_s7.inside_drawn_scoped;
                    return {px.x, px.y, 1.f};
                }
                // The packet was fine and the POINT was refused. This is the branch that
                // turned out to be 51.2% of attempts while reading as a packet problem.
                // It is NOT a pipeline failure and keeps the fallback below: a point
                // outside the lens opening is supposed to be drawn the normal way.
                optic_proj_stats().fell_back_proj_failed.fetch_add(1, std::memory_order_relaxed);
            }
        } else {
            ensure_broke = true;
            optic_proj_stats().ensure_failed.fetch_add(1, std::memory_order_relaxed);
        }
        if (ensure_broke)
            optic_proj_stats().fell_back_no_packet.fetch_add(1, std::memory_order_relaxed);
        optic_proj_stats().fell_back.fetch_add(1, std::memory_order_relaxed); // total, kept
        if (ensure_broke) {
            // NO PACKET, SO DRAW NOTHING. Measured 2026-10-04 10:03-10:04: after every
            // ADS transition the route is accepted but no packet is published for ~1-2 s,
            // and 7,642 of 30,145 attempts in one raid ended here -- accounting for every
            // one of that raid's 7,342 unclipped draws. With esp_ads_mask_mode == 0 the
            // mask gate is ALWAYS-TRUE (the optic-maskgate drain says so explicitly), so
            // the section-7 split is the only live clip, and with no packet it cannot run.
            // The old code computed the fallback anyway and returned it with z > 0.01,
            // which is_visible() accepts -- geometry drawn straight across the lens
            // glass boundary, uncorrected.
            //
            // Refusing is the correct outcome, not a workaround. The mask cannot be
            // evaluated without a packet, so there is no honest screen position for this
            // point, and the alternative the old code took -- draw it with the radial
            // fit -- is the thing optic_idea.md exists to prevent. {0,0,-1} is the
            // sentinel the sibling path already returns for "outside the lens, cull";
            // is_visible() rejects it on z before anything else inspects it.
            //
            // Dropping the fallback also removes the world_to_screen_point and
            // camera_pixel_width/height calls below -- managed calls into the optic
            // camera, thousands of them, in the seconds right after that camera changed.
            optic_proj_stats().fell_back_ensure_culled.fetch_add(1, std::memory_order_relaxed);
            optic_proj_stats().fallback_culled.fetch_add(1, std::memory_order_relaxed);
            return {0.f, 0.f, -1.f};
        }
        const unity::vector3 raw = unity::world_to_screen_point(optic, world_point);
        const float cam_w = static_cast<float>(unity::camera_pixel_width(optic));
        const float cam_h = static_cast<float>(unity::camera_pixel_height(optic));
        const unity::vector3 out = map_optic_pixels_to_menu(raw.x, raw.y, raw.z, cam_w, cam_h, 1.f);
        // Counted here rather than at the draw site because the decision is already made:
        // is_visible() rejects on z first, so a fallback result with z <= 0.01 is culled
        // and a result in front of the camera may be drawn. The bounds test is applied
        // after, so this is the "in front" half only -- which is the half that decides
        // whether the fallback is MISPLACING geometry or merely discarding it.
        if (out.z > 0.01f) optic_proj_stats().fallback_drawn.fetch_add(1, std::memory_order_relaxed);
        else optic_proj_stats().fallback_culled.fetch_add(1, std::memory_order_relaxed);
        return out;
    }

    // Section 7 opt-out for callers that build CONNECTED geometry. Always the optic chain
    // (or the plain eye path when not on the optic camera); never the per-point dispatch.
    // Every point then comes from one projection, so a box's height or a bone's length is
    // a real distance, and the two-pass segment split decides which camera each PIECE is
    // drawn with.
    inline unity::vector3 world_to_screen_scoped_only(Il2CppObject* camera,
        unity::vector3 world_point, float zoom) {
        if (game_state::esp_optic_proj && camera && camera == game_state::esp_optic_cam)
            return world_to_screen_optic_scoped(camera, world_point);
        return world_to_screen_fps(camera, world_point, zoom);
    }

    // ---- periphery decision for CONNECTED geometry, resolved once ----------------
    //
    // 2026-09-27, user report: "in case where we're not culling (second mode, both) ESP
    // objects still drift away multiplied by lens."
    //
    // The per-point dispatch in world_to_screen_optic routes INDEPENDENT points, and the
    // log proves it runs (`main_outside` 1945-2697 per drain under periph=1). The
    // geometry that drifts is the geometry that never asks it. Each of these has its own
    // connected shape and so cannot use the per-point path without tearing:
    //
    //   head circle -- standalone piece, radius = |head - neck| in SCREEN space, so the
    //                  two points must share one projection
    //   box + health bar -- one screen rect
    //   skeleton segments -- already handled by the two-pass split (optic_lens_segment_s7)
    //
    // The head circle was the outright bug: it had a cull in cull mode and NOTHING in
    // main-camera mode, so it was drawn at the magnified position whether or not the head
    // was past the glass. Same for the box: it was routed by its centre but never told
    // whether it was drawn scoped, so draw_corner_box clipped a main-camera-projected box
    // against a mask it lay outside of and erased it.
    //
    // So: decide ONCE from a representative point, then project every point of the piece
    // with the chosen camera. The counters are incremented here so all three geometry
    // types feed the same `culled` / `main_outside` numbers the per-point path uses --
    // previously the connected geometry was invisible to the diagnostics entirely, which
    // is why `culled` looked healthy while boxes and heads still leaked.
    struct region_pick {
        bool draw = false;     // false -> the piece is out past the glass; do not draw
        bool use_fps = false;  // true -> project with the main camera at 1x
        bool scoped = false;   // true -> drawn magnified; callers MUST clip to the mask
    };

    // Is this menu-pixel position inside the fitted lens opening?
    inline bool optic_point_inside_menu(float px, float py) {
        const optics::lens::packet* p = optic_lens_packet();
        if (!p || p->mask.size() < 3) return true;  // no mask -> nothing to be outside of
        const float w = static_cast<float>(menu::get_width());
        const float h = static_cast<float>(menu::get_height());
        if (w < 1.f || h < 1.f) return true;
        return optics::lens::point_in_mask(*p,
            optics::lens::v2{px / w * 2.f - 1.f, 1.f - py / h * 2.f});
    }

    // Resolve the camera for a whole piece of geometry from a representative point.
    inline region_pick optic_pick_region(bool inside) {
        region_pick r{};
        if (!game_state::esp_optic_s7 || inside) {
            r.draw = true;
            r.scoped = true;
            ++optics::lens::g_s7.inside_drawn_scoped;
            return r;
        }
        if (game_state::esp_optic_periphery == game_state::optic_periphery::cull) {
            ++optics::lens::g_s7.outside_culled;
            return r;  // draw == false
        }
        Il2CppObject* const fps = g_esp_fps_cam.load(std::memory_order_acquire);
        if (!fps) {
            // No main camera published. Fall back to scoped rather than dropping the
            // piece, and mark it scoped so the caller still clips it to the glass.
            r.draw = true;
            r.scoped = true;
            ++optics::lens::g_s7.outside_left_scoped;
            return r;
        }
        r.draw = true;
        r.use_fps = true;
        ++optics::lens::g_s7.outside_drawn_main;
        return r;
    }

    // Project every point of one piece with the camera the pick chose. One camera for all
    // of them, so any distance derived from two of them is a real distance.
    inline unity::vector3 optic_project_region(const region_pick& r, Il2CppObject* optic_cam,
        unity::vector3 wp, float zoom) {
        if (r.use_fps) {
            Il2CppObject* const fps = g_esp_fps_cam.load(std::memory_order_acquire);
            if (fps) return world_to_screen_fps(fps, wp, 1.f);
        }
        return world_to_screen_scoped_only(optic_cam, wp, zoom);
    }

    inline unity::vector3 world_to_screen_optic(Il2CppObject* optic, unity::vector3 world_point,
        const float radial_scale) {
        // Exact lens placement first; radial-fit fallback when the pipeline
        // cannot validate this frame (shader/singleton/mesh checks failed).
        optic_proj_stats().attempts.fetch_add(1, std::memory_order_relaxed);
        // Set only when the pipeline could not produce a packet for this frame. It is
        // NOT set when a packet existed and refused this point -- that is the
        // outside-the-lens case the fallback exists to serve, and it must keep drawing.
        bool ensure_broke = false;
        if (optic_lens_ensure_frame()) {
            const optics::lens::packet* const pk = optic_lens_published();
            if (!pk) {
                ensure_broke = true;
                optic_proj_stats().ensure_failed.fetch_add(1, std::memory_order_relaxed);
            } else {
            optics::lens::v2 px{};
            const float w = static_cast<float>(menu::get_width());
            const float h = static_cast<float>(menu::get_height());
            if (optics::lens::project_point(*pk,
                    optics::lens::v3{world_point.x, world_point.y, world_point.z},
                    w, h, px)) {
                optic_proj_stats().scoped_ok.fetch_add(1, std::memory_order_relaxed);
                // ---- section 7 per-point dispatch (line 574) --------------------
                // "Use scoped projection inside this mask and main-camera projection
                // outside it. These are two separately projected and clipped passes,
                // NOT a choice made once per player." The "not once per player" is the
                // operative part: the split is per POINT, so one entity can straddle the
                // boundary and have its box edges land in different regions.
                //
                // Measurement that motivates this (2026-09-27): cover 15-20% of the
                // screen, and 19k-30k projected points per drain landed OUTSIDE the
                // fitted mask against 2k-14k inside -- roughly 85% of all ESP drawn
                // through a camera magnifying ~5.8x, which is the reported "objects
                // outside the scope also get enlarged".
                const optics::lens::v2 ndc{px.x / w * 2.f - 1.f, 1.f - px.y / h * 2.f};
                const bool have_mask = pk->mask.size() >= 3;
                const bool inside = have_mask && optics::lens::point_in_mask(*pk, ndc);
                if (game_state::esp_optic_s7 && !inside) {
                    // Outside the lens opening. What happens is a mode choice, because the
                    // two cases are genuinely different optics:
                    //
                    //  - cull (default): a magnified scope blacks out its surround, so
                    //    there is nothing to see out there and the ESP must not be
                    //    drawn. Return an off-screen sentinel -- z <= 0.01 makes
                    //    is_visible() fail, which is the existing "don't draw this" path,
                    //    so labels / loot / extracts / symbols / health bars all drop out
                    //    through one check instead of each needing its own.
                    //  - main_camera: a 1x optic renders the eye view around the glass, so
                    //    the periphery is real and should be drawn at 1x.
                    //
                    // Both used to be "draw it", which is what produced ESP over the
                    // scope housing (user report 2026-09-27).
                    if (game_state::esp_optic_periphery == game_state::optic_periphery::cull) {
                        ++optics::lens::g_s7.outside_culled;
                        return {0.f, 0.f, -1.f};
                    }
                    Il2CppObject* const fps = g_esp_fps_cam.load(std::memory_order_acquire);
                    if (fps) {
                        ++optics::lens::g_s7.outside_drawn_main;
                        return world_to_screen_fps(fps, world_point, 1.f);
                    }
                    // No main camera published: fall through to the scoped position
                    // rather than dropping the point.
                }
                {
                    auto& reg = optics::lens::g_region;
                    if (!have_mask) {
                        ++reg.no_mask;
                    } else if (inside) {
                        ++reg.inside;
                        ++optics::lens::g_s7.inside_drawn_scoped;
                    } else {
                        ++reg.outside;
                        ++optics::lens::g_s7.outside_left_scoped;
                        // NDC spans ~2 units across the short axis; scale to pixels
                        // so this is comparable with the log's other pixel figures.
                        const float px_dist =
                            optics::lens::distance_outside_mask(*pk, ndc)
                            * 0.5f * (w < h ? w : h);
                        // Only meaningful for points still ON screen. Off-axis points
                        // project to coordinates orders of magnitude away (measured up to
                        // 2.0e7 px), and including them made this metric useless -- it
                        // reported a distance no screen could contain instead of how far
                        // outside the mask a VISIBLE point fell.
                        const bool on_screen = px.x >= 0.f && px.y >= 0.f
                            && px.x <= w && px.y <= h;
                        if (on_screen && px_dist > reg.max_outside_px)
                            reg.max_outside_px = px_dist;
                    }
                }
                return {px.x, px.y, 1.f};
            }
            }
        }
        else
        {
            ensure_broke = true;
            optic_proj_stats().ensure_failed.fetch_add(1, std::memory_order_relaxed);
        }
        optic_proj_stats().fell_back.fetch_add(1, std::memory_order_relaxed);
        // The per-point dispatch path reaches the same fallback and shares the same
        // `attempts` / `fell_back` counters as world_to_screen_optic_scoped. It was NOT
        // covered by the split added on 2026-10-01, so the very first run of that split
        // reported fell_back=1194 against no_packet=0 proj_failed=0 -- a total that does
        // not reconcile with its parts, which is the exact failure the split was meant to
        // cure. Found in one run precisely because the parts were printed next to the
        // total; it would have been believed indefinitely otherwise.
        //
        // Counted here as its own pair, because a point dispatched per-point is a
        // different decision from a point in a connected segment, and lumping them would
        // re-create the single-total problem one level up.
        optic_proj_stats().fell_back_pointwise.fetch_add(1, std::memory_order_relaxed);
        if (ensure_broke) {
            // NO PACKET, SO DRAW NOTHING. Second of the two fallback sites with this
            // guard; the reasoning and the measurement are on the sibling path in
            // world_to_screen_optic_scoped. Short version: after an ADS transition the
            // route is accepted but no packet exists for ~1-2 s, and with
            // esp_ads_mask_mode == 0 the section-7 split is the only live clip -- so a
            // fallback returned here is drawn across the lens glass boundary with no
            // correction. is_visible() accepts it, because z > 0.01.
            //
            // The sentinel matches the one this same function already returns for
            // "outside the lens opening, cull" a few lines above, so labels / loot /
            // extracts / health bars all drop out through the single is_visible() check
            // they already use, with no per-consumer change.
            //
            // `fell_back_pointwise` above counts EVERY fallback reaching here, which is
            // why the two cases were indistinguishable in the log before
            // fell_back_ensure_culled was added: the "NO PACKET ... drawn UNCLIPPED"
            // warning was reporting refusals as packet failures.
            optic_proj_stats().fell_back_ensure_culled.fetch_add(1, std::memory_order_relaxed);
            optic_proj_stats().fallback_culled.fetch_add(1, std::memory_order_relaxed);
            return {0.f, 0.f, -1.f};
        }
        const unity::vector3 raw = unity::world_to_screen_point(optic, world_point);
        const float cam_w = static_cast<float>(unity::camera_pixel_width(optic));
        const float cam_h = static_cast<float>(unity::camera_pixel_height(optic));
        const unity::vector3 out =
            map_optic_pixels_to_menu(raw.x, raw.y, raw.z, cam_w, cam_h, radial_scale);
        if (out.z > 0.01f) optic_proj_stats().fallback_drawn.fetch_add(1, std::memory_order_relaxed);
        else optic_proj_stats().fallback_culled.fetch_add(1, std::memory_order_relaxed);
        return out;
    }

    // Unified ESP entry: uses optic letterbox+radial when this frame projects via optic cam.
    // Optional lens_renderer parameter for full optic_idea.md implementation (Section 2).
    inline unity::vector3 world_to_screen(Il2CppObject* camera, unity::vector3 world_point,
        float zoom, Il2CppObject* lens_renderer = nullptr) {
        if (game_state::esp_optic_proj && camera && camera == game_state::esp_optic_cam)
        {
            // Record what the first point of this epoch is projected with. One integer
            // compare per call; the body runs once per distinct epoch, not per point.
            // The 600 ms dump can only ever sample the reset state (the :2746 write is
            // unconditional), so sampling there answers "what does the timer see", not
            // "what did the projection use". This answers the second.
            if (game_state::esp_optic_radial_drawn_epoch != game_state::esp_optic_radial_epoch)
            {
                game_state::esp_optic_radial_drawn_epoch = game_state::esp_optic_radial_epoch;
                game_state::esp_optic_radial_drawn = game_state::esp_optic_radial;
                game_state::esp_optic_radial_drawn_set = game_state::esp_optic_radial_set;
            }
            return world_to_screen_optic(camera, world_point, game_state::esp_optic_radial);
        }
        return world_to_screen_fps(camera, world_point, zoom);
    }

    inline ULONGLONG esp_scaled_interval_ms(const ULONGLONG base_ms, float rate) {
        // Scans invoke IL2CPP and can become the dominant frame cost. Keep the
        // user setting responsive without allowing sub-frame scan loops.
        if (rate < 0.25f) rate = 0.25f;
        if (rate > 2.f) rate = 2.f;
        const double scaled = static_cast<double>(base_ms) / static_cast<double>(rate);
        if (scaled < 100.0) return 100;
        if (scaled > 600000.0) return 600000;
        return static_cast<ULONGLONG>(scaled + 0.5);
    }

    // EFT scope PIP camera (weapon-sway follows this transform, not FPS Camera).
    inline std::string try_localize_game_key(const std::string& key);  // defined below

    // Item requirement on an exfiltration point (hidden "need item" extracts):
    // returns true and fills `item_name` (localized ShortName) when the point
    // carries a TransferItemRequirement. Localization key pattern from the dump:
    // <Id> + " ShortName".
    inline bool try_get_exfil_item_requirement(Il2CppObject* exfil_point, std::string& item_name) {
        item_name.clear();
        if (!exfil_point || !exfil_point->klass) return false;
        Il2CppObjectInstance point(exfil_point);
        Il2CppArray* reqs = point.get_field<Il2CppArray*>("Requirements");
        if (!reqs || reqs->max_length == 0) return false;
        for (il2cpp_array_size_t i = 0; i < reqs->max_length; ++i)
        {
            Il2CppObject* req = reinterpret_cast<Il2CppObject**>(&reqs->data)[i];
            if (!req || !req->klass) continue;
            if (!strstr(req->klass->name, "TransferItemRequirement")) continue;
            Il2CppObjectInstance req_inst(req);
            Il2CppString* id_str = req_inst.get_field<Il2CppString*>("Id");
            const std::string id = il2utils::conv_string(id_str);
            if (id.empty())
            {
                item_name = req->klass->name;
                return true;
            }
            const std::string localized = try_localize_game_key(id + " ShortName");
            item_name = localized.empty() ? id : localized;
            return true;
        }
        return false;
    }

    // Everything the exfil LABEL needs, resolved in one pass over the point.
    //
    // Returned as a struct rather than three out-params because the caller was already making
    // two separate calls over the same object (display name + item requirement), and adding a
    // third for the scav-coop test would mean three walks of `Requirements` per exfil per frame.
    struct exfil_label_parts
    {
        std::string name;
        // The item the exit needs. For a SECRET point this is Settings.Id verbatim; for a
        // regular point it is the localized ShortName of a TransferItemRequirement. Empty when
        // the exit needs nothing.
        std::string item;
        bool        secret = false;
        bool        scav_coop = false;
    };

    // ---- EXFIL ELIGIBILITY: ask the game, do not infer it from a status byte ----
    //
    // The user reported (2026-10-05, session pid 18560) that exfils are labelled open when
    // they are not. Both call sites read the raw backing field:
    //
    //     EspModule.cpp:5979    exfiltration_point.get_field<int>("_status")
    //     TeleportModule.cpp:147  Il2CppObjectInstance(point).get_field<int>("_status")
    //
    // and both are wrong for two separate reasons.
    //
    // (a) THE FIELD IS A BYTE. ISIL, EFT/Interactive/ExfiltrationPoint.txt:92-96:
    //
    //         Method: EExfiltrationStatus get_Status()
    //           95: movzx eax,byte ptr [rcx+58h]      <-- ONE byte at +0x58
    //
    //     `get_field<int>` reads FOUR bytes at that offset, so it also reads three bytes of
    //     neighbouring instance data. Every EExfiltrationStatus value is < 9 so the low byte is
    //     right on little-endian, but the read still spans memory it does not own. The game's
    //     own getter is correct, self-documenting, and resolves once per class.
    //
    // (b) STATUS IS NOT ELIGIBILITY -- and this is what is on screen. ISIL:
    //
    //         ExfiltrationPoint.txt:3857 SetInitialStatus()
    //           3875: cmp dword ptr [rax+20h],1       <-- branches on a SUB-object's field
    //           3883: mov dl,4                        <-- writes 4
    //           3886: mov dl,2                        <-- or 2
    //         ExfiltrationPoint.txt:10417 HasMetRequirements(String profileId)
    //         ExfiltrationPoint.txt:8562  UnmetRequirements()
    //         ExfiltrationPoint.txt:2442  EligibleEntryPoints (Enumerable.Contains)
    //         ExfiltrationController.txt:3197  EligiblePoints(Profile)      <-- THE AUTHORITY
    //         ExfiltrationController.txt:4135  SecretEligiblePoints()
    //         ..._NestedType___c.txt:686/716  <EligibleForPmc> / <EligibleForScav>
    //
    //     So an exfil can carry status 2 "Available" and still be absent from EligiblePoints --
    //     because the player is Scav, or a requirement is unmet, or it is entry-point gated.
    //     Labelling from `_status` therefore says "Available" about an extract the player cannot
    //     use, which is the complaint exactly.
    //
    // THE FIX, AND THEN THE HALF OF IT THAT WAS WRONG. The 2026-10-05 fix made
    // `EligiblePoints()` membership the label. That was right about status and
    // wrong about the other direction, and it is why the report came back:
    // membership is NOT availability either -- see exfil_eligibility_of for the
    // reconstruction. `EligiblePoints` filters on `Settings.Chance > 0`,
    // `Settings.Name`, and `EligibleEntryPoints.Contains(entryPoint)`; it never
    // reads `_status` or `Requirements`. So a point absent from the list is
    // correctly not yours, but a point PRESENT in the list may still be closed.
    // The verdict is now the conjunction of both -- see exfil_eligibility_of.
    //
    // COST: EligiblePoints() BUILDS A FILTERED ARRAY, so it is not called per exfil and not
    // called per frame. One call per refresh, then a pointer comparison per exfil against a
    // vector that is a handful of entries long. `get_Status()` is a plain virtual read and IS
    // called per exfil.
    //
    // FAILS OPEN, and the direction matters: if the snapshot cannot be taken, eligibility stays
    // UNKNOWN and the caller keeps the status label it already had. A stale "Open" is bad;
    // showing nothing would be worse; and treating a failed snapshot as authoritative is how
    // this bug shipped in the first place.

    enum class exfil_eligibility : int { unknown = 0, eligible, not_eligible };

    // ---- THE EXFIL STATUS ENUM, as the game defines it ------------------------
    //
    // GameDump/<build>/dump.cs, `enum EExfiltrationStatus`, cross-checked against
    // ISIL `EFT/Interactive/ExfiltrationPoint.txt:92` (`get_Status` -> ONE byte at
    // +0x58, `movzx eax,byte ptr [rcx+58h]; ret`) and `:407` (`set_Status`
    // branches on `value == 3` then `value == 1`). Because it is a byte enum it
    // is *unsigned*, so the "-1 means n/a" convention used by `destination.status`
    // never collides with a real value.
    //
    // The previous table in this tree (`1=Closed, 2=Available, 4/5=Open,
    // 6=Pending, 7=Inactive, 8=Hidden`) is WRONG from 2 down and has no 8 at all.
    // It came from a decompiler's enum *name* list rather than its values, which
    // is the same failure this project has already been bitten by twice. The
    // labels below are derived per value below, not asserted.
    //
    //     name                        value  means, from the game's own code
    //     NotPresent                  1      trigger not spawned on this raid
    //     UncompleteRequirements      2      spawned, but Requirements not met
    //     Countdown                   3      shared-timer exfil in its countdown
    //     RegularMode                 4      open and usable
    //     Pending                     5      a player is inside and has extracted
    //     AwaitsManualActivation      6      needs a manual activation trigger
    //     Hidden                      7      present but deliberately hidden
    //
    // Derived from:
    //   value 1 -- `set_Status` has an explicit `cmp dil,1` arm (ExfiltrationPoint.txt:430)
    //              that calls `Disable()`, i.e. the point is removed from play.
    //   value 2 -- `SetInitialStatus` writes 2 when `Requirements` is
    //              `OfType<WorldEventRequirement>().Any()` (ExfiltrationPoint.txt:4017-4020).
    //              That is a *requirements not yet evaluated* state, the opposite
    //              of "Available". `SetStatusLogged` is what promotes it later.
    //   value 3 -- `set_Status` (ExfiltrationPoint.txt:407) and
    //              `GetRemainingExfiltrationTime` (ExfiltrationPoint.txt:1484) both
    //              special-case 3, and the latter is the one that computes
    //              `ExfiltrationTime - elapsed`: only a countdown has a remaining
    //              time to compute, so 3 is the shared-timer countdown.
    //   value 4 -- `SetInitialStatus` writes 4 as the ordinary "open" status
    //              (ExfiltrationPoint.txt:3883, mov dl,4) when there is no
    //              WorldEventRequirement. 4 is the only value the mod may render
    //              as "Open" on its own authority.
    //   value 5 -- `Disable(prevStatus)` opens with `cmp dl,5; je` (ExfiltrationPoint.txt:7212)
    //              -- a 5 is *not* something to disable, because it is the
    //              post-extraction transient.
    //   value 6 -- `SetStatusLogged`/`ExternalSetStatus` are the only writers, and
    //              the sibling class is `AwaitsManualActivationRequirement`.
    //   value 7 -- `Hidden`; `SecretExfiltrationPoint` uses its own
    //              `<EligibleForPmc>`/`<EligibleForScav>` flags instead, so a 7 on
    //              a regular point means the game is hiding it.
    enum class exfil_status : int {
        not_present = 1,
        uncomplete_requirements = 2,
        countdown = 3,
        regular_mode = 4,
        pending = 5,
        awaits_manual_activation = 6,
        hidden = 7,
    };

    // Is this status THIS PLAYER may leave by, right now?
    //
    // Only `RegularMode` (4). This is deliberately the narrowest answer available:
    //
    //   - NotPresent (1)          -> obviously not usable.
    //   - UncompleteRequirements (2) -> the trigger exists but Requirements are not
    //     satisfied. This is the value that produced the 2026-10-05 bug report:
    //     "exfils are labelled open when they are not".
    //   - Countdown (3)           -> the countdown is *running*, which means the
    //     extraction has not happened yet. Whether it will complete depends on
    //     other players; calling it Open is a guess.
    //   - Pending (5)             -> a player already went through. Not "open".
    //   - AwaitsManualActivation (6) -> by definition not open yet.
    //   - Hidden (7)              -> hidden.
    //
    // A value we do not recognise (a new game build, or 0 = never initialised)
    // returns false, so an unrecognised status is never rendered "Open". That is
    // the fail-CLOSED direction, and it is safe here: `exfil_eligibility_of`
    // returns `unknown` rather than `not_eligible` for these, so the caller keeps
    // its fallback label instead of being told a confident lie.
    inline bool exfil_status_is_open(int status) {
        return status == static_cast<int>(exfil_status::regular_mode);
    }

// Retry interval for the case where the answer is still MISSING. It is not a refresh
// interval: once the answer exists, the snapshot is never re-taken (see
// refresh_exfil_eligibility). Exfils are generated once on raid entrance, so per-raid is
// the correct lifetime and 1 Hz forever was polling a fixed value.
// WHEN the second pass runs, measured from the game's own raid-start call. This replaces
// kExfilEligibilityRetryMs entirely: eligibility is now taken a FIXED number of times per raid
// (at the first resolvable frame, and once more here) instead of on a timer. Bounded by
// construction, which a TTL keyed on "did we get an answer" never was -- see 98fad97b.
inline constexpr ULONGLONG kExfilSecondPassMs =  30000;
inline constexpr ULONGLONG kExfilThirdPassMs  = 300000;

// How many reads per raid, total. Three: first resolvable frame, +30 s, +300 s.
inline constexpr int kExfilPassCount = 3;

    struct exfil_eligibility_snapshot {
        // Keyed on the MAIN PLAYER as well as the controller, deliberately. Keying on the
        // controller alone is a trap: a new raid frees the old controller and can allocate
        // the new one at the same address, so a pointer-only key reads as valid for the whole
        // next raid while describing the previous one. The player object is what actually
        // changes per raid and is already resolved at the call site.
        Il2CppObject* player = nullptr;
        Il2CppObject* controller = nullptr;
        ULONGLONG     taken_at_ms = 0;

        // GetTickCount64() of the LocalRaidStarted that this snapshot belongs to. Copied
        // rather than read from a global at decide time, because a snapshot outlives the raid
        // that made it and must not start measuring against the NEXT raid's clock.
        ULONGLONG     raid_ms = 0;
        bool          valid = false;
        // WHICH lists were actually obtained. Without these, "not in the list" and "the list
        // was never taken" are indistinguishable, and reporting every extract `not_eligible`
        // would be fail-CLOSED -- every extract labelled "Blocked" -- which is a far worse
        // regression than the wrong-status bug this replaces.
        bool          have_regular = false;
        bool          have_secret = false;
        std::vector<Il2CppObject*> eligible;
        std::vector<Il2CppObject*> secret_eligible;

        void clear() {
            controller = nullptr; player = nullptr;

            passes_taken = 0; raid_ms = 0;
            taken_at_ms = 0; valid = false;
            have_regular = false; have_secret = false;
            eligible.clear(); secret_eligible.clear();
        }

        // "Do we have the answer?" -- have_regular specifically, because it is the one that needs
        // a Profile and therefore the one that can still be missing EARLY in a raid.
        // have_secret alone must not be enough: SecretEligiblePoints() takes no Profile, so it
        // succeeds before a Profile exists, and stopping there would leave every regular extract
        // reading `unknown` for the whole raid.
// How many times the lists have been TAKEN for this raid. Not "did we get an answer":
        // the two-pass schedule is a property of the CLOCK, and gating it on the answer is
        // what let SecretEligiblePoints() run 120x a second for a whole raid (98fad97b).
        // Whether a list was obtained decides what we may CLAIM -- see exfil_eligibility_of.
        int  passes_taken = 0;
    };

    // The player's Profile, the argument `EligiblePoints` requires. Same two-step the rest of
    // this file already uses (see the get_Profile fallback near line 649): the field first,
    // the property second.
    inline Il2CppObject* try_get_player_profile(Il2CppObject* player_obj) {
        if (!player_obj || !player_obj->klass) return nullptr;
        if (Il2CppObject* profile = try_get_field_object(player_obj, "Profile"))
            if (profile->klass) return profile;

        Il2CppObjectInstance inst(player_obj);
        const auto get_profile = inst.get_method<Il2CppObject* (*)(Il2CppObject*)>(
            "get_Profile", 0, false, false);
        if (get_profile)
        {
            Il2CppObject* profile = get_profile(player_obj);
            if (profile && profile->klass) return profile;
        }
        return nullptr;
    }

    // Copies a controller-owned eligible array into `out`. Returns false when the method could
    // not be resolved or produced no array, which the caller records so the verdict can fall
    // back to `unknown` instead of to a confident "Blocked".
    //
    // `arg_count` is passed through to `get_method` with `allow_any_argc = false`, and that is
    // load-bearing rather than stylistic. `il2utils::get_method` (il2utils.h:336-339) falls back
    // to "any arity" when the exact count misses, which hands back the first overload's pointer
    // regardless of its real signature. There is NO parameterless `EligiblePoints` -- ISIL has
    // `EligiblePoints(Profile)` at 3197 and `EligiblePoints(string)` at 3355 -- so asking for 0
    // args silently returned the 1-arg method, and calling it through a 1-parameter function
    // pointer left `rdx` holding garbage that the game then dereferences (`mov rbx,rdx` /
    // `mov rcx,[rbx+48h]`). That was a crash on the game thread, introduced by c6704e99.
    inline bool merge_eligible_array(Il2CppObject* controller, const char* method,
                                     int arg_count, Il2CppObject* arg,
                                     std::vector<Il2CppObject*>& out) {
        if (!controller || !controller->klass) return false;
        Il2CppObjectInstance inst(controller);
        Il2CppArray* arr = nullptr;
        if (arg)
        {
            const auto getter = inst.get_method<Il2CppArray* (*)(Il2CppObject*, Il2CppObject*)>(
                method, arg_count, false, /*allow_any_argc=*/false);
            if (!getter) return false;
            arr = getter(controller, arg);
        }
        else
        {
            const auto getter = inst.get_method<Il2CppArray* (*)(Il2CppObject*)>(
                method, arg_count, false, /*allow_any_argc=*/false);
            if (!getter) return false;
            arr = getter(controller);
        }
        if (!arr) return false;

        // Local liveness, not eft_api::is_il2cpp_object_likely_valid -- that is defined LATER
        // in this header, so using it here is a compile error (C3861) and reaching forward
        // would couple this block to an unrelated declaration's position. The narrower test is
        // the right one anyway: these are slots straight out of the game's own eligible array,
        // where the only failure mode is a null slot, so `p && p->klass` covers it.
        for (il2cpp_array_size_t i = 0; i < arr->max_length; ++i)
        {
            Il2CppObject* p = reinterpret_cast<Il2CppObject**>(&arr->data)[i];
            if (p && p->klass) out.push_back(p);
        }
        // An array that resolved but is EMPTY is still a valid answer: it means nothing is
        // currently eligible, which is a real and common state early in a raid.
        return true;
    }

    inline exfil_eligibility_snapshot& exfil_eligibility_cache() {
        static exfil_eligibility_snapshot snap;
        return snap;
    }

    // One refresh of the game's own eligible sets, for the current raid and the current player.
    //
    // `main_player` is needed because `EligiblePoints` takes a Profile. Without one the regular
    // list is simply not taken and the verdict stays `unknown` -- see exfil_eligibility_of.

// ---- WHEN THE RAID STARTED, as the user defines it: the game's LocalRaidStarted call -------
//
// Set from hk_local_raid_started. That hook is the REQUEST side of the raid-start RPC, not its
// result -- its own comment says nothing about the destination is knowable there -- but all
// this needs is a clock reference, and the game has by definition finished starting a raid by
// the time the request goes out. Anchoring here rather than on "the first frame we saw a
// controller" is what makes the count exactly two: a reference that only exists once we already
// have a controller cannot bound the pre-controller phase.
inline std::atomic<long long>& exfil_raid_started_ms() {
    static std::atomic<long long> ms{0};
    return ms;
}

// Also resets the pass counter, so a new raid cannot inherit the previous raid's
// "passes_taken == 2" and skip its second pass. The (controller, player) key would catch a new
// raid anyway, but only AFTER the first frame of the new one, and this makes the intent local.
inline void note_local_raid_started() noexcept {
    const long long now = (long long)GetTickCount64();
    exfil_raid_started_ms().store(now, std::memory_order_relaxed);
    {
        std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
        exfil_eligibility_snapshot& snap = exfil_eligibility_cache();
        snap.passes_taken = 0;
        snap.raid_ms = (ULONGLONG)now;
    }
    logger::info("exfil: raid start noted -- eligibility taken at first resolvable frame and "
                 "once more at +" + std::to_string(kExfilSecondPassMs / 1000) + "s");
}

    inline bool refresh_exfil_eligibility(Il2CppObject* exfiltration_controller,
                                          Il2CppObject* main_player) {
        // Zone because the alternative was 11.6 s of unaccounted time: this is called once
        // per gameworld_update from EspModule.cpp and was inside no zone, so it was part of
        // the 89.6% remainder rather than a measurable line item.
        TA_ZONE_N("eft_api::refresh_exfil_eligibility");
        exfil_eligibility_snapshot& snap = exfil_eligibility_cache();
        const ULONGLONG now = GetTickCount64();
        // TWO PASSES PER RAID, ON A CLOCK. Not a TTL, and not gated on whether the first
        // pass got an answer.
        //
        //   pass 1  the first frame we can resolve a controller and a player
        //   pass 2  exactly once, kExfilSecondPassMs after LocalRaidStarted
        //   after   never again for this raid
        //
        // Both halves of that are load-bearing, and both were got wrong at least once:
        //
        // - Gating on the ANSWER is what 98fad97b removed. `have_regular` is set only when
        //   EligiblePoints(Profile) was actually taken, so a Profile that never resolved made
        //   the guard never short-circuit, and SecretEligiblePoints() -- a managed method that
        //   BUILDS A FILTERED ARRAY (ISIL ExfiltrationController.txt:4135) -- ran 120 times a
        //   second for the whole raid. The answer decides what we may CLAIM
        //   (exfil_eligibility_of), never whether we may re-READ.
        //
        // - Gating on a TTL anchored at taken_at_ms instead of at the raid start is the same
        //   class of error: it makes the number of passes depend on when the first frame
        //   happened to land. Anchored at the game's own raid-start call, the count is two,
        //   always, whatever the frame timing.
        //
        // The +30 s pass exists because pass 1 runs early enough that the Profile may be unset
        // and requirement evaluation may not have run. This is the only concession to the fact
        // that eligibility is not quite fixed for the raid.
        const bool same_raid = snap.valid
            && snap.controller == exfiltration_controller
            && snap.player == main_player;
        const ULONGLONG raid_ms = exfil_raid_started_ms().load(std::memory_order_relaxed);
        // Fall back to this snapshot's own raid marker when the hook never fired for it, so a
        // raid that did not come through LocalRaidStarted still gets its second pass rather
        // than an immediate re-take on every frame (a 0 reference would always be "elapsed").
        const ULONGLONG reference = (raid_ms != 0 && raid_ms == snap.raid_ms)
            ? raid_ms : snap.taken_at_ms;
// A pass is DUE when its own deadline has passed and it has not been taken. Written as a
        // table indexed by how many have been taken, because the two-pass form this replaced
        // (`passes_taken >= 2 || elapsed < kExfilSecondPassMs`) cannot express three deadlines
        // without a nested ladder, and the ladder is where the next deadline gets forgotten.
        //
        //     taken 0 -> the first resolvable frame takes it, unconditionally
        //     taken 1 -> due at +30  s
        //     taken 2 -> due at +300 s
        //     taken 3 -> never again, for the rest of the raid
        //
        // Still not gated on whether a pass got an answer. That is 98fad97b's bug, and it is
        // the reason this reads as a deadline table rather than as "retry until satisfied":
        // whether a list was obtained decides what we may CLAIM (exfil_eligibility_of), never
        // whether we may re-READ.
        if (same_raid && snap.passes_taken >= 1)
        {
            if (snap.passes_taken >= kExfilPassCount) return true;
            const ULONGLONG due_ms = (snap.passes_taken == 1)
                ? kExfilSecondPassMs : kExfilThirdPassMs;
            if ((now - reference) < due_ms) return true;
        }

        snap.clear();
        snap.controller = exfiltration_controller;
        snap.player = main_player;
        snap.taken_at_ms = now;
        // Copied once, so the +30 s test is anchored to the raid rather than to this pass.
        // If note_local_raid_started() already ran for this raid its stamp is authoritative and
        // identical; this only fills the gap for a raid the hook never saw.
        if (snap.raid_ms == 0) snap.raid_ms = (ULONGLONG)raid_ms;


        // Same reasoning as merge_eligible_array: see the note there.
        if (!exfiltration_controller || !exfiltration_controller->klass) return false;

        // Regular exfils: `EligiblePoints(Profile)`, one argument, arity verified.
        if (Il2CppObject* profile = try_get_player_profile(main_player))
            snap.have_regular = merge_eligible_array(
                exfiltration_controller, "EligiblePoints", 1, profile, snap.eligible);

        // Secret exfils: `SecretEligiblePoints()` is genuinely 0-arg (ISIL 4135), so it needs
        // no Profile and keeps working when the Profile cannot be resolved.
        snap.have_secret = merge_eligible_array(
            exfiltration_controller, "SecretEligiblePoints", 0, nullptr, snap.secret_eligible);

        // Counted HERE, not above: if the controller is invalid the function returns false
        // before reading anything, and a counter incremented before that would burn one of
        // the two passes on a frame where no list was taken.
        ++snap.passes_taken;
        snap.valid = true;
        return true;
    }

    // The status BYTE, read the way the game reads it.
    //
    // Kept separate from eligibility on purpose: status answers "what phase is this extract in",
    // eligibility answers "may this player leave by it right now". They are different questions
    // and the bug was conflating them. `get_Status()` IS parameterless (ISIL: `movzx eax,byte
    // ptr [rcx+58h]; ret`), so `allow_any_argc=false` is safe here and keeps a future overload
    // from handing back a pointer with a different signature.
    //
    // DEFINED BEFORE exfil_eligibility_of because that function now calls it. It was originally
    // written after, when only the ESP's fallback switch used it.
    inline int get_exfil_status(Il2CppObject* exfil_point) {
        if (!exfil_point || !exfil_point->klass) return 0;
        Il2CppObjectInstance inst(exfil_point);
        const auto getter = inst.get_method<int (*)(Il2CppObject*)>(
            "get_Status", 0, false, /*allow_any_argc=*/false);
        if (getter) return getter(exfil_point);
        // Fallback: the backing field, as a BYTE (ISIL: movzx eax,byte ptr [rcx+58h]).
        const FieldInfo* f = il2utils::resolve_field(exfil_point->klass, "_status");
        if (f) return *reinterpret_cast<uint8_t*>(
            reinterpret_cast<uintptr_t>(exfil_point) + f->offset);
        return 0;
    }

    // Pointer identity, not name: two SecretExfiltrationPoint instances can share a name, and
    // the eligible arrays hold the same instances the caller is holding.
    //
    // WHAT THIS ACTUALLY ANSWERS. It is a conjunction, and both halves are needed:
    //
    //   1. MEMBERSHIP  -- `EligiblePoints(Profile)` / `SecretEligiblePoints()`.
    //   2. LIVE STATUS -- `get_Status()`.
    //
    // (1) alone is NOT availability, and this is the defect the 2026-10-05 fix
    // left behind. Reconstructed from the game build's own lambdas (ISIL
    // `ExfiltrationController_NestedType___c.txt:550` and `:598`, cross-checked
    // against `GameDump/120047965/dump.cs` ExitTriggerSettings):
    //
    //     <EligiblePoints>b__33_1  x.Settings.Chance > 0f
    //     <EligiblePoints>b__33_2  x.Settings.Name is not null/empty
    //     <EligiblePoints>b__0    x.EligibleEntryPoints.Contains(entryPointName)
    //
    // `Chance` and `Name` are backend *spawn configuration* (the same fields
    // `RollChance` reads), and `EligibleEntryPoints` is
    // `Settings.EntryPoints.Split(',')` set once in `LoadSettings`
    // (ExfiltrationPoint.txt:3592). So `EligiblePoints` answers "which points
    // EXIST for this profile's entry point" -- which is exactly what
    // `BaseLocalGame` feeds it to `ExtractionTimersPanel.SetTime`
    // (BaseLocalGame`1.txt:7722/7739/7831). It never looks at `_status` or at
    // `Requirements`, so a point can sit in the list at `UncompleteRequirements`
    // (2) and be reported "Open". That is the remaining half of the user report.
    //
    // (2) alone is also not enough -- it is the original bug: status is per-point
    // and shared between players, so it cannot know this profile is Scav or that
    // a requirement is unmet. Hence the conjunction.
    //
    // The KILL order matters. A point that is in the list but NOT open is
    // `unknown`, not `not_eligible`: the caller's fallback label ("Not
    // available", "Blocked: need Item") is *more* informative than a bare
    // `not_eligible`, and this keeps the fail-open contract of
    // `have_regular`/`have_secret` intact -- a status we cannot read degrades to
    // the old behaviour rather than to a confident "Blocked".
    //
    // MECHANICS WORTH KNOWING: `get_Status()` is a virtual 0-arg method resolved
    // with `allow_any_argc = false`, so it cannot be silently handed a wrong
    // overload. It is called per exfil per frame, which is cheap (one indirect
    // call through a cached MethodInfo) and is NOT the same trap as
    // `EligiblePoints()` -- that method BUILDS A FILTERED ARRAY, which is why IT
    // is still called once per refresh and not here.
    inline exfil_eligibility exfil_eligibility_of(Il2CppObject* exfil_point) {
        if (!exfil_point) return exfil_eligibility::unknown;
        exfil_eligibility_snapshot& snap = exfil_eligibility_cache();
        if (!snap.valid) return exfil_eligibility::unknown;

        // Membership first: if the point is simply not in the eligible set the
        // status byte is irrelevant and we keep the pre-existing verdict.
        bool eligible = false;
        for (Il2CppObject* p : snap.eligible)
            if (p == exfil_point) { eligible = true; break; }
        if (!eligible)
            for (Il2CppObject* p : snap.secret_eligible)
                if (p == exfil_point) { eligible = true; break; }

        // Only a confident "not eligible" when BOTH lists were actually taken. Otherwise this
        // is an absence of information, not an answer, and the caller keeps the status label.
        if (!eligible)
            return (snap.have_regular && snap.have_secret)
                ? exfil_eligibility::not_eligible
                : exfil_eligibility::unknown;

        // In the eligible set. Now require the live status to agree. A point that
        // exists but is not open is reported `unknown` -- see the KILL order above.
        if (!exfil_status_is_open(get_exfil_status(exfil_point)))
            return exfil_eligibility::unknown;
        return exfil_eligibility::eligible;
    }

    // The status BYTE is defined above exfil_eligibility_of, which now calls it.


    // Lens renderer from the active weapon: Player -> HandsController -> Item
    // (FirearmController/Stationary/BTR) -> WeaponSystem -> LensRenderer field.
    inline Il2CppObject* get_lens_renderer_from_weapon(Il2CppObject* player_obj) {
        if (!player_obj || !player_obj->klass) return nullptr;

        Il2CppObject* hands_controller = nullptr;
        {
            Il2CppObjectInstance player(player_obj);
            const auto get_hands = player.get_method<Il2CppObject* (*)(Il2CppObject*)>(
                "get_HandsController", 0);
            if (get_hands)
                hands_controller = get_hands(player_obj);
        }
        if (!hands_controller || !hands_controller->klass) return nullptr;

        Il2CppObject* weapon = nullptr;
        {
            Il2CppObjectInstance fc(hands_controller);
            const auto get_item = fc.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_Item", 0);
            if (get_item)
                weapon = get_item(hands_controller);
        }
        if (!weapon || !weapon->klass) return nullptr;

        const std::string klass_name = weapon->klass->name;
        if (klass_name.find("FirearmController") == std::string::npos &&
            klass_name.find("Stationary") == std::string::npos &&
            klass_name.find("BTR") == std::string::npos)
        {
            return nullptr;
        }

        Il2CppObject* weapon_system = nullptr;
        for (const char* field : {"_weaponSystem", "WeaponSystem", "<WeaponSystem>k__BackingField"})
        {
            const FieldInfo* fi = il2utils::resolve_field(weapon->klass, field);
            if (!fi) continue;
            weapon_system = *reinterpret_cast<Il2CppObject**>(
                reinterpret_cast<UINT64>(weapon) + fi->offset);
            if (weapon_system) break;
        }
        if (!weapon_system || !weapon_system->klass) return nullptr;

        // LensRenderer / <LensRenderer>k__BackingField / _lensRenderer, then the
        // get_LensRenderer() method.
        for (const char* name : {"LensRenderer", "<LensRenderer>k__BackingField", "_lensRenderer"})
        {
            const FieldInfo* field = il2utils::resolve_field(weapon_system->klass, name);
            if (!field) continue;
            Il2CppObject* lens = *reinterpret_cast<Il2CppObject**>(
                reinterpret_cast<UINT64>(weapon_system) + field->offset);
            if (lens && lens->klass) return lens;
        }
        Il2CppObjectInstance ws(weapon_system);
        const auto get_lens = ws.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_LensRenderer", 0);
        if (get_lens)
        {
            Il2CppObject* lens = get_lens(weapon_system);
            if (lens && lens->klass) return lens;
        }
        return nullptr;
    }

    inline Il2CppObject* try_get_optic_camera() {
        static const char* k_exact[] = {
            "BaseOpticCamera(Clone)",
            "BaseOpticCamera",
            "OpticCamera(Clone)",
            "OpticCamera",
        };
        for (const char* name : k_exact)
        {
            if (Il2CppObject* cam = unity::get_named_camera(name))
                return cam;
        }
        if (Il2CppObject* cam = unity::find_camera_name_contains("Optic"))
            return cam;
        if (Il2CppObject* cam = unity::find_camera_name_contains("optic"))
            return cam;
        // Name probes can miss across scopes/builds; the lens pipeline already
        // navigates CameraManager -> OpticCameraManager -> Camera — use that as
        // the authoritative fallback.
        if (Il2CppObject* cam = optics::lens::optic_camera_from_manager())
            return cam;
        return nullptr;
    }

    // ===================================================================
    // ===================================================================
    // ScopeMaskRenderer reachability probe -- REMOVED 2026-09-28. IT CRASHED THE GAME.
    //
    // DO NOT re-add this next to setup_esp_optic_frame. Read the rest of this first.
    //
    // What it was for. Defect A's root cause is measured: the lens mask is the
    // projected bounding box of the lens renderer's world AABB
    // (optics_lens_pipeline.h:1996-2024), and those bounds enclose the scope HOUSING
    // rather than just the clear aperture. From two 1919x1079 frames, the region
    // over-covers the visible aperture by 19-22% in radius, the excess landing on the
    // black housing. The box-vs-disc projection term explains at most 0.7% of that
    // (a real scope gives R/d ~ 0.04-0.12, box/disc = x/sqrt(1-x^2) = 1.001-1.003),
    // so the ~1.2x body-to-aperture ratio is a genuine per-optic geometric constant.
    //
    // Why the game cannot just tell us. No aperture number is exposed anywhere in
    // Assembly-CSharp (searched; the only lens/mask/size accessors belong to
    // FaceCoverMask*, NightVision* and ThermalVision*, all unrelated systems), and
    // CreateMaskTexture(Camera,int,int) only allocates a FULL-SCREEN RenderTexture --
    // its two ints are the camera input size, since CheckMaskTexture compares
    // _maskTexture.width/height against them and Camera.get_pixelHeight feeds them.
    // The aperture is painted into that texture later by DrawOptic's command buffer
    // and never sized by anything readable. So the mask bitmap is the only
    // authoritative source, and reading it means a readback.
    //
    // WHY IT CRASHED, which is the part that matters. This probe was called from
    // setup_esp_optic_frame, and that runs on the PRESENT HOOK -- the RENDER thread,
    // not Unity's main thread. The 2026-09-28 19:31:36 log proves it: the probe logged
    // on tid=8344 while every game-side line (hk_local_raid_started, Magic Aim ammo
    // cache) logged on tid=19908, and the process died immediately after, ~5.5 s into
    // "Loading in at: factory4_day".
    //
    //      19:31:30.286 tid=8344  optic-route: idle (no local player yet)
    //      19:31:30.485 tid=19908  Loading in at: factory4_day
    //      19:31:36.013 tid=8344  [optic-maskprobe] class resolved ns='' klass=0x324dad30
    //      <crash>
    //
    // No warn line follows, and both resolve_image("UnityEngine.CoreModule.dll") and
    // resolve_class(ue,"UnityEngine","Object") warn on failure, so both had succeeded:
    // execution had reached Object.FindObjectOfType(Type). Unity's object registry is
    // not thread-safe, and walking it from the render thread while the main thread is
    // still populating the raid scene is a hard crash. This was an architectural
    // mistake, not a bad argument list or a stale offset.
    //
    // The consequence is bigger than this probe: Graphics.Blit and
    // Texture2D.GetPixels32 are main-thread-only for the same reason, so the whole
    // readback plan is misfiled. It cannot be driven from the overlay at all.
    //
    // WHERE IT MUST RUN INSTEAD. UnityEngine.LateUpdate on the main thread.
    // EFT.CameraControl.OpticComponentUpdater.LateUpdate() is the right anchor: main
    // thread, alive only while the optic component is (i.e. in a raid, while scoped),
    // and an object this file already holds for the FOV work. always_on.h already
    // hooks main-thread game callbacks the same way (hk_local_raid_started logs on
    // tid=19908), so il2utils::hook_method is the established mechanism.
    //
    // Still unverified, and to be logged rather than assumed next time: whether
    // _maskTexture really sits at +0x58 (ISIL's sole RenderTexture store in
    // CreateMaskTexture says so; the probe read it BY NAME via
    // il2cpp_class_get_field_from_name precisely so the log could confirm it instead
    // of trusting it), and whether FindObjectOfType accepts the raw Il2CppType* from
    // class_get_type. Both are one cheap log line from a main-thread call site.
    // ===================================================================

    // THE -1 SENTINEL. 2026-10-11, and unlike the m_CachedPtr guards above it is
    // not a race.
    //
    // This morning's crashes (pids 23080 and 8472, build 6ACB4D10) both faulted
    // reading 0xFFFFFFFFFFFFFFFF: the probe's `ACCESS_VIOLATION READ of
    // 0xFFFFFFFFFFFFFFFF` at EspModule::draw_overlay+0x2D1, which is
    // `cmp qword ptr [rax], 0` with rax loaded as -1, and a resolve_esp_camera
    // frame under a Unity getter that had just RETURNED the same value. An
    // il2cpp wrapper whose object is gone can hand back -1 rather than null --
    // and -1 is not null, so every `if (!cam)` in this file is blind to it,
    // `cam->klass` on it faults, and the trust check below would project the
    // overlay out of it.
    //
    // WHAT THIS IS NOT: it is not the per-object liveness guard tried and removed
    // on 2026-10-04. That one read a field of a real object and raced with its
    // destruction. This one tests the POINTER ITSELF, and the value tested is
    // the value the caller passes on, with no dereference in between -- so the
    // check cannot pass for one pointer and be used with another. What it cannot
    // do is stop an object that is alive at the check and destroyed before the
    // call; that window is the is_in_raid gate's trade, stated above.
    //
    // WHERE IT APPLIES: every camera pointer this file publishes or consumes.
    // The resolver's return value is the load-bearing one -- a -1 that escapes
    // resolve_esp_camera reaches EspModule::draw_overlay, where it faulted.
    inline bool camera_ptr_invalid(const Il2CppObject* cam) {
        return !cam || reinterpret_cast<uintptr_t>(cam) == ~(uintptr_t)0;
    }

    inline bool camera_is_enabled(Il2CppObject* camera) {
        // This used to open with
        //
        //     if (!unity::is_unity_object_alive(camera)) return false;
        //
        // and the REMOVAL is the finding, not a revert. That was the correct DIAGNOSIS --
        // UnityEngine.Object.m_CachedPtr is the field every managed call dereferences at
        // this+0x10, and section 0.16's freed collider faulted on exactly that offset --
        // and it did not fix the crash. All four 2026-10-03/04 exfil crashes happened with
        // this guard deployed, three of them with byte-identical stacks across separate
        // processes.
        //
        // WHY IT SURVIVED: m_CachedPtr is the CONSEQUENCE of destruction. Reading it and then
        // calling through the wrapper is a race with no ordering between our read and the
        // game's write -- the check can pass and the object can die before the call is
        // issued. No placement of a check on that field removes the window, only shrinks it,
        // and the resolver makes hundreds of managed calls per frame, so the window was hit
        // every time.
        //
        // WHAT REPLACED IT is resolve_esp_camera's is_in_raid gate, which is different in
        // kind: hk_local_raid_ended clears that on the GAME thread before the game is handed
        // back and before anything is destroyed. A render-thread read that still sees `true`
        // therefore means teardown has not begun. That is an ordering fact, not a race.
        //
        // AND THE PER-OBJECT FORM DOMINATED THE PROFILE: 44.6% of all self time in the 08:49
        // capture -- 64.87 s over 140,875 calls, 460 us each -- because four call sites on a
        // 64-slot memo drove the hit rate from 88% to 57% (unity-memo in the log, which is
        // an independent measurement and not Tracy's), and every miss is a VirtualQuery that
        // serialises on the process address-space lock.
        //
        // What remains below is the WRAPPER check. It is free, and it still catches the case
        // the flag cannot: a null or unclassified pointer handed in from outside a raid.
        // The sentinel runs FIRST: -1 is non-null, so the old condition ran straight into
        // camera->klass on it, which is the pid-23080 fault site (draw_overlay+0x2D1 is
        // `cmp qword ptr [rax], 0` with rax = -1). See camera_ptr_invalid.
        if (camera_ptr_invalid(camera) || !camera->klass) return false;
        Il2CppObjectInstance inst(camera);
        // Behaviour.enabled
        if (const auto get_en = inst.get_method<bool (*)(Il2CppObject*)>("get_enabled", 0, false))
        {
            if (!get_en(camera))
                return false;
        }
        // GameObject.activeInHierarchy — optic GO is often disabled when not ADS
        if (Il2CppObject* go = unity::component_get_game_object(camera))
        {
            Il2CppObjectInstance goi(go);
            if (const auto get_active = goi.get_method<bool (*)(Il2CppObject*)>("get_activeInHierarchy", 0, false))
                return get_active(go);
            if (const auto get_active2 = goi.get_method<bool (*)(Il2CppObject*)>("get_active", 0, false))
                return get_active2(go);
        }
        return true;
    }

    // ===================================================================
    // Camera choice: WHICH camera, and how far it is from the local player.
    // ===================================================================
    //
    // User report 2026-10-02: as the raid started, the ESP camera looked like it had
    // landed on a BOT rather than on the local player, and corrected itself once the
    // player zoomed into a scope. There are two ways this code can return a camera that
    // is not ours, and they are different in kind:
    //
    //   a) unity::get_named_camera("FPS Camera") returns the FIRST camera in Camera.all
    //      whose name matches. Nothing establishes that the scene holds only one such
    //      camera, so with more than one match the choice is an accident of enumeration
    //      order rather than a decision.
    //   b) The fallback is Camera.current, which this file's own comment says is only
    //      reliable inside Unity's render callbacks, not from our Present hook.
    //
    // Counted rather than argued, because "it picked a bot" and "it picked a bot twice in
    // a raid start and never again" need different fixes and the counters distinguish
    // them: `named_multi` says whether (a) is reachable AT ALL, and `far` says whether
    // whatever we ended up with was near the local player. The mean and max distances are
    // logged so the threshold below can be set from a capture instead of guessed at.
    enum class cam_source : int { named = 0,
        current_fallback,
        none,
        COUNT };
    inline constexpr int kCamSourceCount = static_cast<int>(cam_source::COUNT);

    // Deliberately generous. The threshold exists to catch a camera on some other
    // character, not to police our own: a player who is airborne, prone or mid-ragdoll is
    // exactly when their rig transform and its camera disagree most, and that must not
    // start costing frames.
    inline constexpr float kCamTrustRadius = 6.0f;

    inline std::atomic<unsigned long long>* g_cam_source_counts() {
        static std::atomic<unsigned long long> counts[kCamSourceCount];
        return counts;
    }
    // Calls where the name matched more than one camera, i.e. where (a) was in play.
    inline std::atomic<unsigned long long> g_cam_named_multi{0};
    // Resolves attempted, counted separately from the sources so the closed set has a
    // denominator. Deriving the denominator from the buckets defeats the point: a bucket
    // that failed to count itself is exactly what the check exists to catch.
    inline std::atomic<unsigned long long> g_cam_calls{0};
    // Resolved cameras further than kCamTrustRadius from the local player, and how many of
    // those we refused to use.
    inline std::atomic<unsigned long long> g_cam_far{0};
    inline std::atomic<unsigned long long> g_cam_far_refused{0};
    // Millimetres, so the sum stays exact in an integer counter. 1e3 scale, not 1e6:
    // distances here are metres-to-tens-of-metres, so millimetres is already far more
    // precision than a threshold comparison needs.
    inline std::atomic<unsigned long long> g_cam_dist_mm_sum{0};
    inline std::atomic<unsigned long long> g_cam_dist_mm_max{0};

    inline void bump_cam_source(const cam_source s) {
        g_cam_source_counts()[static_cast<int>(s)].fetch_add(1, std::memory_order_relaxed);
    }

    // Un-count a source that was tentatively counted and then retracted.
    //
    // EXISTS because `pick_esp_fps_camera` counts its bucket BEFORE it has decided to
    // keep the camera, and the refuse path below has to take that count back. Two
    // separate functions rather than a raw `fetch_sub` at the call site, because the
    // MISMATCH this fixes was a double-RETACTION of the same call and neither function
    // can see the other's:
    //
    //   1. `bump_cam_source(source)` counts the tentative bucket.        (+1 source)
    //   2. refuse path: fetch_sub(1) on source, bump_cam_source(none).  (-1 source, +1 none)
    //   3. `resolve_esp_camera` sees cam == nullptr and RETURNS, and the caller --
    //      `maybe_report_camera_choice`'s own accounting, and any future caller --
    //      can also decide the resolve produced nothing and count `none` AGAIN.
    //
    // Step 3 is the bug, and it is observable: 4 of 9 `cam-choice` lines in the
    // 2026-10-04 08:37 session read `[MISMATCH]`, with `sum` EXCEEDING `resolves` --
    // e.g. `resolves=6668 named=6669`. A sum larger than the denominator is not
    // possible from the closed set alone; it needs one resolve counted twice, which is
    // exactly a `none` counted at step 2 and again at step 3.
    //
    // So the invariant is stated once, here, and the refuse path uses it:
    //
    //     exactly ONE of { bump_cam_source(source), retract_cam_source(source) }
    //
    // per resolve, and `none` is bumped exactly once per refused resolve. The reporter
    // can then keep treating `[closed]` as evidence that no path is uncounted, which is
    // the whole reason it computes the sum at all.
    inline void retract_cam_source(const cam_source s) {
        g_cam_source_counts()[static_cast<int>(s)].fetch_sub(1, std::memory_order_relaxed);
    }

    // Throttled, and read on the render thread while resolve_esp_camera is called from
    // there. Atomics rather than plain counters because the aimbot calls the resolver too.
    inline void maybe_report_camera_choice() {
        static auto s_last = std::chrono::steady_clock::now();
        const auto now = std::chrono::steady_clock::now();
        if (now - s_last < std::chrono::milliseconds(30000)) return;
        s_last = now;

        auto* c = g_cam_source_counts();
        // SNAPSHOT, THEN CLEAR -- and the order is the whole point.
        //
        // This used to read the three buckets with `.load()` for the printed values,
        // compute `sum` from those reads, and only afterwards `store(0)` them at the end
        // of the line. Between the load and the store, a concurrent resolve can bump a
        // bucket -- and the aimbot calls this resolver from the game thread while
        // `maybe_report_camera_choice` is called from the render thread, so that window
        // is real. Observed in the 2026-10-04 08:37 session, 4 lines of 9 mismatched, in
        // BOTH directions:
        //
        //     resolves=2734 named=2733   sum < resolves   (a resolve counted after `sum`)
        //     resolves=6668 named=6669   sum > resolves   (a resolve counted before `sum`,
        //                                                    and after `resolves` was read)
        //
        // So this was a torn read of a live counter set, not a missing count. Which
        // means the `[MISMATCH]` flag -- documented as detecting "a return path that does
        // not count itself" -- was reporting a race in the reporter. A check that cries
        // wolf on 4 of 9 lines is worse than no check, because the next reader assumes the
        // invariant is broken and goes looking for a bug that is not there.
        //
        // Each counter is now `exchange`d into a local, which takes the value AND clears
        // it in one indivisible step, so every bucket, the resolve count and the distance
        // accumulators all describe the SAME instant. `sum` is computed from the
        // snapshot, never from a second read.
        unsigned long long bucket[kCamSourceCount];
        for (int i = 0; i < kCamSourceCount; ++i)
            bucket[i] = c[i].exchange(0, std::memory_order_relaxed);

        unsigned long long sum = 0;
        for (int i = 0; i < kCamSourceCount; ++i) sum += bucket[i];
        // Every resolve counts exactly one source, including the frames it refuses, so the
        // closed set must reconcile. If it does not, a return path exists that does not
        // count itself and the rest of the line is not safe to read.
        const auto n = bucket[static_cast<int>(cam_source::named)]
            + bucket[static_cast<int>(cam_source::current_fallback)];
        const auto dist_sum = g_cam_dist_mm_sum.exchange(0, std::memory_order_relaxed);
        const auto dist_max = g_cam_dist_mm_max.exchange(0, std::memory_order_relaxed);
        const auto multi = g_cam_named_multi.exchange(0, std::memory_order_relaxed);
        const auto far_count = g_cam_far.exchange(0, std::memory_order_relaxed);
        const auto refused_count = g_cam_far_refused.exchange(0, std::memory_order_relaxed);

        const auto calls = g_cam_calls.exchange(0, std::memory_order_relaxed);
        logger::info("cam-choice: resolves=" + std::to_string(calls)
            + " named=" + std::to_string(bucket[static_cast<int>(cam_source::named)])
            + " fallback=" + std::to_string(bucket[static_cast<int>(cam_source::current_fallback)])
            + " none=" + std::to_string(bucket[static_cast<int>(cam_source::none)])
            + " | named_multi=" + std::to_string(multi)
            + " far=" + std::to_string(far_count)
            + " far_refused=" + std::to_string(refused_count)
            + " dist_mean_m=" + std::to_string(n ? static_cast<double>(dist_sum) / n / 1000.0 : 0.0)
            + " dist_max_m=" + std::to_string(static_cast<double>(dist_max) / 1000.0)
            + (calls == 0 ? " [idle]" : "")
            + (sum == calls ? " [closed]" : " [MISMATCH sum=" + std::to_string(sum) + "]"));
        // No trailing clear: the buckets were already zeroed by the exchange() snapshot
        // above. Leaving a store(0) here would re-introduce the window that snapshot
        // exists to close -- it would discard any resolve that landed between the
        // snapshot and this line, making `sum` exceed `calls` for real.
    }

    // World position of any component-backed object: two hops to the transform.
    inline bool camera_world_position(Il2CppObject* cam, unity::vector3& out) {
        if (!cam) return false;
        Il2CppObject* go = unity::component_get_game_object(cam);
        Il2CppObject* tr = go ? unity::gameobject_get_transform(go) : nullptr;
        if (!tr) return false;
        out = unity::transform_get_pos(tr);
        return true;
    }

    // Our own reference point for "is this camera ours". Taken as a parameter rather than
    // read from g_local_player: that global is never cleared on raid exit, so dereferencing
    // it from the render thread would be a stale-pointer read on a path that currently has
    // no reason to take one. EspModule already hands main_player_ to setup_esp_optic_frame
    // on this same thread, so this adds no new trust and no new lifetime question.
    inline bool local_player_world_position(Il2CppObject* player, unity::vector3& out) {
        return camera_world_position(player, out);
    }

    // The FPS camera, chosen with the local player as the tiebreak.
    //
    // The change from get_named_camera is small and specific: when the name matches more
    // than once, take the match NEAREST the local player instead of the first enumerated.
    // When there is one match, or when no local player is known to rank against, this
    // returns exactly what the old code returned -- every score is constant and the first
    // candidate wins, which is find_camera_if's semantics by construction.
    inline Il2CppObject* pick_esp_fps_camera(Il2CppObject* local_player) {
        unity::vector3 eye{};
        const bool have_eye = local_player_world_position(local_player, eye);
        g_cam_calls.fetch_add(1, std::memory_order_relaxed);

        int named_matches = 0;
        Il2CppObject* fps = unity::find_camera_if_best(
            // NO liveness check in this predicate, deliberately, and the reason is MEASURED.
            //
            // A liveness guard here was added on 2026-10-04 and REMOVED the same day. It cost
            // ~9 calls per resolution -- find_camera_if_best enumerates every camera and this
            // runs once per candidate -- against 14,198 resolutions in one raid, which took
            // unity::is_unity_object_alive from 36,547 calls to 140,875.
            //
            // And it BACKFIRED, which is the part worth keeping. That helper's memo TTL is
            // counted in CALLS (kNativeMemoTtlCalls), so quadrupling the call volume
            // quadruples how fast the memo expires. The log's own hit/miss report fell from
            // 98% to 55% in the very same session -- the exact symptom its report text warns
            // about. The guard destroyed the caching it was relying on.
            //
            // THE RESIDUAL, stated rather than hidden: those managed calls are still made on
            // every candidate, so a camera destroyed MID-ENUMERATION is not caught here. That
            // has never faulted -- this enumeration ran unguarded for the whole project -- and
            // the two guards below cover the case that was actually reported. If a per-candidate
            // check is ever wanted again it must be a POINTER COMPARISON against last frame's
            // camera, not a syscall.
            [&](Il2CppObject* cam) { return unity::name_equals(cam, "FPS Camera"); },
            [&](Il2CppObject* cam) {
                // Cannot rank without a reference point: a constant score, which leaves
                // the first match standing, exactly as before.
                if (!have_eye) return 0.f;
                unity::vector3 p{};
                return camera_world_position(cam, p) ? (p - eye).length() : 1e9f;
            },
            &named_matches);
        if (named_matches > 1) g_cam_named_multi.fetch_add(1, std::memory_order_relaxed);

        // Which bucket this call will land in, held in a local rather than re-derived from
        // named_matches when the camera is refused below. The bucket a call tentatively
        // used has to be undone if the call then produces nothing, and inferring which one
        // it was is exactly the kind of reasoning that breaks when a source is added.
        // The sentinel counts as "no named match": it arrives from the same managed
        // lookups as a real camera, and everything below this point reads it as one
        // otherwise. Same bucket arithmetic as before -- exactly one bump per call,
        // `none` when nothing usable came back. See camera_ptr_invalid.
        cam_source source = cam_source::named;
        if (camera_ptr_invalid(fps))
        {
            fps = unity::get_current_camera();
            source = camera_ptr_invalid(fps) ? cam_source::none : cam_source::current_fallback;
        }
        // REMOVED 2026-10-04, same reason as the predicate check above and for the same
        // reason it did not work: m_CachedPtr is the consequence of destruction, so testing it
        // and then using the object is a race, not a guard. The Camera.current fallback IS
        // the object most likely to die during teardown -- which is exactly why the correct
        // cover for it is resolve_esp_camera's is_in_raid gate, which is ordered by the game
        // thread BEFORE anything is destroyed, rather than a read of the wreckage.
        //
        // One call per resolution instead of nine is not the reason to remove it; the reason is
        // that it never worked and it cost 44.6% of self time. A guard that cannot fail is not
        // a guard, and one that costs half the profile will be removed by whoever inherits it.
        bump_cam_source(source);
        if (camera_ptr_invalid(fps)) return nullptr;

        if (have_eye)
        {
            unity::vector3 p{};
            const bool got = camera_world_position(fps, p);
            const float d = got ? (p - eye).length() : 1e9f;
            if (got)
            {
                const auto mm = static_cast<unsigned long long>(d * 1000.0f);
                g_cam_dist_mm_sum.fetch_add(mm, std::memory_order_relaxed);
                unsigned long long seen_max = g_cam_dist_mm_max.load(std::memory_order_relaxed);
                while (mm > seen_max
                    && !g_cam_dist_mm_max.compare_exchange_weak(seen_max, mm,
                        std::memory_order_relaxed))
                {
                }
            }
            if (!got || d > kCamTrustRadius)
            {
                g_cam_far.fetch_add(1, std::memory_order_relaxed);
                g_cam_far_refused.fetch_add(1, std::memory_order_relaxed);
                // Refuse rather than project every icon out of somebody else's eye. The
                // caller skips the frame, so this costs a visible pause for a moment --
                // a far smaller failure than drawing the whole overlay through a camera
                // that is following a bot around the map.
                //
                // retract + bump(none) is ONE retraction and ONE `none`. See
                // retract_cam_source for the invariant and for why the distinction was
                // observable as `[MISMATCH]` with sum EXCEEDING resolves.
                retract_cam_source(source);
                bump_cam_source(cam_source::none);
                return nullptr;
            }
        }
        return fps;
    }

    // When prefer_optic and optic camera is live (ADS — any optic, including 1x / no mag):
    // project ESP through scope camera. out_using_optic set when optic path is active.
    // out_fps_camera, when given, receives the FPS camera THIS CALL resolved.
    //
    // It exists because callers that go on to calibrate against the FPS camera
    // used to re-derive it with a second unity::get_named_camera("FPS Camera").
    // That is not a cheaper way to ask the same question -- it is the same
    // question asked twice, microseconds apart, and it is deterministic, so the
    // answer was the same pointer both times. The cost was real though:
    // find_camera_if() is backed by Unity's Camera.all, which ALLOCATES A FRESH
    // MANAGED ARRAY on every call, so the duplicate was a managed allocation plus
    // a GetName call per camera in the scene, per call, on a path the Aimbot runs
    // once per candidate per frame (97,994 calls in the 2026-10-01 15:54 capture)
    // and ESP runs far more often.
    //
    // Not a per-frame cache and deliberately not the manager route: it returns
    // the very same pointer the duplicate lookup did, with no lifetime question
    // and no change to WHICH camera is chosen. See the note on the by-name lookup
    // below for why that ordering is not mine to reorder.
    //
    // local_player is a TIEBREAK AND A TRUST CHECK, not a requirement: pass null and the
    // choice is made with no reference point and nothing is refused. See pick_esp_fps_camera.
    inline Il2CppObject* resolve_esp_camera(const bool prefer_optic, const float scope_zoom,
        float* out_zoom, bool* out_using_optic = nullptr,
        Il2CppObject** out_fps_camera = nullptr, Il2CppObject* local_player = nullptr) {
        // THE GATE, and it REPLACES the per-object liveness checks rather than joining
        // them. Both of the earlier attempts at this crash are recorded here, because
        // both were reasonable and both failed, and the reason they failed is the whole
        // point of this function.
        //
        // ATTEMPT 1, 2026-10-04 07:39 (build 6AC1D894): guard the objects. camera_is_enabled
        // and pick_esp_fps_camera gained unity::is_unity_object_alive(), which reads
        // UnityEngine.Object.m_CachedPtr -- the field every managed call dereferences at
        // this+0x10, and the exact field section 0.16's freed collider faulted on. Correct
        // diagnosis, and the crash survived it three times with a byte-identical stack.
        //
        // WHY IT SURVIVED: m_CachedPtr is the CONSEQUENCE of destruction, so a check on it
        // is a race by construction. The check passes, the game thread destroys the camera
        // in the next microsecond, the managed call throws. There is no ordering between
        // our read and the game's write, so no arrangement of the check removes the window
        // -- only shrinking it. The window was being hit every time because the resolver
        // makes hundreds of managed calls per frame.
        //
        // AND IT COST 44.6% OF ALL SELF TIME. Measured 2026-10-04 08:49 (build 6AC1E40D):
        // unity::is_unity_object_alive, 140,875 calls, 64.87 s of a 145.5 s profile, 460 us
        // per call -- against 1.46 s and 39.87 us in the 07:00 capture, before these checks
        // existed. Four new call sites on a 64-slot memo collided, and the memo's hit rate
        // fell from 88% to 57% (unity-memo in the log, which is an independent measurement
        // and not Tracy's). Every miss is a VirtualQuery, and VirtualQuery serialises on
        // the process address-space lock, so per-call cost inflated by an order of magnitude.
        //
        // WHAT IS DIFFERENT HERE: is_in_raid is cleared by hk_local_raid_ended, which runs
        // on the GAME thread as the game's own "the raid is over" call -- BEFORE it hands
        // back to the game and before anything is destroyed. So the ordering here is one
        // thread's program order, not a race between two. A render-thread read that still
        // sees `true` therefore means teardown has not begun, which makes this guard sound
        // where the m_CachedPtr guard was not.
        //
        // The limit, stated so nobody over-trusts it: this is not a lock. A frame already
        // past this line keeps resolving, and the flag cannot stop a call that has already
        // been issued. That is why the two managed calls below re-check rather than
        // trusting the one at the top -- two atomic loads against hundreds of managed calls
        // removed is the trade being made here, and it is worth it in both directions.
        //
        // The out-params are set on the way out so a caller cannot read a stale value from
        // a previous resolution: this function returns nullptr on this path, and every
        // caller already handles nullptr because pick_esp_fps_camera's `none` path has
        // always been able to produce it. No new contract is introduced.
        if (!game_state::is_in_raid.load(std::memory_order_acquire)) {
            if (out_fps_camera) *out_fps_camera = nullptr;
            if (out_zoom) *out_zoom = scope_zoom;
            if (out_using_optic) *out_using_optic = false;
            return nullptr;
        }
        // Camera.current is only guaranteed valid inside Unity's own render callbacks
        // (OnPreRender/OnPostRender/OnGUI). Read from our Present hook — a different
        // call context — it can return a stale reference that stops tracking the
        // live camera transform: every ESP icon then appears anchored to wherever
        // the camera was pointed when that stale value was captured, so turning the
        // camera looks like it drags the icons instead of them staying world-locked.
        // The by-name lookup is already trusted elsewhere in this file (see
        // setup_esp_optic_frame / world_to_screen_prefer_optic) as the reliable
        // reference for this exact game; prefer it, and only fall back to
        // Camera.current if that lookup ever comes back empty.
        // BOTH lookups now go through pick_esp_fps_camera, which keeps the by-name-first
        // ordering the comment above describes and adds two things the pair could not do:
        // among several same-named cameras it takes the one nearest the local player instead
        // of the first enumerated, and it refuses a camera nowhere near the local player
        // rather than projecting the whole overlay out of it. With no local_player passed
        // it is the previous behaviour exactly -- see the note on pick_esp_fps_camera.
        // Re-check, immediately before the work, not only at the gate above. Enumerating
        // cameras is not free and not managed-call-free, so the top-of-function read can
        // already be stale by the time the first managed call is issued. Two atomic loads
        // per resolution against the ~590 calls/second this path used to make.
        if (!game_state::is_in_raid.load(std::memory_order_acquire)) {
            if (out_fps_camera) *out_fps_camera = nullptr;
            if (out_zoom) *out_zoom = scope_zoom;
            if (out_using_optic) *out_using_optic = false;
            return nullptr;
        }
        Il2CppObject* fps = pick_esp_fps_camera(local_player);
        // THE GUARD, 2026-10-11: return invalid if cam is ~0ull. pick_esp_fps_camera
        // already refuses the sentinel for its own accounting, and this is the one that
        // keeps it out of the PUBLISHED result -- a -1 escaping here is what
        // EspModule::draw_overlay dereferenced in pid 23080 (`cmp qword ptr [rax], 0`
        // with rax = -1), after travelling through every caller that only tests null.
        // All three out-params are cleared so no caller re-reads a stale one.
        if (camera_ptr_invalid(fps)) {
            if (out_fps_camera) *out_fps_camera = nullptr;
            if (out_zoom) *out_zoom = scope_zoom;
            if (out_using_optic) *out_using_optic = false;
            return nullptr;
        }
        // Published before the optic swap below, so the caller gets the FPS
        // camera even on the frame where the optic camera is the one returned.
        if (out_fps_camera) *out_fps_camera = fps;
        if (out_zoom) *out_zoom = scope_zoom;
        if (out_using_optic) *out_using_optic = false;

        if (!prefer_optic)
            return fps;

        // And again before the optic branch, which is where the throw actually was:
        // camera_is_enabled() is the call that reached Component.get_gameObject() on a
        // destroyed camera in all four of the 2026-10-03/04 exfil crashes.
        if (!game_state::is_in_raid.load(std::memory_order_acquire))
            return fps;

        Il2CppObject* optic = try_get_optic_camera();
        // The sentinel first: `!optic` is blind to -1 and camera_is_enabled would now
        // return false for it, but the test belongs here where the pointer enters the
        // branch -- 2026-10-11, the 8472 stack had this branch under a Unity getter
        // returning -1. See camera_ptr_invalid.
        if (camera_ptr_invalid(optic) || optic == fps || !camera_is_enabled(optic))
            return fps;

        if (out_zoom) *out_zoom = 1.f;
        if (out_using_optic) *out_using_optic = true;
        return optic;
    }

    // Call once per ESP overlay frame after resolve_esp_camera.
    inline void setup_esp_optic_frame(const bool using_optic, Il2CppObject* cam,
        const float scope_zoom, const float user_radial_scale,
        Il2CppObject* local_player = nullptr) {
        game_state::esp_optic_proj = false;
        game_state::esp_optic_cam = nullptr;
        game_state::esp_optic_radial = 1.f;
        // Unconditional reset. Bump the epoch so a consumer reading radK can tell whether
        // this reset was the LAST write -- see the note on esp_optic_radial in game_state.h.
        ++game_state::esp_optic_radial_epoch;
        ++game_state::esp_optic_frame_calls;

        // Note the player BEFORE anything touches the pipeline — the 09-25 20:15
        // log showed the diagnostic's ensure_frame call running before the note
        // happened, so every attempt bailed on "local player missing" silently.
        if (local_player)
            optic_lens_note_local_player(local_player);

        // #7 diagnostic (TEMPORARY, on-change): which projection path the ESP is
        // actually using — pins down "skeleton not magnified at 4x" reports.
        // Only the optic-path state is logged: the eye pass alternates every
        // frame in dual mode and would spam the on-change dedupe.
        if (using_optic)
        {
            static std::string s_last_path;
            const bool pipeline_ok = optic_lens_ensure_frame();
            // NOTE: the ScopeMaskRenderer reachability probe used to be called here and
            // it crashed the game at raid entry on 2026-09-28. This block runs on the
            // PRESENT HOOK -- the render thread -- and Object.FindObjectOfType walks a
            // registry that is not thread-safe to touch from here while the main thread
            // is still building the raid scene. The full post-mortem, including the
            // thread ids and the fact that the readback plan is misfiled for the same
            // reason, is in the block comment above camera_is_enabled. Reachability and
            // the mask readback belong on the main thread -- OpticComponentUpdater's
            // LateUpdate is the intended anchor.
            std::string path = std::format("pipeline={} maskN={}",
                pipeline_ok ? "valid" : "fallback", game_state::esp_lens_mask_count);
            if (path != s_last_path)
            {
                s_last_path = path;
                std::string cam_name = "?";
                if (cam)
                {
                    if (Il2CppObject* go = unity::component_get_game_object(cam))
                        cam_name = unity::get_name(go);
                }
                logger::info(std::format("esp-path: usingOptic=true {} cam='{}'", path, cam_name));
            }
        }

        if (!using_optic || !cam)
            return;

        // Refresh the packet eagerly so the fitted mask is ready for this pass's
        // gating (esp_ads_mask_allows) before any drawing happens.
        optic_lens_ensure_frame();

        Il2CppObject* fps = unity::get_current_camera();
        // Prefer FPS camera named, not optic, for calibration reference.
        if (fps == cam)
        {
            if (Il2CppObject* named = unity::get_named_camera("FPS Camera"))
                fps = named;
        }

        float auto_k = calibrate_optic_radial_scale_impl(cam, fps, scope_zoom);
        const float user = user_radial_scale > 0.05f ? user_radial_scale : 1.f;
        float k = auto_k * user;
        // Record the provenance BEFORE clamping -- after clamping, `k` cannot
        // distinguish "calibration said 1.02" from "calibration said 4.7 and the
        // ceiling cut it".
        game_state::esp_zoom_auto_k = auto_k;
        game_state::esp_zoom_user_k = user;
        game_state::esp_zoom_scope_zoom = scope_zoom;
        game_state::esp_zoom_using_optic = using_optic;
        game_state::esp_zoom_dual = game_state::esp_dual_ads_active;
        game_state::esp_zoom_k_clamped = false;
        // Same 1/magnification quantity as the clamp in
        // calibrate_optic_radial_scale_impl, and the same bounds: 1.0 = 1x optic,
        // 1/16 = 16x scope. Was [0.15, 1.5], a magnification-shaped window, so this
        // second clamp silently re-inflated anything the (also wrong) calibration clamp
        // had let through. Two clamps with different bounds on one quantity, and the
        // banner reported only this one -- which is why `auto_k=0.200 final_k=0.200`
        // in the logs could not be reconciled with a [0.15,1.5] claim.
        if (k < 0.0625f) { k = 0.0625f; game_state::esp_zoom_k_clamped = true; }
        if (k > 1.f) { k = 1.f; game_state::esp_zoom_k_clamped = true; }
        game_state::esp_zoom_final_k = k;
        game_state::esp_zoom_packet_valid = optic_lens_published() != nullptr;

        game_state::esp_optic_proj = true;
        game_state::esp_optic_cam = cam;
        // Diagnostics that run mid-frame (the `optic-fov` trace inside
        // optic_lens_ensure_frame) read this instead, because both of its hot callers
        // run before esp_optic_cam is assigned. See game_state.h.
        game_state::esp_optic_cam_cached = cam;
        game_state::esp_optic_radial = k;
        // Record WHICH write landed last, and with what. If a later unconditional reset
        // (:2746) wins, radK reads 1.0 while final_k still shows k -- which is exactly the
        // 67-of-68 contradiction the 22:18 log shows. One epoch counter separates the two
        // explanations without guessing.
        game_state::esp_optic_radial_set = k;
        game_state::esp_optic_radial_epoch = game_state::esp_optic_radial_set_epoch =
            game_state::esp_optic_radial_epoch + 1;
    }

    // Prefer live optic cam when ADS (any mag). Self-contained — does not touch ESP frame state.
    // Used by aimbot target marker / bone pick so FOV circle matches the reticle view.
    /**
     * ONE camera resolution, reusable for every projection in the same pass.
     *
     * Why this exists. world_to_screen_prefer_optic() resolves the camera on every
     * call, and resolution is not cheap: pick_esp_fps_camera() goes through
     * unity::find_camera_if_best, which is backed by Unity's Camera.all -- a FRESH
     * MANAGED ARRAY ALLOCATION per call, plus a GetName call per camera in the scene
     * (see the note above resolve_esp_camera). The 2026-10-04 capture measured it:
     *
     *     eft_api::w2s_prefer_optic:resolve_camera
     *         154,544 calls   6.33 s self   41.0 us mean   15.71 ms max
     *     aimbot::project_to_screen   incl max 55.72 ms  <- identical, so the whole
     *                                                             stall is one resolve
     *     aimbot::candidate_pick      22,431 calls, incl 16.81 s
     *
     * 154,544 resolutions for 22,431 picks is 6.9x redundancy: the aimbot projected
     * ~7 candidate bones per pick and re-answered the identical camera question for
     * each one, microseconds apart, for a deterministic answer. And it is 92% of the
     * entire pick cost -- 15.52 s of candidate_pick's 16.81 s inclusive.
     *
     * The cam-choice diagnostic says the lookup is not even doing anything adaptive:
     * resolves=25696 named=25696 fallback=0 none=0 named_multi=0 far=0. Every call
     * succeeds by name, so there is no fallback branch being taken and no cache miss
     * to amortise -- the 41 us IS the successful name walk, paid 6.9 times per pick.
     *
     * So: resolve once per pass, project many. Deliberately NOT a cross-frame cache.
     * The camera legitimately changes between frames (ADS transitions, scope swaps),
     * and a stale camera is the exact bug the by-name lookup was chosen to fix -- see
     * the Camera.current note on resolve_esp_camera. One resolution per pick pass has
     * the same lifetime as the pass and cannot outlive it.
     */
    struct esp_camera_frame {
        Il2CppObject* cam = nullptr;
        /// The FPS camera, published even when `cam` is the optic one. Null when it
        /// is the same object, which is the case calibrate_optic_radial_scale_impl
        /// must not be handed.
        Il2CppObject* fps = nullptr;
        /// The scope_zoom AS PASSED IN. Not resolve_esp_camera's mutated out_zoom:
        /// the optic branch calibrates against this one, while the FPS branch projects
        /// with out_zoom. Those differ -- out_zoom becomes 1.f when the optic camera
        /// wins -- so collapsing them to one field would silently change the FPS path.
        float scope_zoom = 1.f;
        bool using_optic = false;

        /// Camera pixel dimensions, read ONCE per pass. Added 2026-10-05.
        ///
        /// WHY THEY ARE HERE. `world_to_screen_fps` used to call
        /// `unity::camera_pixel_width/_height` itself, PER POINT. Each of those
        /// goes through `unity::cached_method`, which on every call builds a
        /// `std::string` key (`std::to_string(clazz) + "." + name`, so at least
        /// two heap allocations) and takes a PROCESS-GLOBAL mutex
        /// (`unity::method_cache_mutex()`). Measured on `05.10_good.tracy`:
        /// `aimbot::project_to_screen` 147,706 calls, self mean 3.744 us but
        /// self MAX 39,695.575 us -- a 10,600x outlier -- with
        /// `il2utils::resolve_method` called 18,746,398 times in the same
        /// capture. A global lock on a per-point path is the shape that produces
        /// a multi-millisecond wait; that is the inference, and it is why the
        /// reads moved rather than being merely cached.
        ///
        /// `-1` would mean "not supplied"; the resolved value is passed through
        /// unchanged INCLUDING a failed read, which returns 0. So `>= 0` is the
        /// test and 0 is honoured, because `world_to_screen_fps` already has a
        /// `cam_w < 1.f` early return that yields the un-normalised point. A
        /// retry here would only repeat a lookup that already failed.
        float cam_w = -1.f;
        float cam_h = -1.f;

        /// `calibrate_optic_radial_scale_impl` for THIS frame, or -1 if it was not
        /// computed. See the note on the call site in world_to_screen_with_frame
        /// for why this was the expensive one.
        ///
        /// Every early return of that function is `1.f`, so -1 cannot collide with
        /// a real result. And if it ever could, the consumer recomputes -- which is
        /// exactly what it does today, so the failure mode of a bad sentinel here
        /// is the old cost, never a wrong number.
        float optic_radial_k = -1.f;

        [[nodiscard]] bool valid() const { return cam != nullptr; }
    };

    /// Resolve once. Prefer this at the top of a loop that will project more than
    /// one point, and pass the result to world_to_screen_with_frame.
    inline esp_camera_frame resolve_esp_camera_frame(const bool prefer_optic,
        const float scope_zoom, Il2CppObject* local_player = nullptr) {
        // A NEW name, not the old `w2s_prefer_optic:resolve_camera`. world_to_screen_prefer_optic
        // keeps that zone and still resolves per call for its own callers, so sharing a
        // name would merge "once per pass" with "once per point" and produce exactly the
        // averaged, meaningless figure the split was added to avoid.
        TA_ZONE_N("eft_api::resolve_esp_camera_frame");
        esp_camera_frame f;
        f.scope_zoom = scope_zoom;
        f.cam = resolve_esp_camera(prefer_optic, scope_zoom, nullptr, &f.using_optic,
            &f.fps, local_player);
        // Same normalisation world_to_screen_prefer_optic applies before calibrating:
        // handing the calibrator the optic camera as its own FPS reference is a
        // self-calibration, which is what the `fps == cam` guard there prevents.
        if (f.fps == f.cam) f.fps = nullptr;

        // Per-PASS, added 2026-10-05. Three reads that used to be per-POINT.
        //
        // ORDER IS LOAD-BEARING and is why this sits BELOW the `fps == cam`
        // normalisation above: `world_to_screen_with_frame` calibrated with the
        // NORMALISED f.fps, and handing the calibrator the optic camera as its
        // own FPS reference is the self-calibration the guard exists to prevent.
        // Computing it here but passing the un-normalised pointer would have been
        // a silent behaviour change on a path whose entire argument is that it is
        // not.
        if (f.cam)
        {
            f.cam_w = static_cast<float>(unity::camera_pixel_width(f.cam));
            f.cam_h = static_cast<float>(unity::camera_pixel_height(f.cam));
            if (f.using_optic)
                f.optic_radial_k = calibrate_optic_radial_scale_impl(f.cam, f.fps, f.scope_zoom);
        }
        return f;
    }

    /**
     * Project using an ALREADY-resolved camera. The arithmetic is deliberately
     * identical to world_to_screen_prefer_optic's, including the wide [0.01, 4]
     * clamp and the reason for it (see that function) -- this is the same code path
     * with the resolution lifted out, not a second opinion about magnification.
     */
    inline unity::vector3 world_to_screen_with_frame(const unity::vector3& world_point,
        const esp_camera_frame& f, const float user_radial_scale = 1.f) {
        if (!f.valid()) return {};

        if (f.using_optic) {
            // THE PER-PASS FIX, 2026-10-05. This used to be a bare
            // `calibrate_optic_radial_scale_impl(f.cam, f.fps, f.scope_zoom)` on
            // every projected point, inside the loop at AimbotModule.cpp:860.
            //
            // That call is a geometric SOLVE, not a lookup: two managed
            // resolutions (get_forward, get_right) via
            // `Il2CppObjectInstance::get_method`, a transform read, two
            // `camera_pixel_*` cached_method lookups, and two probe projections
            // -- per point. And every input is fixed for the pass: the camera,
            // the FPS reference, and the zoom.
            //
            // It was also UNZONED, which is why the cost landed where it did:
            // `aimbot::project_to_screen` has a self MAX of 39,695.575 us and no
            // zoned child to hold any of it. The per-point work now happens once
            // per pass, in resolve_esp_camera_frame, and is zoned there as
            // `eft_api::calibrate_optic_radial_scale`.
            //
            // `user_radial_scale` and the clamp stay PER CALL on purpose: they
            // are caller state, not camera state, and hoisting them would change
            // what a different caller sees.
            float k = f.optic_radial_k >= 0.f ? f.optic_radial_k
                : calibrate_optic_radial_scale_impl(f.cam, f.fps, f.scope_zoom);
            if (user_radial_scale > 0.05f) k *= user_radial_scale;
            if (k < 0.01f) k = 0.01f;
            if (k > 4.f) k = 4.f;
            return world_to_screen_optic(f.cam, world_point, k);
        }

        // Dual rear plane: never fake-zoom FPS. Otherwise legacy scope_zoom for irons.
        // f.scope_zoom, not out_zoom -- they are equal on this branch precisely
        // because resolve_esp_camera only rewrites out_zoom when using_optic.
        return world_to_screen_fps(f.cam, world_point,
            game_state::esp_dual_ads_active ? 1.f : f.scope_zoom, f.cam_w, f.cam_h);
    }

    inline unity::vector3 world_to_screen_prefer_optic(unity::vector3 world_point,
        const float scope_zoom,
        const float user_radial_scale = 1.f) {
        float z = scope_zoom;
        bool using_optic = false;
        // Collected from resolve_esp_camera's own lookup. This used to be a second
        // unity::get_named_camera("FPS Camera") here, which asked the identical
        // question a few microseconds later and got the identical pointer back --
        // at the price of another Camera.all managed-array allocation and a
        // GetName call per camera. resolve_esp_camera only returns the optic
        // camera when it differs from this one, so `fps` here is already
        // non-null and already different from `cam`; the two guards the old
        // duplicate needed cannot fire, which is why dropping them changes
        // nothing.
        Il2CppObject* fps = nullptr;
        // The split that aimbot::project_to_screen's own zone could not give.
        //
        // project_to_screen is 2.71 s over 129,895 calls (20.8 us mean) but has a
        // 54.12 ms max -- one call, 2,600x its own mean, and the same frame also
        // stalled candidate_pick (54.12 ms) and frame::AimbotModule::draw_overlay
        // (54.14 ms). One 54 ms frame in three different functions is the signature of
        // something global on that frame, not three coincidences, but the trace cannot
        // say what because there is nothing under this function at all.
        //
        // resolve_esp_camera is the candidate: the comment immediately below explains
        // that this used to ask for the camera a SECOND time via
        // unity::get_named_camera("FPS Camera"), at the cost of a Camera.all managed
        // array allocation and a GetName call PER CAMERA, PER CALL. Deduplicated once,
        // but 129,895 calls of it is still 129,895 chances for an allocation to be the
        // thing that occasionally takes 54 ms.
        //
        // So: camera resolution here, the arithmetic below, and the difference is
        // attributable rather than inferred from a comment describing a past bug.
        TA_ZONE_N("eft_api::w2s_prefer_optic:resolve_camera");
        Il2CppObject* cam = resolve_esp_camera(true, scope_zoom, &z, &using_optic, &fps);
        if (!cam)
            return {};

        if (using_optic)
        {
            if (fps == cam)
                fps = nullptr;
            float k = calibrate_optic_radial_scale_impl(cam, fps, scope_zoom);
            if (user_radial_scale > 0.05f)
                k *= user_radial_scale;
            // Deliberately a WIDE sanity band, not the calibrated range. `k` from
            // calibration is 1/magnification and is already clamped to [1/16, 1]; this
            // is AFTER the user's multiplier, so a user asking for a 2x stretch must
            // still be able to exceed 1. What must not happen is the old [0.15, 1.5]
            // floor, which sat on THIS path -- the one that actually runs when the
            // packet is invalid -- and re-inflated a correct calibration: a 12x scope's
            // true 0.083 became 0.15, an 80% size error, on exactly the frames where the
            // pipeline had already failed once.
            if (k < 0.01f) k = 0.01f;
            if (k > 4.f) k = 4.f;
            return world_to_screen_optic(cam, world_point, k);
        }

        // Dual rear plane: never fake-zoom FPS. Otherwise keep legacy scope_zoom for iron sights.
        return world_to_screen_fps(cam, world_point,
            game_state::esp_dual_ads_active ? 1.f : z);
    }

    // Aimbot marker: dual ADS = optic only inside mask, eyes without zoom outside.
    // Target pick near reticle still uses prefer_optic (center = scope).
    inline unity::vector3 world_to_screen_aim_marker(unity::vector3 world_point,
        const float scope_zoom,
        const float user_radial_scale = 1.f) {
        if (!game_state::esp_dual_ads_active)
            return world_to_screen_prefer_optic(world_point, scope_zoom, user_radial_scale);

        float z = 1.f;
        bool using_optic = false;
        Il2CppObject* optic = resolve_esp_camera(true, scope_zoom, &z, &using_optic);
        Il2CppObject* fps = resolve_esp_camera(false, 1.f, nullptr, nullptr);
        if (!fps)
            fps = unity::get_current_camera();

        if (using_optic && optic)
        {
            Il2CppObject* cal_fps = unity::get_named_camera("FPS Camera");
            if (!cal_fps || cal_fps == optic)
                cal_fps = fps;
            if (cal_fps == optic)
                cal_fps = nullptr;
            float k = calibrate_optic_radial_scale_impl(optic, cal_fps, scope_zoom);
            const float user = user_radial_scale > 0.05f
                ? user_radial_scale
                : (game_state::esp_optic_user_scale > 0.05f
                          ? game_state::esp_optic_user_scale
                          : 1.f);
            k *= user;
            // Same wide band as the single-pass path above, and for the same reason.
            // Currently unreachable (dual ADS is permanently off) but left consistent so
            // it cannot be reintroduced with the old magnification-shaped bounds.
            if (k < 0.01f) k = 0.01f;
            if (k > 4.f) k = 4.f;

            const unity::vector3 o = world_to_screen_optic(optic, world_point, k);
            // Inside the ADS mask → optic layer; outside → eye plane, no zoom.
            if (o.z > 0.01f && game_state::esp_ads_mask_contains(o.x, o.y))
                return o;
        }

        if (!fps)
            return {};
        return world_to_screen_fps(fps, world_point, 1.f);
    }

    // Fail-closed value here is 1 for every resolve below, because 1 is already
    // what this function returns for "no scope information" (the `return 1` that
    // used to follow the `if`). A resolve miss therefore reads as "not scoped"
    // and leaves the projection exactly as it was, rather than inventing a zoom.
    inline float get_scope_zoom(Il2CppObjectInstance& player) {
        // All five resolves below used to read `...get_method<...>(...)(obj)` --
        // the resolver's result invoked inline, never tested. A miss returns
        // nullptr, so that is a call to address 0x0: the same shape as the
        // 2026-10-04 21:24:50 crash (0xC0000005, operation 8 execute, faulting
        // address 0x0) in unity::camera_fov, which 6c8435ff fixed for the camera
        // resolvers.
        //
        // This function was missed by that sweep because four of its five calls
        // are split across lines by the formatter, and a line-based grep cannot
        // see a call whose `(` lands on the next line. tools/audit_call_through.py
        // walks the whole file text and finds 96 of these repo-wide, 9 here.
        const auto get_hands_fn =
            player.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_HandsController", 0);
        if (!get_hands_fn) return 1;
        Il2CppObject* hands_controller_object = get_hands_fn(player.get_instance());

        // The `->klass` test is new. The old condition was
        // `hands_controller_object && std::string(hands_controller_object->klass->name)`,
        // which reads through ->klass without testing it -- so a non-null wrapper
        // carrying a null klass was a null deref one line before the managed call
        // this function was crashing in. try_is_btr_by_weapon (:4604) and
        // try_read_weapon_ammo (:6585) already had this test; this did not.
        if (!hands_controller_object || !hands_controller_object->klass) return 1;
        if (std::string(hands_controller_object->klass->name) != "FirearmController")
            return 1;

        Il2CppObjectInstance firearm_controller(hands_controller_object);

        const auto is_aiming_fn =
            firearm_controller.get_method<bool (*)(Il2CppObject*)>("get_IsAiming", 0);
        if (!is_aiming_fn) return 1;
        if (!is_aiming_fn(hands_controller_object))
            return 1;

        const auto pwa_fn = player.get_method<Il2CppObject* (*)(Il2CppObject*)>(
            "get_ProceduralWeaponAnimation", 0);
        if (!pwa_fn) return 1;
        Il2CppObject* pwa_obj = pwa_fn(player.get_instance());
        if (!pwa_obj) return 1;
        Il2CppObjectInstance procedural_weapon_animation(pwa_obj);

        const auto aiming_mod_fn = procedural_weapon_animation.get_method<Il2CppObject* (*)(Il2CppObject*)>(
            "get_CurrentAimingMod", 0);
        if (!aiming_mod_fn) return 1;
        const auto mod_ptr = aiming_mod_fn(procedural_weapon_animation.get_instance());

        if (!mod_ptr) return 1;

        Il2CppObjectInstance sight_component(mod_ptr);
        const float zoom = sight_component.get_field<float>("ScopeZoomValue");

        const auto adjustable_fn = sight_component.get_method<Il2CppObject* (*)(Il2CppObject*)>(
            "get_AdjustableOpticData", 0);
        if (!adjustable_fn) return 1;
        Il2CppObject* adjustable_obj = adjustable_fn(sight_component.get_instance());
        // Also new. MinMaxFov is read through this object, so a null here was a
        // null deref even when the resolve itself succeeded.
        if (!adjustable_obj || !adjustable_obj->klass) return 1;
        Il2CppObjectInstance adjustable_data(adjustable_obj);

        // not a magnifying scope
        if (zoom == 0.0f) return 1;

        const auto minmax = adjustable_data.get_field<unity::vector3>("MinMaxFov");

        // calculate the actual zoom by dividing by max fov;
        return minmax.x / zoom;
    }

    inline bool is_visible(const unity::vector3& screen_point) {
        if (!(screen_point.z > 0.01f
                && screen_point.x > -100.0f && screen_point.y > -100.0f
                && screen_point.x < menu::get_width() + 100.0f
                && screen_point.y < menu::get_height() + 100.0f))
            return false;
        // Dual ADS: drop points that fall on the wrong side of the optic mask.
        return game_state::esp_ads_mask_allows(screen_point.x, screen_point.y);
    }

    // is_loot_container_display_name() was removed: no callers. It held a
    // hardcoded 27-name display list that nothing read, and a hardcoded list
    // that no live code consults is a list that silently rots against game
    // updates. Consumers use entry::loot_container from the item database.

    // ---- addressability probe accounting ----------------------------------------
    //
    // VirtualQuery is a kernel transition, and this function sits on the hideout's per-field
    // read path: the 1 Hz areas walk alone makes about 400 of them (three per field read, five
    // fields per area) and the productions walk roughly 200 more. That is ~600 kernel
    // transitions a second, spent re-proving addresses that were proved a second ago and whose
    // FieldInfo offsets were already memoised by hideout_cached_field.
    //
    // Whether that is actually expensive is not a thing to guess at, because the two possible
    // answers call for OPPOSITE responses:
    //   * If a probe costs its normal sub-microsecond, 600 of them is ~0.5 ms, they are
    //     ruled out as the cause, and the stall is somewhere else entirely.
    //   * If a probe really costs ~200 us - which is what dividing a measured 130 ms stall by
    //     ~600 probes implies - then something in this process is intercepting queries, and the
    //     fix is to stop making them (validate once per element, not once per field), because
    //     no amount of making an intercepted call cheaper helps.
    // So the number decides which of those it is, and these counters are what produce it.
    //
    // QueryPerformanceCounter, not GetTickCount64: the latter only advances every ~15.6 ms on
    // this machine (see the note by g_pkt_published), which is far too coarse to time a call
    // that may only cost a microsecond. QPC is ~25 ns - noise against either figure above.
    inline std::atomic<unsigned long long> g_probe_calls{0};
    inline std::atomic<unsigned long long> g_probe_ticks{0};

    // Milliseconds for a QPC tick count. The frequency is a constant, so it is read once.
    inline double probe_ticks_to_ms(const unsigned long long ticks) {
        static const double per_ms = [] {
            LARGE_INTEGER freq{};
            QueryPerformanceFrequency(&freq);
            return freq.QuadPart ? 1000.0 / static_cast<double>(freq.QuadPart) : 0.0;
        }();
        return static_cast<double>(ticks) * per_ms;
    }

    // Probes made and time spent in them SINCE the last drain, so a caller can scope the
    // measurement to one region (the areas walk, then the productions walk) instead of
    // reporting a process-wide total that any other thread could contaminate.
    struct probe_stats {
        unsigned long long calls = 0;
        double ms = 0.0;
    };

    inline probe_stats drain_probe_stats() {
        probe_stats out;
        out.calls = g_probe_calls.exchange(0, std::memory_order_relaxed);
        out.ms = probe_ticks_to_ms(g_probe_ticks.exchange(0, std::memory_order_relaxed));
        return out;
    }

    // Accumulates one addressability query into the counters above. Shared by every caller so the
    // hideout summary's "Np Xms" counts ALL of them, memoised or not.
    //
    // That "memoised or not" is the part worth reading. The first run of this measurement showed
    // the areas walk dropping to "0p 0.0ms" after the probe memo landed, which reads like the
    // probing had been removed. It had not: the memo calls VirtualQuery directly rather than
    // through is_readable_address, so those queries were simply happening outside the counters.
    // A diagnostic that under-reports the thing it exists to measure is worse than none.
    struct probe_scoped {
        LARGE_INTEGER begin{};
        LARGE_INTEGER end{};

        void start() { QueryPerformanceCounter(&begin); }
        void stop() {
            QueryPerformanceCounter(&end);
            g_probe_calls.fetch_add(1, std::memory_order_relaxed);
            g_probe_ticks.fetch_add(
                static_cast<unsigned long long>(end.QuadPart - begin.QuadPart),
                std::memory_order_relaxed);
        }
    };

    // The single VirtualQuery behind is_readable_address, optionally reporting the REGION that
    // answered it so a caller can memoise the region rather than re-asking.
    //
    // Kept as one function rather than a second implementation so the probe_scoped accounting
    // above stays on every kernel transition this mod makes. A memo that queries VirtualQuery
    // directly is exactly the under-counting the note on probe_scoped is about.
    inline bool probe_readable(const void* ptr, const size_t size,
        uintptr_t* out_region_base, uintptr_t* out_region_end) {
        if (out_region_base) *out_region_base = 0;
        if (out_region_end) *out_region_end = 0;
        // A null pointer is a null check, not a probe, so it is deliberately not counted: the
        // callers that pass null are being defensive, not paying for a kernel transition.
        if (!ptr) return false;

        probe_scoped probe;
        probe.start();

        MEMORY_BASIC_INFORMATION mbi{};
        bool readable = false;
        uintptr_t region_base = 0;
        uintptr_t region_end = 0;
        if (VirtualQuery(ptr, &mbi, sizeof(mbi)))
        {
            readable = mbi.State == MEM_COMMIT
                && !(mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD));
            if (readable)
            {
                region_base = reinterpret_cast<uintptr_t>(mbi.BaseAddress);
                region_end = region_base + mbi.RegionSize;
                const auto addr = reinterpret_cast<uintptr_t>(ptr);
                readable = addr + size <= region_end;
            }
        }

        probe.stop();
        // Only a verified region is reported. A caller storing this cannot cache a range that
        // was never proven.
        if (readable)
        {
            if (out_region_base) *out_region_base = region_base;
            if (out_region_end) *out_region_end = region_end;
        }
        return readable;
    }

    inline bool is_readable_address(const void* ptr, const size_t size = 8) {
        TA_ZONE_N("eft_api::is_readable_address");
        return probe_readable(ptr, size, nullptr, nullptr);
    }

    // ---------------------------------------------------------------- region memo
    //
    // WHO CALLS is_readable_address_cached NOW, and why that list is the whole point.
    // `rg 'is_readable_address\(' ` outside this function should return only its definition.
    // The two paths that matter:
    //
    //   - the string path (try_read_il2cpp_string), which was 64.3% of all probes
    //   - the item and container introspection helpers -- try_read_string_field,
    //     try_get_array_field, append_list_items, try_get_item_stack_count,
    //     try_get_item_stack_max, try_get_item_is_quest, try_get_template_string_id
    //     -- plus is_il2cpp_object_strict.
    //
    // The second group was measured at 2,493,902 uncached calls costing 91.6 s (7.64% of
    // wall clock) in the 20-minute capture, on one thread at ~34 probes per frame, running
    // only while a raid was live. Every one of them is a FIELD SLOT read -- an address at
    // `object + field->offset`, which is inside the object's own region -- so the hit rate
    // is near-total by construction rather than by luck. They are the last uncached callers
    // in this header; the transit guards in always_on.h and the hideout walk in
    // hideout_reflection.h still use the raw probe, and both are cold (21 calls/min and
    // 1 Hz respectively).
    //
    // WHY, IN NUMBERS. The 2026-10-01 25-minute capture (tracy_traces/bigger_raid.tracy) put
    // this probe at 253.7 s over 5,436,179 calls -- 16.83% of wall clock, mean 46.7 us per
    // VirtualQuery, max 5.55 ms, std/mean 3.41. A VirtualQuery is supposed to cost well under a
    // microsecond, and this process makes every one of them extraordinary expensive; the
    // codebase had already recorded ~207 us and ~186 us per call for its own probes. The fix
    // is not a cheaper check, it is fewer checks.
    //
    // try_read_il2cpp_string accounted for 3,493,674 of those 5,436,179 probes (64.3%) on its
    // own -- two per call, the header and then the chars buffer. So this memo starts there.
    //
    // STORE THE REGION, NOT THE READ'S BYTES. This is the whole ballgame and getting it wrong
    // was a real measured regression in optics_lens_pipeline.h: a page-keyed table that cached
    // each individual read's byte range re-probed on the very next read, moving the thrash
    // around without removing it. Caching the region makes every later read anywhere inside it
    // free, which is the point -- an Il2CppString's header and its chars are usually in the
    // SAME region, so the second probe of a single call often disappears too.
    //
    // DIRECT-MAPPED AND UNLOCKED, like the optics table: no probing, no eviction policy. The
    // multiplicative spread keeps regularly-strided regions from systematically sharing a slot
    // and evicting each other every call.
    //
    // SIZE: 256 WAS TOO SMALL, MEASURED NOT GUESSED. The first build of this memo used 256,
    // on the argument that the optics table holds its working set there. It does -- at 99.44%
    // over the same 25 minutes -- but the optics path reads ONE camera object, and this one
    // reads strings scattered across the IL2CPP heap. The counters settled it in one session:
    //
    //   probe-memo: hit/miss=124191/14247 (90%) fills=14247 evictions=14247 evict/miss=100.0%
    //
    // 100.0% in 13 of 15 windows, and fills == evictions exactly. That is the signature of a
    // working set larger than the table: every miss takes a slot from a different region, and
    // the region that just lost its slot misses again on its next probe. The optics table
    // cannot show this because it never gets there.
    //
    // 4096 slots is 64 KB of statics and a 16x increase. The justification for stopping there
    // rather than going larger is the measurement in the same report line: at 100% eviction
    // the miss rate IS the working-set touch rate, ~14,000 distinct pages per 30 s window. A
    // table big enough to hold that outright would be tens of megabytes, which is absurd for
    // a readability cache, so the honest target is "large enough that the hot set fits" and
    // the honest check is that evict/miss falls well below 100%. If it stays pinned at 100%
    // after this, the working set really is larger than 4096 and the answer is a different
    // structure -- a second-level filter or a per-callsite region hint -- not a bigger array.
    //
    // THE WRITE ORDER IS LOAD-BEARING. `size` is zeroed BEFORE `base` is written and only set
    // last, so `size != 0` implies `base` was already written. A concurrent reader therefore
    // either sees an empty slot and re-probes, or sees a complete pair. Writing base first
    // would let a reader pair a new base with an old size and accept a range that was never
    // verified -- a false "readable", which is the one failure this whole mechanism must not
    // have.
    //
    // LIFETIME. The IL2CPP GC heap is committed for the process and its objects are freed to
    // free lists rather than unmapped, so a cached region stays valid; reading reused space
    // yields garbage, not a fault. That argument holds for the heap and NOT for a stack or a
    // freed VirtualAlloc block, which is why clear_probe_region_memo() is called on every
    // transit boundary rather than left to run for the session. Same reasoning as the per-walk
    // memo in hideout_reflection.h, at coarser granularity.
    // The table size, declared before the hash because the hash masks against it.
    // This ordering is not cosmetic: kProbeRegionSlots was originally declared
    // below probe_region_slot_index(), which is a C2065 build failure, and the
    // same mistake was made once already with clear_probe_region_memo().
    inline constexpr size_t kProbeRegionSlots = 4096;

    // Fibonacci hashing on the HIGH bits. This replaced `(page * 2654435761) >> 20 & 255`,
    // and the replacement was necessary rather than cosmetic.
    //
    // THE OLD EXPRESSION WAS NOT A STALE SHIFT, IT WAS A DIFFERENT SHIFT, AND >> 20 WAS
    // DOING REAL WORK THAT >> 52 THROWS AWAY. Measured, on consecutive pages:
    //
    //     mult >> 20 & 255   (256 slots)   256/4096 distinct  -- fine at its own size
    //     mult >> 52 & 4095  (as I wrote)    1/4096 distinct  -- COLLAPSED
    //     fibonacci high bits (now)      3656/4096 distinct  -- 89.3%
    //
    // The product page * K advances by a CONSTANT K (~2^31.3) per page, so a run of
    // consecutive pages walks the product through a fixed arithmetic progression. Taking
    // the top 12 bits of that lands in one slot: (1087*K)>>52 and (1088*K)>>52 are both 0,
    // and the delta is 0. Taking bits 20..27 instead moves the index every page, which is
    // why the 256-slot version worked at all.
    //
    // So the resize to 4096 slots as first written would have been a REGRESSION that the
    // next capture would have shown as evict/miss back at 100% -- one slot, thrashing
    // against itself. The harness caught it before it shipped, and catching it is the only
    // reason this comment can be confident rather than hopeful.
    //
    // Fibonacci hashing is the textbook answer to exactly this: multiply by 2^64/phi and
    // take the HIGH bits, so sequential keys scatter. The ideal random hash into 4096 slots
    // occupies ~36.8% of them, and this reaches 89.3% on consecutive pages and 71.9% on
    // 64 KiB-strided ones, so it is comfortably past what randomness would give.
    inline size_t probe_region_slot_index(uintptr_t page) {
        // Fibonacci hashing: multiply by 2^64/phi, then keep the HIGH bits, because that is
        // what scatters sequential keys. The final mask is REQUIRED and not decorative.
        //
        // Writing this as `>> 32` with no mask is an out-of-BOUNDS WRITE, and it is what the
        // first version of this line did: >> 32 yields 32 bits, so the "index" ran to
        // 4,294,967,295 against a 4096-entry array. The harness caught it as a
        // 0xC0000005 with no output; in the DLL it would have been silent corruption of
        // whatever followed the table in .bss. >> 52 (12 bits for 4096 slots) was the value
        // measured in the diagnostic; the mask makes the correct width follow kProbeRegionSlots
        // instead of being remembered, and the static_assert keeps it a power of two.
        static_assert((kProbeRegionSlots & (kProbeRegionSlots - 1)) == 0,
            "the slot mask below is only valid for a power-of-two table");
        return static_cast<size_t>((page * 11400714819323198485ull) >> 32) & (kProbeRegionSlots - 1);
    }
    struct probe_region_slot {
        uintptr_t base = 0;
        size_t size = 0;
    };
    // 4096, not 256 -- see the sizing note above. A named constant rather than a bare 256 in
    // three places, because the number is now load-bearing and the next reader should be able
    // to change it in one edit and see every use follow.
    inline probe_region_slot (&probe_region_slots())[kProbeRegionSlots] {
        static probe_region_slot slots[kProbeRegionSlots];
        return slots;
    }
    // Hit/miss accounting for the memo below, so its effectiveness is a measurement rather
    // than an argument. The optics memo has always reported `range hit/miss=` in the log and
    // that is what settled its sizing; this is the same instrument, for the same reason.
    //
    // `evictions` is the one that matters and is NOT in the optics line. A direct-mapped
    // table's failure mode is not "the table is full", it is two hot regions sharing a slot
    // and evicting each other, so the miss count climbs while the slot count looks fine.
    // Counting an eviction separately is what distinguishes that from a genuinely large
    // working set. They call for opposite responses -- resize the table versus question why
    // the mod is touching so many distinct regions -- so they are counted apart.
    // Plain unsigned long long, NOT std::atomic, and that is deliberate -- the optics
    // counter set in the same file does use atomics.
    //
    // A std::atomic is neither copyable nor formattable, so drain_probe_memo_stats()
    // could not return one and std::format could not take one. Both of those were
    // compile errors on the first build of this change, which is a cheaper argument
    // for the design than the reason below.
    //
    // The counters are touched from more than one thread, so this is a race in the
    // strict sense: a lost increment costs one count in a diagnostic, never a wrong
    // answer and never a fault. relaxed atomics would be the pedantic form and would
    // buy nothing measurable here -- the quantity is a hit RATE, and one increment in
    // a million is not a finding. What the plain counters buy: they copy, they format,
    // and a torn 64-bit increment on x64 cannot produce a plausible wrong rate.
    struct probe_memo_counters {
        unsigned long long hits = 0;
        unsigned long long misses = 0;
        unsigned long long fills = 0;
        unsigned long long evictions = 0;
        unsigned long long clears = 0;
    };
    inline probe_memo_counters& probe_memo_stats() {
        static probe_memo_counters c{};
        return c;
    }
    // Drains the counters, so a caller can report a window rather than a process total.
    //
    // Read-then-zero rather than an atomic exchange, because the counters are plain integers
    // (see the note on the struct). A probe racing the drain is either counted in this window
    // or the next, which is the right behaviour for a per-window rate and costs nothing.
    inline probe_memo_counters drain_probe_memo_stats() {
        auto& c = probe_memo_stats();
        probe_memo_counters out;
        out.hits = c.hits;         c.hits = 0;
        out.misses = c.misses;     c.misses = 0;
        out.fills = c.fills;       c.fills = 0;
        out.evictions = c.evictions; c.evictions = 0;
        out.clears = c.clears;     c.clears = 0;
        return out;
    }

    // Declared here rather than next to probe_region_slots() because it counts a clear, and
    // probe_memo_stats() is what owns the counters. Order in a header is a real constraint:
    // calling it from clear_probe_region_memo() above the definition is a compile error, and
    // that is exactly what the first build of this change reported.
    inline void clear_probe_region_memo() {
        auto* p = probe_region_slots();
        // memset, not a loop over the elements. At 256 slots this was 4 KB and a loop
        // was fine; at 4096 it is 64 KB per transit boundary, and memset is what the
        // compiler emits for the loop anyway. This runs on the raid transition, which is
        // a frame the player already sees a hitch on, so a byte-fill is the right way to
        // spend it.
        std::memset(p, 0, sizeof(probe_region_slot) * kProbeRegionSlots);
        probe_memo_stats().clears += 1;
    }

    inline bool is_readable_address_cached(const void* ptr, const size_t size = 8) {
        if (!ptr) return false;
        auto& st = probe_memo_stats();
        const auto addr = reinterpret_cast<uintptr_t>(ptr);
        const uintptr_t page = addr >> 12;
        probe_region_slot& slot = probe_region_slots()[probe_region_slot_index(page)];
        // Same arithmetic the oracle uses (addr + size <= region_end), so a hit means exactly
        // what a syscall would have said -- only without the syscall.
        if (slot.size != 0 && addr >= slot.base && addr + size <= slot.base + slot.size) {
            st.hits += 1;
            return true;
        }

        st.misses += 1;
        uintptr_t base = 0;
        uintptr_t end = 0;
        if (!probe_readable(ptr, size, &base, &end)) return false;
        // A slot already holding a DIFFERENT region is being taken away from something. The
        // base comparison matters: refilling the same slot with the same region is not an
        // eviction, and counting it as one would report thrash where there is none.
        if (slot.size != 0 && slot.base != base)
            st.evictions += 1;
        slot.size = 0;              // invalidate first -- see the write-order note above
        slot.base = base;
        slot.size = static_cast<size_t>(end - base);
        st.fills += 1;
        return true;
    }

    // Reports the memo's hit rate on a throttle, and says which of the two failure modes is
    // happening. Called from the string path, which is where the volume is.
    //
    // The two lines answer different questions and both are needed:
    //   evictions climbing with a small miss count  -> the TABLE is too small, resize it
    //   misses climbing with evictions flat         -> the mod touches more distinct regions
    //                                                  than expected; resizing hides that
    //                                                  rather than fixing it
    inline void maybe_report_probe_memo() {
        static auto s_last = std::chrono::steady_clock::now();
        constexpr long long kProbeMemoDumpMs = 30000;
        const auto now = std::chrono::steady_clock::now();
        if (now - s_last < std::chrono::milliseconds(kProbeMemoDumpMs)) return;
        s_last = now;

        const probe_memo_counters c = drain_probe_memo_stats();
        const unsigned long long hits = c.hits;
        const unsigned long long misses = c.misses;
        const unsigned long long fills = c.fills;
        const unsigned long long evictions = c.evictions;
        const unsigned long long clears = c.clears;
        const auto total = hits + misses;
        // Nothing to say during a menu or a loading screen, and a line every 30 s of zeros
        // would be exactly the log flood this repo already has a problem with.
        if (total < 1000) return;

        const double rate = 100.0 * static_cast<double>(hits) / static_cast<double>(total);
        const double evict_pct = misses
            ? 100.0 * static_cast<double>(evictions) / static_cast<double>(misses) : 0.0;
        logger::debug(std::format(
            "probe-memo: hit/miss={}/{} ({:.2}%) fills={} evictions={} clears={} evict/miss={:.1f}%"
            " -- evict rising => 256 slots too small; miss rising with evict flat => working set grew",
            hits, misses, rate, fills, evictions, clears, evict_pct));
    }

    inline bool is_il2cpp_object_likely_valid(Il2CppObject* obj) {
        return obj && obj->klass && obj->klass->name;
    }

    inline bool is_il2cpp_object_strict(Il2CppObject* obj) {
        // Memoised, not the raw probe. This is three VirtualQuery calls per invocation, and
        // EspModule alone calls it from six sites on per-frame paths (item objects,
        // container roots, inventory roots) -- so a single frame of ESP work pays dozens of
        // syscalls that all ask the same question about the same few GC-heap regions.
        //
        // The 2026-10-01 9.5-minute capture left 289,255 is_readable_address calls costing
        // 42.3 s once the string path was memoised (146 us per call, 7.41% of wall clock),
        // and this function is the largest single contributor: the addresses are managed
        // heap objects, which is the same region set the string memo already caches, and
        // that memo was measured at a 100% hit rate with zero refills.
        //
        // Same soundness argument as the string path, and no new one: the IL2CPP GC heap is
        // committed for the process and its objects are freed to free lists rather than
        // unmapped, so a cached region stays valid and a reused address reads as readable,
        // which yields a stale-but-mapped object rather than a fault. clear_probe_region_memo()
        // on the transit boundary bounds it regardless.
        if (!is_readable_address_cached(obj, sizeof(Il2CppObject))) return false;
        if (!obj->klass || !is_readable_address_cached(obj->klass, sizeof(Il2CppClass))) return false;
        if (!obj->klass->name || !is_readable_address_cached(obj->klass->name, 1)) return false;
        return true;
    }

    inline std::string try_read_il2cpp_string(Il2CppString* str) {
        TA_ZONE_N("eft_api::try_read_il2cpp_string");
        // The memoised probe, not the syscall. This function was 64.3% of all 5,436,179
        // probes in the 2026-10-01 capture -- 3,493,674 of them, two per call. See
        // is_readable_address_cached for the numbers and for why the region is what gets
        // stored.
        if (!str || !is_readable_address_cached(str, sizeof(Il2CppString))) return {};
        if (str->length <= 0 || str->length > 512) return {};
        if (!is_readable_address_cached(str->chars,
                static_cast<size_t>(str->length) * sizeof(wchar_t)))
            return {};
        // The memo's report line. Throttled inside, and it stays quiet when there is nothing
        // to say -- the sizing of this table is currently an argument and this makes it a
        // measurement. See maybe_report_probe_memo for how to read the two numbers.
        maybe_report_probe_memo();
        return to_display_utf8(il2utils::conv_wstring(str));
    }

    inline std::string try_read_string_field(Il2CppObject* obj, const char* field_name) {
        if (!is_il2cpp_object_likely_valid(obj)) return {};

        const FieldInfo* field = il2utils::resolve_field(obj->klass, field_name);
        if (!field) return {};

        const UINT64 field_addr = reinterpret_cast<UINT64>(obj) + field->offset;
        if (!is_readable_address_cached(reinterpret_cast<void*>(field_addr), sizeof(Il2CppString*)))
            return {};

        Il2CppString* str = *reinterpret_cast<Il2CppString**>(field_addr);
        return try_read_il2cpp_string(str);
    }

    inline std::string get_info_nickname(Il2CppObject* profile) {
        Il2CppObject* info = try_get_field_object(profile, "Info");
        if (!info) return {};

        const std::string nickname = try_read_string_field(info, "Nickname");
        if (nickname.empty()) return {};

        return nickname;
    }

    inline std::wstring get_info_nickname_wide(Il2CppObject* profile) {
        Il2CppObject* info = try_get_field_object(profile, "Info");
        if (!info) return {};

        const std::string nickname = try_read_string_field(info, "Nickname");
        if (nickname.empty()) return {};

        return std::wstring(nickname.begin(), nickname.end());
    }

    inline bool weapon_short_name_is_btr(const std::string& short_name) {
        if (short_name.empty()) return false;
        return short_name.find("PKTM") != std::string::npos
            || short_name.find("PKP") != std::string::npos
            || short_name.find("KORD") != std::string::npos
            || short_name.find("kord") != std::string::npos;
    }

    inline bool try_is_btr_by_weapon(Il2CppObject* player_obj) {
        if (!player_obj || !player_obj->klass) return false;

        // A resolve miss here is a MISCLASSIFICATION, not missing data: false means
        // "not a BTR", and both callers treat that as a positive claim --
        // classify_player_label falls through to classify_wild_spawn_role, and the
        // Aimbot's skip_btr keeps the target in the running. So a miss silently
        // reclassifies a BTR as an ordinary wild spawn and starts aiming at it.
        // That is the worst of the three silent-guard failures recorded in
        // AGENTS_TODO 5.7ad: the other two lose data, this one produces a wrong answer.
        //
        // WARN, not ERROR, and once per distinct failure rather than per call -- this runs
        // on the Aimbot's per-player, per-frame scan, so an unconditional logger::warn here
        // would be a per-frame flood on exactly the build that is already broken.
        Il2CppObjectInstance player(player_obj);
        // Resolved into a local and tested, not invoked inline. See the note at
        // get_scope_zoom: a miss here is a call to 0x0, and both of these run on
        // the Aimbot's per-player, per-frame path.
        const auto get_hands_fn =
            player.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_HandsController", 0);
        if (!get_hands_fn)
        {
            static std::atomic<int> s_warned{ 0 };
            if (s_warned.fetch_add(1, std::memory_order_relaxed) < 3)
                logger::warn("try_is_btr_by_weapon: get_HandsController did not resolve --"
                             " returning \"not a BTR\", which callers read as a real answer"
                             " (a BTR would be misclassified and started on by the Aimbot)");
            return false;
        }
        Il2CppObject* hands_controller = get_hands_fn(player_obj);
        if (!hands_controller || !hands_controller->klass) return false;

        // strstr straight onto the const char*. This built a std::string per player
        // per frame purely to run two substring searches over it, and the Aimbot's
        // target scan asks this once per alive player per frame. std::string::find is
        // the same search; strstr just does not allocate first.
        const char* controller_name = hands_controller->klass->name;
        if (controller_name
            && (strstr(controller_name, "Stationary") || strstr(controller_name, "BTR")))
            return true;

        Il2CppObject* weapon_item = nullptr;
        if (const MethodInfo* get_item = il2utils::resolve_method(hands_controller->klass, "get_Item", 0))
        {
            using get_item_fn = Il2CppObject* (*)(Il2CppObject*);
            weapon_item = reinterpret_cast<get_item_fn>(get_item->methodPointer)(hands_controller);
        }
        if (!weapon_item)
            weapon_item = try_get_field_object(hands_controller, "Item");
        if (!weapon_item)
            return false;

        Il2CppObjectInstance weapon(weapon_item);
        const auto get_template_fn =
            weapon.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_Template", 0);
        if (!get_template_fn)
        {
            // Same reasoning as get_HandsController above: false is a claim here, not a
            // gap. Warned on the same capped counter so a broken build produces two lines,
            // not one per player per frame.
            static std::atomic<int> s_warned{ 0 };
            if (s_warned.fetch_add(1, std::memory_order_relaxed) < 3)
                logger::warn("try_is_btr_by_weapon: get_Template did not resolve --"
                             " returning \"not a BTR\", which callers read as a real answer");
            return false;
        }
        Il2CppObject* template_obj = get_template_fn(weapon_item);
        if (!template_obj) return false;

        // Cached per TEMPLATE, and that is the point of choosing this key rather than
        // the player. A weapon template is a shared, immutable asset object -- one per
        // weapon TYPE, referenced by every player holding that weapon -- so its
        // ShortName cannot change. Keying on the player instead would go stale the
        // moment that player swapped weapons, and a BTR that put a rifle down would
        // keep being excluded (or, worse, start being a target).
        //
        // thread_local for the same reason as the role store above: game thread and
        // render thread both reach this, and a torn read here is a wrong verdict.
        //
        // The empty read is returned WITHOUT caching. try_read_string_field gives {} on
        // a failed read, and weapon_short_name_is_btr("") is false -- so caching that
        // false would pin a transient read failure as a real "this is not a BTR".
        static thread_local std::unordered_map<const Il2CppObject*, bool> s_btr_by_template;
        if (const auto cached = s_btr_by_template.find(template_obj); cached != s_btr_by_template.end())
            return cached->second;

        const std::string short_name = try_read_string_field(template_obj, "ShortName");
        if (short_name.empty()) return false;

        const bool is_btr = weapon_short_name_is_btr(short_name);
        s_btr_by_template.emplace(template_obj, is_btr);
        return is_btr;
    }

    // is_btr_bot() was removed: no callers. Its only live behaviour,
    // try_is_btr_by_weapon() above, is still reachable on its own.
    inline bool is_lootable_container_class_fast(Il2CppObject* obj) {
        if (!is_il2cpp_object_likely_valid(obj)) return false;
        return strstr(obj->klass->name, "LootableContainer") != nullptr;
    }

    // is_lootable_container_object() was removed: a bare one-line passthrough to
    // is_lootable_container_class_fast(), which every caller already used.
    inline bool is_container_object_alive(Il2CppObject* obj) {
        if (!is_lootable_container_class_fast(obj)) return false;

        Il2CppObject* game_object = unity::component_get_game_object(obj);
        if (!game_object) return false;

        return unity::gameobject_get_transform(game_object) != nullptr;
    }

    inline bool is_nested_compound_item(Il2CppObject* item_obj) {
        if (!is_il2cpp_object_likely_valid(item_obj)) return false;
        const char* class_name = item_obj->klass->name;
        return strstr(class_name, "CompoundItem") != nullptr
            || strstr(class_name, "Inventory") != nullptr;
    }

    inline Il2CppObject* try_get_backing_field_object(Il2CppObject* obj, const char* backing_field,
        const char* plain_field = nullptr) {
        Il2CppObject* value = try_get_field_object(obj, backing_field);
        if (!value && plain_field) value = try_get_field_object(obj, plain_field);
        return value;
    }

    inline Il2CppArray* try_get_array_field(Il2CppObject* obj, const char* field_name) {
        if (!is_il2cpp_object_likely_valid(obj)) return nullptr;

        const FieldInfo* field = il2utils::resolve_field(obj->klass, field_name);
        if (!field) return nullptr;

        const UINT64 field_addr = reinterpret_cast<UINT64>(obj) + field->offset;
        if (!is_readable_address_cached(reinterpret_cast<void*>(field_addr), sizeof(Il2CppArray*)))
            return nullptr;

        Il2CppArray* arr = *reinterpret_cast<Il2CppArray**>(field_addr);
        if (!arr || !is_readable_address_cached(arr, sizeof(Il2CppArray))) return nullptr;
        if (arr->max_length > 256) return nullptr;
        return arr;
    }

    inline int try_get_list_count(Il2CppObject* list_obj) {
        if (!list_obj || !list_obj->klass) return 0;

        const FieldInfo* size_field = il2utils::resolve_field(list_obj->klass, "_size");
        if (size_field)
        {
            const int size = *reinterpret_cast<int*>(reinterpret_cast<UINT64>(list_obj) + size_field->offset);
            if (size >= 0) return size;
        }

        Il2CppObjectInstance list_inst(list_obj);
        const auto get_count = list_inst.get_method<int (*)(Il2CppObject*)>("get_Count", 0);
        if (!get_count) return 0;
        return get_count(list_obj);
    }

    inline void append_list_items(Il2CppObject* list_obj, std::vector<Il2CppObject*>& out,
        const int max_items = 128) {
        if (!list_obj) return;

        auto* list = reinterpret_cast<unity::list*>(list_obj);
        if (!list || !list->m_p_list_array) return;

        const int count = (std::min)(try_get_list_count(list_obj), max_items);
        const int limit = static_cast<int>(list->m_p_list_array->max_length);
        if (limit <= 0 || limit > 512) return;

        const size_t bytes_needed = static_cast<size_t>(limit) * sizeof(Il2CppObject*);
        if (!is_readable_address_cached(&list->m_p_list_array->data, bytes_needed)) return;

        for (int i = 0; i < count && i < limit; ++i)
        {
            Il2CppObject* item_obj = reinterpret_cast<Il2CppObject**>(&list->m_p_list_array->data)[i];
            if (is_il2cpp_object_likely_valid(item_obj)) out.push_back(item_obj);
        }
    }

    inline void collect_compound_items_recursive(Il2CppObject* compound_item, std::vector<Il2CppObject*>& out,
        const int depth = 0) {
        if (!is_il2cpp_object_likely_valid(compound_item) || depth > 3
            || static_cast<int>(out.size()) >= 256) return;

        if (Il2CppArray* grids = try_get_array_field(compound_item, "Grids"))
        {
            const size_t grid_count = (std::min)(grids->max_length, static_cast<size_t>(16));
            for (size_t i = 0; i < grid_count; ++i)
            {
                Il2CppObject* grid = reinterpret_cast<Il2CppObject**>(&grids->data)[i];
                if (!is_il2cpp_object_likely_valid(grid)) continue;

                Il2CppObject* collection = try_get_backing_field_object(
                    grid, "<ItemCollection>k__BackingField", "ItemCollection");
                if (!collection) continue;

                append_list_items(
                    try_get_field_object(collection, "ItemsList"), out, 128);
            }
        }

        if (Il2CppArray* slots = try_get_array_field(compound_item, "Slots"))
        {
            const size_t slot_count = (std::min)(slots->max_length, static_cast<size_t>(32));
            for (size_t i = 0; i < slot_count; ++i)
            {
                Il2CppObject* slot = reinterpret_cast<Il2CppObject**>(&slots->data)[i];
                if (!is_il2cpp_object_likely_valid(slot)) continue;

                Il2CppObject* contained = try_get_backing_field_object(
                    slot, "<ContainedItem>k__BackingField", "ContainedItem");
                if (!is_il2cpp_object_likely_valid(contained)) continue;

                out.push_back(contained);
                if (is_nested_compound_item(contained))
                    collect_compound_items_recursive(contained, out, depth + 1);
            }
        }
    }

    inline Il2CppObject* try_get_container_item_owner(Il2CppObject* container_obj) {
        return try_get_field_object(container_obj, "ItemOwner");
    }

    inline Il2CppObject* try_get_controller_root_item(Il2CppObject* item_owner) {
        if (!item_owner) return nullptr;

        Il2CppObject* root_item = try_get_field_object(item_owner, "<RootItem>k__BackingField");
        if (root_item) return root_item;

        Il2CppObjectInstance owner_inst(item_owner);
        const auto get_root = owner_inst.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_Root", 0);
        if (get_root) return get_root(item_owner);
        return nullptr;
    }

    inline bool is_lootable_container_valid(Il2CppObject* obj) {
        if (!obj || !obj->klass || !obj->klass->name) return false;

        Il2CppObject* item_owner = try_get_container_item_owner(obj);
        if (!item_owner) return false;
        return try_get_controller_root_item(item_owner) != nullptr;
    }

    // Did the game actually put a container HERE, or is this just an unused prefab in the scene?
    //
    // unity::find_objects_of_type returns every LootableContainer COMPONENT that exists in the
    // loaded scene, and every map ships far more container prefabs than one raid uses. The loot
    // spawner rolls a subset of them. The un-rolled ones have a live component -- position,
    // renderer, everything -- and nothing about the object distinguishes them from a real
    // container, which is why they drew as ghosts: boxes marked on the map where nothing is.
    //
    // Three things make a container real. All read from dump.cs 1.2.0.0,
    // EFT.Interactive.LootableContainer:
    //
    //     public ItemController ItemOwner;   // 0x178
    //     public bool IsAlwaysLootable;      // 0x1A8
    //     public bool IsAlwaysSpawn;         // 0x1A9
    //
    //   * ItemOwner      -- Init(ItemController) assigns it, and Init runs only for a container
    //                       the spawner rolled. The ordinary case.
    //   * IsAlwaysSpawn  -- [HideInInspector] prefab flag; never behind a roll.
    //   * IsAlwaysLootable -- [HideInInspector] prefab flag; always lootable.
    //
    // The two flags are ONE BYTE bools at 0x1A8/0x1A9, adjacent to each other and to
    // _isConverted at 0x1AA. They are read a byte at a time on purpose: a four-byte read would
    // swallow the neighbouring fields and report a flag as set because of the field after it.
    inline bool is_container_actually_placed(Il2CppObject* container_obj) {
        if (!is_il2cpp_object_likely_valid(container_obj)) return false;

        // ItemOwner is a reference field; any non-null value means Init() ran.
        if (try_get_container_item_owner(container_obj)) return true;

        for (const char* flag : { "IsAlwaysSpawn", "IsAlwaysLootable" })
        {
            const FieldInfo* field = cached_field(container_obj->klass, flag);
            if (!field) continue;
            if (*reinterpret_cast<const uint8_t*>(
                    reinterpret_cast<uintptr_t>(container_obj) + field->offset))
                return true;
        }
        return false;
    }

    // Item.CurrentAddress -- the ItemAddress saying where this item currently sits,
    // or null when nothing owns it.
    //
    // READ AS A FIELD, NEVER THROUGH get_Parent(). Item (dump.cs:456093, build
    // 120047965) declares `private ItemAddress <CurrentAddress>k__BackingField; // 0x50`
    // at 456116 and exposes it twice over -- `public ItemAddress CurrentAddress { get;
    // set; }` at 456167 and `public ItemAddress Parent { get; }` at 456168 -- and
    // Item.txt:4474-4587 shows the two are NOT the same call: get_CurrentAddress is a
    // bare `mov rax,[rcx+50h] / ret`, while get_Parent is that read followed by
    // `test rax,rax / je <throw>` whose throw builds
    // Exception("Trying to get parent of an item that doesn't have a parent: " + name)
    // (the String.Concat is at Item.txt:4569).
    // Detached is precisely the state a caller here wants to observe, so get_Parent
    // throws on every success -- and a managed throw crossing into a native frame
    // arrives as 0xE06D7363, which ended the process on the 2026-10-15 container
    // loot-teleport attempt.
    inline Il2CppObject* try_get_item_current_address(Il2CppObject* item_obj) {
        return try_get_backing_field_object(item_obj, "<CurrentAddress>k__BackingField",
            "CurrentAddress");
    }

    enum class detach_result { detached, already_detached, refused, faulted };

    namespace detail {
        // ItemAddress.Remove(Item item, bool simulate) -> OperationResult<ContainerRemoveResult>.
        //
        // THE ABI, read off the callees rather than assumed. The return is a 16-byte
        // struct delivered through a hidden pointer, so the native signature carries one
        // more parameter than the C# one:
        //
        //   GridItemAddress.txt:640-651  push rbx / mov rdx,[rdx+28h] (this->Grid,
        //                                dump.cs:468896 declares it at 0x28) /
        //                                mov rbx,rcx / movups xmm0,[rax] /
        //                                movups [rbx],xmm0
        //   SlotItemAddress.txt:526-533  mov rdx,[rdx+18h] (this->Slot, 0x18) /
        //                                movzx eax,r9b (simulate)
        //   OwnerItself.txt:355-360      mov rbp,rcx / mov r14,rdx / mov rdi,r8 /
        //                                movzx esi,r9b
        //
        // i.e. (retbuf=rcx, this=rdx, item=r8, simulate=r9, MethodInfo*). Note this is
        // NOT reachable through Il2CppObjectInstance::call_or_void, which always puts
        // `this` in the first parameter slot.
        //
        // THE RESULT BUFFER IS NEVER READ. Success is established by re-reading
        // CurrentAddress, because every one of the three branches nulls it on the
        // success path. Verified per branch, not assumed -- a strategy that was wrong
        // here would report `refused` for every successful detach and leave the item out
        // of its container and out of the world, which is the orphan this exists to
        // avoid:
        //
        //   grid   GridItemAddress.Remove -> Grid.Remove (Grid.txt:5382) ->
        //          Grid.RemoveInternal (5464), which at raw 5590-5593 does
        //          `lea rcx,[rdi+50h] / mov [rdi+50h],rbp` with rbp zeroed and rdi the
        //          item, then the tracked-store barrier at 0x18050C030.
        //   slot   Slot.RemoveItemInternal (Slot.txt:6731), `mov [rsi+50h],r14` at 6976.
        //   self   OwnerItself.Remove, `lea rcx,[rdi+50h] / mov qword ptr [rdi+50h],0`
        //          at OwnerItself.txt:373-374.
        //
        // A removal the game refuses -- Grid's ItemNotInGridError, say -- leaves it set.
        // Modelling OperationResult's explicit layout to learn that would be more code
        // and less trustworthy than one field read.
        //
        // DO NOT "RE-VERIFY" THIS BY GREPPING THE ISIL SECTIONS FOR CurrentAddress. It
        // finds nothing in Grid.txt and nothing in OwnerItself.txt, and the conclusion it
        // invites -- that only Slot nulls the field, so the check is unsound -- is wrong.
        // Grid's store IS in that file's ISIL section, at offset 235 / line 5852, rendered
        // as `Move [simulate @ r8 (System.Boolean)+50], 0`: the annotator lost track of
        // which value r8 held and named a bool you cannot index. OwnerItself's is not in
        // its ISIL section at all. AGENTS.md says the raw `Disassembly:` block is
        // authoritative and the `ISIL:` one annotates survivors by guess; this is that,
        // and it cost a full re-derivation to find out.
        //
        // SIZE, CHECKED TWO WAYS. dump.cs:208019 declares
        // `struct OperationResult<TValue> { readonly TValue Value; readonly Error
        // <Error>k__BackingField; }`, and both members are reference types for this
        // instantiation (ContainerRemoveResult is a class at dump.cs:471125, Error an
        // abstract class at 207784), so 8 + 8 = 16. GridItemAddress.Remove agrees:
        // `movups xmm0,[rax] / movups [rbx],xmm0` copies the inner result into the
        // caller's buffer as one 16-byte SSE move.
        //
        // "PROTECTED" IS NOT ENFORCED HERE, which is worth knowing before assuming a
        // refusal covers it. The five concrete address classes are all `private sealed`
        // empty markers -- Grid.ProtectedGridItemAddress (dump.cs:449664),
        // ReferenceGrid.ReferenceItemAddress (450291), Slot.ProtectedSlotItemAddress
        // (450956), StackSlot.ProtectedStackSlotItemAddress (451697),
        // ItemController.ProtectedOwnerItself (467561) -- declaring no members at all, so
        // they inherit their base's Remove verbatim, and that base body is a pure
        // forwarder: `mov rdx,[rdx+28h]` then `call Grid.Remove`, with no protection
        // check anywhere in it. Protection is the CALLER's business. A detach this code
        // performs on a protected slot can therefore succeed, and the caller must not
        // read `refused` as "the game protected this".
        //
        // No destructible object in this frame, so the caller may wrap it in __try.
        inline detach_result detach_item_call(Il2CppObject* address, Il2CppObject* item_obj) {
            using remove_fn = void (*)(void* retbuf, Il2CppObject* self, Il2CppObject* item,
                bool simulate, const MethodInfo* method);

            alignas(16) unsigned char result_buffer[16] = {};
            const MethodInfo* mi = nullptr;
            // Exact arity and no any-argc fallback: every ItemAddress subclass
            // (ProxyItemAddress, OwnerItself, SlotItemAddress, StackSlotItemAddress,
            // GridItemAddress, CollectiveItemAddress -- dump.cs 468760, 468796, 468844,
            // 468883, 468925, 472846) overrides Remove(Item, bool) and nothing else on
            // them is named Remove, so a miss is a real miss worth a log line rather than
            // a silent call to the wrong arity. Exactly two other classes in the whole
            // assembly declare a same-shaped Remove(Item, bool) -- Grid (450082) and
            // StackSlot (451790) -- and neither is an ItemAddress, so CurrentAddress can
            // never hold one. (All these dump.cs line numbers are build 120047965;
            // re-derive them from GameDump/<build>/dump.cs rather than trusting them.)
            const remove_fn fn = il2utils::get_method<remove_fn>(address->klass, "Remove", 2,
                /*log_fail=*/true, /*allow_any_argc=*/false, &mi);
            if (!fn || !mi) return detach_result::refused;

            fn(result_buffer, address, item_obj, /*simulate=*/false, mi);
            return try_get_item_current_address(item_obj)
                ? detach_result::refused
                : detach_result::detached;
        }

        // SEH-guarded, and the throw site is not hypothetical: GridItemAddress.Remove
        // opens `mov rdx,[rdx+28h] / test rdx,rdx / je <Newobj NullReferenceException>`
        // (GridItemAddress.txt, "Remove(Item, Boolean)" disassembly), so an address whose
        // Grid is already null throws, and an uncaught managed throw reaching a native
        // frame is 0xE06D7363 and a dead process. The __try frame holds nothing
        // destructible (AGENTS.md, MSVC traps); everything that does lives in the caller
        // above it.
        inline detach_result detach_item_guarded(Il2CppObject* address, Il2CppObject* item_obj) {
            __try {
                return detach_item_call(address, item_obj);
            } __except (EXCEPTION_EXECUTE_HANDLER) {
                return detach_result::faulted;
            }
        }
    }

    // Detach an item from whatever grid, slot or stack holds it, so that it can be
    // handed to GameWorld.ThrowItem.
    //
    // WHY DETACHING IS NOT OPTIONAL. ThrowItem wraps whatever it is given in a
    // `new ItemController(item, ...)` -- GameWorld.txt ISIL offsets 94 and 102 -- and
    // performs no ownership check of any kind. An item still sitting in a crate
    // therefore ends up with two owners: the crate's grid keeps it and the new ground
    // loot claims it too, so every button press would add another copy of the same
    // Item. That is the duplication the reverted 2026-10-15 attempt shipped.
    inline detach_result detach_item_from_owner(Il2CppObject* item_obj) {
        if (!is_il2cpp_object_likely_valid(item_obj)) return detach_result::refused;
        Il2CppObject* address = try_get_item_current_address(item_obj);
        if (!address) return detach_result::already_detached;
        if (!is_il2cpp_object_likely_valid(address)) return detach_result::refused;
        return detail::detach_item_guarded(address, item_obj);
    }

    inline Il2CppObject* try_get_item_template(Il2CppObject* item_obj) {
        if (!is_il2cpp_object_likely_valid(item_obj)) return nullptr;
        return try_get_backing_field_object(item_obj, "<Template>k__BackingField", "Template");
    }

    inline bool is_inventory_item_valid(Il2CppObject* item_obj) {
        return try_get_item_template(item_obj) != nullptr;
    }

    inline int try_get_item_stack_count(Il2CppObject* item_obj) {
        if (!is_il2cpp_object_likely_valid(item_obj)) return 1;

        // Hot path (per loot item per scan) — cached klass-keyed lookup (audit 09-25).
        const FieldInfo* field = cached_field(item_obj->klass, "StackObjectsCount");
        if (!field) return 1;

        const UINT64 field_addr = reinterpret_cast<UINT64>(item_obj) + field->offset;
        if (!is_readable_address_cached(reinterpret_cast<void*>(field_addr), sizeof(int))) return 1;

        return *reinterpret_cast<int*>(field_addr);
    }

    inline int try_get_item_stack_max(Il2CppObject* item_obj) {
        if (!is_il2cpp_object_likely_valid(item_obj)) return 1;

        Il2CppObject* template_obj = try_get_item_template(item_obj);
        if (!template_obj) return 1;

        const FieldInfo* field = cached_field(template_obj->klass, "StackMaxSize");
        if (!field) return 1;

        const UINT64 field_addr = reinterpret_cast<UINT64>(template_obj) + field->offset;
        if (!is_readable_address_cached(reinterpret_cast<void*>(field_addr), sizeof(int))) return 1;

        const int max_size = *reinterpret_cast<int*>(field_addr);
        return max_size > 0 ? max_size : 1;
    }

    // ---- Active-quest item filter ------------------------------------------
    // ItemTemplate.QuestItem is a static template flag — it cannot tell whether
    // the quest the item belongs to is still active, so completed/never-taken
    // quests leave "bogus" quest loot on the map (user report 2026-09-25). This
    // cache holds the item template ids targeted by the player's STARTED quests
    // (ConditionFindItem / ConditionHandoverItem / ConditionCompletableItem
    // `target` arrays); quest loot whose id is not in the set is stale.
    inline std::unordered_set<std::string> g_active_quest_item_ids;
    inline ULONGLONG g_active_quest_ids_ms = 0;
    inline bool g_active_quest_ids_refreshed = false;

    inline void refresh_active_quest_item_ids(Il2CppObject* main_player) {
        // Zoned 2026-10-12, at the CALLEE and not at a call site, because there are
        // two callers (WorldModule::gameworld_update and EspModule) and a zone at
        // either one would attribute a shared cost to whichever happened to be read.
        //
        // It self-throttles to 10 s two lines down, so this is expected to be a cheap
        // row. That is exactly why it is worth having: the early return is a REGIME,
        // and a cheap mean across a 10 s period hides the cost of the refresh itself.
        // If this ever reads as a large share, the throttle is not doing what it says.
        TA_ZONE_N("world::refresh_active_quest_item_ids");
        const ULONGLONG now = GetTickCount64();
        if (g_active_quest_ids_refreshed && now - g_active_quest_ids_ms < 10000) return;
        g_active_quest_ids_ms = now;
        g_active_quest_ids_refreshed = true;

        g_active_quest_item_ids.clear();
        if (!main_player || !main_player->klass) return;

        Il2CppObjectInstance player(main_player);
        const auto get_qc = player.get_method<Il2CppObject* (*)(Il2CppObject*)>(
            "get_QuestController", 0, false);
        if (!get_qc) return;
        Il2CppObject* quest_controller = get_qc(main_player);
        if (!quest_controller) return;
        Il2CppObjectInstance qc(quest_controller);
        const auto get_book = qc.get_method<Il2CppObject* (*)(Il2CppObject*)>(
            "get_Quests", 0, false);
        if (!get_book) return;
        Il2CppObject* quest_book = get_book(quest_controller);
        if (!quest_book) return;
        unity::list* quests_data =
            Il2CppObjectInstance(quest_book).get_field<unity::list*>("_questsData");
        if (!quests_data || !quests_data->m_p_list_array) return;

        for (size_t i = 0; i < quests_data->m_p_list_array->max_length; ++i)
        {
            Il2CppObject* quest_data =
                reinterpret_cast<Il2CppObject**>(&quests_data->m_p_list_array->data)[i];
            if (!quest_data) continue;
            Il2CppObjectInstance qd(quest_data);
            Il2CppObject* quest = qd.get_field<Il2CppObject*>("Quest");
            if (!quest) continue;
            Il2CppObjectInstance q(quest);

            // Only Started quests (2) still need their items. AvailableForFinish
            // (3) means every finish condition is already satisfied; Completed (4)
            // and Locked/AvailableForStart are irrelevant.
            Il2CppObject* status_data = q.get_field<Il2CppObject*>("_statusData");
            if (!status_data) continue;
            if (Il2CppObjectInstance(status_data).get_field<int>("Status") != 2) continue;

            const auto get_conditions = q.get_method<Il2CppObject* (*)(Il2CppObject*)>(
                "get_Conditions", 0, false);
            if (!get_conditions) continue;
            Il2CppObject* conditions_obj = get_conditions(quest);
            auto* cond_dict = reinterpret_cast<unity::dict<int, Il2CppObject*>*>(conditions_obj);
            if (!cond_dict || !cond_dict->m_p_entries) continue;

            for (int di = 0; di < cond_dict->m_i_count; ++di)
            {
                Il2CppObject* collection = cond_dict->get_value_by_index(di);
                if (!collection) continue;
                unity::list* clist =
                    Il2CppObjectInstance(collection).get_field<unity::list*>("List");
                if (!clist || !clist->m_p_list_array) continue;
                for (size_t ci = 0; ci < clist->m_p_list_array->max_length; ++ci)
                {
                    Il2CppObject* condition =
                        reinterpret_cast<Il2CppObject**>(&clist->m_p_list_array->data)[ci];
                    if (!condition || !condition->klass || !condition->klass->name) continue;
                    const char* cname = condition->klass->name;
                    if (!cname) continue;

                    // AV hardening (09-25 evening crash): `target` is only read
                    // when its declared element type is System.String — condition
                    // classes declare it as MongoID[]/other types too, and reading
                    // those as Il2CppString* is a wild-pointer deref.
                    const auto collect_string_targets =
                        [&](Il2CppObject* cond) {
                            const FieldInfo* tf =
                                il2utils::resolve_field(cond->klass, "target");
                            if (!tf || !tf->type
                                || tf->type->type != 0x15 /* GENERICINST */)
                                return;
                            const auto* gc = static_cast<const Il2CppGenericClass*>(
                                tf->type->data.generic_class);
                            if (!gc || !gc->context.class_inst
                                || gc->context.class_inst->type_argc != 1)
                                return;
                            const Il2CppType* elem =
                                gc->context.class_inst->type_argv[0];
                            if (!elem || elem->type != IL2CPP_TYPE_STRING)
                                return;
                            auto* tv = *reinterpret_cast<Il2CppArray**>(
                                reinterpret_cast<uintptr_t>(cond) + tf->offset);
                            if (!tv || tv->max_length == 0) return;
                            for (il2cpp_array_size_t ti = 0; ti < tv->max_length; ++ti)
                            {
                                Il2CppString* tid =
                                    reinterpret_cast<Il2CppString**>(&tv->data)[ti];
                                const std::string id = il2utils::conv_string(tid);
                                if (!id.empty()) g_active_quest_item_ids.insert(id);
                            }
                        };

                    // CounterCreator wraps its conditions in a nested
                    // ConditionCounterTemplate — recurse via get_Conditions()
                    // (returns a single ConditionCollection).
                    if (strstr(cname, "ConditionCounterCreator"))
                    {
                        const auto get_cc =
                            il2utils::get_method<Il2CppObject* (*)(Il2CppObject*)>(
                                condition->klass, "get_Conditions", 0, false);
                        if (!get_cc) continue;
                        Il2CppObject* coll = get_cc(condition);
                        if (!coll) continue;
                        unity::list* clist2 =
                            Il2CppObjectInstance(coll).get_field<unity::list*>("List");
                        if (!clist2 || !clist2->m_p_list_array) continue;
                        for (size_t ci2 = 0; ci2 < clist2->m_p_list_array->max_length; ++ci2)
                        {
                            Il2CppObject* inner =
                                reinterpret_cast<Il2CppObject**>(&clist2->m_p_list_array->data)[ci2];
                            if (!inner || !inner->klass) continue;
                            collect_string_targets(inner);
                        }
                        continue;
                    }

                    // All other Condition* classes: collect `target` when it is a
                    // validated string array (FindItem/HandoverItem/...).
                    collect_string_targets(condition);
                }
            }
        }
    }

    // True when the template id is targeted by a started quest. Fail-open while
    // the cache has never been refreshed (pre-first-frame ordering) so behavior
    // degrades to the old template-flag-only filter, never to hiding everything.
    inline bool is_active_quest_item_id(const std::string& template_id) {
        if (!g_active_quest_ids_refreshed) return true;
        return g_active_quest_item_ids.count(template_id) > 0;
    }

    inline bool try_get_item_is_quest(Il2CppObject* item_obj) {
        if (!is_il2cpp_object_likely_valid(item_obj)) return false;

        Il2CppObject* template_obj = try_get_item_template(item_obj);
        if (!template_obj) return false;

        // Hot path (per loot item per scan) — cached klass-keyed lookup (audit 09-25).
        const FieldInfo* field = cached_field(template_obj->klass, "QuestItem");
        if (!field) return false;

        const UINT64 field_addr = reinterpret_cast<UINT64>(template_obj) + field->offset;
        if (!is_readable_address_cached(reinterpret_cast<void*>(field_addr), sizeof(bool))) return false;

        return *reinterpret_cast<bool*>(field_addr);
    }

    inline bool try_get_item_is_provision(Il2CppObject* item_obj) {
        if (!item_obj || !item_obj->klass || !item_obj->klass->name) return false;
        const char* cls_name = item_obj->klass->name;
        return strstr(cls_name, "Food") != nullptr || strstr(cls_name, "Drink") != nullptr;
    }

    inline std::string try_get_template_string_id(Il2CppObject* template_obj) {
        if (!is_il2cpp_object_likely_valid(template_obj)) return {};

        static const MethodInfo* get_string_id = nullptr;
        static const Il2CppClass* get_string_id_class = nullptr;
        // Re-resolve only when the template klass differs from the cached one — other
        // ItemTemplate subclasses must not inherit a stale method pointer (audit 09-25).
        if ((!get_string_id || get_string_id_class != template_obj->klass) && template_obj->klass)
        {
            get_string_id = il2utils::resolve_method(template_obj->klass, "get_StringId", 0);
            get_string_id_class = template_obj->klass;
        }

        if (get_string_id && get_string_id->methodPointer)
        {
            Il2CppString* str = reinterpret_cast<Il2CppString* (*)(Il2CppObject*, const MethodInfo*)>(
                get_string_id->methodPointer)(template_obj, get_string_id);
            const std::string id = try_read_il2cpp_string(str);
            if (!id.empty()) return id;
        }

        const FieldInfo* id_field = cached_field(template_obj->klass, "<_id>k__BackingField");
        if (!id_field) return {};

        const UINT64 mongo_base = reinterpret_cast<UINT64>(template_obj) + id_field->offset;
        if (!is_readable_address_cached(reinterpret_cast<void*>(mongo_base), 0x18)) return {};

        // MongoID._stringID is at +0x10 inside the struct (dump 1.0.6.0.46010).
        Il2CppString* str = *reinterpret_cast<Il2CppString**>(mongo_base + 0x10);
        return try_read_il2cpp_string(str);
    }

    inline std::string try_get_item_template_id(Il2CppObject* item_obj) {
        return try_get_template_string_id(try_get_item_template(item_obj));
    }

    inline std::string mongo_id_string(const mongo_id& id) {
        if (!id.string_id) return {};
        return try_read_il2cpp_string(reinterpret_cast<Il2CppString*>(id.string_id));
    }

    // Walk Dictionary<MongoID, EWishlistGroup|byte> entries (hashCode >= 0 = occupied).
    template <typename TValue>
    inline void foreach_mongo_dict(Il2CppObject* dict_obj,
        const std::function<void(const std::string& tid, TValue group)>& fn) {
        if (!is_il2cpp_object_likely_valid(dict_obj) || !fn) return;
        auto* d = reinterpret_cast<unity::dict<mongo_id, TValue>*>(dict_obj);
        if (!d || !d->m_p_entries || d->m_p_entries->max_length == 0) return;

        const int n = static_cast<int>(d->m_p_entries->max_length);
        auto* entries = d->get_entry();
        if (!entries) return;

        for (int i = 0; i < n; ++i)
        {
            if (entries[i].m_i_hash_code < 0) continue;
            const std::string tid = mongo_id_string(entries[i].m_t_key);
            if (tid.empty()) continue;
            fn(tid, entries[i].m_t_value);
        }
    }

    // Profile.WishlistManager → wishlist / hideout template-id sets (dump 1.0.6.5.46221).
    inline void refresh_wishlist_filter_sets(Il2CppObject* profile, item_categories::filter_sets& out) {
        out = {};
        if (!is_il2cpp_object_likely_valid(profile) || !profile->klass) return;

        Il2CppObject* wm = nullptr;
        if (FieldInfo* f = il2utils::resolve_field(profile->klass, "WishlistManager"))
        {
            if (f->offset > 0)
                wm = *reinterpret_cast<Il2CppObject**>(reinterpret_cast<uintptr_t>(profile) + f->offset);
        }
        if (!is_il2cpp_object_likely_valid(wm) || !wm->klass) return;

        auto ingest_dict = [&](Il2CppObject* dict_obj) {
            size_t before = out.wishlist.size() + out.hideout.size();
            // The group is ALREADY in hand here: foreach_mongo_dict hands it to the callback
            // and the old body compared it to k_group_hideout and then dropped it. So this is
            // a routing change -- no new field read, no new managed call. add() writes the
            // per-group set and the matching union together, which is what keeps the
            // `before` comparison below meaningful.
            foreach_mongo_dict<int>(dict_obj, [&](const std::string& tid, int group) {
                out.add(tid, static_cast<item_categories::wishlist_group>(group));
            });
            if (out.wishlist.size() + out.hideout.size() == before)
            {
                // Retry at BYTE width. The entry stride happens to match for an int and a
                // byte value -- MongoID is 24 bytes and the entry pads to 40 either way --
                // so the int read gets the right keys even when the value is a byte. Left
                // alone on purpose: changing the width is a behaviour change and this is not
                // the task.
                foreach_mongo_dict<unsigned char>(dict_obj, [&](const std::string& tid, unsigned char group) {
                    out.add(tid, static_cast<item_categories::wishlist_group>(group));
                });
            }
        };

        for (const char* fname : {"_wishlistItems", "_userItems"})
        {
            if (FieldInfo* f = il2utils::resolve_field(wm->klass, fname))
            {
                if (f->offset > 0)
                {
                    Il2CppObject* dict = *reinterpret_cast<Il2CppObject**>(
                        reinterpret_cast<uintptr_t>(wm) + f->offset);
                    ingest_dict(dict);
                }
            }
        }

        if (out.wishlist.empty() && out.hideout.empty())
        {
            Il2CppObjectInstance wmi(wm);
            if (const auto get_wl = wmi.get_method<Il2CppObject* (*)(Il2CppObject*)>("GetWishlist", 0, false))
                ingest_dict(get_wl(wm));
        }

        if (const MethodInfo* get_qol = il2utils::resolve_method(wm->klass, "GetHideoutQolItems", 0))
        {
            if (get_qol->methodPointer)
            {
                Il2CppObject* hs = reinterpret_cast<Il2CppObject* (*)(Il2CppObject*, const MethodInfo*)>(
                    get_qol->methodPointer)(wm, get_qol);
                if (is_il2cpp_object_likely_valid(hs))
                {
                    auto* set = reinterpret_cast<unity::hashset<mongo_id>*>(hs);
                    if (set && set->m_p_slots)
                    {
                        auto* slots = set->get_slots();
                        const int last = set->m_i_last_index;
                        for (int i = 0; i < last; ++i)
                        {
                            if (slots[i].m_i_hash_code < 0) continue;
                            const std::string tid = mongo_id_string(slots[i].m_t_value);
                            if (!tid.empty())
                            // GetHideoutQolItems returns a plain HashSet<MongoID> with no group
                            // value attached, so Hideout here is not an inference -- it is what
                            // the method returns.
                            out.add(tid, item_categories::wishlist_group::hideout);
                        }
                    }
                }
            }
        }

        out.ready = !out.wishlist.empty() || !out.hideout.empty();
    }

    // Cash stacks (RUB/USD/EUR). Flea has no sell price for these; face value = stack count * unit.
    inline bool try_get_item_is_money(Il2CppObject* item_obj) {
        if (!is_il2cpp_object_likely_valid(item_obj) || !item_obj->klass || !item_obj->klass->name)
            return false;
        // EFT.InventoryLogic.Money
        if (strstr(item_obj->klass->name, "Money") != nullptr)
            return true;

        const std::string tid = try_get_item_template_id(item_obj);
        return tid == "5449016a4bdc2d6f028b456f"  // Roubles
            || tid == "5696686a4bdc2da3298b456a"  // Dollars
            || tid == "569668774bdc2da2298b4568"; // Euros
    }

    // Approximate face value in RUB per currency unit (for min-value filters / display).
    inline int money_unit_value_rub(const std::string& template_id) {
        if (template_id == "5449016a4bdc2d6f028b456f") return 1;   // RUB
        if (template_id == "5696686a4bdc2da3298b456a") return 150; // USD ~rub
        if (template_id == "569668774bdc2da2298b4568") return 160; // EUR ~rub
        return 1;
    }

    inline bool class_name_contains(Il2CppObject* obj, const char* needle) {
        if (!needle || !needle[0]) return false;
        if (!is_il2cpp_object_likely_valid(obj) || !obj->klass || !obj->klass->name) return false;
        return strstr(obj->klass->name, needle) != nullptr;
    }

    inline bool is_inventory_equipment_item(Il2CppObject* item_obj) {
        if (!is_il2cpp_object_likely_valid(item_obj) || !item_obj->klass || !item_obj->klass->name)
            return false;

        const char* item_class = item_obj->klass->name;
        return strcmp(item_class, "InventoryEquipment") == 0
            || strcmp(item_class, "Equipment") == 0;
    }

    inline bool is_player_inventory_item(Il2CppObject* item_obj) {
        if (!is_il2cpp_object_likely_valid(item_obj) || !item_obj->klass || !item_obj->klass->name)
            return false;

        if (is_inventory_equipment_item(item_obj))
            return true;

        const char* item_class = item_obj->klass->name;
        if (strcmp(item_class, "Inventory") == 0)
            return true;

        if (!strstr(item_class, "CompoundItem") && !strstr(item_class, "Inventory"))
            return false;

        Il2CppArray* slots = try_get_array_field(item_obj, "Slots");
        Il2CppArray* grids = try_get_array_field(item_obj, "Grids");
        if (!slots || !grids || slots->max_length < 4 || grids->max_length < 2)
            return false;

        return try_get_item_template_id(item_obj).empty();
    }

    inline Il2CppObject* try_find_player_by_profile_id(Il2CppObject* game_world, const std::string& profile_id) {
        if (!is_il2cpp_object_strict(game_world) || profile_id.empty()) return nullptr;

        Il2CppObject* dict_obj = try_get_field_object(game_world, "_allPlayersEverExistedByProfileId");
        if (!dict_obj) return nullptr;

        auto* players_dict = reinterpret_cast<unity::dict<Il2CppString*, Il2CppObject*>*>(dict_obj);
        if (!players_dict || players_dict->m_i_count <= 0) return nullptr;

        for (int i = 0; i < players_dict->m_i_count; ++i)
        {
            Il2CppString* key = players_dict->get_key_by_index(i);
            if (!key) continue;
            if (try_read_il2cpp_string(key) != profile_id) continue;

            Il2CppObject* player = players_dict->get_value_by_index(i);
            if (is_il2cpp_object_strict(player)) return player;
        }

        return nullptr;
    }

    inline bool try_player_is_ai(Il2CppObject* player_obj) {
        if (!is_il2cpp_object_strict(player_obj)) return false;

        Il2CppObjectInstance player(player_obj);
        const auto get_is_ai = player.get_method<bool (*)(Il2CppObject*)>("get_IsAI", 0);
        if (!get_is_ai) return false;

        return get_is_ai(player_obj);
    }

    inline void collect_ai_profile_ids(Il2CppObject* game_world, std::unordered_set<std::string>& out) {
        out.clear();
        if (!is_il2cpp_object_strict(game_world)) return;

        Il2CppObject* dict_obj = try_get_field_object(game_world, "_allPlayersEverExistedByProfileId");
        if (!dict_obj) return;

        auto* players_dict = reinterpret_cast<unity::dict<Il2CppString*, Il2CppObject*>*>(dict_obj);
        if (!players_dict || players_dict->m_i_count <= 0) return;

        out.reserve(static_cast<size_t>(players_dict->m_i_count) / 2 + 1);
        for (int i = 0; i < players_dict->m_i_count; ++i)
        {
            Il2CppString* key = players_dict->get_key_by_index(i);
            Il2CppObject* player = players_dict->get_value_by_index(i);
            if (!key || !try_player_is_ai(player)) continue;

            const std::string profile_id = try_read_il2cpp_string(key);
            if (!profile_id.empty())
                out.insert(profile_id);
        }
    }

    inline bool try_is_bot_corpse(
        Il2CppObject* corpse_obj,
        Il2CppObject* game_world,
        const std::unordered_set<std::string>* ai_profile_ids = nullptr) {
        if (!corpse_obj || !class_name_contains(corpse_obj, "Corpse")) return false;

        const std::string profile_id = try_read_string_field(corpse_obj, "PlayerProfileID");
        if (profile_id.empty() || !game_world) return false;

        if (ai_profile_ids)
            return ai_profile_ids->count(profile_id) > 0;

        Il2CppObject* player = try_find_player_by_profile_id(game_world, profile_id);
        return player && try_player_is_ai(player);
    }

    inline bool is_bot_corpse_loot(Il2CppObject* loot_obj, Il2CppObject* item_obj) {
        if (class_name_contains(loot_obj, "Corpse"))
            return true;

        return is_player_inventory_item(item_obj);
    }

    inline std::string try_get_item_display_name(Il2CppObject* item_obj) {
        Il2CppObject* template_obj = try_get_item_template(item_obj);
        if (template_obj)
        {
            std::string name = try_read_string_field(template_obj, "ShortName");
            if (!name.empty()) return name;

            name = try_read_string_field(template_obj, "Name");
            if (!name.empty()) return name;
        }

        if (is_il2cpp_object_likely_valid(item_obj))
            return item_obj->klass->name;

        return "Item";
    }

    // Localizer for game_items::prewarm, keyed by the 24-hex MongoID string the
    // live item db stores.
    //
    // FULL display name, not ShortName: ShortName is abbreviated and is heavily
    // occluded/ambiguous in several localisations (items sharing a prefix or
    // differing only by a truncated word), which makes it a poor label and a poor
    // search key. Note the SEPARATOR: the game's key is "<MongoID> Name" with a
    // SPACE, not "<id>/Name" with a slash. try_localize_with_suffix builds the slash
    // form, so passing a bare id never tries the key the game actually uses -- that
    // was why the db kept falling back to the raw `_name` slug.
    //
    // REJECTED ALTERNATIVE — do not "optimize" this into a direct call to
    // EFT.LocalizationExtensions.LocalizedShortName(EFT.MongoID):
    //   - Two 1-arg overloads exist (ISIL: Item @1035, MongoID @1182), so
    //     name+arg-count resolution is a coin flip.
    //   - MongoID is a VALUE TYPE, not a class. Proof from the db's own verified
    //     dictionary layout: entry stride 40 = {int32 hash; int32 next; MongoID
    //     key; ItemTemplate* value}, so the key occupies bytes 8..32 inline. A
    //     reference-type key would be 8 bytes and give stride 24. A 24-byte
    //     struct crosses the x64 call boundary by hidden-pointer, so calling it
    //     with a boxed heap object (il2cpp_object_new) would pass a bad pointer
    //     and corrupt the callee's copy.
    // The localization-key route needs no ABI assumptions at all.
    //
    // EXACT key first, then the generic chain as a fallback. Evidence for the exact
    // form: ItemTemplate.get_NameLocalizationKey() reads a 24-byte MongoID at
    // this+0xE0 and stringifies it (ISIL: movups xmm0,[rbx+0E0h] / movsd
    // xmm1,[rbx+0F0h] -> MongoID.ToString()); that MongoID is the one the live db
    // already holds. Same SPACE convention as the working secret-extract path
    // (`id + " ShortName"`).
    inline std::string try_get_item_name_for_template_id(const std::string& template_id) {
        if (template_id.empty()) return {};
        if (const std::string exact = try_localize_game_key(template_id + " Name"); !exact.empty())
            return exact;
        return try_localize_game_key(template_id);
    }

    inline std::string try_get_item_localized_short_name(
        Il2CppObject* item_obj,
        Il2CppString* (*localized_short_name)(Il2CppObject*)) {
        if (!item_obj || !localized_short_name) return {};

        Il2CppString* name_str = localized_short_name(item_obj);
        if (!name_str) return {};

        std::string name = to_display_utf8(il2utils::conv_wstring(name_str));
        return name.empty() ? "Item" : name;
    }

    inline std::string try_get_item_localized_name(
        Il2CppObject* item_obj,
        Il2CppString* (*localized_short_name)(Il2CppObject*),
        Il2CppString* (*localized_name)(Il2CppObject*)) {
        std::string name = try_get_item_localized_short_name(item_obj, localized_short_name);
        if (!name.empty() && name != "Item") return name;

        if (!item_obj || !localized_name) return name.empty() ? "Item" : name;

        Il2CppString* name_str = localized_name(item_obj);
        if (!name_str) return name.empty() ? "Item" : name;

        name = to_display_utf8(il2utils::conv_wstring(name_str));
        return name.empty() ? "Item" : name;
    }

    inline void collect_compound_grid_items_recursive(Il2CppObject* compound_item, std::vector<Il2CppObject*>& out,
        const int depth = 0) {
        if (!is_il2cpp_object_likely_valid(compound_item) || depth > 3
            || static_cast<int>(out.size()) >= 256) return;

        if (Il2CppArray* grids = try_get_array_field(compound_item, "Grids"))
        {
            const size_t grid_count = (std::min)(grids->max_length, static_cast<size_t>(16));
            for (size_t i = 0; i < grid_count; ++i)
            {
                Il2CppObject* grid = reinterpret_cast<Il2CppObject**>(&grids->data)[i];
                if (!is_il2cpp_object_likely_valid(grid)) continue;

                Il2CppObject* collection = try_get_backing_field_object(
                    grid, "<ItemCollection>k__BackingField", "ItemCollection");
                if (!collection) continue;

                const size_t before = out.size();
                append_list_items(
                    try_get_field_object(collection, "ItemsList"), out, 128);

                for (size_t j = before; j < out.size(); ++j)
                {
                    if (static_cast<int>(out.size()) >= 256) return;
                    if (is_nested_compound_item(out[j]))
                        collect_compound_grid_items_recursive(out[j], out, depth + 1);
                }
            }
        }
    }

    inline Il2CppObject* try_get_inventory_equipment(Il2CppObject* inventory_obj) {
        if (!is_il2cpp_object_likely_valid(inventory_obj) || !inventory_obj->klass || !inventory_obj->klass->name)
            return nullptr;
        if (strcmp(inventory_obj->klass->name, "Inventory") != 0)
            return nullptr;
        return try_get_field_object(inventory_obj, "Equipment");
    }

    inline Il2CppObject* try_get_slot_contained_item(Il2CppObject* slot_obj) {
        if (Il2CppObject* value = try_get_backing_field_object(
                slot_obj, "<ContainedItem>k__BackingField", "ContainedItem"))
            return value;

        if (!is_il2cpp_object_likely_valid(slot_obj) || !slot_obj->klass)
            return nullptr;

        Il2CppObjectInstance slot(slot_obj);
        const auto get_contained = slot.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_ContainedItem", 0);
        if (!get_contained) return nullptr;
        return get_contained(slot_obj);
    }

    inline void append_contained_loot_items(Il2CppObject* contained, std::vector<Il2CppObject*>& out,
        const bool grid_contents_only) {
        if (!is_il2cpp_object_likely_valid(contained)) return;

        if (grid_contents_only)
        {
            const size_t before = out.size();
            collect_compound_grid_items_recursive(contained, out);
            if (out.size() == before && is_inventory_item_valid(contained))
                out.push_back(contained);
        }
        else if (is_inventory_item_valid(contained))
        {
            out.push_back(contained);
        }
    }

    inline Il2CppObject* try_get_equipment_slot_by_enum(Il2CppObject* equipment_like, const int slot_index) {
        if (!is_il2cpp_object_likely_valid(equipment_like) || !equipment_like->klass)
            return nullptr;

        Il2CppObjectInstance eq(equipment_like);
        const auto get_slot = eq.get_method<Il2CppObject* (*)(Il2CppObject*, int)>("GetSlot", 1);
        if (!get_slot) return nullptr;
        return get_slot(equipment_like, slot_index);
    }

    inline Il2CppObject* try_get_equipment_slot_object(Il2CppObject* loot_item, const int slot_index) {
        if (is_inventory_equipment_item(loot_item))
            return try_get_equipment_slot_by_enum(loot_item, slot_index);

        if (Il2CppObject* equipment = try_get_inventory_equipment(loot_item))
            return try_get_equipment_slot_by_enum(equipment, slot_index);

        return nullptr;
    }

    inline void collect_corpse_slot_items(Il2CppObject* loot_item, const int slot_index,
        std::vector<Il2CppObject*>& out, const bool grid_contents_only) {
        Il2CppObject* slot = try_get_equipment_slot_object(loot_item, slot_index);
        if (!is_il2cpp_object_likely_valid(slot)) return;
        append_contained_loot_items(try_get_slot_contained_item(slot), out, grid_contents_only);
    }

    inline bool is_corpse_lootable_inventory(Il2CppObject* item_obj) {
        if (!is_il2cpp_object_likely_valid(item_obj)) return false;
        if (is_inventory_equipment_item(item_obj)) return true;
        if (try_get_inventory_equipment(item_obj)) return true;
        return is_player_inventory_item(item_obj);
    }

    inline Il2CppObject* try_resolve_corpse_inventory_root(Il2CppObject* loot_obj, Il2CppObject* item_obj) {
        if (is_corpse_lootable_inventory(item_obj))
            return item_obj;

        if (!is_il2cpp_object_likely_valid(loot_obj))
            return nullptr;

        Il2CppObject* item_owner = try_get_container_item_owner(loot_obj);
        Il2CppObject* root_item = try_get_controller_root_item(item_owner);
        if (is_corpse_lootable_inventory(root_item))
            return root_item;

        return nullptr;
    }

    inline bool foreach_corpse_lootable_item(
        Il2CppObject* inventory_root,
        const std::function<bool(Il2CppObject*)>& visitor) {
        if (!visitor || !is_corpse_lootable_inventory(inventory_root)) return false;

        std::vector<Il2CppObject*> items;
        items.reserve(32);

        // EquipmentSlot from dump: FirstPrimary=0, SecondPrimary=1, Holster=2, Scabbard=3,
        // Backpack=4, TacticalVest=6, Pockets=8
        collect_corpse_slot_items(inventory_root, 0, items, true);
        collect_corpse_slot_items(inventory_root, 1, items, true);
        collect_corpse_slot_items(inventory_root, 2, items, true);
        collect_corpse_slot_items(inventory_root, 3, items, true);
        collect_corpse_slot_items(inventory_root, 4, items, true);
        collect_corpse_slot_items(inventory_root, 6, items, true);
        collect_corpse_slot_items(inventory_root, 8, items, true);

        for (Il2CppObject* item_obj : items)
        {
            if (!is_il2cpp_object_likely_valid(item_obj)) continue;
            if (!visitor(item_obj)) return true;
        }
        return !items.empty();
    }

    inline bool foreach_container_item(
        Il2CppObject* root_item,
        const std::function<bool(Il2CppObject*)>& visitor) {
        if (!visitor || !is_il2cpp_object_likely_valid(root_item)) return false;

        std::vector<Il2CppObject*> items;
        items.reserve(32);
        collect_compound_items_recursive(root_item, items);

        for (Il2CppObject* item_obj : items)
        {
            if (item_obj == root_item) continue;
            if (!is_il2cpp_object_likely_valid(item_obj)) continue;
            if (!visitor(item_obj)) return true;
        }
        return !items.empty();
    }

    inline std::atomic<bool>& external_loot_inventory_open_cached() {
        static std::atomic<bool> value{false};
        return value;
    }

    inline std::atomic<bool>& ui_blocking_screen_open_cached() {
        static std::atomic<bool> value{false};
        return value;
    }

    inline bool query_external_loot_inventory_open() {
        static const Il2CppImage* assembly = il2utils::resolve_image("Assembly-CSharp.dll");
        if (!assembly) return false;

        static const Il2CppClass* screen_manager_class =
            il2utils::resolve_class(assembly, "EFT.UI.Screens", "EftScreenManager");
        if (!screen_manager_class) return false;

        static auto get_screen_manager = il2utils::get_method<Il2CppObject* (*)()>(
            screen_manager_class, "get_Instance", 0);
        if (!get_screen_manager) return false;

        Il2CppObject* screen_manager = get_screen_manager();
        if (!is_il2cpp_object_likely_valid(screen_manager)) return false;

        static auto get_current_controller = il2utils::get_method<Il2CppObject* (*)(Il2CppObject*)>(
            screen_manager_class, "get_CurrentScreenController", 0);
        if (!get_current_controller) return false;

        Il2CppObject* controller = get_current_controller(screen_manager);
        if (!is_il2cpp_object_likely_valid(controller)) return false;

        Il2CppObjectInstance controller_inst(controller);
        const auto get_closed = controller_inst.get_method<bool (*)(Il2CppObject*)>("get_Closed", 0);
        if (get_closed && get_closed(controller)) return false;

        const auto get_screen_type = controller_inst.get_method<int (*)(Il2CppObject*)>("get_ScreenType", 0);
        if (!get_screen_type) return false;

        const int screen_type = get_screen_type(controller);
        // Re-derived 2026-10-14 against every dump on disk (110146911, 115047242,
        // 115047426, 115047473, 115147510, 120047888, 120047965): all six say
        // Inventory = 16 and TransferItemsInRaid = 43. The 15/42 this line used
        // to carry matches no build available here -- 15 is
        // HideoutCircleOfCultists, which is why the minimap never hid over an
        // open inventory: the screen it was looking for is the cultist one.
        // The enum's entry count grew 58 -> 60 across those dumps and these two
        // values did not move, but that is an observation about six builds, not
        // a guarantee; tools/tests/test_screen_type_constants.py re-derives both
        // from a dump when one is present.
        constexpr int inventory_screen = 16;       // EEftScreenType.Inventory
        constexpr int transfer_items_in_raid = 43; // EEftScreenType.TransferItemsInRaid

        if (screen_type == transfer_items_in_raid)
            return true;

        if (screen_type != inventory_screen)
            return false;

        // Tab inventory: LootItem is null and ShowAsGridContent is false.
        // Corpse/container/bag loot: LootItem is set or grid loot view is active.
        Il2CppObject* loot_item = try_get_field_object(controller, "LootItem");
        if (is_il2cpp_object_likely_valid(loot_item))
            return true;

        const auto get_show_as_grid = controller_inst.get_method<bool (*)(Il2CppObject*)>(
            "get_ShowAsGridContent", 0);
        return get_show_as_grid && get_show_as_grid(controller);
    }

    inline void update_external_loot_inventory_open_cached() {
        external_loot_inventory_open_cached().store(
            query_external_loot_inventory_open(), std::memory_order_relaxed);
    }

    inline bool is_external_loot_inventory_open_cached() {
        return external_loot_inventory_open_cached().load(std::memory_order_relaxed);
    }

    // Broader than query_external_loot_inventory_open(): that one only fires for
    // looting (TransferItemsInRaid, or Inventory with LootItem/grid). This one
    // fires for ANY Inventory or TransferItemsInRaid screen, so opening your
    // own backpack also suppresses the minimap. Deliberately a separate
    // function rather than widening the existing one -- its name and every
    // call site say "external loot", and quietly making it mean "any screen"
    // would lie to the next reader.
    inline bool query_ui_blocking_screen_open() {
        static const Il2CppImage* assembly = il2utils::resolve_image("Assembly-CSharp.dll");
        if (!assembly) return false;

        static const Il2CppClass* screen_manager_class =
            il2utils::resolve_class(assembly, "EFT.UI.Screens", "EftScreenManager");
        if (!screen_manager_class) return false;

        static auto get_screen_manager = il2utils::get_method<Il2CppObject* (*)()>(
            screen_manager_class, "get_Instance", 0);
        if (!get_screen_manager) return false;

        Il2CppObject* screen_manager = get_screen_manager();
        if (!is_il2cpp_object_likely_valid(screen_manager)) return false;

        static auto get_current_controller = il2utils::get_method<Il2CppObject* (*)(Il2CppObject*)>(
            screen_manager_class, "get_CurrentScreenController", 0);
        if (!get_current_controller) return false;

        Il2CppObject* controller = get_current_controller(screen_manager);
        if (!is_il2cpp_object_likely_valid(controller)) return false;

        Il2CppObjectInstance controller_inst(controller);
        const auto get_screen_type = controller_inst.get_method<int (*)(Il2CppObject*)>("get_ScreenType", 0);
        if (!get_screen_type) return false;

        const int screen_type = get_screen_type(controller);
        // 16/43, re-derived 2026-10-14 from all six dumps on disk; the 15/42
        // this carried before matched HideoutCircleOfCultists and nothing else,
        // which is why an open inventory never suppressed the radar. See the
        // longer note on the same constants in query_external_loot_inventory_open.
        constexpr int inventory_screen = 16;       // EEftScreenType.Inventory
        constexpr int transfer_items_in_raid = 43; // EEftScreenType.TransferItemsInRaid

        return screen_type == inventory_screen || screen_type == transfer_items_in_raid;
    }

    inline void update_ui_blocking_screen_open_cached() {
        ui_blocking_screen_open_cached().store(
            query_ui_blocking_screen_open(), std::memory_order_relaxed);
    }

    inline bool is_ui_blocking_screen_open_cached() {
        return ui_blocking_screen_open_cached().load(std::memory_order_relaxed);
    }

    // is_bot_corpse_inventory_open() was removed: a one-line alias for
    // is_external_loot_inventory_open_cached() above, which has real callers.
    namespace detail {
        // Dump 46221: all of these take MethodInfo* tail (IL2CPP ABI).
        using localization_instance_fn_t = Il2CppObject* (*)(const MethodInfo*);
        using localization_value_fn_t = Il2CppString* (*)(Il2CppObject*, Il2CppString*, const MethodInfo*);
        using parse_localization_fn_t = Il2CppString* (*)(Il2CppString*, const MethodInfo*);

        inline const MethodInfo*& parse_localization_mi() {
            static const MethodInfo* mi = nullptr;
            return mi;
        }

        inline parse_localization_fn_t parse_localization_fn() {
            static parse_localization_fn_t fn = nullptr;
            static bool resolved = false;
            if (!resolved)
            {
                resolved = true;
                const Il2CppImage* assembly = il2utils::resolve_image("Assembly-CSharp.dll");
                if (!assembly) return fn;
                const Il2CppClass* cls = il2utils::resolve_class(assembly, "EFT", "LocalizationExtensions");
                if (!cls) return fn;
                const MethodInfo* mi = il2utils::resolve_method(cls, "ParseLocalization", 1);
                if (mi && mi->methodPointer)
                {
                    parse_localization_mi() = mi;
                    fn = reinterpret_cast<parse_localization_fn_t>(mi->methodPointer);
                }
            }
            return fn;
        }

        inline const MethodInfo*& localization_manager_instance_mi() {
            static const MethodInfo* mi = nullptr;
            return mi;
        }

        inline localization_instance_fn_t localization_manager_instance_fn() {
            static localization_instance_fn_t fn = nullptr;
            static bool resolved = false;
            if (!resolved)
            {
                resolved = true;
                const Il2CppImage* assembly = il2utils::resolve_image("Assembly-CSharp.dll");
                if (!assembly) return fn;
                const Il2CppClass* cls = il2utils::resolve_class(assembly, "EFT", "LocalizationManager");
                if (!cls) return fn;
                const MethodInfo* mi = il2utils::resolve_method(cls, "get_Instance", 0);
                if (mi && mi->methodPointer)
                {
                    localization_manager_instance_mi() = mi;
                    fn = reinterpret_cast<localization_instance_fn_t>(mi->methodPointer);
                }
            }
            return fn;
        }

        inline const MethodInfo*& localization_value_mi() {
            static const MethodInfo* mi = nullptr;
            return mi;
        }

        inline localization_value_fn_t localization_value_fn() {
            static localization_value_fn_t fn = nullptr;
            static bool resolved = false;
            if (!resolved)
            {
                resolved = true;
                const Il2CppImage* assembly = il2utils::resolve_image("Assembly-CSharp.dll");
                if (!assembly) return fn;
                const Il2CppClass* cls = il2utils::resolve_class(assembly, "EFT", "LocalizationManager");
                if (!cls) return fn;
                // Prefer 1-arg LocalizedValue(id); 2-arg overload also exists (id, locale).
                const MethodInfo* mi = il2utils::resolve_method(cls, "LocalizedValue", 1);
                if (mi && mi->methodPointer)
                {
                    localization_value_mi() = mi;
                    fn = reinterpret_cast<localization_value_fn_t>(mi->methodPointer);
                }
            }
            return fn;
        }

        // LocalizationManager.HasValidLocalization(string) -> bool. Instance method, hence the
        // (manager, key, methodInfo) shape and hence the trailing-MethodInfo convention
        // every other resolver here already uses.
        using localization_valid_fn_t = bool (*)(Il2CppObject*, Il2CppString*, const MethodInfo*);

        inline const MethodInfo*& has_valid_localization_mi() {
            static const MethodInfo* mi = nullptr;
            return mi;
        }

        inline localization_valid_fn_t& has_valid_localization_fn() {
            static localization_valid_fn_t fn = nullptr;
            return fn;
        }

        // ---- negative-cache guard -------------------------------------------
        //
        // The lookup caches below conflate two very different empty results:
        //
        //   (a) the localization subsystem was AVAILABLE and genuinely has no
        //       entry for this key  -> a real negative. Worth caching: it saves
        //       re-issuing the call for every key on every raid.
        //
        //   (b) a dependency was MISSING (LocalizationManager singleton not yet
        //       constructed, method pointer unresolved, Il2CppString alloc
        //       failed)  -> the lookup never actually ran. Caching this turns a
        //       transient outage into a PERMANENT miss: the next call hits the
        //       cache entry and can never retry, even once the manager is back.
        //
        // (b) is what produced the "56 still show the raw template slug" tail
        // being stuck: prewarm's own comment claims "snapshot() keeps retrying",
        // and the NAME handling does degrade gracefully, but the cache silently
        // defeated the retry. During a raid transition the manager is briefly
        // absent, so a whole pass could poison itself.
        //
        // Rule: only cache a negative that came from an actual lookup. Use
        // provisional_miss() for the "could not attempt" case -- it returns empty
        // and leaves the cache untouched, so the next caller retries.
        inline std::atomic<uint64_t>& localization_miss_count() {
            static std::atomic<uint64_t> n{0};
            return n;
        }

        inline std::string provisional_miss() {
            const uint64_t n = localization_miss_count().fetch_add(1, std::memory_order_relaxed) + 1;
            // A single unavailable window can miss thousands of keys (one full pass
            // over the template db is ~6000 lookups, each tried under two key forms),
            // so this is rate-limited: the FIRST one is the actionable signal, since
            // it means the subsystem was not up at that moment. After that, report
            // only occasionally so a raid transition cannot flood the log.
            if (n == 1)
                logger::warn("localization unavailable: lookup skipped and left UNCACHED so a "
                             "later call retries (further occurrences suppressed)");
            else if (n % 10000 == 0)
                logger::debug(std::format("localization unavailable: {} lookups skipped so far",
                                          n));
            return {};
        }

        // Guarded by localization_cache_mutex(), declared in the detail block
        // above role_label_cache().
        inline std::unordered_map<std::string, std::string>& localization_lookup_cache() {
            static std::unordered_map<std::string, std::string> cache;
            return cache;
        }

        inline std::unordered_map<std::string, std::string>& game_key_cache() {
            static std::unordered_map<std::string, std::string> cache;
            return cache;
        }

        inline std::unordered_map<uintptr_t, std::string>& exfil_display_cache() {
            static std::unordered_map<uintptr_t, std::string> cache;
            return cache;
        }

        inline std::unordered_map<uintptr_t, std::string>& transit_display_cache() {
            static std::unordered_map<uintptr_t, std::string> cache;
            return cache;
        }

        inline std::unordered_map<uintptr_t, std::string>& container_display_cache() {
            static std::unordered_map<uintptr_t, std::string> cache;
            return cache;
        }

        inline std::unordered_map<std::string, std::string>& template_display_cache() {
            static std::unordered_map<std::string, std::string> cache;
            return cache;
        }

        inline std::unordered_map<std::string, std::string>& location_display_cache() {
            static std::unordered_map<std::string, std::string> cache;
            return cache;
        }

        using localized_item_fn_t = Il2CppString* (*)(Il2CppObject*);

        inline localized_item_fn_t localized_short_name_fn() {
            static localized_item_fn_t fn = nullptr;
            static bool resolved = false;
            if (!resolved)
            {
                resolved = true;
                const Il2CppImage* assembly = il2utils::resolve_image("Assembly-CSharp.dll");
                if (!assembly) return fn;
                const Il2CppClass* cls = il2utils::resolve_class(assembly, "EFT", "LocalizationExtensions");
                if (!cls) return fn;
                // AMBIGUOUS BY NAME: LocalizationExtensions declares TWO 1-arg
                // overloads (ISIL dump):
                //   LocalizedShortName(EFT.InventoryLogic.Item)  line 1035
                //   LocalizedShortName(EFT.MongoID)              line 1182
                // resolve_method(name, arg_count) cannot tell them apart, so this
                // picks whichever comes first — a coin flip. Callers must not rely
                // on it for a specific overload: MongoID is a value type whose
                // by-value call crosses the x64 boundary by hidden pointer, so a
                // mismatched binding corrupts the callee's copy. Item-name lookups
                // go through the localization-key path instead
                // (try_get_item_name_for_template_id).
                fn = il2utils::get_method<localized_item_fn_t>(cls, "LocalizedShortName", 1);
            }
            return fn;
        }

        inline localized_item_fn_t localized_name_fn() {
            static localized_item_fn_t fn = nullptr;
            static bool resolved = false;
            if (!resolved)
            {
                resolved = true;
                const Il2CppImage* assembly = il2utils::resolve_image("Assembly-CSharp.dll");
                if (!assembly) return fn;
                const Il2CppClass* cls = il2utils::resolve_class(assembly, "EFT", "LocalizationExtensions");
                if (!cls) return fn;
                fn = il2utils::get_method<localized_item_fn_t>(cls, "LocalizedName", 1);
            }
            return fn;
        }
    } // namespace detail

    inline void clear_localization_cache() {
        // One lock for all eight: taking them individually would let a reader
        // slip in between two of the clears and repopulate a table that is meant
        // to be empty.
        std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
        detail::localization_lookup_cache().clear();
        detail::role_label_cache().clear();
        detail::game_key_cache().clear();
        detail::exfil_display_cache().clear();
        detail::transit_display_cache().clear();
        detail::container_display_cache().clear();
        detail::template_display_cache().clear();
        detail::location_display_cache().clear();
    }

    // ---- ONE-SHOT PER CONTAINER CLASS: what does each resolve step actually return? ----
    //
    // Three redesigns of try_get_lootable_container_display_name have now failed to fix the
    // label, and all three were static reasoning about `container_id` -- a value that has
    // never been observed at runtime. get_Id() can return empty, can return a per-TYPE
    // string rather than a per-INSTANCE one, or can return a value whose "<id> Name" key
    // is absent from the locale table, and the three cases need three different fixes.
    // The dump cannot tell them apart: it says what the getter does, not what it returns.
    //
    // So this reports it. Once per distinct klass->name, so a raid with three container
    // types produces three lines and then nothing, for the life of the process.
    //
    // The classification is decided by RE-DERIVING each step, not by trusting the cached
    // label: the whole bug class here has been a caller believing a downstream stage
    // answered when an upstream one returned empty.

    inline bool is_plausible_localized_result(const std::string& key, const std::string& result) {
        if (result.empty() || result == key) return false;
        if (!result.empty() && result.front() == '/') return false;
        if (result.find("/Name/") != std::string::npos) return false;
        if (result.find("/Description/") != std::string::npos) return false;

        // Failed Localized(id, "Name") / LocalizedValue often returns the constructed key:
        //   "Name/<id>", "Name/Name/<id>", "<id>/Name", "<id> Name"
        // Those differ from `key` so the naive equality check accepts them — reject here.
        if (result.rfind("Name/", 0) == 0) return false;
        if (result.rfind("Description/", 0) == 0) return false;
        if (result.size() >= 5 && result.compare(result.size() - 5, 5, "/Name") == 0) return false;
        if (result.size() >= 5 && result.compare(result.size() - 5, 5, " Name") == 0
            && result.find(' ') == result.size() - 5)
            return false;

        if (!key.empty())
        {
            if (result == "Name/" + key) return false;
            if (result == "Name/Name/" + key) return false;
            if (result == key + "/Name") return false;
            if (result == key + " Name") return false;
            if (result == "Description/" + key) return false;
            // Any "Name/.../<key>" miss path
            if (result.size() > key.size()
                && result.compare(result.size() - key.size(), key.size(), key) == 0
                && result.find("Name/") != std::string::npos)
                return false;
        }

        // Path-only ASCII keys with no letters outside Name/hex (still untranslated).
        {
            bool has_slash = result.find('/') != std::string::npos;
            bool only_keyish = true;
            for (unsigned char c : result)
            {
                if (std::isalnum(c) || c == '/' || c == '_' || c == '-' || c == ' ')
                    continue;
                only_keyish = false;
                break;
            }
            // Human text usually has spaces or non-ASCII; pure "Name/Name/hex" is not human.
            if (has_slash && only_keyish && result.find("Name") != std::string::npos)
                return false;
        }

        return true;
    }

    inline Il2CppObject* try_get_localization_manager() {
        static Il2CppObject* cached_manager = nullptr;

        if (cached_manager && is_il2cpp_object_strict(cached_manager))
            return cached_manager;

        detail::localization_instance_fn_t get_instance = detail::localization_manager_instance_fn();
        if (!get_instance) return nullptr;

        Il2CppObject* manager = get_instance(detail::localization_manager_instance_mi());
        if (!is_il2cpp_object_strict(manager)) return nullptr;

        cached_manager = manager;
        return cached_manager;
    }

    // ------------------------------------------------------------------ has_valid_localization
    //
    // "Does this key exist in the locale table?", asked of the GAME rather than answered by
    // a heuristic of ours.
    //
    // This exists because Localized(id, prefix) has NO fallback: on a miss it returns the
    // KEY ITSELF. A caller therefore cannot tell a resolved string from an unresolved one by
    // looking at what it got back -- "5dabf25c51e0590000000000 name" is a perfectly
    // plausible quest name and is also a raw locale key. LocalizationManager exposes exactly
    // the predicate needed for that, HasValidLocalization(string)
    // (dump.cs, RVA 0x2B0F720), and asking it beats inferring from the returned text.
    //
    // Returns FALSE when the manager or the method cannot be resolved. That conflates "no
    // such key" with "could not ask", which is deliberate and documented at the call site:
    // every caller here is a diagnostic whose job is to say a name looks wrong, and a probe
    // that cannot run should not read as a clean bill of health. Do NOT cache the result --
    // the locale table is not fully loaded at boot, so a key that misses early can resolve
    // minutes later, which is the same reason resolve_method memoises successes only.
    inline bool has_valid_localization(const std::string& key) {
        if (key.empty()) return false;

        static const MethodInfo*& mi = detail::has_valid_localization_mi();
        static auto& fn = detail::has_valid_localization_fn();
        static bool resolved = false;
        if (!resolved)
        {
            resolved = true;
            const Il2CppImage* assembly = il2utils::resolve_image("Assembly-CSharp.dll");
            if (!assembly) return false;
            const Il2CppClass* cls = il2utils::resolve_class(assembly, "EFT", "LocalizationManager");
            if (!cls) return false;
            const MethodInfo* found = il2utils::resolve_method(cls, "HasValidLocalization", 1);
            if (found && found->methodPointer)
            {
                mi = found;
                fn = reinterpret_cast<bool (*)(Il2CppObject*, Il2CppString*, const MethodInfo*)>(
                    found->methodPointer);
            }
        }
        if (!fn) return false;

        Il2CppObject* manager = try_get_localization_manager();
        if (!manager) return false;

        Il2CppString* key_str = il2cpp::il2cpp_string_new(key.c_str());
        if (!key_str) return false;

        return fn(manager, key_str, mi);
    }

    inline std::string try_localize_key(const std::string& key) {
        if (key.empty()) return {};

        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            const auto& cache = detail::localization_lookup_cache();
            if (const auto cached = cache.find(key); cached != cache.end())
                return cached->second;
        }

        detail::localization_value_fn_t localized_value = detail::localization_value_fn();
        Il2CppObject* manager = try_get_localization_manager();
        if (!manager || !localized_value)
        {
            // Dependency missing -- the lookup never ran. Do NOT cache; see
            // provisional_miss().
            return detail::provisional_miss();
        }

        Il2CppString* key_str = il2cpp::il2cpp_string_new(key.c_str());
        if (!key_str)
        {
            // Transient allocation failure, not a missing translation.
            return detail::provisional_miss();
        }

        const std::string localized = try_read_il2cpp_string(
            localized_value(manager, key_str, detail::localization_value_mi()));
        const std::string result = is_plausible_localized_result(key, localized) ? localized : std::string{};
        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            detail::localization_lookup_cache()[key] = result;
        }
        return result;
    }

    inline std::string try_localize_with_suffix(const std::string& id, const char* suffix) {
        if (id.empty() || !suffix || !suffix[0]) return {};
        return try_localize_key(id + "/" + suffix);
    }

    inline std::string try_parse_localization(const std::string& key) {
        if (key.empty()) return {};

        const std::string cache_key = "\x01parse:" + key;
        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            const auto& cache = detail::localization_lookup_cache();
            if (const auto cached = cache.find(cache_key); cached != cache.end())
                return cached->second;
        }

        if (!try_get_localization_manager())
        {
            // Dependency missing -- do NOT cache, so a later call retries.
            return detail::provisional_miss();
        }

        detail::parse_localization_fn_t parse_fn = detail::parse_localization_fn();
        if (!parse_fn)
        {
            // Method not resolved (yet) -- same reasoning.
            return detail::provisional_miss();
        }

        Il2CppString* key_str = il2cpp::il2cpp_string_new(key.c_str());
        if (!key_str)
        {
            return detail::provisional_miss();
        }

        // Dump: ParseLocalization(string original, const MethodInfo* method)
        const std::string localized = try_read_il2cpp_string(
            parse_fn(key_str, detail::parse_localization_mi()));
        const std::string result = is_plausible_localized_result(key, localized) ? localized : std::string{};
        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            detail::localization_lookup_cache()[cache_key] = result;
        }
        return result;
    }

    inline std::string try_localize_game_key(const std::string& key) {
        if (key.empty()) return {};

        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            const auto& cache = detail::game_key_cache();
            if (const auto cached = cache.find(key); cached != cache.end())
                return cached->second;
        }

        if (!try_get_localization_manager())
        {
            // Dependency missing -- do NOT cache, so a later call retries.
            return detail::provisional_miss();
        }

        const bool looks_like_desc_key = key.find("_DESC") != std::string::npos
            || key.find("_desc") != std::string::npos;

        auto store_and_return = [&](const std::string& value) -> std::string {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            detail::game_key_cache()[key] = value;
            return value;
        };

        if (!looks_like_desc_key)
        {
            if (const std::string by_name = try_localize_with_suffix(key, "Name");
                is_plausible_localized_result(key, by_name))
                return store_and_return(by_name);
        }

        if (const std::string direct = try_localize_key(key);
            is_plausible_localized_result(key, direct))
            return store_and_return(direct);

        if (looks_like_desc_key || key.find('_') != std::string::npos)
        {
            if (const std::string parsed = try_parse_localization(key);
                is_plausible_localized_result(key, parsed))
                return store_and_return(parsed);
        }

        if (!looks_like_desc_key)
        {
            if (const std::string by_description = try_localize_with_suffix(key, "Description");
                is_plausible_localized_result(key, by_description))
                return store_and_return(by_description);
        }

        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            detail::game_key_cache()[key] = {};
        }
        return {};
    }

    // The raid's location id, read off the GameWorld.
    //
    // ONE copy, consolidated 2026-10-14. It was written in five: EspModule,
    // RaidDashboardModule, TeleportModule, MarkedRoomsModule (same file) and
    // AiLimitModule. The .map showed exactly ONE of them surviving as a symbol
    // -- the other four were inlined by LTCG, so the duplication cost ZERO
    // BYTES, which is the point AGENTS.md makes about dup_scan findings being
    // maintainability debt by default. Nothing here got smaller; six copies of
    // a probe became one.
    //
    // It is the UNION of what the copies did, and the union is deliberately the
    // careful one:
    //   - both classes are tried (the passed-in one and the instance's own),
    //     because two copies did that and one-class is a strict subset;
    //   - a field whose offset is <= 0 is SKIPPED, as three copies did. Reading
    //     at offset 0 would land on the object header and reinterpret it as a
    //     pointer -- the copies that used Il2CppObjectInstance::get_field did
    //     not have this guard, and this helper does, which is why it is not
    //     written in terms of get_field;
    //   - the value pointer is null-checked before it is dereferenced.
    //
    // The three spellings are tried in order because the first is a
    // compiler-generated backing field that has been named differently across
    // builds.
    //
    // EspModule keeps a thin wrapper of its own because it alone also falls back
    // to the get_LocationId METHOD when no field resolves -- see there.
    inline std::string read_location_id(const Il2CppClass* game_world_class,
        Il2CppObjectInstance& game_world_instance) {
        Il2CppObject* instance = game_world_instance.get_instance();
        if (!instance || !instance->klass) return {};

        const Il2CppClass* classes[] = { game_world_class, instance->klass };
        for (const Il2CppClass* clazz : classes) {
            if (!clazz) continue;
            for (const char* name : { "<LocationId>k__BackingField", "LocationId", "_locationId" }) {
                const FieldInfo* field = il2utils::resolve_field(clazz, name);
                // offset <= 0 is not paranoia: a resolved field at 0 would put
                // the read on the object header.
                if (!field || field->offset <= 0) continue;
                auto* value = *reinterpret_cast<Il2CppString**>(
                    reinterpret_cast<uintptr_t>(instance) + field->offset);
                if (!value) continue;
                const std::string id = il2utils::conv_string(value);
                if (!id.empty()) return id;
            }
        }
        return {};
    }

    inline std::string normalize_location_id_for_display(const std::string& location_id) {
        if (location_id == "factory4_day" || location_id == "factory4_night")
            return "factory4";
        if (location_id == "Sandbox_high" || location_id == "Sandbox_start")
            return "Sandbox";
        return location_id;
    }

    inline Il2CppObject* try_get_raid_location_settings() {
        using location_get_fn_t = Il2CppObject* (*)(Il2CppObject*);

        static bool resolved = false;
        static const Il2CppImage* assembly = nullptr;
        static location_get_fn_t get_location_from_owner = nullptr;
        static location_get_fn_t get_location_from_local_game = nullptr;

        if (!resolved)
        {
            resolved = true;
            assembly = il2utils::resolve_image("Assembly-CSharp.dll");
            if (!assembly) return nullptr;

            if (const Il2CppClass* owner_class = il2utils::resolve_class(assembly, "EFT", "GamePlayerOwner"))
            {
                if (const MethodInfo* method = il2utils::resolve_method(owner_class, "get_Location", 0);
                    method && method->methodPointer)
                    get_location_from_owner = reinterpret_cast<location_get_fn_t>(method->methodPointer);
            }

            if (const Il2CppClass* local_game_class = il2utils::resolve_class(assembly, "EFT", "LocalGame"))
            {
                if (const MethodInfo* method = il2utils::resolve_method(local_game_class, "get_Location", 0);
                    method && method->methodPointer)
                    get_location_from_local_game = reinterpret_cast<location_get_fn_t>(method->methodPointer);
            }
        }

        const auto try_source = [&](location_get_fn_t getter, const char* class_name) -> Il2CppObject* {
            if (!assembly || !getter) return nullptr;

            Il2CppObject* type = il2utils::get_system_type(assembly, "EFT", class_name);
            if (!type) return nullptr;

            Il2CppObject* source = unity::find_object_of_type(type);
            if (!is_il2cpp_object_likely_valid(source)) return nullptr;

            Il2CppObject* location = getter(source);
            return is_il2cpp_object_likely_valid(location) ? location : nullptr;
        };

        if (Il2CppObject* location = try_source(get_location_from_owner, "GamePlayerOwner"))
            return location;

        return try_source(get_location_from_local_game, "LocalGame");
    }

    inline std::string try_read_location_localized_name(Il2CppObject* location) {
        if (!is_il2cpp_object_likely_valid(location)) return {};

        using location_localized_name_fn_t = Il2CppString* (*)(Il2CppObject*);

        static location_localized_name_fn_t get_localized_name = nullptr;
        static bool resolved = false;
        if (!resolved)
        {
            resolved = true;
            const Il2CppClass* location_class = location->klass;
            if (!location_class)
            {
                if (const Il2CppImage* assembly = il2utils::resolve_image("Assembly-CSharp.dll"))
                {
                    if (const Il2CppClass* location_settings_class = il2utils::resolve_class(assembly, "", "LocationSettings"))
                        location_class = il2utils::resolve_class_nested(location_settings_class, "Location");
                }
            }

            if (location_class)
            {
                if (const MethodInfo* method = il2utils::resolve_method(location_class, "get_LocalizedName", 0);
                    method && method->methodPointer)
                    get_localized_name = reinterpret_cast<location_localized_name_fn_t>(method->methodPointer);
            }
        }

        if (!get_localized_name) return {};
        return try_read_il2cpp_string(get_localized_name(location));
    }

    inline std::string try_get_location_display_name(const std::string& location_id) {
        if (location_id.empty()) return {};

        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            const auto& cache = detail::location_display_cache();
            if (const auto cached = cache.find(location_id); cached != cache.end())
                return cached->second;
        }

        const std::string normalized = normalize_location_id_for_display(location_id);
        std::string display_name;

        if (Il2CppObject* location = try_get_raid_location_settings())
        {
            if (const std::string runtime_name = try_read_location_localized_name(location);
                is_plausible_localized_result(location_id, runtime_name))
                display_name = runtime_name;

            if (display_name.empty())
            {
                const std::string name_key = try_read_string_field(location, "Name");
                if (!name_key.empty())
                {
                    if (const std::string localized = try_localize_game_key(name_key); !localized.empty())
                        display_name = localized;
                }
            }
        }

        const auto try_candidates = [&](const std::vector<std::string>& ids) {
            for (const std::string& id : ids)
            {
                if (id.empty()) continue;

                if (const std::string by_name = try_localize_with_suffix(id, "Name");
                    is_plausible_localized_result(id, by_name))
                {
                    display_name = by_name;
                    return true;
                }

                if (const std::string localized = try_localize_game_key(id); !localized.empty())
                {
                    display_name = localized;
                    return true;
                }
            }
            return false;
        };

        if (display_name.empty() && !try_candidates({normalized, location_id}))
            display_name = normalized.empty() ? location_id : normalized;

        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            detail::location_display_cache()[location_id] = display_name;
        }
        return display_name;
    }

    inline std::string try_get_exfil_display_name(Il2CppObject* exfil_point) {
        if (!is_il2cpp_object_likely_valid(exfil_point)) return {};

        const uintptr_t point_key = reinterpret_cast<uintptr_t>(exfil_point);
        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            const auto& cache = detail::exfil_display_cache();
            if (const auto cached = cache.find(point_key); cached != cache.end())
                return cached->second;
        }

        Il2CppObject* settings = try_get_field_object(exfil_point, "Settings");
        const std::string code_name = settings ? try_read_string_field(settings, "Name") : std::string{};
        if (code_name.empty()) return {};

        std::string display_name = code_name;
        if (const std::string localized = try_localize_game_key(code_name); !localized.empty())
            display_name = localized;

        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            detail::exfil_display_cache()[point_key] = display_name;
        }
        return display_name;
    }
    inline exfil_label_parts try_get_exfil_label_parts(Il2CppObject* exfil_point) {
        exfil_label_parts out;
        if (!is_il2cpp_object_likely_valid(exfil_point)) return out;

        out.name = try_get_exfil_display_name(exfil_point);

        // SECRET: decided by the CLASS, not by which array the point came from. The caller
        // knows the array (it iterates both), but the class is the property of the object and
        // survives being handed to a different caller.
        if (exfil_point->klass && exfil_point->klass->name
            && strstr(exfil_point->klass->name, "SecretExfiltrationPoint"))
        {
            out.secret = true;
            // SecretExfiltrationPoint has SecretTransferItemRequirement property returning
            // SecretExitTransferItemRequirement : ExfiltrationRequirement (has Id field at 0x18).
            if (Il2CppObject* req = try_get_field_object(exfil_point, "SecretTransferItemRequirement"))
                out.item = try_read_string_field(req, "Id");
        }

        // ONE walk of Requirements, answering both "needs an item" and "needs a scav".
        Il2CppObjectInstance inst(exfil_point);
        if (Il2CppArray* reqs = inst.get_field<Il2CppArray*>("Requirements"))
        {
            for (il2cpp_array_size_t k = 0; k < reqs->max_length; ++k)
            {
                Il2CppObject* req = reinterpret_cast<Il2CppObject**>(&reqs->data)[k];
                if (!req || !req->klass || !req->klass->name) continue;
                const char* cn = req->klass->name;

                // ScavCooperationRequirement is the game's own marker for "this exit needs a
                // scav partner" (Assembly-CSharp/EFT/Interactive/ScavCooperationRequirement.txt).
                // Matching on the class name rather than guessing from eligibility, because
                // "not eligible for a PMC" has several causes and only one of them is this.
                if (strstr(cn, "ScavCooperationRequirement"))
                {
                    out.scav_coop = true;
                    continue;
                }

                // A regular point's item, unchanged from try_get_exfil_item_requirement:
                // TransferItemRequirement and friends carry an `Id` that IS a locale key, so
                // unlike the secret case this one does need localizing.
                if (out.item.empty() && strstr(cn, "TransferItemRequirement"))
                {
                    Il2CppObjectInstance ri(req);
                    const std::string id = il2utils::conv_string(ri.get_field<Il2CppString*>("Id"));
                    const std::string localized = try_localize_game_key(id + " Name");
                    out.item = localized.empty() ? id : localized;
                }
            }
        }
        return out;
    }

    inline std::string try_get_transit_display_name(Il2CppObject* transit_point) {
        if (!is_il2cpp_object_likely_valid(transit_point)) return {};

        const uintptr_t point_key = reinterpret_cast<uintptr_t>(transit_point);
        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            const auto& cache = detail::transit_display_cache();
            if (const auto cached = cache.find(point_key); cached != cache.end())
                return cached->second;
        }

        Il2CppObject* parameters = try_get_field_object(transit_point, "parameters");
        if (!parameters) return {};

        const std::string description_key = try_read_string_field(parameters, "description");
        const std::string location_id = try_read_string_field(parameters, "location");
        const std::string name_key = try_read_string_field(parameters, "name");

        std::string display_name;
        for (const std::string& candidate : {description_key, location_id})
        {
            if (candidate.empty()) continue;

            if (const std::string localized = try_localize_game_key(candidate);
                is_plausible_localized_result(candidate, localized))
            {
                display_name = localized;
                break;
            }
        }

        if (display_name.empty())
        {
            if (!description_key.empty())
                display_name = description_key;
            else if (!location_id.empty())
                display_name = location_id;
            else
                display_name = name_key;
        }

        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            detail::transit_display_cache()[point_key] = display_name;
        }
        return display_name;
    }

    inline std::string try_read_localized_item_fn(Il2CppObject* item_obj, detail::localized_item_fn_t localized_fn) {
        if (!item_obj || !localized_fn) return {};

        Il2CppString* name_str = localized_fn(item_obj);
        if (!name_str) return {};

        const std::string name = to_display_utf8(il2utils::conv_wstring(name_str));
        if (name.empty() || name == "Item") return {};
        return name;
    }

    inline std::string try_get_item_localized_full_name(Il2CppObject* item_obj) {
        if (!is_il2cpp_object_strict(item_obj)) return {};

        std::string display_name = try_read_localized_item_fn(item_obj, detail::localized_name_fn());
        if (display_name.empty())
            display_name = try_read_localized_item_fn(item_obj, detail::localized_short_name_fn());
        if (display_name.empty())
            display_name = try_get_item_display_name(item_obj);

        return display_name;
    }

    inline std::string try_resolve_caliber_display_name(const std::string& caliber_key) {
        if (caliber_key.empty()) return {};

        using get_caliber_name_fn_t = Il2CppString* (*)(Il2CppString*);
        static get_caliber_name_fn_t fn = nullptr;
        static bool resolved = false;
        if (!resolved)
        {
            resolved = true;
            const Il2CppImage* assembly = il2utils::resolve_image("Assembly-CSharp.dll");
            if (assembly)
            {
                const Il2CppClass* cls = il2utils::resolve_class(assembly, "EFT.Builds", "MagBuildsStorage");
                if (cls)
                    fn = il2utils::get_method<get_caliber_name_fn_t>(cls, "GetCaliberName", 1);
            }
        }

        if (fn)
        {
            Il2CppString* result = fn(il2cpp::il2cpp_string_new(caliber_key.c_str()));
            if (result)
            {
                const std::string localized = to_display_utf8(il2utils::conv_wstring(result));
                if (!localized.empty())
                    return localized;
            }
        }

        if (const std::string localized = try_localize_game_key(caliber_key); !localized.empty())
            return localized;

        return caliber_key;
    }

    inline bool is_generic_bullet_ammo_type(const std::string& ammo_type_key) {
        if (ammo_type_key.empty()) return false;

        std::string lower = ammo_type_key;
        std::transform(lower.begin(), lower.end(), lower.begin(),
            [](const unsigned char c) { return static_cast<char>(std::tolower(c)); });
        return lower == "bullet";
    }

    inline std::string try_get_ammo_type_suffix(Il2CppObject* template_obj) {
        if (!template_obj) return {};

        const std::string ammo_type_key = try_read_string_field(template_obj, "ammoType");
        if (ammo_type_key.empty() || is_generic_bullet_ammo_type(ammo_type_key)) return {};

        if (const std::string localized = try_localize_game_key(ammo_type_key); !localized.empty())
            return localized;

        return ammo_type_key;
    }

    inline std::string try_get_ammo_display_name(Il2CppObject* ammo_or_template) {
        if (!is_il2cpp_object_strict(ammo_or_template)) return {};

        Il2CppObject* template_obj = nullptr;
        Il2CppObject* item_obj = ammo_or_template;
        if (ammo_or_template->klass && ammo_or_template->klass->name
            && strstr(ammo_or_template->klass->name, "Template") != nullptr)
        {
            template_obj = ammo_or_template;
            item_obj = nullptr;
        }
        else
        {
            template_obj = try_get_item_template(ammo_or_template);
        }

        std::string caliber_key;
        if (template_obj)
            caliber_key = try_read_string_field(template_obj, "Caliber");

        if (caliber_key.empty() && item_obj && item_obj->klass && item_obj->klass->name
            && strcmp(item_obj->klass->name, "Ammo") == 0)
        {
            Il2CppObjectInstance ammo_inst(item_obj);
            if (const auto get_caliber = ammo_inst.get_method<Il2CppString* (*)(Il2CppObject*)>("get_Caliber", 0))
            {
                if (Il2CppString* cal_str = get_caliber(item_obj))
                    caliber_key = to_display_utf8(il2utils::conv_wstring(cal_str));
            }
        }

        const std::string caliber_display = try_resolve_caliber_display_name(caliber_key);

        std::string short_display;
        if (item_obj)
            short_display = try_read_localized_item_fn(item_obj, detail::localized_short_name_fn());
        else if (template_obj)
            short_display = try_read_localized_item_fn(template_obj, detail::localized_short_name_fn());

        const std::string type_suffix = try_get_ammo_type_suffix(template_obj);
        if (!type_suffix.empty() && short_display.find(type_suffix) == std::string::npos)
        {
            if (!short_display.empty())
                short_display += ' ';
            short_display += type_suffix;
        }

        if (!caliber_display.empty() && !short_display.empty())
            return caliber_display + " " + short_display;
        if (!caliber_display.empty())
            return caliber_display;
        if (!short_display.empty())
            return short_display;

        if (item_obj)
            return try_get_item_localized_full_name(item_obj);

        return {};
    }

    inline std::string try_get_item_localized_display_name(Il2CppObject* item_obj) {
        if (!is_il2cpp_object_strict(item_obj)) return {};

        const std::string template_id = try_get_item_template_id(item_obj);
        if (!template_id.empty())
        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            const auto& cache = detail::template_display_cache();
            const auto cached = cache.find(template_id);
            if (cached != cache.end())
                return cached->second;
        }

        detail::localized_item_fn_t short_name_fn = detail::localized_short_name_fn();
        detail::localized_item_fn_t name_fn = detail::localized_name_fn();

        std::string display_name = try_get_item_localized_name(item_obj, short_name_fn, name_fn);
        if (display_name.empty() || display_name == "Item")
            display_name = try_get_item_display_name(item_obj);

        if (!template_id.empty() && !display_name.empty())
        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            detail::template_display_cache()[template_id] = display_name;
        }

        return display_name;
    }

// ---------------------------------------------------------------------------------
// Container-label probe. PLACEMENT IS LOAD-BEARING, TWICE OVER.
//
// (1) ORDER. This must come AFTER try_get_item_localized_display_name (
//     declared ~line 5900) and after has_valid_localization (~line 6500), or the header
//     does not compile: C3861 'identifier not found'. The first attempt parked this inside
//     namespace detail, right after container_display_cache(), where neither exists yet.
//     A header is order-dependent and the compiler is the only thing that reports it.
//
// (2) LOCK. The body needs localization_cache_mutex(), but only TRANSITIVELY -- via
//     try_localize_game_key -> try_localize_key. That mutex is a plain std::mutex, not
//     recursive, so the CALL SITE in try_get_lootable_container_display_name must sit
//     OUTSIDE the cache's lock_guard block. It does, and there is a comment there.

    inline void probe_container_label_steps(Il2CppObject* container_obj) {
        static std::unordered_map<std::string, int> seen;
        static int s_reports = 0;
        static constexpr int kMaxReports = 24;

        const char* klass_name = (container_obj && container_obj->klass && container_obj->klass->name)
            ? container_obj->klass->name : "<null klass>";
        std::string kname = klass_name ? klass_name : "<null>";

        // Count sightings; only the first few distinct classes get reported.
        const int nth = ++seen[kname];
        if (nth > 1) return;
        if (s_reports >= kMaxReports) return;
        ++s_reports;

        // --- step 1: ItemOwner -> RootItem -> item db ---
        std::string step1;
        Il2CppObject* item_owner = try_get_container_item_owner(container_obj);
        Il2CppObject* root_item = item_owner ? try_get_controller_root_item(item_owner) : nullptr;
        if (root_item)
        {
            step1 = try_get_item_localized_display_name(root_item);
            if (step1 == "Item") step1.clear();
        }

        // --- step 2: get_Id(), raw, plus what each key form localizes to ---
        std::string raw_id;
        bool got_getter = false;
        {
            Il2CppObjectInstance inst(container_obj);
            const auto get_id = inst.get_method<Il2CppString* (*)(Il2CppObject*)>(
                "get_Id", 0, false, /*allow_any_argc=*/false);
            got_getter = (get_id != nullptr);
            if (get_id) raw_id = try_read_il2cpp_string(get_id(container_obj));
        }
        const std::string id_space = try_localize_game_key(raw_id + " Name");
        const std::string id_bare = raw_id.empty() ? std::string{} : try_localize_game_key(raw_id);
        // Ask the GAME whether the key exists, rather than inferring from what came back.
        const bool key_exists = !raw_id.empty() && has_valid_localization(raw_id + " Name");

        // --- step 3: get_TypeKey() ---
        std::string type_key;
        {
            Il2CppObjectInstance inst(container_obj);
            const auto get_tk = inst.get_method<Il2CppString* (*)(Il2CppObject*)>(
                "get_TypeKey", 0, false, /*allow_any_argc=*/false);
            if (get_tk) type_key = try_read_il2cpp_string(get_tk(container_obj));
        }

        logger::info(std::format(
            "container-probe: klass='{}' nth={} owner={} root={} step1='{}' "
            "get_Id:fn={} raw='{}' '<'+'id+'> Name'='{}' bare='{}' keyExists={} "
            "typeKey='{}'",
            kname, nth, item_owner ? "yes" : "NO", root_item ? "yes" : "NO", step1,
            got_getter ? "yes" : "NO", raw_id, id_space, id_bare,
            key_exists ? "yes" : "no", type_key));

        // --- verdict: which stage is the one that is empty ---
        const char* where = step1.empty() ? "1:ItemOwner/RootItem" : "";
        if (step1.empty() && raw_id.empty())
            where = got_getter ? "2:get_Id returned EMPTY" : "2:get_Id DID NOT RESOLVE";
        else if (step1.empty() && id_space.empty() && id_bare.empty() && !key_exists)
            where = "2:locale has no key for this id";
        else if (step1.empty() && id_space.empty() && id_bare.empty() && key_exists)
            where = "2:key EXISTS but lookup+plausibility filter rejected it";
        if (step1.empty() && !where[0])
            where = "?";
        logger::info(std::format("container-probe: first-empty-stage = {}", where));
    }

    inline std::string try_get_lootable_container_display_name(Il2CppObject* container_obj) {
        // PROBE FIRST, and deliberately OUTSIDE the cache lock below.
        //
        // The mutex the probe needs is taken TRANSITIVELY, which is why this placement is
        // load-bearing and not cosmetic:
        //
        //     probe_container_label_steps
        //       -> try_localize_game_key / has_valid_localization
        //         -> try_localize_key
        //           -> std::lock_guard(localization_cache_mutex())
        //
        // localization_cache_mutex() is a plain std::mutex, NOT recursive. Calling the probe
        // from inside the cache block below self-deadlocks the game thread on the first
        // container of the first raid. The first version of this patch did exactly that and
        // compiled clean, because the lock is three calls away and nowhere in the probe's own
        // text. This comment exists so the next person does not 'tidy' the call back inside.
        probe_container_label_steps(container_obj);

        const uintptr_t cache_key = reinterpret_cast<uintptr_t>(container_obj);
        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            const auto& cache = detail::container_display_cache();
            if (const auto cached = cache.find(cache_key); cached != cache.end())
                return cached->second;
        }

        std::string display_name;

        // ---- 1. THE CONTAINER'S OWN TEMPLATE ---------------------------------------------
        // dump.cs 1.2.0.0, EFT.Interactive.LootableContainer:
        //
        //     public string Template;    // 0x180
        //
        // This is the only always-present, actually-localizable identity on the object. It is
        // a [SerializeField], so the level prefab fills it in at load; it is never null the
        // way ItemOwner is, because ItemOwner is assigned by Init(ItemController) when the
        // loot spawner decides this container is real -- which for an unspawned one is never.
        //
        // ORDER MATTERS, and getting it wrong is what produced the permanent generic label.
        // Template must be tried BEFORE get_Id(), because get_Id() succeeds on EVERY
        // container and returns the SCENE OBJECT NAME --
        //
        //     container_City_SW_02_LexOs_blockpost_00024
        //
        // which is not a locale key, so every localization of it misses and the resolver
        // falls through to TypeKey, whose value is the literal string "container". Reading
        // Template only when get_Id() came back EMPTY therefore never ran: get_Id() is never
        // empty. That is the whole regression.
        {
            Il2CppObject* tmpl_obj = try_get_field_object(container_obj, "Template");
            if (tmpl_obj)
            {
                const std::string tmpl =
                    try_read_il2cpp_string(reinterpret_cast<Il2CppString*>(tmpl_obj));
                if (!tmpl.empty())
                {
                    if (const std::string localized =
                            try_localize_game_key(tmpl + " Name"); !localized.empty())
                    {
                        display_name = localized;
                    }
                    else if (const std::string localized =
                                 try_localize_game_key(tmpl); !localized.empty())
                    {
                        display_name = localized;
                    }
                }
            }
        }

        // ---- 2. the item behind the container ---------------------------------------------
        // ItemOwner is the ItemController Init() handed this container. Preferred over
        // Template, because the root item is what is actually inside the box this raid.
        if (display_name.empty())
        {
            if (Il2CppObject* item_owner = try_get_container_item_owner(container_obj))
            {
                if (Il2CppObject* root_item = try_get_controller_root_item(item_owner))
                {
                    display_name = try_get_item_localized_display_name(root_item);
                    if (display_name == "Item")
                        display_name.clear();
                }
            }
        }

        if (!display_name.empty())
        {
            std::lock_guard<std::mutex> lock(detail::localization_cache_mutex());
            detail::container_display_cache()[cache_key] = display_name;
            return display_name;
        }

        // ---- 3. get_Id(): the SCENE OBJECT NAME, as a last-resort label --------------------
        // dump.cs: `public string Id { get; set; }` / `get_Id()` RVA 0x6E8900 Slot: 69.
        //
        // It is a distinct object, not a key -- it does not localize. But it is far more
        // informative to a player than "Container", so it is used verbatim as the label
        // rather than discarded.
        //
        // NOTE call_or supplies `self` itself, so a 0-arg getter takes NO call_args. Passing
        // the instance as an argument deduces FP with an extra Il2CppObject* parameter and so
        // resolves a signature that does not exist.
        {
            Il2CppObjectInstance container_inst(container_obj);
            if (const auto get_id = container_inst.call_or<StrPtr>("get_Id", 0, StrPtr{}))
            {
                const std::string container_id = try_read_il2cpp_string(get_id);
                if (!container_id.empty())
                    return container_id;
            }
        }

        // ---- 4. TypeKey: the literal "container". DELIBERATELY NOT CACHED. ----------------
        // A class constant, identical for every container on the map, whose localized value
        // is the generic word. Last resort, nothing more.
        //
        // This used to be cached, which is what made the generic label PERMANENT for the
        // whole raid: the entry survived even after ItemOwner was populated and a real name
        // existed, because the cache is consulted first and is keyed by object address.
        {
            Il2CppObjectInstance container_inst(container_obj);
            if (const auto get_type_key =
                    container_inst.call_or<StrPtr>("get_TypeKey", 0, StrPtr{}))
            {
                const std::string type_key = try_read_il2cpp_string(get_type_key);
                if (!type_key.empty())
                {
                    if (const std::string localized =
                            try_localize_game_key(type_key); !localized.empty())
                    {
                        return localized;
                    }
                    return type_key;
                }
            }
        }

        // ---- 5. nothing at all -------------------------------------------------------------
        if (container_obj->klass && container_obj->klass->name && *container_obj->klass->name)
            return std::string("#") + container_obj->klass->name;
        return "Container";
    }

    // (Old radial-fit optic declarations removed — the lens pipeline in
    // optics_lens_pipeline.h plus the radial fallback in world_to_screen_optic
    // are the single projection path; see util/linalg.h for shared math.)
    struct weapon_ammo_state
    {
        bool active = false;
        int mag_count = 0;
        int mag_max = 0;
        int chamber_count = 0;
        float initial_speed = 0.f;
        int penetration_power = 0;        // AmmoTemplate.PenetrationPower (1..~70 class scale)
        float obstacle_pen_chance = -1.f; // AmmoTemplate.PenetrationChanceObstacle (0..1); -1 = unknown
        // AmmoTemplate.RicochetChance. Only its SIGN matters: ISIL's
        // BallisticCollider.Deflects gates on `shot.RicochetChance <= 0 -> never
        // deflects`, and the magnitude cancels out of P(deflect) entirely (the roll
        // range is scaled by the same total it is compared against). -1 = unknown,
        // which is treated as "can deflect" so a missing getter never silently
        // disables ricochet reporting.
        float ricochet_chance = -1.f;
        std::string chamber_name;
    };

    inline bool try_read_weapon_ammo(Il2CppObject* player_obj, weapon_ammo_state& out, bool* hands_not_firearm = nullptr) {
        if (hands_not_firearm)
            *hands_not_firearm = false;
        if (!player_obj) return false;

        Il2CppObjectInstance player(player_obj);
        // Resolved into a local and tested, not invoked inline. See the note at
        // get_scope_zoom: a miss here is a call to 0x0, and both of these run on
        // the Aimbot's per-player, per-frame path.
        const auto get_hands_fn =
            player.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_HandsController", 0);
        if (!get_hands_fn)
        {
            // Silent-guard failure #3 from AGENTS_TODO 5.7ad: a miss here makes the ammo
            // readouts vanish with nothing in the log. `false` is also the honest "no ammo
            // data", so callers cannot tell a resolve failure from an empty magazine.
            // Capped, because this is on the Aimbot's per-player, per-frame path.
            static std::atomic<int> s_warned{ 0 };
            if (s_warned.fetch_add(1, std::memory_order_relaxed) < 3)
                logger::warn("try_read_weapon_ammo: get_HandsController did not resolve --"
                             " ammo readouts report \"no data\", indistinguishable from an"
                             " empty magazine");
            return false;
        }
        Il2CppObject* hands_controller = get_hands_fn(player_obj);
        if (!hands_controller || !hands_controller->klass) return false;
        if (strcmp(hands_controller->klass->name, "FirearmController") != 0)
        {
            if (hands_not_firearm)
                *hands_not_firearm = true;
            return false;
        }

        out = {};

        Il2CppObjectInstance firearm_controller(hands_controller);
        const auto get_item_fn =
            firearm_controller.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_Item", 0);
        if (!get_item_fn)
        {
            static std::atomic<int> s_warned{ 0 };
            if (s_warned.fetch_add(1, std::memory_order_relaxed) < 3)
                logger::warn("try_read_weapon_ammo: get_Item did not resolve --"
                             " ammo readouts report \"no data\"");
            return false;
        }
        Il2CppObject* weapon_obj = get_item_fn(hands_controller);
        if (!weapon_obj) return false;

        Il2CppObjectInstance weapon(weapon_obj);

        if (const auto get_mag_count = weapon.get_method<int (*)(Il2CppObject*)>("GetCurrentMagazineCount", 0))
            out.mag_count = get_mag_count(weapon_obj);
        if (const auto get_mag_max = weapon.get_method<int (*)(Il2CppObject*)>("GetMaxMagazineCount", 0))
            out.mag_max = get_mag_max(weapon_obj);
        if (const auto get_chamber_count = weapon.get_method<int (*)(Il2CppObject*)>("get_ChamberAmmoCount", 0))
            out.chamber_count = get_chamber_count(weapon_obj);

        if (const auto get_first_chamber = weapon.get_method<Il2CppObject* (*)(Il2CppObject*)>(
                "get_FirstLoadedChamberSlot", 0))
        {
            if (Il2CppObject* slot_obj = get_first_chamber(weapon_obj))
            {
                if (Il2CppObject* ammo_item = try_get_slot_contained_item(slot_obj))
                {
                    out.chamber_name = try_get_ammo_display_name(ammo_item);
                    Il2CppObjectInstance ammo_inst(ammo_item);
                    if (const auto get_initial_speed =
                            ammo_inst.get_method<float (*)(Il2CppObject*)>("get_InitialSpeed", 0))
                    {
                        out.initial_speed = get_initial_speed(ammo_item);
                    }
                    // Penetration model inputs (verified: AmmoTemplate fields via getters).
                    if (const auto get_pen_power =
                            ammo_inst.get_method<int (*)(Il2CppObject*)>("get_PenetrationPower", 0))
                    {
                        out.penetration_power = get_pen_power(ammo_item);
                    }
                    if (const auto get_pen_obst =
                            ammo_inst.get_method<float (*)(Il2CppObject*)>("get_PenetrationChanceObstacle", 0))
                    {
                        const float ch = get_pen_obst(ammo_item);
                        out.obstacle_pen_chance = (std::isfinite(ch) && ch >= 0.f) ? ch : -1.f;
                    }
                    if (const auto get_ric = ammo_inst.get_method<float (*)(Il2CppObject*)>(
                            "get_RicochetChance", 0))
                    {
                        const float rc = get_ric(ammo_item);
                        out.ricochet_chance = std::isfinite(rc) ? rc : -1.f;
                    }
                }
            }
        }

        if (out.chamber_name.empty() && out.chamber_count > 0)
        {
            if (const auto get_template = weapon.get_method<Il2CppObject* (*)(Il2CppObject*)>(
                    "get_CurrentAmmoTemplate", 0))
            {
                if (Il2CppObject* tmpl = get_template(weapon_obj))
                {
                    out.chamber_name = try_get_ammo_display_name(tmpl);
                    // Fallback: template object also exposes the same getters.
                    Il2CppObjectInstance tmpl_inst(tmpl);
                    if (out.penetration_power <= 0)
                    {
                        if (const auto get_pen_power =
                                tmpl_inst.get_method<int (*)(Il2CppObject*)>("get_PenetrationPower", 0))
                            out.penetration_power = get_pen_power(tmpl);
                    }
                    if (out.obstacle_pen_chance < 0.f)
                    {
                        if (const auto get_pen_obst =
                                tmpl_inst.get_method<float (*)(Il2CppObject*)>("get_PenetrationChanceObstacle", 0))
                        {
                            const float ch = get_pen_obst(tmpl);
                            out.obstacle_pen_chance = (std::isfinite(ch) && ch >= 0.f) ? ch : -1.f;
                        }
                    }
                    if (out.ricochet_chance < 0.f)
                    {
                        if (const auto get_ric = tmpl_inst.get_method<float (*)(Il2CppObject*)>(
                                "get_RicochetChance", 0))
                        {
                            const float rc = get_ric(tmpl);
                            out.ricochet_chance = std::isfinite(rc) ? rc : -1.f;
                        }
                    }
                }
            }
        }

        out.active = true;
        return true;
    }

} // namespace eft_api
