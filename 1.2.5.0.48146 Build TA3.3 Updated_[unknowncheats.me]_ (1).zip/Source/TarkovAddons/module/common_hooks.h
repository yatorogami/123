#pragma once

#include <Windows.h> // [NEW] Required for Sleep()
#include "always_on.h"
#include "ModuleManager.h"
#include "game_state.h"

namespace common_hooks {
    inline Il2CppImage* assembly_csharp;
    inline const Il2CppClass* game_world_class;

    using update_sig = void (*)(Il2CppObject*);
    inline update_sig o_tarkov_application_update = nullptr;
    inline update_sig o_game_world_update = nullptr;

    // The event half of the is_in_raid false edge is declared in game_state.h as
    // game_state::on_local_raid_ended_event, NOT here: ItemModule.h needs it and cannot
    // include this header (circular -- this pulls ModuleManager.h, which pulls
    // ItemModule.h).

    inline const Il2CppClass* is_in_raid;

    inline Il2CppObject* asset_bundle_load_object = nullptr;
    inline bool asset_bundle_loaded = false;

    // Watchdog for the post-transit bundle reload. The user reported items
    // reverting to their original textures after a transit with the toggle dead:
    // if is_asset_bundle_valid() ever misses, or LoadFromFileAsync wedges, the
    // reload cycle can sit in the "stale bundle, load never completing" state
    // forever and scan_item_chams keeps early-returning on a null bundle. A
    // timed restart of the load cycle keeps the chams self-healing.
    static constexpr ULONGLONG kBundleReloadTimeoutMs = 15000;
    // Backoff between failed start_load() attempts. Without it a permanent
    // failure retries every frame, because the cycle state is "not started".
    static constexpr ULONGLONG kBundleRetryBackoffMs = 5000;
    inline ULONGLONG reload_start_ms_ = 0;
    inline ULONGLONG bundle_retry_after_ms_ = 0;
    inline bool reload_watchdog_armed_ = false;

    void hk_tarkov_application_update(Il2CppObject* instance);

    void hk_game_world_update(Il2CppObject* instance);

    inline bool init() {
        // Assembly-CSharp is loaded later than GameAssembly. Bound the wait so a
        // failed/changed game load cannot leave the injected thread running forever.
        constexpr DWORD wait_timeout_ms = 120000;
        const DWORD wait_started = GetTickCount();
        while (!il2utils::resolve_image("Assembly-CSharp.dll"))
        {
            if (GetTickCount() - wait_started > wait_timeout_ms)
            {
                logger::error("Timed out waiting for Assembly-CSharp.dll; hooks were not installed");
                return false;
            }
            Sleep(50);
        }
        assembly_csharp = il2utils::resolve_image("Assembly-CSharp.dll");
        if (!assembly_csharp)
            return false;

        // ingame status class
        is_in_raid = il2utils::resolve_class(assembly_csharp, "EFT", "InGameStatus");

        // hook game world update
        game_world_class = il2utils::resolve_class(assembly_csharp, "EFT", "GameWorld");
        if (!is_in_raid || !game_world_class)
        {
            logger::error("Required EFT classes were not found; hooks were not installed");
            return false;
        }
        il2utils::hook_method(game_world_class, "Update", 0, hk_game_world_update,
            &o_game_world_update);

        // hook tarkov application update
        const Il2CppClass* tarkov_application_class = il2utils::resolve_class(assembly_csharp, "EFT", "TarkovApplication");
        if (!tarkov_application_class)
        {
            logger::error("TarkovApplication class was not found; hooks were not installed");
            return false;
        }
        il2utils::hook_method(tarkov_application_class, "Update", 0, hk_tarkov_application_update,
            &o_tarkov_application_update);
        if (!o_game_world_update || !o_tarkov_application_update)
        {
            logger::error("Required update hooks could not be installed");
            return false;
        }
        return true;
    }
} // namespace common_hooks
