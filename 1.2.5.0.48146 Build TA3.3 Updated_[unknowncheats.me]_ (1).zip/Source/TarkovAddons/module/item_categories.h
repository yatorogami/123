#pragma once
#include <cstdint>
#include <cstring>
#include <memory>
#include <string>
#include <unordered_set>

// Loot filters: Wishlist + Hideout (from Profile.WishlistManager / EWishlistGroup), and
// the eight handbook-style loot categories (from the ItemTemplate class hierarchy).
namespace item_categories {
    enum class kind : unsigned char {
        other = 0,
        wishlist,
        hideout,
    };

    // Loot category, derived from the concrete ItemTemplate subclass.
    //
    // Why the class and not a field: there is no category field on ItemTemplate. The
    // community `items.json` carried "propertiesType": "ItemPropertiesFoodDrink",
    // which was the discriminated-union tag of the server's template table;
    // ItemTemplate.TemplateSerializer : PolymorphicSerializer<ItemTemplate, string>
    // is the game doing the same thing. In the client the string tag is gone and the
    // category is the TYPE of the object. So `klass->name` is the whole of it.
    //
    // The previous implementation matched substrings against the item's LOCALIZED
    // display name, and had five provable defects: Valuables was a strict subset of
    // Barter, Barter had no positive requirement at all, Ammo could not see a calibre
    // (its needles contained no digit, while EFT ammo is named "7.62x51 M80"), buckets
    // overlapped, and the needles were English against a translated string. Reading
    // the type fixes all five and costs one load from a pointer the build loop already
    // dereferences.
    // The SelectValue list in LootTeleportModule's constructor is ordered to match these
    // ordinals, and the filter relies on that:
    //   0 All | 1 Valuables | 2 Barter | 3 Medical | 4 Food | 5 Ammo
    //   6 Weapons | 7 Armor | 8 Keys
    // So `category == static_cast<int>(loot::valuables)` etc. is a valid comparison.
    // The drop-down order is therefore also the precedence order for anything that
    // ever needs one, and the keys are stored in config as those indices -- which means
    // REORDERING this enum silently re-labels every saved setting. Append only, and
    // only when a real category is missing.
    enum class loot : uint8_t {
        unknown = 0, // class not in the table -- fall back, never silently exclude
        valuables,
        barter,
        medical,
        food,
        ammo,
        weapons,
        armor,
        keys,
        count,
    };

    // Maps a concrete ItemTemplate subclass name to a loot category.
    //
    // A switch on the exact name, NOT a prefix or substring match: "Key" and
    // "KeyTemplate" are different classes and guessing between them is how the
    // substring version got Valuables ⊂ Barter. An unknown name returns
    // loot::unknown so the caller can fall back rather than treat it as a non-match.
    //
    // Precedence where classes overlap is decided here and nowhere else, so each item
    // lands in exactly one bucket.
    //
    // Maps an ItemTemplate's CLASS HIERARCHY to a loot category.
    //
    // Not a table of leaf class names, because there are 130 of them and a new one
    // appears with most patches. The first version listed 30 leaves, chosen by a grep
    // that matched 27 of 130, and the live log immediately showed the cost:
    //
    //   124 distinct template classes, 1953/5963 entries mapped (4010 unmapped)
    //   SingleUseContainerTemplate=427[?] ArmorPlateTemplate=426[?] MagazineTemplate=230[?]
    //
    // Two thirds unmapped, and the misses were the LARGEST families -- which is exactly
    // what a name table gets wrong, because the popular items are the ones with their
    // own class.
    //
    // So the classifier walks the base chain and matches FAMILY ROOTS. A new
    // AssaultWhateverTemplate is a weapon because it derives from WeaponTemplate, with
    // nothing to add here. Weapons prove a name-based table cannot work at all: the
    // twelve are AssaultCarbine, AssaultRifle, GrenadeLauncher, MachineGun,
    // MarksmanRifle, Pistol, Revolver, RocketLauncher, Shotgun, Smg, SniperRifle,
    // SpecialWeapon, and the only thing they share is their parent.
    //
    // `chain` is class names from most-derived to root, which the caller builds by
    // walking Il2CppClass::parent (a pointer at a fixed offset in the always-valid
    // part of the struct, the same chain resolve_field already walks). First match wins,
    // so the order of the root table is the precedence order.
    inline loot loot_from_ancestry(const char* const* chain, size_t n) {
        for (size_t i = 0; i < n; ++i) {
            const char* c = chain[i];
            if (!c || !c[0]) continue;
            // -- Ammo. AmmoBoxTemplate is the box, not a StackableItemTemplate, so it
            // needs its own root; RocketTemplate sits under StackableItemTemplate.
            if (std::strcmp(c, "AmmoTemplate") == 0 || std::strcmp(c, "AmmoBoxTemplate") == 0)
                return loot::ammo;
            // -- Weapons. KnifeTemplate and ThrowWeapTemplate derive from ItemTemplate,
            // not WeaponTemplate, so they are separate roots.
            if (std::strcmp(c, "WeaponTemplate") == 0 || std::strcmp(c, "KnifeTemplate") == 0 ||
                std::strcmp(c, "ThrowWeapTemplate") == 0)
                return loot::weapons;
            if (std::strcmp(c, "MedsTemplate") == 0) return loot::medical;
            if (std::strcmp(c, "FoodDrinkTemplate") == 0) return loot::food;
            if (std::strcmp(c, "KeyTemplate") == 0) return loot::keys;
            // -- Armor & gear.
            //
            // ArmoredEquipmentTemplate is the load-bearing root for the five families
            // under it -- ArmorPlate, Armor, Headwear, FaceCover, Visors. Those five are
            // also listed by name below, which is redundant: deleting
            // "ArmorPlateTemplate" from this condition changes nothing, because the walk
            // reaches ArmoredEquipmentTemplate one step later. Checked by hand, not
            // assumed. They are kept only as insurance in case BSG reparents one out
            // from under the root.
            //
            // ArmorPlateTemplate alone is 426 templates, the single largest loot family in
            // the game, and the leaf-name version of this table missed it.
            //
            // VestTemplate and BackpackTemplate are genuinely load-bearing entries: they
            // derive from SearchableItemTemplate, NOT from ArmoredEquipmentTemplate,
            // which is the trap. ArmBandTemplate and HeadphonesTemplate sit under
            // EquipmentTemplate, so EquipmentTemplate covers those two. The category label
            // is "Armor & Gear", so a backpack and headphones belong here.
            if (std::strcmp(c, "ArmoredEquipmentTemplate") == 0 ||
                std::strcmp(c, "ArmorTemplate") == 0 || std::strcmp(c, "ArmorPlateTemplate") == 0 ||
                std::strcmp(c, "HeadwearTemplate") == 0 || std::strcmp(c, "FaceCoverTemplate") == 0 ||
                std::strcmp(c, "VisorsTemplate") == 0 || std::strcmp(c, "VestTemplate") == 0 ||
                std::strcmp(c, "ArmBandTemplate") == 0 || std::strcmp(c, "HeadphonesTemplate") == 0 ||
                std::strcmp(c, "BackpackTemplate") == 0 || std::strcmp(c, "EquipmentTemplate") == 0)
                return loot::armor;
            // -- Valuables. Both derive from BarterItemTemplate, so they must be tested
            // BEFORE barter or they would be swallowed by it -- which is precisely the
            // old "Valuables is a subset of Barter" defect, reappearing through the
            // hierarchy this time.
            if (std::strcmp(c, "JewelryTemplate") == 0 || std::strcmp(c, "ElectronicsTemplate") == 0)
                return loot::valuables;
            // -- Barter. BarterItemTemplate's ten subclasses plus two whole families that
            // are loot rather than equipment: ModTemplate (39 classes -- scopes,
            // magazines, barrels, handguards, stocks, mounts, flashlights) and
            // SpecItemTemplate (compass, cultist amulet, mark of unknown, multitool,
            // planting kit, range finder, radio, recorder, repair kit).
            //
            // Mods are the most valuable loot in a raid and had no bucket at all.
            if (std::strcmp(c, "BarterItemTemplate") == 0 || std::strcmp(c, "ModTemplate") == 0 ||
                std::strcmp(c, "SpecItemTemplate") == 0 || std::strcmp(c, "ChemLightTemplate") == 0)
                return loot::barter;
        }
        return loot::unknown;
    }

    // True when the class NAME ALONE hits a family root, i.e. the leaf is itself a root
    // rather than something that inherits one. Callers that hold an Il2CppClass should
    // walk the chain and call loot_from_ancestry instead -- this is only for the
    // diagnostics that have a string and no class pointer, and it deliberately has a
    // different name so it cannot be reached by accident.
    //
    // There used to be a two-argument template here, taking (leaf, parent_name_of).
    // It was unused: the mod walks Il2CppClass::parent and the harness builds its own
    // chain, and because it took the same two arguments as the array overload above it
    // silently won overload resolution for loot_from_ancestry(chain, count) with
    // ParentNameOf deduced as int. Cut rather than renamed.
    inline bool loot_class_is_known(const char* leaf) {
        if (!leaf) return false;
        const char* chain[1] = { leaf };
        return loot_from_ancestry(chain, 1) != loot::unknown;
    }

    // =================================================================================
    // WISHLIST GROUPS. The game's own EWishlistGroup, not a taxonomy of ours.
    //
    // Re-derived from the dump rather than trusted from the comment that used to sit here.
    // WishlistManager.GroupToWishlistIcon (ISIL WishlistManager.txt:4552) is the only
    // method that switches on the value exhaustively, and it does so without naming it:
    //
    //     7  CheckEqual v8 @ ZF_v1, group @ rcx (EFT.EWishlistGroup), 0
    //    11  Subtract v11, group, 1
    //    13  Subtract v13, v11, 1
    //    15  Subtract v21, v13, 1
    //    24  CheckEqual v27 @ ZF_v2, v21, 1
    //    29  Return 0     30  Return 14    31  Return 13    32  Return 12    33  Return 11
    //
    // Five outcomes, so five values: 0, 1, 2, 3, 4. The VALUES are proven. The LABELS are
    // NOT -- the dump carries no name table for the enum, so the words below are ours and
    // are the one part of this a future dump could contradict.
    //
    // `wishlist_group::other` shares a word with the existing `kind::other`, which means
    // something different ("nothing matched"). That is a coincidence of spelling, not an
    // intent; this one IS EWishlistGroup's value 4.
    enum class wishlist_group : uint8_t {
        quests = 0,
        hideout = 1,
        trading = 2,
        equipment = 3,
        other = 4,
        none = 255, // not on the wishlist at all
    };

    inline constexpr int kWishlistGroupCount = 5;

    // A set of selected groups, one bit each. Chosen over five bools so the selection can
    // be passed, compared and defaulted as ONE value -- a mask of 0 is a well-defined
    // "nothing selected", which five separate bools cannot express.
    //
    // APPEND-ONLY. A group's bit is derived from the enum's VALUE, so the bits happen to
    // line up with the game's numbering. Renumbering the enum could move them, and the
    // static_asserts below pin the GAME's values rather than the bit positions -- so this
    // is the one place where "append only" is a promise and not a compile error.
    using wishlist_mask = uint8_t;

    inline constexpr wishlist_mask group_bit(const wishlist_group g) {
        return (g == wishlist_group::none)
            ? wishlist_mask{0}
            : static_cast<wishlist_mask>(wishlist_mask{1} << static_cast<uint8_t>(g));
    }

    inline constexpr wishlist_mask wishlist_all_mask() {
        return static_cast<wishlist_mask>((wishlist_mask{1} << kWishlistGroupCount) - 1);
    }

    // The five values above are EFT.EWishlistGroup's, pinned so a renumber cannot ship
    // silently. The Hideout assert is the one that would actually have earned its keep: the
    // dictionary walk in eft_api.h routes an entry with `group == k_group_hideout` into the
    // hideout set, so if 1 stopped meaning Hideout that comparison would quietly start
    // filing every hideout requirement under Trading.
    static_assert(static_cast<uint8_t>(wishlist_group::quests) == 0, "EWishlistGroup: Quests = 0");
    static_assert(static_cast<uint8_t>(wishlist_group::hideout) == 1, "EWishlistGroup: Hideout = 1");
    static_assert(static_cast<uint8_t>(wishlist_group::trading) == 2, "EWishlistGroup: Trading = 2");
    static_assert(static_cast<uint8_t>(wishlist_group::equipment) == 3, "EWishlistGroup: Equipment = 3");
    static_assert(static_cast<uint8_t>(wishlist_group::other) == 4, "EWishlistGroup: Other = 4");

    // EWishlistGroup (dump 1.0.6.5.46221): Quests=0, Hideout=1, Trading=2, Equipment=3, Other=4
    inline constexpr int k_group_hideout = 1;

    struct filter_sets
    {
        std::unordered_set<std::string> wishlist; // any group except Hideout
        std::unordered_set<std::string> hideout;  // group Hideout (+ hideout QoL if present)
        bool ready = false;

        // Per-group membership, indexed by wishlist_group's value. This is the granularity
        // the union above throws away.
        //
        // Filled by the SAME dictionary walk that fills `wishlist`/`hideout`, so the two
        // cannot disagree. Those two are RETAINED rather than replaced: classify_id() and
        // its callers predate this and must keep behaving identically.
        std::unordered_set<std::string> by_group[kWishlistGroupCount];

        // Insert into the per-group set AND the matching union, in one call, so a future
        // caller cannot populate one and forget the other -- which is exactly the drift that
        // made the groups unreadable in the first place.
        inline void add(const std::string& tid, const wishlist_group g) {
            if (tid.empty() || g == wishlist_group::none) return;
            by_group[static_cast<size_t>(g)].insert(tid);
            if (g == wishlist_group::hideout)
                hideout.insert(tid);
            else
                wishlist.insert(tid);
        }

        // True when `tid` is in group `g`. Kept separate from the union lookup because
        // "on the wishlist" and "on THIS wishlist group" are different questions, and
        // collapsing them is the thing being fixed.
        inline bool in_group(const std::string& tid, const wishlist_group g) const {
            if (tid.empty() || !ready || g == wishlist_group::none) return false;
            return by_group[static_cast<size_t>(g)].find(tid) != by_group[static_cast<size_t>(g)].end();
        }
    };

    inline kind classify_id(const std::string& template_id, const filter_sets& sets) {
        if (template_id.empty() || !sets.ready)
            return kind::other;
        // Hideout takes priority when both apply.
        if (sets.hideout.find(template_id) != sets.hideout.end())
            return kind::hideout;
        if (sets.wishlist.find(template_id) != sets.wishlist.end())
            return kind::wishlist;
        return kind::other;
    }

    // Which wishlist GROUP an id is in, or `none`. The question classify_id cannot answer.
    //
    // Returns on the FIRST group that matches. An id is expected in exactly one group -- it
    // is one dictionary entry with one group value -- so the order only matters for an id
    // that appears in two sets, which happens if a user moves an item and the old entry is
    // still cached. Lowest value wins there, which is arbitrary and harmless.
    inline wishlist_group classify_group(const std::string& template_id, const filter_sets& sets) {
        if (template_id.empty() || !sets.ready) return wishlist_group::none;
        for (int g = 0; g < kWishlistGroupCount; ++g)
            if (sets.in_group(template_id, static_cast<wishlist_group>(g)))
                return static_cast<wishlist_group>(g);
        return wishlist_group::none;
    }

    // Does the user's selection admit this group?
    //
    // A zero mask means "this caller expressed no group selection at all" and admits every
    // group. That is deliberate: it makes an unmigrated caller -- and a user who has every
    // group checkbox off -- get the OLD flat behaviour rather than nothing. Decided here,
    // once, rather than in each of the two modules.
    inline bool wishlist_allows(const wishlist_group g, const wishlist_mask selected) {
        if (g == wishlist_group::none) return false;
        if (selected == 0) return true;
        return (selected & group_bit(g)) != 0;
    }

    // =========================================================================
    // Shared filter predicates. One implementation, two callers.
    //
    // These existed as two copies each -- one in EspModule for the ESP loot
    // filters, one in LootTeleportModule for the Loot Teleporter card -- and the
    // copies had already DIVERGED. LootTeleportModule had been moved onto the
    // class taxonomy below; EspModule still ran the old substring switch, which
    // is how the two ended up disagreeing about the same dropdown.
    //
    // Neither module owns this logic. EspModule's own comment records why the
    // duplication was deliberate in the first place -- "the card must not depend
    // on the ESP renderer module" -- which is a real constraint, but it is a
    // constraint on the SETTINGS, not on the predicate. The settings are still
    // per-module (`loot_*` vs `loot_*_` config keys, deliberately); the answer to
    // "does this item match" is not per-module, and having two answers is how
    // they drift.
    // =========================================================================

    // Does `kind` satisfy the user's selected loot category?
    //
    // `category` is the raw SelectValue index, which is the same numbering as the
    // `loot` enum: 1 Valuables .. 8 Keys, with 0 meaning "All Categories". The
    // numbering lining up is what lets this be a cast rather than a lookup, and it
    // is checked below by a static_assert rather than by a comment.
    //
    // UNKNOWN ALLOWS -- but only for a DISPLAY filter. See allow_unknown.
    inline bool loot_category_allows(const loot kind, const int category,
        const bool allow_unknown = true) {
        if (category == 0) return true;
        if (kind == loot::unknown) return allow_unknown;
        return static_cast<int>(kind) == category;
    }

    // The permissive fallback is a DISPLAY decision and does not survive being
    // reused for an ACTION.
    //
    // For the ESP loot filters, an unmapped item falling through is the right
    // answer: a filter that silently hides loot is worse than one that is
    // quietly permissive, and the db build logs how many entries take this path.
    //
    // For a TELEPORT it is the opposite. `loot_category_allows` returning true
    // for "Medical" moves every unmapped item to the player's feet, and the
    // measured unmapped population is not a handful of oddities -- the live
    // log for 2026-10-11 reads
    //
    //   124 distinct template classes, 5012/6001 entries mapped to a category
    //   (989 unmapped) ... 24 of 124 classes unmapped:
    //   SingleUseContainerTemplate=427, InfoTemplate=180, NoteItemTemplate=84, ...
    //
    // so one in six loot entries passes EVERY category the user picks. Wishlist
    // items land disproportionately in those classes (an obscure wanted item is
    // usually an obscure class), which is what made "Teleport Category Loot To
    // Me" appear to drag the wishlist along with it.
    //
    // So the two callers disagree deliberately, and this pair of constants is
    // where that disagreement lives. Each is named for what it MEANS in its own
    // context so a caller writes the policy it wants rather than negating the
    // other one -- the negation is exactly the kind of edit that silently ships
    // the permissive rule to the teleporter.
    inline constexpr bool kCategoryFilterPermitsUnknown = true;  // ESP: label it
    inline constexpr bool kTeleportCategoryAllowsUnknown = false; // action: do not move it

    // The cast above assumes the `loot` enum value IS the dropdown index. That is a
    // real coupling to a lang file -- the SelectValue in EspModule and
    // LootTeleportModule lists eight options in this order -- so it is pinned here
    // rather than left to a comment. If someone reorders the enum, or inserts a
    // category, this fails to compile instead of silently filtering on the wrong
    // bucket, which is the failure mode the substring version already had.
    static_assert(static_cast<int>(loot::unknown) == 0, "dropdown index 0 is All Categories");
    static_assert(static_cast<int>(loot::valuables) == 1, "dropdown order: Valuables first");
    static_assert(static_cast<int>(loot::keys) == 8, "eight categories, Keys last");
    static_assert(static_cast<int>(loot::count) == 9, "the SelectValue has 9 entries incl. All");

    // The four-option loot filter shared by the ESP teleport card and the Loot
    // Teleporter card. `filter` is the SelectValue index:
    //
    //   0  All Items
    //   1  Quest items
    //   2  Category/Wishlist   <- one option covering both axes, so the filters
    //                             never overlap: an item in the selected category
    //                             OR on the wishlist passes
    //   3  By-name item        <- the one item picked in the search box
    //
    // Wishlist and category are ONE option, not two: they are different axes and
    // both can be true of the same item at once, so separate options would let one
    // item match two filters at once. Combined, each item matches at most one.
    //
    // Everything the predicate needs is passed in, so a caller supplies its own
    // config values and this stays independent of both modules.
    struct teleport_filter_input
    {
        bool is_quest = false;
        kind wishlist = kind::other;
        loot category_kind = loot::unknown;
        int category = 0;              // the selected category index; 0 = All
        const char* selected_id = "";   // template id of the one selected item
        const char* template_id = "";   // the item being tested

        // The item's wishlist GROUP and the user's selected-group mask. Both default to
        // unset, and unset is defined to mean the OLD behaviour rather than a new one: a
        // zero mask admits every group (see wishlist_allows).
        //
        // The harness sets only `wishlist` and asserts filter 2 matches on it. That is why
        // matches_teleport_filter FALLS BACK to the boolean when the mask is zero, rather
        // than those assertions being edited to set a mask -- the fallback is the
        // compatibility, and rewriting the tests would have deleted the evidence for it.
        wishlist_group wl_group = wishlist_group::none;
        wishlist_mask  wl_mask = 0;

        // Whether an item whose class the taxonomy does not recognise counts as a
        // match for the CATEGORY half. Defaults to true -- the ESP display
        // filter's rule, and the one the harness asserts. The Loot Teleporter
        // clears it, because there the filter drives a teleport rather than a
        // label. See loot_category_allows for the measured unmapped population
        // that makes the difference visible.
        bool allow_unknown_category = true;

        // When non-null, filter 3 matches on MEMBERSHIP of this set rather than
        // on selected_id. That is what makes the item search a multi-select: the
        // set is every id the query matched, so the caller does not depend on the
        // user having clicked one of them. selected_id stays the path for a
        // caller that genuinely wants one item (and is what the harness asserts).
        // A multi-select search: the ids the current query matched -- or the
        // one the user pinned by clicking. A shared_ptr rather than a pointer
        // into the search box's member, because that member is swapped on the
        // render thread while this predicate runs on the game thread; the
        // reference held here keeps the set alive and unwritten for the call.
        // Null means the caller has no multi box at all, which is the answer
        // that falls through to the single-id comparison below.
        std::shared_ptr<const std::unordered_set<std::string>> selected_ids;

    };

    inline bool matches_teleport_filter(const int filter, const teleport_filter_input& in) {
        switch (filter) {
        case 1: // Quest items
            return in.is_quest;
        case 2: // Category/Wishlist
            // "All Categories" is not a useful filtered teleport, so the category
            // half matches nothing rather than everything -- with no category
            // picked this option degenerates to wishlist-only.
            if (in.category > 0
                && loot_category_allows(in.category_kind, in.category, in.allow_unknown_category))
                return true;
            // The wishlist half. `wl_group` is authoritative when the caller supplied one;
            // the `in.wishlist` fallback is what keeps an unmigrated caller -- and the
            // harness's existing assertions -- working unchanged.
            if (in.wl_mask != 0)
                return wishlist_allows(in.wl_group, in.wl_mask);
            return in.wishlist == kind::wishlist;
        case 3: // By-name item
            // A multi-select search selects the whole matched set, so an empty
            // set (no query, or a query that matched nothing) selects nothing --
            // the same answer an empty single selection gives below.
            if (in.selected_ids)
                return !in.selected_ids->empty()
                    && in.selected_ids->find(in.template_id ? in.template_id : "") != in.selected_ids->end();
            return in.selected_id && *in.selected_id
                && in.template_id && std::strcmp(in.template_id, in.selected_id) == 0;
        case 4: // Category ONLY -- the split half of the old option 2
            // Unconditional: an All category (index 0) is the caller saying "no category
            // restriction", which is not the same as "match everything". The old option 2
            // folded the wishlist half in as well, so a caller that wanted category-only
            // got wishlist items too.
            return in.category > 0
                && loot_category_allows(in.category_kind, in.category, in.allow_unknown_category);
        case 5: // Wishlist ONLY -- the other split half
            return in.wl_mask != 0 && wishlist_allows(in.wl_group, in.wl_mask);
        default:
            return true;
        }
    }
} // namespace item_categories
