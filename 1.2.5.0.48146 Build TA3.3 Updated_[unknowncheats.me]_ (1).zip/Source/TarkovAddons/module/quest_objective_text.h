#pragma once

// The half of the quest objective summary that has nothing to do with IL2CPP:
// what a row is CALLED, and how the rows are merged and ordered.
//
// Split out of quest_objectives.h for the same reason config/ConfigValue.h exists
// as its own header (tools/harness/README.md): the logic worth testing cannot be
// reached through a header that opens with the game's object model. This one has
// no Il2CppObject in it at all, so
// tools/harness/test_quest_objectives_text.cpp compiles it directly and needs
// neither a stub nor a game.
//
// The other half -- reading Conditions off a live quest -- stays in
// quest_objectives.h, which includes this.

#include <algorithm>
#include <cctype>
#include <cstddef>
#include <cstring>
#include <string>
#include <vector>

namespace quest_objectives {

    // One row of the checklist.
    //
    // has_count is false for a condition whose target is 1 with no progress yet:
    // "eliminate a Cultist Priest" is a tick box, and "0/1" beside it is noise on
    // a list that is mostly tick boxes. Once it has progress, or asks for more
    // than one, the number is what the player wants to see.
    struct objective
    {
        std::string text;
        int current = 0;
        int target = 0;
        bool done = false;
        bool has_count = false;
    };

    // A description is bounded before it reaches the card, because a quest that
    // asks for a long list of items produces a sentence with all of them in it
    // and the card has a fixed width.
    inline constexpr size_t kMaxTextLen = 160;

    // Verb and standalone label for a condition the game could not describe in
    // words. The verb is only used on that fallback path; when
    // FormattedDescription works, the row is the game's own sentence and none of
    // this is involved.
    //
    // Ordered most-derived first, because these are substring tests on the class
    // name and the inheritance chain runs the other way: ConditionPlaceBeacon
    // and ConditionLeaveItemAtLocation are both ConditionZone, so a Zone test in
    // front of them would relabel every beacon and item-drop as "Reach an area".
    struct text_plan
    {
        const char* verb;
        const char* fallback;
    };

    inline text_plan plan_for(const char* klass_name) {
        if (!klass_name) return {"Complete", "Objective"};

        if (strstr(klass_name, "PlaceBeacon")) return {"Place a beacon at", "Place a beacon"};
        if (strstr(klass_name, "LeaveItemAtLocation")) return {"Place", "Place an item"};
        if (strstr(klass_name, "VisitPlace") || strstr(klass_name, "LocationTrigger"))
            return {"Reach", "Reach a location"};
        if (strstr(klass_name, "ConditionZone") || strstr(klass_name, "InZone"))
            return {"Reach", "Reach an area"};
        if (strstr(klass_name, "TransitionLocation")) return {"Take the transit", "Use the transit"};
        if (strstr(klass_name, "HandoverItem")) return {"Hand over", "Hand over an item"};
        if (strstr(klass_name, "FindItem")) return {"Find", "Find an item"};
        if (strstr(klass_name, "SellItemToTrader")) return {"Sell", "Sell an item"};
        if (strstr(klass_name, "SearchAndDestroy") || strstr(klass_name, "ConditionKills")
            || strstr(klass_name, "ArenaEnemyPreset"))
            return {"Eliminate", "Eliminate the target"};
        if (strstr(klass_name, "ConditionHit")) return {"Hit", "Hit the target"};
        if (strstr(klass_name, "Shots")) return {"Fire", "Fire the required shots"};
        if (strstr(klass_name, "WeaponAssembly")) return {"Assemble", "Assemble a weapon"};
        if (strstr(klass_name, "Skill")) return {"Improve", "Improve a skill"};
        if (strstr(klass_name, "Experience")) return {"Gain experience in", "Gain experience"};
        if (strstr(klass_name, "TraderLoyalty") || strstr(klass_name, "TraderStanding"))
            return {"Raise standing with", "Raise trader standing"};
        if (strstr(klass_name, "PrestigeLevel") || strstr(klass_name, "ConditionLevel"))
            return {"Reach level", "Reach the required level"};
        if (strstr(klass_name, "LeagueRank")) return {"Reach league rank", "Reach the required rank"};
        if (strstr(klass_name, "ExitName") || strstr(klass_name, "ExitStatus"))
            return {"Extract via", "Extract through the required exit"};
        if (strstr(klass_name, "QuestTime") || strstr(klass_name, "ConditionTime"))
            return {"Survive", "Survive / wait"};
        if (strstr(klass_name, "Health")) return {"Keep health", "Health condition"};
        if (strstr(klass_name, "ConditionLocation")) return {"Reach", "Reach a location"};
        if (strstr(klass_name, "CompletableItem") || strstr(klass_name, "ConditionItem")
            || strstr(klass_name, "HasItem"))
            return {"Obtain", "Obtain an item"};

        return {"Complete", "Objective"};
    }

    // ConditionHit.target is a single string that may itself be a comma- or
    // semicolon-separated list ("Scavs,Usec"), and ConditionFindItem's is not
    // always an array, so splitting covers both shapes.
    //
    // Empty fields are dropped rather than kept: a trailing comma is not a
    // target, and an empty label would join as "" and render as a stray comma.
    inline void split_token_list(const std::string& text, std::vector<std::string>& out) {
        std::string token;
        for (const char c : text) {
            if (c == ',' || c == ';') {
                if (!token.empty()) out.push_back(token);
                token.clear();
                continue;
            }
            token.push_back(c);
        }
        if (!token.empty()) out.push_back(token);
    }

    inline std::string join_labels(const std::vector<std::string>& labels, const size_t limit = 3) {
        std::string joined;
        const size_t shown = (std::min)(limit, labels.size());
        for (size_t i = 0; i < shown; ++i) {
            if (i) joined += ", ";
            joined += labels[i];
        }
        if (labels.size() > shown) {
            joined += " +";
            joined += std::to_string(labels.size() - shown);
        }
        return joined;
    }

    // Truncate on a UTF-8 boundary. A description that is mostly a long item name
    // can otherwise be cut mid-codepoint, and ImGui then renders the tail as a
    // replacement character.
    inline void truncate_text(std::string& text) {
        if (text.size() <= kMaxTextLen) return;
        size_t cut = kMaxTextLen;
        while (cut > 0 && (static_cast<unsigned char>(text[cut]) & 0xC0) == 0x80) --cut;
        text.resize(cut);
    }

    // ASCII-only case folding, and NOT std::tolower.
    //
    // This is measured, not assumed. std::tolower is the C library's, and the C
    // library is in the "C" locale unless something calls setlocale -- nothing in
    // this project does, so it folds A-Z and returns every other byte unchanged.
    // A Russian quest label is stored as UTF-8, so its capital and lower-case
    // letters are DIFFERENT BYTES: "Тест" is D0 A2 D0 B5 D1 81 D1 82 and "тест"
    // is D0 B2 D0 B5 D1 81 D1 82. Comparing them through std::tolower gives 0 --
    // measured, not reasoned, and an assertion in
    // tools/harness/test_quest_objectives_text.cpp holds it there.
    //
    // Real Unicode case folding needs the game's own casing tables or a Unicode
    // data table, which is not worth carrying for this. What is actually needed
    // is narrower than it looks: two conditions of the SAME quest that mean the
    // same thing render through the same locale lookup, so their descriptions are
    // byte-identical and plain equality merges them. The case fold is a bonus for
    // the ASCII case (an item name differing only in case), not the mechanism.
    inline char fold_ascii(const char c) {
        const unsigned char u = static_cast<unsigned char>(c);
        return (u >= 'A' && u <= 'Z') ? static_cast<char>(u - 'A' + 'a') : c;
    }

    // This is the merge key, so what it decides is what two objectives collapse
    // into. It is deliberately asymmetric to a naive comparison: equal means
    // "same row", and two genuinely different objectives merging into one is a
    // wrong checklist entry, which is worse than two rows that could have been
    // one.
    inline bool same_label(const std::string& a, const std::string& b) {
        if (a.size() != b.size()) return false;
        for (size_t i = 0; i < a.size(); ++i)
            if (fold_ascii(a[i]) != fold_ascii(b[i])) return false;
        return true;
    }

    // "Summed up" is the point of this pass. A quest that asks for the same thing
    // in three separate conditions -- three item handovers, two kill conditions
    // on the same enemy -- is one line for the player, not five, with the counts
    // added. Without it the checklist is longer than the quest journal's and
    // strictly worse to read.
    //
    // done is the AND of the merged rows: a summed row is finished only when
    // every condition behind it is. OR-ing would show a quest as complete while
    // one of its three identical objectives is still outstanding.
    inline void merge_duplicates(std::vector<objective>& lines) {
        if (lines.size() < 2) return;

        std::vector<objective> merged;
        merged.reserve(lines.size());
        for (objective& line : lines) {
            auto it = std::find_if(merged.begin(), merged.end(),
                [&](const objective& existing) { return same_label(existing.text, line.text); });
            if (it == merged.end()) {
                merged.push_back(std::move(line));
                continue;
            }
            it->current += line.current;
            it->target += line.target;
            it->has_count = it->has_count || line.has_count;
            it->done = it->done && line.done;
        }
        lines = std::move(merged);
    }

    // What is left to do first. stable_sort so the order within each group is the
    // order the quest declares, which is the order the journal uses.
    inline void order_by_outstanding(std::vector<objective>& lines) {
        std::stable_sort(lines.begin(), lines.end(),
            [](const objective& a, const objective& b) {
                return static_cast<int>(a.done) < static_cast<int>(b.done);
            });
    }

    // ---------------------------------------------------------------- All-view shortfall
    //
    // Pure integer and boolean logic, in THIS header, because that is the only one of the two
    // quest_objectives headers with no IL2CPP in it and therefore the only one
    // tools/harness/test_quest_objectives_text.cpp can compile. The arithmetic below decides
    // how many of the player's own quests the card admits it is hiding, and before this it
    // lived in build_snapshot() where nothing could check it -- which is how it was wrong for
    // as long as it was wrong.
    //
    // The order the card RENDERS, as a rank. Lower is drawn first:
    //
    //   0  known && !zone_bound   "anywhere"   -- no map dependency at all
    //   1  known &&  zone_bound   "on this map"
    //   2  !known                  "unreadable" -- the conditions could not be walked
    //
    // This mirrors draw_menu_extra() exactly, and that is deliberate rather than
    // coincidental: a cap keeps the first N BY THIS RANK, so what it drops is the bottom of
    // what the player already reads. The quest_group::known comment records why the third
    // bucket exists -- conflating "unknown" with "not location-bound" claims an unreadable
    // quest is doable anywhere -- and a cap that dropped those first would be making the same
    // mistake about which quests are worth the raid.
    //
    // WHY LOCATION-BOUND IS NOT RANK 0, since the collect_all() comment argues the other way
    // ("on a map with 14 location-bound quests the cap kept twelve that cannot be done here
    // and dropped the ones that can"). That argument rests on deciding whether a quest's zone
    // belongs to the CURRENT map -- and location_binding_of()'s own comment says that needs
    // the game's zone-to-map table, and that guessing "would put quests in the wrong group".
    // Ranking on a distinction this file documents as unusable for exactly this purpose would
    // be acting on a signal that is not there. A non-location-bound quest is doable somewhere
    // with no further information; a location-bound one MIGHT be doable here. Rank 0 is the
    // one that is a real answer rather than an unknown.
    inline constexpr int kAllViewAnywhere = 0;
    inline constexpr int kAllViewZones = 1;
    inline constexpr int kAllViewUnreadable = 2;

    [[nodiscard]] inline int all_view_rank(bool known, bool zone_bound) {
        if (!known) return kAllViewUnreadable;
        return zone_bound ? kAllViewZones : kAllViewAnywhere;
    }

    // How many quests produced no rows at all, which is the shortfall the card reports as
    // "unreadable" and which is NOT the same thing as the cap having hidden some.
    //
    //     requested = shown + capped_away + unreadable
    //
    // `capped_away` is the number of quests THE CAP ACTUALLY DROPPED, not the cap's limit.
    //
    // THIS USED TO PASS kAllQuestCap, and that is a third distinct bug in the same three
    // lines. The cap was applied to the INPUT (all_quest_inputs_.resize), so the quests it
    // dropped were never offered to collect_all() and never became groups -- the true dropped
    // count is `requested - limit`, which is not the limit. On the 2026-10-08 profile, 36
    // listed, 24 shown, 12 actually dropped: the old expression computed
    // 36 - 24 - 24 = -12, clamped to 0, and printed "0 unreadable".
    //
    // That happens to be right on that profile because those quests really were all readable.
    // It is not right in general: with 4 genuinely unreadable quests it would read 36 - 24 -
    // 20 = -8, clamp, and print 0 when the answer is 4 -- the count that tells the player
    // four of their quests have no checklist at all. The comment above the old line described
    // fixing exactly this bug once already, and the fix reintroduced it in the same edit.
    //
    // Clamped because the three inputs are maintained at three different places in one
    // function and a negative answer is a bug in the bookkeeping, not a fact about the player.
    [[nodiscard]] inline int all_view_unreadable(int requested, int shown, int capped_away) {
        const int unreadable = requested - shown - capped_away;
        return unreadable < 0 ? 0 : unreadable;
    }

} // namespace quest_objectives