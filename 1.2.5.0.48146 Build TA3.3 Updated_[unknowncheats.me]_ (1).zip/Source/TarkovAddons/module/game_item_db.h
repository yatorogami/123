#pragma once

// Live item database — enumerates every ItemTemplate from the game's own
// ItemFactory (captured at raid init by ItemModule's hk_init_level hook),
// replacing the static assets/item_database.h snapshot that went stale and
// only covered EN/FR names.
//
// Path (dump-verified 2026-09-25):
//   EFT.ItemFactory.ItemTemplates (JsonType.ItemTemplates)
//     -> Dictionary<MongoID, EFT.InventoryLogic.ItemTemplate>
//
// Layout history (all AV-guarded now):
//   - MongoID = { uint32 _timeStamp, uint64 _counter, Il2CppString* _stringID }
//     = 24 bytes (IL-verified). Its string id is MongoID.ConvertToString =
//     timeStamp.ToString("X8") + counter.ToString("X16") — emitted lowercase
//     to match the id format already stored in saved configs.
//   - Dictionary entry = { int hashCode, int next, MongoID key, ItemTemplate* }
//     -> stride 40, value at +32. The earlier 32-byte assumption read each
//     key's _stringID as the value — sampling saw String objects, never
//     matched ItemTemplate, and the db came back silently empty.
//   - ItemTemplates may BE the dictionary (JsonType.ItemTemplates implements
//     the Dictionary<MongoID, ItemTemplate> enumeration directly — verified
//     via ItemFactory.CreateAllItemsEver passing `this.ItemTemplates` to
//     Enumerable.Where over KeyValuePair). The naive "reinterpret the object
//     as a Dictionary and read m_p_entries" shortcut caused the raid-load AV
//     (arbitrary field data at offset 24) and was removed wholesale — which
//     broke the db entirely: field discovery finds no Dictionary-typed FIELD
//     on the object because its own fields are the dictionary internals
//     (09-25 evening 4). The identity probe below re-enables that route
//     SAFELY: klass identity checked by NAME (ancestry/interface), then
//     layout guarded by readability, then content-sampled before use.

#include <atomic>
#include <format>
#include <memory>
#include <mutex>
#include <Windows.h>
#include <functional>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include "game_state.h"
#include "item_categories.h"
#include "../il2cpp/Il2CppObjectInstance.h"
#include "../il2cpp/il2utils.h"
#include "../util/logger.h"
#include "../util/tracy_bridge.h"

namespace game_items {
    struct entry
    {
        std::string id;
        std::string name;
        // ItemTemplate.QuestItem — a static template property (NOT "is loot for a
        // quest I have started", which is the separate active-quest filter).
        //
        // Recorded here so spawn pickers can exclude quest items while name lookups
        // keep working for quest items that legitimately appear in a raid. Quest
        // items are spawned by the Quest Completer's own path, not the generic
        // create-item UI.
        bool quest_item = false;
        // ItemTemplate.Width / Height, in grid cells. Resolved from the same template objects
        // the name already comes from, so the marginal cost is two field reads per template at
        // build time. Used to size a stack against a grid before asking the server to place it
        // (hideout result collection).
        //
        // 0 means "not resolved": ItemTemplate declares its size on a base class, and a server
        // that renames the backing field leaves these at 0 rather than guessing at a size.
        int width = 0;
        int height = 0;
        // The loot bucket, from the concrete ItemTemplate subclass. See
        // item_categories::loot and loot_from_template_class for why this is the type
        // and not a field, and for the precedence rules.
        //
        // One byte, resolved once at build time from a name that is already in the
        // class object. Deliberately NOT the class name as a std::string: 6,000
        // owning copies of a string the process already holds would be ~192 KB and a
        // second owner for data nothing would ever free.
        //
        // loot::unknown is a real value, not a default to ignore: it means the class
        // was not in the table, and the filter falls back rather than excluding.
        item_categories::loot loot_kind = item_categories::loot::unknown;
    };

    // ---- PUBLISHED DATABASE ------------------------------------------------
    // The entries and the id->index map travel together as one immutable
    // object, swapped in by a single pointer store.
    //
    // Two separate globals could not work, for two independent reasons.
    //
    //  1. Threads. localize_snapshot() runs on a DETACHED thread (prewarm) and
    //     used to rewrite entry::name in place, while the render thread read
    //     those std::strings through ItemSearchValue's menus and through
    //     name_by_id() from four module menus. build() meanwhile did
    //     `g_snapshot = std::move(out)`, freeing the very vector the
    //     localization thread was walking. That is the same use-after-free as
    //     the ESP skeleton crash, in a different file.
    //
    //  2. Consistency, even single-threaded. name_by_id() and dimensions() each
    //     need both halves; reading them as two globals could pair a freshly
    //     built vector with a stale index and read the wrong entry, or index
    //     past the end of the new one.
    struct db_snapshot
    {
        std::vector<entry> entries;
        // id -> index into entries (audit 09-25 #1: name_by_id was an O(N) scan
        // over ~every template, quadratic on the loot-scan fallback path).
        std::unordered_map<std::string, size_t> index;
    };
    using db_snapshot_ptr = std::shared_ptr<const db_snapshot>;

    // Held only while g_db is being read or replaced -- never across a build()
    // or a localization pass. Readers get a shared_ptr and are then lock-free.
    inline std::mutex g_publish_mutex;
    inline db_snapshot_ptr g_db = std::make_shared<const db_snapshot>();
    inline std::atomic<bool> g_built{false};
    // Backoff for the rebuild retry: snapshot() is called per loot item, and a
    // permanently-failing build() spammed ~60 debug lines/second (09-25 log).
    // Atomic because snapshot() is reachable from the render thread.
    inline std::atomic<ULONGLONG> g_last_build_fail_ms{0};

    // The one place the published database changes shape.
    inline void publish_snapshot(std::vector<entry>&& out) {
        auto next = std::make_shared<db_snapshot>();
        next->entries = std::move(out);
        next->index.reserve(next->entries.size());
        for (size_t i = 0; i < next->entries.size(); ++i)
            next->index.emplace(next->entries[i].id, i);
        {
            std::lock_guard<std::mutex> lock(g_publish_mutex);
            g_db = std::move(next);
        }
        g_built.store(true, std::memory_order_release);
    }

    // The currently published database, pinned for as long as the caller holds
    // the returned shared_ptr. Never null.
    inline db_snapshot_ptr current_snapshot() {
        std::lock_guard<std::mutex> lock(g_publish_mutex);
        return g_db;
    }

    struct mongo_id
    {
        uint32_t time_stamp;
        uint64_t counter;
        Il2CppString* string_id;  // ctor caches ConvertToString(_timeStamp, _counter)
    };

    // Mirror of Dictionary<MongoID, ItemTemplate>:
    // entry = { int hashCode, int next, MongoID key (24 B — _timeStamp/_counter/
    // _stringID, IL-verified), ItemTemplate* value } -> stride 40, value at +32.
    struct template_entry
    {
        int32_t hash;
        int32_t next;
        mongo_id key;
        Il2CppObject* value;
    };

    struct template_dict : Il2CppObject
    {
        Il2CppArray* m_p_buckets;
        Il2CppArray* m_p_entries;
        int m_i_count;
        int m_i_version;
        int m_i_free_list;
        int m_i_free_count;
        void* m_p_comparer;
        void* m_p_keys;
        void* m_p_values;
    };

    inline bool looks_like_item_template(Il2CppObject* obj) {
        return obj && obj->klass && obj->klass->name
            && strstr(obj->klass->name, "ItemTemplate") != nullptr;
    }

    // Local page-readability check (game_item_db.h must stay independent of eft_api).
    inline bool readable_range(const void* addr, size_t bytes) {
        if (!addr || bytes == 0) return false;
        constexpr DWORD ok = PAGE_READWRITE | PAGE_READONLY | PAGE_EXECUTE_READ |
                             PAGE_EXECUTE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_WRITECOPY;
        const auto* first = static_cast<const uint8_t*>(addr);
        const auto* last = first + bytes - 1; // inclusive last byte
        for (const auto* probe : {first, last})
        {
            MEMORY_BASIC_INFORMATION mbi{};
            if (!VirtualQuery(probe, &mbi, sizeof(mbi))) return false;
            if (mbi.State != MEM_COMMIT) return false;
            if (!(mbi.Protect & ok)) return false;
            const auto* region_end =
                reinterpret_cast<const uint8_t*>(mbi.BaseAddress) + mbi.RegionSize;
            if (last >= region_end) return false; // range crosses past this region
        }
        return true;
    }

    inline const char* safe_class_name(const Il2CppObject* obj) {
        return (obj && obj->klass && obj->klass->name) ? obj->klass->name : nullptr;
    }

    // Identity check by NAME only — no layout deref. True when the object's class
    // derives from Dictionary`2 (typeHierarchy) or implements IDictionary/
    // IDictionary`2 (interfaces). JsonType.ItemTemplates hits the interface route;
    // a genuine Dictionary<MongoID, ItemTemplate> hits the ancestry route.
    inline bool klass_looks_like_dictionary(const Il2CppClass* klass) {
        if (!klass) return false;
        if (klass->typeHierarchy && klass->typeHierarchyDepth > 0)
        {
            for (uint8_t i = 0; i < klass->typeHierarchyDepth; ++i)
            {
                const Il2CppClass* base = klass->typeHierarchy[i];
                if (base && base->name && strcmp(base->name, "Dictionary`2") == 0)
                    return true;
            }
        }
        if (klass->implementedInterfaces && klass->interfaces_count > 0)
        {
            for (uint16_t i = 0; i < klass->interfaces_count; ++i)
            {
                const Il2CppClass* itf = klass->implementedInterfaces[i];
                if (!itf || !itf->name) continue;
                if (strcmp(itf->name, "IDictionary`2") == 0
                    || strcmp(itf->name, "IDictionary") == 0)
                    return true;
            }
        }
        return false;
    }

    // TRUE validation that a candidate object can be read with the template_dict
    // layout: identity by name, then every deref below is readability-guarded.
    // Content sampling (ItemTemplate values) happens here too, so a false
    // identity can never survive into enumeration.
    inline bool try_as_template_dictionary(Il2CppObject* obj, template_dict** out_dict) {
        *out_dict = nullptr;
        if (!obj || !obj->klass) return false;
        if (!klass_looks_like_dictionary(obj->klass)) return false;
        if (!readable_range(obj, sizeof(template_dict))) return false;

        auto* d = reinterpret_cast<template_dict*>(obj);
        if (!d->m_p_entries) return false;

        // Real Il2CppArray layout (il2cpp-object-internals.h): max_length at +0x18.
        if (!readable_range(d->m_p_entries, sizeof(Il2CppArray))) return false;
        if (d->m_p_entries->max_length == 0
            || d->m_p_entries->max_length > 100000) // absurd count => not this layout
            return false;
        if (!readable_range(&d->m_p_entries->data,
                            static_cast<size_t>(d->m_p_entries->max_length) * sizeof(template_entry)))
            return false;

        auto* entries = reinterpret_cast<const template_entry*>(&d->m_p_entries->data);
        // Content sample: ItemTemplate values AND MongoID keys. The value check
        // alone was fooled once (stride-32 era read _stringID as the value).
        // The entire entries array is already validated readable above, so we
        // can skip per-probe readability checks.
        const int n = static_cast<int>(d->m_p_entries->max_length);
        const int probes[3] = {0, n / 2, n - 1};
        int template_hits = 0;
        int key_hits = 0;
        for (int pi = 0; pi < 3; ++pi)
        {
            const template_entry& e = entries[probes[pi]];
            if (e.value && e.value->klass && looks_like_item_template(e.value))
                ++template_hits;
            if (e.key.time_stamp != 0)
                ++key_hits;
        }
        if (template_hits == 0) return false; // keys-only is not enough to enumerate names

        *out_dict = d;
        return true;
    }

    // Upgrade already-collected names through a localizer.
    //
    // The enumeration above reads <_name>k__BackingField, which the ISIL dump
    // shows is a plain stored string (get__name() is a trivial getter) and NOT
    // the display name: ItemTemplate carries a separate get_NameLocalizationKey().
    // So a raw snapshot is the template/design name and consumers that fall back
    // to the 24-hex id when a name is missing show users an internal identifier.
    //
    // The localizer is injected rather than called directly so this header keeps
    // its stated independence from eft_api (see readable_range). Callers pass the
    // game's own LocalizationExtensions.LocalizedShortName path, which resolves
    // per-locale display names.
    //
    // Only replaces a name when the localizer returns something non-empty, so a
    // failed lookup degrades to the raw template name instead of to an empty
    // string (and therefore to the id at the call sites).
    //
    // Reports `resolved` and `changed` SEPARATELY, and the distinction matters:
    //
    //   resolved = the localizer returned a non-empty name  -> the real health
    //              signal. Stable across passes.
    //   changed  = the stored name actually differed        -> a TRANSITION count.
    //
    // These diverge on every pass after the first. The snapshot is a process-wide
    // global and the localization cache is cleared between raids
    // (EspModule::clear_runtime_cache), so pass 2 re-resolves all ~6000 keys from
    // scratch -- gets the same answers -- and therefore changes nothing. Reporting
    // only `changed` made that print "localized 0/5963", which reads as total
    // failure but in fact means "already correct, nothing to do". It is equally
    // consistent with every lookup FAILING, so the line carried no information at
    // exactly the moment it was most alarming. (Observed 2026-09-26.)
    struct localize_stats {
        size_t total = 0;
        size_t resolved = 0;
        size_t changed = 0;
    };

    // Localizes a COPY and publishes it. It must not touch the published
    // database in place: this runs on a detached thread while the render thread
    // reads the current names. The copy costs one deep copy of ~6k entries on
    // the background thread, which is exactly the work the thread exists to
    // keep off raid start.
    inline localize_stats localize_snapshot(const std::function<std::string(const std::string&)>& localizer) {
        TA_ZONE_N("game_item_db::localize_snapshot");
        localize_stats st{};
        const db_snapshot_ptr current = current_snapshot();
        if (!localizer || current->entries.empty()) return st;

        std::vector<entry> upgraded = current->entries;
        st.total = upgraded.size();
        for (entry& e : upgraded)
        {
            if (e.id.empty()) continue;
            std::string localized;
            try {
                localized = localizer(e.id);
            } catch (...) {
                continue; // a throwing localizer must not take down the snapshot
            }
            if (localized.empty()) continue;
            ++st.resolved;
            if (localized != e.name)
            {
                e.name = std::move(localized);
                ++st.changed;
            }
        }

        // Only publish if nothing replaced the database while we were working.
        // Otherwise this pass is describing a generation that no longer exists
        // and would resurrect a pre-build database (or worse, one built from a
        // different ItemFactory).
        {
            std::lock_guard<std::mutex> lock(g_publish_mutex);
            if (g_db != current) return st;
            auto next = std::make_shared<db_snapshot>();
            next->entries = std::move(upgraded);
            // Ids are untouched by localization, so the index carries over.
            next->index = current->index;
            g_db = std::move(next);
        }
        return st;
    }

    // Walk a validated dictionary and append {id, name, quest_item} for every
    // ItemTemplate. Returns the number of named entries produced.
    inline size_t enumerate_template_dictionary(Il2CppObject* dict_obj, std::vector<entry>& out) {
        auto* dict = reinterpret_cast<template_dict*>(dict_obj);
        auto* entries = reinterpret_cast<const template_entry*>(&dict->m_p_entries->data);
        const int n = static_cast<int>(dict->m_p_entries->max_length);

        // Resolve fields once before the loop — all templates share the same class,
        // so there's no need to check per-iteration. resolve_field walks the parent
        // chain, so Width/Height on a base class are found on the first call.
        const FieldInfo* name_field = nullptr;
        const FieldInfo* quest_field = nullptr;
        const FieldInfo* width_field = nullptr;
        const FieldInfo* height_field = nullptr;

        // How far up Il2CppClass::parent to walk when classifying a template. The real
        // hierarchy is 8 deep at most among the 130 classes GameDump lists, so 24 is
        // slack -- and the bound is a guard against a malformed image turning this into
        // a spin.
        constexpr int kMaxTemplateDepth = 24;

        // Find the first valid template to resolve fields from
        for (int i = 0; i < n; ++i)
        {
            Il2CppObject* tpl = entries[i].value;
            if (!tpl || !tpl->klass) continue;
            name_field = il2utils::resolve_field(tpl->klass, "<_name>k__BackingField");
            quest_field = il2utils::resolve_field(tpl->klass, "QuestItem");
            width_field = il2utils::resolve_field(tpl->klass, "Width");
            height_field = il2utils::resolve_field(tpl->klass, "Height");
            break;
        }

        size_t named = 0;
        size_t scanned = 0;         // entries that reached the class-name read
        // Concrete template class per entry, tallied. Diagnostic only - see the note
        // on the summary below. The per-entry category is resolved into the one-byte
        // `entry::loot_kind`; this map exists only to prove the read works and to show
        // what the taxonomy actually is for this game version.
        std::unordered_map<std::string, size_t> by_class;
        // Entries per class that the walk could NOT classify. Kept separately from a
        // second guess about the table, because a second guess is exactly what broke:
        // the first version marked classes with loot_class_is_known(leaf), which only
        // ever asked "is this LEAF a family root". Now that classification walks the
        // base chain, MagazineTemplate is mapped through ModTemplate and would have
        // been marked [?] anyway -- the mark inverts as the table improves. Counted from
        // the scan, the mark cannot lie about what actually happened.
        std::unordered_map<std::string, size_t> by_class_unmapped;
        size_t unknown_class = 0;   // entries whose class is not in the category table
        for (int i = 0; i < n; ++i)
        {
            const template_entry& e = entries[i];
            Il2CppObject* tpl = e.value;
            if (!tpl || !tpl->klass) continue;

            entry out_entry;
            // Hidden/dev entries: MongoID(0,0) — skip.
            if (e.key.time_stamp == 0 && e.key.counter == 0) continue;
            // The object header is already dereferenced by the guard above, and
            // Il2CppClass::name is in the always-valid block (image+0x10), so this
            // costs one load from a pointer the loop already trusts and needs no
            // new guard. Never localized, unlike `name`.
            if (const char* cn = tpl->klass->name)
            {
                ++scanned;
                ++by_class[cn];
                // Classify by walking the BASE chain, not by matching the leaf name.
                // The chain is walked from tpl->klass up through ->parent, which is the
                // same walk il2utils::resolve_field already does for inherited fields,
                // and it is why a new AssaultWhateverTemplate needs no table entry here:
                // it is a weapon because it derives from WeaponTemplate.
                const char* chain[kMaxTemplateDepth];
                size_t depth = 0;
                for (const Il2CppClass* k = tpl->klass; k && depth < kMaxTemplateDepth;
                     k = k->parent)
                    chain[depth++] = k->name;
                out_entry.loot_kind = item_categories::loot_from_ancestry(chain, depth);
                if (out_entry.loot_kind == item_categories::loot::unknown) {
                    ++unknown_class;
                    ++by_class_unmapped[cn];
                }
            }
            out_entry.id = std::format("{:08x}{:016x}", e.key.time_stamp, e.key.counter);
            if (name_field)
            {
                auto* name = *reinterpret_cast<Il2CppString**>(
                    reinterpret_cast<uintptr_t>(tpl) + name_field->offset);
                out_entry.name = il2utils::conv_string(name);
            }
            // Per-entry readability checks are redundant: try_as_template_dictionary()
            // already validated the entire entries array is readable, and the content
            // sampling confirmed the values are valid ItemTemplate objects. The fields
            // are at fixed offsets from the template pointer — if the template object
            // is valid, its fields are valid. Removing ~24,000 VirtualQuery calls
            // per raid init (6000 templates x 4 field checks).
            if (quest_field && quest_field->offset > 0)
            {
                const auto* flag = reinterpret_cast<const uint8_t*>(tpl) + quest_field->offset;
                out_entry.quest_item = *reinterpret_cast<const bool*>(flag);
            }
            if (width_field && width_field->offset > 0)
            {
                const auto* slot = reinterpret_cast<const uint8_t*>(tpl) + width_field->offset;
                out_entry.width = *reinterpret_cast<const int*>(slot);
            }
            if (height_field && height_field->offset > 0)
            {
                const auto* slot = reinterpret_cast<const uint8_t*>(tpl) + height_field->offset;
                out_entry.height = *reinterpret_cast<const int*>(slot);
            }
            if (!out_entry.name.empty())
            {
                out.push_back(std::move(out_entry));
                ++named;
            }
        }

        // The tally summary. Emitted from inside this function because both callers
        // (object-as-dictionary and field route) funnel through here, so this cannot
        // be forgotten by one path and duplicated by the other.
        //
        // Why this exists: the Loot Teleporter's eight categories were eight
        // substring lists over the item's LOCALIZED display name, and they had five
        // provable defects (Valuables a strict subset of Barter; Barter unbounded;
        // Ammo unable to see a calibre; overlapping buckets; English needles against
        // a translated name). The fix is to read the concrete template class instead,
        // because the category is not a field - it IS the type. `propertiesType` in
        // the community items.json was the discriminated-union tag for exactly this,
        // and ItemTemplate.TemplateSerializer : PolymorphicSerializer<ItemTemplate,
        // string> is the game doing the same thing.
        //
        // This line is the evidence that the read works and what the real taxonomy is.
        // Without it the whole scheme would rest on a reading of dump.cs and a struct
        // layout, which is exactly the kind of evidence that turned out to be wrong
        // once already (see AGENTS_TODO.md 5.12 and 5.13).
        if (!by_class.empty())
        {
            std::vector<std::pair<std::string, size_t>> rows(by_class.begin(), by_class.end());
            std::sort(rows.begin(), rows.end(),
                [](const auto& a, const auto& b) {
                    return a.second != b.second ? a.second > b.second : a.first < b.first;
                });
            // One line, not one per class. 6,000 entries is fine to walk and would
            // be 40 lines of log on every raid.
            std::string joined;
            size_t shown = 0;
            for (const auto& [cls, count] : rows)
            {
                if (shown++ == 12) {
                    joined += " ...(+" + std::to_string(rows.size() - 12) + " more)";
                    break;
                }
                if (!joined.empty()) joined += ", ";
                joined += cls + "=" + std::to_string(count);
                // Marked from the scan, not from a second opinion about the table. If
                // this build ever moves the hierarchy, the unmapped classes show up
                // here by name rather than the loot silently falling out of every
                // category filter.
                const auto it = by_class_unmapped.find(cls);
                if (it != by_class_unmapped.end() && it->second)
                    joined += "[" + std::to_string(it->second) + " unmapped]";
            }

            // Then EVERY unmapped class, because the truncated list above hid 112 of
            // them and that is how a table covering 33% of a raid survived review: the
            // evidence needed to disprove it was in the log the whole time, one page
            // down. Bounded, so a badly broken table cannot produce a megabyte.
            std::vector<std::pair<std::string, size_t>> unmapped_rows(
                by_class_unmapped.begin(), by_class_unmapped.end());
            std::sort(unmapped_rows.begin(), unmapped_rows.end(),
                [](const auto& a, const auto& b) {
                    return a.second != b.second ? a.second > b.second : a.first < b.first;
                });
            std::string unmapped_list;
            constexpr size_t kMaxUnmappedListed = 48;
            for (size_t i = 0; i < unmapped_rows.size() && i < kMaxUnmappedListed; ++i)
            {
                if (!unmapped_list.empty()) unmapped_list += ", ";
                unmapped_list += unmapped_rows[i].first + "=" +
                                 std::to_string(unmapped_rows[i].second);
            }
            if (unmapped_rows.size() > kMaxUnmappedListed)
                unmapped_list += " ...(+" + std::to_string(unmapped_rows.size() -
                                                            kMaxUnmappedListed) + " more)";

            logger::info(std::format(
                "game item db: {} distinct template classes, {}/{} entries mapped to a "
                "category ({} unmapped) - {}\n"
                "game item db: {} of {} classes unmapped: {}",
                rows.size(), scanned - unknown_class, scanned, unknown_class, joined,
                unmapped_rows.size(), rows.size(),
                unmapped_list.empty() ? "(none)" : unmapped_list));
        }
        return named;
    }

    inline void build() {
        // The game_item_db::build zone was removed here. The 2026-10-01 profile
        // measured it at 7.7 ms over ONE call with no children -- 0.0014% of a
        // 543 s session -- and it was nested inside prewarm, whose own inclusive
        // was 7.85 ms. Two zone names for a single ~8 ms startup event, on a path
        // that runs once per raid. localize_snapshot, which is the expensive part
        // of this file at 30.7 s, keeps its zone and is unaffected: prewarm runs it
        // on a background thread, so it was never inside either zone.
        Il2CppObject* factory = game_state::item_factory;
        if (!factory || !factory->klass) return; // retry on next draw until raid init

        const FieldInfo* itf = il2utils::resolve_field(factory->klass, "ItemTemplates");
        if (!itf) return;
        auto* item_templates = *reinterpret_cast<Il2CppObject**>(
            reinterpret_cast<uintptr_t>(factory) + itf->offset);
        if (!item_templates || !item_templates->klass) return;

        // Route 1 — the ItemTemplates object itself is the dictionary (the
        // CreateAllItemsEver evidence). Every deref is guarded inside; a plain
        // non-dictionary object fails the name/interface identity check and
        // never reaches layout reads (the 09-25 raid-load AV is unreachable).
        template_dict* self_dict = nullptr;
        if (try_as_template_dictionary(item_templates, &self_dict))
        {
            std::vector<entry> out;
            const size_t named = enumerate_template_dictionary(item_templates, out);
            if (named > 0)
            {
                // Entries and index are published together, so a lookup can
                // never pair a new vector with a stale map.
                const size_t built = out.size();
                publish_snapshot(std::move(out));
                logger::debug(std::format(
                    "game item db: {} templates from live ItemFactory (object-as-dictionary)",
                    built));
                return;
            }
            logger::debug("game item db: ItemTemplates is a dictionary but yielded no named templates");
        }

        // Route 2 — a dictionary-valued FIELD on the ItemTemplates class, its
        // ancestors, or the factory class. Each candidate object is fully
        // validated (identity + readability + content sample) before use, so a
        // wrong guess degrades to a skip, never to a deref of arbitrary data.
        Il2CppObject* dict_obj = nullptr;
        const Il2CppClass* chain[4] = {
            item_templates->klass,
            item_templates->klass->parent,
            factory->klass,
            factory->klass->parent,
        };
        for (const Il2CppClass* klass : chain)
        {
            if (!klass || !klass->fields) continue;
            for (int fi = 0; fi < klass->field_count; ++fi)
            {
                const FieldInfo& f = klass->fields[fi];
                if (!f.type || f.type->type != 0x15 /* IL2CPP_TYPE_GENERICINST */) continue;
                const auto* gc = static_cast<const Il2CppGenericClass*>(f.type->data.generic_class);
                if (!gc || !gc->cached_class || !gc->cached_class->name) continue;
                if (strcmp(gc->cached_class->name, "Dictionary`2") != 0) continue;
                if (f.offset <= 0) continue;
                if (!readable_range(
                        reinterpret_cast<const uint8_t*>(item_templates) + f.offset,
                        sizeof(void*)))
                    continue;

                auto* cand = *reinterpret_cast<Il2CppObject**>(
                    reinterpret_cast<uintptr_t>(item_templates) + f.offset);
                template_dict* validated = nullptr;
                if (cand && cand != item_templates
                    && try_as_template_dictionary(cand, &validated))
                {
                    dict_obj = cand;
                    break;
                }
            }
            if (dict_obj) break;
        }

        if (!dict_obj)
        {
            // Route 2 fail is class-shape-specific: report the actual leaf class so
            // the next log names the shape we missed.
            logger::debug(std::format(
                "game item db: no usable Dictionary<MongoID, ItemTemplate> (leaf class '{}', identity route {})",
                safe_class_name(item_templates) ? safe_class_name(item_templates) : "?",
                self_dict ? "matched but empty" : "not matched"));
            return;
        }

        std::vector<entry> out;
        const size_t named = enumerate_template_dictionary(dict_obj, out);
        if (named == 0)
        {
            logger::debug("game item db: dictionary field validated but yielded no named templates");
            return; // keep retrying; the dictionary was there but unreadable
        }

        // Build the id->index map as part of the same publish, so a lookup can
        // never see a new vector with a stale (or half-built) index.
        const size_t built = out.size();
        publish_snapshot(std::move(out));
        logger::debug(std::format(
            "game item db: {} templates from live ItemFactory (field route)", built));
    }

    // Returns the published database by shared_ptr, so the caller keeps it
    // alive for as long as it holds the result. Never null, and always a
    // consistent (entries, index) pair.
    inline db_snapshot_ptr snapshot() {
        if (!g_built.load(std::memory_order_acquire))
        {
            // Retry backoff: builds run per loot item via name_by_id; a failing
            // build() must not retry per call (60 lines/sec of debug spam).
            if (g_last_build_fail_ms.load(std::memory_order_relaxed) != 0)
                return current_snapshot();
            g_last_build_fail_ms.store(GetTickCount64(), std::memory_order_relaxed);
            build();
            if (g_built.load(std::memory_order_acquire))
                g_last_build_fail_ms.store(0, std::memory_order_relaxed);
        }
        return current_snapshot();
    }

    // Build the snapshot now and upgrade its names through `localizer`.
    //
    // Called from the ItemFactory capture point (ItemModule's InitLevel hook)
    // rather than lazily from the first loot-item lookup, so the db is complete
    // and localized before the first ESP draw instead of after it. That removes
    // the window where consumers hit an empty name and fall back to the 24-hex
    // id (EspModule::lookup_item_db_name) or match the category filter against
    // an empty string (loot_ui_filter_allowed).
    //
    // Safe to call repeatedly: the snapshot is built once and then re-localized on
    // each raid, because the localization cache is cleared between raids. A repeat
    // pass is expected to resolve the same names and therefore CHANGE nothing --
    // that is a success, not a regression. Deliberately runs AFTER the hooked
    // ItemFactory init returns — the template dictionary is not populated until
    // then, so building earlier yields an empty db.
    inline void prewarm(const std::function<std::string(const std::string&)>& localizer) {
        // Zone removed alongside game_item_db::build -- see the note there. This
        // function's whole inclusive cost was 7.85 ms and its self cost 0.14 ms;
        // the 30.7 s of localize_snapshot it starts runs on a detached thread and
        // was never inside this scope.
        if (!g_built.load(std::memory_order_acquire)) build();
        if (!g_built.load(std::memory_order_acquire))
            return; // factory absent or unreadable; snapshot() keeps retrying

        // Run localization on a background thread to avoid blocking raid start.
        // The snapshot is already built (enumeration is fast), so the game can
        // start with raw names and the localization happens in the background.
        // The localizer is copied into the thread, so it must be copyable.
        std::thread([localizer]() {
            const localize_stats st = localize_snapshot(localizer);
            if (st.total == 0) return;

            // `resolved` is the health metric: a LOW count is the signal that the
            // localization key format is wrong again, which is otherwise invisible because
            // the raw `_name` slug still displays.
            //
            // Logged on CHANGE only. prewarm runs once per GameWorld.InitLevel, i.e. once
            // per raid, and `resolved` is stable for a given game build -- so an
            // unconditional line printed a byte-identical duplicate every raid and read as
            // a double pass (observed 2026-09-26: the same 5911/5963 line 4.5 min apart,
            // which was genuinely two raids, not two passes over one raid).
            //
            // A genuine change still logs at INFO, so a build that starts failing
            // localization -- or starts resolving the previously-unresolved tail -- is
            // visible without waiting for a count to move.
            static size_t s_last_resolved = static_cast<size_t>(-1);
            static size_t s_last_total = 0;
            if (st.resolved != s_last_resolved || st.total != s_last_total)
            {
                s_last_resolved = st.resolved;
                s_last_total = st.total;
                if (st.resolved < st.total)
                {
                    logger::info(std::format(
                        "game item db: localized {}/{} template names ({} still show the raw template slug)",
                        st.resolved, st.total, st.total - st.resolved));
                }
                else
                {
                    logger::info(std::format(
                        "game item db: localized {}/{} template names (all resolved)", st.resolved,
                        st.total));
                }
            }

            // Spell out `changed` explicitly so "0 changed" reads as "already localized"
            // rather than as the catastrophic failure it superficially resembles. This is
            // the line that distinguishes "one pass, already correct" from "two passes".
            logger::debug(std::format(
                "game item db: name pass resolved {}/{}, changed {}", st.resolved, st.total,
                st.changed));
        }).detach();
    }

    inline std::string name_by_id(const std::string& id) {
        if (id.empty()) return {};
        // One snapshot for both halves of the lookup, so the index cannot
        // belong to a different generation than the vector it indexes into.
        const db_snapshot_ptr db = snapshot();
        const auto it = db->index.find(id);
        return it != db->index.end() ? db->entries[it->second].name : std::string{};
    }

    // The loot bucket for a template id, or loot::unknown if it is not in the
    // database or its class is not in the category table.
    //
    // Sibling of name_by_id() and on purpose: same snapshot-for-both-halves rule, so
    // the index cannot belong to a different generation than the vector it indexes.
    // The Loot Teleporter filter calls this per loot item per frame, which is why it
    // returns the one-byte enum rather than the name.
    inline item_categories::loot loot_kind_by_id(const std::string& id) {
        if (id.empty()) return item_categories::loot::unknown;
        const db_snapshot_ptr db = snapshot();
        const auto it = db->index.find(id);
        return it != db->index.end() ? db->entries[it->second].loot_kind
                                     : item_categories::loot::unknown;
    }

    // True when the template is flagged QuestItem. Used by spawn pickers to keep
    // quest items out of the generic create-item UI — the Quest Completer spawns
    // those through its own path. Name lookups deliberately do NOT consult this, so
    // ESP/LootTeleport still resolve names for quest items found in a raid.

    // Grid footprint of one item template, in cells (width * height). Returns false when the
    // template is unknown or its size did not resolve — callers must treat that as "size
    // unknown" and fall back, never as "zero cells", which would make any capacity check
    // pass vacuously.
    inline bool dimensions(const std::string& id, int& width, int& height) {
        width = 0;
        height = 0;
        if (id.empty()) return false;
        const db_snapshot_ptr db = snapshot();
        const auto it = db->index.find(id);
        if (it == db->index.end()) return false;
        const entry& found = db->entries[it->second];
        if (found.width <= 0 || found.height <= 0) return false;
        width = found.width;
        height = found.height;
        return true;
    }
} // namespace game_items
