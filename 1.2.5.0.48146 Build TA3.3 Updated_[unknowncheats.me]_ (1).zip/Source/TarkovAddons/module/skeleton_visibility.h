#pragma once

// The `[CLEANUP-PENDING:OPTICS]` freeze that used to open this file is GONE:
// the optics rework landed and the user lifted the freeze on 2026-10-13
// (AGENTS.md, "Do not touch"). A dead-code pass had found two unreferenced
// helpers here, `is_finite` and `estimate_ricochet_chance` (the latter a
// deliberate shim left over from the P(deflect) = 1 - |cos(incidence)|
// correction, kept "for compatibility" with nothing ever calling it). **Both
// were DELETED 2026-10-13**, once the freeze lifted; `assess_ricochet` is the
// live derivation the shim wrapped, and the "magnitude is deliberately NOT an
// input" fact it carried is recorded in CLEANUP_AUDIT.md section 2.3.
//
// ---------------------------------------------------------------------------
// SCOPE OF THE FILE, and the INCLUDE_AIMBOT SPLIT inside it
// ---------------------------------------------------------------------------
// This header serves TWO consumers with very different needs:
//
//   ESP visibility  -- is_target_visible + try_get_visibility_origin, needed by
//                      EVERY build (skeleton/box ESP is not aimbot-gated).
//   Magic Aim       -- is_target_visible_penetrating, the BallisticCollider
//                      model and the multi-layer walk, needed ONLY when the
//                      aimbot is compiled in.
//
// The penetration half used to compile unconditionally, which contradicted the
// whole point of the flavour split: `Prod no aimbot` defines no INCLUDE_AIMBOT,
// yet it still shipped classify_blocker, assess_ricochet, terrain_ballistic_at,
// the Shot.TryGetBallisticCollider resolution and the entire 630-line layer
// walk -- with no caller for any of it, because AimbotModule.cpp is the only
// caller and it is guarded out. Worse, `ensure_penetration_init()` was reached
// from `ensure_init()` via ESP's `is_ready()`, so even the BallisticCollider
// class + System.Type lookup still ran in a build that cannot use it.
//
// So the PENETRATION MODEL is inside `#ifdef INCLUDE_AIMBOT` and the plain
// visibility half is not. Two deliberate exceptions, both of which look like
// inconsistencies and are not:
//
//   * The counter STORAGE and the breakdown REPORTER stay unguarded. ESP owns
//     `maybe_report_hit_breakdown()`, and a reporter that half-compiled would
//     either need a second report line for the same 30 s window or would lose
//     the self-check. Storing two `unsigned long long[16]` costs nothing; the
//     pen counters simply stay at zero in a no-aimbot build, and the reporter
//     says so rather than omitting the field.
//
//   * `try_get_fireport_position` stays unguarded. It is aimbot-only by
//     *intent*, but `try_get_visibility_origin` (ESP) calls it as its second
//     choice of origin, so guarding it would break the ESP path.
//
// Verified before splitting: every penetration symbol below is referenced only
// from this file. `readable_range` has an independent copy in game_item_db.h,
// which is why the guarded one here can go without touching that file.

#include "../il2cpp/Il2CppObjectInstance.h"
#include "../il2cpp/il2utils.h"
#include "../il2cpp/unity.h"
#include "../util/logger.h"
#include "../util/tracy_bridge.h"
// Required by skeleton_vis::read_ballistic_identity, which gates every managed call
// it makes on eft_api::is_readable_address_cached -- the memo that took the
// VirtualQuery guard from 8% of wall clock to 0.07%. That guard is what stops the
// penetration walk faulting inside a managed method on a collider that has already
// been freed; see the note on the function and AGENTS_TODO.md 5.7f.
//
// No cycle -- eft_api.h does not include this header.
#include "eft_api.h"

#include <algorithm>
#include <cmath>
#include <format>
#include <limits>
#include <string>

// Skeleton line-of-sight via EFT PhysicsExtensions.Linecast (safer than raw Unity Physics.Linecast).
namespace skeleton_vis {
    // int, NOT float. Changed to float at some point in the working tree (2026-10-03,
    // not by the probe work) and reverted here. A LayerMask is a 32-bit bitmask; holding
    // one in a float is wrong on its face, and it emitted the build's only two
    // warnings -- `return` and `initialization`, C4244, float -> int -- in a tree whose
    // documented invariant is 0 errors and 0 code warnings.
    //
    // It happened to be harmless for this ONE value, which is worth recording so the
    // fix is not mistaken for a behaviour change: 0x80400000 = 2,151,677,952, and that
    // is 8,404,992 * 2^8 with 8,404,992 < 2^24, so it IS exactly representable in a
    // float32 and round-trips through one without loss. A mask with any of the low 8
    // bits set would NOT be, and would silently zero them. That is the trap.
    inline constexpr int fallback_layer_mask = static_cast<int>(0x80400000u);
    inline constexpr int query_ignore_triggers = 1; // QueryTriggerInteraction.Ignore

    /**
     * Whether the penetration walk raycasts with the game's bullet HitMask.
     *
     * TRUE, and it was briefly turned off on a wrong inference -- see the note at the
     * mask selection in is_target_visible_penetrating.
     */
    inline constexpr bool kUseBulletHitMask = true;

    // Page-readability check for guarded pointer dereferences (AV hardening).
    //
    // Zoned because this is a RAW VirtualQuery: it does not go through
    // eft_api::is_readable_address, so it appears in neither that zone's 680,325
    // calls nor its probe_scoped counters. The probe picture was therefore known to
    // be incomplete, and this path is per-raycast on a per-target frame path, where
    // a VirtualQuery measured at ~114 us mean is not a rounding error.
    //
    // Aimbot-gated: its only caller is the penetration walk's GetComponentInParent
    // fallback. game_item_db.h carries its own independent copy for its own use.
#ifdef INCLUDE_AIMBOT
    inline bool readable_range(const void* addr, size_t bytes) {
        TA_ZONE_N("skeleton_vis::readable_range");
        if (!addr || bytes == 0) return false;
        MEMORY_BASIC_INFORMATION mbi{};
        if (!VirtualQuery(addr, &mbi, sizeof(mbi))) return false;
        if (mbi.State != MEM_COMMIT) return false;
        constexpr DWORD ok = PAGE_READWRITE | PAGE_READONLY | PAGE_EXECUTE_READ |
                             PAGE_EXECUTE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_WRITECOPY;
        return (mbi.Protect & ok) != 0;
    }
#endif // INCLUDE_AIMBOT

    struct layer_mask_field
    {
        int m_mask = 0;
    };

    // Local struct for EFT PhysicsExtensions.Linecast (uses custom RaycastHit layout)
    struct raycast_hit
    {
        unity::vector3 m_point{};
        unity::vector3 m_normal{};
        uint32_t m_face_id = 0;
        float m_distance = 0.f;
        unity::vector2 m_uv{};
        int m_collider_instance_id = 0;
    };

    using linecast_ext_sig = bool (*)(unity::vector3, unity::vector3, int, int, raycast_hit*);
    using hit_get_transform_sig = Il2CppObject* (*)(raycast_hit*);
    using transform_get_parent_sig = Il2CppObject* (*)(Il2CppObject*);

    inline bool g_initialized = false;
    inline linecast_ext_sig g_linecast = nullptr;
    inline hit_get_transform_sig g_hit_get_transform = nullptr;
    inline transform_get_parent_sig g_transform_get_parent = nullptr;

    // =======================================================================
    // Fireport cost, windowed. Read the comment at
    // `try_get_fireport_position` before changing anything here -- the reason
    // this exists is that the Tracy zone cannot answer the only question that
    // matters about it.
    //
    // Accumulator: plain counters, no atomics. Written on the game thread only
    // (`hk_game_world_update` -> `ModuleManager::apply`), read by the reporter
    // on the same thread. The four call sites of `try_get_fireport_position`
    // are all inside `gameworld_update` or behind their own `is_in_raid` check
    // -- verified 2026-10-04 -- so there is no second writer to race with. If
    // that ever changes these MUST become relaxed atomics, because a torn
    // 64-bit add would silently under-report the thing this exists to measure.
    // =======================================================================
    struct fireport_window_t {
        unsigned long long calls = 0;
        unsigned long long total_ns = 0;
        unsigned long long max_ns = 0;
        unsigned long long last_report_ms = 0;
        long long freq = 0;
        // Regime counters. See report_fireport_window() for why the mean is not the
        // number to act on: the function is bimodal by ~56,000x and a mean over both
        // describes neither mode.
        unsigned long long slow_calls = 0;
        unsigned long long slow_total_ns = 0;
    };

    // Threshold separating the two measured regimes: fast ~1 us, slow ~52,000 us. Placed
    // far from both so the classification does not depend on the exact value, and
    // compared in the same units as the accumulator (ns).
    inline constexpr unsigned long long kSlowCallUs = 100;

    // WHICH of the four try_get_fireport_position callers is currently asking. Read by
    // get_bifacial_position() into quest_objectives::detail_stage_ so a throw or a cost
    // spike inside the managed getter can be attributed to a CALLER rather than to the
    // shared helper.
    //
    // A plain `inline const char*` rather than a thread_local: the write and the read are
    // in the same function with nothing between them that can yield, and the codebase
    // already accepts exactly this pattern for detail_stage_ (quest_objectives.h:53 and
    // ~30 set/clear sites). Making it thread_local would be safer and is the obvious
    // objection; it is declined because the value is only ever a literal set immediately
    // before use, so a cross-thread read could mislabel a stage but could never corrupt
    // state or crash. That trade is recorded rather than hidden -- if a second thread ever
    // calls into here, this needs to become thread_local.
    inline const char* g_fireport_site = "unknown";

    // RAII wrapper so a call site cannot leak its label into the NEXT one.
    //
    // Added 2026-10-04 after `+8+transit+crash` measured the damage. The label was
    // set on entry and never restored, so a caller that did not set one inherited
    // whatever the previous caller left behind:
    //
    //     aimbot/gameworld_update    11,063 calls   <- the label
    //     aimbot::fireport_resolve    2,108 calls   <- the zone, on the SAME two lines
    //
    // A 5x over-count, pointing the fix at the wrong function: the path that
    // actually carried the 202 s was `try_get_visibility_origin`'s memo, which sets
    // no label at all, and it was being reported as the aimbot's. Meanwhile
    // `unknown` (400 calls, 51.72 us mean -- the worst calls in the capture) was
    // that same memo's calls under the default.
    //
    // Declined, and why: making this a parameter of `try_get_fireport_position`
    // would be strictly better and is the real fix, but it changes a four-caller
    // signature in a file two workstreams are editing. The guard is correct for
    // every caller that uses it and costs one store; the parameter change can be
    // made once, deliberately, by whoever owns this file next.
    struct fireport_site_guard {
        const char* prev;
        explicit fireport_site_guard(const char* site) : prev(g_fireport_site) {
            g_fireport_site = site;
        }
        ~fireport_site_guard() { g_fireport_site = prev; }
        fireport_site_guard(const fireport_site_guard&) = delete;
        fireport_site_guard& operator=(const fireport_site_guard&) = delete;
    };

#define FIREPORT_SITE(name) ::skeleton_vis::fireport_site_guard ta_fireport_site_##__LINE__(name)

    inline fireport_window_t& fireport_window() {
        static fireport_window_t w;
        if (w.freq == 0) {
            LARGE_INTEGER f{};
            // A zero frequency would make every nanosecond figure below divide by
            // zero. Fail closed to 1 ns/tick rather than producing infinities that
            // print as "nan" and get read as "the instrument is broken".
            w.freq = QueryPerformanceFrequency(&f) && f.QuadPart > 0
                ? f.QuadPart : 1;
        }
        return w;
    }

    // Referenced by the scope guard inside try_get_fireport_position.
    inline fireport_window_t& g_fireport_win = fireport_window();

    inline unsigned long long monotonic_ms() {
        LARGE_INTEGER f{}, t{};
        if (!QueryPerformanceFrequency(&f) || f.QuadPart <= 0) return 0;
        QueryPerformanceCounter(&t);
        return (unsigned long long)((t.QuadPart / f.QuadPart) * 1000ULL
            + ((t.QuadPart % f.QuadPart) * 1000ULL) / (unsigned long long)f.QuadPart);
    }

    // The one place this is printed from: once per `gameworld_update`, on the
    // game thread, after the accumulator has been filled.
    //
    // The window gate is a COMPARISON against a clock, evaluated before any
    // string is built. That ordering is the whole lesson from `unity.h` today,
    // where a `std::format` argument list was evaluated at the call site on all
    // 140,875 calls while the function it fed early-returned: 64.87 s, and the
    // guard read as if it were working. Nothing here builds a string unless it
    // will print one.
    inline void report_fireport_window() {
        fireport_window_t& w = fireport_window();
        const unsigned long long now = monotonic_ms();
        constexpr unsigned long long kWindowMs = 30000;
        if (now < w.last_report_ms + kWindowMs) return;
        w.last_report_ms = now;
        const unsigned long long calls = w.calls;
        const unsigned long long total = w.total_ns;
        const unsigned long long mx = w.max_ns;
        w.calls = 0;
        w.total_ns = 0;
        w.max_ns = 0;
        if (calls == 0) return;

        // The mean is printed, but IT IS NOT THE NUMBER TO ACT ON, and leaving it as the
        // headline is what hid this for a day. Measured across the 2026-10-04 sessions:
        //
        //     fast windows (13 of 16)   mean 0.9 us    rate ~140 Hz
        //     slow windows (3 of 16)    mean 52,302 us rate 11-28 Hz
        //
        // A 56,661x ratio between two regimes of the SAME function. An aggregate mean over
        // both is a number about neither: quoting it invites "the getter is slow", when
        // the getter is ~1 us and one regime is 52 ms.
        //
        // So the line separates the regimes instead of averaging them, using a threshold
        // far above the fast mode and far below the slow one (100 us: the fast mode is
        // ~1 us, the slow mode ~52,000 us, so the placement is not delicate). `slow_calls`
        // is the count that decides whether there is a problem at all, and it is the
        // number to watch. `mean_us` is retained so a trend is still visible, but it is
        // labelled for what it is.
        logger::debug("fireport-cost: calls=" + std::to_string(calls)
            + " total_ms=" + std::to_string(total / 1000000ULL)
            + " mean_us=" + std::to_string((total / 1000ULL) / calls)
            + " max_ms=" + std::to_string(mx / 1000000ULL)
            + " rate_hz=" + std::to_string(
                (unsigned long long)((double)calls * 1000.0 / (double)kWindowMs))
            + " | slow(>" + std::to_string(kSlowCallUs) + "us)=" + std::to_string(w.slow_calls)
            + " slow_total_ms=" + std::to_string(w.slow_total_ns / 1000000ULL)
            + " [MEAN MIXES TWO REGIMES -- judge by slow=]");
        w.slow_calls = 0;
        w.slow_total_ns = 0;
    }

    inline bool get_bifacial_position(Il2CppObject* bifacial, unity::vector3& out) {
        if (!bifacial || !bifacial->klass) return false;
        // ---- THE CHEAP-DOOR GATE (ISIL BifacialTransform.get_position, 2026-10-04) ----
        //
        // MEASURED WHY THIS EXISTS. `+13_good` / pid 8700: this call ran 38,880 us mean for
        // 21.5 s inside a single 30 s window, 553 of 553 calls slow, and my own probe printed
        //     my_pos=(70.76,0.23,-72.80) rig_degenerate=false allow_fireport_read=true
        //     slow_calls=9699
        // i.e. the loading screen, with a REAL rig coordinate, for ~10,000 consecutive slow
        // calls. Two earlier attempts to gate this on a "is the player placed" predicate both
        // failed for the same reason: that predicate is not observable from here. This one is
        // read out of the object's own layout instead.
        //
        // `get_position` on EFT.BifacialTransform (ISIL dump, method at line 216) has three
        // exits, and TWO of them branch to the same address 0x180C14339:
        //
        //     Original (+0x10) != null   ->  Transform.get_position   native, ~0.5 us
        //     Original == null, imitating (+0x18) != null
        //                               ->  call [rax]  a virtual call through a stored
        //                                   Func<Vector3>, i.e. game code we do not own
        //     both null                 ->  return the cached position at +0xAC/+0xB4
        //
        // `_positionImitator` is confirmed at +0x18 by SetImitators (line 51: `mov [rcx+18h],rdx`
        // stores its first delegate), and the imitations are stored in declaration order.
        //
        // So: skip the call when BOTH the native door and the imitation are absent, because then
        // the answer is a cached field we cannot distinguish from a live one, and the call buys
        // nothing. Two pointer reads. No game-state inference, which is the whole point -- the
        // inference is what failed twice.
        //
        // Resolved BY NAME, so a patch that reorders the fields degrades to "no gate" rather
        // than to a wrong read. Cached per class: resolve_field is not free and this is called
        // ~24 times a second.
        static const FieldInfo* s_orig_field = nullptr;
        static const FieldInfo* s_imit_field = nullptr;
        static const Il2CppClass*  s_gate_klass  = nullptr;
        if (s_gate_klass != bifacial->klass) {
            s_gate_klass  = bifacial->klass;
            s_orig_field  = il2utils::resolve_field(bifacial->klass, "Original");
            s_imit_field  = il2utils::resolve_field(bifacial->klass, "_positionImitator");
        }
        if (s_orig_field && s_imit_field) {
            const bool has_native = *reinterpret_cast<void**>(
                reinterpret_cast<char*>(bifacial) + s_orig_field->offset) != nullptr;
            const bool has_imitator = *reinterpret_cast<void**>(
                reinterpret_cast<char*>(bifacial) + s_imit_field->offset) != nullptr;
            if (!has_native && !has_imitator)
                return false;   // cached-position branch: nothing to gain from asking
        }

        unity::vector3 result{};
        {
            // The resolve AND the call are delegated to the single reader in eft_api, which
            // the three other copies of this sequence now share. Doing the resolve here as
            // well would have been a second lookup of the same memoised entry for the same
            // object -- ~224 ns and no new information. resolve_method still keeps its own
            // zone inside that call, so it stays separately attributed in the capture.
            // The resolve stays here because the cheap-door gate above and the TA_ZONE_SITE
            // below both need `method`; only the CALL is delegated, to the single reader in
            // eft_api that three other copies of this sequence now share.
            // The managed call, separated from the resolve above it.
            //
            // `aimbot::fireport_resolve` measured 310.59 s of SELF time over 22,129
            // calls (14,035 us mean, 246.03 ms max) in the 2026-10-04 14:36 capture --
            // 39.96% of the entire capture, and 33x the next most expensive zone in
            // it. Its two `il2utils::resolve_method` children came back at 1 us and
            // 570 ns, so 99.999% of it is in the two calls those resolves produce the
            // pointers for. Which two is not yet known, and this is the split.
            //
            // Named under `skeleton_vis::` and not `aimbot::` because this function is
            // shared: `try_get_fireport_position` has four callers (AimbotModule.cpp,
            // AimbotModule.h, EspModule.cpp, and the memo in
            // try_get_visibility_origin) and a zone named after one of them would
            // misattribute the other three.
            //
            // WHICH of the four is still not visible, and `g_fireport_site` is what fixes
            // it. Measured 2026-10-04 16:34: this zone ran 26,101 calls while
            // `aimbot::fireport_resolve` ran 15,264 -- **10,837 calls (41%) with no caller
            // that fits**. The flat CSV cannot attribute them: no call tree, and the
            // README's max_ns-equality test found no parent sharing this zone's maximum.
            //
            // TWO candidates were checked and ruled out ON COST ALONE, which is the part
            // worth recording: `EspModule::gameworld_update` has 13,494 calls -- almost
            // exactly the remainder -- but only 527 us inclusive, far too small to contain
            // a 5.73 ms call; `aimbot::visibility_origin_resolve` has 13,494 at 1.4 us.
            // A near-exact count match is NOT containment, and reading it as one would
            // have named the wrong caller with total confidence.
            //
            //
            // Same technique the overlay workstream used to turn 'menu::draw' into
            // 'ESP::draw_overlay', and applied here because nothing else in the export can
            // do it: the two candidate fixes (cache a genuinely-slow getter vs. add a
            // liveness check for a stale Bifacial) are OPPOSITES, so which caller is
            // responsible decides which fix is correct, and guessing would be a coin flip
            // on the most expensive function in the project.
            //
            // The name is chosen at RUNTIME from g_fireport_site, which each of the four
            // call sites sets on the way in. That makes each caller its own row in the CSV
            // rather than one row with a varying label, so the numbers are groupable --
            // see TA_ZONE_SITE in tracy_bridge.h for why the site must stay a small fixed
            // set of literals.
            //
            // It deliberately does NOT write quest_objectives::detail_stage_, which is the
            // stage the overlay throw drain reads: this header does not include
            // quest_objectives.h, and adding that include to make a diagnostic work would
            // invert the dependency for no benefit.
            TA_ZONE_SITE("skeleton_vis::fireport:get_position", g_fireport_site);
            if (!eft_api::try_get_managed_position(bifacial, result)) return false;
        }
        out = result;
        return true;
    }

    inline int read_static_layer_mask(const Il2CppClass* cls, const char* field_name,
                                      bool* resolved = nullptr) {
        if (resolved) *resolved = false;
        if (!cls) return 0;
        FieldInfo* field = il2utils::resolve_field(cls, field_name);
        if (!field) return 0;

        layer_mask_field value{};
        il2cpp::il2cpp_field_static_get_value(field, &value);
        // A RESOLVED mask of 0 is a real answer (the game's cctor ran and the mask
        // is empty), and is not the same as "the field did not resolve". Reporting
        // them identically is what made a total resolution failure invisible.
        if (resolved) *resolved = true;
        return value.m_mask;
    }

    // ---- what the occlusion mask actually turned out to be --------------------
    //
    // Added 2026-10-05 because the mask was, until now, invisible: nothing logged
    // it, nothing logged whether each component resolved, and -- see
    // try_get_occlusion_layer_mask -- a total failure was indistinguishable from
    // success. So two very different builds could produce the same log.
    //
    // Why it matters concretely: `vis-breakdown` shows `hit_target=0` and
    // `hit_shooter=0` across 1,480,017 rays, i.e. classify_hit_transform has never
    // returned anything but `none`. Reading the source, that is EXPECTED -- the
    // mask union below deliberately contains no `PlayerMask` and no
    // `ConsiderPlayerMask`, so the ray cannot hit a player collider at all. But
    // that is a claim about the source, not a measurement of the running build,
    // and if the game-side lookups were failing the fallback would be in force
    // instead. These counters are what tells the two apart.
    struct occlusion_mask_report
    {
        int effective = 0;
        int fallback_only = 0;      // 1 if no game-side component resolved at all
        int settings_resolved = 0;  // out of 3 EFTHardSettings fields
        int layers_resolved = 0;    // out of 8 LayersMaskController statics
        int occlusion_api_resolved = 0; // out of 2 SoundOcclusionUtils getters
    };
    inline occlusion_mask_report g_occlusion_mask_report{};

    // The game's own bullet hit mask: BallisticsCalculatorConstants.HitMask
    // (static; built in .cctor from layer names — Shot.CheckCollision raycasts
    // with it). Our WEAPON_OCCLUSION raycast mask includes colliders bullets
    // never touch (catwalk grating: 'collider' child of garbage_mix_K6_set_P —
    // log 09-25 20:16), so the penetration walk must raycast with the bullet
    // mask, not the occlusion mask. Falls back to the occlusion mask until the
    // static is initialized.
    //
    // Aimbot-gated with the rest of the penetration model: this mask only ever
    // selects what is_target_visible_penetrating is about to raycast against.
#ifdef INCLUDE_AIMBOT
    inline int g_bullet_layer_mask = 0;
    inline bool g_bullet_mask_tried = false;

    inline int try_get_bullet_layer_mask() {
        if (!g_bullet_mask_tried)
        {
            g_bullet_mask_tried = true;
            Il2CppImage* asm_img = il2utils::resolve_image("Assembly-CSharp.dll");
            if (asm_img)
            {
                const Il2CppClass* cls =
                    il2utils::resolve_class(asm_img, "EFT.Ballistics", "BallisticsCalculatorConstants");
                if (cls)
                {
                    if (FieldInfo* field = il2utils::resolve_field(cls, "HitMask"))
                    {
                        // HitMask must be a STATIC field (.cctor-initialized). A
                        // static_get_value on an instance field reads outside the
                        // static block — verify the flag + allocated statics first.
                        const bool is_static = field->type
                            && (field->type->attrs & 0x0010) != 0; // FieldAttributes.Static
                        if (is_static && field->parent && field->parent->static_fields)
                        {
                            layer_mask_field value{};
                            il2cpp::il2cpp_field_static_get_value(field, &value);
                            g_bullet_layer_mask = value.m_mask;
                        }
                    }
                }
            }
            if (g_bullet_layer_mask)
                logger::debug(std::format("pen-check: bullet HitMask = 0x{:08x}", g_bullet_layer_mask));
        }
        return g_bullet_layer_mask;
    }
#endif // INCLUDE_AIMBOT

    inline int try_get_occlusion_layer_mask() {
        static int cached_mask = 0;
        static bool tried = false;
        if (tried) return cached_mask;
        tried = true;

        // ZERO, not fallback_layer_mask.
        //
        // WAS: `int mask = fallback_layer_mask;`, which made cached_mask incapable
        // of ever being 0, which made the `cached_mask ? cached_mask : fallback`
        // ternary below dead -- so a build where every game-side lookup failed and
        // a build where all of them succeeded produced the same log line, and the
        // fallback was silently OR'd into the mask even on full success. Now the
        // fallback is applied only when nothing at all resolved, and which of those
        // two happened is reported.
        int mask = 0;
        occlusion_mask_report rep{};
        bool any_game_side = false;

        Il2CppImage* asm_img = il2utils::resolve_image("Assembly-CSharp.dll");
        if (asm_img)
        {
            // NAMESPACE FIX (2026-10-05). This asked for "EFT", and has always
            // returned nullptr: GameDump/115147510/dump.cs:14945 declares
            //     public sealed class EFTHardSettings : ScriptableObject
            // with no namespace, and the DiffableCs copy says so on line 1
            // ("//Type is in global namespace"). il2cpp_class_from_name is the
            // game's own export and matches the namespace exactly; it is not a
            // search. LayersMaskController, asked for with "" three lines below,
            // has always resolved -- which is exactly why this went unnoticed next
            // to it.
            //
            // MEASURED, not inferred: the per-component report added alongside this
            // prints `settings=0/3` on every window of the 2026-10-05 session while
            // `layers=8/8` and `occlusion_api=2/2`. So all three settings masks have
            // been silently absent from every raycast this build has ever made, and
            // `fallback_layer_mask` was being OR'd in to cover for them.
            //
            // Both spellings are tried, global first, because the correct answer
            // differs by game build and guessing wrong costs the whole block.
            const Il2CppClass* settings_class = il2utils::resolve_class(asm_img, "", "EFTHardSettings");
            if (!settings_class)
                settings_class = il2utils::resolve_class(asm_img, "EFT", "EFTHardSettings");
            if (settings_class)
            {
                const MethodInfo* get_instance = il2utils::resolve_method(settings_class, "get_Instance", 0);
                if (get_instance && get_instance->methodPointer)
                {
                    Il2CppObject* settings = reinterpret_cast<Il2CppObject* (*)()>(get_instance->methodPointer)();
                    if (settings)
                    {
                        Il2CppObjectInstance settings_inst(settings);
                        // Offsets verified against GameDump/115147510
                        // EFTHardSettings.cs: BaseMask 0x1EC, WEAPON_OCCLUSION_LAYERS 0x240,
                        // ENVIRONMENT_HIT_MASK 0x414.
                        //
                        // These are INSTANCE fields on the settings singleton, so they
                        // are read through the instance accessor. An earlier version of
                        // this change routed them through read_static_layer_mask for
                        // uniformity, which would have been a REGRESSION: the static
                        // getter on an instance field reads the wrong storage. Kept as
                        // get_field, with resolve_field used only as the resolution probe.
                        for (const char* name : { "WEAPON_OCCLUSION_LAYERS",
                                                   "ENVIRONMENT_HIT_MASK", "BaseMask" })
                        {
                            if (il2utils::resolve_field(settings_class, name))
                                ++rep.settings_resolved;
                            mask |= settings_inst.get_field<layer_mask_field>(name).m_mask;
                            any_game_side = true;
                        }
                    }
                }
            }

            // Static map geometry (LowPoly walls/terrain) + dynamic interactives
            // (containers/loot). NOTE: no PlayerMask and no ConsiderPlayerMask,
            // deliberately -- a player must not occlude the line of sight to another
            // player, and that omission is why hit_target/hit_shooter are structurally
            // unreachable rather than merely unobserved.
            const Il2CppClass* layers_class = il2utils::resolve_class(asm_img, "", "LayersMaskController");
            if (layers_class)
            {
                for (const char* name : { "HighPolyWithTerrainMask",
                                           "HighPolyWithTerrainNoGrassMask",
                                           "HighPolyCollider",
                                           "LowPolyColliderLayerMask",
                                           "TerrainMask",
                                           "PlayerStaticCollisionsMask",
                                           "InteractiveMask",
                                           "LootCollisionMask" })
                {
                    bool ok = false;
                    const int v = read_static_layer_mask(layers_class, name, &ok);
                    mask |= v;
                    if (ok) ++rep.layers_resolved;
                    any_game_side = true;
                }
            }

            // The game's OWN authored notion of what occludes. This is the only part
            // of the mask with game-side authority behind it.
            const Il2CppClass* occlusion_class = il2utils::resolve_class(
                asm_img, "Audio.SpatialSystem.Utils", "SoundOcclusionUtils");
            if (occlusion_class)
            {
                const MethodInfo* high_poly = il2utils::resolve_method(
                    occlusion_class, "get_HighPolyOcclusionMask", 0);
                const MethodInfo* low_poly = il2utils::resolve_method(
                    occlusion_class, "get_LowPolyOcclusionMask", 0);
                if (high_poly && high_poly->methodPointer) {
                    mask |= reinterpret_cast<int (*)()>(high_poly->methodPointer)();
                    ++rep.occlusion_api_resolved;
                    any_game_side = true;
                }
                if (low_poly && low_poly->methodPointer) {
                    mask |= reinterpret_cast<int (*)()>(low_poly->methodPointer)();
                    ++rep.occlusion_api_resolved;
                    any_game_side = true;
                }
            }
        }

        if (!any_game_side) {
            // Every game-side lookup failed. Say so, loudly, in the data.
            mask = fallback_layer_mask;
            rep.fallback_only = 1;
        }

        rep.effective = mask;
        g_occlusion_mask_report = rep;
        cached_mask = mask;
        return cached_mask;
    }

    #ifdef INCLUDE_AIMBOT
    inline void ensure_penetration_init();
#endif // INCLUDE_AIMBOT

    inline void ensure_init() {
        if (g_initialized) return;

        // Aimbot-gated, and this call is the reason it had to be. ESP reaches
        // ensure_init() through is_ready(), so an unconditional call here ran
        // the BallisticCollider class + System.Type resolution on every build --
        // including one whose aimbot was compiled out and could never use it.
#ifdef INCLUDE_AIMBOT
        ensure_penetration_init();
#endif // INCLUDE_AIMBOT

        Il2CppImage* asm_img = il2utils::resolve_image("Assembly-CSharp.dll");
        Il2CppImage* physics_image = il2utils::resolve_image("UnityEngine.PhysicsModule.dll");
        Il2CppImage* core_image = il2utils::resolve_image("UnityEngine.CoreModule.dll");
        if (!asm_img || !physics_image || !core_image) return;

        const Il2CppClass* ext_class = il2utils::resolve_class(asm_img, "", "PhysicsExtensions");
        const Il2CppClass* raycast_hit_class = il2utils::resolve_class(physics_image, "UnityEngine", "RaycastHit");
        const Il2CppClass* transform_class = il2utils::resolve_class(core_image, "UnityEngine", "Transform");
        if (!ext_class || !raycast_hit_class || !transform_class) return;

        const MethodInfo* linecast_method = il2utils::resolve_method(
            ext_class, "Linecast", 5);
        const MethodInfo* hit_transform_method = il2utils::resolve_method(
            raycast_hit_class, "get_transform", 0);
        const MethodInfo* parent_method = il2utils::resolve_method(
            transform_class, "get_parent", 0);

        if (!linecast_method || !linecast_method->methodPointer) return;
        if (!hit_transform_method || !hit_transform_method->methodPointer) return;
        if (!parent_method || !parent_method->methodPointer) return;

        g_linecast = reinterpret_cast<linecast_ext_sig>(linecast_method->methodPointer);
        g_hit_get_transform = reinterpret_cast<hit_get_transform_sig>(hit_transform_method->methodPointer);
        g_transform_get_parent = reinterpret_cast<transform_get_parent_sig>(parent_method->methodPointer);
        g_initialized = g_linecast && g_hit_get_transform && g_transform_get_parent;
    }

    inline bool is_ready() {
        ensure_init();
        return g_initialized;
    }

    inline Il2CppObject* get_player_transform(Il2CppObject* player_obj) {
        if (!player_obj) return nullptr;
        Il2CppObject* player_go = unity::component_get_game_object(player_obj);
        if (!player_go) return nullptr;
        return unity::gameobject_get_transform(player_go);
    }

    // WHO the ray hit, from the walk up to the rig root. Three outcomes, not two, and the
    // third is the one that was missing.
    //
    // The 2026-10-02 "nextday" capture showed is_player_transform entered on 1,810,284
    // calls -- EXACTLY the count of is_target_visible -- which given the control flow can
    // only mean every raycast hit something and passed both filters. The likely cause is
    // that the origin is the shooter's own camera or fireport (try_get_visibility_origin,
    // skeleton_visibility.h:703-725) and the occlusion layer mask includes the shooter's own
    // colliders, so the first thing the ray meets is the shooter's own body.
    //
    // The old two-outcome test cannot express that. It walks looking ONLY for the TARGET's
    // transform, so a hit on the shooter's own body runs the full 48-hop walk, fails to find
    // the target, and returns FALSE -- i.e. "occluded". Our own body would then report every
    // enemy as hidden. The single-parent comparison below cannot be blamed for the cost: it
    // runs on every hit regardless, and the walk is only 2.9% of this path
    // (0.57 s of 19.31 s). It is wrong, not slow.
    enum class hit_owner { none,
        shooter,
        target };

    inline hit_owner classify_hit_transform(Il2CppObject* hit_transform,
        Il2CppObject* shooter_obj, Il2CppObject* target_obj) {
        if (!hit_transform) return hit_owner::none;
        // Both resolved up front so the walk compares against locals rather than calling
        // get_player_transform twice inside the loop.
        const Il2CppObject* shooter_tr = shooter_obj ? get_player_transform(shooter_obj) : nullptr;
        const Il2CppObject* target_tr = target_obj ? get_player_transform(target_obj) : nullptr;
        if (!shooter_tr && !target_tr) return hit_owner::none;

        Il2CppObject* current = hit_transform;
        for (int depth = 0; depth < 48 && current; ++depth)
        {
            // One walk, two early exits. Checking the shooter alongside the target is what
            // turns a 48-hop miss into a hit on the first or second hop, and it is the
            // difference between "our own arm blocks everything" and "our own arm is not a
            // wall".
            if (target_tr && current == target_tr) return hit_owner::target;
            if (shooter_tr && current == shooter_tr) return hit_owner::shooter;
            current = g_transform_get_parent(current);
        }
        return hit_owner::none;
    }

    // ===================================================================
    // BOUNDED VISIBILITY DIAGNOSTIC -- two questions, one budget.
    // REMOVE ONCE ANSWERED. Not a feature; nothing depends on it.
    // ===================================================================
    // The bounded diagnostic is GONE, and this is the record of why, because its verdict
    // label was wrong 13 times out of 13 -- the second time in this file that an
    // instrument of mine reported a confident conclusion it had not earned.
    //
    // TWO QUESTIONS, both now answered.
    //
    // Q1 (on the `hit_owner::none` arm) asked whether the 98% of rays ending in
    // `hit_occluder` were being walked past player-owned geometry. Its detector matched
    // `_BALLISTIC_`, which is only EFT's material suffix on ANY ballistic collider, so it
    // returned WALK-FAILED on all twelve samples against
    // `Old_Control_Panel_A_BALLISTIC_metalthink` -- a control panel. That pattern is
    // removed; see name_looks_player_owned.
    //
    // Q2 (on the `ray_miss` arm) re-cast the identical ray with ALL layers and printed
    // FALSE-VISIBLE whenever that ray hit anything. Thirteen samples, two clusters:
    //
    //   10 x blocked 0.01-0.05 m from the camera, ratio ~0.001
    //        the SHOOTER'S OWN collider -- the camera sits inside their own head
    //   3 x blocked at 11.3 / 13.4 / 26.5 m, ratio 0.68 / 0.99 / 0.99
    //        essentially AT the bone -- the TARGET'S OWN collider
    //
    // **Neither cluster is a false visible.** Ignoring your own body is what makes the
    // check work at all, and reaching the target is the definition of visible. Q2
    // established the opposite of what its label claimed, and something more useful on
    // the way:
    //
    // THE OCCLUSION MASK IS WORLD-GEOMETRY-ONLY BY CONSTRUCTION, and THAT is why
    // `hit_target` is structurally unreachable rather than broken. The target's own
    // collider layer is not in the mask, so the ray passes through and exits as
    // `ray_miss`, reported as visible -- correctly. Same for the shooter, which is why
    // `hit_shooter` is also always 0.
    //
    // The consequence worth keeping: because the mask never lets a player collider reach
    // `classify_hit_transform`, that walk's behaviour ON a player collider has never been
    // observed at all. It is not shown correct and not shown broken -- it is unreachable
    // while the mask is built this way, and would only start to matter if someone widened
    // the mask to include player layers.


    // GameObject.get_layer, resolved lazily inside the diagnostic rather than in
    // ensure_init(), which gates g_initialized on every pointer it resolves -- a
    // cosmetic accessor there could take the whole visibility feature down with it.
    inline int vis_diag_layer_of(Il2CppObject* game_object) {
        using get_layer_sig = int (*)(Il2CppObject*);
        static const get_layer_sig s_get_layer = [] () -> get_layer_sig {
            Il2CppImage* core = il2utils::resolve_image("UnityEngine.CoreModule.dll");
            const Il2CppClass* cls = core
                ? il2utils::resolve_class(core, "UnityEngine", "GameObject") : nullptr;
            const MethodInfo* m = cls
                ? il2utils::resolve_method(cls, "get_layer", 0) : nullptr;
            return (m && m->methodPointer)
                ? reinterpret_cast<get_layer_sig>(m->methodPointer) : nullptr;
        }();
        if (!game_object || !s_get_layer) return -1;
        if (!eft_api::is_readable_address_cached(game_object, sizeof(Il2CppObject)))
            return -1;
        return s_get_layer(game_object);
    }

    // vis_diag_occluder -- Q1 -- RETIRED 2026-10-03, and its answer was a false positive
    // caused by this file's own detector, which is why it is recorded rather than just
    // deleted. It walked the hit's chain looking for a player-owned ancestor and printed
    // WALK-FAILED on all twelve samples against `Old_Control_Panel_A_BALLISTIC_metalthick`:
    // a control panel 3.13-3.29 m from the camera, with the bone 62.5-85.6 m away, on
    // layer 12 and inMask=1. That is CORRECT occlusion, and `_BALLISTIC_` -- which the
    // detector treated as a player marker -- is only EFT's material suffix on any
    // ballistic collider, static geometry included. See name_looks_player_owned.
    //
    // What the twelve samples DID establish, which is the actual finding, is the geometry:
    // an occluder ~3 m out and a target 62-86 m away, every time. The walk is right; the
    // high occluder rate is real occlusion; and the ESP is raycasting toward targets far
    // beyond what an interior map lets you see. Retired so the still-open miss question
    // gets the whole sample budget -- at a 97.6% occluder rate the two probes shared one
    // budget and Q2 never got a single sample.

    // ---- visibility-check distance cap: is the number actually earning its keep? ----
    //
    // The cap on the ESP's per-bone occlusion rays is set by a config default
    // (EspModule.h `skeleton_vis_distance`, 75 m). That number is a judgement, not a
    // measurement, so these counters exist to replace the judgement with data: per 30 s
    // window, how many player-skeletons were inside the cap (rays cast) versus outside it
    // (rays skipped), and how many bones that skipped work would have been.
    //
    // The arithmetic a reader can do with it: if `players_in` is a small fraction of the
    // total, the cap is doing nearly all the work and raising it would cost
    // `players_out * ~17.6 bones * ~10.9 us` per frame. If `players_in` is most of them,
    // the cap is set too tight and is throwing away real visibility information.
    inline unsigned long long& g_vis_rays_players_in() {
        static unsigned long long v = 0; return v;
    }
    inline unsigned long long& g_vis_rays_players_out() {
        static unsigned long long v = 0; return v;
    }
    inline unsigned long long& g_vis_rays_bones_skipped() {
        static unsigned long long v = 0; return v;
    }

    // Game thread only, same trade as g_vis_exit_counts: written by collect_skeleton and
    // read by the 30 s reporter, both on the game thread.
    inline void record_vis_distance(bool cast_rays, bool had_bones) {
        if (cast_rays) { ++g_vis_rays_players_in(); return; }
        ++g_vis_rays_players_out();
        if (had_bones) ++g_vis_rays_bones_skipped();
    }

    inline void reset_vis_distance_counters() {
        g_vis_rays_players_in() = 0;
        g_vis_rays_players_out() = 0;
        g_vis_rays_bones_skipped() = 0;
    }

    // ---- view-cone cull: how much of the circle is actually being looked at? ----
    //
    // The ESP built a skeleton, and cast ~17.6 occlusion rays at it, for EVERY player
    // inside a 3D sphere -- including players directly behind the camera. It is the only
    // ESP item that works that way: exfils, transits, grenades, keycards, loot, quest POIs,
    // bot corpses and even the player LABEL all do
    //
    //   world_to_screen(cam, pos3d, ...); if (!is_visible(screen_pos)) continue;
    //
    // BEFORE doing their per-item work, while the skeleton path culled per-BONE on the
    // render thread at EspModule.cpp:1188, long after the game thread had done the work.
    //
    // These counters size the waste rather than assuming it: `culled` is how many
    // skeletons were never built, `built` how many were. A cull ratio near 0.75 on a
    // 70-degree cone is the arithmetic working; near 0 means the cone is far wider than
    // the view and the work was mostly needed anyway.
    inline unsigned long long& g_vis_cone_culled() {
        static unsigned long long v = 0; return v;
    }
    inline unsigned long long& g_vis_cone_built() {
        static unsigned long long v = 0; return v;
    }
    inline void reset_vis_cone_counters() {
        g_vis_cone_culled() = 0;
        g_vis_cone_built() = 0;
    }

    // Increments live at the call site as `++skeleton_vis::g_vis_cone_built()`, which is
    // why these return a reference rather than a value: a plain `unsigned long long`
    // member would need the report to read the counter rather than the name of it.

    inline bool is_player_transform(Il2CppObject* hit_transform, Il2CppObject* player_obj) {
        return classify_hit_transform(hit_transform, nullptr, player_obj) != hit_owner::none;
    }

    // ------------------------------------------------------------------------
    // pen_stop -- WHY the penetration walk gave its verdict, as data.
    //
    // UNGUARDED on purpose, and it is the one piece of the penetration model
    // that is not inside INCLUDE_AIMBOT, because the counter storage and the
    // 30 s reporter that prints it are ESP-owned (see the scope note at the top
    // of this file). In a no-aimbot build nothing increments these; they read
    // zero and the reporter says "pen: not built" rather than omitting a field
    // the reader has learned to expect.
    //
    // It replaces the free-text `reason` that classify_blocker used to hand
    // back, and that is the whole point: a string cannot be counted. The
    // diagnostics could print "ammo power <= PenetrationLevel" forever and
    // nobody could ask how often it fired, because the only record was a
    // line of text behind a 500 ms throttle. One enum is now the single source
    // of truth for BOTH the log message and the tally, so they cannot drift --
    // which is the failure the pen-check log already suffered once (189 lines
    // annotated as blocked while the headline said PENETRABLE).
    //
    // `none` means nothing blocked the round, i.e. the walk reported a clear or
    // penetrable line. It is a bucket like any other so the set stays closed:
    // every call increments exactly one slot, and the slots sum to the call
    // count by construction.
    //
    // Ordering constraint: `pen_stop::COUNT` must stay last. The reporter walks
    // 0..COUNT-1.
    // ------------------------------------------------------------------------
    enum class pen_stop : int {
        none = 0,             // clear line / penetrates; NOT a block
        not_ready,            // physics init failed or no target object -- cannot cast
        no_ammo,              // pen power <= 0, so nothing can be decided
        degenerate_ray,       // origin-to-target length < 0.1 m; nothing to trace
        ammo_vs_level,        // ammo PenetrationPower <= collider PenetrationLevel
        chance_zero,          // collider PenetrationChance ~ 0
        combined_low,         // combined ammo+collider chance <= 1%
        ricochet,             // deflection risk >= kRicochetBlockAt
        unreadable,           // BallisticCollider present, fields unreadable
        sibling_unreadable,   // sibling-sweep BallisticCollider, fields unreadable
        no_ballistic,         // nothing on the hit chain: env / terrain
        accumulated_floor,    // accumulated chance fell below kMinAccumulated
        budget_casts,         // raycast budget (kMaxCasts) exhausted
        budget_layers,        // layer budget (kMaxLayers) exhausted, blockers remain
        // Added 2026-10-04. The ray origin came to rest INSIDE geometry after
        // step_past() advanced it past the previous layer. Previously this exit had
        // no code at all and reported `stop_layer < 0`, which on the 23:14 Factory
        // log meant 76 PENETRABLE verdicts from 82 uses -- an unverified pass. See
        // the exit for the full chain.
        origin_in_mesh,
        COUNT
    };

    inline constexpr int kPenStopCount = static_cast<int>(pen_stop::COUNT);

    // ------------------------------------------------------------------------
    // Skipped layers -- NOT a pen_stop, and that is the whole design point.
    //
    // pen_stop has a load-bearing invariant: exactly one slot per walk, so the
    // slots sum to the call count by construction. A skipped layer is not a
    // verdict -- the walk continues past it -- so putting skips in pen_stop would
    // break that invariant and make every tally ambiguous. Separate counters.
    //
    // Why they had to exist at all. Both skip paths write only into the `diag`
    // string, which is built solely under log_dump, so they were invisible in the
    // tally. Measured 2026-10-04: 23 hierarchy skips and 40 same-ballistic skips
    // across the session, and NOT ONE of them appeared in any `pen: total=` line.
    //
    // That matters because of the bug these counters were added to measure. The
    // hierarchy test at `related && just_behind` skips a hit when it merely
    // SHARES AN ANCESTOR with the previous layer and sits within 0.4 m of it. A
    // cylinder inside a metal cage satisfies both, so it gets discarded as an
    // "exit face" and never graded -- and the walk then reports `clear` through a
    // solid metal cylinder. A walk that dropped a real layer and one that graded
    // it correctly are INDISTINGUISHABLE in the tally, so there was no way to
    // bound how often this fired, and therefore no way to verify a fix.
    //
    // Two counters, not one, because the two paths are not the same test and a
    // single number would hide which one is over-firing.
    //
    // Game thread only, same trade as g_pen_stop_counts.
    // ------------------------------------------------------------------------
    inline unsigned long long& g_pen_skip_hierarchy() {
        static unsigned long long v = 0; return v;
    }
    /// Same BallisticCollider AND an exit face -- a genuine exit collision, which
    /// does not count as another layer because one PenetrationLevel covers the
    /// whole component. This is the precise form of the rule; the hierarchy skip
    /// above is the approximation that runs first.
    inline unsigned long long& g_pen_skip_same_ballistic() {
        static unsigned long long v = 0; return v;
    }
    /// Same BallisticCollider, but the normal faces the ray: a RE-ENTRY into a
    /// collider the round already crossed. Counted separately because it is the
    /// case where identity is true and the layer is still real -- a compound shell
    /// has more surfaces than its single PenetrationLevel describes -- and because
    /// a large number here means the walk is re-grading geometry the cheap way
    /// would have skipped, which is a cost question as much as a correctness one.
    inline unsigned long long& g_pen_reentry() {
        static unsigned long long v = 0; return v;
    }

    // The one place a stop reason becomes text, for both the log line and the
    // reporter's column headings. Kept next to the enum so adding a value
    // without a string is a compile error rather than a blank column.
    inline const char* pen_stop_name(pen_stop s) {
        switch (s)
        {
        case pen_stop::none: return "clear";
        case pen_stop::not_ready: return "not_ready";
        case pen_stop::no_ammo: return "no_ammo";
        case pen_stop::degenerate_ray: return "degenerate_ray";
        case pen_stop::ammo_vs_level: return "ammo_vs_level";
        case pen_stop::chance_zero: return "chance_zero";
        case pen_stop::combined_low: return "combined_low";
        case pen_stop::ricochet: return "ricochet";
        case pen_stop::unreadable: return "unreadable";
        case pen_stop::sibling_unreadable: return "sibling_unreadable";
        case pen_stop::no_ballistic: return "no_ballistic";
        case pen_stop::accumulated_floor: return "accum_floor";
        case pen_stop::budget_casts: return "budget_casts";
        case pen_stop::budget_layers: return "budget_layers";
        case pen_stop::origin_in_mesh: return "origin_in_mesh";
        case pen_stop::COUNT: break;
        }
        return "?";
    }

    // ===================================================================
    // PENETRATION MODEL -- aimbot-only. See the scope note at the top of
    // this file: the ESP needs none of this, and in a no-aimbot build the
    // whole block below has no caller at all.
    // ===================================================================
#ifdef INCLUDE_AIMBOT
    // --- Penetration model ---------------------------------------------------
    // Mirrors the game's own flow (verified against the IL dump):
    //   Shot.TryGetBallisticCollider: hit.collider.GetComponent<BallisticCollider>()
    //     || hit.collider.transform.parent.GetComponent<BallisticCollider>()
    //   BallisticCollider.IsPenetrated(shot, hitPoint):
    //     PenetrationChance < ~0            -> no penetrate (int sentinel: 0)
    //     shot.PenetrationPower <= PenetrationLevel
    //            (so ammo power strictly greater than level required)
    //     random.NextDouble() < shot.PenetrationChance + PenetrationChance
    //     -> penetrates; otherwise the bullet is stopped (ricochet/deflect).

    inline Il2CppObject* g_ballistic_type = nullptr;       // System.Type for BallisticCollider
    inline const Il2CppClass* g_ballistic_class = nullptr; // Il2CppClass for field offsets
    // The game's own resolver: Shot.TryGetBallisticCollider(RaycastHit, out BaseBallistic)
    // — authoritative GetComponentInParent semantics, no hierarchy guessing.
    // ABI (dump 2026-09-25): INSTANCE method — this @ rcx (UNUSED in the body,
    // 0 references), hit @ rdx (RaycastHit* — >8-byte struct passes by pointer),
    // out @ r8 (BaseBallistic&). Calling it as a static put the out-slot in the
    // hit position and left r8 garbage → the method wrote its result to a wild
    // pointer → the raid-entry crash. this=null is safe (never dereferenced).
    using try_get_ballistic_sig = bool (*)(void* /*unused this*/, void* raycast_hit_ptr,
                                           Il2CppObject** out_ballistic);
    inline try_get_ballistic_sig g_try_get_ballistic = nullptr;

    inline void ensure_penetration_init() {
        if (g_ballistic_class) return;

        Il2CppImage* asm_img = il2utils::resolve_image("Assembly-CSharp.dll");
        if (!asm_img) return;

        // BallisticCollider extends BaseBallistic; components live as BallisticCollider.
        // 2026-09-24 log finding (#20): the empty-namespace resolve failed silently,
        // so EVERY component lookup returned null and all cover read as terrain —
        // even GOs literally named *_BALLISTIC_metalthin. Namespace is EFT.Ballistics
        // (per the ISIL dump); keep the root-namespace probe as a fallback.
        const Il2CppClass* cls = il2utils::resolve_class(asm_img, "EFT.Ballistics", "BallisticCollider");
        if (!cls) cls = il2utils::resolve_class(asm_img, "", "BallisticCollider");
        if (!cls) return;

        g_ballistic_class = cls;
        g_ballistic_type = il2utils::get_system_type(asm_img, "EFT.Ballistics", "BallisticCollider");
        if (!g_ballistic_type)
            g_ballistic_type = il2utils::get_system_type(asm_img, "", "BallisticCollider");

        // Resolve the game's own static resolver (dump 2026-09-25: static, takes
        // the RaycastHit struct BY POINTER per x64 ABI — our raycast_hit matches
        // the UnityEngine.RaycastHit layout incl. m_ColliderInstanceID @ +0x28).
        const Il2CppClass* shot_cls = il2utils::resolve_class(asm_img, "EFT.Ballistics", "Shot");
        if (shot_cls)
        {
            const MethodInfo* m = il2utils::resolve_method(shot_cls, "TryGetBallisticCollider", 2);
            if (m && m->methodPointer)
                g_try_get_ballistic = reinterpret_cast<try_get_ballistic_sig>(m->methodPointer);
        }
    }

    // Mirrors Shot.TryGetBallisticCollider: component on the collider itself, then
    // on the collider's transform parent (ray hits usually land on child meshes).
    inline Il2CppObject* try_get_ballistic_collider(Il2CppObject* hit_collider) {
        if (!hit_collider || !g_ballistic_type || !g_ballistic_class) return nullptr;

        Il2CppObject* component =
            unity::gameobject_get_component(hit_collider, g_ballistic_type);
        if (component) return component;

        // component_get_game_object / gameobject_get_transform work for any Component,
        // Colliders included.
        Il2CppObject* hit_go = unity::component_get_game_object(hit_collider);
        if (!hit_go) return nullptr;
        Il2CppObject* hit_tr = unity::gameobject_get_transform(hit_go);
        if (!hit_tr) return nullptr;
        Il2CppObject* parent_tr = unity::transform_get_parent(hit_tr);
        if (!parent_tr) return nullptr;

        return unity::gameobject_get_component(parent_tr, g_ballistic_type);
    }

    struct ballistic_penetration
    {
        float penetration_level = 0.f;
        float penetration_chance = 0.f;
        // BaseBallistic+0x48 (ISIL: `Move this.RicochetChance (System.Single),
        // [collider @ rdx (BaseBallistic)+48]`). NaN when unavailable, matching the
        // NaN-preserving policy below.
        float ricochet_chance = std::numeric_limits<float>::quiet_NaN();
    };

    // TRUE when the runtime type really carries the penetration fields, i.e. it is
    // an EFT.Ballistics.BallisticCollider or something derived from one
    // (BodyPartCollider, ArmorPlateCollider). Deliberately asked of the OBJECT'S OWN
    // class, never of a cached one -- see the long note on
    // try_read_ballistic_penetration below for why that distinction is the whole bug.
    inline bool carries_penetration_fields(const Il2CppClass* klass) {
        if (!klass) return false;
        return il2utils::resolve_field(klass, "PenetrationLevel") != nullptr
            && il2utils::resolve_field(klass, "PenetrationChance") != nullptr;
    }

    // EFT.Ballistics.TerrainBallistic.Get(Vector3 pos) -> BallisticCollider.
    //
    // Terrain is not a collider in the raycast sense: a TerrainBallistic is the
    // terrain system, and Get(pos) returns the BallisticCollider that actually
    // covers that point, carrying the real PenetrationLevel/PenetrationChance for
    // whatever material is there. Reading the penetration fields off the
    // TerrainBallistic itself cannot work, because they are declared on
    // BallisticCollider and TerrainBallistic does not derive from it.
    //
    // The Vector3 argument arrives BY REFERENCE: the game's own disassembly
    // (`mov rbx,rdx` then `[rbx]` / `[rbx+8]`) puts a pointer in the second
    // argument register, which is the IL2CPP convention for a 12-byte struct on
    // the Windows x64 ABI. unity::vector3 is exactly three floats, so &v is that
    // pointer.
    inline Il2CppObject* terrain_ballistic_at(Il2CppObject* terrain,
        const unity::vector3& pos) {
        if (!terrain || !terrain->klass) return nullptr;
        Il2CppObjectInstance inst(terrain);
        const auto get = inst.get_method<Il2CppObject* (*)(Il2CppObject*, unity::vector3*)>(
            "Get", 1, /*log_fail=*/false);
        if (!get) return nullptr;
        return get(terrain, const_cast<unity::vector3*>(&pos));
    }

    // Reads PenetrationLevel/PenetrationChance off an object that really has them.
    //
    // THE FIELDS BELONG TO BallisticCollider, NOT TO BaseBallistic. That was
    // mis-stated in the comment this replaces ("BaseBallistic layout: IL shows
    // PenetrationLevel @+0x40"), and the wrong class was being asked for them:
    //
    //   BaseBallistic      : MonoBehaviour        SurfaceSound @0x20  (its ONLY field)
    //   BallisticCollider  : BaseBallistic        PenetrationLevel  @0x40
    //                                            PenetrationChance @0x44
    //                                            RicochetChance    @0x48
    //   TerrainBallistic   : BaseBallistic        _worldPosition @0x3C  (Vector3)
    //
    // TerrainBallistic therefore has NO PenetrationLevel, and its own Vector3 at
    // 0x3C occupies 0x40 and 0x44. Resolving the field against BallisticCollider
    // and then applying the offset to a TerrainBallistic read _worldPosition.y
    // into penetration_level and _worldPosition.z into penetration_chance. The
    // game's own disassembly agrees -- IsilDump/Assembly-CSharp/
    // TerrainBallistic.txt, `Get(Vector3)`: `movsd xmm0,[rsi+3Ch]` and
    // `mov eax,[rsi+44h]`.
    //
    // In the 2026-10-01 log that surfaced as `penLevel=-103.676
    // penChance=-752.121094` and a "BLOCKED (PenetrationChance ~ 0)" that was
    // never about a wall at all. 88 of 88 TerrainBallistic layers were affected;
    // 7 of 393 BallisticCollider ones were. It only appears on 2+ penetrations
    // because a second layer is only reached once the first is penetrable, and
    // what sits behind a wall is usually terrain.
    //
    // The fields are therefore resolved against `ballistic->klass` -- the type the
    // object actually is -- which is memoised by il2utils::resolve_field and so
    // costs a hash lookup, not a walk.
    inline bool try_read_ballistic_penetration(Il2CppObject* ballistic,
        ballistic_penetration& out) {
        if (!ballistic) return false;

        const Il2CppClass* obj_class = ballistic->klass;
        if (obj_class)
        {
            const FieldInfo* level_field =
                il2utils::resolve_field(obj_class, "PenetrationLevel");
            const FieldInfo* chance_field =
                il2utils::resolve_field(obj_class, "PenetrationChance");
            const FieldInfo* ricochet_field =
                il2utils::resolve_field(obj_class, "RicochetChance");
            if (level_field && chance_field && level_field->offset > 0
                && chance_field->offset > 0)
            {
                out.penetration_level = *reinterpret_cast<float*>(
                    reinterpret_cast<uintptr_t>(ballistic) + level_field->offset);
                out.penetration_chance = *reinterpret_cast<float*>(
                    reinterpret_cast<uintptr_t>(ballistic) + chance_field->offset);
                if (ricochet_field && ricochet_field->offset > 0)
                {
                    out.ricochet_chance = *reinterpret_cast<float*>(
                        reinterpret_cast<uintptr_t>(ballistic) + ricochet_field->offset);
                }
                // Keep NaN values: IsUnsetup colliders carry NaN ballistics and
                // classify_blocker() treats them as penetrable (Shot.CheckCollision
                // only stops on colliders with real ballistic data). Filtering NaN
                // here made that branch dead code, so unsetup grates/chain-link
                // read as 'blocked' (#12).
                //
                // Everything else out of range is a LAYOUT MISTAKE, not a game value,
                // and must not be handed to classify_blocker() as if it were one: a
                // negative level or a chance outside [0,1] would be classified as
                // "PenetrationChance ~ 0" and BLOCK a shot over misread memory. NaN
                // is explicitly let through (the comparisons below are all false for
                // it, hence the explicit isnan guards rather than a plain range test).
                if (!std::isnan(out.penetration_level) && out.penetration_level < 0.f)
                    return false;
                if (!std::isnan(out.penetration_chance)
                    && (out.penetration_chance < 0.f || out.penetration_chance > 1.f))
                    return false;
                if (!std::isnan(out.ricochet_chance)
                    && (out.ricochet_chance < 0.f || out.ricochet_chance > 1.f))
                    return false;
                return true;
            }

            // Fields missed on this build — fall back to the property getters.
            // (The current dump has no getters: PenetrationLevel/PenetrationChance
            // are plain fields at BaseBallistic+0x40/+0x44. This fallback only
            // fires on builds where they were turned into properties; resolve is
            // silent so it costs nothing when absent.)
            Il2CppObjectInstance ballistic_inst(ballistic);
            bool read_level = false;
            bool read_chance = false;
            if (const auto get_level = ballistic_inst.get_method<float (*)(Il2CppObject*)>(
                    "get_PenetrationLevel", 0, /*log_fail=*/false))
            {
                out.penetration_level = get_level(ballistic);
                read_level = true;
            }
            if (const auto get_chance = ballistic_inst.get_method<float (*)(Il2CppObject*)>(
                    "get_PenetrationChance", 0, /*log_fail=*/false))
            {
                out.penetration_chance = get_chance(ballistic);
                read_chance = true;
            }
            // Same policy as the field path: pass whatever the getters returned
            // (NaN included) down to classify_blocker(), which owns the
            // IsUnsetup decision.
            if (read_level || read_chance)
                return true;

            // Silent: the throttled pen-check dump reports the unreadable case
            // with full hit context — logging here would spam per frame.
        }
        // No access path at all (class missing, offsets absent, no getters) —
        // the caller keeps its conservative 'unreadable' treatment.
        return false;
    }

    // Full resolution for ONE layer: read the object's own penetration fields, and
    // when it does not have them, ask the terrain system for the real collider.
    //
    // This is the entry point both layer loops use. try_read_ballistic_penetration()
    // alone would treat every TerrainBallistic as unreadable, and "unreadable" blocks
    // conservatively -- right for a genuine read failure, wrong for terrain, which is
    // just a proxy that holds a reference to the collider that actually covers the
    // point. Terrain is also the common case behind a penetrable wall, which is why
    // this only shows up once a shot goes through two or more layers.
    inline bool try_read_layer_penetration(Il2CppObject* ballistic,
        const unity::vector3& hit_point, ballistic_penetration& out) {
        if (try_read_ballistic_penetration(ballistic, out))
            return true;
        if (!ballistic || !ballistic->klass) return false;
        // Only when the type genuinely lacks the fields, so this cannot fire on a
        // real BallisticCollider whose read merely failed.
        if (carries_penetration_fields(ballistic->klass)) return false;
        if (Il2CppObject* terrain_col = terrain_ballistic_at(ballistic, hit_point))
            return try_read_ballistic_penetration(terrain_col, out);
        return false;
    }

    // Outcome of walking penetrable surfaces along the fire line.
    enum class penetration_result {
        clear = 0,      // nothing in the way
        penetrable = 1, // all blockers penetrable with the loaded ammo
        blocked = 2,    // a blocker (or an unmodeled collider) stops the bullet
        unknown = 3,    // no BallisticCollider and no ammo data - cannot decide
        // Would penetrate, but a layer is a strong DEFLECTION candidate: the round
        // ricochets off and lands somewhere else entirely, so the target behind it is
        // NOT a reliable shot. Distinct from `blocked` (the round stops) because the
        // visible symptom differs — the player fires and hits cover or air.
        ricochet = 4
    };

    inline constexpr float k_pene_chance_epsilon = 1e-6f;

    // Ricochet modelling -- RECOVERED FROM ISIL, not guessed.
    //
    // Source: IsilDump/Assembly-CSharp/EFT/Ballistics/BallisticCollider.txt,
    // `System.Boolean Deflects(Single _hitCosDirectionToNormal, Shot shot, Vector3
    //  hitPoint, Vector3 shotNormal, Vector3 shotDirection)`. Decoded from the raw
    // disassembly (the ISIL pseudo-listing MIS-TRACKS the roll's return value -- see
    // below), it is:
    //
    //   angle = Angle(shotNormal, -shotDirection)        // degrees, 0 = perpendicular
    //   if (this.RicochetChance <= 1E-45)          return false   // surface cannot deflect
    //   if (angle <= 42.5f)                        return false   // hard angle floor
    //   if (angle >= 80f)                          return <b14>
    //   if (shot == null)                          return <b14>
    //   if (shot.RicochetChance <= 0)              return false   // ammo cannot deflect
    //   if (shot.Randoms == null)                  return <b14>
    //   total     = shot.RicochetChance + this.RicochetChance
    //   threshold = (1 - |cos|) * total
    //   return NextSingle(total) < threshold         // disassembly: comiss+seta
    //
    // THE KEY CONSEQUENCE, and the reason this no longer needs calibrating:
    //
    //   NextSingle(total) is uniform on [0, total), so
    //       P(deflect) = threshold / total = 1 - |cos(incidence)|
    //
    // The RicochetChance MAGNITUDES CANCEL COMPLETELY. They gate the roll to zero
    // (collider ~0 or ammo <=0 -> never deflects) and set the roll's range, but the
    // range cancels. So the previous model -- which multiplied by
    // `collider.RicochetChance` and compared the product against a threshold -- was
    // wrong STRUCTURALLY, not merely uncalibrated: it made the reported probability
    // depend on a quantity the game cancels.
    //
    // (ISIL's own listing renders the final comparison as `threshold > total`, which
    // is unsatisfiable and would mean Deflects() can never return true. The raw
    // disassembly is unambiguous -- `comiss xmm6, xmm0` against the call's RETURN
    // value, then `seta` -- so the listing dropped the return value. Trust the
    // disassembly.)
    //
    // The `angle >= 80f` edge is NOT enforced. ISIL resolves @b14 to
    // `throw new NullReferenceException()`, which is also the target of the
    // `shot == null` and `Randoms == null` checks -- a branch target shared by an
    // ordinary null path and an ordinary float path cannot really be a throw, so the
    // 80-degree edge is most likely a decompilation artefact. Enforcing a possibly
    // bogus gate would suppress real ricochets, so it is measured and logged
    // (see ricochet_debug_dump) instead of gated. The 42.5-degree floor IS enforced:
    // there it unambiguously resolves to `Return 0`.

    // The game's own hard floor: at or below 42.5 degrees of incidence the round
    // never deflects, whatever the RicochetChance values say.
    inline constexpr float kRicochetAngleFloorDeg = 42.5f;
    // Observed but NOT enforced -- see above. Logged so one run confirms or kills it.
    inline constexpr float kRicochetAngleCeilDeg = 80.f;

    // Decision threshold on a now-CORRECT probability, so it is a product choice
    // ("at what chance is this shot unreliable enough to hide the target?") rather
    // than a physical constant. 0.5 = a coin flip suppresses. Everything below still
    // reports its per-layer probability in the debug dump.
    inline constexpr float kRicochetBlockAt = 0.5f;

    struct ricochet_assessment {
        float probability = 0.f;      // P(deflect) == 1 - |cos|, the game's own odds
        float angle_deg = 0.f;        // 0 = perpendicular, 90 = grazing
        bool collider_can = false;    // collider.RicochetChance > 1E-45
        bool ammo_can = false;        // shot.RicochetChance > 0
        bool above_floor = false;     // angle_deg > 42.5
        bool below_ceil = false;      // angle_deg < 80 (logged, not gated)
    };

    // Angle-weighted per-layer ricochet probability, mirroring the game's own
    // (1 - cos(incidence)) * RicochetChance weighting.
    //
    // `ray_dir` is the unit shot direction, `surface_normal` the hit normal. |dot| is
    // 1 for a perpendicular hit (no deflection) and 0 for a grazing one (full
    // deflection), which is the same axis the game uses via _hitCosDirectionToNormal.
    inline ricochet_assessment assess_ricochet(float collider_ricochet_chance,
        float ammo_ricochet_chance, const unity::vector3& ray_dir,
        const unity::vector3& surface_normal) {
        ricochet_assessment a{};
        const float cos_incidence = std::fabs(unity::dot(ray_dir, surface_normal));
        if (!std::isfinite(cos_incidence)) return a;
        const float c = std::clamp(cos_incidence, 0.f, 1.f);
        a.probability = 1.f - c;
        a.angle_deg = std::acos(c) * 57.29577951308232f;

        // NaN means the build did not expose the field: stay silent rather than
        // invent a deflection the game may not model.
        a.collider_can = !std::isnan(collider_ricochet_chance) && collider_ricochet_chance > 1e-45f;
        a.ammo_can = !std::isnan(ammo_ricochet_chance) && ammo_ricochet_chance > 0.f;
        a.above_floor = a.angle_deg > kRicochetAngleFloorDeg;
        a.below_ceil = a.angle_deg < kRicochetAngleCeilDeg;
        if (!a.collider_can || !a.ammo_can || !a.above_floor) a.probability = 0.f;
        return a;
    }

    // The game's own obstacle gate, transcribed.
//
// BallisticCollider.IsPenetrated, raw disassembly (BallisticCollider.txt:1016-1036):
//
//   movss xmm0,[rdi+44h]        ; this.PenetrationChance
//   comiss xmm0, 1E-45f         ; static float [1865F48A0h]
//   jb     -> return false
//   ...
//   movss xmm0,[rbx+60h]        ; shot.PenetrationPower
//   comiss xmm0,[rdi+40h]       ; this.PenetrationLevel
//   jbe    -> return false
//   ...
//   movss xmm6,[rbx+6Ch]        ; shot.PenetrationChance
//   addss xmm6,[rdi+44h]        ; + this.PenetrationChance
//   call   NextFloat(...)       ; the roll
//   comiss xmm6,xmm0
//   seta   al                   ; return sum > roll
//
// THE SUM IS ADDITIVE. It is not an independent-combination product, which is what
// this function used to compute:
//
//   was  1 - (1-ammo) * (1-collider)      now  min(1, ammo + collider)
//
// For the values in the 2026-10-03 log that is the whole story. M855A1 obst=0.550
// through a metalthin panel with penChance=0.580:
//
//   was  0.8110    now  1.0000
//
// The old figure was reported as the chance of getting through thin cover and was
// wrong by 19 points in the pessimistic direction, on every layer, for the entire
// session. Because the game ADDS, any pair summing to >= 1 is a certainty: the roll
// is drawn in [0,1), so `sum > roll` is unconditionally true and the clamp to 1 is
// behaviour-preserving rather than a safety net. The 90%-of-blocks `ammo_vs_level`
// tally in that log was mostly this formula refusing to call a pass a pass.
//
// The previous comment claimed this matched "the accumulated chance product". It
// did not, and the discrepancy is the reason the wall check graded stricter than
// the game did.
//
// ammo_obstacle_chance == -1 means "unknown" (see eft_api::weapon_ammo_state); the
// game has no such state because a Shot either has a template or does not exist.
// Folded to 0 rather than summed literally, which under the product form had turned
// -1 into a plausible-looking 0.16 and is under the additive form simply negative.
inline float estimate_obstacle_penetration_chance(float ammo_obstacle_chance,
    float collider_penetration_chance) {
    const float a = ammo_obstacle_chance > 0.f ? ammo_obstacle_chance : 0.f;
    const float c = collider_penetration_chance > 0.f ? collider_penetration_chance : 0.f;
    return std::clamp(a + c, 0.f, 1.f);
    }

    // ------------------------------------------------------------------------
    // Layer identity, for the throttled dump.
    //
    // WHY THIS EXISTS. The dump's `go='...'` has always been the name of the GameObject
    // the RAYCAST hit, while the three floats beside it come from a different object
    // entirely -- the one Shot.TryGetBallisticCollider returned, which is the
    // BallisticCollider on the collider or on the collider's PARENT. Pairing that name
    // with those numbers produced a confident, entirely spurious material table
    // ("this metalthin panel reads 4, that one reads 100") and sent the investigation
    // after a PenetrationLevel sentinel that does not exist.
    //
    // What settles it is identity from the COMPONENT's side, which is what these four
    // fields are. `_typeOfMaterial` is the authoritative MaterialType enum (Concrete=5,
    // MetalThin=16, MetalThick=17, WoodThin=27, WoodThick=28, Cardboard=3, ...), so it
    // says what the collider IS without parsing a naming convention; `_presetId` is
    // -900 for OLD_PRESET_ID -- the .ctor writes 0xFFFFFC7C and nothing else -- so a
    // collider still naming a preset index is distinguishable from one carrying baked
    // inline values; scale closes the ApplyScaleMult question empirically rather than
    // by argument.
    //
    // The scale hypothesis is ALREADY DEAD on static evidence, recorded here so nobody
    // re-derives it: BallisticPreset.ApplyScaleMult is the only writer that multiplies
    // PenetrationLevel by ScaleToPenetrationCurve.Evaluate(max(scale.x, scale.y)), and
    // it has NO CALLERS anywhere in the dumped assemblies. Awake() is a single call to
    // BaseBallistic.Associate(this._typeOfMaterial) and touches no float field, so the
    // levels are baked serialised data, not a computed value. Scale is logged anyway,
    // because "the dump shows 1.00 everywhere" closes it in one run instead of one
    // argument, and it is the cheapest way to catch a future build where the call does
    // exist.
    //
    // unity::get_name allocates and the lossy-scale resolve walks the method table, so
    // all of this sits behind the caller's log_dump gate -- at most once per 500 ms,
    // never on the common path.
    // ------------------------------------------------------------------------
    struct ballistic_identity {
        int material_type = -1;  // EFT.Ballistics.MaterialType; -1 = unread
        int preset_id = -1;      // BallisticCollider._presetId; -900 = OLD_PRESET_ID
        unity::vector3 scale{};  // lossyScale; all-zero = unresolved
        std::string owner_name;  // the COMPONENT's own GameObject, not the hit GO
    };

    // Transform.get_lossyScale -- AN INSTANCE METHOD. Resolved once and latched on first
    // use, which happens inside the log gate.
    //
    // IT IS NOT STATIC, and calling it as though it were is what killed the process four
    // times. UnityEngine/Transform.cs:170 declares it as
    //
    //     public Vector3 get_lossyScale() { }
    //     private void get_lossyScale_Injected(out Vector3 ret) { }
    //
    // i.e. an ordinary instance getter, so the `this` pointer arrives in RCX and the
    // callee immediately reads fields off it. The first version of this helper typed
    // the pointer `unity::vector3 (*)()` -- zero parameters -- and called `fn()`, which
    // left RCX holding whatever happened to be there. The callee then dereferenced that
    // as a Transform and faulted at [garbage + 0x10], which is exactly the shape of
    // every crash in the 2026-10-03 series:
    //
    //   0x00001F8500000010   0x0000369400000010
    //   0x0000429400000010   0x0000488C00000010   0x000050AC00000010
    //
    // The parameter is the fix. `is_unity_object_alive` on the caller side was correct
    // and stayed -- it is what tells us the object is not already a corpse -- but it
    // cannot help when the CALLER never passes the object at all.
    //
    // This is also why the fault sat one byte past the call: 0x1ACE63 is the return
    // address, and the callee's prologue faulted before it could return.
    inline bool try_get_lossy_scale(Il2CppObject* transform, unity::vector3& out) {
        static int state = -1; // -1 untried, 0 unusable, 1 ready
        static unity::vector3 (*fn)(Il2CppObject*) = nullptr;
        if (state < 0)
        {
            state = 0;
            Il2CppImage* core = il2utils::resolve_image("UnityEngine.CoreModule.dll");
            if (core)
            {
                if (const Il2CppClass* tr =
                        il2utils::resolve_class(core, "UnityEngine", "Transform"))
                {
                    // 0 args is correct -- `this` is not counted as a parameter -- so
                    // the resolve is unchanged. Only the CALL signature was wrong.
                    if (const MethodInfo* m = il2utils::resolve_method(tr, "get_lossyScale", 0))
                    {
                        if (m->methodPointer)
                        {
                            fn = reinterpret_cast<unity::vector3 (*)(Il2CppObject*)>(
                                m->methodPointer);
                            state = 1;
                        }
                    }
                }
            }
        }
        if (state != 1 || !transform || !fn) return false;
        out = fn(transform);   // <-- the argument this was missing for four crashes
        return std::isfinite(out.x) && std::isfinite(out.y) && std::isfinite(out.z);
    }

    // Reads by NAME, memoised by il2utils::resolve_field, so each field is a hash
    // lookup rather than a walk -- and it keeps working if the layout ever moves, which
    // is the entire lesson of the TerrainBallistic +0x40 incident.
    inline ballistic_identity read_ballistic_identity(Il2CppObject* ballistic) {
        ballistic_identity id{};
        if (!ballistic || !ballistic->klass) return id;

        // LIVENESS GUARD, AND THIS FUNCTION IS THE REASON FOR THE CRASH.
        //
        // The 2026-10-03 17:54 crash is here. Symbolized against the deployed build
        // 6AC10BEC, the stack was:
        //
        //   frame 0  read_ballistic_identity       +0x242
        //   frame 1  describe_layer                +0x54
        //   frame 2  try_read_ballistic_penetration+0x60   (inlined)
        //   frame 3  assess_ricochet               +0xCB    (inlined)
        //   frame 4  try_read_layer_penetration    +0x1D    (inlined)
        //   frame 5  is_target_visible_penetrating +0xE6A
        //
        // with the fault address OUTSIDE our image, i.e. inside a MANAGED method this
        // function called. `ballistic` comes out of Shot.TryGetBallisticCollider, off a
        // live raycast hit, and by the time the walk has classified a layer and reached
        // this diagnostic the object can be gone. hierarchy_chain and vis_hit_layer,
        // added alongside this file's vis-probe work, guard exactly this.
        //
        // THE FIRST GUARD WAS WRONG, and it cost a second crash. It used
        // eft_api::is_readable_address_cached, on the reasoning that a page-readability
        // check is what stops a managed call on a freed object. It is not: that function
        // answers "is this page mapped", and a freed UnityEngine.Object still has a
        // committed page, so it returned true and the call faulted anyway. The 18:14
        // build shipped that guard and crashed in this same function -- same symbol,
        // offset merely moved +0x242 -> +0x2A2 because the guard itself shifted the code,
        // which is what made it look like progress.
        //
        // unity::is_unity_object_alive is the test that actually separates the two cases:
        // it reads m_CachedPtr, which is precisely the field the fault dereferenced. All
        // four of these reads are bad_pointer + 0x10 -- 0x00001F8500000010,
        // 0x0000369400000010, 0x0000429400000010, 0x0000488C00000010 -- one shape, four
        // sessions.
        //
        // Checked per hop: `go` and `transform` are derived objects that can be
        // destroyed independently of the component they came from, and a Unity object's
        // "destroyed" state IS a null m_CachedPtr, so this is the only test that can tell
        // a live object from a corpse.
        //
        // Affordable because it memoises on a 64-call TTL. Unlike the page memo it is
        // allowed to answer "alive" for a short window, which is the trade that makes it
        // usable on a diagnostic path; the 16:49 log's `unity-memo: revalidations=25`
        // says the TTL is being honoured in practice (revalidations track misses rather
        // than running every call).
        const Il2CppClass* k = ballistic->klass;
        if (const FieldInfo* f = il2utils::resolve_field(k, "_typeOfMaterial"))
            if (f->offset > 0)
                id.material_type = *reinterpret_cast<int*>(
                    reinterpret_cast<uintptr_t>(ballistic) + f->offset);
        if (const FieldInfo* f = il2utils::resolve_field(k, "_presetId"))
            if (f->offset > 0)
                id.preset_id = *reinterpret_cast<int*>(
                    reinterpret_cast<uintptr_t>(ballistic) + f->offset);

        // No managed call until the object is known alive. The field reads above are
        // plain arithmetic on memory we were handed, so they are left unguarded --
        // and they are the only thing still reported when the object is a corpse.
        if (!unity::is_unity_object_alive(ballistic, "skeleton/ballistic"))
            return id;

        Il2CppObject* go = unity::component_get_game_object(ballistic);
        if (!go || !unity::is_unity_object_alive(go, "skeleton/gameobject"))
            return id;
        id.owner_name = unity::get_name(go);

        Il2CppObject* tr = unity::gameobject_get_transform(go);
        if (tr && unity::is_unity_object_alive(tr, "skeleton/transform"))
            try_get_lossy_scale(tr, id.scale);
        return id;
    }

    // ONE formatter for a layer, shared by the primary path and the sibling sweep.
    //
    // They were two hand-copied blocks that had already diverged once -- the sibling
    // copy dropped the "NaN(unmodelled)" ricochet annotation -- which is the same
    // failure mode as the second hand-copied `step_past` block this file already fixed.
    // One function means a field added here cannot be missing from one path.
    //
    // Only called under log_dump.
    inline std::string describe_layer(Il2CppObject* ballistic,
        const ballistic_penetration& bc, float ammo_obst_chance,
        penetration_result r, pen_stop gate, const ricochet_assessment& ric) {
        const ballistic_identity id = read_ballistic_identity(ballistic);
        std::string s = std::format(
            " penLevel={:.3f}{} penChance={:.6f}{} ricochet={:.3f}{} "
            "layerCombined={:.4f} -> {} ({})",
            bc.penetration_level, std::isnan(bc.penetration_level) ? " NaN" : "",
            bc.penetration_chance, std::isnan(bc.penetration_chance) ? " NaN" : "",
            bc.ricochet_chance, std::isnan(bc.ricochet_chance) ? " NaN(unmodelled)" : "",
            estimate_obstacle_penetration_chance(ammo_obst_chance, bc.penetration_chance),
            r == penetration_result::penetrable ? "pass" : "BLOCKED", pen_stop_name(gate));
        // ISIL Deflects: P(deflect) is 1-|cos| and the RicochetChance magnitudes
        // cancel, so log the ANGLE and the three gates -- those decide the outcome.
        s += std::format(
            " | ricochet P={:.3f} angle={:.1f}deg (floor {:.1f}, ceil {:.1f})"
            " colliderCan={} ammoCan={} aboveFloor={} belowCeil={}",
            ric.probability, ric.angle_deg,
            kRicochetAngleFloorDeg, kRicochetAngleCeilDeg,
            ric.collider_can ? 1 : 0, ric.ammo_can ? 1 : 0,
            ric.above_floor ? 1 : 0, ric.below_ceil ? 1 : 0);
        // The component's own identity, beside the numbers that were read off it.
        // `go='...'` earlier in the line is the object the ray hit; `owner` is the
        // object the floats came from. They are frequently different objects, and that
        // difference is the entire thing being measured.
        s += std::format(" | owner='{}' matType={} presetId={} scale=({:.2f},{:.2f},{:.2f})",
            id.owner_name.empty() ? "?" : id.owner_name, id.material_type, id.preset_id,
            id.scale.x, id.scale.y, id.scale.z);
        return s;
    }

    // One blocker between fireport and target: decides whether the loaded ammo
    // would punch through it. Mirrors BallisticCollider.IsPenetrated + the
    // ExitWallChance stop-roll. `stop` (optional) receives which gate fired.
    //
    // It used to hand back `const char** reason` and the walk carried that string
    // around. It is now a pen_stop, for the reason given on that enum: the string
    // was the reason the whole model was unmeasurable. Every branch below sets a
    // code, and pen_stop_name() turns it into text where text is wanted, so the
    // tally and the log message cannot disagree.
    //
    // `penetrable` deliberately records pen_stop::none, not a "passed" value.
    // A pass is not a stop, and the tally has one bucket per OUTCOME.
    inline penetration_result classify_blocker(const ballistic_penetration& bc,
        float ammo_power, float ammo_obstacle_chance, pen_stop* stop = nullptr) {
        const auto set_stop = [stop](pen_stop s) { if (stop) *stop = s; };

        // 2026-09-23 finding: a PenetrationLevel of ~0 must NOT hard-block. Thin
        // cover (paper, sheet metal, chain-link) has Level==0 with a real chance
        // roll — the old epsilon shortcut made those read as "impossible" even
        // though the bullet passes through. Only the game's actual gate applies:
        // "ammo Power <= Level -> no penetration" (strictly-greater check below),
        // otherwise the chance roll decides.
        if (ammo_power <= bc.penetration_level)
        {
            set_stop(pen_stop::ammo_vs_level);
            return penetration_result::blocked;
        }

        // IsUnsetup (NaN fields) means no ballistic data — game allows penetration.
        // Check for NaN explicitly since NaN < x is always false.
        if (std::isnan(bc.penetration_chance) || std::isnan(bc.penetration_level)) {
            set_stop(pen_stop::none);
            return penetration_result::penetrable;
        }

        // IsUnsetup guards this via "> 0f"; keep the same spirit.
        if (bc.penetration_chance < k_pene_chance_epsilon)
        {
            set_stop(pen_stop::chance_zero);
            return penetration_result::blocked;
        }

        const float combined = estimate_obstacle_penetration_chance(
            ammo_obstacle_chance, bc.penetration_chance);
        if (combined <= 0.01f)
        {
            set_stop(pen_stop::combined_low);
            return penetration_result::blocked;
        }
        set_stop(pen_stop::none);
        return penetration_result::penetrable;
    }
    // ---- the per-layer gate, once (2026-10-10) -------------------------------
    //
    // `dup_scan` reported the ancestor ballistic-walk's per-layer gate and the
    // sibling sweep's copy of it as 30-line and 19-line clones
    // (`tools/handoff_skeleton_vis_clone_merge.md`). They live inside ONE function
    // body, so MSVC cannot fold them: unlike most `dup_scan` findings -- which the
    // linker has already collapsed to one address and which therefore cost nothing
    // to leave alone (AGENTS.md, "Which duplicated code actually costs bytes") --
    // this one really is two copies of the same arithmetic in the hottest loop in
    // the ESP path. That is why it was merged rather than filed.
    //
    // WHAT IS SHARED AND WHAT IS NOT, deliberately. The two paths aim identically
    // but PRINT differently, and the asymmetry is load-bearing for reading a log:
    // a `stop_reason` that starts `"sibling:"` is what identifies WHICH sweep
    // stopped the round, and the sibling verdict is missing the ancestor's
    // `"; round likely skips off"` suffix. Both facts are asserted by
    // `tools/tests/test_pen_diagnostic_strings.py`, which is the guard the handoff
    // asked for in its 5.4. So this helper computes and returns the verdict, and
    // every string stays in its own caller, verbatim.
    //
    // It also leaves the two state assignments alone. `layer_is_ballistic` is a
    // bool read by the `if (!layer_is_ballistic)` sweep gate below;
    // `layer_ballistic` is an Il2CppObject* read by `same_collider` on the NEXT
    // iteration. Different variables, different readers: a merge that collapsed
    // them would compile and quietly change behaviour.
    struct pen_layer_gate
    {
        penetration_result r = penetration_result::penetrable;
        pen_stop gate = pen_stop::none;
        const char* reason = "";       // pen_stop_name(gate); the COUNTED reason
        float layer_combined = 0.f;    // estimate_obstacle_penetration_chance(...)
        ricochet_assessment ric{};
    };

    // Everything the gate needs that does not change between layers. Built once
    // per walk rather than passed positionally, so a call site stays readable and
    // adding a field cannot silently reorder an existing one.
    //
    // `ricochet_risk` is a POINTER because it ACCUMULATES across layers: it is an
    // in-and-out, exactly as the two inline copies left it. A pointer rather than
    // a reference-to-non-const so the environment can stay `const` -- mutating
    // through a pointer is legal on a const object, and `const` here documents
    // that nothing else about the per-walk setup changes mid-walk.
    struct pen_layer_env
    {
        float ammo_power = 0.f;
        float ammo_obst_chance = 0.f;
        float ammo_ricochet = -1.f;
        float dirx = 0.f, diry = 0.f, dirz = 0.f;   // unit shot direction
        float* ricochet_risk = nullptr;             // in AND out
        bool log_dump = false;
        std::string* diag = nullptr;
    };

    // `describe_object` is whose identity the per-layer line reports, and it is
    // NOT the same on the two paths: the ancestor reports `layer_ballistic`, the
    // sibling sweep reports the `ballistic` it has just found. So it is a
    // parameter, not something read out of the environment.
    inline pen_layer_gate grade_layer(const ballistic_penetration& bc,
        Il2CppObject* describe_object, const pen_layer_env& env,
        const unity::vector3& surface_normal) {
        pen_layer_gate g{};
        g.gate = pen_stop::none;
        g.r = classify_blocker(bc, env.ammo_power, env.ammo_obst_chance, &g.gate);
        g.reason = pen_stop_name(g.gate);
        g.layer_combined = estimate_obstacle_penetration_chance(
            env.ammo_obst_chance, bc.penetration_chance);
        // Ricochet evaluation, AFTER the penetration gate: a layer can be fully
        // penetrable and still not be a usable shot, because the game rolls
        // RicochetChance and the round skips off. The shot direction is this
        // layer's approach vector and the hit normal is the surface, which is
        // exactly the incidence the game weights by.
        const unity::vector3 shot_dir{env.dirx, env.diry, env.dirz};
        g.ric = assess_ricochet(bc.ricochet_chance, env.ammo_ricochet,
            shot_dir, surface_normal);
        // Mutates the caller's running risk, which is the one piece of in-and-out
        // state in this environment. The two inline copies wrote this exact
        // expression; this is that expression, once.
        if (env.ricochet_risk) {
            *env.ricochet_risk = 1.f - (1.f - *env.ricochet_risk)
                * (1.f - g.ric.probability);
        }
        if (env.log_dump && env.diag) {
            *env.diag += describe_layer(describe_object, bc, env.ammo_obst_chance,
                g.r, g.gate, g.ric);
        }
        return g;
    }

#endif // INCLUDE_AIMBOT

    // A position read that came back at the world origin is not a position.
    //
    // unity::transform_get_pos() returns vector3{} -- i.e. exactly {0,0,0} -- for
    // TWO distinct failure modes and one real one, and the caller cannot tell them
    // apart (unity.h:760):
    //
    //   1. the transform pointer was null;
    //   2. get_position_internal was not resolved yet;
    //   3. the managed get_position genuinely returned {0,0,0}.
    //
    // (3) is not hypothetical. The player rig reads {0,0,0} while it is still being
    // placed, and that window is exactly when this file's origins are chosen -- raid
    // start, which is also when Camera.current was independently reported to belong
    // to a BOT. So the two faults coincide, which is why they have looked like one
    // unreliable feature rather than two.
    //
    // WHY IT MATTERS, concretely: a rig at the origin used as the trust-test
    // reference puts the real camera tens of metres from it, so the camera is
    // rejected as "somebody else's" on every frame of that window; and the rig
    // FALLBACK then handed back {0,0,1.6} as a ray origin, i.e. every ESP and pen
    // ray started at the map corner. Both follow from taking a possibly-degenerate
    // read at face value.
    //
    // The threshold is 1 mm, not something generous. The only thing it has to
    // separate is "float noise around an uninitialised zero" from "a real world
    // position", and no EFT map places a player or a muzzle within a millimetre of
    // the exact world origin. A looser epsilon here would silently blank the
    // visibility feature for players who genuinely are near the origin.
    //
    // Declared here, above its first caller, rather than beside the visibility-origin
    // code that motivated it: the fireport read needs it too, and that is the one
    // whose failure corrupts the shot rather than only the readout.
    inline constexpr float kDegenerateOriginEps = 1e-3f;

    inline bool is_degenerate_origin(const unity::vector3& v) {
        return std::fabs(v.x) < kDegenerateOriginEps
            && std::fabs(v.y) < kDegenerateOriginEps
            && std::fabs(v.z) < kDegenerateOriginEps;
    }

    // A fireport read that lands on the world origin is reported as a FAILED read, not
    // as a position.
    //
    // get_bifacial_position() only checks that the pointer was non-null and that a
    // get_position method existed, then returns whatever it read. So a
    // not-yet-resolved or not-yet-placed muzzle arrives as a confident {0,0,0} with
    // a `true` return, which is the most expensive possible shape for a caller: it
    // looks like success. Every caller here already has a defined action for false
    // and a wrong one for true, so the check belongs at the source:
    //
    //   AimbotModule::gameworld_update -> falls back to the rig position
    //   hk_initiate_shot                 -> falls back to the engine's own direction
    //   try_get_visibility_origin        -> tries the next origin in order
    //
    // Without it, the shot hook would have normalised (target - {0,0,0}) and pointed
    // every shot at the map corner, which is the one failure mode here that silently
    // corrupts the actual shot rather than merely mis-reporting visibility.
    inline bool try_get_fireport_position(Il2CppObject* player_obj, unity::vector3& out) {
        // ---- windowed cost accumulator -------------------------------------
        //
        // WHY THIS EXISTS, and it is not a Tracy zone.
        //
        // `aimbot::fireport_resolve` measured 310.59 s over 22,129 calls in the
        // 2026-10-04 14:36 capture -- 39.96% of the capture -- and the aggregate is
        // **bimodal**. Bucketing the per-event rows (`csvexport -u`, which carries
        // `ns_since_start`) gives:
        //
        //     3.5 minutes   13,812 calls   mean  1.44 us
        //     6.0 minutes    8,317 calls   mean 37,343 us      <- 25,873x
        //
        // A Tracy zone answers "how much" and cannot answer "when". `min_ns` and
        // `max_ns` do not localise a regime, and the CSV has no time axis beyond that.
        // So the one number that decides whether this is a loading-screen cost, a
        // raid-play cost, or both, **is not in the profile at all** -- and the profile
        // is the only artefact that survives the session.
        //
        // The log does carry a timeline (`Loading in at:`, `Local Raid Ended`), so the
        // fix is to put this number in the log too, on a fixed window, so the two can
        // be laid on top of each other. That is what `report_fireport_window()` prints.
        //
        // Deliberately a plain counter and NOT `TA_ZONE_IS_ACTIVE`: this is a
        // correctness question, not a profiling one, and it must not vanish when no
        // profiler is attached.
        // ---- TTL CACHE: a muzzle position does not need reading 24 times a second ----
        //
        // This is a DIFFERENT KIND of fix from the two that preceded it, and the difference is
        // the point. Both of those tried to infer a game STATE ("is the player placed") from
        // something observable and both were wrong: the probe printed
        // `my_pos=(70.76,0.23,-72.80) rig_degenerate=false` during the very window it was meant
        // to catch, because a loading-screen rig still carries a plausible coordinate. Inferring
        // state is what failed, twice.
        //
        // This infers nothing. It observes how fast the value can physically change -- it is a
        // MUZZLE position, consumed once per frame as a ray origin -- and reads it at a rate that
        // justifies. At ~42 ms per read against a 500 ms period the call happens on ~2.4% of
        // frames, so ~97.6% of the cost goes, and that also holds on the healthy path where the
        // read is 0.5 us and the real cost is the 24 Hz of managed traffic rather than any single
        // call.
        //
        // WHY IT LIVES HERE AND NOT IN THE CALLEE'S MEMO. `fp_state` below is per-call and dies
        // every frame, which is exactly why the read repeats at the game tick rate even though
        // this file already contains a memo. The cache has to outlive the call.
        //
        // Keyed on the player pointer: a new raid gets a new player object, so it cannot inherit
        // the previous raid's muzzle. A degenerate or failed read clears it rather than sticking,
        // so a bad value cannot persist for the TTL. Game-thread state only, like the window
        // accumulator above -- `try_get_fireport_position` is reached from
        // `gameworld_update` on the game thread, and the aimbot's callers are documented as
        // same-thread at :319.
        //
        // 500 ms is a judgement, and it is the only number here that is not measured. A muzzle
        // does not move 24x/second; if the game ever animates it, 500 ms is the ceiling on how
        // stale a ray origin can be, and the windowed accumulator above will show the read rate
        // change if that guess is wrong.
        static Il2CppObject* s_cached_for = nullptr;
        static unity::vector3  s_cached_pos{};
        static long long       s_cached_at_ms = -1;
        constexpr long long    kVisOriginFireportTtlMs = 500;
        const long long s_now_ms = monotonic_ms();
        if (s_cached_for == player_obj && s_cached_at_ms >= 0
            && (s_now_ms - s_cached_at_ms) < kVisOriginFireportTtlMs
            && !is_degenerate_origin(s_cached_pos))
        {
            out = s_cached_pos;
            return true;
        }


        ++g_fireport_win.calls;
        LARGE_INTEGER fp_win_t0{};
        QueryPerformanceCounter(&fp_win_t0);

        // Takes the start stamp BY VALUE. A local struct's destructor cannot
        // reach an enclosing function's local, and the alternative -- a
        // file-scope static for the stamp -- would be shared state across a
        // function with four call sites.
        struct fp_win_scope {
            LARGE_INTEGER t0;
            ~fp_win_scope() {
                LARGE_INTEGER t1{};
                QueryPerformanceCounter(&t1);
                const long long freq = g_fireport_win.freq;
                if (freq <= 0) return;
                const long long ns = ((t1.QuadPart - t0.QuadPart) * 1000000000LL) / freq;
                if (ns < 0) return;
                g_fireport_win.total_ns += (unsigned long long)ns;
                if ((unsigned long long)ns > g_fireport_win.max_ns)
                    g_fireport_win.max_ns = (unsigned long long)ns;
                // Regime split, counted here rather than derived at report time: by the
                // time the window closes the bimodality is invisible in the total, and
                // this function is bimodal by ~56,000x (fast ~1 us, slow ~52 ms).
                if ((unsigned long long)ns > kSlowCallUs * 1000ULL) {
                    g_fireport_win.slow_calls += 1;
                    g_fireport_win.slow_total_ns += (unsigned long long)ns;
                }
            }
        } fp_win_guard{ fp_win_t0 };

        if (!player_obj) return false;

        Il2CppObjectInstance player_inst(player_obj);
        const auto get_fireport = player_inst.get_method<Il2CppObject* (*)(Il2CppObject*)>("get_Fireport", 0);
        if (!get_fireport) return false;

        Il2CppObject* fireport = nullptr;
        {
            // `Player.get_Fireport()`, the first of the two managed calls, separated
            // from the resolve above and from `get_bifacial_position` below.
            //
            // Whether this or `get_position` carries the 37 ms is NOT known. The
            // accumulator above exists so that the log can answer it per window even
            // without a profiler attached.
            TA_ZONE_N("skeleton_vis::fireport:get_Fireport");
            fireport = get_fireport(player_obj);
        }
        if (!fireport) return false;

        if (!get_bifacial_position(fireport, out)) return false;
        if (is_degenerate_origin(out)) return false;
        return true;
        // Only a real position is cached: `is_degenerate_origin` is the same test the
        // function has always applied to its result, so caching cannot smuggle a {0,0,0}
        // through as a success on a later frame.
        s_cached_for = player_obj;
        s_cached_pos = out;
        s_cached_at_ms = s_now_ms;
    }

    // WHERE an occlusion ray starts, and how far we trust each candidate.
    //
    // Three sources, in an order that depends on WHO IS ASKING:
    //
    //   camera_first (ESP)   -- the camera is an eye position, which is the right
    //                           origin for "can the player SEE this".
    //   fireport_first (aim) -- the fireport is where the bullet actually starts,
    //                           which is the right origin for "can the bullet
    //                           REACH this". The shot hook re-derives its
    //                           direction from the fireport at fire time, so a
    //                           penetration walk anchored anywhere else would be
    //                           grading a shot the game is not going to take.
    //
    // Both orders then fall through to the same trust-tested camera, then to a
    // fixed estimate on the rig transform. Every source is anchored to
    // main_player by construction except the camera, which is the only one that
    // can be somebody else's.
    //
    // The old camera branch took unity::get_current_camera() and ignored its own
    // main_player argument entirely. Camera.current is the very value the ESP camera falls
    // back to, and the 2026-10-02 user report was that at raid start it could belong to a
    // BOT. If it did, every ray this file casts started at that bot's head.
    //
    // That would account for the counter result that otherwise made no sense:
    // hit_occluder 96.0% with hit_shooter and hit_target at exactly 0, over 2,993,970 rays.
    // A ray leaving the wrong character meets that character's surroundings, and the walk in
    // classify_hit_transform looks for the shooter and the target -- finds neither -- and
    // calls it "occluder". So the 96% may be substantially "cast from the wrong place",
    // not "targets are genuinely behind walls". Those two readings call for opposite fixes,
    // which is why the source is now counted rather than assumed.
    //
    // The radius is deliberately wider than the camera's own trust radius in eft_api.h
    // (kCamTrustRadius) because a wrong ORIGIN only skews a distance calculation, while a
    // wrongly refused DRAW camera blanks the overlay. Kept as two constants rather than one
    // shared one because this header does not include eft_api.h and should not grow a
    // dependency on it to share a literal.
    //
    // MEASURED IN METRES. This used to be written `(out - rig).length() <= kVisOriginTrustRadius`,
    // and vector3::length() returns the SQUARED magnitude (unity.cpp:41), so the test was
    // sq_dist <= 8 -- an effective radius of sqrt(8) = 2.83 m wearing an 8 m label. A camera
    // 3 m from the rig, which is a normal third-person shoulder offset, was being REJECTED as
    // "probably another player's". That silently pushed the ESP onto the fireport path far
    // more often than intended, which is the exact opposite of what the constant's own
    // comment says it is for. It is unity::length() now, and the free function is the true
    // Euclidean one -- same trap as the member, spelled differently.
    inline constexpr float kVisOriginTrustRadius = 8.0f;

    enum class vis_origin_source : int { camera = 0, fireport, rig_estimate, COUNT };
    inline constexpr int kVisOriginSourceCount = static_cast<int>(vis_origin_source::COUNT);

    enum class vis_origin_preference : int { camera_first = 0, fireport_first };

    // TWO counter sinks, not one.
    //
    // The original single array was reported as "origin camera=/fireport=/rig=", which read
    // as one property of the feature. It is not: ESP visibility and the aimbot's penetration
    // walk ask different questions of the same three sources, prefer different ones first,
    // and fire on entirely different rates. Sharing one array would have let a change in the
    // aimbot's cadence move the number being used to diagnose the ESP -- the same
    // un-attributable aggregate that made the 96% hit_occluder reading unreviewable in the
    // first place. So each caller counts into its own, and the report prints both labelled.
    inline std::atomic<unsigned long long>* g_vis_origin_counts() {
        static std::atomic<unsigned long long> counts[kVisOriginSourceCount];
        return counts;
    }

    // Aimbot's sink. Declared unconditionally (see the scope note at the top of this file)
    // so the reporter is ESP-only; in a no-aimbot build this stays zero.
    inline std::atomic<unsigned long long>* g_pen_origin_counts() {
        static std::atomic<unsigned long long> counts[kVisOriginSourceCount];
        return counts;
    }

    // `counts` defaults to the ESP sink, so every existing call site keeps both its
    // behaviour and its attribution.
    //
    // THE REFERENCE POINT, which is the subtle part.
    //
    // "Is this camera too far from us?" is only answerable if there is a point we
    // KNOW is ours. That used to be the rig transform, which is wrong twice over:
    // it is the read that can silently come back {0,0,0}, and it is a body-centre
    // position while the camera sits at head height and off to the shoulder, so
    // even when healthy the two are a couple of metres apart before any bot
    // suspicion is involved.
    //
    // The reference is now the FIREPORT, for the reason measured in-game: it is
    // resolved from main_player.get_Fireport() and is the exact point the bullet
    // leaves from, so it is both unambiguously ours and in the same neighbourhood
    // as the camera. The rig transform is the fallback reference, and only when it
    // is not degenerate.
    //
    // When neither reference exists, the established house rule is kept rather than
    // overturned: the camera stands. The rationale is unchanged ("cannot rank it,
    // do not guess") and the degenerate case is now visible in the counters rather
    // than silent -- `try_fireport` and `try_rig` both fail, so a frame that took
    // this path shows camera=+N with the other two flat, which is distinguishable
    // from the healthy case where camera wins because it IS close.
    inline bool try_get_visibility_origin(Il2CppObject* main_player, unity::vector3& out,
        vis_origin_preference pref = vis_origin_preference::camera_first,
        std::atomic<unsigned long long>* counts = nullptr,
        // Added 2026-10-04. See the note at the `fireport()` lambda below: this is the
        // ONE remaining path to the 200 s, and it needs the caller to be able to say
        // "there is nothing to read yet".
        //
        // Defaults to true, so every existing call site -- ESP's two, and any future
        // one -- keeps its current behaviour exactly. The aimbot's gameworld_update
        // passes `!hands_not_firearm`.
        bool allow_fireport_read = true) {
        if (!counts) counts = g_vis_origin_counts();
        Il2CppObject* main_tr = get_player_transform(main_player);
        const unity::vector3 rig = main_tr
            ? unity::transform_get_pos(main_tr) : unity::vector3{};
        const auto credit = [counts](vis_origin_source src) {
            counts[static_cast<int>(src)].fetch_add(1, std::memory_order_relaxed);
        };

        // An unpopulated rig must not become the yardstick, and must not become the
        // origin either. `has_rig` gates both uses.
        const bool has_rig = main_tr && !is_degenerate_origin(rig);

        // Memoised fireport read. Resolving it costs TWO UNCACHED name->method walks
        // (get_Fireport, then get_position on the Bifacial) -- il2utils::resolve_method
        // has no cache, unlike resolve_field -- so it is not something to spend on a
        // frame where the camera is accepted outright. The memo means the trust-test
        // reference and the try_fireport() fallback can share one read instead of
        // racing to perform two.
        //
        // MEASURED, and this is no longer a footnote. In `+8+transit+crash` this
        // lambda carried **202.14 s inclusive over 9,355 calls -- 99.7% of
        // AimbotModule::gameworld_update** -- at 21,608 us mean and 80.86 ms max,
        // while the gated direct call site above it (`aimbot::fireport_resolve`)
        // measured 0.00 s. The cost is `Bifacial.get_position()`, and it is
        // expensive exactly when `has_rig` is false: an unpopulated rig IS the
        // loading screen, and that is the only condition that reaches this lambda.
        //
        // So `allow_fireport_read == false` makes the read impossible rather than
        // merely unlikely. What that costs: with no reference point, `has_ref`
        // stays false and the camera trust test cannot run -- which is the
        // documented house rule for that case already ("cannot rank it, do not
        // guess", camera stands). It is not a new degradation; it is the existing
        // one, reached deliberately instead of after a 40-70 ms managed call that
        // was going to be discarded.
        int fp_state = -1; // -1 not tried, 0 failed, 1 ok
        unity::vector3 fp_pos{};
        const auto fireport = [&]() -> const unity::vector3* {
            if (!allow_fireport_read) return nullptr;
            if (fp_state < 0) {
                // Labelled like every other call site, and with the guard so this
                // memo cannot inherit a stale label -- which is exactly what it did
                // in `+8`, where its 9,355 expensive calls were reported as
                // `aimbot/gameworld_update` (11,063) and its worst ones as `unknown`.
                FIREPORT_SITE("vis_origin/fireport_memo");
                fp_state = try_get_fireport_position(main_player, fp_pos) ? 1 : 0;
            }
            return fp_state ? &fp_pos : nullptr;
        };

        // Reference point for the camera trust test.
        //
        // The rig transform is used when it is healthy, because it costs nothing extra
        // and is what this function always compared against. Only when it is ABSENT or
        // UNPOPULATED does it fall back to the fireport, which is the case that was
        // actually broken: a rig sitting at the world origin made every real camera
        // look tens of metres away, so it got rejected as another player's, and the
        // rig fallback then supplied {0,0,1.6} as a ray origin.
        //
        // So the fireport is a REPAIR for the degenerate case rather than a change of
        // yardstick for every frame. Preferring it unconditionally would have been
        // marginally more faithful to the in-game measurement but would pay two method
        // walks per frame forever to fix a window that lasts a second or two at raid
        // start.
        unity::vector3 ref = rig;
        bool has_ref = has_rig;
        if (!has_ref)
            if (const unity::vector3* fp = fireport()) { ref = *fp; has_ref = true; }

        // The camera is taken ONLY when it is demonstrably ours. Without this test the
        // branch was the single largest source of wrong answers available to this file, and
        // it looked like the most trustworthy of the three because it is a real eye position.
        const auto try_camera = [&]() -> bool {
            Il2CppObject* cam = unity::get_current_camera();
            if (!cam) return false;
            Il2CppObject* cam_go = unity::component_get_game_object(cam);
            Il2CppObject* cam_tr = cam_go ? unity::gameobject_get_transform(cam_go) : nullptr;
            if (!cam_tr) return false;
            const unity::vector3 cam_pos = unity::transform_get_pos(cam_tr);
            // A camera at the world origin is a failed read, not a camera.
            if (is_degenerate_origin(cam_pos)) return false;
            // With no usable reference there is nothing to compare against, so the
            // camera stands -- the same "cannot rank it, do not guess" rule the camera
            // picker uses for the draw camera.
            if (!has_ref)
            {
                out = cam_pos;
                credit(vis_origin_source::camera);
                return true;
            }
            if (unity::length(cam_pos - ref) > kVisOriginTrustRadius) return false;
            out = cam_pos;
            credit(vis_origin_source::camera);
            return true;
        };

        // Anchored to main_player by construction -- it comes off main_player.get_Fireport()
        // -- so it needs no trust test, which is what makes it both the first choice for a
        // bullet-tracing walk and the right thing to fall back to when the camera turns out
        // to be someone else's. try_get_fireport_position() already rejects a degenerate
        // read, so reaching here means the value is usable.
        const auto try_fireport = [&]() -> bool {
            const unity::vector3* fp = fireport();
            if (!fp) return false;
            out = *fp;
            credit(vis_origin_source::fireport);
            return true;
        };

        const auto try_rig = [&]() -> bool {
            if (!has_rig) return false;
            out = rig;
            out.y += 1.6f;
            credit(vis_origin_source::rig_estimate);
            return true;
        };

        if (pref == vis_origin_preference::fireport_first)
            return try_fireport() || try_camera() || try_rig();
        return try_camera() || try_fireport() || try_rig();
    }

    // Occlusion check: blocked only when the first hit is NOT part of the target player hierarchy.
    //
    // Zoned, and the same name is used on the penetrating variant below so the two
    // aggregate into one bucket: this is the mod's most expensive optional work --
    // an IL2CPP call into the engine's physics per target per frame -- and
    // skeleton_visibility.h had no zone at all, so a per-target frame path sat
    // entirely inside the 67% of the 2026-10-01 profile that no zone accounted for.
    // EVERY exit from is_target_visible, counted. Three counters were not enough and the
    // reason is worth stating, because it is the same mistake as the zone split: counting only
    // the branch you are looking at.
    //
    // The function has SEVEN exits, and the three I first added sat only on the last three:
    //
    //   1 not_ready       !is_ready() || !target_player_obj
    //   2 ray_miss        g_linecast returned false
    //   3 inside_hit      hit within 0.05m, or a degenerate normal
    //   4 no_transform    g_hit_get_transform gave null
    //   5 hit_shooter     the walk found OUR OWN hierarchy
    //   6 hit_target      the walk found the target's hierarchy
    //   7 hit_occluder    the walk exhausted 48 hops -- real cover
    //
    // Exits 2, 3 and 4 are the ones a hit-focused counter set cannot see at all, and they are
    // precisely the ones that decide the questions being asked: "is the mask letting through
    // geometry that never occludes" is mostly about exit 7, while "are we hitting ourselves" is
    // exit 5. Counting three of seven would have produced numbers that do not add up and a
    // conclusion drawn from the remainder.
    //
    // THE SET IS CLOSED ON PURPOSE: every exit increments exactly one slot, so the buckets sum
    // to the call count by construction. That makes the report SELF-VERIFYING -- if the sum
    // ever disagrees with the zone's count, an exit was added without being counted, and the
    // numbers are not to be believed. A partial counter set cannot detect itself failing.
    //
    // Plain unsigned long long, not atomics, and deliberately: incremented and read on the
    // game thread only (is_target_visible is called from collect_skeleton, which runs in
    // gameworld_update). Same reasoning as probe_memo_stats, which makes the same trade for
    // the same reason.
    enum class vis_exit : int { not_ready = 0,
        ray_miss,
        inside_hit,
        no_transform,
        hit_shooter,
        hit_target,
        hit_occluder,
        COUNT };

    inline constexpr int kVisExitCount = static_cast<int>(vis_exit::COUNT);

    inline unsigned long long* g_vis_exit_counts() {
        static unsigned long long counts[kVisExitCount] = {};
        return counts;
    }
    inline unsigned long long& g_vis_exit_total() {
        static unsigned long long v = 0;
        return v;
    }

    // ---- pen-check tally ---------------------------------------------------
    //
    // THE GAP THIS CLOSES. The breakdown above was the only numeric record of
    // what these rays hit, and it is fed exclusively by is_target_visible. Every
    // Magic Aim pen check therefore reported nothing at all: not how often it
    // cleared, not how often it blocked, and above all not WHY. The only trace
    // was one `pen-check:` string every 500 ms, which cannot answer "is the wall
    // check discarding 90% of targets or 0.1%?" -- and that was the actual open
    // question in the #20 thread.
    //
    // Same shape as vis_exit for the same reason: one slot per pen_stop, closed,
    // with the sum asserted against the call count in the dump. The write happens
    // at exactly one place (record_stop / the clear exit), so "every call lands in
    // exactly one bucket" is true by construction rather than by discipline, and
    // the [closed]/[MISMATCH] marker in the report is what proves it at runtime.
    //
    // Game thread only, same trade as g_vis_exit_counts and for the same reason:
    // is_target_visible_penetrating runs in AimbotModule::gameworld_update.
    inline unsigned long long* g_pen_stop_counts() {
        static unsigned long long counts[kPenStopCount] = {};
        return counts;
    }
    inline unsigned long long& g_pen_stop_total() {
        static unsigned long long v = 0;
        return v;
    }

    // Throttled breakdown, called from the game thread so the read matches the writes.
    // Reports the window AND the lifetime totals, because the lifetime numbers are the ones
    // that stay meaningful when a window happens to catch no rays.
    inline void maybe_report_hit_breakdown() {
        static auto s_last = std::chrono::steady_clock::now();
        constexpr long long kDumpMs = 30000;
        const auto now = std::chrono::steady_clock::now();
        if (now - s_last < std::chrono::milliseconds(kDumpMs)) return;
        s_last = now;

        unsigned long long* c = g_vis_exit_counts();
        const unsigned long long total = g_vis_exit_total();
        unsigned long long sum = 0;
        for (int i = 0; i < kVisExitCount; ++i) sum += c[i];
        // Self-check: the closed set guarantees sum == total. If it ever does not, an exit
        // path exists that is not counted, and every percentage below is unsafe to read.
        logger::info("vis-breakdown: total=" + std::to_string(total)
            + " not_ready=" + std::to_string(c[static_cast<int>(vis_exit::not_ready)])
            + " ray_miss=" + std::to_string(c[static_cast<int>(vis_exit::ray_miss)])
            + " inside_hit=" + std::to_string(c[static_cast<int>(vis_exit::inside_hit)])
            + " no_transform=" + std::to_string(c[static_cast<int>(vis_exit::no_transform)])
            + " hit_shooter=" + std::to_string(c[static_cast<int>(vis_exit::hit_shooter)])
            + " hit_target=" + std::to_string(c[static_cast<int>(vis_exit::hit_target)])
            + " hit_occluder=" + std::to_string(c[static_cast<int>(vis_exit::hit_occluder)])
            + (sum == total ? " [closed]" : " [MISMATCH sum=" + std::to_string(sum) + "]")
            // THE MASK, on the same line and the same window. `hit_target=0` and
            // `hit_shooter=0` are only interpretable next to the mask that produced
            // them: those exits are unreachable precisely because the union contains
            // no player layer, and `fallback=1` would mean the whole thing was
            // guessed. Printed as the unsigned decimal of the bitmask, because a
            // 32-bit mask in hex reads as negative in int and %08X is not worth the
            // signedness trap here.
            + " | mask=" + std::to_string(g_occlusion_mask_report.effective)
            + " fallback=" + std::to_string(g_occlusion_mask_report.fallback_only)
            + " settings=" + std::to_string(g_occlusion_mask_report.settings_resolved) + "/3"
            + " layers=" + std::to_string(g_occlusion_mask_report.layers_resolved) + "/8"
            + " occlusion_api=" + std::to_string(g_occlusion_mask_report.occlusion_api_resolved) + "/2"
            // Origin source on the same line and the same 30 s window: it is read on this
            // thread, it is the other half of the same question (where the rays came from,
            // as opposed to what they hit), and a second throttle would only cost the two
            // halves the ability to be read against each other.
            + " | origin camera="
            + std::to_string(g_vis_origin_counts()[static_cast<int>(vis_origin_source::camera)]
                .exchange(0, std::memory_order_relaxed))
            + " fireport="
            + std::to_string(g_vis_origin_counts()[static_cast<int>(vis_origin_source::fireport)]
                .exchange(0, std::memory_order_relaxed))
            + " rig="
            + std::to_string(g_vis_origin_counts()[static_cast<int>(vis_origin_source::rig_estimate)]
                .exchange(0, std::memory_order_relaxed)));

        // Same window, same line: the pen-check tally answers the OTHER question --
        // what the MAGIC AIM wall check concluded, and on what grounds -- and it was
        // previously unreported entirely, which is why #20 was still open with no way
        // to tell a wall check working correctly from one discarding every target.
        //
        // Its origin source is printed too, separately from the ESP's, because the two
        // prefer different sources first (fireport vs camera) and fire at completely
        // different rates. Sharing one column would have made both unreadable.
        unsigned long long* p = g_pen_stop_counts();
        const unsigned long long pen_total = g_pen_stop_total();
        unsigned long long pen_sum = 0;
        std::string pen_line;
        if (pen_total == 0)
        {
            // Distinguish "no pen check ran" from "the counter is broken". In a no-aimbot
            // build this is the permanent answer and saying so beats printing zeros that
            // read like a wall check which never fired.
            pen_line = "pen: total=0 (no aimbot build / wall check never ran)";
        }
        else
        {
            for (int i = 0; i < kPenStopCount; ++i) {
                pen_sum += p[i];
                if (p[i] == 0) continue;   // keep the line short; a zero is not news
                pen_line += std::string(" ") + pen_stop_name(static_cast<pen_stop>(i))
                    + "=" + std::to_string(p[i]);
            }
            pen_line = "pen: total=" + std::to_string(pen_total) + pen_line
                + (pen_sum == pen_total
                    ? std::string(" [closed]")
                    : " [MISMATCH sum=" + std::to_string(pen_sum) + "]")
                + " | pen-origin camera="
                + std::to_string(g_pen_origin_counts()[static_cast<int>(vis_origin_source::camera)]
                    .exchange(0, std::memory_order_relaxed))
                + " fireport="
                + std::to_string(g_pen_origin_counts()[static_cast<int>(vis_origin_source::fireport)]
                    .exchange(0, std::memory_order_relaxed))
                + " rig="
                + std::to_string(g_pen_origin_counts()[static_cast<int>(vis_origin_source::rig_estimate)]
                    .exchange(0, std::memory_order_relaxed));

            // Skipped layers, appended here so they land BEFORE the reset below and so
            // they are on the SAME line as the verdicts they change.
            //
            // On the same line deliberately: the reader's question is "how many of these
            // `clear` verdicts are clean?", and a skip count on a different line cannot
            // be correlated with the verdicts it might have caused. `skippedLayers=`
            // rather than another pen_stop bucket, because a skip is not a verdict --
            // see the invariant on pen_stop.
            pen_line += " | skippedLayers=" + std::to_string(g_pen_skip_hierarchy())
                + " (hierarchy=" + std::to_string(g_pen_skip_hierarchy())
                + ", sameBallistic=" + std::to_string(g_pen_skip_same_ballistic())
                + ") | reEntry=" + std::to_string(g_pen_reentry());
        }
        logger::info(pen_line);

        for (int i = 0; i < kVisExitCount; ++i) c[i] = 0;
        g_vis_exit_total() = 0;
        for (int i = 0; i < kPenStopCount; ++i) p[i] = 0;
        g_pen_stop_total() = 0;
        g_pen_skip_hierarchy() = 0;
        g_pen_skip_same_ballistic() = 0;
        g_pen_reentry() = 0;

        // Whether the visibility-check distance cap is set right, as opposed to guessed.
        // See g_vis_rays_players_in for what a reader does with these three.
        logger::info("vis-dist-cap: playersIn=" + std::to_string(g_vis_rays_players_in())
            + " playersOut=" + std::to_string(g_vis_rays_players_out())
            + " bonesSkipped=" + std::to_string(g_vis_rays_bones_skipped())
            + " | raysOut ~= playersOut*~17.6 bones*~10.9us per frame avoided");
        reset_vis_distance_counters();

        const unsigned long long cone_culled = g_vis_cone_culled();
        const unsigned long long cone_built = g_vis_cone_built();
        const unsigned long long cone_total = cone_culled + cone_built;
        logger::info("vis-cone: built=" + std::to_string(cone_built)
            + " culled=" + std::to_string(cone_culled)
            + " of=" + std::to_string(cone_total)
            + " culledPct="
            + std::to_string(cone_total ? (100 * cone_culled / cone_total) : 0)
            + "% | saved ~= culled*~0.22ms per frame; a 70deg cone is 19% of a circle, "
            "so ~81% is the ceiling if every off-screen player is behind the camera");
        reset_vis_cone_counters();
    }

    inline bool is_target_visible(const unity::vector3& origin, const unity::vector3& target,
        Il2CppObject* target_player_obj, Il2CppObject* shooter_obj = nullptr) {
        TA_ZONE_N("skeleton_vis::is_target_visible");
        ++g_vis_exit_total();
        if (!is_ready() || !target_player_obj) {
            ++g_vis_exit_counts()[static_cast<int>(vis_exit::not_ready)];
            return true;
        }

        const int layer_mask = try_get_occlusion_layer_mask();
        raycast_hit hit{};

        // Split from is_target_visible's self time. The 2026-10-01 current+6 capture put
        // this function at 69.32 s / 9.26% over 5,534,508 calls (12.5 us mean, 9.27 ms
        // max) -- the largest single leaf in the module -- with no way to tell how much was
        // the physics query and how much was the hierarchy walk below. Optimising that
        // blind is how the earlier round went wrong, so the split comes first.
        {
            TA_ZONE_N("skeleton_vis::occlusion_linecast");
            if (!g_linecast(origin, target, layer_mask, query_ignore_triggers, &hit)) {
                ++g_vis_exit_counts()[static_cast<int>(vis_exit::ray_miss)];
                return true;
            }
        }

        // Filter out inside-hits: very close distance or invalid normal indicates point is inside mesh
        //
        // unity::length(), NOT the member. The member returns the SQUARED magnitude
        // (unity.cpp:41), so the original `hit.m_normal.length() < 0.1f` was really
        // testing |n|^2 < 0.1, i.e. a |n| threshold of ~0.316 -- three times looser than
        // the number in the source. Both appear in the pen walk too; both are fixed
        // together here. The direction of the change is the safe one: this branch
        // returns TRUE (visible), so a stricter normal test converts some
        // former "occluder" verdicts into "clear", never the reverse.
        if (hit.m_distance < 0.05f || unity::length(hit.m_normal) < 0.1f) {
            ++g_vis_exit_counts()[static_cast<int>(vis_exit::inside_hit)];
            return true;
        }

        Il2CppObject* hit_transform = g_hit_get_transform(&hit);
        if (!hit_transform) {
            ++g_vis_exit_counts()[static_cast<int>(vis_exit::no_transform)];
            return true;
        }

        // Its own block, because TA_ZONE_N expands to a variable literally named `ta_zone`
        // and two in one scope is a redefinition (C2374).
        {
            TA_ZONE_N("skeleton_vis::is_player_transform");
            // THE QUICK EXIT, and it changes the answer rather than just the cost.
            //
            // shooter is the LOCAL player, not another member of AllAlivePlayerList -- the
            // ESP skips it as a draw target (EspModule.cpp:5341) but its body is still in the
            // scene, and the ray origin sits on it. When the ray hits our OWN collider that is
            // not cover, so it must not count as blocked. The previous test searched only for
            // the target's transform and therefore classified that hit as occluded.
            const hit_owner owner = classify_hit_transform(hit_transform, shooter_obj, target_player_obj);
            unsigned long long* counts = g_vis_exit_counts();
            switch (owner)
            {
            case hit_owner::shooter:
                ++counts[static_cast<int>(vis_exit::hit_shooter)];
                return true;
            case hit_owner::target:
                ++counts[static_cast<int>(vis_exit::hit_target)];
                return true;
            case hit_owner::none:
                ++counts[static_cast<int>(vis_exit::hit_occluder)];
                return false;
            }
            // Unreachable: hit_owner has three enumerators and all are handled. Counted
            // anyway so the closed-set invariant cannot be broken by a future enumerator
            // added without a case here.
            ++counts[static_cast<int>(vis_exit::hit_occluder)];
            return false;
        }
    }

    // Penetration-aware visibility: like is_target_visible, but a blocked ray only
    // counts as blocked when the loaded ammo could NOT punch through the obstacle.
    //
    // ammo_power      — PenetrationPower of the chambered ammo (EFT 1–70 class scale)
    // ammo_obst_chance — PenetrationChanceObstacle of the ammo (0..1), -1 = unknown
    // ammo_ricochet    — AmmoTemplate.RicochetChance; only the SIGN is used (see
    //                     kRicochetBlockAt). -1 = unknown, treated as "can deflect".
    //
    // NOTE: wall-check settings must keep the OCCLUSION ray mask; penetration is
    // only "modeled" for colliders carrying a BaseBallistic/BallisticCollider.
    // Plain LowPoly/Terrain hits (no component) are treated as NOT penetrable,
    // mirroring Shot.CheckCollision where a hit without a component is a wall stop.
    //
    // `shooter_obj` (the LOCAL player) is NOT optional in spirit: pass it, or pass
    // null and accept the behaviour below. It did not exist here at all until now,
    // while is_target_visible has had it for a while, and the omission is not
    // cosmetic. This walk's origin is the shooter's own fireport, so the first
    // collider the ray can meet is frequently the shooter's own body -- and this
    // function used to test hits with is_player_transform(), which calls
    // classify_hit_transform() with a NULL shooter and therefore cannot tell "our
    // own arm" from "a wall". Our own arm was then walked as a LAYER, found to
    // carry no BallisticCollider, and reported as
    // `no BallisticCollider on hit chain (env/terrain)` -> BLOCKED. That is the
    // ESP's exact bug (fixed there via hit_owner::shooter), reintroduced here.
    //
    // The three-way classify is what makes the self-hit a non-event: it is a clear
    // line, skipped without consuming layer budget, and counted separately in the
    // breakdown so "the ray left the fireport and immediately met us" is visible
    // as its own number rather than inferred from a wall verdict.
#ifdef INCLUDE_AIMBOT
    inline bool is_target_visible_penetrating(const unity::vector3& origin,
        const unity::vector3& target, Il2CppObject* target_player_obj,
        float ammo_power, float ammo_obst_chance, float ammo_ricochet = -1.f,
        Il2CppObject* shooter_obj = nullptr) {
        // NOT the name used by is_target_visible above. They were one zone, which
        // made them one row in any export and hid that they are not remotely the
        // same cost. The 2026-10-03 capture has the split:
        //
        //   skeleton_vis::is_target_visible          2,533,776 calls   10.9 us mean
        //   this function                                    9,874 calls  130.6 us mean
        //
        // A 12x difference in per-call cost, from the same raycast helper, because
        // this one walks layers and reads BallisticCollider fields while the ESP one
        // stops at the first occluder. Averaging them together produced a single
        // meaningless 10.9 us figure and a per-call number that understated the pen
        // path by an order of magnitude -- which is exactly the number you would
        // budget against when deciding whether the pen walk is affordable.
        //
        // Distinct names rather than distinct source lines: Tracy's export keys on
        // the name, so a shared name is only separable by hand in the UI, and any
        // cross-session aggregation silently merges them again.
        TA_ZONE_N("skeleton_vis::is_target_visible_penetrating");
        // Routed through finish() like every other exit, so it lands in the tally. It
        // used to be a bare `return true` above every piece of pen-check
        // machinery, which made it uncountable: a physics layer that failed to
        // initialise was indistinguishable from a pen check that never ran.
        if (!is_ready() || !target_player_obj) {
            ++g_pen_stop_total();
            ++g_pen_stop_counts()[static_cast<int>(pen_stop::not_ready)];
            return true;
        }

        // Bullet-truth raycast: the game's own HitMask covers exactly what bullets
        // collide with.
        //
        // THIS MASK IS LOAD-BEARING, which a two-day detour established the hard way.
        // It was turned off here on the inference that HitMask correlated 2-for-2 with
        // a fatal fault (both crashes did follow a `pen-check: bullet HitMask` line).
        // The inference was wrong. The 17:54 run crashed WITH the occlusion mask, which
        // exonerated it -- and the pen-check lines from that same run show what the
        // occlusion mask actually costs:
        //
        //   L0 go='jacket_02_LOOTABLE'         noBallisticChain
        //   L1 go='Area_02_inside_wall_D_COLLIDER'  noBallisticChain
        //   L2 go='Loader_01_COLLIDER'         noBallisticChain
        //   L3 go='Area_02_inside_wall_A_COLLIDER'  noBallisticChain
        //   -> BLOCKED, accumulated=1.000
        //
        // EVERY layer, every time, `no BallisticCollider on hit chain`. The occlusion
        // mask does not merely add noise (the comment this replaced said it hit
        // "catwalk gratings that bullets fly straight through", which is true but is
        // the smaller half): it EXCLUDES the layer the `*_BALLISTIC_*` objects live on,
        // so the raycast lands on the plain `*_COLLIDER` visual meshes instead. Those
        // carry no BallisticCollider, the game's resolver returns null, the walk falls
        // through to "env/terrain", and it blocks everything. `accumulated=1.000` is
        // the tell: no layer ever contributed a chance, because no layer was ever
        // classified.
        //
        // So the feature cannot work without this mask, and the crash was never it.
        // The crash was read_ballistic_identity making an unguarded managed call on a
        // freed collider; see that function.
        int layer_mask = try_get_occlusion_layer_mask();
        if constexpr (kUseBulletHitMask)
        {
            if (const int bullet_mask = try_get_bullet_layer_mask(); bullet_mask != 0)
                layer_mask = bullet_mask;
        }

        // --- #20 penetration diagnostics ---------------------------------------
        // 2026-09-26: RETAINED (was marked TEMPORARY) and moved from logger::info to
        // logger::debug. Penetration is signed off as good, so this is now a standing
        // diagnostic rather than a temporary campaign: it stays available behind the
        // (now single) Debug Log toggle without spamming the console at INFO. Keep the
        // 500 ms throttle - without it this dump is unusable.
        // Covers: per-layer hit GOs and their BallisticCollider values, the gate that
        // fired on each layer, the accumulated multi-layer chance, and ammo data as
        // passed in (the ammo layer is also dumped on-change in AimbotModule).
        static ULONGLONG s_last_dump_ms = 0;
        const ULONGLONG now_ms = GetTickCount64();
        const bool log_dump = (now_ms - s_last_dump_ms) >= 500;

        // Whether this call prints its whole path rather than stopping at the
        // first blocker. Gated on the SAME 500 ms throttle as the logging, on
        // purpose: the throttle is what limits output to roughly one call per
        // half second, so the calls that get printed are already the ones worth
        // printing completely. There is no volume reason to truncate a path that
        // is being printed anyway.
        //
        // Why it matters: the walk used to return false at the first layer that
        // failed, so the log ended there. Measured on the 2026-10-02 15:13-15:16
        // session, 120 of 120 "BLOCKED at layer 0" lines contained zero L1+
        // content -- which means a wrong BLOCKED and a correct one printed
        // identically and the log could not falsify its own verdict.
        //
        // trace CANNOT change the verdict. The first stopping layer is recorded
        // in stop_layer and the function returns stop_layer < 0, so a trace that
        // walked past a blocker and reached the target still reports blocked.
        // Also requires debug logging, which log_dump does not. log_dump is a
        // pure 500 ms wall-clock throttle with no logger::debug_enabled() test
        // anywhere in it, so roughly one call per 500 ms built `diag` and walked
        // past blockers even with the Debug Log toggle off. My previous commit
        // message asserted the opposite and was wrong about it.
        //
        // The throttle itself is left alone: it predates this change and its
        // cadence is what the dump's rate is calibrated against.
        const bool trace = log_dump && logger::debug_enabled();

        // Declared here rather than further down because finish() below captures
        // all three, and a lambda's capture set is fixed where the lambda is
        // written -- an identifier declared after it is simply not in scope.
        std::string diag;
        float accumulated = 1.f;
        // Hoisted out of the for-statement's init-clause for the same reason.
        // Carried across iterations already: the loop has no increment-expression
        // and `++layer` happens at the classified-layer points in the body, so
        // this changes its lifetime and nothing else.
        int layer = 0;

        // First layer that stopped the round, and why. -1 = nothing stopped it.
        int stop_layer = -1;
        std::string stop_reason;
        // The COUNTED half of "why". stop_reason is free text and is only ever
        // printed; this is the enum the 30 s breakdown tallies, so a wall check
        // blocking 90% of targets becomes a number instead of a paragraph. It is
        // derived from stop_layer, never set independently, so the two cannot
        // describe different things.
        pen_stop stop_code = pen_stop::none;
        // const std::string&, NOT std::string_view: three callers below pass
        // std::format(...).c_str(), and the temporary std::string that owns those
        // characters dies at the end of the full expression. A string_view
        // parameter would be left pointing at freed memory and the assignment
        // here would read it. Binding to a const reference materialises the
        // temporary for the whole call, which includes that assignment.
        //
        // `code` is mandatory at every call site even where a dynamic string is
        // also produced (the ricochet and sibling cases): a tally whose buckets
        // depended on whether the caller felt like supplying one would not be a
        // closed set, which is the only property that makes it trustworthy.
        const auto record_stop = [&](int at_layer, pen_stop code, const std::string& why) {
            if (stop_layer < 0) {
                stop_layer = at_layer;
                stop_code = code;
                stop_reason = std::string(why);
            }
        };

        // The single line this call emits, and the verdict it returns. Every exit
        // in trace mode goes through here, so the line always covers the whole
        // path: which layer stopped the round, what was behind it, and what the
        // accumulated chance would have been had the round survived.
        //
        // In trace mode the per-layer "DECISION:" emissions inside the walk are
        // suppressed (they are guarded on !trace) precisely so this can be the
        // only output -- otherwise the reader still gets a truncated line first
        // and the full one second.
        //
        // IT IS ALSO THE ONLY PLACE THE TALLY IS WRITTEN -- with one exception, the
        // not-ready bail above, which increments the counters directly because it sits
        // before this lambda exists. Routing every exit through one function is what
        // makes the counter set closed: "exactly one slot per call" is then a property
        // of the control flow instead of a rule the next person has to remember. Two
        // exits used to be bare `return false;` / `return true;` statements with no
        // counting at all (the no-ammo bail and the degenerate-ray bail) -- the first
        // of which is the single most likely reason a wall check silently discards
        // every target in a raid. Both come through here now.
        //
        // The bucket is stop_code, which is derived from the recorded stop rather
        // than from the exit site. That distinction is deliberate: in trace mode
        // the walk runs PAST a blocking layer and can then end on "raycast hit
        // with no transform", but the verdict it returns is still BLOCKED because
        // of the recorded stop. Counting the exit site would have filed that call
        // under a clear-path bucket while it returned false.
        const auto finish = [&](bool penetrable, std::string_view note) -> bool {
            ++g_pen_stop_total();
            ++g_pen_stop_counts()[static_cast<int>(stop_code)];
            if (!log_dump) return penetrable;
            // The HEADLINE verdict is derived from the value being returned, not
            // from the caller's note. A caller reaching here may be exiting on its
            // own terms while an EARLIER layer already recorded a stop, in which
            // case `penetrable` is false and the note is only the detail.
            //
            // This was the bug the 2026-10-02 20:56 session exposed: 189 lines
            // annotated blocked layers and still printed "PENETRABLE - ...",
            // because every caller's note was hand-written on the assumption that
            // its own branch decided the outcome. The return value was right, so
            // no shot went through stone -- but the log said penetrable through
            // solid rock, which sent the investigation at the targeting logic
            // rather than at the log.
            std::string line = diag + " | DECISION: "
                + (penetrable ? "PENETRABLE" : "BLOCKED");
            if (!note.empty())
                line += " - " + std::string(note);
            // The reason is printed here rather than left implicit in diag,
            // because it is the field the whole change exists to expose, and
            // diag does not carry it for every stop: the ricochet and
            // no-BallisticCollider per-layer lines report risk figures and a
            // geometry parent name rather than a reason string.
            if (stop_layer >= 0)
                line += std::format(
                    " | TRACED: stopped at L{} ({}), {} further layer(s) behind it, "
                    "accumulated would have been {:.4f}",
                    stop_layer, stop_reason,
                    layer > stop_layer ? layer - stop_layer : 0, accumulated);
            logger::debug(line);
            return penetrable;
        };
        if (log_dump)
        {
            s_last_dump_ms = now_ms;
            diag = std::format(
                "pen-check: ammo power={} obst={:.3f}", static_cast<int>(ammo_power),
                ammo_obst_chance);
        }

        // No ammo data: keep the old, conservative behavior.
        //
        // Routed through finish() with an EXPLICIT stop_code rather than left as a bare
        // `return false`, because this is the single most likely reason a wall check
        // silently discards every target in a raid: reload with no round chambered, or
        // hands holding something that is not a firearm, and cached_.penetration_power
        // is 0. It was completely invisible -- no counter, and the log line explaining
        // it was only reachable through the 500 ms trace.
        if (ammo_power <= 0.f)
        {
            stop_layer = 0;
            stop_code = pen_stop::no_ammo;
            stop_reason = "no ammo data (pen power <= 0)";
            return finish(false,
                "no ammo data (pen power <= 0; see 'Magic Aim ammo cache' line)");
        }

        // --- multi-layer penetration walk ----------------------------------------
        // EFT rolls penetration PER BallisticCollider layer: the bullet continues
        // past a penetrated layer (degraded) and must beat the next one too.
        // Two layers — a wooden box in front of a brick wall — rarely both
        // penetrate, so classifying only the FIRST hit wildly overestimated
        // visibility (user footnote 2026-09-24 night 2). Walk the ray through
        // every blocker: classify each layer, accumulate the chance product,
        // advance past the layer, repeat until the ray reaches the target.
        // LAYER BUDGET: 3, was 4. Reduced 2026-10-04 on the user's call -- a target
        // behind more than three penetrable layers is not worth shooting at, and the
        // verdict was already BLOCKED. Evidence, the saving, and the one residual
        // risk are written out at the walk's exit, above `record_stop(...,
        // pen_stop::budget_layers ...)`.
        constexpr int kMaxLayers = 3;       // classified layers; more = conservative block
        constexpr int kMaxCasts = 16;       // total raycasts incl. exit-skip advances
        constexpr float kLayerEps = 0.05f;  // step past a penetrated surface
        constexpr float kMinAccumulated = 0.05f;

    // An exit face of the layer just penetrated sits IMMEDIATELY behind it: the origin
    // is advanced by (hit distance + kLayerEps) only. Measured 0.09 m in the
    // awning _BALLISTIC_ -> _COLLIDER case that motivated the rule.
    //
    // This bound is what makes the exit rule safe. The rule must also require the new
    // hit to be CLOSE, not merely RELATED: EFT nests map geometry deeply, so a wall
    // and the cover behind it routinely share an ancestor or a parent. Requiring
    // relatedness alone silently discarded genuinely separate colliders, so only the
    // FIRST ballistic layer was ever accounted for and everything behind it was
    // ignored — a false "penetrable" straight through a second wall.
    constexpr float kExitFaceMaxDist = 0.4f;

        // EFT bullet rule (user, 2026-09-25): a collider is penetrated ONCE — the
        // exit collision with the SAME ballistic object does not count as another
        // layer. The occlusion raycast re-hits the object's plain _COLLIDER
        // sibling / back face right after a pass (log: awning L0
        // '_BALLISTIC_genericsoft' -> L1 '_COLLIDER' 0.09 m later), so those
        // re-hits must be skipped, not classified as new opaque layers.
        Il2CppObject* prev_hit_go = nullptr;
        Il2CppObject* prev_parent_go = nullptr;
        Il2CppObject* prev_ballistic = nullptr;
        int casts = 0;

        float ox = origin.x, oy = origin.y, oz = origin.z;
        float dirx = target.x - origin.x, diry = target.y - origin.y, dirz = target.z - origin.z;
        const float total_len = std::sqrt(dirx * dirx + diry * diry + dirz * dirz);
        if (total_len < 0.1f)
        {
            // Routed through finish() so it is counted. Worth naming: an origin and a
            // target within 10 cm of each other is what a degenerate target bone read
            // produces, and returning `true` from here reported "clear line" for it --
            // a pass the walk never actually verified.
            stop_code = pen_stop::degenerate_ray;
            return finish(true, "origin and target are within 0.1 m; nothing to trace");
        }
        dirx /= total_len; diry /= total_len; dirz /= total_len;

    // Accumulated probability that the round DEFLECTS somewhere along the walked path
    // (1 - prod(1 - p_layer)). Independent-layer combination, matching how the
    // accumulated penetration chance is treated. Stays 0 when the build does not expose
    // RicochetChance, so behaviour is unchanged there.
    //
    // 2026-10-10: this was `float ricochet_risk = 0.f;` and is now a REFERENCE to
    // pen_env.ricochet_risk, declared after pen_env below. grade_layer accumulates into
    // it per layer, so the declaration had to move or the two copies would diverge.

    // The per-layer gate's invariant inputs, built once per walk and mutated
    // through by grade_layer (ricochet_risk accumulates across layers).
    //
    // The accumulator lives here, at the innermost scope that still outlives every
    // layer of the walk, and both names below are bound to it: the environment takes
    // its address because grade_layer must write through a const environment, and
    // the local reference is what the walk's own readers use. One storage, two views.
    float ricochet_risk_holder = 0.f;
    pen_layer_env pen_env{};
    pen_env.ammo_power = ammo_power;
    pen_env.ammo_obst_chance = ammo_obst_chance;
    pen_env.ammo_ricochet = ammo_ricochet;
    pen_env.dirx = dirx; pen_env.diry = diry; pen_env.dirz = dirz;
    pen_env.log_dump = log_dump;
    pen_env.diag = &diag;
    pen_env.ricochet_risk = &ricochet_risk_holder;

    // A REFERENCE, not a second copy, and the declaration order is load-bearing.
    // grade_layer folds each layer's deflection odds into the value
    // pen_env.ricochet_risk points at; every existing reader below -- the two
    // `>= kRicochetBlockAt` gates and the three forensic strings -- must see that
    // accumulated figure. Written as a second copy, the two would drift the moment
    // a layer was graded, and the drift would be silent: the value would still be
    // finite and still in range. (Third declaration-order defect in this file that
    // MSVC reports as a compile error rather than as a logic error.)
    float& ricochet_risk = ricochet_risk_holder;

        // Same-object test for the exit-collision rule.
        //
        // TIGHTENED 2026-10-04. This walked up to EIGHT ancestors looking for a match,
        // which made "related" mean "somewhere in the same prefab". A metal cage with
        // a cylinder inside it is one prefab: the cylinder shares the assembly root, so
        // the walk found it, and because the cylinder also sits within kExitFaceMaxDist
        // of the cage's inner face it was discarded as an "exit face" and NEVER GRADED.
        // If the cage wall itself was penetrable the walk then reported `clear` straight
        // through a solid metal cylinder -- a pen-success through an object the user can
        // see, which is the worst failure mode this function has, because nothing in the
        // verdict distinguishes it from a correct pass.
        //
        // Depth 1 is what the rule was WRITTEN for. Its own note cites the 2026-09-25
        // log: an awning's `_BALLISTIC_genericsoft` followed by its plain `_COLLIDER`
        // 0.09 m later. Those are two components on ONE GameObject -- `go ==
        // prev_hit_go` -- or a `_BALLISTIC_`/`_COLLIDER` pair under one shared immediate
        // parent. Neither needs an eight-level climb. Anything deeper is a different
        // surface that happens to be assembled nearby, and that is exactly the case that
        // has to be counted as its own layer.
        //
        // Not deleted, and the distance bound is still required alongside it: an earlier
        // version with relatedness alone was too broad and let genuinely separate
        // colliders be discarded, producing false passes in the OTHER direction. The
        // invariant being protected is "one collider is penetrated once" -- stated exactly
        // by the `layer_ballistic == prev_ballistic` test further down, which this now
        // defers to instead of pre-empting it with a looser approximation.
        auto same_object = [&](Il2CppObject* go, Il2CppObject* ref_transform) {
            if (!prev_hit_go && !prev_parent_go) return false;
            if (go == prev_hit_go || go == prev_parent_go) return true;
            // ONE level, and only a shared PARENT. An ancestor further up is an assembly,
            // not an object. That single change is the whole of the tightening.
            Il2CppObject* up = unity::transform_get_parent(ref_transform);
            if (!up) return false;
            Il2CppObject* anc_go = unity::component_get_game_object(up);
            return anc_go != nullptr && (anc_go == prev_hit_go || anc_go == prev_parent_go);
        };

        // Is this hit the FAR SIDE of something the ray already passed through?
        //
        // A surface the ray is ENTERING presents a normal pointing back along the ray;
        // a surface it is LEAVING presents one pointing the same way. That is the entire
        // discriminator, and it is GEOMETRIC -- so unlike the hierarchy test it cannot be
        // fooled by two unrelated surfaces happening to be assembled next to each other.
        //
        // This is precisely what double-sided geometry breaks. A thin shell, a cylinder
        // inside a cage, a door frame: each presents an entry face AND an exit face with
        // opposite normals, and only a hierarchy-plus-distance test confuses a second
        // object's entry face with the first object's exit face.
        //
        // `m_normal` is NOT guaranteed unit length. The occlusion path treats
        // `length(m_normal) < 0.1f` as an invalid-normal test, which is why that is a
        // threshold and not a comparison against 1 -- so the normal is normalised here.
        //
        // A degenerate or NaN normal returns FALSE, i.e. do NOT skip. "Cannot tell" must
        // resolve towards counting the layer, never towards discarding it: the failure
        // modes are not symmetric, since counting a redundant exit face costs one extra
        // raycast while discarding a real layer produces a pen-success nobody can see.
        auto is_exit_face_normal = [&](const unity::vector3& n, const float dx,
            const float dy, const float dz) {
            const float len = unity::length(n);
            if (!(len > 1e-3f)) return false;
            const float d = (n.x * dx + n.y * dy + n.z * dz) / len;
            // A hit exactly edge-on has an unreliable normal and either answer is
            // defensible, so require the normal to actually point downstream before
            // letting it authorise a skip. Unity's back-face culling puts entry normals
            // solidly below 0, so this band costs nothing on real entry faces.
            return d > 0.1f;
        };

        for (; layer < kMaxLayers;)
        {
            // Zoned 2026-10-07. Fires once per loop iteration, at the TOP of
            // the body so it counts every pass including the one that will
            // exhaust the layer budget. Without it, `budget_layers` in the
            // tally says "hit the cap" but not how many iterations it took to
            // get there -- and the cap is 3, so a walk that hits it in 3
            // iterations is behaving as designed, while one that hits it in
            // 12 is over-counting layers and the cap is not the real story.
            //
            // The log already shows `reEntry=0` and `skippedLayers=0` in every
            // `budget_layers` window, which rules out duplicate-ballistic
            // re-entry as the cause. This zone answers the remaining question:
            // are there genuinely that many distinct surfaces, or is the walk
            // iterating without advancing `layer` for some other reason.
            //
            // Cost when profiling is one zone construct per iteration (up to
            // kMaxCasts=16 per walk). On the 07.10 capture that is ~320k
            // constructions over 1.7 s of walk time, ~2% overhead. Acceptable
            // for the diagnostic; remove once the budget_layers question is
            // settled.
            TA_ZONE_N("skeleton_vis::pen:layer_iter");
            if (++casts > kMaxCasts)
            {
                // Recorded as a stop, not merely logged: in trace mode the walk
                // can reach the budget having passed layers that did not block,
                // and without this the function would report PENETRABLE where the
                // real walk reports BLOCKED.
                record_stop(stop_layer < 0 ? layer : stop_layer, pen_stop::budget_casts,
                    "raycast budget exhausted");
                return finish(false,
                    std::format("raycast budget exhausted (accumulated={:.3f})", accumulated));
            }
            const unity::vector3 ray_o{ox, oy, oz};
            raycast_hit hit{};
            //
            // Zoned 2026-10-05, and it is the reason this comment exists.
            //
            // WHY. Measured on `05.10_good.tracy` (186 MB, exported 21:25):
            //
            //   skeleton_vis::is_target_visible_penetrating  11,179 calls  1.132 s
            //     mean 101.258 us   MAX 9,422.931 us   std 565.594 us
            //
            // A 9.4 ms worst call, on a 16.7 ms frame budget, is a dropped frame -- and
            // the user has been reporting stalls they attribute to this walk. The two
            // zones inside it could not explain it: `pen:resolve_ballistic` maxes at
            // 367.777 us and `pen:read_penetration` at 200.878 us. So the cost was in
            // "raycasts", by elimination -- which is an inference, not a measurement,
            // and the 2026-10-01 note above `occlusion_linecast` records exactly that
            // mistake ("the largest single leaf in the module, with no way to tell how
            // much was the physics query and how much was the hierarchy walk below.
            // Optimising that blind is how the earlier round went wrong") going
            // unfixed here for a week.
            //
            // The zone covers the `if` AND its early return, matching
            // `occlusion_linecast` at line 2354: the clear-line exit IS this
            // raycast's verdict, so folding it in attributes it correctly rather than
            // hiding it in the walk's self time.
            {
                TA_ZONE_N("skeleton_vis::pen:linecast");
                if (!g_linecast(ray_o, target, layer_mask, query_ignore_triggers, &hit))
                {
                    // Reached the target without further blockers. In trace mode this
                    // can happen while stop_layer >= 0 (the round did not actually
                    // survive that earlier layer), so the verdict is the recorded
                    // stop, not this exit.
                    return finish(stop_layer < 0,
                        std::format("clear line after {} layer(s), accumulated={:.3f}", layer, accumulated));
                }
            }
            // unity::length(), NOT the member -- see the note on the identical test in
            // is_target_visible. The member is the SQUARED magnitude, so this was
            // really rejecting |n| < ~0.316.
            if (hit.m_distance < 0.05f || unity::length(hit.m_normal) < 0.1f)
            {
                // RECORDED AS A STOP, 2026-10-04. This used to be
                // `finish(stop_layer < 0, ...)`, i.e. PENETRABLE whenever no earlier
                // layer had blocked. On the 23:14 Factory log that produced **76
                // PENETRABLE verdicts from 82 uses of this exit** -- a pass the walk
                // never verified, which is the failure mode the notes above
                // classify_hit_transform call the worst one this function has,
                // because nothing in the verdict distinguishes it from a real one.
                //
                // WHY THE ORIGIN IS INSIDE A MESH AT ALL. This check runs on the ray
                // origin AFTER `step_past()` advanced it by `hit.m_distance +
                // kLayerEps`, so it is not the walk's starting origin -- it is one
                // epsilon past the surface just crossed. Both logged examples had
                // already graded and PASSED a layer:
                //
                //   | L0 go='Corner_table_01_BALLISTIC_woodthick' dist=2.82 -> pass (clear)
                //     | DECISION: PENETRABLE - origin effectively inside a mesh
                //   | L0 go='Base HumanHead' dist=6.88 owner='Eyes' -> pass (clear)
                //     | DECISION: PENETRABLE - origin effectively inside a mesh
                //
                // In the second, L0 was the TARGET's own head: the advanced origin
                // landed past it, inside the shooter's mesh or the back of the skull.
                //
                // ORDER IS THE ACTUAL DEFECT, and it is deliberate. `classify_hit_-
                // transform` -- which recognises "this is our own body" and skips the
                // surface WITHOUT spending layer budget -- sits BELOW this test. So an
                // origin that came to rest inside the shooter's own mesh got a free
                // pass instead of the skip-and-continue that `hit_owner::shooter`
                // already handles three lines further down.
                //
                // The reasoning that produced `stop_layer < 0` was sound and the
                // verdict was still wrong: it asks "has a LAYER blocked this walk?",
                // and for a walk that graded one layer and passed, the answer was no
                // -- while the thing that actually stopped it, this origin, was never
                // recorded anywhere. Recording it makes the tally and the verdict
                // agree, and preserves an earlier stop because record_stop is a no-op
                // once stop_layer is set.
                //
                // `finish(false, ...)` rather than `finish(stop_layer < 0, ...)`: after
                // the record_stop above the value is false either way, and stating it
                // keeps the verdict from depending on the reader tracing that effect.
                record_stop(layer, pen_stop::origin_in_mesh,
                    "ray origin came to rest inside a mesh after advancing past the "
                    "previous layer");
                return finish(false,
                    "origin effectively inside a mesh (hit within 0.05 m or degenerate normal)");
            }

            // Managed call per cast, and the one whose failure mode is a silent
            // "raycast hit with no transform" -- a verdict produced by a call that
            // returned nothing, indistinguishable from a real miss in the tally.
            Il2CppObject* hit_transform = nullptr;
            {
                TA_ZONE_N("skeleton_vis::pen:hit_get_transform");
                hit_transform = g_hit_get_transform(&hit);
            }
            if (!hit_transform)
                return finish(stop_layer < 0, "raycast hit with no transform");

            // Reached the target's own body — the shot connects. Or OUR OWN body, which
            // is not cover and must not be walked as a layer.
            //
            // This is the three-way test, matching is_target_visible, and it is the
            // change that makes the walk usable at all when the ray starts at the
            // shooter's fireport. The previous `is_player_transform(hit, target)` could
            // not express "that is us": it passes a null shooter, so a hit on the
            // local player's own collider walked the full 48 hops, found neither the
            // shooter nor the target, and fell through to be classified as a LAYER.
            // Our own arm carries no BallisticCollider, so the verdict was
            // `no BallisticCollider on hit chain (env/terrain)` -> BLOCKED, and the
            // wall check reported every enemy in the room as hidden.
            //
            // The origin made this near-certain rather than occasional: the first
            // thing a ray leaving the fireport meets is frequently the shooter's own
            // body. Treat it as clear, and skip it WITHOUT consuming layer budget --
            // same treatment as the exit-face rule, and for the same reason: it is not
            // a material the round has to beat.
            //
            // The origin tracker (prev_hit_go) is deliberately NOT updated for a
            // self-hit, so it cannot make a later real layer look like an exit face.
            // The other half of the split, and the stronger suspect for a
            // multi-millisecond call: this walks up to 48 ancestors
            // (`for (int depth = 0; depth < 48 && current; ++depth)`, line 717),
            // each step calling get_player_transform / get_parent / get_name on the
            // managed side. It is also SHARED with the ESP walk (lines 877 and 2393),
            // so it is deliberately zoned at the CALL SITE rather than inside: an
            // inner zone would merge both callers into one row and lose the split
            // this is for.
            //
            // `const` dropped because the zone needs a plain lvalue to assign into.
            // Read-only at 2909 and 2915 only, both outside the block below.
            hit_owner owner = hit_owner::none;
            {
                TA_ZONE_N("skeleton_vis::pen:classify_hit");
                owner = classify_hit_transform(hit_transform, shooter_obj, target_player_obj);
            }
            if (owner == hit_owner::shooter)
            {
                const float advance = hit.m_distance + kLayerEps;
                ox += dirx * advance; oy += diry * advance; oz += dirz * advance;
                continue;
            }
            if (owner == hit_owner::target)
            {
                return finish(stop_layer < 0,
                    std::format("hit target after {} layer(s), accumulated={:.3f}", layer, accumulated));
            }

            // Exit-collision rule FIRST (before any classification): a re-hit of
            // the previously penetrated object — its own _BALLISTIC_ collider's
            // far face or its plain _COLLIDER sibling — is the bullet EXITING,
            // not a new layer (log 2026-09-25: the same Cable_drum GO classified
            // as L0 AND L1; awning _BALLISTIC_ then _COLLIDER 0.09 m later).
            {
                // Zoned 2026-10-05, for the same reason as pen:step_past: this runs
                // on every layer and holds one managed read plus `same_object` and
                // the exit-normal test, none of which had a row.
                TA_ZONE_N("skeleton_vis::pen:exit_face_rule");
                Il2CppObject* hit_go = unity::component_get_game_object(hit_transform);
                // THREE conditions, not two. Relatedness alone is too broad in EFT's
                // hierarchy and distance alone would discard a genuinely thin second
                // surface -- but related AND near was ALSO not sufficient, because it
                // cannot tell the far side of the object just crossed from the near side
                // of a DIFFERENT object nested inside it. See same_object and
                // is_exit_face_normal above; the normal test is what makes the rule
                // physical rather than genealogical.
                const bool related = hit_go
                    && (hit_go == prev_hit_go || same_object(hit_go, hit_transform));
                const bool just_behind = hit.m_distance <= kExitFaceMaxDist;
                const bool exiting = is_exit_face_normal(hit.m_normal, dirx, diry, dirz);
                if (prev_hit_go && related && just_behind && exiting)
                {
                    ++g_pen_skip_hierarchy();
                    if (log_dump)
                        diag += std::format(" | L{} go='{}' dist={:.2f} [exit-face of previous layer — skipped]",
                            layer, hit_go ? unity::get_name(hit_go) : std::string("?"), hit.m_distance);
                    const float advance = hit.m_distance + kLayerEps;
                    ox += dirx * advance; oy += diry * advance; oz += dirz * advance;
                    continue;
                }
                if (log_dump)
                {
                    // Says WHICH condition failed, because "counted as a new layer" on
                    // its own is the line that hid this for a month: it looks identical
                    // whether the layer was correctly counted or wrongly kept.
                    std::string why;
                    if (related && just_behind && !exiting)
                        why = " [related and near but the NORMAL faces the ray — a new surface inside a related object, counted as a new layer]";
                    else if (related && !just_behind)
                        why = " [related but too far to be an exit face — counted as a new layer]";
                    diag += std::format(" | L{} go='{}' dist={:.2f}{}",
                        layer, hit_go ? unity::get_name(hit_go) : std::string("?"), hit.m_distance, why);
                }
            }

            // Authoritative first: the game's own static resolver
            // (Shot.TryGetBallisticCollider) — exact GetComponentInParent semantics
            // the bullets use, no hierarchy guessing.
            Il2CppObject* layer_ballistic = nullptr;
            bool used_game_resolver = false;
            {
                // Zoned 2026-10-04, and this is the walk's dominant per-layer cost.
                //
                // `g_try_get_ballistic` is the game's own
                // `Shot.TryGetBallisticCollider`, so its cost is Unity's
                // `GetComponentInParent` running on the managed side -- a hierarchy
                // walk we do not control, once per layer, on the game thread. Every
                // `+7` log line says `ballistic='...' (game-resolved)`, so this
                // branch is taken on every layer of every walk and the fallback
                // hierarchy walk below it is effectively dead.
                //
                // That makes this the honest suspect for "the pen check costs more
                // with more layers", which is exactly the symptom reported. It was
                // invisible before: `occlusion_linecast` measured the ray and
                // nothing measured the collider lookup that follows it.
                TA_ZONE_N("skeleton_vis::pen:resolve_ballistic");
                if (g_try_get_ballistic && g_try_get_ballistic(nullptr, &hit, &layer_ballistic))
                {
                    used_game_resolver = true;
                    if (log_dump && layer_ballistic->klass && layer_ballistic->klass->name)
                        diag += std::format(" ballistic='{}' (game-resolved)", layer_ballistic->klass->name);
                }
            }

            // Fallback: bounded GetComponentInParent walk (hit GO + 7 ancestors),
            // then one sibling sweep — only when the game resolver is unavailable.
            if (!layer_ballistic && !used_game_resolver)
            {
                Il2CppObject* candidates[8] = {hit_transform, nullptr, nullptr, nullptr,
                                               nullptr, nullptr, nullptr, nullptr};
                {
                    Il2CppObject* up = unity::transform_get_parent(hit_transform);
                    for (int i = 1; i < 8 && up; ++i) {
                        candidates[i] = up;
                        up = unity::transform_get_parent(up);
                    }
                }
                for (size_t ci = 0; ci < 8 && !layer_ballistic; ++ci)
                {
                    Il2CppObject* candidate = candidates[ci];
                    if (!candidate) continue;
                    Il2CppObject* go = unity::component_get_game_object(candidate);
                    if (!go) continue;
                    Il2CppObject* ballistic =
                        unity::gameobject_get_component(go, g_ballistic_type);
                    if (!ballistic
                        || !readable_range(reinterpret_cast<const void*>(
                                               reinterpret_cast<uintptr_t>(ballistic)),
                                           8))
                        continue; // component object not dereferenceable — skip
                    layer_ballistic = ballistic;
                }
            }

            bool layer_is_ballistic = false;
            if (layer_ballistic)
            {
                // THE SAME COLLIDER. Which of two very different things is this?
                //
                //   (a) its FAR SIDE - the bullet is EXITING a shell it already paid                //       for. One PenetrationLevel covers the whole collider, so counting
                //       the exit again would charge for material the round already got
                //       through. This is what the skip was written for.
                //
                //   (b) a SECOND ENTRY — the collider is a compound shell (a barrel
                //       with nested walls, a cage, a double-skinned panel) and the ray
                //       has come back around into it. The single PenetrationLevel does
                //       NOT describe that: it is one number for the whole component,
                //       and the component has more than one surface.
                //
                // The old test was `layer_ballistic == prev_ballistic` alone, which
                // ASSUMED (a). Identity cannot tell them apart — the same pointer is
                // returned in both cases — so every re-entry was silently free. That is
                // the same shape of error as the hierarchy skip above, one level down:
                // a test that names a thing rather than the property being asked about.
                //
                // The discriminator is the normal, and it is the same one used above for
                // the same reason. An exit face points downstream (the ray is leaving);
                // an entry face points back at the ray (it is arriving). Where the
                // hierarchy test asks "is this the same object?", this asks "is this the
                // same SURFACE?" — and a compound collider fails the second question
                // while passing the first.
                //
                // Presumption on ambiguity is toward (b): if the normal is degenerate or
                // unusable, grade the layer. Over-counting a wall makes the wall check
                // refuse a shot it should allow; under-counting lets the round pass
                // through material the game would stop it on. Only one of those is a
                // cheat that does not work.
                const bool same_collider = (layer_ballistic == prev_ballistic);
                const bool exiting = is_exit_face_normal(hit.m_normal, dirx, diry, dirz);
                if (same_collider && exiting)
                {
                    // (a) genuine exit collision — does not count.
                    ++g_pen_skip_same_ballistic();
                    if (log_dump)
                        diag += " [same ballistic, exit face — skipped]";
                    const float advance = hit.m_distance + kLayerEps;
                    ox += dirx * advance; oy += diry * advance; oz += dirz * advance;
                    layer_is_ballistic = true; // object already beaten
                }
                else if (same_collider)
                {
                    // (b) RE-ENTRY into a collider already crossed. Falls through to be
                    // graded like any other layer, which is the point: its own
                    // PenetrationLevel is applied a second time and accumulates.
                    ++g_pen_reentry();
                    if (log_dump)
                        diag += " [re-entered a collider already crossed — graded again"
                                ", its PenetrationLevel describes one shell]";
                }
                else
                {
                    ballistic_penetration bc{};
                    // Zoned 2026-10-04. This is the second of the walk's two
                    // per-layer MANAGED reads, and it is the one that decides the
                    // verdict. `classify_blocker()` beside it is pure arithmetic --
                    // min(1, a+c) plus three gates -- so before this zone existed
                    // the walk's cost could only be attributed to "raycasts", and
                    // the honest answer to "is the pen calc expensive because of the
                    // rays or because of reading the collider" was not measurable.
                    //
                    // Both are now separate rows: `skeleton_vis::pen:resolve_ballistic`
                    // (the game's own Shot.TryGetBallisticCollider, i.e. a
                    // GetComponentInParent on the managed side) and
                    // `skeleton_vis::pen:read_penetration` (PenetrationLevel and
                    // PenetrationChance off whatever that returned).
                    bool layer_readable = false;
                    {
                        TA_ZONE_N("skeleton_vis::pen:read_penetration");
                        layer_readable = try_read_layer_penetration(layer_ballistic, hit.m_point, bc);
                    }
                    if (!layer_readable)
                    {
                        record_stop(layer, pen_stop::unreadable,
                            "ballistic present but PenLevel/PenChance unreadable");
                        if (!trace) {
                            return finish(false,
                                "ballistic present but PenLevel/PenChance unreadable "
                                "(not a BallisticCollider, and terrain lookup did not resolve one)");
                        }
                        // Trace: step past it so the layers behind an unreadable
                        // collider still get reported. layer_is_ballistic is set
                        // because the object IS a ballistic component, it is
                        // only its numbers that could not be read.
                        prev_ballistic = layer_ballistic;
                        prev_hit_go = unity::component_get_game_object(hit_transform);
                        if (Il2CppObject* ptr = unity::transform_get_parent(hit_transform))
                            prev_parent_go = unity::component_get_game_object(ptr);
                        const float unreadable_advance = hit.m_distance + kLayerEps;
                        ox += dirx * unreadable_advance;
                        oy += diry * unreadable_advance;
                        oz += dirz * unreadable_advance;
                        ++layer;
                        continue;
                    }

                    // `gate` is the COUNTED reason; `reason` is its text for the per-layer log
                    // line, taken from the same source so the two cannot disagree.
                    //
                    // grade_layer classifies, combines, assesses the ricochet, folds it
                    // into the running risk, and appends the per-layer line on log_dump.
                    // The strings and the tail stay here because they differ between the
                    // two paths (see the helper's comment for why that is load-bearing).
                    const pen_layer_gate lg = grade_layer(bc, layer_ballistic, pen_env,
                        hit.m_normal);
                    const float layer_combined = lg.layer_combined;
                    const penetration_result r = lg.r;
                    const pen_stop gate = lg.gate;
                    const char* reason = lg.reason;

                    if (r != penetration_result::penetrable)
                    {
                        record_stop(layer, gate, reason);
                        if (!trace)
                            return finish(false,
                                std::format("blocked at layer {} ({})", layer, reason));
                        // Falls through to `accumulated *= layer_combined` below,
                        // so the reported figure is the chance the round would
                        // have had if this one layer had not stopped it.
                    }
                    else if (ricochet_risk >= kRicochetBlockAt)
                    {
                        // A deflecting layer makes the whole shot unpredictable:
                        // even if THIS layer would pass, the round may not arrive
                        // at the layers behind it, so it cannot be reported as a
                        // clean penetration.
                        //
                        // `else if`: once a layer has already been recorded as the
                        // stop, a later ricochet on a later layer is not a second
                        // verdict, it is just another property of the path behind
                        // it, and must not overwrite the first reason.
                        record_stop(layer, pen_stop::ricochet, std::format(
                            "ricochet {:.3f} >= {:.2f}", ricochet_risk, kRicochetBlockAt));
                        if (!trace)
                            return finish(false, std::format(
                                "layer {} is a deflection candidate (ricochet risk "
                                "{:.3f} >= {:.2f}); round likely skips off",
                                layer, ricochet_risk, kRicochetBlockAt));
                    }

                    accumulated *= layer_combined;
                    ++layer;              // only classified layers consume the budget
                    layer_is_ballistic = true;
                }
            }

            if (!layer_is_ballistic)
            {
                // No BaseBallistic on the ancestor chain: the game's own structure
                // frequently parks the component on a SIBLING GO ('X_BALLISTIC_mat'
                // next to 'X_COLLIDER' under the same parent — log 2026-09-25:
                // Enterance_Gate_01_L_COLLIDER / parent 'Enterance_Gate_01_L').
                // Sweep the immediate parent's children once before calling it
                // terrain.
                Il2CppObject* parent_tr = unity::transform_get_parent(hit_transform);
                Il2CppObject* parent_go = parent_tr
                    ? unity::component_get_game_object(parent_tr) : nullptr;
                if (parent_go)
                {
                    Il2CppObjectInstance parent_inst(parent_go);
                    const auto get_children =
                        parent_inst.get_method<Il2CppArray* (*)(Il2CppObject*, Il2CppObject*, bool)>(
                            "GetComponentsInChildren", 2, /*log_fail=*/false);
                    const auto get_children_1 =
                        get_children ? nullptr
                        : parent_inst.get_method<Il2CppArray* (*)(Il2CppObject*, Il2CppObject*)>(
                            "GetComponentsInChildren", 1, /*log_fail=*/false);
                    Il2CppArray* arr = nullptr;
                    if (get_children)
                        arr = get_children(parent_go, g_ballistic_type, false);
                    else if (get_children_1)
                        arr = get_children_1(parent_go, g_ballistic_type);
                    if (arr && arr->max_length > 0)
                    {
                        Il2CppObject* ballistic =
                            reinterpret_cast<Il2CppObject**>(&arr->data)[0];
                        if (ballistic && ballistic != prev_ballistic)
                        {
                            if (log_dump && ballistic->klass && ballistic->klass->name)
                                diag += std::format(" siblingBallistic='{}'", ballistic->klass->name);

                            ballistic_penetration bc{};
                            if (!try_read_layer_penetration(ballistic, hit.m_point, bc))
                            {
                                record_stop(layer, pen_stop::sibling_unreadable,
                                    "sibling BallisticCollider unreadable");
                                if (!trace)
                                    return finish(false,
                                        "sibling BallisticCollider unreadable");
                                // Trace: the block below already ends in the
                                // advance-and-continue tail, so fall into it
                                // rather than copying the advance a third time.
                                prev_ballistic = ballistic;
                                prev_hit_go = unity::component_get_game_object(hit_transform);
                                if (Il2CppObject* ptr = unity::transform_get_parent(hit_transform))
                                    prev_parent_go = unity::component_get_game_object(ptr);
                                ++layer;
                                const float sib_unreadable_advance = hit.m_distance + kLayerEps;
                                ox += dirx * sib_unreadable_advance;
                                oy += diry * sib_unreadable_advance;
                                oz += dirz * sib_unreadable_advance;
                                continue;
                            }
                            // Same gate, same verdict, same running risk -- and now the
                            // same STRINGS too. The 2026-10-14 policy decision: the two
                            // paths used to print differently -- the sibling's dead stop
                            // carried a (sibling; ...) tag, its stop_reason a sibling:
                            // prefix, its ricochet verdict lacked the ancestor's
                            // "round likely skips off" suffix -- which was load-bearing
                            // for reading a historical log, because a stop_reason
                            // starting with the sibling prefix named WHICH sweep stopped
                            // the round. That distinction is deliberately GONE: the
                            // counted `pen_stop` buckets still separate the paths
                            // (`sibling_unreadable` vs `unreadable`), and keeping the
                            // strings distinct had outlived its use. Historical logs keep
                            // matching through the old wording; new ones do not. See
                            // CHANGELOG's 2026-10-14 entry and the test that pins this.
                            // (Written without quoting the retired spellings on purpose:
                            // the checker's comment blanker preserves quoted spans, so a
                            // quoted example here would read as a live string literal and
                            // fail its own absence test.)
                            const pen_layer_gate lg = grade_layer(bc, ballistic, pen_env,
                                hit.m_normal);
                            const float layer_combined = lg.layer_combined;
                            const penetration_result r = lg.r;
                            const pen_stop gate = lg.gate;
                            const char* reason = lg.reason;
                            if (r != penetration_result::penetrable)
                            {
                                record_stop(layer, gate, reason);
                                if (!trace)
                                    return finish(false, std::format(
                                        "blocked at layer {} ({})", layer, reason));
                            }
                            else if (ricochet_risk >= kRicochetBlockAt)
                            {
                                record_stop(layer, pen_stop::ricochet, std::format("ricochet {:.3f} >= {:.2f}",
                                    ricochet_risk, kRicochetBlockAt));
                                if (!trace)
                                    return finish(false, std::format(
                                        "layer {} is a deflection candidate "
                                        "(ricochet risk {:.3f} >= {:.2f}); round likely skips off",
                                        layer, ricochet_risk, kRicochetBlockAt));
                            }
                            accumulated *= layer_combined;
                            ++layer;
                            layer_ballistic = ballistic;
                            const float advance = hit.m_distance + kLayerEps;
                            ox += dirx * advance; oy += diry * advance; oz += dirz * advance;
                            continue;
                        }
                    }
                }
                // Genuinely no ballistic data: environment/terrain — opaque.
                //
                // The parent name is collected on BOTH paths, not under log_dump.
                // In trace mode this is usually the layer that stops the round —
                // the reported symptom was "collider+geometry and it still said
                // blocked" — and a stop that does not say WHAT it hit is the one
                // case where the name is the whole answer. unity::get_name
                // allocates, so it is guarded on trace rather than paid for the
                // common path.
                const bool want_geom_name = log_dump;
                if (want_geom_name)
                {
                    Il2CppObject* p1 = unity::transform_get_parent(hit_transform);
                    std::string a1 = p1 ? [&]{
                        Il2CppObject* g = unity::component_get_game_object(p1);
                        return g ? unity::get_name(g) : std::string("?");
                    }() : std::string("none");
                    diag += " noBallisticChain parent='" + a1 + "'";
                }
                record_stop(layer, pen_stop::no_ballistic,
                    "no BallisticCollider on hit chain (env/terrain)");
                if (!trace)
                    return finish(false,
                        "no BallisticCollider on hit chain (env/terrain)");
                // Trace: keep walking so the layers behind a nameless piece of
                // environment are still reported. prev_ballistic is cleared
                // because this object is not a ballistic at all, so the next
                // layer's same-object exit rule must not fire against it.
                prev_ballistic = nullptr;
                prev_hit_go = unity::component_get_game_object(hit_transform);
                if (Il2CppObject* ptr = unity::transform_get_parent(hit_transform))
                    prev_parent_go = unity::component_get_game_object(ptr);
                const float geom_advance = hit.m_distance + kLayerEps;
                ox += dirx * geom_advance; oy += diry * geom_advance; oz += dirz * geom_advance;
                ++layer;
                continue;
            }

            // Remember the object identity for the exit rule and advance past
            // the surface. Extracted so the trace path below steps past a
            // BLOCKING layer exactly the way the normal path steps past a
            // penetrated one, instead of a second hand-copied block that can
            // drift from this one.
            auto step_past = [&](Il2CppObject* current_ballistic) {
                // Zoned 2026-10-05. THREE managed calls, once per graded layer,
                // unconditionally -- so it is on every walk and was invisible.
                //
                // Added while partitioning the residual that `pen:linecast` and
                // friends left: after those five rows, 71.1% of the walk was still
                // self time (1,178.5 ms of 1,656.4 ms, ~94 us per walk). Naming what
                // it is NOT mattered as much:
                //
                //   * the bounded GetComponentInParent fallback -- NEVER RUNS. All
                //     242 pen-check records in the 05.10_bad session carry
                //     "(game-resolved)", and it is gated on
                //     `!layer_ballistic && !used_game_resolver`.
                //   * `same_object` -- already tightened to ONE level, so two
                //     managed calls, not the eight its own comment used to describe.
                //   * `unity::get_name` -- all four sites are under `log_dump` or
                //     `trace`, so they are diagnostic-only.
                //
                // Two of those three were guesses that measurement killed, which is
                // why this is a zone rather than a conclusion.
                TA_ZONE_N("skeleton_vis::pen:step_past");
                prev_ballistic = current_ballistic;
                prev_hit_go = unity::component_get_game_object(hit_transform);
                if (Il2CppObject* ptr = unity::transform_get_parent(hit_transform))
                    prev_parent_go = unity::component_get_game_object(ptr);
                const float advance = hit.m_distance + kLayerEps;
                ox += dirx * advance; oy += diry * advance; oz += dirz * advance;
            };

            if (accumulated < kMinAccumulated)
            {
                record_stop(layer, pen_stop::accumulated_floor,
                    "accumulated chance below the floor");
                if (!trace)
                    return finish(false, std::format(
                        "accumulated chance {:.3f} below {:.2f} after {} layer(s) "
                        "(bullet unlikely to punch through)",
                        accumulated, kMinAccumulated, layer + 1));
            }

            // Advance past the surface and keep walking.
            //
            // Unconditional, and deliberately so. An earlier version of this
            // advanced only when the accumulated chance was still above the
            // floor, which in trace mode recorded a stop, skipped the advance
            // and skipped `++layer` -- so the next iteration re-raycast from the
            // SAME origin. `casts` still increments, so it terminated rather
            // than spinning, but it burned the raycast budget re-shooting one
            // surface and the trace came out unreadable.
            step_past(layer_ballistic);
        }

        // kMaxLayers 4 -> 3, 2026-10-04, on the user's call. Full evidence here, at the
        // exit, because this is where the change is observable.
        //
        // WHAT THE LOG SUPPORTS (369 `pen-check:` records, pid 21872 / 25432):
        //
        //     layers raycast       2:78   3:27   4:218 (59%)   5+: 0
        //     reached the target   after 0:17  1:16  2:56  3:20   4: 0
        //     cleared after N      never, at any N
        //
        // So no walk in the sample ever needed a fourth layer to reach its target,
        // and the 59% that raycast a fourth were all already BLOCKED. Dropping the cap
        // to 3 changes no observed verdict, and it changes no `pen_stop` tally either
        // -- `record_stop` below passes `stop_layer` through when one is set, so the
        // tally still names the layer that actually blocked.
        //
        // WHAT IT SAVES: one `occlusion_linecast` (6.4 us mean, 0.24 ms max, 200,886
        // calls that capture) on 59% of 4,245 walks -- about **16 ms across the whole
        // capture**. A simplification, not a performance fix. It is emphatically NOT
        // the frame hitch: the pen walk's worst single walk was 8.06 ms and its
        // inclusive total was 0.31 s out of a capture with 180 s in `get_position`.
        //
        // THE RESIDUAL RISK, stated because it is real and I cannot rule it out. The
        // loop condition is `layer < kMaxLayers` and the clear-line test is the FIRST
        // thing the loop body does. So a walk that penetrates exactly three layers and
        // then finds clear air to the target returns `clear line after 3 layer(s)` ->
        // PASS with the cap at 4, and falls out of the loop -> `budget_layers` ->
        // BLOCKED with the cap at 3. **That flips PASS to BLOCKED.** Zero such walks
        // were observed in 369 records, so it is rare or absent -- but "not observed in
        // 369" is not "impossible", and no test here can settle it without a physics
        // scene.
        //
        // If it turns out to matter, the fix is NOT to restore the cap. It is to let
        // the loop run one extra iteration whose only job is to test for clear air
        // after the last classified layer. That pays the raycast back on every blocked
        // walk -- the exact cost this change removes -- so it is a trade, not a
        // correction.
        //
        // Too many layers — conservative: the bullet would be degraded to nothing.
        record_stop(stop_layer < 0 ? kMaxLayers : stop_layer, pen_stop::budget_layers,
            "layer budget exhausted with more blockers remaining");
        return finish(false,
            std::format("{} layers penetrated but more blockers remain (accumulated={:.3f})", kMaxLayers, accumulated));
    }
#endif // INCLUDE_AIMBOT
} // namespace skeleton_vis
