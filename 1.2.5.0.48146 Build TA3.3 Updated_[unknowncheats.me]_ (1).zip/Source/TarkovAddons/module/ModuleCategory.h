#pragma once
#include <cstdint>

enum ModuleCategory : uint8_t {
    RaidDashboard,
    BotSpawner,
    Visuals,
    MapEditor,
    // Backs the "Map Stuff" nav tab: Minimap and Icebreaker Scenario. Renamed
    // from Minimap when the tab outgrew a single module -- the value predated
    // this tab and had never been used.
    MapStuff,
    Exploit,
    ItemSpawnerEditor,
    WeaponBuilder,
    ProfileEditor,
    Teleport,
    QuestCompleter,
    Config,
    Credits,
    Misc,
};
