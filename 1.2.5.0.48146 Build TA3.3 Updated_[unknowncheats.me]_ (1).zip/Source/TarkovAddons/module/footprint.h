#pragma once

// The mod's own memory footprint, measured rather than assumed.
//
// WHY THIS EXISTS. On 2026-10-15 EFT was measured committing 31.5 GB live and
// 40.6 GB at a crash, driving system commit to 94% repeatedly. The obvious
// question is whether the mod is the reason. An answer built from sizeof() is
// an assertion, and this project has been repeatedly burned by those -- most
// recently by our own memory sampler, which shipped a 14-DWORD struct layout
// that the build could not complain about and the log had to catch.
//
// So the constants below are MEASURED, by tools/harness/test_footprint_cost.cpp:
//
//   node cost    116.3 bytes/entry   (1.6x sizeof(MetaKey) = 72)
//   bucket cost  18.77 bytes/bucket
//
// measured 2026-10-15 on this machine, against a real
// std::unordered_map<MetaKey, void*, MetaKeyHash> holding the actual
// il2utils::detail::MetaKey. The harness case's negative control fills a map,
// destroys it, and asserts the memory comes back (32.8 MB held, 32.4 MB
// released), so the number is the container's and not background noise. It also
// asserts no rehash happens between its two sample points, because the first
// version straddled one and reported 137 bytes/entry for what was really nodes
// plus a doubled bucket array -- a plausible wrong number, which is exactly what
// the "no rehash" premise now guards.
//
// WHAT IS AND IS NOT COVERED, because a partial answer presented as total is the
// failure this file exists to prevent:
//
//   covered    field_cache() and method_cache() -- the only containers here with
//              NO eviction policy. They are keyed on (class, name) so they
//              saturate on the game's type universe rather than growing without
//              bound, but "saturates eventually" is not a bound.
//   covered    the two fixed region tables, exactly -- they are arrays, not
//              containers, so sizeof is the whole truth.
//   NOT covered  the chams registries, the localisation caches, and anything the
//              render path allocates. Those are bounded by LIVE game objects and
//              so are small, but "small" is a claim, not a measurement.
//
// The reported total is therefore a FLOOR for the mod, not its footprint. It is
// labelled that way in the output rather than presented as the answer.

#include <cstddef>
#include <cstdio>

#include "../il2cpp/il2utils.h"

namespace footprint {

// Measured, not assumed. See the header comment for the harness case that
// produced them and for the negative control that proves they are the
// container's cost and not the process's.
inline constexpr size_t kMeasuredNodeBytes = 116;
inline constexpr size_t kMeasuredBucketBytes = 19;

// Bytes held by one of the metadata caches: every node, plus a proportional
// share of the bucket array. Written as a function so the reporter cannot
// accidentally use one without the other -- an entry count alone understates a
// map by the bucket array, which at low load is most of it.
template <class Map>
inline size_t cache_bytes(const Map& m) {
    return m.size() * kMeasuredNodeBytes + m.bucket_count() * kMeasuredBucketBytes;
}

struct line {
    size_t field_bytes = 0;
    size_t method_bytes = 0;
    size_t region_bytes = 0;
    size_t optics_bytes = 0;
    size_t field_n = 0;
    size_t method_n = 0;
};

inline line measure() {
    line l;
    l.field_n = il2utils::field_cache().size();
    l.method_n = il2utils::method_cache().size();
    l.field_bytes = cache_bytes(il2utils::field_cache());
    l.method_bytes = cache_bytes(il2utils::method_cache());
    return l;
}

// Registered with crash_probe, called on its 15 s tick. One line, because a
// diagnostic that needs a second line to be read is a diagnostic that does not
// get read.
//
// `process_private_mb` is the SAME process's private usage, passed in by the
// caller rather than re-read here, so the ratio is guaranteed to be against a
// figure taken at effectively the same moment. Two separately-sampled numbers
// divided by each other would be a ratio of two times, which is not a thing.
inline void format(char* buf, size_t cap, unsigned long long process_private_mb) {
    const line l = measure();
    const unsigned long long total_kb =
        (l.field_bytes + l.method_bytes + l.region_bytes + l.optics_bytes) / 1024;
    const double pct = process_private_mb
        ? (double(total_kb) / 1024.0) / double(process_private_mb) * 100.0
        : 0.0;

    // FLOOR, not total. See the header.
    std::snprintf(buf, cap,
        "mod-footprint: >=%llu KB of %llu MB (%.3f%%)  "
        "field_cache=%zu/%zu KB  method_cache=%zu/%zu KB  "
        "fixed_tables=%zu KB  (FLOOR: chams+localisation+render NOT included)",
        total_kb, process_private_mb, pct,
        l.field_n, l.field_bytes / 1024,
        l.method_n, l.method_bytes / 1024,
        (l.region_bytes + l.optics_bytes) / 1024);
}

} // namespace footprint

// The adapter crash_probe actually registers.
//
// It lives here rather than in an anonymous namespace in the TU that calls
// set_footprint_provider: registration happens in dllmain.cpp, and a function in
// an anonymous namespace in common_hooks.cpp is invisible to it. That is a
// compile error (C2065) rather than a subtle problem, which is the friendliest
// way this could have failed.
inline void report_mod_footprint(char* buf, size_t cap,
                                 unsigned long long process_private_mb) {
    footprint::format(buf, cap, process_private_mb);
}