#pragma once

// Tracy instrumentation for the hideout production station's recipe panel.
//
// WHY THIS EXISTS
//
// Opening a crafting station — the Workbench especially — stalls the game and leaves the station
// unusable while the recipe list builds. The list is large: the 2026-09-28 log shows 104 of the
// hideout's 260 schemes on areaType 10 (Верстак / workbench), and the panel builds a row per
// requirement.
//
// The rebuild is not one-off. EFT.Hideout.ProductionPanel registers its own change handlers, and
// every one of them funnels into UpdateViews():
//
//     DataChangedHandler()                          ItemChangedHandler(Item)
//     OnCompleteItemsCountChanged(IProductionStorage)
//     ProducingCompleteHandler(ItemsProducerBase, Item[], ProducingItemController)
//     EnergyGenerationChangedHandler(bool)          FavoriteSchemeUpdatedHandler(ProductionScheme)
//
// so any action in the station — starting, cancelling, an item moving, a completion — re-runs the
// whole build. That is the "it re-populates on every action" behaviour, and it is the game's own
// code path, not ours.
//
// The chain, outermost first (ISIL Assembly-CSharp/EFT/Hideout/ProductionPanel.txt):
//
//     Task  ShowContents()                                  panel total
//     IEnumerable<ProductionScheme> GetSortedSchemes(bool)  the per-station recipe list
//     void  UpdateViews()                                  every handler funnels here
//     void  ProduceView.Show(ItemUiContext, InventoryController, ProductionScheme,
//              ItemsProducerBase, Action<string>, Action<string>, bool)
//                                                            per-scheme view build
//     void  HideoutProductionRequirementView.Show(
//              ItemUiContext, InventoryController, ItemRequirement,
//              BaseHideoutScheme, IEnumerable<Item> allItems, bool canStartProduction)
//                                                            one per row; walks the stash
//
// MEASURED, 2026-09-28 (tracy_traces/*.tracy, read with tools/tracy/tracy-csvexport):
//
//   capture    UpdateViews   rows                 UpdateViewsAsync  ShowProduceViewAsync
//   22:07      868 ms mean   1729 / 10.3 ms       (not hooked)      (not hooked)
//   22:26      382 ms mean    735 / 94.0 ms        180 ns / 3        (not hooked)
//   22:35      251 ms mean   1321 / 130.7 ms       360 ns / 4        370 ns / 4
//
// What is established, and what is not:
//
//   * GetSortedSchemes is trivial - 4-5 us. It sorts an already-materialised collection; it does
//     not build one. The 104 Workbench scheme count is real and is not expensive.
//   * The rows are not the cost. ~33 ms per rebuild against a 251 ms UpdateViews, and row cost
//     per call has moved 6 us -> 99 us -> 128 us across captures, so it is station-dependent and
//     not yet stable enough to design against.
//     ^^ WRONG, and wrong in the most expensive way a note can be wrong. Those row figures were read
//     from zones that closed before the work they claimed to bracket - see the 2026-10-01 correction
//     below - so they measured the zone boundary, not the row. Corrected 2026-10-01 20:00 with the
//     scopes fixed: 2,461,294 ns mean per row, 3,484 rows, 8.58 SECONDS. The rows are 87% of hideout
//     panel time. Do not delete this line without reading the correction; it is the single most
//     expensive wrong number in this file's history.
//   * THE ASYNC BODIES ARE EMPTY, and that is now a measured result rather than a suspicion.
//     Both state machines were confirmed to be the RIGHT classes - the 22:35 resolve printed the
//     real name, <<UpdateViews>g__UpdateViewsAsync|25_0>d, and it is the only nested type on
//     ProductionPanel - and both MoveNexts measure in the hundreds of nanoseconds while
//     UpdateViews costs 251 ms. Chasing the async body further is abandoned: the state machine
//     body is evidently inlined into the kickoff stub (IL2CPP emits C++ and clang inlines it), so
//     there is no call left to hook. ~218 ms per rebuild sits inside UpdateViews' own synchronous
//     frame, and has to be attributed by hooking the methods that frame CALLS.
//
// That is what ProduceView.Show and SetInfo/UpdateOrder are for: ordinary synchronous methods,
// signatures taken from ISIL, nothing inferred.
//
// Worth recording as a trap: the real state machine name ends in ">d", while
// il2utils::is_state_machine_class_name() and find_state_machine_class() both look for ">d__".
// Both existing helpers would have REJECTED the correct class. The two-level sweep in this file
// finds it only because it matches on the method-name token and never asks whether the class
// "looks like" a state machine.
//
// WHAT THIS DOES NOT DO
//
// It measures. It does not throttle, debounce or suppress anything — coalescing UpdateViews is a
// behaviour change on a path the game's own StartProducing/SetInfo/UpdateOrder depend on, and it
// should be designed against these numbers rather than guessed at. See the note on
// production_panel_probe_install() for when the hooks are installed and why that is late.
//
// ---------------------------------------------------------------------------------------------
// WHAT THE MEASUREMENTS CONCLUDED, 2026-10-01
// ---------------------------------------------------------------------------------------------
//
// Two questions were open when this instrumentation started. Both are now answered, and the answers
// are recorded here so the next person does not re-derive them from logs.
//
// Q1. "Opening a crafting station stalls the game; keep the recipe list open so returning is free."
//
//     NO, and there is no version of it worth building. Seven COMPLETE opens, two stations, each
//     verified by the completion signal rather than by counting calls:
//
//         area 11   498 ms   384 ms   382 ms
//         area  7   400 ms   396 ms   389 ms
//
//     Flat. Reopening is not cheaper, not more expensive, and not warm - there is no warm path to
//     exploit because construction does not get cheaper with repetition. Every apparent saving
//     before 2026-10-01 17:05 was a half-built open compared against a finished one.
//
// Q2. "Skip the 50-second wait."
//
//     No event of that size exists in this code path. The largest single hideout operation in a
//     48-second visit is ShowContents at 12.8 ms across 10 calls, max 4.2 ms.
//
// WHERE THE TIME ACTUALLY GOES (2026-10-01 20:00 trace, zones correctly scoped for the first time):
//
//     HideoutProductionRequirementView::Show   8,575,150,236 ns  3,484 rows   0.715%
//     ProduceView::Show                       1,133,037,547 ns    180 views  0.095%
//     ProduceView::UpdateView                   127,079,882 ns    934 calls  0.011%
//     ProductionPanel::ShowContents              12,796,463 ns     10 calls  0.001%
//
//     87% of hideout panel time is ONE ROW at 2.46 ms, built 3,484 times. That is very likely the
//     "50 seconds": cumulative, spread across a long session, ~2.46 ms per row, needing ~20,000 row
//     constructions to add up. Nothing about it is a blocking rebuild and nothing about it is fixed
//     by reopening a station more cheaply.
//
// WHAT THIS FILE'S ONE BEHAVIOUR CHANGE IS ACTUALLY WORTH, which is the uncomfortable part:
//
//     The per-view coalescer is REMOVED. It was measured across two sessions and saved nothing.
//
//         2026-10-01 22:26   710 attempts,  51 redundant (7.2%),  0 avoided payments
//         2026-10-01 23:02   295 attempts,   2 redundant (0.7%),  0 avoided payments
//         combined          1005 attempts,  53 redundant (5.3%),  0 avoided payments
//
//     saved[coalesced] is the only counter that represented saved work, and it read 0 both times
//     with dropsPerDebtView at exactly 1.00 - every suppression created a fresh debt, so the
//     trailing pass paid for all of them. Nothing was ever collapsed.
//
//     The reason is structural, not a tuning problem. UpdateViews walks a set of DISTINCT views, so
//     with 27-41 views arriving every ~57 ms a given view repeats only every 1.5-2.3 s - and the
//     250 ms window is 6-9x too short to ever see that. A window wide enough to catch a repeat
//     would defer updates by over a second, which is a visible stall on a crafting panel. So there
//     is no window size at which this feature works, which is why it was deleted rather than tuned.
//
//     Two earlier readings of this were wrong and both are worth keeping as warnings:
//
//       * "The rows are a deferred path, so suppressing UpdateView does not suppress them." Built on
//         a Tracy --self (EXCLUSIVE) export read as if it were inclusive. Inclusive UpdateView is
//         7.25 ms, not 0.136 ms, and 98.2% of it is the requirement rows. The rows ARE nested inside.
//       * "Coalescing is worth 1.3%." Same mistake - 0.136 ms exclusive against a 7.25 ms inclusive.
//         Before the per-view clock fix it was not merely small, it was a net LOSS of +0.188 s.
//
//     tracy-csvexport --self prints EXCLUSIVE time; the plain invocation prints inclusive. A zone
//     with no children is identical in both, which is how to tell. Do not compare one against a
//     bracket or against the other form.
//
//     WHAT SURVIVES is the dispatcher collapse, which is the only coalescing here with a mechanism:
//     a full UpdateViews pass costs ~289 ms and every one of the panel's own change handlers
//     funnels back into it, so collapsing two of them skips a rebuild rather than moving one.
//
// WHAT WOULD ACTUALLY ATTACK THE 87%, and why it is not here:
//
//     Suppressing HideoutProductionRequirementView::Show for rows whose inputs have not changed.
//     That is the cost that matters - 2.57 ms per row, 1939 rows, 4.99 s - and it cannot be done
//     with a time window, because a row's Show has no independent re-driver: skip it on a timer and
//     it does not recover, it just keeps displaying a wrong count. It needs a per-row dirty check
//     against the inputs the row actually reads.
//
//     That is a different feature with a different risk profile, and it was not built on a
//     measurement-first basis. It should be its own decision - not a repointing of this knob, which
//     has now been mis-aimed three times and once shipped pointing at nothing at all.
//
// Tracy zones come from util/tracy_bridge.h, whose TA_ZONE_N compiles to a no-op when
// TRACY_ENABLE is absent — so this instrumentation is free in the configs without the profiler and
// needs no #ifdef here.

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

// hideout_reflection.h for hideout_read_field, and through it eft_api's string reader. The
// per-row zone labels a requirement's TemplateId so a hot row is identifiable in the trace.
#include "hideout_reflection.h"
#include "../il2cpp/exports.h"
#include "../il2cpp/il2utils.h"
#include "../util/logger.h"
#include "../util/tracy_bridge.h"

namespace production_panel_probe {

// Trampolines. One per hook, because each needs somewhere stable for safetyhook to write the
// resume address. They are function POINTERS, so the hook bodies can call them without a cast.
inline void* (*orig_show_contents)(void*) = nullptr;
inline void* (*orig_get_sorted_schemes)(void*, uint8_t) = nullptr;
inline void (*orig_update_views)(void*) = nullptr;
inline void (*orig_req_row_show)(void*, void*, void*, void*, void*, void*, uint8_t) = nullptr;
// MoveNext of <UpdateViews>g__UpdateViewsAsync|25_0's state machine. This is where the 868 ms
// actually goes: UpdateViews only kicks the state machine off, and the trace put 1.9 ms of a
// rebuild in the rows and 5 us in GetSortedSchemes, leaving the async body as the only place
// left. The first version of this file counted "asyncBuilds" from a hook that was never
// installed, so it read 0 forever and looked like evidence. See the header.
inline void (*orig_update_views_async_movenext)(void*) = nullptr;
// MoveNext of ShowProduceView's state machine. This is the one that needs no name invention:
// ShowProduceView is a real async METHOD on ProductionPanel
// (Task`1<Boolean> ShowProduceView(ItemUiContext, ProduceView, Boolean, ItemsProducerBase)),
// so its state machine is a direct nested type and il2utils::hook_async_method finds it with its
// existing one-level "<MethodName>d__" walk.
//
// It is instrumented because the 2026-09-28 22:26 capture ruled the other candidate out.
// UpdateViewsAsync's MoveNext measured 180 ns across three rebuilds while UpdateViews cost
// 1145 ms, so the class the token matched is not the one being Started. The game's own log says
// where the rows come from instead - ProduceView:Show via <>c__DisplayClass15_0:<ShowProduceView>
// b__2 - which places 735 row calls inside this body. See the header.
inline void (*orig_show_produce_view_movenext)(void*) = nullptr;
// IProduceView.UpdateView() - THE call the rebuild actually makes.
//
// Read straight out of the reference tree, which is what ended this. The state machine's MoveNext
// (ISIL .../ProductionPanel_NestedType___UpdateViews_g__UpdateViewsAsync_25_0_d.txt) is, in full:
//
//     this.<>u__1 = TasksExtensions.WaitUntil(new Func<bool>(<UpdateViews>b__25_1), 0);
//     await this.<>u__1;
//     foreach (KeyValuePair<BaseHideoutScheme, IProduceView> in this._views)
//         kvp.Value.UpdateView();
//
// So a rebuild is not a construction pass at all: it waits, then calls UpdateView() on every
// produce view in _views (Dictionary<BaseHideoutScheme, IProduceView>). The panel builds its views
// in Show/ShowProduceView, once; the rebuild only re-renders them. That is why
// HideoutProductionRequirementView::Show shows up as a child of UpdateViews in the trace - the row
// views are refreshed from inside UpdateView().
//
// IProduceView has exactly one method, void UpdateView(), and ProduceView implements it. The
// 104-scheme Workbench means ~104 entries in _views, so ~2.3 ms each is what a 245 ms rebuild
// divides into. This hook is the measurement that confirms or refutes that arithmetic.
//
// Also present, and kept because it creates the views the rebuild then re-renders (1415 ISIL lines,
// the largest method on the panel) - it is where the row Show calls originate.
inline void (*orig_produce_view_show)(void*, void*, void*, void*, void*, void*, void*, uint8_t) = nullptr;
inline void (*orig_update_view)(void*) = nullptr;

// Counters. Relaxed ordering: these are statistics for a human reading a flame graph, and a torn
// count across threads is not a correctness problem here — the game thread is the only writer and
// QPC accumulator for one instrumented hook.
//
// Total AND worst-single-call, because they answer different questions and the standing
// hypothesis needs both to survive or die: that a rebuild re-renders ~68-104 views at ~2.3 ms
// each. If the average lands near 2 ms the hypothesis holds; if the total is large but the
// per-call figures are tiny, the cost is spread thin and no amount of per-view work will move
// it. A count alone cannot tell those apart, which is why the last several captures did not.
struct timing_accum {
    std::atomic<uint64_t> calls{0};
    std::atomic<ULONGLONG> total_ticks{0};
    std::atomic<ULONGLONG> max_ticks{0};

    void add(const ULONGLONG ticks) {
        calls.fetch_add(1, std::memory_order_relaxed);
        total_ticks.fetch_add(ticks, std::memory_order_relaxed);
        // CAS loop rather than load-then-store: two game threads finishing views at once could
        // otherwise both read the old maximum and both write, and the lower one would win. That
        // would report a maximum smaller than a call already counted.
        ULONGLONG seen = max_ticks.load(std::memory_order_relaxed);
        while (ticks > seen
            && !max_ticks.compare_exchange_weak(seen, ticks, std::memory_order_relaxed)) {
        }
    }

    // Named count(), not calls(): the member is already `calls`, and a member and a method
    // cannot share a name in one class.
    uint64_t count() const { return calls.load(std::memory_order_relaxed); }
    double total_ms() const {
        return eft_api::probe_ticks_to_ms(total_ticks.load(std::memory_order_relaxed));
    }
    double max_ms() const {
        return eft_api::probe_ticks_to_ms(max_ticks.load(std::memory_order_relaxed));
    }
    double avg_ms() const {
        const uint64_t n = count();
        return n ? total_ms() / static_cast<double>(n) : 0.0;
    }
};

// "n=612 total=1234.5ms avg=2.02ms max=48.1ms" - cumulative since process start, like the
// counters beside it, so two report lines can be differenced to get a per-interval figure.
inline std::string format_timing(const timing_accum& t) {
    char buf[96];
    std::snprintf(buf, sizeof(buf), "n=%llu total=%.1fms avg=%.2fms max=%.1fms",
        static_cast<unsigned long long>(t.count()), t.total_ms(), t.avg_ms(), t.max_ms());
    return buf;
}

// ---- DISPATCHER STATE, also read by report() ----
inline std::atomic<bool> g_rebuild_pending{false};
inline std::atomic<ULONGLONG> g_rebuild_last_pass_ms{0};
inline std::atomic<uint64_t> g_rebuild_dropped{0};

// ---- WHAT THE PER-VIEW GATE ACTUALLY SUPPRESSED, 2026-10-01 ----
//
// One counter for "dropped" cannot answer the only question that matters, because the three cases
// have completely different values. A zero here is ambiguous in the same way a bare drop count is
// was: it can mean the gate never fired, or that it fired and every drop was legitimate.
//
//   first     never rendered - the update that makes the view visible at all
//   redundant already rendered inside the window - the content is current, so deferring is free
//   stale     rendered, but longer ago than the window - a real update, deferred for no gain
//
// Only `redundant` is a saving. `first` and `stale` are the same work moved to a more expensive
// place, and the 21:32 capture measured that place: 8.99 ms per trailing call against 7.25 ms
// inline, so the deferral carried a 24% premium on top of changing nothing.
inline std::atomic<uint64_t> g_update_view_would_first{0};
inline std::atomic<uint64_t> g_update_view_would_redundant{0};
inline std::atomic<uint64_t> g_update_view_would_stale{0};

// ---- COUNTERS AND FORMATTERS FOR report() ----
//
// These live ABOVE report() on purpose. report() prints all of them, and the natural place for a
// counter is next to the code that bumps it - which is 100-150 lines further down, past report().
// Declaring them here is the fifth time this file has hit "use before declaration" on exactly this
// arrangement, so the ordering is now deliberate rather than accidental: anything report() prints is
// declared before report().

// Two formatters for the report line. Plain functions rather than inline std::to_string chains
// because the ratio needs a zero guard - owed/runs is 0/0 whenever the trailing pass has never run,
// and printing that as "0" or dividing by it is how a dead counter gets mistaken for a real one.
inline std::string format_ratio(const uint64_t num, const uint64_t den) {
    if (!den) return "n/a";
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%.2f", static_cast<double>(num) / static_cast<double>(den));
    return buf;
}

inline std::string format_ms(const double ms) {
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%.2fms", ms);
    return buf;
}

inline ULONGLONG qpc_ticks_now() {
    LARGE_INTEGER t{};
    QueryPerformanceCounter(&t);
    return static_cast<ULONGLONG>(t.QuadPart);
}

// these are read for reporting.
struct counters {
    std::atomic<uint64_t> update_views{0};      // every handler's funnel point
    std::atomic<uint64_t> update_views_async{0};// async build RESUMPTIONS (MoveNext), not builds
    std::atomic<uint64_t> row_show{0};          // requirement rows built
    std::atomic<uint64_t> show_contents{0};     // full panel opens
    std::atomic<uint64_t> get_sorted{0};        // recipe-list enumerations
    std::atomic<uint64_t> show_produce_async{0};// ShowProduceView MoveNext entries
    std::atomic<uint64_t> produce_view_show{0}; // per-scheme view BUILDS (ShowProduceView path)
    std::atomic<uint64_t> update_view{0};       // IProduceView.UpdateView - the rebuild's real work
    std::atomic<ULONGLONG> last_report_ms{0};

    // Cost, not just count. update_view_time is the per-view re-render; rebuild_time is the
    // UpdateViewsAsync body, which is the whole rebuild as the game actually runs it.
    timing_accum update_view_time;
    timing_accum rebuild_time;
};
inline counters& stats() {
    static counters c;
    return c;
}

// One-shot, not a counter: the async state machine either resolves in this build or it does not,
// and retrying the search every frame forever would be a per-frame nested-type walk for nothing.
inline bool g_async_resolve_warned = false;

// A one-line summary, rate-limited. Without the limit this is one line per row build, which at
// 104 rows per action is exactly the log flood this file exists to avoid.
inline bool rebuild_coalescing_active() {
    return !hideout_rebuild_freely();
}

// A view refresh dropped by the coalescer rather than paid.
//

// Arrival cadence of UpdateView, measured before the gate so every attempt counts.
//
// g_update_view_gaps_inside is the number that matters: refreshes that arrived closer together than
// kRebuildCoalesceWindowMs, and therefore the refreshes the coalescing was ABLE to drop. If it is zero
// the gate can never fire and no amount of knob-tweaking will make it; if it is large, the coalescing
// is reaching most of what it could. The min/max bounds are there so an outlier run is
// distinguishable from a steady one - the first run of this showed drops in one session and none in
// another, which is exactly the kind of thing a single average would have hidden.
inline std::atomic<ULONGLONG> g_update_view_last_ms{0};
inline std::atomic<uint64_t> g_update_view_gaps{0};
inline std::atomic<uint64_t> g_update_view_gaps_inside{0};
inline std::atomic<ULONGLONG> g_update_view_gap_total_ms{0};
inline std::atomic<ULONGLONG> g_update_view_gap_min_ms{0};
inline std::atomic<ULONGLONG> g_update_view_gap_max_ms{0};

inline void report(const char* why) {
    const ULONGLONG now = GetTickCount64();
    ULONGLONG last = stats().last_report_ms.load();
    if (now - last < 500) return;
    // Compare-and-swap rather than a plain store: several game threads can reach these at once and
    // the point is only to keep the log readable, so losing a race here is harmless.
    if (!stats().last_report_ms.compare_exchange_strong(last, now)) return;
    logger::info("hideout-panel: " + std::string(why)
        + " contents=" + std::to_string(stats().show_contents.load())
        + " updateViews=" + std::to_string(stats().update_views.load())
        + " asyncResumes=" + std::to_string(stats().update_views_async.load())
        + " rowShows=" + std::to_string(stats().row_show.load())
        + " sortedEnumerations=" + std::to_string(stats().get_sorted.load())
        + " produceAsync=" + std::to_string(stats().show_produce_async.load())
        + " produceViewShows=" + std::to_string(stats().produce_view_show.load())
        // Labelled updateViewCalls, not a second "updateViews=": the two counters are different
        // things (rebuilds vs per-view re-renders) and printing them under one name is why
        // "updateViews=9 ... updateViews=612" read as a contradiction in every log so far.
        + " updateViewCalls=" + std::to_string(stats().update_view.load())
        + " view[" + format_timing(stats().update_view_time) + "]"
        + " rebuild[" + format_timing(stats().rebuild_time) + "]"
        // updateViewCalls now counts EVERY refresh, because nothing is suppressed any more - the
        // counter used to sit after the per-view gate, which meant it read low whenever the
        // coalescer was working, and the drops had to be printed beside it to recover the true
        // attempted total. That indirection is gone with the gate, so this is now simply the number
        // of times the game asked a view to refresh.
        //
        // WOULD-BE-SUPPRESSED, counted but NOT suppressed. The per-view gate was removed on
        // 2026-10-01 after measuring 0 avoided payments across 53 suppressions in two sessions, so
        // these three counters are the tombstone. They answer "would a coalescer have had anything
        // to do here?" without deferring anything and without costing anything measurable.
        //
        // rate is the number that matters: the fraction of refreshes that were already up to date.
        // At 0.7-7.2% across the two measured sessions there is nothing to collapse, and the reason
        // is structural rather than a tuning problem. The panel walks a set of DISTINCT views, so
        // with 27-41 of them arriving every ~57 ms, a given view repeats only every 1.5-2.3 s - and
        // the 250 ms window is 6-9x too short to ever see that. Widening the window enough to reach a
        // repeat means deferring updates by over a second, which is a visible stall on a crafting
        // panel. That is why this is a removal and not a retune.
        //
        // If would[redundant] ever climbs well above zero, the panel's refresh cadence has changed
        // and the gate could be reconsidered. This block is where it would go back in.
        + " would[first=" + std::to_string(g_update_view_would_first.load())
        + " redundant=" + std::to_string(g_update_view_would_redundant.load())
        + " stale=" + std::to_string(g_update_view_would_stale.load())
        + " rate=" + format_ratio(g_update_view_would_redundant.load(),
              g_update_view_would_first.load() + g_update_view_would_redundant.load()
              + g_update_view_would_stale.load()) + "]"
        // Dispatcher collapse count, which used to print only on the one-shot "coalescing ON" line
        // and so was invisible for the rest of the session. This is the ONLY coalescing left, and the
        // only kind with a mechanism: a full UpdateViews pass costs ~289 ms and every one of the
        // panel's own change handlers funnels back into it, so collapsing two of them skips a real
        // rebuild instead of moving one to a more expensive place.
        + " rebuildDropped=" + std::to_string(g_rebuild_dropped.load())
        // The DISPATCHER gate's own state, which is NOT the same question as rebuildDropped. That
        // counter is zero for two entirely different reasons - nothing arrived to drop, or the gate
        // is off -
        // and the 20:00 run showed the second: gap[n=906 inside=893] with dropped=0, i.e. 99% of
        // refreshes WERE inside the window and none were touched.
        //
        // Because the knob is inverted: rebuild_coalescing_active() is !hideout_rebuild_freely(),
        // so ticking the box (labelled "refresh every station view on each change") DISABLES
        // coalescing. The default was flipped to coalescing-on on 2026-10-01 by setting freely's
        // default to false in all three places it lives, so a dropped=0 line now means the gate was
        // switched off on purpose rather than sitting at a default nobody chose.
        //
        // The label still describes the ticked state, so the fast path remains "untick it". Fixing
        // that means editing 19 locale files owned by another workstream, so it is deliberately not
        // bundled into a default change. Until then this field is the thing to read.
        + " coalescing=" + (rebuild_coalescing_active() ? "on" : "off")
        // arrival cadence, and how much of it the window could actually have reached
        + " gap[n=" + std::to_string(g_update_view_gaps.load())
        + " inside=" + std::to_string(g_update_view_gaps_inside.load())
        + " avg=" + std::to_string(g_update_view_gaps.load()
            ? g_update_view_gap_total_ms.load() / g_update_view_gaps.load() : 0)
        + "ms min=" + std::to_string(g_update_view_gap_min_ms.load())
        + "ms max=" + std::to_string(g_update_view_gap_max_ms.load()) + "ms]");
}

// ---------------------------------------------------------------------------------------------
// Rebuild coalescing
// ---------------------------------------------------------------------------------------------
//
// WHAT THE GAME DOES. EFT.Hideout.ProductionPanel.UpdateViews() kicks off an async body whose
// MoveNext (ISIL ProductionPanel_NestedType___UpdateViews_g__UpdateViewsAsync_25_0_d.txt) is, in
// full:
//
//     this.<>u__1 = TasksExtensions.WaitUntil(new Func<bool>(<UpdateViews>b__25_1), 0);
//     await this.<>u__1;
//     foreach (KeyValuePair<BaseHideoutScheme, IProduceView> in this._views)
//         kvp.Value.UpdateView();
//
// so one "refresh" is a call to UpdateView() on every open produce view - ~104 of them on the
// Workbench - and the 2026-09-28 22:35 capture put that at ~245 ms of self time per call, four
// times in thirteen seconds. Six handlers funnel into UpdateViews, which is why it feels like the
// panel re-populates on every action.
//
// COALESCE, DO NOT SUPPRESS. A rebuild that is dropped outright is a rebuild whose result never
// appears, so a suppressed panel would show stale requirement counts and stale production
// progress - a panel that lies about what you own, which is a far worse defect than a visible
// stall. So instead: the first rebuild runs, arrivals inside the window are dropped, and ONE
// trailing rebuild is always owed and always paid. The panel is briefly behind, never wrong.
//
// The trailing pass is what makes this safe, and it is the part that is easy to leave out: a
// dropped call that is never repaid is exactly the suppression this paragraph rejects. It is
// driven from the per-frame tick (production_panel_probe_tick) rather than from a timer thread,
// because it has to run on the same thread as the game's own UI work.
//
// The window is a starting point, not a tuned constant. It is set near one rebuild's measured
// duration (245 ms) so that a burst of actions collapses to roughly one rebuild per window while
// the trailing pass still lands promptly. Re-tune it against the UpdateView zone once the
// per-view cost is known.
inline constexpr ULONGLONG kRebuildCoalesceWindowMs = 250;

// Game-thread-only in practice, atomic so a torn read cannot become a wild call. The pointer is
// the ProductionPanel instance captured from the last rebuild we let through; it is the same
// object the game would have called, since the panel outlives the screen it is shown on - but it
// is only ever dereferenced inside the game thread, and only while a trailing pass is actually
// owed, which cannot outlive the panel because every pass re-captures it.
inline void* g_rebuild_self = nullptr;

// The views belonging to the CURRENT open, and what is known about each.
//
// ONE structure serving two purposes, because they are the same question. Every repeated measurement
// of "is this open cheaper than the last one" failed for want of a completeness signal: 94 views
// STARTED is not 94 views BUILT, and the two Workbench opens of 2026-10-01 11:25 and 11:26 both
// reached 94 while building 4796 and 626 requirement rows respectively. Nothing that counted calls
// could tell those apart, and a half-built open compared against a finished one produces a number
// that means nothing.
//
// `rendered` is that signal. UpdateViews iterates _views and calls UpdateView() on each, so a view
// that has been through UpdateView at least once has been constructed AND laid out. Counting
// rendered views against constructed views says whether the open finished.
//
// `owed` is the debt from coalescing UpdateView rather than UpdateViews - the per-view refresh the
// existing knob's own label promises to control and does not currently touch. A dropped refresh is
// recorded here and repaid by production_panel_probe_tick.
//
// Declared HERE, above its first use in report_coalescing and production_panel_probe_tick, for the
// same reason g_open_last_ms sits above hk_show_contents: putting shared state next to the "other
// globals" puts it after the functions that call it, and MSBuild says so.
//
// Game-thread only, same assumption as the memos elsewhere in this file. Bounded on purpose: if the
// registry ever exceeds the cap it stops coalescing and passes everything through, because an
// unbounded cache keyed on a pointer the GC may reuse is a worse failure than a missed coalesce.
inline constexpr size_t kOpenViewRegistryCap = 512;

struct open_view_state {
    bool rendered = false;  // UpdateView has run at least once since this view was constructed
    // `owed` used to live here - the per-view debt the removed coalescer created. Gone with it.

    // When THIS view last actually ran, in GetTickCount64 ms. Added 2026-10-01 because the drop
    // gate was reading the DISPATCHER's clock (g_rebuild_last_pass_ms) rather than a per-view one,
    // and that turns out to be the whole problem - see the drop path in hk_update_view.
    //
    // The dispatcher sets g_rebuild_last_pass_ms, then calls orig_update_views, which walks the
    // views calling UpdateView on each. Every one of those calls therefore sees now - last ~= 0 and
    // lands inside the window, so the gate drops all of them. The dispatcher's own pass refreshes
    // nothing, and the trailing pass then pays for every view individually.
    //
    // That is what the 2026-10-01 21:32 capture shows: 110 dropped and 108 trailing calls, a 1.0:1
    // ratio, i.e. no batching whatsoever, and 8.99 ms per trailing call against 7.25 ms inline, so
    // the whole layer cost +0.188 s (+4.7%) rather than saving anything. One dispatcher collapse
    // (collapsed=1 of 12) was enough to set the clock and neutralise every view refresh behind it.
    ULONGLONG last_refresh_ms = 0;
};

inline std::unordered_map<void*, open_view_state>& open_views() {
    static std::unordered_map<void*, open_view_state> map;
    return map;
}

// When the window last gained a view that had never been updated - i.e. when new construction last
// happened.
//
// The rendered COUNT is a necessary completion condition and not a sufficient one, which the first
// run of it proved: two Workbench opens of 2026-10-01 11:45 both reported "94 rendered", so both
// passed the gate, and they still differed 5.4x in requirement rows built (3375 against 626). Every
// view had been updated once in both, which is all the count can tell you - a view can render once
// cheaply and be waiting for a second pass that never came because the player left.
//
// Quiescence is the missing half: if no NEW view has appeared for a few seconds before the window
// closed, the open had settled and its row count is final. If the number is small, the player left
// mid-build and the row count means nothing. Printed as settle=<ms>, or -1 when nothing rendered.
//
// WHAT IT DOES NOT COVER, which the 2026-10-01 14:00 run made plain: `rendered` latches on the FIRST
// UpdateView of a view and settle then stops moving, while the panel goes on re-rendering those same
// views for the rest of the window - updateViewCalls 1994 -> 2346 and rows 6616 -> 7795 AFTER the
// last new view had appeared. So settle means "construction finished", not "the panel stopped
// working". The ongoing re-render is a separate cost and settle says nothing about it.
inline ULONGLONG g_open_last_new_render_ms = 0;

// Records that a view has actually been refreshed. Called from EVERY path that reaches orig_update_view,
// including the trailing repayment.
//
// THIS IS THE FIX FOR A BUG THE COALESCING CAUSED IN THE SIGNAL BESIDE IT. The completion count was
// set on the pass-through path only, so a view whose refresh was coalesced and later repaid by the
// trailing pass was never marked rendered - because the repayment calls orig_update_view directly
// and never passed through the bookkeeping. The 2026-10-01 14:58 run then reported
//
//     open: 94 view(s) (83 rendered)
//
// which reads exactly like a player who left mid-build, and is in fact the coalescing hiding eleven
// views that were in fact rendered. The two features share one registry, which is why saving the
// structure also saved the interference: whatever calls orig_update_view has to call this.
inline void note_view_rendered(void* view) {
    auto& state = open_views()[view];
    if (!state.rendered) g_open_last_new_render_ms = GetTickCount64();
    state.rendered = true;
}

inline void report_coalescing() {
    // Rate-limited for the same reason report() is: this is on the drop path, which is the hot
    // path once the knob is off. A collapsed rebuild is only interesting occasionally, and a
    // per-collapse line would be the same log flood this file has already been bitten by.
    static std::atomic<ULONGLONG> last_ms{0};
    const ULONGLONG now = GetTickCount64();
    ULONGLONG last = last_ms.load(std::memory_order_relaxed);
    if (now - last < 5000) return;
    if (!last_ms.compare_exchange_strong(last, now, std::memory_order_relaxed)) return;

    // DISPATCHER coalescing only. The per-view layer this used to report alongside is gone, so the
    // two numbers that made this line ambiguous - viewCallsDropped and owedPerRun - are gone with it.
    // What remains is the only collapse that has a mechanism behind it.
    logger::info("hideout-panel: coalescing ON - window=" + std::to_string(kRebuildCoalesceWindowMs)
        + "ms collapsed=" + std::to_string(g_rebuild_dropped.load())
        + " updateViews=" + std::to_string(stats().update_views.load())
        + " updateView_calls=" + std::to_string(stats().update_view.load())
        + " wouldRedundant=" + std::to_string(g_update_view_would_redundant.load())
        + " trailingOwed=" + (g_rebuild_pending.load(std::memory_order_relaxed) ? "yes" : "no"));
}

// The trailing pass. Called once per frame from HideoutModule's application_update, next to
// production_panel_probe_install.
//
// Deliberately NOT a thread and NOT a timer: the game thread is where the panel's UI work belongs,
// and a background thread poking the panel's views would be a far worse thing to debug than a
// slightly late refresh. If nothing is owed this is a single relaxed load.
inline void production_panel_probe_tick() {
    const bool dispatcher_owed = g_rebuild_pending.load(std::memory_order_relaxed);

    // Per-view debts first, and independently of the dispatcher's: these are the refreshes dropped
    // at the UpdateView level and they are owed whether or not a dispatcher pass is outstanding.
    // Repaying them here rather than from the dispatcher is what keeps the "never leave the panel
    // stale" property intact when the dispatcher happens to be idle.
    // Per-view debts are GONE. They existed only to repay the per-view gate, and 53 suppressions
    // across two sessions produced 0 avoided payments, so there is nothing to repay. The dispatcher
    // debt below is the only one left, and it is the only one with a mechanism: a full UpdateViews
    // pass costs ~289 ms and every one of the panel's own change handlers funnels back into it, so
    // collapsing two of them really does skip a rebuild.
    if (!dispatcher_owed) return;
    if (!orig_update_views) return;                          // hooks not installed
    void* self = g_rebuild_self;
    if (!self) return;

    const ULONGLONG now = GetTickCount64();
    if (now - g_rebuild_last_pass_ms.load(std::memory_order_relaxed) < kRebuildCoalesceWindowMs)
        return;

    g_rebuild_pending.store(false, std::memory_order_relaxed);
    g_rebuild_last_pass_ms.store(now, std::memory_order_relaxed);
    {
        TA_ZONE_N("hideout::ProductionPanel::UpdateViews.trailing");
        orig_update_views(self);
    }
}
//
// Signatures are read off the ISIL declarations, not guessed. A `System.Threading.Tasks.Task` and an
// `IEnumerable<T>` are both reference types, so both are `void*` here; a `bool` parameter is a
// single byte in the IL2CPP ABI. The return value of the two hooked methods that have one is
// passed straight back — dropping it would break the caller, and these are on the game's own
// control flow (GetSortedSchemes' result is what the panel enumerates).
//
// `self` is the MonoBehaviour instance, which is why the first parameter is the instance and not
// an explicit one: IL2CPP passes `this` for instance methods.

// Per-station-open accounting, keyed on ShowContents rather than on the producer pointer. See the
// note in hk_show_contents for why the pointer was the wrong key - it fragments one open across
// many calls, which produced a self-contradictory line.
//
// All timestamps here are GetTickCount64 milliseconds. Nothing in this group is divided by 1000 a
// second time; an earlier version did, and it is why the first version of this measurement printed
// an 11 s burst as "11ms wall".
//
// Declared HERE, above hk_show_contents, because it is that function's state. Declaring it beside
// the other globals further down put it ~100 lines after its first use.
inline ULONGLONG g_open_last_ms = 0;                        // when the previous open happened
inline std::atomic<int> g_open_view_count{0};               // views constructed since then
inline std::atomic<ULONGLONG> g_open_view_ticks{0};         // QPC ticks spent inside ShowProduceView
inline std::atomic<int> g_open_view_area{-1};               // which area that previous open was for

inline void* hk_show_contents(void* self) {
    stats().show_contents.fetch_add(1, std::memory_order_relaxed);
    TA_ZONE_N("hideout::ProductionPanel::ShowContents");

    // ---- a station OPEN, measured as an open -------------------------------
    //
    // ShowContents is the event that means "the recipe list is being built", and the counts prove
    // it. Measured 2026-10-01 10:41-10:42, produceViewShows as a cumulative total:
    //
    //     contents=1  0 -> 94    Workbench, area 10, 99 schemes offered
    //     contents=2  94 -> 121  Medblock,  area  7, 27 schemes offered
    //     contents=3  121 -> 148 Medblock again, +27
    //
    // So every open costs one full construction pass - 94 views at the Workbench, 27 at the
    // Medblock - and leaving a station and returning pays it again in full. That is the whole of
    // the "keep the recipe list open" complaint, and it is now a number rather than a report.
    //
    // THIS REPLACED A FIRST ATTEMPT THAT MEASURED THE WRONG EVENT, and the reason is worth keeping
    // because it is the same shape of error as the gate two commits ago. That version keyed off a
    // change in the `producer` argument, on the theory that a new producer pointer meant a new
    // station open. It does not: the 94 Workbench calls were ONE open, and the run produced this
    // line -
    //
    //     open: area=10 94 view(s), 2508ms of 11ms wall, 33ms before this open
    //
    // which is self-contradictory, 2508 ms of work inside an 11 ms window. The cause was a plain
    // unit slip: GetTickCount64() is ALREADY in milliseconds and the span was divided by 1000
    // again, so the real 11 s and 33 s both printed two orders too small. The numbers underneath
    // were good, and the line that showed them was not trustworthy. A measurement that contradicts
    // itself must not be quoted even when its ingredients look plausible.
    //
    // Note what the corrected run then measured, because it retracts the 11 s that the broken line
    // appeared to support. Construction of those same 94 Workbench views is 2781 ms on a cold open
    // and 1463 ms on a warm one, not 11 s. The 11 s was the SPAN the calls were spread over, which
    // includes everything the panel did between them and has nothing to do with the work.
    {
        const ULONGLONG now = GetTickCount64();
        if (g_open_last_ms != 0) {
            const ULONGLONG absence_ms = now - g_open_last_ms;
            const int views = g_open_view_count.load(std::memory_order_relaxed);
            const double build_ms = eft_api::probe_ticks_to_ms(
                g_open_view_ticks.exchange(0, std::memory_order_relaxed));
            const int area = g_open_view_area.load(std::memory_order_relaxed);
            // How many of the constructed views have since been through UpdateView, which is what
            // makes this open comparable with another one. Reporting the ratio rather than a bare
            // time is deliberate: 94/94 is a finished open and 94/27 is a player who walked away,
            // and only the first of those is a valid input to "is reopening cheaper".
            size_t rendered = 0;
            for (const auto& kv : open_views())
                if (kv.second.rendered) ++rendered;
            const long settle_ms = g_open_last_new_render_ms
                ? static_cast<long>(now - g_open_last_new_render_ms)
                : -1;
            char buf[256];
            std::snprintf(buf, sizeof(buf),
                "hideout-panel: open: %d view(s) (%zu rendered), %lldms of construction, "
                "%llds since the previous open, settle=%ldms%s",
                views,
                rendered,
                static_cast<long long>(build_ms + 0.5),
                static_cast<long long>(absence_ms / 1000),
                settle_ms,
                area >= 0 ? (std::string(", previous was area=") + std::to_string(area)).c_str() : "");
            logger::info(buf);
        }
        g_open_last_ms = now;
        g_open_last_new_render_ms = 0;
        g_open_view_count.store(0, std::memory_order_relaxed);
        open_views().clear();
        // The area is NOT recorded here. At ShowContents time no ShowProduceView has run for the
        // new window, so the latch still describes the PREVIOUS station - reading it here named
        // the wrong one. Measured 2026-10-01 11:09, the window that built 27 Medblock views
        // reported "previous was area=10" when 10 was the station before it.
        //
        // hk_produce_view_show overwrites this on every call instead, so it ends up naming the
        // station that actually built the views: the latch updates on the first call of the window
        // and the last write wins. A window that builds nothing keeps the previous value, which is
        // why the report only prints it when non-negative.
    }

    report("ShowContents");
    return orig_show_contents(self);
}

inline void* hk_get_sorted_schemes(void* self, uint8_t include_continuous) {
    stats().get_sorted.fetch_add(1, std::memory_order_relaxed);
    {
        // Wraps the call AND its labelling, so the trace attributes the real cost. Previously the
        // zone closed before the return, and the 18:35 capture put it at 128 ns a call - the labelling
        // work, not the enumeration.
        TA_ZONE_N("hideout::ProductionPanel::GetSortedSchemes");
        if (TA_ZONE_IS_ACTIVE) {
            // includeContinuous is what separates the permanent producers (Bitcoin farm and
            // friends) from the single-shot recipes, so it belongs in the trace.
            const char* which = include_continuous ? "continuous" : "single";
            TA_ZONE_TEXT(which, 10);
        }
        return orig_get_sorted_schemes(self, include_continuous);
    }
}

inline void hk_update_views(void* self) {
    stats().update_views.fetch_add(1, std::memory_order_relaxed);
    report("UpdateViews");

    // The coalescing gate. ON by default as of 2026-10-01, so the pass-through below is now the
    // opt-OUT path: ticking the box restores the untouched game behaviour and clears any pending
    // pass. Worth being explicit that this is the DEFAULT the feature now ships with, because it
    // was the opposite until this date and the two states are indistinguishable in a trace unless
    // the report line says which one is running.
    if (rebuild_coalescing_active()) {
        const ULONGLONG now = GetTickCount64();
        if (now - g_rebuild_last_pass_ms.load(std::memory_order_relaxed) < kRebuildCoalesceWindowMs) {
            // Inside the window: collapse this one, and owe the panel a trailing pass so the
            // dropped rebuild's result still lands. See the coalescing note for why this is a
            // debt and not a cancellation.
            g_rebuild_pending.store(true, std::memory_order_relaxed);
            g_rebuild_dropped.fetch_add(1, std::memory_order_relaxed);
            report_coalescing();
            return;
        }
        g_rebuild_last_pass_ms.store(now, std::memory_order_relaxed);
        g_rebuild_pending.store(false, std::memory_order_relaxed);
        g_rebuild_self = self;
    }

    orig_update_views(self);
}

// The async build itself. MoveNext fires once per resumption, not once per build, so the counter
// is resumptions and the zone is per-resumption: the ratio against update_views is what says
// whether the build is one long synchronous run or a chain of await round-trips through the
// Unity synchronisation context. At 313 rows that distinction is the whole ballgame - a
// round-trip per row is what turns a rebuild into a visible stall.
inline void hk_update_views_async_movenext(void* state_machine) {
    stats().update_views_async.fetch_add(1, std::memory_order_relaxed);
    const ULONGLONG began = qpc_ticks_now();
    {
        TA_ZONE_N("hideout::ProductionPanel::UpdateViewsAsync");
    }
    orig_update_views_async_movenext(state_machine);
    // One RESUMPTION, not one rebuild. The body is `await WaitUntil(<UpdateViews>b__25_1, 0)`
    // then `foreach (kvp in _views) kvp.Value.UpdateView()`, so a rebuild that spans several
    // resumptions shows up as several entries here. That is why this is reported as a
    // distribution rather than as "the rebuild took N ms" - and why the per-view figure beside
    // it is the one to read first.
    stats().rebuild_time.add(qpc_ticks_now() - began);
}

// ShowProduceView's body: the per-scheme produce-view build, which is where the requirement rows
// are actually constructed. Kept separate from the UpdateViewsAsync zone above rather than merged,
// because until the 22:26 capture lands it is not established that the two are the same body -
// and merging them would hide exactly the discrepancy that discrepancy is here to expose.
inline void hk_show_produce_view_movenext(void* state_machine) {
    stats().show_produce_async.fetch_add(1, std::memory_order_relaxed);
    {
        TA_ZONE_N("hideout::ProductionPanel::ShowProduceViewAsync");
    }
    orig_show_produce_view_movenext(state_machine);
}

// ---- the LIVE hideout, captured off the game's own panel --------------------------------
//
// HideoutModule reads Profile.Hideout, which the log establishes is the HideoutInfo DTO - a
// snapshot, not the running object. Three separate dead ends all trace back to that one fact:
//   * ProductionData.Progress never moves. Measured 2026-09-29 21:24-21:25: `elapsed=244.202026s`
//     on every one of ~70 passes. Nothing was wrong with the derivation, the input was frozen.
//   * get_ProductionController is not on HideoutInfo or any parent, so the fuel/water gauges and
//     station attribution have no object to read.
//   * "get upgrade materials" has nothing, because area upgrade requirements live on the live
//     representation's Calculate*Requirements family.
//
// ISIL supplies the way in, and it is not a singleton hunt:
//
//   ProductionPanel.ShowProduceView(ItemUiContext, ProduceView, Boolean, ItemsProducerBase)
//       -> ProduceView::Show(..., ItemsProducerBase producer, ...)   <- we hook this, arg in hand
//   ItemsProducerBase.get_Hideout() -> this.<Hideout>k__BackingField -> HideoutRepresentation
//
// and from there ISIL shows get_ProductionController(), get_Areas() and the
// Calculate*Requirements family on the representation, plus get_ProducingItems(),
// get_EnergyController() and get_AreaData() on the producer itself.
//
// THIS IS A CAPTURE PLUS A DIAGNOSTIC, not yet a data source. Nothing keeps the hideout alive
// between ShowProduceView calls, so a consumer must re-validate the pointer per use rather than
// trust it. The line below therefore reports what actually resolved instead of quietly feeding
// the 1 Hz snapshot - if the route is wrong, that has to be visible in the log rather than
// showing up later as plausible-looking wrong numbers.
inline std::atomic<Il2CppObject*> g_live_hideout{nullptr};
inline std::atomic<Il2CppObject*> g_live_producer{nullptr};

// The producer whose <Schemes> set is currently in hideout_viewed_station_schemes().
//
// The cheap gate, and deliberately not the atomic above: g_live_producer is re-stored on EVERY
// ShowProduceView call and is the "last thing seen" pointer, whereas this one is only read and
// written to decide whether a re-walk is needed. Same value, but conflating them would make the
// gate useless, because the pointer it compares against would already have been overwritten.
inline Il2CppObject* g_latched_station_producer = nullptr;
// The HideoutRepresentation's ProductionController, read at the same time as the hideout itself.
// This is the object the whole live path hangs off: it owns the per-area producer lists, and
// UpdateProductions(Dictionary<string, ProductionData>) on it is the call the game makes when a
// finished item is collected.
inline std::atomic<Il2CppObject*> g_live_controller{nullptr};

// One live production, read entirely from FIELDS.
//
// Every name and shape below is taken from the ISIL bodies, not inferred, because guessing has
// cost three rounds of "method not found on <wrong class>" already. The references are
// EFT/Hideout/ProductionController.txt and EFT/Hideout/ProducingItemController_NestedType_
// ProducingProcess.txt in TarkovAddons/ISIL-references:
//
//   ProductionController.txt, SetProducer / GetAreaProducers:
//       this._areaProducers  (Dictionary<AreaData, List<ItemsProducerBase>>)   <- PLAIN FIELD
//   ItemsProducerBase.txt, get_ProducingItems:
//       Return this.<ProducingItems>k__BackingField                            <- auto-property
//   ProducingItemController.txt, get_SchemeId / get_AvailableForFinish:
//       Return this.<SchemeId>k__BackingField / this.<AvailableForFinish>k__BackingField
//   ProducingItemController.txt, get_Progress:
//       this._producingProcess.<Progress>k__BackingField                       <- two hops
//   ProducingProcess.txt, get_IsInProgress / get_BaseProductionTime:
//       Return this._isInProgress / this.<BaseProductionTime>k__BackingField    <- MIXED
//
// Two shapes there are easy to get wrong and both were checked rather than assumed:
//   * _isInProgress is a PLAIN field, while its neighbours Progress and BaseProductionTime are
//     backing fields. Reading "<IsInProgress>k__BackingField" returns nothing at all.
//   * ProducingItemController.get_Progress() is a COMPUTED getter that dereferences
//     _producingProcess and THROWS NullReferenceException when it is null. So the getter is not
//     just slower than the field, it is a way to raise a managed exception from our 1 Hz path -
//     and the crash probe is already counting 4000+ routine exceptions. The field is read instead.
//
// get_TimeLeft() is also computed (via EFT.DateTimeExtensions, from <EndTime>k__BackingField and
// the clock), so it is deliberately not used: Progress and BaseProductionTime plus the existing
// extrapolation already produce the countdown, and this does not add a DateTime dependency.
struct live_production {
    // ProducingProcess.<Progress>k__BackingField. A 0..1 FRACTION, not seconds - see the long note
    // above. Fallback only, because nothing in the game assigns this except the server DTO, so it
    // carries the same frozen value raw_progress always did. Kept for the diagnostic line, which
    // needs to show that it is not the source of the countdown.
    double progress_fraction = 0.0;
    // <BaseProductionTime>k__BackingField: the scheme's NOMINAL seconds. Correct, but by
    // construction free of the production-speed bonus, so it is the wrong denominator on its own.
    double base_production_time = 0.0;
    // <EndTime>k__BackingField: the ABSOLUTE unix-seconds deadline, already divided by
    // SpeedCoefficient. This is the live signal - it is the one field the game maintains itself,
    // recomputed by UpdateEndTime whenever the speed changes.
    double end_time = 0.0;
    // <SpeedCoefficient>k__BackingField: the production-speed bonus as a divisor. Reported so a
    // wrong countdown can be told apart from a wrong clock.
    double speed_coefficient = 0.0;
    // Present in the station's complete-items storage but NOT in ProducingItems, i.e. finished
    // and waiting to be taken. This is the state the DTO keeps reporting as a running job, which
    // is the reported bug - see the sweep note for why ProducingItems alone cannot express it.
    //
    // No ProducingItemController backs such an entry, so its progress and countdown fields stay at
    // their defaults; available_for_finish is the whole of what the card needs for it.
    bool finished_waiting = false;
    bool is_in_progress = false;      // ProducingProcess._isInProgress
    bool available_for_finish = false; // <AvailableForFinish>k__BackingField
    int area_type = -1;               // ItemsProducerBase.<AreaType>k__BackingField
    // The game's own remaining time, from ProducingItemController.get_EstimatedTimeLeft(), which
    // IS `EndTime - DateTimeExtensions.get_UtcNowUnix()`. Negative means it could not be read and
    // the caller must fall back rather than draw a countdown from a number it does not have.
    //
    // This is a MANAGED CALL, and it is the one in this file. The reason is that it performs the
    // EndTime-minus-the-game's-clock subtraction internally: reproducing that outside would mean
    // reading UtcNowUnix (a static managed call into System.DateTime) AND knowing which epoch the
    // game counts from, since EndTime is absolute. Seven calls a second for a number that is the
    // answer to the question being asked is a trade worth making; guessing the epoch is not, and a
    // wrong epoch is not a small error - it moves every deadline by however far off it was.
    double seconds_left = -1.0;
    // The true duration: BaseProductionTime / SpeedCoefficient, from the divsd in UpdateEndTime.
    // The DTO's production_time is the NOMINAL figure with no speed bonus in it, which is why the
    // card's HH:MM:SS disagreed with the real finish time.
    double total_seconds = 0.0;
};

inline std::mutex& live_producing_mutex() { static std::mutex m; return m; }

// The sweep's verdict on its own completeness, held under the same lock as the map so a reader
// can never see a fresh map with a stale verdict.
//
// WHY THIS IS NEEDED. The overlay treats the live set as authoritative - it removes DTO rows the
// sweep did not see, and adds rows the DTO has not caught up with. That is only sound if the sweep
// actually saw everything, and "read every producer" is not the same claim as "read every producer
// successfully". A producer whose <ProducingItems> failed to resolve contributes zero entries, and
// treating that as "this station has nothing running" would DELETE a live row off the card. So the
// verdict is the narrower claim: every producer's dictionary was read, and there was at least one
// producer. If either fails the map is still published (the values are as good as ever) but the
// SET is left alone, which degrades to the old behaviour of never removing anything.
struct live_sweep_state {
    std::unordered_map<std::string, live_production> entries;
    bool complete = false;
    int producers = 0;
};

inline live_sweep_state& live_sweep() {
    static live_sweep_state s;
    return s;
}

inline ULONGLONG& live_producing_stamp() { static ULONGLONG v = 0; return v; }

// The game's view of one running recipe, if we have seen it. False means "no live data for this
// scheme", which is NOT the same as "not running" - a station we have not been shown yet looks
// identical from here, and callers must fall back to the DTO rather than treat it as a finish.
inline bool live_production_for(const std::string& scheme_id, live_production& out) {
    if (scheme_id.empty()) return false;
    std::lock_guard<std::mutex> lock(live_producing_mutex());
    const auto& map = live_sweep().entries;
    const auto it = map.find(scheme_id);
    if (it == map.end()) return false;
    out = it->second;
    return true;
}

inline size_t live_production_count() {
    std::lock_guard<std::mutex> lock(live_producing_mutex());
    return live_sweep().entries.size();
}

// ---------------------------------------------------------------------------
// UPGRADE REQUIREMENTS - REACHABILITY PROBE, REMOVED 2026-10-03
// ---------------------------------------------------------------------------
//
// This section answered ONE question - "is the requirements chain reachable, and
// what shape does it come back in" - for a button that no longer exists. The card
// now answers the same question properly, from collect_upgrade_plan, and the
// button's answer went to the LOG FILE rather than to the screen.
//
// Removed: area_requirements_probe, probe_area_requirements(),
// probe_live_upgrade_requirements(). Gone with them is the whole
// request_area_requirements -> queue_area_requirements_ -> run_log_area_details
// chain in HideoutModule, and the get_materials ActionRowValue that was its only
// entry point. That control was constructed, toggled and registered but never
// ->draw()ed, so nothing in this section could ever run - it was verified dead by
// call graph, not by inspection.
//
// WHAT WAS WORTH KEEPING FROM IT, and where it went:
//
//   * The route. It named the correct chain - HideoutRepresentation._areaDatas ->
//     AreaData.get_Requirements() -> RelatedRequirements.Data -> ItemRequirement -
//     and had already established that IntCount/UserItemsCount are the game's own
//     stash-resolved numbers, so the card never touches the stash. collect_upgrade_plan
//     walks exactly this chain and the note above it says so.
//
//   * The correction. The original "template-side data, not profile state" note was
//     wrong, and this section is why that was found. The corrected chain is recorded
//     on collect_upgrade_plan.
//
//   * The read-only guarantee, which still holds and is still worth stating: no
//     upgrade is performed, no item is consumed, nothing is written to any
//     Requirement, and UpgradeZone/CompleteUpgradeZone are deliberately never
//     called - the server consumes the items from the stash there, so a client-side
//     implementation would be both unnecessary and a write against the account.
//     That now lives on the read_upgrade_area / collect_upgrade_plan pair.
//
// The one thing genuinely lost is probe_live_upgrade_requirements()'s route:
// ProductionController._areaProducers KEYS, which are live AreaData objects the
// sweep already walks past and discards. That route saw only producer-backed
// areas - 10 of 28 in the 2026-10-03 capture - so it was never going to be the
// right source for a complete list, and its "cheapest route" quality was exactly
// why it needed a second implementation to cover the other 18.
//
// ---------------------------------------------------------------------------
// THE PERMANENT UPGRADE LIST, 2026-10-02
// ---------------------------------------------------------------------------
//
// Reached from a producer the sweep already holds, so the chain is short:
//
//     ItemsProducerBase.get_Hideout()         -> HideoutRepresentation   (ISIL L4236)
//     HideoutRepresentation.get_AreaDatas()   -> List<AreaData>
//     AreaData._currentLevel                  (+0xA8)
//     AreaData.StageAt(_currentLevel + 1)     -> Stage
//     Stage.Requirements                      -> RelatedRequirements
//     RelatedRequirements.Data                -> List<Requirement>
//     ItemRequirement.<TemplateId>/<IntCount>/<UserItemsCount>k__BackingField
//
// get_Hideout() on the producer is the way in, and note_live_hideout() already reads exactly that
// property at line 1893 for the station latch - so the object was in hand before anyone thought to
// want it.
//
// TWO THINGS THAT ARE NOT WHAT THEY LOOK LIKE, both found by reading the bodies rather than the
// signatures, and both of which change the implementation:
//
//   * AreaData.get_Requirements() does NOT return the next level's needs. Its body is a field read
//     at +0xA8 returning this.<Template>.Requirements - the TEMPLATE's list, identical at every
//     level of that area. Listing that would print the same requirements for a Workbench at level
//     1 and level 3, which answers a question nobody asked.
//   * The per-level list lives on the Stage. get_NextStage() is StageAt(_currentLevel + 1) and
//     AreaData.CanBuild enumerates stage.Requirements, so this is the same object the game checks
//     before allowing the upgrade. Reading it is not a reimplementation of the rule.
//
// StageAt is a managed call, unlike everything else on the panel path. That is deliberate and
// bounded: it runs once per hideout open over ~27 areas, not per frame, and there is no field
// offset to read instead because the stage list is computed by StageAt itself.
//
// READ-ONLY. No Requirement is written and UpgradeZone/CompleteUpgradeZone are not called.

// The HideoutRepresentation, for the upgrade list.
//
// Reached from a producer's <Hideout>k__BackingField. The producer does NOT have to be the one the
// station latch captured - any producer will do - and that distinction is the whole bug this comment
// documents:
//
//   * g_live_producer is stored by note_live_hideout, which fires from the ShowProduceView hook. That
//     only happens when the player OPENS A STATION'S RECIPE PANEL. So g_live_producer is null for a
//     player who walks around their hideout without opening one - the common case - and that is why
//     the 2026-10-02 21:16 run logged "upgrades: reachable=0 areas=0" four times while the live
//     sweep on the very next line reported 11 readable producers.
//   * The controller's _areaProducers is populated by the hideout itself, so it is live whenever the
//     sweep is, with no interaction required.
//
// Prefer the captured producer, fall back to borrowing one out of the controller's dictionary. Two
// producers share one Hideout, so there is no correctness argument for insisting on the captured one.
//
// The route deliberately NOT taken: Comfort.Common.Singleton<HideoutRepresentation>.get_Instance is a
// global and needs no producer at all. It is a static property on a GENERIC INSTANTIATION, so
// reaching it means resolving Singleton`1<HideoutRepresentation> rather than Singleton`1 - more
// machinery than borrowing a pointer the sweep already walks past.
inline Il2CppObject* upgrade_representation() {
    if (Il2CppObject* producer = g_live_producer.load(std::memory_order_relaxed)) {
        if (hideout_class_usable(producer->klass)) {
            // get_Hideout() is an auto-property, so the storage is <Hideout>k__BackingField and there
            // is no field named "Hideout" on the type - the same shape as <Progress> and <TemplateId>.
            if (Il2CppObject* rep =
                    hideout_read_property<Il2CppObject*>(producer, "Hideout", nullptr)) {
                return rep;
            }
        }
    }

    // Fallback: borrow a producer from the controller's dictionary. Same walk the sweep does, so the
    // cost is one dictionary scan and the reachability is exactly the sweep's reachability.
    Il2CppObject* controller = g_live_controller.load(std::memory_order_relaxed);
    if (!controller || !hideout_class_usable(controller->klass)) return nullptr;
    Il2CppObject* by_area = hideout_read_field<Il2CppObject*>(controller, "_areaProducers");
    if (!by_area || !hideout_class_usable(by_area->klass)) return nullptr;
    auto* areas = reinterpret_cast<unity::dict<Il2CppObject*, Il2CppObject*>*>(by_area);
    const int count = areas->m_i_count;
    if (count <= 0 || !areas->m_p_entries
        || !eft_api::is_readable_address(areas->m_p_entries, sizeof(Il2CppArray))) {
        return nullptr;
    }
    const auto* entries = reinterpret_cast<
        const unity::dict<Il2CppObject*, Il2CppObject*>::entry*>(&areas->m_p_entries->data);
    const int walk = (std::min)(count, static_cast<int>(areas->m_p_entries->max_length));
    for (int i = 0; i < walk; ++i) {
        if (entries[i].m_i_hash_code < 0) continue;
        // The VALUE is List<ItemsProducerBase>, so element 0 is a producer.
        Il2CppObject* list_obj = entries[i].m_t_value;
        if (!list_obj || !hideout_class_usable(list_obj->klass)) continue;
        Il2CppObject** slot = hideout_list_at<Il2CppObject*>(reinterpret_cast<unity::list*>(list_obj), 0);
        if (!slot || !*slot || !hideout_class_usable((*slot)->klass)) continue;
        if (Il2CppObject* rep = hideout_read_property<Il2CppObject*>(*slot, "Hideout", nullptr))
            return rep;
    }
    return nullptr;
}

// Reads one ItemRequirement's three values. Returns false if the object is not that shape.
inline bool read_upgrade_requirement(Il2CppObject* req, upgrade_requirement& out) {
    if (!req || !hideout_class_usable(req->klass)) return false;
    const char* cls = req->klass->name ? req->klass->name : "";
    out.template_id = il2utils::conv_string(
        hideout_read_field<Il2CppString*>(req, "<TemplateId>k__BackingField"));
    out.need = hideout_read_field<int>(req, "<IntCount>k__BackingField", 0);

    // UserItemsCount is the HAVE side and -1 is the game's "not evaluated yet" sentinel. That is
    // a different statement from "you have none", so it is carried separately rather than being
    // collapsed into have=0 - a row that claims zero when it means unknown is worse than no row.
    const int have = hideout_read_field<int>(req, "<UserItemsCount>k__BackingField", -1);
    out.have = have;
    out.have_known = have >= 0;

    if (std::strcmp(cls, "ItemRequirement") == 0) {
        out.is_item = true;
        // get_ItemName() does NOT return a display name. ISIL for
        // EFT.Hideout.ItemRequirement.get_ItemName (115147510, IsilDump line 358) is:
        //
        //     22 Call String.Concat, v30 @ rax_v2, this.<TemplateId>k__BackingField, " ShortName"
        //
        // so it returns the LOCALISATION KEY ("5d1b2fa2... ShortName"), not the resolved
        // string. Reading it and displaying it is why the card printed raw MongoIds.
        //
        // try_localize_game_key is the same resolution the rest of this codebase uses for
        // ShortName (see eft_api.h:3270), and it is the path that actually reaches the
        // locale table. Falls back to the raw TemplateId if the key is absent, matching
        // the old behaviour for that case.
        out.label = out.template_id.empty()
            ? std::string()
            : eft_api::try_localize_game_key(out.template_id + " ShortName");
        if (out.label.empty()) out.label = out.template_id;
    } else {
        // Skill, trader, quest, resource and tool gates all live in the same list. They are real
        // blockers on an upgrade and the player needs to see them, but they are not quantities -
        // which is why they are excluded from the summed totals rather than given a fake count.
        out.is_item = false;
        out.label = cls;
        // Strip the type suffix so the card reads "Skill" rather than "SkillRequirement".
        const std::string suffix = "Requirement";
        if (out.label.size() > suffix.size()
            && out.label.compare(out.label.size() - suffix.size(), suffix.size(), suffix) == 0)
            out.label.erase(out.label.size() - suffix.size());
    }
    return true;
}

// Fills one area's row from its NEXT stage. False means no next stage, i.e. max level.
inline bool read_upgrade_area(Il2CppObject* area_data, upgrade_area& out) {
    if (!area_data || !hideout_class_usable(area_data->klass)) return false;
    out.current_level = hideout_read_field<int>(area_data, "_currentLevel", 0);
    out.next_level = out.current_level + 1;

    // _status is a PLAIN FIELD - ISIL, AreaData.get_Status(): `Return this._status
    // (EFT.Hideout.EAreaStatus)` - so this is a field read with no managed call and nothing that
    // can raise. It is the game's own answer to whether the area is finished, and it is read
    // BEFORE the StageAt call below so that a maxed area is known without paying for anything.
    // Enum transcribed from GameDump/.../Hideout/EAreaStatus.cs; see area_status in
    // hideout_reflection.h. -1 is left as the unread sentinel, never a status value.
    out.status = hideout_read_field<int>(area_data, "_status", -1);

    // AreaData carries NO EAreaType of its own, so there is nothing here to read - measured
    // 2026-10-03: "field '_areaType' not found on AreaData or any of its parents", and the card
    // rendered the row as "area -1" because of it.
    //
    // It comes from the TEMPLATE instead. AreaData.get_Template() is an auto-property over
    // <Template>k__BackingField (ISIL: "Return v0 ... this.<Template>k__BackingField
    // (EFT.Hideout.AreaTemplate)"), and AreaTemplate.Type is a PLAIN EAreaType field:
    //
    //     public EAreaType Type;   //Field offset: 0x64
    //
    // from GameDump/115147510/DiffableCs/Assembly-CSharp/EFT/Hideout/AreaTemplate.cs. One
    // memoised property lookup plus one plain field read, and it is route-independent - it works
    // for the HideoutController.Areas objects and the _areaDatas ones alike, which the
    // dictionary key cannot, since the key is only available on one of the two routes.
    //
    // Left at -1 if either step fails, which is still distinguishable from a genuine 0.
    out.area_type = -1;
    {
        Il2CppObject* tmpl = hideout_read_property<Il2CppObject*>(area_data, "Template", nullptr);
        if (tmpl && hideout_class_usable(tmpl->klass))
            out.area_type = hideout_read_field<int>(tmpl, "Type", -1);
    }

    // An area the game says has no future upgrades needs no requirements read at all, so it
    // returns here rather than calling StageAt and re-deriving the same fact the expensive way.
    // The requirement read below is still the authority when _status is unreadable (-1), because
    // a status we could not read must not be allowed to invent an answer.
    if (out.status == static_cast<int>(area_status::no_future_upgrades)) {
        out.has_next = false;
        return false;
    }

    const MethodInfo* stage_at = hideout_cached_method(area_data->klass, "StageAt", 1);
    if (!stage_at || !stage_at->methodPointer) return false;
    auto* fn = reinterpret_cast<Il2CppObject* (*)(Il2CppObject*, int)>(stage_at->methodPointer);
    Il2CppObject* stage = fn(area_data, out.next_level);
    if (!stage || !hideout_class_usable(stage->klass)) return false;   // max level

    // Stage.<StartTime>k__BackingField, a real auto-property - so hideout_read_property finds it
    // on the first try, unlike the hand-written getters on this route. System.DateTime is a
    // struct whose only payload is the long _dateData at offset 0, i.e. ticks since 0001-01-01,
    // with no timezone attached; that is all the card needs to print a date.
    if (Il2CppObject* start = hideout_read_property<Il2CppObject*>(stage, "StartTime", nullptr))
    {
        if (hideout_class_usable(start->klass))
        {
            const long long ticks = *reinterpret_cast<const long long*>(start);
            if (ticks > 0) out.start_time_ticks = ticks;   // 0 == DateTime.MinValue == unset
        }
    }

    // Stage.Requirements is a PUBLIC FIELD, not a property - ISIL shows
    // "Move this.Requirements, stage.Requirements", with no backing field anywhere.
    Il2CppObject* related = hideout_read_field<Il2CppObject*>(stage, "Requirements");
    if (!related || !hideout_class_usable(related->klass)) return false;
    Il2CppObject* data = hideout_read_field<Il2CppObject*>(related, "<Data>k__BackingField", nullptr);
    if (!data) data = hideout_read_field<Il2CppObject*>(related, "Data", nullptr);
    if (!data || !hideout_class_usable(data->klass)) return false;

    auto* list = reinterpret_cast<unity::list*>(data);
    const size_t count = list->live_count();
    for (size_t i = 0; i < count; ++i) {
        Il2CppObject** slot = hideout_list_at<Il2CppObject*>(list, i);
        if (!slot || !*slot) continue;
        upgrade_requirement req;
        if (read_upgrade_requirement(*slot, req)) out.requirements.push_back(req);
    }
    out.has_next = true;
    return true;
}

// Walks every area and rolls the item totals up.
//
// ONE ROUTE, AND IT IS THE ONLY ONE THAT CAN WORK. There was a second, via
// HideoutController.Areas, and it has been removed as unreachable rather than kept as a fallback -
// the reasoning matters more than the deletion, because it looks like it should work:
//
//   * EFT.Hideout.HideoutController DOES have `Dictionary<EAreaType, HideoutArea> get_Areas()` over
//     a private `_areas` (DiffableCs HideoutController.cs:57, offset 0x80), and HideoutArea.get_Data()
//     does hand back AreaData. Both were read out of the dump and both looked right.
//   * But get_HideoutControllerAccess() does not return that type. ISIL:
//
//         Method: EFT.TarkovApplication+HideoutController get_HideoutControllerAccess()
//           Return this.<HideoutControllerAccess>k__BackingField (EFT.TarkovApplication+HideoutController)
//
//     A NESTED type - the hideout LOADER. Its members are HideoutSelectedHandler, TryLoadHideout,
//     StartLoadHideoutMap, StartLoadHideoutBundles, UnloadHideout and HideHideout. It has no
//     _areas and no get_Areas to find, so both the field read and the designated getter failed,
//     which is exactly what the log showed:
//
//         hideout: field '_areas' not found on HideoutController or any of its parents
//         hideout: method 'get_Areas/0' not found on HideoutController or any of its parents
//
//     The scene MonoBehaviour that owns _areas is reachable only through the Unity scene graph,
//     which this module does not walk, so renaming or re-routing could never have fixed it.
//
//   * The misdirection was diagnostic, not accidental: Il2CppClass::name is UNQUALIFIED, so
//     EFT.Hideout.HideoutController and EFT.TarkovApplication+HideoutController both print as
//     "HideoutController". Every failure line therefore named a class whose members visibly exist,
//     which is what sent two rounds of diagnosis after a field resolver that was working fine.
//     hideout_class_label now prints the namespace with a '+' so the two cannot be confused again.
//
// The representation route has no such problem: it is reached from a producer the live sweep
// already holds, so it costs no extra traversal, and it returns all 28 areas - verified 2026-10-03
// as `areas=28 withNext=1 maxed=27 unknown=0`.
inline upgrade_plan collect_upgrade_plan() {
    upgrade_plan plan;
    std::vector<Il2CppObject*> area_objects;

    Il2CppObject* rep = upgrade_representation();
    if (!rep || !hideout_class_usable(rep->klass)) return plan;
    plan.representation_found = true;
    plan.source = "representation";

    // _areaDatas IS THE PLAIN FIELD. It is NOT an auto-property, which is why the property read
    // that used to be here could never work.
    //
    // hideout_read_property(rep, "AreaDatas") tries <AreaDatas>k__BackingField and then the bare
    // name, and BOTH miss - measured 2026-10-03 13:20:47, on a HideoutRepresentation that had just
    // been resolved successfully:
    //
    //     hideout: field '<AreaDatas>k__BackingField' not found on HideoutRepresentation ...
    //     hideout: field 'AreaDatas' not found on HideoutRepresentation ...
    //
    // ISIL says why. HideoutRepresentation.get_AreaDatas() is (metadata-init noise stripped):
    //
    //     Move rax, this._areaDatas            <- offset 0B8, a PLAIN field
    //     test rax, rax / jne ret
    //     ... newobj List<AreaData> ; this._areaDatas = rax
    //
    // so it is a hand-written getter over a private field, with a LAZY allocator in the miss
    // branch - not a compiler-generated one. This is the same trap as ProducingItemController's
    // _isInProgress, which hideout_reflection already documents: three of those neighbours are
    // backing fields and that one is not, and assuming backing-field shape returns nothing at all
    // rather than an error.
    //
    // THE LAZY ALLOCATOR IS WHY THE CALLER HAS A RETRY CLOCK. A representation nobody has asked for
    // its areas yet carries a null list, so the first collects after the hideout opens necessarily
    // come back empty. There is deliberately no getter call to force it - the module runs no
    // managed code on this path - so the caller retries every 2 s until the first success instead.
    //
    // The property read is kept as a fallback so a future rename that DOES make it an
    // auto-property still works, and so the log keeps naming the shape it failed on.
    Il2CppObject* datas = hideout_read_field<Il2CppObject*>(rep, "_areaDatas");
    if (!datas)
        datas = hideout_read_property<Il2CppObject*>(rep, "AreaDatas", nullptr);
    if (!datas || !hideout_class_usable(datas->klass)) return plan;
    auto* list = reinterpret_cast<unity::list*>(datas);
    const size_t count = list->live_count();
    if (count == 0) return plan;
    for (size_t i = 0; i < count; ++i) {
        Il2CppObject** slot = hideout_list_at<Il2CppObject*>(list, i);
        if (slot && *slot) area_objects.push_back(*slot);
    }
    if (area_objects.empty()) return plan;
    plan.reachable = true;

    // Item totals, keyed by template id. A std::map because the output is printed in a stable
    // order and a list that reorders itself between refreshes makes the card unreadable.
    std::map<std::string, size_t> total_index;
    for (Il2CppObject* area_data : area_objects) {
        ++plan.areas_considered;
        upgrade_area area;
        if (!read_upgrade_area(area_data, area)) {
            // Classify the miss instead of dropping it. "Finished" and "we could not read this
            // one" both land here, and only the first is evidence of a maxed hideout - so the
            // card gets to tell them apart rather than inferring one from the other.
            //
            // A readable _status that is NOT NoFutureUpgrades but whose StageAt still came back
            // unusable counts as unknown rather than maxed. That combination is contradictory
            // (the status says there IS a next stage) and treating it as finished would be
            // guessing, which is the failure this split exists to prevent.
            if (area.status == static_cast<int>(area_status::no_future_upgrades))
                ++plan.areas_maxed;
            else
                ++plan.areas_unknown;
            continue;
        }
        if (!area.has_next) continue;
        ++plan.areas_with_next;
        area.name = area.area_type >= 0 ? hideout_localize_area_name(area.area_type) : std::string();
        for (const upgrade_requirement& r : area.requirements) {
            if (!r.is_item || r.template_id.empty()) continue;
            auto it = total_index.find(r.template_id);
            if (it == total_index.end()) {
                total_index.emplace(r.template_id, plan.totals.size());
                upgrade_plan::total t;
                t.label = r.label;
                t.template_id = r.template_id;
                t.need = r.need;
                t.have = r.have;
                t.have_known = r.have_known;
                t.used_by = 1;
                plan.totals.push_back(std::move(t));
            } else {
                upgrade_plan::total& t = plan.totals[it->second];
                t.need += r.need;
                ++t.used_by;
                // have is the STASH count for that template, identical from every area that wants
                // it. Summing it would multiply the player's own inventory by the number of areas
                // - so the first value wins and later ones are ignored.
            }
        }
        plan.areas.push_back(std::move(area));
    }
    return plan;
}

// Defined below, next to g_live_controller. Forward-declared rather than duplicated or moved:
// the declaration-after-use problem is the sixth of its kind in this file, and the honest fix for a
// helper that already has the right home is a declaration, not a second copy of its body.
inline Il2CppObject* live_controller_handle();


// Whether the last sweep saw every producer. Read under the same lock as the map, and consumed by
// the overlay to decide whether it may prune.
inline bool live_sweep_complete() {
    std::lock_guard<std::mutex> lock(live_producing_mutex());
    return live_sweep().complete;
}

// Dropped when the hideout closes. A producer pointer is not a GC root, so entries must not
// outlive the hideout they came from.
inline void live_producing_clear() {
    std::lock_guard<std::mutex> lock(live_producing_mutex());
    live_sweep().entries.clear();
    live_sweep().complete = false;
    live_sweep().producers = 0;
    live_producing_stamp() = 0;
}

// The live ProductionController, as captured off the game's own panel.
//
// Only a CAPTURE. ShowProduceView is the only place a HideoutRepresentation is reachable at all -
// its ItemsProducerBase argument is the entry point - but nothing is read through it any more: the
// sweep goes straight to ProductionController._areaProducers, which holds every station, so what
// happens to be on screen stops mattering.
//
// Re-validated on every use by the caller rather than trusted here. A producer is not a GC root, so
// this can be collected the moment the hideout closes. Null means not-ready - ShowProduceView has
// simply not fired yet - which is a state to retry from, not a fault.
inline Il2CppObject* live_controller_handle() {
    return g_live_controller.load(std::memory_order_relaxed);
}

// ---------------------------------------------------------------------------------------------
// The live sweep: every station's running productions, in one pass
// ---------------------------------------------------------------------------------------------
//
// WHY NOT THE DTO. Profile.Hideout supplies which recipes are configured, but it does not move:
// measured 2026-09-29, m_i_count held at 6-7 and raw_progress sat at 244.202026 with InProgress
// false for a whole session while the player was collecting finished items. Every progress number
// on the card therefore has to come from the game's own controller, which IS updated - by
// ProductionController.UpdateProductions(Dictionary<string, ProductionData>), the call the game
// makes when a finished item is taken.
//
// WHY A FIELD AND NOT A CHAIN. The route to every producer is one plain field. From the ISIL body
// of ProductionController.GetAreaProducers (EFT/Hideout/ProductionController.txt), with the
// metadata-init noise stripped:
//
//     Move    v19 @ rcx_v3, methodof(Dictionary`2<AreaData, List<ItemsProducerBase>>::TryGetValue)
//     CheckEqual v39 @ ZF_v2, this._areaProducers, 0
//     Call    Dictionary`2<Object,Object>.TryGetValue(..., this._areaProducers, behaviour, &v44)
//     Return  v44 @ stack_8_v2
//     Newobj  returnVal2 @ rax_v2, typeof(NullReferenceException)
//
// which is, in C#, `return _areaProducers.TryGetValue(behaviour, out var v) ? v : throw new
// NullReferenceException();`. So _areaProducers is a PLAIN FIELD of type
// Dictionary<AreaData, List<ItemsProducerBase>> and it is the COMPLETE set of producers for the
// whole hideout. Reading it directly replaces the per-area call the previous design made:
//
//   * get_AreaDatas() + GetAreaProducers() per area was 27 managed calls a second, each ALLOCATING
//     a List, and every area missing from the dictionary raises a real managed
//     NullReferenceException - per the throw above. The crash probe is already counting 4000+
//     routine exceptions; adding 27/s from a path that has nothing to do with an error would have
//     been indefensible. That is the whole reason for reading the field.
//   * AreaData.get_HasActiveProduction() could not serve as a cheap pre-filter for the same
//     reason: one more managed call per area, to avoid a different one.
//
// Everything below _areaProducers is a field as well, so the sweep is pointer arithmetic over two
// dictionaries and NO managed code at all. Names and shapes, each read out of an ISIL body rather
// than inferred - guessing has already cost three "not found on <wrong class>" rounds here:
//
//   ItemsProducerBase.txt      get_ProducingItems        -> this.<ProducingItems>k__BackingField
//   ItemsProducerBase.txt      get_AreaType             -> this.<AreaType>k__BackingField
//   ProducingItemController.txt get_SchemeId            -> this.<SchemeId>k__BackingField
//   ProducingItemController.txt get_AvailableForFinish  -> this.<AvailableForFinish>k__BackingField
//   ProducingItemController.txt get_Progress            -> this._producingProcess.<Progress>k__BackingField
//   ProducingProcess.txt       get_IsInProgress         -> this._isInProgress             <- PLAIN
//   ProducingProcess.txt       get_BaseProductionTime   -> this.<BaseProductionTime>k__BackingField
//   ProducingProcess.txt       get_EndTime              -> this.<EndTime>k__BackingField
//   ProducingProcess.txt       get_SpeedCoefficient     -> this.<SpeedCoefficient>k__BackingField
//
// Three of those are not backing fields, and each would have been a silent zero if assumed:
//
//   * _isInProgress is a PLAIN field while its neighbours are backing fields. Reading
//     "<IsInProgress>k__BackingField" returns nothing at all, so the flag reads false on every
//     production and every running job would look finished - the exact failure the live path
//     exists to fix, reintroduced silently.
//   * ProducingItemController.get_Progress() is a COMPUTED getter that dereferences
//     _producingProcess and THROWS NullReferenceException when that is null. So it is not merely
//     slower than the field, it is a way to raise a managed exception from the 1 Hz path. The
//     field is read instead, and _producingProcess being null is treated as "not started" rather
//     than as a fault.
//   * ProducingProcess.get_TimeLeft() is also computed - it goes through EFT.DateTimeExtensions
//     from <EndTime>k__BackingField and the clock - so it is deliberately not used. EndTime is
//     read directly and the game's own clock is read directly instead, which is the same
//     subtraction without the getter (see live_utc_now for why the clock is not assumed).
//
// PROGRESS IS A RATIO, NOT SECONDS. This is the one that broke the bars, and the correction is
// worth stating because the field name is actively misleading. ProducingItemController.txt,
// UpdateFromProductionData:
//
//     Divide   v55, productionData.Progress (Single), productionData.ProductionTime (Int32)
//     Move     _producingProcess.<Progress>k__BackingField, v55
//     Move     _producingProcess.<BaseProductionTime>k__BackingField, productionData.ProductionTime
//     CallVoid ProducingProcess.UpdateProductionTimeAndProgressStatus
//
// So <Progress> is progressData.Progress / productionData.ProductionTime - a 0..1 FRACTION, and
// <BaseProductionTime> is the nominal total in seconds. The first version of this reader treated
// <Progress> as elapsed seconds and assigned it to ProductionInfo.raw_progress, which
// production_view_now consumes as SECONDS against production_time. The 2026-09-30 00:11 sweep shows
// exactly what that produced:
//
//     live sweep -> ... 7 running recipe(s) [run=6 ready=0] 0/12187 1/4312 0/3000 0/3668 0/33750
//
// 0 or 1 "of" 12187 - a fraction against a total, divided by the total again downstream. Every bar
// read 0% and every countdown read the full nominal duration. BaseProductionTime was RIGHT all
// along (300000s is the 83:19:58 on the card, 4312s is the 01:11:52), so the totals in that line
// are the game speaking correctly and the ratios are me dividing them twice.
//
// THE COUNTDOWN IS NOT THE NOMINAL DURATION, which is the "timing did not match" half. ISIL
// ProducingProcess.UpdateEndTime, with the two divisions intact:
//
//     Utils.ApproxEquals(this._speedCoefficient, 0d)  -> if ~0, leave EndTime alone
//     divsd   ... / this._speedCoefficient
//     subsd   <BaseProductionTime> - <EndTime>        ->  i.e. UtcNow + (Base - EndTime) / speed
//     mulsd   ...
//     addsd   + DateTimeExtensions.get_UtcNowUnix()
//     Move    this.<EndTime>k__BackingField
//
// and ProducingItemController.get_EstimatedTimeInt, the number the game's own panel shows:
//
//     _isInProgress ? Math.Ceiling(<EndTime>k__BackingField - DateTimeExtensions.get_UtcNowUnix())
//                   : _timeLeft
//
// So the remaining time is an ABSOLUTE WALL-CLOCK DEADLINE minus now, and the deadline already has
// your production-speed bonus divided into it. ProductionInfo.production_time is the scheme's
// nominal productionTime, which by construction has no speed coefficient in it - which is precisely
// why the card's HH:MM:SS disagreed with the real finish time. So the live path must supply a
// deadline, not an elapsed count, and both the total and the elapsed are re-derived from it.
//
// Nothing in UpdateProductionTimeAndProgressStatus or UpdateEndTime ever ASSIGNS <Progress>. Only
// UpdateFromProductionData does, and that is driven by the server DTO - the same frozen source this
// whole path exists to escape. So the fraction is not a live signal either; EndTime is the only
// field the game maintains on its own, and it is therefore the only one read for the countdown.
//
// A scheme id is the dictionary KEY as well as a field, but the field is read: it is the same
// string the game looks the job up by, and reading the key as well would only be a second copy of
// the same value to validate.
//
// UtcNowUnix is deliberately NOT read here. It is DateTimeExtensions.ToUnixTime(DateTimeExtensions
// .get_UtcNow()) - a managed static call into System.DateTime - and EndTime is an ABSOLUTE deadline,
// so subtracting it outside the game means also having to know which epoch the game counts from.
// Getting that wrong is not a rounding error; it shifts every deadline by however far off it was.
// So the one managed call in this file is the game's own get_EstimatedTimeLeft(), which performs
// exactly that subtraction internally and returns a plain number of seconds.
//
// Resolved on the VALUE class, not the dictionary. That distinction is the whole ballgame and
// getting it backwards was a real bug on 2026-09-29 22:40:
//
//     hideout: method 'get_SchemeId/0' not found on Dictionary`2 or any of its parents
//
// get_EstimatedTimeLeft lives on the ProducingItemController in each VALUE. Resolving against the
// container finds nothing, and latching that failure would leave the countdown on the frozen DTO for
// the rest of the session - which is precisely the bug this file exists to fix.
struct live_estimate_getter {
    float (*estimated_time_left)(Il2CppObject*) = nullptr;
    const Il2CppClass* from = nullptr;
};

inline live_estimate_getter& estimated_time_left_getter(const Il2CppClass* klass) {
    static live_estimate_getter g;
    if (g.from == klass) return g;
    if (!klass) return g;
    live_estimate_getter fresh;
    if (const MethodInfo* m = hideout_cached_method(klass, "get_EstimatedTimeLeft", 0))
        fresh.estimated_time_left = reinterpret_cast<float (*)(Il2CppObject*)>(m->methodPointer);
    fresh.from = klass;
    g = fresh;
    return g;
}

inline bool read_live_producing_item(Il2CppObject* value, const int area_type,
    live_production& out) {
    if (!hideout_class_usable(value->klass)) return false;
    Il2CppObject* process = hideout_read_field<Il2CppObject*>(value, "_producingProcess");
    if (!process || !hideout_class_usable(process->klass)) return false;

    // The fraction is a FALLBACK and nothing else - see the note above. It is never assigned to
    // raw_progress downstream, which would reintroduce the seconds-vs-ratio bug verbatim. It is
    // read because it is the only cross-check available on the total.
    out.progress_fraction = hideout_read_field<double>(process, "<Progress>k__BackingField", 0.0);
    const double base = hideout_read_field<double>(process,
        "<BaseProductionTime>k__BackingField", 0.0);
    out.base_production_time = base;
    out.end_time = hideout_read_field<double>(process, "<EndTime>k__BackingField", 0.0);
    out.speed_coefficient =
        hideout_read_field<double>(process, "<SpeedCoefficient>k__BackingField", 0.0);

    // PLAIN field, not a backing field - see the note above. Reading the backing-field name here
    // returns false on every production, which is indistinguishable from "nothing is running".
    out.is_in_progress = hideout_read_field<bool>(process, "_isInProgress", false);
    out.available_for_finish =
        hideout_read_field<bool>(value, "<AvailableForFinish>k__BackingField", false);
    out.area_type = area_type;

    // The true duration, from the divsd in UpdateEndTime. Guarded on speed > 0 because
    // UpdateEndTime returns early when the coefficient is ~0, which means "no deadline at all" -
    // and a total of zero is what production_view_now treats as "not a production", rendering 0%
    // with no countdown. That is the exact broken state, so falling back to the nominal base is
    // strictly better than dividing.
    out.total_seconds = (out.speed_coefficient > 1e-6) ? base / out.speed_coefficient : base;

    // The game's own remaining time, falling back to the cached _timeLeft the game writes
    // alongside EndTime. NaN is excluded explicitly rather than by a `>= 0` guard, because NaN
    // compares false against everything and would sail straight through one - and then poison the
    // subtraction downstream into a bar that reads as a plausible number.
    out.seconds_left = -1.0;
    const live_estimate_getter& est = estimated_time_left_getter(value->klass);
    if (est.estimated_time_left) {
        const float left = est.estimated_time_left(value);
        if (left == left && left >= 0.0f && left < 1.0e9f) {
            out.seconds_left = static_cast<double>(left);
        }
    }
    if (out.seconds_left < 0.0) {
        const double cached = hideout_read_field<double>(process, "_timeLeft", -1.0);
        if (cached == cached && cached >= 0.0 && cached < 1.0e9) out.seconds_left = cached;
    }
    return true;
}

// Overlay the live controller's view onto the DTO-derived productions.
//
// The DTO supplies WHICH recipes are configured; the live controller supplies HOW FAR ALONG they
// are and whether they are waiting to be collected. Both are needed and only one of them is
// fresh: on 2026-09-29 the DTO held raw_progress at 244.202026 with in_progress=no for a whole
// session while finished items were being collected, and reported "7 producing" for 37 straight
// seconds. Anything derived from it therefore froze - which is the reported bug - and the three
// symptoms the user saw were all the same frozen source.
//
// THE LIVE SET IS NOW AUTHORITATIVE, not just the live values. Both directions, because the
// reported symptom was a row that would not go away:
//
//   DTO row with no live entry   -> REMOVED. On 2026-09-30 18:20 Propital was taken out of the
//                                  Medblock and the card kept showing it at 100% / "Ready to
//                                  collect" for the rest of the session, because the frozen DTO
//                                  still listed it and the overlay only ever wrote values. The
//                                  game's own take path removes the entry from ProducingItems
//                                  (ItemsProducerBase.txt ~L12483, Dictionary.Remove on
//                                  doneItemId), so absence from BOTH live dictionaries means gone.
//   live entry with no DTO row   -> ADDED. A recipe requested during the session is in the live
//                                  objects immediately and in the DTO only on the next server
//                                  sync, so without this the card could not show a newly started
//                                  job at all - it appeared only after a relog.
//
// Both directions are gated on live_sweep_complete(), because pruning through an incomplete read
// deletes rows that are merely unread, not finished. That is the difference between "the card is
// briefly behind" and "the card deletes your jobs", and it is why the sweep reports `set=`.
//
// GATED ON THE SWEEP, NOT ON ANY SINGLE PRODUCER. An earlier version of this note argued the
// opposite - that a station we have not been shown is indistinguishable from an idle one - and that
// was true only of the ShowProduceView hook, which saw one station at a time. The sweep reads
// ProductionController._areaProducers, i.e. every station, so absence is now meaningful. Keeping
// the old reasoning would have meant the card could never remove anything, which is the bug.
//
// A waiting entry (finished, in the station's complete-items storage) has no ProducingItemController
// behind it, so it carries no progress - only available_for_finish, which is all production_view_now
// needs to draw 100% / "Ready to collect".
//
// Returns how many rows were refreshed from live data, for the summary line to report.
inline size_t apply_live_productions(std::vector<ProductionInfo>& productions,
    const std::vector<std::string>& label_ids = {},
    const std::vector<std::string>& labels = {}) {
    if (productions.empty() && !live_sweep_complete()) return 0;
    const ULONGLONG now = GetTickCount64();
    const bool authoritative = live_sweep_complete();
    size_t patched = 0;
    for (ProductionInfo& p : productions)
    {
        live_production lp;
        if (!live_production_for(p.recipe_id, lp)) continue;
        ++patched;
        p.available_for_finish = lp.available_for_finish;
        // The game's OWN flag, read off ProducingProcess._isInProgress, not a derivation. Both
        // previous sources were wrong: the DTO's ProductionData.InProgress read false for a job
        // that was plainly running (ready=no, production_time=12187, elapsed 244s), and deriving
        // it as !available_for_finish is only as good as a second field. production_view_now gates
        // the whole extrapolation on this, so a wrong value silently stops the countdown without
        // touching anything else.
        p.in_progress = lp.is_in_progress;

        // The live TOTAL, with the production-speed bonus divided in. This is the "timing did not
        // match" fix: the DTO's production_time is the scheme's NOMINAL productionTime and carries
        // no speed coefficient, so a countdown built from it disagrees with the real finish time by
        // exactly the bonus. Guarded - a zero total makes production_view_now render the row as
        // "no production" (0%, no countdown), which is the state being fixed, so the DTO's own
        // value is better than a computed zero.
        if (lp.total_seconds > 0.5) {
            p.production_time = static_cast<int>(lp.total_seconds + 0.5);
        }

        // ELAPSED IS DERIVED FROM THE COUNTDOWN, and this is the part that is easy to get wrong in
        // a way that looks fine. lp.progress_fraction is a 0..1 ratio written only by
        // UpdateFromProductionData - i.e. by the frozen server DTO - so assigning it to
        // raw_progress gives 0% on every row, which is what the first version did on
        // 2026-09-30 00:11. Instead: total minus the game's own remaining time. Both come from the
        // live object and they share a clock, so the two agree by construction.
        //
        // The seconds_left >= 0 test matters twice over. A negative value means the read failed, and
        // a failed read must fall through to the DTO rather than be clamped - clamping would
        // overwrite a possibly-good DTO value with a fabricated "just finished". And a value that
        // exceeds the total is a job past its deadline that has not been collected yet, which is
        // real and should read as complete rather than being discarded.
        if (lp.seconds_left >= 0.0 && p.production_time > 0) {
            const double elapsed = static_cast<double>(p.production_time) - lp.seconds_left;
            const float clamped = static_cast<float>(elapsed < 0.0 ? 0.0 : elapsed);
            p.raw_progress = clamped > static_cast<float>(p.production_time)
                ? static_cast<float>(p.production_time)
                : clamped;
        }

        // Re-stamped every pass, which is CORRECT here and was not for the DTO path. The anchor in
        // hideout_progress_anchor only moves when the value MOVES, and this value genuinely moves
        // every pass - it comes from a live clock, not a snapshot - so it re-anchors each time and
        // the extrapolation contributes at most the sub-second remainder since the sweep. The DTO
        // case needed the opposite treatment precisely because its value never moved.
        p.observed_ms = now;
        // progress / seconds_left are the stored, non-extrapolated derivations and are
        // recomputed by production_view_now on read, so they are deliberately left alone.
    }

    if (!authoritative) return patched;

    // ---- the set: remove what the game no longer has, add what the DTO has not caught up with ---
    //
    // Both passes under one snapshot of the live keys, because reading the map once per row and
    // then again for the set would let a sweep landing in between produce a half-old, half-new
    // answer - some rows judged against one sweep and some against the next. The lock is held for
    // the whole reconciliation so the answer is a single consistent view.
    std::unordered_map<std::string, live_production> live;
    {
        std::lock_guard<std::mutex> lock(live_producing_mutex());
        live = live_sweep().entries;
    }
    if (live.empty()) return patched;

    // 1. Drop DTO rows the game no longer has. erase-remove-if, keeping the order of what survives,
    //    because the card's row order comes from this vector and reordering it every pass would
    //    make rows jump under the player's cursor.
    const size_t before_remove = productions.size();
    productions.erase(
        std::remove_if(productions.begin(), productions.end(),
            [&live](const ProductionInfo& p) { return live.find(p.recipe_id) == live.end(); }),
        productions.end());
    const size_t removed = before_remove - productions.size();

    // 2. Add live entries the DTO does not list. A job started during this session is in the live
    //    objects now and reaches the DTO only on the next server sync, so without this the card
    //    cannot show it until a relog - which is the other half of "the card did not update".
    size_t added = 0;
    for (const auto& kv : live)
    {
        const bool already = std::any_of(productions.begin(), productions.end(),
            [&kv](const ProductionInfo& p) { return p.recipe_id == kv.first; });
        if (already) continue;
        ProductionInfo fresh_row;
        fresh_row.recipe_id = kv.first;
        // The label comes from the recipe list, which is keyed by the same scheme id. Falls back to
        // the raw id when the recipe is not in the loaded 254, which is a worse row rather than a
        // wrong one - and the recipe list is refetched on the 30 s clock, so it fills in.
        fresh_row.product_label = kv.first;
        for (size_t i = 0; i < label_ids.size() && i < labels.size(); ++i) {
            if (label_ids[i] != kv.first) continue;
            if (!labels[i].empty()) fresh_row.product_label = labels[i];
            break;
        }
        const live_production& lp = kv.second;
        fresh_row.available_for_finish = lp.available_for_finish;
        fresh_row.in_progress = lp.is_in_progress;
        if (lp.total_seconds > 0.5) {
            fresh_row.production_time = static_cast<int>(lp.total_seconds + 0.5);
        }
        if (lp.seconds_left >= 0.0 && fresh_row.production_time > 0) {
            const double elapsed =
                static_cast<double>(fresh_row.production_time) - lp.seconds_left;
            fresh_row.raw_progress = static_cast<float>(elapsed < 0.0 ? 0.0 : elapsed);
        }
        fresh_row.observed_ms = now;
        // data stays null: it is the managed ProductionData this row would have been read from, and
        // there is none for a row the DTO never carried. Consumers must already treat it as
        // optional, since it is only valid for the hideout's lifetime anyway.
        productions.push_back(std::move(fresh_row));
        ++added;
    }

    if (removed || added) {
        logger::info("hideout-panel: live set -> " + std::to_string(removed) + " removed, "
            + std::to_string(added) + " added, " + std::to_string(patched) + " refreshed, "
            + std::to_string(productions.size()) + " row(s) after");
    }
    return patched;
}

// Read every station's live productions out of ProductionController._areaProducers.
//
// The whole sweep is two dictionary walks and no managed code; see the long note above for the ISIL
// bodies each name and shape came from, and for why the per-area GetAreaProducers call it
// replaces was not merely slower but would have raised a managed NullReferenceException per
// unmapped area.
//
// REPLACED, NOT MERGED, over the union of TWO dictionaries per producer. A production that has been
// collected is absent from both, and merging would leave its stale entry in the map for the rest of
// the session - which is exactly the symptom being fixed. A production that is finished but NOT yet
// collected is absent from one of them and present in the other, which is why a single dictionary
// could not express it; see the storage read inside the walk for the ISIL that settles this.
//
// Returns how many productions are now known, for the summary line.
inline size_t refresh_live_productions(Il2CppObject* controller) {
    if (!controller || !hideout_class_usable(controller->klass)) return 0;

    Il2CppObject* by_area = hideout_read_field<Il2CppObject*>(controller, "_areaProducers");
    if (!by_area || !hideout_class_usable(by_area->klass)) {
        // Not-ready is the likelier explanation than a renamed field: the controller has no
        // producers until the hideout's stations have been built. One line, not one per pass.
        hideout_warn_once("live_area_producers",
            "ProductionController._areaProducers is "
            + std::string(by_area ? "not a readable object" : "null/absent")
            + " - live production progress is unavailable, falling back to the DTO");
        return 0;
    }

    // Dictionary<AreaData, List<ItemsProducerBase>>: the KEY is the area, the VALUE is the list of
    // producers on it. Only the value is needed here - area identity comes from each producer's own
    // AreaType, which is the same number the schemes are keyed by.
    auto* areas = reinterpret_cast<unity::dict<Il2CppObject*, Il2CppObject*>*>(by_area);
    const int count = areas->m_i_count;
    if (count <= 0 || !areas->m_p_entries
        || !eft_api::is_readable_address(areas->m_p_entries, sizeof(Il2CppArray))) {
        return 0;
    }
    const auto* entries =
        reinterpret_cast<const unity::dict<Il2CppObject*, Il2CppObject*>::entry*>(
            &areas->m_p_entries->data);
    const int walk = (std::min)(count, static_cast<int>(areas->m_p_entries->max_length));

    std::unordered_map<std::string, live_production> fresh;
    int producers_total = 0;
    int producers_measured = 0; // producers whose <ProducingItems> read back as a dictionary
    int items_seen = 0;          // dictionary entries examined
    int running = 0;             // entries with a non-null _producingProcess
    int ready = 0;               // of those, available to collect
    int countdown = 0;           // of those, where the game's remaining-time read worked
    int waiting_seen = 0;        // keys in the stations' complete-items storage
    int waiting_named = 0;       // of those, the ones whose scheme id actually read
    int waiting_empty = 0;       // of those, the ones holding ZERO items - tombstones left by Clear
    int waiting_only = 0;        // of those, with nothing running under the same id
    int waiting_over_running = 0;// of those, merged onto a running entry as "ready"
    int storage_shapes = 0;      // producers whose storage was not the dictionary shape
    std::string storage_kind;    // the class name, reported once
    std::string sample;          // a few left/total pairs, so "does it move" is readable

    for (int i = 0; i < walk; ++i)
    {
        if (entries[i].m_i_hash_code < 0) continue;
        Il2CppObject* producer_list = entries[i].m_t_value;
        if (!hideout_class_usable(producer_list ? producer_list->klass : nullptr)) continue;

        hideout_iterate_collection(producer_list, "live area producers", [&](Il2CppObject* producer) {
            if (!hideout_class_usable(producer->klass)) return;
            ++producers_total;

            // Auto-property. hideout_read_property tries <ProducingItems>k__BackingField first and
            // the bare name second, which is what this needs - the field really is named that.
            Il2CppObject* items = hideout_read_property<Il2CppObject*>(producer, "ProducingItems");
            if (!items || !hideout_class_usable(items->klass)) return;
            ++producers_measured;

            // Auto-property, and the same reason it matters as above: reading the bare "AreaType"
            // would return -1 for every producer and station attribution would silently break.
            const int area_type =
                hideout_read_field<int>(producer, "<AreaType>k__BackingField", -1);

            auto* dict = reinterpret_cast<unity::dict<Il2CppString*, Il2CppObject*>*>(items);
            const int n = dict->m_i_count;

            // NO EARLY RETURN HERE, and the absence of one is the fix. This used to read
            //
            //     if (n <= 0 || !m_p_entries || !readable) { return; }
            //
            // which is harmless on its own - there is nothing to walk - but it returned out of the
            // PRODUCER lambda, and the storage walk below lives in the same lambda. So a station
            // with an empty ProducingItems never had its _completeItems read at all.
            //
            // That is not an edge case, it is the single most important state a station can be in:
            // "holding a finished item, nothing running" is exactly what ProducingItems looks like
            // after the game does Dictionary.Remove(<ProducingItems>, doneItemId). The station that
            // most needs the storage walk is the one the early-out guaranteed would skip it.
            //
            // Measured 2026-09-30 23:02-23:04, which is what made it visible rather than theoretical:
            //   23:03:35  3 running + 0 waiting (0 keys, 0 empty)   <- stations holding items absent
            //   23:03:46  4 running + 0 waiting (2 keys, 2 empty)   <- only the stations that ALSO
            //                                                                 had something running
            // The 2 keys were tombstones from a collect. Every station whose only state was a
            // waiting item reported nothing, so the card showed no completed crafts while the game
            // was offering TAKE - the exact inverse of the 20:53 report, from the same feature.
            if (n > 0 && dict->m_p_entries
                && eft_api::is_readable_address(dict->m_p_entries, sizeof(Il2CppArray))) {
                const auto* rows =
                    reinterpret_cast<const unity::dict<Il2CppString*, Il2CppObject*>::entry*>(
                        &dict->m_p_entries->data);
                const int limit = (std::min)(n, static_cast<int>(dict->m_p_entries->max_length));
                for (int j = 0; j < limit; ++j)
                {
                    if (rows[j].m_i_hash_code < 0) continue;
                    ++items_seen;
                    Il2CppObject* value = rows[j].m_t_value;
                    live_production lp;
                    if (!read_live_producing_item(value, area_type, lp)) continue;
                    if (lp.is_in_progress) ++running;
                    if (lp.available_for_finish) ++ready;
                    if (lp.seconds_left >= 0.0) ++countdown;

                    const std::string id =
                        hideout_read_string(hideout_read_field<Il2CppString*>(
                            value, "<SchemeId>k__BackingField"));
                    if (id.empty()) continue;
                    fresh[id] = lp;

                    // Three pairs is enough to see the numbers move between passes; more would bury
                    // the rest of the log, which is the failure mode this file has already been bitten
                    // by twice. The id is truncated because a full MongoId is 24 hex characters. These
                    // are REMAINING/total - the two numbers the card draws - rather than progress,
                    // because "did the countdown tick" is the question and a ratio does not answer it.
                    if (sample.size() < 120) {
                        char pair[64];
                        std::snprintf(pair, sizeof(pair), "%.0f/%.0f",
                            lp.seconds_left, lp.total_seconds);
                        std::string one = id.substr(0, 8) + "=" + pair;
                        if (lp.available_for_finish) one += "!";
                        // REMAINING > TOTAL IS NOT A COUNTDOWN, and printing it bare made an
                        // impossible pair look like data. The 2026-10-01 23:02 log carried
                        // 5d5589c1=19500/12187 and 5d5c205b=43862/300000 on the same line - a
                        // job with five hours left on a three-hour recipe.
                        //
                        // The root cause is still unknown: seconds_left comes from
                        // ProducingItemController.get_EstimatedTimeLeft() and total_seconds from
                        // the scheme, so the two are read from different sources and evidently do
                        // not share an epoch. That is a separate investigation.
                        //
                        // What this marker does is stop the anomaly reading as a plausible number.
                        // A consumer - a person or a script - can now see that the pair is
                        // incoherent instead of having to notice that it is impossible, and the
                        // per-row shape is unchanged so the sample still lines up.
                        if (lp.total_seconds > 0.0 && lp.seconds_left > lp.total_seconds) one += "?";
                        if (!sample.empty()) sample += " ";
                        sample += one;
                    }
                }
            }

            // ---- the finished-but-uncollected half ----------------------------------
            //
            // ProducingItems is NOT the whole set, and that is the entire reason a collected item
            // stayed on the card. Two ISIL facts, both read out of the bodies rather than guessed:
            //
            //   ItemsProducerBase.txt ~L12483:  Dictionary.Remove(<ProducingItems>, doneItemId)
            //   ItemsProducerBase.txt ~L8006:   Dictionary.Remove(<ProducingItems>, schemeId)
            //
            // so TAKING a finished item removes its entry from ProducingItems. And
            // DefaultProductionStorage.GetItemsCount shows where it lives until then:
            //
            //   Call Dictionary`2<Object,Object>.TryGetValue, this._completeItems, scheme, &v46
            //
            // i.e. DefaultProductionStorage._completeItems, a Dictionary<string, List<Item>> keyed
            // by the SAME scheme id. A production that is finished but not yet collected is
            // therefore ABSENT from ProducingItems and PRESENT in _completeItems, and reading only
            // ProducingItems cannot tell that apart from one that was collected - it is gone from
            // both. On 2026-09-30 18:20 the DTO listed 7 productions, the sweep saw 4, and the
            // three it did not see were all "Ready to collect" rows on the card: two genuinely
            // waiting, one (Propital) already taken. One number cannot describe those three.
            //
            // The union of the two key sets is the authoritative answer to "what is this station
            // working on or holding", and both are plain fields, so it costs no managed call.
            //
            // Reached through _completeItemsStorage, a PLAIN field on ItemsProducerBase - NOT a
            // backing field. An earlier version reporting
            //   field '<CompleteItemsStorage>k__BackingField' not found on ItemsProducer
            // was right that the name was wrong and the log's "not found" was the correct answer.
            //
            // The field is read rather than get_CompleteItemsStorage() called, deliberately. That
            // getter's body is
            //
            //     this._completeItemsStorage ??= new DefaultProductionStorage()
            //
            // so calling it would ALLOCATE on any station that has never finished anything, from
            // a path that is supposed to be read-only. Null simply means nothing is waiting there,
            // which is the common case and needs no allocation to express.
            Il2CppObject* storage =
                hideout_read_field<Il2CppObject*>(producer, "_completeItemsStorage");
            if (!storage || !hideout_class_usable(storage->klass)) return;
            if (storage_kind.empty() && storage->klass->name) storage_kind = storage->klass->name;
            Il2CppObject* complete = hideout_read_field<Il2CppObject*>(storage, "_completeItems");
            if (!complete || !hideout_class_usable(complete->klass)) {
                // A storage whose _completeItems is not an object we can walk. ISIL shows there is
                // at least one such shape: SingleSchemeStorage._completeItems is a
                // List<Item>, not a Dictionary, and it carries no scheme key at all (its
                // GetItemsCount ignores the `scheme` argument and returns the list's _size). So a
                // single-scheme station's finished items are NOT visible to this sweep, and its
                // ready state cannot be read without a different route. Counted and named rather
                // than silently skipped, so a station that is always one shape behind is visible.
                ++storage_shapes;
                return;
            }

            auto* done = reinterpret_cast<unity::dict<Il2CppString*, Il2CppObject*>*>(complete);
            const int d = done->m_i_count;
            if (d <= 0 || !done->m_p_entries
                || !eft_api::is_readable_address(done->m_p_entries, sizeof(Il2CppArray))) {
                return;
            }
            const auto* done_rows =
                reinterpret_cast<const unity::dict<Il2CppString*, Il2CppObject*>::entry*>(
                    &done->m_p_entries->data);
            const int done_limit = (std::min)(d, static_cast<int>(done->m_p_entries->max_length));
            for (int j = 0; j < done_limit; ++j)
            {
                if (done_rows[j].m_i_hash_code < 0) continue;
                ++waiting_seen;
                const std::string id = hideout_read_string(done_rows[j].m_t_key);
                if (id.empty()) continue;
                ++waiting_named;

                // A KEY IS NOT PROOF OF AN ITEM. This is the whole fix, and getting it wrong
                // produced two opposite misreports in a row.
                //
                // DefaultProductionStorage.Clear(scheme), ISIL in full:
                //
                //     Call   List`1<Item>::Clear
                //     Add    [v48+1C], [v48+1C], 1     // a counter goes up
                //     Move   [v48+18], 0                // _size = 0
                //     ...    Dictionary`2<String,Int32>.Remove
                //
                // It empties the LIST and never removes the dictionary KEY. So after the player
                // takes a finished item, its scheme id stays in _completeItems forever, pointing at
                // an empty list. Reading key presence therefore reports "ready to collect" for the
                // rest of the session:
                //
                //   * 19:32, with the original "running wins, skip" rule - the card showed a live
                //     countdown for Орел while the station was offering TAKE (2 stored, 0 over a
                //     running job), and the user read that as "nothing on the left".
                //   * 20:53, after flipping to "ready wins" - the same tombstone forced 100% /
                //     "Ready to collect" onto rows that were genuinely still running. The sweep said
                //     `5de919ec=3636/3668` - 32 SECONDS from done - and the card showed it finished,
                //     because the player had collected an earlier batch of the same recipe and
                //     started a new one. The user reported the inverse: card says ready, in-game
                //     says a new job is running. Both reports were this one fact.
                //
                // So the count has to be read, and via try_get_list_count rather than by offset
                // arithmetic here: that helper reads _size (0x18) with a get_Count fallback, which
                // is byte-for-byte what IProductionStorage.GetItemsCount returns - `Return
                // [v46+18h]` in its own body. Reusing it means this cannot drift from the number
                // the game itself would answer, which is the only number that matters here.
                Il2CppObject* items = done_rows[j].m_t_value;
                if (!hideout_class_usable(items ? items->klass : nullptr)) {
                    ++waiting_empty;
                    continue;
                }
                const int held = eft_api::try_get_list_count(items);
                if (held <= 0) {
                    // A tombstone, not a collectable item. Counted so the log can show a station
                    // whose storage is all tombstones - otherwise a permanently non-empty
                    // _completeItems looks identical to a permanently full one.
                    ++waiting_empty;
                    continue;
                }

                // READY WINS OVER RUNNING, which is correct once the count is read. The two
                // dictionaries answer different questions rather than competing:
                //
                //     _completeItems[scheme] with a non-empty list -> "is there an item to take?"
                //     ProducingItems[scheme]                       -> "what is running, how far?"
                //
                // A scheme can be in both - one batch finished while the next runs - and then there
                // genuinely IS something to collect, so the ready flag is right and the running
                // entry's progress is kept so the row falls back to its countdown as soon as the
                // item is taken. production_view_now checks available_for_finish first, and the
                // render checks it before in_progress, so the row draws as finished rather than
                // reporting a countdown for a job the player can already collect.
                const auto running = fresh.find(id);
                if (running == fresh.end()) {
                    live_production waiting;
                    waiting.finished_waiting = true;
                    waiting.available_for_finish = true;
                    waiting.area_type = area_type;
                    fresh[id] = waiting;
                    ++waiting_only;
                } else {
                    running->second.finished_waiting = true;
                    running->second.available_for_finish = true;
                    ++waiting_over_running;
                }
            }
        });
    }

    {
        std::lock_guard<std::mutex> lock(live_producing_mutex());
        live_sweep().entries = std::move(fresh);
        // The narrow claim, as described on live_sweep_state. A producer whose dictionary did not
        // read is a hole in the SET, and pruning through a hole deletes a live row off the card.
        live_sweep().complete = producers_total > 0 && producers_measured == producers_total;
        live_sweep().producers = producers_total;
        live_producing_stamp() = GetTickCount64();
    }
    const size_t known = live_production_count();

    // The first few passes, then once every 10 s. A hard 6-pass cap was too little for the question
    // being asked: the 2026-09-30 run stopped reporting six seconds after the station opened, which
    // is exactly the window in which "is the countdown moving" is unanswerable. So the steady state
    // is a slow heartbeat rather than silence - a swept number that has stopped changing has to be
    // visible as such, or the log cannot distinguish "working" from "frozen" after the first few
    // seconds. Rate-limited rather than per-pass because this is 7 rows of text.
    static int reported = 0;
    static ULONGLONG last_report_ms = 0;
    const ULONGLONG now_ms = GetTickCount64();
    const bool due = (reported < 6) || (now_ms - last_report_ms >= 10000);
    if (due && (items_seen > 0 || reported < 1
        || producers_measured < producers_total || countdown < items_seen
        || waiting_named > 0 || storage_shapes > 0
        || waiting_seen != waiting_named)) {
        last_report_ms = now_ms;
        ++reported;
        logger::info("hideout-panel: live sweep -> " + std::to_string(count)
            + " area(s) with producers, " + std::to_string(producers_total) + " producer(s) ("
            + std::to_string(producers_measured) + " readable), "
            + std::to_string(items_seen) + " running + " + std::to_string(waiting_only)
            + " waiting (" + std::to_string(waiting_named) + " keys, "
            + std::to_string(waiting_empty) + " empty, "
            + std::to_string(waiting_over_running) + " over a running job), "
            + std::to_string(known) + " total [run=" + std::to_string(running)
            + " ready=" + std::to_string(ready)
            + " clock=" + std::to_string(countdown)
            + " set=" + (live_sweep_complete() ? "authoritative" : "partial") + "]"
            + (storage_shapes > 0
                ? " storage=" + storage_kind + " x" + std::to_string(storage_shapes) + " (not a dictionary)"
                : std::string())
            + (sample.empty() ? std::string() : " " + sample));
    }
    return known;
}

inline void note_live_hideout(Il2CppObject* producer) {
    if (!producer) return;
    bool found = false;
    Il2CppObject* hideout = hideout_read_property<Il2CppObject*>(producer, "Hideout", &found);
    // No such member means this is not the shape ISIL describes. Say nothing rather than warn on
    // every one of ~27 rows: a wrong assumption here should be one line, not a wall.
    if (!found) return;

    g_live_producer.store(producer, std::memory_order_relaxed);

    // ---- latch the station being looked at --------------------------------
    //
    // ShowProduceView is called once per row of the game's own produce view, and every one of them
    // carries the ItemsProducerBase for the open panel. So "which station am I at" is handed over
    // on every call rather than having to be inferred from the sweep.
    //
    // This producer was previously discarded on the strength of a MISREADING of its own
    // measurement, kept here because the mistake is easy to repeat. The old note said the readout
    // "measured (2026-09-29 22:59) as idle on all 27 calls", and concluded the pointer was not
    // usable. Idle is a statement about that station's ProducingItems being empty. It says nothing
    // about whether the pointer can identify the station - a bench with nothing running is still
    // perfectly good at answering "which recipes can I make", which is the question being asked
    // here. Two different facts, and the conclusion came from the wrong one.
    //
    // THE POINTER IS THE GATE, AND IT HAS TO BE THE FIRST THING. The first version of this walked
    // <Schemes> and built a fresh unordered_set<string> on every call, then compared sizes to
    // decide whether anything had changed. Comparing the SIZES is not a gate, it is a check that
    // runs after the work it is supposed to avoid - the same "validate after the expensive step"
    // ordering that has cost this project a run more than once.
    //
    // What it cost, measured 2026-10-01 09:25-09:26, at the Workbench:
    //
    //     viewing station area=10 with 99 scheme(s)     24 calls at the Intelligence Center
    //                                                    94 calls at the Workbench
    //     produceViewShows=142   rebuild avg=279.53ms   max=886.3ms
    //
    // 142 walks of a 99-entry dictionary, building and destroying 142 hash sets and allocating
    // ~14000 std::strings, on the game's UI thread inside a hook, at the same moment the panel was
    // already spending 886 ms rebuilding itself. The pointer comparison below is one integer
    // compare and it is exact: the same producer means the same station means the same Schemes.
    if (producer == g_latched_station_producer) return;
    g_latched_station_producer = producer;

    // The scheme set, not just the area. <Schemes>k__BackingField is a Dictionary<string,
    // BaseHideoutScheme> and it is the game's own answer to what this station offers - InitStorage
    // uses exactly this to find the scheme behind a finished production
    // (ItemsProducerBase ~L7228: TryGetValue(<Schemes>, productionData.RecipeId)). Area type would
    // be coarser than the truth and measurably so: one area holds 2 producers, so two different
    // benches share an areaType.
    {
        const int area = hideout_read_field<int>(producer, "<AreaType>k__BackingField", -1);
        std::unordered_set<std::string> ids;
        Il2CppObject* schemes =
            hideout_read_field<Il2CppObject*>(producer, "<Schemes>k__BackingField");
        if (schemes && hideout_class_usable(schemes->klass)) {
            auto* dict = reinterpret_cast<unity::dict<Il2CppString*, Il2CppObject*>*>(schemes);
            const int n = dict->m_i_count;
            if (n > 0 && dict->m_p_entries
                && eft_api::is_readable_address(dict->m_p_entries, sizeof(Il2CppArray))) {
                const auto* rows =
                    reinterpret_cast<const unity::dict<Il2CppString*, Il2CppObject*>::entry*>(
                        &dict->m_p_entries->data);
                const int limit =
                    (std::min)(n, static_cast<int>(dict->m_p_entries->max_length));
                for (int j = 0; j < limit; ++j) {
                    if (rows[j].m_i_hash_code < 0) continue;
                    const std::string id = hideout_read_string(rows[j].m_t_key);
                    if (!id.empty()) ids.insert(id);
                }
            }
        }

        auto& latched = hideout_viewed_station_schemes();
        int& latched_area = hideout_viewed_station_area();
        latched = std::move(ids);
        latched_area = area;
        logger::info("hideout-panel: viewing station area=" + std::to_string(area)
            + " with " + std::to_string(latched.size()) + " scheme(s)");
    }

    // The per-row producing readout is GONE - not because the producer is unusable, which the
    // paragraph above establishes, but because "what is the station I happen to be looking at
    // making" answers a question the sweep already answers better. What the player wants from the
    // station is the opposite question - "narrow my list to this" - and that is what the latch
    // above now serves.
    if (!hideout)
    {
        // Not-ready rather than broken: ItemsProducerBase has no Hideout until the hideout has
        // initialised it, so this is a state to retry from, not a fault to report.
        g_live_hideout.store(nullptr, std::memory_order_relaxed);
        return;
    }
    // Log on capture and on change only. Re-logging per row would be 27 identical lines a
    // second, which is the failure mode this whole file exists to avoid.
    if (g_live_hideout.exchange(hideout, std::memory_order_relaxed) == hideout) return;

    bool controller_found = false;
    bool areas_found = false;
    bool items_found = false;
    Il2CppObject* controller = hideout_read_property<Il2CppObject*>(
        hideout, "ProductionController", &controller_found);
    Il2CppObject* areas = hideout_read_property<Il2CppObject*>(hideout, "Areas", &areas_found);
    Il2CppObject* producing = hideout_read_property<Il2CppObject*>(
        producer, "ProducingItems", &items_found);

    size_t area_len = 0;
    if (areas) area_len = (std::min)(static_cast<size_t>(512),
        reinterpret_cast<Il2CppArray*>(areas)->max_length);

    int producing_count = 0;
    if (producing) producing_count = reinterpret_cast<unity::dict<Il2CppString*, Il2CppObject*>*>(
        producing)->m_i_count;

    char buf[320];
    std::snprintf(buf, sizeof(buf),
        "hideout-panel: LIVE hideout captured off ShowProduceView: producer=%p hideout=%p | "
        "ProductionController=%s%p | Areas=%s len=%zu | ProducingItems=%s count=%d",
        producer, hideout,
        controller_found ? "" : "NO-MEMBER ", controller,
        areas_found ? (areas ? (areas->klass && areas->klass->name ? areas->klass->name : "?") : "null") : "NO-MEMBER",
        area_len,
        items_found ? "" : "NO-MEMBER ", producing_count);
    logger::info(buf);

    // Keep the controller: the 1 Hz sweep needs it, and this is the only place it is ever in hand.
    g_live_controller.store(controller_found ? controller : nullptr,
        std::memory_order_relaxed);
}

// The per-scheme view build. This is the first hook placed on a method that is definitely reached
// synchronously from inside UpdateViews' frame, rather than on a state machine that the compiler
// turned out to inline away.
inline void hk_produce_view_show(void* self, void* item_ui_context, void* inventory, void* scheme,
    void* producer, void* on_start_producing, void* get_produced_items, uint8_t available_favorites) {
    stats().produce_view_show.fetch_add(1, std::memory_order_relaxed);
    note_live_hideout(static_cast<Il2CppObject*>(producer));

    // ---- cost of CONSTRUCTING one view --------------------------------------
    //
    // Accumulated into the current ShowContents window and drained by hk_show_contents. Only the
    // SYNCHRONOUS part of ShowProduceView is timed: it is an async method (Task`1<Boolean>), so this
    // bracket covers the call that STARTS the state machine, not the body that builds the view. The
    // rest of an open's cost is therefore not in this number, which is why the report says "of
    // construction" rather than claiming to be the whole build.
    //
    // Deliberately NOT keyed on the producer pointer. That was the first attempt and it was wrong:
    // one open is 94 calls against one pointer, and 27 against another, all within a single
    // ShowContents. Keying on the pointer fragmented a single open into many "stations". See the
    // note in hk_show_contents.
    const ULONGLONG began = qpc_ticks_now();
    g_open_view_count.fetch_add(1, std::memory_order_relaxed);
    // note_live_hideout ran first and has already updated the latch, so this is the station that is
    // actually being built. Overwritten every call; the last one before the next ShowContents wins.
    g_open_view_area.store(hideout_viewed_station_area(), std::memory_order_relaxed);
    {
        // Wraps the call. See the note in hk_update_view: an empty zone reads as ~40 ns and looks
        // like a small cost rather than a missing measurement, which is how every zone in this file
        // managed to be useless at once.
        TA_ZONE_N("hideout::ProduceView::Show");
        orig_produce_view_show(self, item_ui_context, inventory, scheme, producer,
            on_start_producing, get_produced_items, available_favorites);
    }
    g_open_view_ticks.fetch_add(qpc_ticks_now() - began, std::memory_order_relaxed);
}

inline void hk_update_view(void* self) {
    // ---- the coalescing the knob was always supposed to do --------------------
    //
    // This is the cost. Measured 2026-10-01 11:24-11:27 on one session at the Workbench:
    //
    //     updateViewCalls=2345   view total=19185.4ms   avg=8.18ms   max=75.6ms
    //     rebuild[n=24 total=12324.6ms avg=513.52ms max=1037.7ms]
    //
    // UpdateViews is only the DISPATCHER - it awaits, then calls UpdateView() on every entry in
    // _views. The existing coalescer collapses the dispatcher, which is why turning it on cut 21
    // dispatches to 15 and left all 2345 inner calls untouched. The knob's own label is "Refresh
    // every station view on each change", so the per-station-view refresh is what it is supposed to
    // control, and this is the call that actually is one.
    //
    // SAME DEBT STRUCTURE AS THE DISPATCHER COALESCER, one level down: a refresh that is dropped
    // here is recorded as owed and repaid by production_panel_probe_tick. A dropped refresh is never
    // a cancelled one - that is the whole reason the existing coalescer pays a trailing pass, and
    // the reason it is easy to leave out. A panel whose rows quietly stopped refreshing would show
    // stale requirement counts, which is a worse defect than a visible stall.

    // ---- HOW OFTEN REFRESHES ARRIVE, WHICH IS WHAT DECIDES THE GATE ---------
    //
    // Measured BEFORE the gate, so it counts every attempt, and split by whether the gap since the
    // previous attempt was inside the coalescing window. That split is the whole question, and it is
    // the one input never logged until now: the 250 ms window is only reachable if consecutive
    // refreshes actually arrive closer than that.
    //
    // It settled a disagreement the counters could not. The 2026-10-01 14:58 run dropped 555
    // refreshes against 185 paid, and the 17:05 run then dropped NONE of 1118 with the same binary -
    // which reads like a contradiction until the arrival times are known. Either refreshes arrive in
    // bursts sometimes and not others, in which case both runs are correct and the gate is
    // situational; or they never arrive that close, and the 555 came from something else entirely.
    // The gap distribution says which, and nothing else in the log can.
    {
        const ULONGLONG now_ms = GetTickCount64();
        const ULONGLONG last_ms = g_update_view_last_ms.load(std::memory_order_relaxed);
        g_update_view_last_ms.store(now_ms, std::memory_order_relaxed);
        if (last_ms != 0) {
            const ULONGLONG gap = now_ms - last_ms;
            g_update_view_gaps.fetch_add(1, std::memory_order_relaxed);
            if (gap < kRebuildCoalesceWindowMs)
                g_update_view_gaps_inside.fetch_add(1, std::memory_order_relaxed);
            g_update_view_gap_total_ms.fetch_add(gap, std::memory_order_relaxed);
            // Min/max by compare-exchange rather than a lock: this is the hot path and the value is
            // diagnostic, so losing a race costs a slightly wrong bound and nothing else.
            ULONGLONG seen_max = g_update_view_gap_max_ms.load(std::memory_order_relaxed);
            while (gap > seen_max
                && !g_update_view_gap_max_ms.compare_exchange_weak(seen_max, gap,
                    std::memory_order_relaxed)) {}
            ULONGLONG seen_min = g_update_view_gap_min_ms.load(std::memory_order_relaxed);
            if (seen_min == 0 || gap < seen_min) {
                while (seen_min != 0 && gap < seen_min
                    && !g_update_view_gap_min_ms.compare_exchange_weak(seen_min, gap,
                        std::memory_order_relaxed)) {}
                if (seen_min == 0)
                    g_update_view_gap_min_ms.compare_exchange_weak(seen_min, gap,
                        std::memory_order_relaxed);
            }
        }
    }

    // ---- WOULD-BE-SUPPRESSED, COUNTED BUT NOT SUPPRESSED ----
    //
    // This used to be a gate that dropped the refresh and recorded a debt. It no longer suppresses
    // anything, and the reason is measured rather than argued - see the header's REMOVED section for
    // the full result. In short: 53 suppressions across two sessions produced 0 avoided payments.
    //
    // The counting is kept, and kept cheap, because the negative result should not be something that
    // has to be remembered. If a future change to the panel's refresh cadence ever creates genuine
    // repeats, wouldRedundant climbing above zero is the signal that a coalescer would have
    // something to collapse, and this is where it would go back in.
    //
    // One relaxed load, one compare, and an increment on the rare branch. The refresh itself is
    // always paid inline, exactly as the game made it.
    if (!open_views().empty() && open_views().size() <= kOpenViewRegistryCap) {
        const ULONGLONG now_ms = GetTickCount64();
        auto& state = open_views()[self];
        // first_run is the case that must never be touched: a view being updated for the very first
        // time is being CONSTRUCTED into its visible state, and deferring that is the stall this
        // module was written to remove. The old dispatcher-clock gate suppressed these, which is why
        // drop[first] used to be non-zero.
        if (!state.rendered)
            g_update_view_would_first.fetch_add(1, std::memory_order_relaxed);
        else if (state.last_refresh_ms != 0
            && (now_ms - state.last_refresh_ms) < kRebuildCoalesceWindowMs)
            g_update_view_would_redundant.fetch_add(1, std::memory_order_relaxed);
        else
            g_update_view_would_stale.fetch_add(1, std::memory_order_relaxed);
    }

    stats().update_view.fetch_add(1, std::memory_order_relaxed);
    // The completion signal. UpdateViews walks _views calling UpdateView on each, so a view that has
    // been here at least once has been constructed and laid out - which is what makes an open
    // comparable with another. See open_view_state.
    //
    // Routed through note_view_rendered rather than written out, because the OTHER path that reaches
    // orig_update_view has to record it too. Inlining the bookkeeping here is what let the 14:58 run
    // report "94 view(s) (83 rendered)" for an open that had rendered all 94.
    note_view_rendered(self);
    // The per-view clock the would-be-suppression counter above reads. Stamped here because this is
    // now the ONLY path that reaches orig_update_view - the trailing per-view loop is gone - so
    // "when did this view last actually refresh" has exactly one answer and this is it.
    open_views()[self].last_refresh_ms = GetTickCount64();
    const ULONGLONG began = qpc_ticks_now();
    // THE ZONE WRAPS THE CALL. It used to be its own empty block immediately above this line, which
    // measured nothing at all - and that is not a subtlety, it is what the 2026-10-01 18:35 capture
    // shows: this zone reported 8990 ns across 223 calls, a mean of 40 ns, while the bracket beside
    // it reported 4.61 ms for the same 223 calls. A 115000x disagreement on the same calls is not a
    // measurement disagreement, it is one of the two numbers being wrong, and the trace was.
    //
    // Worth keeping as a habit: a Tracy zone that wraps no work is not a small cost, it is a missing
    // one. Every zone in this file had that shape, so the capture reported the hideout as a
    // rounding error in a session that was 6% optics and 2% ESP. The fix is one pair of braces and
    // the next capture will actually be worth reading.
    {
        TA_ZONE_N("hideout::ProduceView::UpdateView");
        orig_update_view(self);
    }
    // Timed around the real call, independently of the zone, so this figure means the same thing
    // with or without a profiler attached - TA_ZONE_N compiles to nothing unless TRACY_ENABLE.
    stats().update_view_time.add(qpc_ticks_now() - began);
}

// The row's TemplateId, for labelling the zone.
//
// TemplateId is an AUTO-PROPERTY, not a field. ISIL (EFT/Hideout/ItemRequirement.txt) is explicit:
//
//     Method: System.String get_TemplateId()
//         1 Return this.<TemplateId>k__BackingField (System.String)
//     Method: System.Void set_TemplateId(System.String value)
//         0 Move this.<TemplateId>k__BackingField (System.String), value @ rdx (System.String)
//
// so the storage is a compiler-generated field literally named "<TemplateId>k__BackingField", and
// there is no field named "TemplateId" anywhere on the type or its parents. Asking
// il2cpp_class_get_field_from_name for "TemplateId" therefore cannot succeed, and the first
// version of this file did exactly that: the 2026-09-28 log carries
//
//     hideout: field 'TemplateId' not found on ItemRequirement or any of its parents
//     hideout: field 'TemplateId' not found on ToolRequirement or any of its parents
//
// once per class, and every row went unlabelled for the rest of the session. The failure cached
// itself silently - g_tpl_klass was stored even when the field was null, so the miss was never
// retried and never re-reported. A label that is always empty and a label that is only empty
// because nothing is listening look identical in a capture, which is exactly the confusion this
// comment exists to prevent.
//
// The FieldInfo is resolved ONCE per class and then read by offset. Going through
// hideout_read_field per row would be correct but would call into IL2CPP metadata - a mutex plus
// il2cpp_class_get_field_from_name - from inside a hook running on the game's UI thread, once per
// row, 313 rows per rebuild. That is the engine's own class-initialisation lock being contended by
// injected code on a hot path, and it is a deadlock class of bug that would only show up with the
// profiler attached, i.e. exactly when it is wanted. The field offset does not move, so resolve it
// on the first row and reuse it.
//
// Atomics rather than plain globals: the offset is effectively game-thread-only, but a torn read of
// a FieldInfo* would be a wild dereference rather than a wrong label, and the cost of guarding it
// is one relaxed load per row.
inline std::atomic<const FieldInfo*> g_tpl_field{nullptr};
inline std::atomic<const Il2CppClass*> g_tpl_klass{nullptr};

inline std::string row_template_id(Il2CppObject* req) {
    // Non-const because eft_api::is_il2cpp_object_likely_valid walks obj->klass->name to answer.
    if (!req || !eft_api::is_il2cpp_object_likely_valid(req)) return {};
    const Il2CppClass* klass = req->klass;
    if (!klass) return {};

    if (g_tpl_klass.load(std::memory_order_relaxed) != klass) {
        // First row, or the class genuinely changed. Re-resolve rather than trust a stale offset.
        // The auto-property backing field is the real storage. The plain name is kept as a second
        // candidate purely so that a future build which turns TemplateId into a genuine field
        // keeps working; same defensive shape as EspModule.h:2155.
        const FieldInfo* f = hideout_cached_field(klass, "<TemplateId>k__BackingField");
        if (!f) f = hideout_cached_field(klass, "TemplateId");
        g_tpl_field.store(f, std::memory_order_relaxed);
        g_tpl_klass.store(klass, std::memory_order_relaxed);
        if (!f) {
            // A miss is worth saying out loud, but once: a per-frame warn here would bury the
            // capture it is meant to explain, and an empty label is otherwise indistinguishable
            // from "no profiler attached" in the finished trace.
            static bool warned = false;
            if (!warned) {
                warned = true;
                logger::warn("hideout-panel: no TemplateId storage found on "
                    + std::string(klass->name ? klass->name : "?")
                    + "; per-row zone labels will be empty for this class");
            }
            return {};
        }
    }

    const FieldInfo* field = g_tpl_field.load(std::memory_order_relaxed);
    if (!field) return {};
    // Probed before the deref, like every other read in this codebase.
    const auto* slot = reinterpret_cast<const uint8_t*>(req) + field->offset;
    if (!eft_api::is_readable_address(slot, sizeof(Il2CppString*))) return {};
    Il2CppString* s = *reinterpret_cast<Il2CppString* const*>(slot);
    if (!s) return {};
    return eft_api::try_read_il2cpp_string(s);
}

inline void hk_req_row_show(void* self, void* item_ui_context, void* inventory,
    void* requirement, void* scheme, void* all_items, uint8_t can_start) {
    // Counted, not just timed: at 104 rows per rebuild the CALL COUNT is the number that says
    // whether the cost is per-row or one-off, and a flame graph alone makes that harder to read.
    stats().row_show.fetch_add(1, std::memory_order_relaxed);
    {
        // This zone is OURS ONLY. The 18:35 capture read 3.39 ms across 1603 rows here - the
        // largest hideout zone in the profile - and all of it was row_template_id, which is OUR
        // work; the game's own row construction sat in the SAME zone, so the two could not be
        // told apart. That is what mis-attributed 17.75% and 7.86% of two captures to us: this
        // comment used to assert the game's row construction was outside the zone while
        // orig_req_row_show sat inside it at the bottom of this very block, and the comment was
        // simply wrong. Fixed 2026-10-14 by moving the game call into its own child span, so the
        // outer zone now contains exactly the template-id lookup and nothing else.
        TA_ZONE_N("hideout::HideoutProductionRequirementView::Show");
        if (TA_ZONE_IS_ACTIVE) {
            // The stash walk happens inside the game on `allItems`; naming the row's template is
            // what makes a hot row identifiable in the trace rather than just "row 87 of 104".
            const std::string id = row_template_id(reinterpret_cast<Il2CppObject*>(requirement));
            if (!id.empty()) TA_ZONE_TEXT(id.data(), id.size());
        }
        {
            // The game's half of the call, in its own span. Deliberately a CHILD and not a move:
            // the row cost we care about (ours) stays in the parent, and the game's cost is now
            // separately visible instead of inflating it. Both are per-row, so both want the row
            // count to make sense of them -- which is what row_show above is for.
            // (TA_ZONE_SITE declares ta_zname/ta_zsite, not ta_zone, so it is legal next to the
            // parent zone in the same function -- the property TA_ZONE_N does not have.)
            TA_ZONE_SITE("hideout::HideoutProductionRequirementView::Show", "game");
            orig_req_row_show(self, item_ui_context, inventory, requirement, scheme, all_items, can_start);
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Installation
// ---------------------------------------------------------------------------------------------
//
// The async build's state machine, for <UpdateViews>g__UpdateViewsAsync|25_0().
//
// ISIL (Assembly-CSharp/EFT/Hideout/ProductionPanel.txt) gives the signature:
//
//     Method: System.Threading.Tasks.Task <UpdateViews>g__UpdateViewsAsync|25_0()
//
// and the disassembly is an async kickoff stub - it builds a state machine, calls
// AsyncTaskMethodBuilder.Start on it, then GetTask. So there IS a state machine with a MoveNext,
// and that MoveNext is where the 868 ms per rebuild goes. The method's own body is only the
// handoff, which is why hooking the method measures nothing.
//
// The `|25_0` suffix marks a compiler-generated LOCAL FUNCTION rather than a real method, so the
// state machine is not necessarily a direct child of ProductionPanel: it can sit one level deeper,
// inside a closure class (<>c__DisplayClass25_0) that is itself nested in ProductionPanel.
//
//     ProductionPanel
//       +-- <UpdateViews>g__UpdateViewsAsync|25_0>d__NN          (flat, non-capturing)
//       +-- <>c__DisplayClass25_0                               (capturing)
//             +-- <UpdateViews>g__UpdateViewsAsync|25_0>d__NN
//
// Both shapes are swept because ISIL carries no nested-type table to tell us which one this build
// uses, and guessing is how the first version of this resolver came to find nothing.
// The token that identifies the local function's state machine among the nested types.
//
// NOT the full name. The first attempt matched on "<UpdateViews>g__UpdateViewsAsync|25_0>d__" and
// found nothing on the 2026-09-28 22:21 run, because that spells out a Roslyn naming convention
// this decompiler had never shown us: ISIL gives the METHOD name, not the shape of the state
// machine that compiler emitted for it, and ISIL carries no nested-type table to check against.
// So the whole tail is a guess, and it was wrong.
//
// What is not a guess is the distinctive part. "UpdateViewsAsync" appears in the method name ISIL
// did give us, is unique within this class, and is what the state machine is named after whichever
// suffix convention applies. Matching on that alone finds the class in either emission shape; a
// class that matches but turns out to have no MoveNext simply fails the hook, loudly, rather than
// being silently skipped.
inline const char* const k_update_views_async_token = "UpdateViewsAsync";

// Every nested type name reached during the sweep, for the failure diagnostic. Collected rather
// than logged inline so that a miss reports what was actually there - the alternative, which is
// what the first version did, is to report nothing and leave the next person guessing again.
inline std::string g_async_candidates;

// The class the token actually matched, kept so the SUCCESS path can name it. The 22:26 run
// hooked a class, reported success, and measured 180 ns - so "found something" was never evidence
// that it was the right something. Naming the match is the whole point of this.
inline std::string g_async_matched;

inline void note_async_candidate(const char* depth, const char* name) {
    if (g_async_candidates.size() > 900) return; // bounded: this is a diagnostic, not a dump
    if (!g_async_candidates.empty()) g_async_candidates += ", ";
    g_async_candidates += depth;
    g_async_candidates += name;
}

inline const Il2CppClass* find_async_movenext_class(const Il2CppClass* panel) {
    if (!panel) return nullptr;
    il2cpp::il2cpp_runtime_class_init(const_cast<Il2CppClass*>(panel));

    g_async_candidates.clear();
    g_async_matched.clear();

    // One level: the state machine nested straight in ProductionPanel (non-capturing local
    // function, or an ordinary async method).
    for (uint16_t i = 0; i < panel->nested_type_count; i++) {
        Il2CppClass* nested = panel->nestedTypes[i];
        if (!nested || !nested->name) continue;
        note_async_candidate("", nested->name);
        if (std::string(nested->name).find(k_update_views_async_token) != std::string::npos) {
            g_async_matched = nested->name;
            return nested;
        }
    }

    // Two levels: the state machine inside a closure class. find_state_machine_class() in
    // il2utils walks exactly one level off the class it is handed, so handed ProductionPanel it
    // would never see this shape, return nullptr, and hook_async_method would log "no state
    // machine found" - the same zero-counter symptom as not hooking it at all.
    for (uint16_t i = 0; i < panel->nested_type_count; i++) {
        Il2CppClass* nested = panel->nestedTypes[i];
        if (!nested || !nested->name) continue;
        if (std::string(nested->name).find("DisplayClass") == std::string::npos) continue;

        // A closure class' own nested types are only populated once it is initialised.
        il2cpp::il2cpp_runtime_class_init(nested);
        for (uint16_t j = 0; j < nested->nested_type_count; j++) {
            Il2CppClass* inner = nested->nestedTypes[j];
            if (!inner || !inner->name) continue;
            note_async_candidate((std::string(nested->name) + "/").c_str(), inner->name);
            if (std::string(inner->name).find(k_update_views_async_token) != std::string::npos) {
                g_async_matched = std::string(nested->name) + "/" + inner->name;
                return inner;
            }
        }
    }
    return nullptr;
}


// LATE, AND THE DELAY IS THE POINT.
//
// EFT.Hideout.ProductionPanel and HideoutProductionRequirementView are MonoBehaviours tied to the
// hideout screen. This installs on the first frame where the module has resolved a LIVE hideout
// representation, not on the first frame the type is resolvable — those are very different points,
// and the difference is where the first version of this file went wrong:
//
//   * resolve_class() by name only needs Assembly-CSharp's type table, which is available at
//     startup. Gating on that is not "after the hideout has loaded" despite looking like it.
//   * resolve_method() does not runtime-init the class, so on a not-yet-initialised type it
//     returns null and hook_method logs a failure and returns. Latching "attempted" there made a
//     transient state permanent.
//
// So: hook against the real hideout object, runtime-init before reading methods, and retry until
// every hook has landed. The flag is what keeps that from re-hooking every tick afterwards.
//
// The second constraint: GetSortedSchemes is not reached until the player actually opens that
// station, so "hook installed" and "zone has any samples" are different milestones. The report
// line is how you tell them apart — an install with a zero count means the panel is present but
// that station has not been opened yet.
//
// Idempotent, and safe to call from anywhere on the game thread. `hideout` is the live hideout
// representation HideoutModule already resolved; null simply means "not loaded yet", which is the
// normal state for most of the session.
inline void production_panel_probe_install(Il2CppObject* hideout) {
    static std::atomic<bool> installed{false};
    if (installed.load()) return;

    // The trigger is the live hideout, NOT the presence of the type. That distinction was the
    // second defect in this file, so it is worth stating precisely:
    //
    //   resolve_class() succeeds as soon as Assembly-CSharp's type table is reachable, which is
    //   long before the hideout screen exists. resolve_method() does not call
    //   il2cpp_runtime_class_init (unlike hideout_cached_method), so a class whose method table has
    //   not been built yet yields a null method and a silent "hook_method FAILED". The old code
    //   then latched attempted=true and never retried — a transient not-ready state permanently
    //   disabled the probe.
    //
    // Hence: install late (real hideout), and latch only on complete success.
    if (!hideout) return;

    const Il2CppImage* image = il2utils::resolve_image("Assembly-CSharp.dll");
    if (!image) return;

    const Il2CppClass* panel = il2utils::resolve_class(image, "EFT.Hideout", "ProductionPanel");
    if (!panel) return; // hideout is up but this panel is not in the build; nothing to do
    const Il2CppClass* row = il2utils::resolve_class(image, "EFT.Hideout",
        "HideoutProductionRequirementView");
    // The per-scheme view. Resolved here rather than at file scope so that a build without it
    // degrades to "rows only" instead of taking the whole install down with it.
    const Il2CppClass* produce_view = il2utils::resolve_class(image, "EFT.Hideout", "ProduceView");

    // Populate the method tables before reading them. Mirrors hideout_cached_method.
    if (!panel->methods)
        il2cpp::il2cpp_runtime_class_init(const_cast<Il2CppClass*>(panel));
    if (row && !row->methods)
        il2cpp::il2cpp_runtime_class_init(const_cast<Il2CppClass*>(row));
    if (produce_view && !produce_view->methods)
        il2cpp::il2cpp_runtime_class_init(const_cast<Il2CppClass*>(produce_view));

    // Each hook is tracked independently. A partial install must not be repeated — that would
    // double-hook — but must not be discarded either. install_one() returns early once the
    // trampoline has landed, and false when hook_method could not install, so a null orig_*
    // reliably means "nothing was hooked" and is safe to retry next frame.
    const auto install_one = [](auto& orig, const Il2CppClass* k, const char* name, int args, auto hook) {
        if (orig) return true;
        il2utils::hook_method(k, name, args, hook, &orig);
        return orig != nullptr;
    };

    const bool a = install_one(orig_show_contents, panel, "ShowContents", 0, hk_show_contents);
    const bool b = install_one(orig_get_sorted_schemes, panel, "GetSortedSchemes", 1, hk_get_sorted_schemes);
    const bool c = install_one(orig_update_views, panel, "UpdateViews", 0, hk_update_views);
    const bool d = row ? install_one(orig_req_row_show, row, "Show", 6, hk_req_row_show) : true;
    if (!row)
        logger::warn("hideout-panel: HideoutProductionRequirementView not found; "
            "per-row cost will not be attributed");

    // The synchronous methods. These are the ones the 22:35 capture says to look at: both async
    // bodies measured empty, so the time is in UpdateViews' own frame.
    const bool g = produce_view
        ? install_one(orig_produce_view_show, produce_view, "Show", 7, hk_produce_view_show) : true;
    // UpdateView, not SetInfo/UpdateOrder. The previous revision hooked those two on the theory
    // that they were "named downstream in the handler list" - which was a guess from a comment,
    // and the reference tree shows the rebuild calls neither. This one is read out of the state
    // machine's MoveNext.
    const bool h = produce_view
        ? install_one(orig_update_view, produce_view, "UpdateView", 0, hk_update_view) : true;
    if (!produce_view)
        logger::warn("hideout-panel: EFT.Hideout.ProduceView not found; "
            "per-scheme build cost will not be attributed");

    // The two async bodies. Resolved separately from install_one because the target is a MoveNext
    // on a nested state machine, not a named method on the panel, so there is no (class, name, argc)
    // triple to hand to hook_method.
    //
    // RESOLVED ONCE, NOT RETRIED. The panel class is class-initialised above, so its nestedTypes
    // are already populated: these are deterministic metadata lookups with no transient not-ready
    // state. If they miss, they miss in this build, and retrying would mean a nested-type sweep
    // plus string building on every frame for the rest of the session. g_async_resolve_warned
    // doubles as the "already attempted" flag. The original defect this file was rewritten around
    // - resolve_method() returning null on a not-yet-initialised class - cannot apply here, because
    // the gate above is the live hideout, not the mere presence of the type.
    if (!g_async_resolve_warned) {
        g_async_resolve_warned = true;

        if (!orig_update_views_async_movenext) {
            if (const Il2CppClass* sm = find_async_movenext_class(panel)) {
                il2utils::hook_method(sm, "MoveNext", 0, hk_update_views_async_movenext,
                    &orig_update_views_async_movenext);
            }
        }

        if (!orig_show_produce_view_movenext) {
            il2utils::hook_async_method(panel, "ShowProduceView", 4, hk_show_produce_view_movenext,
                &orig_show_produce_view_movenext);
        }

        // Reported unconditionally, and on success as well as failure. The 22:26 run's failure was
        // not that the resolve missed - it matched something and reported success - but that
        // nothing recorded WHICH, so a hook that installed cleanly and measured 180 ns was
        // indistinguishable from a correct one. Naming the match is the entire point.
        logger::info("hideout-panel: async resolve -> UpdateViewsAsync matched='"
            + (g_async_matched.empty() ? std::string("(none)") : g_async_matched)
            + "' hooked=" + (orig_update_views_async_movenext ? "yes" : "NO")
            + " | ShowProduceView hooked=" + (orig_show_produce_view_movenext ? "yes" : "NO")
            + " | ProductionPanel nested types seen: [" + g_async_candidates + "]");
    }

    // The latch covers the four hooks that are known-reliable, NOT the async ones. A missing async
    // body means the stall stays unattributed; it does not make the row and sort counters wrong,
    // and refusing to latch would re-run the whole install every frame forever. The async state is
    // reported once by the line above.
    if (!(a && b && c && d && g && h))
    {
        // Rate-limited: a hook that can never resolve in this build would otherwise print this
        // once per frame for the rest of the session, which is how a real diagnostic gets buried.
        static int partial_warn_budget = 10;
        if (partial_warn_budget > 0) {
            --partial_warn_budget;
            logger::warn("hideout-panel: partial install; will retry the missing hooks");
        }
        return;
    }
    installed.store(true);
    // Reaching this line implies a && b && c && d && e && f, so there is no "not hooked" variant
    // to print - MSVC folds such a ternary away entirely, which is the right outcome, because a
    // diagnostic that cannot fire is worse than none. Per-hook state is reported by the async
    // resolve line above and by the partial-install warns.
    logger::info("hideout-panel: instrumentation installed on ProductionPanel"
        + std::string(row ? " + HideoutProductionRequirementView" : "")
        + " + UpdateViewsAsync");
}

} // namespace production_panel_probe
