#include "common.h"
#include "QueuedAction.h"

bool QueuedAction::request(const bool allowed, const ULONGLONG cooldown_ms) {
    const ULONGLONG now = GetTickCount64();
    if (!allowed || pending_ || (last_request_ms_ && now - last_request_ms_ < cooldown_ms))
        return false;
    pending_ = true;
    last_request_ms_ = now;
    return true;
}

bool QueuedAction::take(const bool allowed) {
    if (!pending_)
        return false;
    pending_ = false;
    return allowed;
}

[[nodiscard]] bool QueuedAction::pending() const { return pending_; }

void QueuedAction::clear() { pending_ = false; }
