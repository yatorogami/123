#pragma once

// ---------------------------------------------------------------------------
// PROTOTYPE -- NOT A FEATURE. Delete this file and its one call site in
// ChamsModule::gameworld_update to remove it entirely.
// ---------------------------------------------------------------------------
//
// WHAT THIS IS. Step 1 of tools/material_catalogue_route.md: can this process
// enumerate live UnityEngine.Material objects BY NAME, through the managed ABI,
// with no hardcoded RVAs? That question has to be answered in-game, because
// every candidate answer is an assumption until something prints real names.
//
// It runs ONCE per process, at the first in-raid gameworld_update, and writes
// its verdict to the log. It is not on any per-frame path and holds no state
// between calls.
//
// WHY IT EXISTS AS A SEPARATE FILE. Every number it produces is a measurement,
// and a measurement that cannot be re-run on demand decays into an anecdote. The
// call site is two lines and the whole thing is one header.
//
// -----------------------------------------------------------------------------
// THE TRUTH-IN-THE-LOG DESIGN, which is the actual point of this prototype.
//
// This repository has shipped three separate tools that each reported success
// while comparing nothing. So the failure mode this file is built to make
// IMPOSSIBLE is the one where the probe runs, an INFO line appears, and nobody
// can tell whether it checked anything. Therefore:
//
//   * The verdict is a tri-state with the same meaning as audit_config_pointers.py
//     and tools/verify/audit.py -- 0 = clean, 1 = found a problem, 2 = CHECKED
//     NOTHING. 2 is deliberately NOT 0. A probe that could not resolve its type
//     or its method must never be readable as a pass.
//   * Every count is labelled with what it counted, because "materials=1200" and
//     "distinct names=840" are different claims and only one of them is a
//     catalogue.
//   * The elapsed milliseconds are logged because the cost of this call was an
//     open question in the route note, not a detail. The first real run split it
//     no further than one number (1,016 ms for 2,597 rows), so the line now
//     carries PER-PHASE milliseconds -- resolve / enum / census / liveness /
//     names -- and those five RECONCILE with the total, so no part of the cost
//     can hide in an unmeasured residue. They are the candidate causes and one
//     number cannot choose between them: `dead=0` argued the per-hit check was
//     cheap, which left the whole-row sweep and the per-entry managed get_name
//     as the two candidates, and the census call (FindObjectsOfTypeAll over
//     EVERY object) is a third that would otherwise have been invisible. The
//     per-entry GetTickCount64 pairs that make the split are a read of the
//     shared tick page, not a syscall, so the instrument is far below the
//     figure it measures.
//   * `rows` is a MANAGED count and is now labelled as one. `Resources.
//     FindObjectsOfTypeAll` can only see materials that have a managed wrapper;
//     whether native-only materials are missing is UNMEASURED and the line says
//     `native_coverage=unmeasured` so the number cannot be read as a total. The
//     companion `objects_all=` census (the same call for UnityEngine.Object)
//     gives the denominator that makes the ratio readable. A native type-manager
//     walk is the only thing that answers it outright, and that needs a NAMED
//     oracle for the UnityPlayer globals first -- which is the optics
//     instance-table handoff's deliverable, not a guess this file is allowed to
//     make (see tools/handoff_optics_instance_table_rva.md, "Do not").
//   * The needle counts are reported as CORROBORATION ONLY, never as a gate. A
//     zero on "emissive" is not a failure; the probe does not know the game's
//     material vocabulary and guessing at it would be the exact error the
//     unknowncheats.me dumper made by hardcoding five favourite names.
//
// -----------------------------------------------------------------------------
// TWO THINGS THE DUMP SETTLED, recorded so nobody re-derives them wrong:
//
//   1. UnityEngine declares FindObjectsOfTypeAll(Type) on TWO classes:
//        Resources     (TypeDefIndex 23198)  <- public sealed, the real one
//        ResourcesAPI  (TypeDefIndex 23197)  <- identical static signature
//      Resolving the wrong one yields a valid MethodInfo for a class the game
//      never calls, and the probe returns an empty array that looks like a
//      legitimate "no materials loaded". It is in Resources.
//   2. Arity is exactly 1, verified against
//      TarkovAddons/GameDump/1.2.0.0.47965/dump.cs:1159760
//          public static Object[] FindObjectsOfTypeAll(Type type) { }
//      hence allow_any_argc=false. "Exact arity or nothing" is the house rule
//      (ChamsModule.cpp:322-325) because the wrong-overload mistake has already
//      reached a shipped DLL once.
//
// Both verified by reading the dump on 2026-10-13. Neither is inferred.

#include <algorithm>
#include <cstdint>
#include <string>
#include <unordered_set>
#include <vector>

#include "../il2cpp/il2utils.h"
#include "../il2cpp/libil2cpp/il2cpp-api-types.h"
#include "../il2cpp/unity.h"
#include "../util/logger.h"

namespace material_catalogue {

// Same convention as audit_config_pointers.py / tools/verify/audit.py.
inline constexpr int kCheckedNothing = 2; // could not determine anything
inline constexpr int kFailed = 1;         // ran, and the answer is "no"
inline constexpr int kOk = 0;             // resolved, and returned rows

struct result {
    int verdict = kCheckedNothing;
    std::uint32_t rows = 0;           // entries in the returned array
    std::uint32_t alive = 0;          // passed the native-liveness check
    std::uint32_t dead = 0;           // managed wrapper, native object gone
    std::uint32_t unnamed = 0;        // alive but get_name() came back empty
    std::uint32_t distinct = 0;       // DISTINCT names among the alive set
    std::uint32_t cap_skipped = 0;    // alive, named, but past the log cap
    std::uint32_t objects_all = 0;    // UnityEngine.Object census (denominator)
    bool objects_all_ok = false;      // the census call itself resolved
    unsigned long long elapsed_ms = 0;
    // The one elapsed number, split. Which of the four is the 1,016 ms decides
    // whether the 2 s/15 s clock is survivable, and the original line could not
    // answer it: `dead=0` argued the per-hit check was cheap, which left the
    // sweep itself and the per-entry managed get_name as the two candidates.
    unsigned long long resolve_ms = 0;    // type + method resolution
    unsigned long long enumerate_ms = 0;  // FindObjectsOfTypeAll itself
    unsigned long long census_ms = 0;     // the UnityEngine.Object denominator call
    unsigned long long liveness_ms = 0;   // is_unity_object_alive across all rows
    unsigned long long names_ms = 0;      // get_name across the alive rows
};

// Named so the log line cannot be read as "it worked" when it did not.
inline const char* verdict_word(const int verdict) {
    switch (verdict) {
    case kOk:
        return "OK";
    case kFailed:
        return "FAILED";
    default:
        return "INDETERMINATE";
    }
}

// Candidate substrings, reported as counts only. Sourced from the unverified
// third-party dumper's favourites; they are here so a human can eyeball
// whether the names look like EFT materials at all. NOT a pass/fail gate.
inline constexpr const char* kNeedles[] = {"emissive", "chameleon", "manpad", "Hidden/", "Glow_Red"};

inline constexpr std::size_t kNeedleCount = sizeof(kNeedles) / sizeof(kNeedles[0]);

inline constexpr std::size_t kMaxLoggedNames = 40;

// Upper bound, not a target. A Material catalogue in a loaded raid is expected
// to be large; this only exists so a wrong `rows` cannot print a million names.
inline constexpr std::uint32_t kMaxPlausibleRows = 500000;

// UnityEngine.Material -> System.Type. Same call shape ChamsModule already uses
// for Shader (:235) and Renderer (:1272).
inline Il2CppObject* material_type_object(const Il2CppImage* image) {
    return il2utils::get_system_type(image, "UnityEngine", "Material");
}

// UnityEngine.Object -> System.Type, for the census. Same resolution path, one
// level up the hierarchy -- every Material IS an Object, so this count is the
// denominator that tells the reader how much of the loaded managed world the
// Material count represents.
inline Il2CppObject* object_type_object(const Il2CppImage* image) {
    return il2utils::get_system_type(image, "UnityEngine", "Object");
}

// Resolve the static once. Deliberately NOT function-local statics at namespace
// scope: get_method already memoises successes on (class, name, arg_count) --
// measured 2026-10-09 at 22,114,149 calls / 4.916 s, all hits -- so re-resolving
// is a hash lookup, and a statics-here cache would be a second cache to reason
// about for no measurable gain.
inline Il2CppArray* find_all(const Il2CppImage* image, Il2CppObject* type) {
    if (!image || !type) return nullptr;

    const Il2CppClass* resources = il2utils::resolve_class(image, "UnityEngine", "Resources");
    if (!resources) return nullptr; // resolve_class has already logged why

    // STATIC method: the C signature has no `this`. The trailing MethodInfo* is
    // the IL2CPP convention (AGENTS.md, "one hidden trailing Il2CppMethodInfo*")
    // and `mi_out` exists on get_method for exactly this. Most call sites in this
    // codebase omit it (unity::get_name, get_sharedMaterials); passing it is
    // strictly safer on x64-64 either way -- a callee that ignores it drops a
    // trailing register/stack slot, and a callee that reads it gets a valid
    // pointer instead of whatever was in that slot.
    using find_all_sig = Il2CppArray* (*)(Il2CppObject*, const MethodInfo*);
    const MethodInfo* mi = nullptr;
    const auto fn = il2utils::get_method<find_all_sig>(
        resources, "FindObjectsOfTypeAll", 1, /*log_fail=*/true, /*allow_any_argc=*/false, &mi);
    if (!fn) return nullptr; // get_method has already logged why

    return fn(type, mi);
}

// The call, with every count that distinguishes "it ran" from "it worked".
inline result probe(const Il2CppImage* image) {
    result r;
    const unsigned long long t0 = GetTickCount64();

    // Phase split, and the phases RECONCILE with elapsed_ms -- the five spans
    // sum to the total, so a reader can see there is no unexplained residue in
    // the 1,016 ms. "Resolve + enumerate" was originally one span because
    // neither was a candidate for the cost; the census changed that, because
    // FindObjectsOfTypeAll over EVERY object is potentially the most expensive
    // call in the file and must not hide inside another phase.
    Il2CppObject* type = material_type_object(image);
    if (!type) {
        r.verdict = kCheckedNothing;
        r.resolve_ms = GetTickCount64() - t0;
        r.elapsed_ms = r.resolve_ms;
        logger::error("material-catalog: INDETERMINATE -- UnityEngine.Material did not "
                      "resolve to a System.Type (image null: " + std::to_string(image == nullptr) + ")");
        return r;
    }
    const unsigned long long t1 = GetTickCount64();
    r.resolve_ms = t1 - t0;

    Il2CppArray* all = find_all(image, type);
    const unsigned long long t2 = GetTickCount64();
    r.enumerate_ms = t2 - t1;
    if (!all) {
        r.verdict = kCheckedNothing;
        r.elapsed_ms = t2 - t0;
        logger::error("material-catalog: INDETERMINATE -- FindObjectsOfTypeAll(Type) "
                      "resolved but returned null");
        return r;
    }

    r.rows = static_cast<std::uint32_t>(all->max_length);
    if (r.rows == 0 || r.rows > kMaxPlausibleRows) {
        r.verdict = kFailed;
        r.elapsed_ms = GetTickCount64() - t0;
        logger::error("material-catalog: FAILED -- row count outside the plausible range: rows="
                      + std::to_string(r.rows) + " (bound " + std::to_string(kMaxPlausibleRows)
                      + "). A zero here is the shape a wrong CLASS looks like, so it is a failure "
                        "and not an empty catalogue.");
        return r;
    }

    // The denominator census. Deliberately AFTER the primary enumeration and
    // its counts: it is context, and a failure here must not disturb the
    // verdict. A census that could not resolve reports 0 with objects_all_ok
    // false, and the line prints `unknown` rather than a zero that reads as a
    // measurement of nothing.
    const unsigned long long c0 = GetTickCount64();
    if (Il2CppObject* obj_type = object_type_object(image)) {
        if (Il2CppArray* objs = find_all(image, obj_type)) {
            r.objects_all = static_cast<std::uint32_t>(objs->max_length);
            r.objects_all_ok = true;
        }
    }
    r.census_ms = GetTickCount64() - c0;

    std::unordered_set<std::string> distinct;
    distinct.reserve(r.rows);
    std::vector<std::string> logged;
    logged.reserve(kMaxLoggedNames);
    std::uint32_t needle_hits[kNeedleCount] = {};

    for (std::uint32_t i = 0; i < r.rows; ++i) {
        Il2CppObject* m = reinterpret_cast<Il2CppObject**>(&all->data)[i];
        if (!m) continue;

        // A managed wrapper outlives its native object across a transit
        // (unity.h:1151-1160), and a catalogue is built exactly when the scene
        // churns most. This is one VirtualQuery per DISTINCT pointer, memoised,
        // which is why elapsed_ms is logged rather than assumed.
        const unsigned long long l0 = GetTickCount64();
        const bool alive = unity::is_unity_object_alive(m, "chams/catalogue");
        r.liveness_ms += GetTickCount64() - l0;
        if (!alive) {
            ++r.dead;
            continue;
        }
        ++r.alive;

        // unity::get_name is bound once against UnityEngine.Object (unity.h:743-745),
        // so it is Object.get_name reached through a Material -- inherited and
        // non-virtual, so the same implementation. Not re-resolved per entry.
        const unsigned long long n0 = GetTickCount64();
        std::string name = unity::get_name(m);
        r.names_ms += GetTickCount64() - n0;
        if (name.empty()) {
            ++r.unnamed;
            continue;
        }

        if (distinct.insert(name).second) {
            // first sighting wins; the sorted sample below is what a human reads
            if (logged.size() < kMaxLoggedNames)
                logged.push_back(name);
            else
                ++r.cap_skipped;
        }

        for (std::size_t n = 0; n < kNeedleCount; ++n) {
            if (name.find(kNeedles[n]) != std::string::npos) {
                ++needle_hits[n];
                break;
            }
        }
    }

    r.distinct = static_cast<std::uint32_t>(distinct.size());
    r.elapsed_ms = GetTickCount64() - t0;

    // An empty ALIVE set is the one "ran and learned nothing" case that survives
    // the row-count gate above, so it is separated from a real answer.
    r.verdict = (r.distinct == 0) ? kFailed : kOk;

    std::sort(logged.begin(), logged.end());
    std::string sample;
    for (std::size_t i = 0; i < logged.size(); ++i) {
        if (i) sample += ", ";
        sample += logged[i];
    }

    std::string needles;
    for (std::size_t n = 0; n < kNeedleCount; ++n) {
        if (n) needles += " ";
        needles += std::string(kNeedles[n]) + "=" + std::to_string(needle_hits[n]);
    }

    // Every number named, and the verdict first, so a reader who greps one line
    // cannot mistake "ran" for "worked".
    logger::info("material-catalog: " + std::string(verdict_word(r.verdict))
                 + " rows=" + std::to_string(r.rows) + " alive=" + std::to_string(r.alive)
                 + " dead=" + std::to_string(r.dead) + " unnamed=" + std::to_string(r.unnamed)
                 + " distinct_names=" + std::to_string(r.distinct)
                 + " sampled=" + std::to_string(logged.size())
                 + " cap_skipped=" + std::to_string(r.cap_skipped) + " elapsed_ms="
                 + std::to_string(r.elapsed_ms) + " phase_ms[resolve=" + std::to_string(r.resolve_ms)
                 + " enum=" + std::to_string(r.enumerate_ms) + " census="
                 + std::to_string(r.census_ms) + " liveness="
                 + std::to_string(r.liveness_ms) + " names=" + std::to_string(r.names_ms) + "]"
                 + " objects_all=" + (r.objects_all_ok ? std::to_string(r.objects_all) : std::string("unknown"))
                 + " native_coverage=unmeasured needles[" + needles + "]");
    logger::info("material-catalog: first " + std::to_string(logged.size())
                 + " distinct names, sorted: " + (sample.empty() ? std::string("(none)") : sample));

    if (r.verdict != kOk) {
        logger::error("material-catalog: the route resolved and returned " + std::to_string(r.rows)
                      + " rows but produced no usable names. Treat the managed route as UNPROVEN; "
                        "do not read this as an empty catalogue.");
    }

    return r;
}

// The once-per-process guard lives HERE so the call site is two lines and the
// prototype is removable by deleting this file plus that call.
//
// Not a member of ChamsModule, and not a function-local static in
// gameworld_update: the chams header deliberately lifted its scan cursor out of
// a function-local static precisely because six clear sites could not reach it
// (ChamsModule.h:190-204). Nothing here needs clearing -- "once per process" is
// the entire intent -- so the guard is a static local of the function that owns
// the policy.
inline int probe_once(const Il2CppImage* image) {
    static bool done = false;
    static result last{};
    if (done) return last.verdict;
    done = true;
    last = probe(image);
    return last.verdict;
}

} // namespace material_catalogue
