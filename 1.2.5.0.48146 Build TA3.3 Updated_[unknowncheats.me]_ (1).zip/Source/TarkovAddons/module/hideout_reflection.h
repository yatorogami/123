#pragma once

// Shared IL2CPP reflection helpers for the hideout modules (HideoutModule's manual
// controls and HideoutAutomationModule's unattended automation).
//
// Kept in its own header so both modules use ONE copy of the metadata memo rather
// than each carrying their own — a second memo would double every lookup's cost and
// let the two disagree about what resolved.
//
// THERE ARE TWO REFERENCE TREES AND THEY ANSWER DIFFERENT QUESTIONS. Getting this wrong is
// expensive, so the division is recorded here rather than rediscovered per shape:
//
//   ISIL-references/IsilDump        - a METHOD-BODY dump. Proves method names, signatures,
//                                    and what a getter actually does (auto-property vs computed,
//                                    plain field vs backing field, lazy init or not). Has NO
//                                    enums and no field list, because a type with no methods
//                                    produces no entry.
//
//   GameDump/<build>/DiffableCs     - decompiled C#. Authoritative for the things IsilDump
//                                    cannot show: ENUM members, plain field names, class
//                                    hierarchy. GameDump holds one folder per game build
//                                    (110146911, 115047242, 115047426, 115047473, 115147510);
//                                    the active one is 115147510, matching compatibility
//                                    profile 1.1.5.1.47510.
//
// Concretely, this cost a wrong turn: AreaData._status is a plain field of type EAreaStatus,
// and the eleven EAreaStatus members could not be recovered from IsilDump at all - it has no
// such file - while they sit in one readable line at
// GameDump/115147510/DiffableCs/Assembly-CSharp/EFT/Hideout/EAreaStatus.cs. Rule of thumb: go
// to IsilDump to learn what a getter DOES, go to DiffableCs to learn what members EXIST.
//
// Signatures and field names here are taken from the ISIL reference tree
// (TarkovAddons/ISIL-references/IsilDump, build 1.1.5.1.47510). ISIL is a
// method-body dump, so it proves the METHOD names and signatures below; the
// plain fields it cannot list (Profile.Hideout, HideoutInfo.Areas,
// HideoutInfo.Production) are the ones confirmed live by HideoutModule's own
// diagnostics. Anything inferred rather than evidenced is commented as such.

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <map>
#include <string>
#include <unordered_map>
#include <unordered_set>

#include "eft_api.h" // same directory; "../eft_api.h" does not exist and broke the build
#include "game_item_db.h" // for game_items::dimensions, which resolve_template_stack reads
#include "../util/logger.h" // for the knob-change log lines in the setters below
#include "../il2cpp/exports.h"
#include "../il2cpp/unity.h"

// ---------------------------------------------------------------------------
// Metadata memo
// ---------------------------------------------------------------------------
//
// IL2CPP class layout and managed method pointers are fixed for the life of the
// process, so every lookup is resolved once per (class, name) and reused. The
// area and production walks resolve several members PER ELEMENT, so the
// un-memoised form cost 4*N + 7*M name walks on every refresh. Running that
// unthrottled is what caused an AppHang during raid extraction.
//
// Misses are cached too. Every candidate here probes a shape that moves between
// game versions, and re-walking a known-absent member costs exactly as much as
// re-walking a present one. Nothing is logged here, so each call site keeps full
// control of its own single diagnostic line.
//
// These use their own maps rather than eft_api::cached_field's direct-mapped
// table: that one is process-wide and already carries the per-item loot lookups, so
// it fills mid-raid and permanently degrades those lookups to uncached resolves
// (logged once). Correct, but the hideout probes run often enough that they are
// better off owning a map that cannot saturate.
//
// ---------------------------------------------------------------------------
// Class sanity
// ---------------------------------------------------------------------------
//
// Is this address mapped and readable AT ALL? Deliberately a single-page check with NO span
// arithmetic.
//
// The obvious shape -- "is [ptr, ptr+size) inside one committed region" -- is wrong, and an
// earlier revision of this file used it. A buffer whose LAST element crosses a page boundary
// fails it, and an IL2CPP metadata table very often does, because tables are packed back to
// back at the end of their pages. That is not hypothetical: the same check in il2utils
// reported UnityEngine.Object, Transform and Camera as "unlinked" and stopped the project
// from starting (2026-09-27 19:46). Asking only "is this one address readable" has no false
// positives, because it never spans a boundary.
inline bool hideout_address_readable(const void* ptr) {
    // MEMOISED, and this is the single largest win in the hideout pass.
    //
    // It used to call VirtualQuery directly, which made it the most expensive thing in the
    // module AND invisible to its own instrumentation: eft_api::drain_probe_stats() counts
    // probe_readable(), so every call here was uncounted. That is why the 2026-10-03 log
    // reported "walk 9.7ms (areas 3.0/30p, prod 3.5/35p)" - 65 probes, ~1 s of duty - while
    // the pass it was describing actually took 104 ms at p50, 89 passes out of 89 over a
    // 33.3 ms frame. 91% of that pass was this function, uncounted.
    //
    // WHY IT DOMINATES. hideout_class_usable (below) calls this three times, and it is called
    // per by_area entry (10x a pass in the live sweep), per producer, and from
    // hideout_iterate_collection / hideout_class_label on the same handful of class pointers
    // over and over. Every one of those pointers is an Il2CppClass or a class `name` string.
    //
    // WHY MEMOISING IT IS SOUND, which is the part that matters. It is not GC heap data: it is
    // il2cpp METADATA, which is mapped once when GameAssembly loads and stays committed for
    // the life of the process. So a region answer for a metadata pointer cannot go stale the
    // way a GC-heap answer can - there is no free-list reuse to confuse it, and the region is
    // never unmapped except at process exit. This is a STRICTLY weaker assumption than the one
    // is_readable_address_cached already carries for the GC heap ("objects are freed to free
    // lists rather than unmapped"), so it inherits that function's soundness rather than
    // needing a new argument. clear_probe_region_memo() on the transit boundary bounds the
    // table regardless.
    //
    // The one-byte size is what preserves the property this function was written for: no span
    // arithmetic, so a buffer whose last element crosses a page boundary cannot false-negative.
    // See the note above about metadata tables packed at the end of their pages.
    //
    // NOT thread_local, unlike the per-walk memo below, and deliberately not: the region table
    // is a single shared array and the hideout pass benefits from it being warm from whatever ran
    // earlier on the thread. It is a plain non-atomic table, so this is a data race in the
    // strict sense - but it is one the project already runs everywhere, because
    // is_readable_address_cached is reached from try_read_il2cpp_string and
    // is_il2cpp_object_strict, and the 2026-10-03 log shows those running on tid=22016 and
    // tid=7464 while the hideout pass ran on tid=17684. Worst case here is a redundant
    // re-probe, or a stale region answer for a metadata pointer, and metadata is mapped for the
    // life of the process. Making the table thread_local to remove the race would also remove
    // the sharing, which is most of the win.
    return eft_api::is_readable_address_cached(ptr, 1);
}

// A class pointer we did not construct can be garbage while still being non-null, and
// il2cpp_class_get_method_from_name / _get_field_from_name both dereference it immediately.
// The metadata TABLE contents are deliberately not checked (see above); this only rejects
// the case where the pointer itself is not a class.
inline bool hideout_class_usable(const Il2CppClass* klass) {
    if (!hideout_address_readable(klass)) return false;
    // Il2CppClass::klass is documented "hack to pretend we are a MonoVTable. Points to
    // ourself" (il2cpp-class-internals.h:377), so a real class always satisfies klass->klass
    // == klass, and a pointer read out of unrelated memory essentially never does.
    if (!hideout_address_readable(klass->klass) || klass->klass != klass) return false;
    return klass->name && hideout_address_readable(klass->name);
}

// RETURNS std::string, AND THAT IS NOT COSMETIC. This used to return const char*, which was
// only safe while the label WAS the runtime's own stable klass->name pointer. Adding the namespace
// prefix meant building it as a temporary std::string, and `return (std::string(ns) + "+" +
// klass->name).c_str();` returns a pointer into a string destroyed at the end of the statement.
// The 2026-10-03 19:54 log caught it: a lookup that should have printed
// `EFT.HideoutInfo` printed `?K??`, which is freed memory. A diagnostic that reports garbage
// exactly when it is reporting a failure is worse than no diagnostic, and this one was only
// reachable through the trace/warn paths - which is why it survived a build and a commit.
//
// So the type is changed rather than the bug papered over with a static or thread_local buffer:
// a self-returning std::string cannot dangle, and it costs one small allocation on a path that
// already builds a log string. Callers that bound it to const char* now hold a std::string.
inline std::string hideout_class_label(const Il2CppClass* klass) {
    if (!hideout_class_usable(klass)) return "<not-a-class>";
    // The NESTING MARKER IS NOT COSMETIC. Il2CppClass::name is UNQUALIFIED, so a nested type
    // prints the same string as a top-level one with the same short name - and EFT has a pair:
    //
    //     EFT.Hideout.HideoutController                  (the scene MonoBehaviour, owns _areas)
    //     EFT.TarkovApplication+HideoutController       (the loader; has NO _areas, no get_Areas)
    //
    // get_HideoutControllerAccess() returns the SECOND. Because both report name ==
    // "HideoutController", every failure line read `field '_areas' not found on HideoutController`
    // and looked like a broken field resolver on a class whose members plainly exist. It was not:
    // the lookup was pointed at the wrong type entirely, and no amount of renaming would have
    // fixed it. Two rounds of "the resolver cannot see private fields" were wrong for that reason.
    //
    // The '+' on the namespace is what makes the two distinguishable at all, so it is included.
    // If the namespace is missing (some synthetic classes), fall back to the bare name rather
    // than printing an empty prefix that reads like a bug.
    const char* ns = klass->namespaze;
    if (!ns || !*ns) return klass->name ? klass->name : "<null name>";
    return std::string(ns) + "+" + (klass->name ? klass->name : "<null name>");
}

// Reported once per (class, member): these run per element on the area and production walks, so
// an unconditional warn would be a wall of text a second.
inline void hideout_warn_unusable(const Il2CppClass* klass, const char* what, const char* name) {
    static std::unordered_map<std::string, bool> reported;
    const std::string key = std::to_string(reinterpret_cast<uintptr_t>(klass)) + '.'
        + std::string(what) + '.' + (name ? name : "?");
    if (reported.emplace(key, true).second)
        logger::warn(std::string("hideout: ") + what + " '" + (name ? name : "?")
            + "' skipped; the class pointer 0x" + std::to_string(reinterpret_cast<uintptr_t>(klass))
            + " is not a usable class");
}

// Debug-only tracing for the post-areas window, where three crashes in a row landed with only
// "areas loaded" in the log. Gated on the same toggle as the module's other traces, so it is
// free when the Debug Log card is off.
inline void hideout_trace(const std::string& message) {
    if (logger::debug_enabled()) logger::debug("hideout: " + message);
}

// `quiet` suppresses the not-found trace without changing the cache, so a speculative probe costs
// nothing extra and a real miss stays a real miss. hideout_poll_task uses it for get_Succeed: it
// probes the task's result precisely to find out whether that result is an IResult, so a miss is
// the EXPECTED answer for every collection-valued task. Tracing it made a working code path look
// like a fault, at one line per recipe poll.
inline const MethodInfo* hideout_cached_method(const Il2CppClass* klass, const char* name,
    const int args, const bool quiet = false) {
    if (!klass || !name) return nullptr;
    static std::unordered_map<std::string, const MethodInfo*> cache;
    const std::string key = std::to_string(reinterpret_cast<uintptr_t>(klass)) + '.'
        + name + '/' + std::to_string(args);
    if (const auto it = cache.find(key); it != cache.end()) return it->second;
    // Guarded on the cache-MISS path only, so the common cache hit costs one string build.
    if (!hideout_class_usable(klass))
    {
        hideout_warn_unusable(klass, "method", name);
        cache.emplace(key, nullptr);
        return nullptr;
    }
    // Walk the inheritance chain explicitly rather than trusting the runtime to.
    //
    // il2cpp_class_get_method_from_name searches ONE class's own `methods` array, and the
    // unwrapped body pinned in exports.h:29-38 shows only a flag-masked walk over that array --
    // no parent traversal. That matters here: IsCompleted, IsFaulted and Result are declared on
    // System.Threading.Tasks.Task, and the object being reflected is the closed generic
    // Task<ProductionSchemesCollection>, which INHERITS all three. A leaf-only lookup misses
    // every one of them, hideout_poll_task then reports `pending` on every refresh, and the
    // recipe dropdown can never fill.
    //
    // Doing it here is correct either way: if the runtime does walk parents, the leaf matches
    // first and nothing changes; if it does not, this is the fix. il2utils::resolve_field walks
    // parents for exactly the same reason.
    //
    // The parent walk also forces each class's method table to be set up first. Il2CppClass.methods
    // is documented in the runtime as "Initialized in SetupMethods", which is driven by class
    // initialisation — so a class the runtime has not initialised yet has a null/empty `methods`
    // array and EVERY lookup on it misses. That is not hypothetical: the 2026-09-27 log shows
    // `GetEnumerator/0 not found on <>OfTypeIterator>d__97`1`, and that method certainly exists —
    // it is the public entry point of a System.Linq iterator. Class initialisation is the
    // documented way to force SetupMethods, and it is safe on a class that is already live.
    const MethodInfo* method = nullptr;
    for (const Il2CppClass* current = klass; current && !method; current = current->parent)
    {
        if (!hideout_class_usable(current)) continue;
        if (!current->methods) il2cpp::il2cpp_runtime_class_init(const_cast<Il2CppClass*>(current));
        method = il2utils::resolve_method(current, name, args);
    }
    if (!method && !quiet)
        hideout_trace("method '" + std::string(name) + "/"
            + std::to_string(args) + "' not found on " + hideout_class_label(klass)
            + " or any of its parents");
    cache.emplace(key, method);
    return method;
}

inline const FieldInfo* hideout_cached_field(const Il2CppClass* klass, const char* name) {
    if (!klass || !name) return nullptr;
    static std::unordered_map<std::string, const FieldInfo*> cache;
    const std::string key = std::to_string(reinterpret_cast<uintptr_t>(klass)) + '.' + name;
    if (const auto it = cache.find(key); it != cache.end()) return it->second;
    if (!hideout_class_usable(klass))
    {
        hideout_warn_unusable(klass, "field", name);
        cache.emplace(key, nullptr);
        return nullptr;
    }
    const FieldInfo* field = il2utils::resolve_field(klass, name);
    if (!field)
        hideout_trace("field '" + std::string(name) + "' not found on "
            + hideout_class_label(klass) + " or any of its parents");
    cache.emplace(key, field);
    return field;
}

// End of the committed, non-guarded region containing `p`, or 0 when there is none.
//
// This is the single VirtualQuery behind the per-walk memo below. Kept separate from
// eft_api::is_readable_address because that answers a yes/no for a given size, and what the
// field reader actually needs is the region's END so the remaining checks can be arithmetic.
inline uintptr_t hideout_region_end(const void* p) {
    if (!p) return 0;
    // Counted through the same probe_scoped as eft_api::is_readable_address, even though the
    // memo means this path is taken far less often. A memo does not make the kernel call free,
    // and the summary line is only useful while it reports the real number of queries - see the
    // note on probe_scoped about what the first post-memo run reported instead.
    eft_api::probe_scoped probe;
    probe.start();
    MEMORY_BASIC_INFORMATION mbi{};
    const bool ok = VirtualQuery(p, &mbi, sizeof(mbi));
    probe.stop();
    if (!ok) return 0;
    if (mbi.State != MEM_COMMIT) return 0;
    if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) return 0;
    return reinterpret_cast<uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;
}

inline bool hideout_fits_in(const uintptr_t region_end, const void* p, const size_t size) {
    return region_end != 0 && reinterpret_cast<uintptr_t>(p) + size <= region_end;
}

// Per-walk memo of region ends, keyed by the pointer that was probed.
//
// WHY THIS EXISTS, IN NUMBERS. The 1 Hz hideout walk was measured at ~138 ms, and the probe
// time inside it was ~137 ms of that: 408 VirtualQuery calls for the 27 areas and 278 for the
// 8 productions, at ~207 us and ~186 us each. That is the whole stall, and a VirtualQuery is
// supposed to cost well under a microsecond, so something in this process makes each one
// extraordinary expensive. The fix is not to make the call cheaper - it is to stop making it:
// 408 is exactly 27 areas x 5 fields x 3 probes, and 278 is the same shape on the production
// side, i.e. the SAME three questions (is the object mapped, is its class mapped, is the field
// slot mapped) were being re-asked through the kernel once per FIELD instead of once per
// element.
//
// NOTHING IS BEING TRUSTED THAT WAS NOT ALREADY CHECKED. All three old checks computed
// "is this address inside a committed non-guarded region, and do `size` bytes fit before the
// end". Once the region's end is known, each of those is a subtraction against it. So the
// answers are the same ones the syscalls gave; the syscall is simply not repeated for an
// answer already in hand.
//
// LIFETIME IS THE PART THAT MATTERS. Cleared at the start of every walk and never carried
// across one, because a cached region end goes stale the instant the object behind it is
// freed, and holding one past that point would trade a syscall for a window in which a
// mid-walk free reads as valid. Within a single walk that window is closed by the collection
// itself: the 27 AreaInfos are elements of ONE array and the productions are values of ONE
// dictionary, so holding the collection across the walk holds every element across it too.
// The case the 2026-09-27 capture caught - an element freed mid-walk - is a different
// collection on a different walk, and that walk starts with an empty memo.
struct hideout_probe_memo {
    std::vector<std::pair<const void*, uintptr_t>> seen;

    // Bounded so a caller that walks something enormous cannot turn the lookup into a long
    // linear scan. Past the cap the query is simply made again: slower, never wrong.
    static constexpr size_t kCap = 1024;

    void clear() { seen.clear(); }

    uintptr_t end_for(const void* p) {
        for (const auto& e : seen) {
            if (e.first == p) return e.second;
        }
        const uintptr_t end = hideout_region_end(p);
        if (seen.size() < kCap) seen.emplace_back(p, end);
        return end;
    }
};

// thread_local, so two threads walking concurrently cannot share (and clear) each other's memo.
// The hideout refresh is single-threaded today; this is so that stays true for free.
inline hideout_probe_memo& hideout_probe_cache() {
    thread_local hideout_probe_memo memo;
    return memo;
}

// Read an auto-property: the compiler-generated backing field first, the plain name second.
//
// Separate from hideout_read_field because a GETTER IS NOT A FIELD, and guessing wrong costs a
// silent zero rather than an error. ISIL states the storage plainly - get_Hideout() on
// ItemsProducerBase is `1 Return this.<Hideout>k__BackingField (EFT.Hideout.HideoutRepresentation)`
// and get_TemplateId() is the same shape - and this project has already been bitten twice: once
// reading a bare `TemplateId` and getting an unlabelled row, and once reading a bare `Hideout`.
//
// `found` separates "the member does not exist" from "it exists and is null". A fallback-only
// signature cannot: a null pointer and an absent field return the same thing, and here the
// difference is the whole question - a null Hideout means the producer has not been initialised
// yet, which is a not-ready state to retry, while no field at all means the name is wrong, which
// is a bug to fix.
template <typename T>
inline T hideout_read_property(Il2CppObject* object, const char* property, bool* found = nullptr) {
    if (found) *found = false;
    if (!object || !property) return T{};
    const Il2CppClass* klass = object->klass;
    if (!klass) return T{};

    const std::string backing = std::string("<") + property + ">k__BackingField";
    const FieldInfo* field = hideout_cached_field(klass, backing.c_str());
    if (!field) field = hideout_cached_field(klass, property);
    if (!field) return T{};

    hideout_probe_memo& memo = hideout_probe_cache();
    const uintptr_t object_end = memo.end_for(object);
    if (!hideout_fits_in(object_end, object, sizeof(Il2CppObject))) return T{};
    const auto* slot = reinterpret_cast<const uint8_t*>(object) + field->offset;
    if (!hideout_fits_in(object_end, slot, sizeof(T))) return T{};

    if (found) *found = true;
    return *reinterpret_cast<const T*>(slot);
}

// ---------------------------------------------------------------------------
// UPGRADE REQUIREMENTS - the permanent list, 2026-10-02
// ---------------------------------------------------------------------------
//
// Reached from a producer, and the chain is short because the live sweep already holds one:
//
//     ItemsProducerBase.get_Hideout()   -> HideoutRepresentation   (ISIL L4236)
//     HideoutRepresentation.get_AreaDatas()  -> List<AreaData>
//     AreaData._currentLevel            (+0xA8, ISIL: get_CurrentStage reads it)
//     AreaData.StageAt(level + 1)       -> Stage                   (ISIL get_NextStage)
//     Stage.Requirements                -> RelatedRequirements      (public field)
//     RelatedRequirements.Data          -> List<Requirement>
//     ItemRequirement.<TemplateId>/<IntCount>/<UserItemsCount>k__BackingField
//
// TWO THINGS THAT ARE NOT WHAT THE OLD NOTE SAID, both corrected here because they change the
// implementation:
//
//   * get_Requirements() on AreaData returns this.<Template>.Requirements - a FIELD READ AT +0xA8,
//     not a method that consults the current level. It is the TEMPLATE's list, identical for every
//     level of that area, so it does NOT answer "what does the NEXT level need".
//   * The per-level list is on the Stage: StageAt(_currentLevel + 1).Requirements. That is what
//     get_NextStage() returns and what AreaData.CanBuild enumerates, so it is the same object the
//     game itself checks before letting an upgrade proceed.
//
// Reading the template's list instead would list the same requirements for a Workbench at every
// level, which is worse than useless for "what should I gather next".
//
// READ-ONLY. Nothing here writes to a Requirement or calls UpgradeZone/CompleteUpgradeZone.

// One requirement row, as the card needs it: what it is, how many, and how many are on hand.
struct upgrade_requirement {
    std::string label;      // game-resolved name, never a raw template id where avoidable
    std::string template_id;// MongoId, kept as a dim suffix so a row stays identifiable
    int need = 0;           // IntCount - what this level wants
    int have = 0;           // UserItemsCount - what the stash holds, -1 if not evaluated
    bool have_known = false;// UserItemsCount < 0 means the game has not evaluated it yet
    bool is_item = true;    // false for skill / trader / quest gates, which are not item rows
};

// EFT.Hideout.EAreaStatus - AreaData._status, verbatim from
// GameDump/115147510/DiffableCs/Assembly-CSharp/EFT/Hideout/EAreaStatus.cs:
//
//     public enum EAreaStatus { NotSet = 0, LockedToConstruct = 1, ReadyToConstruct = 2,
//       Constructing = 3, ReadyToInstallConstruct = 4, LockedToUpgrade = 5, ReadyToUpgrade = 6,
//       Upgrading = 7, ReadyToInstallUpgrade = 8, NoFutureUpgrades = 9, AutoUpgrading = 10 }
//
// Byte-identical (SHA256 AE2D82E9...) in all five GameDump builds, so these values are not
// build-specific and do not need re-reading per patch. IsilDump has no copy at all - see the
// note at the top of this file.
//
// WHY IT MATTERS. NoFutureUpgrades is the game's OWN answer to "this area is finished", which is
// not the same question as "this area has no requirement rows", and the card needs the
// difference:
//
//   * Before, upgrade_area::has_next was inferred from StageAt(level+1) returning null, and the
//     card's "nothing to upgrade" line fired on an EMPTY requirement list. An empty list is also
//     what a failed read produces, so a read failure was indistinguishable from a finished
//     hideout - which is how "All stations are at their maximum level" could be printed while
//     nothing had actually been read.
//   * Reading _status is a PLAIN FIELD (ISIL: `Return this._status (EFT.Hideout.EAreaStatus)`),
//     so it costs nothing and cannot itself fail the way the StageAt() managed call can.
//
// Values are stored raw rather than mapped to strings: nothing needs the name at runtime yet,
// and a stale name is worse than an honest number.
enum class area_status : int {
    not_set = 0,
    locked_to_construct = 1,
    ready_to_construct = 2,
    constructing = 3,
    ready_to_install_construct = 4,
    locked_to_upgrade = 5,
    ready_to_upgrade = 6,
    upgrading = 7,
    ready_to_install_upgrade = 8,
    no_future_upgrades = 9,
    auto_upgrading = 10,
};

// One area's next-level requirements, plus the identity the card prints.
struct upgrade_area {
    int area_type = 0;
    std::string name;        // localised area name
    int current_level = 0;
    int next_level = 0;      // == current_level + 1
    bool has_next = false;   // false at max level, where StageAt returns null
    // AreaData._status, verbatim from the enum above. -1 when the field could not be read, which
    // is NOT the same as not_set (0) and must not be compared against no_future_upgrades.
    int status = -1;
    // Stage.<StartTime>k__BackingField as .NET DateTime ticks, or -1 when unset/unreadable.
    // DateTime.MinValue is 0, so 0 is treated as "no date" rather than as 0001-01-01.
    //
    // This is what makes a TIME-GATED upgrade legible. Measured 2026-10-03: the hideout had
    // exactly one area with a next stage - the seasonal Christmas tree - and the card showed
    // "Next level 0 -> 1" with no requirement rows and no explanation, which reads as broken.
    // The stage simply is not available yet, and Stage.get_StartTime() is a real auto-property
    // (ISIL: "Return this.<StartTime>k__BackingField (System.DateTime)"), so the date is
    // readable and the card can say so instead of showing an empty list.
    long long start_time_ticks = -1;
    std::vector<upgrade_requirement> requirements;
};

// The collected set, plus the rolled-up totals the card shows under the per-area list.
struct upgrade_plan {
    std::vector<upgrade_area> areas;
    // Areas that are FINISHED vs areas whose read FAILED. These are different facts and the card
    // must not print "everything is maxed" without both: an area that could not be read leaves
    // the same empty requirement list as one that genuinely needs nothing, so an earlier version
    // of this line asserted "all stations are at their maximum level" on the strength of an empty
    // list alone - which is exactly the shape a failed read produces.
    int areas_maxed = 0;     // confirmed finished by _status == NoFutureUpgrades
    int areas_unknown = 0;   // could not be classified at all; NOT evidence of anything
    // WHICH ROUTE produced this plan, so the log can say so. Both routes return the same
    // AreaData objects and the same count, so without this the two are indistinguishable in
    // output - which is exactly how HideoutController.Areas was reported as "working" for a
    // session while every one of its reads was failing and _areaDatas was quietly carrying it.
    // "controller" | "representation" | "none".
    const char* source = "none";
    // Summed across every area, keyed by template id - the "gather it all at once" answer. Only
    // item rows are summed: a skill gate is not a quantity, so summing those would be nonsense.
    struct total {
        std::string label;
        std::string template_id;
        int need = 0;
        int have = 0;
        bool have_known = false;
        int used_by = 0;     // how many areas want this item
    };
    std::vector<total> totals;
    int areas_considered = 0;
    int areas_with_next = 0;
    bool reachable = false;  // the chain worked; false means no representation was found
    // Whether a HideoutRepresentation was reached AT ALL, which is a different question from
    // whether its area list could be walked, and the card needs both to tell the truth.
    //
    // It was not, and the card collapsed all three states onto reachable=false and printed
    // "Reach the hideout to read upgrade requirements" - including while the player was standing
    // in the hideout with the representation in hand (measured 2026-10-03 13:20:47, where
    // HideoutRepresentation was resolved successfully and only the AreaDatas read below it
    // failed). The three states are:
    //
    //   representation_found=false                 -> not in the hideout, or ShowProduceView has
    //                                                   not fired yet. "Reach the hideout" is
    //                                                   TRUE here and only here.
    //   representation_found=true,  reachable=false -> we have the object but not its area list.
    //                                                   Saying "reach the hideout" here is a lie.
    //   reachable=true,  areas.empty()             -> read it, and there is genuinely nothing
    //                                                   pending. "All at maximum" is the answer.
    bool representation_found = false;
};

// The collector that fills an upgrade_plan lives in production_panel_probe.h, NOT here, and that
// placement is forced rather than stylistic: this header is included BY production_panel_probe.h,
// so anything here that called into the probe would be circular. The types are here because
// HideoutModule's snapshot needs them and this header is what it already includes; the walk needs
// g_live_producer, which only the probe owns.

// One element of a List<T>, by index.
//
// Needed for List<EFT.Hideout.Requirement> (RelatedRequirements.Data). unity::list exposes
// live_count() and to_array() but no element accessor, and reaching through the array's data
// directly is what every other walk in this file does - so it is written once here rather than
// open-coded at each call site.
//
// T is the ELEMENT type, which for a reference-type list is the pointer stored in the slot. The
// addressability check is the point: a List<Requirement> holds managed objects the module has no
// other reason to have validated, and the memo that hideout_read_field uses is keyed per object
// within one walk, so reading a slot's pointee through it is the same safety story as a field read.
template <typename T>
inline T* hideout_list_at(unity::list* list, const size_t index) {
    if (!list) return nullptr;
    const size_t count = list->live_count();
    if (index >= count) return nullptr;
    Il2CppArray* array = list->m_p_list_array;
    if (!array || !eft_api::is_readable_address(&array->data, array->max_length * sizeof(T)))
        return nullptr;
    return reinterpret_cast<T*>(&array->data) + index;
}

// Start of a walk over one collection. Everything the memo learned about a PREVIOUS walk is
// dropped, because a region that was mapped then need not be mapped now.
inline void hideout_probe_cache_reset() {
    hideout_probe_cache().clear();
}

// is_readable_address through the per-walk memo. Same question, same answer, one syscall per
// distinct pointer per walk instead of one per call.
//
// SCOPE, precisely, because it is not uniform and the difference matters:
//
//   * hideout_read_field (above) is memoised on EVERY path, the 30 s recipe walk included.
//     That is safe because a memo entry is created on an object's FIRST field read and used
//     only for that object's remaining field reads, which are consecutive in its own
//     iteration. The window a stale entry could cover is therefore per-object and microseconds
//     wide - the same width it had when every one of those field reads re-probed. The reset at
//     the start of each walk is what stops it crossing into the next walk.
//   * THIS function and hideout_read_string below are used only on the two 1 Hz walks. The
//     recipe path keeps the plain uncached call, because it builds a fresh pointer per
//     dictionary KEY and per scheme - those are genuinely distinct addresses, so a memo buys
//     nothing there, and it is that path which produced the 2026-09-27 mid-walk free. Its
//     detection still runs off hideout_class_usable / hideout_address_readable, which are
//     deliberately NOT memoised and are unchanged by any of this.
inline bool hideout_readable(const void* p, const size_t size) {
    if (!p) return false;
    return hideout_fits_in(hideout_probe_cache().end_for(p), p, size);
}

// try_read_il2cpp_string through the per-walk memo.
//
// Deliberately a near-copy of eft_api::try_read_il2cpp_string rather than a flag on it. That
// function is shared by every module in the project, and the one thing this change is about is
// NOT changing its behaviour for any of them - a per-walk memo is only sound where the walk
// bounds the lifetime, and that is a property of the call site, not of the reader. Duplicating
// eight lines keeps the blast radius inside this file. The body is identical otherwise:
// non-null, header readable, 0 < length <= 512, chars readable for the whole length.
inline std::string hideout_read_string(Il2CppString* str) {
    if (!str) return {};
    hideout_probe_memo& memo = hideout_probe_cache();
    if (!hideout_fits_in(memo.end_for(str), str, sizeof(Il2CppString))) return {};
    if (str->length <= 0 || str->length > 512) return {};
    const auto* chars = str->chars;
    if (!hideout_fits_in(memo.end_for(chars), chars,
            static_cast<size_t>(str->length) * sizeof(wchar_t))) {
        return {};
    }
    return eft_api::to_display_utf8(il2utils::conv_wstring(str));
}

// Read a value-typed instance field through the memo. Returns `fallback` when the
// object is null or the member is absent, so callers need no offset arithmetic.
template <typename T>
inline T hideout_read_field(Il2CppObject* object, const char* name, const T fallback = T{}) {
    if (!object) return fallback;
    // The object itself is probed before its klass is read. A field read returning a stale or
    // non-object pointer is exactly the case this header exists to survive, and `object->klass`
    // is the first deref of it -- reading it unguarded is what turns a bad pointer into a
    // process kill instead of a skipped field.
    //
    // The query is memoised for the span of the current walk (see hideout_probe_memo for the
    // measurement that forced this and for why the lifetime is one walk). One query per element
    // instead of three per field.
    hideout_probe_memo& memo = hideout_probe_cache();
    const uintptr_t object_end = memo.end_for(object);
    if (!hideout_fits_in(object_end, object, sizeof(Il2CppObject))) return fallback;
    const Il2CppClass* klass = object->klass;
    if (!klass || !hideout_fits_in(memo.end_for(klass), klass, sizeof(void*))) return fallback;
    const FieldInfo* field = hideout_cached_field(klass, name);
    if (!field) return fallback;
    // Bounds-checked against the object's own region before the deref, like every other read in
    // this codebase. It used to be its own VirtualQuery on the slot; asking the object's region
    // instead is the same question with an answer already in hand, and strictly MORE conservative
    // in the one case where they could differ - a field whose slot spills into the following
    // region. That case now reads as a skipped field rather than a read, which is the safe
    // direction: a missing number is visible, a wild read is a process kill.
    const auto* slot = reinterpret_cast<const uint8_t*>(object) + field->offset;
    if (!hideout_fits_in(object_end, slot, sizeof(T))) return fallback;
    return *reinterpret_cast<const T*>(slot);
}

// The instantiated Il2CppClass behind a closed generic type
// (IEnumerable<ItemToHandover> -> its interface class). Used to recover the
// ELEMENT type of a generic parameter — see hideout_element_class.
inline const Il2CppType* hideout_generic_arg(const Il2CppType* type, const unsigned index = 0) {
    if (!type || type->byref || type->type != IL2CPP_TYPE_GENERICINST) return nullptr;
    const auto* generic = type->data.generic_class;
    if (!generic) return nullptr;
    const Il2CppGenericInst* inst = generic->context.class_inst;
    if (!inst || !inst->type_argv || index >= inst->type_argc) return nullptr;
    return inst->type_argv[index];
}

inline std::string hideout_to_lower(std::string value) {
    // std::tolower is only defined for values representable as unsigned char;
    // handing it a plain char is undefined behaviour for the high-bit range,
    // which area names with accents hit.
    std::transform(value.begin(), value.end(), value.begin(),
        [](const unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return value;
}

// Iterate elements of either a raw Il2CppArray or a List<T> (unity::list layout) — the
// exact collection type behind Areas/Requirements isn't confirmed from static dumps, so
// this checks the live class name before treating the memory as either shape rather than
// guessing and risking a misread. Calls fn(element) for each valid entry.
//
// The List<T> branch bounds the walk on the element COUNT, not on the backing array's
// max_length: unity::list (il2cpp/unity.h) carries no _size field, so max_length is the
// CAPACITY and walking to it reads every stale slot past the end. This mirrors
// eft_api::append_list_items, including its validity filter and its cap, so a collection
// whose class name lies can neither spin nor hand back a freed object.
template <typename Fn>
inline void hideout_iterate_collection(Il2CppObject* collection_obj, const char* label, Fn fn) {
    if (!collection_obj)
    {
        if (logger::debug_enabled()) logger::debug(std::string(label) + " is null");
        return;
    }
    // A walk is starting, so nothing the previous walk learned about addressability still
    // holds. See hideout_probe_memo: the memo is valid for one walk and no longer, because
    // "this region was mapped" stops being true the moment the object behind it is freed.
    hideout_probe_cache_reset();
    const char* cls_name = (collection_obj->klass && collection_obj->klass->name)
        ? collection_obj->klass->name
        : "?";

    // Nothing here can walk more than this; a shape we misread must not spin.
    constexpr size_t kMaxEntries = 512;

    if (strstr(cls_name, "[]"))
    {
        auto* arr = reinterpret_cast<Il2CppArray*>(collection_obj);
        const size_t limit = (std::min)(static_cast<size_t>(kMaxEntries), arr->max_length);
        if (logger::debug_enabled())
            logger::debug(std::string(label) + " is array class=" + cls_name
                + " len=" + std::to_string(limit));
        for (size_t i = 0; i < limit; ++i)
        {
            Il2CppObject* el = reinterpret_cast<Il2CppObject**>(&arr->data)[i];
            if (eft_api::is_il2cpp_object_likely_valid(el)) fn(el);
        }
        return;
    }

    if (strstr(cls_name, "List"))
    {
        auto* lst = reinterpret_cast<unity::list*>(collection_obj);
        if (!lst->m_p_list_array)
        {
            if (logger::debug_enabled()) logger::debug(std::string(label) + " List backing array is null");
            return;
        }
        const size_t capacity = lst->m_p_list_array->max_length;
        if (capacity == 0) return;

        // try_get_list_count reads the managed _size (falling back to get_Count). A List<T>
        // without either would read as 0, so fall back to the capacity walk rather than
        // silently reporting an empty collection — the validity filter makes that safe.
        const int managed_count = eft_api::try_get_list_count(collection_obj);
        const size_t count = managed_count > 0
            ? (std::min)(static_cast<size_t>(managed_count), capacity)
            : (std::min)(capacity, kMaxEntries);

        if (logger::debug_enabled())
            logger::debug(std::string(label) + " is List class=" + cls_name
                + " count=" + std::to_string(count) + " cap=" + std::to_string(capacity));
        for (size_t i = 0; i < count; ++i)
        {
            Il2CppObject* el = reinterpret_cast<Il2CppObject**>(&lst->m_p_list_array->data)[i];
            if (eft_api::is_il2cpp_object_likely_valid(el)) fn(el);
        }
        return;
    }

    // An unreadable shape is a permanent condition for this build, so say it once rather
    // than once per refresh. The map is per template instantiation, i.e. per call site.
    static std::unordered_map<std::string, bool> warned;
    if (warned.emplace(label, true).second)
        logger::warn("hideout: " + std::string(label) + " is an unknown collection type: " + cls_name);
}

// ---------------------------------------------------------------------------
// Profile -> hideout
// ---------------------------------------------------------------------------

// How Profile exposes the player's hideout. The accessor name is not something the static
// dumps pin down (no "Profile" class was present in the reference dump), so this probes a
// few candidates rather than hardcoding one guess that could silently return null forever.
// The winner is cached: a FieldInfo offset and a MethodInfo pointer are both fixed for the
// process lifetime, so a hit is a pointer read. Before this was cached the probe re-ran up
// to 7 resolve_method/resolve_field lookups on EVERY call.
struct hideout_accessor
{
    const FieldInfo* field = nullptr;   // read directly at field->offset
    const MethodInfo* method = nullptr; // property getter, invoked per read
    const Il2CppClass* probed_class = nullptr;
    bool probed = false;
};

inline const hideout_accessor& hideout_resolve_accessor(const Il2CppClass* profile_class) {
    static hideout_accessor accessor;
    if (!profile_class) return accessor;
    if (accessor.probed && accessor.probed_class == profile_class) return accessor;

    accessor = {};
    accessor.probed = true;
    accessor.probed_class = profile_class;

    // Fields first: the live accessor is a plain field, and a direct offset read costs
    // nothing next to a call.
    static const char* field_candidates[] = {"Hideout", "HideoutRepresentation", "_hideout"};
    for (const char* name : field_candidates)
    {
        if (const FieldInfo* field = hideout_cached_field(profile_class, name))
        {
            accessor.field = field;
            logger::info(std::string("hideout: resolved Profile.") + name + " (field)");
            return accessor;
        }
    }

    static const char* method_candidates[] = {
        "get_HideoutRepresentation", "get_Hideout", "get_HideoutData", "get_HideoutModel"};
    for (const char* name : method_candidates)
    {
        const MethodInfo* method = hideout_cached_method(profile_class, name, 0);
        if (method && method->methodPointer)
        {
            accessor.method = method;
            logger::info(std::string("hideout: resolved Profile.") + name + "() (method)");
            return accessor;
        }
    }

    logger::warn("hideout: could not resolve the hideout from Profile via any known accessor");
    return accessor;
}

// The player's HideoutRepresentation from their Profile, or null.
inline Il2CppObject* hideout_read_representation(Il2CppObject* profile) {
    if (!profile || !profile->klass) return nullptr;
    const hideout_accessor& accessor = hideout_resolve_accessor(profile->klass);
    if (accessor.field)
        return *reinterpret_cast<Il2CppObject**>(
            reinterpret_cast<uint8_t*>(profile) + accessor.field->offset);
    if (accessor.method && accessor.method->methodPointer)
        return static_cast<Il2CppObject* (*)(Il2CppObject*)>(accessor.method->methodPointer)(profile);
    return nullptr;
}

// The Area collection on HideoutInfo. Areas is a plain FIELD (confirmed live), not a
// get_Areas() method — the AreaData class shapes in the static dump do not apply to
// whatever is actually linked from Profile.
//
// CONFIRMED LIVE 2026-09-27 (debug log): the field holds EFT.AreaInfo[], not AreaData[]. The
// element exposes NO get_CurrentLevel / get_Template / get_NextStage — those belong to
// EFT.Hideout.AreaData, which lives on the HideoutRepresentation the client builds for its
// own UI and which Profile does not reference. AreaInfo is the persisted DTO and is flat:
//
//   field                  offset  meaning
//   Active                 0x10    bool   the player owns it
//   Type                   0x14    EAreaType (int enum) — the area's identity
//   Level                  0x18    int
//   CompleteTime           0x1C    int    when the current upgrade finishes
//   Constructing           0x24    bool   an upgrade is running
//   PassiveBonusesEnabled  0x25    bool
//   LastRecipe             0x28    string MongoID of the last production queued here
//   Slots                  0x30    collection
//
// Note what is NOT here: no Template, no Id, and no Requirements. The area's upgrade
// requirements are template-side data the client loads from the hideout bundles, not profile
// state, so they cannot be read from HideoutInfo at all.
inline Il2CppObject* hideout_areas(Il2CppObject* hideout) {
    return hideout_read_field<Il2CppObject*>(hideout, "Areas");
}

// A readable label for an EFT.EAreaType, via the game's OWN localizer.
//
// ISIL settles this: EFT/Hideout/AreaTemplate.txt's get_Name() is a single call —
// `LocalizationExtensions.LocalizeAreaName(this.Type)` — and
// EFT/LocalizationExtensions.txt declares it as
// `static String LocalizeAreaName(EAreaType type)`.
//
// So there is no table to maintain and nothing to drift: this returns the same string the
// hideout UI shows for the area. An earlier revision hand-wrote an EAreaType switch assuming
// map names (Shoreline, Reserve, ...) and was simply wrong — in a hideout context EAreaType
// identifies production areas, so the expected labels are things like Bitcoin, Cooking,
// Crafting, Medicine.
//
// The enum arrives as an int in the ABI. Returns "Area N" if the call is unavailable or comes
// back empty, so a row is never blank.
inline std::string hideout_localize_area_name(const int area_type) {
    // Memoized per EAreaType, and this is the single biggest win in the areas walk.
    //
    // LocalizeAreaName is MANAGED code: it looks the type up in the localization table and
    // allocates a managed Il2CppString, which conv_string then transcodes out of UTF-16. The
    // areas loop called it once per area on every refresh, so the walk cost 27 managed round
    // trips a second on the game's main thread — which is what the "slow while walking hideout
    // areas" actually was, once the per-element logging was gone. There are ~27 distinct
    // EAreaType values for the lifetime of the process and a player's language does not change
    // mid-session, so this collapses to one managed call per type, ever.
    static std::unordered_map<int, std::string> cache;
    if (const auto it = cache.find(area_type); it != cache.end()) return it->second;

    static Il2CppString* (*localize)(int) = nullptr;
    static bool resolved = false;
    if (!resolved)
    {
        resolved = true;
        const Il2CppClass* klass = il2utils::resolve_class(
            il2utils::resolve_image("Assembly-CSharp.dll"), "EFT", "LocalizationExtensions");
        if (klass)
        {
            const MethodInfo* method = hideout_cached_method(klass, "LocalizeAreaName", 1);
            if (method && method->methodPointer)
                localize = static_cast<Il2CppString* (*)(int)>(method->methodPointer);
        }
        if (!localize)
        {
            static bool warned = false;
            if (!warned)
            {
                warned = true;
                logger::warn("hideout: EFT.LocalizationExtensions.LocalizeAreaName is unavailable; "
                             "area names fall back to the raw EAreaType number");
            }
        }
    }

    if (localize)
    {
        // Null-safe: conv_string yields "" for a null string.
        const std::string name = il2utils::conv_string(localize(area_type));
        if (!name.empty())
        {
            cache.emplace(area_type, name);
            return name;
        }
    }
    return "Area " + std::to_string(area_type);
}

// The template id of an area element, or "" when the element doesn't expose one.
inline std::string hideout_area_id(Il2CppObject* area_data) {
    if (!area_data || !area_data->klass) return {};
    const MethodInfo* get_template = hideout_cached_method(area_data->klass, "get_Template", 0);
    if (!get_template || !get_template->methodPointer) return {};
    Il2CppObject* tmpl = static_cast<Il2CppObject* (*)(Il2CppObject*)>(get_template->methodPointer)(area_data);
    if (!tmpl) return {};
    return eft_api::try_read_il2cpp_string(hideout_read_field<Il2CppString*>(tmpl, "Id"));
}

// ---------------------------------------------------------------------------
// Production schemes
// ---------------------------------------------------------------------------
// Message helpers
// ---------------------------------------------------------------------------
//
// These live ABOVE their first use. hideout_enumerate_any needs hideout_warn_once, and a
// C++ non-template inline function must be declared before the point of use, so keeping the
// warning helper below the enumerator was a hard compile error, not a style nit.

// One-shot warning helper. Every failure mode below is permanent for the build, so each says
// itself once and then costs a single bool.
//
// This exists because the previous attempt at labelling schemes was written from ISIL alone,
// compiled clean, and produced nothing in game — six of 260 recipes had names and the rest were
// still MongoIDs, with no indication of which of the four steps below had failed. A silent
// empty string is indistinguishable from "the feature is broken"; these make the difference
// legible in one run.
inline void hideout_warn_once(const char* id, const std::string& message) {
    static std::unordered_map<std::string, bool> warned;
    if (warned.emplace(id, true).second) logger::warn("hideout: " + message);
}

// Kept as a named wrapper because message building reads better with it, and because it used to
// be load-bearing: hideout_class_label returned const char*, which cannot be concatenated with a
// string literal ("literal" + const char* is a pointer add) and failed at every call site with a
// bogus "no overload takes 1 argument". hideout_class_label now returns std::string, so this is
// a straight forward - the name survives because it reads better than the call it wraps.
inline std::string hideout_class_name(const Il2CppClass* klass) {
    return hideout_class_label(klass);
}

// ---------------------------------------------------------------------------
// One-shot metadata dumper
// ---------------------------------------------------------------------------
//
// ISIL is method-body-only: it carries no field tables, so there has been nothing to check a
// member name or a storage layout against. Every "field not found" in this file has therefore
// been resolved by guessing a name, and a wrong guess is indistinguishable from a name that
// genuinely does not exist — the read just returns the fallback.
//
// This dumps the real table so that stops being true. It is the diagnostic to reach for when a
// member is missing and the log cannot say why: one call names every instance field on a class
// and its parents, with the offset and the type.
//
// The type name is the expensive part and there is no il2cpp_type_get_name export in this build,
// so it is obtained the long way round — il2cpp_type_get_object materialises a System.Type, whose
// own get_Name is then called through the same memo every other getter here uses. That is a
// managed call and it allocates, which is why this is strictly one-shot per (id, class) and never
// runs on a refresh path.

inline std::string hideout_type_name(const Il2CppType* type) {
    if (!type) return {};
    if (!il2cpp_offsets::il2cpp_type_get_object) return {};
    if (!eft_api::is_readable_address(type, sizeof(void*))) return {};

    Il2CppObject* boxed = il2cpp::il2cpp_type_get_object(type);
    if (!eft_api::is_il2cpp_object_likely_valid(boxed)) return {};
    if (!eft_api::is_readable_address(boxed, sizeof(Il2CppObject))) return {};

    const MethodInfo* get_name = hideout_cached_method(boxed->klass, "get_Name", 0);
    if (!get_name || !get_name->methodPointer) return {};
    return eft_api::try_read_il2cpp_string(
        static_cast<Il2CppString* (*)(Il2CppObject*)>(get_name->methodPointer)(boxed));
}

// Every instance field of `klass` and its parents, as "name +offset : Type". Once per `id`.
// A per-field VirtualQuery is the only readability check used: a single-region span test over a
// whole table would fail on any class whose fields happen to straddle a guard page, and that
// failure would look exactly like "this class has no fields".
inline void hideout_dump_fields_once(const char* id, const Il2CppClass* klass) {
    if (!id || !klass) return;
    static std::unordered_map<std::string, bool> dumped;
    if (!dumped.emplace(std::string(id) + '@' + hideout_class_name(klass), true).second)
        return;

    std::string out = "hideout fields of " + hideout_class_name(klass) + " (" + std::to_string(klass->field_count) + " own):";
    int seen = 0;
    for (const Il2CppClass* c = klass; c; c = c->parent)
    {
        if (!eft_api::is_readable_address(c, sizeof(void*))) break;
        if (!c->fields || c->field_count == 0) continue;
        for (uint16_t i = 0; i < c->field_count; ++i)
        {
            if (!eft_api::is_readable_address(&c->fields[i], sizeof(FieldInfo))) break;
            const FieldInfo& field = c->fields[i];
            if (!field.name) continue;

            char offset[16];
            std::snprintf(offset, sizeof(offset), "+0x%x", static_cast<unsigned>(field.offset));
            out += "\n    ";
            out += field.name;
            out += ' ';
            out += offset;
            out += " : ";
            out += hideout_type_name(field.type);
            ++seen;
        }
        out += "\n  -- end " + hideout_class_name(c);
        out += (c->parent ? " --\n" : " --");
    }
    if (seen == 0) out += "\n    (no readable field table)";
    logger::info(out);
}
// ---------------------------------------------------------------------------
//
// A scheme and where it should be started. The kind is expressed STRUCTURALLY, by which of
// the three arrays on ProductionSchemesCollection the scheme lives in (ISIL
// EFT/Hideout/ProductionSchemesCollection.txt) — there is no ProductionKind field anywhere.
// "Continuous" is not a scheme kind at all: it is a flag on the producer
// (ItemsProducerBase.get_IsConstantConsumption, used by PermanentProducer for Bitcoin and
// friends), which is not reachable from here, so it stays an explicit choice.
enum class hideout_scheme_kind {
    single = 0,
    continuous = 1,
    scav_case = 2,
    cultists = 3,
};

struct hideout_scheme
{
    std::string id;
    hideout_scheme_kind kind = hideout_scheme_kind::single;
    // Localized product name when one is known (see ProductionInfo::product_label). Empty
    // for a scheme that is not currently running, because the produced item is only
    // discoverable from a live ProductionData entry.
    std::string label;
    // BaseHideoutScheme.areaType — the station this recipe belongs to, as an EAreaType number.
    //
    // Found by the 2026-09-28 field dump (`areaType +0x38 : Int32` on BaseHideoutScheme), which
    // is where the station attribution actually lives. It was previously sourced from
    // HideoutRepresentation -> ProductionController -> producers, and that path is unreachable
    // because Profile.Hideout is the HideoutInfo DTO — so the feature was latched off and the log
    // reported "0 with a station prefix". The field was in the recipe payload the whole time.
    //
    // -1 means "not read", which is distinct from a genuine 0: a scheme with no station is
    // different from a scheme whose areaType field failed to resolve, and the diagnostic below
    // reports them separately.
    int area_type = -1;
};

// Request the production scheme list.
//
// IMPORTANT (confirmed live 2026-09-27): this lives on IEftSession, NOT on the hideout
// object. Profile.Hideout is the EFT.HideoutInfo DTO, which has no ProductionSchemes field
// and no GetProductionRecipes method — an earlier revision looked for both there and logged
// "GetProductionRecipes not found on the hideout" once a second.
//
// Returns the in-flight Task, or null if the method is missing. The caller must retain it and
// poll with hideout_poll_task; the collection arrives as the task's Result.
inline Il2CppObject* hideout_request_production_schemes(Il2CppObject* session) {
    if (!session || !session->klass) return nullptr;
    const MethodInfo* m = hideout_cached_method(session->klass, "GetProductionRecipes", 0);
    if (!m || !m->methodPointer) return nullptr;
    return static_cast<Il2CppObject* (*)(Il2CppObject*)>(m->methodPointer)(session);
}

// Walk an IEnumerable<T> whose concrete runtime type is not pinned down by a static dump.
//
// hideout_iterate_collection recognises a raw Il2CppArray and unity::list by class name, and
// warns on anything else. That is the right behaviour for a collection this module KNOWS the
// shape of, but get_RequiredItems is declared IEnumerable<ItemRequirement>, so the object could
// equally be a List, an array, or a compiler-generated iterator — and ISIL carries no field
// tables, so there is nothing to check it against.
//
// So: hand the two known shapes to the existing walker, and drive the enumerator protocol for
// everything else. GetEnumerator/MoveNext/get_Current is the one interface every IEnumerable
// implements, including the explicit-interface implementations on List<T> that a by-name method
// lookup cannot see. The loop is hard-bounded so a shape we misread cannot spin.
template <typename Fn>
inline void hideout_enumerate_any(Il2CppObject* collection_obj, const char* label, Fn fn) {
    if (!eft_api::is_il2cpp_object_likely_valid(collection_obj)) return;
    const char* cls_name = (collection_obj->klass && collection_obj->klass->name)
        ? collection_obj->klass->name
        : "?";
    if (strstr(cls_name, "[]") || strstr(cls_name, "List"))
    {
        hideout_iterate_collection(collection_obj, label, fn);
        return;
    }

    constexpr size_t kMaxEntries = 64;

    // THE OBJECT MAY ALREADY BE A COMPILER-GENERATED ITERATOR — AND ONLY THEN IS IT SAFE TO
    // DRIVE ITS MoveNext.
    //
    // Confirmed 2026-09-27: get_RequiredItems() returns `<>OfTypeIterator>d__97`1, and
    // `GetEnumerator/0` is not resolvable on it or any parent. That is not a missing method and
    // not a lazily-built method table — il2cpp_runtime_class_init is called before every resolve
    // and the miss survived it. The `<>Xxx>d__NN` name is a C# compiler-generated STATE MACHINE,
    // and an iterator's state machine is the IEnumerator itself: no GetEnumerator to find, and
    // its members are
    //     private bool MoveNext()
    //     T System.Collections.Generic.IEnumerator<T>.get_Current()  <- EXPLICIT interface impl
    //     T <>2__current                                            <- the field it forwards to
    // so `get_Current` is unreachable by name and the value lives in a field. By-name MoveNext on
    // such a class is sound — il2utils::hook_async_method relies on exactly that
    // (hook_method(state_machine_class, "MoveNext", 0, ...)), and the transit hooks prove it.
    //
    // WHY THIS IS GATED ON BOTH THE NAME AND THE FIELD, rather than on MoveNext alone: there are
    // plenty of classes carrying a MoveNext, and two families matter here —
    //   * an ITERATOR state machine, <>OfTypeIterator>d__97, which has a `<>2__current` field;
    //   * an ASYNC state machine,    <>SomeAsync>d__12,        which has none.
    // Driving the second would EXECUTE A COROUTINE from inside a menu render path. The `<>2__current`
    // field is the discriminator: only an iterator has one, so requiring it means a MoveNext is
    // only ever called on a class we have established is a lazy sequence. Name plus field, not
    // name plus optimism.
    const bool looks_generated = il2utils::is_state_machine_class_name(cls_name);
    if (looks_generated)
    {
        const FieldInfo* current_field = hideout_cached_field(
            collection_obj->klass, "<>2__current");
        if (current_field)
        {
            // The MoveNext resolution (including the class-initialisation that populates the
            // method table) comes from il2utils, shared with the transit hooks — so this path
            // and the ones already proven in game resolve MoveNext the same way. Deliberately NOT
            // find_state_machine_class: the class is already in hand here, and that helper
            // searches a declaring class's NESTED types, which is the wrong direction.
            const MethodInfo* move = il2utils::resolve_state_machine_movenext(collection_obj->klass);
            if (move && move->methodPointer)
            {
                // MoveNext resolves and is called, but returns false on the FIRST call for every
                // one of the 260 schemes, and the state field does not move (0/260 elements,
                // <>1__state stays -2). MoveNext's behaviour is decided by two compiler fields,
                // so they are read to find out why:
                //
                //   <>1__state            -2 fresh / 0 started / 1..n suspended / -3 finished
                //   <>l__initialThreadId  recorded by the generator
                //
                // Observed: `state -2->-2, thread creator=1 me=24052`. The differing thread is the
                // obvious suspect — a generated iterator is single-threaded — but it is a
                // SUSPECT, not a proven cause: what a fresh iterator's initial thread id should
                // be is not derivable from here, and the codegen that consumes -2 is not
                // observable through ISIL. So it is not acted on as though it were settled.
                //
                // What IS acted on is the observed failure, latched per CLASS. The first time a
                // given state-machine class fails to advance, that is recorded, and later
                // instances of the same class skip the call. That removes the repeat cost (one
                // guaranteed-empty managed call per scheme per refresh) without ever disabling a
                // path on a theory: nothing is skipped until it has actually been seen to fail,
                // and a different class that does advance is unaffected.
                static std::unordered_map<std::string, bool> will_not_advance;
                if (will_not_advance.count(cls_name)) return;

                const int state_before = hideout_read_field<int>(
                    collection_obj, "<>1__state", -999);
                const int creator_thread = hideout_read_field<int>(
                    collection_obj, "<>l__initialThreadId", -999);
                const int my_thread = static_cast<int>(GetCurrentThreadId());

                const auto step = reinterpret_cast<bool (*)(Il2CppObject*)>(move->methodPointer);
                size_t produced = 0;
                for (size_t i = 0; i < kMaxEntries; ++i)
                {
                    if (!eft_api::is_readable_address(collection_obj, sizeof(Il2CppObject))) break;
                    if (!step(collection_obj)) break;
                    ++produced;
                    Il2CppObject* value = hideout_read_field<Il2CppObject*>(
                        collection_obj, "<>2__current");
                    if (eft_api::is_il2cpp_object_likely_valid(value)) fn(value);
                }
                const int state_after = hideout_read_field<int>(
                    collection_obj, "<>1__state", -999);

                const bool stalled = produced == 0 && state_after == state_before;
                if (stalled) will_not_advance.emplace(cls_name, true);
                hideout_trace(std::string(label) + " is a generated iterator ("
                    + cls_name + "): " + std::to_string(produced) + " element(s)"
                    + ", state " + std::to_string(state_before) + "->" + std::to_string(state_after)
                    + ", thread creator=" + std::to_string(creator_thread)
                    + " me=" + std::to_string(my_thread)
                    + (creator_thread != -999 && creator_thread != my_thread ? " (differs)" : "")
                    + (stalled ? " (latched: not called again for this class)" : ""));
                if (stalled)
                    hideout_warn_once("iter_empty",
                        std::string(label) + " is a " + cls_name
                            + " (a compiler-generated iterator) and did not advance: state "
                            + std::to_string(state_before) + "->" + std::to_string(state_after)
                            + ", thread creator=" + std::to_string(creator_thread)
                            + " vs current " + std::to_string(my_thread)
                            + ". Further calls for this class are skipped; the values must come from "
                            + "the scheme's own storage - see the field dump in this log");
                return;
            }
        }
        // Named like a state machine but no <>2__current: an async one, or a shape we do not
        // know. Fall through to the GetEnumerator path rather than guessing.
    }

    const MethodInfo* get_enumerator = hideout_cached_method(
        collection_obj->klass, "GetEnumerator", 0);
    if (!get_enumerator || !get_enumerator->methodPointer)
    {
        static std::unordered_map<std::string, bool> warned;
        if (warned.emplace(std::string(label) + '/' + cls_name, true).second)
            logger::warn("hideout: " + std::string(label) + " is a " + cls_name
                + " with neither GetEnumerator nor a usable <>2__current iterator - "
                  "it will read as empty");
        return;
    }

    Il2CppObject* enumerator = static_cast<Il2CppObject* (*)(Il2CppObject*)>(
        get_enumerator->methodPointer)(collection_obj);
    if (!eft_api::is_il2cpp_object_likely_valid(enumerator)) return;
    const MethodInfo* move_next = hideout_cached_method(enumerator->klass, "MoveNext", 0);
    const MethodInfo* current = hideout_cached_method(enumerator->klass, "get_Current", 0);
    if (!move_next || !move_next->methodPointer || !current || !current->methodPointer)
    {
        static bool warned = false;
        if (!warned)
        {
            warned = true;
            logger::warn("hideout: " + std::string(label) + " yielded a "
                + hideout_class_label(enumerator->klass)
                + " whose enumerator does not expose MoveNext/get_Current - it will read as empty");
        }
        return;
    }

    const auto step = reinterpret_cast<bool (*)(Il2CppObject*)>(move_next->methodPointer);
    auto item = static_cast<Il2CppObject* (*)(Il2CppObject*)>(current->methodPointer);
    for (size_t i = 0; i < kMaxEntries; ++i)
    {
        if (!eft_api::is_readable_address(enumerator, sizeof(Il2CppObject))) return;
        if (!step(enumerator)) return;
        Il2CppObject* value = item(enumerator);
        if (eft_api::is_il2cpp_object_likely_valid(value)) fn(value);
    }
    logger::warn("hideout: " + std::string(label) + " exceeded the " + std::to_string(kMaxEntries)
        + " element cap and was truncated");
}

// ---------------------------------------------------------------------------
// Which station (area) each scheme belongs to
// ---------------------------------------------------------------------------
//
// A scheme carries no area, so the earlier "Zone->Recipe->Result" label could never be built
// from the scheme itself. The link does exist — it is just three objects away, on the graph the
// game uses to run production:
//
//   HideoutRepresentation.get_ProductionController()      -> ProductionController
//   ProductionController.GetAreaProducers(AreaData)      -> List<ItemsProducerBase>
//   ItemsProducerBase.get_AreaType()                      -> EAreaType   (the station)
//   ItemsProducerBase.get_Schemes()                       -> Dictionary<string, BaseHideoutScheme>
//
// ISIL: EFT/Hideout/HideoutRepresentation.txt (get_ProductionController),
// EFT/Hideout/ProductionController.txt (GetAreaProducers),
// EFT/Hideout/ItemsProducerBase.txt (get_AreaType, get_Schemes).
//
// Crucially the producer's Schemes dictionary covers EVERY scheme the station can run, not just
// the one currently going, so unlike ProductionData.Products this yields a station for all ~260
// recipes. get_AreaDatas() supplies the AreaData argument GetAreaProducers needs.
// A facility that CONSUMES a resource instead of producing an item: the water treatment plant
// and the generator, and in practice anything whose producer is a PermanentProducer carrying a
// ResourceConsumer.
//
// The game's own model is what makes these readable. ResourceConsumer exposes the two totals
// (get_TotalResourceCount / get_TotalResourceCountLeft) and the drain rate (get_Consumption,
// get_ConsumptionReduction, get_ResultConsumption); ConsumptionTimer exposes the countdown the
// game maintains itself (get_TimeLeftFromStart / get_CurrentTimeLeft). ISIL:
// EFT/Hideout/ResourceConsumer.txt, EFT/Hideout/ConsumptionTimer.txt.
//
// The TIMER is the primary source for the fraction, not the resource counts: TimeLeftFromStart is
// the duration the facility was given when it was filled, so TimeLeft/TimeLeftFromStart is
// exactly the "relative remaining" a player sees on the facility, and it stays correct across a
// refill. The double totals are kept as a cross-check and as the fallback for a facility whose
// timer is not running.
struct hideout_resource
{
    int area_type = -1;
    std::string area_name;
    bool is_on = false;
    bool is_working = false;
    bool timer_running = false;
    // Seconds. timer_total is the duration at fill time, so the pair gives a fraction.
    int timer_total = 0;
    int timer_left = 0;
    // Raw resource units (litres, litres of fuel) — not necessarily seconds.
    double resource_total = 0.0;
    double resource_left = 0.0;
    // Installed supplies, counted only.
    //
    // WHY COUNTED AND NOT READ: BarterItem and SupplyItem expose no accessors at all in the
    // reference dump (BarterItem has just a .ctor, SupplyItem just a .ctor) and ISIL is
    // method-body-only, so there is no field table to name their members from. The IL does show
    // that ResourceConsumer keeps ONE aggregate double for remaining — a single
    // TotalResourceCountLeft at +0x48, decremented in place against ResultConsumption — so the
    // game itself does not hold a per-slot remaining value on the consumer either. Any per-slot
    // number is therefore necessarily a share of the aggregate, and is presented as such.
    int supplies_installed = 0;
    // PermanentProducer.get_MaxSuppliesCount() — the real slot capacity, not an estimate.
    int supplies_capacity = 0;

    // 0..1, clamped. Prefers the timer; falls back to the resource totals.
    [[nodiscard]] float fraction() const;

    // How many slots' worth of supply is left, as a share of the total. This is an AVERAGE over
    // the slots, not a count of which specific ones are spent: the game keeps one aggregate
    // remaining value, so whether it drains slot-by-slot or uniformly is not knowable from here.
    // Drawn as proportional pips for exactly that reason — a row of pips says "this much of the
    // total is left" truthfully, where eight individually-labelled slots would assert something
    // the data does not support.
    //
    // SEAM: if BarterItem's members ever become readable (a runtime field-name probe, or a
    // dump that carries fields), replace this with the real per-slot values and draw the pips
    // per slot. Everything else here — capacity, fraction, countdown — already comes from the
    // game and would not change.
    [[nodiscard]] float slots_remaining() const;
};

// Memo, filled by hideout_refresh_production_graph.
inline std::vector<hideout_resource>& hideout_resource_facilities() {
    static std::vector<hideout_resource> list;
    return list;
}

// Non-const: hideout_refresh_production_graph clears and fills this, and the composition sites
// only read it. A single file-scope memo rather than a parameter, because the two hideout
// modules read the same attribution and neither should walk the producer graph twice.
inline std::unordered_map<std::string, int>& hideout_scheme_stations() {
    static std::unordered_map<std::string, int> map;
    return map;
}

// scheme id -> BaseHideoutScheme.areaType, read straight off each scheme by
// hideout_read_schemes.
//
// This is deliberately NOT hideout_scheme_stations(). That map is filled by walking
// HideoutRepresentation -> ProductionController, which is unreachable (Profile.Hideout is the
// HideoutInfo DTO), so it is always empty and the log has been reporting "0 with a station
// prefix" as a result. This map is filled from the recipe payload itself, so it is expected to be
// populated. Keeping them separate means the cross-check in HideoutModule can compare the two
// independent sources and say whether they agree, rather than one silently replacing the other.
inline std::unordered_map<std::string, int>& hideout_scheme_area_types() {
    static std::unordered_map<std::string, int> map;
    return map;
}

// Walks HideoutRepresentation -> ProductionController -> producers, filling BOTH memos above.
//
// `want_schemes` exists because the two outputs are wanted on different clocks. The scheme walk
// reads a ~260-entry dictionary per producer and only feeds the recipe labels, which change on
// the slow recipe tick. The resource consumers are a countdown that drains continuously, so they
// have to be re-read on the fast refresh or the gauge would sit still for half a minute at a time.
// Passing false skips the dictionary walk and leaves the station memo untouched.
//
// Returns the stage it reached, as a short string, for the trace. The distinction that matters:
// "the controller is null" is a NOT-READY state that the next refresh retries, while "the walk
// completed and found nothing" is a real fault worth warning about. An earlier revision warned on
// both, so a hideout whose controllers are wired up a second after the profile loaded logged a
// permanent-looking fault for something transient — and the caller could not tell the two apart.
inline const char* hideout_refresh_production_graph(Il2CppObject* hideout,
    const bool want_schemes = true) {
    if (!eft_api::is_il2cpp_object_likely_valid(hideout)) return "no-hideout";

    // Latch off permanently once we learn the hideout is the DTO rather than the live object.
    //
    // CONFIRMED 2026-09-27 from the log: `representation class=EFT.HideoutInfo`, and
    // `get_ProductionController/0 not found on HideoutInfo or any of its parents`. Profile.Hideout
    // is the EFT.HideoutInfo DTO — Areas, Production and nothing else. ProductionController, and
    // with it ItemsProducerBase and ResourceConsumer, hang off the CLIENT-SIDE
    // EFT.Hideout.HideoutRepresentation that the hideout screen builds for its own UI, and
    // Profile does not reference it.
    //
    // There is no way in from here. Searching the whole reference dump for a member that returns
    // HideoutRepresentation finds none, so it is reachable only through a private field on the
    // screen controller or game loader, and ISIL is method-body-only with no field tables to name
    // one. This whole feature — station prefixes and fuel/water gauges — therefore depends on
    // finding that object by some other means, and until then it must not cost a walk per refresh.
    static bool graph_unreachable = false;
    if (graph_unreachable) return "unreachable (Profile.Hideout is the HideoutInfo DTO)";

    const MethodInfo* get_controller = hideout_cached_method(
        hideout->klass, "get_ProductionController", 0);
    if (!get_controller || !get_controller->methodPointer)
    {
        graph_unreachable = true;
        hideout_warn_once("station_controller",
            "Profile.Hideout is a " + hideout_class_name(hideout->klass)
                + ", which has no ProductionController - it is the DTO, not the live HideoutRepresentation. "
                  "Station attribution and fuel/water gauges need that object and are disabled until it "
                  "can be reached.");
        return "unreachable (Profile.Hideout is the HideoutInfo DTO)";
    }
    Il2CppObject* controller = static_cast<Il2CppObject* (*)(Il2CppObject*)>(
        get_controller->methodPointer)(hideout);
    // Not-ready, not broken: SetupControllers wires the controllers up on the hideout screen, so
    // a null here just means the profile is a moment ahead of the UI. Retried next refresh.
    if (!eft_api::is_il2cpp_object_likely_valid(controller))
        return "controller-null (not ready yet)";

    const MethodInfo* get_area_datas = hideout_cached_method(
        hideout->klass, "get_AreaDatas", 0);
    if (!get_area_datas || !get_area_datas->methodPointer)
    {
        hideout_warn_once("station_areadatas",
            "no get_AreaDatas on " + hideout_class_name(hideout->klass)
                + " - recipes cannot be attributed to a station");
        return "no-get_AreaDatas";
    }
    Il2CppObject* area_datas = static_cast<Il2CppObject* (*)(Il2CppObject*)>(
        get_area_datas->methodPointer)(hideout);
    if (!eft_api::is_il2cpp_object_likely_valid(area_datas))
        return "area-datas-null (not ready yet)";

    // GetAreaProducers is an instance method on the controller that takes an AreaData.
    const MethodInfo* get_producers = hideout_cached_method(
        controller->klass, "GetAreaProducers", 1);
    if (!get_producers || !get_producers->methodPointer)
    {
        hideout_warn_once("station_getproducers",
            "no ProductionController.GetAreaProducers on "
                + hideout_class_name(controller->klass));
        return "no-GetAreaProducers";
    }
    const auto producers_of = static_cast<Il2CppObject* (*)(Il2CppObject*, Il2CppObject*)>(
        get_producers->methodPointer);

    std::unordered_map<std::string, int>& map = hideout_scheme_stations();
    if (want_schemes) map.clear();
    std::vector<hideout_resource>& resources = hideout_resource_facilities();
    resources.clear();
    int producers = 0;
    int stations = 0;
    int consumers = 0;

    // Read a zero-argument property through its accessor, returning `fallback` when the accessor
    // is absent or the call comes back unusable. get_ResourceConsumer only exists on
    // PermanentProducer, so a producer that is not a PermanentProducer simply reports null here
    // rather than needing a class check.
    auto call_flag = [](Il2CppObject* o, const char* name) {
        const MethodInfo* m = hideout_cached_method(o->klass, name, 0);
        if (!m || !m->methodPointer) return false;
        return static_cast<bool (*)(Il2CppObject*)>(m->methodPointer)(o);
    };
    auto call_double = [](Il2CppObject* o, const char* name, const double fallback) {
        const MethodInfo* m = hideout_cached_method(o->klass, name, 0);
        if (!m || !m->methodPointer) return fallback;
        return static_cast<double (*)(Il2CppObject*)>(m->methodPointer)(o);
    };
    auto call_int = [](Il2CppObject* o, const char* name) {
        const MethodInfo* m = hideout_cached_method(o->klass, name, 0);
        if (!m || !m->methodPointer) return -1;
        return static_cast<int (*)(Il2CppObject*)>(m->methodPointer)(o);
    };

    hideout_enumerate_any(area_datas, "hideout AreaDatas", [&](Il2CppObject* area_data) {
        Il2CppObject* list = producers_of(controller, area_data);
        if (!eft_api::is_il2cpp_object_likely_valid(list)) return;
        hideout_enumerate_any(list, "area producers", [&](Il2CppObject* producer) {
            const int area_type = hideout_read_field<int>(producer, "AreaType", -1);
            if (area_type < 0) return;
            ++producers;
            ++stations;

            // ---- resource consumer? (water plant, generator, and anything else that drains) --
            // Checked BEFORE the scheme loop and independently of it, so a facility that
            // consumes without running any recipe is still reported.
            const MethodInfo* get_consumer = hideout_cached_method(
                producer->klass, "get_ResourceConsumer", 0);
            if (get_consumer && get_consumer->methodPointer)
            {
                Il2CppObject* consumer = static_cast<Il2CppObject* (*)(Il2CppObject*)>(
                    get_consumer->methodPointer)(producer);
                if (eft_api::is_il2cpp_object_likely_valid(consumer))
                {
                    hideout_resource res;
                    res.area_type = area_type;
                    res.area_name = hideout_localize_area_name(area_type);
                    res.is_on = call_flag(consumer, "get_IsOn");
                    res.is_working = call_flag(consumer, "get_IsWorking");
                    res.resource_total = call_double(consumer, "get_TotalResourceCount", 0.0);
                    res.resource_left = call_double(consumer, "get_TotalResourceCountLeft", 0.0);

                    Il2CppObject* using_items = nullptr;
                    const MethodInfo* get_using = hideout_cached_method(
                        consumer->klass, "get_UsingItems", 0);
                    if (get_using && get_using->methodPointer)
                        using_items = static_cast<Il2CppObject* (*)(Il2CppObject*)>(
                            get_using->methodPointer)(consumer);
                    if (eft_api::is_il2cpp_object_likely_valid(using_items)
                        && eft_api::is_readable_address(using_items, sizeof(Il2CppArray)))
                        res.supplies_installed = static_cast<int>(
                            reinterpret_cast<Il2CppArray*>(using_items)->max_length);

                    // PermanentProducer also reports the real slot capacity, which is what makes
                    // the pip row a true "n of m" rather than a guess.
                    res.supplies_capacity = call_int(producer, "get_MaxSuppliesCount");
                    if (res.supplies_installed > res.supplies_capacity
                        && res.supplies_capacity > 0)
                        res.supplies_installed = res.supplies_capacity;

                    // The countdown the game keeps for the facility.
                    const MethodInfo* get_timer = hideout_cached_method(
                        consumer->klass, "get_Timer", 0);
                    Il2CppObject* timer = (get_timer && get_timer->methodPointer)
                        ? static_cast<Il2CppObject* (*)(Il2CppObject*)>(
                              get_timer->methodPointer)(consumer)
                        : nullptr;
                    if (eft_api::is_il2cpp_object_likely_valid(timer))
                    {
                        res.timer_running = call_flag(timer, "get_IsRunning");
                        res.timer_total = call_int(timer, "get_TimeLeftFromStart");
                        // CurrentTimeLeft is the recomputed value; TimeLeft is the cached one.
                        // Prefer the recomputed, fall back to the cached, because a paused timer
                        // leaves the cached value stale and the recomputed one honest.
                        res.timer_left = call_int(timer, "get_CurrentTimeLeft");
                        if (res.timer_left < 0) res.timer_left = call_int(timer, "get_TimeLeft");
                    }
                    ++consumers;
                    resources.push_back(std::move(res));
                }
            }

            // Schemes is Dictionary<string, BaseHideoutScheme>, so the keys ARE the scheme ids
            // the dropdown already holds. unity::dict's entry is { hash, next, key, value }.
            if (!want_schemes) return;
            Il2CppObject* schemes = hideout_read_field<Il2CppObject*>(producer, "Schemes");
            if (!eft_api::is_il2cpp_object_likely_valid(schemes)) return;
            if (!eft_api::is_readable_address(schemes, sizeof(Il2CppArray))) return;
            auto* arr = reinterpret_cast<Il2CppArray*>(schemes);
            using entry_t = unity::dict<Il2CppString*, Il2CppObject*>::entry;
            const auto* entries = reinterpret_cast<const entry_t*>(&arr->data);
            const int count = std::min<int>(static_cast<int>(arr->max_length), 4096);
            for (int i = 0; i < count; ++i)
            {
                if (entries[i].m_i_hash_code < 0) continue;
                const std::string id = eft_api::try_read_il2cpp_string(entries[i].m_t_key);
                if (id.empty()) continue;
                // First producer wins: an area can legitimately appear twice (a PermanentProducer
                // alongside a base one) and both name the same station.
                map.emplace(id, area_type);
            }
        });
    });
    // Reaching this point means every hop resolved, so an empty result here is a real fault and
    // not a not-ready state. That distinction is the whole reason the stage is reported.
    hideout_trace("graph walked: " + std::to_string(producers) + " producer(s), "
        + std::to_string(consumers) + " resource consumer(s), "
        + std::to_string(map.size()) + " scheme(s) attributed"
        + (want_schemes ? "" : " (schemes not requested this pass)"));
    if (want_schemes && map.empty())
        hideout_warn_once("station_empty",
            "the producer graph walked cleanly but attributed 0 schemes to a station, so recipe "
            "labels have no station prefix");
    if (resources.empty())
        hideout_warn_once("resource_empty",
            "the producer graph walked cleanly but no producer exposed a ResourceConsumer, so the "
            "water plant and generator cannot be shown as fuel/water gauges");
    return "walked";
}

// A MongoID, the 24-hex template id the game uses everywhere.
//
// MongoID = { uint32 _timeStamp; uint64 _counter; Il2CppString* _stringID } (24 bytes; same
// shape and same IL-verified layout as game_items::mongo_id). _stringID is the runtime's own
// cached Convert.ToString(_timeStamp, _counter), i.e. exactly the 24-hex template id that
// game_items::entry::id holds and that eft_api::try_get_item_name_for_template_id expects, so the
// cached string is read as-is rather than reformatted.
//
// Reading a MongoID as an Il2CppString* handed the low 8 bytes of the struct to
// eft_api::try_read_il2cpp_string, which correctly rejected them as unmapped. That is why every
// production label came back empty: the guard was working, the TYPE was wrong.
//
// Declared here rather than reusing game_items::mongo_id: game_item_db.h states it must stay
// independent of eft_api, and this header sits on the eft_api side of that line.
struct flat_item_tpl
{
    uint32_t time_stamp;
    uint64_t counter;
    Il2CppString* string_id;
};

// ---------------------------------------------------------------------------
// Recipe list: the reload toggle and the loaded count
// ---------------------------------------------------------------------------
//
// These live here, in the header both hideout modules already include, rather than on either
// module. The knob is drawn by Hideout Improvements (the old automation card) but HONOURED by
// HideoutModule, which owns the refresh. A file-scope toggle is what lets the two stay independent
// — HideoutModule holds no pointer to the card, and the card owns no refresh of its own.
//
// The default is true, so nothing changes until the player unticks it. The count is the number of
// schemes currently published, which is what turns "the list is empty" into a distinguishable
// "the list has not loaded yet" — the same not-ready-yet vs genuinely-broken distinction the rest
// of this file is careful about.
inline bool& hideout_recipe_reload_flag() {
    static bool reload = true;
    return reload;
}

inline void hideout_set_recipe_reload(const bool reload) {
    hideout_recipe_reload_flag() = reload;
}

inline bool hideout_recipe_reload() {
    return hideout_recipe_reload_flag();
}

// ---------------------------------------------------------------------------
// Station rebuild coalescing
// ---------------------------------------------------------------------------
//
// A SEPARATE control from the recipe pin above, on purpose. They were briefly one knob, on the
// theory that a single switch was tidier - but the recipe pin suppresses OUR 30 s
// GetProductionRecipes re-fetch, while this suppresses the GAME's rebuild, and bundling them
// means unticking one silently changes the cost profile of the other. Two independent switches
// for two independent costs is the honest arrangement.
//
// Default true, like its sibling, so unticking is the opt-in and nothing changes until then.
// "Freely" rather than "reload" because the thing being controlled is how often the panel
// re-renders its views, not whether a fetch happens.
//
// Honoured by production_panel_probe::hk_update_views. See the coalescing note there for what it
// does and, importantly, what it deliberately does NOT do (it never leaves the panel stale).
// Default FALSE, so coalescing is on without anyone touching the menu. This is the third copy of
// this default - the CheckboxValue ctor in HideoutAutomationModule and the current-value slot in
// ta/configs/legit_sel are the other two - and they must agree.
//
// It has to be the STATIC default, not just the config, because this flag is only ever written from
// HideoutAutomationModule::draw_menu_extra(), and menu.cpp calls that from inside draw_card_frame's
// body lambda, which is guarded by `if (!collapsed)`. A folded card never calls it, so a config
// value alone is silently ignored and the static initialiser is what actually runs. That is what
// made viewCallsDropped=0 ambiguous for several runs: the config said one thing and the folded card
// used the other.
inline bool& hideout_rebuild_freely_flag() {
    static bool freely = false;
    return freely;
}

inline void hideout_set_rebuild_freely(const bool freely) {
    // CHANGE-GATED, and that is the whole point of it.
    //
    // This setter is called from draw_menu_extra() every frame the card is unfolded, so an
    // unconditional line would flood the log. But this file had NO logging at all, and that is how
    // the 2026-10-01 21:04 session became unreadable: the run started coalescing=on and reached
    // viewCallsDropped=110, then the report line read coalescing=off from the second ShowContents
    // onward with the drop count frozen at 110. The config file was provably untouched (same bytes,
    // same mtime) and both of its slots said false, so the only way get_value() could return true is
    // that something set the checkbox in memory - and with the setter unlogged there was no way to
    // tell a stray UI toggle from a config load reading the wrong slot.
    //
    // Gated so the line appears on the transition and then stays quiet, which makes the moment
    // attributable instead of merely inferable from two counters that stopped moving.
    if (hideout_rebuild_freely_flag() != freely) {
        logger::info(std::string("hideout-knob: rebuild_freely ") + (freely ? "true" : "false")
            + " -> coalescing " + (freely ? "off" : "on")
            + " (draw_menu_extra, config key hideout_rebuild_freely_cb)");
    }
    hideout_rebuild_freely_flag() = freely;
}

inline bool hideout_rebuild_freely() {
    return hideout_rebuild_freely_flag();
}

// ---------------------------------------------------------------------------
// Stick the crafting list to the station you are standing at
// ---------------------------------------------------------------------------
//
// A THIRD knob, again independent of the other two, and again for the same reason they are
// independent: this one changes WHICH rows are drawn, while its siblings change how often a
// fetch or a rebuild happens. Bundling a visibility filter into a cost knob means unticking
// the cost knob appears to also change the list.
//
// Default true, so the list follows the player by default. Off gives the whole hideout.
//
// Honoured in HideoutModule::refresh_hideout_state, against the scheme set latched by
// production_panel_probe::note_live_hideout.
inline bool& hideout_stick_station_flag() {
    static bool stick = true;
    return stick;
}

inline void hideout_set_stick_station(const bool stick) {
    // Change-gated for the same reason as hideout_set_rebuild_freely above: a station filter that
    // silently turns itself off looks exactly like a station filter that is not working, and the
    // two are indistinguishable from the card's contents alone.
    if (hideout_stick_station_flag() != stick) {
        logger::info(std::string("hideout-knob: stick_station ") + (stick ? "true" : "false")
            + " (draw_menu_extra, config key hideout_stick_station_cb)");
    }
    hideout_stick_station_flag() = stick;
}

inline bool hideout_stick_station() {
    return hideout_stick_station_flag();
}

// The scheme ids the player is currently looking at, and which station that is.
//
// Filled from ShowProduceView's `producer` argument - the ItemsProducerBase for the open panel -
// and read by the crafting-list filter. Both sides run on the game thread (the hook is the game's
// own UI call, the filter is the menu refresh), which is the same assumption the two memos above
// already make, so a plain static is the honest amount of machinery here. A mutex would imply a
// race that does not exist.
//
// EMPTY MEANS "NOT STICKING", and that is not the same as "the station offers nothing". The
// distinction matters: ShowProduceView only fires when a PRODUCTION station panel is open, so
// standing at the water plant produces no call at all. The set is then left holding the last
// production station seen rather than being cleared, which is what makes the filter stick
// instead of blinking off every time the player looks at something that is not a bench.
inline std::unordered_set<std::string>& hideout_viewed_station_schemes() {
    static std::unordered_set<std::string> ids;
    return ids;
}

inline int& hideout_viewed_station_area() {
    static int area = -1;
    return area;
}

inline size_t& hideout_recipe_count_ref() {
    static size_t count = 0;
    return count;
}

inline void hideout_set_recipe_count(const size_t count) {
    hideout_recipe_count_ref() = count;
}

inline size_t hideout_recipe_count() {
    return hideout_recipe_count_ref();
}

// ---------------------------------------------------------------------------
// Scheme labels, read from storage rather than from get_RequiredItems
// ---------------------------------------------------------------------------
//
// The 2026-09-28 field dump settled what get_RequiredItems was hiding. BaseHideoutScheme carries
//
//     requirements +0x48 : Requirement[]
//
// and get_RequiredItems() is a COMPUTED property returning `requirements.OfType<ItemRequirement>()`
// — which is exactly why it hands back a `<>OfTypeIterator>d__97` and why that iterator would not
// advance. The array was never the problem; the projection over it was.
//
// Reading the field directly is strictly better than the property, not merely a fallback:
//   * It is a FIELD read, so it costs no managed call. The old path paid get_RequiredItems plus
//     one call per requirement per scheme, and that is what the per-pass label budget existed to
//     throttle. Reading the array removes the reason for a budget on this half.
//   * It reaches elements the projection drops. OfType<T> silently discards every Requirement that
//     is not an ItemRequirement, so the old path could not have named those even if it worked.
//
// `Requirement` and `ItemRequirement` are DIFFERENT types and only the latter has get_ItemName /
// get_TemplateId (ISIL Assembly-CSharp/EFT/Hideout/ItemRequirement.txt). Requirement itself exposes
// just get_Type / get_SourceAreaType (…/Requirement.txt). So each element is asked for the
// ItemRequirement accessors and skipped when they do not resolve, which performs the OfType<T>
// test by capability instead of by type handle.

// The item a scheme PRODUCES, by name. Preferred over the requirement list because it is what you
// get rather than what you hand over.
//
// ProductionScheme carries `endProduct` (a MongoID value type) — proven by the field dump:
//     endProduct +0x50 : MongoID
//     isEncoded  +0x68 : Boolean
// ISIL lists only .ctor() for ProductionScheme, which is consistent with that: the class has no
// properties, so there is no accessor to call and the field is the only route. The MongoID is
// read with the same IL-verified 24-byte layout already used for JsonType.FlatItem._tpl.
//
// ScavCaseScheme instead has `endProducts` (a ScavProduct, +0x50) and CultistsScheme has neither,
// so both fall through to the requirement label. ScavProduct's shape needs its own dump and is not
// guessed at here.
inline std::string hideout_scheme_product_name(Il2CppObject* scheme) {
    if (!eft_api::is_il2cpp_object_likely_valid(scheme)) return {};
    Il2CppString* tpl = hideout_read_field<flat_item_tpl>(scheme, "endProduct").string_id;
    const std::string id = eft_api::try_read_il2cpp_string(tpl);
    if (id.empty()) return {};
    std::string name = eft_api::try_get_item_name_for_template_id(id);
    return name.empty() ? id : name;
}

// The requirement list read straight off the field: the same per-element naming the old walker
// did, minus the iterator.
inline std::string hideout_scheme_requirement_label(Il2CppObject* scheme) {
    Il2CppObject* array_obj = hideout_read_field<Il2CppObject*>(scheme, "requirements");
    if (!eft_api::is_il2cpp_object_likely_valid(array_obj)
        || !eft_api::is_readable_address(array_obj, sizeof(Il2CppObject))) return {};
    // `name` is unqualified, so the namespace prefix does not affect this test: the label ends in the
    // element-type marker either way.
    const std::string cls = hideout_class_label(array_obj->klass);
    if (cls.find("[]") == std::string::npos)
    {
        hideout_warn_once("req_not_array",
            "BaseHideoutScheme.requirements is a " + hideout_class_name(array_obj->klass)
                + ", not an array - the requirement label is unavailable");
        return {};
    }
    if (!eft_api::is_readable_address(array_obj, sizeof(Il2CppArray))) return {};

    std::string label;
    int seen = 0;
    int walked = 0;
    auto* array = reinterpret_cast<Il2CppArray*>(array_obj);
    for (size_t i = 0; i < array->max_length && seen < 3; ++i)
    {
        const auto* slot = reinterpret_cast<Il2CppObject**>(&array->data) + i;
        if (!eft_api::is_readable_address(slot, sizeof(Il2CppObject*))) break;
        Il2CppObject* requirement = *slot;
        if (!eft_api::is_il2cpp_object_likely_valid(requirement)) continue;
        if (!eft_api::is_readable_address(requirement, sizeof(Il2CppObject))) continue;
        ++walked;

        std::string name;
        const MethodInfo* get_name = hideout_cached_method(requirement->klass, "get_ItemName", 0);
        if (get_name && get_name->methodPointer)
            name = eft_api::try_read_il2cpp_string(
                static_cast<Il2CppString* (*)(Il2CppObject*)>(get_name->methodPointer)(requirement));
        if (name.empty())
        {
            const MethodInfo* get_tpl = hideout_cached_method(
                requirement->klass, "get_TemplateId", 0);
            if (get_tpl && get_tpl->methodPointer)
            {
                const std::string tpl = eft_api::try_read_il2cpp_string(
                    static_cast<Il2CppString* (*)(Il2CppObject*)>(
                        get_tpl->methodPointer)(requirement));
                if (!tpl.empty()) name = eft_api::try_get_item_name_for_template_id(tpl);
            }
        }
        // Neither accessor resolving means this element is a plain Requirement rather than an
        // ItemRequirement — precisely the element OfType<T> would have discarded.
        if (name.empty()) continue;
        ++seen;
        if (label.find(name) != std::string::npos) continue;
        if (!label.empty()) label += " + ";
        label += name;
    }
    if (walked == 0)
        hideout_warn_once("req_empty",
            "BaseHideoutScheme.requirements on " + hideout_class_name(scheme->klass)
                + " held no readable elements");
    return label;
}

// Flatten a ProductionSchemesCollection into a list. Reads the get_ProductionSchemes
// auto-property rather than a backing field, and takes each scheme's id from
// BaseHideoutScheme._id — the same string that keys HideoutInfo.Production and that
// ProducingItemController.SchemeId is set from.
//
// Only ordinary production schemes are read. get_ScavCaseSchemes and get_CultistsSchemes exist
// on the same collection and are deliberately skipped - see the source table below for why.
//
// `label_budget` bounds how many NOT-YET-LABELLED schemes this call will pay managed calls for.
// The collection is re-fetched from the session on every recipe refresh, so the scheme objects
// are new each time and nothing about them can be cached by identity — but the LABEL is a pure
// function of the id, so it is memoised on the id and the budget only ever pays for ids that
// have never been seen. Exceeding the budget leaves work for the next call.
inline std::vector<hideout_scheme> hideout_read_schemes(Il2CppObject* collection,
    int label_budget = 32, bool* labels_pending = nullptr) {
    std::vector<hideout_scheme> out;
    if (labels_pending) *labels_pending = false;
    if (!eft_api::is_il2cpp_object_likely_valid(collection)) return out;

    // Labels are a pure function of the scheme id, so they are memoised for the process
    // lifetime. Function-local so it is shared with the automation module, which reads the same
    // collection through this same function and would otherwise re-pay for every id twice.
    static std::unordered_map<std::string, std::string> label_cache;
    int unlabelled = 0;

    struct source
    {
        const char* getter;
        hideout_scheme_kind kind;
    };
    // ONLY the ordinary production schemes. ScavCaseScheme (5) and CultistsScheme (1) are
    // deliberately not read.
    //
    // They are excluded on purpose, not because they are unreadable: both are RNG on the way in
    // AND on the way out, so there is nothing stable to show. A scav case yields a random item
    // from a random seed, and the cultist recipe rolls its own outcome, which means the label,
    // the requirement list and the station are all describing a lottery ticket rather than a
    // craftable recipe. Tracking them produced three visible artefacts and no information:
    //   * the mid-walk staleness on the ScavCaseScheme[] array (the 2nd of 5 elements reading
    //     as class=<not-a-class>, with eight "field skipped; class pointer is not a usable
    //     class" warnings behind it). This is a SYMPTOM, not the crash it was once described as.
    //     The crash this walk actually had was a pointer-arithmetic stride bug - the element
    //     walk advanced by sizeof(void*) while the elements are Il2CppObject, 16 bytes - and
    //     excluding these schemes did not fix it. It was still worth excluding them for the two
    //     reasons below, but the exclusion must not be remembered as the crash fix, or the next
    //     stride mistake will be attributed to a change that had nothing to do with it;
    //   * areaType=0 on all six, which the EAreaType table then labelled "Вентиляция", so six
    //     lotteries were shown as sitting at the ventilation shaft;
    //   * and a share of the "1 still a raw id" label that never resolved.
    //
    // Excluding them also removes the ONLY schemes with areaType 0, so the histogram and the
    // station attribution stop having to special-case zero as "not a station".
    static const source sources[] = {
        {"get_ProductionSchemes", hideout_scheme_kind::single},
    };

    hideout_warn_once("rng_schemes_skipped",
        "scav-case and cultist schemes are not listed: both are RNG in and out, so a row for "
        "them describes a lottery rather than a recipe (6 schemes dropped, 260 -> 254)");

    for (const source& src : sources)
    {
        const MethodInfo* getter = hideout_cached_method(collection->klass, src.getter, 0);
        if (!getter || !getter->methodPointer) continue;
        Il2CppObject* array = static_cast<Il2CppObject* (*)(Il2CppObject*)>(
            getter->methodPointer)(collection);
        if (!array) continue;

        Il2CppObject* array_obj = reinterpret_cast<Il2CppObject*>(array);
        const size_t before = out.size();
        // Recorded as the walk goes, so the per-scheme sample below reports on the same pointers
        // this loop validated rather than re-deriving them from the raw array (see the note there
        // for what that re-derivation cost).
        std::vector<Il2CppObject*> visited;
        visited.reserve(64);
        hideout_iterate_collection(array_obj, src.getter, [&](Il2CppObject* scheme) {
            visited.push_back(scheme);
            const std::string id = eft_api::try_read_il2cpp_string(
                hideout_read_field<Il2CppString*>(scheme, "_id"));
            if (id.empty()) return;
            hideout_scheme entry;
            entry.id = id;
            entry.kind = src.kind;
            // The station, straight off the scheme. Read before the label work so it is captured
            // even for a scheme whose label is served from the cache, and published in both the
            // entry and the side memo the cross-check reads.
            entry.area_type = hideout_read_field<int>(scheme, "areaType", -1);
            hideout_scheme_area_types()[id] = entry.area_type;
            // Precedence: the produced item first, because it is what the recipe MAKES and it
            // costs nothing to read (a field plus the localizer), so all ~254 ProductionSchemes
            // resolve in the FIRST pass with no budget consumed at all. Only schemes with no
            // endProduct — the scav cases and the cultist recipe — fall through to the requirement
            // list, and that is the only remaining path that pays managed calls, so it is the only
            // one the budget still has to throttle.
            entry.label = hideout_scheme_product_name(scheme);
            if (entry.label.empty())
            {
                const auto cached = label_cache.find(id);
                if (cached != label_cache.end())
                {
                    entry.label = cached->second;
                }
                else if (label_budget > 0)
                {
                    // Only new ids reach the managed path, and only while there is budget left.
                    --label_budget;
                    entry.label = hideout_scheme_requirement_label(scheme);
                    label_cache.emplace(id, entry.label);
                    if (entry.label.empty()) ++unlabelled;
                }
            }
            out.push_back(std::move(entry));
        });
        // Per-getter counts rather than a line per getter: three getters at one line each was
        // nine log lines (getter, array shape, yield count) for information that fits in one.
        hideout_trace(std::string(src.getter) + " -> class="
            + hideout_class_label(array_obj->klass) + ", "
            + std::to_string(out.size() - before) + " scheme(s)");

        // The sample below reports on `visited`, recorded as the walk went, rather than
        // re-deriving element pointers out of the raw array. IT USED TO RE-DERIVE THEM, and that
        // was a live crash. The old line was:
        //
        //     Il2CppObject* scheme = *reinterpret_cast<Il2CppObject**>(
        //                                &reinterpret_cast<Il2CppArray*>(array_obj)->data)
        //         + (i - before);
        //
        // which dereferences to an Il2CppObject* and then POINTER-ADDS. Il2CppObject is 16 bytes
        // and array elements are 8-byte pointers, so the stride was doubled: element 0 was read
        // correctly and every element after it came from the wrong slot. The 2026-09-29 21:57 crash
        // is that, on element 1 of 254 - the disassembly shows the doubled stride (`shl rcx, 4`),
        // the `sampled < 6` bound (`cmp edx, 6`), and a faulting `cmp qword ptr [rax+0x10], 0` on a
        // MISALIGNED rax (0x5656D7C3) read from two slots along. The "<not-a-class> scheme sample"
        // immediately before the fault in the log is this block printing a pointer it invented.
        //
        // The `is_il2cpp_object_likely_valid` guard did not save it either: that function itself
        // walks obj->klass->name, so on a wild pointer it faults before it can return a verdict.

        // ---- per-scheme field sample ---------------------------------------
        //
        // The first few schemes of each kind, with EVERY field the 2026-09-28 dump says exists.
        // The areaType histogram above says whether the numbers look like stations; this says
        // what the rest of the scheme carries, which is what a station prefix would have to be
        // built from if areaType turns out to be something else.
        //
        // Bounded, and `sampled` is static so the whole thing runs once per process. This is a
        // diagnostic, not a data source: the recipe list comes from `out` above.
        static int sampled = 0;
        if (sampled < 6)
        {
            for (size_t i = before; i < out.size() && sampled < 6; ++i, ++sampled)
            {
                if (i - before >= visited.size()) break;
                Il2CppObject* scheme = visited[i - before];
                // hideout_class_usable, not is_il2cpp_object_likely_valid: it probes before it
                // dereferences, and everything below reads scheme->klass and its fields.
                if (!hideout_class_usable(scheme ? scheme->klass : nullptr)) continue;
                const int area = out[i].area_type;
                const std::string station = area >= 0 ? hideout_localize_area_name(area) : "";
                logger::info("hideout: scheme sample [" + std::string(src.getter) + "] "
                    + out[i].id
                    + " class=" + hideout_class_label(scheme->klass)
                    + " areaType=" + std::to_string(area)
                    + " station='" + station + "'"
                    + " Level=" + std::to_string(hideout_read_field<int>(scheme, "Level", -1))
                    + " count=" + std::to_string(hideout_read_field<int>(scheme, "count", -1))
                    + " limit=" + std::to_string(hideout_read_field<int>(scheme, "productionLimitCount", -1))
                    + " locked=" + std::to_string(hideout_read_field<bool>(scheme, "locked"))
                    + " continuous=" + std::to_string(hideout_read_field<bool>(scheme, "continuous"))
                    + " codeProd=" + std::to_string(hideout_read_field<bool>(scheme, "isCodeProduction"))
                    + " fuelAllTime=" + std::to_string(hideout_read_field<bool>(scheme, "needFuelForAllProductionTime"))
                    + " prodTime=" + std::to_string(hideout_read_field<float>(scheme, "productionTime", -1.0f))
                    + " label='" + out[i].label + "'");
            }
        }
    }

    // Report what the label pass achieved, once per call rather than once per scheme. The
    // interesting number is not "how many are labelled" but "is there more to do", because that
    // is what tells the caller to come back immediately instead of waiting out its slow clock.
    //
    // label_cache is process-wide and shared with the automation module, so it can legitimately
    // hold MORE ids than this call saw. The deferred count is therefore computed signed, not as
    // an unsigned subtraction that would wrap.
    const int cached_total = static_cast<int>(label_cache.size());
    const int seen_here = static_cast<int>(out.size());
    int deferred = 0;
    for (const hideout_scheme& scheme : out)
        if (scheme.label.empty() && label_cache.find(scheme.id) == label_cache.end()) ++deferred;
    hideout_trace("labels: " + std::to_string(cached_total) + " cached, " + std::to_string(unlabelled)
        + " resolved to nothing this pass, " + std::to_string(deferred) + " deferred"
        + " (budget " + std::to_string(label_budget) + ", " + std::to_string(seen_here) + " seen)");

    // ---- station diagnostic ------------------------------------------------
    //
    // The question this answers: does BaseHideoutScheme.areaType actually identify the station a
    // recipe belongs to, and if so does it agree with the station we can derive independently from
    // AreaInfo.LastRecipe?
    //
    // Deliberately a SUMMARY, not a line per scheme. 260 schemes would be 260 lines on the first
    // pass and would bury everything else in the log, which is the mistake the recipe list already
    // made once. So: one histogram line, plus a bounded sample that carries every field we know
    // how to read off a scheme, so one run shows the whole shape rather than just the one field
    // being tested.
    //
    // The three counts are the ones that separate the failure modes:
    //   unresolved (-1)  the field name is wrong, or it is not a field — a NAMING failure
    //   distinct values  how many different stations the catalogue spans — 1 would mean the field
    //                    is a constant and is not a station at all
    //   out of EAreaType a value that localizes to nothing, i.e. not a real station number
    // None of those three requires a second run to interpret.
    {
        int unresolved = 0;
        int zero = 0;
        int off_enum = 0;
        int lowest = 0;
        int highest = 0;
        bool first = true;
        std::map<int, int> histogram;
        for (const hideout_scheme& scheme : out)
        {
            if (scheme.area_type < 0)
            {
                ++unresolved;
                continue;
            }
            if (scheme.area_type == 0) ++zero;
            ++histogram[scheme.area_type];
            if (first)
            {
                lowest = highest = scheme.area_type;
                first = false;
            }
            else
            {
                if (scheme.area_type < lowest) lowest = scheme.area_type;
                if (scheme.area_type > highest) highest = scheme.area_type;
            }
            // LocalizeAreaName is the game's own mapping, so an unresolvable number is evidence
            // the value is not an EAreaType — and it costs no managed call after the first,
            // because hideout_localize_area_name memoises per area type.
            if (hideout_localize_area_name(scheme.area_type).empty()) ++off_enum;
        }
        logger::info("hideout: scheme areaType -> " + std::to_string(out.size()) + " scheme(s), "
            + std::to_string(unresolved) + " unresolved, "
            + std::to_string(zero) + " zero, "
            + std::to_string(histogram.size()) + " distinct value(s), range "
            + std::to_string(first ? 0 : lowest) + ".." + std::to_string(highest) + ", "
            + std::to_string(off_enum) + " not an EAreaType");
        // The histogram, WITH the localized name for each value rather than the number alone.
        // The number on its own is not interpretable: EAreaType has no name table in the ISIL dump
        // (LocalizationExtensions.LocalizeAreaName is method-body-only and its body is truncated
        // before the string table), so "10x104" cannot be turned into a station name from the
        // reference tree. The game's own localizer can, and it already ran for the "not an
        // EAreaType" count above, so the name is free here.
        //
        // Capped at 12 entries; a full dump would be unreadable, and the tail is the long tail of
        // one-recipe stations anyway.
        std::string hist;
        int shown = 0;
        for (const auto& [value, count] : histogram)
        {
            if (shown >= 12)
            {
                hist += ", ...";
                break;
            }
            if (!hist.empty()) hist += ", ";
            hist += std::to_string(value) + "=" + hideout_localize_area_name(value)
                + " x" + std::to_string(count);
            ++shown;
        }
        if (!hist.empty()) logger::info("hideout: scheme areaType histogram: " + hist);
    }

    if (labels_pending) *labels_pending = deferred > 0;
    return out;
}

// ---------------------------------------------------------------------------
// Menu-operation context (outside a raid, i.e. in the hideout itself)
// ---------------------------------------------------------------------------
//
// ISIL: EFT.MainMenuShowOperation's constructor stores its IEftSession into
// `this._session` and the EFT.Profile it was handed into `this._profile`
// (MainMenuShowOperation ISIL lines 63 and 82). That pair is the whole reason this
// automation can run at all: outside a raid there is no main player, so
// player.get_Profile() — the only Profile route the rest of the codebase uses —
// does not exist. The menu operation carries both.

// Whether the player currently has the hideout loaded. ISIL:
// EFT.TarkovApplication.get_HideoutControllerAccess() returns the HideoutController,
// whose `_hideoutGameLoader` field holds the loader, and
// HideoutGameLoader.get_IsLoaded() is literally `this._playerOwner != null`.
inline bool hideout_is_loaded(Il2CppObject* application) {
    if (!application || !application->klass) return false;
    const auto get_controller = hideout_cached_method(application->klass, "get_HideoutControllerAccess", 0);
    if (!get_controller || !get_controller->methodPointer) return false;
    Il2CppObject* controller = static_cast<Il2CppObject* (*)(Il2CppObject*)>(
        get_controller->methodPointer)(application);
    if (!controller) return false;

    Il2CppObject* loader = hideout_read_field<Il2CppObject*>(controller, "_hideoutGameLoader");
    if (!loader) return false;

    const auto is_loaded = hideout_cached_method(loader->klass, "get_IsLoaded", 0);
    if (!is_loaded || !is_loaded->methodPointer) return false;
    return static_cast<bool (*)(Il2CppObject*)>(is_loaded->methodPointer)(loader);
}

// The menu operation currently backing the hideout, or null.
inline Il2CppObject* hideout_menu_operation(Il2CppObject* application) {
    return hideout_read_field<Il2CppObject*>(application, "_menuOperation");
}

// IEftSession for the open menu operation, or null. Every production verb below lives
// on this interface (ISIL EFT/IEftSession.txt).
inline Il2CppObject* hideout_session(Il2CppObject* menu_operation) {
    return hideout_read_field<Il2CppObject*>(menu_operation, "_session");
}

// The Profile behind the open menu operation, or null. Reached only outside a raid —
// see the note above.
inline Il2CppObject* hideout_menu_profile(Il2CppObject* menu_operation) {
    return hideout_read_field<Il2CppObject*>(menu_operation, "_profile");
}

// ---------------------------------------------------------------------------
// Stash capacity
// ---------------------------------------------------------------------------
//
// Before asking the server to hand over a finished production, check that the result could
// physically land in the stash. A rejected take is not free: the server refuses, the
// production stays flagged AvailableForFinish, and a naive loop re-requests it every tick
// forever. Two mechanisms guard against that, and this is the first.
//
// The verdict is deliberately CONSERVATIVE-IN-FORM, OPTIMISTIC-IN-PACKING:
//
//   * It compares total cells needed against total free cells. It does NOT model the grid's
//     packing, so a fragmented stash can report "fits" and still be refused. That direction
//     is safe because the second mechanism (bounded, backed-off retries) covers it.
//   * "unknown" is a first-class answer. If the factory, the stash, the grid dimensions or a
//     template's size cannot be read, the check declines to guess and the caller proceeds —
//     an unreadable capacity must not silently block collection forever.
//
// Route (ISIL): Profile.get_InventoryInfo() -> Inventory.Stash -> Stash.get_Grid();
// Grid exposes get_GridWidth()/get_GridHeight(); the contents are CompoundItem.Slots, each
// read through get_ContainedItem() and then Item.get_Width()/get_Height().

enum class hideout_space_verdict {
    fits,
    too_full,
    unknown,
};

// Total cells the production's Products would occupy, plus how many stacks. False when any
// stack's size is unresolved — the caller must then treat the whole verdict as unknown.
inline bool hideout_result_cells(Il2CppObject* production_data, int& total_cells, int& stacks) {
    total_cells = 0;
    stacks = 0;
    Il2CppObject* products = hideout_read_field<Il2CppObject*>(production_data, "Products");
    if (!eft_api::is_il2cpp_object_likely_valid(products)) return false;

    const char* cls = (products->klass && products->klass->name) ? products->klass->name : "";
    if (!strstr(cls, "[]")) return false;

    auto* array = reinterpret_cast<Il2CppArray*>(products);
    for (size_t i = 0; i < array->max_length; ++i)
    {
        Il2CppObject* flat = reinterpret_cast<Il2CppObject**>(&array->data)[i];
        if (!eft_api::is_il2cpp_object_likely_valid(flat)) continue;
        const std::string tpl = eft_api::try_read_il2cpp_string(
            hideout_read_field<Il2CppString*>(flat, "_tpl"));
        if (tpl.empty()) continue;

        int width = 0;
        int height = 0;
        if (!game_items::dimensions(tpl, width, height)) return false;
        total_cells += width * height;
        ++stacks;
    }
    return true;
}

// Free cells in the player's stash, as capacity minus the footprint of what is in it.
// False when the stash or its grid cannot be read.
inline bool hideout_stash_free_cells(Il2CppObject* profile, int& free_cells) {
    free_cells = 0;
    if (!profile || !profile->klass) return false;

    const MethodInfo* get_inventory = hideout_cached_method(profile->klass, "get_InventoryInfo", 0);
    if (!get_inventory || !get_inventory->methodPointer) return false;
    Il2CppObject* inventory = static_cast<Il2CppObject* (*)(Il2CppObject*)>(
        get_inventory->methodPointer)(profile);
    if (!eft_api::is_il2cpp_object_likely_valid(inventory)) return false;

    Il2CppObject* stash = hideout_read_field<Il2CppObject*>(inventory, "Stash");
    if (!eft_api::is_il2cpp_object_likely_valid(stash)) return false;

    const MethodInfo* get_grid = hideout_cached_method(stash->klass, "get_Grid", 0);
    if (!get_grid || !get_grid->methodPointer) return false;
    Il2CppObject* grid = static_cast<Il2CppObject* (*)(Il2CppObject*)>(get_grid->methodPointer)(stash);
    if (!eft_api::is_il2cpp_object_likely_valid(grid)) return false;

    const MethodInfo* get_width = hideout_cached_method(grid->klass, "get_GridWidth", 0);
    const MethodInfo* get_height = hideout_cached_method(grid->klass, "get_GridHeight", 0);
    if (!get_width || !get_width->methodPointer || !get_height || !get_height->methodPointer)
        return false;

    const int columns = static_cast<int (*)(Il2CppObject*)>(get_width->methodPointer)(grid);
    const int rows = static_cast<int (*)(Il2CppObject*)>(get_height->methodPointer)(grid);
    if (columns <= 0 || rows <= 0) return false;
    int capacity = columns * rows;

    // Contents: CompoundItem.Slots, each holding at most one item. The stash does not nest,
    // so one level is the whole footprint.
    Il2CppObject* slots = hideout_read_field<Il2CppObject*>(stash, "Slots");
    if (eft_api::is_il2cpp_object_likely_valid(slots))
    {
        const char* slot_cls = (slots->klass && slots->klass->name) ? slots->klass->name : "";
        if (strstr(slot_cls, "[]"))
        {
            auto* slot_array = reinterpret_cast<Il2CppArray*>(slots);
            for (size_t i = 0; i < slot_array->max_length; ++i)
            {
                Il2CppObject* slot = reinterpret_cast<Il2CppObject**>(&slot_array->data)[i];
                if (!eft_api::is_il2cpp_object_likely_valid(slot)) continue;
                const MethodInfo* contained = hideout_cached_method(slot->klass, "get_ContainedItem", 0);
                if (!contained || !contained->methodPointer) continue;
                Il2CppObject* item = static_cast<Il2CppObject* (*)(Il2CppObject*)>(
                    contained->methodPointer)(slot);
                if (!eft_api::is_il2cpp_object_likely_valid(item)) continue;

                const MethodInfo* item_w = hideout_cached_method(item->klass, "get_Width", 0);
                const MethodInfo* item_h = hideout_cached_method(item->klass, "get_Height", 0);
                if (!item_w || !item_w->methodPointer || !item_h || !item_h->methodPointer)
                    return false; // an item of unknown size makes the total unknowable
                capacity -= static_cast<int (*)(Il2CppObject*)>(item_w->methodPointer)(item)
                    * static_cast<int (*)(Il2CppObject*)>(item_h->methodPointer)(item);
            }
        }
    }

    free_cells = capacity > 0 ? capacity : 0;
    return true;
}

// Can this production's result land in the stash?
inline hideout_space_verdict hideout_result_fits(Il2CppObject* profile,
    Il2CppObject* production_data) {
    int needed = 0;
    int stacks = 0;
    if (!hideout_result_cells(production_data, needed, stacks)) return hideout_space_verdict::unknown;
    if (stacks == 0) return hideout_space_verdict::fits; // nothing to place

    int free_cells = 0;
    if (!hideout_stash_free_cells(profile, free_cells)) return hideout_space_verdict::unknown;

    return needed <= free_cells ? hideout_space_verdict::fits : hideout_space_verdict::too_full;
}

//
// ---------------------------------------------------------------------------
// Async session results
// ---------------------------------------------------------------------------
//
// Every hideout verb that can fail returns Task<Comfort.Common.IResult>. Handing back a
// non-null Task only proves the request was DISPATCHED — not that the server accepted it.
// Discarding the Task (as an earlier revision did) is why a collect could report success in
// the log while the game showed nothing: the failure lived in the result object nobody read.
//
// Task<T>.Result blocks while the task is pending, so IsCompleted is checked first and a
// faulted task is never asked for its result (that rethrows in managed code).

enum class hideout_task_state {
    pending,   // still running
    succeeded, // settled, IResult.Succeed == true
    failed,    // settled with an error, or faulted
};

// Inspect a Task<T>. `result` receives the settled value (the IResult for the production
// verbs, the ProductionSchemesCollection for GetProductionRecipes) and `error` the server's
// message on failure. `result` is only meaningful when the return is not `pending`.
inline hideout_task_state hideout_poll_task(Il2CppObject* task, Il2CppObject*& result,
    std::string& error) {
    result = nullptr;
    if (!eft_api::is_il2cpp_object_likely_valid(task)) return hideout_task_state::failed;

    const MethodInfo* is_completed = hideout_cached_method(task->klass, "get_IsCompleted", 0);
    if (!is_completed || !is_completed->methodPointer) return hideout_task_state::pending;
    if (!static_cast<bool (*)(Il2CppObject*)>(is_completed->methodPointer)(task))
        return hideout_task_state::pending;

    // Reached at least once, so the task is settled. Logged because the class identity is the
    // thing that decides whether the three lookups below can work at all: they are declared on
    // System.Threading.Tasks.Task and INHERITED by the closed generic we are holding, which is
    // why hideout_cached_method walks parents.
    hideout_trace(std::string("task settled, class=") + hideout_class_label(task->klass));

    // A faulted task's Result getter rethrows; report it as a failure without touching it.
    const MethodInfo* is_faulted = hideout_cached_method(task->klass, "get_IsFaulted", 0);
    if (is_faulted && is_faulted->methodPointer
        && static_cast<bool (*)(Il2CppObject*)>(is_faulted->methodPointer)(task))
    {
        error = "task faulted";
        return hideout_task_state::failed;
    }

    const MethodInfo* get_result = hideout_cached_method(task->klass, "get_Result", 0);
    if (!get_result || !get_result->methodPointer) return hideout_task_state::pending;
    Il2CppObject* value = static_cast<Il2CppObject* (*)(Il2CppObject*)>(
        get_result->methodPointer)(task);
    if (!eft_api::is_il2cpp_object_likely_valid(value))
    {
        error = "no result object";
        return hideout_task_state::failed;
    }
    result = value;

    // The production verbs return Comfort.Common.IResult: get_Succeed(), get_Failed(),
    // get_Error() (ISIL Comfort/Comfort/Common/IResult.txt). A non-IResult result (a
    // collection, say) has no such method, which is how this doubles as "did it succeed".
    const MethodInfo* succeed = hideout_cached_method(value->klass, "get_Succeed", 0, /*quiet=*/true);
    if (!succeed || !succeed->methodPointer) return hideout_task_state::succeeded;
    if (static_cast<bool (*)(Il2CppObject*)>(succeed->methodPointer)(value))
        return hideout_task_state::succeeded;

    error = "server reported failure";
    const MethodInfo* get_error = hideout_cached_method(value->klass, "get_Error", 0);
    if (get_error && get_error->methodPointer)
    {
        Il2CppString* message = static_cast<Il2CppString* (*)(Il2CppObject*)>(
            get_error->methodPointer)(value);
        if (message)
        {
            const std::string text = il2utils::conv_string(message);
            if (!text.empty()) error = text;
        }
    }
    return hideout_task_state::failed;
}

// Mirrors EFT.Hideout.ProductionData, the Dictionary<string, ProductionData> value on
// EFT.HideoutInfo. ISIL pins the field names and widths; the offsets it shows
// (ItemsProducerBase / ProducingItemController) are:
//   Progress 0x10 float, StartTimestamp 0x14 int, ProductionTime 0x18 int,
//   InProgress 0x1C bool, RecipeId 0x20 string, AvailableForFinish 0x41 bool.
// Only the names are resolved at runtime — the offsets are never hardcoded, so a
// server-side layout change cannot silently misread a slot.
struct ProductionInfo
{
    std::string recipe_id;
    // Localized name of the item(s) this recipe produces, e.g. "Bitcoin". Empty when the
    // server sent no product list. This is the ONLY human label available: ISIL confirms
    // EFT.Hideout.BaseHideoutScheme carries just _id, Level, productionTime and requirements
    // — no name and no localization accessor anywhere in the hideout namespace, so the game
    // itself must be resolving a scheme's title from what it produces.
    std::string product_label;
    // Completion as a 0..1 fraction, ALREADY CLAMPED. Computed from StartTimestamp and
    // ProductionTime rather than read from the server, because the server's own Progress field is
    // not a ratio — see the derivation in hideout_read_production.
    float progress = 0.0f;
    // The raw, un-normalized ProductionData.Progress exactly as the server sent it. It is ELAPSED
    // SECONDS, not a ratio — see the derivation in hideout_read_production. Dividing it by 100 was
    // what made bars read 2400%.
    float raw_progress = 0.0f;
    // production_time - raw_progress, in seconds. Negative when the job is past its nominal
    // duration; the caller clamps. Derived rather than computed from StartTimestamp, which the
    // 2026-09-27 log showed is not in seconds-since-epoch.
    int seconds_left = 0;
    // GetTickCount64() at the moment raw_progress was read, so the countdown can be advanced
    // locally between server updates — see production_view_now. Zero means the record did not
    // come off this machine's clock, which disables the extrapolation rather than guessing.
    ULONGLONG observed_ms = 0;
    bool in_progress = false;
    int production_time = 0;     // total seconds
    int64_t start_timestamp = 0; // unix seconds (widened: the game field is a 32-bit int)
    bool available_for_finish = false;
    bool interrupted = false;
    // The managed ProductionData this record was read from. Valid only for as long as the
    // hideout is loaded — it is carried so the stash-capacity check can read the same
    // Products list without a second dictionary lookup, and must not be dereferenced on a
    // later tick.
    Il2CppObject* data = nullptr;
};

// JsonType.FlatItem._tpl is an EFT.MongoID, NOT a string.
//
// ISIL, Assembly-CSharp/JsonType/FlatItem.txt, Clone() disassembly:
//     movups xmm1,[rdi+28h]        ; 16 bytes
//     movsd  xmm0,[rdi+38h]        ; +8 more  -> a 24-byte copy of `this._tpl`
//     movups [rbx+28h],xmm1
//     movsd  [rbx+38h],xmm0
// and ISIL line 56:  Move v41._tpl (EFT.MongoID), this._tpl (EFT.MongoID)
//
// Reading it as an Il2CppString* handed the low 8 bytes of a struct to
// eft_api::try_read_il2cpp_string, which correctly rejected them as unmapped. That is why every
// production label came back empty: the guard was working, the TYPE was wrong.
//
// MongoID = { uint32 _timeStamp; uint64 _counter; Il2CppString* _stringID } (24 bytes; same
// shape and same IL-verified layout as game_items::mongo_id). _stringID is the runtime's own
// cached Convert.ToString(_timeStamp, _counter), i.e. exactly the 24-hex template id that
// game_items::entry::id holds and that eft_api::try_get_item_name_for_template_id expects, so
// the cached string is read as-is rather than reformatted.
//
// Declared here rather than reusing game_items::mongo_id: game_item_db.h states it must stay
// independent of eft_api, and this header sits on the eft_api side of that line.
struct flat_item_tpl; // defined above hideout_scheme_product_name, which reads endProduct

// Read the produced-item names out of ProductionData.Products (JsonType.FlatItem[]).
// Distinct templates are joined so a multi-product recipe reads sensibly.
inline std::string hideout_read_product_label(Il2CppObject* data) {
    Il2CppObject* products = hideout_read_field<Il2CppObject*>(data, "Products");
    // is_il2cpp_object_likely_valid only proves non-null, so the class name is resolved through
    // the guarded label and strstr never walks an unmapped string. `products` itself is probed
    // too: it came out of a field on an object we reflected by name, and the deref below is
    // otherwise the first unguarded read on this path.
    if (!eft_api::is_il2cpp_object_likely_valid(products)
        || !hideout_readable(products, sizeof(Il2CppObject))) return {};
    const std::string cls = hideout_class_label(products->klass);
    if (cls.find("[]") == std::string::npos) return {};

    std::string label;
    int seen = 0;
    int resolved = 0;
    // max_length comes straight off the array header, so the header is probed before the read.
    if (!hideout_readable(products, sizeof(Il2CppArray))) return {};
    auto* array = reinterpret_cast<Il2CppArray*>(products);
    for (size_t i = 0; i < array->max_length && seen < 4; ++i)
    {
        // Every step of the element read is probed. The array slot can hand back something that is
        // not an object, and is_il2cpp_object_likely_valid itself walks obj->klass->name without
        // probing either hop -- so the element is validated here rather than trusted.
        //
        // Through the per-walk memo rather than eft_api::is_readable_address. This walk is on the
        // 1 Hz path and used to make up to three kernel queries per product element on top of the
        // two inside the string read; at the ~190 us a query actually costs here, that was most
        // of the production half of the stall. Same question, same answer, once per element.
        const auto* slot = reinterpret_cast<Il2CppObject**>(&array->data) + i;
        if (!hideout_readable(slot, sizeof(Il2CppObject*))) break;
        Il2CppObject* flat = *slot;
        if (!flat) continue;
        if (!hideout_readable(flat, sizeof(Il2CppObject))) continue;
        if (!hideout_readable(flat->klass, sizeof(void*))) continue;
        if (!flat->klass->name) continue;

        const std::string tpl = hideout_read_string(
            hideout_read_field<flat_item_tpl>(flat, "_tpl").string_id);
        if (tpl.empty()) continue;
        ++resolved;
        // The template id IS the localization key convention the rest of the project uses
        // (eft_api::try_get_item_name_for_template_id, "<Id> Name" then bare id).
        std::string name = eft_api::try_get_item_name_for_template_id(tpl);
        if (name.empty()) name = tpl;
        if (label.find(name) != std::string::npos) continue; // de-dupe repeated stacks
        if (!label.empty()) label += " + ";
        label += name;
        ++seen;
    }
    // A non-empty Products array whose _tpl never resolves means the field moved or changed
    // type, not that the recipe produces nothing. Worth one warning rather than a trace per
    // element -- this is what told us _tpl was a MongoId being read as a string.
    if (array->max_length > 0 && resolved == 0)
    {
        static std::unordered_map<std::string, bool> reported;
        if (reported.emplace(std::string(cls) + '/' + std::to_string(array->max_length), true).second)
            logger::warn("hideout: Products is " + std::string(cls) + " of length "
                + std::to_string(array->max_length) + " but no element exposed a usable "
                                                      "'_tpl' MongoId - production labels will stay empty");
    }
    return label;
}

// The instant a production's raw_progress was last SEEN TO MOVE, which is what the
// extrapolation in production_view_now has to measure its elapsed wall time from.
//
// WHY THIS IS NOT SIMPLY "the time of this read". production_view_now adds (now - observed_ms)
// to raw_progress so the bar advances between server pushes, and it was written on the stated
// assumption - recorded in its own comment - that the server pushes at least once a second,
// which is what bounds the extrapolation to one refresh interval. That assumption is false and
// the log says so unambiguously: on 2026-09-29 from 21:24:37 to 21:25:48, every one of ~70
// consecutive passes printed `elapsed=244.202026s` to the last digit, and `left=11942s`. The
// DTO is not advancing at all, which is consistent with this log's standing finding that
// Profile.Hideout is the HideoutInfo DTO rather than the live HideoutRepresentation, and with
// the game's own ProducingItemController copying that same unchanging productionData.Progress.
//
// With a frozen server value, re-stamping observed_ms on every read turned the extrapolation
// into a perfect one-second sawtooth: each pass displayed 244.2 climbing to 245.2, then the
// next pass discarded that second and began again. The countdown therefore never got past one
// second of progress and the bar never left 2.0% - which is exactly the reported "timer and
// percentage oscillate back and forward, stuck to one second".
//
// So the anchor moves only when the value MOVES:
//   * a server that ticks re-anchors on every push, so the server still wins immediately and
//     the display self-corrects precisely as designed;
//   * a server that is silent lets local wall time accumulate, which is the entire reason for
//     extrapolating between reads instead of just re-reading every frame.
//
// The comparison is exact float equality on purpose: "this value is bit-identical to last time"
// is precisely the question being asked, and an epsilon would silently re-anchor on a server
// that is advancing too slowly to see. One consequence is worth stating: a job that restarts at
// exactly the elapsed value the previous one ended on is indistinguishable from one that never
// moved, and would keep the older anchor until the server ticks. That costs a briefly-too-large
// elapsed reading which self-corrects, as against a permanently sawtoothing bar.
//
// Keyed by recipe id, stable for the life of a production. A finished job's entry is left behind
// and simply never matched again, and the map is bounded regardless.
inline ULONGLONG hideout_progress_anchor(const std::string& recipe_id, const float raw_progress,
    const ULONGLONG sampled_at) {
    if (recipe_id.empty()) return sampled_at;

    struct anchor_entry {
        float last_raw;
        ULONGLONG anchored_at;
    };
    static std::unordered_map<std::string, anchor_entry> anchors;

    const auto it = anchors.find(recipe_id);
    if (it != anchors.end() && it->second.last_raw == raw_progress) return it->second.anchored_at;

    // Bounded, so a long session cannot grow this without limit. Clearing costs a re-anchor,
    // which is the old behaviour - never a wrong number.
    if (anchors.size() >= 512) anchors.clear();
    anchors[recipe_id] = {raw_progress, sampled_at};
    return sampled_at;
}

inline ProductionInfo hideout_read_production(Il2CppObject* data) {
    ProductionInfo info;
    if (!eft_api::is_il2cpp_object_likely_valid(data)) return info;
    info.data = data;
    info.recipe_id = hideout_read_string(
        hideout_read_field<Il2CppString*>(data, "RecipeId"));
    info.raw_progress = hideout_read_field<float>(data, "Progress");
    info.in_progress = hideout_read_field<bool>(data, "InProgress");
    info.production_time = hideout_read_field<int>(data, "ProductionTime");
    info.start_timestamp = hideout_read_field<int>(data, "StartTimestamp", 0);
    info.available_for_finish = hideout_read_field<bool>(data, "AvailableForFinish");
    info.interrupted = hideout_read_field<bool>(data, "Interrupted");
    info.product_label = hideout_read_product_label(data);

    // Progress is NOT a 0..1 fraction — it is ELAPSED SECONDS, and the 2026-09-27 log settled how
    // to turn it into one.
    //
    // Logged sample: `raw=244.202026 elapsed/total -> 100.000000% (start=1765208473 total=12187)`.
    // Two facts fall out of that one line:
    //   * StartTimestamp 1765208473 is NOT a unix epoch value — against a September-2026 clock it is
    //     ~25 million seconds ago, so any fraction derived from it saturates immediately. That is
    //     why every bar in the card reads 100% and the countdowns are nonsense. The field exists
    //     and reads, but it is not in seconds-since-epoch, so it is not used for progress.
    //   * raw 244.2 against total 12187 is 2.0% — a four-minute job in a 3h23m production, which
    //     is exactly the shape of a real hideout production. So Progress and ProductionTime are
    //     both durations and the ratio is the fraction.
    //
    // ISIL agrees on the pair: ProducingItemController.UpdateFromProductionData copies
    // productionData.Progress into ProducingProcess.Progress and productionData.ProductionTime into
    // ProducingProcess.BaseProductionTime as two separate fields, never dividing them.
    info.progress = 0.0f;
    if (info.available_for_finish)
    {
        info.progress = 1.0f;
    }
    else if (info.production_time > 0 && info.raw_progress >= 0.0f)
    {
        const float fraction = info.raw_progress / static_cast<float>(info.production_time);
        info.progress = fraction < 0.0f ? 0.0f : (fraction > 1.0f ? 1.0f : fraction);
    }
    // Seconds of work left, from the same pair. Negative means the job is past its nominal
    // duration — a speed bonus, a reduction, or a server that has not yet flipped
    // AvailableForFinish — so the caller is expected to clamp rather than to show a minus.
    info.seconds_left = info.production_time > 0
        ? static_cast<int>(info.production_time - info.raw_progress)
        : 0;
    // Stamped last, so observed_ms is the instant the Progress value above was read rather than
    // the instant some later field was touched.
    //
    // Then moved BACK to the original anchor when the server value turns out not to have moved
    // at all, so the extrapolation accumulates instead of resetting every pass. Read
    // hideout_progress_anchor above before changing this back to a plain GetTickCount64.
    info.observed_ms = hideout_progress_anchor(
        info.recipe_id, info.raw_progress, GetTickCount64());
    return info;
}

// A production's progress and remaining time AS OF `now_ms`, for drawing.
//
// WHY THIS EXISTS: progress used to be drawn straight off the 1 Hz snapshot, and it looked
// frozen. That is not a cadence problem — re-reading more often cannot help, because what is
// being read is the server's own ProductionData.Progress, and the server refreshes that DTO on
// its own schedule. Between two server updates the field is a constant, so every re-read returns
// the identical number and both the bar and the HH:MM:SS text stand still. On a 12187 s job
// that reads as "hung".
//
// So the countdown is extrapolated locally between server updates: raw_progress is anchored to
// observed_ms when read, and the wall time since then is added back here. The consequences are
// all deliberate:
//   * the display ticks at frame rate with no extra managed calls — this is arithmetic on values
//     already sitting in the snapshot;
//   * it self-corrects, because the next 1 Hz read overwrites both raw_progress and observed_ms,
//     so the server always wins immediately, and a server value that goes BACKWARDS (a
//     correction, or a new job reusing this record) re-anchors instead of being fought;
//   * it is clamped to production_time, so an over-running job sticks at 100% / 00:00:00 rather
//     than showing a negative countdown;
//   * it only advances while the job is genuinely running. available_for_finish means the server
//     says it is done and interrupted means it is not progressing, so in both cases wall time
//     passing must NOT be added — that would count up a job that is standing still.
//
// Everything is derived from raw_progress and production_time HERE, in one place, rather than
// falling back to the already-derived progress/seconds_left fields on the paths that cannot
// extrapolate. That distinction is not cosmetic: those two fields are computed by
// hideout_read_production, so reading them back made the answer depend on WHICH path was taken.
// A job running past its nominal duration came back with a negative seconds_left that way, and
// the row then rendered "--:--:--" instead of a finished-looking 00:00:00. Deriving
// unconditionally means the clamping below applies on every path, and the two stored fields are
// left to serve logging only.
//
// Being wrong is bounded and in the safe direction: the extrapolation is at most one refresh
// interval (1 s) ahead of the server, because that is how old the sample can be.
struct production_view
{
    float progress;
    int seconds_left;
};

inline production_view production_view_now(const ProductionInfo& info, ULONGLONG now_ms) {
    if (info.production_time <= 0) return {0.0f, 0};
    if (info.available_for_finish) return {1.0f, 0};

    float elapsed = info.raw_progress;
    if (info.in_progress && !info.interrupted
        && info.observed_ms != 0 && now_ms > info.observed_ms)
        elapsed += static_cast<float>(now_ms - info.observed_ms) / 1000.0f;

    const float total = static_cast<float>(info.production_time);
    if (elapsed < 0.0f) elapsed = 0.0f;
    if (elapsed > total) elapsed = total;

    production_view view;
    view.progress = elapsed / total;
    view.seconds_left = static_cast<int>(total - elapsed + 0.5f);
    return view;
}

inline production_view production_view_now(const ProductionInfo& info) {
    return production_view_now(info, GetTickCount64());
}

// Snapshot of every active production, or an empty vector when the hideout exposes no
// Production dictionary. A Dictionary's m_i_count covers freed slots too; a negative hash
// code marks an empty one, matching the unity::hashset convention in il2cpp/unity.h.
inline std::vector<ProductionInfo> hideout_read_productions(Il2CppObject* hideout) {
    std::vector<ProductionInfo> out;
    // Same reason as hideout_iterate_collection: a walk is beginning, so the previous walk's
    // addressability results are discarded rather than trusted. This walk is the second of the
    // two 1 Hz ones and was measured at ~52 ms across 278 probes.
    hideout_probe_cache_reset();
    Il2CppObject* production = hideout_read_field<Il2CppObject*>(hideout, "Production");
    if (!eft_api::is_il2cpp_object_likely_valid(production)) return out;

    // is_il2cpp_object_likely_valid only proves the pointers are non-null, not that they are
    // mapped, so the class name is still probed before strstr reads it.
    if (!eft_api::is_readable_address(production->klass, sizeof(Il2CppClass))) return out;
    const char* cls_name = (production->klass->name
                               && eft_api::is_readable_address(production->klass->name, 1))
        ? production->klass->name
        : "";
    if (!strstr(cls_name, "Dictionary"))
    {
        // Every bail-out in this function used to be silent, so "production disappeared" and
        // "the field name moved" looked identical from the log. Name the class we actually got.
        static std::unordered_map<std::string, bool> reported;
        const std::string label = cls_name[0] ? cls_name : "<unreadable class name>";
        if (reported.emplace(label, true).second)
            logger::warn("hideout: HideoutInfo.Production is a " + label
                + ", not a Dictionary - productions are unavailable");
        return out;
    }

    auto* dict = reinterpret_cast<unity::dict<Il2CppString*, Il2CppObject*>*>(production);
    const int count = dict->m_i_count;
    if (count <= 0 || !dict->m_p_entries) return out;
    if (!eft_api::is_readable_address(dict->m_p_entries, sizeof(Il2CppArray))) return out;
    // m_i_count is the number of OCCUPIED slots, including free-list tombstones, and it is
    // read off a struct cast by hand -- so it is clamped to the array that actually backs it
    // before anything indexes with it. Without this the loop below trusts a count that nothing
    // has checked against m_p_entries->max_length, and an over-count walks off the end of the
    // array into whatever the allocator put next.
    const auto* entries = reinterpret_cast<const unity::dict<Il2CppString*, Il2CppObject*>::entry*>(
        &dict->m_p_entries->data);
    const int capacity = static_cast<int>(dict->m_p_entries->max_length);
    if (capacity <= 0) return out;
    const int walk = (std::min)(count, capacity);
    hideout_trace("Production is " + std::string(cls_name) + ": m_i_count=" + std::to_string(count)
        + " entries.max_length=" + std::to_string(capacity) + " -> walking "
        + std::to_string(walk));
    if (walk != count)
        logger::warn("hideout: Production m_i_count (" + std::to_string(count)
            + ") exceeds its entries array (" + std::to_string(capacity) + "); clamped");

    out.reserve(static_cast<size_t>(walk));
    size_t live = 0;
    for (int i = 0; i < walk; ++i)
    {
        if (entries[i].m_i_hash_code < 0) continue;
        ++live;
        Il2CppObject* value = entries[i].m_t_value;
        // No per-entry trace here on purpose. The crash window was bracketed down to this walk
        // by the step markers in HideoutModule, so the per-entry lines no longer earn their
        // cost -- and write_line opens/closes the log file per line, so they were paying a
        // filesystem round trip on the game's main thread, once a second, per entry.
        ProductionInfo info = hideout_read_production(value);
        if (info.recipe_id.empty()) continue;
        out.push_back(std::move(info));
    }
    // One line for the whole walk: tombstones vs live entries is the thing worth seeing, since a
    // wrong m_i_count reads here as "live" entries that are really free-list slots.
    hideout_trace("walked " + std::to_string(walk) + " slot(s), " + std::to_string(live)
        + " occupied, " + std::to_string(out.size()) + " kept");
    // ...plus the first production's raw-vs-derived progress. The server's Progress is not a
    // ratio (see hideout_read_production), so if the bar ever looks wrong again, this one line
    // says whether the input or the derivation is at fault without needing a per-entry trace.
    //
    // It reports the RAW value and the VIEW side by side, and that is not redundancy. The raw
    // field is what the server holds and it does not move while the DTO is frozen, so on its own
    // this line looked identical before and after the re-anchor fix - it reports the snapshot as
    // stored, not what the player sees. `anchor=` is the real diagnostic: it is how long the
    // value has been unchanged, so it either grows steadily (fixed) or resets to ~0s every pass
    // (regressed). `view=` is the number actually on screen.
    if (!out.empty())
    {
        const ProductionInfo& first = out.front();
        const ULONGLONG now = GetTickCount64();
        const ULONGLONG anchor_age_ms = first.observed_ms && now > first.observed_ms
            ? now - first.observed_ms
            : 0;
        const production_view view = production_view_now(first, now);
        // in_progress / interrupted are reported because they decide whether the extrapolation
        // runs AT ALL (production_view_now gates on both), and on 2026-09-29 they were the reason
        // it did not: the anchor climbed to 60s while the view stayed pinned at 244.202026s, so
        // the anchor was working and the consumer was not. Those two fields come off the same
        // frozen DTO as the progress itself, so they cannot be trusted without being seen.
        hideout_trace("progress sample: raw=" + std::to_string(first.raw_progress)
            + "s anchor=" + std::to_string(anchor_age_ms / 1000) + "s old"
            + " in_progress=" + (first.in_progress ? "yes" : "no")
            + " interrupted=" + (first.interrupted ? "yes" : "no")
            + " -> view " + std::to_string(view.progress * first.production_time)
            + "s of " + std::to_string(first.production_time) + "s = "
            + std::to_string(view.progress * 100.0f) + "%"
            + " (left=" + std::to_string(view.seconds_left)
            + "s ready=" + (first.available_for_finish ? "yes" : "no") + ")");
    }
    return out;
}
