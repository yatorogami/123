#include "common.h"
#include "hotkeys.h"

#include "impl/AiLimitModule.h"
#include "impl/AmmoHudModule.h"
// AimbotModule.h guards its entire contents, so in a no-aimbot build this
// include resolves to nothing and register_aimbot() must not be compiled
// either -- both live under the same guard.
#ifdef INCLUDE_AIMBOT
#include "impl/AimbotModule.h"
#endif
#include "impl/ConfigModule.h"
#include "impl/DoorsModule.h"
#include "impl/EspModule.h"
#include "impl/MapModule.h"
#include "impl/MinimapModule.h"
#include "impl/PlayerModule.h"
#include "impl/WeaponModule.h"
#include "impl/WorldModule.h"
#include "impl/IcebreakerScenarioModule.h"
#include "game_state.h"

void hotkeys::register_esp(EspModule* esp) {
    add_toggle("esp.extracts", "hk_extracts_act", section::esp, esp->extracts);
    add_toggle("esp.transits", "hk_transits_act", section::esp, esp->transits);
    add_toggle("esp.players", "hk_players_act", section::esp, esp->players);
    add_toggle("esp.npc", "hk_npc_act", section::esp, esp->npc);
    add_toggle("esp.player_box", "hk_esp_box_act", section::esp, esp->player_box);
    add_toggle("esp.skeleton", "hk_skeleton_act", section::esp, esp->skeleton);
    add_toggle("esp.loot", "hk_loot_act", section::esp, esp->loot_esp);
    add_toggle("esp.containers", "hk_containers_act", section::esp, esp->container_esp);
    add_toggle("esp.show_loot_prices", "hk_show_loot_prices_act", section::esp, esp->show_loot_prices);
    add_toggle("esp.container_loot", "hk_container_loot_act", section::esp, esp->container_show_loot);
    add_toggle("esp.container_prices", "hk_container_prices_act", section::esp, esp->container_show_value);
    add_toggle("esp.corpse_loot", "hk_corpse_loot_act", section::esp, esp->corpse_show_loot);
    add_toggle("esp.provisions", "hk_provisions_act", section::esp, esp->show_provisions);
    add_toggle("esp.quest_items", "hk_quest_items_act", section::esp, esp->quest_items);
    add_toggle("esp.quest_esp", "hk_quest_esp_act", section::esp, esp->quest_esp_enabled);
    add_toggle("esp.grenades", "hk_grenade_esp_act", section::esp, esp->grenade_esp,
        0, nullptr, true);
    add_toggle("esp.keypanels", "hk_keypanel_esp_act", section::esp, esp->keypanel_esp,
        0, nullptr, true);
}

void hotkeys::register_minimap(MinimapModule* minimap) {
    add_toggle("esp.radar", "hk_radar_act", section::esp, minimap->radar);
}

// The big map's own keybind, on the plan's M (plan_bigmap_and_minimap.md 4.1).
// No default VK_ is bound here on purpose: hotkeys::add_toggle registers the
// binding, and leaving it unassigned means the user picks the key rather than
// the mod grabbing a letter that another overlay may already want.
void hotkeys::register_map(MapModule* map) {
    add_toggle("map.big_map", "hk_big_map_act", section::esp, map->big_map);
}

void hotkeys::register_player(PlayerModule* player, AiLimitModule* ai_limit) {
    add_toggle("exploit.god_mode", "hk_god_mode_act", section::exploits, player->god_mode,
        0, [player]() { return !player->god_mode2->get_value(); });
    add_toggle("exploit.buddha_mode", "hk_god_mode2_act", section::exploits, player->god_mode2, 0, [player]() { return !player->god_mode->get_value(); }, true);
    add_toggle("exploit.infinite_stamina", "hk_infinite_stamina_act", section::exploits, player->infinite_stamina);
    add_toggle("exploit.no_hunger_thirst", "hk_no_hunger_thirst_act", section::exploits, player->no_hunger_thirst);
    add_toggle("exploit.instant_search", "hk_instant_search_act", section::exploits, player->instant_search);
    add_toggle("exploit.double_search", "hk_double_search_act", section::exploits, player->double_search);
    add_toggle("exploit.speed_hack", "hk_speed_hack_act", section::exploits, player->speed_hack);
    add_toggle("exploit.fly_hack", "hk_fly_hack_act", section::exploits, player->fly_hack);
    add_keybind("exploit.fly_up", "fly_up_act", section::exploits, &player->fly_up_key, VK_SPACE);
    add_keybind("exploit.fly_down", "fly_down_act", section::exploits, &player->fly_down_key, VK_CONTROL);
    add_toggle("exploit.always_survive", "hk_always_survive_act", section::exploits, player->always_survive);
    add_toggle("exploit.thermal", "hk_thermal_act", section::exploits, player->thermal_vision);
    add_toggle("exploit.night_vision", "hk_night_vision_act", section::exploits, player->night_vision);
    add_toggle("exploit.no_visor", "hk_no_visor_act", section::exploits, player->no_visor);
    add_toggle("exploit.third_person", "hk_third_person_act", section::exploits, player->third_person);
    add_toggle("exploit.far_reach", "hk_far_reach_act", section::exploits, player->far_reach);
    add_toggle("exploit.invisible_bots_neutral", "hk_invisible_bots_neutral_act", section::exploits, ai_limit->invisible_to_bots_neutral,
        0, [ai_limit]() { return !ai_limit->invisible_to_bots_ally->get_value(); });
    add_toggle("exploit.invisible_bots_ally", "hk_invisible_bots_ally_act", section::exploits, ai_limit->invisible_to_bots_ally,
        0, [ai_limit]() { return !ai_limit->invisible_to_bots_neutral->get_value(); });
    add_action("exploit.call_airdrop", "hk_call_airdrop_act", section::exploits, [player]() { player->queue_call_airdrop = true; }, 0, true);
}

void hotkeys::register_weapon(WeaponModule* weapon) {
    add_toggle("exploit.no_jam", "hk_no_jam_act", section::exploits, weapon->no_jam);
    add_toggle("exploit.infinite_ammo", "hk_infinite_ammo_act", section::exploits, weapon->infinite_ammo);
    // always_breach UI is on WorldModule; hotkey still registered if world module is available via world register
    add_toggle("exploit.no_head_bob", "hk_no_head_bob_act", section::exploits, weapon->no_head_bobbing);
    add_toggle("exploit.no_aim_sway", "hk_no_aim_sway_act", section::exploits, weapon->no_aim_sway);
    add_toggle("exploit.no_breath", "hk_no_breath_act", section::exploits, weapon->no_breath_sway);
    add_toggle("exploit.no_recoil", "hk_no_recoil_act", section::exploits, weapon->no_recoil_force);
}

void hotkeys::register_doors(DoorsModule* doors) {
    add_toggle("exploit.always_breach", "hk_always_breach_act", section::exploits, doors->always_breach_door);
}

void hotkeys::register_world(WorldModule* world) {
    add_action("exploit.kill_all", "hk_kill_all_act", section::exploits,
        [world]() { world->queue_kill_all = true; });
    add_action("exploit.tp_all", "hk_tp_all_act", section::exploits,
        [world]() { world->queue_tp_all = true; });
    add_action("exploit.tp_one", "hk_tp_one_act", section::exploits,
        [world]() { world->queue_tp_one = true; });
}

void hotkeys::register_ammo_hud(AmmoHudModule* ammo_hud) {
    add_toggle("esp.ammo_hud", "hk_ammo_hud_act", section::esp, ammo_hud->enabled,
        0, nullptr, true);
}

void hotkeys::register_icebreaker_scenario(IcebreakerScenarioModule* module) {
    
}

void hotkeys::register_config(ConfigModule* config) {
    if (!config) return;
    add_toggle("config.esp_manual_refresh", "hk_esp_manual_refresh_act", section::esp,
        config->esp_manual_refresh);
    add_action("config.esp_refresh_now", "hk_esp_refresh_now_act", section::esp,
        []() { game_state::esp_manual_refresh_request = true; });
}

#ifdef INCLUDE_AIMBOT
// Aim type is a mutually-exclusive dropdown, not a set of independent toggles,
// so it gets one key per option instead of one key that flips it. Pressing a
// key puts the dropdown on that option; the dropdown and every key therefore
// read and write the same value, and neither can disagree with the other.
//
// The indices are POSITIONAL and must stay in step with AimbotModule's
// SelectValue(0, { none, magic bullet, magic aim, aimbot }). Option 0 is
// included deliberately: "None" is a mode like any other, and without a key for
// it an aim key could only ever be turned off by opening the menu.
//
// Labels reuse the dropdown's own i18n keys, so a binding reads exactly like
// the option it selects and nothing has to be translated twice. i18n::tr has no
// fallback chain -- a key missing from a locale is echoed back verbatim -- so
// reusing keys that already exist in all 19 lang files is the only way to avoid
// shipping 19 raw key names to non-English users.
void hotkeys::register_aimbot(AimbotModule* aimbot) {
    if (!aimbot) return;
    add_select("aim.none", "none_sel", section::aimbot, aimbot->aim_type, 0);
    add_select("aim.magic_bullet", "hk_magic_bullet_act", section::aimbot, aimbot->aim_type, 1);
    add_select("aim.magic_aim", "magic_aim_sel", section::aimbot, aimbot->aim_type, 2);
    add_select("aim.aimbot", "aimbot_sel", section::aimbot, aimbot->aim_type, 3);
}
#endif
