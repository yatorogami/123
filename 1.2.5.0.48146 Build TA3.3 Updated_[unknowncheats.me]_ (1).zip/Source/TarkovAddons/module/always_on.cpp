#include "common.h"
#include "always_on.h"

namespace always_on {

    bool sm_view::ok() const { return base != nullptr; }

} // namespace always_on
