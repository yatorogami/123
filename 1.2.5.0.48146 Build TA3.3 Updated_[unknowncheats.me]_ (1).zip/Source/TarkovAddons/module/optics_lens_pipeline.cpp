#include "common.h"
#include "optics_lens_pipeline.h"

namespace optics::lens {

    scoped_call_timer::scoped_call_timer() : start(qpc_us()) { ++perf_sections().calls; }

    scoped_call_timer::~scoped_call_timer() { perf_sections().total_micros += qpc_us() - start; }

    v3 affine_map::local_from_uv(const v2& uv) const {
        return center + u_axis * (uv.x - 0.5f) + v_axis * (uv.y - 0.5f);
    }

} // namespace optics::lens
