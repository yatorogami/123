#pragma once

// READ-ONLY probe of the player's grenade throw vector. 2026-10-04.
//
// WHAT THIS IS FOR
//   The goal is "throw at the enemy instead of at the eye line", i.e. rewrite the
//   vector the throw force is applied along -- the same shape as
//   `hk_initiate_shot`, which re-derives `shot_direction` from the fireport.
//
//   The game already hands us that vector as an explicit parameter.  From the
//   ISIL dump (Assembly-CSharp/EFT/Player_NestedType_BaseGrenadeHandsController):
//
//     Player+GrenadeHandsController.HighThrow() / .LowThrow()
//       -> BaseGrenadeHandsController.Throw(timeSinceSafetyLevelRemoved, low)
//            branches on Player.get_IsAI; the player branch reads
//            Skills.StrengthBuffThrowDistanceInc / ThrowingEliteBuff and
//            EFTHardSettings, the AI branch reads BotGrenadeController.ToThrowDirection
//          -> ThrowGrenadeInner(throwPosition, timeSinceSafetyLevelRemoved,
//                                lowHighThrow, direction, forcePower,
//                                lowThrow, withVelocity)
//            computes the launch vector as Quaternion.op_Multiply(<grenade
//            transform rotation>, <direction>), runs CheckHandsToBodyObstacles,
//          -> ThrowGrenade(timeSinceSafetyLevelRemoved, position, rotation, force, lowThrow)
//               which calls Player.ThrowGrenade(...) for the authoritative result
//                 AND CreateAndRegisterGrenade(position, rotation, force) ->
//                   GrenadeFactory.Create(settings, position, rotation, force)
//
//   So `force` as it reaches `ThrowGrenade` IS the launch vector.  That is the
//   thing to rewrite.
//
// WHY THIS IS A POLL AND NOT A HOOK
//   `ThrowGrenade` takes (float, Vector3, Quaternion, Vector3, bool).  A hook needs
//   its x64 ABI exactly right, and the two reconstructions available here disagree
//   with each other:
//
//     - the MSVC layout this codebase already uses successfully for
//       `initiate_shot_sig` (three `unity::vector3` BY VALUE in xmm0..xmm5) would
//       put position in xmm1/xmm2, rotation in xmm3/xmm4, force in xmm5/xmm6, and
//       lowThrow in rdx;
//     - the disassembly in the ISIL dump reads position from r8, force from r9,
//       rotation from [rsp+0A0h] and lowThrow from [rsp+0A8h] -- i.e. as stack
//       POINTERS.
//
//   Both cannot be true.  Getting it wrong is not a safe failure: even a
//   read-only hook re-emits its arguments to the trampoline, so a wrong
//   declaration corrupts the outgoing call rather than merely logging nonsense.
//   We already have one unattributed ACCESS_VIOLATION in this codebase and I am
//   not adding a second by guessing.
//
//   The controller caches the same values in plain fields, which the game's own
//   `ClientGrenadeHandsController.ThrowGrenade` writes immediately before calling
//   the base.  Reading them needs no ABI at all and cannot corrupt anything.  If
//   the numbers come back sane, phase 2 is a naked shim that reads the offsets out
//   of the callee's OWN prologue (verbatim in the dump) -- still no guessing.
//
// FIELD OFFSETS
//   Taken from the stores in `ClientGrenadeHandsController.ThrowGrenade`
//   (r14 = this):
//       mov      byte [r14+10Ch], 1        ; throw-issued flag
//       movups   [r14+110h], xmm0         ; force       <- xmm0 was loaded from rdi
//       movsd    [r14+120h], xmm0         ; position.x  <- xmm0 was loaded from rsi
//       mov      [r14+128h], eax          ; position.z
//       movsd    [r14+12Ch], xmm0         ; rotation.x  <- xmm0 was loaded from rbp
//       mov      [r14+134h], eax          ; rotation.z
//       mov      [r14+138h], bl          ; lowThrow
//   Note +0x12C holds THREE floats, not a full Quaternion: a Quaternion would put
//   w at +0x138, and the game overwrites +0x138 with the bool.  The two layouts are
//   therefore mutually exclusive and `report()` counts which one we actually see.
//
// SELF-VALIDATING
//   Nothing here trusts the offsets.  A position is metres in world space, a throw
//   force is a speed, a rotation axis is unit-ish and lowThrow is a bool.  Every
//   sample is classified into plausible / not, and `report()` prints the tally, so a
//   wrong offset shows up as "0 of N plausible" rather than as plausible-looking
//   nonsense that gets built on.

// Aimbot-flavour guarded, same reasoning as AimbotModule.h: this reads the throw
// vector, which is exploit surface, so a "no aimbot" build must not be able to
// reach it at all rather than merely not call it.
#ifdef INCLUDE_AIMBOT

#include "../../il2cpp/il2utils.h"
#include "../../il2cpp/libil2cpp/il2cpp-object-internals.h"
#include "../../il2cpp/unity.h"
#include "../../util/logger.h"
#include "../../util/tracy_bridge.h"
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>

namespace grenade_probe {

    // ---------------------------------------------------------------- offsets
    inline constexpr uintptr_t kOffThrowIssued = 0x10C;
    inline constexpr uintptr_t kOffForce       = 0x110;
    inline constexpr uintptr_t kOffPosition    = 0x120;
    inline constexpr uintptr_t kOffRotation    = 0x12C;
    inline constexpr uintptr_t kOffLowThrow    = 0x138;

    // The exact class the offsets above were read out of.  Anything else is
    // counted and reported but NOT read, because the layout is a different one
    // and reading it would produce garbage attributed to a real vector.
    inline constexpr const char* kExpectedClass = "ClientGrenadeHandsController";

    // ---------------------------------------------------------------- resolved
    using get_hands_controller_sig = Il2CppObject* (*)(Il2CppObject*);
    using get_is_ai_sig             = bool (*)(Il2CppObject*);

    inline get_hands_controller_sig g_get_hands_controller = nullptr;
    inline get_is_ai_sig             g_get_is_ai             = nullptr;
    inline bool g_resolved = false;

    // ---------------------------------------------------------------- counters
    inline unsigned long long g_calls          = 0;  // probe() invocations
    inline unsigned long long g_armed          = 0;  // hands WAS a grenade controller
    inline unsigned long long g_samples        = 0;  // fields actually read
    inline unsigned long long g_plausible      = 0;  // ... and looked physical
    inline unsigned long long g_high           = 0;  // lowThrow == 0
    inline unsigned long long g_low            = 0;  // lowThrow == 1
    inline unsigned long long g_badlow         = 0;  // neither: layout surprise
    inline unsigned long long g_player         = 0;  // Player.get_IsAI == false
    inline unsigned long long g_ai             = 0;  // Player.get_IsAI == true
    inline unsigned long long g_other_class    = 0;  // grenade controller, wrong class
    inline unsigned long long g_no_controller  = 0;  // hands was null

    // Last sample, kept so a periodic report can print it without having caught it
    // inside the frame it happened.
    inline unity::vector3 g_last_force    = {};
    inline unity::vector3 g_last_position = {};
    inline unity::vector3 g_last_rotation = {};
    inline float          g_last_mag      = 0.f;
    inline float          g_last_issued   = -1.f;
    inline float          g_last_low      = -1.f;

    inline unsigned long long g_first_report_ms = 0;
    inline unsigned long long g_last_report_ms  = 0;
    inline unsigned long long g_reports         = 0;

    inline unsigned long long now_ms() {
        LARGE_INTEGER f{}, t{};
        if (!QueryPerformanceFrequency(&f) || f.QuadPart <= 0) return 0;
        QueryPerformanceCounter(&t);
        return (unsigned long long)((t.QuadPart / f.QuadPart) * 1000ULL
            + ((t.QuadPart % f.QuadPart) * 1000ULL) / (unsigned long long)f.QuadPart);
    }

    template <typename T>
    inline T field(Il2CppObject* o, uintptr_t off) {
        return *reinterpret_cast<const T*>(reinterpret_cast<uintptr_t>(o) + off);
    }

    inline void resolve() {
        if (g_resolved) return;
        g_resolved = true;  // once only, even on failure: a missing method is not
                            // going to appear by next frame, and the counters say so

        Il2CppImage* image = il2utils::resolve_image("Assembly-CSharp.dll");
        if (!image)
        {
            logger::warn("grenade-probe: Assembly-CSharp.dll not found; probe is off");
            return;
        }

        const Il2CppClass* player_class = il2utils::resolve_class(image, "EFT", "Player");
        if (player_class)
        {
            if (const MethodInfo* m = il2utils::resolve_method(player_class, "get_HandsController", 0))
                if (m->methodPointer)
                    g_get_hands_controller = reinterpret_cast<get_hands_controller_sig>(m->methodPointer);

            if (const MethodInfo* m = il2utils::resolve_method(player_class, "get_IsAI", 0))
                if (m->methodPointer)
                    g_get_is_ai = reinterpret_cast<get_is_ai_sig>(m->methodPointer);
        }

        if (!g_get_hands_controller)
            logger::warn("grenade-probe: Player.get_HandsController unresolved; probe is off");
        else if (!g_get_is_ai)
            logger::warn("grenade-probe: Player.get_IsAI unresolved; the AI/player split "
                         "will read as player-only");

        logger::info(std::string("grenade-probe: READ-ONLY build. Offsets ") +
                     "issued=0x10C force=0x110 position=0x120 rotation=0x12C lowThrow=0x138, "
                     "class=" + kExpectedClass + ". No throw value is modified.");
    }

    // A force is a launch speed.  Unity grenades leave the hand at roughly
    // single-digit to low-tens m/s; anything outside this is a misread offset.
    inline bool force_plausible(float m) {
        return std::isfinite(m) && m > 0.05f && m < 200.f;
    }
    // A world position in metres.  Raid maps are a few km across at most.
    inline bool position_plausible(const unity::vector3& p) {
        return std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z)
            && std::fabs(p.x) < 5000.f && std::fabs(p.y) < 5000.f && std::fabs(p.z) < 5000.f;
    }
    // A rotation axis should be roughly unit length.
    inline bool rotation_plausible(const unity::vector3& r) {
        return std::isfinite(r.x) && std::isfinite(r.y) && std::isfinite(r.z)
            && r.length() > 0.2f && r.length() < 5.f;
    }

    inline void report() {
        ++g_reports;
        std::string s;
        s.reserve(320);
        char buf[320];
        _snprintf_s(buf, sizeof(buf), _TRUNCATE,
            "grenade-probe: armed=%llu samples=%llu plausible=%llu | high=%llu low=%llu badlow=%llu "
            "| player=%llu ai=%llu | other_class=%llu no_controller=%llu",
            g_armed, g_samples, g_plausible, g_high, g_low, g_badlow, g_player, g_ai,
            g_other_class, g_no_controller);
        s += buf;
        _snprintf_s(buf, sizeof(buf), _TRUNCATE,
            " || last force=(%.3f,%.3f,%.3f)|v|=%.3f  pos=(%.2f,%.2f,%.2f) "
            "rot=(%.3f,%.3f,%.3f) issued=%.0f low=%.0f",
            g_last_force.x, g_last_force.y, g_last_force.z, g_last_mag,
            g_last_position.x, g_last_position.y, g_last_position.z,
            g_last_rotation.x, g_last_rotation.y, g_last_rotation.z,
            g_last_issued, g_last_low);
        s += buf;
        logger::info(s);
    }

    /// Called once per frame from the aimbot's gameworld_update. Read-only.
    inline void probe(Il2CppObject* player) {
        TA_ZONE_N("grenade::throw_probe");
        if (!player) return;
        resolve();

        ++g_calls;
        if (!g_get_hands_controller)
        {
            report();
            return;
        }

        Il2CppObject* hands = g_get_hands_controller(player);
        if (!hands || !hands->klass || !hands->klass->name)
        {
            ++g_no_controller;
            return;
        }

        const char* cls = hands->klass->name;
        if (!std::strstr(cls, "Grenade"))
            return;  // a firearm in hands: not our business, and not an error

        // The offsets are only valid for the class they were read from.
        if (std::strcmp(cls, kExpectedClass) != 0)
        {
            ++g_other_class;
            if (g_other_class == 1)
                logger::warn(std::string("grenade-probe: hands are a '") + cls
                             + "', not " + kExpectedClass
                             + "; offsets NOT valid for it, so nothing is read. "
                               "Phase 2 needs this class's layout.");
            return;
        }

        ++g_armed;

        if (g_get_is_ai)
            g_get_is_ai(player) ? ++g_ai : ++g_player;

        const unity::vector3 force    = field<unity::vector3>(hands, kOffForce);
        const unity::vector3 position = field<unity::vector3>(hands, kOffPosition);
        const unity::vector3 rotation = field<unity::vector3>(hands, kOffRotation);
        // BYTE reads, deliberately. The game stores `mov byte [r14+10Ch],1` and
        // `mov [r14+138h],bl` -- one byte each. Reading four bytes there would pick
        // up whatever the next three bytes of padding or adjacent field hold, and a
        // 1 followed by three zero bytes is 1.4e-45, not 1.0f. So the `low == 0.f` /
        // `low == 1.f` classification below would match neither arm and both tallies
        // would read 0 while looking like they had run.
        const std::uint8_t    issued   = field<std::uint8_t>(hands, kOffThrowIssued);
        const std::uint8_t    low      = field<std::uint8_t>(hands, kOffLowThrow);

        ++g_samples;
        const float mag = force.length();
        const bool ok = force_plausible(mag) && position_plausible(position)
                        && rotation_plausible(rotation);
        if (ok) ++g_plausible;

        if (low == 0)      ++g_high;
        else if (low == 1) ++g_low;
        // Anything else is a layout surprise, not a throw type. Counted so the
        // report can say so instead of quietly dropping it.
        else               ++g_badlow;

        g_last_force    = force;
        g_last_position = position;
        g_last_rotation = rotation;
        g_last_mag      = mag;
        g_last_issued   = static_cast<float>(issued);
        g_last_low      = static_cast<float>(low);

        // 30 s, and always the first one so a raid that only ever throws once still
        // produces output.
        const unsigned long long now = now_ms();
        if (!g_first_report_ms || !g_last_report_ms || now - g_last_report_ms >= 30000ULL)
        {
            g_first_report_ms = now;
            g_last_report_ms  = now;
            report();
        }
    }

}  // namespace grenade_probe

#endif  // INCLUDE_AIMBOT