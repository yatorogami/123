# Menu typefaces

Embedded in the DLL as RCDATA 1400-1401-1402 (`assets/menu_background.rc`) and
loaded by `gui/menu/menu.cpp`. There are three faces, and one rule about which
is which:

| file | role | size |
|---|---|---|
| `Inter-Regular.ttf` | the UI face, and the overlay/HUD face | 16px · HUD 256px |
| `Inter-SemiBold.ttf` | card headings, the nav title | 18px |
| `JetBrainsMono-Regular.ttf` | every number: slider readouts, keycaps, item ids, the ammo block | 15px · HUD 256px |

## Why they are embedded rather than read from `C:\Windows\Fonts`

The face this menu used before was Segoe UI, loaded from the system. That is
fine for a tool that runs on the author's machine and **not** fine for a mod
that ships a DLL: Segoe UI is a Microsoft system font and redistributing it is
not something this project should do. Both replacements are SIL OFL 1.1, whose
whole point is that embedding is permitted — the licence text is beside the
faces (`Inter-OFL.txt`, `JetBrainsMono-OFL.txt`) and that is the obligation the
licence carries.

## Provenance

| face | version | source |
|---|---|---|
| Inter | 4.1 | `github.com/rsms/inter` release `v4.1`, `extras/ttf/` |
| JetBrains Mono | 2.304 | `github.com/JetBrains/JetBrainsMono` release `v2.304`, `fonts/ttf/` |

Fetched with `tools/fetch_ui_fonts.py`, which pulls both release zips and
keeps only these three faces. Verified byte-for-byte inside the shipped DLL by
`tools/check_dll_resources.py`, which reads the resource directory and
compares each payload against the file here — because a `.rc` entry that
silently fails to compile is invisible from the menu: the loader would fall
back to a system face, the UI would look normal, and Inter would simply not be
there.

## Coverage is measured, not assumed

`tools/check_font_coverage.py` reads the cmaps against the exact ranges
`build_unicode_glyph_ranges()` asks for. The result that shaped the loader:

- **Inter**: Latin, Latin-1/Ext-A/Ext-B, Greek, Cyrillic, Vietnamese — all
  good. **Thai 1.1%**, CJK 0%.
- **JetBrains Mono**: Latin and Latin-1 complete; no Thai, no CJK.

So the CJK fallbacks (`merge_cjk_fallbacks`) are still merged in, and a **Thai**
merge was added with the font swap — Leelawadee UI, then Arial Unicode. Without
it the shipped `tu` locale renders boxes, which is a regression bought by a
font change. The mono face deliberately does **not** carry the CJK/Thai ranges:
it is only ever asked for digits, key names and template ids, and a mono face
carrying 20k CJK glyphs would cost three times the atlas for glyphs nothing
draws.

## Regenerating

Drop a different version's `.ttf` in here, re-run the coverage check, and
rebuild — the `.rc` entries name files, not versions. If a face is renamed,
update `FONT_SOURCES` in `tools/check_dll_resources.py` at the same time, or
the verification silently stops checking the new one.