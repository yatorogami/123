# Static markers and labels — provenance

The `static_markers` and `labels` arrays in the map configs beside this file
were merged from the **SPT-DynamicMaps** project, submodule `dynamicmaps`
pinned at `4944764f5f6c42d152dca6bd1b5371c4f6212a9e` (tag `1.2.1`):

    https://github.com/acidphantasm/SPT-DynamicMaps

Merged 2026-10-13. The upstream data lives in
`dynamicmaps/Plugin/Resources/Maps/<Map>_<Source>/<Map>_<Source>.jsonc` under
the keys `StaticMarkers` and `Labels`.

## What was taken, and what was not

- **Taken:** the `LockedDoor`, `Switch` and `Secret` static markers, and every
  label. Category spellings were normalised (`Locked Door` → `LockedDoor`).
- **Not taken:** the `Extract` and `Transit` markers. This project reads those
  live from the game, and a static copy would desync from eligibility the first
  time a raid's state changed. See `tools/plan_bigmap_and_minimap.md` step 5.
- **Positions** were re-mapped: upstream writes `Position {x, y, z}` where `x`
  is world X, `y` is world Z and `z` is the altitude; ours is
  `{x, y = z, z = y}`. `tools/tests/test_map_asset_integrity.py` asserts every
  shipped marker lands inside its map's bounds, which is what catches a wrong
  mapping.

## Licence

MIT License

Copyright (c) 2025 Michael P. Starkweather (acidphantasm)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Upstream states that the label text comes from Tarkov.dev map data, also under
MIT. The `_TarkovData` map sources credit Shebuka / TarkovTracker
(<https://github.com/TarkovTracker/tarkovdata/>).
