# Shared vendored libraries

Third-party code used by more than one project in this repo lives here, at the
repository root, rather than being vendored separately into each project.

```text
external/
  nlohmann/      nlohmann/json (single header, ~1 MB)
  safetyhook/    SafetyHook + Zydis
```

## Why it is not inside a project

`TarkovAddons` and `TarkovLauncherBypass` are two DLLs in one repo, built from
two separate solutions (`TarkovAddons.sln` contains both; `TarkovLauncherBypass.sln`
contains only the bypass). Both libraries used to live in TarkovAddons' own
`external/` while the bypass reached into that tree by relative path:

- **SafetyHook** was vendored twice outright — once at
  `TarkovAddons/external/safetyhook/`, once at
  `TarkovLauncherBypass/libs/safetyhook/` — as two byte-identical copies of an
  ~11 MB `Zydis.c` that had to be updated in lockstep. The duplicated copy was
  the one likely to rot.
- **nlohmann/json** was vendored once, but the bypass included it as
  `"../../TarkovAddons/external/nlohmann/json.hpp"`. Nothing in its `.vcxproj`
  declared that dependency, so moving or renaming the file would have broken the
  bypass with a misleading error. An undeclared cross-project include is worse
  than a declared one.

Still-local to `TarkovAddons/external/`: `imgui/`, `nanosvg/`, `stb/`, `tracy/`.
These are used by TarkovAddons only, so they stay there.

## How a project consumes it

Both include paths and source paths are project-relative via
`$(MSBuildThisFileDirectory)`, **not** `$(SolutionDir)`: each project is in its
own solution, so `$(SolutionDir)` does not point at the repo root in all cases.
The existing `compatibility/` folder is referenced the same way.

In a `.vcxproj`:

```xml
<ClCompile Include="$(MSBuildThisFileDirectory)..\external\safetyhook\safetyhook.cpp" />
<ClInclude Include="$(MSBuildThisFileDirectory)..\external\safetyhook\safetyhook.hpp" />
<AdditionalIncludeDirectories>$(MSBuildThisFileDirectory)..\external;...</AdditionalIncludeDirectories>
```

The `AdditionalIncludeDirectories` entry is only needed for angle-bracket
includes such as `<nlohmann/json.hpp>`; relative includes need no include
directory.

In consuming sources, use a relative include, resolved from the including
file's own directory:

```cpp
// TarkovAddons/il2cpp/il2utils.h
#include "../../external/safetyhook/safetyhook.hpp"
```

Every such entry must be mirrored in the matching `.vcxproj.filters` file, and
any `<Filter>` referenced there must be declared in that file's first
`ItemGroup` — Visual Studio errors on an undeclared filter.

## Trade-off

Neither project directory is self-contained any more. Copying
`TarkovLauncherBypass/` on its own to another machine will no longer build,
because it needs the repo root alongside it. In exchange there is exactly one
copy of the library to review, update, and keep in sync.

If that trade-off is ever unwanted, the alternative is a git submodule: each
project keeps a real vendored snapshot pinned to its own version, at the cost
of clone/update friction and the possibility of the two drifting.

## Requirements

SafetyHook needs C++23 for `std::expected`. Both projects compile the
`ClCompile` entry above in every configuration, so both set
`LanguageStandard` to `stdcpp23` and pass `/Zc:__cplusplus` and `/bigobj`
project-wide. `Zydis.c` is a single ~11 MB translation unit and exceeds the COFF
section limit without `/bigobj`.
