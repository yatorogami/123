# TarkovAddons Reloaded — v3.3

Covers everything after the `3.0` branch tip `a3307eaf`, through `v3.3`.

This is a *changelog*: what changed, and what it means. The dead-code
investigation behind it — including seven claims of mine that turned out to be
wrong when re-checked, and why — is kept separately in
[`CLEANUP_AUDIT.md`](CLEANUP_AUDIT.md).

**§0 is unreleased work and is dated separately.** Everything from §1 down is the
`v3.2` retrospective and reads as it was written; §0 is the delta that `v3.3` has
not yet released. The running status of the project is in `AGENTS_TODO.md`; this
file's §0 is only the delta.

**The version itself is written once, in code.** `globals::k_version`
(`TarkovAddons/util/globals.h`) is the only place the number appears;
`prod_name`, the log header, the console and window title, the menu sidebar and
the watermark are all built from it. The sidebar used to carry its own literal,
which is how the number on screen and the number in the log came to be two
different releases at once.

---

## 0. Unreleased — the `v3.3` delta, after `v3.2`

### 0.73 The big map draws markers, pans, zooms and switches floors (2026-10-15)

Steps 6 and 7 of `tools/plan_bigmap_and_minimap.md`, and the live defect that
was sitting under them the whole time.

**`MapModule::player_pos_` was read every frame and written nowhere.** The big
map's player dot rendered at the world origin, and the floor pick chose the level
under (0,0,0). `gameworld_update` took `main_player` as `[[maybe_unused]]`, so
there was no path to it. What made it look like a position rather than missing
data is that **(0,0,0) is inside Customs' playable area** — hence `has_player_pos_`
rides alongside the vector rather than the zero test being used as the sentinel.

The rest of plan 4.3: wheel zoom (multiplies the slider, which stays the per-raid
baseline), drag pan, and **level switching** (`,` / `.` to cycle, `\` to return
to "follow the player"). The floor override lives in `minimap.h` beside the state
it overrides and is consumed by `update_active_layers`, which otherwise re-derives
the level from the player position on every single frame and would undo the pick.

**The markers are EspModule's.** `EspModule::draw_big_map_markers` sits beside
`draw_radar_overlay` and draws from the same snapshots through the same helpers,
glyphs and fonts, because a second renderer would be a second set of colours,
sizes and label anchors that could drift from the radar's with nothing noticing.
`MapModule` takes an injected `EspModule*` for that one call and owns the view.
Four new checkboxes gate the layers independently of the radar's; there is no
distance cull, because a whole-map view exists to show what a 75 m radar cannot.

**Step 7's drop-down is deliberately inert in a raid.** `minimap::active_map()`
is one global loaded map and `EspModule::draw_radar_overlay()` re-requests the
player's own location every frame. A second map cannot be loaded alongside it, so
honouring a mid-raid pick would draw Woods' terrain with Customs' extracts on it —
confidently wrong. The picker is therefore **disabled** in a raid, with an info row
saying why, and works out of raid. Giving `active_map()` per-view state is the
largest remaining item on the plan and is not attempted here.

## 0.72 The pen walk's two layer gates now print ONE set of strings (2026-10-14)

The ancestor ballistic gate and the sibling sweep used to render four different
forensic strings for the same conditions — the sibling's dead stop carried a
`(sibling; …)` tag, its `stop_reason` a `sibling:` prefix, and its ricochet
verdict lacked the ancestor's `; round likely skips off`. That asymmetry was
deliberate for four years of logs: a `stop_reason` starting `sibling:` named
*which sweep* stopped the round.

**The user's call on 2026-10-14: unify.** The sibling gate now renders the
ancestor's four strings exactly. The cost is stated rather than hidden:

- **historical logs keep matching only through the old wording.** A grep for
  `sibling:` finds nothing in new logs;
- a new `blocked at layer N (reason)` verdict no longer says which sweep
  stopped the round. The *counted* `pen_stop` buckets still split the two
  unreadable cases (`sibling_unreadable` vs `unreadable`), so the tally keeps
  the distinction the strings lost — but the verdict text does not.

Recorded here because the last session that changed a diagnostic string sent an
investigation at the wrong subsystem (`handoff_visibility_inside_hit.md` — the
precedent this entry is named after). `tools/tests/test_pen_diagnostic_strings.py`
pins the unified state in both directions: the shared strings exist, the retired
spellings are gone, and the suffix is in *both* deflection verdicts (exactly
two, where it was exactly one).

The structural difference between the two gates is untouched: they still assign
different variables (`layer_is_ballistic` vs `layer_ballistic`) with different
downstream readers, and the sibling path still advances-and-continues where the
ancestor falls through to `step_past`. Merging *those* was never part of this
decision — it needs the before/after trace-dump diff `handoff_skeleton_vis_clone_merge.md`
§5 calls for, and no raid has been captured to provide one.

Ten captures (`current.tracy` … `nextday.tracy`, 51 MB → 421 MB) and the
`tools/harness` / `tools/tests` suites. Four themes, in the order they matter.

### 0.1 The `VirtualQuery` guard was 8% of wall clock, and is now 0.07%

`eft_api::is_readable_address` runs in front of every IL2CPP read. It was
**91.6 s over 2,493,902 calls in one capture** — the single most expensive thing
in the profile, and it was the *guard*, not the work it guards.

The cost was the syscall, not the comparison. `VirtualQuery` costs ~46–200 µs in
this process, and the call count was the problem, so the fix is to make fewer
syscalls rather than to make the check cheaper:

- **`is_readable_address_cached`**: a direct-mapped region memo, resized 256 →
  **4,096** slots with a Fibonacci high-bits hash. The trailing mask is mandatory
  — `>> 32` alone yields a 32-bit index into a 4,096-entry array, which is an
  out-of-bounds write. That was shipped by mistake once and caught only because
  the harness died with a `0xC0000005` and no output.
- **Eight call sites** that were still calling the uncached function were routed
  through the memo. That routing, not the resize, is where the 600× came from.
- **`clear_probe_region_memo()` on every raid boundary**, which is what bounds
  staleness. A cache over freed memory has exactly one defence.
- **`optics::lens::range_readable`**: the same table, same size, same hash.
  29.385 s → **0.092 s**, `hit/miss = 7942/0`, `vq = 0`.
- **`unity::is_unity_object_alive`**: its own 16-slot pointer-keyed memo with a
  64-call TTL, because a dead answer must never be cached. Holds 98% with
  revalidations tracking misses.

Measured across five captures: **91.621 s → 0.091 → 0.149 → 0.119 → 1.339 s**, and
the per-call cost went *down* (48 µs vs 59 µs) while the call count went up 13×.
`probe-memo` finished the last capture at **1,566,266 hits / 1 miss**.

### 0.2 The compatibility profile had never been loaded, in any build, ever

`compatibility_profile::load_for_module` searched
`<dll dir>/compatibility/profiles/`. The MSBuild `Content` item and
`tools/deploy.py` both put the manifest at `<deploy>/ta/compatibility/profiles/`.
The manifest was deployed, valid, 11,245 bytes, in a directory nothing read, and
every launch took the **designed** `NotFound` fallback — silently, because that
path is not an error.

Introduced by the fix that put the manifest under `ta\` in the first place, which
was right: the copy used to live only in the two Prod post-build steps, so Debug
and Release shipped no profile at all. Moving the writer without moving the
reader is the whole defect.

`load_for_module` now uses `module_paths::data_directory_wide()` — the accessor
`TarkovLauncherBypass` already used correctly. One line, and the two processes
can no longer drift on this by accident.

`tools/tests/test_profile_path.py`, 10 cases, asserts the three literals that have
to agree (the `.vcxproj` `<Link>`, `deploy.py`'s destination, the loader's root)
plus launcher/game agreement. Four negative controls, all firing.

**And it broke startup 3 times in 4 launches.** The fix made a fail-closed path
reachable for the first time, and it fired immediately:

```
12:13:12  IL2CPP compatibility profile loaded: eft-1.1.5.1.47510   ← first time ever
          could not resolve required symbol: il2cpp_string_new   (×6)
          IL2CPP compatibility profile is incomplete; startup will stop safely
          Mod startup stopped
12:13:45  same     12:14:07  same     12:14:48  all 14 resolved, mod started
```

The 6 failures are exactly the 6 `export`-resolver symbols. The 8
`pattern`-resolver symbols resolved on every launch, including the failing ones.
The difference is in `il2cpp_offsets.h`: the pattern branch is
`resolve_pattern_with_retry` — **3 attempts, 150 ms apart** — and the export
branch is `resolve_export_body`, **one attempt, no retry**. All six names are
present in GameAssembly.dll's export table (verified against the PE: 386 exported
names), and the manifest gives them `resolution_order: ["export"]` with no
pattern fallback, so one miss is fatal.

**"Wait longer for the game" was proposed and is refuted by measurement.** The
failing launch went from the boot gate to `Loading Il2CPP API` in 2 ms; the
succeeding one in **1 ms**. And on the failing launch a pattern scan of
`GameAssembly.dll` succeeded *in the same millisecond* that `GetProcAddress` on
it failed, with zero pattern retries. The module is scannable before the first
export lookup, so no wait duration and no readiness semaphore can help.

**Diagnostics added rather than a guess.** `scan::find_export_by_hand` is a
hand-rolled export lookup that calls no Windows API, cannot be intercepted, and
bounds-checks every access. On failure the log now carries a **`VERDICT` line**
saying which party is wrong — the table or the API — along with the module's
on-disk path and `GetLastError()` sampled immediately after the call. It also
resolves `GetProcAddress` out of `kernel32.dll`'s export table with the same
reader and calls it, distinguishing "our IAT entry is hooked" from "the export
really is not there". The boot gates log their elapsed ms and poll count,
`GameAssembly.dll`'s path and `SizeOfImage` at the gate, and each init step's
wall time.

`tools/harness/test_export_lookup.cpp`, 43 assertions, five negative controls.
It covers the properties a hand parser gets wrong: PE32 and PE32+ put
`DataDirectory` 16 bytes apart, the name→ordinal→function indirection is two
levels deep (asserted by requiring two lookups to return *different* RVAs), a
forwarder is detected and never returned as an address, lookup is case-sensitive,
and eleven kinds of malformed image are refused rather than read past — because
a parser that faults on the failure path converts a diagnosable startup failure
into a crash during diagnosis.

**Confirmed working, and the explanation above was wrong.** Three launches, all
clean, no ERROR lines. And launch 1 is not "no problem occurred" — it is:

```
boot[at Unity gate]: GameAssembly=7FFCA3B40000 LISTED 91 module(s) enumerated; GetModuleFileNameW FAILED
boot[il2cpp]: 6 of 14 required symbol(s) needed a direct read of the export table
              because GetProcAddress could not. ... startup succeeded anyway.
IL2CPP API Loaded via compatibility profile
```

So the fallback resolved all six at the independently cross-validated RVAs and
the mod started. The counter exists precisely so this launch is distinguishable
from one where the problem never occurred.

**And the timeline corrected the diagnosis.** `EnumProcessModulesEx(LIST_MODULES_ALL)`
**finds GameAssembly.dll on the failing launch** — at the gate, during the first
fallback, and after init. The module was never unlinked; an unlinked module is
invisible to that API too. So it is **listed** while `GetProcAddress` *and*
`GetModuleFileNameW` both refuse it: a **filter on those two APIs for one module**,
not a missing list entry. Two failures sharing an error code is not a mechanism,
and reading `ERROR_MOD_NOT_FOUND` as "the handle is not in the list" without
checking whether it was is the same mistake this project keeps making.

**That settles the retry question: don't add it.** Membership never changed on any
launch. What varies is the loader's policy for those two APIs, and waiting cannot
change a policy.

**One real gap this found, in my own diagnostics.** The GetProcAddress-hook check
lived in `report_export_failure()`, which runs only when the direct export read
*also* fails — and it never does, because it never asks the loader anything. So
the one measurement that would confirm interception never ran in the case
interception was suspected. It is now on the fallback path.

**The hook check ran and gave its third answer.** On the fallback path:

```
export: reference GetProcAddress (from kernel32's own export table, bypassing our IAT)
       at 0x7FFE056B88F0; our IAT GetProcAddress; target GetLastError=126
       -- both returned NULL, so the reference GetProcAddress denies it too.
```

**Our IAT entry is not replaced** — the denial is inside `GetProcAddress` itself.
The instrument's limit, stated plainly: it separates *IAT-hook* from
*not-IAT-hook*, but it cannot separate an **inline hook on GetProcAddress's body**
from a **policy inside GetProcAddress**, because both pointers then lead to the
same patched code. Distinguishing those needs a disassembly of the entry, which
is not worth writing unless the question becomes load-bearing.

**Verified separately, and this is the useful part: the hand-read pointers are
sound.** Three of the six exports are direct prologues; the other three are `E9`
thunks sitting immediately before `CC CC CC …` **INT3 padding** — and INT3 is
precisely what a "breakpoint encountered" dialog reports. Each thunk follows to a
valid prologue in one hop, which is what `follow_export_thunk` does. So the one
place in this project where a pointer mistake would produce the reported dialog
has been checked, and the thunk-following is correct on all three.

**A crash later the same evening was `0xC000070E`** — §5.3's fault, sixth
occurrence, same address, outside this module, on a thread that wrote nothing to
the log. The mod's own thread completed startup normally. The user separately
reported a "breakpoint encountered" dialog, which does **not** match that code
(`0x80000003` vs `0xC000070E`); recorded as an open discrepancy rather than
reconciled, and the log now carries **`pid=`** so "which process, and did it
report a second exception" is answerable next time.

**A pattern worth naming without over-reading it:** in every session observed,
the **first** launch fails and later ones succeed — 3-then-1, 1-then-1,
1-then-1-then-0, and again on 10-02 where the first launch logged `6 of 14` and
the fallback saved it.

**Next launch will confirm, and it is now instrumented to say so.** The boot gate
logged `path="<not loaded>"`, which conflates "the module is absent" with "the
loader will not name a module that is present" — two states needing opposite
responses. `il2cpp_offsets::log_module_state()` now reports the handle, whether
the loader **lists** it, whether it will **name** it, the module count, and
`SizeOfImage` read straight off the module's own PE headers, which works even
when the module is mapped but unlisted. It is called **twice**, at the Unity gate
and again after `il2cpp_offsets::init()`, so the pair is a timeline: if
membership flips between them the unlink races startup and a retry would have
been worth something; if it is already unlisted at the gate, the direct read was
the only thing that could ever have worked.

`init()` also logs how many of the 14 required symbols needed the direct read —
`0` means the fallback stayed idle, which is a real result and not a no-op line,
since a launch that never hits the problem and a launch the fallback saved would
otherwise look identical.

**SOLVED, and the diagnostics named the cause on their first run.** `GetLastError=126`
is `ERROR_MOD_NOT_FOUND`, and `GetModuleFileNameW` failed on the same handle —
both resolve a handle *through the loader's module list*. Meanwhile the boot-gate
line recorded `SizeOfImage=0x66ED000` read successfully, matching the manifest's
identity exactly. **The image is mapped and fully readable; the loader does not
list it.** An LDR entry was unlinked while the image stayed loaded, which is why
it is sometimes listed and sometimes not, and why no wait duration or readiness
semaphore could have fixed it — the game is ready the whole time.

The hand-rolled reader's verdict was independently confirmed: a separate parser,
in a separate language, reading the on-disk `GameAssembly.dll`, agrees on **6/6**
ordinals and RVAs. Two independent readers agreeing is what makes the fallback
trustworthy rather than merely plausible.

The fix inverts the order: `GetProcAddress` is tried first (it is the loader's
canonical answer and the only thing that resolves a forwarder), and on failure
`resolve_export_body` falls back to the direct read and continues into the
existing thunk-following. A range check refuses to call anything that lands
outside the image.

Two things recorded because they are the kind of mistake this project keeps
making. The first version of the fallback assigned the bare **RVA** to the
variable that `follow_export_thunk` hands to the call site — which bounds-checks
against the image, so a bare RVA is out of range on every hop and the mod would
have called the head of the image. Caught on review, before deploy. And
`is_in_loader_list` was first written as a hand walk of
`PEB.InMemoryOrderModuleList`, which needs `PEB` / `PEB_LDR_DATA` /
`LDR_DATA_TABLE_ENTRY` — undeclared under `WIN32_LEAN_AND_MEAN`, which this
project sets — so it would have meant redeclaring loader structures and trusting
their offsets on the path whose purpose is to diagnose something subtle. It now
uses `EnumProcessModulesEx`, which is read-only and cannot write to loader memory
the way a hand walk can if the base-of-entry arithmetic is wrong.

### 0.3 Chams: a null bundle, a state machine that could not leave, and a root cause

`asset_bundles::check_progress` returned `bool`, so *"still loading"* and
*"finished but `get_assetBundle` returned null"* were indistinguishable. A failed
request was therefore polled every frame for as long as it lived, and
`logger::error` is ungated by design — **11,903 lines, one message, 46/second,
85% of a session's log.** The `bundle_retry_after_ms_` backoff existed but only
guarded the *not-started* case, and the watchdog required
`reload_watchdog_armed_`, which is set only on the reload path.

Two independent causes, and suppressing the log would have fixed neither:

- `check_progress` now returns `Loading` / `Loaded` / `Failed`; `Failed` is
  terminal for that request, so the request is dropped and the pre-existing
  backoff applies.
- The underlying cause: **`reset_bundle` never called `Unload`**, leaking the
  native AssetBundle registry entry.

The `report_item_chams_scan()` `accounted` sum also omitted `st.null_obj`, so a
tick full of null `loot_obj` entries reported them as `unaccounted`. `st.unpainted`
is still missing. Verified: `get_assetBundle returned null` 11,903 → **0**.

### 0.4 Documentation, and what it cost

Every markdown file in the repository was audited against the tree, the harness
and a live log. Four were materially wrong, and one of the errors was a *missing*
defect rather than a stale number:

- `WORKFLOW.md` quoted a 118 s build that its own companion document says does not
  reproduce (current: 128–132 s), and had no mention of `tools/harness` at all.
- `tools/harness/README.md` documented `test_data_paths.cpp`, which no longer
  exists, plus a `logger_stub` workaround and a three-way `%APPDATA%` guard for a
  header that became `tools/migrate_legacy.py`. The guard is not merely deleted:
  the Python `migrate(legacy_root, deploy_root)` takes the roots as arguments, so
  the 23-real-files hazard in `WORKFLOW.md` is unrepresentable rather than guarded.
- `tools/tracy/README.md` listed 6 zones against 65, and described the optics memo
  as 256-slot.
- `CHANGELOG.md` §1 says *"the bypass reads its manifests from
  `ta\compatibility\profiles\`, matching the in-game DLL."* That was true and the
  in-game DLL did not. **It is the sentence that should have caught 0.2**, and it
  was written before the reader was broken and never revisited.

Two lessons from the pass, both of them the same one:

- **Count what the runners execute, not the files in the directory.**
  `tools/harness/` holds eight `.cpp` files and the runners build seven;
  `test_card_fold_realfile.cpp` is wired into nothing.
- **A checker that passes on a comment is not a checker.** The first version of
  `test_profile_path.py` matched `data_directory_wide` in the function body — where
  the fix's own explanatory comment contains that string. Reverting the code and
  running the negative control returned 10/10. It only failed after comments were
  stripped before matching. That is the fourth instance in this project of a tool
  reporting success because it did nothing, and the only reason it was caught is
  that the control was actually run.

### 0.5 The chams/OpenGL work, and where the frame goes now

Not part of this pass — the other workstreams' areas — but the numbers move:

| zone | self | share | calls |
|---|---|---|---|
| `hideout::Card::refresh_hideout_state` | 155.7 s | 8.68% | 171,433 |
| `hideout::HideoutProductionRequirementView::Show` | 34.8 s | 1.94% | 7,881 |
| `skeleton_vis::occlusion_linecast` | 18.7 s | 1.04% | 1,810,284 |

`refresh_hideout_state` is **908 µs per call and runs once per frame** — its call
count is identical to `game::tarkov_application_update`'s, so it is 1:1 with the
frame. That is 8.7% of a 30-minute capture spent on hideout state, on a path
that is menu-side. The `skeleton_vis` split paid for itself: 18.7 s for the raycast
against 69.3 s for the same work before it was split.

Accounted time across all 65 zones is **14.2%**; the other 85.8% is the game's
render, physics and netcode on threads this mod does not hook. That is a ceiling
on instrumentation, not a gap in it.

### 0.6 The Quest Completer card can say what a quest asks for

The card's dropdown listed quest **names** and nothing else. Everything that
decides which quest to hand in next — the items to bring out, the enemy types, the
count on each — was only visible in the game's own journal, which an overlay
cannot reach. So the card could complete a quest and could not tell you what it
was, which is the question a player opens it to answer.

Two things now read off the quest, both from the game's own data rather than a
translation of a condition class name:

- **A checklist for the selected quest**, one row per objective, with its
  current/target count and a tick box. The text is
  `Condition.get_FormattedDescription` — the same call the journal's
  `ObjectiveView` makes — so it reads the way the journal reads.
- **A `[done/total]` tally in each dropdown entry**, so a quest that is one
  objective from finishing is distinguishable from one that has barely started.

"Summarised" is load-bearing: a quest asking the same thing in three separate
conditions is **one row with the counts added**, not three. `done` on a merged row
is the AND of its parts, because OR-ing reports a quest complete while one of its
objectives is outstanding. Outstanding rows sort first, and the order within each
group is the quest's own.

New: `module/quest_objectives.h` reads a live quest, `module/quest_objective_text.h`
decides what a row says, and `QuestModule` publishes the result through the same
`atomic<shared_ptr<const snapshot>>` hand-off `HideoutModule` uses. Quest objects
and Condition pointers are raid-scoped, so the text cache, the badge map and the
selected-quest id are all dropped at the raid boundary — a pointer-keyed cache
across that line can hand back a new object's address a freed one's used to have.

**Cost, and the shape it drove.** The detailed pass resolves
`FormattedDescription` per condition — a managed property that formats and
localizes — and looks up the item factory per template id. That is fine for one
quest every 300 ms and would not be for the whole list, so the dropdown's tallies
use a three-calls-per-condition pass run **round-robin, one quest per scan**. On a
late-wipe profile that is a couple of quests' worth per scan instead of ~150 extra
IL2CPP calls, and the only thing it can delay is a number in a dropdown the player
is not currently looking at. The selected quest is always refreshed in full.

**Three i18n keys, all 19 locales**, inserted at their sorted position rather than
through a JSON round-trip: `i18n::tr()` has no fallback chain (`util/i18n.cpp`
returns the key itself on a miss), so a key in one file renders as a literal
`quest_obj_title` in the other 18.

**Coverage: 183 assertions**, `tools/harness/test_quest_objectives_text.cpp`, in
both runners. It compiles the real `quest_objective_text.h`, which is its own file
precisely so the logic with decisions in it can be tested without the game's object
model — the verb table's ordering (`ConditionPlaceBeacon` and
`ConditionLeaveItemAtLocation` both derive from `ConditionZone`, so a `Zone` test
in front of them relabels every beacon), the summing, the stable ordering, the cap,
and the UTF-8 truncation boundary.

**One assertion found a real defect.** `same_label` was `std::tolower` with a
comment claiming case-insensitivity. It is **not** case-insensitive for any
non-ASCII label: the CRT is in the `C` locale because nothing calls `setlocale`,
so it folds A-Z and returns every other byte unchanged — and a Russian label is
UTF-8, where "Тест" and "тест" are *different bytes* (`D0 A2…` vs `D0 B2…`).
Measured, not reasoned. It is now an explicit ASCII fold, the limit is documented
where the code is, and the Cyrillic pair is a permanent assertion. The usual
`(c | 0x20)` one-liner is also rejected in the test: it maps `'@'` (`0x40`) to
`` '`' ``, which merges two different objectives into one row.

**What is NOT covered, and is the larger half.** The functions that read a live
quest — the `get_Conditions` walk, `IsConditionDone`, the progress checker's
`CurrentValue`, the SEH-guarded description read, the target field walk — all take
an `Il2CppObject*` and need the game. No executable assertion reaches them, here or
anywhere.

**One thing that would have been a latent crash, checked against the dump rather
than assumed.** Every managed call in the new file passes its `MethodInfo` as a
trailing argument, which the rest of this project usually does not. Both
spellings work for a method that ignores the argument — x64 puts it in a register
the callee never reads — so the existing style is not wrong, just narrower. It is
wrong for a method declared on a **generic type**, and `Conditional<TConditional>`
is one. `IsConditionDone` reads the register unconditionally:

```
mov rdi, r8          ; the MethodInfo
...
mov rax, [rdi+20h]   ; rgctx, dereferenced with no null check
```

(`ISIL-references/.../Conditional`1.txt`.) Omitting it there hands the callee
whatever the caller left in `r8`: a garbage pointer read, which is neither a
compile error nor reliably a crash — it is a small offset from a near-null
address, so it surfaces later and somewhere else. Passing it always is correct in
both cases and free in the one where it is ignored.

**The checklist never appeared, on the first deploy.** `publish_objectives()`
set `detail_ready = true` and never set `detail_id`, and `draw_menu_extra()`
requires both:

```cpp
if (!snap->detail_ready || snap->detail_id != selected_quest() || snap->detail_id.empty())
    return;
```

So the objectives were read off the quest, formatted, merged and counted every
scan, published into a snapshot, and then discarded on arrival — a gate that
could never open. Nothing on the card said so: there was no row, no empty
section, no error, and no log line, because from the code's point of view every
step had succeeded. It surfaced only because it was run in the game and the
checklist was not on screen.

The cause is worth naming precisely because it is not a typo: `detail_ready` and
`detail_id` are not redundant, and the two questions they answer are different.
"Do I have a checklist" is `detail_ready`; "may I draw it" is `detail_id`, which
must match the selection *and* be non-empty. Writing only the first produces a
snapshot that is complete and unusable. Both fields are now set together, with the
reason in `QuestModule.h`.

**What this says about the verification.** Everything in this section is verified
by build and by the harness — and the feature did not work. The harness cannot
catch this one, and that is a property of the case, not an oversight: the bug is
in the hand-off between two threads through a snapshot, and `quest_objective_text.h`
has no knowledge of snapshots, quests or threads. It is the same shape as the
`HideoutModule` repopulate crash noted above, where a race stayed dormant until
data actually started arriving. A build cannot express "this gate can never
open" and a unit test over a pure function cannot either.

Verified: all four x64 configurations (`Prod`, `Prod no aimbot`, `Release`,
`Debug`) build with 0 errors and 0 code warnings; `run_windows.bat` exit 0 across
all nine cases; `pytest tools/tests` 149 passed / 6 subtests. The checklist was
observed missing in-game on the first deploy, and the fix is **still NOT
verified in game** — the DLL could not be replaced while the game was running, so
the corrected build has not been loaded. What to check once it is: that the
objective rows appear for a quest in progress, that the dropdown tally advances as
objectives complete, and that the rows stay stable rather than shuffling between
scans.

### 0.7 Pressing "Start Profiler" could kill the game, and it did

The user reported the game dying when they started the Tracy profiler, under heavy
load, and asked whether that was a coincidence. **It was not.** It is also the first
crash in this project that produced a stack, and the first fault inside our own
module.

```
code=0xC0000005  ACCESS_VIOLATION READ of 0x0000000000000008
faulting rva +0x100B03  ->  tracy::GetProfilerThreadData +0x43
  #0 tracy::profiler::Zone::Zone +0x2E7        <- the only frame that holds up
  #1,#2,#3,#5  ??_C@_0CL@... string literals    <- data, not code
  #4 asset_bundles::check_progress +0x239
  #6 dxhook::release_texture_id +0xE0
```

The faulting instruction is the answer, and the fault address is exact:

```
mov rdi, qword ptr [rip + 0x31b4e9]   ; rdi = tracy::s_profilerData
add rdi, 8
mov rbx, qword ptr [rdi]               ; <- READ of 0x8
```

**Only the fault address should be trusted.** The probe collects stack words whose value
falls inside our module's range; it does not check they are return addresses. Four of
the seven resolve to `??_C@_...` compiler-generated **string literals**. Worse, a
truncated symbol table made frames #4 and #6 resolve to `hk_tarkov_application_update`
and `dxhook::WndProc` — a call chain I wrote down as fact before checking it. It was
the parser's fault. `tools/symbolize.py` drops symbols in a table's holes and resolves
them to the nearest preceding symbol, which invents a plausible and wrong neighbour
rather than admitting ignorance. **A truncated symbol table does not degrade into
"unknown".**

**`tracy::s_profilerData` was null.** Under `TRACY_MANUAL_LIFETIME` all of Tracy's
state hangs off that one plain non-atomic pointer, and `GetProfilerData()` is
`TRACY_ASSERT(s_profilerData); return *s_profilerData;` — the assert compiles out
under `NDEBUG`, which both Prod configs define, so there is no null check at all.

`util/tracy_bridge.cpp` was:

```cpp
bool start() {
    if (g_started.exchange(true, std::memory_order_acq_rel)) return true;  // publishes
    StartupProfiler();                                                    // allocates
    return true;
}
```

`g_started` is the gate every `tracy::profiler::Zone` reads. So the button published
"started" and *then* allocated the profiler data, and any `TA_ZONE` on any other
thread in that window built a real `tracy::ScopedZone` against a null pointer.
`StartupProfiler()` spawns worker threads before returning, so the window is not
narrow — and under load the main thread is in instrumented code more of the time,
which is exactly why the load looked causal. It was not; it widened the window.

**The fix, in two parts.** `start()` now calls `StartupProfiler()` first and
publishes `g_started` second — that is the defect. And `running()` now returns
`g_started && tracy::IsProfilerStarted()`: Tracy sets that flag as the *last*
statement of `StartupProfiler()` and clears it as the *first* of
`ShutdownProfiler()`, so it is the one flag that cannot be true while
`s_profilerData` is null. That second part is not the fix; it makes the invariant
structural rather than positional, because statement order does not survive
refactors. `IsProfilerStarted()` is a bare atomic load — `ZoneIsActive` and
`GetProfiler().IsConnected()` would **not** work, they dereference the very pointer
being guarded. `client_attached()` now goes through `running()` so there is one gate
rather than two that can drift.

**Verified in the shipped binary.** Disassembling the deployed
`tracy::profiler::Zone::Zone` (rva `0x44B70`) shows both flags read, each with a
branch to the inert path, before anything calls into Tracy:

```
00044BAD  movzx eax, byte ptr [rip + 0x3d780b]   ; -> g_started
00044BB6  je   0x44f46                              ; inert
00044BBC  movzx eax, byte ptr [rip + 0x3d77f5]   ; -> tracy::s_isProfilerStarted
00044BC5  je   0x44f46                              ; inert
00044C02  call 0x100AC0                            ; only now: tracy::GetProfilerData
00044C07  mov  rbx, qword ptr [rax + 8]             ; the read that used to fault
```

**`tools/tests/test_tracy_start_order.py`, 6 cases, with a negative control that
fires.** It is a text test and says why that is adequate rather than a compromise: the
invariant is the position of two statements in one function, and observing it for real
means racing threads under a debugger. Comments *and string literals* are blanked
before matching, because the control that matters is a source whose comment claims
the right order while the code does the wrong thing — the same shape that made
`test_profile_path.py` vacuous in its first version. Checked against the real pre-fix
file from git, which it rejects, naming the cause rather than a downstream symptom.

**A long-standing explanation in `tracy_bridge.h` was wrong and is now retracted.** It
held that `TRACY_CALLSTACK` caused a crash, because four `0x40010006`
(`DBG_PRINTEXCEPTION_C`) events landed on the dying thread and the only
`OutputDebugStringA` on that path was the symbolizer's own `SymError()`. That
inference from fingerprints did not survive a crash that came with a stack.
`TRACY_CALLSTACK` stays `0` on its original reasoning — `RtlWalkFrameChain` over an
unregistered `.pdata` in a manually mapped, LDR-unlinked DLL is not an input to trust
— but it was never what killed the process.

**Live confirmation, 20:50 the same day.** A later session on the rebuilt DLL pressed
Start Profiler at 20:50:12 and ran to 21:16:48 with no fault. That is the one check
that could not be faked. That session also logged `0 of 14` direct reads — the first
launch in a while where `GetProcAddress` worked normally and the export fallback never
engaged.

**A tool was wrong twice while writing this up, and both are worth knowing about.**
`tools/symbolize.py`'s first regex dropped 26,363 of 43,619 symbols and invented
neighbouring functions for the holes; its `--file` mode then treated system-dll
addresses as RVAs and matched only `at <addr>` while the probe's frame lines have no
`at`, printing a full confident wrong table. A tool that under-reports, or reports
confidently when it did nothing, is worse than no tool. It now prints its symbol count
and flags offsets too large to be plausible.

**Not retired: the older `0xC0000005` `EXECUTE` at `0x0` with `frames=0`.** Still
unexplained. It dies during *"Waiting for Unity window to become ready"*, before
`Loading Il2CPP API`, so no instrumented zone could have been running. The shape
rhymes with this one; it is not this one, and the resemblance is recorded so it does
not quietly become a conclusion.

**And a related gap, now measured rather than assumed:** `crash_probe.h` explicitly
returns `false` for `0x80000003` (BREAKPOINT) and `0x80000004` (SINGLE_STEP), so those
are captured and never printed, and the ring is only dumped when something fatal fires.
A later session produced another user-visible "breakpoint encountered" warning without
crashing, and the instrumentation is structurally incapable of confirming or refuting
it. What can be said: we raise no breakpoints (`DebugBreak`/`__debugbreak`/`int 3`
appear nowhere in our code), and a breakpoint that had gone unhandled would still have
reached the unhandled-exception filter and been logged — nothing was logged, so **it was
handled.** Outside this module, most likely the game's `Debug.Break()` or anti-cheat.

**New: `tools/symbolize.py`.** Turns the crash probe's `address +rva` frames into
names against the linker `.map`, and can pull the frames straight out of a log with
`--file`. It is what made this diagnosis a reading rather than a guess.

### 0.8 A crash we could not name, and the three gaps it exposed

A new crash arrived — **not** the Tracy bug, not the breakpoint:

```
code=0xC0000005  ACCESS_VIOLATION READ of 0x0000000000000050
faulting rva=+0x1AD7AA   tid=23656   frames=11
captured #4036 … #4059   (the ring had already wrapped past 4000)
```

Different code, offset, read size and thread from the 19:47 crash, in a third session
(`pid=4588` — the `pid=` field telling three writers apart in one file).

**It is ours and it is unnameable, and that is the finding.** The crash ran build stamp
`0x6AC00784`; the `TarkovAddons.map` sitting next to the DLL was `0x6AC0093E`, a **later**
build deployed between the crash and the read. Not a missing-symbols problem — `install`
already ships `.map` and `.pdb`. The problem is that one slot gets overwritten by the
next install.

That is measurable rather than arguable: a function entry starts with a
push/sub/endbr64/REX prefix, so a stale RVA under a shifted map lands mid-instruction.
**1 of 11 frames decoded plausibly**, and the fault address decoded to nothing. The first
symbolization pass offered `AimbotModule::AimbotModule +0x2EA`, `menu::draw +0x1D5B`,
`dxhook::dxPresent12 +0x1ACC` — a tidy render-frame story, entirely invented, and caught
only because the decode check ran before the names were believed.

> The build stamp **detected** the mismatch, which is what it was added for. It did not
> *name* the crash. Noticing that you cannot read the answer is not the same as reading it.

**1. Symbols are archived per build.** `deploy.py install` now also writes
`symbols\<PE-TimeDateStamp>\` beside the DLL, newest 8 builds retained. The stamp is the
same field `crash_probe.h` prints, read by `deploy.build_stamp()` from the same place — a
crash log plus one directory listing is now enough to name any recent crash. Re-installing
the same stamp overwrites in place instead of consuming a slot. `symbols\` survives a plain
`uninstall` on purpose, since it is the only thing that can name a crash from a build you
have since replaced; `--purge` removes it explicitly, because a purge that quietly leaves
44 MB per build behind is not a purge. Archive failure warns rather than failing the
install.

`tools/symbolize.py --build-stamp 0x6AC00784` selects the archived map by that name, and a
stamp with no archive exits listing the builds it *does* have rather than silently
symbolizing against the current one — which is the exact mistake this section is about.

**2. Frames that are not frames.** The probe collected any stack word inside our address
range and called it a frame; on 19:47, four of seven resolved to compiler-generated
**string literals**, and the call chain built from them had to be retracted.
`fill_event` now tests each candidate with `RtlLookupFunctionEntry`, which consults
`.pdata` and so answers code-vs-data exactly — no PE headers needed, which matters for a
manual-mapped image whose headers may not have been copied. Rejected words are **counted
and reported** (`frames=3 (+4 in-module data words, not code)`) rather than silently
dropped, because silent filtering is what made the old report look complete when it was
not.

**3. Per-code totals.** A user-visible "breakpoint encountered" was structurally
invisible: `0x80000003` is deliberately excluded from reporting and no total existed
anywhere. `g_code_count`/`g_code_bits` are 8 relaxed-increment slots bumped in `record()`
before the ring write, and `emit_code_histogram()` prints the whole session's history
**last**, after the per-event list — the ordering is the point, since `captured #4059`
means nothing alone while "4059 of 4060, and the rest were `DBG_PRINTEXCEPTION_C` on one
thread" is a diagnosis. Collisions name both codes rather than one wrong name. A clean
session still cannot print it: no exit hook survives a hard kill.

**Also:** an access violation now states its own arithmetic (`address is null + 0x50`,
`offset +0x50 from <base>`). "Null plus a field offset" has been the right reading every
time, and it took three crashes to notice it was implicit.

**Still open:** the 22:0x crash itself. `symbols\6AC00784\` does not exist — that build
predates the archive — so it will never be named. It is a `null + 0x50` read, the same
shape as the Tracy `null + 8`, and that is as far as the evidence goes.

**The histogram's first output changed a conclusion, on its first run.** The next crash
was §5.3's `0xC000070E` again, and now with numbers:

```
crash probe: 36 exception(s) seen, by code:
crash probe:   0xE06D7363 C++ exception                               x7
crash probe:   0xC000070E THREADPOOL_FREE_LIBRARY_ON_COMPLETION_FAILED  x29
```

**29, not one**, across three threads. Six previous sightings had been logged as six
isolated events and read as a stray; it is a burst. And the session is 387 ms long — the
process died a quarter-second after `Menu Key: Insert`, during the game's own start-up
rather than during play. That is the first hard timing this fault has had, and it is a
much smaller thing to chase.

**And it found a bug in itself, which is the more useful half.** The first shipped version
hashed into 8 slots and kept `fetch_or(code)`, treating a slot as a *set* of codes. Two
codes sharing a slot OR to a value whose individual bits are not codes, so the printer
could only say "?", and it said so on this very log:

```
0xE06D7363 ?/?/?/?/?/?/?/?/?/?/?/?/?/?/?/?/? (merged slot) x7
0xC000070E ?/?/?/?/?/?/?/? (merged slot)              x29
```

The counts were right; the naming was noise, and the naming is the point of a histogram.
Rewritten as a 16-slot open-addressed table, one code per slot, lock-free via
compare_exchange with linear probing — which is not optional here, since `count_code`
runs inside the vectored handler and a lock there can deadlock. The collision is real,
not hypothetical: `0xE06D7363` and `0x80000003` both hash to slot 3 under the current
constants, so the old design *would* have merged the C++ exception count with the
breakpoint count on any machine that raised one.

Total and per-slot sum are tracked separately so a full table reports a shortfall instead
of letting the two numbers quietly disagree.

**Symbolizing used the archive on the first try**, which is the real proof the §0.8
change works:

```
build   6AC07EA6 -> ...\symbols\6AC07EA6\TarkovAddons.map
[addr] rva 0xDEFFBD49  OUTSIDE the symbol span 0x0..0x9D5348 -- not in this image, skipped
```

Right build, and the fault is in `kernel32` — outside us, as §5.3 always said. Compare the
22:0x crash, where no archive existed and 10 of 11 frames were invented.

### 0.9 Aimbot / pen-check: the wall check could not tell our own arm from a wall

A wiring review of the aimbot and the penetration walk turned up one functional
bug, two latent ones in the same family, and an instrumentation gap that had kept
#20 unanswerable.

**The pen walk had no shooter argument.** `is_target_visible` has taken
`shooter_obj` for a while and classifies a hit three ways — `none` / `shooter` /
`target` — via `classify_hit_transform`. `is_target_visible_penetrating` did not
have the parameter at all and tested hits with `is_player_transform()`, which
passes a **null** shooter. So a hit on the local player's own collider walked the
full 48 hops, matched neither the shooter nor the target, fell through to be
classified as a **layer**, found no `BallisticCollider` on it, and returned
`no BallisticCollider on hit chain (env/terrain)` → **BLOCKED**.

That is the ESP's exact bug, already root-caused and fixed there, reintroduced on
the path that was never given the fix. It was near-certain rather than occasional
because the walk's ray origin *is* the shooter's own fireport — the first collider
it meets is frequently the shooter's own body. Self-hits are now recognised,
skipped without consuming layer budget, and reported as their own exit. This is
the change most likely to alter observable behaviour, in the permissive direction.

**`vector3::length()` is the squared magnitude, and three call sites wanted the
real one.** `unity.cpp:41` returns `x*x + y*y + z*z`. Two consequences:

- `kVisOriginTrustRadius` was documented and named as an **8 m** camera trust
  radius but was written `(out - rig).length() <= kVisOriginTrustRadius`, i.e.
  `sq_dist <= 8` — an effective **2.83 m** wearing an 8 m label. A camera 3 m from
  the rig, a normal third-person shoulder offset, was being rejected as "probably
  another player's", which pushed the ESP onto the fireport path far more often
  than the constant's own comment says it should.
- Both `hit.m_normal.length() < 0.1f` inside-hit filters were really `|n|² < 0.1`,
  a `|n|` threshold of ~0.316. Now `unity::length()` in both. The change is in the
  safe direction: that branch returns *visible*, so a stricter normal test converts
  former "occluder" verdicts into "clear", never the reverse.

**A transform read at the world origin is not a position.**
`unity::transform_get_pos` returns exactly `{0,0,0}` for a null transform *or* an
unresolved `get_position` pointer (`unity.h:761`) — and the player rig also reads
`{0,0,0}` while it is still being placed, which is the same window in which
`Camera.current` was independently reported to belong to a bot. Taken at face
value, a rig at the origin (a) made every real camera look tens of metres away and
(b) then supplied `{0,0,1.6}` as a ray origin via the rig fallback, i.e. every ESP
and pen ray started at the map corner. An `is_degenerate_origin` guard now rejects
those reads; `try_get_fireport_position` reports a degenerate muzzle as a *failed*
read, so `hk_initiate_shot` falls back to the engine's own direction instead of
normalising `target - {0,0,0}` and aiming the actual shot at the map corner.

The camera trust test now measures against the **fireport** when the rig is
missing or unpopulated — the reference measured in-game as the one that works, and
the point the bullet actually leaves from. It is a repair for the degenerate case
rather than a permanent change of yardstick: resolving the fireport costs two
*uncached* `resolve_method` walks, and paying them every frame to fix a window that
lasts a second or two at raid start is a bad trade. The read is memoised so the
trust test and the fallback share one lookup.

**`skeleton_visibility.h` is now split along the flavour boundary.** The penetration
model was compiled unconditionally, which contradicted the point of `INCLUDE_AIMBOT`:
`Prod no aimbot` shipped `classify_blocker`, `assess_ricochet`,
`terrain_ballistic_at`, the `Shot.TryGetBallisticCollider` resolution and the whole
630-line walk with no caller for any of them — and because `ensure_penetration_init()`
was reached from `ensure_init()` via ESP's `is_ready()`, even the `BallisticCollider`
class + `System.Type` lookup ran in a build that cannot use it. The model is now
inside `#ifdef INCLUDE_AIMBOT`; the plain visibility half is not, because ESP needs
it in every build. Verified by string-scanning the two binaries: `pen-check: ammo
power`, `no BallisticCollider on hit chain`, `TryGetBallisticCollider` and `raycast
budget exhausted` are present in `with_aimbot` and absent from `no_aimbot`, while
the shared reporter/enum strings are in both by design. 8,486,400 vs 8,435,200
bytes, −51,200.

**The pen-check had no numbers.** The 30 s `vis-breakdown` counters are fed
exclusively by `is_target_visible`, so every Magic Aim wall check reported nothing:
not how often it cleared, not how often it blocked, and above all not *why*. The
only trace was one `pen-check:` string per 500 ms, which cannot answer "is the wall
check discarding 90% of targets or 0.1%?" — the actual open question in #20.
`classify_blocker` handed back a `const char*`, and a string cannot be counted; it
now returns a `pen_stop` that is the single source of truth for both the log
message and the tally. Every exit funnels through one `finish()`, which is the only
place the tally is written, so "exactly one bucket per call" is a property of the
control flow. The dump prints `[closed]`/`[MISMATCH]` on the same argument as the
visibility set. Two exits that were uncountable — `no_ammo` (the most likely reason
a wall check silently discards everything: reload with nothing chambered) and the
sub-0.1 m degenerate ray — are now buckets of their own.

**Smaller items.** `wall_check` was visible and inert in Magic Bullet mode, which
teleports the bullet rather than tracing it, and the pick loop gates on
`aim_type > 1`; it is hidden there now. `gameworld_update` recomputed the aim-cone
radius inline instead of calling the `aim_cone_radius()` helper that exists
precisely so the gate and the drawn circle cannot drift. The candidate pick's
`closest` / `distFromReticle < closest` / `break` construct could only ever be true
on the first survivor and never influenced the choice — it is now a plain `picked`
flag, matching the selection rule the code actually implements (nearest by 3D
distance, first to pass every filter).

Both `Prod|x64` and `Prod no aimbot|x64` build clean; `tools/tests` is 155 passed.

### 0.17 `get_lossyScale` was called with no `this`, and killed the process five times

An ACCESS_VIOLATION that survived three separate misdiagnoses, and the actual cause
was one missing argument.

**The bug.** `try_get_lossy_scale` is the only call in this codebase that resolves an
**instance** getter and then calls it through a **zero-parameter** signature:

```cpp
static unity::vector3 (*fn)() = nullptr;   // no `this`
...
out = fn();                                 // never passes `transform`
```

`UnityEngine/Transform.cs:170` declares `public Vector3 get_lossyScale()`, an ordinary
instance property — so the callee reads fields off `this` immediately, and `this` was
whatever happened to be in `RCX`. The fault was always `garbage + 0x10`:

```
0x00001F8500000010   0x0000369400000010   0x0000429400000010
0x0000488C00000010   0x000050AC00000010
```

Five sessions, one shape. The signature is now
`unity::vector3 (*)(Il2CppObject*)` and the call passes `transform`. Verified in the
rebuilt image: the call site gained `mov rdx,rdi` — the argument was genuinely absent
before. It is correct per the x64 ABI, where a 12-byte struct return occupies
`RAX:RDX`, so the hidden return pointer takes `RCX` and the first declared argument
takes `RDX`.

**How three wrong answers survived, since that is the part worth keeping.** Every
crash reported the fault address as `<outside this module>`, and on the first two I
concluded — correctly — that the fault was in a managed method we had called. Then
wrongly, twice, about *which* one:

1. **"It's the bullet `HitMask`."** `pen-check: bullet HitMask` prints once per process,
   immediately before the first raycast, so "a crash followed it" was an artifact of
   print timing rather than evidence. n=2 and I treated it as a correlation. Turning the
   mask off then broke the feature outright: with the occlusion mask the raycast hits
   plain `*_COLLIDER` meshes that carry no `BallisticCollider`, so every layer resolved
   `noBallisticChain`, `accumulated=1.000`, and everything blocked as env/terrain. The
   mask excludes the layer the `*_BALLISTIC_*` objects live on. Restored.
2. **"A page-readability guard fixes it."** `eft_api::is_readable_address_cached` answers
   *is this page mapped*. A freed `UnityEngine.Object` still has a committed page, so the
   guard returned true and the call faulted anyway. The 18:14 build shipped it and crashed
   in the same function, with the fault merely relocated `+0x242 → +0x2A2` because the
   guard shifted the code — which read as progress. The correct test is
   `unity::is_unity_object_alive`, which reads `m_CachedPtr`, the exact field being
   dereferenced. It is now on every managed call in `read_ballistic_identity`.
3. **"The liveness guard fixed it."** It was correct and necessary but not sufficient. A
   guard cannot help when the caller never passes the object: the callee was reading
   `&out`, a stack slot, which is not a Unity object at all.

What actually located it was symbolizing a frame I had twice dismissed as external. The
frames at `+0x1ACE63` were always inside our image — our extent is `0x9E6000` and those
offsets are far smaller — and I had mis-computed that twice before checking. Once
`tools/symbolize` ran against the deployed build's map, frame 0 named the function
immediately, and disassembling it showed a `call rax` with no argument-setup
instructions at all.

**The lesson, recorded because it generalises:** a crash whose fault address is outside
the image is still *caused* by our call, and the fix is to disassemble the call site
rather than reason about the callee. Also: `resolve_method` verifying arity says nothing
about whether you *pass* the arguments when you call through the resulting pointer.

### 0.10 Penetration grading now matches `IsPenetrated`, and the dump identifies the collider

Two changes from reading `EFT/Ballistics/BallisticCollider.txt`, both prompted by a
re-check of the 2026-10-03 log rather than by a symptom.

**The combined chance was computed by the wrong formula.** Decoded from raw
disassembly (`BallisticCollider.txt:1016-1036`), the game does:

```
movss xmm6,[rbx+6Ch]     ; shot.PenetrationChance
addss xmm6,[rdi+44h]     ; + this.PenetrationChance
call   NextFloat(...)    ; the roll
comiss xmm6,xmm0
seta   al                ; return sum > roll
```

It **adds** the two chances and draws once. `estimate_obstacle_penetration_chance`
computed `1-(1-a)(1-c)`, an independent-combination product, and its comment claimed
that matched the game. It did not. For the values in that log — M855A1 `obst=0.550`
through `penChance=0.580` — the old form reported **0.8110** where the game computes
**1.13** against a roll in `[0,1)` and therefore penetrates unconditionally. Every
layer, every frame, 19 points pessimistic on thin cover; any pair summing to ≥ 1 is a
certainty in the game and the old formula refused to call it one. That, not the level
gate, is the likeliest single contributor to the `ammo_vs_level` block tally
dominating that session.

Now `min(1, a + c)`. The clamp is behaviour-preserving rather than a safety net,
precisely because the roll is drawn in `[0,1)`. `ammo_obstacle_chance == -1`
("unknown") is folded to 0: the game has no such state, and under the product form it
had been silently becoming a plausible-looking `0.16`.

**The `go='...'` in the dump was never the object the numbers came from.** §0.9's
material table was built by pairing the raycast-hit GameObject's name with floats read
off a *different* object — the `BallisticCollider` that `Shot.TryGetBallisticCollider`
returned, which is the component on the collider or on the collider's **parent**. The
whole table was therefore spurious, and so was the `100.0` sentinel theory built on it.
`describe_layer` now emits, per layer, alongside the numbers:

- `owner='...'` — the **component's own** GameObject, so `owner` vs `go` shows directly
  whether the resolver returned the object that was hit
- `matType=` — `_typeOfMaterial` at +0x34, the authoritative `MaterialType` enum, which
  identifies the material without parsing the `_BALLISTIC_<name>` convention
- `presetId=` — `_presetId` at +0x28; **−900** is `OLD_PRESET_ID`
- `scale=(x,y,z)` — `Transform.get_lossyScale`

`_presetId` and `Awake()` also settle a question the previous investigation could not:
the `.ctor` writes `0xFFFFFC7C` (**−900**) and touches nothing else, and `Awake()` is
a single `BaseBallistic.Associate(this._typeOfMaterial)` call. **`BallisticPreset.ApplyScaleMult`
— the only writer that multiplies `PenetrationLevel` by `ScaleToPenetrationCurve`, with
a tooltip reading *"PenetrationLevel зависит от скейла"* — has no callers anywhere in
the dumped assemblies.** So the levels are baked serialised data, not a computed
product, and the scale path is dead at runtime. `get_lossyScale` is still logged: it
closes the question empirically in one run and is the cheapest way to notice a future
build where the call does exist.

The two hand-copied per-layer `std::format` blocks — which had already diverged, the
sibling copy having dropped the `NaN(unmodelled)` ricochet annotation — are now one
`describe_layer`. `get_name` allocates and the `get_lossyScale` resolve walks the
method table, so all of it stays behind the existing 500 ms `log_dump` gate.

Reading `matType`: `0 None · 1 Asphalt · 2 Body · 3 Cardboard · 4 Chainfence ·
5 Concrete · 6 Fabric · 7 GarbageMetal · 8 GarbagePaper · 9 GenericSoft · 10 Glass ·
11 GlassShattered · 12 Grate · 13 GrassHigh · 14 GrassLow · 15 Gravel · 16 MetalThin ·
17 MetalThick · 18 Mud · 19 Pebbles · 20 Plastic · 21 Stone · 22 Soil · 23 SoilForest ·
24 Tile · 25 Water · 26 WaterPuddle · 27 WoodThin · 28 WoodThick · 29 Tyre ·
30 Rubber · 31 GenericHard · 32 BodyArmor · 33 Swamp · 34 Helmet · 35 GlassVisor ·
36 HelmetRicochet · 37 MetalNoDecal · 38 Snow`. `-1` means the field did not resolve.

**Open, and not addressed here:** the ESP visibility result is still 99.97%
`hit_occluder` with `hit_target = 0` over 2.75 M rays (§0.9), and §0.9's fixes are
no-ops for that capture — the camera won 100% of origin decisions and `inside_hit`
never fired. That one wants the occlusion mask measured against the bullet `HitMask`.

### 0.11 The sixth capture: ESP still costs 12.4% of wall clock, and the visibility answer is still wrong

`next_next_day.tracy` (211 MB, raid 13:21:59–13:26:51 on factory4_day,
PVE_OFFLINE) is not written up anywhere yet. It is also the capture that reopens
§0.9's headline, so the two belong together.

**The raycast work improved.** `occlusion_linecast` is 27.97 s / **6.14%** over
2,964,255 calls at 9.4 µs each, against `current+6`'s 69.32 s / 9.26% over
5,534,508 calls at 12.5 µs. Per call that is −25%, and the call count roughly
halved. The raw *total* against `nextday` reads as a regression (18.7 s →
27.97 s) and is not evidence of one — `AGENTS_TODO.md` §5.7b already records an
83× spread in call count from the same binary, so no two-capture A/B in this
family can support a percentage claim in either direction.

**The hideout side of that capture is a real win**, and belongs to the hideout
workstream rather than to this file: `hideout::Card::refresh_hideout_state` went
155.681 s / 8.678% / 171,433 calls / 908 µs → **6.440 s / 1.413% / 38,467 calls
/ 167 µs**, and its call count now equals `game::tarkov_application_update`'s,
i.e. the draw-frame gating described in §5.7b landed. 24× less time.

**The finding, which is not a performance question.** Aggregating the eight 30 s
`vis-breakdown` windows (2,755,305 of the capture's 2,964,255 rays):

| exit | count | share |
|---|---|---|
| `hit_occluder` | 2,752,308 | **99.89%** |
| `ray_miss` | 2,997 | 0.11% |
| `inside_hit` | 0 | — |
| `no_transform` | 0 | — |
| `hit_shooter` | **0** | — |
| `hit_target` | **0** | — |

`hit_target = 0` cannot be a true reading. A ray from the camera to a bot's chest
that reaches the bot hits the **bot's own** collider; over 2.75 M rays that bucket
cannot never fire once. So `classify_hit_transform`'s 48-hop ancestor walk is not
recognising player-owned colliders, the ESP reports every limb of every enemy as
occluded, and ~119 physics casts per game update (≈2.96 M over the raid) are spent
producing an answer that is wrong every time. The feature is simultaneously the
largest single leaf in the capture and non-functional.

**Corroborated from a different mask and a different origin.** §0.9 fixed the
shooter/target classification in the pen walk. The aimbot's traces still show

```
L0 go='eurocube_skeleton_01_BALLISTIC_metalthin' dist=5.42 ... -> pass (clear)
L1 go='Catwalk_floor_concrete_01_BALLISTIC_concrete'      -> BLOCKED (ammo_vs_level)
```

`eurocube_skeleton_01` is a bone collider **on the target**. A working classify
returns `hit_owner::target` at L0 and ends the walk with "hit target"; instead the
target's own skeleton is walked as a penetrable layer and the floor behind it
decides the shot. Same walk, different origin (fireport), different mask
(`bullet HitMask = 0x40811810`), same failure — so this is the hierarchy walk, not
the ESP layer mask and not §0.9's `shooter_obj` wiring.

**The origin is ruled out by the same capture**, which is worth recording because it
closes off the theory §0.9 was built around reaching raid start:
`origin camera=3430 fireport=0 rig=0` — the trust-tested camera won *every*
resolution, so nothing here is the degenerate-`{0,0,0}` rig. `not_ready=0`, and
`g_transform_get_parent` is non-null by construction (`skeleton_visibility.h:290`).

**Added: a bounded one-shot hierarchy probe** (`probe_occluder_hierarchy`), called
only from the `hit_owner::none` arm — the branch that is 99.89% of rays. At most 12
samples, at least 2 s apart, then never again. The spacing is load-bearing rather than
decorative: at ~119 casts per update and ~114 updates/s a budget-only gate spends all
12 samples inside the first 100 ms of the raid — one player, one origin, one instant —
and that instant is precisely the raid-start window in which §0.9 records the rig
reading `{0,0,0}` and `Camera.current` independently reported as belonging to a bot.
An ungated probe would have collected nothing but the least representative samples and
presented them as authoritative. Each sample prints:

- `dist` — under 0.05 m would have taken the `inside_hit` exit instead, so a small
  value means "our own collider, the camera is inside it" and a large one means
  "real geometry". Opposite fixes; the counter alone cannot separate them.
- `layer` / `inMask` — separates "the walk is wrong" from "the mask is too broad".
  `try_get_occlusion_layer_mask()` ORs `PlayerStaticCollisionsMask`,
  `LootCollisionMask` and `InteractiveMask` in, and the camera sits inside the
  shooter's own colliders, so there is something to hit on every ray.
- the full ancestor chain of the hit, of the shooter and of the target, by name, plus
  whether the hit chain **contains** the shooter/target transform.
- `end=reached-root` vs `hop-ceiling` — "not parented under the player node" versus
  "deeper than the probe printed".

`CONTAINS shooter/target` is computed by re-walking the chain independently rather
than read off `classify_hit_transform`, because the walk's own verdict is the thing
under suspicion and cannot be its own evidence.

Cost discipline follows `WORKFLOW.md`'s rule that a per-frame trace must either
avoid string building or not exist: every string is built at most 12 times in the
life of the process, and once the budget is gone the entire steady-state cost on the
raycast path is **one relaxed atomic load** — the clock is not read at all, because
the budget check is ordered first. It logs at INFO rather than DEBUG because it is a
one-shot capture and must not require the debug toggle to be collected.
`GameObject.get_layer` is resolved lazily *inside* the probe rather than in
`ensure_init()`, which gates `g_initialized` on every pointer it resolves — a name
accessor there would be able to take the whole visibility feature down with it.

**Also added: a bounded slow-frame probe** for the 469.8 ms outlier, after
correcting two earlier notes that had blamed the wrong thing. `gameworld_update` is
mean 1.64 ms / std 2.97 ms / **max 469.8 ms**, but `collect_skeleton` is only 13.6 ms
of that — 2.9% — and `occlusion_linecast` max is 541 µs. The remaining ~456 ms is
*self* time: unzoned code. `EspModule::is_player_any_part_visible` already has a zone
and appears **zero times** in the capture, so the box-visibility path was off that
session and is excluded too.

- **Permanent, free when Tracy is compiled out:** zones on
  `esp_bones::get_player_body` and `esp_bones::get_skeleton_root`. That chain runs
  2–3× per bone lookup — ~1 M times per capture — and opens with an **uncached**
  `resolve_method` (`il2utils::resolve_method` has no cache, unlike `resolve_field`).
  Without them `get_bone_transform_by_name`'s 12.5 ms max was a single unattributable
  number.
- **Temporary, marked as such:** `slow_frame_probe` keeps six `steady_clock` phase
  timers in `gameworld_update` (setup / loop / row / box / skel / tail) and logs one
  line for any frame over **40 ms**, at most 6 times per process. 40 ms is >13σ of the
  measured mean, so no ordinary frame can trip it. The line prints `unaccounted` — the
  residual the named phases do not explain — so if that dominates, the cost is in code
  the probe does not name and the zones will; if `row` or `tail` dominates, one line
  settles it with no capture at all. Six clock reads per frame is ~20–40 ns each
  against a 1.64 ms mean, under 1%; the expensive part is building the string, and
  that is behind both the threshold and the budget.

Prime suspect, recorded so the reader can check it rather than re-derive it:
`refresh_cache_stats()`, throttled to once per second and documented in place as
walking **every** cache — `item_info_cache`, `container_item_caches_`,
`corpse_item_caches_`. O(entries) on the game thread, on a ~1 s cadence, unzoned. The
cadence matches the "one lone outlier frame" shape. Hypothesis, not measurement;
`tail` in the probe line is what settles it.

### 0.12 The probes answered: the visibility walk was never broken, and the hitch was the cache stats

`next_next_day+1.tracy` is a pre-instrumentation, hideout-only session — no new zones,
and useless as a control. `next_next_day+2+crash.tracy` is the instrumented build and
is what answers §0.10.

**The visibility classification is correct, and §0.10's central claim was wrong.** The
probe caught the ray hitting *a shelf on a yellow plastic barrel, 4.78 m away*:

```
hit chain: Rack_shelf_04_COLLIDER <- Rack_shelf_04 <- Barrel_plastic_01_yellow_clear Group
             <- 1 <- PROPS_spawns_exits <- PROP <- OO <- SBG_Factory_Rework_Main_Building
shooter chain: PlayerSuperior(Clone)   target chain: Bot1
CONTAINS shooter=no target=no
```

The walk climbed nine real nodes to the scene root and correctly identified the hit as
neither player. `CONTAINS=no` is the **right** answer. So "hit_target = 0 cannot be a
true reading" was overconfident: it can be true, because the target was behind scenery
for the whole observation window and all ~17 rays per skeleton hit the same barrel. The
feature is doing its job and paying 6.14% of wall clock to do it.

Two structural facts worth having on record: the shooter (`PlayerSuperior(Clone)`) and
target (`Bot1`) chains are **one node each, then reached-root** — the player GameObject
is parented directly to the scene root, so `classify_hit_transform` works only because
bone colliders are descendants of it. And the occlusion mask resolved to **`0xe4441ac9`**,
not the `0x80400000` fallback: thirteen layers (0, 3, 6, 7, 9, 11, 12, 18, 22, 26, 29, 30,
31) OR'd wholesale from `WEAPON_OCCLUSION_LAYERS`, `ENVIRONMENT_HIT_MASK`, `BaseMask`,
`HighPoly*`, `TerrainMask`, `PlayerStaticCollisionsMask`, `InteractiveMask` and
`LootCollisionMask` — **including Unity's layer 0 / "Default"**. That breadth is the
plausible reason for a high occluder rate even with the walk correct, and it is the
remaining open question. It is a product decision, not a defect.

**The 469.8 ms frame is `refresh_cache_stats`.** The phase probe:

```
esp-slow-frame[1/6]: total=484818us setup=11901us loop=15963us row=635us
  box=0us skel=11362us tail=456953us unaccounted=3966us | players=6 worstRow=528us
```

`tail` is **94.2%** of the frame, against a trace `max` of 485,257,680 ns — agreement
to **0.09%**, so the probe is measuring the right thing. The per-player row work is
635 µs in total, so `get_Nickname` and `build_player_label` are excluded too, as is
box-visibility (`box=0`, and `EspModule::is_player_any_part_visible` has a zone and
appears zero times). `refresh_cache_stats` is now a permanent zone
(`esp_scan::refresh_cache_stats`) and the slow-frame line carries a `cacheStats=`
bucket, so it is pinned rather than suspected.

**The uncached-`resolve_method` worry was unfounded**, which is what the new zones were
for: `esp_bones::get_player_body` 21,780 calls at **286 ns** mean, `get_skeleton_root`
5,940 at **558 ns** — 0.003% and 0.0015% of wall clock. The zones stay because they are
free and this is now a measured fact rather than an assumption.

**One `ACCESS_VIOLATION`, unattributed.** `READ of 0x0000369400000010`, faulting RVA
outside this module, all six frames outside, game thread, ~31 s into the raid and
immediately after the second probe sample — the first run of the build containing the
probe. Named rather than filed under "not ours" because it is the only added code that
hands Unity objects to *managed* calls (`get_name` per ancestor, `get_layer`), where
`classify_hit_transform` merely compares the pointers it walks; a dangling pointer
passed into the game faults inside the game, which is what "outside this module" looks
like. Against it: both samples completed with full named chains, the game thread kept
working afterwards, and crashes outside this module are the established pattern (§5.1:
eight across thirteen hours, none in our module). I could not attribute it, so the
probe was **hardened rather than defended** — every managed call it makes is now gated
on `eft_api::is_readable_address_cached`, checked **per hop** rather than once for the
chain, because an ancestor can be freed while a deeper node is still mapped.

`vis-breakdown` printed **zero** times: it is throttled to 30 s, `gameworld_update`
only runs once a `GameWorld` exists, and the raid began at 16:49:03 with the process
dead by 16:49:34. The `hit_target` rate against an *unobstructed* bot is therefore
still unmeasured, and the probe got 2 of its 12 samples for the same reason. A longer
raid closes it.

### 0.13 The probe crashed twice with an identical signature, so it is removed — and the cache stats were innocent

`next_next_day+3+crash.tracy` is also named `+crash`. The log now holds two sessions
(pid 16776, then pid 22200); it is appended rather than rotated, so it has to be read
by `pid` or the two interleave.

**The crash repeated with the same signature.** Same low faulting offset (`…E798`) in
both crashing sessions, both reads at **`+0x10`** — the first instance field of an
`Il2CppObject`, i.e. `*(garbage + 0x10)`:

| session | build | samples | crash | read address |
|---|---|---|---|---|
| 13:26 / 14:46 | pre-instrumentation | 0 | no | — |
| 16:49 `+2` | probe v1 | 2 | **yes** | `0x0000369400000010` |
| 17:54 `+3` | probe v2 (hardened) | 8 | **yes** | `0x0000429400000010` |

Two for two on instrumented builds, none on the two that lacked it. **The v2 hardening
was incomplete**: it gated `hierarchy_chain`, `gameobject_layer` and the GameObject
name, but left `chain_contains` walking parents through `g_transform_get_parent`
unguarded — up to 20 unguarded managed calls per sample, 160 across `+3`'s eight
samples. That hole was in both crashing builds.

So the probe is **removed rather than fixed**: `probe_occluder_hierarchy`,
`chain_contains`, `hierarchy_chain`, `gameobject_layer`, `hier_probe_due`,
`g_hier_probe_budget`, the three `kHierProbe*` constants and the `hit_owner::none`
call site are all gone. When a diagnostic may be causing crashes, removing it is the
correct response whether or not it is guilty — and the question it existed to answer
was already answered, so there is nothing left to trade crash risk for.

**Ten samples over two sessions all agree, confirming §0.12 rather than changing it:**
every one hit a genuine prop or wall on **layer 18**, chains resolved cleanly to
`reached-root`, and `CONTAINS shooter=no target=no` — the **correct** verdict.
`Area_02_inside_wall_D_COLLIDER` and `Case_shower_COLLIDER`, `dist` 1.25–3.02 m.
Masks differed per session (`0xe4441ac9` vs `0xe4441ac0`; bit 0 present only in the
first), layer 18 set in both. `vis-breakdown` printed **zero** times for the third
session running — the raid is never long enough to close its 30 s window.

**`refresh_cache_stats` is innocent; §0.12's prime suspect is disproved.**

```
esp-slow-frame[1/6]: total=538018us setup=8615us loop=15401us row=288us box=0us
  skel=11386us tail=514002us cacheStats=4us unaccounted=3727us | players=6 worstRow=226us
```

`esp_scan::refresh_cache_stats`: **14 calls, max 4,190 ns** — four microseconds against
a 514 ms tail. The `cacheStats=` bucket existed so this could be settled by one line
rather than another capture, and it did exactly that.

**The 514 ms tail is still unattributed, and is now zoned rather than guessed.** No
zone in the `+3` profile has a `max` near 514 ms, so the tail is unzoned work — and the
loot/container/quest blocks in the post-loop half had no zones at all, including a
573-line block at `EspModule.cpp:5727`. Added for free:
`esp_scan::loot_and_container_scan`, `esp_scan::quest_poi_scan`, and
`lootScan=`/`poiScan=` buckets on the slow-frame line.

**Not ours, but in our file: `fallback_layer_mask` had become `float`.** The
post-instrumentation builds surfaced C4244 `float`→`int` warnings — the only warnings
in a tree documented as 0-warning. `git diff` showed the parallel session had changed
`int` → `float`. Reverted to `int`, with the reasoning recorded in place. It was
harmless for this one value (`0x80400000` = 2,151,677,952 = 8,404,992 × 2⁸ with
8,404,992 < 2²⁴, exactly representable in a float32, so it round-trips losslessly), but
a mask with any of the low 8 bits set would have silently zeroed them.





### 0.14 The crash probe was killing the process it was observing

For about a month, every `0xC0000005` in this project ended with an empty log, and
the reason was not that the probe missed anything. **It caused it.**

WER was re-enabled on 2026-10-03 and immediately caught what a month of silence had
hidden:

```
exception      0xC0000005 (ACCESS_VIOLATION)
address        TarkovAddons.dll+0x1AE83A      (WER fault offset 0x7FF866C60DA1)
thread         18992, the process MAIN thread
symbol         crash_probe::fill_event+0x41
instruction    ff 15 19 63 26 00   call qword ptr [rip+0x266319]  -> __imp_GetCurrentThreadId
```

`fill_event` is reachable only from the vectored exception handler. So the process
died executing `GetCurrentThreadId()` **inside the VEH**, five seconds after boot.
A fault inside a VEH is not catchable — Windows runs no further vectored handler,
finds no `__except`, and calls neither the unhandled filter nor `std::terminate` —
so it terminates on the spot, having written nothing.

Why the call faulted is arithmetic. `fill_event`'s prologue costs 152 bytes (three
pushes and `sub rsp,0x80`); its last successful store is at entry−32 and the
faulting `call` pushes its return address at entry−160. Under 160 bytes of stack
were left on that thread. On x64 a `call [mem]` pushes before loading its target,
so the push is what faulted — the IAT was fine, and `logger.cpp:82` calls
`GetCurrentThreadId()` on every single log line.

Three defects, all of which had been shipping:

1. **The capture ran before the report.** `handler()` called `record()` — and so
   `fill_event()` — *before* `report_fatal()`. Capture was not a prelude to the
   report; on the fatal path it was the thing that ran first, and it was the thing
   that died. Capture is now split: the cheap half (fields only, no import call,
   no stack walk, ~20 bytes of stack) runs first and unconditionally, the
   expensive half runs afterwards inside an SEH guard, and the report runs after
   that — so it runs whether or not the enrichment survived.
2. **`emit()`'s line buffer was 1 KB of stack.** Unusable on the thread that needs a
   report most. Now one static buffer; `g_emitting` already serialises `emit()`, so
   it needs no lock.
3. **`in_executable_section()` passed a null `ImageBase`** to
   `RtlLookupFunctionEntry`, which makes it walk the PEB loader list to find our
   own module. **That walk faults from inside a VEH** — measured, not reasoned. It
   also could not have worked: a manual-mapped image is not in the loader lists, so
   every one of our return addresses was being classified as a *data word* instead
   of a frame. `g_base` is now passed.

Fixed and verified in `tools/probe_test`, which is a standalone harness that
compiles the header against a real Windows process — 35 assertions. The case that
matters is `smallstack`: a thread with a 64 KB reserve is run out of stack and then
faulted, and the assertions are that the fault is **still reported** and that the
process dies of `0xC00000FD`, the original fault, rather than `0xC0000005`, the
probe's. Every pre-existing case faults on a healthy stack, which is why the suite
was green while the shipped DLL was fatal.

The payoff: with the probe working, it named the `show_cone` crash in §2 within the
hour, and a minidump of that crash was cross-checked against the probe's report
field for field — including `ExceptionInformation[1]`, the one field WER does not
carry.

**One class remains invisible, and that is now proven rather than suspected.**
`SetUnhandledExceptionFilter` and `std::set_terminate` are each *one global slot*,
last writer wins, and the game takes both during its own start-up. The probe
detects the displacement and logs it, and deliberately does **not** reclaim the
slot — doing so would suppress Battlestate's crash dialog and its minidump, which
changes how the process dies. So an unhandled C++ exception is structurally
unreportable here unless someone decides otherwise. See `AGENTS_TODO.md` §5.16.

### 0.15 The menu's column boundary is decided before drawing, not during

Enabling "Show Debug Log" moved **Favorites and Configs into the left column**. The
cause was structural rather than cosmetic: `gui/menu/menu.cpp` decided the two-column
split *inside* its draw loop, after each card had already been rendered, keyed on
`m->name`. That had grown into **eleven predicates** and had produced three defects
in one afternoon:

- The Raid Dashboard boundary keyed on the Debug Log card, but Debug Log was
  registered *after* Favorites — so toggling it dragged Favorites left too.
- Because the split was decided mid-draw, every pinned boundary needed a matching
  "keep this left" opt-out to stop the 50%-height heuristic pre-empting it, and
  those opt-outs had to cover a whole *run* of cards. The Profile page needed a
  paragraph to explain it, which is a design admitting it is wrong.
- `##col2` could be opened twice in one frame.

Now the card list is built first and the boundary resolved from it, so the loop has
no per-card branch at all. The policy is data in `gui/menu/column_layout.h` — one
declarative table keyed on the real `ModuleCategory`, so there is no second tab enum
to drift. Two things stopped being special cases: the conditional Debug Log card is
simply absent from the list, so the boundary moves up by itself; and `Teleport`
needed a third state, `Sticky`, because it has a keep-left card and *no* pinned
boundary — marking it `Left` would have silently promoted it to one and permanently
moved two cards.

`tools/harness/test_column_layout.cpp` compiles that header for real (44 assertions)
and asserts both toggle states, every tab's split, and — by reading `ModuleManager.h`
and `module/impl/*.cpp` as source text — that every left-column card is registered
before the first right-column one. That last check is the one that earns its keep:
the table keys on module names, so a rename or reorder would otherwise break the
layout with nothing failing. Verified by reinstating the original defect, which
reports `Debug Log must be registered before Favorites`.

Not done, and now safe to defer: the table still keys on module names rather than a
`LayoutSlot` on `Module`, and `draw_card_frame()` still uses the display name as the
ImGui ID while the stable identifier the constructor already takes is used only for
i18n — so retitling a module discards its fold state. See `AGENTS_TODO.md` §3.10.

### 0.16 The crash is named: the aimbot pen-check, not the vis-probe

`next_next_day+4+crash.tracy`. The one-shot hierarchy probe is **removed** from this
build (`vis-probe` appears zero times in the log) -- **and the game still crashed**,
third consecutive identical signature: fault offset `...E798`, read at `+0x10`.
Removing the instrument changed nothing, so **the probe was never the cause.**

`tools/symbolize.py` against build 6AC10BEC names it:

```
frame 0  skeleton_vis::read_ballistic_identity        +0x2A2
frame 2  skeleton_vis::describe_layer                 +0x54
frame 3  skeleton_vis::try_read_ballistic_penetration +0x60
frame 4  skeleton_vis::assess_ricochet                +0xCB
frame 5  skeleton_vis::try_read_layer_penetration     +0x1D
frame 6  skeleton_vis::is_target_visible_penetrating  +0xF89
```

**This is the AIMBOT's penetration walk, not the ESP.** The read at `+0x10` is
`UnityEngine.Object.m_CachedPtr`, which every managed call dereferences at `this+0x10`
-- a managed call on a freed collider, in a function that had no readability guard.
`ballistic` comes off `Shot.TryGetBallisticCollider` on a live raycast hit, and by the
time the walk has classified a layer and reached the diagnostic the object can be gone.
The last line before death is `pen-check: bullet HitMask = 0x40811810`, that walk's own
initialisation.

Two corrections this forced on the earlier entries: **"outside this module" never meant
the mod was innocent** -- it only ever meant the stack scan found no in-module *code*
frames, and the faulting *instruction* was ours. That misreading is what sent 0.12 and
0.13 after the wrong suspect, and it is worth writing down because the phrase is
actively misleading.

`read_ballistic_identity` now gates every managed call on
`eft_api::is_readable_address_cached`, checked per hop because `go` and `transform` are
derived objects that can be freed independently. That fix came from the 17:54 crash; the
`+4` build predates it, which is why it still faulted.

**Hitch: the new buckets fired, and cross-validate to the microsecond.**

```
esp-slow-frame[1/6]: total=518581us setup=13831us loop=22426us row=940us box=0us
  skel=17306us tail=482323us cacheStats=3us lootScan=77610us poiScan=195728us
  unaccounted=4180us | players=5 rowsOver1ms=0 worstRow=858us
```

`esp_scan::quest_poi_scan` max 195,727,242 ns against `poiScan=195728us`;
`esp_scan::loot_and_container_scan` max 77,609,975 ns against `lootScan=77610us`;
`esp_scan::refresh_cache_stats` max 4,619 ns against `cacheStats=3us` -- innocent for the
third time running. **`quest_poi_scan` is the new prime suspect at 196 ms**, 40.6% of
the tail, and the first part of it measured rather than guessed. **209 ms of the 482 ms
tail is still unattributed**, because the `do_quest_items` block, the `publish()` group,
`scan_bot_corpses_for_minimap` and the grenade/tripwire/keypanel scans still carry no
zones.

`vis-breakdown` printed zero times again -- and now measurably so:
`frame::EspModule::gameworld_update` ran 3,180 calls at a 1.55 ms mean, about 28 s of
game thread, just under the 30 s the reporter needs. The reporter is not broken; the
raid has never been long enough. ~10% more raid time closes it.

---

### 0.41 Eleven zones added to `gameworld_update`, because 99.92% of it had none

Numbered 0.41 because §0.38 and §0.40 were taken by the other session. It was first written
as an uncommitted §0.39 and destroyed by a `git checkout -- CHANGELOG.md` run by that
session mid-append; §0.39 now carries a placeholder saying so, and this is the restored
text plus the answer that arrived the same day.

The measurement that started it, from `next_next_next_day+3+stuck.tracy`, self time (`-e`):

    frame::AimbotModule::gameworld_update   174.84 s   2,753 calls   63,509 us mean   140.18 ms max
    sum of every zoned region inside it        0.146 s
    UNATTRIBUTED                             174.70 s   (99.92%)

So the finding is not "the aimbot got slower". It is **"the aimbot's most expensive function
had no instrumentation on the code that costs the money"**. The optics workstream found the
174.84 s and carried it; I own the file and had zoned the pick loop, the scan body and the
method resolves, all of which came back free. What was left was code with no zone at all.

**What I added** (all in `AimbotModule.cpp`, `gameworld_update`):

| zone | what it measures |
|---|---|
| `aimbot::local_player_transform` | `component -> GameObject -> Transform -> position`, 3 hops, feeding the fallback pen origin *and* the camera trust reference |
| `aimbot::fireport_resolve` | `try_get_fireport_position` — see §0.42, this is where the 174.84 s was |
| `aimbot::visibility_origin_resolve` | the SAME fireport resolution again behind its own memo, plus a `Camera.current` read and a trust test |
| `aimbot::main_player_transform` | a `gameobject_get_transform` that **turned out to be dead** |
| `aimbot::gather_phase` | half the function: who is in range |
| `aimbot::pick_phase` | half the function: who do we shoot at |
| `aimbot::alive_players_fetch` | the `AllAlivePlayersList` field hops |
| `aimbot::wall_check_call` | the pen walk **including** argument setup and the three `cached_` float reads, which the inner zone cannot see |
| `aimbot::mode3_output` / `:mode3_projection` / `:mode3_mouse` | the mode-3 output stage, split because the projection is unconditional and the mouse is not |

`gather_phase` / `pick_phase` are a deliberate **boundary, not a hypothesis**. Three successive
guesses about where the unattributed time lived all came back free; a fourth would have been
a guess. This measures the two halves against each other so the next capture says which half
to stop looking at.

**Dead read found on the way:** `main_player_transform` was assigned and never read — four
matches, all of them the declaration and its own new zone. Kept and zoned rather than deleted,
because its cost was never measured (it is inside the 99.92%) and removing it in the same edit
that discovered it would change what the capture measures. It came back at 0.38 s over 22,137
calls, so it was never the problem — but that number is only available because it was zoned
rather than deleted on suspicion.

**C2374, three times, and a test for it.** `TA_ZONE_N` expands to a local literally named
`ta_zone` (`util/tracy_bridge.h:168`), so two in one brace scope is a redefinition. Hit on
`pick_phase`+`candidate_pick`, then `gather_phase`+`pick_phase`, then
`mode3_output`+`mode3_mouse`. `tools/tests/test_zone_scope.py` now checks this statically,
tracking scope **identity** rather than brace depth — two sibling `if` blocks are the same
depth and different scopes, and a depth-keyed version flags 11 false positives on the shipped
code. Three negative controls, all verified to fail for the right reason, including a replay of
the exact `pick_phase`/`candidate_pick` shape that broke the build.

**Zone census: 101 sites, 98 literal names, 16 files.** The gap of 3 is the one dynamic site
(`ModuleManager.cpp:77`, `TA_ZONE_N(m->name.data())`), which makes `frame::module` one row per
module instead of a single bucket, plus the macro definition and its no-op twin in
`tracy_bridge.h`.

---

### 0.42 SOLVED: the 174.8 s was one uncounted line, and it was 40% of the capture

`next_next_next_day+4+stuck.tracy`, 2026-10-04 14:36. Self time (`-e`):

    aimbot::fireport_resolve            310.59 s  22,129 calls  14,035 us mean  246.03 ms max   39.96%
    frame::EspModule::draw_overlay        9.44 s   24,099 calls     391.6 us mean
    hideout::Card::refresh_hideout_state  7.31 s   28,366 calls     257.7 us mean

**33x the next most expensive zone in the capture.** And the enclosing function now reads what
it always actually cost:

    frame::AimbotModule::gameworld_update   self = 0.0132 s   incl = 314.31 s

0.0132 s self. The 174.84 s / 99.92%-unattributed figure from §0.41 was this one call being
charged to its parent because it had no zone of its own. **It was never a mystery; it was an
unmeasured line**, and the "47x climb with falling call count" was 2,753 frames each paying a
share of one call.

### The hypothesis written into that zone was wrong, and the capture said so in one click

The comment above `aimbot::fireport_resolve` blamed the **two uncached name->method walks**,
quoting `skeleton_visibility.h`'s own note. Tracy's zone-info window on a single instance:

    Self time: 130.12 ms (100.00%)
    Child zones (2):  il2utils::resolve_method  1 us (0.00%)
                       il2utils::resolve_method  570 ns (0.00%)

**1.57 us out of 130.12 ms — 0.001%.** 99.999% is the two *managed calls* those resolves
produce pointers for: `Player.get_Fireport()` and `Bifacial.get_position()`. Both are now zoned
separately inside `try_get_fireport_position` as `skeleton_vis::fireport:get_Fireport` and
`:get_position`, so one more capture says which one. **Still not known which**, and guessing
between a property getter and a transform-matrix multiply at this magnitude would be picking a
plausible story rather than taking a measurement.

Named under `skeleton_vis::` rather than `aimbot::` because the function has four callers —
`AimbotModule.cpp`, `AimbotModule.h`, `EspModule.cpp`, and the memo in
`try_get_visibility_origin` — and a zone named after one of them would misattribute the others.

### The cost is BIMODAL, and my "not a load artifact" claim was wrong

The screenshot that prompted this was taken at 14:32:38, four minutes into
`Loading in at: bigmap`. I wrote that the load screen was "when the sample was taken, not what
made it expensive", on the strength of call counts. **That was wrong, and it was the same
denominator mistake this file records three separate times.**

`csvexport -u` reports **one row per event** with `ns_since_start` — a time axis the aggregate
table does not have. Bucketing the 22,129 fireport events by 30 s:

| window | calls | total | mean | max |
|---|---|---|---|---|
| 14:32:13 | 261 | 18.7 s | **71.8 ms** | 93 ms |
| 14:32:43 | 468 | 14.5 s | **30.9 ms** | 136 ms |
| 14:33:13 - 14:36:43 | 13,812 | 0.017 s | **1.4 us** | 0.08 ms |
| 14:37:43 - 14:43:35 | 4,349 | 294 s | **63 ms** | 246 ms |

**Bimodal by a factor of 25,873.** 3.5 minutes essentially free, 6 minutes catastrophically
expensive. "14,035 us mean over 22,129 calls" is two populations averaged and I quoted it as if
it described every call. The 78%-of-frames argument has the same defect: a call rate says how
often, not how much.

**What the same technique settles: it is NOT the thread being descheduled.** Every zone split
by the two regimes:

| zone | free regime | costly regime | ratio |
|---|---|---|---|
| `aimbot::fireport_resolve` | 1.44 us | **37,343 us** | 25,873x |
| `aimbot::local_player_transform` | 1.05 us | 44.05 us | 42x |
| `aimbot::ammo_cache` | 27.22 us | 13.34 us | **unchanged** |
| `aimbot::visibility_origin_resolve` | 1.09 us | 1.10 us | **unchanged** |
| `aimbot::gather_phase` | 20.62 us | 23.11 us | **unchanged** |
| `frame::EspModule::gameworld_update` | 478 us | 1,041 us | 2x |

`gather_phase` and `ammo_cache` run on the same frames and cost the same in both. A blocked
thread would have appeared in all of them. **It is the call.**

`visibility_origin_resolve` being flat is NOT evidence that the fireport is cheap on the second
path — it only touches the fireport when the player's rig is absent
(`skeleton_visibility.h:1587-1588`), so normally it never reaches it. Recorded because for a
moment it read as the same function running 34,000x faster in the same frame.

**What this capture still cannot say: which regime is load and which is raid play.** The log's
last line is 14:30:37, one record before the capture window opens, so the timeline that would
label the two regimes does not exist for this session. The shape is established; the cause is
not.

### The instrument that closes it: a windowed reporter in the log, not a zone

`csvexport -u` carries `ns_since_start`, so the shape was recoverable *from the capture*. What
is not recoverable is the correlation with `Loading in at:` / `Local Raid Ended`, because the
log is the artefact with the timeline and it had nothing for this session.

So `try_get_fireport_position` accumulates into plain counters and
`report_fireport_window()` prints every 30 s, into the **log**:

    fireport-cost: calls=N total_ms=X mean_us=Y max_ms=Z rate_hz=R

Deliberately **not** a Tracy zone: this is a correctness question, not a profiling one, and it
must survive a session with no profiler attached. The window gate is a clock comparison
evaluated **before** any string is built — the `unity.h` lesson from earlier today, where a
`std::format` argument list evaluated at the call site cost 64.87 s behind a guard that read as
working.

Plain counters, not atomics: the four call sites are all inside `gameworld_update` or behind
their own `is_in_raid` check, so there is one writer on the game thread. If that ever changes
they must become relaxed atomics, because a torn 64-bit add would silently under-report the one
number this exists to produce.

### Verified separately: it cannot run outside `is_in_raid`

Asked, so checked rather than asserted. `gameworld_update` has exactly **one** dispatch site —
`common_hooks.cpp:381`, inside `ModuleManager::apply` — and `hk_game_world_update` returns at
`:361` on `!game_state::is_in_raid` before reaching it. The aimbot's other two entry points
gate themselves: `AimbotModule.cpp:51` (`draw_overlay`) and `:98` (`application_update`).

All four call sites of `try_get_fireport_position` — `AimbotModule.cpp:315`,
`skeleton_visibility.h:1567`, `EspModule.cpp:5460`, `EspModule.cpp:5615` — sit inside one of
those, so there is no path to it from outside the gate.

**Which does not answer the loading-screen question**, and the distinction is the whole point:
`is_in_raid` is set TRUE from inside `hk_game_world_update` the moment `MainPlayer` is
non-null (`game_state.h:50-57`), which is *before* the map streams. The gate is real. It is not
a load gate.

---

### 0.44 Layer budget 4 -> 3, and the hitch that was never the layer count

User report: the aimbot hitches when a target sits behind several penetrable
layers, "up to what feels like a second". Asked me to cap at 3 layers -- "max
layers we can penetrate is 3 and drop everything else" -- and to check what the
logs say first.

**The logs say the layer count is not the hitch.** From `+5+stuck`, self and
inclusive tables:

    skeleton_vis::is_target_visible_penetrating   0.31 s incl   4,245 calls   41.8 us mean   8.06 ms MAX
    skeleton_vis::occlusion_linecast              1.28 s self 200,886 calls    6.4 us mean   0.24 ms max

**Worst single walk in the capture: 8 ms.** The pen walk is not capable of a
one-second hitch, and its inclusive total is 0.31 s out of a capture carrying
180 s elsewhere. What the second-scale hitches actually are, from the same
capture's `max_ns` column: `always_on::hk_comeback_to_main_menu` 5,370 ms (4
calls, not mine), `always_on::hk_prepare_game_job` 1,177 ms (7 calls, not mine),
`Quest Completer` 627 ms (not mine), and `frame::EspModule::gameworld_update`
**806 ms** (not mine).

**The cap is still right, and it is now in.** `kMaxLayers` 4 -> 3 at
`skeleton_visibility.h:2322`, on the user's call. What the 369 `pen-check:`
records support:

    layers raycast        2:78   3:27   4:218 (59%)   5+: 0
    reached the target    after 0:17  1:16  2:56  3:20   4: 0
    cleared after N       never, at any N

So no walk in the sample needed a fourth layer to reach its target, and the 59%
that raycast a fourth were all already `BLOCKED`. What it saves: one
`occlusion_linecast` (6.4 us) on 59% of 4,245 walks, about **16 ms across the
whole capture**. A simplification, not a performance fix, and it does not move
the `pen_stop` tally -- `record_stop` passes a set `stop_layer` through, so a
blocked walk is still attributed to the layer that blocked it.

**The one residual risk, stated in the source and not argued away here.** The
loop condition is `layer < kMaxLayers` and the clear-line test is the first thing
the loop body does. A walk that penetrates exactly three layers and then finds
clear air returns `clear line after 3 layer(s)` -> PASS at cap 4, and falls out of
the loop -> `budget_layers` -> BLOCKED at cap 3. **That flips PASS to BLOCKED.**
Zero such walks in 369 records, so it is rare or absent -- but "not observed in
369" is not "impossible", and no test here can settle it without a physics scene.
If it shows, the fix is not to restore the cap but to let the loop run one extra
iteration whose only job is the clear-air test, which pays the raycast back on
every blocked walk. That is a trade, not a correction.

`tools/tests/test_pen_layer_budget.py` (6 tests) pins the cap, asserts the
`record_stop` passthrough that keeps the tally honest, and **re-derives both log
claims from the session log rather than trusting the table above** -- skipping
loudly if no log is present rather than asserting a constant it cannot produce.
Two negative controls verified against the intended assertion: reverting the cap
on disk fails `test_kmaxlayers_is_three`, and neutering the comment-blanking
helper fails `test_cap_comment_cannot_satisfy_the_numeric_assertion` with
`Regex matched: '4 -> 3'` -- which is the point, since the source comment says
"4 -> 3" in prose and a numeric assertion must not be satisfiable by it.

`Prod|x64` clean, **0 errors, 0 warnings**. `tools/tests` **210 passed**.

**Numbering:** 0.44, not 0.43, because the other session's 0.43 (the
`Camera.all` / `is_in_raid` overlay throw) is in this file already. Their text is
not mine to renumber.

---

### 0.47 Eleven more zones, and the one that answers the pen-check question

Asked for zones rather than changes, on the grounds that a capture is worth more
than another argument. Zones only -- no logic moved except the fireport gate in
0.46. Three gaps, in the order they matter.

### 1. `hk_initiate_shot` had NO zone at all, and it is the shot path

```
aimbot::initiate_shot                     whole hook
aimbot::initiate_shot:player_field        get_field("_player")
aimbot::initiate_shot:fireport            try_get_fireport_position, re-derived at fire time
aimbot::initiate_shot:direction           to_target + the finite/length guards + normalize
aimbot::initiate_shot:stale_direction     the FALLBACK branch, when the fireport read failed
aimbot::initiate_shot:tp_bullet           should_tp_bullet
aimbot::initiate_shot:game_call           o_initiate_shot, the game's own work
```

This is the only aimbot code that runs on the game's shot rather than on our
frame, and it was invisible in every capture taken so far. A capture showing the
aimbot costing nothing and the game hitching could not distinguish *"the aimbot
did not cause it"* from *"the aimbot caused it here"*.

Two of the seven are not just about cost. `:stale_direction` is a **different
answer**, not a slower version of the same one -- reaching it means the fireport
read *failed*, which during a load it may do for tens of seconds, so a capture
with that zone hot is showing a fallback carrying the traffic. And `:fireport` is
**not covered by the `hands_not_firearm` gate** added in 0.46: that gate is local
to `gameworld_update`. Deliberate for now, because a shot during a load is not
something a player does -- and zoned rather than changed, so a capture can say how
often it is actually reached before anyone decides whether it needs one.

### 2. `local_player_transform` split into its three hops

```
aimbot::lpt:game_object   component_get_game_object
aimbot::lpt:transform     gameobject_get_transform
aimbot::lpt:pos           transform_get_pos
```

The whole read measured **118.75 µs mean / 51.24 ms max** in `+7` and ~1 µs in
`+5`. One number cannot say which hop degrades when the player object is being
torn down, and they will not degrade together: the first two are pointer walks,
and only `:pos` can force Unity to bring a transform hierarchy up to date. That
is the same class of read as `Bifacial.get_position`, which is the 180 s finding.

### 3. The pen walk's two per-layer MANAGED reads, split from the ray

```
skeleton_vis::pen:resolve_ballistic    the game's Shot.TryGetBallisticCollider
skeleton_vis::pen:read_penetration     PenetrationLevel / PenetrationChance
```

This is the one that answers the question the whole thread started from. Until
now the walk's cost could only be attributed to **raycasts** --
`occlusion_linecast` was measured and the two managed reads that follow it were
not -- so "is the pen check expensive because of the rays or because of reading
the collider" was not measurable, only arguable.

`resolve_ballistic` is the honest suspect for *"costs more with more layers"*:
it is Unity's `GetComponentInParent` running on the managed side, once per layer,
on the game thread, and **every `+7` log line says `(game-resolved)`**, so it is
taken on every layer of every walk and the fallback hierarchy walk beside it is
effectively dead. `classify_blocker()` -- the part that was in question -- is pure
arithmetic, `min(1, a+c)` plus three gates.

### Also: `aimbot::application_update` was unzoned

It is the only place the aimbot's state is *cleared*, and only when
`!is_in_raid`. If the flag lags teardown, this is the code that has to keep
running past the point where the objects it holds are being destroyed -- which is
the question the overlay workstream is on, from the other end.

**Zone census: 116 `TA_ZONE_N` sites, 113 literal names, 16 files** (was 101/98).
`aimbot::*` is now 36. The parallel session added `TA_ZONE_SITE` to
`tracy_bridge.h` in the same window -- a per-caller site dimension on
`skeleton_vis::fireport:get_position`, which replaces the bare zone on that line
and keeps its name. Complementary, and the count above does not include it.

**A collision worth recording.** Their edit landed in `skeleton_visibility.h` at
17:07 while I was editing the same file, and the build failed twice with
`C2065: detail_stage_ undeclared` at lines 310 and 313 -- **lines that are prose
inside a comment**. The tell was that the error pointed at a comment: the file on
disk was not the file the compiler read. All 15 of my zones survived their write.
What I did about it is worth copying: the wait loop now requires **both** no
build processes for 50 s **and** no writes to the four shared files for 90 s.
Process-quiet alone is not file-quiet when two agents edit the same header, and
the symptom looks like a syntax error rather than a race.

`Prod|x64` clean, 0 errors, 0 warnings. `tools/tests` **210 passed**.

---

### 0.49 The fireport was still 202 s after gating it, because there were two call sites and I gated the cheap one

`next_next_next_day+8+transit+crash.tracy`, 2026-10-04 18:39. First capture with
the `hands_not_firearm` gate (0.46) and the first with `TA_ZONE_SITE`.

    aimbot::fireport_resolve            incl  0.00 s   2,108 calls      1.9 us mean
    aimbot::visibility_origin_resolve   incl 202.14 s   9,355 calls  21,608 us mean  80.86 ms max
    frame::AimbotModule::gameworld_update incl 202.67 s  9,354 calls

**The gate worked. It just was not on the path that cost anything.**
`aimbot::fireport_resolve` went from 310.59 s to 0.00 s. Everything that remained
was the fireport read inside `try_get_visibility_origin`'s own memo -- the fourth
caller, which 0.46 did not touch -- at **99.7% of the function**.

0.46's own note named it and then under-weighted it: *"called from here
unconditionally, and AGAIN inside `try_get_visibility_origin()` via its own memo
... on these numbers it is worth at most half of 310 s."* After the gate it was
**100% of what was left**. The memo is reached only when `has_rig` is false --
an unpopulated rig IS the loading screen -- so the one condition that triggers it
is the one that makes `Bifacial.get_position()` cost 40-72 ms.

### Three fixes

**1. `try_get_visibility_origin` takes `allow_fireport_read`, default true.**
ESP's two call sites and any future one are unchanged; the aimbot's
`gameworld_update` passes `!hands_not_firearm`. What it costs: with no reference
point `has_ref` stays false and the camera trust test cannot run, which is the
documented house rule for that case already ("cannot rank it, do not guess",
camera stands). Not a new degradation -- the existing one, reached deliberately
instead of after a managed call that was going to be discarded.

**2. `TA_ZONE_SITE` was accepting its `name` argument and discarding it.** It
expanded to `(site), (site) ? strlen(site) : 0` and never mentioned `name`, so
every span produced a row named by `site` alone. That is why `+8` contains a row
called **`unknown` (20.69 s, 400 calls, 51.72 us mean -- the worst calls in the
capture)** and a row called `aimbot/gameworld_update` (181.42 s), with nothing in
the export saying either was the fireport. Now composed as `name@site`, cached
thread-locally on the last (name, site) pair, so the steady state is two pointer
compares and no allocation -- the per-call `std::format` this macro's own comment
forbids.

**3. `g_fireport_site` leaked.** Set on entry, never restored, so a caller that
set no label inherited the previous one:

    aimbot/gameworld_update    11,063 calls   <- the LABEL
    aimbot::fireport_resolve    2,108 calls   <- the zone, on the SAME two lines

A 5x over-count **pointing the fix at the wrong function**: the memo that carried
the 202 s was reported as the aimbot's, and the aimbot's real calls were
undercounted. Now `FIREPORT_SITE("...")`, an RAII guard that restores on scope
exit, at all three call sites.

### The crash: one frame is real, two are not

    frame 3  0x1BA5F8  AimbotModule::gameworld_update +0x10B8
    frame 4  0x1960D1  ModuleManager::apply +0xE1
    frame 5  0x2AA732  reported as hk_game_world_update +0x352
    frame 6  0x2AA883  reported as the lambda inside hk_game_world_update +0x33

`AimbotModule::gameworld_update` is at RVA 0x1B9540, so `+0x10B8` is 0x1BA5F8, and
the byte there is:

    0x1BA5F6   call rax
    0x1BA5F8   nop                    <-- the reported frame

A `nop` immediately after a `call` is a **return address**, which is the check
`tools/pe_disasm.py`'s docstring says to apply before believing a frame. So frame 3
is genuine: an indirect call through a cached function pointer, preceded by three
null checks, so not a null call.

**Frames 5 and 6 are not `hk_game_world_update`.** The map puts it at RVA
**0x2AB170**; those two are 0xA3E and 0x8ED *below* it and resolve to
`asset_bundles::start_load +0xDD2` and `asset_bundles::check_progress +0x43`. The
outer context is the game's **asset bundle loader**, and a chain running from there
into our module hook cannot be a real call chain -- our hook is called by the
game's world update, not by its bundle loader.

**What cannot be said.** The probe's own line says it: *"scan of stack words, not
an unwound stack"*, and the fault was `ACCESS_VIOLATION WRITE of 0x6` at
`faulting rva=<outside this module>` on tid 29848, after ~8,850 `0xE06D7363`
exceptions on that same thread. **The fault was not proven to be in our code**, and
I am not going to name a culprit from a stack-word scan.

**The lead worth taking.** `xref_global.py` on the callee's global (0x441248)
finds exactly **one** writer, at 0x59D0D inside
`?init@?A0x10f3e34b@@YAKPEAX@Z +0xBED` -- a function-local static's dynamic
initialiser. **I did not identify which static.** And global A (0x5D64B8) is
**zeroed at `AimbotModule::application_update +0xA6`**, which is the `!is_in_raid`
state-clear branch: two paths on different ticks, one zeroing a cached pointer and
one calling through cached pointers, gated by a flag the log already shows lagging
teardown (`cam-choice` still reporting 9 s after `Local Raid Ended`).
## 1. The deployment layout is now one folder

**This is the headline change.** Everything the mod reads or writes lives under
`ta\`, next to the three DLLs:

```
<deploy>\
    TarkovAddons.dll
    TarkovLauncherBypass.dll
    vk_swiftshader.dll
    ta\
        compatibility\profiles\     per-build IL2CPP manifest
        launcher.cfg                shared config
        offsets.cfg                 legacy IL2CPP fallback
        patterns.cfg                signature overrides
        lang\*.json                 fallback translations
        maps\*.json, *.svg          fallback minimap assets
        configs\<config>            your settings
        chams\tarkovutils\          chams asset bundle
        tarkov_prices.json          item price cache
```

Uninstall is now "delete the deployment folder", and the config is a file anyone
can find.

`configs\` and `chams\` were added after the first cut. `ta\` mixes shipped
read-only data with data rewritten at runtime, and the user's settings are the
one file here someone may want to find, copy, diff or restore — burying it among
the shipped files makes it easy to mistake for something the mod owns and
replaces on update. `configs\` separates "yours" from "ours" the same way `ta\`
separates data from the DLLs, and makes "back up your settings" one folder. The
migration also moves a config already sitting directly in `ta\` into
`ta\configs\`, so a 3.2 install that has run once does not silently reset to
defaults when this lands.

**Why a subfolder rather than the DLL folder itself:** a re-deploy or a repair
that replaces the DLL then has no need to guess which other files are the user's
and must be preserved.

**Logs stay next to the DLL**, not in `ta\`. They are diagnostic output, and
"send me the log next to `TarkovAddons.dll`" is a request anyone can act on. The
Debug Log menu panel reads that same path.

### Your existing settings are imported automatically

On first start the mod creates `ta\` and *moves* the pre-3.2 files into it, from
both old locations:

| From | What |
| --- | --- |
| `%APPDATA%\TarkovAddons\` | configs, `tarkov_prices.json`, unpacked maps, `tile_cache\` |
| the deployment folder | `launcher.cfg`, `offsets.cfg`, `patterns.cfg`, `lang\`, `maps\` |

Properties, all deliberate:

- **Never overwrites** anything already in `ta\`. If a file exists in both
  places, the `ta\` copy wins and the stale one is left alone rather than deleted.
- **Never deletes a legacy directory** — only the individual files it moved.
- **Falls back to reading the old locations** if `ta\` cannot be created, so a
  read-only install loads its settings instead of silently resetting to defaults.
- Logs every file it touches, and the count of what it imported.
- If `ta\` is not usable it does nothing at all, rather than half-migrating.

You do not need to reinstall. Existing installs converge on next launch.

### Path probing collapsed

Because there is one data folder, the search lists went away:

| | Before | After |
| --- | --- | --- |
| Price cache read | 8 paths, 6 of them CWD-relative | 3 |
| Minimap asset search | 9 directories, 3 CWD-relative | 2 |
| Translations | ~10 candidate directories | RCDATA, then `ta\lang` |

The CWD-relative probes (`tarkov_prices.json`, `../BsgLauncher/...`,
`maps`) meant the folder that got used depended on where the process happened to
be launched from. They are gone.

`launcher.cfg` overrides still win where they always did: `marketJson=`,
`mapsDir=`, `langDir=`.

---

## 2. Bugs fixed

### The committed tree did not compile

`module/hideout_reflection.h` included two paths that do not exist:

```cpp
#include "../eft_api.h"         // the file is module/eft_api.h
#include "../../il2cpp/unity.h"  // the file is TarkovAddons/il2cpp/unity.h
```

Corrected to `"eft_api.h"` and `"../il2cpp/unity.h"`. This is not a regression
introduced by 3.1/3.2 work — the tree at `a3307eaf` could not be built at all.

### Memory safety

- **`wide_to_utf8` wrote one byte past its buffer** (`util/module_paths.h`).
  `WideCharToMultiByte` was called with `-1`, which reports the byte count
  *including* the terminating NUL and then writes that many bytes — into a
  buffer declared one byte smaller. Now passes an explicit character count.
- **`always_on.h` wrote one element past the end of an array**: the loop
  condition was `i <= m_i_count` rather than `i < m_i_count`.
- **`unity::dict` indexed without bounds checks.** Added an `index_in_range`
  guard; an out-of-range index now returns null instead of reading past the
  bucket array.
- **`AimbotModule::show_cone` was never constructed** (`module/impl/AimbotModule.cpp`).
  `0xC0000005`, READ of `0x50`, at `draw_overlay+0xCA` on the render thread, on the
  first frame in a raid. The member was declared, documented and dereferenced, and
  its i18n key was already in all 19 `lang/*.json` — everything except the one line
  that creates it, so it held **indeterminate** memory, not null. Fixed by adding
  it to the constructor's init list, and the trap is disarmed for the next
  omission: all 11 raw config pointers now carry `= nullptr`, so a future miss is
  a deterministic null dereference at a known line rather than a wild read.
  `tools/audit_config_pointers.py` checks every config pointer in every module
  header; the count is re-derived from the tool by
  `tools/tests/test_doc_counts.py` rather than quoted here, so this entry cannot
  go stale. Same shape as the `hook_method` null write above, and the same lesson:
  fix the call site *and* make the mistake impossible to express.

### Correctness

- **`QuestModule` dereferenced `_questsData` without a null check.**
- **`WeaponBuilderModule` validated at build time but not at consume time**, so
  a stale index could read out of bounds. Bounds are re-checked on use.
- **`i18n::tr()` lost its mutex** at some point, leaving a `std::string`
  translation map read concurrently from the render and network threads. Restored.
- **`hook_change_health` computed a clamped damage value and then discarded it.**
  It walked `_bodyState` by reflection on every damage event, clamped vital parts
  to 1 HP, and then forwarded the *unmodified* `delta` — so the entire walk was
  wasted work that changed nothing. It is now an explicit passthrough, with the
  old clamp preserved as commented-out code and a note on why it should not be
  switched on blindly (it is a second damage path on top of `hook_kill`, which
  already blocks death outright).
- **Debug logging was on by default.** The `DEBUG` switch defaulted to `true`, so
  every release build wrote a full diagnostic log. Now off; the Debug Log panel
  toggle still turns it on.
- **Dead `any_null` branch** in the item-lookup path removed.

### A trap worth knowing about

`windows.h` defines `min` and `max` as function-like macros, which poisons
`std::min(a, b)` — it fails to compile with *"expected unqualified-id before «(»"*.
The fix is the explicit-template form `std::min<T>(a, b)`. Four sites used a bare
`min`/`max`; all now use `std::min<T>` / `std::max<T>`.

My first attempt at this fix was itself wrong (I used bare `std::min(a, b)` and
only caught it by compiling against simulated MSVC macros).

### Build and logging

- The per-config post-build steps were collapsed to one unconditional step, with
  a guard so the Debug/Release configs — where `OutDir == IntDir` — do not copy
  the DLL onto itself (which returns errorlevel 1 and would abort the rest).
- A locked DLL now prints a useful warning instead of failing the build silently.
- The Debug Log panel read a hardcoded `C:\tarkovaddons_log.txt` while the logger
  wrote elsewhere. Both now resolve to the same file next to the DLL.

---

## 3. New subsystems

### Compatibility profiles

Per-game-build manifests replace hardcoded offsets as the primary resolution
source.

- `compatibility/profiles/<version>/manifest.json` — symbols per game build
- `tools/manifest_tool.py`, `tools/manifest.schema.json`, and a test suite
  (`tools/tests/test_manifest_tool.py`) to author and validate them
- `tools/parse_pdb.py`, `tools/parse_dump_cs.cs`, `tools/ida_extract_patterns.py`
  for extraction
- `il2cpp/compatibility_profile.h` — the in-mod loader

The launcher's disabler is now manifest-only: it no longer carries its own
hardcoded target offsets. `offsets.cfg` / `patterns.cfg` are demoted to a legacy
seed for builds with no manifest.

The bypass reads its manifests from `ta\compatibility\profiles\`, matching the
in-game DLL.

### Hideout automation

`module/hideout_reflection.h` (reflection layer) and
`module/impl/HideoutAutomationModule.h` (the automation itself).
`HideoutModule.h` grew substantially and is now actually compiled.

### Icebreaker scenario

`module/impl/IcebreakerScenarioModule.h`.

### Optics lens pipeline — **not audited**

`module/optics_lens_pipeline.h` (~2200 lines) plus a large `EspModule` rework.

**This code was deliberately left untouched.** An optics rework is in progress
elsewhere, so the cleanup pass skipped it rather than colliding. It is *not*
covered by any of the fixes or dead-code removals above. See the open-items list
in §6 for the specific defects that are known and still present in it.

### Other

- `module/game_item_db.h` replaces `assets/item_database.h`
- `util/tracy_bridge.*` plus vendored Tracy — opt-in profiling
- `util/linalg.h`, `config/FloatSliderEditableValue.h`
- `build.ps1` and the `tools/` Python toolchain

---

## 4. Dead code removed

`ISIL-references/` and `external/` are excluded; everything below is first-party.

### Files

| Removed | Lines | Why |
| --- | --- | --- |
| `il2cpp/generated_bindings.h` | 9699 | Unreachable, no generator, 126 methods share one offset |
| `assets/embedded_assets.h` | 22461 | No generator, duplicated data already in RCDATA |
| `assets/menu_background_bytes.inc` | ~11.4 MB | A 1.9 MB PNG stored a third time, as one-byte-per-line hex — and *tried first*, ahead of RCDATA |
| `assets/Black division background.jpg` | 200 KB | Zero references, not in the `.rc`, not in the project |
| `util/hash.h` | — | Unused |
| `lib/detours.lib` | 844 KB | Unlinked once SafetyHook landed |
| `lib/d3dx11.lib` | 14 KB | Linked, but no D3DX11 API is called anywhere in the tree |

`TarkovAddons/lib/` is now empty and removed from the build.

Also removed: `external/detours/`, `hooks/`, `gui_dev/`, `assets/item_database.h`,
and the nested duplicate `TarkovLauncherBypass/TarkovLauncherBypass/` project
directory (the bypass was flattened one level).

### Functions

- `QuestModule::complete_all_impl` and its `queue_unlock_all` flag — no call site,
  no UI button. The other three quest actions are unaffected.
- `il2utils::hook_vtable_method` — a `[[deprecated]]` shim with zero call sites.
- `TA_FRAME` — defined twice (once per `#ifdef` branch), called zero times.

### Archived rather than deleted

`module/always_on_deprecated.h` (224 lines) holds the dead
`hk_transit_point_move_next` hook body and three unused signatures. It is not
compiled and not included; it is kept because the investigation into it took
real time and the reasoning is worth preserving. `always_on.h` went 1885 → 1763
lines with all 24 installed hooks still live.

### Deliberately kept

`config/FavoritesValue.h` (132 lines) has no references, but it is a complete,
plausible feature rather than a stub. Kept.

---

## 5. One embedded-asset mechanism

The background image, all 19 locales, and all 22 minimap assets are compiled
into the DLL as `RCDATA` (see `assets/menu_background.rc` — id 101 for the
background, 1200–1221 for maps, 1300–1318 for locales). Verified id by id
against the on-disk set: 12 map `.json` + 10 map `.svg` = 22. `laboratory` and
`labyrinth` have no SVG, by design.

RCDATA is now the single mechanism. Previously three different code paths walked
the resource section, each with its own bounds handling. They are collapsed into
`util/pe_resource.h`, which validates every step.

On-disk copies under `ta\lang` and `ta\maps` are still deployed, as the fallback
and so the files remain readable and editable. Translations resolve RCDATA first,
then `ta\lang` — so they work even if the resource section is unavailable.

### The RCDATA path never actually worked, and a harness did not catch it

Worth stating plainly, because it is a lesson about the verification in §6.

`pe_resource::rcdata()` was being called with `self_module = nullptr` by both
`util/i18n.cpp` and `module/minimap.h`. With a null module its Win32 fallback
called `FindResourceW(nullptr, ...)`, which searches the **game executable**, not
the mod — so the resource lookup returned nothing and RCDATA silently never
loaded. The deployed on-disk copies in `ta\lang`, `ta\maps` and the background
PNG hid the failure completely: every feature worked, via the fallback, so
nothing looked wrong.

`rcdata()` now resolves the module from the call's own code address
(`GetModuleHandleExW(FROM_ADDRESS)`, validated against the PE headers, with a
`VirtualQuery`/`AllocationBase` fallback for a fully manual-mapped image with the
LDR entry unlinked) — which is what `menu.cpp` was already doing for the same
reason. The fix is confirmed with 15/15 assertions against the real built DLL,
mapped the way a manual mapper would.

**My RCDATA harness tested the walker in isolation and passed.** It proved the
bounds validation and the enumeration logic. It did not exercise the *call
sites*, so it was blind to a `nullptr` that made the whole mechanism a no-op.
A test that passes while the feature it guards has never run is worse than no
test, because it manufactures confidence. The call site is the thing that needed
testing.

### The image-base lookup had one gate, and both of its answers went through it

The `self_module = nullptr` bug above was fixed and then the minimap still
reported **22/22 RCDATA payloads missing** — every embedded map, at DEBUG level,
followed by one ERROR saying the reader could not find a PE image base.

The packages were never at fault. Both the previously deployed DLL and the new
build contain all 42 `RT_RCDATA` entries (`101`, `1200`–`1221`, `1300`–`1318`)
with sane sizes, and `util/i18n.cpp` reads nineteen of them through the *same*
`pe_resource::rcdata()` in the same process, minutes earlier, successfully. So
neither the packaging nor the walk's arithmetic could be it, which left
`image_base_from()` — upstream of every payload.

That function had two sources, and the real problem is that they were not
independent:

```
GetModuleHandleExW(FROM_ADDRESS) ─┐
                                  ├─> looks_like_pe_image() ─> is_readable() ─> VirtualQuery()
VirtualQuery().AllocationBase  ──┘
```

Both answers had to clear `is_readable()`, and `is_readable()` began with a
`VirtualQuery` and returned `false` when it returned nothing. One call that comes
back empty therefore rejects a perfectly valid `HMODULE` *and* the
`AllocationBase`, and there is no third source left to try — which is why the
failure was total rather than partial, and why 22 identical messages said
nothing about which of the two things had gone wrong.

Three changes, in `util/pe_resource.h`:

- **`is_readable()` no longer depends on `VirtualQuery` alone.** `VirtualQuery`
  stays the fast path; when it fails, says the region is not committed, or
  reports a range spanning past the region, readability is answered with
  `ReadProcessMemory` against our own process, which reports a fault as a return
  value instead of raising. A blinded or intercepted `VirtualQuery` can no longer
  take the reader down.
- **A third source: `scan_back_for_image_base()`.** Walk backwards one page at a
  time from the code address for the PE header of an image that *contains* it —
  the canonical manual-mapper recovery. It needs no loader list and no
  meaningful `AllocationBase`, so it still answers when the other two are
  blinded. The containment test (`base <= address < base + SizeOfImage`) is what
  makes it safe: a naive scan settles for a *neighbouring* image's headers and
  then walks the wrong `.rsrc`, which is a silent wrong answer and worse than the
  failure being fixed.
- **`last_failure()` is `thread_local` and names each source.** It was one shared
  `const char*`, written by the failing lookup and read once after — from a
  render thread that runs it 22 times while `i18n.cpp` and `menu.cpp` call it
  from others, so another thread could overwrite the reason in between. The old
  comment called that a benign race on a diagnostic string; it is not benign while
  the diagnostic is the only evidence of a total failure. The reason is now
  formatted into a thread-local buffer and reports what each source actually
  said, which is the difference between "the loader lists do not contain us" and
  "both sources answered and their answers were rejected as non-headers" — opposite
  fixes.

Also fixed while in there: `child_directory()` validated only that a resource
directory's *offset* fell inside `.rsrc`, not that its 16-byte header did, so a
directory at `section_size - 1` was returned and the caller immediately read
`NumberOfNamedEntries` out of bounds — the exact class of bug this function was
extracted to eliminate.

### It did not work. The diagnostic is what proved it.

The first fix was not enough, and the log from the next run is why this section
appears twice.

The diagnostic printed all three sources failing at once, for an address
`base + 0x1057A0` — squarely inside `.text`:

```
GetModuleHandleExW(FROM_ADDRESS) -> a handle that is NOT a PE image header
VirtualQuery().AllocationBase    -> an AllocationBase that is NOT a PE image header
Backward page scan (64 MiB)      -> no PE header whose SizeOfImage contains it
```

and the surrounding log settles what that means:

- `crash probe: armed, this module at 0x7FFA37B70000 mapped extent 0x96F000`
  — 19:30:31, from the same `GetModuleHandleExW(FROM_ADDRESS)` call.
- `i18n: available languages: en, ru, … sk` — 19:30:32. The same reader had just
  read **19 payloads** out of this image.
- the minimap's 22 payloads, gone — 19:34:00, on another thread.

All three sources validate through `looks_like_pe_image()`, so all three dying
together says one thing and one thing only: `image_extent_at(base)` had started
returning 0 for our own, still-mapped, still-executing image. The backward scan
passed the base page on its way down — it is only 1 MB below the code address —
and did not accept it either. And `probe_readable()` could not rescue it, so it
was never a `VirtualQuery` problem at all: the header read itself stopped
answering. No amount of reading it better from 19:34 onwards was going to help.

**The fix is to stop asking.** The image base is a constant for the lifetime of
the module, and the loader *hands it to us*: `DllMain`'s `hModule` **is** the
base, at the one moment its headers are guaranteed readable.

`pe_resource::remember_image_base(hModule)` now runs first thing in
`DLL_PROCESS_ATTACH`, validates the headers while it still can, and stores
`{base, SizeOfImage}`. `image_base_from()` consults that before any query, and
the containment test — `base <= address < base + SizeOfImage` — is done on
integers. **Serving the captured base reads no headers at all**, so nothing that
happens later can invalidate it. A failed capture stores nothing and the query
sources answer as before, which is the old behaviour and strictly better than
caching something unvalidated.

This is the same pattern `module_paths::init()` already uses for the DLL's
on-disk path, for the same hazard, already written down there: loaders hide the
module from the module lists "right after LoadLibrary returns". This one is
simply reached later in time.

Two smaller things came out of the same round:

- **The diagnostic now reports facts, not conclusions.** "not a PE image header"
  was an *inference* from a failed validation, and it hid the only interesting
  part: an unreadable page, a wrong magic, a bad `SizeOfImage` and a hijacked
  answer all read identically. It now prints the raw `VirtualQuery` fields
  (`Type` / `State` / `Protect` / `RegionBase` / `RegionSize`) for both the code
  address and the allocation base, the magic at each candidate, the loader's own
  handle and extent, and whether the init-time capture is populated. One run of
  *that* would have named the cause on 19:30 instead of on 19:34.
- **The failure buffer grew to 1024 bytes.** The one line that explains a total
  failure is the only evidence there is; truncating it to fit defeats it.

### Coverage for the reader

`tools/harness/pe_resource_test.cpp` + `run_windows.bat`: **55 assertions**, all
passing, compiling the real header against real `RCDATA` compiled in by
`rc.exe`. It exists because this failure was so hard to diagnose from logs
alone, and `run.sh` could not cover a Win32-only file — the excuse that it "had
no coverage" was wrong: it needs a Windows *host*, which is what this is.

Its decisive block captures a base, then makes the header page `PAGE_NOACCESS`
and blanks the body, so all three query sources fail exactly as they did in the
game — and asserts the captured base still answers. Seven guards are validated
by negative control, i.e. by reverting the behaviour and confirming the harness
fails:

| Reverted | Result |
| --- | --- |
| captured base dropped from `image_base_from()` | 54/55, exit 1 |
| cached base served without a containment test | 53/55, exit 1 |
| capture stores an unvalidated base | 51/55, exit 1 |
| containment guard removed | 41/43\*, exit 1 |
| third source (`scan_back_for_image_base`) removed | 42/43\*, exit 1 |
| `is_readable()` back to `VirtualQuery`-only | 41/43\*, exit 1 |
| `last_failure()` shared, not `thread_local` | 42/43\*, exit 1 |

\* counted against the 43-assertion file as it stood before the captured-base
block was added.

Two of those controls caught tests that were passing for the wrong reason, and
the test file records both where they happened: the thread test read its reason
before the worker had been scheduled, and the "spans two regions" assertion used
two pages with identical protections, which `VirtualQuery` merges into a single
region. Both now have forcing conditions. A test that cannot fail is worse than
no test.

**What is still not covered:** an intercepted `VirtualQuery`. It is an imported
function, so interposing on it would mean redefining a `dllimport`. The specific
claim "a blinded `VirtualQuery` cannot take the reader down" is argued from the
source rather than asserted — and, per the run above, it was the wrong theory
anyway.

---

## 6. Known open items

Listed honestly rather than buried. Nothing here is fixed in v3.2.

Each item below was re-verified against the code while writing this section, and
items that did not survive that check have been left out — see the note at the
end.

### 1. A confirmed null-pointer write — fix this first

`module/production_panel_probe.h`, `production_panel_install()`. Crash confirmed
from a minidump: `0xC0000005`, WRITE violation at address `0x0`, faulting at
`TarkovAddons.dll + 0xEBA90`. It went misread as a chams asset-bundle failure for
several sessions because both run in the same `ModuleManager` dispatch.

The cause is a trap in `il2utils::hook_method`, whose last parameter is taken
**by value** and is meant to be the *address* of the caller's orig-pointer. Every
other call site passes `&o_...`, so `T2` deduces to pointer-to-pointer and the
store lands in the caller's variable. Four calls in `production_panel_probe.h`
omit the `&`, so `T2` deduces to the *function-pointer type* — `original` holds
the **value** of `orig_show_contents` (null on first install), and the store
becomes `*(void**)nullptr`. `reinterpret_cast<void**>` on a function pointer is
legal on x64, so it compiles silently.

Adding the four `&` fixes the crash. **The fix worth taking is to make the
contract unfailable** — take `T2& original`, or an explicit `void**` — so a bare
function pointer stops compiling. Adding the `&` leaves the same trap armed for
the next caller.

> **Superseded:** this section originally said `util/crash_probe.h` "should come
> out once the crash is verified fixed". That is no longer the decision — the
> probe is **retained as a standing diagnostic**. The justification has changed
> twice since, and the version quoted here was itself wrong:
>
> *This said* "WER is disabled machine-wide", which stopped being true on
> 2026-10-03 when WER was re-enabled. The conclusion survives anyway, for a
> sharper reason: **WER reports the faulting module, the fault offset and the
> thread, but not `ExceptionRecord.ExceptionInformation[1]`** — the address that
> was actually unreadable or unwritable. That one field is the whole difference
> between "somewhere in here" and a diagnosis, and it is the field the probe
> prints first. It is what located the 2026-10-03 12:38 crash.
>
> What is left of the original reasoning still holds: this project builds no
> standalone executable, and a fault inside the game process is a one-shot event
> with no attached debugger. `tools/probe_test` is now a partial exception — a
> standalone harness that exercises the probe against a real process.
>
> The probe's header and arming comment no longer carry the TEMPORARY banner. See
> `AGENTS_TODO.md` §0, and §5.16 for the one class of crash it provably cannot
> see.

Full analysis in `AGENTS_TODO.md` §0.

### Launcher bypass

- **The HWID check is never patched, and the warning says why it isn't.**
  `globals::PATCH_WINDOW` is 32 — the number of bytes `remote_bytes_match` reads
  from the live module — but the manifest's `hwid_check` pattern is **33 bytes**
  (the longest of all 19 symbols; the next longest is 29). `pattern_matches`
  bounds-checks correctly and returns `false` at byte 32, so the check can never
  succeed. `spoofer.cpp` then logs *"rejected by byte check against the live
  module - check left alone"*, which reads like the live bytes didn't match. They
  did. The window is one byte too small. Either raise `PATCH_WINDOW` to 64 or
  split the validation. **This fails safe** — the check is left in place — so the
  consequence is a feature that silently does nothing, not a crash.
- **The LDR module walk reads the wrong structure.** `injector.cpp:68-80` takes
  `InLoadOrderModuleList.Flink` as the address of an `LDR_DATA_TABLE_ENTRY`.
  `Flink` points at the *next entry's* `InLoadOrderLinks` field, which is not the
  start of the entry. Every field read from there is offset wrong. The correct
  address is `Flink - offsetof(LDR_DATA_TABLE_ENTRY, InLoadOrderLinks)`.
- **`CloseHandle` is called on a remote module base address.** At
  `injector.cpp:277`, `found_module` is `me32.modBaseAddr` from a toolhelp
  snapshot of the *game* process. That is a pointer in another process, not a
  handle in this one. `CloseHandle` on it either fails or, by coincidence, closes
  an unrelated handle in the launcher. Line 272 (`CloseHandle(snapshot)`) is
  correct; 277 is not.
- **`find_module` iterates past its own array.** `disabler.cpp:47` declares
  `HMODULE hMods[1024]` but bounds the loop with `cbNeeded / sizeof(HMODULE)`,
  and `cbNeeded` is the size needed for *all* modules in the target. A process
  with more than 1024 modules would read off the end of the stack array. Real
  game processes are far below that, so this is latent rather than live, but the
  bound should be `min(cbNeeded, sizeof(hMods))`.
- **x86 calling-convention mismatch in the HWID spoofer.** In `spoofer.cpp`,
  `oGetFn` (`:273`) and `oGetSystemFirmwareTable` (`:159`) are function pointers
  declared with no calling convention, so they are `__cdecl`, while their hooks
  `hkGetFn` (`:275`) and `hkGetSystemFirmwareTable` (`:161`) are `__stdcall`. The
  SafetyHook trampolines are retyped to the cdecl pointer, so on a stack the real
  `__stdcall` callee pops the arguments *and* the cdecl caller pops them again.
  **Moot as of the x64-only cleanup** — see below. Recorded because the mismatch
  is still in the source and would return the moment an x86 configuration is
  added back.

### Optics / ESP

Untouched on purpose — see §3. Known and still present:

- `dual_active` has dead branches in three sites, and those dead branches are the
  only optic-aware path in each, so enabling the feature as written would not work.
- `main_player_` is declared at `EspModule.h:678` with no initializer and is read
  at `:5071` and `:5122` inside the lens pipeline, while the first assignment is
  at `:5669`. If the lens pipeline runs first on a given frame, that read is of an
  indeterminate pointer. Order-dependent, so not proven to fire every run.
- A packet-pool race in `optic_lens_pipeline` (identified during the earlier
  audit, not re-verified in this pass).

### Verification

**Status: the x64 build now passes.** All x64 configurations of all three
projects (`TarkovAddons`, `TarkovLauncherBypass`, `vk_swiftshader`) compile and
link with zero errors, via the solution and per-project.

The first pass here was `-fsyntax-only` plus harnesses, and that was not enough —
see §5. Building is what surfaced the two defects reasoning had missed:

- `menu.cpp` carried a leftover `static const unsigned char menu_background_png[];`
  from this changelog's own background cleanup: a definition of incomplete array
  type with no initializer, which is ill-formed C++. Nothing referenced it, and no
  syntax check objected, because the error only appears once the declaration is
  actually reached in a compiling TU with the include removed.
- All four `Win32` configurations of the bypass failed with C2039 on
  `CONTEXT::Rip`, which only exists in the x64 `CONTEXT` layout. They were dead
  and are now deleted rather than repaired. Nothing had caught it because nothing
  had ever built them.

| Harness | Covers | Result |
| --- | --- | --- |
| migration | 9 scenarios driving the real `module_paths.h` / `data_migration.h` against real directories, including a 3.2 config being found when the move never happens | 32/32 |
| RCDATA | walker, then the call sites, against the real built DLL mapped as a manual mapper would, byte-identical payloads | 15/15 |
| deploy script | the `ta/` half of the post-build, under `wine cmd` — result tree and file counts | pass |
| i18n order | RCDATA-before-disk resolution | pass |
| `wide_to_utf8` | the overflow fix, at the boundary size | pass |
| config parser | the `key;value;favKey;fav` token walk against real save output | pass |

**A successful build establishes no runtime behaviour.** Everything below still
needs one launch: the bypass hook install path, the `"Built-in minimap assets
unpacked: … (22/22 files)"` line (whose *first* appearance is the proof RCDATA
works), chams, and the `ta\configs\` result against a real install.

Details in `CLEANUP_AUDIT.md` and `AGENTS_TODO.md`.


### Claims that were dropped

Kept here so the same ground is not re-covered: three items from the earlier
audit turned out to be wrong when re-checked and are **not** defects.

- `HideoutAutomationModule` "calls `GetProductionRecipes` unthrottled every
  frame" — no. `refresh_schemes` guards on `schemes_task_`, issues a new request
  only when nothing is in flight, and returns while the task is pending.
- `eft_ready` "is not atomic" — no. All three uses (`:187`, `:300`, `:568`) are
  inside the same function, `launch_game`. There is no cross-thread race.
- `g_active_quest_item_ids` "is unguarded" — no. `is_active_quest_item_id`
  fails open when the cache has never been refreshed, and degrades to the older
  template-flag-only filter rather than to hiding everything.


---

## 7. Version

`v3.1` → **`v3.2`**, called stable.

The config serialization format is unchanged, so this is a minor bump. The
deployment layout is reorganised but migrated automatically, so it is not a
breaking change for existing installs. `get_display_title()` in `util/globals.h`
is the single source of truth for the console title, menu title, watermark and
log header.

### 0.18 A complete raid at last: 2.42 M rays, `hit_target` = 0, and no crash

`next_next_day+6+crash.tracy` is 192 MB — the first capture of a full raid length
(19:51:25 -> 19:55:38, exfil), and the first seven `vis-breakdown` windows this
investigation has had.

| exit | count | share |
|---|---|---|
| `hit_occluder` | 2,378,645 | **98.389%** |
| `ray_miss` | 38,959 | 1.611% |
| `hit_target` | **0** | — |
| `hit_shooter` | **0** | — |
| **total** | **2,417,604** | closed set verified |

**`hit_target = 0` over a complete raid**, at 131.3 rays per game update and 17.6 per
skeleton. Not a transient, and not a short session.

**The removed probe never asked the discriminating question.** All ten of its samples
hit static geometry — `Rack_shelf_04_COLLIDER`, `Area_02_inside_wall_D_COLLIDER`,
`Case_shower_COLLIDER`, all layer 18 at 1.25-4.78 m. That shows the walk is correct
*walking props to the scene root*. The case that separates "correct" from "broken" is a
ray reaching a **bone collider**, and no sample ever produced one.

So two explanations stand, with opposite fixes. **Structural:** the target's own layer
is simply absent from the resolved mask (`0xe4441ac9` / `0xe4441ac0` — bits
0,3,6,7,9,11,12,18,22,26,29,30,31, OR'd from whole masks), which makes `hit_target`
unreachable by construction; `hit_occluder` then means "blocked, not drawn",
`ray_miss` means "clear, drawn", and the feature is **correct** with 98% simply
recording that the tracked bots were behind walls — unremarkable for factory with 7-10
players across rooms, and the 1.6% `ray_miss` is the visible ones (it spikes to 8.3% in
one window). **Or a real bug:** the walk never matches player-owned colliders and every
limb is drawn occluded.

The decisive test is one extra raycast: on the `ray_miss` exit, re-cast the identical
ray with an all-layer mask and report what it hits. Target's own collider means the mask
was at fault; nothing means the bone genuinely has no collider and `ray_miss` is honest.
1.6% of rays, sample-capped, and no managed object walks at all.


**On the crash: 0.16 and 0.17 supersede this section's attribution, and 0.14 changes
the instrument.** Symbolizing this session's AV independently landed on
`read_ballistic_identity` -> `describe_layer` -> `assess_ricochet` ->
`try_read_layer_penetration` -> `is_target_visible_penetrating`: the aimbot pen-check,
not the ESP. That much stands. But 0.17 identifies a missing `this` on
`try_get_lossy_scale`, and that function is reached from `assess_ricochet` -- the
**same frame in the same stack** -- so it is a more specific account of the same crash
than mine was. And 0.14 establishes the crash probe could itself kill the process, which
means "the probe reported an AV" was never a guarantee that the probe was not also a
cause. My 0.12/0.13 reasoning about `outside this module` was wrong for that reason as
well, independently of the misreading 0.16 records.

**No crash captured — which is itself a result, and a limited one.** Zero
`ACCESS_VIOLATION` and zero `FATAL` across the whole raid with the pen-check running
continuously to `Local Raid Ended`, where the four previous sessions each had exactly
one AV mid-raid. The post-exfil exit is almost certainly **after** the vectored handler
is detached at teardown, so the probe could not have seen it; this should not be read as
"the pen-check fix held" so much as "the instrument was not looking".

The pen tallies ran closed-set over ~9,000 checks with the full spread of reasons
visible (`clear` / `ammo_vs_level` / `ricochet` / `budget_layers` / `chance_zero`) —
the other workstream's result, recorded because it is the same log.

`esp_scan::quest_poi_scan` is the reproducible hitch: zone `max` 213,128,150 ns against
`poiScan=213128us`, the third session at ~200-213 ms.
`esp_scan::refresh_cache_stats` max 16,980 ns — innocent for the **fourth** time. But
213,604 µs of the 508,694 µs tail remains unattributed, stable at 209-214 ms across
three sessions, in the `do_quest_items` block, the `publish()` group,
`scan_bot_corpses_for_minimap` and the grenade/tripwire/keypanel scans — none of which
carry a zone.

### 0.19 Two bounded diagnostics for the visibility question, and the last unzoned tail regions

**A correction to 0.18's own proposal.** The all-layer re-cast was suggested for the
`ray_miss` exit on the reasoning that it tests the 98%. It does not: `ray_miss` **returns
TRUE** -- it is the *visible* verdict -- so re-casting there tests false **positives** in
the 1.6%, a real but different defect. The 98% lives on the `hit_occluder` exit. Both are
now instrumented, each on the exit that carries its question, sharing one budget of 12
samples at least 2 s apart:

- **`vis_diag_occluder`** (`hit_owner::none`, 98.389% of rays) reports the hit's layer and
  distance and the **first ancestor whose name looks player-owned** -- `eurocube*`,
  `*_BALLISTIC_*`, `Root_Joint`. A hit carrying one of those that `classify_hit_transform`
  returned `none` for is the walk **provably** failing, with the name attached
  (`VERDICT=WALK-FAILED`). This is the evidence the removed chain dump could not produce:
  selecting samples by "unattributed hit" can only ever find things that are not
  attributed, which is circular, and why ten static-geometry samples settled nothing.
- **`vis_diag_miss`** (`ray_miss`, 1.611%) re-casts the identical ray with all layers. A
  hit means the occlusion mask is too **narrow** and a bone is drawn as visible while
  actually behind something on an excluded layer (`VERDICT=FALSE-VISIBLE`).

Together they test both directions of the mask and the walk itself. The pen walk's log is
already evidence for the first -- `L0 go='eurocube_skeleton_01_BALLISTIC_metalthin'`
walked as a penetrable layer where a working classify returns `hit_owner::target` -- and
this turns that observation into a measurement.

**Safety.** Every managed call is gated on `eft_api::is_readable_address_cached`, checked
**per hop** rather than once per chain, since an ancestor can be freed while a deeper node
is still mapped; unreadable nodes print `<unreadable>` and stop the walk instead of being
handed to the game. The re-cast is `g_linecast`, already called ~2.5 M times per raid, so
no new kind of surface -- which matters because 0.16 shows a fault inside a managed method
reads as "outside this module", the misreading that got a probe blamed for a pen-check
crash.

Steady-state cost is **one relaxed atomic load per call**: the budget check is first, so
once the 12 samples are spent there is no clock read and no extra raycast.

**Every region in `gameworld_update`'s post-loop half now carries a zone**, which is what
the 209-214 ms remainder needed -- its candidates had none. Added
`esp_scan::quest_items_scan`, `esp_scan::keypanel_scan`, `esp_scan::publish_group`, plus
`miscScan` / `corpseScan` / `publish` buckets.

**`esp_scan::publish_group` is the one to watch:** it is the only block in that half taking
a **cross-thread** lock. `data_mutex` is the same mutex the render thread takes to read
its snapshot, so a stall there is contention rather than work -- and contention would look
exactly like the stable remainder. Its bucket is stamped immediately before the lock so
it measures the **wait**. If it shows ~200 ms with almost no self time, the answer is the
lock.

Two wiring mistakes caught rather than shipped, both of which would have produced a
misleading log line instead of a crash: `t_publish` was aliased to `t_corpse`, so
`us_publish` spanned the corpse scan and the buckets overlapped; and declaring it
`const auto` *inside* the publish block scoped it there while the accumulation sits after
the closing brace, giving `C2065: t_publish: undeclared identifier`. Declared in function
scope, assigned immediately before the lock.

Verified: timers strictly monotonic 5316 -> 6566, no bare `return` between `begin` and
`report` so every bucket always closes, and both consumers of `skeleton_visibility.h`
compile clean with **0 errors and 0 warnings** in `Prod|x64` and `Prod no aimbot|x64`.
`tools/tests` 155 passed.

### 0.59 The liveness memo cost 460 µs per call on a 98% hit rate, and the camera reporter was lying

> **Renumbered 2026-10-06 from 0.22.** This and the next entry were written by a
> second session that started its own series at 0.21, colliding with the 0.20-0.22
> run that follows. Both numbers were ambiguous for as long as that stood. The pair
> moved to the two free numbers at the end of the run; nothing else was renumbered,
> so no other citation changed meaning. The 0.20-0.22 entries below kept their
> numbers because 0.23+ continues from them.

`next_next_next_day+1+crash.tracy` (61.6 MB, 2026-10-04 08:37) plus its log. Three fixes, two of which
were found by arithmetic rather than by the profiler, and one self-correction.

**A RETRACTION FIRST, because it would have been acted on.** The previous entry's
`resolve_esp_camera_frame` figure was read as a regression — 41 µs → 2,501 µs, "the hoist made it 6×
worse". **That compared this session's _inclusive_ total against the previous session's _self_**, which
is the trap `tools/tracy/README.md` names as the one that costs the most time. Measured properly:

| zone | self | inclusive |
|---|---|---|
| `eft_api::resolve_esp_camera_frame` | **0.19 s** / 14,198 calls / **13.5 µs** | 35.51 s |
| `aimbot::candidate_pick` | 0.01 s | 37.15 s |

The zone's self time went **41 µs → 13.5 µs** and calls **154,544 → 14,198**. The hoist did what it was
built to do, and the 35.51 s belongs to `candidate_pick`'s children, which the inclusive column is
counting on the way past. **Not reverted** — reverting on that comparison would have made the frame
worse while looking principled. The lesson is the README's own: one table at a time, and `-e` is not
`-u`.

**1. `unity::is_unity_object_alive`: 64.87 s, 460 µs mean, against a 98% memo hit rate.**
Two numbers that cannot both be right — a memo hit is a compare and a return. The function called
`maybe_report_native_object_memo()` on **every hit**, and that helper early-returns unless 30 s have
passed, so it reads as guarded. It is not: **`std::format`'s arguments are evaluated at the call site**,
so the formatting work happened on all 140,875 calls rather than the ~9 that print. This is
`WORKFLOW.md`'s "per-frame logging costs real time" note, in a function called per-frame from several
sites, and the zone's own comment still claimed the profile number "justified memoising this".

Fixed by gating on the cheap counter **first** — `(st.hits % kReportEvery) == 0` — so the clock read,
the `std::format` and the logging only happen every 4,096 calls. Deliberately **not** gated on
`TA_ZONE_IS_ACTIVE`: that would tie a correctness fix to whether a profiler is attached, and the cost
is real whether or not anyone is listening. Both the hit path and the post-syscall store are gated.

**2. `cam-choice` `[MISMATCH]` was a torn read in the reporter, not a missing count.** 4 lines of 9
mismatched, in **both** directions (`sum < resolves` three times, `sum > resolves` once). A sum larger
than the denominator is impossible from the closed set alone, which is what made it look like a
double-count. It was not: the reporter read all three buckets with `.load()`, computed `sum` from
those reads, and cleared them with `store(0)` at the **end** of the function — while the aimbot
resolves cameras from the game thread and the reporter runs on the render thread. Every intermediate
value is a snapshot of a different instant.

Fixed by `exchange()`-ing each bucket into a local, which takes the value and clears it in one
indivisible step, so the buckets, `resolves` and the distance accumulators all describe the same
instant. The trailing `store(0)` is **removed**, not moved: re-zeroing after the snapshot would
discard resolves that landed in between and make `sum > resolves` for real.

A `[MISMATCH]` that fires on 4 of 9 lines is worse than no check — it trains the reader to assume the
invariant is broken and go hunting a bug that isn't there.

`retract_cam_source()` added as a named counterpart to `bump_cam_source()`, so the refuse path's
`fetch_sub` is one retraction by construction rather than a raw decrement at a call site. A test
asserts **every** `fetch_sub` in `eft_api.h` lives inside that helper.

**3. The last unowned region in the aimbot is now zoned.** `frame::AimbotModule::gameworld_update` had
19.58 s of self time (1,338 µs mean over 14,630 calls) with every child attributed. Both of my earlier
hypothesis zones came back **wrong**: `main_player_method_resolve` 0.01 s and `velocity_prediction`
0.00 s over 775 calls. The cost is in the live-player scan's loop body, now split three ways:

| zone | what it isolates |
|---|---|
| `alive_player_scan:profile_fetch` | the one `get_Profile` managed call per candidate |
| `alive_player_scan:transform_walk` | component → GameObject → Transform → position |
| `alive_player_scan:candidate_insert` | the `std::map` insert, i.e. a malloc/free pair per surviving player per frame against a map cleared and rebuilt every frame |

All three needed explicit braces: `TA_ZONE_N` expands to a variable literally named `ta_zone`, and
`alive_player_scan`'s zone is still open around the loop, so a bare zone is a redefinition (C2374).
That is the third time this build has hit it, so it is now stated at each site rather than rediscovered.

**Tests.** `tools/tests/test_unity_liveness_throttle.py`, 5 cases, two negative controls that
re-introduce each shipped defect (unguarded report; `.load()` + trailing clear) and must fail — both
verified to fail for the right reason rather than passing vacuously. `tools/tests` **190 passed**.

Both flavours build clean, 0 errors and 0 warnings.

### 0.60 The aimbot resolved the camera once per candidate bone, and the pen walk could discard a real layer

> **Renumbered 2026-10-06 from 0.21** — see the note on 0.59 above. This entry
> previously sat *before* its own 0.22 in file order as well as sharing the number,
> so the pair read 0.22 then 0.21. It now reads in order.

Both found from `next_next_next_day+crash.tracy` (63.8 MB, 2026-10-04) plus its log. The
log's own pen-check lines are what made the second one visible; neither was reachable from
the previous capture.

**1. Camera resolution was 92% of the target pick, 6.9x over-called.**

| zone | calls | self | mean | max |
|---|---|---|---|---|
| `eft_api::w2s_prefer_optic:resolve_camera` | **154,544** | **6.33 s** | 41.0 µs | 15.71 ms |
| `aimbot::project_to_screen` | 153,725 | — | — | **55.72 ms** |
| `aimbot::candidate_pick` | 22,431 | — | — | 90.32 ms |

The two identical **55.72 ms** maxima place that frame's entire stall inside one resolve
call, by the exact-`max_ns` technique in `tools/tracy/README.md`. And 154,544 resolutions
for 22,431 picks is **6.9x redundancy**: the loop projects ~7 candidate bones and each
iteration re-resolved the camera from scratch.

It is not a cheap redundant read. `pick_esp_fps_camera` reaches `unity::find_camera_if_best`,
which is backed by Unity's `Camera.all` — **a fresh managed array allocation per call plus a
`GetName` per camera in the scene**. So this was an allocation per projected bone.

And it was not adaptive, so there was nothing to amortise. The `cam-choice` diagnostic says
`resolves=25696 named=25696 fallback=0 none=0 | named_multi=0 far=0 far_refused=0` — every
call succeeded by name. The 41 µs *is* the successful name walk, paid 6.9 times per pick.

Fixed by resolving once per pass: `eft_api::esp_camera_frame` + `resolve_esp_camera_frame` +
`world_to_screen_with_frame` in `eft_api.h`, and the pick loop now projects through the
hoisted value. **Once per pass, deliberately not a cross-frame cache** — the camera
legitimately changes between frames, and a stale camera is the exact failure the by-name
lookup exists to prevent.

Two details that are silent behaviour changes if got wrong, so both are asserted in
`tools/tests/test_camera_resolve_once.py`:

- the struct carries `scope_zoom` **as passed in**, not `resolve_esp_camera`'s mutated
  `out_zoom`. The optic branch calibrates against the former and the FPS branch projects
  with the latter, and they differ — `out_zoom` becomes `1.f` when the optic camera wins.
  Collapsing them would break the FPS path, and the symptom would be "ESP is offset when
  not ADS" and nothing else.
- `fps` is nulled when it equals `cam`, so the calibrator is never handed the optic camera
  as its own FPS reference.

The old wrapper is **kept**: `world_to_screen_aim_marker` and the ESP still call it. This is
a call-site change, not an API removal.

The new zone is `eft_api::resolve_esp_camera_frame`, deliberately **not** the wrapper's
`w2s_prefer_optic:resolve_camera` — sharing a name would merge "once per pass" with "once
per point" and produce exactly the meaningless average the split existed to prevent.

**2. The exit-face rule could discard a genuinely separate layer — a pen-success with no
trace.** The rule skipped a re-hit when it merely **shared an ancestor** with the previous
layer (an eight-level climb) **and** sat within `kExitFaceMaxDist` (0.4 m). A metal cage
with a cylinder inside it is one prefab, and the cylinder sits within 0.4 m of the cage's
inner face — so the cylinder was discarded as an "exit face" and **never graded**. If the
cage wall was penetrable, the walk reported `clear` straight through solid metal.

The precise test already existed and ran **second**: `layer_ballistic == prev_ballistic`. For
the cylinder that is a *different* `BallisticCollider`, so it would have counted it
correctly. The loose hierarchy test was pre-empting the exact identity test.

Fixed on both axes:

- **Normal test added**, which is what actually distinguishes the cases. A surface the ray
  is *entering* presents a normal pointing back along the ray; one it is *leaving* points
  the same way. `m_normal` is not guaranteed unit length (the occlusion path treats
  `length(m_normal) < 0.1f` as an invalid-normal test), so it is normalised, with a dead
  band at ±0.1. Degenerate/NaN returns **false** — "cannot tell" must resolve towards
  counting the layer, never towards discarding it, because the failure modes are not
  symmetric.
- **`same_object` tightened to depth 1.** The rule was written for a `_BALLISTIC_`/
  `_COLLIDER` pair on one GameObject, or under one shared immediate parent — neither needs
  an eight-level climb. Deeper than that is an assembly, not an object. The distance bound is
  still required: an earlier version with relatedness alone produced false passes in the
  *other* direction.

**Honest status: this did not reproduce.** 23 hierarchy skips in the 2026-10-04 session and
**all 23 were on the same GameObject** as the previous layer — zero cases of a different
object being skipped. The 55 `related but too far` cases were correctly counted as new
layers, so the distance safety valve is working. The diagnosis stands on reading the code,
not on evidence, and there was **no way to tell** — which is finding 3.

**3. Skipped layers were invisible in the tally, so none of the above was measurable.**
Both skip paths wrote only into the `diag` string, built solely under `log_dump`. Measured:
**23 hierarchy skips and 40 same-ballistic skips in one session, and not one appeared in any
`pen: total=` line.** A walk that dropped a real layer and one that graded it correctly are
*indistinguishable*, so the bug could not be bounded and a fix could not be verified.

Fixed with two counters, reported on the pen line:

```
| skippedLayers=63 (hierarchy=23, sameBallistic=40)
```

**Separate counters, not new `pen_stop` buckets.** `pen_stop` has a load-bearing invariant —
exactly one slot per walk, so the slots sum to the call count by construction. A skip is not
a verdict; the walk continues past it. Putting skips in `pen_stop` would break the invariant
and make every tally ambiguous. Two counters rather than one because the two paths are
different tests and a single number would hide which is over-firing.

The `diag` text now also says **which** condition failed, because `"counted as a new layer"`
on its own is the line that hid this:

```
[related and near but the NORMAL faces the ray — a new surface inside a related object, counted as a new layer]
```

**3b. Identity is not "the same surface" — a re-entry into a compound collider was free.**
The `layer_ballistic == prev_ballistic` test was the *entire* basis for "the bullet is exiting
a collider it already paid for". But pointer equality cannot distinguish two cases, because
**both return the same component**:

| | geometry | should it count? |
|---|---|---|
| **exit** | the far side of a shell | **no** — one `PenetrationLevel` describes the whole component, so charging again bills for material already crossed |
| **re-entry** | a compound shell (nested walls, a barrel, a double-skinned panel) the ray has come back around into | **yes** — the single level does not describe it; the component has more surfaces than the one number |

Identity-only assumed the benign case. Same shape of error as the hierarchy skip one level
up: **a test that names a thing rather than the property being asked about.**

Fixed with the same discriminator — the normal — asking about the *surface* rather than naming
the *object*. `if (same_collider && exiting)` skips; `else if (same_collider)` falls through
to be graded again, counting `reEntry=`. Ambiguity resolves toward grading, because the
failure modes are not symmetric: over-counting makes the wall check refuse a shot it should
allow, under-counting lets the round through material the game would stop it on.

Reported as a **third** number, because without it `sameBallistic=N` reads as "N layers
correctly skipped" when some were re-entries that should have been graded:

```
| skippedLayers=0 (hierarchy=0, sameBallistic=139) | reEntry=0
```

**4. `frame::AimbotModule::gameworld_update` had 16.75 s of unowned self time** — 729.8 µs
mean over 22,952 calls, third-largest self time in the session, with every pick-loop child
separately zoned and separately small. The cost had to be outside the loop. Two candidate
zones added: `aimbot::main_player_method_resolve` (two **uncached** name→method walks per
frame — `resolve_method` has no cache, unlike `resolve_field`) and
`aimbot::velocity_prediction` (gated on the config value, so with prediction off the zone is
absent — which is the proof the gate works). If the next capture shows the first near zero,
the cost is the scan loop's own body, which is the question the number answers.

**Tests.** `tools/tests/test_pen_exit_face.py`, 26 cases. The predicates are **executed** —
ported 1:1 and run against hand-built geometry, 15 cases including the cylinder, thin
shells, non-unit normals and the dead-band edges; expectations are derived from which way the
surface faces, not from what the old code did. The wiring is asserted on source with comments
and literals blanked, plus a **negative control** that reverts all three requirements and must
fail. `tools/tests/test_camera_resolve_once.py`, 4 cases, two negative controls (hoisting the
resolve back into the loop; reverting to the wrapper). A third pen control collapses
`same_collider && exiting` back to bare identity and removes the re-entry branch — the shape
that actually shipped — and must fail.

**5. First deployment evidence, from `pid=3560` (2026-10-04 07:46).** The counters were
worth their keep immediately, and contradicted the diagnosis:

```
pen: total=1410 ... | skippedLayers=0 (hierarchy=0, sameBallistic=139) | reEntry=0
```

**`hierarchy=0` across the entire session.** The depth-1 tightening alone took the skip count
from 23/session to **zero** — every one of those 23 was an eight-ancestor false positive, and
the normal test was not what fixed it. The normal fired 34 times, but in **31 of 34 the
rejected layer was a different GameObject**, which the tightened `same_object` already
refuses. The 20× concrete-wall case was the same GameObject re-deriving itself, resolved by
`same ballistic` immediately after — so the normal test was over-firing on multi-panel walls
at the cost of an extra raycast and a muddier log. Its value there turned out to be
**diagnostic**: it named the case, which is how the identity/re-entry distinction above was
found.

`[closed]` held on all four tallies, so the `pen_stop` invariant survived. The crash in this
session was the same `0xE06D7363` at `KERNELBASE.dll+0xC41CA`, **with no Tracy running** —
so it is not Tracy-dependent, which weakens the Tracy hypothesis from the previous session.
Separately, `ERROR quest objectives: publish_objectives threw … 'badge pass'` appeared
**462 times** (0 in the two prior sessions, 187/minute at peak); that is the Quest
Completer, not this subsystem, but at 463 of 32,159 lines it puts the pen data under a 1.4%
flood.

One assertion in the pen test matches **raw** source rather than blanked, because
`skippedLayers=` is emitted inside a string literal and the stripper blanks those by design —
making that assertion unsatisfiable would be worse than not having it.

**179 tests pass** (was 155). Both flavours build clean, 0 errors and 0 warnings. All six
zone names verified present in the shipped binary.

### 0.20 How to operate a Tracy capture, written down — and three claims in that file were wrong

`tools/tracy/README.md` is the operating manual for the profiler. It existed and was
substantial, and reading it against the artefacts produced **three wrong instructions**,
two of which had been wrong long enough to mislead. It is now corrected, and the missing
procedure is written down.

**1. "Build Debug or Release — the `Prod` configs contain no profiler at all."** Wrong.
`TarkovAddons.vcxproj` carries a deliberate `TRACY_ENABLE` override on **both** `Prod`
configurations:

> `TRACY_ENABLE` IS defined here on purpose, temporarily: we want profiles of the
> **SHIPPING** build, not of Release. […] PLANNED REVERT: once the findings are in, drop
> these four defines to exclude the profiler from `Prod` again.

Verified against the built DLLs, both of which contain the `Start Profiler` string. This
matters beyond tidiness: **a Debug or Release profile is not comparable to a Prod
profile** — different optimisation, inlining and `_ITERATOR_DEBUG_LEVEL` — so a claim
that crosses that boundary is not an A/B result.

**2. The `.vcxproj`'s own comment claimed `Prod no aimbot|x64` "still has `TRACY_ENABLE`
absent."** Also wrong; that config omits `INCLUDE_AIMBOT`, not `TRACY_ENABLE`. The file
now says so and points at the artefact check, because a comment asserting which
configuration has a flag is exactly as stale as a document asserting it.

**3. "Two zones can deliberately share a name to aggregate into one bucket."** This was
**actively harmful advice**, and both instances of it are now split. Tracy aggregates
custom-named zones *by name*; `TA_ZONE_TEXT` attaches a string to a single call's payload
and never reaches the zone statistics. So a shared name plus the module name as text is
not a cheap way to get per-module detail — it is a way to **lose** it.

`frame::module` was `TA_ZONE_N("frame::module")` + `TA_ZONE_TEXT(m->name)`, added
specifically to answer *"which module is expensive"*. It carried **2,577,013 calls and
70.03 s**, and the CSV export showed one indivisible row. Now `TA_ZONE_N(m->name.data())`
— `m->name` is a `std::string`, so `.data()` is NUL-terminated and the macro's `strlen` is
safe — and one call site emits ~30 rows. The question survived three capture cycles
because the zone that existed to answer it could not answer it in the only form these
traces get read.

`skeleton_vis::is_target_visible` was the same mistake with a measurable cost. It covered
both the ESP raycast and the aimbot penetration walk, which measure **10.9 µs and
130.6 µs per call** — 12× apart, same helper. As one row the export reported a single
meaningless 10.9 µs mean and a summed call count. Split into
`is_target_visible` / `is_target_visible_penetrating`.

**Five zones touched, one renamed**, all aimed at regions the flat export could not
resolve:

| Zone | What it answers |
|---|---|
| `frame::module` → module name | the 70.03 s split per module at last |
| `skeleton_vis::is_target_visible_penetrating` | the 130.6 µs walk, no longer averaged with a 10.9 µs raycast |
| `EspModule::collect_skeleton:vis_memo_hit` / `:vis_rays` | the memo hit rate — the only lever on 25.78 s of raycasts |
| `EspModule::collect_skeleton:limb_health` | the last ~1.7 s unattributed in the module's largest function |
| `eft_api::w2s_prefer_optic:resolve_camera` | camera resolution vs projection behind the 54 ms frame |

**What the capture shows, from `next_next_day+6` (183 MB).** `ModuleManager::apply` self
time is **0.28 s of 70.31 s**, so the dispatch loop is free and everything is in modules.
`collect_skeleton` (34.97 s) is fully accounted: bones 5.57 s + visibility 27.68 s + ~1.7 s
self. And **`occlusion_linecast` is 93% of visibility time** — 2.53 M managed
`PhysicsExtensions.Linecast` calls at 10.2 µs. Irreducible per call; the only lever is
fewer calls, which is what the memo zones measure.

**A memo claim in this very section was wrong, and its own zones overturned it.** The first
draft of the paragraph above reasoned that the ESP visibility memo "cannot fire", because
`collect_skeleton` keeps a per-player memo gated on `vis_frame_serial_` (incremented once
per **presented frame**) while the memo is consulted once per **game-world update** per
player, and `+6` had **33,267 draws against 19,294 updates** — updates rarer than frames.
The arithmetic offered as confirmation was **2,533,776 rays / 143,808 calls = 17.6 rays
per call**, read as "every call raycasts".

That inference was wrong, and wrong in a way worth recording: 17.6 is an **average over
all calls, diluted by the hits**. `+7` measured it —

| branch | calls | share | inclusive mean |
|---|---|---|---|
| `collect_skeleton:vis_memo_hit` | 18,231 | **12.6%** | 0.1 µs |
| `collect_skeleton:vis_rays` | 127,014 | 87.4% | 217.9 µs |

— and `2,667,294 rays / 127,014 ray-calling calls = 21.0`, i.e. each *ray-calling* pass does
its whole link list, consistent with `skeleton_links().size()`. So the memo fires
**12.6%** of the time: `+7` had 53,638 draws against 53,637 world updates, so a hit means
the game ran two updates inside one presented frame.

The conclusion that survives is narrower and more interesting: **the memo is a frame-rate
artefact, not a throttle.** It saves ~3.5 s here and reduces nothing systematically — on a
machine where updates outran frames the rate would invert. It is not dead code; it is
unprincipled.

Still not changed. Whether it *should* become a real throttle is a behaviour question with
a flicker risk, and it now has a measurement instead of an argument. The lesson recorded
in `tools/tracy/README.md`: an average across a bimodal branch tells you nothing about
either branch — which is the whole reason those two zones exist.

**Two more findings the flat export could not show.** Sorting by `total_ns` hides a
**~58 M call** sub-microsecond tail: `managed_string_equals_leaf` 18.5 M, `bone_key`
15.0 M, `resolve_method` 13.3 M, `resolve_field` 11.1 M. Individually invisible, together
several seconds — a per-call cost under ~1 µs is a multiplier, not a leaf, and it only
appears if you sort by `counts`. And `always_on::hk_prepare_game_job` fires 8 times a
session at **3,258 ms on its worst call**, which nobody has ever looked at.

**Two operational gotchas now documented, both hit in this session.** The export encoding is
**not fixed**, and it is not the CLI's choice — `tracy-csvexport.exe` writes **plain UTF-8,
no BOM** (two runs, no encoding flag among `-f -s -c -e -u -g -m -p -t`), while the CSVs
beside the `.tracy` in `tracy_traces/` are **UTF-16LE with a BOM**. Something other than the
CLI wrote those; the GUI's own statistics export is the likely candidate and that is **not
proven**. `Import-Csv` sniffs both, Python's `csv` sniffs neither, and both failure modes
read as corruption: `KeyError: 'name'` on a header of `'\x00n\x00a\x00m\x00e'`, or
`UnicodeDecodeError: truncated data` at byte 0 with an **odd** file length, which is the
tell. Sniff the BOM. Second, the export is a **flat list of per-zone aggregates with no
call tree**, so containment has to be inferred; exact `max_ns` equality proves it.
`aimbot::project_to_screen`, `aimbot::candidate_pick` and `frame::AimbotModule::draw_overlay`
share a **54.12 ms** maximum, which places the whole 54 ms inside the projection and shows
one event rather than three coincidences — the answer you want, from a file that cannot
express parentage.

Zone inventory corrected: **79 distinct static names across 16 files, 82 sites**, plus one
dynamically-named site. The file's previous "65 zones / 66 sites, counted 2026-10-01" was
already wrong when written — it sat unmaintained while `skeleton_visibility.h` grew by
~950 lines. Recount rather than trust either number.

Both flavours build clean, **0 errors and 0 warnings**, `tools/tests` **155 passed**.

### 0.21 The visibility question closes: the walk is right, and the occluder probe was wrong

`next_next_day+7+crash.tracy` (224 MB). Three sessions in the log; the relevant one is
pid=25656 (22:39:59 -> 22:57:09, clean exfil). `vis-diag-occluder` returned all 12 of 12
samples, and **the instrument was confidently wrong.**

**Every sample read `VERDICT=WALK-FAILED` against `Old_Control_Panel_A_BALLISTIC_metalthick`
-- a control panel.** `classify_hit_transform` was right; the detector was wrong. This
file's own `name_looks_player_owned` treated `_BALLISTIC_` as a player marker, and it is
only EFT's material suffix on any ballistic collider, static geometry included. Removed;
the surviving patterns (`eurocube*`, `Root_Joint`) are player-specific by construction.
Twelve confident wrong answers from one over-broad pattern -- and the second time in this
investigation that an instrument of mine had to be discarded, the first being reading
`outside this module` as exculpatory.

**What the twelve samples did establish is the finding, and it is geometry:** an occluder
at **3.13-3.29 m** against a bone at **62.5-85.6 m**, on layer 12, `inMask=1`. A prop
three metres from the camera and a target sixty to eighty-six metres away is correct
occlusion, correctly reported.

**So there is no visibility bug, closed three ways:** two full raids and **5,420,982 rays
with `hit_target` = 0 and `hit_shooter` = 0**, closed set verified on both (pid=25656
alone: 16 windows, 3,003,378 rays, 97.62% occluder, 2.38% miss, peak 13.5% in one
window); ten chain-dump samples hitting genuine props; twelve new samples hitting a
control panel.

**The remaining finding is cost, and it is configurable.** `skeleton_distance` defaults to
**200 m** (range 50-1500). The ESP builds ~7.45 skeletons per game update with **~131
rays per frame** toward targets 60-90 m away, across a factory interior where a prop three
metres out hides them. Nearly all that work re-establishes what the geometry already says.

**The tail is fully attributed, and my lock-contention theory was wrong.**

```
esp-slow-frame[1/6]: total=516909us ... tail=486656us cacheStats=3us lootScan=73616us
  poiScan=214609us miscScan=193931us corpseScan=4371us publish=114us unaccounted=3203us
```

`poiScan` 214,609 + `miscScan` 193,931 + `lootScan` 73,616 + `corpseScan` 4,371 +
`publish` 114 + `cacheStats` 3 = **486,644 against a 486,656 tail** -- 12 us residual,
**99.998% attributed**. The 209-214 ms remainder three sessions could not place is
`miscScan`, the grenade/tripwire/keypanel bracket; `refresh_passcode_labels` under
`data_mutex` is the suspect inside it and now carries a zone, but there is no CSV export
for `+7` so the three-way split is not yet measured.

`esp_scan::publish_group` reads **114 us**, so 0.19's cross-thread-contention prediction
is **dead** -- the mechanism was named precisely and it was wrong. The zone stays.

**The exfil crash is not one the probe can see, for the second session running.**
pid=25656 ended with `Local Raid Ended` / `Transfer Items: 1` and **no fault of any
kind**. Same as `+6`. The process dies during or after teardown where the vectored
handler does not observe it, most likely after detach at unload. That is an instrument
limit, not an absence of crashes.

**The one real crash belongs to another session and another subsystem.** pid=10864 died
seconds in, `ACCESS_VIOLATION EXECUTE` of `0x0` -- a call through a null function
pointer -- symbolized against build `6AC13F71` to `dxhook::create_window +0xE2` <- 
`dxhook::dx11_setup +0x2B6`, last log line `Hooking Present`. `dxhook.cpp` is unmodified
in the working tree, so it is pre-existing, and it is the graphics/chams area.

`vis_diag_occluder` is **retired**: its question is answered and its verdict was a false
positive, so the still-open miss question gets the whole budget. A budget shared between a
97.6% path and a 2.4% path does not sample the 2.4% path -- `vis_diag_miss` got **zero**
samples last run, which is recorded as the design mistake it was.

### 0.22 A visibility-check distance cap -- and the trap that made it more than two lines

The per-bone occlusion rays are the largest leaf in every capture, and 0.20 closed the
correctness question: they answer correctly, they are just spent on targets nothing can be
seen through. 5,420,982 rays over two raids, `hit_target` = 0, and the samples put an
occluder **3.13-3.29 m** from the camera against a bone **62.5-85.6 m** away on a factory
interior. So the cap is the lever.

**Added `skeleton_vis_distance`** -- a `FloatSliderEditableValue`, default **75 m**, range
25-1500, plus `skeleton_vis_distance_itm` in `lang/en.json`. It gates **only the physics**,
which is why it is a separate slider: lowering `skeleton_distance` from its 200 m default
would also stop the skeleton being *drawn* past the limit, conflating "how far do I want
silhouettes" with "how far do I want to pay ~10.9 us per bone to pick a colour".

**The trap.** The obvious implementation -- skip the whole `if (check_visibility && ...)`
block past the cap -- is wrong in the dangerous direction. `EspModule.cpp:994` decides:

```cpp
const bool vis_on = skeleton_visibility->get_value() && link_index
    && *link_index < entry.link_visible.size();
```

An **empty** `link_visible` makes `vis_on` false, which falls past every visibility branch
to plain `skeleton_color` -- a **full-colour silhouette**, i.e. an enemy behind a wall drawn
as though visible. The cap therefore applies *after*
`entry.link_visible.assign(links.size(), false)` and before the ray loop, keeping the entry
in the occluded branch. That is also why it is near behaviour-preserving: it lands on the
verdict 97.6% of those rays were already producing.

**The number is a judgement, so the counters to replace it ship in the same commit.**
`record_vis_distance()` reports per 30 s window:

```
vis-dist-cap: playersIn=N playersOut=N bonesSkipped=N
  | raysOut ~= playersOut*~17.6 bones*~10.9us per frame avoided
```

`playersIn` small means 75 m is doing nearly all the work; `playersIn` dominant means it
is too tight and is discarding real information. One run replaces the judgement.

Wiring mistake, same class as before: the per-frame read was first placed beside
`skel_max_dist`, which lives in **`draw_overlay`**, not `gameworld_update` -- two functions
in this file carry near-identical tail blocks, and the call site is 400 lines away in the
other one, giving `C2065: vis_check_max_dist: undeclared identifier`.

Both consumers clean, **0 errors and 0 warnings**, in `Prod|x64` and `Prod no aimbot|x64`;
`lang/en.json` parses with 694 keys; no migration references `skeleton_distance` or
`box_distance` so a new slider needs none. `tools/tests` 155 passed. **How much this
actually saves remains unmeasured until a run reports `vis-dist-cap:`.**

### 0.23 The cost knob now explains itself on hover

`skeleton_vis_distance` reads as a distance but is a CPU knob, so it gained a hover
tooltip. Three shared files changed, all additively, none of them touched by the parallel
session:

- `slider_float_editable` takes a trailing `const char* tooltip = nullptr` -- several
  hundred existing call sites unchanged.
- `FloatSliderEditableValue` gains `tooltip_`, an optional ctor argument and
  `set_tooltip()`. Resolved via `i18n::tr()` **at construction**, so `draw()` does no
  translation per frame -- the same lifetime the title gets from `ConfigValue`.
- The popup hooks the slider track's **existing** `hovered`, so it adds no hit target and
  cannot change what the widget responds to, and it is suppressed while dragging.

The text gives the per-player cost (**~180 us of game-thread time per extra player per
frame**, from ~17-18 raycasts at ~10 us), then the part that actually surprises: it
scales with *how many players fall inside the circle*, so doubling the radius roughly
**quadruples** the work in a populated map rather than doubling it. Deliberately a
mechanism rather than a measurement -- baking a captured percentage into a shipped string
rots, and the live number is one `vis-dist-cap:` line away.

Editing hazard recorded: `slider_int_editable` and `slider_float_editable` end with a
byte-identical `AddCircleFilled(...track_w, cy...)` line, so a text-anchored edit matched
twice and refused; inserted by verified line number after asserting the target was inside
`slider_float_editable`.

`EspModule.cpp`, `AimbotModule.cpp`, `FloatSliderEditableValue.cpp` and
`imgui_addons.cpp` all clean -- 0 errors, 0 warnings -- in `Prod|x64` and
`Prod no aimbot|x64`. `lang/en.json` parses with 695 keys. `tools/tests` 155 passed.

### 0.24 The ESP was building skeletons for players behind the camera

Asking "does the raycast go in every direction?" found the largest remaining waste in the
module -- and it was not the distance cap.

**The asymmetry.** Every other ESP item projects and culls *before* doing its per-item
work; exfils, transits, grenades, keycards, loot, quest POIs, bot corpses and the **player
label** (`EspModule.cpp:5313`) all do `world_to_screen` then `if (!is_visible(...))
continue;`. The skeleton was the exception: its gate was **3D distance only**, so ~17 bone
resolutions plus ~17.6 occlusion rays -- **~0.22 ms** of game-thread time -- were spent on
every player inside a 200 m *sphere*, players directly behind the camera included. The
screen-space cull came afterwards and **per bone**, on the render thread
(`EspModule.cpp:1188`): all that work, for a figure that draws nothing.

Now culled in `gameworld_update` before any per-player skeleton work, so it saves the bone
resolution too. **Yaw-only**, deliberately: ignoring pitch keeps targets directly overhead
when they are in front horizontally, the generous direction. **Camera, not player body** --
the view is `cam='BaseOpticCamera(Clone)'` while scoped, a different object from the
player, and the one that frames the shot. **Fails open**: no culling without a valid camera
transform, and none for a target within 1 cm horizontally where the angle is undefined.

**70 degrees full cone** (`kSkeletonConeHalfAngleDeg = 35.f`), 19.4% of a circle, so an
**81% ceiling** on skeletons skipped. Verified in isolation: dead ahead kept, 45 degrees
off-axis culled, 90 and 180 culled, and the axis correctly rotates at yaw 90.

**The cost is pop-in at the cone edge, and it is a real trade.** 70 degrees full is
+/-35, at or just inside a typical 70-90 degree horizontal FOV, so a skeleton at the very
screen edge can pop in while turning. The symptom is skeletons flickering on-screen while
rotating, and the fix is one constant: at **50** (100 degrees full) the saving is ~72%
instead of ~81% and the edge sits outside any plausible FOV. Left at 35 because 70 degrees
was the figure asked for.

`vis-cone:` in the 30 s report gives built / culled / total and the percentage, so this is
measured rather than assumed. Both consumers clean -- 0 errors, 0 warnings -- in
`Prod|x64` and `Prod no aimbot|x64`. `tools/tests` 155 passed.

The two culls are **not additive**: a player outside the cone is skipped before the
distance cap is consulted, so raising the cap buys less once the cone is in place. Read
`vis-cone` and `vis-dist-cap` together rather than as separate wins.

### 0.25 The view cone now covers the whole player store -- and where a global limiter would not have helped

**5.7l's cull was skeleton-only.** It now covers box, label and skeleton, from one place:
`temp_players` is filtered by the same cone immediately before `player_store =
publish(...)`, which covers both render-side iterations -- boxes at
`EspModule.cpp:5199`, labels at `:5273`.

**Why one store-side filter rather than per draw site, because this is what fixes the
reported artifact.** Both draw sites already cull with `eft_api::is_visible`, but:

```cpp
screen_point.z > 0.01f && screen_point.x > -100.0f && screen_point.y > -100.0f
    && screen_point.x < menu::get_width() + 100.0f
```

...accepts a **100 px margin outside the viewport on every side**. A player just
off-screen passes both tests, and is built, projected and drawn anyway -- which is where
"skeleton lines getting all over screen" comes from. One store-side filter is cheaper than
any number of draw-side tests and cannot drift out of agreement with them. Note `z > 0.01f`
already handles **behind-camera**; this is about the margin, not the back of your head.

Fails open exactly as the skeleton gate does, with the same directly-overhead carve-out
where the horizontal angle is undefined.

**Where a truly global cone would not have helped, which is why it stops at players:**

- **`esp_scan::quest_poi_scan` is 214 ms of a 508 ms tail (44%) and is
  enumeration-bound** -- `quest_esp::start_collect_cycle()` then
  `advance_collect(game_world_obj, 512)` in a `while (... && guard++ < 400)` drain. It must
  walk the world to find anything, so view filtering cannot reduce it.
- **Loot is barely affected**: already registry-filtered by `dist_sq`, with a deliberate
  "no FindObjectsOfType" note at `EspModule.cpp:3576`. Culling it also removes awareness of
  things at your feet.
- **Exfils / transits / grenades / tripwires / keycards / corpses / containers** are tens
  per frame, not thousands, and already distance-gated. Consistency is the only argument
  there, not CPU.

Players are where the volume is (7.45 skeletons/update x ~17.6 rays, ~0.22 ms each) and
where the artifact is. Extending is one `erase(remove_if(...))` per vector -- all the
structs carry `pos3d` -- but it should be per-vector on purpose.

Both consumers clean -- 0 errors, 0 warnings -- in `Prod|x64` and `Prod no aimbot|x64`.
`tools/tests` 155 passed. **Caveat: `vis-cone:` counts skeletons only, so the next run will
under-report this change's effect.** Noted rather than hidden.

### 0.26 The view cone needed an origin that is not `my_pos`

`my_pos` is `unity::transform_get_pos(main_player_transform)`, which returns **exactly
{0,0,0}** for three indistinguishable cases (`unity.h:760`): null transform, unresolved
`get_position`, and a rig still being placed. The third is raid start -- the same window
0.9 records `Camera.current` belonging to a **bot**.

Unguarded, the cone would have been centred on the **world origin**, so legitimate players
get culled and illegitimate ones survive. A cull that cannot establish where the viewer is
must not fire.

**The fireport is the fallback** -- resolved from `main_player.get_Fireport()`, so anchored
to the local player *by construction*, which matters more than proximity -- and
`try_get_fireport_position` already rejects a degenerate muzzle itself. If rig and fireport
both fail, the cone is **disabled for the frame**.

It is called **only on the degenerate path**, because it does an UNCACHED `resolve_method`
and would be a poor per-frame cost for a raid-start transient. And `main_player_` is already
an `Il2CppObject*`; the first attempt wrote `main_player_.get_instance()` and drew
`C2228: expression to the left of '.get_instance' must be a class`.

`cone_origin` now feeds both cone sites. Both consumers clean -- 0 errors, 0 warnings -- in
`Prod|x64` and `Prod no aimbot|x64`. `tools/tests` 155 passed.

### 0.27 REGRESSION FIXED: the view cone pointed at the wrong object and hid every skeleton for 90 s

**Symptom:** skeletons stopped rendering while ESP labels kept drawing. The log says why --
the raid started 06:56:21 and the first three 30 s windows were:

```
06:57:30  vis-cone: built=0 culled=29544 of=29544 culledPct=100%
06:58:00  vis-cone: built=0 culled=28800 of=28800 culledPct=100%
06:58:30  vis-cone: built=0 culled=29132 of=29132 culledPct=100%
06:59:00  vis-cone: built=4956 culled=15698 of=20654 culledPct=76%
```

Every skeleton culled in every direction for ~90 s, then settling to 59-88% as designed.
Two defects, both mine.

**1. The direction came from the wrong object.** The cull took its yaw from
`unity::get_current_camera()` -- `Camera.current`. This module does **not** draw with it: it
resolves its own camera, which the report shows succeeding every time
(`cam-choice: resolves=25696 named=25696 fallback=0 none=0`). `Camera.current` is a
different object, not guaranteed to be the one framing the shot, so its rotation is not the
view direction. That call was mine and was the only one in the file.

Now the direction is **the player's own forward** -- what "in front of the player" means,
from `main_player_transform`, already resolved and already proven good because it is the
transform `my_pos` came from. No camera, no second object to disagree with, and scoped the
body still faces the optic. (`Camera.current` remains legitimate inside
`try_get_visibility_origin`, which needs only a position and has a fallback ladder.)

**2. A failed read was indistinguishable from a genuine 0 degrees.** `get_transform_yaw_y`
returns `0.f` for a null transform, an unresolved `get_eulerAngles`, and a real 0 degrees
alike -- so a cull gating on it turns "I could not read this" into a *confidently wrong
direction*, which is the worst failure mode for something deciding what is off-screen. Added
`try_get_transform_yaw_y(transform, float&) -> bool`; `cone_active` now needs a valid
direction **and** a valid origin, and a failure disables the cull for the frame.

**3. The missing instrument.** A one-shot `esp-cone-init:` logs
`dirOk / originOk / active / yaw / fwd / origin / halfAngle` on the session's first frame.
With it, this bug would have been one line instead of one minute of inference.

Both consumers clean -- 0 errors, 0 warnings -- in `Prod|x64` and `Prod no aimbot|x64`. No
code use of `get_current_camera` remains in `EspModule.cpp`. `tools/tests` 155 passed.

### 0.28 The 06:56 regression is fixed, and the visibility mask's narrowness is now explained

**The one-shot instrument does exactly what it was added for:**

```
esp-cone-init: dirOk=true originOk=true active=true yaw=127.1deg fwd=(0.80,-0.60)
  origin=(-46.3,0.3,7.0) halfAngle=35deg source=player-transform
```

`yaw=127.1` is a real facing -- which `Camera.current` was not giving. `vis-cone:` now
varies **31% / 39% / 75% / 73%** across four windows with `built` substantial in every
one, no 100% window, skeletons render. **No crash**: 6,536 exceptions, all
`DBG_PRINTEXCEPTION_C` and C++ throws, zero `0xC0000005`, zero `FATAL`.

**Q2 answered, and its verdict was wrong 13 times out of 13.** All twelve samples printed
`FALSE-VISIBLE`, but by distance they are two clusters:

- **10 x blocked at 0.01-0.05 m from the camera** (ratio ~0.001) -- the **shooter's own
  collider**; the camera sits inside their own head
- **3 x blocked at 11.3 / 13.4 / 26.5 m** (ratio 0.68 / 0.99 / 0.99) -- essentially **at
  the bone** -- the **target's own collider**

Neither is a false visible. Ignoring your own body is what makes the check work at all,
and reaching the target *is* the definition of visible. The probe labelled "an all-layer ray
hit something" as "false visible", which is not what it established.

**What it did establish, and it closes a question open since 0.11: THE OCCLUSION MASK IS
WORLD-GEOMETRY-ONLY BY CONSTRUCTION, which is why `hit_target` is structurally unreachable
rather than broken.** The target's own collider layer is not in `0xe4441ac9`, so the ray
passes through and exits as `ray_miss` -- reported as visible, correctly. Same for the
shooter, hence `hit_shooter` = 0 always.

**Worth keeping:** because the mask never lets a player collider reach
`classify_hit_transform`, that walk's behaviour on a player collider has never been observed
at all. Not shown correct, not shown broken -- unreachable while the mask is built this
way, and only relevant if someone widens the mask to include player layers.

`vis_diag_miss`, its budget, `vis_diag_due`, `name_looks_player_owned` and
`vis_diag_layer_of` are removed, reasoning left as a comment. Two of three instruments in
this thread have now reported a confident conclusion they had not earned -- a heuristic that
cannot fail is not a heuristic, and a verdict token deserves the same evidence as the code
around it.

Surgery hazard, self-inflicted: removing that block by line range left an orphaned `}` from
an earlier deletion, closing `namespace skeleton_vis` early and yielding four errors
pointing 120 lines from the cause. A symbol-set diff against HEAD proved nothing had been
lost.

Both consumers clean -- 0 errors, 0 warnings -- in `Prod|x64` and `Prod no aimbot|x64`.
`tools/tests` 179 passed.

### 0.29 Cone pop-in fixed with hysteresis, and the two cone sites can no longer disagree

Reported after the 0.28 fix: skeletons "can drastically change their draw-status" as the
player turns. A bare angle test has no memory, so a target a few degrees outside the edge
flips with every mouse movement.

**The skeleton gate and the store filter each recomputed the cone angle independently** --
so an entry could be built and then dropped, or dropped and then built. The decision is now
made **once per player per frame** and carried on the entry as `player::in_view_cone`; both
consumers read the flag. This also makes the grace possible, which needs per-player state
keyed on identity.

**Two mechanisms remove the pop, because they cover different motions:**

- half-angle **35 -> 50 deg** (70 -> 100 deg full) -- the edge now sits outside a typical
  70-90 deg horizontal FOV, so a slow sweep crosses the boundary off-screen
- **frame grace of 30 ticks** (~0.25 s) -- absorbs quick flicks and momentary corrections,
  which a wider cone does not and which a wider cone alone cannot fix

Ceiling falls from ~81% to ~72% culled. That is the trade, and both constants are named.

**Unbounded-growth bug in the memo, found while implementing it.** The first version did
`cone_memo_[key]` **before** the angle test, inserting an entry for every player entity every
tick -- including those inside the cone, whose only state is `outside_frames = 0` -- and never
releasing one. `operator[]` is now on the outside path only; the inside path finds and erases.

**The stale sweep is correctness, not hygiene.** An entity freed and reallocated at the same
address would inherit the previous occupant's grace and render with someone else's
hysteresis for up to 0.25 s; only a sweep prevents that. `kConeStaleTicks` (4,800) is set ~160x
the grace on purpose: dropping a memo early gives a player a **fresh full grace** next time it
crosses the edge, which delays a cull and never pops, while dropping it late costs only map
space.

`cone_tick` is a plain local static, deliberately not `vis_frame_serial_` -- that is the
visibility draw-gate's clock.

`esp-cone-init:` now also reports `halfAngle=50deg graceFrames=30`.

Both consumers clean -- 0 errors, 0 warnings -- in `Prod|x64` and `Prod no aimbot|x64`.
`tools/tests` 179 passed.

### 0.30 The camera guard was guarding the managed wrapper, not the object -- and the unguarded path was next to it

Verified a handover from the parallel session. `camera_is_enabled` guarded
`!camera || !camera->klass` and then **immediately made a managed call** (`get_enabled`,
then `component_get_game_object` -> `get_activeInHierarchy`). Every managed call on a
`UnityEngine.Object` dereferences `m_CachedPtr` at `this+0x10` first, so on a destroyed object
the wrapper is alive, `klass` is valid, and **the call is what faults**. Unity's fake null.

**The helper already existed and was not used here.** `unity::is_unity_object_alive`
(`unity.h:1084`) resolves `m_CachedPtr` by name rather than hardcoding `+0x10`, rejects null,
and `VirtualQuery`s the native pointer under a TTL memo. It has 9 existing call sites; the
camera path was the last place still on the old guard.

**0.16's link is tighter than a defect-class resemblance:** its signature was verbatim "fault
offset `...E798`, read at `+0x10`" -- exactly `m_CachedPtr`, the same read 0.16 already fixed
once, through a door that fix never covered.

**Exposure was wider than reported.** `pick_esp_fps_camera` is the *unconditional* path --
every frame, both `prefer_optic` values -- and had no liveness check at all: managed calls on
every candidate during enumeration, plus a `get_current_camera()` fallback that bypasses the
predicate entirely. The report found the guarded-but-wrong site; the unguarded one was beside
it.

Fixed in three places with the existing helper: the `camera_is_enabled` guard, the
`pick_esp_fps_camera` predicate (so a dead camera is never touched during enumeration -- the
earlier fault site), and its final selection (the only cover for the fallback). One check per
frame on the winner; the predicate is affordable because the helper memoises, so the
`VirtualQuery` is once per TTL window, not per frame.

**Not proven: teardown reachability.** `draw_overlay` returns on `!game_state::is_in_raid`, so
the path dies when that flips, and the ordering against camera destruction is unestablished. A
candidate for the unexplained post-exfil crashes -- but the probe detaches at teardown, so no
capture could confirm it. Fixed is not the same as shown to be the cause.

Limit recorded: the helper reads `obj->klass`, so it guards a destroyed-but-alive wrapper, not
a freed wrapper.

Both consumers clean -- 0 errors, 0 warnings -- in `Prod|x64` and `Prod no aimbot|x64`.
`tools/tests` 179 passed.

### 0.31 The raid-boundary measurement: presumption confirmed, and one of my own claims withdrawn

Checked the `raid-boundary` lines, which exist for exactly this.

**Confirmed.** `pid=16740`: the poll cleared `is_in_raid` at **06:51:32**, and there is zero
ESP camera activity between then and the next raid. `esp-path` (06:56:27) and `vis-cone`
(06:57:30) resume, but they belong to **raid 2**, which started at 06:56:21.782 -- the flag
was legitimately re-armed. The gate held.

**Withdrawn:** my claim, made minutes earlier in the same investigation, that 580 post-boundary
`esp-path` lines contradicted the gate. They are raid 2. A timestamp filter does not separate
"after the flag dropped" from "after the next raid started".

**The log flood is already fixed by the parallel session** -- `common_hooks.cpp:286` logs only
when `set_in_raid` reports a move, and `game_state.h:67-73` documents this exact measurement as
the old build's defect. The new session has zero such lines, as predicted. No work done.

**The open question narrowed by static reachability, which beats a counter:** `resolve_esp_camera`
has exactly two call sites, both in `draw_overlay`, both after the `!is_in_raid` return at
`EspModule.cpp:4667`. `!is_in_raid` cannot reach the camera path.

**Still unanswerable from the log, because the boundary it can show is the wrong one.** 06:51:32
was a raid end into a live menu with raid 2 following, so no scene teardown occurred. The exfil
teardown boundaries are the ones the crash probe does not cover.

Remaining question is one fact: does `InRaid` go false **before** or **after** the camera is
destroyed. Not built yet -- a one-shot `alive=` probe at the `set_in_raid(false)` transition would
answer it, and is left pending because it is a diagnostic and the last two instruments in this
file both claimed more than they had earned.

### 0.32 The camera guard's per-candidate half is removed: it cost 10x the calls and broke its own memo

Measured on `next_next_next_day+1+crash.tracy` (build `0x6AC1E40D`), which contains the 0.30
guard. `unity::is_unity_object_alive` went from **36,547 calls to 140,875** -- and
`resolve_esp_camera_frame` ran 14,198 times, so **9.92 calls per resolution**: the per-candidate
predicate over ~9 cameras, plus two guards.

**It backfired.** That helper's memo TTL is counted in **CALLS**, so calling it 4x more often
expires the memo 4x faster. The log's `unity-memo` report fell **98% -> 55%** in the same
session -- verbatim the symptom its own text warns about. **The guard destroyed the caching it
was relying on.**

Removed the per-candidate guard (~9 of the 10 calls, and it protected the least -- that
enumeration ran unguarded for the whole project without faulting). Kept `camera_is_enabled`
(`eft_api.h:3222`, the reported defect) and the single selection check (`eft_api.h:3413`, the
only cover for the `get_current_camera()` fallback). **2 calls per resolution instead of ~10.**
The mid-enumeration residual is recorded in the source rather than hidden.

**The tracy timing is not quotable and the reason is structural:** `is_unity_object_alive` runs
on two threads, so that row aggregates two per-thread trees. `resolve_esp_camera_frame` (35.5 s)
exceeds `draw_overlay` (30.3 s), its only caller; `is_unity_object_alive` (64.9 s) exceeds
`Aimbot` (58.5 s) entirely. Capture-to-capture is confounded too -- a heavier raid. What
survives is the **call count** (arithmetic from the code) and the **log hit rate** (independent
of tracy). A per-thread split would need distinct zone names per calling thread; not built.

Also confirmed: the cone fix is live (`esp-cone-init: dirOk=true ... yaw=0.0deg` -- the exact
ambiguity that broke the original yaw read, now disambiguated by the separate `bool`).

The `+crash` capture ends with no closing exception histogram and no `raid-boundary` line --
flag never visibly cleared, so not the exfil boundary; `raid-boundary` at zero lines is exactly
what the parallel session's `moved` gate predicts.

Both consumers clean -- 0 errors, 0 warnings -- in `Prod|x64` and `Prod no aimbot|x64`.
`tools/tests` 179 passed.

### 0.33 A probe names whoever takes the crash probe's two report doors, and two of my own errors are corrected

**Correction 1 -- "no closing histogram" was my bug.** Crash-probe continuation lines do not
repeat the `[timestamp] pid=` prefix, so every `pid=` filter this session silently discarded the
whole block. A FATAL was in that log the whole time. Any earlier conclusion resting on "no
FATAL/AV" after a `pid=` filter needs re-deriving -- including 5.7r-a's boundary reading.

**Correction 2 -- the 0.32 denominator was wrong.** `aimbot::candidate_pick` and
`eft_api::resolve_esp_camera_frame` have identical counts (14,198/14,198; 961/961), so "per
resolution" was really "per aimbot candidate". Per **render frame** (`draw_overlay`,
render-thread only): 1.07 pre-guard -> **7.49** with the predicate -> **1.14** without. The
conclusion holds and the fix is confirmed, with the memo hit rate recovering to **95-98%** -- but
the published figure should have read 7.5, not 9.9.

**The crash that was there:** unhandled **C++ exception** `0xE06D7363` flags `0x81`,
NONCONTINUABLE, `ExceptionInformation[0]=0x19930520` (MSVC's C++ magic), via
`KERNELBASE!RaiseException` from `UnityPlayer.dll+0x2144E6`, thrown type UNRESOLVED, faulting
rva **outside this module** -- `TarkovAddons.dll` appears in no frame. After
`Local Raid Ended`. Frames are a stack-word scan, not a symbolised unwind, so single frames are
unreliable and the exception type is still unknown.

**The camera guard is exonerated by ordering**, not shown unnecessary: the raid ended via the
`LocalRaidEnded` event, so `set_in_raid(false)` gated `draw_overlay` off before the throw.

**The probe.** `module_owner_of()` resolves a handler address to module basename + RVA via
`GetModuleHandleExW(FROM_ADDRESS|UNCHANGED_REFCOUNT)` -- the same mechanism `install()` already
uses -- checking our own MANUAL-MAPPED base first so a displacement by us reads as ours.
`report_handler_owners()` reports `intact=` plus both owners; `intact=false` means a slot was
TAKEN and the named owner is the taker.

**Deliberately not inside `verify_handlers`:** that is reachable from the vectored handler and
`GetModuleHandleExW` takes the loader lock, and this crash happens at teardown, which is exactly
when that lock may be held. So `verify_handlers` still only records; resolution is deferred.

Called from `module/common_hooks.cpp:311` at the `set_in_raid(false)` transition, **outside**
`if (moved)` so it reports on every false read -- the question is what changed without our flag
moving. Covers both raid-end doors.

`UnityPlayer.dll` confirms the standing guess; `(not in the loader lists)` would mean a
manual-mapped injector. Either is a result; the guess is what this replaces.

Clean -- 0 errors, 0 warnings -- all three TUs in `Prod|x64` and `Prod no aimbot|x64`.
`tools/tests` 185 passed.

### 0.34 Handler attribution now resolves at the CRASH, not only at the raid boundary

**The gap:** the 2026-10-04 `REPAIRED` lines arrived in the same breath as the `FATAL` -- the slots
were taken **at teardown**, i.e. after the raid boundary. A process that dies there never reaches
another boundary, so the boundary-only probe would have printed `intact=yes` and **never named the
taker**. An address, and nothing more.

**Two paths, because they fail differently:**

- **At the boundary** (`common_hooks.cpp:311`) -- refreshes the table, reports `intact=` plus both
  owners. Covers a take-over before the flag drops, and gives the baseline.
- **At the crash** -- both `REPAIRED` emits now carry `taken by <module>+0x<rva>`. Same instant as
  the `FATAL`, which is the case that matters.

**Why a static table rather than `GetModuleHandleExW` on the crash path:** `verify_handlers` is
reachable from the vectored handler, `GetModuleHandleExW` takes the **loader lock**, and this
crash happens at **teardown** -- exactly when that lock may be held. So names are resolved once
from a safe context into up to 256 `{base,size,name}` records (`K32EnumProcessModules`, resolved
by `GetProcAddress` so no import library is needed; count published `release` after the records
are written) and the VEH-side lookup is a **linear scan**: no API call, no lock, no allocation.

Our own `g_base` is checked first so a displacement *by us* cannot be misattributed -- this module
is manual-mapped and may be absent from the loader lists. An unmatched address prints
`(not in the table; region base 0x... and may be stale)`: **unknown is reported as unknown.**

The staleness trade is deliberate -- a stale answer that cannot deadlock beats a fresh one that
can -- and the boundary call refreshes every menu frame. Also **deleted** the `GetModuleHandleExW`
resolver so there is one resolver, not two with different failure modes.

Two self-inflicted surgery errors, same mistake twice: deleting a function by "first line whose
`strip()` is `}`" matched an **inner** brace and left an orphaned tail (`C2059: syntax error: if`,
170 lines from the cause); and two `find()` calls for the same anchor both took the **first**
match, so the second overwrote the first and the UEF emit passed the terminate handler's
variables. Fix: match closers on exact indentation, and `assert len(matches) == 1`.

Clean -- 0 errors, 0 warnings -- four TUs in `Prod|x64` and `Prod no aimbot|x64`.
`tools/tests` 190 passed.

Reading the result: `UnityPlayer.dll+0x...` confirms the standing guess; `(not in the table)`
means a manual-mapped injector; `intact=yes` everywhere plus a named taker at crash time means the
take-over happens strictly between boundary and crash, which is itself the finding.

### 0.35 Fixed a link error the per-TU verification habit could not see

Good catch from the user -- it did not fail to compile, it failed to **link**:

```
common_hooks.obj : error LNK2005: crash_probe::g_warned_uef already defined
common_hooks.obj : error LNK2005: crash_probe::g_warned_terminate already defined
```

`util/crash_probe.h` declared both as plain namespace-scope `std::atomic<bool>`, which is fine with
exactly one includer -- and 0.34 made `module/common_hooks.cpp` a second one, to call
`report_handler_owners()` at the raid boundary. Two definitions. The symbols are **pre-existing**;
the second includer was mine.

Fixed by marking both `inline`. The linker named exactly those two, and `g_base`, `g_size`,
`g_prev_uef`, `g_prev_terminate`, `g_modules`, `g_module_count` were already `inline`, so that was
the complete set.

**The habit that hid it:** all session verification has been `ClCompile /p:SelectedFiles=<one .cpp>`,
which stops before the link and is structurally unable to see `LNK2005`. Eight clean per-TU reports
across four TUs while the project did not link. **Any change to a header's include set now gets a
full build with link before being called verified.** Per-TU stays the fast path for single-.cpp logic
changes.

It remains the good failure mode: an ODR violation is a loud link error naming both symbols, not a
silent per-TU divergence.

Full build **and link**: `Prod|x64` exit 0, `Prod no aimbot|x64` exit 0, **0 errors, 0 warnings**
either way. `tools/tests` 190 passed. Also the first whole-project clean build of the session,
including the parallel session's Quest files, which were mutually incompatible earlier today.

### 0.36 Fixed a crash I introduced: recursive fault in the vectored handler from calling the CRT

Build `0x6AC207E5` died seconds after launch. My defect, from the 0.34 attribution work.

WER: **`ucrtbase.dll` / `c0000005` / `+0x65655`, the same site twice in one report.** The log ended
at `Menu Key: Insert` with boot otherwise normal, and **the crash probe printed nothing at all** --
the silence was the tell.

Mechanism: EFT throws constantly during startup; the VEH fires and calls
`verify_handlers_throttled` (first call is immediate); a slot reads displaced; my
`module_owner_lockfree` ran **inside the VEH** and called `std::snprintf`; the CRT faulted, the VEH
fired again from inside itself, and a recursive fault in a VEH is terminal -- taking the probe's
own report path with it. The duplicated offset is the recursion, not two faults.

Fixed: `module_owner_lockfree` is now **CRT-free** (`put_bounded` / `put_hex_bounded`, hand-rolled
hex, no printf, no allocation). The RVA is returned to the caller for `emit()` to format.
`VirtualQuery` kept -- a syscall with no lock -- hand-hexed.

**Scope corrected:** not "no CRT in the file" -- `emit()` has always formatted there and
`refresh_module_table()` still uses `snprintf`, because `install()` runs on the init **thread**
(`dllmain.cpp` `init(LPVOID)`, not `DllMain` at :344) with no loader lock held. The rule is
narrower: **nothing that re-enters the CRT may run from the vectored handler.** I had blamed
`GetModuleHandleExW`'s loader lock last section; that was real but not what bit.

Also fixed `enum_modules_fn`'s `LPDWORD*` -> `LPDWORD`.

**Repair method.** The first fix deleted the wrong function: `find()` matched the forward
declaration I had added earlier, so it swallowed `verify_handlers()` itself plus `module_rec`,
`g_modules`, `g_module_count` and `refresh_module_table()`. Positional patching of this file had
already failed four times today (orphaned brace, first-match `find`, `strip()` inner-brace, forward
declaration), so I **restored from the last known-good copy and re-applied everything in ONE
asserted script**. It then applied first try; all remaining failures were in my assertions, not the
edits -- two-line signatures, an inserted declaration matching its own anchor, and a forward
declaration's `);` being on its second line.

**After N positional edits fail on one file, restore and re-apply -- do not attempt edit N+1.**

Full build **and link**: `Prod|x64` and `Prod no aimbot|x64` both exit 0, 0 errors, 0 warnings.
`tools/tests` 190 passed.

### 0.37 The reporter was crashing while it reported: varargs, an unsigned where a pointer belonged

Still crashing, and "the logo on the crash changed" was the clue that mattered -- the process was
dying somewhere new. `%LOCALAPPDATA%\CrashDumps`, via `tools/minidump_read.py`:

- `3560` 07:54 `0x6AC1D894` -> **`0xE06D7363` at `KERNELBASE+0x241CA`** (RaiseException)
- `24172` 11:05 `0x6AC207E5` -> `0xC0000005` at `ucrtbase+0x65655`, **read at `0xA5230`**
- `19516` 11:59 `0x6AC21084` -> `0xC0000005` at `ucrtbase+0x65655`, **read at `0xA5230`**

The first is the real fault and is unchanged: an unhandled C++ exception from GameAssembly. The
other two are **my reporter crashing**. `ucrtbase+0x65655` is `_itoa+0x1C5` per
`dumpbin /exports` -- the decimal integer formatter. `0xA5230` is not random: it is the **RVA of
the foreign handler**, identical in both dumps because it is the same handler.

`tools/symbolize.py` gives `crash_probe::handler +0x631` -> `emit +0xFE` -> `emit_ring +0x3AF` ->
`image_name +0x124`. So the `0xE06D7363` arrives, the VEH reports it, and the report faults.

`emit()` is printf-style varargs. The format reads `(%s) ... taken by %s+0x%x (0x%p, not our
0x%p)` and I passed `(owner, rva, context, prev, ours)`, so the **second `%s` got `uef_rva`, an
unsigned**, and the CRT read a string from it -- `0xA5230` is that integer as an address. Both
arms were wrong the same way. It faulted inside the VEH, the handler re-entered, and a recursive
fault in a VEH is terminal.

**That is why these crashes have been invisible** -- so 0.36's "the handler detaches at teardown"
was wrong. It is a reporter that dies mid-report, and the changed logo follows: once the probe
kills the process, another component's crash UI gets there first.

**Correction:** 0.36 blamed `snprintf` in `module_owner_lockfree`. That stays as correct
practice but **was not the cause** -- `REPAIRED` appears zero times in both crashing runs, so it
never ran. Right file, wrong function. Its claim that `emit()` runs safely there was false;
`emit()` was the crash.

**Lesson, the fourth of its kind this session: a printf-style call is verified by nothing I
own.** Not the compiler, not a full build+link, not 190 tests -- only symbolising a stack I had
previously written off as unreliable. The fix now verifies format/argument agreement
mechanically by parsing the format and asserting the order.

`image_name` still calls `GetModuleFileNameA`, a PEB walk the boot comment calls unreliable for
a manual-mapped image, from a post-fault reporting path. Not this bug; next to harden.

The post-exfil `0xE06D7363` is still the real bug and still unexplained -- but the probe can now
survive reporting it.

Full build AND link, both configs, exit 0, 0 errors, 0 warnings. `tools/tests` 190 passed.

### 0.38 They found the cause of a number I had written off, and my premises about their code

CHANGELOG 0.22 (parallel session) reports `unity::is_unity_object_alive` at **64.87 s / 460 us
mean / 98% hit rate** -- the three numbers I measured from `next_next_next_day+1+crash.tracy`.

**I declined to quote them**, on the reasoning that the zone runs on two threads so the row
merges two per-thread trees, evidenced by a child exceeding its parent
(`resolve_esp_camera_frame` 35.5 s > `draw_overlay` 30.3 s). **That reasoning was wrong.** The
number is real and they found the cause: `maybe_report_native_object_memo()` early-returns, but
**`std::format`'s arguments are evaluated at the call site**, so formatting ran on all 140,875
calls rather than the ~9 that print. A real defect in `il2cpp/unity.h`, in code that predates my
work -- what I did was multiply the call count that reaches it. My 0.32 message and 5.7s both
say those timings are "not quotable"; read that as "the number is right and I did not know why".
They resolved it with `-e` self time (0.19 s / 13.5 us over 14,198 calls), the technique the
README names and I did not reach for.

**Premises about their code**, recorded so they can be checked rather than trusted. Each marked
VERIFIED / MEASURED / ASSUMED -- full text in AGENTS_TODO.md 5.7u-b.

- **`set_in_raid` returns bool = "the flag moved"** (VERIFIED). My one uncommitted line sits
  deliberately OUTSIDE `if (moved)`, so it does not depend on that semantic.
- **the raid-boundary `is_in_raid` is the resolved `InGameStatus` class, not the bool**
  (VERIFIED, `common_hooks.cpp:63`).
- **`tracy::CrashFilter` takes our UEF slot, and it is TEMPORARY** (VERIFIED):
  `TracyProfiler.cpp:1633`, called from `:2043`; `TRACY_NO_CRASH_HANDLER` and
  `TRACY_WIN32_NO_DESKTOP` are defined nowhere, so the install is live; `TRACY_ENABLE` is in all
  four x64 configs (`vcxproj:134,164,203,296`) and `tracy_bridge.h:5` calls that "temporarily".
  `RemoveCrashHandler` at `:1642` restores *our* filter if we already re-asserted. **So the
  REPAIRED churn is our own profiler in a temporary build state, not an injector, and no
  defence is needed.**
- **`AimbotModule::gameworld_update`: 175,130 ms, mean 63.6 ms, 60.1% of the whole tick, with
  ~174,600 ms unattributed** (MEASURED, `+3+stuck`). Its file; I have not read the function.
- **`find_camera_if_best` allocates per call via `Camera.all`** (VERIFIED,
  `il2cpp/unity.h:907`, fallback `:915`), confirming their 0.21 claim. My "~9 cameras" was
  inferred from arithmetic and is retired.
- **skeleton_visibility.h's ballistics model is theirs**, committed wholesale in 33dfd2c4
  because EspModule.cpp calls into that file.
- **18 of 19 changed lang/*.json are their sync** (ASSUMED, from en.json holding only quest
  keys).

**Ledger defect, flagged not fixed: CHANGELOG 0.21 and 0.22 each appear twice** -- theirs at
lines 2123/2198, mine at 2506/2571. Both agents started from 0.21. My series is 0.21-0.37 and
contiguous; renumbering mine to 0.38+ is the cheaper fix and I will do it on request rather than
unilaterally, being 17 headings in a file both of us edit.

### 0.39 LOST - another workstream's uncommitted section, destroyed 2026-10-04

**This section is a placeholder, not content.** §0.39 ("Eleven zones added to
`gameworld_update`, because 99.92% of it had none -- still undiagnosed") was written by a
different workstream and was **uncommitted**, and it was destroyed by a bad shell pipeline on
2026-10-04 while this entry was being appended. `git checkout -- CHANGELOG.md` restored
everything that was committed; the uncommitted §0.39 was not in git and is not recoverable from
any editor history or cache on this machine.

**It has not been reconstructed, deliberately.** A plausible-looking reconstruction would be
worse than an obvious gap: it would differ from what was actually written in ways nobody could
detect, and it would be attributed to a workstream that did not write it.

Its substance survives elsewhere -- `tools/premises_about_other_workstreams.md:229` ("Fixed as of
2026-10-04. Eleven zones added to...") and `AGENTS_TODO.md`. Whoever wrote §0.39 should restore
it from their own session history. **§0.40 below is unaffected and is mine.**

### 0.40 `Unity init failed` was a race inside IL2CPP, and the log line named nothing

The appended log failed 45 ms into boot and stopped the mod:

    14:17:29.030 Loading Unity
    14:17:29.041 ERROR Unity init failed: required UnityEngine classes missing

The aimbot memo had seen the same line six minutes before a *good* launch and written it off as
unrelated (`tools/handoff_exfil_overlay_and_probe_memo.md:100`). It is not unrelated, and the
reason it read as unrelated is the subject of this entry: the line named no class and no cause,
so there was nothing to attach it to.

**The absence in the log is the diagnosis.** There is no `resolve_image FAILED` line, so
`UnityEngine.CoreModule.dll` *was* found. One image's `il2cpp_class_from_name` lookup failed five
times, not five lookups failing.

**Not our pattern.** Offline against the shipped `GameAssembly.dll`: the manifest identity
matches exactly, its `.text_sha256` matches the actual `.text` raw bytes for both GameAssembly
and UnityPlayer, and every pattern symbol has **exactly one** match in the whole mapped image.
The pattern-vs-export split is also deliberate -- for three symbols the pattern hit *is* the
export's thunk target.

**What it actually is.** `il2cpp_class_from_name` keeps a per-image class hash map at
`image + 0x30`, publishes it **before filling it**, and re-reads that pointer on every fill
iteration. A reader arriving in that window gets `xor eax, eax` -- null for **every** name, not
just absent ones. There is no lock in that function. `unity::init()` runs on the thread `DllMain`
creates, not Unity's main thread, and the boot gate returned on its first poll
(`0 ms, 0 poll(s)`), so it runs inside Unity's own startup -- when the game is doing the same
first lookups.

**Changed.** The five required classes now resolve from one table inside a bounded retry:
3 attempts, 150 ms apart -- the same treatment and numbers `resolve_pattern_with_retry()` already
gets in `il2cpp_offsets.h`. This is §5.9's defect class in the one place §5.9 did not reach.

The failure path now names the class instead of describing a group:

    ERROR Unity init: required class UnityEngine.Camera did not resolve (still null after 3 attempt(s), 150 ms apart)
    ERROR Unity init: 0 of 5 required UnityEngine classes resolved

and the recovered case says so explicitly -- `null on the first attempt and resolved on attempt N
of 3 -- this is a race on il2cpp_class_from_name's per-image cache` -- which is the confirmation
the old line could not give.

**Bounded on purpose.** If this thread is the one that published an empty map, no retry can
populate it: the guard is `if ([image+0x30] != 0) use as-is`. That case reports "still null after
3 attempts" rather than masquerading as a missing class.

**Two bugs I introduced in the fix, both caught by the test I wrote for it.** I first put the
"resolved on attempt N" WARN inside the failure branch, where `attempts_used > 0` means the
*opposite* -- the retries ran and still returned null, the unrecoverable case. And I first passed
`attempts_used + 1` to the failure report, printing "4 of 3". `tools/tests/
test_unity_class_resolve_retry.py` (7 tests, 4 negative controls, each verified to fail on its
intended assertion) pins both, plus that the lookups happen *inside* the loop -- a retry that
does not re-run the failing lookups is not a retry.

Full evidence, including what could not be established and one risk flagged rather than
concluded: `AGENTS_TODO.md` §5.7w.
### 0.43 The overlay throw is `Camera.all` during the window where the raid is over but `is_in_raid` is not

Session 21872, build `0x6AC243A2`: 14 throws at ~50 ms, all after `Local Raid Ended`. The
call-site is **`ESP::draw_overlay`** -- the parallel session's existing `set_draw_stage_overlay`
instrumentation. `minimap::process_pending_map_load` was `0/0`, so **it was never the minimap.**

**The finding: `is_in_raid` can be true after the raid is over.** The flag drops on the
`LocalRaidEnded` event or the `InRaid` poll, and there is a window before that lands. So
`draw_overlay`'s gate does not fire and we call `find_camera_if_best` ->
`camera_get_all_internal()` -- Unity's `Camera.all` -- while the camera subsystem tears down.

**ISIL, as asked.** `TarkovApplication.txt:5865` proves `InGameStatus.InRaid` is the game's
*own* gate (`typeof(EFT.InGameStatus)`, null-check, read `v33.InRaid`) -- so it is not a proxy we
invented, just too coarse for teardown. `EFT.HealthSystem.IHealthController.get_IsAlive()`
exists and **we already resolve it** (`eft_api.h:664`, `:968`) -- no new interop.
**`GameStarted` is a FALSE LEAD**: a `System.Single` metrics duration on `ClientMetricsEvents`,
not a state flag. Reporting it as a predicate would have been the fourth wrong conclusion here.

**Two changes, both in `draw_overlay`.** `scene_objects_live` (player resolves AND
`try_get_health_controller` non-null) **fails OPEN**, and is deliberately **not** `IsAlive`
alone -- a dead player is still in a raid with a working camera, so that would drop the ESP for
corpses and spectators. And both `resolve_esp_camera` calls now sit in **`catch (...)`**, which
is the part that limits the damage: `menu::draw` already caught it, so the throw was never
fatal, but the poison pill stops calling `menu::draw` after 120 consecutive throws -- so one
subsystem's exception was costing the **entire** overlay. Local catch means no cameras this
frame, everything else drawn, and the pill's counter resets.

**Reverted:** my per-widget stage label. It produced **zero hits**, named nothing (the throw is
in no `ConfigValue::draw()`), and cost a `std::string` per widget per draw on a 313 us path.
The decisive step was reading the label that already existed.

**Process:** applied as three chained patch scripts and failed three times on chain ordering,
not on any single edit. Consolidated into one script from a pristine backup that verifies
use-before-declare; first try. Do not compose patch scripts.

Prod|x64 full build + link: exit 0, 0 errors, 0 warnings. `tools/tests` 210 passed.

**Prod-only from now on, per instruction.** Caveat: `Prod no aimbot` had a real break from the
parallel session's uncommitted fireport work in `skeleton_visibility.h`, so it is currently
**unverified rather than known-good** -- the same blind spot as per-TU builds hiding `LNK2005`.

**Renumbered at commit time, and the cause is worth recording.** This section went in as
`0.38` and collided with `0.38 They found the cause of a number I had written off` -- which
is **my own** commit `72647f4f`, not the parallel session's. My duplicate-number guard keyed
on the *whole title*, so a title that really was different sailed straight through it. The
collision is on the short key, which is the only thing a reader navigates by.

Left standing deliberately: **`0.21` and `0.22` are still each duplicated** between the two
workstreams. Those predate this and I am not renumbering another session's prose.

### 0.45 Two runs: the catch contained the throw, the gate did not prevent it, and the freeze is not ours

Runs of 2026-10-04 16:18 (`pid 30432`, stuck) and 16:34 (`pid 26280`, exfil success), both on
the build carrying the `draw_overlay` catch. Measured, not inferred.

**1. THE CATCH WORKS. `menu::draw` throws by session:**

| session | `threw at stage 'menu::draw'` |
|---|---|
| 21872 (pre) | 14 |
| 23892 (pre) | 8 |
| 25432 (pre) | 16 |
| **30432 (post)** | **0** |
| **26280 (post)** | **0** |

The exception no longer escapes to the overlay boundary, so the poison pill never counts
consecutive failures. This is the change's whole value and it is confirmed twice.

**2. THE GATE DOES NOT DETECT THE WINDOW -- a negative result about my own predicate.** The
throw line carries the state at the moment of the throw:

```
esp: camera resolution threw (managed) -- ... scene_objects_live=true is_in_raid=true
```

Both the player **and** its health controller still resolve, and `is_in_raid` is still true,
and `Camera.all` throws anyway. So `try_get_health_controller(main_player_)` cannot see this
teardown -- **the same class of error as 5.7r, one level out**: there the camera guard tested
a managed *wrapper* rather than the object behind it, and here the scene gate tests a managed
player rather than whether calling into Unity is safe. `scene_objects_live` fails open, which
is the correct default, and the catch is what actually does the work. **The gate is not
harmful but it is not earning its place.**

The throw still happens, **641 ms after `Local Raid Ended`** (16:29:48.101 -> 16:29:48.742),
now caught locally.

**3. NO COST FROM THE CHANGE.** `eft_api::resolve_esp_camera_frame`: mean **10.5 us** on the
stuck run vs **11.7 us** on the exfil run (**-10%**), max **0.3 ms**. The gate and the
`catch` are free. (Cross-capture means are weak evidence -- the captures differ 6x in length
-- but a 10x regression could not hide under that.)

**4. THE FREEZE IS A 7.5 s GAME-THREAD BLOCK, AND IT IS NOT OURS.**

| zone | stuck | exfil (control) |
|---|---|---|
| `always_on::hk_on_game_end` | **7479 ms, 1 call** | 29.6 ms, 2 calls |
| `always_on::hk_comeback_to_main_menu` | **7460 ms, 4 calls** | 2655 ms, 3 calls |
| `always_on::hk_prepare_game_job` | 1214 ms, 7 calls | 1197 ms, 6 calls |

`hk_on_game_end` blocked the game thread for **7.48 s in a single call**. That is the "stuck",
and it is an order of magnitude above anything of ours. Three things make this a game-side
reading rather than an accusation:

- **No child zone accounts for it.** Nothing in the capture nests inside those 7.46 s, so the
  time is unattributed -- the game's own `OnGameEnd` / `ComebackToMainMenu` / `PrepareGameJob`
  work, or something it waits on. Our hook bodies there are four to six `[transitdbg]` lines.
- **The *successful* run freezes too**: `hk_comeback_to_main_menu` takes 2.66 s in the exfil
  run that worked. The zone is inherently multi-second and merely variable.
- `hk_prepare_game_job` is ~1.2 s in **both**, so it is normal game-save work and not the
  differentiator.

Our worst during the same window is an order of magnitude smaller: `EspModule::gameworld_update`
max **853 ms**, `draw_overlay` max **240 ms**. The 1434 ms `hk_game_world_update` frame is that
same 853 ms call nested inside one anomalous frame.

**5. A SECOND MANAGED-THROW SITE, already contained.**
`quest objectives: a condition of SideQuest threw a non-std exception while being read` --
7 per session, `quest_objectives.h:728` and `:735`, logged at WARN from inside an existing
`catch`. Benign, but it is a second place a managed call is made on a dying object.

**6. MY OWN REPORTER WAS THE MEASUREMENT DEFECT.** Both diagnostics capped at `n < 5`, so each
run logged exactly five lines and **the log cannot distinguish 5 throws from 500**. Capping the
flood is right; capping the *rate* suppresses the only number worth having -- the same mistake
as the `probe-memo` line that cried wolf. Now: first 3, then every 256th, always printing the
**running total**, for both the throw counter and the scene-gone counter.

Prod|x64 full build + link: exit 0, 0 errors, 0 warnings. `tools/tests` 210 passed.

### 0.46 The gate is cut down to the free half, and the 7.5 s finally gets a zone

Follows 0.45, which measured the fix and refuted half of it.

**1. `scene_objects_live` loses the health-controller half.** It is now
`main_player_ != nullptr && main_player_->klass != nullptr`. Two reasons, and the second is
the one that mattered:

- It is the expensive half. The pointer test is arithmetic; `try_get_health_controller` is two
  **managed** calls on the render thread, once per `draw_overlay`. The parallel session added a
  per-object memo to that function *because* of this gate -- a fix for a cost the gate should
  not have created. Their memo is left in place; `try_get_player_health` uses it too.
- **It sat OUTSIDE the `try`.** The local `catch (...)` exists so a managed throw cannot reach
  `menu::draw`, and the gate was putting a managed call back into the one path with no
  protection -- on a dying player, which is exactly when it can throw. It did not throw in
  either run. That is luck, not design.

The free half is kept because it earned its place: it fired on both runs during transits, and
skipping the resolve then is correct and costs nothing.

**2. The 7.5 s gets attributed.** `::orig` zones added to `hk_on_game_end`,
`hk_comeback_to_main_menu` and `hk_prepare_game_job`, so the next capture answers the only
question that matters: is the 7479 ms the **game's** `MoveNext`, or **our** per-iteration
`resolve_field` plus `[transitdbg]` logging? Those are unrelated bugs and they belong to
different people.

Our side has a real mechanism, which is why this is worth one zone rather than a shrug:
these hooks fire per **iteration** and "spin" during a transit, and `il2utils::resolve_field`
takes `metadata_cache_mutex` -- **one shared non-recursive mutex** also used by
`resolve_method`, `resolve_image` and `resolve_class`, which the render thread hammers
(~514,000 `resolve_image` + `resolve_class` calls per the note at `il2utils.h`). A lock convoy
there is a plausible multi-second stall, and it would be ours.

Additive only: three single-line scopes, no control flow, no signatures, no existing statement
touched -- another session is working in `always_on.h`. Splitting the pre-work into its own
zone needs `result_raw` / `profile_id` hoisted above the scope, which is a real restructure and
should wait until `orig` says which side to look at.

**3. `EspModule.cpp` line endings normalised to CRLF** (110 bare-LF lines left by my own
earlier scripted writes). `core.autocrlf=true` meant the committed blob was already correct, but
the mixed local file is what made the `edit` tool refuse to match the region **three times**
before I switched to index-anchored python.

**Process notes.** Another process on this machine is writing to `$env:TEMP` and injected
unrelated output into two of my script runs; scratch has moved to `Temp\opencode\esp`. And
twice today a verification assertion failed while the edit itself was fine -- once on a brace
walk with too small a window, once on an assertion string I had mis-specified. Both times I
was about to "fix" correct code because my check was wrong.

### 0.48 The ::orig zones answer it: 99.8% of the freeze is the game's own MoveNext

Run `pid 27460` (18:27-18:38), capture `next_next_next_day+8+transit+crash`.

**1. THE BLOCK IS NOT OURS. That is now measured, not argued.**

| zone | hook max | `::orig` max | ours | share |
|---|---|---|---|---|
| `hk_on_game_end` | 4122.1 ms | 4115.1 ms | **7.0 ms** | **0.17%** |
| `hk_comeback_to_main_menu` | 4113.2 ms | 4104.8 ms | **8.4 ms** | **0.20%** |
| `hk_prepare_game_job` | 3323.8 ms | 3321.5 ms | **2.4 ms** | **0.07%** |

The three-line zones added in 0.46 did their job on the first run that had them. **The
`resolve_field` mutex hypothesis is REFUTED**: our per-iteration field resolution plus
`[transitdbg]` logging is 0.1-0.2% of a four-second stall, so there is no lock convoy to fix
and no reason to restructure `always_on.h` after all. The stall is `o_*_move_next` -- the game's
own coroutine step.

Also variable, as predicted: 4122 ms here against 7479 ms on the previous run, same code path.

**2. THE THROW RATE IS 6,913, NOT 5.** This is what fixing the reporter bought:

```
18:34:19.969  throw #1 so far
18:38:33.301  throw #6913 so far      -- scene_objects_live=true is_in_raid=true
```

**27.3 throws/second, unbroken, for 253 seconds**, starting **99 s after `Local Raid Ended`
(18:32:40)**. Every sampled line reads `is_in_raid=true`, so `is_in_raid` never dropped for the
whole storm -- and the `hk_local_raid_ended` hook's `on_local_raid_ended_event()` runs *before*
its own log line, so the event definitely fired. Something set the flag back to true, which
means the ratchet's revoke is being undone by a later `true` observation. **Not fixed here**:
`is_in_raid` is read by 18 files and its re-arm condition is a design question for whoever owns
`common_hooks.cpp`.

**3. THEY ARE CHEAP, WHICH DECIDES THE FIX.** `eft_api::resolve_esp_camera_frame`: 2,107 calls,
mean 10.7 us, max 298 us, **total 22.6 ms**. So ~6,900 caught managed exceptions cost tens of
milliseconds. Nothing is on fire, and this is *not* the freeze.

**4. SO: a circuit breaker, not an optimisation.** 6,913 pointless trips into a Unity subsystem
that has already gone, every frame, on the render thread -- and a reporter that capped at 5
lines made it look like 5. A camera that has thrown 8 times running will not recover inside the
same raid, so `draw_overlay` now stops asking:

- trips at **8 consecutive** throws (~0.3 s at the measured rate), logs once when it trips,
- **keyed on the player pointer**, so a new raid re-arms it -- a process-lifetime latch would
  disarm the overlay for every raid after the first bad one,
- **re-arms on any successful resolve**, so a camera that recovers is used again.

Scope: `EspModule.cpp` only. Deliberately does not touch `is_in_raid` or the poll ratchet.

**5. No crash, despite the capture's name.** No minidump since 18:00, no `menu::draw` throws
(still 0 for this build), and the log ends normally with a fresh `hk_local_game_create`. The
file is named `+transit+crash` but nothing crashed in it.

Prod|x64 build of my file: verified per-TU clean. **Full-project link is blocked by the other
session's in-flight `QuestModule` refactor** (`QuestModule.h` removed `all_quests` /
`detail_id` / `detail_ready` from `quest_objectives_snapshot` at 18:52:47; `QuestModule.cpp`
still references them and was being written at 19:00:12). `EspModule.cpp` references nothing
from it.

### 0.50 I committed a line that was not mine, and no, it is not an infinite loop

**The direct answer first: no loop.** My circuit breaker is `EspModule.cpp:4778-4864`, 37 code
lines, containing no `while`, `for`, `do` or `goto`. A naive grep reports two `for` matches and
both are the English word inside comments ("for 253 seconds", "for the rest of this raid"). The
whole block is straight-line: two statics, an `if` to re-arm on a new player, one comparison,
and the `try`/`catch` it always was.

**But the question surfaced a real fault of mine, and it is worse than a loop would be.**

Committing the breaker, I ran `git add TarkovAddons/module/impl/EspModule.cpp` -- the WHOLE file
-- while the other session had an uncommitted line in it:

```cpp
FIREPORT_SITE("esp/view_cone_origin");   // EspModule.cpp:5764, EspModule::gameworld_update
```

It was not in `c7d0a02f`, the commit before mine (verified by reading that blob), so **my
`c0962a80` absorbed it.** The numstat gave it away and I did not read it closely enough: **49
lines added where my breaker is 21.** The other 28 were theirs.

**Why it mattered even though it cannot hang the game.** `FIREPORT_SITE` expands to a
`fireport_site_guard` whose constructor writes the **shared global**
`skeleton_vis::g_fireport_site` (`skeleton_visibility.h:193`) and whose destructor restores it --
plain, non-atomic, read by `TA_ZONE_SITE(..., g_fireport_site)` at `:355`. They added it to label
*their* four `try_get_fireport_position` call sites. Mine is a fifth, in a different subsystem,
so their per-site attribution would report `esp/view_cone_origin` for time that is not the
fireport path -- and nobody reading that report would know a second session's label got in there.

Reverted, one line, and it is theirs to re-add if they want it.

**On the game not loading, honestly: I cannot claim this fixed it.** WER shows
`AppHangTransient` at 20:11:50 and 20:21:41, and an `APPCRASH` cluster at 20:00:43-44 which
**predates my commit at 19:09** -- so at least one failure mode is not mine. The macro is a
scoped guard, not a loop. What I can say is measured: no session since the breaker build has
logged a single `camera resolution threw` line, so the breaker path is not being exercised at
all, let alone spinning.

Prod|x64 full build + link: exit 0, 0 errors, 0 warnings. `tools/tests` 213 passed, 2 skipped.

### 0.51 The grenade throw vector, located in the ISIL dump -- and probed by reading fields, not by hooking

The ask was to throw grenades at enemies instead of at the eye line: the same shape as
`hk_initiate_shot`, which re-derives `shot_direction` from the fireport. The throw side
had never been looked at. `TarkovAddons/ISIL-references/IsilDump` (26,457 files) has it.

**The chain, all from the dump rather than inferred:**

```
Player+GrenadeHandsController.HighThrow() / .LowThrow()
  -> BaseGrenadeHandsController.Throw(timeSinceSafetyLevelRemoved, low)
       branches on Player.get_IsAI (ISIL 208). Player branch reads
       Skills.StrengthBuffThrowDistanceInc and ThrowingEliteBuff, plus
       EFTHardSettings; AI branch reads BotGrenadeController.get_ToThrowDirection
       and logs "Bot throw (grenadeForce:{}, mass:{}, AIGreanageThrowData.Forc:{}...)"
     -> ThrowGrenadeInner(throwPosition, timeSinceSafetyLevelRemoved, lowHighThrow,
                          direction, forcePower, lowThrow, withVelocity)
          launch vector = Quaternion.op_Multiply(<grenadeTransform.rotation>, direction),
          then CheckHandsToBodyObstacles for the body-clip correction
       -> ThrowGrenade(timeSinceSafetyLevelRemoved, position, rotation, force, lowThrow)
            calls Player.ThrowGrenade(...) for the authoritative GrenadeThrowResult,
            AND CreateAndRegisterGrenade(position, rotation, force)
              -> GrenadeFactory.Create(settings, position, rotation, force)
```

So `force` as it reaches `ThrowGrenade` *is* the launch vector. That is the thing to
rewrite, and it sits below the body-obstacle correction, so a substituted vector cannot
clip the grenade into the thrower's own body.

The game already splits player from AI on `Player.get_IsAI`, so "player throws only" is
a field read rather than a caller-stack guess. `StrengthBuffThrowDistanceInc` being a
*distance* stat also confirms force is a distance input, not decoration.

**This build probes; it does not modify anything.** `module/grenade_throw_probe.h` is
new, called once per frame from `gameworld_update`, and reads the launch values off
the hands controller. Two findings forced that shape:

1. **I would have had to guess an ABI, and a wrong guess is not a safe failure.** The
   MSVC layout this codebase already uses for `initiate_shot_sig` (three `unity::vector3`
   by value) would put position in xmm1/xmm2, rotation in xmm3/xmm4, force in xmm5/xmm6
   and `lowThrow` in rdx. The dump's own disassembly instead reads position from **r8**,
   force from **r9**, rotation from **[rsp+0A0h]** and `lowThrow` from **[rsp+0A8h]** --
   as stack pointers. Both cannot be true. Even a read-only hook re-emits its arguments
   to the trampoline, so a wrong declaration corrupts the outgoing call instead of
   merely logging nonsense, and we already have one unattributed ACCESS_VIOLATION.

2. **The controller caches the same values in plain fields**, which the game's own
   `ClientGrenadeHandsController.ThrowGrenade` writes immediately before calling the
   base. Reading those needs no ABI and cannot corrupt anything: `+0x10C` throw-issued,
   `+0x110` force, `+0x120` position, `+0x12C` rotation, `+0x138` lowThrow.

`+0x12C` holds three floats, not a full Quaternion -- a Quaternion would put `w` at
`+0x138`, and the game overwrites `+0x138` with the bool. The two layouts are mutually
exclusive, so the probe reports which one it actually sees.

**Two bugs I introduced in the probe and fixed before building**, both the same mistake:
`+0x10C` and `+0x138` are written as `mov byte` / `mov [r14+138h],bl`, one byte each.
Reading four bytes picks up neighbouring padding, and a `1` followed by three zero bytes
is 1.4e-45, not `1.0f` -- so a `low == 1.f` test would have matched neither arm and both
tallies would read 0 while looking like they had run. Now read as `uint8_t`, with a third
`badlow` counter so a layout surprise is reported rather than dropped.

The probe is self-validating rather than trusting its own offsets: position in metres,
force as a launch speed, rotation roughly unit, `lowThrow` a clean bool. Every sample is
classified plausible or not, and the report prints the tally, so wrong offsets surface as
"0 of N plausible" instead of as plausible-looking numbers that get built on. It also
refuses to read at all unless the hands controller is exactly
`ClientGrenadeHandsController` -- the offsets are only valid for the class they were read
from, and a different grenade controller class is counted and reported by name instead.

**Phase 2, if the numbers are sane:** a naked shim reading the argument offsets out of
`ThrowGrenade`'s *own prologue* (verbatim in the dump) -- still no guessing -- and
writing `force` toward the aimbot's target the way `hk_initiate_shot` writes
`shot_direction`.

Prod|x64 build + link: exit 0, `out/prod/with_aimbot/TarkovAddons.dll` 8405.00 KB at
23:07:15. Probe strings confirmed present in the shipped binary (`grenade-probe: READ-ONLY
build`, `get_HandsController`, `get_IsAI`, `ClientGrenadeHandsController`,
`grenade::throw_probe`).

**Not measured.** No capture yet. Whether `force` tracks the eye line -- which is the
premise of the whole request -- is asserted by nothing so far.

### 0.52 A test made the inference its own source warns against, and failed on it

`test_pen_layer_budget.py::test_no_walk_in_the_log_ever_cleared` went red on the
21:11Factory log. It was a test bug, and the interesting part is *which* bug.

The test asserted that no `pen-check:` record contains the phrase
`clear line after N layer(s)`, on the reasoning that such a record is a walk that
cleared, and that a walk clearing at exactly the layer cap is the case `kMaxLayers`
4 -> 3 would flip from PASS to BLOCKED. Five records matched. **Two of them said
`DECISION: BLOCKED`.**

The phrase is a *note*, not a verdict. `finish()` is called as
`finish(stop_layer < 0, <note>)` from every exit, so a walk whose ray eventually
reached the target can still be BLOCKED because an earlier layer already recorded a
stop -- and it still carries "clear line after 2 layer(s)" as its explanation.

The source says so, in a comment directly above `finish()`, describing the bug it
already fixed once: *"every caller's note was hand-written on the assumption that its
own branch decided the outcome"* -- 189 records once printed PENETRABLE through solid
rock. So the test was re-making, in a test written specifically to guard the layer cap,
the exact inference that comment exists to prevent. My own habit of reading a log's
prose as its verdict, which is what made the self/aggregate time-axis mistake earlier.

Two corrections, both in `tools/tests/test_pen_layer_budget.py`:

1. **Key on the verdict, not the note.** New `penetrable()` helper, used by
   `test_no_walk_in_the_log_ever_cleared` *and* by
   `test_no_walk_in_the_log_needed_a_fourth_layer`, which had the same defect -- it
   counted `hit target after N layer(s)` in any record, so a BLOCKED walk that reached
   the target after 4 layers would have failed it spuriously. Distributions across the
   195 pen records: `hit target after` all-records {0:23, 1:25, 2:37} but
   PENETRABLE-only {0:23, 1:1, 2:2}; `clear line after` all-records {0:3, 1:1, 2:1} but
   PENETRABLE-only {0:3}.
2. **Assert on the flip case, not on zero.** The old assertion was "zero at any layer
   count", which would now be asserting that direct shots never succeed: 23 of the 33
   PENETRABLE walks hit the target at layer **0**, where the cap is irrelevant because
   there is nothing to walk through. The assertion is now on `N == kMaxLayers`
   specifically, with the full distribution in the failure message so movement toward
   the cap is visible before it trips.

Plus a source-level guard,
`test_decision_is_derived_from_the_return_value_not_the_note`, so the property both
tests now rely on cannot be rewritten away silently. Its first version asserted on the
receiving variable's name and named a variable that does not exist (`text`); fixed to
anchor on the `DECISION:` literal and the `penetrable` ternary instead, which are the
parts that carry the meaning.

Not a code change: no verdict, tally or cap moved. `skeleton_visibility.h` is untouched
by this section. `tools/tests` 216 passed.

### 0.53 The wall check reported 76 clear lines it never verified, and the pen walk's exit order is why

From the `+13_good` capture and the 23:14 Factory log. Two independent defects, both
required fixing, and the second only became visible once the first was measured.

**WHAT THE LOG SAID.** 82 `pen-check:` records reached the walk's degenerate-origin
exit -- "hit within 0.05 m or degenerate normal" -- and **76 of them returned
PENETRABLE**. A pass the walk never verified, on a live aim path.

**A. THE MEANINGLESS QUESTION.** `AimbotModule.cpp` gated the walk on
`vis_origin_ok`, which stays TRUE with a grenade in hand: the camera resolves fine
once the fireport is suppressed. So the walk ran with no round chambered, reading
`penPower=44` off the last firearm. The `pen-origin` tally proves the shape of it:

    23:14:34   camera=3151 fireport=227    <- grenade out, fireport correctly suppressed
    23:15:34   camera=128  fireport=3657   <- rifle back

Traced from the camera the ray is short and starts inside the shooter's own mesh or
the wall they are stood against, so it hit the degenerate exit almost every time:
**70 of the 82, all 70 PENETRABLE, all in one minute.** Penetration grading answers
"can a round reach it"; with a grenade there is no round. Gate is now
`&& !hands_not_firearm`, matching the two fireport gates above it.

**B. THE UNANSWERABLE ONE REPORTED AS A PASS.** The other 12 had a firearm out. The
`L0` prefix shows these walks had already graded a layer and passed it:

    | L0 go='Corner_table_01_BALLISTIC_woodthick' dist=2.82 -> pass (clear)
      | DECISION: PENETRABLE - origin effectively inside a mesh
    | L0 go='Base HumanHead' dist=6.88 owner='Eyes' -> pass (clear)
      | DECISION: PENETRABLE - origin effectively inside a mesh

So this is not the walk's starting origin. `step_past()` advances the ray by
`hit.m_distance + kLayerEps`, and the check runs on the advanced origin -- one epsilon
past the surface just crossed. In the second example L0 was the TARGET's own head.

**The exit order is the defect, and it is deliberate.** The loop tests:

    1. raycast          2. distance < 0.05 -> DEGENERATE EXIT
    3. classify_hit_transform -> hit_owner::shooter -> skip, no budget spent
    4. exit-face rules  5. grade the layer

Step 3 is the rule that recognises "this is our own body" and steps past it for free.
It sits BELOW step 2, so an origin that came to rest inside the shooter's own mesh
got a free pass instead of the skip-and-continue already implemented three lines down.

The exit was `finish(stop_layer < 0, ...)`. The reasoning was sound and the verdict
was still wrong: `stop_layer < 0` asks whether a **layer** blocked, and for a walk that
graded one layer and passed, the honest answer was no -- while the thing that actually
stopped it, this origin, was recorded nowhere. It now records
`pen_stop::origin_in_mesh` first, so the tally and the verdict agree, and
`finish(false, ...)` rather than a value that depends on the reader tracing that
effect. `record_stop` is a no-op once `stop_layer` is set, so an earlier stop wins.

**A SECOND INSTANCE, FOUND BY THE TEST, NOT YET FIXED.** `is_target_visible` --
the occlusion walk, ESP's path -- has the byte-identical test and does
`++g_vis_exit_counts()[vis_exit::inside_hit]; return true;`. Same false pass,
different workstream. The new test's locator had to be anchored on the note string
rather than on `if (hit.m_distance < 0.05f` for exactly this reason: that
expression appears twice in the header, and anchoring on it matched the wrong copy
first. Reported, not touched.

> **Expanded into a handoff 2026-10-05: `tools/handoff_visibility_inside_hit.md`.**
> Two things were established that change how this should be read, both by checking
> rather than assuming:
>
> **The fix does not transfer, and the reason is not cosmetic.** The pen walk calls
> `step_past()` and advances its origin by `hit.m_distance + kLayerEps` between
> layers; `is_target_visible`'s body (`:2224`-`:2300`) contains no `step_past` and no
> `kLayerEps` at all, verified mechanically. So its `inside_hit` fires on a
> *different physical situation* -- per §0.9, "our own collider, the camera is
> inside it" -- not on the crossed-surface epsilon this section diagnosed.
>
> **The conservative direction is inverted.** `finish(false, ...)` means "do not
> claim penetration". `return true` means **"visible"**, and it is not discarded:
> `EspModule.cpp:1150` assigns it to `entry.link_visible[i]`, the per-link draw
> state, cached per bone per frame at `:1144`-`:1152`. So flipping it would hide
> skeletons the mod draws today -- a product decision on a live draw path.
>
> **And the priority is lower than "same false pass" implies:** `inside_hit` has
> measured **0 across 5,172,909 rays** in every recorded `vis-breakdown` window, and
> that counter is already printed every 30 s. This is a latent defect on an exit
> that has never fired, not the 76-in-82 the pen walk had. It stays reported and
> untouched, in the frozen optics surface, and the deciding number is one existing
> log line.

`tools/tests/test_pen_degenerate_origin.py` is new: 4 tests on the source, with
comments blanked so the explanatory block above the exit cannot satisfy the assertions
made about it. One asserts the `record_stop` precedes `finish`, since `finish` reads the
stop to build both verdict and tally. One asserts `finish(false, ...)`, and one asserts
the exit never goes back to `stop_layer`. The last generalises: every `pen_stop` member
must have a case in `pen_stop_name`, because `kPenStopCount` is derived from `COUNT`
and an unnamed bucket would be counted and printed as `?`.

Mutation-checked, partially: reverting `finish(false, ...)` to `stop_layer < 0` makes
`test_exit_cannot_return_penetrable` fail as intended. The `record_stop` assertion was
not mutation-checked by reverting the call -- a line-ending mismatch defeated the
substitution -- but it was demonstrated live by failing on its first run, when the
region locator pointed at `is_target_visible`.

Prod|x64 build + link: exit 0, `out/prod/with_aimbot/TarkovAddons.dll` 8407.50 KB at
00:04:42. `origin_in_mesh` confirmed present in the shipped binary. `tools/tests`
220 passed.

---

### 0.54 Prod|x64 did not build, and the error named a lambda that was innocent

Found while verifying the two previous commits, and it is worth the space because
**the whole `Prod|x64` was unbuildable** — 24 errors, no output DLL — while
`tools/tests` was green at 230 and the changelog's last build line said exit 0.

**NOT MINE.** The break arrived in `f1006f6c` ("optic: instrument the off-centre
shake per frame"). Found by building rather than by reading, which is the second
time in this project's history that has been the only way something surfaced.

```
optics_lens_pipeline.h(2455,23): error C2065: g_root_ring_filled: undeclared identifier
optics_lens_pipeline.h(3257,36): error C2326: lambda_3::operator(): a function
                                   cannot access "g_root_ring"
optics_lens_pipeline.h(3247,13): error C2888: root_corrector_disabled::<lambda_1>:
                                   a symbol cannot be defined in namespace "lens"
```

**WHAT IT ACTUALLY WAS.** `root_frame_sample`, `kRootRing`, `g_root_ring*` and
`root_corrector_disabled()` were declared **inside `camera_consistent()`'s body**
— function-local statics — while `root_frame_summary()` at namespace scope reads
all of them. Name lookup in a namespace-scope function body happens at the point
of definition, not at instantiation, so a later declaration is not visible to it.
24 errors from one ordering mistake.

**Why the errors point somewhere else, which is the part worth remembering.**
C2326 ("a function cannot access g_root_ring") and C2888 ("a symbol cannot be
defined in namespace lens") both name the **lambda** `record_root_frame`, and
neither mentions declaration order. That lambda has an empty capture list,
`[](const v3* local, ...)`, which is *correct* for a namespace-scope variable —
no capture is needed — but only once the variable is visible at the lambda's own
definition point. So the errors invite exactly the wrong fix: add a capture
list, or make the variables `static`, which changes nothing about the real cause
and would then fail again. **C2601 ("invalid local function definitions") on
`root_corrector_disabled` is the honest one** and is the tell that it was a local
definition all along.

The `getenv` in the same function was a third, independent defect: C4996, and
`_CRT_SECURE_NO_WARNINGS` is not defined in `pch.h`, so it is a real warning
against this project's zero-warning standard rather than a build break. Replaced
with `GetEnvironmentVariableA`. There is no `getenv` precedent elsewhere in this
tree, which is part of why it went unnoticed.

**The fix** is a move, not a rewrite: the four declarations and the kill switch
go to namespace scope next to `root_frame_summary()`, which is their only reader.
No logic touched, and the ring's semantics are unchanged — they were already
`inline`, so hoisting them out of the function body costs nothing and was
already how they behaved.

Prod|x64 clean `Rebuild`: **exit 0, 0 errors, 0 code warnings**, 153 s,
`out/prod/with_aimbot/TarkovAddons.dll` 8410.50 KB. The only warning is
`MSB8012`, documented as expected in four places. `tools/tests` 230 passed /
6 subtests; `tools/harness/run_windows.bat` exit 0 on all 11 native cases.

All four x64 configurations of **the solution** then rebuilt clean, which is all
twelve: `TarkovAddons.sln` carries `TarkovAddons`, `TarkovLauncherBypass` and
`vk_swiftshader`, so one `Rebuild` covers every project. `Prod` 152 s, `Prod no
aimbot` 146 s, `Debug` 147 s, `Release` 148 s — all exit 0, 0 errors.

**"0 code warnings" holds for `TarkovAddons` and not for the solution**, which is
worth stating because the standing-state line in `AGENTS_TODO.md` says twelve
configurations. Two warnings are first-party and both are in
`TarkovLauncherBypass`: `injector.cpp:137` C4312 and `spoofer.cpp:41` C4200. The
remaining 131 are SDK noise (`ntstatus.h` macro redefinitions, one C4244 in
`xutility`). `Debug` and `Release` also emit a non-compiler warning that
`x64\Debug\TarkovAddons.dll` is locked by the running game — harmless for `Prod`,
which is the shipping configuration, but it means the `Debug` output is not
necessarily freshly written and should not be quoted as one.

### A regression I introduced in the fix above, found by re-reading it afterwards

The `GetEnvironmentVariableA` replacement dropped a property the original had. The
original cached the read:

```cpp
static const bool off = [] { const char* v = std::getenv(...); ... }();
return off;
```

My version called `GetEnvironmentVariableA` on **every invocation**, from inside
the per-frame corrector at `acquire_packet`. `GetEnvironmentVariableA` walks the
process environment block each time, so that is a syscall-ish cost on a path that
runs once per accepted sample, every frame — paid to read a variable that cannot
change. **The C4996 warning was real and the caching was not the cause of it**;
fixing the warning by swapping the API quietly removed a property the original had
for free, and my note claimed only that the caching was "not the problem", which
was true and also the thing I then deleted.

Restored to a function-local `static const`, with the overflow case now treated as
SET rather than as unset: `n >= sizeof(buf)` means the value did not fit, which for
this switch can only be a non-`"0"` value, and running a corrector the operator
asked to turn off is the worse failure of the two.

**Recorded because the shape is the one this file keeps hitting.** A fix that
compiles, is faster on the axis that was complained about, and passes every check
available can still be a regression on an axis nobody was measuring — and the
commit that introduced it also asserted "no logic touched". The claim was about
the ring's move, which is true; it was not about the getenv swap sitting in the
same hunk.

**The lesson, and it is the one this file keeps re-learning.** Two of the three
verification signals were green — the test suite and the changelog's own last
build line — while the thing that actually ships did not compile. `tools/tests`
and `tools/harness` **both run without building the project**, by design: that is
what makes them fast and immune to a concurrent agent's edit to the DLL. The cost
is that a header-only change which never touches a `.cpp` is invisible to all of
them. So the full-build check is not redundant with the suite, and the habit to
keep is the one `WORKFLOW.md` already states — **"verified" means `Prod|x64` full
build + link, exit 0** — applied even when the change is prose and a test file.

### 0.55 Two label defects, and three of the four commits it took were mine

`Prod|x64` build and link, exit 0, 0 errors, 0 warnings, the one `MSB8012` that `AGENTS.md`
records as expected. `tools/tests` 248 passed. Commits `c6704e99`, `558581ee`, `dca9ccc3`,
`5a09eb38`.

**1. WHAT THE USER SAW.** Two things, reported from screenshots on session `pid 18560`, and
both were present in the ESP overlay *and* the Teleport map selector, from the same reads in
both places.

- **Container labels printed a 24-hex MongoID.** Three overlapping labels at 86m / 87m / 170m,
  all reading `5d6d3bb386f774785b67a77a`. `eft_api::try_get_item_display_name` ended:

      if (is_il2cpp_object_likely_valid(item_obj))
          return item_obj->klass->name;

  which is the object's IL2CPP **class** name -- a MongoID slug when the ItemTemplate carries no
  `ShortName`/`Name`, drawn as though it were a label. The population is measured, not
  hypothetical: the game's own item db logs
  `localized 5907/5963 template names (56 still show the raw template slug)`.

  Fixed by keeping the identifier and **marking it `#`**, which is the convention the two
  `item_mod` call sites in `EspModule.cpp` already use. Deliberately *not* attempting to make
  those 56 localize: `eft_api.h` records that the lookup conflates "no such key" (cacheable)
  with "the localization subsystem is missing" (must stay uncached), and conflating them turns a
  transient outage into a **permanent** miss. That is the item-db workstream's problem.

- **Exfils read open when the player cannot use them.** Both sites read the raw backing field:

      exfiltration_point.get_field<int>("_status");

  Two defects. **(a)** `_status` is a **byte** -- ISIL, `ExfiltrationPoint.txt:95`,
  `movzx eax,byte ptr [rcx+58h]` -- so `get_field<int>` reads four bytes and three of them
  belong to neighbouring fields. **(b)** the visible one: **status is not eligibility**. ISIL
  names the authority, `ExfiltrationController.EligiblePoints()`, filtering on
  `<EligibleForPmc>` / `<EligibleForScav>` and `HasMetRequirements`. An exfil can sit at status
  2 "Available" and still be absent from that set -- Scav, unmet requirement, entry-point
  gated.

  In Teleport this was not cosmetic: `exit_status_active` decided which extracts the selector
  offers as **teleport destinations** (`status == 2 || 4 || 5`), so the same wrong read was
  offering unusable extracts as live ones.

**2. AND THEN I BROKE IT THREE TIMES.** This is the part worth keeping.

- **`c6704e99`** shipped a **crash**. There is no parameterless `EligiblePoints`; ISIL has
  `EligiblePoints(Profile)` and `EligiblePoints(string)`. `il2utils::get_method`
  (`il2utils.h:336-339`) falls back to "any arity" when the exact count misses, so asking for
  0 args returned the **1-arg** method, which I then called through a 1-parameter function
  pointer. `rdx` held garbage and the game's prologue dereferences it:

      mov rbx,rdx / test rbx,rbx / je <scav> / mov rcx,[rbx+48h]

  A read through an uncontrolled pointer, on the game thread, every second, in a raid. Not a
  wrong label -- a crash, introduced by me, in the one class of fault `crash_probe.h` exists to
  catch. The reasoning error was claiming a signature I had read the *method list* of but never
  checked: this repo's central habit, and I walked straight into it.

- **`c6704e99`** also shipped a **stray `}`** in `TeleportModule.cpp` (replaced a two-line span
  with text ending in its own brace). It surfaced as `C2059` at line 115 *and* as "no
  4-argument overload of `collect_exit_array`" at 142 -- one character reported as a confusing
  error far from its cause. Every assertion I wrote checked that something was **present**; a
  truncated, unbalanced or wrong-arity line passes all of them.

- **`c6704e99`** shipped a **truncated line**, live until `5a09eb38`. My patch scripts print
  lines cut to 104 characters; in two places that truncated text was also the search anchor and
  the replacement was assembled from it, so `EspModule.cpp:6048` lost `instance());` and read
  as `...component_get_game_object(exfiltration_point.get_`. The compiler said `get_ is not a
  member of Il2CppObjectInstance` -- three tokens from anything that looks like a lost tail.

**3. THE FAIL-OPEN PATH WAS FAIL-CLOSED.** `exfil_eligibility_of` returned `not_eligible` for
any point absent from both eligible lists. If `EligiblePoints` could not be taken -- no Profile,
unresolved method -- **every** extract would have been reported "Blocked", in the map selector
too. The opposite of what the code's own comment promised, and a louder regression than the bug
it replaced. Now two flags, `have_regular` / `have_secret`, make "not in the list"
distinguishable from "the list was never taken", and only a genuine absence of both produces a
confident `not_eligible`.

**4. TWO COMMENTS THAT DESCRIBED THE INTENT RATHER THAN THE CODE.** Both found while fixing the
above, and both are checkable and wrong:

- The ESP refresh sat **inside** a two-iteration loop under the comment
  `Refreshed ONCE per frame here, not per exfil`. It was once per **array**.
- The Teleport refresh sat inside a conditional block, so when the regular-points field failed
  to resolve, `SecretEligiblePoints` was never read either and the whole snapshot went stale.

Both moved above what they were inside. An `allow_any_argc = false` now guards **every** method
resolve in the block, including the two that are correct today, because a wrong overload
returning a plausible pointer is the failure this whole thread is about.

**5. TWO CHECKS, BUILT BECAUSE THE VERIFICATIONS I HAD COULD NOT FAIL.**

- `tools/tests/test_brace_balance.py` -- braces balanced outside comments and literals across 95
  files. Carries a negative control that reinserts the exact stray brace it was written for.
  Writing it took two corrections, both recorded in the file: an apostrophe in a `//` comment
  ("the game's own" -- 59 such lines in `crash_probe.h`) read as a character literal; then the
  same carve-out applied to double quotes, so `"favorite##" + x + "##" + y` swallowed four
  functions and a file the compiler accepts was reported as one unclosed brace. A checker that
  reports a confident wrong answer is worse than no checker.
- `tools/tests/test_diff_truncation.py` -- flags an added line that is a strict prefix of the
  line it replaced. A prefix match **alone** is not sufficient, and the first version got that
  wrong: wrapping a statement onto two lines has exactly that shape with nothing wrong, so
  reflows were reported as damage, which trains people to ignore the output. The discriminator
  is whether the lost text reappears elsewhere in the added lines. Its **known limitation is
  written down**: a lost single-character tail is invisible to it, since a lone `;` occurs
  throughout any diff -- that one was caught by the compiler, which is the right tool for it.

**6. NOT ATTEMPTED.** The 56 unlocalized template slugs (1), and the `is_in_raid` re-arm
question behind the 6,913-throw storm in 0.48, which is read by 18 files and belongs to whoever
owns `common_hooks.cpp`.

**Scope:** `module/eft_api.h`, `module/impl/EspModule.{h,cpp}`,
`module/impl/TeleportModule.{h,cpp}`, two files under `tools/tests`. Neither existing suite
compiles these headers, so the build above is the only thing that verifies them.

### 0.56 The container labels were localized with the wrong separator, and `get_Id()` was never called

`Prod|x64` build and link, exit 0, 0 errors, 0 warnings, the one `MSB8012` that `AGENTS.md`
records as expected. `tools/tests` 248 passed.

**0.55's container fix was aimed at the wrong code path, and the user corrected it: the container
names are not in the item database.** Both halves of that are right, and they are the same fact
seen from two sides. `c6704e99` had changed `try_get_item_display_name`, which containers do not
go through -- and worse, `try_get_item_localized_display_name` caches whatever that returns into
`template_display_cache` under the template id, and the container path READS that cache via
`ItemOwner->RootItem`, so the change would have injected `#`-prefixed strings into container
names. That change is reverted here.

**1. THE SEPARATOR. This is the actual defect.** `eft_api.h` records the convention itself, in a
comment written for the item db:

    the game's key is "<MongoID> Name" with a SPACE, not "<id>/Name" with a slash.
    try_localize_with_suffix builds the slash form, so passing a bare id never tries the key
    the game actually uses

`try_localize_game_key` calls `try_localize_with_suffix(key, "Name")`, which is `id + "/Name"`
(`eft_api.h:6385`). So handing it a **bare** id tries the slash form and the bare form, never
`<id> Name`. The container path did exactly that, at what were lines 6910 and 6925 -- so it
missed on every container and fell through to a raw identifier. The working localizer for the
item db gets this right and its comment says so: `try_get_item_name_for_template_id` (5731) calls
`try_localize_game_key(template_id + " Name")` first.

**2. THE CONTAINER'S OWN IDENTITY WAS NEVER READ.** ISIL,
`Assembly-CSharp/EFT/Interactive/LootableContainer.txt`:

    Method: System.String get_Id()          line 512
      515:  mov rax,[rcx+70h]
      516:  ret

A per-instance string at `+0x70` -- the one member that VARIES per container, and the code never
called it. Instead it asked for a `Template` field the class does not declare (0 `Field:` entries
in the dump) and for `get_TypeKey()`, which is:

    Method: System.String get_TypeKey()     line 216
      225:  mov rax,[185C12300h]
      226:  add rsp,28h
      227:  ret

A value loaded from a metadata slot: **the same string for every LootableContainer in the
process**. It was consulted BEFORE the per-instance id, so it could only ever produce one
identical label for a whole map's worth of containers.

**3. WHICH EXPLAINS THE SCREENSHOT.** `klass->name` is the trap that made this look like it was
working: for an IL2CPP-generated container subclass the class name IS the template id. Three
instances of one container type therefore printed the same `5d6d3bb386f774785b67a77a` at 86m,
87m and 170m. **Identical strings at different distances are the signature of a per-TYPE answer
being used where a per-INSTANCE one was needed**, and that is what made it read as a container
that could not be identified rather than a per-instance lookup that was never performed.

**4. NEW ORDER.** `ItemOwner->RootItem` (unchanged, still best when it resolves) -> **`get_Id()`
localized with the SPACE convention**, then bare -> `get_TypeKey()` (a class constant, so last and
never cached) -> `klass->name` marked `#` and not cached. `get_Id` is resolved with
`allow_any_argc = false`; it is genuinely 0-arg, and the any-arity fallback is what handed
`EligiblePoints` a 1-arg pointer in 0.55.

**5. THE CACHE IS WHAT MADE IT PERMANENT.** `container_display_cache()[ptr] = display_name` ran
unconditionally, including when the name came from a fallback because
`try_get_localization_manager()` was not up yet. That defeats the entire purpose of
`detail::provisional_miss()`, which returns empty and deliberately does **not** cache so a later
call retries: `try_localize_game_key` was carefully re-entrant and the caller then cached the
FALLBACK one level up, turning a localization outage during the first container scan into a
permanent wrong label for that container for the rest of the process. Now only a name derived
from the container's own identity is cached.

**NOT CLAIMED.** No in-game run. The separator and the `get_Id` offset are read from this file's
own documented convention and from ISIL, and both are consistent, but neither has been observed
in a live raid. "Three instances of one type printing one id" is the falsifier: if the labels
become distinct per container the diagnosis holds, and if they stay identical then `get_Id()` is
also a per-type value and the next source to reach for is the `LootableContainerParameters` /
`LootableContainersGroup` mapping the dump also contains.

**Scope:** `module/eft_api.h` only. Reverts part of `c6704e99`.

### 0.57 The container redesign is reverted, and the one thing it taught me is that I was wrong twice

`Prod|x64` exit 0, 0 errors, 0 warnings. `tools/tests` 272 passed. `module/eft_api.h` only.

**0.56 is reverted.** `try_get_lootable_container_display_name` is restored byte-for-byte to its
pre-0.56 text, from git rather than retyped, plus one token: `allow_any_argc = false` on the
`get_TypeKey` resolve. `get_TypeKey()` is genuinely 0-arg (ISIL:216), so that cannot change
behaviour when it resolves -- it can only turn a future wrong-overload match into a nullptr the
existing `if (const auto ...)` already handles.

**0.55 and 0.56 were two redesigns of one function across two commits, and 0.56 made the label
WORSE.** `get_TypeKey()` resolving to a generic type word meant every container printed the same
word, which is strictly less informative than a raw id. Reverted at the user's request, and the
request was right: a redesign that regresses the symptom is worth reverting regardless of how sound
the reasoning was, and mine was sound-sounding and wrong twice.

**WHAT I CHECKED BEFORE ADDING ANY NULL-CHECK,** because "just add a null-check" is still an
instruction and not a licence to invent one:

    try_read_il2cpp_string   !str || !is_readable_address_cached(...)      already safe
    try_read_string_field    if (!field) return {}                          already safe
    try_get_container_item_owner    returns the field, no dereference       already safe
    try_get_controller_root_item    returns nullptr on both paths            already safe
    container_obj->klass->name       already guarded by the empty() check     already safe

So there was exactly **one** missing null-check in that function, and it was the arity one. Adding
more would have been the same overreach wearing a different hat.

**STILL TRUE OF THE RESTORED CODE, recorded so the revert is not read as a fix:**

- `get_TypeKey()` is a **class constant** (ISIL:216, `mov rax,[185C12300h]`) -- identical for
  every `LootableContainer` in the process, so it cannot name one.
- The labels will read as raw ids again. They will **not** read as `medbag`. Whatever produced
  `medbag` is not in this function's history: unchanged since the 08-22 base and the 09-29 split.
  And no `get_method FAILED` line appears anywhere in the log, so **no resolver is missing at
  runtime** -- which refutes every "the method stopped resolving" explanation I had been circling.

**THE ONE HYPOTHESIS THIS THREAD NEVER TESTED.** `ItemOwner -> RootItem` is the only path in that
function that can produce a real localized container name, and the only step whose availability is
a *runtime property* rather than a *code property* -- every other step is provably unchanged since
before the regression. So the question is whether `try_get_container_item_owner` returns non-null
for a real container today, and the honest way to answer that is a probe that logs what it
returns, not a third redesign.

**THE EXFIL FIX STAYS.** It is the other half of the original report, was never disputed, and
touches a different function.

### 0.58 The 483 ms cannot be attributed, because 89.6% of that function has no zone

`Prod|x64` exit 0, 0 errors, 0 warnings. `tools/tests` 278 passed. `module/eft_api.h` only.

**1. THE QUESTION.** `frame::EspModule::gameworld_update  calls=22867  max=482,987,609 ns`.
From `tracy_traces/05.10_bad_incl.csv`:

    gameworld_update inclusive   12.983 s
    its ZONED children, summed    1.346 s
    UNZONED remainder            11.637 s   (89.6%)

    esp_scan::keypanel_scan            max 171.3 ms
    esp_scan::quest_poi_scan           max 170.9 ms
    esp_scan::loot_and_container_scan max 109.1 ms

**This capture cannot answer the question.** There is no child zone anywhere near 483 ms, because
nine of every ten milliseconds of the function is unaccounted for by construction. The three
maxima above are the only candidates and none of them is close, so naming one would be a guess
dressed as a finding. That is the honest answer and it is a statement about the instrumentation,
not about the ESP.

**2. WHAT LOOKING FOR IT DID FIND, and it was mine.** `refresh_exfil_eligibility` is called once
per `gameworld_update` from `EspModule.cpp:6023`, in no zone of its own -- so it was part of that
89.6%. And its guard was:

    if (snap.valid && snap.controller == exfiltration_controller && snap.have_regular
        && (now - snap.taken_at_ms) < kExfilEligibilityRefreshMs)

`snap.have_regular` is set only when `EligiblePoints(Profile)` was actually taken, so if the
Profile never resolved the guard **never short-circuited**, and `SecretEligiblePoints()` -- a
managed method that BUILDS A FILTERED ARRAY (ISIL `ExfiltrationController.txt:4135`) -- ran 120
times a second for the whole raid. A guard keyed on the ANSWER instead of on TIME.

**3. THE FIX, and the model for it came from the user, not from me.**

    Exfils generate once on raid entrance and only ones that really update are item-locked
    ones, so I guess there's no need to keep updating them once we got them.

That is better than the 1 s TTL I had chosen: I was polling a fixed value forever. Now:

    answered      ->  0 calls for the rest of the raid
    not answered  ->  at most 1 per second, until the Profile appears

Keyed on **(controller, MAIN PLAYER)**, not the controller alone. A pointer-only key is a worse
trap than a stale label: a new raid frees the old controller and can allocate the new one at the
same address, so the snapshot would read as valid all raid while describing the previous one --
confidently wrong rather than merely stale. `answered()` keys on `have_regular` and not
`have_secret`, because `SecretEligiblePoints()` takes no Profile and so succeeds before a
Profile exists; stopping there would leave every regular extract reading `unknown` all raid.

**4. A ZONE, so the next capture can answer.** The refresh now carries `TA_ZONE_N`. Since the
call is once per raid it should read ~1 call, and a count that stays at 1 is the evidence the
lifetime is right.

**5. NOT ATTRIBUTED, explicitly.** The per-frame `SecretEligiblePoints()` is a real defect and is
fixed on its own terms, but it does **not** obviously explain a single 483 ms spike: the unzoned
MEAN is 0.509 ms, so whatever spikes is not paid every frame. Two candidates remain with nothing
to separate them -- GC pressure from those managed allocations, or a caught managed throw (the
ESP already catches them, and a catch with no zone around it is invisible here).

**6. THE STALENESS ACCEPTED.** An item-locked extract that becomes usable when the item is
picked up keeps its pre-loot verdict until the next raid. That is the case the user named as the
only one that really updates, so the limitation is real and accepted deliberately. The cheap
remedy, if ever wanted, is re-taking only the item-gated entries on a slow interval -- not a
shorter TTL on everything, which is exactly what this removes.

### 0.61 The loot filter had two answers to one question, and the ESP one was broken

`sh tools/harness/run.sh` exit 0 (4 portable cases). `tools/harness/test_loot_categories.cpp`
95 assertions, up from 74. `tools/tests` 284 passed. `item_categories.h`,
`module/impl/EspModule.{h,cpp}`, `module/impl/LootTeleportModule.{h,cpp}`.
**Not build-verified** -- see §7.

**1. THE DIVERGENCE.** The loot category filter existed twice: `EspModule::loot_ui_filter_allowed`
for the ESP loot filters, and `LootTeleportModule::loot_ui_filter_allowed` for the Loot
Teleporter card. They had already drifted. `LootTeleportModule` had been moved onto the item's
ItemTemplate **class** (`item_categories::loot`, resolved once at db build time from the class
ancestry); `EspModule` was still running the old **substring switch** against the item's
localized display name. So the same dropdown meant two different things depending on which
card you were looking at. `LootTeleportModule.cpp` even said so in a comment: *"EspModule.cpp
still has its own copy of the same substring switch... Two copies of this logic existed before
this change; one does now."*

The substring switch had five provable defects, all from matching a name instead of a class:
Valuables was a strict subset of Barter; Barter had no positive requirement, so Bolts, Duct
tape and Car Battery all passed it; Ammo could not see a calibre because none of its six
needles contained a digit while EFT ammo is named "7.62x51 M80"; buckets overlapped
("SURV-12 Sniper Rifle" was both Medical and Weapons); and the needles were English against a
name the game localizes, so on a non-English client the whole feature silently matched almost
nothing. The class name is never localized.

**2. THE SHARED PREDICATE.** Both halves now ask `item_categories::loot_category_allows`, which
takes the resolved `loot` and the dropdown index. The numbering lines up exactly -- 1 Valuables
.. 8 Keys, 0 = All -- so the cast is a `static_assert` rather than a comment, and reordering
the enum fails to compile instead of silently filtering on the wrong bucket. The "unknown
allows" policy (an unclassified item is shown, not hidden) is stated once, in the one place
that decides it.

**3. A LATENT BUG THE DRY-UP REMOVED.** Both copies of the four-option filter (Quest /
Wishlisted / Selected item / Category) answered "Category" by calling their own
`loot_ui_filter_allowed` -- which applies the **"selected items only" gate before the
category gate**. So with both toggles on, choosing "one category" silently meant "the selected
item, if it happens to be in that category". Both toggles default off, so it was never
reachable in practice, but it was in the code both copies inherited. The shared
`item_categories::matches_teleport_filter` decides case 4 on the category alone. There is a
regression assertion that fails against the old behaviour.

**4. THE TAXONOMY QUESTION WAS ALREADY ANSWERED.** Wishlist and the `*Template` categories
are not two dropdowns. They are options 2 and 4 of one list -- player-controlled
(`EWishlistGroup`) and game-defined (the class) respectively -- and both can be true of the same
item at the same time. That is why they are options and not a partition: a user picking
between them would be asked to discard a true fact.

**5. WHAT WENT AWAY.** `EspModule::category_allows` (~40 lines of needle lists),
`EspModule::contains_any`, `EspModule::database_name_for_template`,
`LootTeleportModule::loot_ui_filter_allowed`, and the `name` parameter's last reason to exist.
The per-frame lowercase-and-compare on the ESP draw path is gone with them. The `name`
parameter itself stays -- removing it would churn three call sites for no behaviour gain -- but
it is now `(void)name` at both definitions, which says so where a reader will see it.

**6. THE FREEZE QUESTION, ANSWERED.** `EspModule.h` carries `[CLEANUP-PENDING:OPTICS] DO NOT
CLEAN UP THIS FILE YET`, with an enumerated list of optics items. The loot filter is not on
that list and has nothing to do with optics, so this change does not touch the frozen surface.
Two accessors that became dead as a *result* of this change were removed rather than left for
the optics pass; both are in the commit message if that pass wants them back.

**7. WHY THIS IS NOT BUILD-VERIFIED, AND WHAT WAS DONE INSTEAD.** A `Prod|x64` link needs
MSVC on Windows and is not available here. The two modified `.cpp` files cannot even be
syntax-checked with mingw, for reasons that predate this change: `il2cpp/il2utils.h:355` does
an MSVC-only `static_cast` from `void*` to a function pointer, and `module/quest_esp.h:673`
uses SEH `__except`. Neither file is touched by this change. So the new code was checked two
other ways, and both are in the commit: `tools/harness/test_loot_categories.cpp` includes the
real `item_categories.h` and now asserts the shared predicates (95 assertions, with a
negative control that was run and confirmed to go red against the old behaviour); and a
throwaway TU reproduced both new function bodies verbatim against stubs and compiled and
linked clean. That is weaker than a real link and is not described as one.

### 0.63 The `ailimit` AI controls, on the Bot Spawner page

`Prod|x64` exit 0, 0 errors, 0 warnings (MSB8012 only, which is benign).
`tools/harness/run_windows.bat` exit 0, all 15 cases. `tools/tests` 452 passed;
the one failure left,
`test_manifest_tool.py::test_shipped_patterns_cfg_exposes_hwid_check_slot`, is
pre-existing at HEAD (`patterns.cfg` ships a `hwid_check` pattern from commit
d03f86a0e and that test still asserts the slot is empty) and is untouched here.
`tools/harness/run.sh` cannot run on this box at all: no `g++`, `clang++` or
`clang` on PATH, which is a box limitation, not a code one.

**WHERE IT LANDED.** Two commits, because two of us were editing this tree at
once: the code (`WorldModule.h`, `WorldModule.cpp`, `LootTeleportModule.cpp`)
and the English strings went in with the chams workstream's `e4593f6a2` and
`7eac821df`, which swept the working tree as it stood. That is §0.50 again —
"I committed a line that was not mine" — seen from the other side. Nothing was
rewritten and no history was touched.

**WHAT THIS IS.** The `ailimit/` submodule (SPT-AILimit 1.9.2) caps how much
bot AI a raid runs: sort every bot by how far the nearest human is, and let only
the first N within D metres keep thinking. The rest are parked. Newly spawned
bots get a grace period, and the scan re-runs on a frame interval.

It is its own card on the Bot Spawner tab, `AiLimitModule`, in the LEFT column:

| control | meaning | range / default |
|---|---|---|
| Enable AI Limit | master toggle; turning it off WAKES what it parked | off |
| Auto-tune per map | fills the two sliders from the raid's map preset on raid start | on |
| Bots Kept Awake | ailimit's "Bot Limit (At Distance)" | 0..20, 6 |
| Bot Disable Distance | ailimit's "Map Related" distance | 50..400, 150 |
| Spawn Grace | ailimit's "Time After Spawn" | 0..60 s, 10 |
| Scan Interval | ailimit's "Frames To Check" | 30..600 frames, 300 |

**EVERY MEMBER NAME IS READ OUT OF THE GAME, NOT GUESSED.** All three IsilDump
trees (115147510, 120047888, 120047965) were checked before a line was written,
which is why each link has two shapes: 115147510 keeps
`BotOwner.Settings` / `.Memory` as plain public fields, the two newer builds
moved them behind `<Name>k__BackingField` behind a getter. The park itself is
`BotStandBy.DoStay()` (which reads `Settings.FileSettings.Mind.CAN_STAND_BY`
and returns without touching anything if it is false), `_nextCheckTime` pushed
1000 s out so the game's own `Update()` stops re-evaluating, `GoalEnemy` cleared
and `BotState = NonActive`. The wake is the exact mirror: `Activate()`,
`_nextCheckTime = now + 10`, `BotState = Active`.

**THE ONE DIVERGENCE, ON PURPOSE.** ailimit ends its park with
`player.gameObject.SetActive(false)`. It is a server-side SPT plugin, so that
removes the bot from the authoritative simulation; this DLL is a client guest in
a live raid, where a local `SetActive(false)` cannot be exercised here and cannot
be recovered cleanly if the server re-activates it. So the park stops at
`DoStay()`. The cost is stated rather than hidden: a parked bot still renders, it
just stops thinking.

**CONFIG SHAPE.** ailimit stores 20 numbers (one pair per map). This keeps one
live pair and refills it from a preset table on raid start when Auto-tune is on,
which is the same behaviour with 18 fewer config keys and 18 fewer translation
strings per locale. The 13 new i18n keys are in all 19 `lang/*.json`. A map with
no preset row (Labyrinth) keeps whatever the sliders hold instead of silently
overwriting it with 6/200.

**ITS OWN CARD, NOT A SECTION IN SOMEONE ELSE'S.** It was first written inside
`WorldModule` and drawn by the `BotControlModule` card, which put eight new
sliders in a card that already held the bot-teleport pair — the "squished with the
Bot Teleport card" complaint. It now lives in its own
`module/impl/AiLimitModule.{h,cpp}`, registered between `WorldModule` and
`BotControlModule` so the draw order puts it in the LEFT column of the tab, marked
`Column::Left` in `column_layout.h`. The tab reads as three cards with one job
each:

    Bot Spawner  |  force-spawn, loot teleport
    AI Limit     |  this card -- how many bots keep thinking
    Bot Controls |  kill / teleport the bots that are there

That order is load-bearing twice over. `column_layout.h` pins the boundary after
the LAST `Left` card, so `AI Limit` being declared `Left` is what sends `Bot
Controls` right; and the draw order comes from `ModuleManager.h`'s declaration
order, so `AiLimitModule` must stay registered before `BotControlModule`.
`tools/harness/test_column_layout.cpp` asserts both, from the real sources.

**AND THE INVISIBLE-TO-AI CONTROLS MOVED IN, WHICH FOUND THE LAG.** The two
"invisible to AI" toggles were in the Player card's misc section; they are
AI-perception behaviour, so they were MOVED into `AiLimitModule` wholesale --
values, enum, chain walk, reporter, cadence, hotkeys and all -- and
`hotkeys::register_player` now takes an `AiLimitModule*` to bind them. The config
keys change from `##Player` to `##AI Limit`, which means a saved value under the
old key is not found and falls back to its default. No migration was written,
deliberately.

Moving it put the code in front of someone reading it for a different reason, and
that is when the lag became obvious:

**The ally path threw a managed exception, 4 times a second, per bot group.**
There is no game API for "make this player an ally" -- verified in the dump
(BotGroupHostility has no AddAlly, the surviving AddAlly on EFT/Player is an
empty `ret 0`, the real method is private and takes a struct), so the code writes
`BotGroupHostility.Allies` directly, and because that dictionary is typed it must
supply a `BotGroupEnemyInfo` as the value -- one allocation and a ctor per bot
per call. Then:

    Dictionary<IPlayer, BotGroupEnemyInfo>.Add(local_player, info)

and `Add` throws on a key that is already there. From the game's own binary:
`Dictionary`2.Add` opens with `mov r9b,2` (`InsertionBehavior.ThrowOnExisting`)
before calling `TryInsert`. So the first call inserted the player and every later
call -- 4 Hz, per bot group, forever -- threw `ArgumentException`, complete with
an object allocation and a 24-frame stack capture, unwinding out through our
native hook frames and into the game's managed frame, which catches it. Which is
why it never crashed and only lagged.

The 2026-10-11 log corroborates it without being able to prove it: the crash
probe's 24-entry ring held **18 consecutive `0xE06D7363` events** -- a C++/IL2CPP
exception thrown -- as the dominant recent activity, at the moment the feature
was applying. The reported frames are a stack-word scan through GameAssembly and
UnityPlayer with none in this module, which is what a managed throw out of a
`methodPointer` call looks like from outside. So: mechanism proven from code and
binary, log consistent, exact attribution not provable from the capture.

**THE FIX** is one `ContainsKey` before the write. It is a single managed call
that cannot throw, so a bot group the player is already an ally of now costs one
lookup instead of an allocation, a constructor and a thrown exception; `Add` is
reached only when the key is absent and cannot throw. The 250 ms cadence was not
the cause -- it only set the rate of the throwing, which is worth recording
because "raise the interval" is the obvious wrong fix and would have looked like
it helped.

`tools/tests/test_invisible_bots_chain.py` grew two cases for it (13 now): one
asserting `ContainsKey` is resolved before `Add`, one asserting the
already-present branch returns true so the caller does not re-report the bot
every tick. Both were written against the defect present and confirmed red
first.

**AND A SECOND DEFECT, WHICH THE NEXT LOG CAUGHT.** The follow-up session ran a
raid with `invisible_to_bots_ally_cb` set to **true** and the feature did
nothing, silently, for the whole raid: `init: AI Limit` logged, no
`invisible_to_bots:` line at all. The cause was structural rather than a bad
name -- the ally chain had been appended *inside* `gameworld_update`, after its
`if (!ai_limit_enabled) return;` gate, and `ai_limit_enabled` was `false`. Two
independent features sharing one per-frame entry point means any gate that
RETURNS disables the other half. The log showed nothing precisely because the
feature that would have reported it had not run -- the same invisible-failure
shape as a checker that cannot fail.

The chain is now its own `update_invisible_to_bots()` method, called first and
unconditionally, before any limit gate can return. One new case asserts it
structurally rather than by member name: the chain must not appear in
`gameworld_update`'s body, the call must precede the enable check, and there
must be no `return` between them. Negative-controlled by moving the call back
behind the gate and confirming it goes red.

**AND TWO MORE, FROM THE CARD'S OWN APPEARANCE.** A screenshot of the Bot Spawner
tab produced the next two findings, and neither is the ally chain at all.

*The card rendered the two toggles twice.* `menu.cpp`'s `apply()` draws every
`conf()`-registered value, and `draw_menu_extra()` drew `section_invisible_` and
both checkboxes **again**. So the card showed the pair on top, then the pair
again at the bottom in swapped order -- two widgets sharing one ImGui ID each.
This is the trap `HideoutAutomationModule`, `LootTeleportModule` and
`BotControlModule` all guard against with `set_hidden_in_owner_menu(true)`, and
this card did not, with no test to say so.

*They were on top by accident.* `conf()` pushes into `config_values` in
**declaration order**, not in the order the constructor's initializer list names
them. The two toggles are `public` (the hotkeys bind them) and everything else is
`private`, so the `public:` block happened to come first and they registered
first. That is the layout the user asked for, arrived at by a coin-flip on where
someone typed `public:` -- move one member across that boundary and the card
silently reshuffles. The position is now explicit:
`draw_menu_extra_before_values()` returns true, and the three values are hidden
from the automatic list.

*And turning ally off never unlocked neutral.* `sync_invis_state()` ran only in
`application_update()`, which `ModuleManager::apply()` gates on `is_active()` --
and `is_active()` is exactly "one of these three toggles is on". Switching the
last toggle off removed the module from the very loop that has to react to that
switch, so the peer stayed greyed out until the game was restarted.

The instructive part is commit `601a79179` ("Properly reenable checkboxes"),
which added the missing `else` branch to `sync_invis_state()` and changed
nothing observable. The logic was right and the **path** was wrong, so a correct
fix read as a failed one -- and it was written off as "the checkbox is stuck"
rather than "this branch is unreachable". It is the same structural class as the
bug above it: a feature whose only liveness check is one of the values it is
meant to police cannot observe that value going false. The sync now also runs in
`prepare_menu_draw()`, which comes from `apply_all()` -- `is_active()`-independent,
and the only place `disabled_` is observable at all.

Four new cases (18 in the file), each negative-controlled separately: drop the
hidden flags, flip `draw_menu_extra_before_values()`, remove the sync from
`prepare_menu_draw()`, remove the `else` branch -- one failure each, then restored.

Stripping the rows out of `BotControls` also exposed a pre-existing bug worth
naming: `make_bots_ally` and `make_brain_dead` were hidden in the owner menu but
never drawn by the card that owns them, so neither was reachable at all. They are
drawn now.

**WHAT WAS VERIFIED, AND HOW.** Build and link, exit 0, 0 errors, 0 warnings.
`audit_config_pointers.py` reports 358 pointers across 29 headers (347 before the
new module header landed; the header count moved, the pointer count did not).
`map_icf.py` was
re-measured three times over, and that is the useful part of this entry: the
first-party figures went **101/375/274 -> 112/396/284** when the new
translation unit landed, then to **106/388/282** when a concurrent session's
uncommitted code reached the DLL the `.map` was taken from. Raw:
**2,050 groups / 18,992 -> 2,196 / 19,474 -> 2,120 / 19,497 symbols**. So one of
those two jumps is this change and one is not, and nothing in the numbers says
which. WORKFLOW.md, AGENTS.md and the tool's docstring were updated to the last
measurement together, and `test_map_icf.py` re-derives every one of them.

`test_dup_scan.py`'s documented scale moved with the new file: 178 → 180
first-party files, comparable 168 → 170. That test is the reason a new module
cannot be added here without noticing.

Why `map_icf`'s raw figures move with nobody touching them: it reads the `.map`
in `out/prod/with_aimbot/`, and `build.ps1` deliberately does NOT override
`OutDir`, so that file is written by whichever agent built last. I measured
18,982; a concurrent session rebuilt mid-verification and the same measurement
came back 18,984. The raw figure is a property of the tree AND of whoever built
it last, so a raw figure that moves by a handful of symbols is a rebuild.

And the sharper version of that, which the figure treadmill produced on its own:
**the two build systems do not produce the same fold count.** On the same source
tree, `build.ps1` (MSBuild) gave 106 groups / 388 symbols / 282 copies saved and
`build_cmake.ps1` (Ninja) gave 112 / 396 / 284 — six groups' difference on
identical source, because the two toolchains do not emit byte-identical code for
every function, so identical COMDAT folding finds more pairs under one compiler
than the other. The documented figure is therefore three-coordinate — tree, AND
whoever built last, AND which toolchain they used — and the third coordinate is
not stated in any of the docstrings that quote it. Nothing here is wrong; it is
under-specified, and a future reader who re-measures under the other backend will
find a "regression" that is a backend.

**NOT VERIFIED, AND IT IS THE IMPORTANT ONE: no raid was launched.** Every
member name is dump-verified and every resolution failure reports itself once
per raid instead of once per scan (`test_invisible_bots_chain.py` is the reason
that discipline exists), but "the names are right" is not "the bots park
correctly". The next thing to do is launch a Factory raid with it on and read
the card's info line and the log.

### 0.62 Container labels reverted to MongoIDs, restoring the per-instance `get_Id()` path

`Prod|x64` exit 0, 0 errors, 0 warnings. `tools/tests` 3 failures, all pre-existing from
concurrent sessions. `TarkovAddons/module/eft_api.h` only.

**1. WHAT THE USER REPORTED.** After reverting the 0.56 redesign (commit 592eb60d), container
labels went back to showing 24-hex MongoIDs. The user said: "it used to say medbag".

**2. WHY THE BASE COMMIT ALSO FELL THROUGH.** The pre-0.55 resolver chain was:

    ItemOwner -> RootItem -> item db
    Template field
    get_TypeKey()   <- class constant, same for every container
    klass->name     <- MongoID

The base commit (and my revert) falls through to `get_TypeKey()` when the ItemOwner path
fails. `get_TypeKey()` is a class constant -- it returns "LootableContainer" or similar for
every instance, so it localizes to the generic word "Контейнеры" (Containers). It cannot name
one container.

**3. THE ONLY PATH THAT PRODUCES PER-INSTANCE NAMES.** ISIL,
`Assembly-CSharp/EFT/Interactive/LootableContainer.txt`:

    Method: System.String get_Id()      line 512
      515:  mov rax,[rcx+70h]
      516:  ret

A per-instance string at +0x70. This is the member that VARIES per container. The 0.56 commit
added it; 0.57 reverted it. The user's "return it the way it was" and "it used to say medbag"
point to a version where this path worked.

**4. THE SEPARATOR.** The game's localization key is "<id> Name" with a SPACE, not
"<id>/Name" with a slash. 0.56 had used the slash form (via `try_localize_with_suffix`) and
missed. The fix is to call `try_localize_game_key(container_id + " Name")` directly, then
fall back to `try_localize_game_key(container_id)` without suffix.

**5. CACHE POLICY.** Only names derived from the container's own identity (`get_Id()`) are
cached. Names derived from the item behind the container (`ItemOwner->RootItem`) are NOT
cached, because that item can change between sessions and a stale cache would permanently
label the container wrong.

**6. ORDER OF RESOLUTION.**

    1. ItemOwner -> RootItem -> item db  (not cached, best when it resolves)
    2. get_Id() + space-localized         (cached)
    3. get_TypeKey()                      (cached)
    4. klass->name prefixed #             (not cached, identifier fallback)

**7. WHY THIS IS NOT A REDESIGN.** The resolver is byte-for-byte what 0.56 had, minus the
slash separator bug, plus the arity guard on `get_TypeKey` from the revert, plus the explicit
`/*allow_any_argc=*/false` on `get_Id` that the base commit was missing.

**NOT CLAIMED.** No in-game run. The `get_Id` offset and the space separator are read from the
ISIL dump and are stable across the captured game builds. If localization still misses, the
next source to probe is the `LootableContainerParameters` / `LootableContainersGroup` mapping
in the dump.

### 0.64 Container chams: the loot scan cannot see a LootableContainer

`Prod|x64` exit 0, 0 errors, 0 warnings (MSB8012 once, expected and benign).
`tools/tests` / `tools/harness` green except three failures that belong to other
sessions' in-flight work. `ChamsModule.h` / `ChamsModule.cpp` only, plus the 19
`lang/*.json` and four documentation figures re-measured.

**WHAT WAS ASKED FOR.** Chams-type colouring on containers, reusing the rendering
pipeline instead of the external ESP draw, with the colouring reset on a transit
and on an exfil.

**WHY IT IS NOT A FLAG ON LOOT CHAMS.** `GameWorld.LootItems` is the loose loot. A
`LootableContainer` is an `EFT.Interactive` component on a scene object: no entry
in that list, and no `_renderers` field, which is the field `apply_chams_to_item`
reads to find what to paint. The loot scan cannot see one and the item painter
cannot paint one. So two new pieces -- an enumeration and a renderer collector --
and everything else shared.

**THE ENUMERATION IS A SCENE-WIDE SEARCH, AND THAT IS THE WHOLE PROBLEM.**
`FindObjectsOfType(LootableContainer)` is the only source, and the ESP measured it
at 8.4 ms average / 135 ms peak. Running that per paint tick is not an option, so
discovery runs on its own clock -- 2 s for the first 30 s of a raid, because the
loot spawner rolls containers during them, then 15 s -- and the 250 ms paint walk
works off the cached list.

**GHOSTS.** Every map ships more container prefabs than one raid uses, and an
un-rolled one has a live component, a position and a renderer: nothing
distinguishes it from a real container except `ItemOwner` / `IsAlwaysSpawn` /
`IsAlwaysLootable`, which `eft_api::is_container_actually_placed` already encodes.
The cache is rebuilt from scratch each pass, so there is no merge branch for an
admitted ghost to survive in -- the leak the ESP's merge branch had to defend
against.

**THE PAINT AND RESTORE ARE ONE IMPLEMENTATION NOW.** The renderer-list loop was
duplicated between the item paint and un-paint, with the alignment rule --
`saved[n]` belongs to the Nth qualifying renderer -- held together by two loops
happening to agree. Both surfaces now produce their list through one collector and
share `paint_renderer_list` / `restore_renderer_list`. Item behaviour unchanged;
`dup_scan`'s token band was re-measured for it.

**THE TRANSFORM WALK IS DEPTH-CAPPED AND ACTIVE-ONLY.** A container is usually
parented into furniture -- a drawer inside a desk. `GetComponentsInChildren
(Renderer, true)` is the obvious call, and it repaints the desk, the shelf and
whatever else the prefab nests under. Depth 2, `get_activeSelf` children only, the
container's own component first.

**RESET, WHICH IS THE PART THAT WAS ASKED FOR.** Two boundaries, two detectors,
because they are visible from different places. A transit changes the GameWorld
instance inside one raid with `is_in_raid` potentially true straight through the
load, and that is observable in `gameworld_update`. A raid end stops
`hk_game_world_update` from firing at all -- the hook gates every module's
`gameworld_update` on `is_in_raid` -- so nothing in `gameworld_update` can observe
it, and that half lives in `application_update`, whose hook has no raid gate. Both
forget rather than restore, which is `clear_runtime_cache`'s documented teardown
trade: the renderers are being torn down, and walking one to write its materials
back is the fault the item path already learned to avoid.

**NOT CLAIMED.** No in-game run. The discovery cadence, the depth cap and the
active-only rule are reasoned from the ESP's measurements and the prefab
structure. Whether a drawer-in-desk container paints correctly is what the first
raid has to answer, and the trace line (`container-chams: found= cached= ghost=
...`) is written to say so.

### 0.65 Four ways into a menu of 31 cards: quick jump, changed markers, key conflicts, and a scrub readout

The menu is 31 cards across ten tabs, and until now the only way to reach a
card was to know which of the ten it was on. This section adds the four pieces
of usability the menu was missing, in the order they matter.

**0.65.1 Ctrl+K finds any card, value or keybind** (`gui/menu/quick_search.h`,
`menu.cpp`). A command palette with a subsequence fuzzy ranking: `aimfov`
finds `Aimbot FOV`, `esp loot` requires both terms. Enter jumps -- picks the
tab, unfolds the card, scrolls the column to it and pulses it. The ranking is
its own header, with no ImGui in it, so `tools/harness` compiles the real one:
the split that `card_fold_state.h` and `column_layout.h` already established,
which is what let a 24-assertion case and ten negative controls exist at all.
One rule is recorded as having NO control, and the test file says why: the
per-match run bonus trades against the gap penalty 10-to-1, so with the
matched letters and the skip count held equal the two terms cancel and no
ordering can observe one alone. Pinning it would mean asserting an absolute
score.

**0.65.2 A dot beside every row that differs from its default** (`ConfigValue::
is_changed`, the card gutter). Not a cached flag -- values are written from at
least four directions (the widget, a hotkey, the config loader, Reset Defaults)
and "changed" is a question about the current string, not the last write; a
flag would be wrong the moment a fifth writer appeared. The dot doubles as the
reset button, sitting in the card's 14*sf indent where no control lives, so no
existing hit area moved. `FavoritesValue` overrides it false: favorites are
bookmarks, and the reset affordance would clear the list the Clear button
already owns.

**0.65.3 The keybind conflict report** (`gui/menu/hotkey_conflicts.h`,
`hotkeys.h`). `hotkeys::all()` is one flat registry nothing compares, so two
features could land on one key and the panel showed two identical buttons with
no hint that pressing the key fires both. A report, not a gate -- it unbinds
nothing. `key == 0` (unbound) never collides, or the default configuration
would open with a page of false conflicts and teach the user to ignore it. One
binding on `VK_INSERT` is a conflict on its own: `menu::draw()` reads INSERT
directly, so the binding can never fire on its own terms.

**0.65.4 The slider readout scrubs** (`imgui_addons`). The editable sliders'
number was an `InputFloat` -- it typed, and that was all. It is a
`DragFloat`/`DragInt` now, so it drags and Ctrl+click still types, with the
speed derived from the range so a ~220px sweep spans it on every slider. A
fixed speed of 1.0 would cross the 0..3840 camera FOV range in four pixels of
mouse movement.

**The verification pass, which is the real content of this section.** The
features were committed first (the standing rule: a commit made before the
build is not build-verified) and build-verified after: full Prod|x64, exit 0,
0 warnings, 0 errors. Windows `pytest tools/tests` then read **7 failed**, and
four of them were mine and one was my own rebuild's shadow:

- `test_menu_double_draw` guarded the literal apply() one-liner the marker
  replaced. Re-pointed at the new shape -- ONE regex requiring the lambda to
  skip hidden values AND still draw, because a separate "the draw is somewhere
  in the file" check would pass with the draw outside the lambda. Both halves
  re-controlled against the real menu.cpp: deleting the draw, and deleting the
  hidden check, each fire it.
- `test_doc_counts`: 19 -> 21 native, 7 -> 9 portable. The harness README
  table also gained the three cases it had silently omitted (text_fold,
  wishlist_groups, survival_clamp) -- a table that undercounts its own runner
  is the failure mode that section exists to prevent.
- `test_dup_scan`: 183 -> 185 files. The 25,000 first-40 floor became 20,000,
  because the two new headers sort early enough to push larger files out of
  the first 40 and the measured total is 23,350. A floor set above a
  measurement nobody re-measures is the failure this test argues against.
- `test_map_icf` and the prose beside it: the rebuild produced a newer `.map`
  than the docs. Re-measured -- 110 groups / 405 first-party symbols / 295
  copies (was 111/402/291), largest group 91 (was 90), raw 2,230 groups /
  19,668 symbols, `$unwind$` 6,183 across 2,009 addresses, largest raw group
  1,263. The claim about the largest hand-written group was re-checked and
  still holds: 5 modules override `draw_menu_extra_before_values`, 6 symbols
  carry the name, the five that share an address fold.

The RAW figure is the one that moves: two rebuilds of this tree ten
  minutes apart read 19,669 and 19,668, because another workstream was
  committing beside it. 	est_map_icf.py re-derives all of them from the
  newest .map on every run, so the live docs (AGENTS.md, WORKFLOW.md) are
  held current by the test; this section is a record of the reading taken
  when the work landed.

Final state, measured on this tree: `run_windows.bat` exit 0 over all 21
cases, `pytest tools/tests` **505 passed, 23 subtests, 1 failed** -- the single
failure being `hwid_check`, which is real, platform-independent and owned by
another workstream.

**And three defects self-review found after the first commit, each fixed in its
own commit with its own build verification**, because they are the kind that
compile green and only show up in a raid:

1. **The palette could not be dismissed.** `draw()` stands its Escape gate
   down while the palette is open (the first press belongs to the palette, the
   second to the menu -- the two-stage behaviour the Escape block already
   documented for popups), and the palette itself did not listen. The key
   therefore did nothing at all while it was up.
2. **The reset affordance poked outside its window.** Positioned 15*sf left
   of the row with a width of 13*sf, its left edge was 1*sf outside the
   column child -- a pixel at 1080p, more at 4K, all lost to the clip rect.
3. **A symmetric test fixture**, which passed while proving nothing: the first
   version of the run-length assertion compared `"abxc"` against `"acbc"`,
   and both hands have exactly one gap and one run, so the two scores are
   equal and the assertion was a coin toss. Rewritten against `"axbc"`.

**NOT CLAIMED. No in-game run.** Nothing here has been exercised against a
live raid: whether the palette types, whether the scroll-to lands on the right
card, whether the gutter reset reads as intended next to a real slider row,
and whether the drag scrub feels right at a real FOV range, are all open. What
is measured is that it compiles, links clean into the shipping configuration,
that the pure logic holds under ten negative controls, and that every figure
its neighbouring docs quote was re-derived rather than remembered.
### 0.66 Inter and JetBrains Mono, the overlay face unfrozen, and the search fields that were squished

The typeface review arrived with two recommendations — embed Inter + JetBrains
Mono rather than read Segoe UI off the system — and the strongest part of it
was not visual at all. Segoe UI is a Microsoft **system** font: legal to load
from `C:\Windows\Fonts`, not legal to redistribute inside a DLL. Both
replacements are SIL OFL 1.1, whose licences now ship in `assets/fonts/` beside
the faces.

**THE COVERAGE WAS MEASURED, AND IT CHANGED THE LOADER.**
`tools/check_font_coverage.py` reads each face's cmap against the exact ranges
`build_unicode_glyph_ranges()` asks for:

| | Inter | JetBrains Mono |
|---|---|---|
| Latin / Latin-1 / Ext-A / Ext-B | complete | complete / 98.4% |
| Cyrillic | 100% | 95.8% |
| Greek | 96% | 96% |
| Vietnamese | 100% | 98.8% |
| **Thai** | **1.1%** | 0% |
| CJK | 0% | 0% |

Inter has essentially **no Thai**, and the menu ships a Thai locale. A naive
font swap would have rendered `tu` as boxes — a regression bought by a font
change, and invisible until a Thai user opened the menu. So the existing CJK
fallbacks stay and a Thai one was added (Leelawadee UI, then Arial Unicode).
The mono face deliberately carries neither CJK nor Thai: it is only ever asked
for digits, key names and template ids, and 20k CJK glyphs in a mono atlas is
cost for glyphs nothing draws.

**Embedded as RCDATA 1400-1402**, the pattern already used for the 1.9 MB
background image and all 19 locales. It survives a manual map that hides the
Win32 resource API, and it needs no compressor — this vendored ImGui tree has
no `misc/fonts/`, so the compressed-array route would have meant vendoring a
tool to save 700 KB. `tools/check_dll_resources.py` walks the shipped DLL's
resource directory and compares each payload byte-for-byte against the file in
`assets/fonts/`, because a `.rc` entry that silently fails to compile is
invisible from the menu: the loader falls back to a system face and everything
looks normal. All three read IDENTICAL.

**The overlay came with it.** The ESP/optics *typeface* freeze was lifted by the
user on 2026-10-13, so `get_hud_font()` — nine EspModule sites, the ammo HUD,
the watermark — is Inter now, and the ammo block's pure numbers ("12 / 60", a
weapon code) go to JetBrains Mono at HUD size. The optics **logic**
`[CLEANUP-PENDING:OPTICS]` markers were still in place when this was written;
**the logic freeze was lifted the same day and the markers were removed** (see
`AGENTS.md` "Do not touch" for the current state, and `AGENTS_TODO.md`'s
top-of-file 2026-10-13 note for what the lift unblocks). `AGENTS.md` records the
unfreeze with its date so that nobody "restores" Segoe UI later as a regression
fix. Mixed labels (a name and its distance) stay in Inter on purpose: two faces
inside one string reads worse than either face alone.

**Search fields stopped being squished.** `theme()`'s `FramePadding` is (4, 3),
tuned when the menu was dense enough that vertical space cost a row — and it
leaves typed text against the frame's left and top edge, which reads as
squished rather than compact in a field whose whole job is showing text. It
cannot move globally: `menu.h` records that the widget widths in
`imgui_addons.h` are tuned to those metrics. So `push_search_padding()` scopes
a roomier frame to the fields that need it, and **both** search boxes in the
tree (the item picker and the quick-jump palette) go through that one helper,
which is what stops a third one from being different again.

**And `%.3f` is gone from the readouts.** The review's sharpest observation was
that `100.000` and `30.000` look like debug output, and it was right — every
float readout in the menu defaulted to three decimals.
`number_format_for_range()` derives the format from the range (>=10 → `%.0f`,
>=1 → `%.2f`, else `%.3f`), so pixels read as pixels and an opacity reads
`0.45`, with no call site to touch.

**What the review also proposed, and why it was not done here.** One-row
sliders (label | track | value on a single line) are a real density win, but
every slider path in this project passes widths tuned to the current metrics
and the note in `menu.h` says so; it is a layout change, not a style change, and
it wants its own pass. FreeType hinting is the other one: it is the difference
between a 2015 and a 2025 screenshot at 14-16px, and it needs freetype vendored
into **both** build systems — which is not a change to make while another
workstream is inside them. Settings-as-data, for what it is worth, is already
the architecture: `ConfigValue` is the record, the registry is the array, and
the search, favorites, saves and per-row reset all fell out of it rather than
being added alongside it.

**NOT CLAIMED. No in-game run.** No raid has shown this menu, this overlay or
this ammo block. Measured: the build is clean, the three faces are in the
artefact byte-for-byte, the coverage numbers above were read out of the fonts,
and pytest reads 505 passed / 1 failed (`hwid_check`, pre-existing and owned
elsewhere).
### 0.67 The item search stopped selecting, and the fix was one line and one hazard

The user reported it after the multi-select redefinition: **"it doesn't seem
to work as selection any more."**

**Cause.** The redefinition (`f5ffc5627`) taught the loot filter to read the
*query's* matched set — the right answer for a multi select — and registered
those two boxes with a **null callback**. The click path set `selected_id_` and
`selected_name_` and nothing else. So clicking a row changed what the summary
line claimed (`> all N matches selected` became `[id] > name`) and nothing
else: `matches_teleport_filter` consults `selected_ids` first and returns, so
`selected_id` was never read. A pick the predicate ignores is worse than no
pick, because the UI asserts one.

**Fix.** In multi mode the click *is* the pick: it pins the matched set to the
one row, so the summary and the predicate agree, "Teleport Selected Loot" moves
the row that was clicked, and re-typing (or clearing) the query returns to the
whole matched set — `refilter()` republishes from `query_` on every keystroke.
The single-pick boxes (Item Editor, Weapon Builder) never took that branch and
are unchanged.

**And the hazard the same redefinition left behind.** `matched_ids_` was a
plain `unordered_set` member, rehashed by `refilter()` on the **render** thread
while the loot filters on the **game** thread held a raw pointer into it — the
shape of the crash `b9ca0b366` already fixed once for ESP ("the render thread
handed the game thread a pointer the game thread could free"). It is published
as an immutable `shared_ptr` now: built complete, then swapped. A reader holds
its own reference and reads a set nothing is writing. The predicate takes the
`shared_ptr` rather than the pointer.

**The harness caught this change and was updated, not weakened.**
`test_loot_categories.cpp`'s filter-3 assertions set `selected_ids` as a raw
pointer and stopped compiling — a harness that compiles the real header cannot
be updated by anything softer than the real API. They publish through the same
`shared_ptr` the live code does, and all 120 assertions still pass.

**What the shared tree cost this time, recorded because it is the third time
in two sessions.** This session's build was blocked twice over by another
session's `quest_esp.h`: first their uncommitted `logger::debug(fmt, ...)`
(`logger::debug` takes a single `std::string` here), then their commit of it.
`tools/verify_in_worktree.py` exists because of that: it mirrors only the files
a change touches into a sibling worktree at a green HEAD and runs the real
build there — a read-only copy, no edit of their file — which verified this
change while their tree was red. Separately, one line of this change
(`EspModule.cpp`'s call site) reached master **inside another session's
commit** (`63c19fac1`, the use-after-move fix) by whole-file staging. That is
the hazard AGENTS.md already documents; nothing was lost, and it is recorded
here rather than by rewriting shared history.

**NOT CLAIMED. No in-game run.** That a click now moves the right loot is
argued from the code and from 120 harness assertions, not measured in a raid.
Build: exit 0, 0 errors, 0 first-party warnings. pytest: 533 passed, 23
subtests, 1 failed (`hwid_check`, pre-existing and owned elsewhere). Harness:
21 cases, exit 0.

### 0.68 Static markers and labels on the radar — the last planned asset step

The third item of the bigmap plan's part 3, and the last one that needs no new
module. **242 static markers and 270 labels now draw on the radar**, merged from
the DynamicMaps submodule: locked doors (yellow), switches (teal) and secrets
(violet), with place names in dim grey behind them. Two checkboxes on the
Minimap card, both default off like every other radar extra, with keys in all 19
locales.

**What was not merged, and why that is the important half.** DynamicMaps also
carries 117 Extract and 25 Transit markers. Those are exactly what this project
already reads *live* — the exfil/transit scan — and a static copy desyncs from
eligibility the first time a raid's state changes. Merging the upstream file
wholesale would have been the easy version and would have introduced a second,
silently-wrong answer to a question the live scan already answers. The
integrity test now fails if anyone ever does.

**The test caught the test.** The obvious guard for a coordinate-mapping error
is a bounds check, and it does not work: swapping the mapping's second and third
components moves each marker's `z` onto its altitude, and an altitude is a small
number that lands inside nearly every map's z range. The swapped data passed
the bounds check 12/12 during the negative control. What does catch it is the
markers' z spread against their y spread — 10–60x on correct data, inverted by a
swap. `test_marker_z_spread_is_not_an_altitude_spread` is that check, and its
docstring records that it exists because the bounds check failed the control.
That is the third time in this repository that a negative control has proved a
test was not testing what its name said.

**Two measurements that correct the plan.** The plan's "384 markers" is all
categories; the included subset is 242 once the source's `Locked Door` spelling
is normalised. And the plan's own list of what needs measuring ("whether
Streets' 42 markers plus 46 labels are too dense to read") is still unmeasured
— the count is known, the readability is not.

**NOT CLAIMED. No in-game run.** Build-verified: clean `Prod|x64` build + link,
exit 0, 0 errors, 0 first-party warnings; `audit_config_pointers.py` exit 0
(the two new checkboxes — its pointer and header counts are re-derived on every
run by `tools/tests/test_doc_counts.py`, which is why they are not quoted in a
dated section: they were already stale the moment this line was written).
pytest: 538 passed, 6
skipped, 23 subtests, 2 failed — both pre-existing and owned elsewhere
(`hwid_check`'s blank slot, `map_icf`'s figures against a `.map` another
session keeps rebuilding). The integrity suite gained five cases, 13 total.
Nothing here has been looked at on a live radar.
### 0.69 The item spawn dropped the item after creating it, because this path had its own copy of the placement loop

The report: **"searching (and selecting) still doesn't allow spawning items into
inventory."** The deployed log answers half of it on its own:

```
DEBUG  Created Item: 5734758f24597738025ee253      <- three times
DEBUG  Placed Item                                  <- never
```

So the search works. A real template id reaches `GetPresetItem` three times,
which means `item_id` is filled by the search's click and the factory resolves.
The item is **created**, and then dropped — the report is exactly right.

**What the log could not say is which of four silent failures it was**, and
reading the branch found the defect rather than a cause: this path carries its
own hand-rolled copy of a loop `ItemModule.h` already provides as
`place_item_in_grids()`. The copy is worse than the original twice over — it
indexes element `[0]` of `Grids` on every iteration, so a container with several
grids only ever offers its first, and it dereferences `Grids` with no null check.
The duplication is also *why* it drifted: `spawn_quest_item` has always used the
shared helper, and this one quietly diverged from it.

**And the chosen slot was the whole answer rather than the first choice.** The
default target is the backpack, so an empty slot — no backpack equipped, or one
with no room for this item — dropped the item *after* `GetPresetItem` had already
created it. Three clicks, three orphaned items in the game's hands, and a player
with nothing on screen to say so.

Now one implementation (the shared helper), the chosen slot first, then the rest
of the gear — backpack, rig, secure container, pockets, the same list
`spawn_quest_item` already walks — and every step logging which one it was.

**The slot mapping was checked against the dump before touching any of it:** the
mod's combo order matches EFT's `EquipmentSlot` enum exactly, 4 is `Backpack`,
and `Equipment.GetSlot(EquipmentSlot)` is the signature the call uses. The
ordering was never the problem.

**Verified in a worktree, again.** The main tree was red for another session
(uncommitted `ChamsModule.cpp`, case labels outside a switch), so this file was
mirrored alone into a sibling worktree at the committed HEAD and built there with
its own SLOT — exit 0, 0 compiler/linker errors, and the only warnings the three
AGENTS.md already names (`Zydis.h` C4005, Bypass's `injector.cpp` C4312 /
`spoofer.cpp` C4200).

**Two gaps in the same path, named and NOT fixed here**, because both are
behaviour changes that want the next log rather than a guess: `Create` silently
does nothing when `is_in_raid` is false (no message, no disabled state), and an
empty `item_id` is equally silent.

**NOT CLAIMED: no in-game run.** That the slot was empty is now the most likely
reading of the old silence — which is what the new lines exist to confirm or
refute.
### 0.70 Drop in the world, and the crash question answered honestly

**"Could the created-and-never-placed items have caused the crash?"** The
evidence, in full, because the answer is *not proven* and saying so matters
more than a tidy theory:

- The deployed log shows **three `Created Item`** calls (21:38:51, 21:39:01 ×2)
  with **no `Placed Item`** — orphans, exactly as diagnosed in §0.69.
- The FATAL is `0xC0000005 ACCESS_VIOLATION WRITE of 0x10` — a **null `this`
  dereference inside a managed method**, i.e. an instance call on a null
  receiver. Our code makes such calls; the game makes millions.
- It fired on `tid=5732`, the **same thread** as the spawn, **4½ minutes after
  the last one**.
- The crash probe captured **no frame of ours** in 2048 words of stack, and
  says so itself ("our code is either genuinely absent, or sits deeper than
  the scan reached and this report cannot tell which").
- The session also threw **1590 C++ exceptions**, so this process was throwing
  constantly with or without us.

**What the old code did contain** is one call of exactly that shape:
`GetSlot` was dereferenced without a null check before `get_ContainedItem` was
invoked on its result — a managed call on a null `this`, the same WRITE of
0x10. That is now guarded (and it cannot have been *this* crash, because a null
slot would have crashed on the first press, not on the fourth and not four
minutes later).

**What is now closed regardless:** no orphan is silent any more, the world-drop
gives a placement that cannot run out of room, and the one remaining failure
path logs the item id.

**The feature.** A `Drop mode` selector on the Item Spawner card — *Into gear*
(the unchanged default), *At my feet*, *In front of me* — going through the
game's own `GameWorld.ThrowItem(Item, IPlayer, Vector3 position, Quaternion
rotation, Vector3 velocity, Vector3 angularVelocity, syncable,
performPickUpValidation, makeVisibleAfterDelay)`, so the loot entity, its view
and its pickup validation are the game's rather than an entity we compose.

**Two deliberate choices, both recorded in the code.** The position comes from
the player's own transform rather than the camera: the camera resolver is
render-thread-cached (the note in `eft_api::resolve_esp_camera` explains why
that cache exists) and this runs on the game thread, so reading it here would
race with the ESP. And the throw goes through `call_or()`, the fail-closed
wrapper, because a bare `get_method("ThrowItem", 9)` that fails to resolve is a
call through address zero — the shape that killed this process on 2026-10-04.

**NOT CLAIMED. No in-game run.** That `ThrowItem` accepts these arguments and
that a 2.5 m drop lands somewhere sane is what the next raid has to show; the
build proves it compiles and links, which is all a compile can prove.
### 0.71 The changed-from-default dot moves to the label line

The gutter dot that marks a setting as changed from its default has been in the
wrong place three times, and the report that prompted this one — "still off the
center on multi-line widgets" — is the reason it took three.

Each earlier version picked a **function of the row's height**: first the row's
top edge, then the row's centre. In this menu the row height is *content*, not
layout. A slider row is two lines; `ItemSearchValue`'s row grows with the number
of search results you typed. So a height-derived dot is a function of content,
and it slides down while the user is reading the label it annotates — which is
the same defect wearing three different coordinates.

The dot is now centred on the **label line** (`ImGui::GetFrameHeight()`, which is
exactly a label's line box because every label in the menu is drawn with
`AlignTextToFramePadding`), so its position depends only on the label. For a
one-line row the two expressions are identical, which is why this is invisible on
the majority of rows: every checkbox and textbox draws its dot where it always
did. It is also not flush to the row's top edge, which was the first attempt —
half a line above the label's optical centre reads as a mis-registered element
rather than as a badge.

The **hit target** moves with it, and that was a second, quieter bug: it was
`min(row_h, 18*sf)`, so on a 200px search row the gutter became a 200px
invisible button whose "click to reset" tooltip appeared beside an empty results
list.

The arithmetic is `gui/menu/changed_marker_layout.h`, its own header for the
reason `quick_search.h` and `column_layout.h` are theirs: `menu.cpp` cannot be
linked by any test, so inline code could only ever be tested through a copy.
`test_changed_marker_layout.cpp` (20 assertions) pins the load-bearing claim —
`dot_y` is **identical** for a 1-line, 2-line and 200px row — and states the
rejected row-centred position as a distance (~90px) rather than an adjective.
Three of `negctl.py`'s thirteen controls are one per position the header rejects,
each failing the case by name.

Build-verified: full `Prod|x64`, exit 0, 0 errors, 0 first-party warnings, and
the artefact confirmed newer than the edit. Harness 22 cases exit 0. pytest 544
passed, 23 subtests, 1 failed — `hwid_check`, the pre-existing documented one.
