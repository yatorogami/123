# Loot Teleport — Container Support Plan

## Goal

Extend the loot teleport feature so it can also teleport items **inside LootableContainer objects** (safes, crates, duffel bags, weapon boxes, etc.), not just loose ground loot.

## Background

| Aspect | Current state |
|---|---|
| **Teleport trigger** | `WorldModule::loot_to_me_impl(filter)` — action-button driven, not per-frame |
| **Loose loot source** | `GameWorld.LootItems` (DictionaryListHydra) + `GameWorld.QuestItemsList` (quest filter only) |
| **What gets moved** | Each `LootItem`'s **transform** — the world-space position of the loose loot wrapper |
| **Filter** | `LootTeleportModule::matches_filter` → `item_categories::matches_teleport_filter` (template-id based) |
| **Container enumeration** | Already done by ChamsModule and EspModule via `unity::find_objects_of_type` |
| **Container item reading** | Already done by `eft_api::collect_compound_items_recursive` (grids + slots, depth-capped) |
| **Item creation in world** | Already wrapped by `ItemModule::throw_item_in_world` (calls `GameWorld.ThrowItem`) |

## The Core Problem

Container items are `Item` objects (pure inventory data) with **no `LootItem` wrapper and no world transform**. The existing teleport moves `transform_set_pos` on a `LootItem` — that approach doesn't work for items that exist only inside a container's grid/slot structure.

**Solution**: For each matching container item, call `GameWorld.ThrowItem(item, player, position, ...)` to create a new `LootItem` in the world at the target position, then remove the item from the container.

## Implementation Steps

### Step 1 — Add container enumeration to WorldModule

**File**: `WorldModule.cpp` (near the existing loot teleport functions)

Add a helper that enumerates containers using the existing pattern:

```cpp
std::vector<Il2CppObject*> WorldModule::enumerate_placed_containers()
{
    std::vector<Il2CppObject*> result;
    Il2CppObject* gw_class = il2utils::get_class(game_world_instance.image(), "EFT", "GameWorld");
    Il2CppObject* container_type = il2utils::get_system_type(game_world_instance.image(),
        "EFT.Interactive", "LootableContainer");

    int found = 0;
    Il2CppObject** objects = unity::find_objects_of_type(container_type, &found);
    if (!objects) return result;

    for (int i = 0; i < found; ++i) {
        if (eft_api::is_container_actually_placed(objects[i]))
            result.push_back(objects[i]);
    }
    return result;
}
```

**Performance**: `find_objects_of_type` costs ~8 ms avg / 135 ms peak. Since teleport is action-triggered (not per-frame), this is acceptable. No caching needed for v1.

### Step 2 — Read items from each container

**File**: `WorldModule.cpp`

```cpp
std::vector<Il2CppObject*> WorldModule::collect_container_items(Il2CppObject* container)
{
    std::vector<Il2CppObject*> items;
    Il2CppObject* item_owner = eft_api::try_get_container_item_owner(container);
    if (!item_owner) return items;
    Il2CppObject* root_item = eft_api::try_get_controller_root_item(item_owner);
    if (!root_item) return items;
    eft_api::collect_compound_items_recursive(root_item, items);
    return items;
}
```

This uses the existing `collect_compound_items_recursive` which walks grids + slots recursively (depth ≤ 3, total ≤ 256 items per container).

### Step 3 — Filter container items

The existing `matches_filter` lambda in `gameworld_update` works on `LootItem*` and reads `_item` to get the template ID. For container items, we already have the `Item*` directly, so the filter logic is simpler:

```cpp
auto matches_filter_for_item = [&](Il2CppObject* item_obj) {
    const std::string template_id = eft_api::try_get_item_template_id(item_obj);
    const bool is_quest = eft_api::try_get_item_is_quest(item_obj) || 
                         eft_api::is_active_quest_item_id(template_id);
    return loot_teleport_filter_matcher_(loot_filter, template_id, {}, is_quest, 
                                          main_player.get_instance());
};
```

### Step 4 — Teleport container items via ThrowItem

**File**: `WorldModule.cpp` (inside `loot_to_me_impl`, after the loose-loot walk)

For each matching container item:

1. Compute the ring position (same ring algorithm as loose loot)
2. Call `throw_item_in_world` to create a new LootItem at that position
3. Remove the item from its container

```cpp
// After loose-loot teleport loop:

// --- Container items ---
if (loot_filter != 1) {  // quest filter only walks QuestItemsList, skip containers
    auto containers = enumerate_placed_containers();
    int container_item_index = 0;

    for (Il2CppObject* container : containers) {
        auto items = collect_container_items(container);
        // Sort by template_id for deterministic ordering
        std::sort(items.begin(), items.end(), [](Il2CppObject* a, Il2CppObject* b) {
            return eft_api::try_get_item_template_id(a) < eft_api::try_get_item_template_id(b);
        });

        for (Il2CppObject* item_obj : items) {
            if (!matches_filter_for_item(item_obj)) continue;

            // Compute ring position (same as loose loot)
            const int in_ring = container_item_index % per_ring;
            const int ring = container_item_index / per_ring;
            const float ring_r = loot_circle_radius->get_value() * (ring + 1);
            const float angle = 2.f * pi * static_cast<float>(in_ring) / static_cast<float>(per_ring);
            const unity::vector3 pos = {
                center.x + cosf(angle) * ring_r,
                center.y + loot_height_offset->get_value(),
                center.z + sinf(angle) * ring_r
            };

            // Create new LootItem in the world
            Il2CppObject* thrown = item_module_->throw_item_in_world(
                item_obj, main_player.get_instance(), pos);
            
            if (thrown) {
                // Remove from container — call the game's remove method
                // Option A: Item.Remove() — the item removes itself from its owner
                eft_api::item_remove_from_owner(item_obj);
                // Option B: container.RemoveItem(item) — if the API exists
            }

            ++container_item_index;
        }
    }
}
```

### Step 5 — Item removal from container

This is the riskiest step — the exact removal API needs verification. Options:

| Approach | API | Risk |
|---|---|---|
| **A. `Item.Remove()`** | Call the item's own `Remove()` method | Clean if the game supports self-removal; may leave container in inconsistent state |
| **B. `ItemController.RemoveItem(item)`** | Call on the container's ItemOwner | More likely correct but need to verify the method signature |
| **C. `Slot.ContainedItem = null`** | Direct field write on the slot | Bypasses game logic; may not trigger inventory update events |

**Recommendation**: Start with **Option A** (`Item.Remove()`) since it's the simplest and the game likely handles the container-side cleanup. Test thoroughly. If it crashes or leaves duplicates, fall back to Option B.

The `Item.Remove()` call pattern:
```cpp
// eft_api.h or inline:
inline void item_remove_from_owner(Il2CppObject* item) {
    static MethodInfo* remove_method = nullptr;
    if (!remove_method) {
        Il2CppClass* item_class = item->klass;
        remove_method = il2cpp_class_get_method_from_name(item_class, "Remove", 0);
    }
    if (remove_method)
        il2cpp_runtime_invoke(remove_method, item, nullptr, nullptr);
}
```

### Step 6 — Preview support

**File**: `WorldModule.cpp` — `refresh_loot_teleport_preview`

The preview currently shows a count of matching loose loot. Add container items to the count:

```cpp
// In refresh_loot_teleport_preview, after counting loose loot:
if (loot_filter != 1) {
    auto containers = enumerate_placed_containers();
    for (auto* container : containers) {
        auto items = collect_container_items(container);
        for (auto* item : items) {
            if (matches_filter_for_item(item))
                ++preview_count;
        }
    }
}
```

### Step 7 — UI label update

**File**: `LootTeleportModule.cpp`

Update the button labels / descriptions to indicate containers are included:

- Change "Teleport All Loot" → "Teleport All Loot + Containers" (or similar)
- Update any tooltip/description text

### Step 8 — Configuration (optional)

Add a config option to toggle container teleport independently:

**File**: `LootTeleportModule.h` / `.cpp`

```cpp
ConfigValue<bool> teleport_from_containers{ this, "Teleport From Containers", true };
```

When `false`, skip the container walk entirely. This gives users a fallback if container teleport causes issues.

## Files to Modify

| File | Change |
|---|---|
| `module/impl/WorldModule.h` | Add `enumerate_placed_containers`, `collect_container_items` declarations |
| `module/impl/WorldModule.cpp` | Add container enumeration + item reading + teleport logic in `loot_to_me_impl`; update `refresh_loot_teleport_preview` |
| `module/impl/LootTeleportModule.h` | Add `teleport_from_containers` config toggle |
| `module/impl/LootTeleportModule.cpp` | Update button labels; wire config toggle |
| `eft_api.h` | Add `item_remove_from_owner` helper (if not already present) |

## Testing Checklist

- [ ] Teleport with filter=All (0) moves loose loot **and** container items
- [ ] Teleport with filter=Quest (1) does NOT touch containers (quest filter is special)
- [ ] Teleport with filter=Category (4) only moves matching container items
- [ ] Teleport with filter=Wishlist (5) only moves matching container items
- [ ] Container items appear in rings around the player, not stacked at one point
- [ ] Original container item is removed after teleport (no duplicates)
- [ ] Preview count includes container items
- [ ] No crashes when containers are empty
- [ ] No crashes when containers have nested containers (depth limit respected)
- [ ] Ghost containers (unrolled prefabs) are skipped
- [ ] Performance: teleport with many containers completes in reasonable time (< 2 s)

## Open Questions

1. **Item removal API** — Does `Item.Remove()` work correctly, or do we need `ItemController.RemoveItem`? Needs in-game testing.
2. **Container item ownership** — Some container items may be "locked" (e.g., quest items that can't be removed). Need to handle removal failure gracefully.
3. **Stack count** — `ThrowItem` with a stackable item: does it respect the stack count, or does it throw a single unit? May need to handle stack splitting.
4. **Performance with many containers** — Maps like Streets of Tarkov may have 50+ containers. If teleport takes too slow, consider caching the container list on a slow clock.

## Estimated Complexity

| Component | Effort |
|---|---|
| Container enumeration | Low (copy existing pattern) |
| Container item reading | Low (use existing `collect_compound_items_recursive`) |
| Filter adaptation | Low |
| ThrowItem teleport | Medium (need to verify throw_item_in_world signature) |
| Item removal | Medium-High (API verification needed) |
| Preview update | Low |
| Config toggle | Low |
| Testing | High (many edge cases) |

**Overall**: Medium. The building blocks all exist. The main risk is the item-removal API and ensuring the game state stays consistent after removal.
