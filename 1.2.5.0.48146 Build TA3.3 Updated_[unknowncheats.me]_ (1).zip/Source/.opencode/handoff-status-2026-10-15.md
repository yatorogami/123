# Handoff status — 2026-10-15 (after the 2026-10-14 raid)

Everything below is a *current* statement. Superseded readings are named as such
rather than deleted, because the reason each one was wrong is the part that
stops the next reader re-deriving it.

## What the raid answered (the log did most of this work)

| question | answer | evidence |
|---|---|---|
| where does the catalogue's 1,016 ms go? | **census 812 ms + liveness 938 ms** of 1,750 ms total. `resolve`/`enum`/`names` are ~0. | `material-catalog: OK rows=2783 ... phase_ms[resolve=0 enum=0 census=812 liveness=938 names=0]` |
| is `rows` a real material count? | **managed-only.** `objects_all=2,521,867` — the Object census is ~900x larger, so the 2,783 is a thin slice. `native_coverage=unmeasured` is now printed. | same line |
| do the radar markers land on the right doors? | **No — 0 of 34 within 2 m, worst 229.9 m.** And they did not draw at all. | `marker-door: map=bigmap markers=34 doors=220 within_2m=0 within_5m=1 unmatched=0 worst=229.9m` |
| do beacon `zoneIds` name cached triggers? | **No.** `found=0` for every id (`ter_013_area_1..4`, `place_THX_15`). | `quest esp: place condition ConditionPlaceBeacon zoneIds=1 id=ter_013_area_1 found=0` |
| did the visibility walk run that session? | **No rays at all.** `vis-breakdown: total=0 ... [closed] | mask=16`, every window. The InteractiveMask/LootCollisionMask question is **still open** — the session had skeleton vis closed. | every `vis-breakdown` line in pid 10496 |
| is the `0x1A237F8` optics literal rotting? | No evidence it is. Zero `why =` strings, 9 `optic-route: accepted`. Still one data point on one build; the negative control (a session where optics visibly failed) has still not been captured. | pid 10496 |

## Three live bugs, found by the user in game, now fixed (`b00feab03`)

1. **Radar markers invisible (Customs).** `read_dynamic_maps_position` swapped
   y/z. DynamicMaps writes Unity order (x=worldX, **y=altitude**, z=worldZ) —
   proven from the shipped data (y spread 21 m across floors, z spread 406 m
   across the map). The swap fed ground coordinates to the per-floor
   `y_min/y_max` filter, which culled all 34 Customs markers; the same line is
   what made the C4 probe report 229.9 m to the nearest door. The existing
   z-spread test read the *data* and could not see the *code*; a new mapping
   test pins the function, and its control (swap restored) goes red.
2. **Minimap never hid over the inventory.** Both screen-type queries used
   `Inventory=15 / TransferItemsInRaid=42`; **every dump on disk (seven builds)
   says 16 and 43**, and 15 is `HideoutCircleOfCultists`. New
   `test_screen_type_constants.py` re-derives from a dump when present and pins
   both call sites; control (15/42 restored) fails 2 of 4.
3. **Chams replaced the item texture.** `apply_chams_to_material` set
   `mainTexture = nullptr` unconditionally. Now carries the pre-paint material's
   texture across, and logs the bundled shader's declared properties once so
   "does it sample `_MainTex`" is measured (the `.shader` sources are not in
   the tree — the bundle is a prebuilt blob).

## Decisions taken on the user's answers

- **A5 (pen strings): unify.** The sibling sweep renders the ancestor's four
  strings. CHANGELOG §0.72 states the cost: historical logs match only the old
  wording, and a verdict no longer names which sweep stopped the round. The
  counted `pen_stop` buckets still split them. The **structural** difference
  (different variables, advance-vs-fallthrough) is deliberately untouched — that
  needs the before/after trace-dump diff no raid has produced.
- **A6 (quest cap): slider.** 24–256, default 64; `kAllQuestCap` stays the
  default the harness tests.
- **A7 (call-throughs): sweep, and it is finished.** `audit_call_through.py`
  reports **0 unguarded** (from 47). 78 resolve-only sites remain, which is a
  *review* population, not the same thing.
- **C1/C2/C4 shipped**: the phase split, the coverage label + census, and the
  marker/door probe are in the build.

## Open, and what would close it

1. **`InputTriggerIds`** — the beacon ids are now read from the iterator, but
   nothing has confirmed they match. The next raid's
   `quest esp: place triggers: input_id_triggers=... input_id_total=... sample=[...]`
   is the answer. If the sample looks like `ter_013_area_*`, the chain is closed;
   if it is empty, the property path failed and the lead moves to the trigger
   objects' own fields.
2. **The catalogue's cost is now attributable and still fatal to the clock.**
   census + liveness is 1,750 ms on one game-thread frame. Neither is safe on
   the 2 s/15 s container clock as written. The liveness memo already exists
   (`unity::is_unity_object_alive`); the census is `FindObjectsOfTypeAll` over
   2.5 M objects and is the more likely thing to break first. **Do not put this
   on any clock without measuring the split again.**
3. **The vis mask.** Untested — the session that should have answered it had
   skeleton vis closed. Needs a raid with player ESP actually resolving.
4. **Chams `_MainTex`.** The property log answers whether the carry-over can
   work at all; if the shader does not declare `_MainTex`, the fix belongs in
   the bundle and the texture carry-over is inert.

## Figures re-derived from this session's build

map_icf 104 groups / 398 first-party / 294 saved; config pointers 367/30;
dup_scan 190 files / 180 comparable (bands widened to 420–428 k); pytest 545
passed, 8 skipped, 1 failed (`hwid_check`, owned elsewhere).