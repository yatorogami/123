# Hand-off archive — answered / solved (removed from `tools/` 2026-10-14)

These six documents were removed from the shared tree because their exchange is
concluded: each was replied to or resolved, and nothing actionable remains that
is not recorded elsewhere (`AGENTS_TODO.md`, `CHANGELOG.md`,
`Workstream_status_2026-09-24.md`, or `../STATUS_ROUNDUP_2026-10-14.md` §"Items
extracted from the archived docs"). Content is verbatim; hashes match the
pre-removal tree.

| file | from → to | verdict | where the closure lives |
|---|---|---|---|
| `handoff_visibility_inside_hit.md` | markdown pass → ESP/optics, 2026-10-05 | **answered: not a bug.** `inside_hit` return-`true` is code hygiene; the reply verified all three no-patch reasons and added the "you were reading the wrong zero" correction | `AGENTS_TODO.md` "Handed off, 2026-10-04" item 3 (CLOSED); falsification of the reply's headline in `AGENTS_TODO.md`'s 2026-10-13 notes |
| `handoff_visibility_inside_hit_REPLY.md` | ESP/optics → markdown pass, 2026-10-05 | the concluding reply; flag on the visibility walk (history since the 2026-10-13 freeze lift) | same; live leftovers re-stated in the round-up's §1–3 |
| `handoff_quest_place_pois.md` | markdown pass → EspModule, 2026-10-13 | **fixed same day** once the freeze lifted: array read of `zoneIds`, one POI per id, `get_zone_id` deleted; tool now 0-unresolvable/exit 0 on both dumps | `AGENTS_TODO.md` top 2026-10-13 note; §5 premise re-stated in the round-up's §4 |
| `handoff_quest_all_cap_order.md` | quest-completer workstream, 2026-10-08 | **both defects fixed, committed, build-verified** (`3b034ece8`, `8cc6fd111`): stage marker + cap-after-collect ranking + arithmetic + cap 24→64 | commit history; §5 follow-ups re-stated in the round-up's §5 |
| `handoff_optics_memo.md` | optics workstream, 2026-10-01 | **done and measured**: `range_readable` 29.385 s → 0.092 s, `hit/miss=7942/0`; the clear-table decision taken and implemented (`clears=1`/raid) | `CHANGELOG.md` optics entries; durable warnings re-stated in the round-up's §6 |
| `handoff_exfil_overlay_and_probe_memo.md` | aimbot/pen-check → menu + eft_api owners, 2026-10-04 | **both items closed.** (1) exfil throw named (`ESP::draw_overlay` camera resolution) and contained — local catch, 0 escaping throws post-fix; the same path's null-call AV fixed in `6c8435ff`. (2) probe-memo thrashing closed as non-issue: turnover, not clustering; <1.4 s/VirtualQuery per session | `CHANGELOG.md` §0.44/§0.45; `Workstream_status_2026-09-24.md` "probe-memo, worked" |

## Why these left and the rest stayed

Left: replied/resolved **and** no live action that is not already carried
elsewhere. Stayed: `skeleton_vis_clone_merge`, `optics_instance_table_rva`,
`material_catalogue_next`, `call_through_null_crash`, `bigmap_progress`,
`hideout_premises` (all open), and the two `premises_*` records (their value is
as falsifiable claim histories, and `AGENTS_TODO.md` still marks one of their
disagreements unresolved).

One consequence to know about: `tools/tests/test_chams_scan_accounting.py`'s
documentation scan used to include `handoff_optics_memo.md`. It skips missing
files by design and its `checked > 500` guard still passes, but the scan is now
one document smaller — re-run it by hand if the `st.unpainted` retraction is
ever edited.
