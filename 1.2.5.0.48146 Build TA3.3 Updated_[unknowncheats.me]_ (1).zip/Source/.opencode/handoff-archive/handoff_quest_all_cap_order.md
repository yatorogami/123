# Quest Completer — 21 objectives silently dropped, and a cap that drops the wrong 12

**Status:** BOTH are fixed, committed and build-verified. The condition-fault *diagnostic* and
the All-view *cap ordering* and its arithmetic were all in the quest-completer workstream, and
the cap finding has been written up and then fixed here rather than left for another owner. See
§3.3 for what changed and §5 for what is still open.

Written by the quest-completer workstream, 2026-10-08. Cross-workstream in the sense that
section 3 needs a decision from whoever owns `build_snapshot()`. **I have not changed
`QuestModule.cpp`** — the cap fix belongs with whoever is already editing it.

Commits: `3b034ece8` (diagnostic), `8cc6fd111` (compile fix).
Verified: `Prod|x64` full build + link, **exit 0, 0 errors, 0 warnings**, 1 × MSB8012 (documented
benign in `AGENTS.md`), and `build.ps1`'s `FRESH` check passed — the DLL postdates the newest
source. Checked against `build_Prod_questfault.txt` directly, not inferred from the exit code.
Not yet deployed.

---

## 1. Verdict

Two independent problems, found in the same session, and it matters that they are different
shapes:

- **§2 — 21 objectives are missing from their checklists**, one per quest, silently. The quest
  still shows, still tallies, still ticks; one row is just gone. The log said
  `a condition of SideQuest threw a non-std exception while being read` and named nothing else.
- **§3 — a third of the active quest set is never read at all.** 36 listed, 24 read, 12 dropped
  by a cap whose own documented reason for existing was that dropping them in that order is the
  wrong thing to do.

Neither is a performance problem. §2 costs 21 managed throws **once per raid**, inside the single
`build_snapshot`.

## 2. The 21 dropped rows

### 2.1 What was measured

Session `pid=3036`, 2026-10-08 07:41→08:36, 9,042 log lines, **zero ERROR/FATAL**.

```
07:44:00.102  quest list: walked a fresh list, listed_quests_ now 36
07:44:00.103  quest scan: walked=68 kept(status 2|3)=36 listed=36 names=68 ... stale-unnamed=8
07:44:00.138  WARN  quest objectives: a condition of SideQuest threw a non-std exception ...
   ... 21 such lines, 07:44:00.138 -> 07:44:01.801 ...
07:44:01.801  quest build: 36 listed, 24 readable, 0 unreadable (CAPPED)
```

By class: **17 SideQuest, 2 MainQuest, 2 QuestChapter.** The latch is per *quest*, so that is 21
**distinct quests**, each losing exactly one row.

### 2.2 The correction this forces on my own earlier note

I had recorded these as "5 dormant `SideQuest`s whose conditions throw". **That is wrong for this
profile.** `0 unreadable` means all 24 quests actually read produced rows — so these are *readable*
quests with one unreadable condition each. Dormant quests produce no rows at all; these produce
most of theirs. The symptom is a missing **objective**, not a missing **quest**, and the two need
different fixes. `tools/premises_quest_completer_about_others.md` carries the same error and
wants the same correction.

### 2.3 Where the throw is — inferred, not measured

Only two of the five calls inside the per-condition guard can throw, using disassembly the file
already quotes in its own comments:

| call | evidence | can throw |
|---|---|---|
| `get_IsNecessary` | `cmp byte ptr [rcx+61h],0 / sete al` | no — field read |
| `Condition.get_value` | `movss xmm0,[rcx+28h]; ret` | no — field read |
| `text_of` | `__try`-guarded inside `write_condition_description_seh` | no |
| `IsConditionDone` | generic `Conditional<T>`, derefs `rgctx` unconditionally | **yes** |
| `get_CurrentValue` | invokes a managed `Func` delegate | **yes** |

So it is one of the last two. **This is elimination from quoted disassembly, not a measurement**,
and it is exactly the habit the fix replaces: the stage marker settles it on the next capture.

### 2.4 Why the line said nothing — three defects in ten lines

1. **The stage was destroyed one line above the log call.** `detail_stage_` names the managed
   call in flight and is set immediately before each of the five calls. Both handlers did
   `detail_stage_ = previous_stage` **before** `logger::warn` and never passed it on. The one
   field that says *which* call failed was computed and discarded. The comment above the guard
   asserted the handler gave "the condition's name AND the call that failed" — it gave neither,
   and that false claim is the reason nobody questioned it for a week.
2. **No condition class.** `condition` is in scope at both handlers; its class name is a field read.
3. **No quest id.** `quest->klass->name` is the *base* class, shared by every quest of that kind,
   so 17 lines were mutually indistinguishable.

Fourth, and separate from the message: the latch was a **function-local `static` that nothing
cleared** — a process-lifetime set keyed on an `Il2CppObject*` that dies with the raid. A quest
that began throwing in the third raid said nothing at all, and a new quest landing on a recycled
address was silent for the rest of the process. That is the same identity mistake `clear_caches()`
exists to undo for `text_cache()` and `no_row_quests()`; the set is now dropped with them.

### 2.5 What the line says now

```
quest objectives: condition read failed -- quest <template id> (<Class>), condition <CondClass>,
  stage <is_necessary|text_of|IsConditionDone|get_CurrentValue|Condition.get_value>: <detail>.
  The row is dropped; every other condition on this quest is still read.
```

The quest id is threaded down from `collect_all`, which already holds it beside the pointer —
deliberately **not** re-derived, because a managed `get_Id` inside a fault handler is a second
chance to fault on the path that just faulted once.

`detail` is one of three, and they are written to be distinguishable at a glance:

- `managed exception System.NullReferenceException: <message>` — the `Il2CppExceptionWrapper`
  clause matched;
- `an Il2CppExceptionWrapper, but no readable message on it` — it matched, payload unreadable;
- `non-std exception, and the payload was not an Il2CppExceptionWrapper -- so the managed type
  and message are unavailable here` — **it did not match.**

The third is the built-in negative control. **The `catch (const Il2CppExceptionWrapper&)` clause
is a hypothesis about how IL2CPP crosses into a native frame, not an established fact.** If it is
wrong, every fault lands in `catch(...)` and says so in as many words; a miss cannot be mistaken
for a hit. Reading the wrapper is `__try`-guarded, because a bad dereference there is an access
violation, which `catch(...)` does not catch under `/EHsc` — a diagnostic that can kill the game
is worse than the one it replaces.

### 2.6 Known hole, not yet closed

`resolve_up()` sets and then clears `detail_stage_`. `is_necessary()` and `condition_value()` call
it *after* setting their own marker, so a throw in either would report `stage (unset)`. They are
the two field reads and so the least likely place — but the marker should be sound rather than
explained afterwards. One `detail_stage_ = "..."` immediately before each `methodPointer` call,
matching what `is_done()` and `current_value()` already do.

### 2.7 What the next capture must show, and what would falsify this

- **21 lines with a real stage** → the diagnosis works; §2.3 is settled by the stage column.
- **21 lines reading `stage (unset)`** → something is throwing outside the five marked calls,
  which would falsify the table in §2.3 and mean the marker is incomplete (§2.6 is then urgent,
  not cosmetic).
- **Every line saying the payload was not an `Il2CppExceptionWrapper`** → the managed-message
  clause is dead weight and should be deleted rather than left in as a comment.
- **Fewer than 21** → either the profile differs or `no_row_quests()` is now skipping quests it
  should not; check `quest build:` first, because it is the line that counts.

## 3. The cap drops 12 quests in the order the comment says is wrong

**This is the item for `QuestModule.cpp`'s owner.**

`quest_objectives.h:1083` states the cap is deliberately **not** applied in `collect_all`, and
gives the reason:

> It used to stop at `kAllQuestCap` quests **in the order they were passed in. That order was the
> DROPDOWN's, which is the profile's quest order rather than the map's — so on a map with 14
> location-bound quests the cap kept twelve that cannot be done here and dropped the ones that
> can. A cap that picks the wrong quests is worse than no cap, because the player cannot tell it
> truncated.**

`QuestModule.cpp:1782` then does exactly that, one layer up:

```cpp
for (const listed_quest& listed : listed_quests_)
    all_quest_inputs_.emplace_back(listed.id, listed.quest);
...
if (all_quest_inputs_.size() > quest_objectives::kAllQuestCap) {
    all_quest_inputs_.resize(quest_objectives::kAllQuestCap);   // first 24 in profile order
```

The ordering claim is checkable and holds: `listed_quests_` is filled inside the `_questsData`
walk (`QuestModule.cpp:1047`, `:1139`), and `draw_overlay` iterates `list->size()` in that same
order (`:774`), so `all_quest_inputs_` order **is** the dropdown order **is** the profile's quest
order. `resize(24)` drops the tail twelve by exactly the order the comment rejects.

Two further consequences:

- The `resize` runs **before** `collect_all`, so `location_binding_of()` never sees the other
  twelve and the grouping that is supposed to decide what is shown first has nothing to rank.
- `kAllQuestCap`'s own comment says 24 "was chosen to be above anything observed, so hitting it
  means the shape of the data changed rather than that a raid was busy." It bit on the first
  profile measured with more than 24 active quests: **36 listed, 24 read, 12 never examined.**

### 3.1 Suggested shape, not a patch

Apply the cap **after** `collect_all`, ranking so location-bound quests survive —
`quest_group::known` is already computed per group and is the signal the file's grouping was
built for. Keep `next->all_requested` as the **pre-cap** count or `quest_obj_all_capped`'s
"Showing {} of {} quests" loses its denominator, since it is set at `:1777`, before the resize.

Worth a decision rather than a default: with 36 active quests, is a 24-quest "All" view the right
product at all, or should the cap only bind as the backstop its comment claims to be?

### 3.2 Why I did not just fix it — superseded, see §3.3

`QuestModule.cpp` had another agent's uncommitted edits at the time this was written. Editing it
mid-flight risks a lost change, and `AGENTS.md` is explicit that the branch and tree are shared.
That agent has since committed (`5fa72be64`), so the obstacle was only ever procedural.

### 3.3 What I changed

Three defects, all in `build_snapshot()` plus the two headers it leans on. **There were three,
not one** — the shortfall arithmetic was wrong independently of the ordering, and finding the
ordering bug led to the second.

**1. The cap no longer picks quests.** `all_quest_inputs_.resize(kAllQuestCap)` is gone. The cap
is applied after `collect_all()`, to groups that have already been through
`location_binding_of()`, ranked by a new `all_view_rank()` before truncation.

**The ranking decision, because it is a decision and not a derivation.** Rank order is *the order
the card already renders*: anywhere → zones → unreadable. Lower rank is drawn first, so
truncating by rank drops **from the bottom of what the player reads**, and a cap that ate the
middle would be a new bug of the same shape.

`quest_objectives.h`'s `collect_all()` comment argues the opposite — keep the quests that "can be
done here", i.e. the location-bound ones. **I did not follow it, and here is why.** That argument
needs to decide whether a quest's zone belongs to *this* map, and `location_binding_of()`'s own
comment says that requires the game's zone-to-map table and that guessing "would put quests in
the wrong group". Ranking on a distinction the file documents as unusable for exactly this
purpose is acting on a signal that is not there. A non-location-bound quest is doable *somewhere*
with no further information; a location-bound one *might* be doable here. Rank 0 is the one that
is a real answer rather than an unknown. The comment is left in place, unamended, so the
disagreement is visible to whoever owns the product call.

**2. The arithmetic was a third, separate bug.** `all_unreadable` was computed as
`requested - kAllQuestCap - shown`, but the cap dropped `requested - kAllQuestCap` quests, not
`kAllQuestCap` of them. On the 2026-10-08 profile that is `36 - 24 - 24 = -12`, clamped to 0 —
right only because those quests genuinely were all readable. With 4 unreadable quests it reads
`36 - 24 - 20 = -8`, clamps, and prints **0 when the answer is 4**. The comment directly above
that line described fixing this exact bug once already; the fix reintroduced it in the same edit.
Now `requested = shown + capped_away + unreadable`, with `capped_away` the number actually
dropped.

**3. The cap is raised 24 → 64.** Its premise had expired: it existed to bound a 300 ms-throttled
*per-publish* scan, and there is no per-publish scan — `build_snapshot()` runs once at raid
entrance with `text_cache()` memoising each condition for the raid. 36 active quests is a normal
late-wipe profile, so 24 was no longer "above anything observed" as its comment claimed. **This
is a judgement call and it is the reversible part.** If a real profile reaches 64, the answer is
to measure `collect_all()`'s per-quest cost, not to raise the constant again.

**And it is now checkable, which it was not.** The arithmetic and the ranking moved into
`quest_objective_text.h` — the one of the two quest headers with no IL2CPP in it, and therefore
the only one `tools/harness/test_quest_objectives_text.cpp` can compile. 15 new assertions.

**Negative control, run:** substituting the shipped `requested - shown - 24` expression and
inverting `all_view_rank` turns the harness red with **exit 1 and 9 named failures**, including
`capped AND unreadable: 36 listed, 20 shown, 12 capped away -> 4 unreadable, not 0`. So the
discriminating case genuinely discriminates. Reverted; harness back to exit 0, 197/197.

## 4. Incidental

- **`quest_objectives::summarise()` has no callers.** `rg` finds the definition and nothing else.
  It is not dead by accident — `AGENTS_TODO.md` records it being called with the wrong arity once
  — but it is dead now, and it is the one place that would still call `collect()` without a
  quest id, so a fault through it would fall back to the base-class name. Left in place: deleting
  it is a separate call, not a side effect of this work.
- The 647-quest walk is unchanged. On this profile the walk saw **68** quests and kept 36, so the
  `walked=647` figure in the older notes is profile-specific, not a property of the code.

## 5. Still open

1. **§2.6's marker hole is closed but untested at runtime.** `get_IsNecessary` and
   `Condition.get_value` now set `detail_stage_` after `resolve_up()` rather than before. There
   is no way to unit-test this — it needs a live IL2CPP object — so it rests on reading the code,
   and the next capture is the only check. A `stage (unset)` line would mean it is not enough.
2. **The `Il2CppExceptionWrapper` clause is still an unverified hypothesis.** §2.5/§2.7 stand.
3. **`all_view_rank` is a product decision, not a derived answer** — §3.3 explains why it went the
   other way from the comment it contradicts. If the intent is that location-bound quests are the
   valuable ones, the ranking inverts and the harness's ordering assertions must invert with it.
4. **64 is a guess with a stated basis.** §3.3. A profile that reaches it is the trigger to
   measure, not to raise it again.

## Provenance

- Log: `C:\Battlestate Games\BsgLauncher\tarkovaddons_log.txt`, session `pid=3036`,
  2026-10-08 07:41:13 → 08:36:52. Copied aside at the time of reading.
- Build: `tools\build.ps1 -Slot questfault -Wait`, `Prod|x64`, exit 0, 0 errors, 0 warnings.
  Build log `build_Prod_questfault.txt`; 0/0 confirmed by counting `error C\d|error LNK\d|error
  MSB\d` and `warning C\d` in it, not by trusting the exit code.
- No runtime capture yet: **the improved line has not been seen in a log.** Everything in §2.5 is
  a claim about what it will print, not an observation that it did.