# Handoff: `vis_exit::inside_hit` in `is_target_visible` returns "visible"

**To:** the ESP / optics workstream (owner of `skeleton_visibility.h`)
**From:** markdown-and-verification pass, 2026-10-05
**Status:** reported, not touched. I have changed nothing in your files.
**Precedent:** `CHANGELOG.md` §0.53 already flagged this — *"A SECOND INSTANCE,
FOUND BY THE TEST, NOT YET FIXED... Reported, not touched."* This memo does not
discover it. What it adds is the measurement that decides how urgent it is, and
an argument that the pen-walk fix does **not** transfer.

---

## The item

`TarkovAddons/module/skeleton_visibility.h:2258`, inside `is_target_visible`:

```cpp
if (hit.m_distance < 0.05f || unity::length(hit.m_normal) < 0.1f) {
    ++g_vis_exit_counts()[static_cast<int>(vis_exit::inside_hit)];
    return true;                      // <- "visible"
}
```

A ray that terminates within 5 cm of its origin, or returns a degenerate normal,
is reported as **the target is visible**. The walk did not verify that.

The byte-identical test at `:2720` in the pen walk (`is_target_visible_penetrating`)
was fixed on 2026-10-04: it now records `pen_stop::origin_in_mesh` and returns
`finish(false, ...)`, because that walk was returning **PENETRABLE** from 82 uses
of the exit on the 23:14 Factory log — 76 of them — an unverified pass.

---

## Why I did not simply apply the same fix, which is the reason to read this

The two functions look identical and are not, in three ways that matter. I checked
each rather than assuming.

**1. The pen walk's origin is not `is_target_visible`'s origin.** This is the
substantive difference, and it is checkable: `is_target_visible`'s body spans
`:2224`-`:2300` and contains **no** `step_past` and **no** `kLayerEps` — verified
mechanically, not by reading. The pen walk calls `step_past()`, advancing the ray
by `hit.m_distance + kLayerEps` after every layer (`:2798`, `:2832`, `:2952`,
`:3169`, and four more). So its `inside_hit` fires on an origin that came to rest
**one epsilon past a surface the walk already crossed** — which is why the two
logged examples had both already graded and passed a layer, and why one of them
was the target's own skull at 6.88 m.

`is_target_visible` casts **once**, from the origin it is handed to the bone, and
never advances. So this exit means something different here, and `CHANGELOG.md`
§0.9 already worked out what: *"under 0.05 m would have taken the `inside_hit`
exit instead, so a small value means **our own collider, the camera is inside
it**, and a large one means real geometry."* That is a different physical
situation from the pen walk's crossed-surface epsilon, and it points at a
different candidate cause — the ray origin being inside the **shooter's** mesh,
not the target being near the camera.

That also corrects the obvious reading. "A bone within 5 cm of the camera" sounds
impossible at a 200 m `skeleton_distance` default, and it is — but that is not why
this exit is quiet, because the distance being measured is from the *ray origin*,
and the origin is the camera.

**2. The conservative direction is opposite.** This is the one that stops me being
able to hand you a patch. In the pen walk, `finish(false, ...)` means *"do not
claim the shot penetrates"* — refusing to assert. In `is_target_visible`,
`return true` means **"visible"**, and the function is on ESP's draw path. So:

| | pen walk | `is_target_visible` |
|---|---|---|
| return means | penetration asserted | target visible |
| refusing to assert | `false` (safe) | `true` — **claims visible** |
| so the conservative choice is | `false` | **`false`** |

Returning `false` here would make the ESP *hide* skeletons it currently draws.
That is a visible behaviour change to a live draw path, and it is a product
decision, not a bug fix. It is also the opposite of what §0.53's one-liner
("Same false pass, different workstream") implies.

Traced to confirm this is a real lever rather than a discarded return:
`EspModule.cpp:1150` assigns it to `entry.link_visible[i]`, i.e. it **is** the
per-link draw state, and `:1144`-`:1152` caches it per bone per frame. It is also
the return value of the helper at `:528`/`:529`, which feeds the whole-skeleton
fallback. Nothing between the exit and the draw discards or defaults it.

**3. It may not be reachable at all.** `inside_hit` has measured **zero** in every
full-raid window recorded in this repository:

| window | rays | `inside_hit` |
|---|---|---|
| `+6` complete raid | 2,417,604 | **0** |
| eight 30 s windows | 2,755,305 | **0** |
| `no_transform` (the adjacent exit) | — | **0** as well |

**5,172,909 rays, never once.** The `vis-breakdown` line is already printed every
30 s and already prints `inside_hit=`, so this is measured, not inferred.

So the honest summary: **an unverified pass on an exit that has never fired in
5.2 M rays.** That is a very different priority from the pen walk's 76-in-82. It
is still a latent defect — the guard exists for a reason, and the reason is
presumably that it *has* fired, or that someone expected it to — but on current
evidence nothing observable is wrong today.

---

## What would settle it, and it is one log line

**`inside_hit=` in a `vis-breakdown` window.** If it is non-zero, this is live and
urgent. If it stays zero across a long raid, the item is a code-hygiene fix to
schedule rather than a defect to chase.

Two things would make that line decisive, and both are small:

- **A raid ~10 % longer than the ones recorded.** `vis-breakdown` is throttled to
  30 s and `gameworld_update` only runs once a `GameWorld` exists; three sessions
  printed it zero times for exactly that reason (`CHANGELOG.md` §0.12, §0.13).
  The existing windows are the ones that cleared the threshold, so they are
  biased *toward* having data — which makes the 0 firings more meaningful than the
  sample count suggests.
- **If you want it settled without a raid**, the interesting case is not the
  target but the **origin**. §0.9's reading is that a small `dist` here means the
  ray origin is inside a collider — and the camera sits inside the shooter's own
  colliders, which §0.9 also notes means "there is something to hit on every ray".
  So this exit is quiet because the occlusion mask keeps the camera out of most of
  its own geometry, not because the situation is impossible. Adding `dist` to the
  `inside_hit` trace costs one float and turns "has never fired" from an
  observation into an explained fact. **Note that `dist` has existed in
  `vis-diag-occluder`'s sample output before and was explicitly called out as the
  field that separates the two candidate causes** — so this is reusing a
  distinction the investigation already defined, not inventing an instrument.

**Note that `vis-diag-occluder` already did this and was retired.** §0.21
records that probe returning 12 of 12 confident `WALK-FAILED` verdicts against a
control panel, because its `name_looks_player_owned` pattern treated
`_BALLISTIC_` as a player marker when it is only EFT's material suffix on any
ballistic collider. So "add a bounded diagnostic to this walk" has a recent,
specific history here of producing confident wrong answers. That is an argument
for using the counter that is **already there** rather than adding an instrument,
and it is why I have not proposed a probe.

---

## What I would *not* do

- **Do not copy `finish(false, ...)` semantics across.** As above: it hides
  skeletons. If that is what you want, it is a decision to make deliberately,
  with the visible consequence stated, not a bug fix.
- **Do not treat §0.53's "same false pass" as settled.** It is the same *shape*;
  whether it is the same *defect* depends on whether this exit can fire at all,
  and the measurement says it has not.
- **Do not let `test_pen_degenerate_origin.py` be read as covering this.** Its
  locator had to anchor on a note string because the expression appears twice;
  §0.53 says so. If you fix this, that test's locator will want revisiting, and
  the fix should be checked against it deliberately rather than by accident.

---

## My premises, and what would falsify each

I am writing about your module from outside it, so these are premises, not
findings. `tools/premises_about_other_workstreams.md` is the precedent for this
format and for recording the limits.

| my premise | evidence | what would falsify it |
|---|---|---|
| `is_target_visible` casts once and never calls `step_past` | mechanical check: body is `:2224`-`:2300`, contains no `step_past` and no `kLayerEps`; every advance in the file is inside the pen walk | a `step_past` call inside `is_target_visible` I did not see |
| `inside_hit` is unreachable in normal play so far | 0 across 5,172,909 rays in the recorded windows | any `vis-breakdown` window with `inside_hit > 0` |
| `return true` here is a visible-behaviour lever, not a pure fix | traced: `EspModule.cpp:1150` assigns it to `entry.link_visible[i]`, the per-link draw state, cached per bone per frame at `:1144`-`:1152`; also the return of the `:528`/`:529` helper | showing any caller discards or defaults the result |
| the pen walk's diagnosis does not transfer | its origin is post-`step_past`, one epsilon past a crossed surface; this one is not | evidence that this function's `origin` parameter is itself an already-advanced origin |
| the quiet exit is about the origin, not the target | §0.9's own note: small `dist` = "our own collider, the camera is inside it"; and the camera sits inside the shooter's colliders | a session showing `inside_hit` with `dist` ≈ camera-to-bone distance |

**What I do not know.** Whether `inside_hit` ever fired in a session nobody
captured. Whether the `0.05f` threshold was chosen from an observation or copied
from the pen walk — if copied, the author may have intended the same behaviour
here, which would make this a deliberate-and-forgotten rather than a defect. And
whether the skeleton draw path would look wrong with the opposite return; that
needs someone who can watch it.

---

## Why this is a handoff and not a fix

`AGENTS_TODO.md` §3.2 freezes the ESP/optics surface: *"DEFERRED, DO NOT TOUCH"*,
7 `[CLEANUP-PENDING:OPTICS]` markers across `EspModule.h`, `esp_text.h`,
`quest_esp.h`, `skeleton_visibility.h` and `unity.h`, because a rework is live on
another machine. `skeleton_visibility.h` is one of them.

I also fixed a bug in this repository's own files *today* by moving five
declarations in `optics_lens_pipeline.h` — and I introduced a regression in the
same hunk, a per-frame environment read, which I only caught by re-reading my own
commit afterwards. It compiled, passed every test, and was faster on the axis
being complained about. That is the base rate for confidently touching a header
you do not own on a shared tree, and it is why the cost/benefit here says report.

This file is yours to close, amend, or reject. If you disagree with the
reachability reading, the measurement in the table is the thing to check, and
`vis-breakdown` already prints it.