# Quest ESP: place objectives ("place a camera", "place a marker") can never draw a marker

> **2026-10-13 — FIXED, same day, once the freeze lifted. Not runtime-verified.**
> `process_place_condition` now reads `zoneIds` through
> `read_string_array_field` (the same shape `process_inzone_conditions` already
> used), emits one `poi_type::place` POI per id, and `get_zone_id` is deleted.
> The field defect is fixed and re-proven against **both real dumps on this
> machine**: `tools/quest_condition_fields.py` now reports
> **0 unresolvable reads, exit 0** on `GameDump/120047965` and
> `GameDump/115147510` (it read 3 / exit 1 before, on both). The tool's GATES
> table and its 15 tests were inverted with the fix — the control that used to
> prove "shipped tool fails" now proves "restoring the old field list fails",
> with the count still 3.
>
> **What is still NOT verified, and it is the one premise §5 names:** that a
> `ConditionPlaceBeacon.zoneIds[]` entry names a `PlaceItemTrigger` the cache
> holds. The new `quest esp: place condition <Class> zoneIds=<n> id=<id>
> found=<0|1>` DEBUG line (built only when `logger::debug_enabled()`, so it
> costs nothing with DEBUG off) answers it on the next raid: `found=0` for
> every id means the id names something else and `get_InputTriggerIds()` is
> the first place to look; `found=1` with nothing on screen means the draw
> path. Everything else below is the original diagnosis, kept as written.

> **2026-10-13 — the freeze blocking this is lifted.** `quest_esp.h`'s
> `[CLEANUP-PENDING:OPTICS]` marker was removed the same day, at the user's
> instruction, so reason (1) in §6 for not patching no longer applies. Reason
> (2) — the §5 premise that still needs a raid to confirm — is unchanged. The
> fix itself was deliberately **not** applied: the instruction was to remove the
> freeze, nothing more.

**Status: diagnosed, not fixed, not runtime-verified.** The field-read defect is
proven against two real game builds (§3). The one premise a raid has to confirm
is in §5 and it is marked as unverified, because confirming it needs the game and
this machine does not have it.

Written 2026-10-13. **I have not changed `quest_esp.h`.** Two reasons, both in
§6: the file is under the `[CLEANUP-PENDING:OPTICS]` freeze, and the fix's
correctness depends on a runtime claim that has not been checked.

---

## 1. Verdict

`poi_type::place` markers are **never emitted**. Not "sometimes", not "for some
maps" — on any quest, in any raid, on both game builds in `TarkovAddons/GameDump/`.

One line gates it, and it looks for a field name that does not exist on any class
it is ever handed:

```cpp
// TarkovAddons/module/quest_esp.h:773
static const char* zone_fields[] = {"zoneId", "zoneID", "ZoneId"};
```

The class that carries the objective has a field called **`zoneIds`** — plural,
and a `string[]`. `il2cpp_class_get_field_from_name` is an exact `strcmp`, and
`il2utils::resolve_field` (`il2utils.h:213`) walks *up* the chain but never
matches a prefix, so all three lookups miss, `get_zone_id()` returns `{}`, and
`process_place_condition` bails at `quest_esp.h:1366`:

```cpp
const std::string zone_id = get_zone_id(condition);
if (zone_id.empty()) return;          // <-- every place objective, always
```

This is **not** a game-update regression. `zoneIds` is what the field has been
called in both dumps available here (§3). The defect is in the repository's root
commit, `bb8615f18`, 2026-08-22.

This is why the report reads the way it does: the four gates that read *correct*
field names (`visit`, `inzone`, `find`, `transit`) draw the quest areas, and the
one gate that does not is exactly the one carrying the place objectives.

## 2. Scope: which objectives, and which do not

The POI pipeline has five gates. Measured against
`TarkovAddons/GameDump/1.2.0.0.47965/dump.cs`, 8 of the 65 `EFT.Quests` `Condition`
subclasses can produce a world marker. **7 of the 8 resolve their field. All 3 that
route to `place` resolve nothing.**

| gate | classes | field read | resolves |
|---|---|---|---|
| `visit` | `ConditionVisitPlace`, `ConditionLocationTrigger` | `target` (string) @0xE0 | 2/2 |
| `inzone` | `ConditionInZone` | `zoneIds` (string[]) @0xE0 | 1/1 |
| `find` | `ConditionFindItem` | `target` (string[]) @0xE0 | 1/1 |
| `transit` | `ConditionTransitionLocation` | `<MapNames>k__BackingField` @0xE0 | 1/1 |
| **`place`** | **`ConditionZone`, `ConditionPlaceBeacon`, `ConditionLeaveItemAtLocation`** | **`zoneId`\|`zoneID`\|`ZoneId`** | **0/3** |

`ConditionPlaceBeacon` is the journal's "place a beacon / marker" objective and
`ConditionLeaveItemAtLocation` is the "place an item at" one that "install a
camera" quests use. Both are `ConditionZone` subclasses, so both die at the same
line. `quest_objective_text.h`'s `plan_for()` already labels them correctly
("Place a beacon at" / "Place") — so **the Quest Completer card names these
objectives fine while the ESP cannot draw one.** That split is the clearest
single symptom to check against.

Re-derive the whole table:

```
python tools\quest_condition_fields.py TarkovAddons\GameDump\1.2.0.0.47965\dump.cs
```

Exit 1 = unresolvable reads found. `--list-uncovered` prints the 57 classes no
gate reaches, for anyone widening coverage.

## 3. What was measured, and the negative control

Tool added with this memo: **`tools/quest_condition_fields.py`**. Exit codes are
deliberate and not interchangeable — **0** clean, **1** problem found, **2**
checked nothing (missing dump, unparseable dump, or a gate whose hand-transcribed
predicate matched nothing at all).

```
1.1.5.47510   -> exit 1   65 Condition subclasses   3 unresolvable reads
1.2.0.0.47965 -> exit 1   65 Condition subclasses   3 unresolvable reads
```

Two figures, one per build, because "this is not a regression" is a claim about
both and needs both.

**Negative control, run.** Replacing the place gate's field list with the name
that exists takes the same dumps from 3 unresolvable reads / exit 1 to **0 /
exit 0**. So the tool is discriminating *this* bug, not flagging something
incidental — verified on the real dumps and pinned in
`tools/tests/test_quest_condition_fields.py::test_the_tool_separates_the_bug_from_the_fix`.

The tool was mutation-tested rather than trusted: forcing exit 0, dropping the
inheritance walk, dropping the stale-table guard, blanking the field parser, and
narrowing the class-name charset each turn the suite red; removing the cycle
guard in `ancestors()` makes it hang (exit 124), which is the intended failure
for an infinite loop.

### Why no test caught it

`tools/harness/test_quest_objectives_text.cpp` **names** `ConditionPlaceBeacon`
and `ConditionLeaveItemAtLocation` and passes — 6 assertions on `plan_for()`, the
checklist's fallback *label*. `quest_esp.h` opens with the game's object model and
cannot be compiled standalone, so the field reads these tests imply coverage of
had **no coverage at all**. This is the "shipped green while comparing nothing"
shape `AGENTS.md` records three separate tools for. The new tool is that coverage;
it needs no compiler, no game and no PDB.

## 4. The fix, in shape — not applied

The obvious one-line rename is **wrong**, and this is the trap:

- `zoneIds` is a `string[]`. `get_zone_id()` returns a single `std::string` and
  the caller emits one POI. A `ConditionZone` with three zone ids must produce
  **three** markers.
- `process_inzone_conditions` (`quest_esp.h:1258`) already does this correctly
  for `ConditionInZone`, via `read_string_array_field()` and a loop. That is the
  shape to copy — the two zone-reading paths are inconsistent today and the
  array-aware one is the correct one.

So the fix is: give `process_place_condition` the array read, iterate, and emit
one `poi_type::place` POI per id. `get_place_trigger_position()`
(`quest_esp.h:858`) already falls back to `get_BeaconDummy`, which is the right
position source for a beacon, and `full_scan_triggers()` (`:1012`) already scans
`PlaceItemTrigger` by both `get_Id` and `get_TriggerId` — so the trigger half of
the pipeline is in place and only the id lookup is missing.

Note the two `zoneIds` fields are at **different offsets**: 0xE0 on
`ConditionInZone`, 0xE8 on `ConditionZone` (which inherits `target` at 0xE0 from
`ConditionMultipleTargets`). Resolving by name handles it; any offset-based fix
would not.

**Dead code this makes visible:** the `"zoneID"` entry in `zone_fields` exists
only on `ConditionLaunchFlare` (`dump.cs:635973`), a class
`is_place_condition_type()` never matches. It is dead as written. Do not treat it
as evidence the list was once right — it suggests the list was copied from
elsewhere, not that `zoneId` ever existed.

## 5. Open: the one premise a raid has to confirm

**The fix assumes a `ConditionPlaceBeacon.zoneIds[]` entry names a
`PlaceItemTrigger` that is already in the trigger cache.** Everything supports it
and nothing proves it:

- `BeaconPlacer` holds `List<PlaceItemTrigger> _placeItemTriggers` and
  `CalculatePlaceItemTrigger()` (`dump.cs:517762`) — beacons do live at
  `PlaceItemTrigger`s.
- `PlaceItemTrigger.get_BeaconDummy()` / `SetBeaconDummy` are the placed
  position.
- `PlaceItemTrigger.TryRenameId(oldId, newId)` exists, which is how a quest's zone
  id gets attached to a trigger at runtime.

**This is circumstantial.** The next capture settles it. Add one line to
`process_place_condition` before the trigger lookup:

```
quest esp: place condition <CondClass> zoneIds=<n> id=<id> found=<0|1>
```

and read what happens. **Falsifying outcomes, and what each means:**

- `found=0` for every id → the id names something else; `get_InputTriggerIds()`
  (a property returning `IEnumerable<string>`, **not** in the trigger cache —
  `full_scan_triggers` registers `get_Id` and `get_TriggerId` only) is the first
  place to look.
- `found=1` and no marker appears → the bug is downstream, in the draw, and §2's
  table is right about the field but wrong about the consequence.
- Markers appear → done, and the premise was right.

## 6. Why this was not patched here

1. **The freeze.** `quest_esp.h:3` carries `[CLEANUP-PENDING:OPTICS] DO NOT CLEAN
   UP THIS FILE YET`, and the optics rework is live on another machine. The freeze
   text is about *removing dead code* and a functional fix is arguably outside it
   — but §4 makes this edit touch a file another machine is working in, on a
   shared branch, where `AGENTS.md` is explicit that the tree and the branch are
   shared. The §4 dead-code note is a reason to touch this file *after* optics
   lands, not before.
2. **No build, no raid.** This is a Linux host: no MSVC, no game. The change is
   small but the premise in §5 is unconfirmed, and per `AGENTS.md` "verified"
   means a full `Prod|x64` build and link plus `tools/tests` — none of which is
   available here. A commit implying verification would be a false claim.

`tools/tests` measured **499 passed, 15 skipped, 23 subtests, 4 failed** on this
tree on **Linux** at `b2538077e`, matching the figure `AGENTS.md` records for this
host; the 4 failures are the pre-existing Windows-only pair plus
`test_build_wait_watchlist`'s path-separator case and the `hwid_check` slot owned
elsewhere. Adding `tools/quest_condition_fields.py` and its 14 tests took that to
**513 passed** — no existing test changed state. Measure before quoting either
figure, per `AGENTS.md`.

## 7. Ownership

`quest_esp.h` is EspModule's territory and `quest_objectives.h` /
`quest_objective_text.h` are QuestModule's. **§1–§4 are entirely EspModule** — the
quest-completer card is *not* affected and no change is proposed in it. §5's
log line is the only thing QuestModule would need, and only if someone wants the
same evidence there.

## Provenance

- Dumps: `TarkovAddons/GameDump/{1.1.5.47510, 1.2.0.0.47965}/dump.cs`
  (gitignored; regenerate locally, never commit). `1.2.0.0.47965` is the build
  `compatibility/profiles/1.2.0.0.47965/manifest.json` describes.
- Field layouts quoted from `dump.cs` are line-anchored: `ConditionZone`
  (`zoneIds` @0xE8) at `dump.cs:636549`, `ConditionPlaceBeacon` at `:636169`,
  `ConditionLeaveItemAtLocation` at `:636005`, `ConditionLaunchFlare`
  (`zoneID` @0xE0) at `:635973`, `BeaconPlacer` at `:517762`, and
  `PlaceItemTrigger` at `:514487` (TypeDefIndex 13826).
- Code lines: `quest_esp.h:770` (`get_zone_id`), `:1366` (the bail),
  `:1374` (the only `poi_type::place` emission), `:1258` (the array-aware path to
  copy). `il2cpp/il2utils.h:213` is the exact-match chain walk.
- History: `git log -S '"zoneId", "zoneID", "ZoneId"'` returns only
  `bb8615f18`, the root commit.
- Not runtime-captured. §5 is a claim about what a log line will print, not an
  observation that it did.