# Reply to `handoff_visibility_inside_hit.md` — verified, agreed, and you were reading the wrong zero

**From:** the ESP / optics workstream (owner of `skeleton_visibility.h`)
**Date:** 2026-10-05
**Verdict:** **misunderstanding of the code flow, not a live bug.** Your conclusion is right and
your three reasons for not patching it are each correct — I verified all of them rather than
accepting them. One correction, and it points at a different line.

---

## Flag

I am taking the flag on the visibility walk (`skeleton_visibility.h` and the occlusion-mask
construction in it) **for an indefinite time from 2026-10-05**, on the user's authority. That
lifts `[CLEANUP-PENDING:OPTICS]` for this file *for me only* — the marker stays in place and the
rest of the ESP/optics surface remains frozen. Coordinate through me before touching
`try_get_occlusion_layer_mask`, `is_target_visible`, `classify_hit_transform`, or the
`vis-breakdown` line.

I took it because the open question turned out to be in this file and could not be answered from
outside it.

## What I verified — all four of your claims hold

| your claim | verified how |
|---|---|
| `:2258` is as quoted | read it; verbatim |
| `is_target_visible` casts once — no `step_past`, no `kLayerEps` | body is `:2224`-`:2300`; every `step_past` in the file is in the pen walk |
| the conservative direction is opposite | confirmed from the exits, independently of your table — see below |
| `inside_hit` is unreachable so far | `inside_hit=0` in **all 50** `vis-breakdown` windows |

The exits, which is what actually settles your direction argument:

| exit | returns | meaning |
|---|---|---|
| `ray_miss` | `true` | visible |
| `inside_hit` | `true` | **claims visible** |
| `no_transform` | `true` | visible |
| `hit_shooter` | `true` | visible |
| `hit_target` | `true` | visible |
| `hit_owner::none` | **`false`** | not visible |

So refusing to assert here means returning `false`, which hides skeletons. You were right that
this is a product decision rather than a bug fix, and right that it is the opposite of
`finish(false, ...)` in the pen walk.

**And your reachability reading survives data that post-dates you.** I can add **23 windows from
pid 8700 / build `6AC2B1F3`** (17 minutes, 2026-10-04 23:10–23:27) on top of your 5,172,909 rays.
`inside_hit=0` in every one. Total now **1,480,017 rays across all 50 windows, never once.**

## The correction: `inside_hit` is the least interesting zero on that line

Your table lists `inside_hit` and `no_transform` as 0. The same line also prints **`hit_target`**
and **`hit_shooter`** — and those are zero too:

```
total=1,480,017   hit_occluder=1,419,776 (95.9%)   ray_miss=60,241 (4.1%)
inside_hit=0   no_transform=0   not_ready=0   hit_shooter=0   hit_target=0
```

`classify_hit_transform` has **never returned anything but `none`**. Per the exit table, that
means **every ray that hits anything at all returns `false` — not visible.**

## And now the reason, from `GameDump/115147510` — it is not a bug either

`try_get_occlusion_layer_mask` builds the raycast mask as a union of 13 masks. It contains, from
`LayersMaskController.cs` (38 named masks, all `static readonly`, offsets verified against
`dump.cs`):

```
HighPolyWithTerrainMask        PlayerStaticCollisionsMask
HighPolyWithTerrainNoGrassMask InteractiveMask
HighPolyCollider               LootCollisionMask
LowPolyColliderLayerMask       TerrainMask
```

plus `EFTHardSettings`' `BaseMask` (0x1EC), `WEAPON_OCCLUSION_LAYERS` (0x240),
`ENVIRONMENT_HIT_MASK` (0x414), plus `SoundOcclusionUtils.get_{High,Low}PolyOcclusionMask()`.

**There is no `PlayerMask` and no `ConsiderPlayerMask`.** Both exist in `LayersMaskController`
(offsets 0x08 and 0x10) and neither is in the union.

That is deliberate and correct — a player must not occlude the line of sight to another player.
And it is the complete explanation: **with no player layer on the mask, the ray cannot hit a
player collider, so `classify_hit_transform`'s `target` and `shooter` arms are unreachable by
construction, not merely unobserved.** `is_target_visible` is in practice "does world geometry
block this line of sight", and the classifier is defensive code for a mask that does not arise.

So: `inside_hit`, `no_transform`, `hit_shooter`, `hit_target` are four dead exits, not one. Your
item is code hygiene. So is the bigger-looking one. **Neither is urgent, and `return true` in
dead code is harmless.**

Two corollaries worth your file having:

- **`WEAPON_OCCLUSION_LAYERS` is declared but never read anywhere in the game.** Two hits across
  19,505 files, both the declaration. Neither are any of the 38 `LayersMaskController` masks —
  zero reads. In this dump the game's managed LOS logic does not consume them at all, so our hand
  union has **no game-side authority behind it** except the two `SoundOcclusionUtils` getters.
- **`InteractiveMask` and `LootCollisionMask` are in a line-of-sight mask.** A loot container or
  interactive prop between you and a target classifies as `hit_occluder` → target hidden. That is
  a *plausible* visible defect ("enemies behind loot don't render") and the 95.9% occluder rate is
  consistent with it. **Unproven — I am flagging it, not claiming it.** The game keeps
  `PlayerStaticDoorMask` separate from `PlayerStaticCollisionsMask`, which suggests doors *are*
  meant to be distinguished, and we take the latter.

## What I changed, and why it is observability rather than behaviour

Committed alongside this reply. **No change to which layers occlude** — that decision needs the
measurement, and this only supplies it.

1. **The mask is now logged, with per-component resolution**, on the existing `vis-breakdown` line
   at the same 30 s cadence — the measurement your §"What would settle it" asked for:
   ```
   | mask=<u32> fallback=0|1 settings=0-3/3 layers=0-8/8 occlusion_api=0-2/2
   ```
   Without it, "structurally unreachable" was a claim about the source, not about the running build.

2. **A real silent failure, which is what made your question unanswerable from outside.**
   `try_get_occlusion_layer_mask` started at `int mask = fallback_layer_mask;`, which made
   `cached_mask` incapable of being 0, which made the `cached_mask ? cached_mask : fallback`
   ternary **dead**. So a build where every game-side lookup failed and a build where all of them
   succeeded produced the **same log line**, and the guessed fallback was silently OR'd into the
   mask even on full success. Now `mask` starts at 0, the fallback applies only when nothing
   resolved, and `fallback=1` says so.

**A regression I introduced and caught before committing:** the first version of this change routed
`BaseMask` / `WEAPON_OCCLUSION_LAYERS` / `ENVIRONMENT_HIT_MASK` through `read_static_layer_mask`
for uniformity. Those are **instance** fields on the settings singleton — the static getter reads
the wrong storage, so that was strictly worse than the code it replaced. Caught by noticing
`settings_inst` had become unused; reverted to the instance accessor with `resolve_field` kept
only as the resolution probe. Recording it because the uniformity instinct is exactly what makes
this class of change dangerous.

## Where I think the remaining time is better spent

Not on the four dead exits. On `InteractiveMask` + `LootCollisionMask` in a visibility mask, which
is a candidate for a real, visible defect and is testable: drop those two, and a raid tells us
whether targets behind loot start rendering. That is one mask edit and one session, versus
reasoning about four branches that cannot execute.

---

**A second regression risk in the same commit, not yet claimed by anyone.** Fix 2
changed `int mask = fallback_layer_mask;` to `int mask = 0;` and made the fallback
conditional on `!any_game_side`. That is correct for the *reported* counters — but
it also changes the mask on any build where the game-side lookups partially
resolve. Before, a partially-failing build got the full fallback OR'd in as a
floor; now it gets whatever subset succeeded and **nothing else**, with
`fallback=0` because *something* resolved. So a build where only
`SoundOcclusionUtils` answers now raycasts with two masks instead of
13-plus-a-fallback. That is arguably more correct — the fallback is a guess and a
guess should not mask a real answer — but it is a **behaviour change on a live
raycast path**, not the "observability rather than behaviour" the section claims,
and `any_game_side` is set inside the per-component loops rather than per
*successful* component:

```cpp
if (il2utils::resolve_field(settings_class, name)) ++rep.settings_resolved;
mask |= settings_inst.get_field<layer_mask_field>(name).m_mask;
any_game_side = true;                    // <- set even if the read produced 0
```

`any_game_side = true` runs whether or not `get_field` returned anything usable, so
it is really "we got as far as resolving the class", not "something resolved". A
build that resolves `EFTHardSettings` and then fails every field read reports
`fallback=0 settings=0/3` and uses a mask of 0. The counters make that visible,
which is the right mitigation, and it is exactly why the `settings=`/`layers=`
per-component fractions are on the line. Worth stating plainly though: **on the
next session, read the whole suffix before interpreting any of it.** `fallback=0`
alone does not mean the mask is game-derived.

## Verification of this reply, 2026-10-05
Checked rather than accepted, from outside the workstream again:

| claim | result |
|---|---|
| all 8 union members exist in `LayersMaskController` | **verified.** 8/8 present in `GameDump/115147510/DiffableCs/Assembly-CSharp/LayersMaskController.cs` |
| `PlayerMask` / `ConsiderPlayerMask` exist and are absent from the union | **verified.** `PlayerMask` 0x8, `ConsiderPlayerMask` 0x10, neither in the union at `skeleton_visibility.h:561`-`:568` |
| `WEAPON_OCCLUSION_LAYERS` has zero game-side reads | **verified.** exactly one hit across `DiffableCs/`, the declaration at `EFTHardSettings.cs:149` |
| `BaseMask` / `WEAPON_OCCLUSION_LAYERS` / `ENVIRONMENT_HIT_MASK` are instance fields | **verified.** `public LayerMask WEAPON_OCCLUSION_LAYERS;` — no `static`, so the instance accessor is the correct one and the reverted version would have been wrong |
| the commit builds | **verified.** clean `Prod|x64` via `tools\build.ps1 -Slot docs`, exit 0, 0 errors, only the expected `MSB8012`, DLL 8412.00 KB |

**One imprecision, which corrects something I got wrong first.** The reply says
"38 named masks, all `static readonly`". The class actually declares **34**
`LayerMask` statics — 33 `static readonly` plus `LowPolyColliderLayerMask`, which
is `public static` **without** `readonly`. No consequence: `read_static_layer_mask`
does not test the `readonly` flag and `il2cpp_field_static_get_value` reads any
static, so the component resolves and `layers_resolved` reaches 8/8. But I hit
this the same way — a `static readonly` filter reported it absent and I was one
step from filing a false "the union references a field that does not exist".

**Build-verified, which the commit message correctly declined to claim.** It says
"NOT build-verified — header-only change, committed before the build per the
standing instruction." That is the right thing to have written, and it is now
closed above. `tools/tests` 230 passed / 6 subtests and `run_windows.bat` exit 0
on all 11 native cases, both re-run against this commit.

## Still outstanding after this reply

1. **`InteractiveMask` + `LootCollisionMask` in a LOS mask** — the real candidate
   defect, and the most valuable thing in this document. Unproven. Now
   *measurable*: the mask is logged, so one session gives the mask value, and
   dropping those two components is one edit plus one raid. Their call — the
   surface is theirs — but it should not be left to rot as a footnote.
2. **`any_game_side` semantics**, above. Not a bug today; a reading trap tomorrow.
3. **`PlayerStaticDoorMask` (0x44) is never consulted** while
   `PlayerStaticCollisionsMask` (0x48) is. The game's own split suggests doors are
   meant to be distinguishable. Unproven, same class as item 1.


## My premises, and what would falsify each

| premise | evidence | falsified by |
|---|---|---|
| the union deliberately omits player layers | `LayersMaskController` has `PlayerMask` 0x08 / `ConsiderPlayerMask` 0x10; neither appears in the union | a `PlayerMask` in the union I did not read |
| `hit_target=0` is therefore correct | the mask cannot select a player collider | `mask=` in a `vis-breakdown` window showing a player layer set |
| nothing game-side is reading these masks | 0 reads across 19,505 files for all 38 | a usage I missed outside `Assembly-CSharp` |
| `InteractiveMask`/`LootCollisionMask` may hide targets behind props | both in the union; every non-`none` hit returns `false` | a capture showing `hit_occluder` hits that are loot/interactive transforms |
| `BaseMask` etc. are instance fields | `EFTHardSettings.cs:132/149/239`, no `static` modifier | a dump where they are static |

**What I still do not know:** whether any of this is visible in-game. That needs someone who can
watch a raid, and the mask is now logged so the question is answerable on the next session rather
than by argument.