# Task: the optics readability memo is thrashing — 29.4 s of a 8-minute capture

> **STATUS: DONE and verified.** Kept as the record of the diagnosis, because the
> arithmetic section is the reason the fix is safe to reproduce and both of its
> traps were shipped by mistake at least once. See "Verifying it worked" at the
> bottom for the measured result.
>
> The measured outcome: `optic-perf: range hit/miss=7942/0 vq=0`,
> `optics::lens::range_readable` **29.385 s → 0.092 s** over 550,401 calls, and
> `hit=7942 miss=0 vq=0` in a later capture. The optics table is
> `kRangeSlots = 4096` with the Fibonacci high-bits hash and the mandatory mask.
>
> **The one open decision this file raised — whether the optics table should be
> cleared like `clear_probe_region_memo()` is — was TAKEN and IMPLEMENTED, and this
> file's status block was stale about it for a week.** `clear_range_readable_table()`
> exists at `optics_lens_pipeline.h:264`, is wired from `common_hooks.cpp:117`
> alongside `eft_api::clear_probe_region_memo()`, and `g_range_clears` is printed
> beside the hit/miss figure at `eft_api.h:1984`. Measured in the 2026-10-09 capture
> (`tracy_traces/tarkovaddons_log_09.10_4.txt`, 43 `optic-perf` windows):
> `range hit/miss=3744/0 vq=0 clears=1` — **clears=1 in every window of the session,
> and it is a cumulative counter.** One clear for the whole raid, which is exactly
> the raid-boundary clear firing once and never again.
>
> That is the answer to the question the counter was added to settle, and I had
> written it up as unresolved. Re-derive it yourself: a `clears` figure that climbs
> mid-raid is hypothesis (a) — `game_state::set_in_raid` has two writers on two
> threads and a spurious transition would drop all 4,096 slots. It did not climb.
>
> One measurement in the original diagnosis was superseded: `VirtualQuery` costs
>
> One measurement in the original diagnosis was superseded: `VirtualQuery` costs
> ~46-200 µs in this process, not a flat 37 µs, and the same session showed the
> per-call cost dominated by a long right tail (min 20 ns). The conclusion that
> the lever is **fewer syscalls, not a faster check** is unchanged and is now
> confirmed across three memos.
>
> The "unrelated one-liner" at the bottom is **complete, and its second half was
> wrong**: `st.null_obj` is in the sum (fixed 2026-10-01), and the item asking for
> `st.unpainted` to be added there is **RETRACTED 2026-10-05** — `unpainted` is a
> sub-counter of `out_of_range`, so adding it double-counts. Nothing is owed here.
> It lived in the chams workstream's file, which
> also had to take a larger fix first — an 11,903-line `ERROR` flood from
> `asset_bundles.h` (85% of one session's log) whose root cause was a leaked
> AssetBundle registry entry, since `reset_bundle` never called `Unload`.

## The problem

`optics::lens::range_readable` is now the single most expensive thing in the profile:

    29.385 s   6.13% of wall clock   790,199 calls   37.2 us per call

The log says why:

    optic-perf: ... range hit/miss=7242/324 vq=648     (per 600 ms window)

**324 misses per 600 ms window.** Each miss is 2 `VirtualQuery` calls (first and last
page), so 648 syscalls per window, at ~37 us each. That is the 29.4 s.

The table is direct-mapped with 256 slots. Its working set is larger than 256, so
every miss evicts a different region and the region that just lost its slot misses
again on its next probe. Steady state, not a cold cache.

**This exact defect was already found and fixed in the sibling table.** See
`eft_api::is_readable_address_cached` in `module/eft_api.h` — it went from
`evict/miss=100.0%` to a 100% hit rate with zero refills. Its comments explain the
whole thing. The optics table is the same design at the old size.

## The fix

All of it is in `module/optics_lens_pipeline.h`, around lines 75-190.

### 1. Size: 256 -> 4096

64 KB of statics. There is a `range_readable_slot()` accessor at ~L147 holding
`static range_slot slots[256]`; make the count a named constant so all uses follow.

### 2. Hash: this is the part that is easy to get wrong

Current:

    ((page * 2654435761ull) >> 20) & 255u

**Do not simply change the shift to `>> 52` to match a 12-bit mask.** Measured on
consecutive pages:

    >> 20 & 255   (256 slots)    256/4096 distinct slots   -- works at its own size
    >> 52 & 4095  (do NOT do)      1/4096 distinct slots   -- COLLAPSED to one slot
    fibonacci high bits           3656/4096 distinct slots  -- 89.3%

The product `page * K` advances by a constant per page, so a run of consecutive
pages walks it through a fixed progression and the top 12 bits never move:
`(1087*K)>>52` and `(1088*K)>>52` are both 0. Bits 20..27 moved every page, which
is the only reason the current expression works. `>> 20` is load-bearing, not stale.

Use the same function `eft_api.h` uses:

    inline size_t index(uintptr_t page) {
        static_assert((kSlots & (kSlots - 1)) == 0, "power of two");
        return static_cast<size_t>((page * 11400714819323198485ull) >> 32) & (kSlots - 1);
    }

**The trailing mask is mandatory.** `>> 32` on its own yields 32 bits, so the index
runs to 4,294,967,295 against a 4096-entry array. That is an out-of-bounds write.
This was shipped by mistake once and caught only because the harness crashed with
a 0xC0000005 and no output.

### 3. Do not break what is already correct

`range_readable()` already caches the whole verified REGION rather than the byte
range of the read that populated it, and the comment at L118-141 documents a real
measured regression from getting that wrong. Leave that alone.

The `size = 0` -> `base` -> `size` write order also matters: zero `size` before
writing `base` so a concurrent reader never pairs a new base with an old size and
accepts a range no syscall approved.

## One decision for you — **DECIDED 2026-10-06, this section is historical**

The optics table is now cleared. `clear_range_readable_table()`
(`optics_lens_pipeline.h:264`) is called from `common_hooks.cpp:117`, on the same
raid-boundary path as `eft_api::clear_probe_region_memo()`, and the
`g_range_clears` counter it increments is printed in the `optic-perf` line
(`eft_api.h:1984`) precisely so the two hypotheses below can be told apart after
the fact.

**The answer is (a) did NOT happen.** From the 2026-10-09 capture, `clears=1` in
every one of 43 `optic-perf` windows, and the counter is cumulative, so the table
was dropped exactly once — at the raid boundary — and never spuriously. Had
`game_state::set_in_raid`'s two writers raced, the figure would have climbed
mid-raid; it did not. So the working set genuinely fits in 4,096 slots, which
`miss=0` in the same line confirms independently.

The reasoning below is left because it is what made this a decision rather than a
default, and because it is the argument to re-read before anyone resizes the table
again — a spurious clear costs a full refill, so resizing makes that failure mode
*more* expensive, not less.

---

The optics table was **never cleared** — it is a function-local static that lives for
the process. The string-path memo in `eft_api.h` is cleared on every raid boundary
(`clear_probe_region_memo()`, called from `hk_tarkov_application_update` when
`is_in_raid` changes), because a cached region end goes stale when the object behind
it is freed.

The optics path reads camera objects and component arrays that are rebuilt on every
transit, so the same staleness argument applies and the current code is carrying that
risk. Resizing the table does not change it either way. Worth a decision, but it is
independent of this fix — do not let it block it.

## Verifying it worked

`optic-perf` already prints what you need; no new instrumentation required.

  - `range hit/miss` should go from 7242/324 to better than 99% hits
  - `vq` should fall from 648 per window to near zero between scene changes
  - `optics::lens::range_readable` self time should drop from 29.4 s and from
    37 us per call to sub-microsecond

Compare with a fresh `tracy-csvexport --self` run of the new capture.

**Measured, 2026-10-01 — all three met.**

| | before | after |
|---|---|---|
| `range hit/miss` | 7242/324 | **7942/0** |
| `vq` per window | 648 | **0** |
| self time | 29.385 s | **0.092 s** |
| calls | 790,199 | 550,401 |

A 320× reduction in self time and zero syscalls between scene changes. `miss=0`
is the number that matters: there is no eviction, so the working set genuinely
fits. Compare the *hit rate* rather than the per-call cost — a fast check with a
thrashing table would still be slow, and the table size is what fixed it.

## Testing it

**A test now exists — `tools/harness/test_range_slot_index.cpp`**, on
`run_windows.bat`, and it asserts exactly the two properties this section
described. The optics table itself still is not included (it pulls in the whole
lens pipeline), so the case copies the page-hash and slot-index arithmetic, which
is what the "if you want a test" note below proposed.

Its measured output, worth keeping because the number sits right on the trap:

    stride     4 KiB -> 2827/4096 distinct slots
    stride    16 KiB -> 2991/4096 distinct slots
    stride    64 KiB -> 2509/4096 distinct slots
    stride   256 KiB -> 3661/4096 distinct slots
    stride  1024 KiB -> 1754/4096 distinct slots
    consecutive pages -> 2827/4096 distinct slots (69.0%, ideal random ~36.8%)

The gate is `>= 40%`, deliberately just above the birthday bound. The measured
**69.0% sitting just under 70%** is precisely why asserting 70% was wrong: a
hash delivers *random* distribution, not better than random, and a gate above the
bound is a test that fails on correct code.

## One unrelated one-liner, in the other workstream's file

`module/impl/ChamsModule.cpp`, in `report_item_chams_scan()`:

    const size_t accounted = st.corpse + st.already + st.no_game_object + st.no_transform
        + st.out_of_range + st.applied;

`st.null_obj` is missing from that sum, so the trace reports `unaccounted=945` for a
1000-item tick when those 945 are fully accounted for as null `loot_obj`. Add
`+ st.null_obj` — and **not** `+ st.unpainted`; see the retraction below.

This is a reporting bug only, not a chams bug: 49 of 1000 LootItems entries are real
items and all 49 were painted, 148 renderers, `zero_renderer=0`, `unpainted=0`.

**Status: `st.null_obj` is now in the sum** (the chams workstream fixed this
2026-10-01; the line is `ChamsModule.cpp:153`, not 136 as filed here).

> **RETRACTED 2026-10-05 — "`st.unpainted` is still missing" was wrong, and the
> fix it names would have been a bug.** `st.unpainted` is not a scan-loop branch.
> It is a **sub-counter inside** the `out_of_range` branch: `:684
> ++st.out_of_range` opens it, `:711 ++st.unpainted` is a detail of it, `:713
> continue` closes it. `out_of_range` already counts that item, so adding
> `st.unpainted` counts it twice and `unaccounted = examined - accounted` goes
> **negative** on every tick that restores anything — strictly worse than the
> defect this item set out to fix.
>
> The sum now has exactly seven terms and the loop has exactly seven
> `continue`-terminated branches, so it reconciles by construction: `null_obj`,
> `corpse`, `no_game_object`, `no_transform`, `out_of_range`, `already`, `applied`.
> `zero_renderer` is likewise correctly excluded — it is the `else` of the
> `applied` branch (`:737`/`:748`) — as are `multi_slot` (an attribute of a
> successful paint) and `hit_cap` (the loop exiting early).
>
> **There is nothing to fix.** `tools/tests/test_chams_scan_accounting.py` asserts
> the branch/sum correspondence and fails if this file keeps recommending the
> change. The error was checked by reading the *sum* rather than the *loop*, which
> is the specific trap in a handoff that hands over its own one-line fix: it
> replaces the reader's judgement with an instruction.
>
> **One honest limit on that enforcement.** The test skips blockquoted lines, so
> the correction above is not itself checked — only live prose is. A future
> session that deleted this retraction and left a plain-prose "`st.unpainted` is
> still missing" would be caught; one that rewrote it into a blockquote would not.
> That is deliberate, for the reason the same test file records elsewhere: a
> check that fails on a document's own correction notes gets deleted rather than
> fixed. If this retraction is ever removed, `test_chams_scan_accounting.py` is
> the thing to re-run by hand.

Two findings that outranked it, also now fixed, recorded here because the
diagnosis is the reusable part:

- **11,903 `ERROR` lines from `asset_bundles.h`,** one message, 46/second, for
  258 s — **85% of that session's log**. `logger::error` is ungated by design, so
  nothing a user can switch turns it off. The line's own comment now says why
  the wording changed: it said "chams stay off this session", which was true
  until the caller began polling forever.
- **Two independent causes, and fixing the flood alone would not have fixed the
  feature.** `check_progress` returned `bool`, so "still loading" and "finished
  with no bundle" were indistinguishable and a dead request was polled every
  frame; **and** the underlying cause was a leaked AssetBundle registry entry —
  `asset_bundles::reset_bundle` never called `Unload`. Fixed by a tri-state
  return (`Loading`/`Loaded`/`Failed`), `Failed` treated as terminal for that
  request so the request is dropped and the pre-existing
  `bundle_retry_after_ms_` backoff finally applies, plus the `Unload` in
  `reset_bundle`.
- **The `item-chams:` trace under-reported.** It printed `shader=ok applied_set=57`
  from a stale cached field while the bundle was null for the final four minutes.
  All 860 traces predate `22:57:55`; none follow. A diagnostic that reports a
  cached value as if it were live is what made the other two hard to see, and it
  is the failure mode the `transitdbg` rate limit was designed to avoid.
