# Task: the overlay throws at exfil, and `probe-memo` is thrashing again

> **From:** the aimbot/pen-check workstream. **Date:** 2026-10-04 13:10.
>
> **Both items below are outside my area** and are handed over rather than taken.
> Item 1 is the crash that killed four consecutive sessions and is now finally
> visible instead of fatal. Item 2 is a live performance regression.
>
> **Nothing here is a request to change behaviour.** Item 1's backoff already
> works; what is missing is *which call* inside `menu::draw` throws. Item 2's
> diagnostic already tells you which failure mode you are in.

---

## 1. `menu::draw()` throws on exfil — the crash is now a log line, and the throw is still unnamed

### What changed

Four consecutive sessions ended like this, with the probe reporting:

    crash probe: ===== FATAL (unhandled exception filter) =====
    crash probe: code=0xE06D7363 flags=0x00000081 NONCONTINUABLE tid=NNNN at 0007FFC029241CA
    crash probe: thrown type: UNRESOLVED. ExceptionInformation = 0x19930520 ...

always preceded by the same three lines:

    Local Raid Ended
    Insured Items: 0
    Transfer Items: 1

The 2026-10-04 13:02 session (`next_next_next_day+3+stuck.tracy`, 6.06 MB) has **no FATAL
at all**, and names the stage instead:

    [13:05:40.556] Local Raid Ended
    [13:05:40.556] Insured Items: 0
    [13:05:40.556] Transfer Items: 1
    [13:05:41.584] ERROR overlay: draw threw at stage 'menu::draw' (non-std exception) occurrence 1
    ...occurrences 2..8...
    ERROR overlay: menu::draw() no longer called after 120 consecutive throws; presenting
           without UI until a draw succeeds. total throws=138
    [13:05:42.542] DEBUG [transitdbg] OnGameEnd shape: sm=0x79b8eef0f0 base=0x79b8eef0e0 delta=-16 ...

**Read that ordering.** The exfil completes at 13:05:40.556, the first overlay throw is
**1.028 s later**, and `OnGameEnd` fires 0.96 s after that. So this is not a throw *during*
teardown — it is a throw on the first frame after it, on the render thread (`tid=28836`,
while the game thread is `tid=25324`).

That timing is the useful part. It points at a **stale-object read in `menu::draw` after
the raid has ended**, not at a race during the transition. Whatever the menu reads on that
first post-exfil frame is already invalid, and every subsequent frame reads it again.

### Why `thrown type: UNRESOLVED` is correct, not a gap

`menu::draw` throws a **non-std** exception — the log says so explicitly. A type with no
`std::exception` base has no vtable, so it has no RTTI, so **no type name is recoverable by
any means**. `tools/probe_test/README.md` documents this as the `uncaught_plain` case and
asserts that reporting `UNRESOLVED` is the correct outcome. Do not spend time on the probe's
type recovery for this one; there is nothing to recover.

### What is actually being asked for

The backoff at `gui/dxhook/dxhook.cpp:1140` (`kOverlayPoisonedAfter = 120`) did exactly
what its comment says it would: converted a process-killing throw into a counted log line,
and the `total throws=138` figure means it also recovered the frame rate. Two log lines
instead of a dead session.

The comment above it is explicit that this **does not claim to know which call throws**:

> WHAT THIS BUYS, precisely: it does not claim to know which call throws. It converts a
> process-killing throw into a named, counted log line, so the next run tells us the stage
> instead of costing us the session.

So the stage is `'menu::draw'` and nothing finer. `menu::draw()` is one call into a dozen
cards, each of which reaches into the game's object model on the render thread. **The
question for whoever owns the menu is: which card, on the first frame after `Local Raid
Ended`.**

Three things that would narrow it, cheapest first:

1. **`menu::draw` is a stage name, not a call site.** If the cards are drawn from a
   collection, a per-card `stage` (the same `detail_stage_` trick `quest_objectives.h`
   already uses, and which narrows `detail: collect()` from four candidate calls to one)
   would name it in a single run.
2. **The `OnGameEnd` hook at 13:05:42.542 is the likely place to look.** It is already
   instrumented (`[transitdbg] OnGameEnd shape: ... delta=-16 off_state=0x10 off_this=0x38`)
   and it runs *after* the first throw. Something the menu reads is being torn down there.
   `local_raid_started` / `hk_local_game_create` / `OnGameEnd` are the three transit
   lifecycle hooks in `always_on.h`; the menu probably caches a player or camera pointer
   that one of them invalidates.
3. **Cheapest confirmation, no code:** disable the menu card that reads a player/camera
   (Quest Completer is the one that holds the most live state — see item 2) and exfil. If
   the throw stops, the working set is named by elimination.

### Two supporting observations

- **`clear_probe_region_memo()` on transit boundaries already exists** for exactly this
  class of staleness, at the *readability* layer. If the menu's throw turns out to be a
  cached region read rather than a stale pointer, that clear is the right precedent.
- **A previous launch in the same log failed cleanly** and is unrelated, but worth knowing:
  `pid=3616` at 12:59:08 → `Unity init failed: required UnityEngine classes missing` →
  `Mod startup stopped`. Six minutes before the good launch. Not connected to the throw.

---

## 2. `probe-memo` eviction is back at 19–100%, and the diagnostic says the table is too small

### What the log says

All seven `probe-memo` lines from the 13:02 session:

    probe-memo: hit/miss=80707/1489  (98%) fills=1479 evictions=404  evict/miss=27.1%
    probe-memo: hit/miss=8611/56    (99%) fills=56   evictions=18   evict/miss=32.1%
    probe-memo: hit/miss=25342/251  (99%) fills=251  evictions=49   evict/miss=19.5%
    probe-memo: hit/miss=26742/42   (1e+02%) fills=42 evictions=42  evict/miss=100.0%
    probe-memo: hit/miss=25896/184  (99%) fills=184  evictions=161  evict/miss=87.5%
    probe-memo: hit/miss=20158/29   (1e+02%) fills=29 evictions=28   evict/miss=96.6%
    probe-memo: hit/miss=80169/1408 (98%) fills=1408 evictions=378  evict/miss=26.8%

### Why this is worth acting on

`eft_api.h:4270-4277` states the threshold explicitly:

> The justification for stopping there rather than going larger is the measurement in the
> same report line: at 100% eviction the miss rate IS the working-set touch rate... The
> honest check is that **evict/miss falls well below 100%**. If it stays pinned at 100%
> after this, the working set really is larger than 4096 and the answer is a **different
> structure** — a second-level filter or a per-callsite region hint — **not a bigger array**.

So the documented decision procedure is already written. **Three of seven windows are at or
near 100%** (`fills == evictions` exactly in the 42/42 and 29/28 windows, which is the
signature the comment names), which by the file's own rule means **resizing again is the
wrong answer.**

`kProbeRegionSlots = 4096` is already 64 KB of statics and 16× the original 256. The
comment's stated alternative is a second-level filter, or a region hint per call site.

### The one number that decides it

`fills=1408` in the last window at 98% hit rate — the working set is ~1,400 distinct
regions per 30 s, which **fits in 4096**. And `fills=1479` in the first window at 98%.
So the table is *not* too small for the steady-state working set; the 100% windows have
`fills=42` and `fills=29`, which are *tiny* working sets that still thrash 100%.

**A 42-region working set cannot overflow a 4096-slot table by capacity.** That is either
hash clustering (29 or 42 distinct pages landing in too few slots) or something else
entirely — and it is the reason I am handing this over rather than resizing. A resize would
make the number *look* better without identifying the cause, which is the failure mode this
diagnostic was built to detect.

**Suggested first check, and it is cheap:** log the number of *distinct slots occupied* at
report time. If 42 fills occupy 3 slots, it is the hash; if they occupy 42, the eviction
counter is miscounting something the comment at `eft_api.h:4432-4436` says it should not.

### Do NOT

- **Do not resize to 16,384.** The file says not to, and the `fills=42` evidence is why.
- **Do not touch the hash without the handoff memo's arithmetic.**
  `tools/handoff_optics_memo.md` §2 is the record of the optics table collapsing to a
  single slot when the shift was naively widened (`>> 52 & 4095` → 1/4096 distinct slots),
  and it documents the Fibonacci high-bits form that replaced it. That mistake shipped once.
- **Do not change the write order** (`size = 0` before `base`, `size` last). It is
  load-bearing: it is what stops a concurrent reader pairing a new `base` with a stale
  `size` and accepting a range that was never verified. That is a false "readable", the one
  failure this mechanism must not have.

---

## What I did *not* touch

Both files are outside the aimbot/pen-check area and I have not modified either:

- `gui/dxhook/dxhook.cpp` — item 1
- `module/eft_api.h` around `kProbeRegionSlots` / `maybe_report_probe_memo` — item 2

My own work this session (`is_unity_object_alive` 64.87 s → 0.54 s, the `cam-choice` torn
read, and the pen exit-face/re-entry rule) is written up in `CHANGELOG.md` §0.60 and §0.59
and is verified by `tools/tests`, so it should not collide with either of the above.

One thing worth flagging for whoever picks up item 1: **`Quest Completer` self time is now
the single largest item in the profile** — 84.17 s over 16,986 calls in the 10:04 capture,
mean 4,955 µs, **max 431 ms** — on a capture one seventh the size of its predecessor. It
also produced 462 `ERROR` lines in the 08:37 session and 1,801 `quest name` lines in the
13:02 one. It holds more live game state than any other card, which makes it the most
likely holder of whatever `menu::draw` is reading after teardown, and it is worth weighing
in item 1's elimination test.