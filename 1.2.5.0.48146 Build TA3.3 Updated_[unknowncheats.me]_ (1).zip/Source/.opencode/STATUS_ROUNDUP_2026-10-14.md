# Status round-up — 2026-10-14 (opencode session)

Consolidated from `tools/handoff_*.md`, `tools/premises_*.md`, `AGENTS_TODO.md`,
`CHANGELOG.md`, `WORKFLOW.md`, `Workstream_status_2026-09-24.md` (historical),
`tools/README.md`, `tools/optics_status.md`, `tools/plan_bigmap_and_minimap.md`,
and live re-measurements where noted.

## What this session did

1. Rounded up the current status of all 14 hand-off/premises docs (below).
2. **Removed 6 concluded hand-offs from the tree** and archived them verbatim in
   `.opencode/handoff-archive/` (see `INDEX.md` there). The removal set is exactly
   the docs that were replied-to or resolved *and* carry no live action that is
   not already recorded elsewhere in the tree. Nothing live was lost: every
   still-open item they contained is re-stated in this file.
3. Re-derived the one count that documents quote and that drifts:
   `tools/audit_call_through.py` today reports **47 unguarded / 79 resolve-only**
   (the crash hand-off's "48 / 80" and its summary table's "48" are stale by one;
   `QuestModule.cpp` is now clean, was 20).

Removal set (all archived, all still cited by history docs):

| file | why it left the tree | closure recorded in |
|---|---|---|
| `tools/handoff_visibility_inside_hit.md` | replied same-day; verdict "code hygiene, not a defect" | `AGENTS_TODO.md` §"Handed off, 2026-10-04" item 3 (CLOSED), and the flag section's 2026-10-13 falsification note |
| `tools/handoff_visibility_inside_hit_REPLY.md` | the concluding reply of the same exchange | same; the flag it took is history (freeze lifted 2026-10-13) |
| `tools/handoff_quest_place_pois.md` | FIXED 2026-10-13, committed (`e05dd0bbf` + `2f29e1bcc`), proven against both dumps | `AGENTS_TODO.md` top note (2026-10-13) |
| `tools/handoff_quest_all_cap_order.md` | both defects fixed, committed, build-verified 2026-10-08 | `CHANGELOG.md` §0.5x era (quest-completer series); the commits are in history |
| `tools/handoff_optics_memo.md` | DONE and measured (29.385 s → 0.092 s; the open decision taken and implemented) | its own status block + `CHANGELOG.md` §0.59-era optics entries |
| `tools/handoff_exfil_overlay_and_probe_memo.md` | item 1 answered + contained; item 2 closed as non-issue | `CHANGELOG.md` §0.44/§0.45 (the catch, the 0-throw table); `Workstream_status_2026-09-24.md` "probe-memo, worked" |

## Current status of everything still in the tree

### Open hand-offs (actionable, owners as stated in each file)

1. **`tools/handoff_skeleton_vis_clone_merge.md`** — OPEN by choice. The two
   clones in `skeleton_visibility.h` (ancestor gate vs sibling sweep) are still
   unmerged. Blocking premise gone (freeze lifted 2026-10-13). The remaining
   gate is §5: a 500 ms trace dump before *and* after, diffed byte for byte —
   no test guards the four forensic strings, so a merge could land green while
   silently changing them. Needs a raid. (`AGENTS_TODO.md` top note agrees.)
2. **`tools/handoff_optics_instance_table_rva.md`** — OPEN. The bare literal
   `0x1A237F8` in `optics_lens_pipeline.h:instance_from_id()` is guarded but
   unnamed. Cheap falsifier already run once (grep of the 2026-10-12 raid pid
   11736: zero `why =` strings) — one data point, not proof. Next step if the
   route ever looks wrong: IDA xref against `Object::RegisterInstanceID`, then a
   *named* profile symbol per `REFRESH_RUNBOOK.md` — never the forum dumper's RVAs.
3. **`tools/handoff_material_catalogue_next.md`** — OPEN past its probe. The
   probe ran 2026-10-13 18:31 (pid 20612): **`material-catalog: OK rows=2597
   alive=2597 dead=0 unnamed=1 distinct_names=2179 elapsed_ms=1016`**. Verdict
   0, names real. The `elapsed_ms=1016` on one `gameworld_update` is the finding
   that changes the plan: nothing may run at this cadence until the cost is
   broken down (the 2,597-entry liveness sweep is the suspect; `dead=0` says the
   per-hit check is cheap). Coverage of native-only materials is still
   unmeasured. The ChamsModule feature work (game-material mode, searchable combo
   picker, replace-vs-alongside decision) is all still ahead and is a product
   call first.
4. **`tools/handoff_call_through_null_crash.md`** — OPEN as a bug class. Root
   cause (`unity::camera_fov` call-through-null) is fixed (`6c8435ff`); **47
   unguarded sites remain** (re-measured today; was 48): `ItemModule.cpp` 22,
   `PlayerModule.cpp` 12, `ItemModule.h` 9, `PlayerModule.h` 3, `EspModule.cpp` 1
   (`get_Nickname`, now :6587). `QuestModule.cpp` is clean. 79 more are
   resolve-only and need review. The checked accessor (`call_or` / `call_or_void`
   in `Il2CppObjectInstance.h`) exists for exactly this sweep. Note the file's
   provenance-table line about the crash probe is stale — see the 2026-10-06
   note in `AGENTS_TODO.md`; do not treat either line as current.
5. **`tools/handoff_bigmap_progress.md` + `tools/plan_bigmap_and_minimap.md`** —
   OPEN, partially stale. Steps 1–5 committed and build-verified; **step 6's
   first increment is in** (`8d7d62929`, plus `245e0832a`, `a5c24d6dc`) — but the
   plan file still says "steps 1–5 implemented; step 6 and step 7 remain" and
   the progress file says "Remaining: step 6 … and step 7". Step 7 (the map
   drop-down) is not started. No raid has drawn the step-5 static markers yet.
6. **`tools/handoff_hideout_premises.md`** — MIXED, keep. Its crash-attribution
   retraction is done and its answer to item 1 (hideout card is a clean
   elimination) was right: the throw was in `ESP::draw_overlay`. Its §5 "still
   open and mine" list (10 dead `hideout::` zones ~0.130%; the
   `production_panel_probe.h` stale comment mis-attributing 17.75%/7.86% of two
   captures; 16 uncached `is_readable_address` call sites in
   `hideout_reflection.h`; the 5.5× `refresh_hideout_state` growth §2.5 says may
   be session mix) is the only record of those items — re-verify before acting,
   it was written 2026-10-05. Also cited by `AGENTS_TODO.md` for a clang-tidy
   suppression's attribution.

### Premises files (kept; they are falsifiable-claim records, not work requests)

7. **`tools/premises_about_other_workstreams.md`** — mostly settled now (§1/§7
   the fireport was located and fixed; §2's gate fix is in; §3's 138-throw puzzle
   was answered by the quest-completer premises: two different counters). The
   `is_unity_object_alive` disagreement is still marked unresolved in
   `AGENTS_TODO.md` §"Cross-workstream premises" — that record should stay.
8. **`tools/premises_quest_completer_about_others.md`** — its resolved section
   named the throwing card (`ESP::draw_overlay`, 2026-10-04 15:22 observation)
   and closed the aimbot's §3/§8 questions. Its §6 bullet "why 45 SideQuests
   return an empty `get_Name()`" is **answered in code, the premises doc is
   stale on it**: `QuestModule.cpp`'s audit comment (:272-289, from the
   2026-10-04 probe, refined 2026-10-11) reports 647 quests / 45 blank names /
   0 raw locale keys, all `class=SideQuest` — dormant holiday-event entries
   whose status field still reads 2, which also explains the per-condition
   non-std throw that accompanies them. "Not a defect, on the evidence."
9. **The `aimbot::fireport_resolve` question is closed too** — the premises
   file's §1/§7 open items ("one capture with the `fireport-cost:` line") were
   answered: root cause was one missing argument (`3c2b57d80`), and the zone
   went 310.59 s → 0.00 s (`CHANGELOG.md` §0.42-era entries).

## Items extracted from the archived docs — still live, do not lose these

These were inside the removed files and are **not** recorded anywhere else:

1. **`InteractiveMask` + `LootCollisionMask` in the LOS mask** (from the
   visibility REPLY) — the real candidate visible defect: loot/props between you
   and a target classify as `hit_occluder` → hidden. Unproven. Now measurable:
   the mask + per-component resolution are logged on the 30 s `vis-breakdown`
   line since `7f911e4d`; dropping the two components is one edit plus one raid.
   ⚠️ The 2026-10-12 raid **falsified** the older "four exits are dead by
   construction" reading (`hit_target=9956`, `hit_shooter=42`, `inside_hit=21`
   with the mask fully resolved) — so the classifier is live; re-derive from
   `vis-breakdown` before building on either reading.
2. **`any_game_side` reading trap** (same REPLY) — `fallback=0` does *not* mean
   game-derived; read the whole `vis-breakdown` suffix. Behaviour change on a
   live raycast path shipped with `7f911e4d` (partially-resolving builds now get
   only what resolved, no guessed floor).
3. **`WEAPON_OCCLUSION_LAYERS` has zero game-side reads** (same REPLY) — the
   hand-built mask union has no game-side authority behind it except the two
   `SoundOcclusionUtils` getters. `PlayerStaticDoorMask` (0x44) is never
   consulted while `PlayerStaticCollisionsMask` (0x48) is.
4. **quest place-POI §5 premise** (from `handoff_quest_place_pois.md`) — the
   field fix is in and re-proven, but whether a `ConditionPlaceBeacon.zoneIds[]`
   entry names a `PlaceItemTrigger` in the cache is **still unconfirmed by a
   raid**. The DEBUG line added with the fix answers it: `found=0` for every id
   → look at `get_InputTriggerIds()`; `found=1` with nothing drawn → the draw path.
5. **quest cap §5 follow-ups** (from `handoff_quest_all_cap_order.md`) — the
   condition-read diagnostic's runtime behaviour is unverified (needs one
   capture; a `stage (unset)` line would mean the marker hole reopened);
   `all_view_rank` is a product decision that deliberately went against
   `quest_objectives.h`'s comment (rank = the order the card already renders);
   the 64 cap is a judgement call with a stated basis — a profile reaching it is
   the trigger to measure, not to raise it.
6. **optics-memo durable warnings** (from `handoff_optics_memo.md`) — the hash
   change that collapsed a table to one slot (`>> 52 & 4095`), the mandatory
   trailing mask, the load-bearing `size = 0` before `base` write order, and the
   chams `st.unpainted` retraction (adding it double-counts;
   `tools/tests/test_chams_scan_accounting.py` asserts the retraction against
   the live sum and scans live prose for the wrong prescription — **that test's
   documentation scan lost one member when this file was archived**; its
   `checked > 500` guard still passes, re-run it by hand if the retraction is
   ever edited).

## Corrections the round-up found (recorded here, not edited into shared docs)

- **`AGENTS_TODO.md` §"Handed off, 2026-10-04" items 1 and 2 read as open but
  are closed.** Item 1 (exfil throw): named (`ESP::draw_overlay`'s camera
  resolution throws a managed exception on the first frame after teardown) and
  contained — local catch in `draw_overlay`, 0 escaping throws in the two
  post-fix runs (`CHANGELOG.md` §0.44/§0.45); the neighbouring null-call AV in
  the same path is fixed in `6c8435ff`. Item 2 (probe-memo thrashing): closed as
  a non-issue — birthday-bound arithmetic shows the 100 % windows are turnover,
  not clustering; 6,918 `VirtualQuery` calls for the whole session = 0.32–1.38 s.
  Its item 3 is marked CLOSED in place; items 4 and 5 are the live ones above.
  Someone owning `AGENTS_TODO.md` should annotate that section.
- **`tools/plan_bigmap_and_minimap.md:3`** still says step 6 remains; step 6's
  first increment is committed.
- **`handoff_call_through_null_crash.md`'s provenance line** "probe still
  destroys the report for stack-starved faults" contradicts the reworked
  `crash_probe.h` (2026-10-06 note in `AGENTS_TODO.md` — "do not delete either
  as superseded" applied then; the file is still open for the bug class, so it
  stays, but that one line is not current).

## Inbound citations now pointing at the archive

- `tools/README.md:1013` — link updated to note the fix + archive path.
- `tools/handoff_skeleton_vis_clone_merge.md:18,154` — citation updated.
- `tools/handoff_hideout_premises.md:133` — citation updated.
- Historical citations left as-is (those documents cite closed work by design):
  `AGENTS_TODO.md` (lines 61, 86, 105, 246, 322, 335–336, 359–360, 726, 5578,
  5603), `CHANGELOG.md` (3706, 3718, 4239), `Workstream_status_2026-09-24.md`
  (8860, 8890, 8991, 9189, 9388, 9825), `tools/tests/test_quest_condition_fields.py:3`
  (provenance comment), `tools/tests/test_pen_diagnostic_strings.py` (cites the
  kept clone-merge handoff), `tools/tests/test_chams_scan_accounting.py:314`
  (scan list — skips missing files by design, guard re-verified).

## Verification done for this round-up

- `python tools\audit_call_through.py` — exit 0, 47/79 (re-measured, was 48/80).
- `pytest tools/tests/test_chams_scan_accounting.py tools\tests\test_pen_diagnostic_strings.py tools\tests\test_dup_scan.py -q` — 38 passed, 1 failed.
  The failure is `test_dup_scan.py::test_the_whole_first_party_tree_meets_the_documented_scale`
  (**190 first-party files vs the documented 187**) and it is **pre-existing, not
  from this cleanup**: dup_scan's `DEFAULT_ROOTS` are `TarkovAddons`,
  `TarkovLauncherBypass`, `shared` and its `SUFFIXES` are C/C++ only, so six
  deleted `.md` files under `tools/` cannot move the count. The +3 is
  `MapModule.cpp` + `MapModule.h` (`8d7d62929`, step 6) and
  `raster_draw_common.h` (`a5c24d6dc`) — the map workstream's re-measurement of
  that test's docstring is owed, exactly as its history records after every
  landing. That test also has no runtime cost to being red — it is a
  documentation-currency guard, not a code guard.
- Deletions staged by explicit path only (never `git add -A`), committed in one
  breath per the standing instruction; nothing else in the tree touched.

## How the commits actually landed (recorded because the tree bit us)
- The **six deletions** were staged early and then swept into the other
  session's commit **`4bd189e3d`** ("esp: five duplicated blocks…", 12:44:40),
  which they committed with their own `EspModule.cpp` work in the index. This is
  the event `AGENTS_TODO.md`'s top note records twice already ("`git add` is a
  half-finished commit that the next session to run `git commit` will finish").
  Nothing was lost and history was **not** rewritten — same resolution as the
  repo's precedent. Their message does not mention the deletions; this section
  is the attribution record.
- My commit **`0536d8be4`** carries the three citation edits above. The
  `.opencode/` storage is intentionally untracked (my storage, not the
  project's), so it will appear as `??` to other sessions — that is expected.
- Their `EspModule.cpp` was uncommitted when this round-up started and is now
  committed in `4bd189e3d`; nothing of either session's was touched by me.
- *(Later the same day: the user committed the storage itself as `96c3d580d`
  "keep opencode in repo", so the `.opencode/` files below are tracked now. My
  storage-edit commit is `717c7b714`.)*

---

# Session 2 — 2026-10-14: C1–C5 instrumentation landed, built, and verified

Commit `1e190da6f` ("instrument: five probes that let the module answer the open
questions"). All five are additive, cold or gated, and none change draw-path
behaviour:

1. **C1 — `material_catalogue.h` phase timing.** The 1,016 ms is now five
   reconciled phases (`phase_ms[resolve enum census liveness names]`) that sum
   to `elapsed_ms`, so no part of the cost can hide. The census (the
   `UnityEngine.Object` denominator call) is its own phase precisely because it
   could have been the hidden third candidate.
2. **C2 — same probe, coverage labelled.** `rows=` is managed-only:
   `native_coverage=unmeasured` is now printed beside `objects_all=`. The native
   type-manager walk is deliberately NOT in the tree — it needs a named oracle
   for the UnityPlayer globals first (the optics instance-table handoff), and
   inventing one is the documented four-times-over error.
3. **C3 — `unity::camera_fov` miss diagnostic.** On a resolve miss the module
   now logs instance/klass readability, the ancestor chain, and how many
   ancestors resolve `get_fieldOfView` — the detail whose absence left the
   2026-10-04 crash's *why* unexplained (the log said `Int32`, not a camera
   class). On the miss path only; log volume answers "is a miss common".
4. **C4 — marker/door placement check.** Once per map entry, DEBUG-gated:
   every `LockedDoor` static marker is matched against the game's own
   `EFT.Interactive.Door` list, nearest door + distance per marker and a
   per-map summary with the worst case. This is the "right door" proof the
   bounds test cannot give.
5. **C5 — hideout zone split.** `orig_req_row_show` now runs in its own
   `TA_ZONE_SITE` child span, so the outer zone measures only our
   template-id work. The comment that claimed the game's call was outside the
   zone (mis-attributing 17.75%/7.86% of two captures to us) is corrected.

**Verified the only way this repo counts:** full `Prod|x64` build in slot
`instrument` — exit 0, 0 errors, 0 C warnings, the one expected `MSB8012`, and
`build.ps1`'s FRESH check (DLL postdates every source). `pytest tools/tests`
545 passed, 6 skipped, 1 failed — the one being the `hwid_check` slot owned
elsewhere.

**Commit `e6e86f8fa`** re-derived the doc figures the build and the tree had
left stale (map_icf 105/400/295, `$unwind` 6,240/2,023/1,299, largest group 92;
config pointers 366/30; dup_scan 190/421,268 & 180/420,968; zone_gap 4 unzoned
bodies; AGENTS.md's pytest line to the measured 545). Suite went 5 red → 1 red.

## What the next raid answers, and what needs the user

From the log file, DEBUG toggle on where noted:
- `marker-door:` lines — are the 242 markers on the right doors (Customs first)?
- `material-catalog:` `phase_ms[...]` — where the 1,016 ms goes, i.e. whether
  the 2 s/15 s clock is survivable.
- `objects_all=` / `native_coverage` — the managed denominator.
- `camera-fov-miss:` — only if the route breaks; the resolve question.
- A Tracy capture after C5 — ours-vs-game on the hideout row.
- Still needs the user's memory: the product calls in the question list
  (chams replace-vs-coexist, drop-down scope, marker density on Streets).
- Deploy (`python tools\deploy.py install`) and the raid are the owed steps;
  the game must be closed first.

