# Compatibility profiles

> **New here:** [`PROFILE_GUIDE.md`](PROFILE_GUIDE.md) is the canonical usage
> document — the manifest field reference, runtime resolver semantics, and the
> consolidated audit record with open items. This file stays the short
> status/module reference.
>
> **A game update just dropped?** [`REFRESH_RUNBOOK.md`](REFRESH_RUNBOOK.md) is
> the ordered procedure, and the two files that make it checkable:
> `tools/verify/verify_manifest.py` (bytes) and `tools/verify/ida_manifest.py`
> (names). Read the runbook before editing any RVA — the order it gives is
> most-stable-symbol-first, and the byte-level checks alone cannot tell you a
> pattern resolved to the wrong function.

Each game build gets its own manifest instead of modifying a global offset
file. The current checked-in profile is:

```text
profiles/1.2.0.0.47888/manifest.json
```

It was generated from the legacy configuration as a seed (`import --clear-rvas`),
its native RVAs were re-derived by name from `GameAssembly.pdb` and by unique
pattern scans, and it was checked against matching local PE files. The profile
is **`validated`** (21 symbols, 14 required) and has been observed loading at
runtime — see `REFRESH_RUNBOOK.md`'s worked example for the full as-executed
procedure.

The previous build's profile is kept as the rollback path and is never selected
against a newer game: `profiles/1.1.5.1.47510/manifest.json` (`staged`, 21
symbols). `deploy.py` ships only the newest profile directory and prunes stale
ones at install, because the launcher-side selector ranks profiles by `status`
and breaks ties by first-encountered directory order — with `UnityPlayer.dll`
byte-identical across these two builds, both profiles matched the launcher's
anchor, so which one won was decided by that ranking rather than by identity.

Neither profile has unresolved entries: all optional native symbols carry both
a manifest RVA and a pattern, so validation reports nothing. (`1.1.5.1.47510`
remains at `staged` — its promotion is a decision nobody has needed to make,
since it is no longer the profile that ships.)

## Status meanings

- `unverified` — imported or edited without module-backed validation
- `staged` — module data was collected, but warnings remain
- `validated` — PE identity, RVAs, and declared patterns passed static checks
- `verified` — reserved for a profile that has also passed runtime testing

`validated` is not a claim that every optional feature has been exercised in a
live game session.

## Validate the current profile

The current profile validates clean — no diagnostics at all, with or without
`--strict`:

```powershell
python tools/manifest_tool.py validate `
  compatibility/profiles/1.2.0.0.47888/manifest.json `
  --module-dir TarkovAddons/GameDump/120047888
# Manifest validation passed          (exit 0, zero issues)

python tools/manifest_tool.py validate `
  compatibility/profiles/1.2.0.0.47888/manifest.json `
  --module-dir TarkovAddons/GameDump/120047888 --strict
# Manifest validation passed          (exit 0, zero issues)
```

A *fresh import* is also clean today, and the difference from the historical
behaviour is the thing to understand. Re-running the import against the current
`offsets.cfg`/`patterns.cfg` emits **21** symbols, `status=validated`, zero
warnings (measured 2026-10-07) — because the cfg slots now carry the 1.2.0
patterns, so every native symbol arrives with at least a pattern. When the
`be_service_check` and `hwid_check` slots are blank (their documented default),
the same import instead warns per blank slot:

```
WARNING symbols[2]: native symbol has no manifest RVA or pattern; ...
WARNING symbols[3]: native symbol has no manifest RVA or pattern; ...
```

The shipped profile carries post-import enrichment the importer does not
produce — PDB-confirmed RVAs, `native` resolvers, per-symbol notes. That
difference is pinned by `ShippedProfileDriftTests`.

The module directory is intentionally not part of the manifest. It is local
input used to verify the profile's PE identity and signatures, and it is
gitignored — `GameDump/` must be regenerated locally, so no test depends on it.

## Launcher module mapping

The launcher-side entries are split across the two native modules as follows:

| Entry | Native module |
|---|---|
| `be_service_check` | `UnityPlayer.dll` |
| `load_be_client` | `GameAssembly.dll` |
| `be_client_start` | `GameAssembly.dll` |
| `be_client_init` | `GameAssembly.dll` |
| `load_be_client_known_offset` | `GameAssembly.dll` |
| `run_validation_movenext_offset` | `GameAssembly.dll` |
| `hwid_check` | `GameAssembly.dll` |

`UnityEngine` is a managed namespace/name; the PE file used by the resolver is
`UnityPlayer.dll`. The generated profile preserves this distinction and the
module mapping is covered by a regression test.

`hwid_check` deserves a note. It is read by `feature/spoofer.cpp` through both
`globals::get_offset()` and `pattern_cfg.get()`, but it used to appear in no
configuration file at all, so it silently fell through to a signature compiled
into the DLL with nothing in version control describing it. That history is why
the slot exists at all: listing the key makes it visible to
`tools/manifest_tool.py`, which imports it as a tracked non-required
`GameAssembly.dll` symbol, so a future game update that breaks the signature
shows up in validation instead of failing silently at runtime.

The slot is no longer blank. Since the 1.2.0.0.47888 refresh it carries the
current 24-byte pattern, the manifest entry carries `rva: 0x3B86B93` with
`source: pattern-scan`, and a fresh import resolves it like every other symbol.
(The comment block above the slot in `patterns.cfg` still describes the blank
era; reconciling that prose is tracked elsewhere.) The RVA addresses the
**call site**, not a function entry — the pattern is the "call above the HWID
check" signature and `TarkovLauncherBypass` overwrites it with
`xor rax,rax; nop; nop`.

## Runtime behavior

The main `TarkovAddons.dll` looks for manifests under:

```text
<data directory>/compatibility/profiles/<version>/manifest.json
```

where the data directory is `ta/` beside the DLL when it exists and the DLL
directory otherwise (`module_paths::data_directory_wide()`). This is the F15
lesson: the loader, the build, and `deploy.py` must all name the same root, and
`tools/tests/test_profile_path.py` exists to hold them to it.

It selects a profile only when the loaded `GameAssembly.dll` matches both
`SizeOfImage` and its PE timestamp. `staged`, `validated`, and `verified`
profiles are eligible; the loader resolves the 14 required IL2CPP entries and
stops safely if any required entry is missing.

If no manifest directory is packaged, startup falls back to the legacy
`offsets.cfg`/`patterns.cfg` resolver for migration compatibility. If a
manifest directory exists but no profile matches the loaded module, startup
fails closed rather than using a potentially stale profile.

The launcher side consumes the same manifests through its own
`compat_profile.cpp`: it selects a profile out-of-process (anchored on
`UnityPlayer.dll`) and `disabler.cpp` resolves and patches
`load_be_client`, `be_client_start`, and `be_client_init` from it. The
main-DLL runtime resolves only the `il2cpp_*` entries and does not patch the
launcher-side symbols.

## Adding a newer build

**Follow [`REFRESH_RUNBOOK.md`](REFRESH_RUNBOOK.md).** It supersedes the sketch
below, which is kept only because the importer flags below are still true.

1. Keep the existing profile unchanged.
2. `--isil-root` is optional: it seeds build-identity detection from an ISIL
   reference tree, and the 1.2.0.0.47888 refresh ran with none — pass
   `--game-version` (and `--profile-id` if you want an id other than the
   derived `eft-<version>`) instead.
3. Use `--clear-rvas` so stale native addresses are not copied.
4. Supply the newer `GameAssembly.dll` and `UnityPlayer.dll` through
   `--module-dir`.
5. Run strict validation and review every unresolved or ambiguous symbol.
6. Promote the profile to `verified` only after runtime testing.

Old patterns may be retained as candidates, but they must not be treated as
valid merely because they came from an older profile.

An import is a **seed, not a profile**. It emits whatever the cfg files say and
`--module-dir` can check — PE identity and pattern uniqueness — but it cannot
name the address a pattern lands on, so it cannot tell a correct pattern from a
plausible one. That gap has twice produced a manifest that validated clean while
being wrong. `tools/verify/ida_manifest.py` closes it when a licensed IDA and a
matching `.i64` are available.
