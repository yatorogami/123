# Refreshing a compatibility profile after a game update

Runbook for what to do when Battlestate ships a new build. The procedure was
first measured on `1.1.5.1.47510` (2026-10-05/06) and then executed end-to-end
on `1.2.0.0.47888` (2026-10-06/07) — see the
[worked example](#worked-example--the-120047888-refresh-as-executed-2026-10-0607)
near the end for that run, including everything that differed from what this
document predicted. **None of the numbers are a promise about the next build.**
Treat the commands as the procedure and the values as examples.

The short version: the update is not "edit some hex numbers". It is *re-derive
each symbol from a named oracle, in a specific order, and let the byte-level
checkers confirm nothing moved silently.* The order matters and is the part that
is easy to get wrong.

---

## 0. Before anything: what "the build changed" actually means

You need the new binaries. They are gitignored (`GameDump/`) and must be
obtained locally:

```
TarkovAddons/GameDump/<new-build>/GameAssembly.dll
TarkovAddons/GameDump/<new-build>/UnityPlayer.dll
```

Optionally, and each gives you a different kind of oracle:

| oracle | path | what it answers |
|---|---|---|
| PE bytes | the two DLLs | is a pattern/RVA still correct? |
| `.i64` | `<dir>/<module>.i64` | **what function is this address?** |
| PDB | `TarkovAddons/GameDump/<build>/GameAssembly.pdb` | what is this RVA's managed name? |
| `dump.cs` | `TarkovAddons/GameDump/<build>/dump.cs` | managed signatures + generic instantiations |
| ISIL | `TarkovAddons/ISIL-references/IsilDump` | call relationships in managed code |
| `export` table | in `GameAssembly.dll` | where does the *public* entry point live? |

**The PDB/dump.cs/ISIL directories are keyed by a different number than the
binaries directory.** `115147510_tarkov-dump/` holds the DLLs;
`115Dump/115147510/` (i.e. `GameDump/115147510/`) holds `dump.cs` and the PDB.
They must correspond, and nothing enforces that. Check the identity fields, not
the folder names.

---

## 1. Establish the new module identity FIRST

Do this before touching any symbol. Every later check is conditioned on it.

```powershell
python tools/verify/verify_manifest.py <old-manifest> <new-module-dir>
```

Or read the fields directly:

```powershell
python -c "import sys;sys.path.insert(0,'tools');import manifest_tool as mt;from pathlib import Path;print(mt.describe_module(Path(r'TarkovAddons\GameDump\<build>\GameAssembly.dll')))"
```

Write the resulting `size` / `pe_timestamp` / `text_sha256` into the new
profile's `modules` block.

> **Two conventions a validator will otherwise get wrong.** `size` is
> `SizeOfImage`, not file size — they differ by a lot on a 100 MB DLL. And
> `text_sha256` is over the **raw on-disk** `.text` bytes, not `VirtualSize`.
> Getting either wrong produces a module block that never matches.

The runtime gate only enforces `SizeOfImage` + PE timestamp. `text_sha256` is
stronger than the loader actually checks, so it is offline-only — which is
exactly why it is worth having here.

---

## 2. Re-derive symbols in this order

The order is not arbitrary. It goes **most-stable-first**, so that the work you
do first is the work least likely to be invalidated by the next thing you do.

### 2a. `export`-resolver symbols — 6 of them, do these first

```
il2cpp_array_new              il2cpp_domain_get_assemblies
il2cpp_field_get_value_object  il2cpp_object_new
il2cpp_runtime_class_init     il2cpp_string_new
```

These carry **no RVA and no pattern**. The runtime resolves them by name from
the export table, so they are the most update-stable entries in the profile and
the least work.

Verify each name still exists in the new module:

```powershell
python tools/verify/verify_manifest.py <manifest> <new-module-dir>
```

`cannot inspect` / `export ... is absent` means the API was removed or renamed.
That is a code change, not a profile change: update `TarkovAddons/il2cpp/exports.h`
and `il2cpp_offsets.h`, not just the JSON.

### 2b. `pattern`-resolver symbols — 8 of them, and these are the trap

`il2cpp_domain_get`, `il2cpp_field_static_get_value`,
`il2cpp_field_static_set_value`, `il2cpp_type_get_object`,
`il2cpp_class_from_name`, `il2cpp_class_get_field_from_name`,
`il2cpp_class_get_method_from_name`, `il2cpp_class_get_nested_types`.

These have a pattern and **no RVA**. Each pattern resolves to a *different
address* than the export of the same name, and that is correct — see §4. Do not
"fix" them to match the export.

For each one:

1. run `find_pattern_matches` / `verify_manifest.py` and confirm the pattern is
   **still unique** in the new module;
2. record the new RVA it resolves to;
3. run `ida_manifest.py` to confirm the export still reaches that address.

If a pattern now matches **zero or many** places, it is dead. Re-derive it from
the PDB (§2c) and replace it — and find the shortest prefix that is unique again
(28 bytes was needed for `run_validation_movenext_offset`; 24 matched 8+ places).

### 2c. `native` symbols with a real RVA — 5 of them

`be_client_init`, `be_client_start`, `be_service_check`, `load_be_client`,
`load_be_client_known_offset`, plus `run_validation_movenext_offset`.

Re-derive the RVA **by name** from the PDB, not by patching the old hex:

```powershell
python tools/parse_pdb.py "TarkovAddons\GameDump\<build>\GameAssembly.pdb" --output rvas.json
```

Then inject, which refuses to silently drop a name:

```powershell
python tools/manifest_tool.py update-rvas <manifest> --rvas rvas.json --source pdb
```

> **`update-rvas` fails loudly on an unknown symbol name** (exit 1, writes
> nothing) rather than warning and applying the rest. That is deliberate. It
> exists because the old behaviour printed `WARN skipping unknown symbol`,
> `Updated 3 symbol(s)` and exited **0**, which is how `0x1B76260` came to be
> recorded nowhere in version control. `--allow-unknown` overrides, deliberately.

`be_service_check` is in `UnityPlayer.dll`, which ships **no PDB**. It cannot be
re-derived by name at all; its pattern is the only handle. If the pattern dies
there is no automated path back — budget for manual work.

### 2d. `hwid_check` — a call site, not a function

Its RVA addresses the **call instruction** above the HWID check, not a function
entry. Confirmed: first byte is `E8`, and it sits `+0x153` into an 808-byte
function. A PDB name lookup for it will find the *enclosing* function and be
wrong. Keep the pattern.

---

## 3. Record what you resolved against, and how

Per symbol, set `source` to what actually produced the value (`pdb`,
`ida-pattern-scan`, …) and put the **PDB name** in `notes`. That name is what
lets the next person check your work without re-running anything.

Write notes in terms that survive a rebuild. **Never write a compiler-generated
ordinal.** `EFT.AnticheatValidationOperation+<RunValidation>d__10::MoveNext` is
wrong the moment any method is added earlier in that class: the compiler numbers
async state machines in declaration order, and this PDB has 279 distinct `d__NN`
values, up to `d__1640`. Record `+<RunValidation>::MoveNext`. Same rule for
`d__`, `<>c`, and `<Foo>b__` — anything the compiler names.

For the same reason, prefer a symbol's *stable* name over its address everywhere
in the tree. The one address that is safe to write down is a **pattern**, because
`verify_manifest.py` re-checks it against the new bytes.

---

## 4. The pattern-vs-export question, and why it is not a bug

Expect every `il2cpp_*` pattern symbol to resolve to a different address than
the export of the same name. Measured on `1.1.5.1.47510`:

| shape | symbols |
|---|---|
| export is a 5 B thunk to the pattern's RVA | `il2cpp_domain_get`, `il2cpp_field_static_set_value`, `il2cpp_type_get_object` |
| export `call`s / `jmp`s the pattern target | `il2cpp_class_get_field_from_name`, `il2cpp_class_get_nested_types` |
| export reaches it indirectly at depth 2 | `il2cpp_class_from_name`, `il2cpp_class_get_method_from_name`, `il2cpp_field_static_get_value` |

The patterns resolve the **unwrapped body**; the export is a wrapper around it.
The forwarding stubs are why the indirect cases are fine:

```
sub_18033A2B0:  xor r9d, r9d ; jmp sub_180208CF0
sub_1803165B0:  xor r8d, r8d ;  jmp sub_1800E41C0
```

Each zeroes a register before jumping, and the body reads it. That is the whole
reason calling the body directly is legal — and why the call sites in
`exports.h` pass that argument explicitly, e.g. the 4-arg cast with a literal
`0` as the 4th argument to `il2cpp_class_get_method_from_name`. **If you change
a cast's arity, or drop the explicit zero, you reintroduce a real bug** and no
checker in this repo will catch it.

---

## 5. Update the legacy cfg files too

The manifest does not replace `offsets.cfg`/`patterns.cfg`; both remain seeds
and a runtime fallback. After a rebuild:

- `patterns.cfg`: any pattern you replaced in §2b.
- `offsets.cfg`: any RVA you changed in §2c, **including the two
  `load_be_client_known_offset` / `run_validation_movenext_offset` slots**.

Keep the comment above each key describing the function, and keep the
"blank means use the built-in signature" convention. A key that exists in a cfg
but has no manifest symbol is an invisible dependency — `hwid_check` was one
once, invisible for its whole life.

Then confirm coverage, which should be total:

```powershell
python tools/verify/verify_manifest.py <manifest> <new-module-dir>
#   cfg offsets.cfg: 20 keys, 20 present in the manifest, 0 absent
#   cfg patterns.cfg: 15 keys, 15 present in the manifest, 0 absent
```

(13 was the 1.1.5.1-era figure; the count moved when the `hwid_check` and
`be_service_check` slots were given explicit values. Re-measure, don't quote.)

`pytest tools/tests` includes `ShippedProfileDriftTests`, which fails if the
shipped profile diverges from what the importer produces from the cfg files. Its
`KNOWN_MISSING_FROM_SHIPPED` tuple is **empty** and must stay empty.

---

## 6. Verify, in increasing strength

```powershell
# 1. schema + bytes, needs the new module dir
python tools/verify/verify_manifest.py <manifest> <new-module-dir>
#    expect: PASS <N> symbol(s) ... exit 0

# 2. the generator's own view
python tools/manifest_tool.py validate <manifest> --module-dir <new-module-dir> --strict
#    expect: Manifest validation passed, exit 0

# 3. names and call chains, needs a licensed IDA + matching .i64
python tools/verify/ida_manifest.py <manifest> <new-module-dir>
#    expect: All gates passed, exit 0

# 4. no regression in the offline suite
python -m pytest tools\tests
```

**Step 3 is the one that can tell you something is right** rather than merely
consistent. Step 1 cannot: it proves the bytes match, not that the bytes are the
right function. Two separate wrong-but-consistent states have already existed in
this repo, and both passed step 1:

- a manifest missing 2 of its symbols entirely;
- `parse_pdb.py` returning a valid RVA for the wrong method.

If step 3 reports `INPUT HASH MISMATCH`, the `.i64` is from a different build
and every name it gives you is fiction. Do not work around it — re-import the
database against the new DLL.

---

## 7. Negative controls: confirm the checks can fail

A green run is only evidence if the same command goes red on a known-bad input.
Before trusting any of this on a new build, spend two minutes:

```powershell
# move one RVA off its pattern -- must fail
python tools/manifest_tool.py update-rvas <copy> --rvas <file with one wrong RVA>
python tools/verify/verify_manifest.py <copy> <module-dir>   # expect exit 1

# corrupt the module hash -- must fail
python tools/verify/verify_manifest.py <corrupted copy> <module-dir>  # expect exit 1

# point it at nothing -- must exit 2, NOT 0
python tools/verify/ida_manifest.py <manifest> <nonexistent-dir>  # expect exit 2
```

If any of those passes, the checker is broken, not the manifest. This is not
hypothetical caution: during this work a negative control of mine **failed to
fire**, and the cause was a vacuous control rather than a tool bug — it had
cleared `patterns[]` *and* moved the RVA, and `resolution_order:
["pattern","export"]` never consults an RVA at all, so the tamper was inert. A
control that cannot fail is worse than none.

---

## 8. Order of operations, condensed

1. obtain the new DLLs; check the PDB/dump.cs directory matches
2. write the new `modules` identity (`SizeOfImage`, timestamp, `.text` hash)
3. `export` symbols — verify the 6 names still exist
4. `pattern` symbols — re-scan, confirm unique, re-derive if not
5. `native` RVA symbols — re-derive **by name** from the PDB, then `update-rvas`
6. re-derive the `il2cpp_*` arity casts in `exports.h` if any wrapper changed
7. update `offsets.cfg` / `patterns.cfg`; confirm 0 absent
8. `verify_manifest.py` → `validate --strict` → `ida_manifest.py` → `pytest`
9. run the negative controls
10. commit, then `build.ps1`, then install and launch through `BsgLauncher.exe`

Steps 3→5 are ordered most-stable-first on purpose. Doing the RVA-dependent work
first and the name-based work last means a mistake in the hard part does not
invalidate the easy part.

---

## Worked example — the 1.2.0.0.47888 refresh, as executed 2026-10-06/07

The run above, written down so the next update is a checklist rather than a
re-derivation. Commit chain: `f0ba59d71` (seed, unverified) → `54c6b683b`
(fix + verification) → `d2861e494` (cfg alignment) → `7dd4017c1` (deploy
newest-only). Every command below was run from the repo root.

**Materials.** `TarkovAddons/GameDump/120047888/` held everything in one
directory — both DLLs, `GameAssembly.pdb`, and both `.i64` files — unlike
1.1.5.1, whose dump and PDB lived in two differently-numbered directories.
**No ISIL tree existed for the new build** at the time (the 1.1.5.1 tree had
just been removed as stale), and that turned out not to matter: `import` works
without `--isil-root`; it only affects provenance. One prerequisite that *does*
bite: `parse_pdb.py` needs `pip install purelypdb`.

**1 — Seed the profile.** Import from the legacy cfg, RVAs cleared, identity
checked against the new dump:

```powershell
python tools/manifest_tool.py import `
  --offsets TarkovAddons/offsets.cfg `
  --patterns TarkovAddons/patterns.cfg `
  --clear-rvas `
  --module-dir TarkovAddons/GameDump/120047888 `
  --output compatibility/profiles/1.2.0.0.47888/manifest.json
```

This yields 21 symbols at `unverified`. Without `--isil-root`, nothing detects
the build for you — pass `--game-version 1.2.0.0.47888` (the profile id
derives from it as `eft-<version>`) or set the `profile` block by hand after
the import. (As it happened, the seed also carried
three PDB-derived RVAs from an earlier in-progress attempt — that history is
not part of the procedure; a clean import starts with every RVA null.)

**2 — Re-derive native RVAs from the PDB, by name.** First update
`tools/parse_pdb.py`'s `SYMBOL_PATTERNS` for the new PDB, *then* run it — the
matcher details are in the file's comments and cost real time here:

```powershell
pip install purelypdb
python tools/parse_pdb.py "TarkovAddons\GameDump\120047888\GameAssembly.pdb" --output rvas.json
python tools/manifest_tool.py update-rvas `
  compatibility/profiles/1.2.0.0.47888/manifest.json --rvas rvas.json --source pdb
```

- The 1.2.0 PDB changed notation: `$$` as the member separator and
  dot-nested types (`.<RunValidation>d__10`). The matcher normalizes both
  generations, so one pattern set serves both.
- **The decoy.** The stale `("BEClient", "CreateInstance")` entry bound
  `load_be_client` to `0x18D0F70` — on this build `CreateInstance` is a *real
  method* with no call edge to `MoveNext`, so patching it leaves `BEClient.Start`
  called and the bypass inert. Correct binding: `("RunValidation", "Start")`,
  which the 1.2.0 PDB names explicitly → `0x40B2290`. Three oracles agreed
  (PDB name, unique pattern, IDA call edge to `MoveNext` at `+0x85`).
- If the tool prints `AMBIGUOUS`, fix the pattern — never take the first hit.

**3 — The symbols no PDB names.** Hand-write `rvas_scan.json` (three entries)
and inject it the same way, with an honest source label:

```json
{ "be_service_check": "0x491E60",
  "hwid_check": "0x3B86B93",
  "load_be_client_known_offset": "0x40B2290" }
```

```powershell
python tools/manifest_tool.py update-rvas `
  compatibility/profiles/1.2.0.0.47888/manifest.json `
  --rvas rvas_scan.json --source pattern-scan
```

Where the values come from: `be_service_check` by unique pattern scan on
`UnityPlayer.dll` (it ships no PDB); `hwid_check` by unique scan on
`GameAssembly.dll` (it is a call site — §2d — so no PDB name exists even in
principle); `load_be_client_known_offset` is `offsets.cfg`'s second name for
`load_be_client`'s address — one address, two symbols, both must exist so
`update-rvas` can address either.

**4 — Restore per-symbol shape by hand.** `update-rvas` writes only `rva` and
`source`; the importer emits degraded shape. For each native symbol, set
`resolver: native`, `resolution_order: ["native", "pattern"]`,
`fallback: "pattern"`, `kind: "function"` (the `_offset`-suffix heuristic will
otherwise call it data), a `notes` string naming the PDB symbol, then the
`provenance` block and `status: "validated"`. The 1.1.5.1 profile is the
reference shape — diff against it.

**5 — Verify, in the §6 order.** All three passed on the first honest attempt:

```powershell
python tools/verify/verify_manifest.py compatibility/profiles/1.2.0.0.47888/manifest.json TarkovAddons/GameDump/120047888
#    PASS 21 symbol(s), exit 0        (note: POSITIONAL args, no --module-dir)
python tools/manifest_tool.py validate compatibility/profiles/1.2.0.0.47888/manifest.json --module-dir TarkovAddons/GameDump/120047888 --strict
python tools/verify/ida_manifest.py compatibility/profiles/1.2.0.0.47888/manifest.json TarkovAddons/GameDump/120047888
#    All gates passed                 (names confirmed every symbol)
```

Plus the three §7 negative controls (all fired) and a fresh-import
cross-check: re-running step 1 into a scratch file after the cfg alignment
emitted the same 21 names, `status=validated`, zero warnings.

**6 — cfg alignment, commit, build, launch.** Fill `offsets.cfg`/`patterns.cfg`
with the new values (§5), commit, `build.ps1`, install, launch through
`BsgLauncher.exe`. The proof the profile loaded, from
`tarkovaddons_log.txt`:

```
IL2CPP compatibility profile loaded: eft-1.2.0.0.47888 (1.2.0.0.47888) from ...\ta\compatibility\profiles\1.2.0.0.47888\manifest.json
IL2CPP API Loaded via compatibility profile
```

**7 — Deploy only the newest profile.** `tools/deploy.py` (since `7dd4017c1`)
ships exactly the newest version-named profile directory and prunes stale ones
from the install on `install`. Reason: the launcher-side selector
(`TarkovLauncherBypass/util/compat_profile.cpp`) ranks by `status` and breaks
ties by first-encountered — directory enumeration order, which is alphabetical,
so the *oldest* wins a tie. `UnityPlayer.dll` was **byte-identical** between
1.1.5.1 and 1.2.0, so both profiles matched the launcher's out-of-process
anchor and only that ranking decided. Today `validated` beats `staged` by luck
of the current statuses; shipping one profile removes the question.

**What differed from this runbook's 1.1.5.1-era assumptions** — read this list
before the next build:

- `load_be_client`'s address **is PDB-named on 1.2.0** (the 1.1.5.1 trap "no
  PDB symbol, derive from dump.cs/ISIL/IDA" no longer applies), and a real
  `CreateInstance` method now exists to be wrongly bound.
- `UnityPlayer.dll` can be byte-identical across builds — never assume the
  launcher anchor distinguishes two profiles.
- The dump layout (one directory vs two) and the PDB's naming conventions both
  changed between these two builds; nothing enforces either. Check, don't
  assume.
- `il2cpp_*` needed **zero work**: all 8 patterns still unique, all 6 export
  names still present — only addresses moved. Expect this to be the common
  case; do not start by re-deriving them.

---

## `load_be_client` — the name is wrong, the patch is not

A known, deliberately-unfixed naming defect, documented so the next person does
not "fix" it without a live launch. Read this before touching `0xEE2660`.

> **1.2.0.0.47888 update (2026-10-06).** The addresses moved but every
> conclusion held: `load_be_client` / `load_be_client_known_offset` →
> `0x40B2290`, `run_validation_movenext_offset` → `0x237F900`, and
> `BEClient.Start`/`Init` → `0x1F62400`/`0x1EABFE0`. Two facts *changed*:
> the 1.2.0 PDB names the generic instantiation explicitly (so the "no PDB
> symbol" trap below no longer applies — but a real `CreateInstance` method
> at `0x18D0F70` now exists as a decoy, see the worked example), and the
> launcher consumes the manifest directly (`disabler.cpp` patches this
> symbol by name). Everything below is the 1.1.5.1.47510 analysis.

**What the address is.** `sub_180EE2660`, a 192-byte function. `dump.cs` places
`AsyncTaskMethodBuilder.Start<AnticheatValidationOperation.<RunValidation>d__NN>`
there, and the ISIL call site shows `rcx=builder`, `rdx=stateMachine`, which is
that signature. It is **not** `RunValidation`'s entry point, and there is no
`BattlEye.BEClient::CreateInstance` anywhere in the game — that name came from
`CreateInstanceResult`, the *return type* of `BEClient::Start`.

**Why two manifest symbols carry one RVA.** `load_be_client` and
`load_be_client_known_offset` are both `0xEE2660`. Not a duplicate:
`offsets.cfg` documents the address as `load_be_client_known_offset`, and
`disabler.cpp:83` patches the manifest symbol `load_be_client`. Both names must
exist so `update-rvas` can address either.

**The name is a description of the effect, and it is accurate — do not "fix" it.**
The chain, all four links verified:

```
RunValidation()                    ISIL AnticheatValidationOperation.txt
  → 0xEE2660                       the Start<stateMachine> + get_Task pair
    → MoveNext()                   0x1B76260 = run_validation_movenext_offset
      → BEClient.Start(...)        ISIL ..._RunValidation_d__10.txt instr 112
      → BEClient.Update()          instr 347
      → BEClient.Stop()            instr 388
```

`BEClient.Start` is called with the game version string
(`"Escape from Tarkov 1.1.5.1.47510"`) and returns `CreateInstanceResult`, which
is where that name comes from — it is `Start`'s *return type*, not a
`CreateInstance` method. Patching `0xEE2660` with `ret` means `MoveNext` never
runs, so `BEClient.Start` is never called: the function's job *is* to load
BEClient. The symbol is named for what it does.

**Why renaming would still be a mistake.** `disabler.cpp:83` selects the patch
target *by name*, and `disabler.cpp:297` repeats those names in the error an
operator sees when nothing patched:

```
the manifest must declare an RVA and a validation pattern for each of
load_be_client, be_client_start and be_client_init
```

Renaming the manifest symbol changes what the launcher patches unless
`disabler.cpp` changes in the same commit. Since the existing name is correct,
there is no reason to.

**On the three call sites.** `sub_180EE2660` is the shared body of the generic
`AsyncTaskMethodBuilder.Start<TStateMachine>`, and it has three callers:

| call site | shape |
|---|---|
| `0x1801c8fe4` | `add rcx, 10h ; jmp` — a 9-byte instantiation thunk |
| `0x182a15061` | `call`, from a 1424-byte function |
| `0x183fd5689` | `call`, from a 271-byte function |

All three pass `r8 = qword_185B6B270` — the same method-table slot — with the
state machine in `rdx` and the builder in `rcx`, then call `sub_183838430`
(`get_Task`) afterwards. So these are the same instantiation `RunValidation`
uses, not unrelated async methods: an earlier note here claimed the patch would
"skip every state machine in the game", and that was wrong. It reaches the
`Start` body for this builder layout.

Whether a *live* launch reaches it from any path other than `RunValidation` is
the only remaining open question, and it is a runtime question. `Start` returns
`void` and the real epilogue at `0x180ee270f` does not set `rax`, so the bare
`ret` is safe in the sense that matters — nothing reads a return value.

**Do not** "correct" the address to something that looks more like RunValidation.
`RunValidation`'s own body is `run_validation_movenext_offset` = `0x1B76260`,
a separate symbol the launcher does not patch — patching *that* instead would
skip `MoveNext` while leaving `Start` to initialise the builder, which is a
different and untested behaviour.

---

## Traps that have already cost time

- **`inf_get_start_ea()` is not the image base.** It returned `0x180519F18`
  against a true `0x180000000`, putting every lookup in the wrong segment and
  reporting `<unnamed>` for all 21 symbols — indistinguishable from "IDA has no
  names". Use `ida_nalt.get_imagebase()`.
- **Both RVAs fit inside *both* modules.** `SizeOfImage` cannot decide which
  module a symbol belongs to. Only reading the bytes can: in `UnityPlayer.dll`,
  `0x1B76260` is relocation data and `0xEE2660` is mid-function.
- **Executable ranges are not named `.text`.** This database splits code across
  `.text` and a segment literally called `il2cpp`. Test IDA's permission bit,
  not the name.
- **A unique byte sequence does not name a function.** That is all step 1 can
  prove.
- **`load_be_client` and `load_be_client_known_offset` are the same address**
  (`0xEE2660`) under two names. Not a duplicate — one is the manifest's name for
  the launcher patch target, the other is `offsets.cfg`'s. Both must exist so
  `update-rvas` can address either. See the `load_be_client` section above before
  touching it: the patch reaches **three** call sites, not one.
- **`0xEE2660` has no PDB symbol — on 1.1.5.1.** It is a compiler-emitted
  generic instantiation, so on that build its identity came from `dump.cs`,
  the ISIL call site and IDA. **1.2.0 changed this:** the PDB names it
  explicitly (`AsyncTaskMethodBuilder$$Start<...<RunValidation>d__10>`), and
  in the same breath made `BattlEye.BEClient$$CreateInstance` a *real method*
  at `0x18D0F70` — which the old `("BEClient","CreateInstance")` pattern
  happily bound. A correct-looking PDB answer can still be the wrong function;
  check the call edge.
- **A `MoveNext` pattern must name the nested type.** `MoveNext` appears 10231
  times in this PDB and 852 of 2069 classes have more than one. `+<RunValidation>`
  carries the specificity.
- **`update-rvas` exit 0 used to mean "possibly wrong".** It no longer does.
- **`import` always writes its output file**, even when validation fails. Never
  promote a failing profile by hand-editing `status`.