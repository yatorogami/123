# Compatibility profiles — usage guide and audit record

Scope: the versioned compatibility-profile system (tooling, manifest schema, C++
runtime loader, build packaging) plus a consolidated audit of the working tree as
of **2026-09-25**, branch `ISIL_115147510` at `3f79d343`.

This is the canonical usage document. `compatibility/README.md` remains the short
status/module reference; `tools/README.md` remains the CLI reference.

> **Verification status, stated up front:** the tooling, the manifest and all four
> x64 build configurations are verified by build and test. The runtime profile
> code path **has now been executed against a live game process**: on 2026-10-07
> the log recorded `IL2CPP compatibility profile loaded: eft-1.2.0.0.47888
> (1.2.0.0.47888) from ...\ta\compatibility\profiles\1.2.0.0.47888\manifest.json`
> followed by `IL2CPP API Loaded via compatibility profile` — the first observed
> profile load in the project's history, on the build after the F15/F17 fixes.
> That observation covers profile *selection* and the 14 required-symbol
> resolution; it is not a per-feature exercise of every optional symbol.

---

## 1. What this system is for

The legacy runtime located IL2CPP entry points with two loose key/value files
(`offsets.cfg`, `patterns.cfg`) and a set of hardcoded fallbacks. When BSG moved a
function, that meant hand-editing values that were never checked against anything.

This replaces that with a per-build, statically validated JSON manifest that the
C++ runtime actually consumes:

```
compatibility/profiles/<game-build>/manifest.json
```

Three rules govern everything below:

1. **Profiles are per build.** Never copy an RVA from one build's profile into
   another's. `--clear-rvas` exists for this.
2. **ISIL references are authoritative for build identity and semantics**, but
   cannot produce reliable raw byte patterns — they are not a complete PE image.
3. **The tooling is file-only.** It never attaches to a process, injects, patches
   memory, or discovers anti-cheat targets.

---

## 2. File map

| Path | Role |
|---|---|
| `tools/manifest.schema.json` | JSON Schema (draft 2020-12) for the manifest |
| `tools/manifest_tool.py` | importer, ISIL inspector, PE/pattern validator |
| `tools/tests/test_manifest_tool.py` | 25 tests for the tooling |
| `compatibility/profiles/1.2.0.0.47888/manifest.json` | current build profile (**21** symbols, 14 required, `validated`, observed loading at runtime) |
| `compatibility/profiles/1.1.5.1.47510/manifest.json` | previous build's profile, kept as the rollback path (`staged`, 21 symbols) |
| `compatibility/README.md` | short status + module-mapping reference |
| `compatibility/PROFILE_GUIDE.md` | this document |
| `compatibility/REFRESH_RUNBOOK.md` | **ordered procedure for a new game build** — read before editing any RVA |
| `TarkovAddons/il2cpp/compatibility_profile.h` | runtime loader public interface |
| `TarkovAddons/il2cpp/compatibility_profile.cpp` | manifest discovery, parsing, identity match; compiled into **both** DLLs |
| `TarkovAddons/il2cpp/il2cpp_offsets.h` | profile branch inside `il2cpp_offsets::init()` |
| `TarkovAddons/TarkovAddons.vcxproj` | `Content` item that ships profiles in every config |
| `TarkovLauncherBypass/TarkovLauncherBypass/util/compat_profile.h` | launcher-side consumer interface |
| `TarkovLauncherBypass/TarkovLauncherBypass/util/compat_profile.cpp` | out-of-process profile selection (UnityPlayer dump anchor), RVA/pattern resolution, GameAssembly identity verification |

### Legacy inputs, now import seeds only

| File | Still read by runtime? | Role now |
|---|---|---|
| `TarkovAddons/offsets.cfg` | yes, **only** when no profile is packaged | import seed |
| `TarkovAddons/patterns.cfg` | yes, **only** when no profile is packaged | import seed + documented blank-slot registry |
| `TarkovLauncherBypass/launcher.cfg` | unchanged | unchanged |

---

## 3. Usage

### 3.1 The normal case: do nothing

A profile for the build you are running is already committed and already ships
with the binary. Build and run. If the loader cannot find a profile it falls back
to the legacy files (§3.5) and logs that it did.

### 3.2 A new game build arrives

This is the workflow the system exists for. Detect, import, validate, build.

**Step 1 — identify the build from ISIL references.**

```powershell
python tools/manifest_tool.py inspect-isil TarkovAddons/ISIL-references/IsilDump
```

Add `--no-count` to skip the `Type:`/`Method:` census, `--output report.json` to
save it. The repo carries ISIL trees for both builds — `115147510` and (since
commit `5e20ee59c`) `120047888` under `TarkovAddons/ISIL-references/`. The
1.2.0.0.47888 refresh itself ran with **no ISIL tree available** and passed
`--game-version` to the import instead — ISIL is a provenance aid, not a
prerequisite (see the worked example in `REFRESH_RUNBOOK.md`).

**Step 2 — create a profile directory and import.**

```powershell
python tools/manifest_tool.py import `
  --offsets TarkovAddons/offsets.cfg `
  --patterns TarkovAddons/patterns.cfg `
  --isil-root TarkovAddons/ISIL-references/IsilDump `
  --clear-rvas `
  --module-dir <dir containing GameAssembly.dll and UnityPlayer.dll> `
  --output compatibility/profiles/<new-build>/manifest.json
```

`--clear-rvas` is the important flag: legacy RVAs are treated as candidates only
and `rva` is emitted as `null`. The new profile starts at `unverified` and is only
promoted to `staged`/`validated` if the `--module-dir` pass succeeds. Without
`--module-dir` you get a syntactically valid but unverified profile.

The importer emits one warning per unresolved symbol and prints
`status=<state>` plus the symbol count on success.

**Step 3 — validate against real module files.**

```powershell
python tools/manifest_tool.py validate `
  compatibility/profiles/<new-build>/manifest.json `
  --module-dir <same dir>
```

This checks `SizeOfImage`, PE timestamp, and re-scans every declared pattern
against the real `.text` section. Add `--strict` to promote warnings to errors —
appropriate in CI, not while a profile still has known-unresolved entries.

**Step 4 — confirm and build.**

Expected clean output for the current profile is `Manifest validation passed`
with **zero warnings**, with or without `--strict` (measured for
`1.2.0.0.47888`; see `README.md`'s "Validate the current profile"). Then:

```powershell
cd TarkovAddons
msbuild TarkovAddons.sln /p:Configuration=Prod /p:Platform=x64
```

The `Content` item copies every `compatibility/profiles/**/manifest.json` into
the output tree, so nothing extra is required per configuration.

**Step 5 — verify at runtime.** Look for
`IL2CPP compatibility profile loaded: <id> (<game_version>) from <path>` in
`tarkovaddons_log.txt`. Anything else (§3.5) means the profile was not used.

### 3.3 Regenerate, do not hand-merge

`manifest.json` files are generated artifacts. Re-run `import` rather than editing
by hand — a hand-merged profile loses the provenance and status logic. If you must
patch a field, re-run `import` afterwards and diff to confirm the change is the
only one.

### 3.4 Keep old profiles

Never overwrite an existing profile directory. Old profiles are the rollback path
and are harmless at runtime: the loader selects by module identity, so a
non-matching profile is simply never chosen.

### 3.5 What the runtime does at startup

Search order and decision table, implemented in
`TarkovAddons/il2cpp/compatibility_profile.cpp` and called from
`il2cpp_offsets::init()`:

1. Read the loaded `GameAssembly.dll` identity: `SizeOfImage` via
   `GetModuleInformation`, PE timestamp via the in-memory NT header (read through
   a `VirtualQuery`-guarded accessor).
2. Recursively collect `manifest.json` under
   `<data directory>/compatibility/profiles/` — where the data directory is
   `ta/` beside the DLL when it exists and the DLL directory otherwise
   (`module_paths::data_directory_wide()`).

   > **Was a live mismatch until 2026-10-01 — F15, fixed and confirmed 2026-10-02.**
   > The loader read `<dll dir>/compatibility/profiles/` while
   > `TarkovAddons.vcxproj` and `deploy.py` both put the manifest at
   > `<deploy>/ta/compatibility/profiles/`, so every deployed build fell back to
   > legacy `offsets.cfg`/`patterns.cfg` with no error. Fixed by having
   > `load_for_module` use `module_paths::data_directory_wide()` — the accessor
   > the launcher process already used correctly. The profile then loaded
   > (`IL2CPP compatibility profile loaded: eft-1.1.5.1.47510`, the first time in
   > the project's history).
   >
   > **It immediately exposed F17** (`AGENTS_TODO.md` §5.9): activating the
   > fail-closed path and the 14-required-symbol enforcement below meant that on
   > 3 launches in 4 the enforcement stopped the mod from starting — 6 of the 14
   > symbols are `export`-resolver and a single `GetProcAddress` returned NULL
   > with `ERROR_MOD_NOT_FOUND`, because the loader had unlinked
   > `GameAssembly.dll` from its module list while the image stayed mapped and
   > readable (§5.9a). **F17 is mitigated, not merely diagnosed:** the export
   > resolver now hand-parses the export table when `GetProcAddress` fails that
   > way, and logs how many symbols needed the direct read. The 2026-10-07
   > 1.2.0.0.47888 launch recorded `0 of 14 required symbol(s) needed a direct
   > read of the export table ... The loader listed the module for all of them
   > this launch` — the mitigation present, unexercised that launch.
   > `tools/tests/test_profile_path.py` holds the reader, the build and
   > `deploy.py` to one directory.
3. Parse each candidate; keep those that match **both** `size` and `pe_timestamp`.
4. Rank surviving candidates by status: `verified` > `validated` > `staged`.
   `unverified` is refused outright. Two candidates at the same rank is an error.
5. Enforce the 14 required symbols (see §6).

| Outcome | Condition | Behaviour |
|---|---|---|
| **Loaded** | a profile matches | resolve the 14 required symbols from it; any failure stops startup |
| **NotFound** | no `compatibility/profiles` directory | log it, fall back to legacy `offsets.cfg`/`patterns.cfg` |
| **Mismatch** | profiles exist, none match | **fail closed** — startup stops |
| **Invalid** | malformed JSON, duplicate symbols, ambiguity | **fail closed** — startup stops |

The asymmetry is deliberate: a deployment that ships no profile is a legacy
deployment and keeps working; a deployment that ships a profile which does not
match the running game must not silently use stale data.

---

## 4. Manifest reference

Top level, all four keys required, `additionalProperties: false` everywhere:

```json
{
  "schema_version": 1,
  "profile":  { ... },
  "modules":  { "<module>.dll": { ... } },
  "symbols":  [ { ... } ]
}
```

### `profile`

| Field | Notes |
|---|---|
| `id` | required, `^[A-Za-z0-9._-]+$`; derived from the build when omitted |
| `game_version` | required |
| `architecture` | `x64` or `x86`; the loader refuses anything but `x64` |
| `status` | `unverified` / `staged` / `validated` / `verified` |
| `source_commit` | optional |
| `provenance` | `source_kind`, `isil_reference`, `verified_at`, `notes` |
| `notes` | free text |

Status meanings: `unverified` imported/edited without module-backed validation;
`staged` module data collected but warnings remain; `validated` PE identity, RVAs
and declared patterns passed static checks; `verified` additionally runtime-tested.
`validated` is **not** a claim that every optional feature was exercised live.

### `modules`

```json
"GameAssembly.dll": {
  "size": 107925504,
  "pe_timestamp": "0x6AAD381A",
  "text_sha256": "827a8463a9c0cbf0..."
}
```

- `pe_timestamp` **must be a string** matching `^0x[0-9A-Fa-f]+$`. The runtime
  loader requires it and requires a match; a numeric value is rejected.
- Both `size` and `pe_timestamp` are mandatory for runtime selection. Size alone
  is not enough.
- `text_sha256` is recorded and checked **offline only**. The runtime does not hash
  the loaded image (see §10).

### `symbols`

Required: `name`, `module`, `kind`, `rva`, `patterns`, `required`.

| Field | Notes |
|---|---|
| `kind` | `function` / `data` / `unknown` |
| `resolver` | `native` / `pattern` / `export` / `managed` |
| `resolution_order` | array of `rva`/`pattern`/`export`/`managed`/`native`, tried in order |
| `rva` | `null` or a string, `^(0[xX][0-9A-Fa-f]+\|[0-9]+)$` |
| `patterns` | array of strings, **min length 3** |
| `expected_matches` | integer ≥ 1; the runtime requires exactly `1` for pattern symbols |
| `export_name` | defaults to `name` when omitted |
| `fallback` | `pattern` / `export` / `none` — documentation of intent |
| `required` | `true` gates runtime startup, see §6 |
| `managed` | managed reference, see below |

A `managed_reference` needs `assembly`, `namespace`, `type`, `member`,
`member_kind` (`field`/`method`/`property`); optional `argument_count`,
`declaring_type`. A `managed` resolver without a reference is rejected.

---

## 5. Conventions

**Blank slots in the legacy cfg files.** `patterns.cfg` documents its own rule:
a blank value means "use the signature compiled into the DLL", and the file is a
ready-made slot rather than a copy of the defaults. Keep new keys consistent —
declare them blank and let the importer pick them up. (As of the 1.2.0.0.47888
refresh the `be_service_check` and `hwid_check` slots are *filled* with the
current patterns, so a fresh import resolves everything; the blank rule still
governs any slot you have no measured pattern for yet.)

**Tracked-but-unresolved symbols.** A symbol that is genuinely consumed by the
code but has no manifest RVA or pattern should be **imported and left empty**,
`required: false`, rather than omitted. Validation then reports it as a permanent,
explained warning instead of it being an invisible hardcoded dependency.

A fresh import produces such entries only for blank cfg slots — historically
`be_service_check` (UnityPlayer.dll has no PDB, so its pattern is the only
handle) and `hwid_check` (signature compiled into the launcher DLL). While
those two slots were blank, each import reported one warning per slot.

The **shipped** profile has none. Every optional native symbol carries both a
manifest RVA and a pattern — the RVAs re-derived by PDB name or unique pattern
scan (`source: pdb` / `pattern-scan`) — so it validates with zero diagnostics,
including under `--strict`.

An earlier revision of this document claimed four such entries. Two of them,
`load_be_client_known_offset` and `run_validation_movenext_offset`, were also
*absent from the manifest entirely* despite being declared in `offsets.cfg` and
emitted by the importer; commit 49d9807c had dropped them. They were restored
2026-10-06, so `ShippedProfileDriftTests` now asserts that nothing is dropped at
all (its exception tuple is empty) and the profile has 21 symbols, 14 required.

None of these are loaded by `TarkovAddons.dll`; they exist so the validator can
report on them. (The launcher side is the consumer — §10.5.)

**Module naming.** The native PE is `UnityPlayer.dll`. `UnityEngine` is a managed
namespace, not a file. The importer maps legacy keys to modules explicitly
(`_module_for_legacy_name`) and that mapping is covered by tests — do not let a
new key rely on the `--default-module` fallback, which silently follows whatever
default the caller passed.

**Required vs optional.** Only the 14 `il2cpp_*` symbols are required. Anything
launcher-side is optional so it can never block main-DLL startup.

---

## 6. Runtime resolver semantics

`resolve_profile_symbol()` in `il2cpp_offsets.h` only handles
`module == "GameAssembly.dll"`. With no explicit `resolution_order` it derives:

| `resolver` | Derived order |
|---|---|
| `pattern` | `pattern`, then `export` |
| `export` | `export` |
| `native` | `native` (RVA) |

- `pattern` — each pattern in `patterns` via `scan::find_pattern`, with retry.
- `export` — `GetProcAddress`, then a direct hand-parse of the export table if
  that fails with `ERROR_MOD_NOT_FOUND` (the loader-unlisted state, F17), then
  jump to the real body if the resolved export is a thunk.
- `native`/`rva` — `module_base + rva`, bounds-checked against the image size.

The 14 names the loader enforces, all `GameAssembly.dll`, all `required: true`:

```
il2cpp_class_from_name              il2cpp_field_static_get_value
il2cpp_class_get_nested_types       il2cpp_field_static_set_value
il2cpp_class_get_field_from_name    il2cpp_field_get_value_object
il2cpp_class_get_method_from_name   il2cpp_string_new
il2cpp_domain_get                   il2cpp_type_get_object
il2cpp_domain_get_assemblies        il2cpp_array_new
il2cpp_object_new                   il2cpp_runtime_class_init
```

A profile is refused at load time if any is missing, not required, on the wrong
module, uses a resolver outside `{native, pattern, export}`, declares a pattern
symbol with no patterns or `expected_matches != 1`, or declares a required native
symbol with neither RVA nor pattern.

Current required-symbol mix: **8 pattern, 6 export**.

---

## 7. Build and packaging

One unconditional `Content` item in `TarkovAddons.vcxproj`:

```xml
<Content Include="$(MSBuildThisFileDirectory)..\compatibility\profiles\**\manifest.json">
  <Link>compatibility\profiles\%(RecursiveDir)%(Filename)%(Extension)</Link>
  <CopyToOutputDirectory>PreserveNewest</CopyToOutputDirectory>
</Content>
```

> **The `<Link>` below is not what the project contains.** The unconditional
> `Content` item at `TarkovAddons.vcxproj:438-444` is the same `Include` with
> `<Link>ta\compatibility\profiles\…</Link>` and `<Visible>false</Visible>`, and
> that is what every configuration actually produces. The `ta\` prefix was added
> so Debug and Release ship a profile too — previously the copy lived only in the
> two Prod post-build steps, so those two configurations shipped none and the
> runtime fell back silently. That reasoning is sound and has not been undone;
> the guide is what fell behind, and moving the `<Link>` without moving the
> reader is what broke the lookup (F15). The runtime now reads the same
> `ta\compatibility\profiles` via `data_directory_wide()`. See §3.2.

`MSBuildThisFileDirectory` rather than `SolutionDir` so it also resolves when the
`.vcxproj` is built directly. All four x64 configurations are `stdcpp23`, required
by `external/safetyhook` (`std::expected`).

Outputs, each containing every committed profile under
`ta/compatibility/profiles/<build>/manifest.json`
(`1.2.0.0.47888` and `1.1.5.1.47510` at the time of writing — though
`deploy.py` prunes all but the newest when installing):

| Configuration | Output |
|---|---|
| `Prod\|x64` | `out/prod/with_aimbot/` |
| `Prod no aimbot\|x64` | `out/prod/no_aimbot/` |
| `Debug\|x64` | `x64/Debug/` |

(`Release|x64` also carries it — the item is outside every `Condition`.)

Confirm with `Get-ChildItem out -Recurse -Filter manifest.json` rather than
trusting this table; it was wrong once, in the way described above.

---

## 8. Tests

```powershell
python -m pytest tools/tests -q      # 480 passed, 23 subtests, 15 skipped, 4 failed (measured 2026-10-12 on LINUX)
```

**Exactly one of those 4 failures concerns this subsystem**, and it is the one
that was already recorded here: `test_shipped_patterns_cfg_exposes_hwid_check_slot`
still asserts the `hwid_check` cfg slot is blank — stale since the 1.2.0 refresh
filled it (see §5; the cfg prose reconciliation is owned by another
workstream). `test_profile_path.py` and `ShippedProfileDriftTests` pass.

The count moved a long way from the 304 / 9 subtests / 3 failed this section
recorded on 2026-10-07, and **two of those three failures are now fixed** —
`test_brace_balance` and `test_call_through_null_scan` were negative controls and
both pass. The 4 that remain are 1 here plus 3 that cannot fail on Windows at all
(they spawn `cmd` or compare backslash paths); `AGENTS.md` names them and is the
place this figure is maintained.

`python -m unittest discover -s tools/tests` also runs but under-reports
(subtests are not counted). Prefer pytest.

Coverage includes legacy parsing, ISIL build detection, pattern parsing, PE
inspection and RVA/file-offset conversion, schema validation, module mapping
(including the non-default `default_module` regression), the `hwid_check`
tracking invariant, the pre-3.2 legacy import in `tools/migrate_legacy.py`,
and — since 2026-10-01 — `test_profile_path.py`, asserting
that the reader, the build and `deploy.py` still name the same directory (F15/F16).

There are **no C++ unit tests** for the loader itself — see §10. The path assertion above
is a text test by necessity, since `compatibility_profile.cpp` pulls in `pch.h`
and `safetyhook` and cannot be executed here; it is negative-controlled with four
deliberate breaks, all of which fail it.

---

## 9. Audit findings, 2026-09-25

### Fixed

| ID | Finding | Resolution |
|---|---|---|
| F1 | `.gitignore` did not cover `out/`, `.vs/`, `GameDump/`; two stray ` ``` ` fences were being parsed as patterns | generic patterns (`out/`, `.vs/`, `GameDump/`, `*.map`, `*.pdb`, `*.VC.db`, …); fences removed |
| F2 | Only `Prod\|x64` and `Prod no aimbot\|x64` had a post-build copy, so `Debug`/`Release` shipped **no profile** and silently used the legacy resolver | single `Content` item, all configurations (§7) — **and this fix is what introduced F15** |
| F3 | `Debug\|x64` and `Release\|x64` were `stdcpp20` and could not compile at all | set to `stdcpp23`; `Debug\|x64` now builds |
| F4 | `Prod no aimbot\|x64` was `stdcpp20`, same `std::expected` failure | set to `stdcpp23` |
| F5 | 24 stale project entries: 4 deleted item-database/optics files, plus 20 `safetyhook\safetyhook\*.hpp` entries pointing at a layout that no longer exists | removed; a check now confirms every registered source/header/resource exists on disk |
| F6 | `module/game_item_db.h` was in neither `.vcxproj` nor `.filters` | registered in both |
| F7 | `hwid_check` was read by `feature/spoofer.cpp` but existed in no config file — an invisible compiled-in dependency. Its module was also assigned by the `--default-module` fallback, so a non-default default would have misfiled it | blank slot added to `patterns.cfg`; explicit `LEGACY_GAME_ASSEMBLY_KEYS` mapping; profile regenerated; 3 tests added |

### Open

| ID | Severity | Finding | Needs |
|---|---|---|---|
| F8 | med | Orphan duplicate `TarkovLauncherBypass` source tree: 22 committed files at the top level, 20 in `TarkovLauncherBypass/TarkovLauncherBypass/`, and the copies have diverged (orphan holds `0x2956650`/`0x9E9E80` and loose `?` signatures; shipping copy holds `0x2987530`/`0x9F1170`). Both `.sln` files resolve to the **nested** project, so the outer one builds nowhere | decision: delete the orphan |
| F9 | med | `out/prod/with_aimbot/intermediates/crash_report.txt` holds an unresolved `0xC0000005` at `TarkovAddons.dll+0x2F71D`. The dump's `GameAssembly.dll` size `0x066ED000` (107,925,504) matches our profile, so it is a real crash on the target build. It cannot be symbolized: the reported DLL image is 12,047,872 bytes vs 12,053,504 today | live repro against a matching binary |
| F10 | med | `TarkovAddons/ISIL-references` is **26,457 already-tracked files**. The ignore rule is a no-op for tracked content | `git rm -r --cached` if untracking is wanted |
| F11 | low | `Configuration::load` (`util/Config.h`) is permissive — no trim, BOM, comment or duplicate handling, last-wins on duplicates — while the Python importer is strict. Verified **not** a live break: `patterns.cfg` is CRLF and `scan::compile_pattern` breaks at the final token, so a trailing `\r` is discarded. Tab-separated patterns *would* fail | deliberate hardening |
| F12 | low | Mixed line endings across shipped config: `patterns.cfg` CRLF, `offsets.cfg`/`launcher.cfg` LF | normalize |
| F13 | low | Four dead `Win32` configurations in an x64-only project | prune |
| F14 | low | `_merge_docs.py` loose at repo root; `Workstream_status_2026-09-24.md` has a 227/99-line rewrite sitting uncommitted | housekeeping |
| F15 | **high** | **The profile never loaded, in any build, ever.** The loader read `<dll dir>/compatibility/profiles/`; the build and `deploy.py` both write `<deploy>/ta/compatibility/profiles/`. The manifest was deployed and valid, in a directory nothing read, and the runtime took the designed `NotFound` fallback — silently, every launch. Introduced by the F2 fix, which moved the `<Link>` under `ta\` for a sound reason without moving the reader or this guide | **FIXED 2026-10-01.** `load_for_module` now uses `module_paths::data_directory_wide()` — the accessor `TarkovLauncherBypass/util/compat_profile.cpp:140` already used correctly. Confirmed by launch 2026-10-02 (`eft-1.1.5.1.47510`) and again on `1.2.0.0.47888` (2026-10-07). `AGENTS_TODO.md` §5.8 |
| F16 | med | Nothing asserted the loader's search path equals the build's output path, which is why F15 shipped. `tools/manifest_tool.py validate` checks the manifest *file*; `tools/harness` compiles headers and never looks at the deployment layout | **FIXED 2026-10-01** — `tools/tests/test_profile_path.py`, 10 cases, checking the `.vcxproj` `<Link>`, `deploy.py`'s destination, the loader's root, and launcher/game agreement. Four negative controls, all firing |
| F17 | **high** | **`export`-resolver symbols are resolved with one attempt and no retry, and a miss is fatal.** 6 of the 14 required symbols use `resolver: export` (`resolution_order: ["export"]`, no pattern fallback); `resolve_pattern_with_retry` gives the other 8 three attempts 150 ms apart, while `resolve_export_body` (`il2cpp_offsets.h:107`) gets one. Measured 2026-10-02: 3 launches in 4 stopped with `Mod startup stopped: IL2CPP API is incomplete`, the 6 failing together; the 4th resolved all 14 on the identical code path. All six names are present in the live `GameAssembly.dll` export table (386 names, verified by parsing the PE) and the identity check passed, so it is not a manifest or drift problem. Unreachable while F15 was open | **RESOLVED 2026-10-02 by a better answer than a retry** — `GetProcAddress` first, then a direct hand-parse of the export table (see "F17 diagnostics" below; the module never becomes listed, so waiting cannot help). Confirmed live: `6 of 14 required symbol(s) needed a direct read ... startup succeeded anyway`. On the 2026-10-07 `1.2.0.0.47888` launch the loader listed the module for all of them (`0 of 14` needed the fallback) |

### F17 diagnostics, added 2026-10-02 — and the answer

The boot gates are instrumented too: each logs its elapsed ms and poll count, and `log_module_state()` reports whether the loader **lists** `GameAssembly.dll` or merely refuses to **name** it — plus `SizeOfImage` read off the module's own headers, which works either way. It is called at the Unity gate **and again after `il2cpp_offsets::init()`**, so the pair is a timeline: a flip between them means the unlink races startup (and a retry would have been worth something), while already-unlisted at the gate means the direct read was the only thing that could ever have worked.

**The "wait longer for the game" theory is refuted by measurement, not by argument.** Timed on both launches: the failing one went from the boot gate to `Loading Il2CPP API` in **2 ms**, the succeeding one in **1 ms**. And on the failing launch a pattern scan of `GameAssembly.dll` **succeeded in the same millisecond** that `GetProcAddress` on it failed, with zero pattern retries logged. The module is byte-for-byte scannable before the first export lookup, so no wait duration and no readiness semaphore can help — readiness is not what is missing.

`scan::find_export_by_hand` is the decisive instrument. It is a hand-rolled export lookup that calls no Windows API, cannot be intercepted, and bounds-checks every access against the image. On failure the log carries a **`VERDICT` line** naming which party is wrong:

- hand lookup finds it, `GetProcAddress` did not → **the table is fine, the API is the failing party**
- hand lookup does not → the name genuinely is not exported, the manifest is wrong for this build
- hand lookup cannot parse → not evidence either way, and it says so

Plus the module's on-disk path, `GetLastError()` sampled *immediately* after the call, and a **GetProcAddress-hook check**: a hand-resolved `GetProcAddress`, fetched by parsing `kernel32.dll`'s export table with the same reader, is called and compared against our IAT entry.

The boot gates are instrumented too: each logs its elapsed ms and poll count, `GameAssembly.dll`'s path and `SizeOfImage` are logged at the gate, and each init step logs its own wall time.

Covered by `tools/harness/test_export_lookup.cpp` — 43 assertions, five negative controls, including that **PE32 and PE32+ put `DataDirectory` 16 bytes apart**, that the name→ordinal→function indirection is two levels deep (asserted by requiring two lookups to return different RVAs), that a forwarder is detected and never returned as an address, and that eleven kinds of malformed image are refused rather than read past.

#### What the diagnostics found

```
GetProcAddress(GameAssembly=7FFCA57A0000, "il2cpp_string_new") returned NULL, GetLastError=126 (0x7E)
GetModuleFileNameW on the module returned 0
boot: GameAssembly=00007FFCA57A0000 path="<not loaded>" SizeOfImage=0x66ED000
VERDICT -- the export IS in the module's export table
         hand-parse: "il2cpp_string_new" FOUND ord=232 rva=0x164870 (386 names)
```

**`126` is `ERROR_MOD_NOT_FOUND`.** Both failing APIs resolve a handle through the loader's module list; both failed on the same handle, while the `SizeOfImage` read on that handle **succeeded** and matches the manifest's identity. So the image is mapped and fully readable and the loader does not list it: an LDR entry was unlinked while the image stayed loaded.

That is why it is sometimes listed and sometimes not, and why no wait could fix it — the game is ready the whole time, and only the loader's bookkeeping varies. Whether a launcher or anti-cheat component unlinks `GameAssembly.dll` is not this mod's to answer.

**The fix inverts the order.** `GetProcAddress` first (canonical, and the only thing here that resolves a forwarder), then the direct read, then the existing thunk-following. The fallback was cross-validated against an independent parse of the on-disk module: **6/6** ordinals and RVAs agree.

**Confirmed 2026-10-02, and "the LDR entry was unlinked" is retracted.** `EnumProcessModulesEx(LIST_MODULES_ALL)` **finds `GameAssembly.dll` on the failing launch** — at the boot gate, during the first fallback, and after `init()`. An unlinked module is invisible to that API too, so the module was never unlinked. It is **listed** while `GetProcAddress` *and* `GetModuleFileNameW` both refuse it: a filter on those two APIs for one module, not a missing list entry.

That settles the retry question — membership never changed, so waiting cannot help — and it means the direct read is the answer rather than a mitigation. A first-launch-fails pattern holds across every session observed (3-then-1, 1-then-1, 1-then-1-then-0), which is consistent enough to record and not enough to explain.

The GetProcAddress-hook check also had to be moved: it lived on the path where the direct read *also* fails, which never happens, so it never ran in the one case it was written for. It is now on the fallback path.

**It ran, and gave its third answer.** A `GetProcAddress` resolved from
kernel32's own export table, bypassing our IAT, **also** returns NULL — so **our
IAT entry is not replaced**, and the denial is inside `GetProcAddress` itself.
The test separates *IAT-hook* from *not-IAT-hook*, but it **cannot** separate an
*inline hook on the function body* from a *policy inside it*: both pointers then
lead to the same patched code. Separating those needs a disassembly of the entry,
which is not worth writing unless the question becomes load-bearing.

**The direct read was verified against the on-disk module**, which is the part
that matters for correctness. Three of the six exports are direct prologues; the
other three are `E9` thunks immediately followed by `CC` **INT3 padding**, and
each thunk follows to a valid prologue in one hop — which is what
`follow_export_thunk` does. INT3 is exactly what a "breakpoint encountered"
dialog reports, so that is the one place in this project where a pointer mistake
would produce that dialog; it is correct on all three.

The fallback is confirmed working: `boot[il2cpp]: 6 of 14 required symbol(s) needed
a direct read of the export table because GetProcAddress could not ... startup
succeeded anyway.`

### Corrections to earlier statements

Recorded because they affected decisions:

- **"`#pragma pack(push,1)` on `ItemSearchValue` is an accidental leftover."**
  Wrong. It is a deliberate convention across **12** files in
  `TarkovAddons/config/`, and `FavoritesValue.h:16-17` documents the hazard and
  works around it (*"this class is `#pragma pack(1)` and packing an OS lock
  primitive would misalign it"*). Nothing was changed. The underlying UB is real
  (packed `std::string`/`std::vector` in a polymorphic class) but removing it is a
  codebase-wide decision, not hygiene.
- **"The duplicate launcher tree can silently ship the wrong code."**
  Overstated. Only the nested project is built, so the orphan *cannot* ship. The
  real risk is edits landing in a file nothing compiles.
- **`git check-ignore` appeared to contradict itself** (an ignore rule present but
  reported "not ignored"). Cause: `check-ignore` skips tracked paths by default;
  `--no-index` is required to evaluate them.
- Two self-inflicted process errors, both caught and fixed before landing:
  a duplicated `<LanguageStandard>` element that would have made the C++23 fix a
  silent no-op, and a test that asserted against `parse_legacy_cfg()`'s
  `(values, truncated)` tuple as if it were a dict.

---

## 10. Known limitations

1. **The runtime profile path is exercised, but thinly.** Observed live loads:
   `eft-1.1.5.1.47510` (2026-10-02, and the launch that exposed F17) and
   `eft-1.2.0.0.47888` (2026-10-07, `IL2CPP API Loaded via compatibility
   profile`). What those launches prove is profile *selection* and resolution
   of the 14 required symbols. No launch has yet exercised the fail-closed
   `Mismatch`/`Invalid` paths or the F17 direct-read fallback against a
   genuinely refusing `GetProcAddress`.
2. **No C++ tests for the loader.** The JSON parser walks a file at process
   startup; only the Python side is tested.
3. **Identity is `SizeOfImage` + PE timestamp.** `text_sha256` is offline-only, so
   two builds sharing size and timestamp would be indistinguishable. The manifest
   advertises a stronger identity than the runtime enforces. Not hypothetical:
   `UnityPlayer.dll` was byte-identical between `1.1.5.1.47510` and
   `1.2.0.0.47888`, which is why the launcher-side selector could match *both*
   profiles against its UnityPlayer anchor — the tie-break was status and
   directory order, not identity. `deploy.py` now ships only the newest profile
   to remove the choice.
4. **The current profile is `validated`; the previous one is `staged` and stays
   that way.** `1.2.0.0.47888` was promoted after PDB/pattern re-derivation and
   an observed live load. `1.1.5.1.47510` remains at `staged` as the rollback
   profile; its promotion question is moot because it no longer ships
   (`deploy.py` prunes it at install).
5. **Launcher-side consumption is real but less validated than the game side.**
   `TarkovLauncherBypass` selects a profile out-of-process through its own
   `compat_profile.cpp` (anchored on `UnityPlayer.dll`) and `disabler.cpp`
   resolves and patches `load_be_client`, `be_client_start` and `be_client_init`
   from the manifest by name. That path was exercised by the 2026-10-06/07
   refresh launches; its failure mode (a profile directory present but stale)
   is what motivated deploy's newest-only rule, since the launcher ranks by
   status and breaks ties by first-encountered order — the *oldest* directory
   wins a tie.
