# BuffComponent — declared types vs. types that actually work

Reference note (2026-09-27). Written while converting the Item Editor / Weapon Builder
enchantment inputs to `FloatSliderEditableValue`, then updated after acting on the
findings. **Sections 1-5 are the evidence; section 6 is what was changed and why.**

Sources (all under `TarkovAddons/`):

| What | Where |
|---|---|
| Enum values | `GameDump/115147510/DiffableCs/Assembly-CSharp/EFT/ERepairBuffType.cs` |
| Field layout | `GameDump/115147510/DiffableCs/Assembly-CSharp/EFT/InventoryLogic/BuffComponent.cs` |
| Attribute ids | `GameDump/115147510/DiffableCs/Assembly-CSharp/EFT/InventoryLogic/EItemAttributeId.cs` |
| Disassembly | `ISIL-references/IsilDump/Assembly-CSharp/EFT/InventoryLogic/BuffComponent.txt` |

Build checked: `115147510` (matches the ISIL dump).

> **Standing constraint on this dump.** The ISIL dump is the whole of the game as
> currently available — there is no further source to check against. Absence of a
> reference in it is therefore treated as absence in the game, not as "not dumped".
> That is what licenses cutting the dead enum entries below rather than hedging on
> them. Re-verify if a fuller dump ever appears.

---

## 1. Short answer

**No. Only 3 of the 6 declared types can do anything through `BuffComponent`, and those
3 split by item domain — 2 are weapon-only, 1 is armor-only.**

`ERepairBuffType` declares 6 values, but only `WeaponSpread` (0), `DamageReduction` (1)
and `MalfunctionProtections` (2) are backed by both a modifier field and an
`EItemAttributeId`. The other three — `WeaponDamage` (3), `ArmorEfficiency` (4),
`DurabilityImprovement` (5) — are declared in the enum but have **no representation at
all** inside the component. Writing one produces a well-formed, serialisable buff that
does nothing.

Worse for the UI: of the three that *are* implemented, **each is consumed by exactly
one side of the game.** See section 2a. So there is no single list of "working types" —
there is a weapon list and an armor list, and they do not overlap.

---

## 2. Why: the switch in `UpdateModifiers`

`BuffComponent` has exactly three derived modifier fields:

```
<WeaponSpread>k__BackingField        +0x40  double
<DamageReduction>k__BackingField     +0x48  double
<MalfunctionProtections>k__BackingField +0x50 double
```

(`BuffComponent.cs` lines 43-47). Six buff types, three fields — so the mapping cannot
be one-to-one.

`UpdateModifiers` (ISIL lines 500-518) is where the routing happens:

```asm
500: mov edx,[rdi+18h]            ; edx = _buffType
501: mov rax,3FF0000000000000h    ; 1.0
502: mov [rdi+40h],rax            ; <WeaponSpread>        = 1.0   <- reset ALL THREE first
503: mov [rdi+48h],rax            ; <DamageReduction>     = 1.0
504: mov [rdi+50h],rax            ; <MalfunctionProtections> = 1.0
505: test edx,edx
506: je   -> 0x181ABA90Bh          ; type == 0
507: sub edx,1
508: je   -> 0x181ABA8F7h          ; type == 1
509: cmp edx,1
510: je   -> 0x181ABA8E3h          ; type == 2
511: xor edx,edx
512: mov rcx,rdi
513: call ResetEnhancedAttribute   ; DEFAULT: types 3, 4, 5 — and any invalid value
514: ... ret                       ; ...returns immediately
519: <MalfunctionProtections> = _value   ; esi=0x4D eax=0x50   (type 2)
524: <DamageReduction>      = _value    ; esi=0x4F eax=0x52   (type 1)
529: <WeaponSpread>         = _value    ; esi=0x4E eax=0x51   (type 0)
```

The `default:` branch is a bare `ResetEnhancedAttribute()` followed by `ret`. It never
touches `_value`'s consumers, and the three modifier fields keep the `1.0` written at
502-504. **That is the dead branch.**

## 2a. Every consumer of the three modifier fields

This is the part that decides what each card may offer. Each field has a small, closed
set of readers, and they are not symmetric:

| field | offset | consumers (whole dump searched) | domain |
|---|---|---|---|
| `<WeaponSpread>` | +0x40 | `Weapon.GetBarrelDeviation()` (`Weapon.txt:11352`)<br>`Weapon.<.ctor>b__105_6()` (`Weapon.txt:27714`)<br>`FirearmController.Shot()` ×2 (`FirearmController.txt:43651,43679`) | **weapon** |
| `<MalfunctionProtections>` | +0x50 | `FirearmController.GetTotalMalfunctionChance()` ×3 (`FirearmController.txt:52420,52611,52617`) | **weapon** |
| `<DamageReduction>` | +0x48 | `ArmorComponent.ApplyDamage()` ×1 (`ArmorComponent.txt:5778`) | **armor only** |

The armor read is explicit and gated (`ArmorComponent.txt:5760-5779`):

```asm
1148 CheckEqual        this.Buff, 0        ; ArmorComponent.Buff null check
1151 ConditionalJump   @b132               ; skip
1162 CheckNotEqual     v542._buffType, 1   ; ONLY when type == DamageReduction
1163 ConditionalJump   @b147               ; skip
1166 Multiply          xmm0 = <DamageReduction> * damageInfo.damage   ; damageInfo+4
1167 Move              damageInfo.damage = xmm0
```

So `damageInfo.damage *= BuffComponent.DamageReduction`, and only for
`_buffType == ERepairBuffType.DamageReduction`. Nothing weapon-side reads that field.
The two `FloatBuff` parameters in the same method's signature
(`lightVestsDamageReduction`, `heavyVestsDamageReduction`) are **skill** values from
`SkillManager` — `EBuffId.LightVestMeleeWeaponDamageReduction = 119` and
`EBuffId.HeavyVestBluntThroughputDamageReduction = 124` — a completely separate armor
reduction path that has nothing to do with `BuffComponent`.

### Consequence for the two cards

- **Weapon Builder** (`WeaponBuilderModule`) is weapon-only: both `refresh_weapons` and
  `resolve_external_weapon` gate on `is_weapon`. Its valid types are therefore
  `WeaponSpread` and `MalfunctionProtections` **only**. Offering DamageReduction there
  writes a field nothing reads — the enchantment still shows in the item tooltip (the
  `EItemAttributeId` 79/82 path is independent) but has no gameplay effect.
- **Item Editor gear card** (`InventoryEditorModule`) targets `ArmoredEquipment.Armor`
  (`ArmoredEquipment.cs:25`, a `public readonly ArmorComponent` at +0x98) and writes
  `ArmorComponent.Buff` (+0x28) — exactly the field `ApplyDamage` reads. Its only valid
  type is `DamageReduction`, which is what it is now fixed to.

`WeaponDamage` (3) has no consumer anywhere, on either side.

### The 100 clamp is load-bearing on the armor side

Because the armor read is a straight multiply, the editor's `1.0 - pct/100` conversion
gives:

| pct | `_value` | `damageInfo.damage` becomes |
|---|---|---|
| 0 | 1.00 | unchanged — **and the buff reports inactive** (section 4) |
| 50 | 0.50 | halved |
| 100 | 0.00 | **zero** — nothing gets through that collider |
| >100 | < 0 | **negative damage** flowing into the damage pipeline |

So 100 is not a cosmetic ceiling on armor: exceeding it does not merely invert a sign,
it hands a negative damage value to the health/damage code. This is the concrete reason
the clamp must hold on every path, including config load.

`EItemAttributeId.cs` contains buff attribute ids for exactly three types — six ids,
two per type, one per rarity:

```
MalfunctionProtectionCommonBuff = 77   (0x4D)
WeaponSpreadCommonBuff         = 78   (0x4E)
DamageReductionCommonBuff      = 79   (0x4F)
MalfunctionProtectionRareBuff  = 80   (0x50)
WeaponSpreadRareBuff           = 81   (0x51)
DamageReductionRareBuff        = 82   (0x52)
```

These are exactly the six immediates at ISIL 519-532 (`esi` = Common, `eax` = Rare,
selected by `cmp dword ptr [rdi+34h],0 / cmovne esi,eax` — i.e. `Rarity != 0`). Three
types x two rarities, no entries for WeaponDamage / ArmorEfficiency /
DurabilityImprovement. A second, independent confirmation of the same three.

`TryGetEnhancedAttributeId` (ISIL 2421-2431) narrows it further — it accepts only
`0x4E` and `0x51` (the two *WeaponSpread* ids) and maps both to `0x20`
(`CenterOfImpact`). So even inside the working three, the "enhanced attribute"
sub-path is WeaponSpread-only.

## 4. The value range

**There is no clamp anywhere in `BuffComponent`.** Traced every writer of `_value`:
`ItemBinarySerializer` (deserialisation) and `set_Value`. Nothing bounds it. The 0-100
range the game shows in its own enhancement panel is a UI-level limit, not a component
invariant. The old `0-8000` cap in `InventoryEditorModule` was therefore reachable —
>100 writes fine, it just inverts the modifier's sign.

The boundary that *is* enforced is at the **low** end, and it is easy to miss:

```asm
; get_IsActive, ISIL 7-18
cmp dword ptr [rcx+18h],0
jl  -> false                  ; _buffType  >= 0
cmp dword ptr [rcx+34h],0
jl  -> false                  ; Rarity     >= 0
movsd xmm0,qword ptr [rcx+20h]
call Double.Equals            ; _value == 1.0 ?
xor al,1
```

`IsActive == (_buffType >= 0) && (Rarity >= 0) && (_value != 1.0)`

`_value` is a multiplier where `1.0` means "no modifier", and the editor converts with
`1.0 - pct/100`. So **a 0% enchantment produces `_value == 1.0` exactly and the game
reports the buff INACTIVE.** Any pct >= 1 is the first active value. This is the real
reason the sliders' lower bound is 1 and not 0.

Practical range, given the `1.0 - pct/100` conversion:

| pct | `_value` | meaning |
|---|---|---|
| 0 | 1.00 | **inactive** — `IsActive == false` |
| 1 | 0.99 | 1% modifier, active |
| 50 | 0.50 | 50% modifier |
| 100 | 0.00 | 100% modifier, fully negated |
| >100 | < 0 | sign inverts; nothing rejects it |

## 5. Two ordering constraints the current code satisfies by luck

Both `set_BuffType` (ISIL 147) and `set_Value` (ISIL 170) and
`set_ThresholdDurability` (ISIL 192) tail-call `UpdateModifiers`. So the sequence in
`InventoryEditorModule::apply_enchantment` is:

```cpp
set_type(buff, enchantment_type_);                        // -> UpdateModifiers
*reinterpret_cast<int*>(buff + rarity->offset) = rarity;  // field write, no setter
set_value(buff, 1.0 - pct / 100.0);                       // -> UpdateModifiers
set_threshold(buff, 1.0 - threshold / 100.0);              // -> UpdateModifiers
```

Two things must hold, and neither is enforced by the API:

1. **`Rarity` is written raw.** `Rarity` is a public *field* at `+0x34`, not a property
   — there is no setter, so the direct write is correct. But `UpdateModifiers` reads it
   to pick the Common/Rare attribute id. It only works because the field write happens
   *before* the last two `UpdateModifiers` calls. Reordering the four lines silently
   yields Common ids while the tooltip claims Rare.

2. **`_thresholdDurability` is recomputed by `UpdateModifiers`.** ISIL 782-800:

   ```asm
   782: cmp byte ptr [rdi+30h],0
   783: jne ...                    ; if _isErrorIssues != 0, SKIP
   ...
   798: mov byte ptr [rdi+30h],1    ; _isErrorIssues = 1
   800: movsd qword ptr [rdi+28h],xmm1   ; _thresholdDurability = <recomputed>
   ```

   The recompute is gated on `_isErrorIssues` (`+0x30`), which the ctor leaves `0`. So
   the *first* `UpdateModifiers` after `set_type` computes the threshold from the item's
   max durability and latches the gate; the editor's own `set_ThresholdDurability` then
   runs afterwards and wins. Setting the threshold before the type would have it
   clobbered.

   Related: `TryDisableComponent` applies `Math.Max(_thresholdDurability, 0.5)`
   (ISIL 425), so a threshold below 0.5 is raised to 0.5 at use time regardless.

---

## 6. What was changed, and the reasoning

All of the following is in the working tree as of 2026-09-27.

### 6.1 Dead buff types removed from both cards

`WeaponBuilderModule::enchantments_` went from 6 entries to the 2 that are read by
weapon-side code:

| index | label | `ERepairBuffType` | kept? |
|---|---|---|---|
| 0 | Weapon Spread | `WeaponSpread` (0) | yes |
| 1 | Malfunction Protection | `MalfunctionProtections` (2) | yes |
| — | Damage Reduction | `DamageReduction` (1) | **cut — armor-only** |
| — | Weapon Damage | `WeaponDamage` (3) | **cut — no consumer** |
| — | Armor Efficiency | `ArmorEfficiency` (4) | **cut — no consumer** |
| — | Durability Improvement | `DurabilityImprovement` (5) | **cut — no consumer** |

`InventoryEditorModule` lost its Type combo entirely and now hardcodes
`k_gear_enchantment_type = 1` (`DamageReduction`) — the one type its armor target can
actually use. The combo shows `"Type: Damage Reduction"` as a static line.

**To restore any of these**, BSG would have to give the type a representation — a
modifier field in `BuffComponent` *and* an `EItemAttributeId` in the 77-82 range — *and*
something must read it on the relevant side. Check all three, not just the enum.

### 6.1b Combo index was being used as the enum value

`WeaponBuilderModule` passed the ImGui combo index straight into
`queue_weapon_enchantment_by_id` as the `ERepairBuffType`. That was correct only while
the list happened to be every value in gapless enum order (0..5). The moment an entry
is removed from the middle, index 1 starts meaning `DamageReduction` while the label
says "Malfunction Protection".

Replaced with an explicit `enchantment_type_values_[]` lookup
(`{0, 2}` — the enum numbers), so the list and the enum are decoupled. The Item Editor
already did this correctly with `gear_enchantment_types[]` before its combo was removed.

### 6.2 Other dead code removed alongside it

Found while cutting the above, all provably unreachable:

- `queue_enchantment_` — the "apply enchantment to the directly selected item" path.
  The flag was only ever read and cleared; nothing set it true since the gear-component
  flow replaced it. The flag, its two `if` blocks, and the `"Select a weapon for this
  enchantment button."` message are gone.
- `gear_component::allow_create` and `queue_enchantment_component_create_` — a
  write-only chain. Both `out.push_back` sites in `collect_gear_enchantment_components`
  passed a literal `false`, so the flag could never be anything but false, and
  `apply_enchantment` was called with a hardcoded `true` rather than reading it.
- `apply_enchantment`'s `allow_create` parameter — both call sites passed `true`
  (one implicitly via the default). Removed.

### 6.3 Clamp

The percent/threshold inputs are `FloatSliderEditableValue(1.f, 1.f, 100.f, …)` in both
cards. The clamp is enforced in three places on purpose, because the widget only bounds
what the user *types*:

1. the slider bounds,
2. `sync_enchantment_inputs()` (the Item Editor's own path),
3. `queue_weapon_enchantment_by_id()` (the Weapon Builder's path).

`slider_float_editable`'s `InputFloat` does not clamp typed input, and
`FloatSliderEditableValue::set()` is an unbounded `std::stof` when loading a config, so
a hand-edited or older config can still carry a value above 100. Nothing in
`BuffComponent` rejects it; the ceiling is ours to enforce.

The old bounds were `0-8000` here and `0-400` in the Weapon Builder, so the same
enchantment could arrive with wildly different values depending on which card sent it.

### 6.4 Lower bound 1 is load-bearing

Not cosmetic. `get_IsActive` requires `_value != 1.0`, and the editor converts with
`1.0 - pct/100`, so a 0% enchantment yields `_value == 1.0` exactly and the game reports
the buff **inactive**. See section 4.

---

## 7. Open questions

- **Resolved:** all three modifier fields *are* read — the earlier note claiming they
  had no consumers was wrong; it came from searching only for `get_DamageReduction`-style
  call syntax. The real readers dereference `<Field>k__BackingField` directly, via
  inlined property getters, so a search for the getter names misses them. Always grep
  the backing-field spelling too. See section 2a.
- **How do ArmorEfficiency / DurabilityImprovement work in the live game, if at all?**
  Probably plain item attributes rather than `BuffComponent` state, which would be a
  different code path (pushing an attribute onto the item). Not implemented, not
  verified.
- **Does `WeaponDamage` (3) do anything?** No consumer anywhere in the dump, on either
  side. Almost certainly reserved/unimplemented.
- **Plate/armor-insert reachability.** `ApplyDamage` reads `ArmorComponent.Buff`, and the
  Item Editor writes it via `ArmoredEquipment.Armor`. Whether armor *plates* expose the
  same `Armor` field, or need a different route, was not checked.
