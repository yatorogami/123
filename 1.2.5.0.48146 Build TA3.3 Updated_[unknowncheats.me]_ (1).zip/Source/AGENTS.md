# AGENTS.md

C++ DLL (`TarkovAddons.dll`) that is **manual-mapped into the live 64-bit game
process**. Not a web app, not a library — nothing here runs except inside
`EscapeFromTarkov.exe`. Windows/MSVC only.

## Read this first

`WORKFLOW.md` is the operational document (build, deploy, crash diagnosis,
symbolization, testing). Read it before doing anything. This file only records
what is *not* in it, or what it gets wrong.

| File | What it is |
|---|---|
| `WORKFLOW.md` | How to build/deploy/diagnose/verify. Start here. |
| `AGENTS_TODO.md` | Outstanding work + what other workstreams own. Long (4.7k lines). |
| `CLEANUP_AUDIT.md` | Stale-code audit, mostly applied. Optic items deferred. |
| `CHANGELOG.md` | Retrospective. Retractions are deliberate — don't "fix" them. |
| `tools/handoff_*.md`, `tools/premises_*.md` | Per-workstream claims + what would falsify them. |

`TarkovAddons/Workstream_status_2026-09-24.md` (8k lines) is historical, not
current. Prefer the executable sources over any of these.

## The project's central habit: a count nobody measured is an assertion

This repo has been bitten repeatedly by checkers reporting success because they
checked nothing, and by plausible numbers in prose decaying into lies. Three
consequences:

- **Run the negative control.** Revert the change, confirm the check goes red,
  and confirm it names the right thing. A test that cannot fail is worse than no
  test. Both `tools/README.md` and `tools/verify/README.md` document three
  separate tools that each shipped green while comparing nothing.
- **A checker that can pass on a comment is not a checker.** `test_profile_path.py`
  strips comments before searching, because v1 matched its own fix's explanatory
  comment and passed 10/10 against deliberately reverted code.
- **Exit codes carry meaning.** `audit_config_pointers.py` / `verify/audit.py`
  exit **2** when they checked nothing, distinct from 0 (clean) and 1 (found a
  problem). Don't normalize 2 into 0.

## Commands

Two build systems, both maintained. **`python tools\deploy.py build` drives CMake
for Debug and Prod (the default since 2026-10-10) and MSBuild for Release and
"Prod no aimbot", which CMake has no targets for; `--backend msbuild` forces
MSBuild for any configuration.** A missing `cmake.exe` on a machine that has
MSBuild **falls back and says so loudly on stderr**, because the two backends
are not the same artefact; `--backend cmake` turns that off, so automation can
treat a missing toolchain as a stop. See WORKFLOW.md "Build and deploy" for what
CMake must not quietly lose — it already lost `/O2` once, silently.

```powershell
python tools\deploy.py build          # CMake (Ninja), Prod|x64 by default
python tools\deploy.py build --rebuild  # deletes and reconfigures the CMake tree
python tools\deploy.py build --config "Prod no aimbot"   # MSBuild, and says so
python tools\deploy.py build --backend msbuild           # force MSBuild anywhere
python tools\deploy.py build --backend cmake             # CMake or fail: no fallback

tools\configure_cmake.ps1              # the standalone scripts still work
tools\build_cmake.ps1 -Configuration Prod

python tools\deploy.py install        # -> C:\Battlestate Games\BsgLauncher\
python tools\deploy.py uninstall      # keeps settings/logs/symbols unless --purge
python tools\deploy.py --gui          # window (or double-click tools\deploy.pyw)
```

`$env:SLOT` picks the build tree (default `opencode`) for both, so two agents
do not share one `IntDir`/`build/`.

`install`/`uninstall` **prompt before writing**. In automation pass `--yes`, or
`--dry-run` (which needs no prompt). With no TTY and neither flag they *stop* and
say so — this is intentional, not a bug.

### Verification (none of it builds the project)

```powershell
python -m pytest tools\tests      # 545 passed, 6 skipped, 23 subtests, 1 failed  (measured 2026-10-14 on WINDOWS)
tools\harness\run_windows.bat     # 23 native cases, exit 0  (measured 2026-10-15)
sh tools/harness/run.sh           # 10 portable cases, needs only a C++23 compiler
sh tools/harness/run.sh --coverage  # the same, instrumented; first-party coverage only
python tools\audit_config_pointers.py
python tools\symbolize.py --file "<log>"     # RVA -> symbol, no PDB needed
```

**The pytest figure is platform-dependent, and it is the one number here that no test
re-derives.** A Linux run and a Windows run are different answers, so the platform is
part of the claim. Measured 2026-10-12 on Linux: **480 passed, 23 subtests, 15
skipped, 4 failed**. Three of those four failures **cannot happen on Windows**:

- `test_crash_probe_confirmed_report.py` — 2 cases, both die in `subprocess` with
  `FileNotFoundError: 'cmd'`.
- `test_build_wait_watchlist.py` — compares Windows backslash paths
  (`il2cpp\unity.h`); on a case-sensitive filesystem the tree enumerates
  `il2cpp/unity.h`. Its own comment records that the forward-slash spelling
  "matches nothing and the test passes", which is a guard against weakening it,
  not licence to swap the separator.

So Windows reads **495 passed, 2 skipped, 2 failed** — measured, not inferred,
on 2026-10-12 with this tree at `5a9d8cc4c`. **Measure it before quoting a
Windows figure**: the two failures were the platform-independent `hwid_check`
slot described next, and `test_map_icf.py::test_the_figures_quoted_in_the_docs_
are_current` — a doc figure gone stale because the `.map` it reads was newer
than the prose beside it. The second one is fixed by that commit, and the suite
then reads **496 passed, 2 skipped, 1 failed**, the single failure being
`hwid_check`. Deriving a Windows figure from a Linux one is how this number came
to read 423, 452 and 304 in three files at once.

Measured again the same day, after the menu quick-jump work landed two new
harness cases and fixed four suites' worth of stale figures (the double-draw
guard's new shape, the dup_scan scale, the harness counts and the map_icf
figures): **505 passed, 23 subtests, 1 failed**, the single failure still
`hwid_check`.

Measured again 2026-10-14 on WINDOWS: **545 passed, 6 skipped, 23 subtests,
1 failed** — the single failure still `hwid_check`. That run also cleared four
stale-figure failures that were sitting in the tree when it started (the
config-pointer count 366/30, the dup_scan scale 191/181 files, the map_icf
figures after the instrumentation build, and the zone_gap count 2→4), each
re-derived from its tool rather than argued. The skips are the four
cmake/clang/mingw-dependent analysis-tree cases on a host without them.

Measured again after `tools/analysis_tree.py` and 11 of its tests landed
(2026-10-12, **Linux**): **499 passed, 15 skipped, 4 failed**. Do not read that as
a regression from the Windows 505 above — it is the same suite on a host where
three Windows-only tests cannot pass. The 12 new tests are the analysis-tree ones,
and 4 of them skip when cmake/clang/mingw are absent.

The fourth failure is **real and platform-independent**:
`test_manifest_tool.py::test_shipped_patterns_cfg_exposes_hwid_check_slot` asserts
`patterns.cfg`'s `hwid_check` is the blank "use the compiled-in signature" slot, while
`TarkovAddons/patterns.cfg:50` now carries a real byte pattern. This is already
recorded and owned elsewhere — `compatibility/PROFILE_GUIDE.md` §8 calls it "stale
since the 1.2.0 refresh filled it" and assigns the reconciliation to another
workstream. Do not "fix" it by blanking the pattern or by weakening the assertion.

More tools exist for finding problems, and they are **reports, not gates** —
`dup_scan.py` and `map_icf.py` exit 1 when they find duplication,
`quest_condition_fields.py` exits 1 when the Quest ESP reads a condition field the
game does not declare, and `run_tidy.ps1` exits 0 with a diagnostic list, so none
belongs in a pass/fail list:

```powershell
python tools\dup_scan.py          # copy/paste clones; ~6 s over the whole tree
python tools\map_icf.py           # what the linker ALREADY folded (costs 0 bytes)
python tools\zone_gap.py          # per-frame module bodies with NO Tracy zone, ranked by size
python tools\quest_condition_fields.py  # condition-field names the Quest ESP reads vs what the game declares
python tools\analysis_tree.py     # a clang-usable compile database, for a non-Windows host
python tools\analysis_tree.py --check    # parse every first-party TU against it
tools\run_tidy.ps1                # clang-tidy; ~3.6 min over 79 TUs, 16 jobs
```

**`analysis_tree.py` is how clang tooling is reached without MSVC.** `run_tidy.ps1`
needs a vcvars64 shell (the SDK include paths arrive in `INCLUDE`, not `-I`) and a
tree configured with `TA_NO_PCH=ON` (clang cannot read a cl.exe `.pch`). This one
configures the same tree against **mingw** — a different artefact, and not a
substitute for `run_tidy.ps1`'s numbers. What it buys is that a Linux box can parse
first-party C++ at all: **58 of 80 TUs parse**, where MSVC-only hosts can compile
all of them.

It does that by checking a **shadow copy** with one line rewritten —
`il2utils.h:412`, the MSVC `static_cast<void*>` → function-pointer extension, which
is 38 of the 42 failures. The flag that would allow it in-tree, `-fms-compatibility`,
undefines `__GNUC__` and breaks clang's own `mmintrin.h`, so it parses *fewer*
files. `--no-shadow` checks the real tree. **Never in `/tmp`**: the tree and the
shadow live under `build/analysis/`, on the checkout, git-ignored.

**`zone_gap.py` is the pre-capture pass.** "Unzoned" is the most expensive state
a hot function can be in and nothing warns you: `ModuleManager::apply` names every
module dynamically, so an unzoned module still exports a tidy row and the
unattributed time simply disappears into it. Measured 2026-10-14: **12 of 32
registered modules** have no `TA_ZONE_N` in their own files, largest first
`MapModule::draw_overlay` at 81 lines (`MapModule` and `WeaponModule` carry
every body over the threshold — step 6's module, landed after the 2026-10-12
measurement this line used to carry). **Size is not cost** — it ranks where
to instrument. Exit 1 = gaps found, **2 = checked nothing**. Its `--list-zones`
strips comments, so it reports 169 live literal zone names — fewer than a plain
scan of the same macro calls, because two of them are not live code at all (one
is a `//` usage example in `tracy_bridge.h`, one is a deliberately commented-out
zone at `QuestModule.cpp:1142`).

`run_tidy.ps1` configures its own tree at `build\analysis\x64\tidy` with
`-DTA_NO_PCH=ON`, because clang cannot read a cl.exe-produced `.pch`. **Do not point
it at `build\Prod`**, and do not set `TA_NO_PCH` in a tree you intend to deploy. The
curated check list and every suppression's justification are in `.clang-tidy` at the
repo root; WORKFLOW.md has the measured numbers.

**`dup_scan` and `map_icf` answer different questions, and the second one usually
wins the argument.** `dup_scan` finds text written twice; it cannot tell you
whether the clone survives into the DLL. MSVC folds identical COMDAT functions to
a single address, and `map_icf.py` reads the `.map` to prove it. Measured:
`IntSliderEditableValue::set` and `IntTextboxValue::set` — a real `dup_scan`
clone pair — share address `0x180178100`, so they cost one copy, not two.

After excluding `$unwind$` records, compiler thunks and std/imgui templates,
only **108 fold groups / 407 first-party symbols / 299 copies already saved**
remain; the largest surviving group is 92 symbols, of which 77 are empty
per-module virtual overrides and the rest are `operator delete` plus a tail of
one-off no-op stubs. The claim this paragraph used to make, that the largest
hand-written group is 21 empty menu-draw hooks that each `return false`, does
not hold on this tree: only 5 modules override `draw_menu_extra_before_values`,
6 symbols carry the name in the `.map`, and all 5 fold.

**So treat a `dup_scan` finding as maintainability debt by default — merging one
will not make the DLL smaller.** Check `map_icf.py` before spending a build on
it. The unfiltered total — twenty thousand symbols — is meaningless and the
default is deliberately *not* it; the reasoning is in WORKFLOW.md under "Which
duplicated code actually costs bytes".

*(First-party figures re-derived 2026-10-15 from the `Prod` build of this tree
after the completed-sweep rewrite. This series is 108/407/299; it moved three times
across four near-identical builds in one session — 108/407/299, then 108/406/298
when the sweep's owners table replaced its quest-book walk and DELETED code, then
back to 108/407/299 — and the lesson is the mechanism, not any one number: a single
added or removed function moves it, so re-derive it. **The raw half is no longer
quoted as a figure at all**, on purpose: it moved three times across three
near-identical builds this session, which is the same mechanism that had this
file, WORKFLOW.md and `map_icf.py`'s docstring disagreeing. Re-derive it with
`map_icf.py --all`; do not transcribe it — `test_map_icf.py` now fails if you
do.)*

There is **no test target in the MSBuild project.** The harness and pytest suites
deliberately compile real headers standalone, which is what makes them fast and
immune to a concurrent build — and also why a header-only change is invisible to
both. Two green suites say nothing about the artefact that ships.

**"Verified" means exactly one thing:** full `Prod|x64` build **and** link, exit 0,
0 errors, 0 warnings, plus `tools/tests` if the change could affect it. A per-TU
`ClCompile` cannot see `LNK2005` and is not what ships.

### Never put scratch in `/tmp` or `TEMP`

Temp cleanup destroyed an entire earlier test suite and a whole verification
toolchain. `tools/verify/` and `tools/harness/` exist *because* of that. Recover
with `git checkout --`, never from a temp copy.

## Multiple agents share one tree and one branch

This is the single most important operational constraint, and it is easy to miss.

- **The branch is shared.** Do not amend, rebase, reset, or `git checkout --` a
  path another session may be editing. On 2026-10-04 `git checkout HEAD --`
  before capturing content destroyed both ledgers on disk.
- **Never `git add -A`.** A whole-file stage once swept 28 lines of another
  session's work into a commit.
- **Commit before you build** (standing instruction, 2026-10-05): edit → verify
  what needs no compiler → commit → build. A commit made before the build is
  *not* build-verified, and its message must not imply otherwise. If the build
  then fails, the fix is a **new commit**.
- **Use `tools\build.ps1`, not raw MSBuild**, when other agents are active. The
  vcxproj pins one `IntDir`, so concurrent builds collide on the 249 MB PCH, on
  identically-named `.obj`s, and — silently and dangerously — on `*.tlog`, the
  ledger MSBuild reads to decide what it still owes. `build.ps1` gives you a
  private `IntDir` per `-Slot`, optionally `-Wait`ing for a sustained quiet
  window, and then **checks the DLL postdates the newest source** (a build that
  exits 0 can still ship the previous source if an edit lands mid-build).
  First use of a slot is a full rebuild; that is expected.
- Raw MSBuild is fine when you are the only agent. `Prod|x64` is the only
  configuration worth building; `Prod no aimbot` exists but is not the signal.
- **`build.ps1` builds ONLY `TarkovAddons\TarkovAddons.vcxproj`.** It is not a
  solution build. If you changed `TarkovLauncherBypass` or `vk_swiftshader`, it
  will print `exit 0` and `FRESH: the DLL postdates every source file` and have
  compiled **neither**. Its freshness check only walks TarkovAddons' sources.
  **For a Bypass or swiftshader change, build the solution**:
  ```powershell
  & $msb TarkovAddons\TarkovAddons.sln /p:Configuration=Prod /p:Platform=x64 `
        /p:IntDir="x64\Prod_docs\" /t:Rebuild /m /v:minimal /nologo
  ```
  Note the **`p:IntDir` override alongside it** — see the next bullet, which is
  the reason the naive fallback does not work.
- **Do NOT verify a Bypass change by building `TarkovLauncherBypass.vcxproj`
  alone.** It compiles, reports exit 0, and puts the DLL in the **wrong folder**.
  Its `OutDir` is `$(SolutionDir)out\prod\with_aimbot\`, and `$(SolutionDir)` is
  only defined by the `.sln` — building the project standalone resolves it to the
  project directory, so the output lands in `TarkovLauncherBypass\out\...` while
  the artefact that actually deploys, `TarkovAddons\out\prod\with_aimbot\`,
  keeps the previous build. Confirmed 2026-10-05: standalone build succeeded and
  the deploy copy was still the pre-edit DLL with a different hash.
  **Placement in `out/` is not a build dependency** — `TarkovAddons.vcxproj` has
  no `ProjectReference` to Bypass; the DLL is in `out/` because Bypass's own
  `OutDir` points there when built through the solution.

## MSVC traps this codebase actually hits

- **`std::min`/`std::max` are function-like macros** from `windows.h`. Bare
  `std::min(a, b)` is a syntax error. Use `(std::min)(a, b)`.
- **`far` is an empty macro.** A local named `far` loses its identifier and MSVC
  reports the error three lines later.
- **`__try` is illegal** in any function with destructible objects. Isolate the
  raw dereference in a small helper (`crash_probe.h`'s `safe_read`).
- **`hook_method`'s last argument must be `T2*` — the *address* of the caller's
  trampoline slot** (`&o_foo`). A bare function pointer deduces `T2` to the
  function type and the trampoline store writes through null on first install.
  There is a `static_assert` for this; the `*` is deliberate (by-reference was
  tried and reverted — it broke ~50 correct call sites).
- **A PCH consumer needs the literal `#include "common.h"` as its first line**,
  and the directory holding it must be on the include path. MSVC matches `/Yu`
  against the *name in the flag*, not the resolved path, so
  `#include "../include/common.h"` fails with C1010 across all 71 TUs. Cost a
  day to bisect once. The header is `TarkovAddons/include/common.h` (was
  `pch.h`); `pch.cpp` survives only as the `/Yc` carrier.
- **The PCH is not optional.** The CMake conversion deleted it and every one of
  the 82 TUs began re-parsing windows.h + nlohmann/json; it was restored under
  both build systems on 2026-10-09. Under CMake it is
  `target_precompile_headers` restricted to `$<COMPILE_LANGUAGE:CXX>` — an
  unrestricted declaration makes CMake build a second PCH for the one C source
  (`Zydis.c`) and dies on `STL1003`. Vendored TUs need
  `SKIP_PRECOMPILE_HEADERS ON` or `safetyhook.cpp` fails on windows.h `min`/`max`
  macros vs its `std::min`.
- `/p:PrecompiledHeader=NotUsing` on the command line is **silently ignored** —
  to A/B the PCH you must edit the project file.
- **Do not "fix" the PCH's 249 MB.** Measured: irreducible (38 leave-one-out
  builds move it ≤4.7 MB), and nearly free (~5 ms/consumer vs ~171 s saved).
  `nlohmann/json.hpp` is 22.8% of it, not the cause; dropping it *costs* 7.9 s.
  Optimise PCH *content too few TUs need*, never its bytes.
- `CppClean` races the PCH. `C1083 ... Invalid argument` mid-`Rebuild` →
  `Stop-Process cl,msbuild,mspdbsrv` and retry.
- `MSB8012` is emitted once per config and is **expected and benign** (the
  project redirects `OutDir` to `out\<config>\<flavor>\`, so the linker's
  `OutputFile` and `TargetPath` disagree). Not one of the "0 code warnings".
- Two persistent first-party warnings live in `TarkovLauncherBypass`
  (`injector.cpp` C4312, `spoofer.cpp` C4200). Everything else is SDK/CRT noise
  (`ntstatus.h` macro redefinitions, `xutility` C4244).
- **`Debug`/`Release` cannot overwrite `x64\Debug\TarkovAddons.dll` while the
  game holds it** — that warning is the game running, not a build failure. Never
  quote the `Debug` DLL as freshly built.

## Architecture

`TarkovAddons.sln` contains **all three projects**, so one `Rebuild` covers all
twelve x64 configurations (4 each): `TarkovAddons`, `TarkovLauncherBypass`,
`TarkovLauncherEntrypoint/vk_swiftshader`.

- **`TarkovAddons/`** — the mod. `dllmain.cpp` is the only real entrypoint;
  `pch.cpp` is the PCH generator. `module/impl/` holds 28 feature modules
  registered in `module/ModuleManager.h`. Config values are header-defined
  classes in `config/`, built by `audit_config_pointers.py` over `module/impl/*.h`.
- **`TarkovLauncherBypass/`** — the launcher-side proxy that loads the mod and
  runs the anti-cheat bypass.
- **`external/`** — `safetyhook` + `nlohmann/json`, shared by both DLL projects
  via `$(MSBuildThisFileDirectory)..\external\`. `TarkovAddons/external/` holds
  imgui, nanosvg, stb, tracy (mod-only). Both trees are vendored as-is.
- **`il2cpp/`** — vendored Unity-generated headers + `il2utils.h`, `unity.h`,
  `il2cpp_offsets.h`, `compatibility_profile.*`. Provenance and the member-level
  verification are in `il2cpp/PROVENANCE.md`. When vendoring, record the archive
  URL, commit/zip, and date **in the committing commit**.
  - `Il2CppArray` carries a deliberate extra trailing `void* data;` that upstream
    lacks, so ~70 call sites can write `&arr->data`. Safe because every use takes
    its *address*; the larger `sizeof` is only ever used as a length bound.
    **Deleting it breaks every one of those call sites.** Leave the comment.
- **`compatibility/profiles/<build>/manifest.json`** — per-game-build IL2CPP
  offsets. The build writes it to `<out>/ta/compatibility/profiles/` and the
  loader reads via `module_paths::data_directory_wide()` — these two disagreed
  for the project's whole life, so the profile was deployed, valid, and **never
  once loaded**. `tools/tests/test_profile_path.py` (10 cases) exists to hold the
  reader, the build, and `deploy.py` to the same path.
  - **A new game build is a procedure, and it is written down:
    `compatibility/REFRESH_RUNBOOK.md`.** Read it before editing an RVA. Re-derive
    every symbol from a *named* oracle, most-stable-first (`export` names, then
    patterns, then RVAs by PDB name) — and treat `validate` passing as proof of
    nothing more than internal consistency. Two wrong-but-consistent states have
    already shipped here: a profile missing 2 of its symbols, and `parse_pdb.py`
    returning a valid RVA for the wrong method.
    `tools/verify/verify_manifest.py` (bytes) and
    `tools/verify/ida_manifest.py` (names, needs a licensed IDA + matching
    `.i64`) are the two halves; both exit `2` rather than `0` when they cannot
    check anything.
  - Two conventions a validator will otherwise get wrong: `size` is
    `SizeOfImage` (not file size) and `text_sha256` is raw on-disk `.text` bytes
    (not `VirtualSize`).
  - The two `compat_profile` implementations (one per DLL) **must not be merged**
    — neither project directory is self-contained. Decided; do not relitigate.
  - `module_paths.h` is the last undeclared cross-project include (Bypass reaches
    into Addons). Deliberately not moved.

## Runtime

```
build  →  C:\Battlestate Games\BsgLauncher\TarkovAddons.dll
launch →  C:\Battlestate Games\BsgLauncher\BsgLauncher.exe
log    →  C:\Battlestate Games\BsgLauncher\tarkovaddons_log.txt
```

- **Launch through `BsgLauncher.exe`.** Starting `EscapeFromTarkov.exe` directly
  does not load the DLL — no log, no mod, looks like a clean launch. A launcher
  sitting at its UI waiting for input is a UI state, not a failure.
- Close Escape from Tarkov and the Battlestate client before installing; a loaded
  DLL cannot be replaced.
- **Quote the log *file*, never the console copy.** The file is flushed per line
  so a crash leaves the last statement on disk; the console copy is batched and
  dies with the process. **Copy it aside before relaunching** — it is routinely
  truncated by hand and is the only artefact that reliably survives a crash.
- **More than one process writes that log, by design.** Group by `pid=` first,
  then order by time; `tid` alone is recycled across processes.
- `DEBUG` is **off by default** (`DebugLogModule::init()` disables it), but the
  *argument* to `logger::debug()` is still built by the caller every frame. Any
  per-frame trace must avoid string building or not exist.
- `install` archives each build's `.map`/`.pdb` to `symbols\<timestamp>\` beside
  the DLL (newest 8). **Always symbolize against the build that crashed**
  (`symbolize.py --build-stamp <stamp>`). A stale map shifts RVAs and yields
  frames that decode mid-instruction into plausible, entirely invented symbols.
- WER/minidumps are a bonus, not a plan — five crashes produced two dumps. The
  real instrument is `util/crash_probe.h` (read-only; every real fault returns
  `EXCEPTION_CONTINUE_SEARCH` — the only codes it consumes are the debugger's own
  `OutputDebugStringA/W` print family, `0x40010006`/`0x4001000A`, while a debugger
  is attached; where a machine delivers those raises as exceptions, that
  consumption is what keeps WinDbg from answering second-chance on every call,
  and where the kernel converts them to debug-string events first it is dormant —
  both models measured 2026-10-10, and `tools/harness/test_debugger_gate.cpp`
  names which one the machine runs). Do not put expensive work before the cheap
  part of its report: a fault inside a VEH is uncatchable, and
  that killed the process it was observing for a month.
- **Game reference material:** `D:\Games\Tarkov` is partly encrypted.
  `UnityPlayer.dll` and `GameAssembly.dll` are readable; `global-metadata.dat` is
  obfuscated across the whole file — use `TarkovAddons/GameDump/<build>/` for the
  decrypted copy. Engine is **2022.3.43f2** (from `UnityPlayer.dll`'s version
  resource; `boot.config` has no `unity-version` key). GameDump and
  `ISIL-references/` are gitignored — regenerate locally, never commit.
- Reading `ISIL-references/IsilDump`: the raw `Disassembly:` section is
  authoritative, the `ISIL:` one is a convenience that drops stack args and
  annotates survivors by guess. **~77% of ISIL is `Nop` padding** — never measure
  one against the other. You cannot map ISIL to raw by call address. Stack arg N≥5
  is `[rsp + 0x20 + (N-5)*8]`, plus one hidden trailing `Il2CppMethodInfo*`.

## Do not touch

- **The ESP / optics *typeface* is no longer frozen** — **lifted by the user on
  2026-10-13.** The overlay face (`menu::get_hud_font()`, nine EspModule call
  sites plus the ammo HUD and the watermark) now follows the menu onto Inter,
  and the ammo block's pure numbers onto JetBrains Mono
  (`menu::get_hud_mono_font()`). **Do not "restore" Segoe UI on the HUD** — the
  loader in `gui/menu/menu.cpp` is deliberate, and its fallback chain exists so
  a machine that cannot read the resource section still gets *something*.
- **The ESP / optics *logic* freeze is LIFTED — 2026-10-13, by the user.** The
  optics rework finished; the `[CLEANUP-PENDING:OPTICS]` markers have been
  removed from `module/impl/EspModule.h`, `module/esp_text.h`,
  `module/quest_esp.h`, `module/skeleton_visibility.h` and `il2cpp/unity.h`,
  and those files are ordinary first-party code again — nothing about them is
  off-limits. What each deferred item *was* is recorded where it was found
  (`CLEANUP_AUDIT.md` §2.3/§2.4 and the header comments themselves), and two of
  those notes survive as engineering facts rather than permissions: the
  `dual_active` guards in `EspModule.h` are dead branches whose removal is a
  behaviour change, and the handoff-era open items in `tools/` stand or fall on
  their own evidence now that nothing is coordinating them. The history — what
  was frozen, why, and what it cost — stays in the dated sections of
  `AGENTS_TODO.md` and `tools/handoff_*.md`; do not re-read any of it as a
  restriction on today's tree.
- `injector.cpp` was listed here as having "two memory-corruption bugs (Flink
  where `CONTAINING_RECORD` belongs; `CloseHandle` on a module base)". **Resolved
  2026-10-05: the `CloseHandle` was real and is fixed; the `Flink` claim was
  wrong** — both offsets are 0 (measured), so those expressions *were*
  `CONTAINING_RECORD`, and line 68 was never that pattern at all. Two
  `static_assert`s now pin it. See `AGENTS_TODO.md` §3.1 before repeating it.
- `AGENTS_TODO.md`'s retraction sections and `CLEANUP_AUDIT.md`'s optic items are
  records of what was investigated and *withdrawn*. Several are enforced by
  tests (`test_chams_scan_accounting.py` asserts a retracted "fix" stays
  retracted). Read before acting on anything named as a finding.

## Known-stale numbers in the docs (verified 2026-10-05)

Prefer re-running the command over quoting a figure from prose:

- `WORKFLOW.md` previously said `audit_config_pointers.py` covered **332
  pointers / 26 headers**. It reported **336 / 28** when checked on 2026-10-05 and
  **337 / 28** when re-measured on 2026-10-06. Both are now corrected to the
  measured figure, and `tools/tests/test_doc_counts.py` re-derives it from the
  tool on every run so it cannot drift again.
- Wall-time build figures (118 s, 152 s, …) are properties of the tree they were
  measured on. Compare the two arms of one experiment, never across trees.
- The pytest count is deliberately *not* machine-checked — a cross-document
  agreement check was written and deleted because its only remedies were editing
  accurate history or removing the check. Don't re-add it.
- Nothing in the harness compiles `test_card_fold_realfile.cpp`; count the cases
  the runners execute, not the `.cpp` files in the directory.
