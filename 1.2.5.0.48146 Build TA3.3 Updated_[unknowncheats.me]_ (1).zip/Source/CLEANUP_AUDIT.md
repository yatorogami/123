# Stale-code audit

Companion to `CHANGELOG.md`. Everything below is derived from mechanical analysis of the tree, then **hand-verified** — the method and its limits are stated in §0 so you can judge each item.

> ## STATUS: APPLIED — with §2.4 corrected below
>
> | Decision | Outcome |
> |---|---|
> | **ESP / optics code WAS frozen** — the optics rework has since landed and the freeze was **lifted by the user on 2026-10-13**. §2.3/§2.4 items are now ordinary cleanup candidates, **none actioned**. The `[CLEANUP-PENDING:OPTICS]` markers have been removed from `EspModule.h`, `esp_text.h`, `quest_esp.h`, `skeleton_visibility.h` and `il2cpp/unity.h`; what each item *was* is recorded in place and below. |
> | **`always_on.h` dead chunks archived, not deleted** | §2.1 **done** → `module/always_on_deprecated.h`. See §7. |
> | **`config/FavoritesValue.h` kept** | §1.2 **kept deliberately** — see the naming-trap note. |
> | **`il2cpp/generated_bindings.h`** | §1.1 **deleted** (9,699 lines, 3.0 MB). |
> | **`assets/embedded_assets.h` (base64 asset pack)** | **deleted** (22,461 lines, 2.9 MB) — the RCDATA path is now the single embedded mechanism. See §8. |
> | **i18n dead block + missing diagnostics** | §3.1 **done**: base64 fallback removed, RCDATA fallback made reachable, and a real failure diagnostic added. See §8. |
> | **Unreferenced functions (non-frozen)** | §6.2 **done**: 6 removed, 3 deliberately kept per §9, 1 (`set_static_field`) removed in the follow-up pass. §2.4 **now** done for `eft_api.h`; the `unity.h` six are frozen with the ESP surface. See §11. |
> | **Hygiene** | §5: duplicate `<random>` removed, unused `hash.h` include removed, `lib\detours.lib` unlinked, stale bypass claims in `offsets.cfg`/`patterns.cfg` corrected. |
> | **NEW — found during this pass** | **WRONG CLAIM, RETRACTED.** I reported the minimap loader as unreachable; it is not. See §9 for the retraction and the mistake that caused it. |
> | **NEW — found during the verification pass** | Two claims in this document were **wrong about what had actually landed** — the cleanup was spread across three `mid-progress` commits, and `9b779eb3` ("cleanup sweep") contains almost none of it. See §12. |
| **NEW — ISIL transit/hook audit** | One real bug **fixed** (`hk_local_raid_started` was a no-op), **two claims retracted** (`hk_try_get_location` is not the wrong method; the transit `LocalRaidSettings` "stale snapshot" was my error), **no hooks archived** — ISIL cannot establish reachability, so the rest is a candidate list awaiting station logs. See §19, and read §19.1 and §19.6c before §19.5. |
|
---

## Naming trap: `FavoritesModule` is not `FavoritesValue`

These two have confusingly similar names and are **completely unrelated**. Worth stating explicitly because it is an easy mistake to make (it was raised during this pass):

| | `FavoritesModule` — `module/impl/` | `FavoritesValue` — `config/` |
|---|---|---|
| Status | **live, and healthy** | **dead** |
| Evidence | vcxproj L324; `ModuleManager.h` L23 include, L99 instantiate | **zero** references anywhere; absent from vcxproj *and* filters |
| Category | Raid Dashboard | — |
| What it does | Lists feature toggles the user starred, by walking `CheckboxValue::all_toggles()` and calling `draw_favorite()` on the favourited ones | A `ConfigValue` subclass holding favourited **loot display names** in a `std::set<std::string>`, serialised `\|`-joined, toggled by **middle-click in EspModule** |

The live one is the star-glyph feature. The dead one is a separate 3.0 design for favouriting individual loot items, which was never wired to anything. Only `FavoritesValue.h` is reported unused; `FavoritesModule` never was.

**Kept, not deleted** — if the loot-favourites feature is still wanted, the design note in that file is worth preserving (the function-local `std::mutex` is deliberate: the class is inside `#pragma pack(1)`, and packing an OS lock primitive would misalign it). If you decide to implement it, note that it depends on an ESP-side middle-click handler that does not currently exist, and ESP is frozen — so this is a post-optics task.

---

## 0. Method, and its limits

Three passes:

1. **Transitive include closure.** Start from the 23 `ClCompile` TUs listed in `TarkovAddons.vcxproj`, follow `#include` transitively (quoted-relative, plus `AdditionalIncludeDirectories` roots). Any project-local header not reached is unreachable. This is sound for headers — a header with no path into the build cannot affect behaviour.
2. **Name-reference counting.** Regex every project identifier once into a per-file histogram, then flag functions whose identifier occurs exactly once in the whole project (i.e. only at its own definition).
3. **Hand verification** of every candidate that survived, because pass 2 cannot see dispatch through function pointers, `&fn`, or virtual overrides.

**Known limits of pass 2** — treat these as *candidates*, not verdicts:

- It cannot see a call made through a function pointer or a virtual base.
- It is textual, so it does **not** evaluate `#ifdef`. Code inside `#ifdef INCLUDE_AIMBOT` is counted even when the shipping build drops it. That is what we want here (an aimbot that is compiled out is *more* dead, not less), but it means aimbot findings describe source, not the shipped binary.
- It cannot see reflection by string name.

**A third method was used later, and it has the same weakness plus two more.**
The ISIL dump (`TarkovAddons/ISIL-references/IsilDump/`) is per-method
disassembly with a reconstructed instruction listing. It is sound for **control
flow inside one method** and it is *not* a call graph: it misses dispatch through
unnamed interface/virtual thunks (so `LocalRaidStarted` greps as zero call sites
while being invoked from `IEftSession` slot 62), it misses delegate invocation
(so `HandleFinishedTask` greps as 2 calls while really running through a
`.cctor`-cached delegate), and it misses reflection. Any "N call sites" figure
derived from it is a **lower bound**, and "zero call sites" means "no statically
named call site". §19.2 works this through with examples, and §19.1 is a
retraction caused by exactly this mistake. **Station logs outrank all of it.**

**Not verified:** I have no MSVC here, so nothing here is compile-verified. Everything is source-level. Deletions are recoverable from git, but the first build after a removal is where mistakes surface.

---

## 1. Tier 1 — whole files with zero references

Exactly **2** of 94 project-local headers are unreachable from the build.

### 1.1 `il2cpp/generated_bindings.h` — 9699 lines

Unreachable, absent from `TarkovAddons.vcxproj` and `.filters`, zero `generated::` call sites anywhere. You already flagged this as a bad venture; the analysis confirms it and adds detail on *why* it is unsalvageable as-is:

- **It cannot be regenerated.** The banner says `AUTO-GENERATED by generate_bindings.py`, and that script is not in the repo.
- **Its offsets are demonstrably wrong.** 1043 bound methods collapse to 334 distinct offsets. 126 methods share `0xDDF80`, 91 share `0x350C10`, 62 share `0x3F68B00`, 62 share `0x107E690`, 51 share `0x22C5F60`, 28 share `0x19E7760`. Concretely, `ClientTransitController::OnItemAdded`, `::IsVisibleTransitPoint` and `::SetTimers` all resolve to `0x19E7760`. Anything built on this calls the wrong function.
- **Its one guard is unreachable.** `if (!fn) return …;` follows `resolve_il2cpp_func(offset)`, which returns `base + offset` — non-null for any base. If `GetModuleHandleW(L"GameAssembly.dll")` fails the helper returns the *raw offset as a function pointer*, every guard passes, and the first call jumps to a low address.
- `RaycastHit` is a struct with zero members — a generator placeholder emitted as valid C++.

`SOLVED.md` §16/§17 already records the rollback ("made things worse in-game", "Do not re-migrate"). The file outlived that decision.

**Recommend: delete.** If the generator ever comes back it should be re-derived from the ISIL dumps, not from this.

### 1.2 `config/FavoritesValue.h` — 132 lines — **KEPT, not deleted**

See the naming-trap table at the top of this document first: this is **not** `FavoritesModule`, which is live. This is the separate, unwired loot-favourites type from 3.0.

Also unreachable, and — unlike the bindings — it is **not even listed in the vcxproj or the filters**. `class FavoritesValue` is never instantiated. Its only project-wide references are its own definition and a passing mention in `compatibility/PROFILE_GUIDE.md`.

`git grep` at both ends of the range shows it was **born dead**: at `a3307eaf` the only file naming it was itself, and at `HEAD` it is still only itself plus that doc. The stated purpose — "middle-click in `EspModule` toggles entries read on the game Update thread" — has no corresponding handler anywhere; the middle-click path it was designed for does not exist.

**Status: deliberately left in place.** If the feature is wanted, it is a post-optics task because it needs an ESP-side change. If it is not wanted, deleting it is then a one-liner.

---

## 2. Tier 2 — functions defined and never referenced (34, all hand-verified)

Every item below has **exactly one** occurrence project-wide: its own definition.

### 2.1 Never hooked — a whole hook body — **DONE: archived**

| Symbol | Was at | Now |
|---|---|---|
| `hk_transit_point_move_next` | `always_on.h:1354` (~130 lines) | `module/always_on_deprecated.h` |
| `o_transit_point_move_next` | `always_on.h:43` | `module/always_on_deprecated.h:75` |
| `get_bots_controller_sig` / `o_get_bots_controller` | `always_on.h:51-52` | `module/always_on_deprecated.h:218-219` |
| `on_ep_interaction_sig` / `o_on_ep_interaction` | `always_on.h:54-55` | `module/always_on_deprecated.h:221-222` |

A `TransitPoint+<Transit>d__38.MoveNext` hook, **never registered** in `init()`. It reads the state-machine struct at hardcoded `+0x10` and `+0x18..+0x80` and scans fields for a `TransitPoint` instance. Its own comments record that it crashed: *"Skipping TransitPoint field dump (previous crash at Dictionary field)"* and *"Controller/async op inside TransitPoint is likely the blocker."*

Moved rather than deleted because a long time was spent on the transit screen-hang investigation and the dead ends are worth keeping. See §7.

**`always_on.h` went 1885 → 1759 lines.** Verified after the move: braces balanced (297/297), **hook registration count still exactly 24**, no dangling references (`o_get_bots_controller` and `o_on_ep_interaction` now have zero occurrences; the three remaining mentions are comment-only).

### 2.2 Superseded wrappers

| Symbol | Location | Superseded by |
|---|---|---|
| `utils::send_input_vk` | `util/utils.h:13` | `AimbotModule::move_mouse` (`AimbotModule.h:202`) — its own local `SendInput` wrapper. Two independent `SendInput` call sites exist; the utility is the orphaned one. |
| `estimate_ricochet_chance` | `skeleton_visibility.h:512` | the new `assess_ricochet` model. Kept deliberately as a "thin shim that ignores the magnitude" — but nothing calls it, so the shim serves no caller. |
| `load_raster_layers` | `minimap.h:1846` | one-line passthrough to `open_svg_for_map`; map loading actually runs via `request_active_map` / `active_map()`. Verified: **map loading is not broken.** |
| `ensure_active_map` | `minimap.h:2299` | same — thin wrapper, superseded by the pending-load worker path |
| `is_quest_item` | `game_item_db.h:542` | consumers read `entry::quest_item` directly |
| `locale_file_exists` | `util/i18n.cpp:398` | superseded by the reordering in `load_locale_file` — see §3 |
| `load_async` | `item_pricing.h:618` | the `refresh_async` path is the one wired up |
| `set_static_field` | `il2cpp/il2utils.h:135` | never used; note its sibling `get_static_field` *is* used, and has a real uninitialised-read bug (see `CHANGELOG.md` §4) |
| `estimate_ricochet_chance`'s caller chain aside, `bounds_from_corners` | `util/map_editor.cpp:17` | |

### 2.3 Left over from the optic rework — **the freeze on this was LIFTED 2026-10-13**

**Written while the optics rework was in flight on another machine, when all ESP-side code was frozen.** Every item in this subsection was left in place deliberately and was marked in-tree with a `[CLEANUP-PENDING:OPTICS]` block comment at the top of the relevant file (`EspModule.h`, `esp_text.h`, `quest_esp.h`, `skeleton_visibility.h`), each listing what specifically was deferred there.

**The rework landed, the user lifted the freeze, and those markers were removed on 2026-10-13.** Everything below is therefore an ordinary cleanup candidate again — deferred by circumstance, not by decision, and the circumstances have expired. Two cautions survive as engineering facts: the `dual_active` guards (below) are a behaviour change to remove, and `estimate_ricochet_chance`'s rationale comment is worth keeping even if the shim goes. None of it was actioned when the markers came off.

| Symbol | Location | Note |
|---|---|---|
| `draw_player_box_overlay` | `EspModule.h` | wraps `draw_player_box_geometry`, but **both** real call sites call `draw_player_box_geometry` directly. An orphan of the two-pass optic split — most likely created *by* the rework still in flight, so its status may change. **DELETED 2026-10-13**, once the rework had landed. |
| `normalize_dir` | `EspModule.h` | unreferenced. **DELETED 2026-10-13.** |
| `any_enabled` | `esp_text.h` | unreferenced. **DELETED 2026-10-13.** |
| `last_collect_was_authoritative` | `quest_esp.h` | unreferenced. **DELETED 2026-10-13.** |
| `is_finite` | `skeleton_visibility.h:31` | local wrapper shadowing `std::is_finite`; unused. **DELETED 2026-10-13** — the live code calls `std::isnan` directly. |
| `estimate_ricochet_chance` | `skeleton_visibility.h:512` | deliberate "compatibility shim" for the `P(deflect) = 1 − \|cos(incidence)\|` correction, with no callers. **DELETED 2026-10-13**; the rationale it carried (the magnitude is deliberately not an input) is preserved here, and `assess_ricochet` is the live derivation it wrapped. |

The 5 surviving `if (dual_active && game_state::esp_ads_mask_mode == 2)` guards (`const bool dual_active = false`) are dead branches but did **not** appear in the reference scan, since they are read. In the box/skeleton/label sites they are now the **only** optic-aware branch, so the optic-aware path there is unreachable while the non-optic path is what actually runs. That is a latent correctness issue for the rework owner to resolve, not a cleanup.

Also deferred, and listed in the `EspModule.h` marker: the duplicated `#include "../../config/FloatSliderEditableValue.h"` (plus duplicated `<algorithm>`, `<unordered_set>`, `<unordered_map>`), and the stale comment above the commented-out per-frame `set_value(false)` block that still claims the code enforces something it no longer does.

**2026-10-13 — all three closed.** The include duplication was already gone from `EspModule.h` by then (one of each remains), so that item needed no edit. The commented-out `set_value(false)` block and its false claim were **deleted**. The `dual_active` guards were **kept, deliberately** — they are the only optic-aware branch at those sites, `dual_active` has been permanently false since the Dual ADS toggle was removed on 2026-09-27, and `game_state::esp_ads_mask_mode` is still user-settable, so removing them would make that knob inert without anything in the menu saying so. That is a config-schema decision, not a cleanup; the reasoning is in the `EspModule.h` header comment. The count is **4** guards, not the 5 recorded here.

### 2.4 Speculatively-added API, never adopted — **now resolved, see §11**

`il2cpp/unity.h` gained a full vector/quaternion math surface in this window; these members have no callers:

`camera_aspect` (914) · `conjugate` (420) · `nlerp` (432) · `quaternion_from_two_vectors` (459) · `to_vectors` (143) · `transform_set_parent` (828)

**2026-10-13 — all six DELETED.** The optics rework landed without adopting them, the user lifted the freeze, and the unreferenced surface went with it; `transform_set_parent` took its `set_parent_internal` resolver (one `SetParent` `get_method` at init) with it. Worth noting `camera_aspect` specifically: one would expect the aimbot to need it, and it does not use it. The maths were written to `optic_idea.md`'s derivation and then the implementation diverged — which is the answer, and it is recorded here rather than left as a question.

**Disposition (§11, as originally written):** the six `unity.h` members were **kept** and the file marked
`[CLEANUP-PENDING:OPTICS]`, because they were written for the optics rework that
was in flight and the quaternion surface is what that rework was most likely to
want. The unrelated `eft_api.h` and `util/utils.h` / `InventoryEditorModule.h`
items in this subsection **were** removed.

**2026-10-13 — the deferral expired.** The optics rework landed without adopting the
quaternion surface, the user lifted the freeze, and the `unity.h` marker was removed.
The six members are now ordinary cleanup candidates and were **not** removed when the
marker came off; `camera_aspect` remains the interesting one, for the reason above.

Also unreferenced: `is_bot_corpse_inventory_open` (`eft_api.h:3985`) · `is_btr_bot` (3028) · `is_follower_role` (375) · `is_loot_container_display_name` (2904) · `is_lootable_container_object` (3045) · `wstring_contains` (265) · `has_armor_component` (`InventoryEditorModule.h:659`) · `set_int_field` (`InventoryEditorModule.h:479`) · `is_key_down` / `is_key_held` (`util/utils.h:27,31` — note the `is_key_down` grep hit inside vendored imgui is an unrelated local variable).

Two in the vendored-but-local `il2cpp/libil2cpp/`: `GetTokenRowId`, `GetTokenType` (`il2cpp-metadata.h:106,110`).

---

## 3. Tier 3 — unreachable statements and dead branches

### 3.1 `util/i18n.cpp` — ~50 lines after `return`

`load_locale_file` ends its `try` with `return true;` and its `catch` with `return false;`. **Everything after that `return false` is unreachable** — approximately 50 lines implementing both embedded fallbacks:

- `load_embedded_locale_json(locale_code, embedded_json)` over the base64 `embedded_assets::k_language_assets`
- `embedded_locale_bytes(locale_code, resource_size)` over RCDATA 1300–1318

The function's own header comment still states the opposite priority ("Only fall back to the embedded assets … once no translation file is found on disk"). Consequences already noted in `CHANGELOG.md` §16: the `.rc` and `embedded_assets.h` are still *built* for an embedded-first delivery that no longer happens, and `discover_available_languages()` still counts embedded assets, so the picker advertises 19 locales the loader cannot read.

`locale_file_exists` (§2.2) is the now-orphaned half of the same refactor.

### 3.2 `il2cpp/il2cpp_offsets.h:437-440` — a branch that can never be taken

```cpp
if (any_null)                                  // line 431 — returns false here
{
    logger::error("IL2CPP API incomplete; mod startup will stop safely");
    return false;
}

if (any_null)                                  // line 437 — always false
    logger::error("Il2CPP API incomplete — Unity init will likely fail");
else
    logger::info("IL2CPP API Loaded");         // line 440 — always taken
```

Lines 437–438 are dead. 440 always fires, including on a profile-loaded run. Harmless but misleading: the string `Il2CPP API incomplete` still exists in the binary, so grepping for it suggests a code path that cannot run.

### 3.3 Empty-but-registered stubs

| Symbol | Location | Note |
|---|---|---|
| `register_icebreaker_scenario` | `hotkeys_register.cpp:95` | **empty function body.** Called from `ModuleManager::init`. The 909-line `IcebreakerScenarioModule` therefore has no hotkey *and* no nav entry (its `Misc` category is absent from `navs[]`), so it is entirely unreachable. |
| `hook_vtable_method` | `il2utils.h` | `[[deprecated]]`, and its body passes `nullptr` to the replacement — a no-op that only logs. |
| `ChamsModule::draw_overlay` / `application_update` | `ChamsModule.h` | emptied after the loot-chams work moved to `scan_item_chams` |
| `MenuSectionValue::draw` | `config/MenuSectionValue.h:15` | empty, but **still constructed by every module and still serialized**. Documented as intentional in-file. Retained for config compatibility — so deleting it is a format change, not a cleanup. |
| `TA_FRAME` | `util/tracy_bridge.h` | defined with a documented contract ("call once per rendered frame"), **zero call sites**. |
| `launcher_dir` | `vk_swiftshader/dllmain.cpp:38` | dead — and its own comment describes the CWD problem that `LOG_FILE` still has. |

---

## 4. Tier 4 — duplication

| What | Where | Note |
|---|---|---|
| **PE RCDATA walker, 3 copies** | `module/minimap.h` · `gui/menu/menu.cpp` · `util/i18n.cpp` | Hand-parses `IMAGE_DOS_HEADER` → `DataDirectory[RESOURCE]` → `IMAGE_RESOURCE_DIRECTORY`, no bounds validation against the section size. The `i18n.cpp` copy is *also* the unreachable one from §3.1 — so collapsing to one shared helper would remove a copy and a dead path at once. |
| `EspModule::matches_loot_teleport_filter` | `EspModule.h:1901` | **RESOLVED in part** by `CHANGELOG.md` §0.61: the filter-4 shared-`ConfigValue` mutation is gone (it now delegates to `item_categories::matches_teleport_filter`, which decides case 4 on the category alone). **Still open:** `public:`, **zero callers** — `LootTeleportModule::matches_filter` is the live path. The dead original is still misleading; making it `private:` is the small fix, deleting it the thorough one. |
| ~~The wishlist/category keyword lists~~ | ~~`EspModule::loot_ui_filter_allowed` vs `LootTeleportModule::matches_filter`~~ | **RESOLVED** by `CHANGELOG.md` §0.61. The 9 keyword lists are gone. Both modules now resolve the category from the ItemTemplate's class ancestry and ask one shared predicate, `item_categories::loot_category_allows`. The "deliberate, so the card does not depend on the renderer" reasoning was about the *settings*, not the *predicate* — the settings are still per-module (`loot_*` vs `ltp_*`), the answer is not. |
| `SendInput` | `util/utils.h:22,24` vs `AimbotModule.h:208` | the utility is the orphaned half (§2.2) |

---

## 5. Tier 5 — hygiene

**Duplicate `#include`s** (same header twice in one file):

- `module/impl/EspModule.h` — `algorithm`, `unordered_set`, `unordered_map`, and **`../../config/FloatSliderEditableValue.h`** (all ×2)
- `module/impl/HideoutAutomationModule.h` — `random` (×2), which is also why §4.2's agent report saw "`<random>` appears twice"

**Unused include:** `il2cpp/il2utils.h` includes `../util/hash.h` and no longer uses it.

**Persisted-but-never-read config values** — four `safety_switch` objects survive as config entries that are loaded, saved and displayed nowhere:

- `PlayerModule::safety_switch`
- `ItemModule::safety_switch`
- `InventoryEditorModule::safety_switch`
- (`QuestModule`'s was removed outright)

**Vendored noise — resolved.** `lib\detours.lib` was in `AdditionalDependencies` in all four x64 `Link` groups with zero Detours sources in `TarkovAddons.vcxproj`; the link is gone. The bypass used Detours for real and was the last legitimate consumer, but it too has since moved to SafetyHook, so nothing links Detours anywhere now. SafetyHook is no longer vendored twice either: both projects compile the single copy in the shared root `external/safetyhook/`. The unused `TarkovAddons/lib/detours.lib` binary and the dead `$(ProjectDir)external/detours` include directory are the only Detours remnants left.

**Do NOT merge the two `compat_profile` implementations — decided, not an oversight.** `TarkovAddons/il2cpp/compatibility_profile.{h,cpp}` and `TarkovLauncherBypass/util/compat_profile.{h,cpp}` look like duplicates and are not. The only byte-identical code is the 6-line `status_priority()` ladder. Everything else diverges on purpose:

- **Data model.** TarkovAddons `Symbol` is 9 fields (name, module, resolver, export_name, `patterns[]`, `resolution_order[]`, expected_matches, optional rva, required) in an `unordered_map`. The bypass `ManifestSymbol` is 2 (rva, first pattern) in a flat vector with linear search, because the launcher resolves ~4 offsets once at attach and then patches. Sharing the heavy model would add allocation and lookup cost to a path whose contract is "never block the launch".
- **Selection policy is opposite.** TarkovAddons matches module identity and returns a hard-failing `LoadResult::Mismatch`. The bypass explicitly does *not*: its header says it takes "any manifest of the right architecture … the newest status wins", and byte-validating the RVA against the live target is its only correctness gate. Merging selection would either import a hard-fail into the launcher's critical path or add a mode flag that re-tests the premise — the exact "unnecessary work in the launcher" to avoid.
- **Lifetime.** TarkovAddons constructs a `Profile` and queries it repeatedly; the bypass parses once into file-scope globals during worker init and never again.

If the two ever need to converge, the safe shape is a shared *core* that only parses the manifest envelope (`schema_version`, `profile.architecture`, `profile.status`) with the symbol model and selection policy left per-project — not one merged implementation.

**One undeclared cross-project include remains.** `TarkovLauncherBypass/util/compat_profile.cpp` includes `"../../TarkovAddons/util/module_paths.h"`. `module_paths.h` is header-only, all `inline`, and generic (resolve your own DLL's on-disk directory, cached at attach before anti-cheat LDR hiding), so it is a genuine shared utility that is filed in the wrong place. It was left alone here because moving it means rewriting 11 include sites across TarkovAddons, several of them first-party rather than vendored — so it does not belong in the third-party `external/`. Note its `GetModuleHandleW(L"TarkovAddons.dll")` fallback is dead in the launcher (TarkovAddons.dll is loaded in the *game* process, so the call returns null and the chain falls through); this is harmless, not a divergence risk, because both DLLs ship in the same folder.

**Stale comments that now point at nothing:**
- `TarkovAddons/offsets.cfg` and `patterns.cfg` still document per-key overrides "on the TarkovLauncherBypass side" — no longer true; the bypass reads the manifest.
- `il2cpp/exports.h` retains build-46221-specific offsets ("Unwrapped body @ 0x33CCF0", "byval_arg is at +0x20 on 46221") for code paths that were replaced.
- `EspModule.h` around the commented-out per-frame `set_value(false)` block says the calls exist "so saved configs cannot reactivate their world scans" — the calls are commented out, so the code no longer enforces that.
- ~~`TarkovLauncherBypass.vcxproj` gained `<ClInclude Include="util\Config.h" />` in this window while that file was deleted from disk and from git.~~ — **DONE**, the dangling entry was removed from `TarkovLauncherBypass.vcxproj` and `.filters`.

---

## 6. Suggested order of work

> **STATUS: this list is applied.** It is kept as the record of what was decided
> and why, not as a to-do list. For what is still outstanding see
> `AGENTS_TODO.md` and `CHANGELOG.md` §6.
>
> Disposition: 1, 2, 4, 5 and 6 are done. 3 remains deferred to the optics owner.
> 7 is still undecided for two of its three items — `TA_FRAME` was deleted, and
> `MenuSectionValue` / the four `safety_switch` entries remain open.
>
> **Correction (§12).** Steps 4, 5 and 6 were described here as applied before
> anyone had checked the tree. They largely were, but step 5 was overstated: it
> claimed "§2.2 removed 10 functions" and that §2.4 was done, and neither was
> true. `set_static_field` was still defined and all twelve `unity.h` /
> `eft_api.h` helpers were still present. See §11 and §12.

Cheap and safe first, because each is independently verifiable:

1. ~~**Delete the two unreachable files** (§1).~~ — *revised.* `FavoritesValue.h` is **kept** (§1.2); only `generated_bindings.h` remains a deletion candidate, and it is unambiguous: 9699 lines, unreachable, not in the project, generator absent, offsets provably wrong.
2. ~~**Delete the dead hook body** `hk_transit_point_move_next`~~ — **DONE**, archived instead of deleted (§7).
3. ~~**Delete the 5 dead `dual_active` branches**~~ — **DEFERRED** to the optics owner (§2.3).
4. ~~**Delete the unreachable i18n block** (§3.1)~~ — **DONE**, plus the decision on the RCDATA entries: kept, and they are now the only embedded mechanism (§8).
5. ~~**Unreferenced functions** (§2.2, §2.4)~~ — **DONE, but not when this said it was.** `send_input_vk`, `is_quest_item`, `locale_file_exists`, `load_async`, `bounds_from_corners`, `hook_vtable_method` and `set_static_field` are gone; the six `eft_api.h` helpers are gone; the six `unity.h` math helpers are kept under the optics freeze. Three §2.2 rows were never candidates — they are the deliberate keeps from the §9 retraction. See §11.
6. **Hygiene** (§5) — duplicate includes outside ESP, unused `hash.h`, stale comments, `lib\detours.lib`.
7. **Decide, don't delete:** `MenuSectionValue` (format change), the four `safety_switch` entries (config-file change), `TA_FRAME` (delete or use — **done**, see §3.3).

One thing I did **not** touch: anything in `TarkovLauncherBypass/feature/injector.cpp`. It is unreformat-only since 3.0 and still carries the two confirmed memory-corruption bugs (`Flink + FIELD_OFFSET` instead of `CONTAINING_RECORD`, and `CloseHandle` on a module base address). Those are live bugs, not stale code, and fixing them is a behaviour change to a working injector.

> **BOTH CLAIMS RESOLVED 2026-10-05 — one fixed, one retracted. Read this before
> repeating either.**
>
> - **`CloseHandle` on a module base address: WAS REAL, NOW FIXED.** `found_module`
>   is `reinterpret_cast<HMODULE>(me32.modBaseAddr)` — a base address, not a handle;
>   the only handle in scope is `snapshot`, already closed above. Deleted. Harmless
>   in practice (module bases cannot collide with this process's small kernel
>   handles) but it clobbered the thread's last-error for whatever ran next.
> - **`Flink + FIELD_OFFSET` instead of `CONTAINING_RECORD`: NEVER A BUG.**
>   Measured: `offsetof(LDR_DATA_TABLE_ENTRY, InLoadOrderLinks) == 0` and
>   `offsetof(LIST_ENTRY, Flink) == 0`, and both expressions evaluated on the same
>   `LIST_ENTRY` printed the **same pointer**. `InLoadOrderLinks` is declared first
>   (`libs/ntdll.h:1982`), so the two forms are the same expression. Rewriting it
>   would have produced identical code behind a different-looking diff.
>
> The audit also listed **line 68**, which is `pbi.PebBaseAddress +
> FIELD_OFFSET(PEB, Ldr)` — there is no `Flink` on it, and reading `PEB::Ldr` at
> 0x18 is the only way to reach the loader list. That line looks like a
> pattern-match on `FIELD_OFFSET(` rather than a reading.
>
> Two `static_assert`s now pin both offsets, so the surviving claim is checked by
> the compiler rather than carried in prose. **The caution that motivated leaving
> this file alone was never wrong** — an injector that rewrites another process's
> loader list and strips PE headers deserves scepticism regardless — only one
> specific finding inside it was.

---

## 8. `assets/embedded_assets.h` — deleted, RCDATA is now the single mechanism

**Removed:** 22,461 lines / 2.9 MB of base64. Like the bindings, **it had no generator** — nothing in the repo produces it, so it could not be maintained or rebuilt.

The real problem was duplication: **the same 19 locale files and 22 map files were compiled into the binary twice** — once as base64 in `.data` (`embedded_assets.h`) and once as RCDATA in `.rsrc` (`assets/menu_background.rc`, ids 1200–1221 and 1300–1318). Two sources of truth for identical content, which can only drift. And per §3.1 the base64 half was already unreachable in the locale loader.

**Kept: RCDATA.** It is the right mechanism — no source bloat, and the `.rc` is already wired into the vcxproj via `<ResourceCompile Include="assets\menu_background.rc" />`. The same `mapped_rcdata()` walker it uses is already proven live for RCDATA 101 (the menu background) in `gui/menu/menu.cpp`.

### Consumers rewired

| Site | Was | Now |
|---|---|---|
| `minimap.h` `ensure_embedded_maps_available` | `embedded_assets::find_map` + `decode_base64` | `embedded_map_resource_bytes()` (RCDATA), already present in the same file |
| `i18n.cpp` `load_embedded_locale_json` | base64 decode helper | **deleted**; the RCDATA `embedded_locale_bytes()` path is now the only embedded fallback |
| `i18n.cpp` `discover_available_languages` | counted `find_language()` (base64) **and** RCDATA | counts RCDATA only — both sources are now real and loadable, so the list is honest |

### Behavioural improvements while in there

- **A corrupt `lang/en.json` now degrades to the built-in copy** instead of hard-failing. Previously a parse error returned `false` immediately, so a half-deployed or truncated file produced raw keys everywhere. The warning is kept and now says the built-in copy was tried.
- **A single missing map payload no longer aborts the whole unpack.** The old loop did `return` on the first failure, leaving a partially written cache and `active_maps_directory()` unset. It now logs per-file, continues, only claims success if at least one file landed, and reports the count (`"Built-in minimap assets unpacked: <dir> (21/22 files)"`).
- **The misleading discovery log is fixed.** `discover_available_languages` hardcoded `"(from <lang dir>)"` even when every locale came from the compiled-in RCDATA and nothing came from disk — precisely backwards during the misdeployment it was supposed to explain.

### The missing diagnostics — the actual gap you pointed at

`ensure_locale_loaded` had **no failure reporting at all**: on total failure it just did `translations.clear()`, and the user saw the entire menu rendered as raw config keys (`weapon_builder_mod`, `tp_all_btn`, …) with nothing on screen or in the log explaining why. Maps already had good diagnostics (`format_maps_search_paths()` plus actionable hints), which is why the asymmetry stood out.

`ensure_locale_loaded` now logs, on total failure: that nothing loaded, the locale, **every directory searched**, and three concrete fixes — copy the `lang` folder next to the DLL, or set `langDir=` in `launcher.cfg`, or drop the single file in — plus the note that RCDATA 1300–1318 should have caught it and that a failure there means a truncated DLL or a build that skipped `menu_background.rc`. Partial failure (`<locale>` missing but English loads) also now logs the fallback instead of silently switching.

**Deploy-layout comments** were added where each search list is defined, so the information is discoverable without reading the log:

- `util/i18n.cpp` `lang_directories_wide()` — the 5-step order, the `langDir=` override, what a locale filename looks like, the raw-key symptom, and the guarantee that English is the floor.
- `module/minimap.h` `build_maps_search_directories()` — the 6-step order, what a maps directory must contain, the 11 built-in maps, which two intentionally have no SVG and three no `tile_path` (so a marker-only radar is by design, not an error), the `tile_cache/<map_id>/` offline hint, and the `Minimap files not found. Searched paths:` signature.

**Trade-off, stated plainly:** this swaps a mechanism for a *live* one. Single-file deploys still work, but the map path now depends on the RCDATA walk succeeding where base64 was previously used. It cannot be compile- or run-tested here, so it needs a smoke test: boot, confirm the `"Built-in minimap assets unpacked: … (22/22 files)"` line, and confirm a language still loads.

---

## 10. Bug fixes applied

All of these were identified earlier in this document or in `CHANGELOG.md`, are outside the frozen ESP surface, and are now fixed. Verified by brace balance, by a project-wide include-resolution sweep, and — where noted — by an executed test.

### 10.1 Memory safety

| Fix | File | Was |
|---|---|---|
| **1-byte heap overflow** | `util/module_paths.h` `wide_to_utf8` | `WideCharToMultiByte(..., -1, ..., size, ...)` reports the byte count **including** the NUL, and the old code allocated `size - 1` then told the API it had `size`. Now passes an explicit character count so no terminator is written. **Tested:** an executable harness demonstrates the overflow (`reports 30, allocates 29, writes 30`) and then verifies the new implementation is byte-identical to the old on 8 inputs including Cyrillic, CJK and an emoji, plus empty/single-char/100-char edges. 8/8 content cases pass, 8/8 "new == old" pass. |
| **Out-of-bounds dictionary write** | `module/always_on.h` `modify_raid_settings` | `for (int i = 0; i <= m_i_count; ++i)` — `m_i_count` is the **live** count, so the last iteration wrote one slot past the used range, and past the `m_p_entries` allocation entirely when the dictionary was full. Now `i < m_i_count`. |
| **Durable bounds guard** | `il2cpp/unity.h` `unity::dict` | `set_value_by_index` / `get_key_by_index` / `get_value_by_index` indexed `p_entry[i]` with **no bounds check at all**. Added `index_in_range()` (checks `i >= 0` and `i < m_p_entries->max_length`) and made `set_value_by_index` return `bool` so a rejected write is visible. Behaviour for valid indices is unchanged. |
| **Null dereference** | `module/impl/QuestModule.h` | `get_field<unity::list*>("_questsData")` was dereferenced unchecked on both hops (`status_data->m_p_list_array->max_length`). A renamed field or a failed `get_Quests()` was an access violation, not an empty list. Now returns early with a warning, balancing `names_lock`. |
| **Out-of-bounds vector index** | `module/impl/WeaponBuilderModule.h` | `gameworld_update` consumes `refresh` → `inspect` → `install` in one pass and `refresh_weapons()` clears `weapons_` and resets `selected_weapon_ = -1`. Bounds were only checked when the *request* was made, never when it was *consumed*, so two queued clicks indexed `weapons_[-1]`. `inspect_slots` and `install_selected_item` now check `has_selected_weapon()` / `has_selected_slot()` at consume time. |

### 10.2 Correctness

- **`i18n::tr()` data race** (`util/i18n.cpp`) — the mutex was dropped from `tr()` at some point while the writers still reassign `translations` under `locale_mutex`, so a language switch raced the render thread on an `unordered_map`. Lock restored; verified none of the three lock holders (`init`, `init_menu_languages`, `set_locale`) call `tr()`, so there is no deadlock.
- **`logger::g_debug_enabled` default** (`util/logger.cpp`) — was `true`, contradicting both its own comment and `logger.h`, producing DEBUG output from logger init until `DebugLogModule::init()` ran. Now `false`.
- **Dead branch** (`il2cpp/il2cpp_offsets.h`) — an `if (any_null) ... else ...` after an earlier `if (any_null) return false`, so the true branch could never run and a second misleading "IL2CPP API incomplete" string was compiled in. Collapsed to the single reachable `logger::info("Il2CPP API Loaded")`.
- **`hook_change_health` no-op** (`module/impl/PlayerModule.h`) — computed a clamped `m_delta` through a `_bodyState` reflection walk, then forwarded the **unmodified** `delta`, so the whole computation was discarded at the cost of a reflection lookup and a full entry scan on every damage event. Death is already blocked by `hook_kill`, so this is now an honest passthrough; the clamp logic is preserved in comments rather than deleted, because enabling it is a gameplay change that should be a deliberate decision.
- **Bare `min`/`max`** (`il2cpp/unity.h`, `module/impl/WeaponModule.h`, `module/impl/ItemModule.h`) — 4 sites relied on the `windows.h` `min`/`max` **macro** rather than `std::min`/`std::max`, which breaks the moment anything defines `NOMINMAX` (the vendored Tracy and SafetyHook both do, in their own TUs).

  **And my first fix to these was itself a bug, caught by the compiler.** I initially rewrote them to a bare `std::min(a, b)`. That form is *also* wrong, and worse than the original: `windows.h` defines `min` as a **function-like** macro, so `min` immediately followed by `(` gets expanded, yielding `std::(((a) < (b)) ? (a) : (b))` — a syntax error. `unity.h` includes `<Windows.h>` at line 9 and does not define `NOMINMAX`, so all four sites would have failed to build. The correct form is the **explicit-template-argument** one, `std::min<T>(a, b)`, because `min` is then followed by `<` and the macro is not invoked. The project already documents this exact rule at `module/optics_lens_pipeline.h:1845` and I had read past it.

  All four now use `std::min<T>` (`<float>` in `unity.h`, `<int>` in the two module files), each with a comment pointing at the reason.

  **Verified by compilation, both directions**, against a synthetic translation unit that defines `min`/`max` exactly as MSVC's `windows.h` does and then compiles the real `rotateTowards` bodies:

  | form | result |
  |---|---|
  | `std::min<float>(a, b)` | compiles |
  | `std::min(a, b)` | **fails** — `expected unqualified-id before «(»` |
  | `(std::min<float>)(a, b)` | compiles (the codebase's other existing style) |

  A project-wide sweep confirms **0** remaining instances of either the bare-`min(` or the un-templated `std::min(` form. Note mingw's headers define `NOMINMAX` by default, so this class of bug is invisible to a mingw build unless the macros are simulated — which is why the test defines them explicitly.

### 10.3 Pre-existing build breakage — **the committed tree did not compile**

`module/hideout_reflection.h` had two includes that resolve to non-existent paths:

```cpp
#include "../eft_api.h"        // -> TarkovAddons/eft_api.h   (file is module/eft_api.h)
#include "../../il2cpp/unity.h" // -> <repo root>/il2cpp/unity.h (file is TarkovAddons/il2cpp/unity.h)
```

Both are included by `HideoutModule.h` and `HideoutAutomationModule.h`, both registered in `ModuleManager.h`, both in the vcxproj — so nothing could build. Corrected to `"eft_api.h"` and `"../il2cpp/unity.h"`.

This was found by a project-wide sweep of every quoted `#include` against the filesystem, which now reports **0 unresolvable** project-local includes (the only remaining misses resolve through `AdditionalIncludeDirectories`, i.e. `imgui.h` and `tracy/Tracy.hpp`).

### 10.4 RCDATA walker: 3 copies → 1, and now bounds-checked

New `util/pe_resource.h` holds the single implementation, previously copy-pasted into `module/minimap.h`, `gui/menu/menu.cpp` and `util/i18n.cpp` (159 lines total). All three now call it, and the two hand-rolled Win32 fallbacks are gone — `pe_resource::rcdata()` does manual-walk-then-`FindResourceW` — which also removed the two `GetModuleHandleExW(..., reinterpret_cast<LPCWSTR>(&fn), ...)` function-pointer casts (an MSVC-permissive construct that is ill-formed elsewhere).

**The three copies had no bounds validation whatsoever.** `OffsetToDirectory`, `OffsetToData` and `Size` were never checked against the resource section extent, so a malformed or truncated resource was an out-of-bounds read. The shared version validates: every directory's header-plus-entries fits the section, every sub-directory offset is inside it, the data entry itself fits, and the payload's RVA and size are inside the section extent.

**A subtlety worth recording**, because getting it wrong is easy: `IMAGE_RESOURCE_DIRECTORY_ENTRY::OffsetToDirectory` and `...::OffsetToData` are **section-relative**, but the `OffsetToData` field *inside* `IMAGE_RESOURCE_DATA_ENTRY` is an **RVA from the image base**. The first version of the bounds check compared the latter against the section *size* and rejected every valid payload — caught only because the harness tests against a real image rather than trusting inspection. Correct form is to bound it by `VirtualAddress .. VirtualAddress + Size`.

**Validated by execution.** An `x86_64-w64-mingw32-g++` harness builds a real PE with `windres` (RCDATA 1200/1201/1300/1301 plus an ICON), links it, and runs the header under wine. 16/16 checks pass:
- all four payloads found, **byte-identical size and content to `FindResourceW`**
- UTF-8 Cyrillic round-trips
- `rcdata()` (walk-then-API) agrees with the walk alone
- content markers present
- undeclared id, id 0, `0xFFFF`, and a wrong-type id all return `nullptr` with size 0 — no crash
- the wrong-type id still resolves via `FindResourceW` as its real type, proving the type filter is not over-rejecting
- a synthetic directory claiming `0xFFFF` entries against a 32-byte section is rejected

### 10.5 Corrections to my own claims

- The **minimap loader is alive** (§9) — retracted.
- The **`queue_start` per-frame loop** in `CHANGELOG.md` was wrong: the reset at the end of `gameworld_update` is unconditional. Corrected in place.
- The **`SendQuestCompleteToBackend` "removed API"** claim was wrong; the ISIL dump shows it present. Corrected in `CHANGELOG.md` §20.

That is four claims in this session traced to a file-scoped `grep` or to a subagent report I did not re-verify. Two of them were shipped into `CHANGELOG.md`/`CLEANUP_AUDIT.md` before being caught.

### 10.5b Deploy payload: `lang/` and `maps/` no longer copied

Once RCDATA became the load path for both, the two copies were pure payload duplication. Verified before removing them:

- **lang** — all 19 files are RCDATA 1300–1318, and `i18n.cpp` reads the compiled copy **first**. An `out\lang` folder is never read.
- **maps** — all 22 files are RCDATA 1200–1221, and they match the 22-entry `embedded_map_asset` table in `module/minimap.h` **exactly** (ids and filenames, checked one by one). `ensure_embedded_maps_available()` unpacks them to `%APPDATA%\TarkovAddons\maps` on first run.
- The `.rc` declares 42 RCDATA entries: 1 background PNG (101) + 22 maps + 19 locales.

**What replaced them** — the minimal set that is genuinely read at runtime:

| File | Read by |
|---|---|
| `launcher.cfg` | `i18n.cpp` (`langDir`), `minimap.h` (`mapsDir`), `item_pricing.h`, and all three bypass features |
| `offsets.cfg` | `il2cpp_offsets.h:243-256` — the legacy fallback when no compatibility profile matches |
| `patterns.cfg` | `il2cpp_offsets.h:319-323` — same, plus per-signature overrides |
| `compatibility/profiles\**` | already handled by the unconditional `Content` item (unchanged) |

`offsets.cfg` and `patterns.cfg` were being read at runtime but were **not copied by any configuration** — so a `NotFound` profile result silently degraded to files that were not deployed. Shipping them closes that.

**Three real problems the restructure also fixed:**

1. **Debug and Release had no post-build step at all.** They shipped none of the above — not the DLL copy, not the config, nothing. Now covered by the unconditional block.
2. **The two Prod steps had drifted.** `Prod|x64` read `$(SolutionDir)assets\maps`; `Prod no aimbot|x64` read `$(SolutionDir)..\..\maps` — a path that no longer exists, so its `if exist` guard meant the maps copy had been **silently doing nothing** in that configuration.
3. **`launcher.cfg` was only deployed in `Prod|x64`**, not in the other three.

**The trap that made this non-trivial.** `Debug|x64` and `Release|x64` set no `OutDir`/`IntDir`, so both default to the *same* directory. An unconditional `copy /Y "$(IntDir)$(TargetFileName)" "$(OutDir)$(TargetFileName)"` therefore copies a file **onto itself**, and `copy` returns **errorlevel 1** in that case — which would trip the existing locked-file branch and skip every config copy, or print a spurious "file is locked" warning on every Debug/Release build. The copy is now guarded by comparing the two paths.

**Validated by execution.** The exact command was run under wine against both layouts: *IntDir == OutDir* (Debug/Release) and *IntDir != OutDir* (Prod) — 9/9 pass. Payload lands in both; the self-copy is skipped rather than tripping errorlevel; the `.map` is deployed when present. A separate probe confirms the guard is necessary rather than defensive: an unguarded self-copy returns `errorlevel 1`.

---

### 10.6 i18n resolution reordered — RCDATA is now the guaranteed default

`load_locale_file` was disk-first with RCDATA as fallback. It is now **RCDATA-first**, and the entire disk search was reduced to a single explicit override.

**The premise checks out:** `<ResourceCompile Include="assets\menu_background.rc" />` sits in an unconditional `ItemGroup` in the vcxproj, not inside a per-configuration `ItemDefinitionGroup`. Ids 1300–1318 are therefore compiled into every configuration, so the translations are genuinely always present and a bare single-DLL drop needs no folder layout.

**What was removed** — the old `lang_directories_wide()` probed roughly ten locations:

`lang\` next to the DLL · the process CWD · the exe's folder and its parents · `..\BsgLauncher\lang` · `..\launcher\lang` · `TarkovAddons\lang` · `%APPDATA%\TarkovAddons\lang` · plus a six-level parent walk hunting for `BsgLauncher` · and a bare `L"lang"`

Several were **CWD-relative**, so the loaded translation depended on where the process happened to be launched from — the same class of fragility already flagged for `launcher.cfg` itself. That list was also the reason the old failure diagnostic was so unhelpful: "checked ten places" gives a user nothing to act on.

That whole walk, the `BsgLauncher` parent search, and the already-dead `lang_directories()` are gone. `i18n.cpp` is **609 → 533 lines**.

**What remains on disk:** exactly one location, the `langDir=` key in `launcher.cfg`, consulted *only* for a locale the binary does not carry — i.e. a custom or community translation. I kept this deliberately rather than deleting disk access entirely: it is a documented user-facing knob, and dropping it would remove the ability to ship a translation the game build has no copy of. If you would rather have RCDATA-only with no override at all, that is now a two-line change.

**Language discovery** was reordered to match: RCDATA is checked first (the guaranteed source), then the override directory contributes any *extra* codes beyond the 19 built in. The log line now names the source instead of hardcoding `(from <lang dir>)`, which had been actively misleading when every locale came from the binary.

**The failure diagnostic was rewritten, because its old advice became wrong.** It used to say "copy the lang folder next to TarkovAddons.dll" — which is now a no-op. Reaching that code at all is much stronger evidence than before: every locale is compiled in, so a miss means the **resource section is missing or unreadable**, not that a folder was absent. It now lists the actual causes in likelihood order — truncated/corrupt DLL, a build without `menu_background.rc`, or a manual mapper that relocates or discards `.rsrc` (the case `pe_resource.h` exists to handle) — and says explicitly that adding a `lang/` folder will not help.

**Validated by execution.** A test mirroring the new resolution, against real RCDATA and a real override directory whose files deliberately *contradict* the compiled copies — 10/10 pass:

- `en` present in **both** places → origin is `rcdata`, and the payload is the compiled one, not the disk one
- `ru` likewise
- `xx` with no compiled copy → falls through to the override dir and loads the custom payload
- a locale with neither source fails cleanly rather than inventing one
- `xx` fails when no override dir is set, proving **nothing else on the filesystem is consulted**

Together with the 16/16 RCDATA harness, that is 26 executed assertions covering the embedded-asset work.

---

## 9. CORRECTION: the minimap loader is NOT dead — I was wrong twice

An earlier draft of this document claimed the minimap map-loading path was unreachable. **That was wrong**, and the mistake is recorded here rather than deleted, because the failure mode is worth naming.

The chain is alive and works:

```
EspModule.h:2358        minimap::request_active_map(current_location_id)   <- every frame, radar path
MapEditorModule.h:89    minimap::request_active_map(editor.location_id)
   -> request_active_map()   writes pending_map_load()
   -> process_pending_map_load()   called every frame from gui/dxhook/dxhook.cpp:1006
   -> active_map().map_ready
```

**How I got it wrong.** After deleting a dead wrapper I noticed `request_active_map` had dropped to a single occurrence and concluded it had been orphaned — so I restored the wrapper and wrote up a "KNOWN GAP" finding plus a `[KNOWN GAP]` comment in `minimap.h`. The single-occurrence count came from `grep -c request_active_map module/minimap.h` — **scoped to one file**. The real call sites are in `EspModule.h` and `MapEditorModule.h`, which that command never looked at.

Two aggravating details worth being honest about:

- My original project-wide reference-count pass (the one that produced the 34-item dead-function list) had **correctly excluded** `request_active_map` from the dead set. I then overrode my own correct result with a narrower grep.
- I never re-ran the *project-wide* check before asserting a "pre-existing" bug and writing a prominent comment about it.

So this is the third time in this session I generalised from a file-scoped grep after a broader pass had already given the right answer (the Loot Teleport buttons, the `launcher.cfg` parse, and now this). The cheap discipline that would have caught all three: never write "X is dead" or "X is never called" from a command that did not search the whole project.

**State after correction:** the `[KNOWN GAP]` comments are removed and replaced with an accurate note. `ensure_active_map` is genuinely uncalled — it is a *request + synchronous readiness query* helper ("kick it and tell me if I can draw yet"), while the radar path calls `request_active_map` directly and then polls `is_map_ready()` across frames. That is a coherent small API, not debris, so it is kept with a comment saying it is unused and why. `load_raster_layers` was restored for the same reason.

Nothing here is a bug and nothing needed fixing. The only real cost was a wrong claim, now corrected.

---


`module/always_on.h` **1885 → 1759 lines**. Four symbols moved out; nothing deleted.

`module/always_on_deprecated.h` (224 lines) is an **archive that is not compiled and not included anywhere** — verified by grep. It exists because a long time was spent investigating the transit screen-hang (the window stalling between location selection and the destination raid), and the investigation produced both working instrumentation and a trail of disproved hypotheses. The value is as much in the comments as the code, so it is preserved rather than discarded.

The archive header records, for each moved item: what it targeted, that it was **never hooked** (which is precisely how it became dead — "defined" is not "installed"), and the specific reasons it was abandoned:

- `hk_transit_point_move_next` — the target state machine is created and consumed while the transit screen is up, before the hooks are installed. It also dereferences the state-machine struct at hardcoded `+0x10` / `+0x18..+0x80` with **no readability guard**, unlike the rest of `always_on.h`, which routes every read through `eft_api::is_readable_address`. Its own comments record a segfault walking the `Dictionary` field and name the Controller/async-op fields as the likely blocker.
- `o_transit_point_move_next`, `get_bots_controller_sig`/`o_get_bots_controller`, `on_ep_interaction_sig`/`o_on_ep_interaction` — never hooked, called, or resolved.

The archive header also warns against re-attempting it blindly, and points at what `always_on.h` learned in the meantime: state-machine field offsets are now probed per call over a delta set (`{0, ±0x8, ±0x10, ±0x20}`) via `resolve_sm_base`, because the `OnGameEnd` crash showed the header shifts between builds. The archived code predates that lesson and hardcodes its offsets.

In `always_on.h` itself, two pointer comments were left in place of the moved code — one at the signature block (lines 50-52) and one at the function site (lines 1348-1359) — so anyone reading either location learns where it went and why it should not be restored unmodified.

**Post-move verification:** braces balanced 297/297 · hook registrations still exactly **24** · `o_get_bots_controller` and `o_on_ep_interaction` have **0** remaining occurrences in `always_on.h` · the three other mentions are comment-only · the real declarations exist only in the archive.

---

## 11. Follow-up pass — the items that were claimed done and were not

This pass existed because the previous one wrote down that it had finished, and
then nobody checked the tree. Checking it found that the claims and the commits
disagreed. What follows is what was actually still outstanding, what was done
about it, and one layout change.

### 11.1 Dead code that survived the "done" tick

| Symbol | Was | Now |
|---|---|---|
| `set_static_field` | `il2utils.h:134` — the one §2.2 row that was never removed | **removed.** It also had no null check on the `FieldInfo` that `resolve_field()` returns, so a renamed field meant a write through null. Its sibling `get_static_field` is used and keeps that hazard, now noted in place. |
| `wstring_contains` | `eft_api.h:266` | **removed** — consumers call `std::wstring::find` directly |
| `is_follower_role` | `eft_api.h:376` | **removed.** `wild_spawn_api::is_follower` is still resolved and still read elsewhere, so the API surface is unchanged; only the unused wrapper went. |
| `is_loot_container_display_name` | `eft_api.h:2905` | **removed.** It held a hardcoded 27-name display list that nothing read. |
| `is_btr_bot` | `eft_api.h:3029` | **removed.** Its only live behaviour, `try_is_btr_by_weapon()`, is reachable on its own. |
| `is_lootable_container_object` | `eft_api.h:3046` | **removed** — a one-line passthrough to the `_fast` variant every caller already used |
| `is_bot_corpse_inventory_open` | `eft_api.h:3986` | **removed** — a one-line alias for the `_cached` variant, which has real callers |

Each was confirmed to have exactly one occurrence project-wide across **both**
projects before removal, and each removal was checked to make sure it did not
strand a helper it had been the only caller of. `is_follower`,
`try_is_btr_by_weapon`, `is_external_loot_inventory_open_cached`,
`is_lootable_container_class_fast`, `is_boss_role`, `wild_spawn_methods`,
`get_wild_spawn_role` and `resolve_field` all still have callers.

**Not removed, deliberately (as of §11):** the six `unity.h` math helpers (§2.4). They were
written to `optic_idea.md`'s derivation for the optics rework, which was in flight
on another machine, so `unity.h` carried a `[CLEANUP-PENDING:OPTICS]` marker
listing them. Deleting a quaternion surface that the next commit on another
machine was likely to call was not a cleanup, it was a merge conflict with extra
steps.

**2026-10-13 — that reason is gone, and the deletion is made.** The rework landed,
the freeze was lifted, and all six `unity.h` math helpers were **deleted** the
same day, together with the `set_parent_internal` resolver that only
`transform_set_parent` used.

### 11.2 A pre-existing compile error nobody had hit

`gui/menu/menu.cpp` contained:

```cpp
static const unsigned char menu_background_png[];
```

A definition of incomplete array type with no initializer — ill-formed in C++,
and MSVC rejects it. It is the leftover of deleting `assets/menu_background_bytes.inc`
in `9b779eb3`: the `.inc` had been the array's definition, the array had no other
references, and the deletion removed the definition but not the declaration. An
interim edit had made it worse by replacing an (MSVC-tolerated) `= { }` with the
bare `[];`. Removed, along with a comment that claimed the array "removes any
runtime dependency on a side-by-side image file" while the function directly
below it loads exactly that as a fallback.

### 11.3 `lang\` is no longer deployed

The post-build step copied `lang\*.json` into `ta\lang\` on every build, and its
comment described the copy as a fallback that "keeps the feature working if the
resource section is ever unavailable". Since §10.6 that is false twice over: the
19 locales are compiled into every configuration as RCDATA 1300–1318 and read
first with no filesystem access, and the only disk path left is the explicit
`langDir=` key for a locale the binary does not carry. The runtime diagnostic
added in §10.6 goes further and tells users that dropping in a `lang\` folder
will not help. The copy is removed and the comment replaced with the actual
reason. `maps\` is **kept** — `minimap.h` still lists the deployment's `ta/maps`
in its default search order, so that payload is live.

### 11.4 Config moved to `ta/configs/`

The user's settings were the one file in `ta/` that is theirs, mixed in with
shipped read-only data (`launcher.cfg`, `offsets.cfg`, `patterns.cfg`, the
compatibility manifests) and a generated cache (`tarkov_prices.json`). They now
live in `ta/configs/<config>`, so "back up your settings" is one folder and a mod
update cannot be mistaken for a settings reset.

- `module_paths.h` gains `kConfigSubdirectoryName` and
  `ensure_config_directory_wide()`. There is deliberately **no** read-only
  variant: a separate non-creating getter is how a save ends up somewhere the
  load does not look. If `ta/` itself could not be created, the accessor returns
  `ta/`'s own fallback (the DLL directory) rather than scattering a `configs/`
  next to the DLLs, preserving the pre-3.2 flat behaviour.
- `ConfigModule::config_path()` uses it. The `%APPDATA%` fallback
  (`legacy_config_path()`) is untouched.
- `data_migration.h` gains step 5: a config that a 3.2 install already put
  **directly in `ta/`** is moved into `ta/configs/`. Without this the move looks
  like "no config found" and silently resets the user to defaults — the worst
  available failure for a settings file. Step 1 (legacy `%APPDATA%`) now targets
  `configs/` directly instead of `ta/`.
- The heuristic is **not** a config-name whitelist. `is_known_ta_root_data_file()`
  excludes the five files that legitimately sit in `ta/` root, and anything else
  that is a regular file there is treated as a config, because the config set is
  user-extensible (`config_1..config_5`, user-renamable) and a whitelist would
  strand real settings. The background PNG is on the exclusion list on purpose:
  `menu.cpp` looks for it at `data_directory_wide()/"…Background.png"` as its
  last-resort texture, and moving it would break that path.
- `adopt_file()` never overwrites, so if both copies somehow exist the
  `configs/` one wins and the old one is left in place rather than deleted.
- Migration runs from `dllmain.cpp:193`, before `ModuleManager::init()` at
  `:221`, so the move happens before any config is read.

**The read path does not depend on the move having happened.** That was the
real gap in the first version of this. `load_config()` originally consulted only
`ta/configs/<config>` and then `%APPDATA%`, so *any* failure of the move — an
unwritable folder, a locked file, a partially-completed earlier run — presented
as "no config found" and silently reset the user to defaults, which is the worst
available failure for a settings file. `load_config()` now tries, in order:

1. `ta/configs/<config>` — where it lives now
2. `ta/<config>` — the 3.2 layout, via a new `previous_config_path()`
3. `%APPDATA%\TarkovAddons\<config>` — pre-3.2
4. `create_config()` — defaults, reached only when all three are genuinely empty

The move is therefore an optimisation that also tidies up, never a precondition
for finding the settings.

**Validated by execution: 32/32 assertions, nine scenarios.** A harness compiles
the real `util/module_paths.h` and `util/data_migration.h` with MSVC and drives
them against real throwaway directories. Nothing is re-implemented; the only
input is a deployment directory, supplied through the production accessor
`module_paths::cached_dll_directory()`, and `%APPDATA%` is redirected with
`_wputenv_s` because `legacy_appdata_dir()` reads it via `_dupenv_s`, which sees
the CRT's copy of the environment rather than the Win32 one.

| Scenario | What it pins down |
|---|---|
| fresh install | `ta/` created; `configs/` **not** created by a migration with nothing to do, only on first write; nothing lands loose in `ta/` |
| 3.2 flat config | moved into `ta/configs/`, byte-identical, old copy gone, lookup resolves there |
| read survives a failed move | with **no migration at all**, the 3.2 config is still found — the case above |
| renamed configs | `my_hvh_setup_v3` and a `中文_配置` filename both migrate, proving the predicate is not a name whitelist; all five shipped files stay in `ta/` root, including the background PNG `menu.cpp` looks up there |
| pre-3.2 `%APPDATA%` | imported into `ta/configs/`, legacy copy removed rather than duplicated, and `tarkov_prices.json` lands in `ta/` root and **not** in `configs/` |
| idempotence | three migration runs; the user's post-migration edit is not clobbered and no stale flat copy reappears |
| both copies exist | `configs/` wins, the old one is left in place rather than deleted |
| data beside the DLL | `launcher.cfg`, a custom `lang/xx.json` and `maps/` still import, so dropping the postbuild copy did not break migration |
| genuinely empty | the only path that reaches defaults |

To make this testable at all, `migrate_legacy_data()` was split: the body moved
to `migrate_legacy_data_once()` and the `static bool done` once-guard stayed as a
thin wrapper. The guard is process-wide state, so without the split every
scenario after the first would have been a silent no-op — an untested one. The
guard is belt-and-braces rather than load-bearing: a completed migration leaves
nothing behind, and `adopt_file()` never overwrites, so a repeat run is a no-op
regardless.

**A caveat about the harness, recorded because it nearly cost real data.**
`legacy_appdata_dir()` is destructive by design: it *moves* files out of
`%APPDATA%`. The first version of the harness redirected `APPDATA` with
`SetEnvironmentVariableW`, which edits the Win32 environment block but not the
CRT copy that `_dupenv_s` reads — so the redirect silently did nothing and the
migration ran against the real user profile, moving 23 real files out of it. The
harness now redirects with `_wputenv_s`, aborts if `_dupenv_s` does not report
the sandbox, and asserts at exit that the real profile was never used as a
source. The lesson generalises past this harness: **anything that reads process
state the migration depends on must be redirected at the layer the code actually
reads, and a test of a destructive-by-design function needs an explicit
proof-it-did-not-escape check rather than a working assumption.**

---

## 17. Precedence: the embedded assets are the SOURCE, not a peer of disk

Raised in review, and it is the right question to ask of §16 — the mechanism was
fixed, but *why did a broken embedded path look like a working mod?* Because
precedence let disk win, silently.

**What the precedence actually was.** `find_maps_directory()` returns
`active_maps_directory()` if it is set, and `ensure_embedded_maps_available()`
sets it — but only via `if (!written) return;`. So in the happy path the embedded
unpack did win outright and no disk directory was searched. Embedded-first was
already true. What was wrong was that:

1. **"Embedded first" was an accident, not a model.** It depended on that one
   early return leaving a string empty. Nothing represented "the embedded assets
   are unavailable" as a fact anything could ask about, so when the unpack failed
   the mod became disk-only with no state change and no decision point.
2. **The failure was reported per-file.** 22 warnings for one cause reads as
   background noise, and noise is what let it survive.
3. **`ta\maps` had two owners.** The post-build step deployed `assets\maps\*`
   there, *and* the runtime unpacked RCDATA into the same directory with `trunc`
   on every run. The bytes are identical, so nothing on disk could distinguish
   which mechanism served a file. The deployed copy was in fact doing all the
   work the whole time, which is the mechanical reason the RCDATA defect was
   invisible rather than merely quiet.

**Changed:**

- `embedded_assets_available()` is now a consulted fact, set on every exit path of
  the unpack — success, total failure, and the two "nowhere to put it" cases
  (no writable data directory, and `create_directories` failing). Each has its own
  message, because they have different causes and different remedies.
- Per-payload detail dropped from `WARN` to `DEBUG`. One cause, one report.
- `Minimap scan:` now carries `embedded=yes|no`, so the precedence is visible in a
  single line instead of having to be inferred from a directory path.
- The post-build copy of `assets\maps` is **removed**. `ta\maps` is now
  unambiguously the embedded cache, regenerated from the binary every run.

**A partial unpack still counts as available** and keeps the embedded directory.
Only a total failure degrades to disk. Eleven of twelve maps from RCDATA is a
better state than twelve from disk, and silently discarding a mostly-successful
unpack would reintroduce the same class of quiet degradation.

*(Sections 14–18 are appended out of numeric order; each was written after the
ones above it, and they are grouped here as the "response to field reports"
cluster: 14 dashboard layout · 15 slider sweep · 16 the RCDATA defect · 17 the
precedence fix that followed from it · 18 the chams bundle.)*

**What deliberately did NOT change:** `mapsDir=` in `launcher.cfg` still outranks
everything. It is an explicit user override, and an override that loses to a
built-in default is not an override — flipping that order would silently break
the documented knob. Embedded beats *ambient* disk; it does not beat a *stated*
preference. That distinction is now written down at the call site, since it is the
thing most likely to be "tidied up" incorrectly later.

---

## 18. The chams bundle was the last holdout on the pre-3.2 layout

Field report: a crash on `Loading Asset Bundle`. The log's last line was always
that one, and the bundle turned out to be a casualty of §11.4 rather than the
cause of the crash.

**What the file actually is.** `assets/asset_bundles.h` embeds the chams
`AssetBundle` as an 18,806-byte array. Unity's `LoadFromFileAsync` takes a
**path**, not a buffer, so `start_load()` writes the array to a real file, hands
over the path, and `check_progress()` deletes it once the load completes. It is a
**transient staging file**, not user data — it is rewritten and removed on every
load cycle.

**It was the only piece of mod data still on the pre-3.2 layout.** Everything
else went to `ta/`; this built its path by hand from `_dupenv_s("APPDATA")` in
two places that had to be kept in sync, neither of which consulted
`module_paths`. That is the inconsistency worth naming: the layout migration
covered the *data* directories and the config file, and this one transient file
was missed because it is not data anyone thinks of as persistent.

**The bug it caused.** `data_migration`'s step 1 sweeps the legacy folder and
treats any unrecognised file as a user **config** — that heuristic is required,
because configs are user-renamable and a whitelist would strand real settings.
`tarkovutils` was therefore filed under `ta\configs\`:

```
migrate: C:\Users\Xeon\AppData\Roaming\TarkovAddons\tarkovutils
      -> C:\Battlestate Games\BsgLauncher\ta\configs\tarkovutils
```

An 18 KB binary sitting among the user's settings files. **This is a direct
consequence of the heuristic in §11.4 working as designed**, which is the point
worth recording: any mod-owned file that appears in `%APPDATA%` and is not in
`ta/` is a candidate for being mistaken for a config.

**Fixed in four parts:**

1. **New home.** `module_paths::chams_bundle_path()` returns
   `ta\chams\tarkovutils`, creating the directory on demand. `start_load()` and
   `check_progress()` both use it, so the two sites can no longer drift — deriving
   the path twice from `%APPDATA%` is precisely how they did.
2. **Migration no longer sweeps it.** `is_legacy_appdata_data_file()` excludes
   `tarkovutils`, alongside `tarkov_prices.json`. Note this is the *opposite*
   trade-off to the `ta/` predicate, deliberately: the legacy folder is a known,
   fixed, mod-owned directory, so everything in it can be enumerated and a
   whitelist is safe there. `ta/` cannot be, because of user-renamed configs.
3. **Existing debris is discarded, not migrated.** Step 2b deletes a leftover
   `tarkovutils` from the legacy folder. Moving it would be pointless: it is
   18 KB of the same embedded bytes every time, rewritten and deleted by the next
   load cycle. Deleting load debris is the honest treatment, and it means a
   crashed load leaves nothing behind at all.
4. **Null-safety in the load path, which is what the crash actually was.**
   `start_load()` called `load_from_file(...)` without checking it — and
   `il2utils::get_method` returns **null** when a method cannot be resolved,
   which happens whenever a game update renames or re-signatures it. That is a
   call through a null function pointer inside `hk_tarkov_application_update`:
   an immediate access violation with nothing logged, which is exactly the
   signature observed (no `Progress:` line ever appeared, meaning the first
   `check_progress` never returned). `get_assetBundle` returning null was worse —
   it logged "Loaded Asset Bundle" and reported **success** with no bundle, after
   which every consumer treated a null bundle as valid.

   Every failure path now logs `chams: ...` with its cause, removes the staged
   file, and leaves chams off **without** claiming success.

5. **Retry backoff.** A null return leaves the cycle state "not started", so the
   next frame retried — a per-frame error log and a per-frame 18 KB write for as
   long as the failure lasted. `hk_tarkov_application_update` now backs off 5 s
   between failed attempts and says once when it retries. The three call sites
   that restart a load also disarm the watchdog when the restart itself fails,
   which previously would have left it armed against a bundle that will never
   exist.

**Validation: 46/46**, the migration harness extended from 32 to 46 with two
scenarios. They assert the bundle is not filed under `configs/`, that the real
config is still migrated (so the fix is not over-broad), that the exclusion
predicate is exact for `tarkovutils` / `legit_sel` / a renamed config, that the
debris is discarded rather than moved, and that the new path is under the
deployment and `ta/` and shares no prefix with the **unredirected** Win32
`%APPDATA%`. That last one needed a new accessor: the harness redirects the CRT
copy of `APPDATA` at the sandbox, and the sandbox itself lives under
`TEMP\AppData\Local\Temp`, so a substring test for "AppData" can never pass.
`real_appdata_root()` reads the Win32 block, which the tests do not touch.

`TarkovAddons.sln` `Prod|x64`: 0 errors, no warnings in any file touched here.

**Not fixed here:** the underlying reason the game's `LoadFromFileAsync` stopped
resolving. That is an offsets/pattern problem, not a cleanup one, and the new
diagnostics are what will identify it — the error line names the resolution
failure directly instead of the process dying on the next line.

---

## 16. The RCDATA mechanism has never actually worked — masked by on-disk copies


Field report: 22 × `Built-in minimap asset unavailable (RCDATA 1200..1221)`.

**The minimap was never the problem.** The log line immediately after the
warnings is the answer:

```
Built-in minimap asset unavailable (RCDATA 1221): woods.svg
Minimap scan: configs=12 dir=C:\Battlestate Games\BsgLauncher\ta\maps
```

It found 12 configs on disk and carried on. The RCDATA fallback was silently dead
and the on-disk `ta/maps` copy did the work.

**The real defect.** `pe_resource::rcdata(self_module, ...)` hands `self_module`
straight to `find_rcdata()`, which is `FindResourceW(self_module, ...)`. Both
in-tree callers pass **`nullptr`**:

- `util/i18n.cpp:96` — `rcdata(nullptr, &embedded_locale_bytes, ...)`
- `module/minimap.h:550` — `rcdata(nullptr, &embedded_map_resource_bytes, ...)`

`FindResourceW(NULL, ...)` searches the **host executable** — `EscapeFromTarkov.exe`
— so that fallback could never find the mod's own payloads. `gui/menu/menu.cpp`
already gets this right: it resolves a real `HMODULE` with
`GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS, ...)`, precisely
because "some loaders pass the host module to DllMain, which makes FindResource
search the game executable". Those two consumers therefore had a fallback aimed
at the wrong module, and only a working manual walk could rescue them.

**Why nothing ever surfaced it.** Every consumer has an on-disk fallback and the
deployment supplies all of them: `ta\lang\*.json` (migrated there on first run),
`ta\TarkovAddons Reloaded Background.png`, and `ta\maps\*`. RCDATA is documented
as the mechanism that makes a bare single-DLL drop work, and §10.6 even *removed*
the lang copy from the post-build on the strength of that claim. The claim was
false; the copies had been propping it up. **The same logs show i18n reporting
`override: ...\ta\lang`** — so the locales were coming from disk too, and RCDATA
was failing for those as well. Nobody noticed because the failure was invisible
in every consumer.

**Fixed** in `pe_resource.h`, in three parts:

1. `image_base_from()` resolves the image base two ways — `GetModuleHandleExW`
   (authoritative, and the only one that survives a loader which mapped the image
   as several separate allocations) and `VirtualQuery().AllocationBase` (works when
   the module is not in the PEB lists at all). Each candidate is validated against
   its PE headers before being accepted, so a source that cannot answer is skipped
   rather than trusted.
2. `rcdata()` now resolves `self_module` from the code address when it is null,
   instead of letting `FindResourceW` assume the host.
3. `looks_like_pe_image()` is guarded by a local `is_readable()`. This is not
   defensive padding — the new test **crashed the probe with an access violation**
   because a candidate base derived from `VirtualQuery` can be the first page of a
   thread stack, which is a guard page, and dereferencing `IMAGE_DOS_HEADER` there
   faults. The original code carried the same latent hazard.

**Validated by execution: 15/15.** A harness maps the real built DLL the way a
manual mapper would, then drives the actual header against it:

- 101, five sampled map ids and three locale ids all resolve through the walk;
- the returned payloads are **byte-identical** to the source files for
  `bigmap.json`, `shoreline.json`, `shoreline.svg` and `en.json`;
- `find_rcdata(nullptr, 1200)` returns **null** — direct proof the old fallback was
  aimed at the host exe and could never succeed;
- `rcdata(nullptr, <our image>, 1200)` returns the payload — the fix works;
- an undeclared id returns null and zeroes the size;
- a stack address is rejected as an image base, without crashing.

**The lesson.** The audit verified this mechanism by asserting the RCDATA entries
were *present in the built DLL* — they were — and that the walk matched
`FindResourceW` on a synthetic image — it did. Both claims were true and neither
could have caught this, because the data was present, the walk was correct, and
the bug lived in the argument deciding **which module** to ask. Presence plus
correctness is not reachability.

---

## 14. Raid Dashboard column layout — Debug Log moved left

The Raid Dashboard split fired on the **first** card, so the layout was:

```
left : Raid Dashboard
right: Favorites, Debug Log, Configs, Hotkeys
```

One small card alone on the left against four on the right, which reads as an
empty column. The boundary now sits on the Debug Log card instead:

```
left : Raid Dashboard, Favorites, Debug Log
right: Configs, Hotkeys
```

**Side effect, flagged rather than done silently:** moving the boundary past
Debug Log also pulls **Favorites** onto the left, because it is drawn before
Debug Log and a column switch can only ever fall *after* a card. The
alternative — reordering module registration so Debug Log precedes Favorites —
is a larger change to `ModuleManager` for no gain, and the resulting grouping is
the balanced one anyway.

Two details a naive edit gets wrong:

1. **The Debug Log card is conditional.** It only draws when
   `RaidDashboardModule::show_debug_log` is on, and the loop `return`s early when
   it is off. Keying the split on that card alone would mean the split *never
   happens* with the toggle off — Configs and the hotkey panel would both land in
   column 1, and the unconditional `BeginChild("##col2")` further down would open
   a second child with a duplicate id. So the hidden-card branch now performs the
   split itself. The invariant to hold is that both paths — toggle on and toggle
   off — switch exactly once.
2. **The 50%-height fallback would preempt the explicit boundary.** It is
   evaluated after *every* card, so a tall Raid Dashboard card would trip it
   immediately and push everything right again — the same bug the Profile page
   already documents for `keep_profile_left`. Hence `keep_dashboard_left`,
   covering the whole run of left-column cards rather than just the one the split
   keys on.

The switch is factored into a `split_to_second_column()` lambda since it is now
reached from two places. It is `[[maybe_unused]]` because the Credits tab draws
its own cards and never switches.

Verified: `TarkovAddons.sln` `Prod|x64` rebuilds with 0 errors, and the migration
(32/32) and parser (19/19) harnesses are unaffected. The layout itself is
ImGui-dependent and was reasoned about rather than executed.

---

## 15. Slider consolidation — 33 plain sliders converted, and why it was not safe yet

`IntSliderEditableValue` / `FloatSliderEditableValue` add a typed input box beside
the track. The codebase used them in 24 places (13 of them in ESP) and the plain
variants in 33, with no pattern to it — `MinimapModule` alone had 14 plain. The
audit trail suggests this is drift rather than intent: the editable type was added
and applied to ESP first (commits `1431bbf9` "add floatsliderEditablevalue",
`fca5740f` "use slider+edit on espmodule") and never propagated.

**The blocker, and the actual answer to "why not use them everywhere".** The
editable variants were not equivalent to the plain ones, because their typed box
was unclamped:

| | plain | editable, before |
|---|---|---|
| drag | bounded to `[min, max]` by construction (`slider_core` clamps `t` to 0..1) | same |
| typed entry | not possible | **int: low bound only. float: no clamp at all** |

So the text box was a hole straight past the slider's range: type `1e9` or `-5`
into a 0..1 float slider and it was accepted, drawn with the handle pinned at an
end, and **written to the config verbatim**. The plain type cannot be put in that
state. Fixing `slider_float_editable` to clamp to `[mn, mx]` and
`slider_int_editable` to clamp both ends is what makes the conversion safe; until
then "wherever we can" would have meant "wherever we can widen the config's value
range by hand".

**Then a second gap, found only by building.** The first pass converted
`MinimapModule`, and the build failed with 17 × `C2039: set_value is not a member
of FloatSliderEditableValue`. `FloatSliderValue` has a clamping `set_value`;
`FloatSliderEditableValue` did not. Converting a type to a *strict subset* of its
replacement is not a refactor.

The consequence is worth recording: one of those 17 was
`EspModule.h:2231` — `minimap_module_self->radar_range->set_value(...)` — a call
from the **frozen** ESP file into a Minimap value. The freeze protects ESP from
being edited, not from being *broken by* someone else, and this is exactly the
cross-module coupling that a "mechanical" sweep walks straight into.
`set_value` (clamped, same as the plain type) is now on
`FloatSliderEditableValue`, making it a true drop-in. `IntSliderEditableValue`
already matched `IntSliderValue` and was left alone.

**Converted: 33** across `MinimapModule` (14), `PlayerModule` (6), `ConfigModule`
(5), `AmmoHudModule` (3), `WorldModule` (3), `MapEditorModule` (1),
`WatermarkModule` (1). `FloatSliderEditableValue` 21 → 39,
`IntSliderEditableValue` 3 → 18. Two duplicate includes were introduced by the
sweep (`PlayerModule`, `AimbotModule` already included the editable header) and
removed; `WatermarkModule` was relying on a transitive include and now has a real
one.

**Not touched: `EspModule.h`.** It is frozen, and its one remaining plain slider
is `loot_min_value_itm` — an `IntSliderValue` spanning **0 to 500000**, which is
precisely the case a text box exists for. Flagged for the optics owner rather than
converted.

**Config compatibility: unaffected.** `to_string()` is identical in both types
and `get_config_key()` is `name + "##" + module` with no reference to the class,
so no key moves and no stored value needs reformatting. `FloatSliderValue` now
has zero instantiations project-wide and is referenced by no header outside its
own; left on disk rather than deleted, since `IntSliderValue` still has one live
use in ESP.

**The lesson, stated because it nearly shipped:** I checked constructor
signatures and `to_string` and called the types interchangeable. They were not —
`set_value` existed on only one side. A drop-in replacement claim needs the *whole*
public surface compared, not the constructor and one serialiser, especially when
the consumer is a file you are not allowed to edit.

---


Reported as "the configs aren't loaded from the new location" and "the Save/Load
buttons lost their captions". **Neither was caused by the `ta/configs/` move**,
and both predate it. The log and the on-disk state are what settled it: the
deployed DLL is byte-identical to the local Prod build, `ta\configs\legit_sel`
exists, and the log contains `Loading Config legit_sel` on every start — so the
new location works. What was actually broken was the loading of it.

### 13.1 Configs "not loading" — a duplicate config key threw out of the loader

`ConfigModule` registered **two** `ConfigValue`s under the same name:

```cpp
MenuSectionValue*   section_language_ = conf(new MenuSectionValue  ("menu_language_sec"));
LanguageSelectValue* menu_language_    = conf(new LanguageSelectValue(0, "menu_language_sec"));
```

`get_config_key()` is `name + "##" + module`, so both produced the identical key
`menu_language_sec##Configs`, and the saved file contains it **twice**. That
matters because `MenuSectionValue::get()` returns `{}`: the section's record
wrote an *empty* value which clobbered the real language index in the load map
(last write wins). `load_config()` then called `LanguageSelectValue::set("")`,
which is `std::stoi("")` — and that **throws `std::invalid_argument`**.

Nothing above the apply loop catches. The exception unwound out of
`load_config()` entirely, so every value registered after the language selector
kept its default and `hotkeys::load()` never ran. One colliding key, and the
whole file was abandoned mid-way — which is exactly what "the config isn't
loading" looks like from the outside.

Fixed three ways, because any one alone leaves the trap armed:

1. **The collision is gone.** The `MenuSectionValue` is renamed to
   `menu_language_sec_hdr`. It draws nothing (`draw()` is an empty body kept
   "for config compatibility"), so its name is only ever a config key and
   renaming it is free. Note the *section* was renamed rather than the selector,
   which means a config written by an older build now restores the saved
   language instead of having it overwritten by an empty value.
2. **Every parse is total.** `config_parse::to_int` / `to_float` in
   `ConfigValue.h`, built on `std::from_chars`. `SelectValue`,
   `LanguageSelectValue`, `FloatSliderValue`, `FloatSliderEditableValue`,
   `IntSliderValue`, `IntSliderEditableValue` and `IntTextboxValue` now fall back
   to their own default on a malformed field instead of throwing, and the five
   now-dead `from_string` helpers were deleted so they cannot be reintroduced as
   a trap. `from_chars` also rejects `"3abc"` and `"  5"`, which `std::stoi`
   would have silently accepted as `3` and `5`.
3. **The loop is contained.** The apply lambda in `load_config()` wraps each
   value in a `try`/`catch` and logs which key was rejected. This is the part
   that generalises: a malformed value is a one-setting problem, and it must not
   be able to abandon the remaining ~1500.

`ColorpickerValue` had the same defect with more edges: four **unchecked**
`elements[]` indexings *and* four `stof` calls, so a truncated colour threw
`std::out_of_range` before it ever reached the parse failures. It now bounds the
element count and parses component-wise.

**19/19 assertions executed** covering the new helpers, including the two inputs
that made `std::stoi` throw, and confirming `from_chars` is stricter than
`stoi` where `stoi` was silently lenient.

### 13.2 Button captions — a use-after-free, from the in-flight work

`ActionRowValue` (the Save and Load buttons are both `ActionRowValue`s):

```cpp
const char* label = !button_text_.empty() ? button_text_.c_str()
                                          : this->get_imgui_title().c_str();
if (ImGui::Button(label, ...))
```

`get_imgui_title()` returns a `std::string` **by value**. The conditional
operator yields a prvalue `const char*`, so the temporary is destroyed at the
end of that *declaration* — `label` then points into freed memory and
`ImGui::Button` renders from it. Fixed by holding the string in a named local.

Worth noting the pre-existing form
`ImGui::Button(this->get_imgui_title().c_str(), ...)` was **correct**: there the
temporary lives to the end of the full-expression. Splitting it across two
statements is what introduced the bug, which is a fairly cheap trap.

### 13.3 A latent collision left in place

`InfoDrawValue` defaults its id to `"Info"`, so any two constructed without an
explicit id share the key `Info##Configs`. Both current instances write empty
values and `set()` is inert, so nothing throws today — but it is the same shape
of bug and the next value-bearing `InfoDrawValue` inherits it. Not changed here
because there is no failure to fix and no clear intended id.

---


The previous version of this document implied a single "cleanup sweep". That is
not what the history shows.

| Commit | Message | What it actually contains |
|---|---|---|
| `aebc439c` | "mid-progress" | `always_on_deprecated.h` created; `generated_bindings.h` and `embedded_assets.h` deleted |
| `6afa655c` | "mid-progress 2" | `pe_resource.h` created; i18n RCDATA-first rework |
| `38e061a0` | "mid-progress 3" | nothing relevant |
| `9b779eb3` | "v3.2 stable: … cleanup sweep …" | **23 files**, 778 insertions / 125,143 deletions — but the deletions are the *deploy payload*, plus docs and the `ta/` post-build |
| `ac376cf2` | "docs: record the spoofer x86 …" | 3 doc files |

The document's own line-count claims corroborate the split: `always_on.h`
1885 → 1759 happens at `e2d03f45`→`aebc439c`, and `i18n.cpp` → 533 at
`6afa655c`. Neither is `9b779eb3`, which left both files essentially untouched.
(One figure does not reconcile: `i18n.cpp` is quoted as 609 lines before the
change, and no commit boundary has 609 — it is 663 at `e2d03f45` and 674 at
`aebc439c`. The 533 endpoint is right.)

Two specific overstatements, both now corrected above:

- **"§2.2 removed 10 functions"** — not true. Six were removed; three rows
  (`estimate_ricochet_chance`, `load_raster_layers`, `ensure_active_map`) were
  never candidates, being the deliberate keeps from the §9 retraction; and
  `set_static_field` was still defined. The count also spans two subsections and
  does not match either.
- **"§6 step 5 (§2.2, §2.4) — done"** — not true. All twelve `unity.h` and
  `eft_api.h` helpers were still present, each with exactly one occurrence, its
  own definition.

This is the same failure mode §9 records, one level up: §9 is about asserting
"X is dead" from a file-scoped grep, and this is about asserting "X is done"
without re-reading the tree. The cheap discipline is the same — when a document
claims work landed, check the tree or the log, not the prose.

---

## 19. The Always-On transit hooks — an ISIL reachability audit

Branch `ISIL_115147510`. Question put to this pass: *what does the game's
Transit code actually do, and are all 24 hooks in `module/always_on.h` needed —
are any unreachable because another hook shadows them?*

**Short answer: no code was archived.** One real bug was found and fixed
(§19.6). Everything else is written down as a **candidate list awaiting
station logs**, because the evidence method turned out to be unsound for
reachability (§19.1). Read §19.1 before acting on any row of §19.5.

### 19.1 RETRACTION — `hk_try_get_location` is not "the wrong method"

I reported `hk_try_get_location` as hooking the wrong target and recommended
archiving it, on the grounds that `ClientTransitController.TryGetLocation` has
exactly one call site in the ISIL dump and that site is
`ClientTransitController.ProtectedLocation` — not transit destination
resolution. **That was wrong**, and the user had already seen the hook firing on
a real station.

The `||`-style local reasoning was fine; the *call-site inventory* was not.
`ProtectedLocation` (`ClientTransitController.txt:2420`) reads
`pointsById[pointId]` → a `TransitPoint` (ISIL 52), takes `point.parameters`
(ISIL 64) and calls `TryGetLocation(v64.target, &v62)` (ISIL 80). The
`location` out-parameter **is `TransitPoint.parameters.target` — the transit
destination**. So `hk_try_get_location`'s `configure_pve_location(*location)`
configures exactly the right object, and the hook's original comment
("Called when resolving a transit destination") was substantially correct. The
method resolves the destination from a *different caller* than
`LocalTransitController.Transit` does, which is not the same as being the wrong
method. Also worth recording: the method is declared on
`EFT.ClientTransitController`, the middle class of
`LocalTransitController : ClientTransitController : TransitController`.

One sub-claim does survive: `get_raid_settings(instance)` inside that hook is a
no-op, because neither `ClientTransitController` nor `LocalTransitController`
carries a `_raidSettings` field (only `LocalTransitController._localRaidSettings`).
`always_on.h` already documents the same trap for `hk_transit`.

### 19.2 The ISIL pass cannot establish reachability — and why

The dump under `TarkovAddons/ISIL-references/IsilDump/` is per-method
disassembly plus a reconstructed instruction listing. It is excellent for
**local control flow** and useless as a **call graph**, for three separate
reasons, each of which bit during this pass:

1. **Unnamed dispatch thunks.** A call through an interface slot or a virtual
   thunk has no symbol. `LocalRaidStarted` is a perfect example: grepping the
   tree for the name finds **four declarations and zero call sites**, which reads
   as "never called". It is in fact called from
   `TarkovApplication+<LocalGameCreate>d__229` as a two-instruction pair —
   `Call 180112600, …, typeof(EFT.IEftSession), 62` then
   `IndirectCall [v4327 @ r8_v61]` (ISIL 913/919) — i.e. `IEftSession` slot 62.
   An agent reported `LocalGameCreate` as having "zero call sites" on the same
   reasoning; that is the same grep artefact, not a finding.
2. **Delegate invocation is invisible.** `TasksExtensions.HandleFinishedTask` has
   **2** direct calls in the whole dump, but it is really invoked through a
   delegate cached once in `.cctor` (`_handleFinishedTask = HandleFinishedTask`,
   `TasksExtensions.txt:2298`) and registered via `Task.ContinueWith`. Counting
   call sites would have understated it enormously — and would equally have
   overstated `HandleExceptions` differently, since its real invocation count is
   809 static sites **plus** every delegate-registered use.
3. **Reflection by string name**, and lambdas whose only reference is a
   `methodof(...)` load feeding a `Func<>`/`Action` construction.

So every "N call sites" figure in this document is a **lower bound**, and
"zero call sites" means "no *statically named* call site". The corollary matters
for §19.5: the only trustworthy reachability evidence available here is
(a) local control flow inside one method, (b) the hook body's own side effects,
and (c) **the station logs**, which outrank all of it.


**Correction — the raw `Disassembly:` sections are not truncated.** While
resolving §19.6c I claimed otherwise and built a "9,773 files truncated"
figure on it. That figure was an artefact of comparing raw instruction lines
against *ISIL* instruction indices, and **a median 76.5% of ISIL lines are
`Nop`**. Corrected measurement over all 28,830 methods carrying both sections
and at least 200 ISIL instructions:

| metric | value |
|---|---|
| median Nop share of the ISIL listing | 76.5% |
| median raw lines / non-Nop ISIL instructions | 2.06 |
| methods where raw >= 95% of non-Nop ISIL | **28,307 (98.19%)** |

Raw is ~2x non-Nop ISIL because the reconstruction collapses multi-instruction
sequences into one line. So the sections are effectively complete, and the
`Disassembly:` half of these files is a first-class evidence source that I had
written off. §19.6c is entirely built on it.

What this changes, beyond §19.6c:

* **Stack-passed arguments are recoverable.** The ISIL annotator drops them and
  then labels the surviving register by whatever type it guessed — that is where
  `v1415 @ stack_-148 (System.Int32)` annotating a `LocalRaidSettings` parameter
  came from. Reading the raw `mov`s fixes the ABI slot arithmetic by hand
  (`rsp = entry_rsp - 0x1F8`; param 18 lands at `[rsp+88h]`).
* **Hook arities and the branch-direction caveat in §19.7 are re-checkable.**
  §19.7 rests on an inferred branch direction because `@bNNN` targets are never
  resolved — but the underlying `cmp`/`jcc` pairs are all present in the raw
  sections, so the direction is confirmable rather than inferred. Not yet done;
  it would upgrade §19.7's caveat from "not LOCAL-CF-grade" to settled.
* **"Zero call sites" stays a lower bound.** None of this adds call-graph edges.
  The §19.2 limits are about dispatch, not about listing fidelity.

The decoding procedure itself — counting the prologue to get `rsp`, the
`[rsp + 0x20 + (N-5)*8]` slot formula, the extra hidden `Il2CppMethodInfo*`
parameter, the Nop share, and the ISIL-vs-raw ordering trap — is written up
once in `WORKFLOW.md` §"Reading `ISIL-references/IsilDump` without being misled",
so it does not have to be re-derived from these two sections.
This extends the §0 "Known limits of pass 2" list, which already covered
function pointers, virtual bases and `#ifdef`. The ISIL pass is a *third*
method with the same weakness plus two more.

### 19.3 What Transit actually does

`EFT.LocalTransitController.Transit(TransitPoint, int, string,
Dictionary<string,ProfileKey>, Player)` → `Task`
(`LocalTransitController.txt:2349`). It is **synchronous** — no state machine,
no `await` — returns `Task.CompletedTask`, and makes **no network call of any
kind**. In order:

| ISIL | Action |
|---|---|
| 60 | reads `point.parameters` (`JsonType.LocationSettings+Location+TransitParameters`) |
| 91 | `TarkovApplication.Exist` |
| 119 | **`TarkovApplication.TryGetLocationById(v62.location, &v104)`** |
| 144 | `Player.get_Side` |
| 176 | `CheckEqual v104.ForceOnlineRaidInPVE, 0` — the online/offline decision |
| 187 | `v104.SavageForceOnlineRaidInPVE` |
| 191/223 | `this._localRaidSettings`, `ELocalMode` |
| 245/246 | `TarkovApplication.<TransitionStatus>k__BackingField = 1` |
| 378 | `this.alreadyTransits.Add(profileId, locationTransit)` |

`ForceOfflineRaidInPVE` is **never read** — zero occurrences in the file.
There is no `TransitPoint.Transit` call, no coroutine, no `Task.Run`; the single
outward call is an unresolved `AbstractGame` vtable slot (`+398`).

The caller chain is a **virtual dispatch**: `TransitPoint+<Transit>d__38` ISIL
562/576 calls through `<Controller>k__BackingField`, typed `EFT.TransitController`
— i.e. the 5-argument register marshalling proves it, but the dump emits no
symbol. Upstream: `TransitPoint.Update` → `UpdateGroupTimers d__39` ISIL 282/378
→ `TransitPoint.Transit`, gated on `parameters != null &&
parameters._groupSize != null` (ISIL 263/266/278/279). The controller instance
is created in `BaseLocalGame<>.Run d__61` ISIL 1322/1331 and published to
`gameWorld.<TransitController>k__BackingField` at ISIL 1343.

`TarkovApplication.TryGetLocationById` has five call sites, all real:
`LocalTransitController.Transit` ISIL 119; `Run d__201` ISIL 1821 and 2078;
`ShowTransitSaveWaitScreen d__239` ISIL 134; `TransitAbuseUtil.CanUsePunishFlag`
ISIL 141.

### 19.4 Evidence classes used in §19.5

- **LOCAL-CF** — proven from control flow *inside a single method*. Survives
  §19.2. Highest confidence here.
- **BODY** — proven by reading the hook body: it logs and calls the original, so
  it cannot change behaviour. Survives §19.2.
- **CALLSITE** — rests on a call-site count. **Not proof.** Needs a station log.

### 19.5 The 24 hooks, re-scoped

Nothing here is archived. The "Verdict" column is what the evidence *currently*
supports, not a decision.

| # | Target (`always_on.h` line) | Class | What the evidence says | Verdict |
|---|---|---|---|---|
| 1 | `MatchMakerSelectionLocationScreen.DisplayLocation` (1644) | CALLSITE | A `Func<Location,bool>` predicate inside a LINQ filter in `ShowInternal(RaidSettings)`, not a draw entry point. Menu-only. But its job — unlock Labyrinth/Icebreaker, hide Terminal — is *inherently* menu-scoped, and it demonstrably fires. | **Keep** |
| 2 | `ClientTransitController.TryGetLocation` (1653) | — | **Retracted, see §19.1.** Fires; resolves `parameters.target`. | **Keep** |
| 3 | `OnReadyToStartMatchingAsync` (1659) | BODY | Only forces `RaidMode = 1`, which `modify_raid_settings` already does. | Redundant, keep |
| 4 | `LocalGameCreate` (1662) | LOCAL-CF | Raid-start guard; the guard is the reason this module works. | **Keep** |
| 5 | `LocalGameMatching` (1665) | LOCAL-CF | As above. | **Keep** |
| 6 | `StartOnlineTransitMatching` (1668) | LOCAL-CF + CALLSITE | `Run d__201` ISIL 2161/2173: `if (IsLocalTransitHop()) goto @b320`, and the `StartOnlineTransitMatching()` call is at ISIL 2204, *past* the branch. Hook 9 forces that predicate true, so `Run` cannot reach it. The local half is solid; "no other dispatch reaches it" is CALLSITE. **Note it swallows the original** — see the risk note below. | Fragile, keep |
| 7 | `Run` (1674→`hk_run_move_next`) | BODY | Carries `run_keep_profile_status_free`, the `profileStatus.status → Free(0)` patch. Load-bearing. | **Keep, essential** |
| 8 | `TryGetLocationById` (1674) | CALLSITE | Five real call sites (§19.3). The real destination-resolution primitive. | **Keep** |
| 9 | `IsLocalTransitHop` (1677) | LOCAL-CF | Returns `true`, never calls the original. Gates hook 6. | **Keep** |
| 10 | `AwaitGameOverSaveStatusAsync` (1683) | BODY | Log-only. | Diagnostics |
| 11 | `ShowTransitSaveWaitScreen` (1686) | BODY | Log-only. Reached only via `OnGameEnd → ComebackToMainMenu(0,1) → ShowTransitSaveWaitScreen`. | Diagnostics |
| 12 | `OnGameEnd` (1689) | BODY | Log-only. | Diagnostics |
| 13 | `ComebackToMainMenu` (1692) | BODY | Log-only. | Diagnostics |
| 14 | `PrepareGameJob` (1695) | BODY + CALLSITE | Log-only. One call site (`PrepareGame d__151` ISIL 70), and `PrepareGame` is reached from `ComebackToMainMenu`, `ExecuteCharacterSelection` and two `RecreateBackend*` — so it fires on **every** raid start, not just transit. | Diagnostics, hot |
| 15 | `ApplyGameOverSaveStatus` (1698) | BODY + CALLSITE | Log-only. Dispatched from `NetworkGameSession.RpcGameOverSaveStatus` ISIL 168 and `NetworkGame<>.GameOverSaveStatus` ISIL 62 — a network receive path, so plausibly never reached in an offline session. "Plausibly", not proven (§19.2). | Diagnostics |
| 16 | `FailGameOverSaveStatus` (1701) | BODY + CALLSITE | Log-only. `NetworkGameSession.OnDisconnect` ISIL 384. Same caveat. | Diagnostics |
| 17 | `HandleExceptions` /1 (1712) | BODY + CALLSITE | Log-only, and a detour on a method with **809** static call sites plus delegate uses. Per-call cost is a detour + an SEH frame + one `get_Exception` that returns null on a healthy task. | Diagnostics, hottest |
| 18 | `HandleExceptions` /2 (1714) | BODY + CALLSITE | Log-only. Four static call sites (`ObjectsFactory_NestedType_Pools` 248, `AbstractAssetsPool\`1` 316 and 878, `RegisterLoadBundlesAndCreatePools_d__33` 1035) — none in the transit chain. | Diagnostics, near-dead |
| 19 | `HandleFinishedTask` /1 (1716) | BODY | Log-only. The completion-side observer, so it is the one that can actually *see* a fault (`IsFaulted` → `LogException`). | Diagnostics, keep if any |
| 20 | `HandleFinishedTask` /2 (1718) | BODY + CALLSITE | Log-only. Two static call sites. | Diagnostics, near-dead |
| 21 | `LocalTransitController.Transit` (1734) | BODY | `setup_target_location` + `setup_local_player_object` + `RaidMode=1`. Load-bearing. | **Keep, essential** |
| 22 | `LocalRaidStarted` (1743) | LOCAL-CF | The guard arming works. Two settings writes were **dead** — fixed, §19.6. | **Keep (fixed)** |
| 23 | `NeedToGoOnlineInPve` (1749) | LOCAL-CF | Returns `false`; sole effect is `RaidMode=Local` + `IsPveOffline=true` in `MatchmakerOperation.Ready`, plus `raid_start_guard_disarm`. | **Keep** |
| 24 | `NeedToGoOfflineInPve` (1752) | LOCAL-CF | Best candidate for "unreachable due to another hook". §19.7. | Candidate |

**Risk note on hook 6.** It does not call `o_start_online_transit_matching` at
all — it logs and returns. It is safe *only* because hook 9 makes `Run` branch
away before reaching it. If any dispatch reaches it that the ISIL cannot name,
the mod silently eats a live `StartOnlineTransitMatching`. The safety net is
load-bearing in the opposite direction from how it reads: it is a
park-the-client guard that is only unreachable because of another hook. Worth
converting to "log loudly, then still call the original" so a future
`IsLocalTransitHop` change cannot turn it into a hang.

**Coupling to remember before touching hooks 10–20.** `g_last_ta` is written by
**nine** of them (lines 639, 976, 1306, 1410, 1442, 1471, 1509, 1550, 1569,
1596), and the two hotkey actions `debug.dump_ta_state` /
`debug.force_save_status` (1724, 1727) read it. Hooks 7 and 8 also write it, so
the hotkeys survive archiving the rest — but only just.

### 19.6 Fixed here: `hk_local_raid_started` was doing nothing

This one is **LOCAL-CF** and needs no station log. In
`TarkovApplication+<LocalGameCreate>d__229`, the sole caller of
`LocalRaidStarted` (IEftSession slot 62, ISIL 913/919):

```
 770/774  new LocalRaidSettings()          location, timeVariant, mode, playerSide,
 799-844                                   transitionType filled from _raidSettings
 845       _localRaidSettings = the new object
 913/919   LocalRaidStarted(_localRaidSettings)          <-- the hook ran HERE
 933/948   GetAwaiter + get_IsCompleted; ConditionalJump SUSPENDS if not complete
 951       GetResult() -> v187 (JsonType.LocalSettings), the RPC response
  991      _localRaidSettings.serverId         = v187.serverId
 1007      _localRaidSettings.selectedLocation = v187.locationLoot
 1023      _localRaidSettings.transition       = v187.transitionSettings
```

`LocalRaidStarted` is the **request**, not the response. Both fields were still
`null` when the hook body ran, so:

- `configure_pve_location(settings.get_field("selectedLocation"))` early-returned
  on a null location;
- the `keep_original_server_id` write of `""` was overwritten 91 ISIL later by
  `v187.serverId` — i.e. **the "blank the server id" toggle did nothing**;
- and the comment *"LocalRaidStarted is where EFT turns LocalRaidSettings into
  the actual destination request. Re-assert the mode and configure the selected
  location immediately"* described an effect the code never had.

`LocalRaidSettings` is a plain sealed class with public fields, no properties
(`dump.cs:257046`): `serverId` 0x10, `location` 0x18, `timeVariant` 0x20, `mode`
0x24, `playerSide` 0x28, `transitionType` 0x2C, `transition` 0x30,
`selectedLocation` 0x38. So there is no setter to hook at ISIL 1020 — it is a
raw field `Move`.

**The fix**, in `module/always_on.h`: both statements moved out of
`hk_local_raid_started` into a new `apply_local_raid_settings_after_rpc(sm)`,
called from `hk_local_game_create` *after* `o_local_game_create(sm)`. Note a
plain post-call write would **still be wrong** — the await at ISIL 948 usually
suspends, so the first `MoveNext` returns before `GetResult` has run. The new
helper therefore gates on `selectedLocation != nullptr`, which is only true
after ISIL 1020; `MoveNext` is re-entered on every resumption, so the
resumption that runs `GetResult` is the one that fires it. Both operations are
idempotent (seven fixed bools; one fixed string), so re-running is harmless.

The guard arming stays in `hk_local_raid_started`: it is pure mod state with no
dependency on the settings, and mid-`LocalGameCreate` is the correct moment for
it. `print_instance_info`, `dump_local_raid_settings` and the
`"Loading in at: …"` line also stay — `location` and `mode` *are* already
populated at ISIL 799/816, so that log was honest.

One trap worth writing down, because the first draft of this fix walked into it:
`_localRaidSettings` is declared on **`TarkovApplication`** (`dump.cs:311891`,
offset `0x118`), not on the `<LocalGameCreate>d__229` state machine. The state
machine has no such field, so `il2utils::resolve_field(sm_klass,
"_localRaidSettings")` returns null and the whole helper silently returns on
every resumption — a fix that looks correct and does nothing. The field has to
be resolved against the validated `<>4__this` owner
(`resolve_field(view.owner->klass, …)`, read from `view.owner`), which is the
same shape `hk_run_move_next` already uses for `_raidSettings` at
`always_on.h:1193`. Note there are two different `_localRaidSettings` fields in
the dump — `TarkovApplication`'s at `0x118` and `LocalTransitController`'s
read-only one at `0xB0` (`dump.cs:257847`) — so resolving by name against the
wrong owner would read a valid-looking but permanently-null field.

### 19.6b Every `_localRaidSettings` in the game — there are two, and only one is ever written

Traced exhaustively: **10 accesses across 3 files**, against **2 declarations**.
There is no third one, and in particular **no state machine declares one**.

| Declaring type | Offset | Mutability | Written | Read |
|---|---|---|---|---|
| `EFT.TarkovApplication` (`dump.cs:311891`) | `0x118` | `private`, reassignable | ISIL 845 (`<LocalGameCreate>d__229`), **ISIL 297 (`TryUnloadGame`) → null** | 845, 919, 991, 1007, 1023 — all in the same `MoveNext` |
| `EFT.LocalTransitController` (`dump.cs:257847`) | `0xB0` | `private readonly` | ISIL 128, its own `.ctor` only | ISIL 191, 200, 349 — all in `Transit` |

**The `v53._localRaidSettings` in the state machine is a red herring, and it is
the exact trap described above.** ISIL 108 is `Move v53 @ r14_v1, this.<>4__this`,
so `v53` is a compiler-hoisted copy of the **outer** `TarkovApplication`, not a
state-machine field. Reading the disassembly as "the state machine has a
`_localRaidSettings`" is what produces the impression there are many. There is
one owner and the state machine merely caches a pointer to it.

**The two fields have opposite lifetimes, and this is what makes the fix's gate
sound.** `TarkovApplication`'s is re-created per raid start and explicitly
nulled on unload, so "is it populated?" is a real question at any instant.
`LocalTransitController`'s is `readonly` — set once when the controller is
constructed — so the *reference* is never null after construction. `readonly` on a
reference field is field-level immutability only: the object it points at is the
ordinary mutable `LocalRaidSettings`, and §19.6c traces that object to the same
instance the RPC writes. It is **not** a snapshot.

### 19.6c RETRACTION — the "stale snapshot" claim above was wrong

I wrote that the controller's injected `LocalRaidSettings` was a **pre-RPC
copy** and that it "diverges in exactly the three fields the fix writes". That
was inferred from method boundaries, not read off the argument values, and it
is **false on both counts**. It is withdrawn; §19.8 question 5 goes with it.

**Refuted by ordering.** The controller is built in `Run d__61`, on an
already-constructed game object. The settings reach that object through
`LocalGame.Create`, whose **18th parameter is
`EFT.LocalRaidSettings raidSettings`** — and the call to it (`LocalGameCreate`
`d__229` ISIL 1316) sits **after** the RPC unpack at ISIL 1004/1020/1036 in the
same `MoveNext`. The controller cannot be holding anything but the
post-RPC-populated object.

**Proven at machine level, not inferred.** §19.2 is right that the ISIL listing
is lossy for stack arguments — at ISIL 1331 the 4th ctor argument is annotated
`v1415 @ stack_-148 (System.Int32)`, which is simply wrong. But the
`Disassembly:` section is there, and decoded it settles both ends of the chain:

```
LocalGameCreate d__229        (entry rsp = rax; rsp = rax - 0x1F8)
  614  mov rax,[r14+118h]      ; r14 = the hoisted TarkovApplication (ISIL 108: v53)
  615  mov [rsp+88h],rax       ; [rsp+88h] = param 18 = raidSettings
  ...  params 5..17 land at [rsp+20h]..[rsp+80h], in order
  643  call 0000000181C98180h   ; LocalGame.Create — 19 machine args = 18 + hidden MethodInfo*

BaseLocalGame`1+<Run>d__61     (rcx = state machine; [rsp+150h] = <>4__this)
  647  mov rax,[rbx+0E8h]       ; rbx = the game instance; _raidSettings
  654  mov [rsp+20h],rax        ; [rsp+20h] = param 4 = localRaidSettings
  655  mov r9,r13               ; param 3 = Profile
  656  mov r8,[rsp+70h]         ; param 2 = TransitParameters[]
  657  mov rdx,[rsp+50h]        ; param 1 = TransitGlobalSettings
  658  mov rcx,r12              ; the Newobj'd LocalTransitController
  659  call 0000000182378490h   ; LocalTransitController..ctor  (VA per dump.cs:257852)
  662  mov [r15+38h],r12        ; gameWorld.<TransitController>k__BackingField = it
```

`0x182378490` **is** `LocalTransitController..ctor` (`dump.cs:257852`), so the call
at `Run d__61` L659 is that ctor and not a neighbour. `rbx` is reloaded from
`[rsp+150h]` — the state machine's `<>4__this` — so it is the game instance and
not a temporary.

So: **`TarkovApplication._localRaidSettings` → `LocalGame.Create` param 18 →
game instance `0xE8` → `LocalTransitController` ctor param 4 →
`_localRaidSettings` (`0xB0`). One object, four hops, no copy.**

**`dump.cs` printing `_raidSettings` as `0x0` is a trap worth naming.**
`BaseLocalGame<TPlayerOwner>` is an *open generic* (`dump.cs:328881`), and
Il2CppDumper does not emit field offsets for open generic definitions — hence
the `0x0` placeholder at `dump.cs:328904`. The instantiated layout, which is what
`Run d__61` actually walks, puts it at `0xE8`. Taking `0x0` as the offset would
have suggested the field could not hold a reference at all.

**Field-set disjointness — a second, independent refutation.** Even if the
snapshot *had* been pre-RPC, it could not have mattered to `Transit`:

| | fields written | fields read |
|---|---|---|
| RPC unpack (ISIL 1004/1020/1036) | `serverId`, `selectedLocation`, `transition` | — |
| the §19.6 fix (`always_on.h:981`) | `selectedLocation` (via `configure_pve_location`), `serverId` | — |
| `Transit` (ISIL 191→223, 349→362) | — | **`mode`, `timeVariant`** |

The three sets are **disjoint**. `Transit` reads exactly two fields off that
object — `LocalRaidSettings.mode` (`0x24`, ISIL 223) and `.timeVariant` (`0x20`,
ISIL 362). Its other `.location` reads, at ISIL 119 and 295, are off `v62`, not
off the settings object. And `mode`/`timeVariant` are filled at ISIL 770/774 +
799–844, i.e. **before** the RPC, from `_raidSettings`. No RPC-populated field,
and no field the fix touches, is ever read by `Transit`.

**Effect on the fix: unchanged.** The fix stands on its own footing —
`LocalRaidStarted` is the request, not the response, so the fields were null when
the old hook body ran, and no part of this retraction touches that. Nothing here
widens the fix's reach either, and it would be wrong to claim it does: `Transit`
does not read `selectedLocation` or `serverId`, so the two writes the fix makes
are not fields it consumes. What the same-object identity actually establishes
is the negative result — the controller and `TarkovApplication` can never
disagree about *any* field of this object, including the two `Transit` does read.

**What stays unproven.** That the game instance's `0xE8` is written *by*
`LocalGame.Create`'s param 18 rather than by some other path — neither
`LocalGame.Create` nor `BaseLocalGame<T>.Create` contains a store to `+0xE8h` at
all. It does not matter: there are exactly two `LocalRaidSettings` instances in
the game (§19.6b), the transit one is `readonly` and written only in its own
ctor, and `LocalGame.Create` has exactly one `LocalRaidSettings` parameter.
Whatever else happens, the controller receives the post-RPC object.

One safety note the trace also settles: `TarkovApplication._localRaidSettings`
is nulled by `TryUnloadGame` at ISIL 297, so anything holding the pointer across
an unload reads a dangling field. `apply_local_raid_settings_after_rpc`
re-resolves and re-reads it on every `MoveNext` and null-checks, so it is
already immune to that.

Verified: `tools/verify/check.sh` fingerprint **0 residual error signatures
across 71 translation units**, exit 0. (An earlier reading of 11 was flakiness
from concurrent load on this box, not a regression — the same binary reports 0.)

### 19.7 The one genuine "shadowed by another hook" candidate

`hk_rs_need_to_go_offline_in_pve` (hook 24). In
`EFT.MatchmakerOperation+<Ready>d__43`, whose ISIL is unambiguous here because
every early-out in the region targets the same label:

```
 1130  if (!RaidSettings.get_Local())                       -> @b345 (exit)
 1165  if (!raidSettings.isInTransition)                    -> @b345
 1181  if (session.<slot 6>() != 1)                          -> @b345
 1230  if (<cond> != 1)                                      -> @b345
 1247  r_online  = RaidSettings.NeedToGoOnlineInPve(side)
 1255  v3409     = !r_online
 1258  ConditionalJump @b181, v3409            <-- short-circuits
 1274  r_offline = RaidSettings.NeedToGoOfflineInPve(side)   <-- only if r_online
 1285  if (!r_offline)                                        -> @b345
 1286  @b181: raidSettings.RaidMode = 1
 1311          raidSettings.IsPveOffline = true
```

That is `if (!NeedToGoOnlineInPve(s) || NeedToGoOfflineInPve(s))` — an `||`.
`hk_rs_need_to_go_online_in_pve` returns `false` unconditionally, so the second
operand is never evaluated and hook 24 never fires.

**Caveat, stated because §19.2 demands it:** the `@bNNN` targets are not
resolved anywhere in these dumps, so `@b181`'s direction is inferred from label
ordering plus the `||` shape. That inference is *not* LOCAL-CF-grade. The claim
survives on a second, direction-independent argument: hook 24's **only** possible
effect is the `RaidMode = 1` write at ISIL 1298, and the mod already forces
`RaidMode = 1` in three other places that all run on this path —
`modify_raid_settings` (`always_on.h:558-565`), via `hk_transit` →
`get_raid_settings` (`:737`), and `hk_on_ready_to_start_matching_async`
(`:928-935`), which is the menu-start pipeline `Ready` belongs to. So hook 24 is
redundant whether or not the branch direction is as inferred.

Both `RaidSettings` methods have exactly one call site each, both in `Ready`
d__43, so they are menu-matchmaker-only: no call from `LocalTransitController`,
`ClientTransitController` or `TarkovApplication`. `hk_rs_need_to_go_online_in_pve`
also carries the `raid_start_guard_disarm("fresh PLAY flow (need_to_go_online)")`
side effect, which is **not** redundant and is why hook 23 stays even if the rest
of its body is.

### 19.8 Settle this on the station before archiving anything

The ISIL cannot close §19.5. What would:

1. **Count the hooks that actually fire.** Every one of the 24 logs on entry
   (`hk_transit CALLED`, `hk_try_get_location`, the `[transitdbg]` lines) and
   `hook_method`/`hook_async_method` already log `FAILED` on any resolution
   miss — so the log is a ready-made oracle. Any target absent from a full
   transit session is the archiving candidate. All 24 arities were checked
   against the ISIL signature table and are correct, so a miss would be a
   resolution failure, not a wrong argument count.
2. **Confirm hook 6 never fires** on a station with `IsLocalTransitHop` forced
   true. If it does, something the dump cannot name dispatches it, and the
   swallow must become a pass-through before anything else is touched.
3. **Confirm hooks 15/16 never fire offline**, which is the premise for calling
   them dead. Both are network-receive-path.
4. **Measure hook 17's cost.** `HandleExceptions` is the one candidate where
   removal buys measurable frame time rather than tidiness.

Until 1–4 exist, the honest status of §19.5 is: **hooks 1–9, 21–23 are load-
bearing; 3, 10–20 are diagnostics; only 24 has a shadowing argument; 2 was a
mistake on my part.**

**Withdrawn from the list above:** item 5 (was transit's `LocalRaidSettings` stale?)
was my error, not a station-log item — see §19.6c. It cost nothing to find, which
is exactly why it should not have been written down as a lead in the first place.

### 19.9 When is a `TransitController` created — and could the mod force one?

Follow-up to §19.6c, asked directly. The hierarchy is small and closed:

```
TransitController            abstract, IDisposable        dump.cs:258006
└── ClientTransitController  abstract                     dump.cs:257705
    ├── LocalTransitController    sealed                  dump.cs:257844
    └── NetworkTransitController  sealed                  dump.cs:257886
```

Both intermediate types are `abstract`, so their never being `Newobj`'d is
expected rather than a gap. **There are exactly two construction sites in the
whole game**, one per leaf:

| Concrete type | Construction site | Publication |
|---|---|---|
| `LocalTransitController` | `BaseLocalGame<T>+<Run>d__61` ISIL 1322 / 1331 | ISIL 1343 → `gameWorld.<TransitController>k__BackingField` |
| `NetworkTransitController` | `NetworkGame<T>+<Run>d__78` ISIL 2957 / 2963 | ISIL 2975 → same backing field |

Both are inside the game's own `Run` state machine, both null-check the
`GameWorld` first (1342 / 2974) and publish only if it is non-null. So the
controller is created **once per game session**, by the game loop, after the
game object exists — which is the ordering §19.6c depends on.

**Could the mod force one? Yes mechanically — `GameWorld.TransitController` is a
public settable property** (`dump.cs:244478`), and the setter is trivial:

```
GameWorld.set_TransitController:
  mov [rcx+38h],rdx
  add rcx,38h
  jmp near ptr 0000000180507AE0h      ; write barrier
```

Three things make it a bad idea anyway, in descending order of how hard they
would be to notice:

1. **It would not take effect.** `Transit` is dispatched through each
   `TransitPoint`'s *own* `<Controller>` reference, not through `GameWorld`'s.
   `TransitPoint` has a public `Controller` property (`Interactive/TransitPoint.txt:13`)
   and **24 read sites** against **zero** in-class writes — the setter has no
   caller anywhere in the dump. `TransitPoint+<Transit>d__38` reads
   `v53.<Controller>k__BackingField` at ISIL 562 and dispatches at 576. Swapping
   `GameWorld.TransitController` would leave every already-spawned transit point
   pointing at the original. A forced controller would sit there, owned by
   nothing, doing nothing — which is exactly the kind of thing that looks like it
   worked.
2. **It would double-subscribe.** `ClientTransitController`'s ctor does
   `ItemController.add_AddItemEvent(this.OnItemAdded)` (ISIL 191) and registers
   a teardown via `_disposables.AddDisposable` (ISIL 215). A second instance
   means a second subscription on the same inventory event. The original is never
   unsubscribed, because `GameWorld.Dispose` (ISIL 695–710) only disposes
   whatever is in the backing field — so the orphan leaks and keeps receiving
   item-added events.
3. **The constructor needs four arguments the mod does not have.**
   `(TransitGlobalSettings, TransitParameters[], Profile, LocalRaidSettings)`.
   `TransitParameters[]` is built inside `Run d__61` and never published anywhere
   the mod can read it; the mod would have to reconstruct it from the location's
   transit config and get it subtly wrong.

**Recommendation: do not.** Transit demonstrably works today, §19.6c shows the
one thing I suspected it might be getting wrong is not wrong, and all three
failure modes above are silent. Recorded here so the option is not re-derived
from scratch later. If a transit behaviour ever does turn out wrong, the cheap
first move is the one already in place — the hook on `Transit` itself — not
replacing the object underneath it.
