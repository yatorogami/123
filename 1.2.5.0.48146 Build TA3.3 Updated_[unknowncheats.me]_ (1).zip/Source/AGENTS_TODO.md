# AGENTS_TODO.md

> ## 2026-10-13 (later) — the bigmap plan's asset steps are done, and three of the four freeze-unblocked items are fixed
>
> **Steps 1–5 of `tools/plan_bigmap_and_minimap.md` all landed today.** The last
> of them, step 5 (static markers + labels on the radar, 242 + 270 rows merged
> from the DynamicMaps submodule behind two MinimapModule checkboxes), is in
> `CHANGELOG.md` §0.68 — including the negative control that proved the obvious
> bounds check could not catch the coordinate mapping. Remaining in that plan:
> step 6 (`MapModule` + M keybind + full-screen view) and step 7 (the drop-down).
>
> **Of the four items the freeze lift unblocked (first note below), three are
> done:** the quest place-POI fix (`e05dd0bbf` + its build fix `2f29e1bcc`,
> verified 0-unresolvable/exit-0 against both real dumps), the
> `bugprone-use-after-move` at `EspModule.cpp` (`63c19fac1`), and the
> CLEANUP_AUDIT §2.3/§2.4 deletions (`80358d826`). The fourth — the
> `skeleton_visibility.h` clone merge — is still open by choice: its own §5 says
> the merge wants a trace-dump diff taken before and after, and that needs a
> raid nobody has run since.
>
> **One process note, mine:** `63c19fac1` swept two hunks of another session's
> in-flight `EspModule.cpp` work into my commit by staging the whole file. Their
> §0.67 records the same event from their side. Nothing was lost and the history
> is not rewritten, but the pattern (stage explicit files, never a whole working
> file another session is editing) is the one AGENTS.md already documents and it
> caught me anyway.
>
> **And the mirror image, 20 minutes later:** I staged all 40 files of the bigmap
> commit, and the other session's `8be6028a7` ("fix(loot): a restored config
> selects again in a multi box") committed the whole index — my bigmap step 5
> included. So the step-5 work is in the tree at `8be6028a7` under their message,
> verified by the build and suites I ran against exactly that content, and not
> re-attributed by rewriting shared history. **The lesson is the same one from
> both directions: on this tree, `git add` is not a staging area, it is a
> half-finished commit that the next session to run `git commit` will finish for
> them.** Stage and commit in one breath, or do not stage.

> ## 2026-10-13 — the ESP/optics freeze is LIFTED. The `[CLEANUP-PENDING:OPTICS]` markers are gone.
>
> The user's instruction, verbatim: *"Remove cleanup-optics - that workflow
> should have finished and no additional changes will be added."* The optics
> rework is finished, so the freeze that protected `EspModule.h`,
> `esp_text.h`, `quest_esp.h`, `skeleton_visibility.h` and `il2cpp/unity.h`
> against a concurrent rework on another machine no longer has anything to
> protect against.
>
> **What was done, and only this:** the five header markers were removed
> (each block's audit findings kept, reworded from "deferred" to "cleanup
> candidate"), and the two code comments that cited the freeze as a live
> constraint were corrected — `EspModule.cpp:5370` (its `esp_text.h` two-line
> helper now exists at `esp_text.h:299`, which the comment contradicted) and
> `AiLimitModule.cpp:602` (the four-way LocationId probe duplication is now
> consolidation-eligible, still not consolidated). `AGENTS.md` "Do not touch"
> is the authoritative current state. **No item the freeze was deferring has
> been actioned** — that is what "no additional changes will be added" means,
> and the list below is the handover, not a worklist.
>
> **What the lift unblocks, for whoever picks each up:**
>
> 1. **`quest_esp.h` place objectives never draw** — diagnosed in
>    `tools/handoff_quest_place_pois.md` (the `zoneId`/`zoneID`/`ZoneId` list
>    matches no field; the class carries `zoneIds`, plural, a `string[]`).
>    Blocked only on this freeze; the fix shape is §4 there (array read + one
>    POI per id, copying `process_inzone_conditions`), and §5's one premise
>    still needs a raid to confirm.
> 2. **A real clang-tidy bug, §5.7ag's "THE REAL BUG"** —
>    `EspModule.cpp:2462`, `bugprone-use-after-move`, with the one-line fix
>    spelled out in that section. It was written down rather than fixed
>    *because* of this freeze.
> 3. **`CLEANUP_AUDIT.md` §2.3/§2.4's deferred items** — the two unreferenced
>    helpers in `skeleton_visibility.h`, `any_enabled` in `esp_text.h`,
>    `last_collect_was_authoritative` in `quest_esp.h`, the `EspModule.h`
>    orphans, and the six `unity.h` math helpers. Two cautions survive as
>    engineering facts: the `dual_active` guards are a behaviour change to
>    remove, and `estimate_ricochet_chance`'s rationale comment is worth
>    keeping if the shim goes.
> 4. **The `skeleton_vis_clone_merge.md` decision set** — that handoff was
>    waiting on exactly this answer ("If the rework has finished, the right
>    change is to delete the stale markers -- that is a small, safe, useful
>    edit and it is not mine to make"). Its §5 merge order still applies.
>
> **Measured tonight, and it changes one conclusion the freeze was guarding:**
> in the 2026-10-12 raid (pid 11736), `vis-breakdown` reports
> `hit_target=9956` and `hit_shooter=42` in single 30 s windows, and
> `inside_hit=21` in one — so `classify_hit_transform` is returning non-`none`
> in volume. The `handoff_visibility_inside_hit_REPLY.md` conclusion that the
> four `vis_exit` zeros were "dead by construction, not merely unobserved"
> (because the occlusion-mask union has no `PlayerMask`/`ConsiderPlayerMask`)
> is **falsified by newer data** — the mask now resolves fully
> (`settings=3/3 layers=8/8 occlusion_api=2/2`) and rays are reaching player
> colliders anyway. See the flag section below. This is why the lift was
> recorded here rather than as a bare "markers deleted" line.

---

> ## 2026-10-06 — two documents are stale about `util/crash_probe.h`. CLARIFICATION NEEDED.
>
> `crash_probe.h` was reworked substantially and is now **2,554 lines**, with a
> `(code, address)`-keyed confirmed latch (`g_confirmed_code`/`g_confirmed_addr`),
> unconditional `######## PROCESS DYING ########` markers, first-chance reports
> labelled as such and capped at 8 per session, and `tools/probe_test/` (46
> assertions). Two places still describe the pre-rework design and **contradict
> each other**:
>
> - `tools/handoff_call_through_null_crash.md`'s provenance table says
>   *"probe still destroys the report for stack-starved faults"* — i.e. the
>   capture-order bug is still open.
> - `crash_probe.h` itself records the ordering as fixed (cheap part first,
>   expensive part behind a guard) after that bug killed the process it was
>   observing for a month.
>
> **The header is the newer artefact and the more likely to be right**, but that
> is an inference from commit order, not something established. What is NOT in
> dispute: **the new form has not been exercised in anger.** No session since the
> rework has produced a real death to report, and the game is mid-update, so
> every claim about how it behaves under a genuine crash is untested. The
> `probe_test` harness proves the report/no-report *logic*; it cannot prove the
> probe survives a real fault.
>
> **Do not treat either line as current, and do not delete either as superseded.**
> The next real crash should settle it, and the first thing to do with that log is
> check whether a `PROCESS DYING` block is followed by frames. A `PROCESS DYING`
> marker with no report attached means the ordering bug is still live no matter
> what the header claims. Until then this is a known-unverified area, not a
> closed one.

---

> ## 2026-10-06 — audit of the earlier call-through-null fixes: ONE was destructive.
>
> Checked against git (`git show 6c8435ff`, `git show 6b35fe8b`, `git show 6b35fe8b^`).
>
> **`unity.h` (6c8435ff, 4 resolvers): behaviour-preserving.** Verified against the parent
> revision — `camera_pixel_width`, `camera_pixel_height` and `camera_aspect` already used
> the `if (!x || !x->klass) … cached_method … fn ? fn(x) : <fail>` shape, and `cached_method`
> pre-existed (4 occurrences in the parent), so the fix matched the established idiom rather
> than inventing one. No reordering, no changed return value.
>
> **`get_scope_zoom` / `try_read_weapon_ammo` (6b35fe8b): behaviour-preserving.** Diffed
> the parent line by line. The fail-closed value is `1` for the zoom factor, which was
> already the function's own "no scope information" answer, and `false` for the two
> `try_*`. The two added null tests (`->klass`, and the `adjustable_obj` behind
> `MinMaxFov`) close real null derefs. The `!= "FirearmController"` → `return 1` rewrite
> is equivalent to the old positive-condition `if`. Nothing lost.
>
> **`try_get_health_controller` (same commit): DESTRUCTIVE, and reverted.** It was **never
> a call-through-null site**. `git show 6b35fe8b^` shows the original already resolved into
> a local and tested it (`if (get_active)` / `if (!get_health) return nullptr`), so the
> commit's premise did not hold for this function. What it added instead was a single-slot
> per-object memo **memoising failures**, justified by a per-frame caller
> (`scene_objects_live`) that was subsequently refuted and cut in `0d065f29` — the
> justification is gone and the memo stayed. Two independent hazards: a transient miss
> during teardown is cached permanently for that pointer, and the slot is never cleared on
> a raid boundary, so a recycled player address can be served the *previous* player's
> controller — a stale pointer handed to managed code. Restored to the original guarded
> form; `cached_method` kept, since that part is sound independently.
>
> **The general lesson, since this is the second time:** a null-guard sweep is not
> automatically a null-guard sweep. The commit bundled a performance change into a safety
> change, and the commit message does not mention it. **Diff the parent revision before
> trusting a "fixed N sites" claim** — the count is of sites *changed*, not sites that were
> broken.
>
> Also fixed here: the three "silent where it was once loud" guards from §5.7ad are now
> **loud** (capped `logger::warn`, so they cannot become the next per-frame flood). They
> remain fail-closed — no behaviour change, only the missing evidence.

---

> ## 2026-10-06 — `[ScavRole/ShooterBTR]` on the overlay: the game ships no translation for it.
>
> **Where it came from.** `eft_api::get_localized_role_label_wide()` (module/eft_api.h) asks
> the game for its own key and then localises it. Traced to the source:
>
> - `WildSpawnType.shooterBTR = 46` (GameDump `EFT/WildSpawnType.cs:50`)
> - its settings row sets `ScavRoleKey = "ScavRole/ShooterBTR"` (ISIL
>   `WildSpawnTypeExtension.txt` line 809)
> - `WildSpawnTypeExtension.cs` declares exactly four such constants — `SCAV_ROLE_BOSS`,
>   `_FOLLOWER`, `_SECTANT`, `_CIVILIAN`. `ScavRole/ShooterBTR` is **not** one of them; it
>   exists only as a literal in the settings table.
> - so `LocalizationExtensions.Localized("ScavRole/ShooterBTR", 0)` returns the key
>   **unresolved**, and the overlay drew it verbatim.
>
> **Fixed**: roles we classify ourselves keep our own label. Only the four kinds the game
> actually translates (`boss`↔Boss, `guard`↔Follower, `cultist`↔Sectant,
> `civilian`↔Civilian) take the game's wording — including its localisation, which is a
> feature. Plus an echo guard: if the localised text still equals the key we passed in, it
> was not translated and is discarded.
>
> **Two things this exposes, not fixed here.** (1) The `npc_kind` ↔ game-key mapping is
> implicit and now load-bearing for four kinds; it deserves a named table rather than a
> hand-maintained `||` list. (2) `GetScavRoleKey`'s `default` branch is
> `get_SCAV_ROLE_DEFAULT` = `ToStringNoBox(role, 4)` — enum value 4 is `scav`, so **every
> unrecognised role returns the literal `"Scav"`**. Any role we do not classify therefore
> labels as "Scav", which is indistinguishable from a genuinely generic scav.

> ## 2026-10-06 — three self-testing checkers were never run by `pytest`, and one control was vacuous.
>
> `pytest tools/tests` collected **zero** tests from `call_through_null_scan.py` and
> `diff_truncation_check.py` — the filenames do not match the `test_*.py` glob — and
> **zero** from `test_brace_balance.py`, which is named correctly but defines only `main()`
> and `negative_control()`. So every guard against those three scanners silently going blind
> was manual-only: it ran when someone remembered to run it.
>
> All three are now collected (7 new tests). Two were renamed to the pytest convention; the
> brace checker already matched the glob and needed only entry points added. Each keeps its
> `__main__` block, so `python tools/tests/<file>.py` still works unchanged.
>
> **`test_brace_balance.py`'s negative control was VACUOUS, and had been since the file went
> LF.** It injected a stray brace by matching a literal `
`; `TeleportModule.cpp` is LF, so
> `str.replace` matched nothing, wrote identical bytes, and then computed "detected" from an
> **unmodified** file. Proven directly: the replacement returns a string equal to the input.
> It was reporting on a file it had never damaged. The anchor is now newline-agnostic and
> asserted, so a stale anchor fails loudly instead of silently passing.
>
> The pytest version of that control also runs against a **copy** in `tmp_path`. The original
> edits a real source file and restores it in a `finally`; a suite that can corrupt a source
> file is one interrupted run away from committing the very damage it exists to detect. The
> editing version is still reachable from the command line, where a human is watching.
>
> Controls fired for all three: recursion removed (bug 1), comment stripping disabled (bug 2),
> the resolver regex blinded, the truncation detector blinded, `balance()` blinded, and the
> brace anchor reverted to `
`. Each fails with a message naming the defect.
>
> **`selftest_watch_client_exit.py` is still not collected, deliberately.** It spawns real
> child processes with real exit codes, is Windows-specific, and takes ~90 s. Folding it into
> the suite would make the fast suite slow and the fast suite's green mean less. It stays a
> manual gate; that is a judgement worth revisiting, not an oversight.

---

Open items as of the end of the SafetyHook migration + vendored-code dedup
(`TarkovLauncherBypass` Detours → SafetyHook; `external/safetyhook` and
`external/nlohmann` shared by both projects).

Companion documents: **`WORKFLOW.md`** (how to build, deploy, diagnose and verify
— written 2026-09-30, start there), `CLEANUP_AUDIT.md` (stale-code audit, mostly
applied) and `CHANGELOG.md` (retrospective for `a3307eaf`..`v3.2`, regenerated).
This file is the "what is still outstanding" list; those are the record of what
happened and how to operate it.

## Cross-workstream premises — read before reasoning about another agent's code

**`tools/premises_about_other_workstreams.md`** — written by the aimbot/pen-check
workstream, 2026-10-04. It records what that workstream *believes* about the optics,
menu and `always_on.h` code, each with its evidence and **what would falsify it**, and
explicitly flags four things it does not know. Several claims contradict
`Workstream_status_2026-09-24.md`; where they do, **both are recorded rather than one
being deleted.**

**The load-bearing disagreement:** the optics workstream retracted the
`is_unity_object_alive` 460 µs spike as a one-session artifact. The aimbot workstream
says it was a real defect in `unity.h`, since fixed (`CHANGELOG.md` §0.59), and points
at the `hit/miss` totals in the optics agent's own captures now landing on exact
multiples of the gate constant. **Unresolved between them; §2 of the premises file has
both readings.** Neither should be treated as settled.

**Also live — LOCATED, cause still open.** `frame::AimbotModule::gameworld_update`
was **174.8 s / 63.5 ms mean** with 99.92% unattributed. The 2026-10-04 14:36 capture
names the region: **`aimbot::fireport_resolve`, 310.59 s over 22,129 calls, 39.96% of
the whole capture**, 33x the next most expensive zone in it. The function now reads
`self = 0.0132 s`.

**Two zones were added inside `try_get_fireport_position` to finish the job**:
`skeleton_vis::fireport:get_Fireport` and `:get_position`. **Which one carries the
cost is not yet known**, and it is a one-capture answer.

**The cost is BIMODAL, not a steady 14 ms.** `csvexport -u` emits one row per event
with `ns_since_start`; bucketed by 30 s it is **1.44 us/call for 3.5 minutes** then
**37,343 us/call for 6 minutes**. "22,129 calls on 78% of frames" says how often, not
how much — I used it to rule out the loading screen and was wrong.

**Not the thread.** Split by regime, `gather_phase` (20.6 -> 23.1 us) and `ammo_cache`
(27.2 -> 13.3 us) are flat while the fireport goes 1.44 -> 37,343 us. A blocked thread
shows in all siblings or none.

**What is needed: one capture with the new `fireport-cost:` line**, which reports
`calls/total_ms/mean_us/max_ms/rate_hz` **into the log every 30 s** so `Loading in at:`
and `Local Raid Ended` can be laid over the buckets. The 14:36 session cannot answer
it — its log stops one record before the capture window opens.

**Verified separately:** it cannot run outside `is_in_raid` (one dispatch site,
`common_hooks.cpp:381`, gate at `:361`; `AimbotModule.cpp:51` and `:98` gate
themselves). **But that is not a load gate** — `is_in_raid` is TRUE from the moment
`MainPlayer` is non-null (`game_state.h:50-57`), before the map streams. A
load-complete predicate does not exist yet and is the likely fix.

All three configs clean; 204 tests pass.

---

## FLAG TAKEN 2026-10-05 - visibility walk (`skeleton_visibility.h`) - indefinite

The ESP/optics workstream has the flag on the visibility walk **for an undefined time from
2026-10-05**, granted by the user. Scope: `try_get_occlusion_layer_mask`,
`is_target_visible`, `classify_hit_transform`, and the `vis-breakdown` line in
`module/skeleton_visibility.h`.

> **2026-10-13 — the flag's protective premise is gone.** It was granted while the
> optics rework was live on another machine; the rework finished, the user lifted
> the freeze, and the `[CLEANUP-PENDING:OPTICS]` marker on this file is removed.
> The coordination request below is history: nothing is coordinating the visibility
> walk any more, and this file is ordinary first-party code. What remains of the
> flag is the *ownership record* — who was looking at what — plus the two open
> items in its last bullet, which now stand on their own evidence.
>
> **And the headline conclusion is falsified by newer data.** The section below says
> the four `vis_exit` zeros are dead code "by construction". The 2026-10-12 raid
> (pid 11736) reports `hit_target=9956`, `hit_shooter=42` and `inside_hit=21` in
> single 30 s windows, with the mask fully resolved
> (`settings=3/3 layers=8/8 occlusion_api=2/2`). Rays are reaching player
> colliders despite no `PlayerMask`/`ConsiderPlayerMask` in the union — so the
> classifier is live, `is_target_visible` is more than "does world geometry block
> this line of sight", and the `InteractiveMask` + `LootCollisionMask` candidate
> is still unproven either way. Re-derive from `vis-breakdown` before building on
> the 2026-10-05 reading.

- Coordinate through that workstream before touching any of the above. *(Historical —
  see the 2026-10-13 note above.)*
- Started by the review in `tools/handoff_visibility_inside_hit_REPLY.md`: the four
  `vis_exit` zeros (`inside_hit`, `no_transform`, `hit_shooter`, `hit_target` - 0 across
  1,480,017 rays) were read as **dead code, not a live defect**, because the occlusion
  mask union contains no `PlayerMask`/`ConsiderPlayerMask`, so a ray cannot hit a player
  collider. **Superseded as to "dead by construction"** — see the note above; the
  `InteractiveMask` + `LootCollisionMask` question it raised is still the open
  candidate for a real visible defect.
  The occlusion mask is now logged per-component; the open candidate for a real visible
  defect is `InteractiveMask` + `LootCollisionMask` in a line-of-sight mask.

## Handed off, 2026-10-04 — not mine, not acted on

Three items from other workstreams, all outside this pass's area. Full detail
and evidence in **`tools/handoff_exfil_overlay_and_probe_memo.md`** and
**`tools/handoff_visibility_inside_hit.md`** (+ its `_REPLY`, which closes item 3
and raises the two that matter more). Items 4 and 5 below are new, from that
reply, and are the optics owner's to action — not to action from here.

1. **`menu::draw()` throws on the first frame after exfil.** This is the crash that
   killed four consecutive sessions (`0xE06D7363` at `KERNELBASE.dll+0xC41CA`, always
   after `Local Raid Ended` / `Transfer Items: 1`). The `kOverlayPoisonedAfter` backoff
   in `gui/dxhook/dxhook.cpp` now catches it — the 13:02 session has **no FATAL** and
   logs `total throws=138` — but it names only the stage. `UNRESOLVED` is *correct*
   here: a non-std throw has no RTTI, so no type name exists to recover. **Owner: the
   menu/overlay workstream.** What is needed: which card, on the first frame after
   teardown.

2. **`probe-memo` eviction is at 19–100% again**, with three of seven windows at
   `fills == evictions`. Per `eft_api.h`'s own stated decision rule this means **a bigger
   array is the wrong fix** — and `fills=29`/`fills=42` in the 100% windows cannot
   overflow a 4096-slot table by capacity, so the cause is not established.
   **Owner: whoever owns `eft_api.h`'s region memo.** Do not resize before reading the
   handoff's "the one number that decides it".

3. **`vis_exit::inside_hit` in `is_target_visible` returns "visible"** — the same
   unverified-pass shape §0.53 fixed in the pen walk, at
   `skeleton_visibility.h:2258`. **Filed 2026-10-05 in
   `tools/handoff_visibility_inside_hit.md`; ANSWERED same day in
   `tools/handoff_visibility_inside_hit_REPLY.md`. CLOSED — no fix wanted, and the
   answer is better than the question.** All three of my reasons for not patching it
   verified, and the correction is the useful part: `inside_hit` was the *least
   interesting* zero on that line. `hit_target` and `hit_shooter` are **also zero**
   across all 50 windows / **1,480,017 rays**, so `classify_hit_transform` has never
   returned anything but `none`. The reason is in `GameDump/115147510`: the occlusion
   mask union contains **no `PlayerMask` and no `ConsiderPlayerMask`** (both exist in
   `LayersMaskController` at 0x08/0x10), deliberately — a player must not occlude
   another player. So the ray cannot hit a player collider and **four exits are dead
   by construction, not one.** `return true` in dead code is harmless.
   I verified the union against the dump: 8/8 members present, both player masks
   absent. **Owner: the ESP/optics workstream**, who has taken the visibility walk
   indefinitely from 2026-10-05 on the user's authority; the
   `[CLEANUP-PENDING:OPTICS]` marker stays and the rest of the surface is still
   frozen. **(Both removed 2026-10-13 — see the top-of-file note; the paragraph
   above is the 2026-10-05 reading and its central claim is falsified.)**
   **The optics commit (`7f911e4d`) is build-verified** - clean `Prod|x64` via
   `tools\build.ps1 -Slot docs`, exit 0, 0 errors, only the expected `MSB8012`, DLL
   8412.00 KB. Its own message correctly declined to claim that.
   **2026-10-13: "four exits are dead by construction" is FALSIFIED by newer data** -
   the 2026-10-12 raid reports `hit_target=9956` / `hit_shooter=42` / `inside_hit=21`
   in single windows with the mask fully resolved. See the top-of-file note and the
   visibility-walk flag section; do not quote the paragraphs above as current.

4. **`InteractiveMask` + `LootCollisionMask` are in the line-of-sight mask** — the
   real candidate defect this exchange surfaced, and the highest-value item in it.
   A loot container or interactive prop between you and a target classifies as
   `hit_occluder` → target hidden, and the **95.9% occluder rate is consistent with
   it**. **Unproven — flagged, not claimed.** The game's own split keeps
   `PlayerStaticDoorMask` (0x44) separate from `PlayerStaticCollisionsMask` (0x48),
   which suggests doors are meant to be distinguished, and we take the latter.
   **Now measurable:** `7f911e4d` logs the mask and per-component resolution on the
   existing 30 s `vis-breakdown` line, so one session gives the mask value, and
   dropping those two components is one edit plus one raid. **Owner: the
   optics workstream** — do not action from this file, coordinate through them.
   Related and same class: `WEAPON_OCCLUSION_LAYERS` has **zero** game-side reads
   (one hit across the whole dump, the declaration), so the hand union has no
   game-side authority behind it except the two `SoundOcclusionUtils` getters.

5. **Reading trap in the new `vis-breakdown` suffix.** `fallback=0` does **not** mean
   the mask is game-derived. `any_game_side` is set inside the per-component loops
   rather than per *successful* component, so a build that resolves the class and
   then fails every field read reports `fallback=0 settings=0/3` with a mask of 0.
   The per-component fractions are the mitigation — **read the whole suffix before
   interpreting any of it.** Same change also moved the mask from
   `fallback_layer_mask` to `0`, so a partially-resolving build now gets only what
   resolved instead of a guessed floor; that is more correct but is a behaviour
   change on a live raycast path, not purely observability.

---

## CURRENT STANDING STATE — 2026-10-01

**Build: green.** All twelve x64 configurations (4 each for `TarkovAddons`,
`TarkovLauncherBypass`, `vk_swiftshader`) compile with **0 errors and 0 code
warnings**. `MSB8012` is expected and benign. See `WORKFLOW.md`.

> **This line was FALSE when I checked it on 2026-10-05, and it stayed false for
> three commits.** `Prod|x64` did not build at all — 24 errors, no output DLL —
> while `tools/tests` was green at 230 and `CHANGELOG.md`'s last build line said
> exit 0. The break arrived in `f1006f6c`, four commits earlier. Re-verified
> 2026-10-05: `Prod|x64` clean `Rebuild` is **exit 0, 0 errors, 0 code warnings**,
> 153 s, `TarkovAddons.dll` 8410.50 KB. **Only `Prod|x64` was re-checked** — the
> other eleven configurations are unverified as of today and the "all twelve"
> claim above is not re-established by that one build.
>
> The cause is worth one line because the errors were actively misleading:
> `optics_lens_pipeline.h` declared the root-corrector ring and its kill switch
> **inside `camera_consistent()`'s body**, and `root_frame_summary()` at
> namespace scope reads both. C2326 and C2888 named a lambda that was innocent,
> and inviting a fix (add a capture list) that changes nothing. C2601 —
> "invalid local function definitions" — was the honest error. Fixed by moving
> five declarations to namespace scope; no logic touched. Full write-up in
> `CHANGELOG.md` §0.54.
>
> **All four x64 configurations re-verified 2026-10-05**, after the fix — and
> **the solution covers all three projects**, which this file previously got wrong
> twice in one afternoon (see the caveat below). `TarkovAddons.sln` contains
> `TarkovAddons.vcxproj`, `..\TarkovLauncherBypass\TarkovLauncherBypass.vcxproj`
> and `..\TarkovLauncherEntrypoint\vk_swiftshader\vk_swiftshader.vcxproj`, each
> with the same four x64 configurations, so **one `Rebuild` of the solution is
> all twelve**. Measured, clean `Rebuild`, all exit 0 / 0 errors:
>
> | configuration | time | first-party warnings |
> |---|---|---|
> | `Prod\|x64` | 152 s | 2 |
> | `Prod no aimbot\|x64` | 146 s | 2 |
> | `Debug\|x64` | 147 s | 3 |
> | `Release\|x64` | 148 s | 3 |
>
> **"0 code warnings" is accurate for `TarkovAddons` and inaccurate for the
> solution.** The two persistent warnings are in `TarkovLauncherBypass`:
> `injector.cpp:137` C4312 (`reinterpret_cast` from `int` to a larger `PVOID`) and
> `spoofer.cpp:41` C4200 (zero-sized array). `Debug`/`Release` add a third, which
> is not a compiler warning: *"Cannot update `x64\Debug\TarkovAddons.dll` — file
> is locked"*, i.e. the game holds that output. Harmless for `Prod`, which is what
> ships, and it is why the `Debug` DLL must not be quoted as freshly built.
> Everything else is SDK/CRT noise: 131 lines from `ntstatus.h` macro redefinitions
> and one C4244 inside `xutility`.
>
> **The generalisable part: neither `tools/tests` nor `tools/harness` builds the
> project, by design.** That is what makes them fast and immune to a concurrent
> agent's edit to the DLL, and it is also why a header-only change is invisible to
> both. Two green suites said nothing about the artefact that ships. `WORKFLOW.md`
> already defines "verified" as a full `Prod|x64` build **and link** — that
> definition is load-bearing and is the one to keep applying when the diff is
> prose.

**Deployed:** `C:\Battlestate Games\BsgLauncher\TarkovAddons.dll`. Launch via
`BsgLauncher.exe` — starting the game directly does not load the DLL. No size or
timestamp is quoted here on purpose: this line was wrong twice in one day
precisely because a deployed build changes without this document changing.
`Get-Item` it, or don't quote it.

### What actually blocks anything, as of 2026-10-01

**The game has been launched, repeatedly, and it crashes.** That is the state.
The "nobody has launched the game on a current build" line this section carried
until 2026-10-01 was written at 18:52 on 09-30 and was already false when the next
session started: ten launches' worth of crash dumps exist between 20:56 on 09-30
and 09:50 on 10-01, plus in-game log lines proving the mod reached
`Loading Asset Bundle`.

So §0, §1.2, §1.3 and §1.5 are not "awaiting a launch" any more. Being precise
about why, because "launched" and "verified" are different things:

- **§1.2 (bypass launch path) is closed by observation.** The game process is
  created, the DLL loads, the log advances. The hook install path demonstrably
  works.
- **§0 (null-write crash) — no recurrence observed**, across ten launches. Not
  proof, but no longer an open question.
- **§1.3 / §1.5 are entangled with the crash work**, not with the launch. The
  10-01 09:50 log shows `Loading Asset Bundle` being reached, so the chams path
  is entered; whether the bundle loads is still unconfirmed, and the
  `LoadFromFileAsync` resolution failure is still undiagnosed.

**One crash of ours is unexplained and is the live item.** See §5. The
`0xC0000005` at `TarkovAddons.dll+0x744C1` (`std::basic_filebuf<char>::_Endwrite`,
READ of `0x138`, on the ESP draw thread) occurred twice — 20:56 and 21:14 on
09-30 — and has never been repaired. The rewritten `util/crash_probe.h` exists
precisely so this class stops being invisible, and it is still invisible, because
`AGENTS_TODO.md` never listed it. That is now fixed: it is §5.1.

Three crashes *were* root-caused and fixed: the recursive `std::mutex` in
`refresh_passcode_labels` (the probe named `std::system_error` directly, thrown
5900+ times on the game's update thread at 09:01 on 10-01), and two earlier
store-escape defects. The remaining `0xC000070E` threadpool fault is measured
**not** to be ours — §5.3.

### Recently closed, recorded in place

| item | where |
| --- | --- |
| `hook_method` null-write crash (§0) | fixed by the hideout/probe author; `T2*` + `static_assert` |
| PCH refactor did not build — 68 × C1010 (§1.7) | fixed: `$(ProjectDir)` on the include path, `#include "pch.h"` as the literal first line in all 70 TUs. Measured **2.5× faster clean build** |
| 34 × C4805 `bool`/`int` in `eft_api.h` (§3.8b) | fixed with an explicit `s_have_sample` flag replacing an `int -1` sentinel |
| vendored IL2CPP header provenance (§1.6) | **verified** — `js6pak/libil2cpp-archive`, 112/113 structs member-identical to 2022.3.43. See `TarkovAddons/il2cpp/PROVENANCE.md` |
| engine version unrecorded (§1.6) | **2022.3.43f2**, from `UnityPlayer.dll`'s version resource |
| compatibility manifest "suspect row" (§1.6) | **withdrawn — the manifest was right**; all six fields verify against the live install |
| `AimbotModule::show_cone` was never constructed — `0xC0000005` READ of `0x50` | **FIXED 2026-10-03**, see §5.15. Declared, documented, dereferenced, i18n key in all 19 `lang/*.json` — and missing from the ctor init list, so it held indeterminate memory. Plus `= nullptr` on all 11 raw config pointers, and `tools/audit_config_pointers.py` guards every config pointer in every module header — the count is re-derived from the tool by `tools/tests/test_doc_counts.py`, so it is not quoted here |
| the crash probe was **killing the process it was observing** | **FIXED 2026-10-03**, §0 and §5.16. `TarkovAddons.dll+0x1AE83A` = `fill_event+0x41` = a `call` to `GetCurrentThreadId` from inside the VEH, under 160 bytes of stack; a fault inside a VEH is uncatchable. Three fixes + cross-checked against the 12:38 minidump field for field |
| menu two-column boundary was 11 `m->name ==` predicates evaluated **while drawing** | **DONE 2026-10-03**, §3.10. Now resolved before drawing from one table in `gui/menu/column_layout.h`, with `tools/harness/test_column_layout.cpp` (44 assertions) covering both toggle states and the registration order it depends on |

### Three things I got wrong, corrected here so it is not repeated

1. **Metadata version 31 was written off as "unverifiable".** It is 31, verified
   from the decrypted copies in `GameDump/`. I had the encrypted shipped file
   open, could not read its header, and wrongly treated *cannot be read from the
   shipped artefact* as *is not true*.
2. **The "2022.3.20–2022.3.62 window" was quoted as if sourced.** It appears in
   no code, comment, or vendored file — only in prose here, which I then repeated
   into `PROVENANCE.md`. A citation loop. Removed from both, and named as a
   retraction rather than restated.
3. **The transit "stale settings snapshot" lead, and the "truncated raw
   disassembly" finding underneath it.** Both were built on measurements I did
   not take properly: the snapshot claim was inferred from method boundaries
   rather than from the argument values, and the truncation figure came from
   comparing raw instruction lines against ISIL indices when a median 76.5% of
   ISIL lines are `Nop`. The raw sections are ~98% complete, and once read
   properly they show the controller shares the *same* `LocalRaidSettings`
   object as `TarkovApplication` — no copy, no staleness. §19.6c, §19.2.

   The general lesson, since it has now happened twice in this file: a claim
   promoted to a "most promising lead" needs its evidence stated at the level it
   was actually obtained. Both of these read as findings because a table and a
   percentage were attached to them.

### The executed-harness evidence no longer re-runs

Every "N/N assertions" figure in this file and in `CLEANUP_AUDIT.md` was real
when it was written, and the harnesses lived in
`%LOCALAPPDATA%\Temp\opencode\ta_tests`. **That directory is gone** (temp
cleanup), so the results stand as evidence but cannot currently be reproduced.
Covered: the `ta/configs` migration (46/46, nine scenarios), the config parser
(19/19), the RCDATA asset path (15/15, against the real built DLL mapped the
way a manual mapper would), a 1-byte heap overflow in `wide_to_utf8` (8/8), and
the RCDATA bounds check (16/16).

**Rebuilt and re-runnable as of 2026-10-11 — 19 cases + 449 pytest.** The
authority is `tools/harness/README.md`; the current per-case table is in
`WORKFLOW.md`. `tools/harness/run_windows.bat` runs all 16 and exits 0; `run.sh`
runs the then-7 portable ones; `pytest tools/tests` is 452 passed / 17 subtests, with 2 failures in other workstreams' files
2 failures in files this workstream does not own (`patterns.cfg`'s `hwid_check`
expectation, and `map_icf`'s doc figures against today's map). Of the
lost set, the config parser and the RCDATA path are covered again, and the
migration is covered in a *different language* — see below. `WORKFLOW.md` records
the two safety traps from writing them (the `_dupenv_s` vs `_wputenv_s` redirect
that once moved 23 real user files, and the logger holding its log file open so
`remove_all` bails partway).

> **This paragraph carried four wrong numbers at once, and so did three other
> files — CORRECTED 2026-10-05 by running the runners.** It said 7 native cases,
> 2 portable, 139 and 149 pytest, with *two* different pytest figures in six
> lines. `WORKFLOW.md` said 11 and 155; `tools/README.md` said 149;
> `tools/verify/README.md` said 7 and 139; and `tools/harness/README.md` said 9,
> then "all eight" two lines later, then "the eight above", while omitting two
> cases its own runner compiles. Measured: `run_windows.bat` exit 0 on **11**,
> `run.sh` builds **3**, `pytest` **230 passed / 6 subtests** (220 before this
> file's own new cases were added), `unittest discover` 120. All four files now
> agree.
>
> **Why it persisted for weeks:** every one of those numbers was *plausible* and
> the suite grew silently past all of them. This is the same failure as
> `audit_config_pointers.py` exiting 0 while checking nothing, and the same as
> `test_profile_path.py`'s negative control passing against reverted code — a
> count nobody measured is an assertion wearing evidence's clothes. The fix is
> not a number, it is the habit in the next paragraph, which is why that one is
> kept.
>
> **Half of it is now enforced rather than promised.**
> `tools/tests/test_doc_counts.py`, 5 cases, re-derives the native case count
> from `run_windows.bat`'s own `call :portable` lines on every run and fails if
> any of the four documents disagrees — which is how it found the "7" and the
> "2 portable" still sitting in this file after they had been corrected
> elsewhere. Negative-controlled both ways: un-wiring one case from the runner
> and reverting one documented count both turn it red and name the file to fix.
>
> **The pytest count is deliberately NOT enforced, and the reason is worth more
> than the check would have been.** A cross-document agreement check on that
> number was written and then deleted: it flags `AGENTS_TODO.md`'s ~10 per-session
> records ("`tools/tests` is 155 passed" inside dated sections), which are
> *correct* — the suite really was 155 when that section was written. So the only
> ways to make it pass were to edit accurate history or delete the check, and a
> check whose only remedies are those two is one that trains people to delete
> checks. It is not merged; the reasoning is in the test file, so the next
> person does not re-derive it.

> **Count the cases the runners execute, not the `.cpp` files in the directory.**
> `test_card_fold_realfile.cpp` sits in `tools/harness/` and is built by neither
> runner. A file no runner compiles cannot be part of a coverage claim, and "8
> files, 7 cases" is the kind of pair of numbers that disagrees with itself in
> one paragraph.
>
> **The other half of that rule, learned the same day 2026-10-05: count what the
> runner executes, not what someone remembers it executing.** The directory holds
> 13 `.cpp` files, of which **11** are wired (`stubs.cpp` is a shared support
> file, `test_card_fold_realfile.cpp` is not built). So "13 files" and "11 cases"
> are *both true and not interchangeable*, which is precisely the disagreement
> above — and the mistake made in the other direction, `tools/harness/README.md`
> undercounting the cases its own runner compiles, is the same error with the
> sign flipped. When in doubt, read the `call :portable` lines in
> `run_windows.bat`: they are the ground truth, and they are 10 of the 11.

**Partly closed 2026-09-30 — `ConfigValue.h` is covered again.** `tools/harness/`
rebuilds the part of that coverage which is standard-library only, and it runs
anywhere: `tools/harness/run.sh` needs just a C++23 compiler, exits 0/1, and
currently asserts **41** cases over the config layer (was 33; the tri-state parse
in item 15 added 8) — the `config_parse` contract
(*report failure, never throw*, including the trailing-junk and embedded-NUL cases
`stoi` would accept silently), `ConfigValue` flag round-tripping, and config-key
structure. It also characterises the key *format* (`"cb##esp_mod"`), which is a
user-facing file format and so belongs in a diff rather than an assertion. It was
negative-controlled: reverting `to_int` to the `stoi` behaviour its own comment
says it avoids fails 8 named assertions and exits 1.

> This paragraph said 33 for four months of copy-paste after item 15 raised it to
> 41. Both numbers were in the file at once, in different sections, with no way to
> tell which was current. Corrected in place; the "was 33" is kept so the change
> is visible rather than looking like a typo.

**Closed 2026-10-01 — `pe_resource.h` was already covered, and `module_paths.h`
is too.** This section listed `data_migration.h`, `module_paths.h` and
`pe_resource.h` as uncovered because they need `WideCharToMultiByte`,
`GetModuleHandleW` or `FindResourceW`. Two corrections:

- `pe_resource.h` **was already covered** — `tools/harness/pe_resource_test.cpp`,
  55 assertions, written 2026-09-30 20:07, thirteen hours *after* the line above
  was written. It compiles the real header against a purpose-built image with real
  RCDATA, seven of the assertions negative-controlled by patching
  `pe_resource.h`. `tools/harness/README.md` was current on this; only this file
  was stale.
- `module_paths.h` is covered by `tools/harness/test_module_paths.cpp`, 27
  assertions, on `run_windows.bat`. The blocker was never really the platform:
  `module_paths::cached_dll_directory()` is an accessor returning a reference to a
  function-local static, so assigning to it redirects the whole namespace at a
  throwaway directory. No environment variable, no module handle, no production
  change. It also closes **§1.4's unwritable deployment path**, which this file
  called unprovable without a read-only install — it is reachable by making `ta` a
  regular file, so `create_directories` fails with an error, which is the same
  branch. That is a different failure mode from a permission denial and the
  harness says so.
- **`data_migration.h` no longer exists.** It moved to `tools/migrate_legacy.py`
  (§5.6) and `util/data_migration.h` is deleted, so the `win_shim/logger_stub.cpp`
  workaround that served it is gone with it. The 42 pytest cases in
  `tools/tests/test_migrate_legacy.py` cover what the header did, and the three-way
  `%APPDATA%` guard is no longer needed at all: the Python
  `migrate(legacy_root, deploy_root)` takes the roots as **arguments**, so there is
  no ambient environment to get wrong. `tools/harness/README.md` still documents
  the old stub and the old guard and has been corrected.

**The translation table is still uncovered, and that one is genuinely larger.** It
needs `i18n::tr`, defined in the Windows-only `i18n.cpp`, and
`tools/harness/stubs.cpp` supplies the identity function — so the harness tests
that the right key *reaches* the translation layer and nothing about the table. It
also needs the real `lang/*.json` and a way to assert on translated output. With
`il2utils.h` (which includes `safetyhook.hpp` and reaches `globals.h`, where a
partial stub would be the green stub this file warns against) it is the largest
remaining hole.

**`/tmp` is not a safe place to keep anything, and that was learned the hard way
twice on 2026-09-30.** A whole verification toolchain — scripts, baselines, a
shadow tree, 82 object files — lived in `/tmp/opencode` and was gone between one
message and the next; the same directory later ate a `cp` backup mid-run, in the
middle of a controlled experiment. That toolchain is now `tools/verify/` and the
harness is `tools/harness/`, both in the repository. For scratch work, restore
with `git checkout --` rather than from a `/tmp` copy.

### Standing questions, in the order they are worth asking

**Answered since this list was written, 2026-10-01.** Recorded here because the
list has been read as current for a while and the top two entries no longer are.

- **"Launch the game" is done, repeatedly.** Multiple full sessions, four Tracy
  captures (`current+3` … `current+6`), a clean log line. §1.2, §1.3 and §0 are
  closed by observation rather than pending.
- **§2.4's transit-hook log is captured.** `[transitdbg]` is now rate-limited to
  1 s per tag with a suppression count, and a session shows 10 of the tags firing:
  `PrepareGameJob` (140), `ComebackToMainMenu` (116), `OnGameEnd` (111), `Run`
  (88), `AwaitGameOverSaveStatus` (69), `OnReadyToStartMatchingAsync` (63),
  `ShowTransitSaveWaitScreen` (23), `TryGetLocationById` (5). **Zero** lines
  matching "base not resolved", so the ungated per-iteration `logger::warn`
  hazard identified in `always_on.h` is latent, not firing. The 24-registration
  count in `always_on.h` still holds.
- **§1.4's unwritable-deployment path is closed** by `test_module_paths.cpp`,
  which reaches the fallback with `ta` as a regular file. See `WORKFLOW.md`.
- **§1.5's chams bundle question is answered, and the answer was worse than "needs
  a runtime confirmation" — then fixed.** Diagnosis: the bundle loads and a
  reload cycle returns null forever. 11,903 `ERROR` lines, one message, 48/second,
  for the last 4m19s of the session, which was **85% of the log**. All 860
  `item-chams:` traces predate the flood (`22:57:54.492`), so chams was working —
  57 items applied — and never came back. Two causes, both needed: the state
  machine at `common_hooks.cpp:58-84` could not leave its failure branch
  (`check_progress` returned `bool`, so "still loading" and "finished with no
  bundle" were indistinguishable, leaving a dead request polled every frame with
  the backoff unreachable), and the underlying cause was a leaked AssetBundle
  registry entry — `asset_bundles::reset_bundle` never called `Unload`.
  **Fixed 2026-10-01 by the chams workstream:** `check_progress` now returns a
  tri-state (`Loading`/`Loaded`/`Failed`), `Failed` is terminal for that request,
  the request is dropped so the existing `bundle_retry_after_ms_` backoff applies,
  and the watchdog is disarmed because it exists for a *wedged* load, not a failed
  one. `ChamsModule.cpp:153`'s `accounted` sum now includes `st.null_obj` (it did
  not when the one-liner was first filed).

  > **The residual that followed it — "`st.unpainted` is still missing from that
  > sum, so a tick with unpainted items reports them as `unaccounted`" — was WRONG,
  > and acting on it would have been a bug. RETRACTED 2026-10-05.** The item was
  > carried here and in `tools/handoff_optics_memo.md` with the exact fix attached,
  > across two sessions, and it had been checked by reading the **sum** rather than
  > the **loop**.
  >
  > `st.unpainted` is not a scan-loop branch. It is a **sub-counter inside** the
  > `out_of_range` branch: `:684 ++st.out_of_range` opens it, `:711
  > ++st.unpainted` is a detail of it, `:713 continue` closes it. `out_of_range`
  > already counts that item, so adding `st.unpainted` to the sum counts it twice
  > and `unaccounted = examined - accounted` goes **negative** on every tick that
  > restores anything — turning the field whose entire purpose is to report a zero
  > into one that reports a negative number.
  >
  > The sum has exactly seven terms and the loop has exactly seven
  > `continue`-terminated branches, so it reconciles by construction: `null_obj`,
  > `corpse`, `no_game_object`, `no_transform`, `out_of_range`, `already`,
  > `applied`. The three counters that look like omissions are all correctly
  > excluded — `zero_renderer` is the `else` of the `applied` branch
  > (`:737`/`:748`), `multi_slot` is an attribute of a successful paint, and
  > `hit_cap` records that the loop exited early rather than that an item fell into
  > a bucket.
  >
  > **Nothing to do in the code.** `tools/tests/test_chams_scan_accounting.py`
  > asserts the sum covers every branch, contains no extras, that `unpainted` is
  > still a sub-counter rather than a sibling branch, and that no document keeps
  > recommending the fix — so this retraction is enforceable rather than merely
  > written down. The general lesson is one this file already records three times:
  > **a handoff item that names its own one-line fix is the most dangerous kind**,
  > because it replaces a reader's judgement with an instruction.

**Needs a person, not an agent:**

1. **§2.4 — the remaining transit questions.** Ten of the 24 tags have now
   fired, so most of `CLEANUP_AUDIT.md` §19.8 is decidable. The ISIL reachability
   audit still cannot finish on its own, so the log remains the oracle for the
   rest. Read §19.1 and §19.6c before §19.5 — a claim in each is retracted, and
   §19.8 had a fifth question that is withdrawn.
2. **§1.5's `LoadFromFileAsync` root cause.** The method resolves; the *bundle*
   comes back null. That is a different question from the one §1.5 framed.
3. **§2.2 — `module_paths.h` is the last undeclared cross-project include.**
   `TarkovLauncherBypass/util/compat_profile.cpp` reaches into
   `TarkovAddons/util/module_paths.h`. First-party, header-only, generic. Not
   moved deliberately. Needs a call: a `shared/` root, or leave it and document
   it. Moving it means rewriting 11 include sites.
4. **§3.3 — "decide, don't delete".** `config/MenuSectionValue.h` and the four
   `safety_switch` config entries. Both are format or config-file changes, so
   they need a migration decision rather than a code change. `TA_FRAME` in
   `tracy_bridge.h` was the third and is done.
5. **196 type names exist only in the fresh dump** (`AimingType`,
   `AmbientType`, `AirdropDataPacket`, … absent from all of `ISIL-references/
   IsilDump`). Real differences, unlike the 949 `_NestedType_` names which are
   purely a naming-convention difference. Whether they are new types or a
   different rule for enumerating enums is unsettled. Low priority.
6. **The compatibility profile is shipped but never loaded — FIXED 2026-10-01,
   CONFIRMED 2026-10-02, and it exposed §5.9 which is now SOLVED.** See §5.8 and
   §5.9a. The reader uses the launcher's accessor, the profile loads, and the
   fail-closed path it made reachable revealed that **`GameAssembly.dll` is
   mapped but not in the loader's module list** on some launches — which is why
   `GetProcAddress` returned null for 6 of 14 required symbols with
   `ERROR_MOD_NOT_FOUND`, and why waiting could never have helped. Fixed by
   falling back to a direct read of the export table, cross-validated 6/6
   against an independent parse of the on-disk module.

**Can be done by an agent, no decisions pending:**

7. **§3.7 — `InfoDrawValue`'s default id is `"Info"`.** Two default-constructed
   instances share the config key `Info##Configs`. Harmless today (both write
   empty values, `set()` is inert) but it is the same shape of bug as §13.1, and
   the first value-bearing instance inherits it. Needs an intended id chosen.
8. **§3.4 — two stale comments.** `il2cpp/exports.h` retains build-46221
   offsets for replaced code paths; `EspModule.h` credits commented-out per-frame
   `set_value(false)` calls with enforcing something they no longer do. The
   `EspModule.h` one is inside the frozen optics surface, so it belongs to that
   owner.
9. **Record provenance for `libil2cpp/` in git.** The archive and exact engine
   line are now known (`PROVENANCE.md`), but no commit records the import date or
   the original author's intent for the `Il2CppArray::data` member. Cheapest
   fix is to record archive URL, commit SHA/zip and date **in the next commit
   that touches the directory**.
10. **The PCH is 249 MB.** All 70 consumers mmap it, it is rewritten every clean
    build, and `CppClean` races it. **CLOSED. Keep it, and do not spend effort
    shrinking it: carrying the size costs ~4.7 s against ~171 s of benefit, and
    every reduction on the menu is single-digit MB.**

    > ### MEASURED 2026-10-04 — the premise was wrong about the cause, and the
    > ### size is irreducible and nearly free anyway
    >
    > This item opened by attributing the byte count to `nlohmann/json.hpp`. The
    > 2026-10-01 measurement below correctly refuted the *conclusion* drawn from
    > that (255 → 201.7 MB, not "a few MB") but never established what the
    > remaining 201.7 MB **was**. Now measured, by rebuilding the PCH outside
    > MSBuild with the `Prod|x64` cl line taken verbatim from
    > `x64\Prod\TarkovAddons.tlog\CL.command.1.tlog` — only `/Yc`, `/Fp`, `/Fo`,
    > `/Fd` and the source changed, and the first rung reproducing the shipping
    > artefact at **249.3 MB against 249.4 MB on disk**, which is what makes the
    > ladder attributable to content rather than to flags:
    >
    > | component | MB | share |
    > | --- | --- | --- |
    > | floor (`#pragma once` alone) | 4.0 | 1.6% |
    > | `windows.h` | 19.3 | 7.7% |
    > | `psapi.h`, `shlobj.h` | 5.8 | 2.3% |
    > | the 38 standard headers | 163.3 | **65.5%** |
    > | `nlohmann/json.hpp` | 56.9 | 22.8% |
    >
    > So json is 22.8% — a real cost, and worth keeping, but not the cause. The
    > standard library is 65.5%.
    >
    > **It cannot be made smaller.** Thirty-eight leave-one-out builds — full
    > `pch.h` minus one standard header each — move it by at most **4.7 MB**
    > (`<random>`; then `<deque>` 1.4, `<unordered_set>` 1.1, `<set>` 0.6, the
    > other 34 at ≤0.1 MB = noise). The headers overlap almost completely: each
    > one's cost is the shared transitive closure of locale, allocator and
    > `<xstring>`, so there is no fat header left to cut. `WIN32_LEAN_AND_MEAN` +
    > `NOMINMAX`, the only lever left, is **6.8 MB** (249.3 → 242.5) and
    > re-imports the silent-include hazard `pch.h` deliberately refuses.
    >
    > **And the size is nearly free**, which is the finding that should stop this
    > being reopened. Trivial consumer TU against a 254 / 30 / 4 MB PCH:
    > 0.039 / 0.037 / 0.034 s (median of 7) — **5 ms to carry 250 MB**, ~0.35 s
    > across the 70 consumers, and a floor at that. Plus 4.4 s to write it.
    > ~4.7 s carried, ~171 s earned, **~36:1**.
    >
    > That is also the exchange rate the json result below obeys, which is worth
    > stating because it is not what this item assumed: dropping 57 MB of json
    > saves ~1.1 ms/TU ≈ **0.08 s** of mapping and costs **7.9 s** of
    > re-parsing, ~99:1 against. **PCH size is nearly free; PCH content that too
    > few TUs need is what costs.** Optimise the second, never the first.
    >
    > **The remaining 128 s is somewhere the PCH cannot show.** Front-end only
    > (`/Zs`), PCH already loaded: `CheckboxValue.cpp` 0.19 s, `WorldModule.cpp`
    > 2.30 s, `QuestModule.cpp` 3.27 s, `ModuleManager.cpp` 4.91 s,
    > `menu.cpp` 5.24 s. The light TU is ideal — the PCH erases 94% of its front
    > end (0.19 s vs 3.01 s without) — but the ~35 TUs pulling the module graph
    > still spend 2.3–5.2 s each, on the order of 100 s of the 128 s build. That
    > is the project headers `pch.h` excludes on purpose, so it **never shows up
    > in the PCH's byte count**. If someone wants the next 2×, it is
    > `ModuleManager.h`'s fan-out, not the PCH — a separate experiment, with the
    > hidden-dependency trade stated in `pch.h:13-21`.
    >
    > Harness is scratch and may be gone:
    > `%LOCALAPPDATA%\Temp\opencode\pchprobe\` (`build_arm.ps1`, `consume_real.ps1`).
    >
    > ### MEASURED 2026-10-01 — ANSWER: **keep it. Do not make this change.**
    >
    > Measured on the Windows box, `Prod|x64`, clean `Rebuild`, four clean builds on
    > one fixed source tree (`fc5b1725` + 10 dirty files; all four runs fingerprinted
    > identical), interleaved with/without/with/without:
    >
    > | pair | with json.hpp in the PCH | without | keeping it saves |
    > | --- | --- | --- | --- |
    > | 1 | 127.7 s | 136.0 s | **8.3 s** (6.1%) |
    > | 2 | 132.4 s | 140.0 s | **7.6 s** (5.4%) |
    >
    > Mean **7.9 s, 5.8%**, spread **0.7 s**. Consistent direction, and the two
    > independent pairs agree closely — which is what the determinism claim quoted
    > below exists to make checkable.
    >
    > **Two findings that matter more than the timing.**
    >
    > 1. **Codegen is unaffected.** `.text` is 2,736,128 bytes in *every* run, both
    >    arms. Dropping the include does not change the generated code. That
    >    contradicts the note further down this item that a PCH change perturbs
    >    codegen (measured for PCH-vs-no-PCH as +10,232 bytes): a *smaller* PCH is
    >    codegen-neutral where a PCH's *presence* is not. It also contradicts an
    >    earlier measurement in this item reporting 2759168 vs 2750976, which was an
    >    artefact of another agent editing the tree mid-experiment.
    > 2. **The stated rationale is falsified.** This item predicts the PCH "should
    >    drop from 255 MB to a few MB". It drops to **201.7 MB**.
    >    `nlohmann/json.hpp` is *not* the dominant part of this PCH, so the reason
    >    the change looked attractive does not exist.
    >
    > The `CppClean`/PCH race this item mentions is real but orthogonal. ~8 s is
    > nothing against the 118 s vs 299 s that having *a* PCH is worth, so the PCH
    > itself remains strongly justified and nothing here argues against it.
    >
    > ### The method, because getting it right took four attempts
    >
    > This item was right that pairs must be compared rather than singles, and
    > right about how much noise that takes. It was not sufficient on its own, and
    > three bugs had to be fixed first — each producing a confident wrong answer,
    > which is the pattern this file keeps hitting:
    >
    > - **The tree was not pinned.** Another agent committed twice mid-experiment
    >   (`6e998afe` -> `fc5b1725`, plus three edited headers), and the `.text`
    >   variation tracked *their* edits rather than the configuration. Fixed by
    >   fingerprinting the tree before every build.
    > - **The fingerprint included `pch.h`** — which is the independent variable,
    >   not a confound. So the two arms could never share a group and the guard
    >   could never reach a conclusion. It failed safe, but a guard that cannot
    >   fire is decoration.
    > - **The verdict branch was inverted.** The deltas hold `with - without`, so
    >   a negative value means *keeping* is faster; the code tested `mean > 0` for
    >   "keeping is faster" and printed **"DROPPING is faster"** on data where
    >   keeping was faster in both pairs. Fixed by expressing everything as
    >   `saving`, where positive always means "keeping is faster", so the number
    >   and the sentence cannot drift apart. Negative-controlled: fed data where
    >   dropping wins, it says so.
    > - **Pairing took a Cartesian product.** Two runs per arm produced four
    >   "pairs" that share runs, reported as four agreeing observations, with an
    >   8.7 s spread that tripped a "treat the size as rough" warning.
    >   Index-matched disjoint pairs give 8.3 s and 7.6 s — spread **0.7 s**. The
    >   8.7 s was each run's own noise recombined, and the false alarm was
    >   manufactured by the analysis rather than present in the measurements.
    >
    > Script: `%LOCALAPPDATA%\Temp\opencode\ta_dumps\pch_experiment4.py` (scratch;
    > move it into `tools/` if the method is worth keeping).
    >
    > *Historical note, so the number is not mistaken for a target:* the baseline
    > below as 118 s / 456 MB was measured on a different tree and does not
    > reproduce. Current clean `Prod|x64` with the PCH is ~128-132 s and ~363 MB of
    > `.obj` across 82 files. Compare the arms of one experiment against each
    > other, never across trees.
    >
    > **A "2 warnings" note that was written here and then had to be taken back.**
    > The measurement script reported 2 warnings, which contradicted this file's
    > "0 code warnings" claim, so it was flagged as something to run down. It is
    > nothing: the only warning in the log is `MSB8012`, **already documented as
    > expected and benign in four places** — `WORKFLOW.md:68`,
    > `AGENTS_TODO.md:19`, `Workstream_status_2026-09-24.md:6516`, and
    > `tools/deploy.py:643`, which explicitly tolerates it. The cause is visible
    > in the project file: `<OutDir>$(SolutionDir)out\prod\with_aimbot\</OutDir>`,
    > so the linker writes to `x64\Prod\` while TargetPath says `out\...`, and
    > MSB8012 is exactly that mismatch.
    >
    > The count was also simply wrong: **MSBuild's own summary says 1.** The
    > script counted *lines containing the word "warning"*, and MSBuild prints
    > `MSB8012` once inline and once again in a trailing replay block — so the
    > regex double-counted a single warning. The same regex shape would also
    > match `Warning(s)` in the summary line, or the word inside any filename or
    > message, so both the warning and error counts in that script are soft. The
    > wall-time comparison is unaffected — it never used them.

    > **Everything from here to the end of item 10 is the PRE-FLIGHT, written
    > 2026-09-30 before anything had been measured. It is kept as the record of
    > how the change was scoped, not as advice — do not act on it.** The
    > measurement above it is the answer, and it went the other way. In
    > particular the reasoning below ("the PCH is dominated by json", "should
    > drop from 255 MB to a few MB") is what sent a day of work at a change that
    > costs 7.9 s and saves 0.08 s; json is 22.8% of the PCH, not the cause.

    *The change is one line:* delete `#include <nlohmann/json.hpp>` from the
    bottom of `TarkovAddons/pch.h`. Nothing else needs editing. The users
    already include it directly and have done all along — `EspModule.h:70`,
    `item_pricing.h:16`, `minimap.h:15`, `util/map_editor.cpp:8`.
    (Earlier notes said six and named `i18n.cpp`; that file only *mentions*
    `json.hpp` in a comment. And a fifth, `il2cpp/compatibility_profile.cpp`, is
    listed in several revisions here without including it — grep says **four**,
    re-verified 2026-10-04. The count mattered, and it was the reasoning that
    mis-predicted the win: three of the four are module-graph headers, so the
    real blast radius is every TU that reaches them, which is why removing the
    line cost 7.9 s rather than saving anything.)

    *Already verified, 2026-09-30, on Linux with mingw-g++:* with that line
    removed, all 71 first-party translation units still compile with **0 residual
    error signatures**, i.e. nothing was relying on the PCH to supply it. There is
    also no dead-include cost to chase afterwards. The only thing that measurement
    cannot tell you is the build-time effect, because the compiler is not MSVC.

    *The trade, stated both ways, because it is not obviously a win.* For: the
    PCH is dominated by json, so it should drop from 255 MB to a few MB, which
    removes the documented `CppClean` race — `C1083 ... Invalid argument` on
    `pch.cpp` mid-`Rebuild`, currently needing `Stop-Process cl,msbuild,mspdbsrv`
    and a retry — and shrinks the per-clean-build write. Against: five
    translation units then parse ~25k lines of json each, instead of mmap-ing a
    prepared blob. Which side wins is an empirical question about MSVC, and the
    honest position is that it could go either way.

    *How to settle it:* two clean `Prod|x64` rebuilds, timed, against the
    recorded 118 s / 456 MB baseline. Do it twice each and compare the pairs, not
    the singles — `WORKFLOW.md` records that two clean builds with identical
    settings *are* byte-identical, so a difference that survives repetition is
    real and one that does not is noise. If it is not faster, revert with
    `git checkout -- TarkovAddons/pch.h`; there is nothing else to undo.

    *If it does go wrong,* read `WORKFLOW.md` "The precompiled header — a trap"
    first: both conditions must hold or all 71 TUs fail with C1010, and one of
    them has already cost a day of bisecting.


**Found 2026-09-30 running the verification tooling on Windows, and FIXED the
same day (items 11-15). The full write-up is in the workstream log, but the
reasoning also lives in `tools/verify/README.md` and `tools/harness/README.md`,
which is where the next person will actually look:**

11. **DONE — `tools/verify/audit.py` was comparing nothing on Windows and exiting
    0.** Repo-relative paths came out backslash-separated and went into
    `git show <rev>:<path>`, which is POSIX-only; git's `fatal:` goes to stderr,
    so `git()` returned empty and every pair was skipped. A second defect hid
    behind that one: `text=True` with no `encoding=`, so git's UTF-8 output was
    decoded as cp1251 and raised. Fixed with `as_posix()` twice plus
    `encoding='utf-8', errors='replace'`, and the tool now **exits 2 instead of
    reporting a verdict it cannot support** when it compares zero pairs.
    Result: **58 pairs, 337 `conf()`, 19 identifiers lost** — so the refactor
    did preserve content. The guarantee was real; the checker was inert.
12. **DONE — `tools/deploy.py` `locked()` did not detect a mapped DLL**, the exact
    case its own docstring names. It probed `open(path, 'r+b')`, which *succeeds*
    on a mapped file. It now checks **both** an open-for-write and
    `os.replace(path, path)`, because each catches one case and misses the
    other: a mapped image refuses rename but allows the open, a read-only file
    refuses the open but allows the rename. A first attempt at only the
    `os.replace` probe regressed `test_readonly_file_is_locked`, which is how the
    one-sidedness was caught. Both probes are non-mutating — verified, content,
    length, mtime and hash are all identical afterwards.
13. **DONE — `confirm()`'s no-terminal guard was defeated on Windows.**
    `sys.stdin.isatty()` is **True** for a redirected stdin such as `< nul`. EOF
    is now treated as `DeployError`, so the command exits 1 with the `--yes`
    hint instead of exiting 0 on a silent no-op. `KeyboardInterrupt`
    deliberately stays an ordinary "no": a person pressing Ctrl+C is answering,
    not reporting a broken terminal.
14. **DONE — the vacuous tests assert something now.** The lock tests take a
    genuine lock: a Win32 handle opened with `dwShareMode=0`, plus a new
    `test_mapped_module_is_detected` that maps the file the way a loaded module
    is mapped, which is the case that actually regressed.
    `test_msbuild_not_found_exits_1_through_main` now calls `deploy.main(argv)`
    in-process, because its patch could never reach the subprocess it spawned.
15. **DONE — the harness reports throws instead of dying to them.**
    `try_parse` / `want_ok` / `want_rejected` make the parse result tri-state, so
    a `stoi` regression is **8 named failures and exit 1** rather than
    `0xC0000409` with no output at all. 41 assertions, was 33.

Suite was **97 passed, 6 subtests, 0 failed** at the time (was 90 passed / 4
failed); it is **220** now — see the count reconciliation at the top of this file.
Every fix is negative-controlled: each new test was shown to fail against the old
behaviour before being shown to pass against the new.

**Do not touch:**

- **§3.2 — the ESP / optics surface WAS frozen; the freeze was lifted 2026-10-13** and
  the `[CLEANUP-PENDING:OPTICS]` markers are removed (`module/impl/EspModule.h`,
  `esp_text.h`, `quest_esp.h`, `skeleton_visibility.h`, `il2cpp/unity.h`). The items
  themselves are unchanged and still open: 16 `dual_active` branches, the triple
  `#include` of `FloatSliderEditableValue.h`, and the stale `set_value(false)`
  comment — all now ordinary cleanup candidates, none actioned (see the dated note
  at the top of this file).
- **§3.1 — `injector.cpp` — was "two memory-corruption bugs, do not touch"; now
  one fixed and one retracted.** The `CloseHandle` on a module base address was
  real and is gone. The `Flink + FIELD_OFFSET(...)` claim was **wrong**: both
  offsets are 0, measured, so those expressions *were* `CONTAINING_RECORD`. Line
  68 was never that pattern at all. Two `static_assert`s pin it. Read §3.1 before
  repeating either claim.
- **§4 — decided, do not relitigate.** The two `compat_profile`
  implementations must not be merged; neither project directory is self-contained.

---

Verification status: **`Release|x64` and `Prod|x64` now build on MSVC.** All
twelve remaining x64 configurations (4 each for `TarkovAddons`,
`TarkovLauncherBypass`, `vk_swiftshader`) compile and link with zero errors, both
via `TarkovAddons.sln` and per-project. The caveat below was true when this file
was written and is now obsolete; it is kept as the record of what that pass
could and could not establish. Header resolution, language features, overload
resolution and MSBuild item paths were all confirmed, and are now confirmed
directly. What a successful build does **not** establish is any runtime
behaviour: §1.2, §1.3, §0 and §1.5 all still await an in-game launch. See
`WORKFLOW.md` for the build and deploy procedure.

Two build-only defects were surfaced by actually building, which is the argument
for doing it rather than reasoning about it:

- `gui/menu/menu.cpp` carried `static const unsigned char menu_background_png[];`
  — a definition of incomplete array type with no initializer, which is
  ill-formed in C++. It was the leftover of deleting `menu_background_bytes.inc`
  in `9b779eb3`, and nothing referenced it.
- All four Win32 configurations of `TarkovLauncherBypass` were failing with C2039
  on `CONTEXT::Rip`, which exists only in the x64 `CONTEXT` layout. Those
  configurations were dead and are now deleted rather than repaired (§3.5).

---

## 0. Confirmed crash — **FIXED in code, awaiting one in-game launch**

> **Status: both fixes are in the tree, and the tree builds and deploys.**
>
> - The four calls in `production_panel_probe.h` now pass `&orig` /
>   `&orig_update_views_async_movenext` (`install_one` takes `Il2CppObject*& orig`
>   and forwards `&orig`; the async MoveNext passes its own address).
> - **`il2utils::hook_method` now takes `T2* original`, not `T2 original`, with a
>   `static_assert`** naming the exact mistake: *"the trampoline slot must be
>   passed as its ADDRESS, e.g. &o_foo. A bare function pointer is dereferenced
>   here and writes through nullptr on first install."* That is fix (b) — the
>   unfailable contract — not (a), so the trap is disarmed for the next caller
>   rather than merely fixed for this one. Taking it by reference was tried and
>   reverted because it fails to compile at all ~50 correct call sites; `T2*`
>   binds the prvalue by value and keeps the discrimination.
>
> **Not yet confirmed at runtime.** The cause is fixed in code; nobody has
> relaunched to prove the null write is gone. See §1.2/§1.3 — a launch is the
> outstanding check for this and several other things.
>
> **`util/crash_probe.h` is RETAINED as a standing diagnostic — DECIDED, not
> an open question.** The code fix is in, but the probe stays, for reasons that
> have nothing to do with the bug it was written for: **this project builds no
> standalone executable, so there is no harness that can re-run a fault on
> demand, no test that reproduces one, and no debugger attached to a live raid.**
> A fault happens once inside a third-party process and dies with it. It is
> read-only on every path (returns `EXCEPTION_CONTINUE_SEARCH` for every real
> fault; since 2026-10-10 the one thing it consumes is the debugger's own
> `0x40010006`/`0x4001000A` print family while a debugger is attached — where a
> machine delivers those raises as exceptions, that is what stops WinDbg
> answering second-chance on every call, and the measured delivery models are
> asserted in `tools/harness/test_debugger_gate.cpp`).
>
> **The stated reason for keeping it was WRONG, and was corrected 2026-10-03.**
> This section used to say *"WER is disabled machine-wide, so this VEH is the
> only thing in the tree that can explain a crash."* WER was re-enabled on
> 2026-10-03 and is no longer disabled. The conclusion survives anyway, for a
> sharper reason: **WER reports the faulting module, the fault offset and the
> thread, but not `EXCEPTION_RECORD::ExceptionInformation[1]`** — the address
> that was actually unreadable or unwritable. That single field is the whole
> difference between "somewhere in here" and a diagnosis, and it is the field the
> probe prints first. WER coming back moves the burden onto the probe rather than
> retiring it. There is still no minidump either; see below.
>
> ### 2026-10-03 10:35:14 — the probe was killing the process it was watching
>
> WER came back and caught a crash for the first time in a month. It was **inside
> this probe**:
>
> | | |
> |---|---|
> | exception | `0xC0000005` (ACCESS_VIOLATION) |
> | address | `TarkovAddons.dll+0x50DA1` (WER fault offset `0x7FF866C60DA1`, module `unknown` — manual map) |
> | thread | `0x4A30` = 18992, the process **main** thread |
> | symbol | `crash_probe::fill_event+0x41` = `call qword ptr [rip+0x266319]` → `__imp_GetCurrentThreadId` |
>
> `handler()` ran the capture *before* the report. `fill_event`'s prologue costs
> 152 bytes (3 pushes + `sub rsp,0x80`); its last successful store is at entry−32
> and the faulting `call` pushes at entry−160, so under 160 bytes of stack were
> left on that thread. On x64 a `call [mem]` pushes before loading its target, so
> the push is what faulted — not a corrupt IAT slot. `GetCurrentThreadId()` was
> working fine; `logger.cpp:82` calls it on every single log line.
>
> A fault inside a VEH is **not catchable**: Windows runs no further vectored
> handler, finds no `__except`, and calls neither the unhandled filter nor
> `std::terminate`. The process dies on the spot. So **every** fatal fault on a
> stack-starved thread was being destroyed by the probe, silently, and "no CRASH
> lines in the log" was never evidence of a clean run.
>
> Three fixes, all in `util/crash_probe.h`, all proved by `tools/probe_test`
> (23 checks, exit 0):
>
> 1. **Order.** The cheap half of a capture now runs first and unconditionally
>    (fields only, no import call, no stack walk, ~20 bytes of stack). The
>    expensive half — tid and frame walk — runs after it inside an SEH guard. The
>    report runs after that, so it runs whether or not the enrichment survived.
> 2. **`emit()`'s 1 KB line buffer** moved off the stack onto one static buffer
>    (`g_emitting` already serialises `emit`, so it needs no lock).
> 3. **`in_executable_section()` passed a null `ImageBase`** to
>    `RtlLookupFunctionEntry`, which makes it walk the PEB loader list to find
>    our own module. **That walk faults from inside a VEH** — measured, not
>    reasoned. It also could not have worked: a manual-mapped image is not in the
>    loader lists at all, so every one of our return addresses was being counted
>    as a *data word* instead of a frame. `g_base` is now passed, which is both
>    correct and one `.pdata` search instead of a linked-list walk.
>
> `tools/probe_test` also grew a `smallstack` case, because every case it already
> had faults on a thread with a **healthy** stack — which is why the suite was
> green while the shipped DLL was fatal. It asserts the process still dies with
> `0xC00000FD`, the *original* fault, rather than `0xC0000005`, the probe's.
>
> **Still unknown: what caused the original fault.** The outer exception's code
> was never named and cannot be recovered from the WER record. Stack exhaustion
> on the main thread is the leading hypothesis and is consistent with everything
> observed, but it is a hypothesis. To settle it, run
> `tools/enable_localdumps.ps1` **as Administrator** (needs HKLM; it writes no
> game behaviour, only post-crash files) and launch once. A minidump carries
> `ExceptionInformation[1]` in its exception stream. If it turns out to *be* a
> stack overflow, switch `DumpType` to `2` — minidumps capture only a limited
> stack, which is precisely what that case needs and lacks.
>
> **The TEMPORARY banner and its "remove once the crash is fixed" instruction
> have been reworded**, since that instruction was the actual hazard: it
> invited the next reader to delete a working diagnostic on the strength of a
> comment, at exactly the moment it stopped being needed by the crash that
> justified it and started being needed by the one that has not happened yet.
> See `util/crash_probe.h` and the `dllmain.cpp` arming comment.

The original analysis, for the record:

**Null-pointer write in `module/production_panel_probe.h`, `production_panel_
install()`.** It was being misread as a chams asset-bundle failure for several
sessions because the two run in the same `ModuleManager` dispatch.

`il2utils::hook_method`'s last parameter is taken **by value** and is meant to be
the *address* of the caller's orig-pointer:

```cpp
template <typename T, typename T2>
void hook_method(const Il2CppClass*, const char*, int, T hook, T2 original)
{ ...
  *reinterpret_cast<void**>(original) = reinterpret_cast<void*>(trampoline); }
```

Every other call site passes `&o_...` (`common_hooks.h:195`, `always_on.h:1647`),
so `T2` deduces to a pointer-to-pointer and the store lands in the caller's
variable. The four calls in `production_panel_probe.h` omit the `&`, so `T2`
deduces to the *function-pointer type* and `original` holds the **value** of
`orig_show_contents` — `nullptr` on first install. `reinterpret_cast<void**>` on
a function pointer is legal on x64, so it compiles silently and the store becomes
`*(void**)nullptr`.

Evidence — minidump `CrashDumps\EscapeFromTarkov.exe.1032.dmp` (2026-09-28
21:26:26), parsed at `TarkovAddons.dll + 0xEBA90`:

```
code        : 0xC0000005  ACCESS_VIOLATION
==> WRITE violation, offending address 0x0000000000000000
```

The stack walk of the same dump shows the faulting frame and its caller both in
`TarkovAddons.dll`, in a `hook_method` instantiation. *(This section is the
original 2026-09-28 analysis, kept for the record. WER was disabled machine-wide
then, so the dumps in `%LOCALAPPDATA%\CrashDumps` were the only post-mortem
artefact available. WER was re-enabled on 2026-10-03 — see the note at the top of
this section for what that changed, and for why it did not make the probe
redundant.)*

Two fixes, and the second is the one worth taking:

- **(a)** add `&` to the four calls, or
- **(b)** make the contract unfailable — take `T2& original`, or an explicit
  `void** original`, so a bare function pointer stops compiling. (a) leaves the
  same trap armed for the next caller.

`util/crash_probe.h` is the vectored-exception diagnostic that located this: it
only reads and searches every real fault (`EXCEPTION_CONTINUE_SEARCH`), so it
cannot change behaviour. See the status block at the top of this section.

---

## 1. Blocking — verify before trusting any of it

**1.1 ~~Build both projects for real.~~ — DONE for x64.** All twelve x64
configurations build. The specific risks the old §1.1 listed are resolved:

- `TarkovAddons.vcxproj` `ClCompile`/`ClInclude` entries pointing at
  `..\external\safetyhook\` and `..\external\nlohmann\` resolve and compile.
- The `$(MSBuildThisFileDirectory)..\external` entry in
  `AdditionalIncludeDirectories` is load-bearing and present in all four
  configs; the four `<nlohmann/json.hpp>` sites build.
- `/bigobj` and `stdcpp23` are both genuinely required and both set.
- The x86 question is closed by deletion rather than repair — see §3.5.

**1.2 Smoke-test the bypass launch path at runtime.** The hook install path was
rewritten end to end, not just cosmetically: `DetourAttach` → `SafetyHookInline::create`,
transaction handling removed, and `disabler::exit()` now detaches *both* hooks
(the old `DetourDetach` only ever removed `CreateProcessInternalW`). Confirm a
real launch still works: game process created via the `CreateProcessInternalW`
hook, parked at its entry point, patches applied, launcher reports a PID. The
`"CreateProcessInternalW hook installed"` and `"CreateProcessW hook also
installed"` log lines are the signal.

**1.3 Smoke-test the §8 RCDATA asset path.** The mechanism had a real defect and
is now fixed — see `CLEANUP_AUDIT.md` §16. `pe_resource::rcdata()` was called with
`self_module = nullptr` by both `util/i18n.cpp` and `module/minimap.h`, so its
Win32 fallback searched the **game executable** rather than the mod, and RCDATA
never worked at all; on-disk copies in `ta\lang`, `ta\maps` and the deployed
background PNG hid it completely. `rcdata()` now resolves the module from the code
address. **15/15 executed assertions** against the real built DLL, mapped the way a
manual mapper would, including byte-identical payload checks.

Still to confirm in-game, and now genuinely worth confirming because a bare DLL
drop is the only configuration where the fix is observable:

- `"Built-in minimap assets unpacked: … (22/22 files)"` — this line was never
  going to appear before, so its *first* appearance is the proof;
- deleting `ta\maps` and `ta\lang` from a copy of the deployment and confirming
  the minimap and the translations still work, since that is the scenario the
  RCDATA mechanism exists for and the one the on-disk copies were masking;
- the i18n failure diagnostic should now be unreachable in normal use. If it ever
  fires, cause 3 in that message (a manual mapper that relocates or discards
  `.rsrc`) is now the only realistic one, and the message says so.

**1.4 Verify the `ta/configs/` move on a real install — CLOSED by harness.** Was
"largely closed" with the unwritable-deployment path still outstanding; it is not
any more. The migration and the read-path fallback chain are covered by
executable coverage driving the real code against real directories — the
`module_paths.h` half in `tools/harness/test_module_paths.cpp` (27 assertions)
and, since `data_migration.h` became `tools/migrate_legacy.py`, the migration's
nine scenarios in `tools/tests/test_migrate_legacy.py` (42 cases). See
`CLEANUP_AUDIT.md` §11.4 for the original scenario table. What is pinned down
includes the case that mattered most: a 3.2 config is found **even when the move
never happens**, because `load_config()` reads `ta/<config>` as a fallback rather
than depending on the migration.

The unwritable-deployment path (`ensure_config_directory_wide()` returning
`ta/`'s own fallback) was previously called unprovable without "a genuinely
read-only install". It is reachable by making `ta` a **regular file**: `is_directory`
is then false and `create_directories` fails with an error, which is the same
branch. Stated precisely: that is a different failure mode from an ACL denial,
and the two are not the same path through the filesystem.

Not covered anywhere: running against a deployed `TarkovAddons.dll`, so a
packaging regression is still not caught. That is the gap that let §5.8 ship.

Earlier text for the same section, kept for the record:
  `ta/`'s own fallback), which is reasoned about but not exercised — it needs a
  genuinely read-only install to provoke.

**1.5 Chams bundle — the null-method crash is fixed, the runtime failure that
followed is also fixed, root cause included.** The crash-on-`Loading Asset Bundle`
diagnosis below was correct and the fix works: `LoadFromFileAsync` resolves and
returns a request. What came next was worse — the request completes and
`get_assetBundle()` returns null, forever, polling at 46/second and writing 85% of
the log — and the cause was not an offsets/pattern problem at all but a leaked
AssetBundle registry entry (`reset_bundle` never called `Unload`) plus a `bool`
return that could not distinguish "still loading" from "finished with no bundle".
Both fixed 2026-10-01; see the standing-questions entry above for the mechanism.
The original analysis follows.
`Loading Asset Bundle` turned out to be two things, both now addressed in
`CLEANUP_AUDIT.md` §18: the bundle was the last piece of mod data still living
at `%APPDATA%\TarkovAddons`, and `data_migration` was filing it under
`ta\configs\` as if it were a settings file. It now lives at
`ta\chams\tarkovutils` via `module_paths::chams_bundle_path()`.

The crash itself was **not** the migration: `start_load()` called a resolved
method pointer without a null check, and `il2utils::get_method` returns null
whenever a game update breaks resolution — a call through a null pointer, with
`Loading Asset Bundle` as the last line ever logged. Every path now logs its
cause, cleans up the staged file, and leaves chams off **without** reporting
success (a null `get_assetBundle` previously logged "Loaded Asset Bundle" and
returned true, so every consumer then treated a null bundle as valid). Failed
attempts back off 5 s instead of retrying per frame.

> **The last paragraph of the original entry was wrong on its premise and is
> retracted.** It read "the reason the game's `LoadFromFileAsync` stopped
> resolving is not diagnosed". It does resolve — 18 `LoadFromFileAsync returned a
> request` traces per session, no `FAILED` line, and the method is called through
> successfully. The open question is one step later: the request completes and
> `get_assetBundle()` returns null. So the failure is not an offsets/pattern
> problem at all, which reclassifies it from "outside the cleanup scope" to a
> live defect in the chams reload path. A diagnosis that named the wrong link in
> the chain would have sent the next reader to a pattern scan instead of to
> `asset_bundles.h:1362`.

**1.7 The PCH refactor did not build — FIXED, and it does pay for itself.**
`29a4c413` *Add a precompiled header* set `<PrecompiledHeader>Use</PrecompiledHeader>`
and gave 12 translation units an include, spelled `#include "../pch.h"`. That
does **not** satisfy MSVC's `/Yu`. `/Yu"pch.h"` matches against the *literal*
name in the flag, not the resolved path, so a file including `../pch.h` counts
as never having included the PCH and fails with **C1010 at end of file** — 68 of
71 first-party `.cpp` files, i.e. the whole project. `TarkovAddons.pch` was being
produced correctly (255 MB) and nobody was finding it.

The evidence is exact: of 71 first-party `.cpp` files, the only two using
`#include "pch.h"` — `dllmain.cpp` and `pch.cpp` — were the only two that
compiled. The 9 using `"../pch.h"` and the 60 with no include at all all failed.

Two-part fix, both applied:

1. `$(ProjectDir)` added to `AdditionalIncludeDirectories` in all four
   configurations. Without it a bare `"pch.h"` cannot resolve from `config/` or
   `module/impl/` — the list held only `..\external` and three `external/*`
   subdirectories, which is presumably why the relative spelling was reached for
   in the first place.
2. All 71 first-party `.cpp` now say `#include "pch.h"` as the **first** line.
   The two `gui/*/` files had used `../../pch.h` and were left holding a
   redundant duplicate once the correct line went in; removed.

**Measured benefit — the refactor is worth keeping.** Clean `Rebuild` of
`TarkovAddons.vcxproj` `Prod|x64`, 12 cores, same machine, back to back:

| | wall time | total `.obj` |
| --- | --- | --- |
| with PCH | **117.7 s** | **456 MB** |
| without PCH | **298.7 s** | **889 MB** |

A 2.54× speedup, and intermediate output halved. First measurement of the
"without" case was a false 118.1 s: `/p:PrecompiledHeader=NotUsing` on the
command line is **silently ignored**, proved by byte-identical `.obj` totals
(478,282,770 across 82 files). It has to be disabled in the project file.

Two costs, both real, neither fatal:

- The PCH is **249 MB**. Each of the 70 consumer processes mmaps it. It is written
  fresh on every clean build, and `CppClean` races it — a `cl.exe` still holding
  it produced `C1083 ... Invalid argument` on `pch.cpp` mid-`Rebuild`.
  **The "trim `json.hpp` out of the PCH is the obvious next win" that used to end
  this bullet is retracted:** measured twice now. It is 56.9 MB of 249.3
  (22.8%, the standard library being 65.5%), removing it *costs* 7.9 s, and
  thirty-eight leave-one-out builds show every other header is worth ≤4.7 MB.
  Carrying all 249 MB costs ~4.7 s against ~171 s of benefit. See item 10.
- **The PCH changes the generated code.** `.text` is *not* byte-identical with
  and without it, and the PCH build is 10,232 bytes larger (vsize 2,525,585 vs
  2,515,353, +0.41%). Before reporting that as a defect, the control: two
  clean builds with identical settings are byte-identical, so the build *is*
  deterministic and the difference is attributable to the PCH rather than to
  build noise. A PCH is a codegen-affecting optimisation, not a
  semantics-preserving transform, so this is expected — but it does mean a
  PCH build is not the same binary as a pre-PCH one, and any in-game
  behavioural difference now has this on the list of suspects.

**1.6 Engine version behind `il2cpp/libil2cpp/` — MOSTLY RESOLVED.**
**Verified: 2022.3.43f2 (d42a179a7d86)**, read from the `UnityPlayer.dll`
`VS_VERSION_INFO` of the live install. The publicly reported version is
**2022.3.43f1**; the binary says f2. Written up in the new
**`TarkovAddons/il2cpp/PROVENANCE.md`**, together with the manifest validation
and the two adjacent questions below.

Note `boot.config` **cannot** answer this on this install — it has no
`unity-version` key, so the "one grep, decisive" route does not exist here and
the version resource is the working source, not the fallback.

The suspect manifest row is **withdrawn — the manifest is right and the
inference was wrong.** It flagged `UnityPlayer.dll` `pe_timestamp`
`0x693FDD26` (2025-12-15) as impossible ~16 months after 2022.3.43f1 shipped.
PE `TimeDateStamp` is stamped at *link* time, so it records when Battlestate
built the player, not when Unity cut the engine release. All three manifest
fields were then re-derived and **all six values match exactly**
(`pe_timestamp` ×2, `text_sha256` ×2, `size` ×2). Two undocumented conventions
were recovered by measurement, both now recorded in `PROVENANCE.md` because
each is easy to get wrong: `size` is `SizeOfImage`, **not** the on-disk file
size (they differ by 2.8 MB / 0.99 MB), and `text_sha256` is the raw `.text`
on-disk bytes, not `VirtualSize`.

Two claims in the old §1.6 needed correcting, one of them mine:

- `global-metadata.dat` is **encrypted as shipped** — first 8 bytes are
  `38 F4 41 03 7C 14 3B 94`, not `AF 1B B1 FA` + version, and the encryption
  covers the whole file: zero shared bytes with the decrypted copy in either
  prefix or suffix, so there is no plaintext island to read. I first wrote the
  version "31" off as *unverifiable*, and that was wrong. It **is** 31, verified
  from the decrypted copies in `GameDump/` — `115147510`, `115047473` and
  `110146911` all report magic `0xFAB11BAF` and version 31. The shipped file is
  27831348 bytes, exactly the length of `GameDump/115147510`, the build the
  manifest describes. Corroborating rather than conclusive, since no byte of the
  two can be compared.
- The `IsilDump`-is-older claim rested on `AFKMonitor` being "only in the fresh
  dump". It **is** in `IsilDump` (3 files). The 72.3% overlap is a **naming
  artifact**: 100% of the 949 `IsilDump`-only names contain `_NestedType_`, and
  the fresh `DiffableCs` dump has zero nested-type entries. It measures a
  convention, not build age.

**Also answered: are the vendored headers the right version? Yes — the upstream
is `js6pak/libil2cpp-archive`, and our copies match it exactly.** Identified by
declared-type-set comparison, which survives the C→C++ conversion but would
differ between Unity versions. Across the six files both sides produced 22
apparent differences and **all 22 are extraction artifacts**: 7 are struct
members present in both (`__klassIndex`, `typeIndex`, `klass`,
`methodDefinitionIndex`, …) and 15 are upstream function-pointer typedefs whose
name the C-side pattern misses, because `typedef … ?\b(\w+);` captures the
parameter of `typedef void (*Name)(Arg);` rather than `Name`. Type sets are
identical. The conversion plus `#pragma once` and added commentary is why our
files are larger than upstream; a whole-file hash could never have matched.

**The specific commit is immaterial, and that was measured rather than assumed.**
`8613ac1` is labelled **2022.3.40 (v31)** and `c3b25fa` is **2022.3.48 (v31)**.
**All six generated headers are byte-identical between them** (FNV-1a, 6/6, same
lengths). Neither commit touches a generated header — both change only `codegen/`
and `vm/Field.*` runtime source, which this project does not use. So there is no
"more suitable" commit of the two; pick either.

Two things this does **not** settle, both recorded in `PROVENANCE.md`:

- ~~Whether the headers match our exact engine version.~~ **Now settled.**
  `unity.bepinex.dev/libil2cpp-source/` (where js6pak's CI publishes) has a
  per-version archive, and `2022.3.43.zip` is extracted to
  `TarkovAddons/GameDump/2022.3.43/`. Compared per-struct — **ordered member
  sequences**, which is layout-sensitive in a way the type-name check was not —
  **112 of 113 structs match member-for-member**, and all six file sizes are
  identical. So the headers are verified against the exact line the game reports
  (2022.3.43f2).
- **The one divergence, and it is a trap.** `Il2CppArray` in our copy has an
  extra `void* data;` that upstream does not — verified against 2022.3.43, which
  ends the struct at `max_length`. It is deliberate and safe, checked two ways:
  all ~70 call sites spell element 0 as `&arr->data` and never dereference
  `data`; and the resulting `sizeof` of 48 vs upstream's 40 is used only as the
  length argument to `is_readable_address()`/`readable_range()`, i.e. strictly
  more conservative, never an element offset. **It had no comment at all**, in a
  vendored header, which is exactly how a later reader deletes it as an
  accidental difference and breaks every one of those call sites. It now carries
  a comment; comment-only, no code changed. Do not "fix" it by removing it.
- **No commit in this repository records the import.** `bb8615f1`
  *TA_Reloaded_2.0_Base* is a bulk import with no provenance message, and
  `aa64917b` is a `<stddef.h>` cleanup. The archive and the exact entry are now
  known from the comparison above, but the *date* and the original author's
  intent for the `data` member are not on record. Worth fixing as a process
  item: record archive URL, commit SHA and date **in the commit that vendors
  third-party code**, so this never has to be re-derived.
- The structural version test still cannot be run: the six files are a partial
  subset (176 type declarations) and `Il2CppTypeDefinition` is not declared at
  all, so there is no vendored struct to lay over the real metadata table. The
  per-struct member comparison is what substitutes for it.

The build-id/"directory mismatch" is also **dissolved**: `GameDump/` names carry
no separators and nine digits decode `1|1|5|X|YYZZZ`, so `115147510` *is*
`1.1.5.1.47510`, matching the manifest.

**Still open in this section:**

- The **upstream archive** the six headers were vendored from is still
  unidentified. `libil2cpp/` arrived in `bb8615f1` *TA_Reloaded_2.0_Base*
  (2026-08-22) with a message recording no provenance; `aa64917b` is a
  two-file `<stddef.h>` cleanup, not a derivation. This is the only claim in
  `PROVENANCE.md` that is not established, and it is the next thing to fill in.
- 196 top-level type names exist only in the fresh dump (`AimingType`,
  `AmbientType`, `AirdropDataPacket`, … absent from all of `IsilDump`). Real
  differences; whether they are new types or a different enum-enumeration rule
  is unsettled.

---

## 2. Follow-ups from the dedup — known, not blocking

**2.1 ~~`TarkovAddons/lib/detours.lib` (844 KB) is still on disk.~~ — DONE.**
Deleted in `9b779eb3` along with `lib/d3dx11.lib` (also linked but never called
from anywhere), which empties `TarkovAddons/lib/` entirely.

**2.2 `module_paths.h` is the last undeclared cross-project include.**
`TarkovLauncherBypass/util/compat_profile.cpp` includes
`"../../TarkovAddons/util/module_paths.h"`. The file is header-only, all
`inline`, and generic — resolve your own DLL's on-disk directory, cached at
attach before anti-cheat LDR hiding — so it is a shared utility filed in the
wrong place. It was deliberately *not* moved: it is first-party, so it does not
belong in the third-party `external/`, and moving it means rewriting 11 include
sites. Needs a decision: a `shared/` root, or leave it and document it.

Note its `GetModuleHandleW(L"TarkovAddons.dll")` fallback is **dead in the
launcher** (TarkovAddons.dll loads in the *game* process, so the call returns
null and the chain falls through). Harmless — both DLLs ship in the same folder
— but dead.

**2.3 `spoofer.cpp` x86 calling-convention mismatch (pre-existing) — now MOOT.**
`oGetFn` and `oGetSystemFirmwareTable` are declared with no calling convention
(`__cdecl`) while `hkGetFn` / `hkGetSystemFirmwareTable` are `__stdcall`, so on
an x86 stack the callee cleans up bytes the caller also expects to clean. The
Detours → SafetyHook migration was *neutral* here: both hand back a trampoline
and the call goes through the same cdecl-typed pointer.

**No longer reachable.** §3.5 deleted the bypass's four `Win32` configurations,
so there is no x86 build of this DLL and no cconv mismatch on the only platform
that has one. The mismatch is still in the source, so it returns the moment an
x86 configuration is added back. Fix, if it ever is needed: add the convention
to the two pointer typedefs.

**2.4 The Always-On transit hooks — nothing archived, one bug fixed, audit
incomplete. Full write-up in `CLEANUP_AUDIT.md` §19.**

`module/always_on.h` registers 24 hooks. An ISIL pass over
`ISIL-references/IsilDump/` mapped what `LocalTransitController.Transit` actually
does (synchronous, zero network calls, §19.3) and produced verdicts for all 24
(§19.5). Outcome:

- **Fixed.** `hk_local_raid_started` was a **no-op**. `LocalRaidStarted` is the
  RPC *request*, not the response, so both of its settings writes ran before the
  fields existed: `configure_pve_location` early-returned on a null location, and
  the `keep_original_server_id` `""` write was overwritten 90 ISIL later. The
  "blank the server id" toggle did nothing at all. Moved into
  `apply_local_raid_settings_after_rpc`, called from `hk_local_game_create` and
  gated on `selectedLocation != nullptr`. §19.6.
- **Retracted.** `hk_try_get_location` is *not* the wrong method and must not be
  archived. `ProtectedLocation` passes `TransitPoint.parameters.target` to it, so
  it resolves the transit destination — just from a different caller than
  `LocalTransitController.Transit` does. §19.1.
- **The method cannot finish the job.** The ISIL dump is not a call graph: it
  misses unnamed interface/virtual thunks (`LocalRaidStarted` greps as zero call
  sites while being invoked via `IEftSession` slot 62), misses delegate
  invocation (`HandleFinishedTask` greps as 2 calls but runs through a
  `.cctor`-cached delegate) and misses reflection. Every "N call sites" figure
  is a lower bound. §19.2.
- **So nothing was archived.** Ten hooks (10–20) are diagnostics-only — they log
  and call the original, so they cannot change behaviour — and 24 is the only
  hook with a shadowing argument (hook 23 returns `false`, which short-circuits
  the `||` in `MatchmakerOperation.Ready`). But the labels in these dumps are not
  resolved, so the branch direction behind that one is inferred, not proven. All
  of it waits on station logs. §19.8 lists the four questions.
- **Retracted again, after I wrote it up as the most promising lead.** I claimed
  `LocalTransitController._localRaidSettings` was a **pre-RPC snapshot** that
  "diverges in exactly the three fields the fix writes", and filed "is transit's
  settings stale?" as §19.8 question 5. It is the same object end to end —
  `TarkovApplication._localRaidSettings` → `LocalGame.Create` param 18 → game
  instance `0xE8` → controller ctor param 4 — proven from raw disassembly, not
  inferred. Independently, the field sets are disjoint: `Transit` reads only
  `mode` and `timeVariant`, and the RPC and the fix write neither. §19.6c.
- **The raw `Disassembly:` sections are usable after all.** I had recorded them as
  truncated on the strength of a bad measurement — comparing raw instruction
  lines against ISIL indices when a median 76.5% of ISIL lines are `Nop`.
  Corrected: 98.19% of methods carry a complete raw section. That is what
  §19.6c is built on, it recovers stack-passed arguments the ISIL annotator
  garbles, and it means §19.7's inferred branch direction is *confirmable*
  rather than permanent. Not yet done. §19.2.
- **A `TransitController` cannot usefully be forced.** There are exactly two
  construction sites (one per concrete leaf) and `GameWorld.TransitController` is
  publicly settable, so it looks possible. It is not: `Transit` dispatches
  through each `TransitPoint`'s own `<Controller>` reference (24 read sites,
  zero in-class writes), so a swapped `GameWorld` controller would be inert; a
  second instance double-subscribes `ItemController.add_AddItemEvent` and the
  orphan is never disposed; and the 4-arg constructor needs a
  `TransitParameters[]` nothing publishes. Do not. §19.9.
- **One fragility worth a decision, no bug today.**
  `hk_start_online_transit_matching` **swallows the original** and returns
  without calling it. It is safe only because `hk_is_local_transit_hop` forces
  the branch in `Run d__201` away from it. If a dispatch the dump cannot name
  ever reaches it, the mod silently eats a live `StartOnlineTransitMatching` and
  the client parks. Converting it to "log loudly, then call the original" costs
  nothing and removes the dependency on hook 9 landing correctly.

Coupling to know before touching 10–20: `g_last_ta` has nine writers, but hooks 7
and 8 write it too, so the two hotkey actions `debug.dump_ta_state` /
`debug.force_save_status` survive archiving the rest. `always_on_deprecated.h`
remains the archive target for anything that does get retired; the 24-registration
count invariant documented in its header must be updated with it.


---

## 3. Pre-existing, not from this change

**3.1 `injector.cpp` — ONE real bug, fixed 2026-10-05; the other claim RETRACTED.**
This said "two memory-corruption bugs, deliberately untouched". One is a real
defect and is now fixed. The other was never a bug, and the reason it survived
being carried through `CLEANUP_AUDIT.md`, this file, `AGENTS.md` and several
sessions is the reason it is worth writing down.

- **`CloseHandle(found_module)` — REAL, FIXED.** `found_module` is
  `reinterpret_cast<HMODULE>(me32.modBaseAddr)`, a module **base address**, not a
  handle; the only handle in scope is `snapshot`, already closed above. So it was
  a wrong-type call that fails with `ERROR_INVALID_HANDLE`. Harmless in practice
  because module bases (0x00007FF8_xxxxxxxx) cannot collide with this process's
  small kernel handles — the real cost was clobbering the thread's last-error for
  whatever ran next. Deleted.

- **`Flink + FIELD_OFFSET(...)` — RETRACTED, it was never a bug.** Measured, not
  argued: `offsetof(LDR_DATA_TABLE_ENTRY, InLoadOrderLinks) == 0` and
  `offsetof(LIST_ENTRY, Flink) == 0`, both evaluated, and the two expressions were
  computed on the same `LIST_ENTRY` and **printed the same pointer**. `InLoadOrderLinks`
  is declared first (`libs/ntdll.h:1982`), so `Flink + FIELD_OFFSET(...)` *is*
  `CONTAINING_RECORD(...)`. Rewriting it would have produced identical code behind
  a different-looking diff — the worst outcome for a finding this load-bearing.

  Two `static_assert`s now pin both offsets, so the claim is checkable at build time
  instead of carried. Same reasoning as `hook_method`'s `T2*` assert: make the trap
  unfailable rather than fix it once.

  **Line 68 was never even the pattern the audit described.** It is
  `pbi.PebBaseAddress + FIELD_OFFSET(PEB, Ldr)` — no `Flink` on it, and reading
  `PEB::Ldr` at 0x18 is the only way to reach the loader list. The audit appears to
  have pattern-matched `FIELD_OFFSET(` and assumed the `CONTAINING_RECORD` shape.

**What is still true of this file, and was the actual reason for caution.** An
injector that rewrites the target's loader list, strips PE headers and randomises
`DllBase` deserves scepticism whatever the arithmetic says. That judgement was
never wrong; only one specific claim inside it was.

**Verification was harder than it looked, and the first two attempts were both
worthless.** Recorded because the failure mode is general and this repo has a
history of green lines that mean nothing:

1. `tools\build.ps1` builds only `TarkovAddons.vcxproj`. It reported `exit 0` and
   `FRESH: the DLL postdates every source file` having compiled neither Bypass nor
   its own freshness check on Bypass's sources.
2. Building `TarkovLauncherBypass.vcxproj` standalone also reported `exit 0`, and
   compiled — but its `OutDir` is `$(SolutionDir)out\prod\with_aimbot\`, and
   `$(SolutionDir)` is only defined by the `.sln`. Standalone, that resolves to the
   project directory, so the DLL landed in `TarkovLauncherBypass\out\` and **the
   deploy copy at `TarkovAddons\out\prod\with_aimbot\TarkovLauncherBypass.dll` was
   still the pre-edit build**, confirmed by a differing SHA-256.

So the DLL that would ship still contained the `CloseHandle` for one more step.
Building the **solution** fixes both halves at once and is the only correct command
for a change outside `TarkovAddons`: exit 0, 0 errors, no new warnings, and all
three deploy DLLs freshly written (16:34-16:36). Now in `AGENTS.md`.

**Placement in `out/` is not a build dependency**, which is the part that reads
wrong at first. There is no `ProjectReference` from `TarkovAddons.vcxproj` to
Bypass; `TarkovLauncherBypass.dll` is in `out/` because Bypass's own `OutDir`
points there when built through the solution. That is why step 1 could pass without
compiling it.

**3.2 ESP / optics surface — WAS frozen, freeze LIFTED 2026-10-13.** The optics rework
landed, the user lifted the freeze, and the `[CLEANUP-PENDING:OPTICS]` markers are gone
from `EspModule.h`, `esp_text.h`, `quest_esp.h` and `skeleton_visibility.h`.
`module/impl/EspModule.h` still carries 16 `dual_active` branches; they were deferred to
the optics owner and are now ordinary cleanup candidates. **Still not actioned** — see
the dated note at the top of this file.

**3.3 "Decide, don't delete"** (`CLEANUP_AUDIT.md` §6.7) — `TA_FRAME` in
`util/tracy_bridge.h` is **DONE** (deleted in `9b779eb3`; it was defined twice,
once per `#ifdef` branch, and called zero times). The other two remain present
and still undecided: `config/MenuSectionValue.h` (format change) and the four
`safety_switch` config entries (config-file change).


> **RESOLVED 2026-10-06 — `safety_switch` removed. `MenuSectionValue` remains.**
>
> `safety_switch` was not born dead, which the note above did not say. `bb8615f1` gated
> ~10 operations on it (`if (!safety_switch->get_value() || !game_state::is_in_raid) return;`
> across Item/Player/InventoryEditor). Then `a3307eaf` ("TA 3.0") removed every gate, flipped
> the default `false`->`true`, **and** hid the checkbox — a coherent deliberate retirement. The
> surviving `ConfigValue` was debris from that, not an oversight. Removed: 3 declarations,
> 3 ctor initialisers, 3 `set_hidden_in_owner_menu` calls, and the now-orphaned
> `safety_switch_cb` from all 19 locales (each -1 key, all still valid JSON, 0 insertions in
> the diff so no reformat crept in).
>
> **The "config-file change" concern was overstated, and both halves were checked.** `load_config`
> iterates over registered `ConfigValue`s and looks each one up, so a key in the file that nothing
> claims is simply never read — existing configs are unaffected. `save_config` writes only
> registered values, so the key stops being written and disappears on the next save. One-way,
> self-healing, non-breaking.
>
> All three shared ONE config key, so they would have loaded the same value — which is moot when
> nothing reads it, but worth noting it was never three independent switches.
>
> **`util/audit_config_pointers.py` dropped 337 -> 334** and `tools/tests/test_doc_counts.py`
> failed on it, which is the check doing its job one day after being written. Three documents
> updated.
>
> ### 3.3a LEFT OPEN, and it is the other half of the same removal
>
> Two things the 3.0 edit left behind, both now dormant. **Neither is removed**, because both
> are capability questions rather than debris:
>
> 1. **`CheckboxValue`'s `safety_switch` parameter and the Ctrl+click path in
>    `gui/menu/imgui_addons.cpp`.** No `CheckboxValue` is constructed with it `true` any more, so
>    `safety_switch_` is permanently false and those branches are unreachable. It is a real UI
>    capability (a checkbox that requires Ctrl to turn *off*), now with no user. Its two
>    localisation keys `safety_understand_inf` and `safety_ctrl_click_inf` are still referenced
>    from `imgui_addons.h:110,117`, so they are not orphans yet.
> 2. **`ItemModule::sync_item_controls_lock()`** (`ItemModule.cpp:13`) is a no-op: it opens with
>    `constexpr bool unlocked = true`, so every `dis(x, !unlocked)` passes `false`. It is called
>    from three places and disables nothing. Also 3.0 debris — it existed to lock the controls
>    when the safety switch was off.
>
> Both are cheap to delete and neither is urgent. They are listed because removing them is a
> decision about whether the capability is wanted, not a cleanup.

**3.4 Stale comments** (`CLEANUP_AUDIT.md` §5) — remaining: `il2cpp/exports.h`
retains build-46221-specific offsets for replaced code paths; `EspModule.h` says
commented-out per-frame `set_value(false)` calls enforce something they no
longer do.

**3.5 ~~Four dead `Win32` configurations.~~ — DONE, deleted not repaired.** This
closes the old F13 item. `TarkovLauncherBypass` and `vk_swiftshader` each
declared `Debug|Release|Prod|Prod no aimbot|Win32`; `TarkovAddons` was already
x64-only. All four bypass Win32 configs were in fact broken: `disabler.cpp:207`
read `CONTEXT::Rip`, which only exists in the x64 `CONTEXT` layout (x86 is
WOW64's, with `Eip`), so every one of them failed with C2039. Nothing caught it
because nothing built them.

Rather than repair the call site, the configurations were removed, along with
their `SolutionConfigurationPlatforms` / `ProjectConfigurationPlatforms` entries
in both `.sln` files. The reasoning: this DLL is injected into a 64-bit game
process, so an x86 build has no consumer, and a configuration that exists but
cannot compile is worse than one that does not exist — it invites an
all-configs build that fails, and it makes the tree claim support it does not
have. Each project now carries a comment saying so. `<Keyword>Win32Proj</Keyword>`
is *not* a platform setting — it is the MSBuild project-type marker for "this is
a Windows DLL project" — and was kept. `vk_swiftshader` was verified as a
control: its Win32 configs compiled, because it never touched `CONTEXT`.

**3.6 ~~The tree does not currently compile — in-flight hideout work.~~ —
RESOLVED.** That work landed while this was being written (`set_hidden` became
`set_hidden_in_owner_menu`, and the lambda arity was corrected), and
`TarkovAddons.sln` `Prod|x64` now rebuilds with 0 errors. Two things to keep in
mind when picking the tree up again:

- the hideout module edits and the `lang/*.json` edits (all 19 files) are **not
  part of this pass** and were in flight throughout it — review them separately;
- the config/parser fixes (`CLEANUP_AUDIT.md` §13) and the dashboard layout
  change (§14) were each verified against a full-solution build, so the two
  change sets are known to coexist, but they were not authored together.

**3.7 `InfoDrawValue`'s default id is `"Info"`.** Any two instances constructed
without an explicit id share the config key `Info##Configs`. The two current
ones write empty values and `set()` is inert, so nothing throws today, but it is
the same shape of bug as §13.1 and the next value-bearing `InfoDrawValue`
inherits it. Left alone: there is no failure to fix and no clear intended id.

**3.8b The C4805 `bool`/`int` warnings in `eft_api.h` — DONE.** 34 instances of
`'!=': unsafe mix of type 'const bool' and 'int'`, all from one line comparing
`rf.packet_consistent` (a `bool`) against `static int s_last_consistent = -1`.
The `-1` was doing duty as a "can never equal a bool" sentinel that forces the
on-change banner to log its first sample. A `bool` cannot hold that state, so
the fix is a separate `static bool s_have_sample` ORed into the condition and set
on the first pass — same first-run guarantee, no type punning.

Worth noting *why the count jumped*: the count went from 8 to 34 after the §1.7
PCH fix, because 68 translation units had not been compiling at all. The header
is reached by most of the project, so the fix made the full extent visible.
Fixing it drops `TarkovAddons` to **0 errors, 0 warnings** in all four x64
configurations.

**3.8 ~~`loot_min_value_itm` is a plain `IntSliderValue`~~ — DONE.** The last
holdout from the `CLEANUP_AUDIT.md` §15 sweep, converted on the repo owner's
explicit decision to unfreeze the one line (`2ab7177b`). Two lines, because the
two types have identical four-argument signatures:

```cpp
IntSliderEditableValue* loot_min_value;                                  // EspModule.h
loot_min_value(conf(new IntSliderEditableValue(10000, 0, 500000, "loot_min_value_itm")));
```

Existing settings are unaffected: the config key is unchanged and both types
serialise through the same path, so a stored `loot_min_value_itm` reads back
identically. `slider_int_editable` clamps both ends — its own comment records
that it used to clamp only the low bound, which let a typed value above the
maximum be stored — so the conversion cannot admit a value the slider could not
represent.

**No longer frozen in `EspModule.h` — the `[CLEANUP-PENDING:OPTICS]` marker was removed
2026-10-13** when the user lifted the freeze: the 16 `dual_active` branches, the
pre-existing **triple** `#include` of `FloatSliderEditableValue.h`, and the stale
`set_value(false)` comment in §3.4. Those were the optics owner's; they are now ordinary
cleanup candidates and remain unactioned (see the top-of-file note).

**3.9 ~~`FloatSliderValue.h` is now unreferenced.~~ — DONE, deleted.** The §3.8
conversion removed `IntSliderValue`'s only remaining user, so both plain slider
types reached zero and were deleted with their `.cpp` files (`ed00742c`
created the `.cpp` halves during the header split; that dead weight is now
gone). The repo owner overrode the earlier "left on disk rather than deleted —
it is the obvious fallback" reasoning. The two `#include`s that referenced them
are gone too: `EspModule.h` and `module/hotkeys_register.cpp`, the latter
pre-existing.

Verified before deleting: no inbound `#include` anywhere in first-party code, no
registry or factory that could construct a config value by type name, and all
four slider classes derive directly from `ConfigValue` — no inheritance between
the plain and editable variants, so the editable ones are unaffected. The
link-stage oracle's fingerprint is byte-identical before and after, which
confirms no removed symbol was still needed.

`always_on_deprecated.h` is the only remaining header with no inbound include,
and that is deliberate: it states it is not compiled and not included anywhere.

**3.10 The menu's two-column boundary was decided WHILE DRAWING — DONE 2026-10-03.**
Not the frozen optics surface, but the same class of hidden coupling, so it is
recorded here rather than in §4.

`gui/menu/menu.cpp` decided the column split inside its draw loop, after the card
had already been rendered, keyed on `m->name`. That arrived as **eleven predicates**
(`keep_exploit_on_left`, `split_after_player`, `move_bot_control_to_right`,
`keep_profile_left`, …) and cost three defects in one afternoon:

1. **The Raid Dashboard boundary was keyed on the Debug Log card, but Debug Log
   was registered AFTER Favorites.** Enabling "Show Debug Log" therefore moved
   Favorites into column 1 with it and left the right column holding Configs
   alone. Reported as *"the debug log and configs move to the left column"*.
   The fix was partly a registration reorder (`ModuleManager.h`), which is load-
   bearing and invisible — see the column-order note in that file.
2. **Because the split was decided mid-draw, every pinned boundary needed a
   matching "keep this left" opt-out** to stop the 50%-height heuristic firing
   early — and those opt-outs had to cover a whole *run* of cards, not just the
   one the boundary keyed on. The Profile page needed a paragraph to explain it.
   A design admitting it is wrong.
3. **`##col2` could be opened twice in one frame**, once by the split and once by
   the hotkeys panel at the end.

Now: the card list is built first and the boundary resolved from it, so the loop
has no per-card branch. The policy is data in `gui/menu/column_layout.h` — one
declarative table keyed on the real `ModuleCategory`, so there is no second tab
enum to drift. Two things then stopped being special cases:

- **The conditional Debug Log card** is simply absent from the list, so the
  boundary moves up by itself. That deleted the explicit
  `if (name == "Debug Log" && !shown) split_to_second_column();` line, which is
  the one the registration order had silently invalidated.
- **`Teleport` needed a third state.** `Map Selector` must stay left, but Teleport
  has *no* pinned boundary, so it is `Sticky`: it suppresses the heuristic without
  pinning. Marking it `Left` would have promoted it to a boundary and permanently
  moved Marked Rooms and Loot Teleporter — a behaviour change disguised as a
  tidy-up.

`tools/harness/test_column_layout.cpp` compiles the real header (44 assertions) and
asserts both toggle states, every tab's split, and — by reading `ModuleManager.h`
and `module/impl/*.cpp` as text — that every left-column card is registered before
the first right-column one. **That last check is the one that matters**: the table
keys on module names, so a rename or a reorder would otherwise break the layout
with nothing failing. Verified by reinstating the original defect, which produces
`Debug Log must be registered before Favorites`.

**Still not done, and they are optional.** The table keys on module *names*, so a
rename means editing it (now caught by the test rather than being silent) —
`Module` could carry a `LayoutSlot` instead. And `draw_card_frame()` still uses the
display name as the ImGui ID, while the stable identifier the constructor already
takes (`aimbot_mod`, `configs_mod`) is used only for i18n. Retitling a module
therefore discards its fold state and every widget's ImGui state. Both are safe to
defer now that the test exists.

---

## 4. Decided — do not relitigate

**4.1 The two `compat_profile` implementations must NOT be merged.** They look
like duplicates and are not. Only the 6-line `status_priority()` ladder is
byte-identical. The rest diverges deliberately: TarkovAddons' `Symbol` is a
9-field struct in a hash map and hard-fails on identity mismatch, while the
bypass takes a 2-field struct in a flat vector, ignores identities by design,
and must never block the launch. Merging would import a hard-fail into the
launcher's critical path or add a mode flag that re-tests the premise. Full
reasoning and the safe shape if they ever must converge (shared envelope-parsing
core, per-project symbol model and selection policy) is in
`CLEANUP_AUDIT.md`. **Recorded so it is not mistaken for an oversight.**

**4.2 Neither project directory is self-contained any more.** Both compile from
the shared root `external/`. Copying `TarkovLauncherBypass/` on its own to
another machine will no longer build. Accepted trade-off; the alternative
(git submodule) is written up in `external/README.md`.

---

## 5. Live crash risks — re-validated 2026-10-01, and re-ranked downward

This section exists because on 2026-10-01 three items were promoted to "live
crash risk, highest severity" on the strength of reading the source and nothing
else, and that ranking was **wrong**. The challenge that produced this section was
the right one: *if they are so dangerous, how come nobody has ever hit them?*
They have not been hit because two of the three are **not reachable**, and the
third was measured and excluded. Ranked by how bad the thing is *in theory* is not
ranking; ranked by whether it can happen is.

**A fourth was added to that list after this section was written**, in the same
hour, by the same mistake: the six unchecked `o_*_move_next` trampolines in
`module/always_on.h`. Also retracted, also on the owner's challenge. The mechanism
is the same and it is now the section's standing rule:

> **An unchecked call site is a shape, not a fault.** Whether it can fault is a
> property of the install path, and the install path is where the question has to
> be answered. `hook_method` (`il2utils.h:381-403`) installs the detour *before*
> it writes the trampoline, and returns without installing anything when the
> detour cannot be created — so a failed install leaves the pointer null **and
> the hook body unreachable**. A renamed `Run` is therefore the case that makes
> `o_run_move_next` safe to call, not the case that makes it crash.

Full retraction in `Workstream_status_2026-09-24.md`, under the entry it
corrects. What survives is a startup race between `il2utils.h:381` and `:403` on
the thread `DllMain` spawns — narrow, and not why the thread faulted.

### 5.1 `0xC0000005` at `TarkovAddons.dll+0x744C1` — FIXED 09-30 21:42, held since

**This was written as "ours, unexplained, unrepaired" and that was wrong on both
counts.** It was diagnosed and repaired the same evening; the gap was that nobody
checked `git log` before promoting it to a live defect.

The fault: `std::basic_filebuf<char>::_Endwrite`, READ of `0x138`, from the ESP
draw thread, at 20:56:06 and 21:14:31 on 09-30. The cause was a function-local
`static std::ofstream` that was **reused** after failure — `clear(); close();`
then `open()` on the same object — so one `basic_filebuf` outlived its file handle
while a write was still dispatched through it. `util/logger.cpp` now
heap-allocates the stream and **destroys** it (`drop_log_stream()`,
`logger.cpp:100-119`) so the next call constructs a fresh `basic_filebuf`, plus a
pre-write `is_open()` re-check and a `try`/`catch` so logging can never be the
thing that takes the process down. Committed `4dec3639`, **09-30 21:42** — 28
minutes after the second occurrence.

**Both crashes predate the fix, and there has been no recurrence since.** Every
crash after 21:42 is a different signature: `0xC000070E` (five, excluded — §5.3)
and `0xE06D7363` (three, the recursive mutex — fixed, §5.2's sibling in the log).
Eight crashes across thirteen hours of play, **no `0xC0000005` in our module**.
That is not proof, and it is the strongest evidence available without
deliberately provoking it.

**What remains genuinely open is narrower, and the log says so:**
`Workstream_status_2026-09-24.md:5317` — *"Not proven. There is more than one
`std::ofstream` in the project and the faulting one was not established."* The
fix addresses the best candidate, and the best candidate is not proven to be the
faulting one. So the open item is **confirmation, not repair**: if a
`0xC0000005` in `TarkovAddons.dll` ever recurs, the reused-filebuf theory is
wrong and the search has to start again.

One trap for whoever picks that up: the crash probe deliberately does **not** go
through the logger — `logger.cpp` records this very fault from inside
`_Endwrite`, so routing a fault report through the logger means calling the thing
that already crashed once. Use the probe's own `FILE_APPEND_DATA` handle.

### 5.2 `PlayerModule.cpp:505` — NOT a live risk. A missing `static_assert` is.

`EXP_TYPE_API[exp_type->get_value()]` was listed as the highest-severity item on
this project. It cannot go out of bounds:

- `exp_type` is a `SelectValue`, and **`SelectValue::clamp_value()` runs on every
  mutation path** — the constructor, `set()`, `set_value()`, `set_options()`, and
  every frame in `draw()`. It clamps to `[0, options.size()-1]`.
- Its option list *is* `EXP_TYPE_KEYS`, 7 entries, and `EXP_TYPE_API` has 7. So
  the clamp bounds the index to exactly the array's range.
- `exp_type` is `new`ed in the member-init list and never reassigned, so the
  unchecked dereference has the same unfailable-by-construction property the
  `hook_method` `T2*` fix relies on.
- And it is not a per-frame path: `queue_add_exp` is set only by
  `PlayerModule::add_exp_impl`, i.e. the EXP hotkey, in a raid.

**What actually remains** is a convention with nothing enforcing it:
`EXP_TYPE_KEYS` (the dropdown) and `EXP_TYPE_API` (the field names) are parallel
arrays, and `TRADER_API` at `PlayerModule.cpp:529` is a third. Add a key without
its API entry and `clamp_value()` cheerfully permits the new index, reading one
element past a `constexpr const char*[]` — which yields a garbage pointer and
faults later, in `resolve_field`, not at the read. That deserves a
`static_assert(std::size(EXP_TYPE_KEYS) == std::size(EXP_TYPE_API))`, which is
two lines, and not a crash investigation.

### 5.3 `0xC000070E` — measured, and it is not ours

`STATUS_THREADPOOL_FREE_LIBRARY_ON_COMPLETION_FAILED`, identified from the SDK's
own `ntstatus.h` rather than guessed. Five occurrences: 09-30 23:00 and 23:21,
10-01 00:15, 01:00, 09:50 — spanning five *different builds of ours*, which a bug
of ours would not survive.

The evidence that excludes us:

- **Zero GameAssembly frames** on any of the five crashing stacks. The crashing
  thread had 125 code addresses on it; none were ours or the game's.
- The one address that *did* resolve into `TarkovAddons.dll` is
  `crash_probe::handler+0x44F` — the probe seeing itself, mid-report. (This also
  means the probe should exclude its own frame from the stack scan; a VEH's frame
  is never part of the faulting stack. Small, real, unfixed.)
- We never call `CreateThreadpoolWork`, `SubmitThreadpoolWork`,
  `RegisterWaitForSingleObject` or `QueueUserWorkItem`, and there is no
  `FreeLibrary` anywhere in the tree.
- `param[3]` is `0xFFFFFFFFC0000135` in all five — a 32-bit NTSTATUS
  sign-extended into a 64-bit slot, i.e. ntdll's own bookkeeping failing.

**Seventh through thirteenth occurrences, 2026-10-03 07:59–08:18 — it is now the
dominant crash, and it is not a memory fault at all.**

Twelve launches in 21 minutes (a restart loop, not play). **Seven died, every one of
them the same way**, 0.26–0.61 s after the probe armed and 0.4 s after `Menu Key:
Insert` — i.e. at the handover from our init to the game's:

| pid   | armed     | fatal     | gap    | exceptions seen        |
|-------|-----------|-----------|--------|------------------------|
| 10536 | 07:59:19  | 07:59:19  | 0.40 s | 40 (0xE06D7363 x7, 070E x33) |
| 22040 | 08:09:09  | 08:09:09  | 0.26 s | 33 (x7, x29)            |
| 9352  | 08:09:52  | 08:09:57  | 5.4 s  | 38 (x7, x33)            |
| 22700 | 08:10:23  | 08:10:23  | 0.33 s | 36 (x7, x29)            |
| 22624 | 08:16:52  | 08:16:58  | 6.3 s  | 42 (x7, x48)            |
| 24220 | 08:17:23  | 08:17:29  | 6.4 s  | 32 (x7, x28)            |
| 476   | 08:18:05  | 08:18:11  | 5.6 s  | 36 (x7, x29)            |

Windows' own record agrees and puts it at 18 of 27 crash events since 09-30, all at
the identical `ntdll.dll+0x2bd49`. The event-log messages are localised (Chinese), so
the fields have to be read positionally out of `EventData` — an English-keyword
regex over `.Message` silently matches nothing and looks like "no data".

**What it actually is, read off the on-disk ntdll.** `ntdll+0x2BD0A` builds the
status on the stack and calls `RtlRaiseException`:

```
0x02BD0A  mov dword ptr [rbp-0x79], 0xc000070e   ; the status
0x02BD11  mov dword ptr [rbp-0x61], 4           ; four parameters
0x02BD44  call RtlRaiseException
0x02BD49  jmp 0x2bb22                            ; <- the address everyone reports
```

So `ntdll+0x2bd49` — the "fault offset" in the event log and the `at 00007FFB0AA4BD49`
in our own report — is **the return address of that call**. Nobody faulted there.
`flags=0x00000080` is `EXCEPTION_NONCONTINUABLE`, which is why it cannot be swallowed
by a `__try` and always reaches the unhandled filter. That also explains `frames=0`:
there is no faulting instruction to walk to, and `faulting rva=<outside this module>`
is accurate rather than a failure. The adjacent `0xC000070C` is built on the same path
with five parameters.

**This strengthens "not ours" rather than weakening it.** Re-checked against the tree:
still no `CreateThreadpoolWork` / `SubmitThreadpoolWork` / `QueueUserWorkItem` /
`RegisterWaitForSingleObject` anywhere. The only `FreeLibrary` calls are
`imgui_impl_win32.cpp:237` (XInput, at shutdown) and `TracyProfiler.cpp:3821/3829`
(symbol-source DLL, after the profiler starts — and these crashes are at 0.3 s, long
before anyone can press Start Profiler). A work item was registered and its owning
library freed by *something*, and the raiser is the OS threadpool acting on it. It is
still 0.3 s into startup, which is inside the window where our injection happens, so
this cannot be closed from inside the process — the uninstall test still stands, and
now has a sharper question to answer.

**And the "no crash probe output" half of the report has a different cause entirely.**
**Five of the twelve launches died with no structured exception at all** — no vectored
report, no unhandled-filter report, no `std::terminate`. Nothing in-process can report
those, because by definition nothing was raised.

The reason there is still no evidence for them is this:

```
HKLM\SOFTWARE\Microsoft\Windows\Windows Error Reporting
    Disabled = 1
    LoggingDisabled = 1
HKLM\SOFTWARE\Policies\...\Windows Error Reporting
    Disabled = 1   LoggingDisabled = 1   DontShowUI = 1
```

**WER is off system-wide**, which is why 2026-10-03 has *zero* Application Error
events despite seven caught fatals — the 09-30→10-02 entries predate it. So the probe
report and the event log between them cover everything that raises an exception, and
**nothing at all covers the five that do not.** `CrashDumps` and `ReportArchive` are
both empty, so there is no minidump either.

`tools/watch_client_exit.py` closes that gap from outside. An exit code has to be read
from a handle opened while the process is alive, so it attaches to the next
`EscapeFromTarkov.exe`, waits, and prints the code — which separates the cases that
look identical from the inside: `0xC0000005` a real fault, `0xC00000FD` stack overflow,
`0xC0000409` fail-fast, `0` a clean exit, and a small number a `TerminateProcess`
(anti-cheat). `tools/tests/selftest_watch_client_exit.py` proves it against three real
process deaths including `os.abort()` → `0xC0000409`, the code that bypasses SEH.

**Do not spend more time on this inside this project.** The clean external test is
`python tools/deploy.py uninstall --yes`, a raid, reinstall — and it would also
prove `uninstall`/`install` round-trips. If `0xC000070E` appears with our DLL
absent, it belongs to the game or the launcher and should stop being logged as
ours. Run `tools/watch_client_exit.py` first so the run produces an exit code either
way.

**Sixth occurrence, 2026-10-02 19:37:43 — still excluded, still the same shape.**
`code=0xC000070E flags=0x00000080 tid=27244 at 00007FFE06D6BD49`,
`faulting rva=<outside this module>`, `(nothing captured before this event)`.
Identical address to the previous five, on a **different thread from the mod's**,
in a process where the probe captured nothing else first — it died 6 s in, before
any C++ exception happened. The mod's own thread ran to completion
(`Loaded Modules`, `Hooked Present`, `Loading Default Features`, `Menu Key`).

**One loose end, and it is a log limitation rather than a new fact: the log shows
five seconds of activity *after* a `FATAL` report.** `Loading Asset Bundle` /
`Loaded Asset Bundle` land at 19:37:43.268/.341, after the probe's report.
A terminated process cannot do that, so either the report was not fatal or **two
processes are appending to the same file** — and `tid` alone cannot tell those
apart, because thread ids are small and recycled. `WORKFLOW.md` already records
that the launcher and the bypass append to the same path by design.

**Fixed: the log prefix carries `pid=` now.** One field, and the ambiguity is gone
for every future log. Nothing parses the prefix — `rg` over the tree finds no
reader of `tid=` or of the date pattern — so the format change is safe. This is
the second time a log limitation has cost real inference: first the 11,903-line
`ERROR` flood drowning everything else, now this.

**Separately: the user reported the launch showed a "breakpoint encountered"
dialog, and that does not match `0xC000070E`.** `EXCEPTION_BREAKPOINT` is
`0x80000003`; `0xC000070E` is `STATUS_THREADPOOL_FREE_LIBRARY_ON_COMPLETION_FAILED`.
Three possibilities, and the log cannot separate them: the dialog came from a
different launch than the one logged; the breakpoint happened after the UEF and
the probe does not report it (it reports non-continuable codes only, and a
breakpoint's flags are not `0x80`); or the dialog is the launcher's rather than
the game's. **Recorded as an open discrepancy rather than reconciled.** With
`pid=` in the log, "which process, and did it report a second exception" becomes
answerable next time.

### 5.4 `il2utils.h:139` `get_static_field` — **DONE**, and `resolve_field` memoised too


**DONE 2026-10-01 — and it is OUR code, not vendored.** I originally wrote this
item as though `il2utils.h` were a vendored header where a divergence from
upstream might matter. It is not. `PROVENANCE.md`'s vendored set is "the six
**generated** headers" from `js6pak/libil2cpp-archive`; `il2utils.h` is 27 KB of
hand-written helpers with no vendored banner, and it includes our own
`safetyhook.hpp`, `logger.h` and `utils.h`. There is no upstream to stay in sync
with, which makes the fix cheaper, not harder.

**Not reachable today, and the cheap check says so.** `get_static_field` passed a
possibly-null `FieldInfo` straight to `il2cpp_field_static_get_value`. Only two
call sites, both compile-time-constant field names, and `EFT.InGameStatus.InRaid`
**exists** — static and `[Obsolete]`, verified. The `InRaid` theory that made this
look urgent was disproved, not confirmed. The real trigger is a Battlestate patch
renaming a field: the same class as the chams crash in §1.5.

**What was wrong with the reply was worse than a missing null check.** The old
signature was `T get_static_field(...)` with `T value;` — default-*initialised*,
not value-initialised. For `T = Il2CppObject*` that is an **indeterminate
pointer**, which `PlayerModule.cpp` then handed straight to the game's `AddInt`. So
the hazard was not only "a null FieldInfo"; it was also "a plausible-looking
garbage pointer passed to a game method".

**The reply is now tri-state**, named rather than `std::optional`, because
`std::optional<bool>` is a trap: `if (opt)` tests *has_value*, not the contained
value, so `if (opt)` meaning "the field is true" is a silent and plausible
mistake. This file has already produced three variants of that bug
(`InfoDrawValue`'s shared default id, the `-1` sentinel in `eft_api.h`'s
`packet_consistent`, `SelectValue`'s clamp), so the states are spelled out:
`Present` / `FieldMissing` / `NoClass`.

**The consumption policy differs per call site, and that is the interesting part.**

- `game_state::is_in_raid` — **keep the last known value.** Both definite answers
  are guesses and they fail in *opposite* directions: `false` silently disables
  every module gated on it (18 files read it), `true` silently enables all of them
  outside a raid. Keeping the previous value is wrong only in the window between
  the patch and the fix, rather than wrong forever.
- The EXP reason field — **abandon the operation.** `reason` goes to a game method,
  so skipping `AddInt` leaves the EXP not applied, which is visible and harmless.
  Passing an indeterminate pointer is neither.

**The log is rate-limited, which is the throughput question answered.** The null
check is one compare. The *logging* was the danger: `logger::warn` writes and
flushes, and the call site is `hk_tarkov_application_update`, i.e. **per frame** —
60 file writes a second. So `warn_static_field_once()` reports each
(class, field, reason) exactly once. The check is free; the log is what had to be
designed.

**`resolve_field` is now memoised, and that was a bigger find than the tri-state.**
It was doing an unmemoised `il2cpp_class_get_field_from_name` — a string-compare
scan of the class's field table — once per class in the inheritance chain, on a
per-frame path, with **138 call sites**. `resolve_image` and `resolve_class` were
memoised for exactly this reason (see the FPS-collapse note at `il2utils.h` L18-42)
and `resolve_field` was missed. `WorldModule.cpp:509-513` was already hand-rolling
the same idea with a `memory_field_resolved` bool, which is the precedent for doing
it once in the header. Only successes are cached, for the reason the file already
gives: a miss can be a "not initialised yet" state that would resolve later.

**The 138 call sites were audited, as asked, and none is unguarded.** 116
machine-classified as guarded; the remaining 22 read by hand. The first version of
that audit reported "2 UNGUARDED, 1 UNCHECKED" and **all three were bugs in the
audit script**: it found the end of a call by splitting on the first `)`, which for
`resolve_field(obj->klass, "X")` is the `)` of a *nested* call, so
`if (const FieldInfo* sf = resolve_field(...))` was read as "dereferenced at once";
and it looked for a null check with a regex that cannot match a compound condition,
so `if (!set_type || !set_value || !rarity) return 0;` read as unguarded. Both
fixed, and the corrected result is that `resolve_field`'s callers are in good
shape. Script kept at
`%LOCALAPPDATA%\Temp\opencode\ta_dumps\audit_resolve_field.py`. That is the sixth
time this session a tool of mine emitted a confident wrong classification.

**Not covered by an executable test, and that is a real gap.** `il2utils.h` cannot
be unit-tested cheaply: it includes `safetyhook.hpp` and, through
`il2cpp_offsets.h`, `Config.h` and `globals.h`. The offsets are mutable `inline
PVOID`s, so a stub layer is *possible* — point them at test functions — but that
is a project in itself, and a partial stub would be the "green stub" this file
warns against elsewhere. So the tri-state is verified by build and by review of the
two call sites, not by execution. Recorded rather than glossed.

### 5.8 The compatibility profile was deployed but never loaded — FIXED

> **Numbering note.** 5.8 and 5.9 sit before 5.5 because they were found last,
> and 5.9 was found because 5.8's fix made a dormant path reachable. Renumbering
> four cross-referenced sections to tidy the order would have cost more than the
> reader saves. The numbers are what other documents cite; the order is not
> load-bearing. Read 5.8 and 5.9 as one unit — 5.9 is 5.8's consequence.

**Found and fixed 2026-10-01.** Not a crash, not untested code: misrouted. This
supersedes the "untested path" framing at
`Workstream_status_2026-09-24.md:5448`, which recorded item 16 as "the main-DLL
profile path has never run live — no log line yet proves a profile was selected."
It had not run because it could not find the file.

| | path |
|---|---|
| loader (before) | `compatibility_profile.cpp` — `dll_directory_wide() / L"compatibility" / L"profiles"` |
| build | `TarkovAddons.vcxproj:440` — `<Link>ta\compatibility\profiles\…` |
| deploy | `tools/deploy.py` — `ta\compatibility\profiles\…` |
| on disk | `BsgLauncher\ta\compatibility\profiles\1.1.5.1.47510\manifest.json` — **present** |
| wanted | `BsgLauncher\compatibility\` — **did not exist** |

And the log said so, every launch: `No compatibility profile found; using legacy
IL2CPP resolver`. That is the *designed* `NotFound` fallback, which is why nothing
errored and the profile had never once been loaded in any build.

**How the two drifted.** The `<Link>` was changed to `ta\` for a sound reason,
recorded in the vcxproj comment: the copy used to live only in the two Prod
post-build steps, so Debug and Release shipped no profile and the runtime quietly
fell back — the F2 fix. The `ta\` prefix is right for the deploy layout; the
guide was never updated, and **the loader was never taught the new location**. So
the guide documented an output that stopped being produced and the runtime read a
directory nothing wrote.

**The fix is one line, and it took the launcher's own accessor.** The launcher
process was already correct: `TarkovLauncherBypass/util/compat_profile.cpp:140`
uses `module_paths::data_directory_wide()`, which resolves to `<dll dir>/ta/` when
`ta/` exists. Only the game DLL hardcoded a root. So `load_for_module` now uses
the same accessor, and the two processes cannot drift on this again by accident:

```cpp
const auto profile_root = module_paths::data_directory_wide();
return load_for_identity(identity, profile_root / L"compatibility" / L"profiles", output, detail);
```

`data_directory_wide()` falls back to the DLL directory when `ta/` is absent, so
a pre-`ta` install — or the `bypass`'s own dead-`GetModuleHandleW` case — still
resolves. This also keeps §4.1 intact: the two `compat_profile` implementations
are still separate and still diverge; they merely agree on where to look.

Built clean (0 errors, 1 expected `MSB8012`), deployed, and the deployed
manifest is at the path the loader now reads.

**ANSWERED 2026-10-02: the profile loads.** `IL2CPP compatibility profile
loaded: eft-1.1.5.1.47510 (1.1.5.1.47510) from C:\Battlestate Games\…` — the
first time in any build that this has ever appeared. The path fix was right.

**It also broke startup on 3 launches in a row, which is §5.9.** The prediction in
this section was "a launch that fails to start is a plausible outcome of this fix,
not only a successful one" — and that is what happened, three times out of four.
Reading the log is what identified it as a *different* defect rather than a
regression in the path fix: the six unresolved symbols are exactly the six
`export`-resolver ones, and the eight `pattern`-resolver ones resolved on the very
same failing launches.

**F16, also fixed: nothing asserted that the reader and the writer agree.** Added
`tools/tests/test_profile_path.py`, 10 cases, which is the fix for the *class*
rather than this instance. It checks the three literals that have to match — the
`.vcxproj` `<Link>`, `deploy.py`'s destination, and the loader's root — plus the
launcher/game agreement, and that the three guides name the deployed path. It
reads the `.cpp` and strips comments before matching, because the first version
of the negative control passed on the fix's own explanatory comment while the code
was reverted; that is a fourth instance of the failure `tools/verify/README.md`
exists to prevent, and it was caught only because the control was actually run.

All four negative controls fire: reverting the accessor (2 failures), rebuilding
the original `dll_directory_wide() / L"compatibility"` concatenation (2), and
moving the `<Link>` out of `ta\` (2). Suite: 149 passed, 6 subtests **at the time**;
it is 220 now (see the count reconciliation near the top of this file).

### 5.9 The export resolver has no retry, and it stops the mod from starting

**Found 2026-10-02, immediately after §5.8's fix shipped.** This is a
consequence of §5.8, not an independent bug: the fail-closed path was
unreachable while the profile never loaded, so this had never run. It is
**live**, it affects **3 launches in 4**, and it is **not fixed**.

The log, verbatim, from one failing launch:

```
Loading Il2CPP API
IL2CPP compatibility profile loaded: eft-1.1.5.1.47510 (1.1.5.1.47510)
Found Pattern: 4C 89 44 24 18 …      Profile resolved il2cpp_class_from_name
Found Pattern: 48 89 5C 24 08 …      Profile resolved il2cpp_class_get_nested_types
Found Pattern: 48 89 5C 24 08 …      Profile resolved il2cpp_class_get_field_from_name
Found Pattern: 48 89 5C 24 10 …      Profile resolved il2cpp_class_get_method_from_name
Found Pattern: 48 83 EC 28 …         Profile resolved il2cpp_domain_get
Compatibility profile could not resolve required symbol: il2cpp_domain_get_assemblies
Found Pattern: 48 89 5C 24 18 …      Profile resolved il2cpp_field_static_get_value
Found Pattern: 48 89 5C 24 08 …      Profile resolved il2cpp_field_static_set_value
Compatibility profile could not resolve required symbol: il2cpp_field_get_value_object
Compatibility profile could not resolve required symbol: il2cpp_string_new
Found Pattern: 48 89 4C 24 08 …      Profile resolved il2cpp_type_get_object
Compatibility profile could not resolve required symbol: il2cpp_array_new
Compatibility profile could not resolve required symbol: il2cpp_object_new
Compatibility profile could not resolve required symbol: il2cpp_runtime_class_init
IL2CPP compatibility profile is incomplete; startup will stop safely
Mod startup stopped: IL2CPP API is incomplete. Update offsets or patterns before retrying.
```

**The 6 failures are exactly the 6 `export`-resolver symbols. The 8
`pattern`-resolver symbols resolved on the same launch, in the same loop,
microseconds apart.** That split is the diagnosis, and it is not a guess about
timing:

| resolver | required | resolved (launches 1–3) | retry |
|---|---|---|---|
| `pattern` | 8 | **8 / 8** | `resolve_pattern_with_retry` — 3 attempts, 150 ms apart |
| `export` | 6 | **0 / 6** | `resolve_export_body` — **1 attempt, none** |

`il2cpp_offsets.h:92` and `:107`. The pattern branch sleeps and retries; the
export branch does not. That the retry exists at all is the tell: cold-start
resolution *is* known to fail transiently, and only one of the two resolvers was
given the treatment.

**What it is not.** Not a wrong manifest, and not a build drift. All six names are
present in GameAssembly.dll's export table — verified by parsing the PE directly
(386 exported names, all six matched) — and the profile's identity check
(`SizeOfImage` + PE timestamp) *passed*, so the live module is the one the
manifest describes. The manifest also gives these six `resolution_order:
["export"]` with **no pattern fallback**, so a single `GetProcAddress` miss is
fatal where a pattern miss would have been retried.

**The evidence for nondeterminism rather than a stable failure is one line of
diff.** The 4th launch (12:14:48) resolved all 14 on the *identical* code path —
no `Found Pattern` line for the export six there either, so they went through the
export branch and succeeded. Same DLL, same game, same manifest, same code.
3 failures then a success, with restart gaps of 33 s / 22 s / 41 s between them.

**What I have not established, and am not going to assert:** the OS-level reason a
`GetProcAddress` on a loaded, mapped module with a known export returns null. It
should not be possible, and I have not proved a mechanism. What *is* established
is that the asymmetry is real, that it is the whole difference between the 8 that
work and the 6 that do not, and that the pattern branch's existing retry is
precisely the remedy for a transient miss.

**The fix is one line** — give `resolve_export_body` the same
`resolve_pattern_with_retry` treatment. It is not applied because it changes
startup behaviour and §5.8 already changed startup behaviour once unasked. Two
things worth deciding alongside it:

- Should a *required* symbol that fails after its retries be fatal at all? The
  design says yes, and that is correct for a profile that matched the module
  identity — a mismatched profile must not silently use stale data. But the
  current code cannot distinguish "the profile is for a different build" from
  "one lookup raced the loader", and it treats both as fatal.
- The 6 export-resolver symbols carry `rva: null` and no pattern. Giving them
  byte patterns would make them as robust as the other 8 and would make the
  resolver split disappear. That is a manifest-authoring task, not a code fix.

#### 5.9a SOLVED 2026-10-02 — the module is mapped but not in the loader's list

**The diagnostics answered it on the first run.** The verdict lines:

```
GetProcAddress(GameAssembly=7FFCA57A0000, "il2cpp_string_new") returned NULL, GetLastError=126 (0x7E)
GetModuleFileNameW on the module returned 0
VERDICT -- the export IS in the module's export table, so GetProcAddress is the failing party
         hand-parse: "il2cpp_string_new" FOUND ord=232 rva=0x164870 (386 names)
```

**`126` is `ERROR_MOD_NOT_FOUND`, and that is the whole answer.** `GetProcAddress`
and `GetModuleFileNameW` both resolve a handle *through the loader's module
list*. Both failed on the same handle. Meanwhile the boot-gate line recorded
`GameAssembly=00007FFCA57A0000 path="<not loaded>" SizeOfImage=0x66ED000` — the
`SizeOfImage` read **succeeded** and matches the manifest's identity exactly.

So: the image is mapped and fully readable, and the loader does not list it. An
LDR entry was unlinked while the image stayed loaded. Nothing about the module
changes afterwards, which is why it is sometimes listed and sometimes not, and
why **no wait duration or readiness semaphore could ever have fixed it** — the
game is ready the whole time; the loader's opinion of it is what varies.

**And the hand reader was right.** An independent parse of the on-disk
`GameAssembly.dll`, with a separate parser in a separate language, agrees on
**6/6** — ordinals 31 / 103 / 111 / 186 / 207 / 232 and RVAs 0x1850F0,
0x3B5700, 0x29AAC0, 0xEB090, 0x1EF910, 0x164870. Two independent readers
agreeing is what makes the fallback trustworthy rather than merely plausible.

**The fix is applied** (`il2cpp_offsets.h::resolve_export_body`): try
`GetProcAddress` first, because it is the loader's canonical answer and the only
thing here that resolves a forwarder; on failure fall back to
`scan::find_export_by_hand`, then continue into the existing
`follow_export_thunk`. So the order is now *optimistic first, proven second* —
inverted from where it started, where the unreliable path was the only path.

Two things worth recording about that code:

- **The first version of the fallback had the exact bug this file keeps
  recording**: it assigned `by_hand.rva` — a bare RVA — to the variable that
  `follow_export_thunk` then hands to the call site. That function bounds-checks
  against `[module_base, module_base+module_size)`, so a bare RVA is out of
  range on every hop, it returns its input unchanged, and the mod would have
  called the head of the image. Caught on review, before deploy. It now uses
  `by_hand.address` (`base + rva`) and **re-checks the result is inside the
  image**, because the consequence of being wrong is a wild call into the game.
- **`is_in_loader_list` was rewritten once, for a better reason than tidiness.**
  It first walked `PEB.InMemoryOrderModuleList` by hand. That needs `PEB`,
  `PEB_LDR_DATA` and `LDR_DATA_TABLE_ENTRY`, which `<windows.h>` does not declare
  under `WIN32_LEAN_AND_MEAN` — which this project sets — so it would have meant
  redeclaring loader structures and trusting their field offsets *on the path
  whose purpose is to diagnose something subtle*. It now uses
  `EnumProcessModulesEx`, which is read-only, documented, and cannot write to
  loader memory the way a hand walk does if the base-of-entry arithmetic is wrong
  (the bug the launcher has, `AGENTS_TODO.md` §3.1). The longer unchecked version
  was the worse instrument precisely because it was on this path.

The remaining question is **why the entry is unlinked at all**, and that is not
the mod's to answer — it is anti-cheat behaviour, and the evidence says the
handle is valid, the bytes are good, and only the bookkeeping is gone. The
fallback is the correct response to a loader state we do not control.

**RETRACTED 2026-10-02: "an LDR entry was unlinked" is WRONG, and the log says so.**
The timeline diagnostic settled it, and it settled it against me:

| launch | at Unity gate | after il2cpp init | `boot[il2cpp]` |
|---|---|---|---|
| 17:05:14 | **LISTED**, `GetModuleFileNameW` FAILED | **LISTED**, FAILED | **6 of 14 by direct read** |
| 17:05:43 | LISTED, named `D:\Games\Tarkov\GameAssembly.dll` | LISTED, named | 0 of 14 |
| 17:07:09 | LISTED, named | LISTED, named | 0 of 14 |

`EnumProcessModulesEx(LIST_MODULES_ALL)` **finds GameAssembly.dll on the
failing launch**, at the gate, during the first fallback, and after init. The
module was never unlinked — an unlinked module is invisible to that API too. So
the module is **listed** while `GetProcAddress` *and* `GetModuleFileNameW` both
refuse it. That is a **filter on those two APIs for one module**, not a missing
list entry.

What I got wrong was inferring the mechanism from two failures sharing an error
code. `ERROR_MOD_NOT_FOUND` is what `GetProcAddress` returns when the handle is
not in the list — and I read that as the handle not being in the list, without
checking whether it actually was. The timeline diagnostic existed precisely to
answer that and I only added it *after* writing the explanation.

**What this settles, and it is the retry question: the retry is not worth
adding.** Membership never changed on any launch. Nothing about the module
varies; what varies is whether the loader's *policy* allows those two APIs to
answer for it. Waiting cannot change that, and the first-launch-fails pattern
in every earlier session is the same coin landing the other way.

**And the fallback is confirmed working, which is the other half of the
question.** Launch 1 is not "no problem occurred" — it is `6 of 14 needed a
direct read`, all six at the RVAs independently cross-validated 6/6, then
`IL2CPP API Loaded via compatibility profile`, then `Hooked Present`. That is
the fix doing its job, which is exactly what the `boot[il2cpp]` counter was added
to make visible. Without it this launch and a launch where nothing happened
would look identical.

**One real diagnostic gap, found by this and now fixed.** The
GetProcAddress-hook check — reference `GetProcAddress` resolved from
kernel32's export table, compared against our IAT entry — lived inside
`report_export_failure()`, which only runs when the direct export read *also*
fails. The direct read never fails, because it never asks the loader anything.
**So the one measurement that would confirm interception never ran in the case
interception was suspected.** It is now `report_getprocaddress_state()` on the
fallback path, called once. A diagnostic on the dead-end path is worse than
none, because it looks like coverage.

**A pattern worth recording without over-reading it:** in every session
observed, the **first** launch fails and later ones succeed. That held for
3-then-1, 1-then-1, now 1-then-1-then-0, and again on 2026-10-02 at 19:37 where
the first launch logged `6 of 14` and the fallback saved it.

#### 5.9c The hook check ran, and gave its third answer — with a limitation

19:37:38.015, on the fallback path:

```
export: reference GetProcAddress (from kernel32's own export table, bypassing our IAT)
       at 0x7FFE056B88F0; our IAT GetProcAddress; target GetLastError=126
       -- both returned NULL, so the reference GetProcAddress denies it too.
       The denial is not specific to our import.
```

So **our IAT entry is not replaced** — the third branch of the three-way test, and
the one the 17:0x launches never reached because the fallback handled them. The
denial happens inside `GetProcAddress` itself.

**The instrument's limitation, stated because it is easy to over-read.** It
distinguishes *IAT-hook* from *not-IAT-hook*. It **cannot** distinguish an
**inline hook on GetProcAddress's body** from a **policy inside GetProcAddress**:
an inline hook changes what the address *means*, and both the IAT entry and the
hand-resolved export point at the same patched code, so "both NULL" is consistent
with both. That needs a different instrument — disassembling `GetProcAddress` and
looking for a `jmp` at its entry — and it is not worth writing unless the question
becomes load-bearing. What is settled is the part that mattered: **it is not our
import.**

**Verified separately: the hand-read pointers are sound.** All six RVAs were
checked against the on-disk `GameAssembly.dll`. Three are direct
(`40 53 48 83 EC ..`, `48 89 5C 24 ..`, `48 83 EC ..` — real prologues) and three
are `E9 rel32` thunks immediately followed by `CC CC CC …` INT3 padding:

```
il2cpp_string_new         E9 1B 9D F9 FF  CC CC ... -> 0xFE590   40 53 48 83 EC 50
il2cpp_array_new          E9 5B 7D 38 00  CC CC ... -> 0x50CE50  40 53 48 83 EC 20
il2cpp_runtime_class_init E9 CB 4C 18 00  CC CC ... -> 0x3745E0  48 89 5C 24 10
```

Each thunk follows to a valid prologue in one hop, which is what
`follow_export_thunk` does. This matters more than it looks: **that `CC` padding
is INT3, which is exactly what a "breakpoint encountered" dialog reports.** So
the one place in this project where a pointer mistake would produce the dialog
the user saw has been checked, and the thunk-following is correct on all three.
It is the strongest negative evidence available for "the new resolution path is
not the cause", and it was worth checking before attributing anything to it.

**One diagnostic still owed, and it is cheap — NOW ADDED.** The boot gate used to
log `path="<not loaded>"`, which conflates two states needing opposite responses:
the module is absent, or the loader will not name a module that is present. That
ambiguity is part of why the first diagnosis had to be inferred. It is now
`il2cpp_offsets::log_module_state(when)`, which reports the handle, whether the
loader **lists** it, whether it will **name** it, the module count, and
`SizeOfImage` read straight off the module's own PE headers with no loader
involved — so it answers even when the module is mapped but unlisted.

**It is called twice**, at the Unity gate and again after `il2cpp_offsets::init()`,
which turns one ambiguous reading into a **two-point timeline**:

- membership flips between them → the unlink **races startup**, and a retry would
  have been worth something after all
- already unlisted at the gate → the unlink happened before we were ever called,
  and the direct read was the only thing that could ever have worked

That is the one question the previous round could not answer, and it is worth
answering because it decides whether the retry is worth adding on top of the
fallback or whether the fallback is simply the answer.

**And positive confirmation of the fallback**, which is a separate gap: a launch
that never hits the problem and a launch the fallback saved produce identical logs
otherwise. `init()` now logs

```
boot[il2cpp]: N of 14 required symbol(s) needed a direct read of the export table
              because GetProcAddress could not. <the loader listed the module for all
              of them this launch | ...startup succeeded anyway.>
```

`0` is a real result, not a no-op line — it says the loader listed the module for
every symbol that launch, which is what distinguishes "the fix is idle" from
"the fix never engaged".

### 5.10 SOLVED 2026-10-02 — "Start Profiler" published its gate before the profiler existed

The user reported the game dying when they started Tracy's profiler, with the game
under heavy load, and asked whether that was coincidence. **It was not, and the
load was a red herring — the load just made the window wider.**

**This is the first crash in this project with a stack, and it is the first fault
inside our own module.** The crash probe reported, on `tid=8344`:

```
code=0xC0000005 flags=0x00000000 at 00007FFCCD1C0B03
faulting rva=+0x100B03
ACCESS_VIOLATION READ of 0x0000000000000008
  #0 00007FFCCD104E57 +0x44E57
  #1 00007FFCCD483368 +0x3C3368
  #2 00007FFCCD483328 +0x3C3328
  #3 00007FFCCD4833D8 +0x3C33D8
  #4 00007FFCCD352349 +0x292349
  #5 00007FFCCD4833D8 +0x3C33D8
  #6 00007FFCCD1E1450 +0x121450
```

**The fault address is what matters, and it is exact:**
`rva +0x100B03 -> tracy::GetProfilerThreadData +0x43`, and the faulting instruction
is:

```
00100AF8  mov rdi, qword ptr [rip + 0x31b4e9]   ; rdi = tracy::s_profilerData
00100AFF  add rdi, 8
00100B03  mov rbx, qword ptr [rdi]               ; <<< READ of 0x8
```

The symbol at that global is an exact match: `tracy::s_profilerData`, `ProfilerData*`,
`.data`. **It was null.** The TLS access three instructions earlier
(`mov r14, [rax + rbp*8]` off `gs:[0x58]`) succeeded, so this is not a TLS failure —
it is a null profiler object. This one instruction carries the entire diagnosis.

**The frames are much weaker than the fault, and I read them too well at first.**
Symbolized with `tools/symbolize.py` against the 19:42 `.map` — 43,590 symbols — they
come out as:

```
#0  tracy::profiler::Zone::Zone +0x2E7                  <- plausible, and it fits
#1  ??_C@_0CL@DEGIHAGN@common_hooks?3?3...              <- a STRING LITERAL
#2  ??_C@_0DN@HJJIMLPG@D?3?2TarkovAddonsReloaded...      <- a STRING LITERAL
#3  ??_C@_0CE@NCLOBAMA@frame?3?3hk_tarkov_applicat@     <- a STRING LITERAL
#4  asset_bundles::check_progress +0x239
#5  (as #3)
#6  dxhook::release_texture_id +0xE0
```

**This is now fixed at the source — §5.14 Gap 2.** `fill_event` tests each candidate with
`RtlLookupFunctionEntry` (`.pdata` ⇒ code), and reports the rejected count in the header
line, so the four data words above would have been labelled rather than named. What
follows is the measurement that led to that change.

`??_C@_...` are compiler-generated **data** symbols. The probe collects stack words
whose value falls inside our module's address range; it does not check that they are
return addresses, or that they point at code at all. #4 and #6 carry the same smell —
unrelated small functions at odd offsets (`+0x239`, `+0xE0`), which is what a stack
*value* looks like when it lands near code by coincidence.

**An earlier, partial symbol table made these frames look far better, and I wrote the
chain down before checking it**: #4 `hk_tarkov_application_update +0x49`, #6
`dxhook::WndProc +0x0`. Both were the *parser's* fault, not the crash's. The first
version of `tools/symbolize.py` required exactly one alphabetic character in the map's
type column and dropped **26,363 of 43,619** symbols; the resulting holes resolve to
*nearest preceding symbol*, which for those addresses was simply the wrong function.

> **A truncated symbol table does not degrade into "unknown". It invents confident
> neighbours.** That is a worse failure than reporting nothing, because the invented
> chain is plausible enough to build a story on — and I did build one.

The retracted chain is left in the record rather than deleted, because that is the
failure and the reason not to trust it. **One frame survives:** #0,
`tracy::profiler::Zone::Zone`, matched on its exact signature, which is what the
null-dereference path predicts. The rest is noise until the probe unwinds properly.

**Live confirmation, 2026-10-02 20:50 — the fix held.** A later session on the
rebuilt DLL (`build stamp=0x6ABFECD9`) pressed Start Profiler at 20:50:12 and ran to
21:16:48 with no fault. That is the one check that could not be faked, and it is now
done. The same session needed `0 of 14` direct reads, so `GetProcAddress` worked
normally and the export fallback never engaged — the first launch of that session that
has not needed it.

**Root cause, in `util/tracy_bridge.cpp`:**

```cpp
bool start() {
    if (g_started.exchange(true, std::memory_order_acq_rel)) return true;  // publishes
    StartupProfiler();                                                    // allocates
    return true;
}
```

`g_started` is the gate every `tracy::profiler::Zone` reads
(`if (!running()) return;`). Under `TRACY_MANUAL_LIFETIME`, **all** of Tracy's
state hangs off `ProfilerData* s_profilerData` — a plain non-atomic pointer — and
`GetProfilerData()` is `TRACY_ASSERT(s_profilerData); return *s_profilerData;`.
The assert compiles out under `NDEBUG`, which both Prod configs define, so there is
**no null check at all** on the read path. So:

> `start()` published "started", then allocated the profiler data. Any `TA_ZONE` on
> any other thread in that window built a real `tracy::ScopedZone` against a null
> `s_profilerData`, and the process died.

The window is not narrow: `StartupProfiler()` calls `SpawnWorkerThreads()` before it
returns. Under load, the main thread is in instrumented code far more of the time,
so the chance of a zone landing in the window rises — which is why the load looked
causal.

**The log ordering is what made this look like a coincidence, and it is worth
recording.** The probe wrote its report, and *then*, 240 ms later:

```
[19:47:17.522 pid=22492 tid=5976 INFO] tracy: profiler started on 127.0.0.1:8086
```

`logger::info` runs *after* `start()` returns in `DebugLogModule::draw_tracy_controls`,
so the crash landing before that line is the expected order, not evidence against
the diagnosis. The line marks the end of the button handler, not the start of the
profiler.

**The fix — two parts, and only the first is the fix:**

1. `start()` calls `StartupProfiler()` **first** and publishes `g_started` **second**
   (`store` after, not `exchange` before). This is the defect.
2. `running()` returns `g_started && tracy::IsProfilerStarted()`. Tracy sets
   `s_isProfilerStarted` as the **last** statement of `StartupProfiler()` and clears
   it as the **first** statement of `ShutdownProfiler()`, so it is the one flag that
   cannot be true while `s_profilerData` is null. Not a fix on its own — it makes
   the invariant structural rather than positional, because statement order does not
   survive refactors. `IsProfilerStarted()` is a bare atomic load; `ZoneIsActive` and
   `GetProfiler().IsConnected()` would **not** work, they dereference the very pointer
   being guarded.
3. `client_attached()` now goes through `running()` rather than reading `g_started`
   itself, so this file has one gate instead of two that can drift.

**Verified in the shipped binary, not just the source.** Disassembling the deployed
`tracy::profiler::Zone::Zone` (rva `0x44B70`) shows both flags read, in order, each
with a `je` to the inert path, before anything calls into Tracy:

```
00044BAD  movzx eax, byte ptr [rip + 0x3d780b]   ; -> 0x41C3BF  g_started
00044BB4  test al, al
00044BB6  je   0x44f46                              ; inert
00044BBC  movzx eax, byte ptr [rip + 0x3d77f5]   ; -> 0x41C3B8  s_isProfilerStarted
00044BC3  test al, al
00044BC5  je   0x44f46                              ; inert
...
00044C02  call 0x100AC0                            ; only now: tracy::GetProfilerData
00044C07  mov  rbx, qword ptr [rax + 8]             ; the read that used to fault
```

Both flags are `std::atomic<bool>` sitting in adjacent `.data` bytes (`0x41C3B8` and
`0x41C3BF`) — Tracy's from `TracyClient.obj`, ours from `tracy_bridge.obj`.

**Regression test, with a negative control that fires.** `tools/tests/test_tracy_start_order.py`,
6 cases. It is a **text** test, and the docstring says why that is adequate rather than
a compromise: the invariant is the position of two statements in one function, and
there is no way to observe it without racing threads under a debugger. Comments **and
string literals are blanked** before matching, because the negative control that
matters is a source whose *comment* claims the right order while the code does the
wrong thing — that is exactly what made `test_profile_path.py` vacuous. Verified by
running the assertions against the **real pre-fix file from git**, which they reject
with the diagnostic naming the actual cause rather than a downstream symptom.

**What this retires, and what it does not.**

*Retired:* the belief that `TRACY_CALLSTACK` caused the crash. `tracy_bridge.h` carried
a long, confident explanation attributing the older `0xC0000005` `EXECUTE` at `0x0`
to the client-side symbolizer failing (`0x40010006` = `DBG_PRINTEXCEPTION_C` from
`TracyCallstack.cpp:643 SymError()`). That inference was wrong, and the header now
says so. `TRACY_CALLSTACK` stays `0` on its original, still-valid reasoning —
`RtlWalkFrameChain` over an unregistered `.pdata` in a manually mapped, LDR-unlinked
DLL is not an input to trust — but it was never what killed the process.

*Not retired:* the older `0xC0000005` `EXECUTE` at `0x0` with `frames=0`, recorded in
§5.4's closing paragraph. It occurs on launches that die during *"Waiting for Unity
window to become ready"* - **before** `Loading Il2CPP API`, so no `TA_ZONE` could have
been running under a started profiler. **It is not this bug.** It remains unexplained
and frameless. Its shape is tempting (a READ of `0x8` now, an EXECUTE at `0x0` then)
and the temptation is recorded here precisely so it does not become a conclusion.

**Instrumentation follow-up, not done:** the probe should not report a stack word as a
frame just because it is in our address range. Checking that the candidate address
begins a plausible instruction (and that the preceding bytes end on a call/ret/jmp, or
that `.pdata` covers it) would have made six of seven frames disappear and left a
one-frame stack that is actually true. Left undone deliberately — it is a crash-time
code path, and adding logic there is how the crash becomes harder to diagnose.



#### 5.9b Diagnostics added 2026-10-02, because the above was not diagnosable from a log

**"Wait longer for the game" was proposed and refuted by the log.** Both failing
launches and both succeeding ones were timed:

| launch | Unity window found | `Loading Il2CPP API` | delta | outcome |
|---|---|---|---|---|
| tid=26264 | 15:09:39.720 | 15:09:39.722 | **2 ms** | STOPPED |
| tid=11444 | 15:09:52.664 | 15:09:52.665 | **1 ms** | **OK** |

The launch that *succeeded* had less time between the boot gate and IL2CPP init.
And on the failing launch a pattern scan over `GameAssembly.dll` **succeeded in
the same millisecond** that `GetProcAddress` on it failed, with
`Pattern resolve failed` logged **zero** times — the eight pattern symbols never
used their retry. So the module is byte-for-byte scannable before the first
export lookup. No wait duration and no readiness semaphore can help, because
readiness is not what is missing.

**What is now instrumented**, on the failure path only, so it costs nothing when
resolution works (`il2cpp_offsets.h::report_export_failure`):

- `GetLastError()` sampled **immediately** after the failing `GetProcAddress`,
  passed in as an argument because formatting a string is enough to clobber it.
  That is the entire reason it is a separate function.
- the module handle, its on-disk path, and the `GameAssembly.dll` path found at
  the boot gate — because a manifest validated against one copy is worth nothing
  if the process loaded another.
- **a hand-rolled export lookup** (`scan::find_export_by_hand`) that calls no
  Windows API, cannot be intercepted, and bounds-checks every access against the
  image. **This is the decisive instrument.** If it finds the name and
  `GetProcAddress` did not, the table is fine and the API is the failing party;
  if it also fails, the name genuinely is not exported and the manifest is wrong.
  Either way the log now says which, in a `VERDICT` line, instead of leaving it
  to be inferred.
- **a GetProcAddress-hook check.** A hand-resolved `GetProcAddress` is fetched by
  parsing `kernel32.dll`'s export table with the same reader, then called. If it
  finds the export and our IAT one does not, our `GetProcAddress` is hooked —
  which would be nobody's fault but ours, and explicitly **not** fixable by
  waiting, which closes off the last version of the "wait longer" idea.

**Boot-scheme diagnostics** (`dllmain.cpp`), same reasoning — a gate that
silently does nothing is indistinguishable from a gate that is not needed:

- each of the two boot gates now logs its **elapsed ms and poll count**. The
  Unity gate currently completes on its first check in 1–2 ms, which is why
  "wait longer" was worth testing and then worth discarding.
- `GameAssembly.dll`'s handle, **on-disk path** and `SizeOfImage`, logged at the
  moment the Unity gate opens.
- wall time for `il2cpp_offsets::init()`, `unity::init()` and
  `ModuleManager::init()` individually, so a future "the mod is slow to start"
  does not have to be re-derived from log timestamps.

**The hand-rolled reader is tested before anyone relies on it**, which is the
point of adding it this way. `tools/harness/test_export_lookup.cpp`, **43
assertions**, compiles the real `scan.h` — not a copy — and covers the properties
a hand parser gets wrong: the **PE32 vs PE32+ DataDirectory offset differs by 16
bytes** and the branch on the magic is real; the **name → ordinal → function
indirection is two levels deep**, so reading `AddressOfNames` as if it were
`AddressOfFunctions` yields a plausible-looking wrong address (asserted by
requiring two lookups to return *different* RVAs); **forwarders** are an RVA
pointing back into the export directory and must not be returned as an address;
lookup is **case-sensitive** like `GetProcAddress`; and eleven malformed-image
cases must be *refused* rather than read past, because a parser that faults on
the failure path converts a diagnosable startup failure into a crash during
diagnosis.

**Five negative controls, all firing:** removing the PE32 branch (3 failures),
removing forwarder detection (1), removing the ordinal range check (1), an
off-by-one in `contains()` (1), and removing the export-directory bounds check
(the case dies). It is in the harness rather than in pytest because it compiles a
first-party Windows header.

**Two things the work turned up, both recorded rather than fixed:**

- **`far` is a `windows.h` keyword macro.** A local named `far` silently loses
  its identifier and MSVC reports a syntax error three lines later. Same family
  as the `std::min` trap `WORKFLOW.md` already records; a new instance of it.
- **My first version of the test failed 2/43 because I forgot the NUL
  terminator** on a synthetic export name, and an unterminated name reads as
  "the export is missing" — the exact symptom the test exists to distinguish.
  That is the test catching its own input, not the parser being wrong, and it is
  why the file says so in place.

**Relation to §5.3 and the `0xC0000005`.** Separate. The `0xC000070E`
threadpool fault recurred and is again outside this module, re-confirming §5.3.
The `0xC0000005` `EXECUTE` at `0x0` with `frames=0` recurred on the launches that
die during *"Waiting for Unity window to become ready"*, i.e. **before**
`Loading Il2CPP API` — so it is not a consequence of §5.8 or §5.9. It is now
timestamped in the log rather than inferred from a minidump that does not exist,
which is a small real gain; it remains unresolvable, because there are no frames.

**Not to be absorbed by §5.10.** §5.10 solved a crash with the same *shape* — a
null from the not-yet-created profiler — but a different *time*: that one is 37 s into
a session with a profiler being started by hand, this one dies before
`Loading Il2CPP API`, which is before any instrumented zone could run. No merge.

### 5.11 The probe cannot see a breakpoint, and one was reported today

The user saw another "breakpoint encountered" warning, this time without a crash. **The
log cannot confirm or refute it, by design**, and that is the finding.

`crash_probe.h:241`:

```cpp
case 0xE06D7363: return false; // C++ throw -- captured, not reported here
case 0x80000003: return false; // BREAKPOINT
case 0x80000004: return false; // SINGLE_STEP
```

Breakpoints land in the ring and are never printed. And the ring is only *dumped* when
a fatal event fires — so on a session that does not crash, the ring is written and never
read. There is no per-code counter anywhere; `g_ring` and `g_seq` are the only state.

**What that rules in and out, which is more than nothing:**

- The probe's unhandled-exception filter reports everything, and the vectored handler
  reports every non-continuable code. `0x80000003` is not in the non-continuable set.
  **A breakpoint that had gone unhandled would still have reached the UEF and been
  logged. Nothing was logged. So the breakpoint was handled** — some handler continued
  execution — which is exactly consistent with "a warning appeared, the game did not
  die".
- We raise none ourselves. `DebugBreak` / `__debugbreak` / `int 3` do not occur
  anywhere in our code. (Do not grep the tree for `int 3` without excluding
  `ISIL-references/` — it appears thousands of times in the game's own IL2CPP dumps
  and produced a 55,000-line result the first time.)
- The 19:47 crash's `CC` INT3 padding was already ruled out as a source: all three
  `E9` thunks follow to valid prologues in one hop.

**So: outside this module, most likely the game's own `Debug.Break()` or anti-cheat.**
**Not attributable from this instrumentation.**

**The cheap fix, when someone wants it:** one `std::atomic<uint32_t>` per interesting
code, incremented in the vectored handler (lock-free, so it is fault-safe), and emitted
once per code the first time it is seen. That is a handful of lines, costs one relaxed
increment per exception, and would turn "a warning appeared" into
`crash probe: saw 0x80000003 x3, first at rva +0x... (outside this module)`. Left
undone because it is a diagnostic for a warning that has not yet caused a failure, and
adding logic to the exception path is how the exception path becomes harder to trust.

**That fix is now built — see §5.14 Gap 3.** `g_code_count`/`g_code_bits` are 8 slots
bumped in `record()`, and `emit_code_histogram()` prints the whole session's history on
any fatal, including the `0x80000003` counts the ring deliberately never shows. Two limits
stand: a clean session still cannot print it (no exit hook survives a hard kill), and a
hash collision merges two codes into one slot — which the printer names both for, rather
than printing one wrong name for a shared count.


### 5.12 Loot Teleporter categories do not match ISIL/GameDump — there is nothing to match

Asked whether the Loot Teleporter's eight categories agree with
`ISIL-references` / `GameDump`. **They cannot: the game has no per-item loot category
in this build.** Checked, not assumed:

- No `ItemCategory` loot enum exists in `GameDump/115147510/dump.cs`. The only types
  matching `*ItemCategory*` are `ECustomizationItemCategory` (dog tags) and the
  `ChangeWishlistItemCategory*` wishlist-operation types. Same answer across all five
  dumps, and across `ISIL-references/IsilDump`.
- The enum-shaped things that do exist are not item categories: `ESpawnCategory`
  (spawn points), `EMemberCategory` (group members), `CategoryLabels` (a chart
  visibility flag).
- `ItemTemp` — the template the mod actually reads — has **no category field at all**.
  Its fields are `Name, ShortName, Description, Weight, QuestItem, ELootRarity,
  SpawnChance, StackMaxSize, CreditsPrice, RagfairLevelToTrade, ...`. Category is not
  among them.

**So the eight categories are entirely our own invention**
(`LootTeleportModule::loot_ui_filter_allowed`): substring tests over the item's
**display name**. Every defect below is provable from the needle lists alone, with no
game data, and was checked rather than eyeballed:

**1. Valuables is a strict subset of Barter.** The two needle sets intersect on exactly
one word (`keycard`). Barter asks only *"does the name contain any of my 20 exclusions?"*
— never anything positive. So `LEDX`, `Physical Bitcoin`, `Rolex`, `Golden Starband`,
`Military Cable`, `Tetri College ML-6` (non-keycard variant) are all in **both**.
Picking "Barter" hands the user the valuables list plus essentially everything else.

**2. Barter is unbounded.** It has no positive requirement, so `Bolts`, `Duct tape`,
`Tool Set`, `Car Battery`, `AA Battery`, `Gas analyzer` all pass. It is "everything
else", which is not a category.

**3. Ammo cannot see a calibre.** The needles are `ammo, cartridge, round, "ap ", fmj,
tracer`. None contains a digit, an `x`, or a `/` — but EFT ammo is named by calibre
(`7.62x51 M80`, `5.45x39 PS`, `12/70 buckshot`, `9x19 Pst gzh`, `40x46 3P2SK`). Every one
of those fails. The category only matches an item whose English display name happens to
contain one of six words, which is luck rather than a rule.

**4. Categories overlap.** `SURV-12 Sniper Rifle` is both Medical (needle `surv`) and
Weapons (needle `rifle`). `MP7 A1` is only Barter — it has no weapon needle match
because there is no `mp7`/`smg` in the list beyond `smg`… and no `smg` in its name.

**5. The load-bearing one: the names are localized, the needles are not.**
`game_item_db` reads the template's `Name` field, and then `localize_snapshot()`
**replaces `entry::name` with the localized string** (`dllmain.cpp:144`: "item names are
localized"). `loot_ui_filter_allowed` matches against that. On a non-English client all
eight categories degrade to whatever the translated word happens to be, and in the
worst case match nothing — silently, because the UI still shows a category and a
non-zero-looking filter. **The `ru.json` `loot_category_*` labels are still the English
strings**, so the mod's own translation of this feature is unstarted.

**What a fix looks like, in order of value:**

1. Stop matching on the display name. The item's `ShortName` (or the template id's
   prefix) is locale-independent and is already read into the DB — a calibre test on
   `ShortName` catches ammo properly, and the known items (`ledx`, `bitcoin`, `rolex`)
   are identifiable by template id.
2. Give Barter a positive definition, or delete it. As a negative filter it is not a
   category.
3. Make the buckets mutually exclusive with a documented precedence, so an item is in
   exactly one.
4. **Decide whether it should be a table at all.** The right long-term shape is a
   template-id → category map generated once from the item DB, which also makes the
   categories testable offline. There is precedent: `item_categories.h` already does
   exactly that shape for Wishlist/Hideout from `EWishlistGroup`.

**Not done — this is a report, not a change.** It needs a decision on (1) vs (4) and a
per-locale decision, and both are the user's call.

### 5.13 CORRECTION to §5.12 — the taxonomy IS there, as the template's CLR type

§5.12 said "the game has no per-item loot category in this build" and that the eight
categories have nothing to match against. **That was wrong, and the user supplied the
correction**: the old `items.json` carried `"propertiesType": "ItemPropertiesFoodDrink"`.

**What `propertiesType` was.** The community `items.json` is a flattened dump of the
server's template table, and `propertiesType` was the **discriminated-union tag** — the
name of the concrete template class. The game itself does the same thing one level up:

```
ItemTemplate.TemplateSerializer : PolymorphicSerializer<ItemTemplate, string>
                                   // TypeDefIndex: 12126
```

so the deserializer picks the concrete class from a string tag. In the client that
string tag is not a field you can read: it is gone. **The class object carries it
instead**, and that is why searching for an `ItemCategory` enum and for a field named
`Category` found nothing. The category is not stored; it *is* the type.

Confirmed in `GameDump/115147510/dump.cs`, where the category is a class hierarchy:

| Mod category | Template class | Also carries |
|---|---|---|
| Ammo | `AmmoTemplate` | `Caliber`, `ammoType`, `Tracer`, `PenetrationPower` |
| Weapons | `WeaponTemplate`, `KnifeTemplate`, `ThrowWeapTemplate` | |
| Armor | `VestTemplate`, `ArmoredEquipmentTemplate`, `FaceCoverTemplate` (`IArmorComponentTemplate`) | |
| Food & Drink | `FoodDrinkTemplate` (`IFoodDrinkComponentTemplate`) | `MaxResource`, `foodUseTime`, `effects_health`, `StimulatorBuffs` |
| Medical | `MedsTemplate` (`IHealthEffectsComponentTemplate`) | `medUseTime`, `MaxHpResource`, `hpResourceRate` |
| Keys | `KeyTemplate` (`IKeyComponentTemplate`) | `KeyId`, `MaximumNumberOfUsage` |
| Barter | `BarterItemTemplate` + `Battery`/`BuildingMaterial`/`Electronics`/`HouseholdGoods`/`Lubricant`/`Tool`/`Fuel`/`BarterOther`/`MedicalSupplies` | |
| Valuables | `JewelryTemplate`, `ElectronicsTemplate` | both `BarterItemTemplate` subclasses |

**`FoodDrinkTemplate`'s fields are the old `properties` block, flattened into real
fields** — `MaxResource` (energy/hydration), `foodUseTime`, `effects_health`,
`effects_damage`, `StimulatorBuffs`. `stimEffects` in the JSON is the predecessor of
`StimulatorBuffs`. The user's snippet is not merely analogous; it is the same data,
before the game gave it a schema.

**Feasibility, from the mod's own headers — this is two memory reads:**

```cpp
// il2cpp-object-internals.h:45
struct Il2CppObject { union { Il2CppClass* klass; Il2CppVTable* vtable; }; ... };
// il2cpp-class-internals.h:365 -- image 0x00, gc_desc 0x08, name 0x10
struct Il2CppClass { const Il2CppImage* image; void* gc_desc; const char* name;
                    const char* namespaze; ... Il2CppClass* parent; ... };
```

`tpl->klass->name` is the template's type name. `klass` is offset 0 and `name` is in
the **always-valid** section, so **no class init, no new il2cpp export, no manifest
entry, and no pattern scan** — and none of the three risks the profile work spent
weeks on. `parent` is at `0x38` if a hierarchy walk is wanted instead of a flat switch.

`game_item_db::build()` already holds each template as `Il2CppObject* tpl` and already
reads `tpl + field->offset`. The type name is the same access with a smaller offset.

**What this kills from §5.12.** Every defect listed there was real *for the string
heuristic* — Valuables ⊂ Barter, unbounded Barter, Ammo unable to see a calibre,
overlapping buckets, and English needles against a localized name — and all five are
solved by reading the type instead:

- Valuables ⊂ Barter: impossible, `JewelryTemplate`/`ElectronicsTemplate` and
  `BarterItemTemplate` are distinguishable classes.
- Barter unbounded: `BarterItemTemplate` is a positive test, so Barter becomes
  "everything else" *only if someone deliberately writes it that way*.
- Ammo: `AmmoTemplate` is exact, and `Caliber` is locale-independent.
- Overlap: a documented `switch` precedence, or none at all if each item lands in one
  arm.
- Localization: the type name is never localized.

**Why I got it wrong, so it does not recur.** I checked for an enum named
`ItemCategory` and for a field named `Category`, found neither, and concluded the
concept was absent. I did not check whether the *hierarchy of the type* encoded it —
and §5.12 even said "`ItemTemp` … has no category field", treating a missing field as a
missing concept. **A missing field is not a missing category.** The general form: when
a concept is absent from a schema, check whether the schema's *type* carries it before
concluding the concept does not exist.

**Not done — report, plus one piece of evidence.** Reading a type name is easy;
deciding the mapping is a design call (interface-based via
`IHealthEffectsComponentTemplate` vs base-class switch; whether
`MedicalSuppliesTemplate` is Medical or Barter; where Spec/Compound/Container go) and
the mod's own `item_categories.h` is where it belongs.

**One thing was built, because "it should work" is not evidence.** `game_item_db.h`'s
`enumerate_template_dictionary` now tallies `tpl->klass->name` per entry and logs one
line after the loop:

```
game item db: {N} distinct template classes - FoodDrinkTemplate=…, AmmoTemplate=…, …
```

Rationale, and it is the same reasoning as §5.10's binary verification: the entire
argument above rests on a reading of `dump.cs` plus a struct layout, and **that kind
of evidence has already been wrong once in this very section** (§5.12). The next raid
prints the real taxonomy with real counts, and either confirms the read or refutes it
before any category depends on it. Costs one load per template from a pointer the loop
**already dereferences** — the guard is literally `if (!tpl || !tpl->klass) continue;`
— so there is no new dereference and no new risk. Emitted inside the shared function
rather than at either call site, because both build paths funnel through it and a
diagnostic at one call site is a diagnostic that one path silently skips.

Deliberately **not** stored in `entry` yet: nothing consumes it, and a per-entry
`std::string` for 6,000 templates is 192 KB and a second owning copy of a name that is
already sitting in the class object.

**What would settle it:** one line in the log after a raid. If the class names come
back, the taxonomy is real and the five defects in §5.12 are all fixable with a
`switch`. If `klass->name` comes back as `ItemTemplate` for everything, the type is not
what I read it to be and nothing here should be built on it.

**SETTLED, AND LANDED.** The class names came back and the taxonomy is real. Both modules
now resolve the category from the ItemTemplate's class ancestry
(`item_categories::loot_from_ancestry`, cached per entry at db build time as
`entry::loot_kind`) and ask one shared predicate,
`item_categories::loot_category_allows`. `EspModule`'s substring switch,
`contains_any`, `database_name_for_template` and `LootTeleportModule`'s duplicate
`loot_ui_filter_allowed` are gone. The four-option filter (Quest / Wishlisted / Selected
item / Category) is likewise one function, `item_categories::matches_teleport_filter`,
because the two copies had already drifted and a duplicated predicate is how they drift
again. See `CHANGELOG.md` §0.61.

One thing the fix removed that was not in §5.12's list: both copies of the four-option
filter answered "Category" by calling their own `loot_ui_filter_allowed`, which applies
the **"selected items only" gate before the category gate** — so with both toggles on,
"one category" silently meant "the selected item, if it happens to be in that category".
Both toggles default off, so it was latent. It is now decided in one place and there is a
regression assertion for it.





### 5.14 A crash that could not be named, and the three instrumentation gaps it exposed — SOLVED

The 22:0x crash is **not** the Tracy bug and not the breakpoint, and the reason it took
this long is worth more than the crash itself.

```
code=0xC0000005  ACCESS_VIOLATION READ of 0x0000000000000050
faulting rva=+0x1AD7AA     tid=23656     frames=11
captured #4036 … #4059     (the ring had already wrapped past 4000)
```

Different code, different offset, different read size, different thread from §5.10's
`+0x100B03 / READ of 0x8 / tid=8344`. A third session in the log, `pid=4588` — the `pid=`
field distinguishing three writers in one file at once.

**It is in our image, and it cannot be symbolized.** The fault is at a module RVA, so it
is ours. But:

```
crashed build stamp       = 0x6AC00784
deployed TarkovAddons.map = 0x6AC0093E
```

A **later** build had been deployed between the crash and the read. So every name is
worthless, and that is measurable rather than arguable: a function entry begins with a
push/sub/endbr64/REX prefix, so under a shifted map a stale RVA lands mid-instruction.
**1 of 11 frames decoded at a plausible instruction start**, and the fault address decoded
to *nothing at all*. The first symbolization pass produced `AimbotModule::AimbotModule
+0x2EA`, `menu::draw +0x1D5B`, `dxhook::dxPresent12 +0x1ACC` — a tidy little render-frame
story, entirely invented, and caught only because the decode check ran before believing it.

> The build stamp **detected** the mismatch, which is exactly what it was added for. It
> did not *name* the crash. Detecting that you cannot read the answer is not the same as
> being able to read it.

**Gap 1, fixed: symbols are archived per build.** `deploy.py install` already copied
`TarkovAddons.map` and `.pdb` beside the DLL — so this was **not** a missing-file problem,
and "copy the map beside the DLL" would have changed nothing. The problem is that one slot
gets overwritten by the next install. It now also writes `symbols\<PE-TimeDateStamp>\`,
keeping the newest `SYMBOL_ARCHIVE_STAMPS = 8`.

- The stamp is the **same field** `crash_probe.h` prints as `build stamp`, read from the
  same place by `deploy.build_stamp()`. Verified: `0x6AC0093E` from the DLL, `0x6AC0093E`
  from the map, `None` for a non-PE file.
- Re-installing the **same** stamp overwrites in place rather than consuming a slot, which
  is the common rebuild-install-rebuild-install case and would otherwise evict a build that
  was never actually distinct.
- `symbols\` is **not** removed by a plain `uninstall`, on purpose: it is the only thing
  that can name a crash from a build you have since replaced. `--purge` removes it,
  explicitly, because a purge that quietly leaves ~44 MB per build behind is not a purge.
- Failure to archive is a **warning, not an install failure** — the DLL and its data are
  already in place.
- `tools/symbolize.py --build-stamp 0x…` selects the archived map by that name, and a stamp
  with no archive exits listing the builds it *does* have rather than silently symbolizing
  against the current one. Both paths verified.

**Gap 2, fixed: frames that are not frames.** §5.10 recorded that the probe filters stack
words by module address range, so data words get reported as frames — and that four of the
seven frames in that crash were compiler-generated **string literals**. `fill_event` now
tests each candidate with `RtlLookupFunctionEntry`, which consults `.pdata` and so returns
non-null for code and null for `.rdata`/`.data`. That is exactly the code-vs-data question
answered by a function the OS already provides, and it needs no PE headers — which matters
because this image is manual-mapped and its headers may not have been copied (the same
reason `mapped_extent` falls back to a VirtualQuery walk). Rejected candidates are
**counted** (`ndata`) and reported in the header line as
`frames=3 (+4 in-module data words, not code)`, because silent filtering is what made the
original report look complete when it was not.

**Gap 3, fixed: no per-code totals.** §5.11's exact complaint — a user-visible "breakpoint
encountered" that the log structurally cannot see — is now measurable.
`g_code_count`/`g_code_bits` are 8 relaxed-increment slots bumped in `record()` *before* the
ring write (so a torn slot cannot lose the count), and `emit_code_histogram()` prints the
whole session's history **last**, after the per-event list. The ordering is the point:
`captured #4059` means nothing alone, whereas "4059 of 4060, and the other 4059 were
`DBG_PRINTEXCEPTION_C` on one thread" is a diagnosis. A hash collision merges two codes and
names **both**, because visibly odd beats confidently wrong.

A clean session still cannot print the histogram — there is no clean-exit hook that
survives a hard kill — but the session that *crashes* can, which is when it is wanted, and
only codes actually seen are listed.

**Also: the AV now states its own arithmetic.** For an access violation the probe prints
`offset +0x50 from <base>` or `address is null + 0x50`, because "null plus a field offset"
is the reading that has been right every time and it took three crashes to notice it was
being left implicit.

**What is still open:** the 22:0x crash itself. `symbols\6AC00784\` does not exist, because
that build predates this change, so it will never be named. It is a `null + 0x50` read —
the same *shape* as the Tracy `null + 8`, a field through a null object — and that is as
far as the evidence goes. §5.11's `uninstall --yes` external test for `0xC000070E` is still
unrun.

**The histogram's first real output, 2026-10-03 07:13 — and it immediately corrected
§5.3's characterisation.** Seventh occurrence of `0xC000070E`, and for the first time
there are numbers:

```
crash probe: 36 exception(s) seen, by code:
crash probe:   0xE06D7363 C++ exception                               x7
crash probe:   0xC000070E THREADPOOL_FREE_LIBRARY_ON_COMPLETION_FAILED  x29
```

**29, not one.** Across three threads — `tid=24020` ×1, `tid=24032` ×3, `tid=24036` ×1
in the visible ring, the rest scrolled past. §5.3 recorded six sightings as six separate
events and concluded "not ours, outside this module". That conclusion still holds, but the
*shape* was wrong: this is a **burst**, not a stray.

**It happens at startup, not during play.** The whole session is 387 ms:

```
07:13:09.358  console-encoding selftest
07:13:09.451  Loading Il2CPP API
07:13:09.678  Loaded Modules          (ModuleManager::init took 187 ms)
07:13:09.730  Hooked Present
07:13:09.745  Menu Key: Insert
              FATAL (unhandled exception filter)  0xC000070E
```

The process died roughly **a quarter second after the mod finished loading**, during the
game's own start-up, while the threadpool is still doing its first work. That is a much
more specific target than "occurs sometimes during a session", and it is the first hard
timing this fault has ever had.

Two things it does **not** tell us: which library is being freed while work is pending,
and whether our loading *causes* the burst or merely lands next to it. The mod loads
~300 ms before the crash, which is suggestive and is not evidence.

**Symbolizing it is a formality, and the tool says so rather than guessing:**

```
build   6AC07EA6 -> ...\symbols\6AC07EA6\TarkovAddons.map
[addr] rva 0xDEFFBD49  OUTSIDE the symbol span 0x0..0x9D5348 -- not in this image, skipped
```

The archive held this exact build, selected on the first try, and the fault address is in
`kernel32` — outside our image, as §5.3 said. Compare §5.14's crash, where no archive
existed and 10 of 11 frames were invented: **the gap that produced that mistake is
closed.**

### 5.15 The 2026-10-03 crashes - ROOT-CAUSED AND FIXED, corrected later the same day

**This entry was first written as OPEN/UNEXPLAINED and it was wrong.** It is
corrected here rather than deleted, because the wrong version is the interesting
one: it hypothesised a float/pointer confusion in the *optics* path, and the real
cause is in the *aimbot's* penetration walk. Full analysis in `CHANGELOG.md` 0.16.

| | 14:45 | 16:49 | 17:54 |
|---|---|---|---|
| exception | `0xC0000005` READ | `0xC0000005` READ | `0xC0000005` READ |
| fault offset | `...E798` | `...E798` | `...E798` |
| deployed build | `0x6AC0E6B4` | `0x6AC0F46A` | `0x6AC10BEC` |
| probe report | lost with the log | yes | yes |
| minidump | **no** | yes, 29.7 MB | **no** |

Three consecutive builds, one instruction. `tools/symbolize.py` against `6AC10BEC`
names the chain:

```
frame 0  skeleton_vis::read_ballistic_identity        +0x2A2
frame 2  skeleton_vis::describe_layer                 +0x54
frame 3  skeleton_vis::try_read_ballistic_penetration +0x60
frame 4  skeleton_vis::assess_ricochet                +0xCB
frame 5  skeleton_vis::try_read_layer_penetration     +0x1D
frame 6  skeleton_vis::is_target_visible_penetrating  +0xF89
```

**Cause:** a managed call on a **freed collider**. The read at `+0x10` is
`UnityEngine.Object.m_CachedPtr`, which every managed call dereferences at
`this+0x10`, and `read_ballistic_identity` had no readability guard. `ballistic`
comes off `Shot.TryGetBallisticCollider` on a live raycast hit; by the time the walk
has classified a layer and reached its own diagnostic, the object can be gone.

**Fix:** `read_ballistic_identity` now gates every managed call on
`eft_api::is_readable_address_cached`, **checked per hop** - `go` and `transform`
are derived objects that can be freed independently of each other, so one guard on
the parent is not enough. The fix came out of the 17:54 crash; the `+4` build
predates it, which is why it still faulted.

**The correction worth keeping, and it is about how we read our own logs:**

> **"`<outside this module>`" never meant the mod was innocent.** On the
> `faulting rva=` line it only means *the faulting instruction is not ours* - here a
> UnityPlayer thunk. The `frames=` list is a different thing, and that is where our
> code is. This entry's first draft read the two together and exonerated the mod on
> the strength of a phrase that cannot carry that meaning, and it sent the earlier
> CHANGELOG 0.12 and 0.13 analysis after the wrong suspect too.

Two things settled on the way past, both worth not re-deriving:

- **The instrument was not the cause.** The one-shot hierarchy probe (`vis-probe`)
  was *removed* from the build and the game still crashed with an identical
  signature. `vis-probe` appears zero times in the log now.
- **The offending addresses were a real signal, read against the wrong subsystem.**
  They ended `0x00000010` and the fault really is a read at `+0x10` - so the
  observation was right and only the attribution was wrong.

**Still open, and it is not this crash:** `esp_scan::quest_poi_scan` max 195.7 ms
against `poiScan=195728us` - 40.6% of a 482 ms frame tail, and the first part of it
measured rather than guessed. **209 ms of that tail is still unattributed**, because
`do_quest_items`, the `publish()` group, `scan_bot_corpses_for_minimap` and the
grenade/tripwire/keypanel scans still carry no zones. Separately, `vis-breakdown`
still never prints because no raid has been long enough - measured, not broken:
`frame::EspModule::gameworld_update` ran 3,180 calls at 1.55 ms mean, ~28 s of game
thread against a 30 s reporter threshold. ~10% more raid time closes it.


### 5.16 The probe cannot see an unhandled C++ exception — CAUSE CONFIRMED, decision pending

The 2026-10-03 13:26:54 crash (`0xE06D7363`, `KERNELBASE.dll+0xC41CA`, main thread,
in transit, immediately after `Local Raid Ended`) produced **no probe output at
all**, while the 12:38 access violation produced a complete report. Two causes were
possible and nothing on disk could separate them.

**Measured.** `crash_probe::verify_handlers()` — added 2026-10-03 for exactly this —
settles it, and fired in both evening sessions:

```
crash probe: WARNING (vectored handler): the terminate handler is 0x00007FF88EE25230, not ours
crash probe: WARNING (vectored handler): the unhandled-exception filter is 0x00007FFFCA6006A0, not ours
```

- The **terminate handler is byte-identical across both processes**
  (`0x00007FF88EE25230`) — a system DLL, mapped at the same address every time.
- The **unhandled-exception filter differs per session** — inside the game's image.

**So: both single-slot report doors are taken by the game.**
`AddVectoredExceptionHandler` is a *list* and survives. `SetUnhandledExceptionFilter`
and `std::set_terminate` are one pointer each, last writer wins, and the game wins
because it initialises for minutes after we inject.

**Consequence, stated plainly:** an unhandled C++ exception is *structurally*
invisible to this probe, not merely rare. That class will never produce a report
until somebody decides otherwise. The 12:38 crash was caught precisely because it
arrives through the one door that cannot be taken.

**The decision — deliberately not taken, and it should stay that way by default.**
The probe detects the displacement and does **not** reclaim the slot, because
reclaiming it would suppress Battlestate's crash dialog and its own minidump, which
changes how the process dies. If that class is wanted:

- the cost is one line (re-assert `SetUnhandledExceptionFilter(on_unhandled)` from
  the vectored handler, rate-limited), and
- **the benefit is bounded: it only covers crashes the game does not handle itself.**
  Whether the game's handler is already doing the reporting is the open question,
  and it is **not answerable from a log.** Worth knowing before paying.

### 5.17 WER local dumps are not a reliable artefact — 2 dumps from 5 crashes

Measured with `HKLM\...\LocalDumps\EscapeFromTarkov.exe` set throughout
(`DumpType=1`, `DumpCount=10`, `%LOCALAPPDATA%\CrashDumps`, enabled by
`tools/enable_localdumps.ps1`):

| crash | WER event | minidump |
| --- | --- | --- |
| 10:35 `0xC0000005` (inside our own VEH) | yes | no — setting came later |
| 12:38 `0xC0000005` | yes | yes |
| 13:26 `0xE06D7363` | yes | **no** |
| 14:45 `0xC0000005` | yes | **no** |
| 16:49 `0xC0000005` | yes | yes |
| 17:54 `0xC0000005` | yes | **no** |

Three of five produced no dump, with WER logging every one. **No pattern
established** — in particular it is *not* "access violations dump and C++ exceptions
don't", because 12:38 and 16:49 were both access violations and only one dumped.

**What to do:** treat `util/crash_probe.h` and `tools/probe_test` as the primary
evidence path; they are the only ones that have been reliable. Treat dumps as a
bonus. **Do not plan a diagnosis around a dump existing** — §5.15's 14:45 crash
has a WER event and nothing else.

**Related, resolved:** the log is truncated by hand before a test run, which is why
that 14:45 session left no log. Nothing in the code does it — `logger.cpp:125` uses
`std::ios::app` and `crash_probe::open_log()` uses `OPEN_ALWAYS`. The habit to add
is **copy the log aside before relaunching after a crash**, since it is the only
artefact that reliably survives one.

### 5.5 A dead test-safety function, found on the way - and then deleted

`data_migration::real_appdata_root()` (`util/data_migration.h:119`) read
`%APPDATA%` from the Win32 environment block rather than the CRT copy,
"so a test cannot accidentally point this at its own sandbox and pass
vacuously." It had **zero callers** anywhere in the tree. The safety net was built
for a test that lived in `%LOCALAPPDATA%\Temp\opencode\ta_tests` and was destroyed
by temp cleanup; the net outlived the thing it was for.

`tools/harness/test_data_paths.cpp` then used it, for the reason it was written:
it captured the real `%APPDATA%` *before* redirecting, re-fingerprinted it
afterwards, and failed hard if anything under it moved. `WORKFLOW.md` records that
a harness bug in this exact area once moved 23 real user files, because
`_dupenv_s` reads the CRT's copy of the environment and `SetEnvironmentVariableW`
does not redirect it — so a harness that redirects with the Win32 call and reads
back with `_dupenv_s` sees the real value, believes it worked, and migrates the
user's real profile. The harness redirected with `_wputenv_s`, **verified
through `_dupenv_s` before doing anything destructive, and skipped the scenario
rather than running it** if the redirect did not take.

**All of that is now gone, and the reason is the better outcome.** The header
moved to `tools/migrate_legacy.py` (§5.6), so `real_appdata_root` went with it.
The guard was not reimplemented, because it is no longer needed: Python's
`migrate(legacy_root, deploy_root)` takes both roots as **arguments**. There is
no ambient `%APPDATA%` to redirect, nothing to verify with a read-back, and
nothing to skip — the 23-real-files hazard cannot be expressed in a function
whose roots the caller supplies. A guard that exists because the API was shaped
badly is a reminder to fix the API; the two guard clauses here were the argument
for doing exactly that.

### 5.6 DECIDED 2026-10-01 — the legacy import moves into `tools/deploy.py`

Raised by the owner twice, and **my first answer was wrong on both counts.** The
rejected reasoning is kept because the next reader will otherwise make it again.

**What I claimed, and why each was wrong:**

- *"Bare DLL drop is a supported configuration, so deploy-time-only migration
  would skip the user it was written for."* Wrong: I over-read
  `AGENTS_TODO.md:408`, which says a bare drop is the only way to *observe* the
  RCDATA path, and promoted a test-methodology sentence into a support policy.
- *"The blocker is `deploy.py`'s ownership model — it touches only files it
  owns, which is what makes re-install safe and uninstall a clean inverse."*
  Also wrong, on inspection. The migration's source is `%APPDATA%` and its
  destination is `ta\configs\`, and **that is already in deploy's protected set**
  (`deploy.py:901-902`). The move lands entirely inside the invariant rather than
  breaking it: uninstall still finds `ta\` non-empty and keeps it, and re-install
  is still a no-op because nothing is overwritten.
- *"The trigger is a stale layout, not 'a deploy last happened'."* Dies on the
  fact below.

**What settles it.** `ConfigModule.cpp:263-267` documents the read path as
`ta/configs/<config>` → `ta/<config>` (the 3.2 layout) → `%APPDATA%\TarkovAddons/
<config>` (pre-3.2), and says steps 2 and 3 exist "so that an install which has
settings never silently starts up on defaults", with the 3.2 one specifically
"still read so that a **failed or skipped** migration cannot present as 'no config
found'". **The migration is therefore not load-bearing by design.** It is a
tidiness operation with a fallback behind it, so *when* it runs cannot affect
correctness. That also retires the crash-surface argument, which was weak anyway:
the code uses `error_code` overloads throughout, and the only un-disciplined calls
are four `path::string()` conversions.

**The decisive argument, and it is one that could not be solved in C++.** The
23-real-files incident recorded in `WORKFLOW.md` exists *only* because
`legacy_appdata_dir()` reads the **ambient** `%APPDATA%` — hence `_wputenv_s`, a
`_dupenv_s` read-back, a three-way guard, and a post-hoc fingerprint of the real
profile. In Python, `migrate(legacy_root, deploy_root)` takes the roots as
**arguments**. There is no ambient environment to get wrong, so the hazard does not
get guarded, it ceases to exist. The `tools/harness/test_data_paths.cpp` guard
becomes unnecessary the moment the roots are parameters.

**What does NOT move: `module_paths.h`, and it is not close.**
`chams_bundle_path()` creates `ta\chams\` on demand *during a raid*, and
`dll_directory_wide()` has to beat manual mapping and LDR hiding — the game process
is the only thing that can do that. This is not "move the paths", it is "move the
legacy import, keep the runtime path resolution".

**Shape of the change:**

- `deploy.py` gains a read-only **preflight** on `install`, run before anything is
  touched, reporting what legacy state exists.
- Per class of file, a **question**. `confirm()` already exists and `--yes` is
  already the non-interactive path, so this is nearly free.
- **Copy, verify, then delete** — not rename-first. The current C++ tries
  `rename` and only falls back to copy+remove, so the common same-volume case
  performs **no verification at all**. The safer ordering is the affordable one
  here.
- `util/data_migration.h` and the single call at `dllmain.cpp:202` are deleted.
  `rg 'data_migration::'` returns exactly that one hit, so it is a clean cut. The
  two whitelists become Python constants, covered by this repo's existing pytest
  suite rather than by a hand-rolled harness.
- The scenarios drafted in `tools/harness/test_data_paths.cpp` port to pytest,
  which is where they belong once the code is in Python. **The harness was not
  wasted** — it is what established that the seam
  (`module_paths::cached_dll_directory()`) made the logic testable at all, and that
  the fallback paths behave as documented.

**Residual risk, stated so it is not discovered later:** a user who updates the
mod without ever running `deploy.py` keeps untidied legacy data. Per
`ConfigModule.cpp` that is an explicitly handled state, not a fault — both
`ta\<config>` and `%APPDATA%\<config>` are still read. Untidied, not broken.

**IMPLEMENTED 2026-10-01, as specified above.** `util/data_migration.h` is
deleted, the call at `dllmain.cpp:202` with it, and `tools/migrate_legacy.py`
(17 KB) is wired into `deploy.py` as a read-only preflight plus an opt-in apply.
`python tools/deploy.py install --dry-run` exercises the preflight and exits
clean. The scenarios ported to `tools/tests/test_migrate_legacy.py`, 42 cases.
`tools/harness/test_data_paths.cpp` became `test_module_paths.cpp` when the
`data_migration.h` half went with the header, and `win_shim/logger_stub.cpp` was
deleted — the MSVC quoted-include trap that made the stub necessary is recorded in
`tools/harness/README.md` as a lesson for the next Windows-only case, since it
still applies to anything pulling in a header with a sibling `logger.h`.

**The guard is gone and that is the point, not an oversight.** `real_appdata_root()`
and the three-way `%APPDATA%` guard went with the header. `migrate(legacy_root,
deploy_root)`
takes both roots as parameters, so there is no ambient environment to redirect
incorrectly, nothing to verify with a read-back and nothing to skip. The 23-real-
files incident exists in `WORKFLOW.md` precisely because `legacy_appdata_dir()`
read the ambient `%APPDATA%`; the Python signature makes that class of bug
unrepresentable.

### 5.7 The first real profile, and what it says the instrumentation was missing

`tracy_traces/small_raid.tracy`, 27.7 MB, 13.7 min, one 4m50s raid, zero WARN and
zero ERROR in the log. `TRACY_CALLSTACK=0` held: no crash, which is the
confirmation the revert needed. Numbers below are from
`tracy-csvexport extract -e` (self time), which is the only form of the table that
answers "where does the time actually go" — the inclusive table is misleading
here, because `frame::ModuleManager::apply` is called from two different hooks and
so legitimately exceeds either one. **A zone's inclusive total exceeding its
parent's is not automatically a bug.**

**Two findings that changed the instrumentation.**

`hk_tarkov_application_update` held **43.2 s of self time, 1.03 ms per call**,
for code that was neither `ModuleManager::apply` nor any child zone. It was
`o_tarkov_application_update` — the game's own Update, inside our zone, charged to
our account. Now zoned as `game::tarkov_application_update`, so the outer zone's
self time is the mod's actual per-frame cost. **A self-time number is not
automatically our cost**, and the largest one in the profile was the game's.

`ModuleManager::apply` held **35.0 s of self time over 110,105 calls, 318 µs
each, 6.44% of the session, with nothing underneath it.** Every module's
per-frame body lands there, and only `EspModule` was measured, on two of its three
entry points. Now one inner zone carries the module name as text, placed after
the `is_active()` gate so it only fires for modules that actually run — one zone
instead of twenty.

**`is_readable_address` really is 114 µs per call, and my first reading was
wrong.** Self time equalled inclusive time *to the nanosecond* (78,015,573,526
both), so this is not preemption absorption across 680,325 samples, which is what
I claimed before the `-e` table existed. `std` 267,410 > mean 114,673 with min
20 ns, so it is a long right tail rather than a uniformly slow function — which
also means the lever is fewer probes, not a faster check. It independently
corroborates the ~207 µs and ~186 µs per call this codebase already recorded at
`hideout_reflection.h:216-217`, so the anomaly is old, not new.

What the profile still cannot say is *which readers* drive those 680,325 calls.
`always_on::read_guarded` is now zoned on the template (all 35 call sites, one
bucket) to split them. `skeleton_vis::readable_range` is zoned because it is a
**raw** `VirtualQuery` that appears in neither that zone nor its `probe_scoped`
counters — and `optics_lens_pipeline.h:176` is a third such bypass, in another
workstream's file. So the probe picture was known-incomplete before this change,
not merely coarse.

**Not added, and the reasoning matters more than the omission.** The three
`il2utils` resolvers measure **0.28% combined**, and the question a hit/miss split
was meant to answer is already answered: `resolve_field` ran **6,939,864 calls at
176 ns mean**. That is the memo working — measured, where before it was argued from
source. Six more zones to keep confirming a settled result is the same
over-instrumentation the 15 `hideout::` zones already demonstrate: half the zone
count for **0.148%** of the session. Those 15 are the largest available reduction
and are **blocked**, because `production_panel_probe.h` is the other workstream's.

**A tooling correction, and it was my error, not a gap in the tools.**
`tracy-csvexport` works and needs no `extract` subcommand:

    tracy-csvexport -e capture.tracy        # exit 0, CSV on stdout

I earlier recorded that it "rejects every invocation" and that there was no
automated path from a capture to numbers. Both wrong. The usage text *prints*
`extract [OPTION...]` while rejecting it, so I read the help output as the
contract, concluded the subcommand was mandatory, and then debugged argument
permutations against a phantom for the rest of the session. Two captures, four
"failed" invocations and a `--self` guess, all of it unnecessary. **`-e -t` does
fail**, so the truncated mean is genuinely unavailable on this build (0.14.1).

`tracy-profiler` is separately a native GUI app — it runs, binds no port and
prints nothing — so it is not reachable headlessly. That is a real limitation,
but it is not a limitation on the *numbers*: `csvexport` covers that.

**CLOSED — the `[transitdbg]` flood is rate-limited.** This was the standing item
when the section was written: 1,415 lines in one minute, every one of them
`[transitdbg]`, from a per-frame field dump, and the log could not be used to hear
anything else. It is now limited to 1 s per tag **with a suppression count**, so
an under-report is visible rather than silent. A later session shows a worst
minute of 135, and zero `base not resolved` lines — which also means the ungated
per-iteration `logger::warn` in the `always_on` MoveNext hooks is latent, not
firing.

### 5.7b What five captures and the probe work actually cost, 2026-10-01 → 10-02

The four captures after this section (`current+3` … `current+6`, 51 → 421 MB) were
spent closing the probe line, and the result is the headline this section was
reaching for:

| | `is_readable_address` |
|---|---|
| `current+3` | 91.621 s / 2,493,902 calls |
| `current+4` | 0.091 s / 2,897 calls |
| `current+5` | 0.149 s / 3,990 calls |
| `current+6` | 0.119 s / 2,029 calls |

**~600-1000×, stable across three captures.** The mechanism was routing eight
field-slot sites through the existing `is_readable_address_cached` memo rather
than anything clever: 256 → 4,096 slots and a Fibonacci high-bits hash, with the
trailing mask mandatory (`>> 32` alone is a 32-bit index into a 4,096-entry array,
which is an out-of-bounds write — shipped by mistake once and caught only because
the harness crashed with no output). The sibling optics table was resized the
same way and went 29.385 s → 0.092 s, `vq=0`. `unity::is_unity_object_alive` got
its own 16-slot memo with a 64-call TTL and holds 98% with revalidations tracking
misses. `clear_probe_region_memo()` runs on every raid boundary, which is what
bounds staleness — the only defence a cache over freed memory has.

Two lessons from doing it, both of which the profile alone would not have given:

- **Memoisation was the fix, not a faster check.** `VirtualQuery` costs ~46-200 µs
  in this process. The lever is fewer syscalls; nothing about the check itself was
  the problem.
- **An unchecked call site is a shape, not a fault** — the same rule as §5. Rank
  by whether it can happen.

**Where the time went instead, which is the more useful finding.** The top cost is
now `skeleton_vis::is_target_visible` at 69.3 s / 9.26% over 5.5 M calls in
`current+6` — the per-target-per-frame raycast — and ESP is 73.3% of module
dispatch. Accounted time across all zones is only 13-23% of wall clock depending
on the capture; the other 77-87% is the game's render, physics and netcode on
threads this mod does not hook. That remainder is a **ceiling on what further
instrumentation can reach**, not a gap in it.

**And a number that must not be quoted across sessions.** Per-minute module cost
moved 6.16 → 11.76 s/min between `current+5` and `current+6`, and Aimbot's share
went 29.4% → 4.9% purely because a session contained less aimbot work. Reported as
percentages that reads as a 6× regression and a 6× improvement. `tools/tracy/README.md`
has the measured band: an 83× spread in call count and 59% in per-call mean from
the same binary, so a two-capture A/B cannot support a "N% faster" claim.

**2026-10-02, `nextday.tracy`, 29.9 min — the fifth and final capture of this
line. Confirmed closed:**

| capture | `is_readable_address` | calls | `probe-memo` |
|---|---|---|---|
| `current+3` | 91.621 s | 2,493,902 | — |
| `current+4` | 0.091 s | 2,897 | 100%, 52 misses |
| `current+5` | 0.149 s | 3,990 | 100%, 4,291 misses |
| `current+6` | 0.119 s | 2,029 | 100%, 2,448 misses |
| `nextday` | **1.339 s** | 27,667 | **1,566,266 hits / 1 miss** |

The last row is the one worth reading carefully, because it looks like a
regression and is not. Total time rose 11× — because the call count rose 13×.
**Per call it went down**, 59 µs → 48 µs. And one miss in 1.57 million probes with
zero evictions is the strongest statement the memo has produced: the working set
genuinely fits 4,096 slots. Optics: `hit=8112 miss=0 vq=0`, `range_readable`
0.019 s. `unity-memo` 98% with revalidations tracking.

**The cost has moved somewhere else, and it is not a probe.**
`hideout::Card::refresh_hideout_state` — **155.681 s, 8.678%, 171,433 calls, 908 µs
each** — was the single largest thing in any capture, 8× the next entry. Its
call count was *identical* to `game::tarkov_application_update`'s, so it ran once
per frame by construction, on a menu-side path. That is another workstream's file
(`HideoutModule.cpp`, dirty) and new alongside the `hideout::Card::*` zones, so it
was new code rather than something that got slower. **CLOSED by the sixth capture —
see §5.7c; that workstream owns the writeup.** `HideoutProductionRequirementView::Show`
was second at 34.8 s, and `skeleton_vis::occlusion_linecast` third at 18.7 s — the
latter being the `is_target_visible` raycast after the other workstream split it,
down from 69.3 s for the same work.

**The instrumentation is done.** 65 zones, 5 captures, one line of work closed and
a ~600× reduction that held. What remains is other workstreams' code and one
product question about what ESP should cost. **The sixth capture makes the product
question sharper and adds a second one — see §5.7c, which supersedes the "cost has
moved somewhere else" paragraph above rather than contradicting it.**

### 5.7c The sixth capture: the visibility feature is 12.4% of wall clock and wrong every time

`next_next_day.tracy` — 211 MB, written 13:28:40, raid **13:21:59 → 13:26:51** on
`factory4_day`, `mode-PVE_OFFLINE` (`hk_local_raid_started` 13:21:59, `Local Raid
Ended` 13:26:51, both in the log at pid=4304). Exports beside it:
`next_next_day.csv` and `next_next_day-self.csv`. Trace wall clock ≈ 456 s.

**Was undocumented before this entry.** The string `next_next_day` appeared nowhere
in the tree, so §5.7b's closing paragraph was the last word on a capture that
contradicts it.

| zone | total | % wall | calls | mean | max |
|---|---|---|---|---|---|
| `frame::EspModule::gameworld_update` | 43.26 s | 9.49% | 26,318 | 1.64 ms | **469.8 ms** |
| `frame::EspModule::draw_overlay` | 13.31 s | 2.92% | 38,467 | 346 µs | 9.10 ms |
| **ESP total** | **56.6 s** | **~12.4%** | | | |
| └ `EspModule::collect_skeleton` | 38.8 s | 8.52% | 169,175 | 229 µs | 13.6 ms |
| └ `skeleton_vis::occlusion_linecast` | **27.97 s** | **6.14%** | **2,964,255** | 9.4 µs | 541 µs |

**Raycast cost improved; the total-vs-total comparison must not be quoted.**
27.97 s / 6.14% / 9.4 µs against `current+6`'s 69.32 s / 9.26% / 12.5 µs is −25% per
call with roughly half the calls. Against `nextday` the total reads 18.7 s → 27.97 s,
which is a *worse* number for the same work — and §5.7b's own warning applies with
full force: 83× spread in call count from the same binary. Neither direction is
evidence.

**The hideout win is real and is not ours to write up.**
`hideout::Card::refresh_hideout_state`: 155.681 s / 8.678% / 171,433 calls / 908 µs →
**6.440 s / 1.413% / 38,467 calls / 167 µs**. 24× less time, 4.5× fewer calls, 5.4×
cheaper each, and the count now equals `tarkov_application_update`'s — the draw-frame
gate landed. Belongs to the hideout workstream.

**The open item this capture creates is a correctness bug wearing a CPU bill.**
Aggregating the eight 30 s `vis-breakdown` windows — 2,755,305 of the capture's
2,964,255 rays:

| exit | count | share |
|---|---|---|
| `hit_occluder` | 2,752,308 | **99.89%** |
| `ray_miss` | 2,997 | 0.11% |
| `inside_hit` / `no_transform` | 0 / 0 | — |
| `hit_shooter` | **0** | — |
| `hit_target` | **0** | — |

`hit_target = 0` over 2.75 M rays is not a true reading: a ray that reaches a bot
hits the bot's own collider. So `classify_hit_transform`'s 48-hop walk does not
recognise player-owned colliders, every limb of every enemy is reported occluded, and
the largest single leaf in the capture is producing an answer that is wrong every
time. ~119 casts per game update at ~114 Hz.

**Cross-validated on a different path**, which is what stops this being an ESP-mask
artefact. The pen walk uses the same `classify_hit_transform` with `shooter_obj`
correctly plumbed (`AimbotModule.cpp:444-449`, `local_player_store`), a different
origin (fireport) and a different mask (`bullet HitMask = 0x40811810`), and logs:

```
L0 go='eurocube_skeleton_01_BALLISTIC_metalthin' dist=5.42 ... -> pass (clear)
L1 go='Catwalk_floor_concrete_01_BALLISTIC_concrete'      -> BLOCKED (ammo_vs_level)
```

`eurocube_skeleton_01` is a bone collider **on the target**. A working classify
returns `hit_owner::target` at L0 and ends the walk; instead the target's own
skeleton is walked as a penetrable layer and the floor behind it decides the shot.
So §0.9's `shooter_obj` fix was necessary and is not sufficient — the walk itself
does not match.

**Ruled out by this capture, which is worth writing down** so the next person does not
re-run it: the origin is *not* the degenerate-rig case §0.9's
`is_degenerate_origin` addresses. `origin camera=3430 fireport=0 rig=0` — the
trust-tested camera won every one of the 3,430 resolutions. `not_ready=0`, and
`g_transform_get_parent` is non-null by construction (`skeleton_visibility.h:290`).

**Leading hypothesis, not yet confirmed:** player bone colliders are not parented
under `get_player_transform(player_obj)` within 48 hops. Supporting hint —
`skeleton_vis::is_player_transform` self time is **461 ns mean over 2,961,258
calls**, which is one or two parent hops, not a walk that terminates on a match.

**Now instrumented for it.** `probe_occluder_hierarchy` (`skeleton_visibility.h`),
called only from the `hit_owner::none` arm, prints at most 12 samples **at least 2 s
apart** and then never again: `dist`, the collider's Unity `layer` and whether that
layer is in the mask, the named ancestor chain of the hit / shooter / target, `end=`
`reached-root` vs `hop-ceiling`, and — computed by re-walking the chain
independently, since the walk's own verdict is the thing under suspicion —
`CONTAINS shooter=… target=…`.

The 2 s spacing is load-bearing, and the first version of this probe did not have it.
At ~119 casts per update and ~114 updates/s, a budget-only gate spends all 12 samples
inside the first 100 ms of the raid: one player, one origin, one instant — and that
instant is the raid-start window CHANGELOG §0.9 records as the one where the rig reads
`{0,0,0}` and `Camera.current` was independently reported to belong to a bot. A probe
without the gap collects nothing but the least representative samples available and
reports them as authoritative. Steady-state cost once the budget is spent is **one
relaxed atomic load**, with the clock read ordered behind it so it never happens at
all. Logged at INFO, so it does not need the debug toggle.

**Verified:** `EspModule.cpp` and `AimbotModule.cpp` (the only two consumers of the
header) compile clean, 0 errors and 0 code warnings, in **both** `Prod|x64` and
`Prod no aimbot|x64` — the probe sits outside the `#ifdef INCLUDE_AIMBOT` boundary, so
the flavour split was worth checking rather than assuming. Same four-way check passes
for the `slow_frame_probe` work. `tools/tests` is 155 passed.
A **full** project build cannot currently be used to verify anything: the parallel
hideout/quest workstream has the tree mid-edit and `QuestResetModule.cpp` /
`QuestModule.cpp` / `quest_objectives.h` do not compile against each other right now
(`completed_quest_names` is not a member of `QuestModule`). Those are not ours, were
not touched, and will be that workstream's to fix — verification was done per-TU with
MSBuild's `SelectedFiles` to route around them. Worth remembering that the `cl`
process and the shared PCH are contended between concurrent sessions, which is how
this section's first two build attempts died with `C1083 Permission denied` on
`x64\prod\tarkovaddons.pch` and then `MSBuild exit code 4294967295`.

**One process note for whoever picks this up.** `EspModule.cpp` has more than one
function ending in the same `if (!game_state::is_in_raid && (last_game_world_ptr ||
!last_raid_location_id_.empty())) { reset_raid_context(); ... }` block, so matching
the end of `gameworld_update` on that text puts the edit in the wrong function. The
first attempt did exactly that and produced `C2065: t_loop_begin: undeclared
identifier`. Anchor on the function's actual tail — the `refresh_cache_stats()`
throttle block and the `publish(std::move(temp_skeletons))` group — or use the next
`EspModule::` definition as the boundary.

**Second open question, product not correctness — do not action without a decision.**
`vis_frame_serial_` is bumped in `draw_overlay` (`EspModule.cpp:4468`) and compared
per player in `collect_skeleton` (`EspModule.cpp:953`), but the producer is the
*game* thread: 38,467 draw frames vs 26,318 `gameworld_update`s vs 169,175
`collect_skeleton` calls. A draw-thread counter gating a game-thread producer means
the memo hit rate is a product of thread interleaving, not a throttle — the gate is
close to a no-op, and the comment's premise ("the two differ by 1.67× and only one
of them is what the user sees") is true of the clocks but silent on the
cross-thread mismatch. Making it an actual throttle is a **visible-behaviour
change** — how stale a limb's visibility may get — so it is a decision, not a fix.
Measured for the decision: 6.4 players per update × ~17.5 bones ≈ 119 casts/update.

**Third, and separate: the hitch — and two earlier notes here had this wrong.**
`frame::EspModule::gameworld_update` is mean 1.64 ms, std 2.97 ms, **max 469.8 ms**
(~157σ, so one frame, not a distribution). It is **not** the skeleton bone resolution:

| | max |
|---|---|
| `frame::EspModule::gameworld_update` | **469.8 ms** (self max **447.0 ms**) |
| `EspModule::collect_skeleton` | 13.6 ms |
| `esp_bones::collect_skeleton_bones` | 12.7 ms |
| `esp_bones::get_bone_transform_by_name` | 12.5 ms |

`collect_skeleton` is **2.9%** of the outlier frame. The other ~456 ms is **self**
time in `gameworld_update` — code with no zone on it. Two sub-paths are already
excluded by the capture: `EspModule::is_player_any_part_visible` **has** a zone and
appears **zero times**, so the box-visibility feature was off that session; and
`occlusion_linecast` max is 541 µs. What remains is the per-player row work
(`get_Nickname` + `build_player_label` + `try_get_head_position` +
`try_get_player_health`, ~20 µs/player at the mean) and the post-loop scan block.

**Now instrumented for it, two ways.** Permanent and free when Tracy is compiled out:
new zones on `esp_bones::get_player_body` and `esp_bones::get_skeleton_root` (the
chain runs 2–3× per bone lookup, ~1 M times per capture, and opens with an *uncached*
`resolve_method` — `il2utils::resolve_method` has no cache, unlike `resolve_field`),
which is what makes `get_bone_transform_by_name`'s 12.5 ms max apportionable at all.

Temporary and marked as such (`slow_frame_probe`, `EspModule.cpp`): `gameworld_update`
now keeps six `steady_clock` phase timers — setup / loop / row / box / skel / tail —
and logs one line per frame over **40 ms**, at most 6 times per process. 40 ms is
chosen against the measured shape, not by taste: >13σ of the 1.64 ms mean, so no
ordinary frame can reach it, while sitting well under the 469.8 ms outlier. The line
also prints `unaccounted`, the residual inside the loop the named phases do not
explain — if that dominates, the cost is in code the probe does not name and the
zones will; if `row` or `tail` dominates, one line answers it with no capture at all.

**Prime suspect, named for the reader:** `refresh_cache_stats()`, throttled to once
per second and documented in place as walking *every* cache — `item_info_cache`,
`container_item_caches_`, `corpse_item_caches_`. That is O(entries) on the game thread,
it fires on a ~1 s cadence, and it has no zone, so nothing in the profile could name
it. The cadence and the "one lone outlier frame" shape are a match. That is a
hypothesis, not a measurement — `tail` in the probe line is what settles it.

### 5.7d Two more captures, and §5.7c's central hypothesis is REFUTED

`next_next_day+1.tracy` (23 MB, 14:46) is a **pre-instrumentation** build — neither
new zone appears in it — and it is a hideout-only session, so it is useless as a
control for anything. `next_next_day+2+crash.tracy` (22 MB, 16:50) is the
instrumented build and is the one that answers §5.7c. Log pid=16776,
16:45:19 → 16:49:34.

**REFUTED: the visibility classification is not broken.** This was §5.7c's main
claim and it is wrong. The probe's two samples:

```
dist=4.78 layer=18 inMask=1 mask=0xe4441ac9 hitGo='Rack_shelf_04_COLLIDER' end=reached-root
ray o=(69.3,1.7,-73.4) bone=(36.0,1.9,38.4) hit=(68.0,1.8,-68.8)
hit    chain: Rack_shelf_04_COLLIDER <- Rack_shelf_04 <- Barrel_plastic_01_yellow_clear Group
                <- 1 <- PROPS_spawns_exits <- PROP <- OO <- SBG_Factory_Rework_Main_Building
shooter chain: PlayerSuperior(Clone) (end=reached-root)
target  chain: Bot1 (end=reached-root)
CONTAINS shooter=no target=no
```

The ray genuinely hit **a shelf on a yellow plastic barrel, 4.78 m away**. The walk
climbed nine real nodes to the scene root and correctly concluded the hit was neither
player. `CONTAINS=no` is the **right** answer, and the walk demonstrably works.

So §5.7c's "hit_target = 0 cannot be a true reading" was **overconfident and wrong**.
It can be true: the target was behind scenery for the whole observation window, and
all ~17 rays per skeleton hit the same barrel. Two structural facts worth keeping:

- `shooter chain: PlayerSuperior(Clone)` and `target chain: Bot1` are **one node each,
  then reached-root** — the player GameObject is parented directly to the scene root.
  So `classify_hit_transform` succeeds only because bone colliders are descendants of
  that node. It works; it is just less structural than the 48-hop ceiling implies.
- The occlusion mask resolved properly: **`0xe4441ac9`**, not the `0x80400000`
  fallback. Bits set: 0, 3, 6, 7, 9, 11, 12, 18, 22, 26, 29, 30, 31 — thirteen
  layers, OR'd wholesale from `WEAPON_OCCLUSION_LAYERS` / `ENVIRONMENT_HIT_MASK` /
  `BaseMask` / `HighPoly*` / `TerrainMask` / `PlayerStaticCollisionsMask` /
  `InteractiveMask` / `LootCollisionMask`. **Layer 0 (Unity "Default") is in it.**
  That is the mask half of the old question and it is now answerable: the mask is
  broad by construction, and it is the plausible reason for a high occluder rate even
  with the walk correct. Unresolved, and it is a product question, not a bug.

**CONFIRMED: the 469.8 ms frame is the post-loop tail, and `refresh_cache_stats` is
the only O(entries) walk in it.**

```
esp-slow-frame[1/6]: gameworld_update total=484818us setup=11901us loop=15963us
  row=635us box=0us skel=11362us tail=456953us unaccounted=3966us
  players=6 rowsOver1ms=0 worstRow=528us
```

`tail` = **456,953 µs of 484,818 µs = 94.2%**. Cross-checked against the trace:
`frame::EspModule::gameworld_update` max is 485,257,680 ns and `frame::module` max is
485,258,440 ns, so the probe's 484,818 µs agrees to **0.09%** — the probe is measuring
the right thing. The per-player row work is 635 µs total and `worstRow` is 528 µs, so
`get_Nickname` / `build_player_label` are **not** it either. Also excluded: `box=0`,
and `EspModule::is_player_any_part_visible` has a zone and appears **zero times** in
the capture, which confirms box-visibility was off.

Now pinned rather than suspected: `esp_scan::refresh_cache_stats` is a permanent zone
and the slow-frame line carries a `cacheStats=` bucket. It walks four unbounded
containers plus quest_esp's counters, on the game thread, once per second.

**CLOSED: the uncached-`resolve_method` chain is not a problem.** The new zones exist
precisely to answer that: `esp_bones::get_player_body` 21,780 calls at **286 ns** mean
(145 µs max), `esp_bones::get_skeleton_root` 5,940 calls at **558 ns**. 0.003% and
0.0015% of wall clock. The hypothesis was wrong; the zones stay because they are free
and this is now a standing fact rather than an assumption.

**The crash, honestly: unattributed, and I am not going to claim it either way.** One
`0xC0000005`, `READ of 0x0000369400000010`, faulting RVA **outside this module**, all
six frames outside, tid=16772 (the game thread). Timeline: raid started 16:49:03.182
(`hk_local_raid_started`), first skeleton 16:49:32.082, `vis-probe` 16:49:32.084 and
16:49:34.085, `esp-slow-frame` 16:49:32.544, aimbot `bullet HitMask` 16:49:34.490,
process dead immediately after.

It is the **first run of the build containing the probe**, which is why it is worth
naming rather than filing under "not ours":

- *For the probe:* it is the only thing added that hands Unity objects to **managed**
  calls (`get_name` per ancestor, `component_get_game_object`, `get_layer`), where
  `classify_hit_transform` merely *compares* the pointers it walks. A dangling pointer
  passed into the game faults **inside** the game — which is exactly what "outside this
  module" looks like, and why that phrase is not by itself exculpatory.
- *Against it:* both samples **completed**, printing full nine-node named chains; the
  game thread kept working after the second one (the aimbot logged 0.4 s later); and
  §5.1 records "eight crashes across thirteen hours, **no `0xC0000005` in our module**",
  so non-module crashes are the established pattern.

I could not attribute it, so the probe was **hardened rather than defended**. Every
managed call it makes is now gated on `eft_api::is_readable_address_cached` — the house
memo that took the VirtualQuery guard from 8% of wall clock to 0.07%, and the same one
`managed_string_equals_leaf` uses before touching `str->chars`. Checked **per hop**,
because an ancestor can be freed while a deeper node is still mapped. This converts
"wild pointer into managed code" into "prints `<unreadable>` and moves on". It does
not prove the probe was innocent; it removes the one class of fault I introduced.

**Still missing, and it is why the counters never arrived:** `vis-breakdown` printed
**zero** times. It is throttled to 30 s and `gameworld_update` only runs once a
`GameWorld` exists — the raid began at 16:49:03 and the process died at 16:49:34, so
the window closed ~1.5 s after it opened. The `hit_target` rate for a session with an
*unobstructed* bot is still unmeasured, and the probe only got 2 of its 12 samples for
the same reason. A longer raid is what closes this.

### 5.7e The probe is removed: it crashed twice, and my hardening of it was incomplete

`next_next_day+3+crash.tracy` (37 MB, 17:54) — also named `+crash`. Log holds two
sessions now (pid 16776 then pid 22200); the log is appended, not rotated, so read by
`pid` first or the two interleave.

**The crash repeated, with an identical signature.**

| session | build | probe samples | crash | faulting offset | read address |
|---|---|---|---|---|---|
| 13:26 | pre-instrumentation | 0 | no | — | — |
| 14:46 `+1` | pre-instrumentation | 0 | no | — | — |
| 16:49 `+2` | probe v1 | 2 | **yes** | `…E798` | `0x0000369400000010` |
| 17:54 `+3` | probe v2 (hardened) | 8 | **yes** | `…E798` | `0x0000429400000010` |

Same low offset (`E798`) in both, and both reads at **`+0x10`** — the first instance
field of an `Il2CppObject`, i.e. `*(garbage + 0x10)`. Two for two on instrumented
builds, none on the two that lacked it. **My §5.7d hardening was incomplete**: I gated
`hierarchy_chain`, `gameobject_layer` and the `hit_go` name, but left
**`chain_contains` walking parents through `g_transform_get_parent` unguarded** — up to
20 unguarded managed calls per sample, 160 across `+3`'s eight samples. That hole was
present in *both* crashing builds.

**So the probe is removed, not fixed.** `probe_occluder_hierarchy`,
`chain_contains`, `hierarchy_chain`, `gameobject_layer`, `hier_probe_due`,
`g_hier_probe_budget`, `kHierProbeSamples/Hops/GapMs` and the `hit_owner::none` call
site are all gone from `skeleton_visibility.h`. Removing a diagnostic is the correct
response to "it may be causing crashes" regardless of whether it is guilty: the
question it existed to answer is answered (§5.7d), so there is nothing left to trade
crash risk for.

**What the eight `+3` samples added, and it confirms §5.7d rather than changing it.**
Ten samples over two sessions, every one the same shape:

```
hitGo='Area_02_inside_wall_D_COLLIDER'  chain: Area_02_inside_wall_D <- SOO_LOD0 <- SBG_Factory_Rework_Areas
hitGo='Case_shower_COLLIDER'             chain: Case_Shower <- A <- Factory_floor_wood_beams <- PROP <- OO <- …
shooter chain: PlayerSuperior(Clone)    target chain: Bot1  /  Bot5
CONTAINS shooter=no target=no            dist 1.25–3.02 m    layer 18
```

Ten for ten: a genuine prop or wall on **layer 18**, chains resolving cleanly to
`reached-root`, and `CONTAINS=no` — the **correct** verdict. The classification walk is
correct; the high occluder rate is real occlusion. Masks differed between sessions
(`0xe4441ac9` vs `0xe4441ac0`) with bit 0 present only in the first; layer 18 set in
both. `vis-breakdown` still printed **zero** times — again a raid too short to close
the 30 s window, now for the third session running.

**`refresh_cache_stats` is innocent — the prime suspect from §5.7d is disproved.**

```
esp-slow-frame[1/6]: total=538018us setup=8615us loop=15401us row=288us box=0us
  skel=11386us tail=514002us cacheStats=4us unaccounted=3727us | players=6 worstRow=226us
```

`esp_scan::refresh_cache_stats`: **14 calls, mean 3,576 ns, max 4,190 ns**. Four
microseconds, against a 514 ms tail. The `cacheStats=` bucket existed precisely so this
could be settled by one line rather than another capture, and it did its job — the
suspicion was wrong and the instrument said so.

**So the 514 ms tail is still unattributed, and it is now zoned rather than guessed.**
Nothing in the `+3` profile has a `max` anywhere near 514 ms
(`esp_scan::refresh_cache_stats` 4.19 µs, `game_item_db::localize_snapshot` 93 ms over
2 calls, `aimbot::candidate_pick` 49 ms), which means the tail is **unzoned work**. The
loot/container/quest blocks in the post-loop half had no zones at all — a 573-line
block at `EspModule.cpp:5727` among them. Added, permanently and for free:
`esp_scan::loot_and_container_scan`, `esp_scan::quest_poi_scan`, and
`lootScan=`/`poiScan=` buckets on the slow-frame line. Next capture settles it.

**Not ours, but it is in our file: `fallback_layer_mask` was `float`.** The
post-instrumentation builds surfaced C4244 `float`→`int` warnings at
`skeleton_visibility.h:206` and `:209` — the only warnings in the tree, against a
documented 0-warning invariant. `git diff` showed the declaration had been changed from
`int` to `float` in the working tree by the parallel session, not by the probe work.
Reverted to `int` with the reasoning recorded in place, because it is wrong on its face
and was the tree's only warning. It happened to be **harmless for this one value** —
`0x80400000` = 2,151,677,952 = 8,404,992 × 2⁸ with 8,404,992 < 2²⁴, so it is exactly
representable in a float32 and round-trips losslessly — but a mask with any of the low
8 bits set would silently zero them. **Whoever changed it should know it is reverted.**




### 5.7f The crash is EXONERATED the vis-probe, and named: it is the aimbot pen-check

`next_next_day+4+crash.tracy` (25 MB, 18:27). Log pid=4100, 18:21:22 -> 18:26:26,
single session (rotated this time). **`vis-probe` appears zero times** -- the removal
took -- **and the game still crashed**, third consecutive identical signature:

| session | vis-probe present | crash | fault offset | read |
|---|---|---|---|---|
| 16:49 `+2` | yes (v1) | yes | `...E798` | `...00000010` |
| 17:54 `+3` | yes (v2) | yes | `...E798` | `...00000010` |
| 18:26 `+4` | **no -- removed** | **yes** | `...E798` | `...00000010` |

Removing the instrument changed nothing, so **the probe was never the cause.** 5.7e's
suspicion was wrong, and so was 5.7d's -- I read "outside this module" as exculpatory
twice, and it was not, because it only ever meant the *stack scan* found no in-module
**code** frames. The faulting *instruction* was ours all along.

**`tools/symbolize.py` against build 6AC10BEC names it exactly:**

```
frame 0  skeleton_vis::read_ballistic_identity            +0x2A2
frame 1  (tracy ScopedZone dtor)
frame 2  skeleton_vis::describe_layer                     +0x54
frame 3  skeleton_vis::try_read_ballistic_penetration     +0x60
frame 4  skeleton_vis::assess_ricochet                    +0xCB
frame 5  skeleton_vis::try_read_layer_penetration         +0x1D
frame 6  skeleton_vis::is_target_visible_penetrating      +0xF89
```

**This is the AIMBOT's penetration walk, not the ESP.** The read at `+0x10` is
`UnityEngine.Object.m_CachedPtr`, which every managed call dereferences at `this+0x10`
-- so the fault was a managed call on a freed collider, inside a function with **no
readability guard**. `ballistic` comes off `Shot.TryGetBallisticCollider` on a live
raycast hit, and by the time the walk has classified a layer and reached the diagnostic
the object can be gone. The last log line before death is `pen-check: bullet HitMask =
0x40811810` -- that walk's own initialisation.

**The parallel session had already found and fixed this independently**, from the 17:54
crash: `read_ballistic_identity` now gates every managed call on
`eft_api::is_readable_address_cached`, checked per hop because `go` and `transform` are
derived objects that can be freed independently. Two independent symbolizations of two
different builds, same function, same offsets -- corroboration, not coincidence.
**The build deployed for `+4` predates that fix**, which is why it still crashed.

Two stale references, both naming symbols that no longer exist:
`skeleton_visibility.h:975` cites `hierarchy_chain` (removed by 5.7e) and
`vis_hit_layer` (**never existed** under that name -- my error, in the include comment
I wrote, now corrected). The only guard sites left in the file are the three inside
`read_ballistic_identity`.

**Hitch: the new buckets fired and cross-validate to the microsecond.**

```
esp-slow-frame[1/6]: total=518581us setup=13831us loop=22426us row=940us box=0us
  skel=17306us tail=482323us cacheStats=3us lootScan=77610us poiScan=195728us
  unaccounted=4180us | players=5 rowsOver1ms=0 worstRow=858us
```

| bucket | probe line | zone `max` |
|---|---|---|
| `esp_scan::quest_poi_scan` | `poiScan=195728us` | 195,727,242 ns |
| `esp_scan::loot_and_container_scan` | `lootScan=77610us` | 77,609,975 ns |
| `esp_scan::refresh_cache_stats` | `cacheStats=3us` | 4,619 ns (27 calls) |

`refresh_cache_stats` is innocent for the third time running. **`quest_poi_scan` is the
new prime suspect at 196 ms** -- 40.6% of the tail, and the first thing measured rather
than guessed. But **209 ms of the 482 ms tail is still unattributed** (43%), because the
`do_quest_items` block, the `publish()` group, `scan_bot_corpses_for_minimap` and the
grenade/tripwire/keypanel scans still carry no zones.

**And `vis-breakdown` still printed zero times -- for a reason that is now measurable.**
`frame::EspModule::gameworld_update` ran **3,180** calls at a 1.55 ms mean, which is
~28 s of game thread -- just under the 30 s window the reporter needs. Three sessions
running, all within a few seconds of short. It is not that the reporter is broken; the
raid has never been long enough. A raid ~10% longer closes it.

### 5.7g A COMPLETE raid at last, and the one question 5.7d did not actually ask

`next_next_day+6+crash.tracy` — **192 MB**, the first capture of a full raid length.
Log pid=20544, raid 19:51:25.025 -> `Local Raid Ended` 19:55:38.315 (3m13s), exfil.
Seven 30 s `vis-breakdown` windows, the first counters this investigation has ever had.

| exit | count | share |
|---|---|---|
| `hit_occluder` | 2,378,645 | **98.389%** |
| `ray_miss` | 38,959 | 1.611% |
| `hit_target` | **0** | — |
| `hit_shooter` | **0** | — |
| `inside_hit` / `no_transform` | 0 / 0 | — |
| **total** | **2,417,604** | closed set verified |

**`hit_target = 0` is now established over a complete raid, not a transient.** 2.42 M
rays, 131.3 per game update, 17.6 per skeleton, 7.45 skeletons per update, and not one
of them was ever attributed to the player it was aimed at.

**And 5.7d's probe did NOT answer the question it was aimed at.** All ten samples hit
static geometry — `Rack_shelf_04_COLLIDER`, `Area_02_inside_wall_D_COLLIDER`,
`Case_shower_COLLIDER`, all layer 18, `dist` 1.25-4.78 m — so the walk was only ever
shown to be correct *walking props to the scene root*. The discriminating case is a ray
that reaches a **bone collider**, and no sample ever produced one. `CONTAINS=no` on a
barrel says nothing about `CONTAINS=no` on a bot's own skeleton.

**Two explanations remain, and they have opposite fixes:**

- **Structural — the target's own layer is not in the occlusion mask.** The mask
  resolves to `0xe4441ac9` / `0xe4441ac0`, bits 0,3,6,7,9,11,12,18,22,26,29,30,31,
  built by OR-ing whole masks together. If no player/bone-collider layer is among them,
  then `hit_target` is **unreachable by construction**, the `hit_occluder` branch means
  "blocked, not drawn", the `ray_miss` branch means "clear, drawn", and the feature is
  **correct** — with 98% occluder simply recording that the tracked bots were behind
  walls, which for factory with 7-10 players spread across rooms is unremarkable rather
  than alarming. The 1.611% `ray_miss` would be the visible ones, and it does spike
  (29,871 in window 2 = 8.3%).
- **A real bug — the walk does not match player-owned colliders**, so every limb of
  every enemy is drawn occluded. This is what 5.7c claimed and 5.7d refuted; the
  refutation was only ever good for the samples taken.

**The decisive test is one extra raycast, and it is cheap.** On the `ray_miss` exit,
re-cast the *identical* ray with an all-layer mask and report what that hits. If it
hits the target's own collider, the mask was the problem; if it hits nothing, the target
genuinely has no collider on that bone and `ray_miss` is the honest answer. `ray_miss`
is 1.6% of rays (~38 k per raid) and a sample budget caps it at a dozen. It is one
extra linecast and **no managed object walks at all**, so it carries none of the
surface the removed probe had — and 5.7f exonerated that probe anyway.

**No crash was captured, and that is a result.** Zero `ACCESS_VIOLATION`, zero `FATAL`
across the entire raid, with the pen-check running continuously right up to
`Local Raid Ended`. The four previous sessions each had exactly one AV mid-raid. The
post-exfil exit the user reports is almost certainly **after** the vectored handler is
detached at teardown, so the probe cannot see it by construction — worth stating so it
is not read as "the fix worked" when in fact the instrument was not looking.

The pen tallies also ran clean and closed-set over 9,000 checks across the seven
windows, with the full spread of reasons now visible (`clear` / `ammo_vs_level` /
`ricochet` / `budget_layers` / `chance_zero`). That is the other workstream's result,
recorded here only because it is the same log.

**Hitch: `quest_poi_scan` confirmed reproducibly, and the remainder is still unnamed.**

```
esp-slow-frame[1/6]: total=543815us setup=13772us loop=21348us row=732us box=0us
  skel=15775us tail=508694us cacheStats=2us lootScan=81960us poiScan=213128us
  unaccounted=4841us | players=10 rowsOver1ms=0 worstRow=548us
```

`esp_scan::quest_poi_scan` zone `max` is 213,128,150 ns against `poiScan=213128us` —
the third session in a row at ~200-213 ms, and the largest single identified piece.
`esp_scan::loot_and_container_scan` max 81,959,386 ns against `lootScan=81960us`.
`esp_scan::refresh_cache_stats` max 16,980 ns against `cacheStats=2us` — innocent for
the **fourth** time. But `tail` 508,694 − 213,128 − 81,960 − 2 leaves **213,604 µs
still unattributed**, and that remainder has been stable at 209-214 ms across three
sessions. Still unzoned: the `do_quest_items` block, the `publish()` group,
`scan_bot_corpses_for_minimap`, and the grenade/tripwire/keypanel scans.

### 5.7h Instrumented for the two remaining questions, and the tail's last unnamed regions zoned

Two bounded diagnostics in `skeleton_visibility.h`, one shared budget (12 samples, >= 2 s
apart), plus the tail zones. Everything below is temporary and marked in place.

**A correction to 5.7g's own proposal first.** The all-layer re-cast was suggested for the
`ray_miss` exit on the reasoning that it tests the 98%. It does not. `ray_miss` **returns
TRUE** -- it is the *visible* verdict -- so re-casting there tests false **positives** in
the 1.6%, a real but different defect. The 98% lives on the `hit_occluder` exit. Both
are now instrumented, each aimed at the exit that carries its question:

- **`vis_diag_occluder`** (the `hit_owner::none` arm, 98.389% of rays). Reports the hit's
  layer and distance and the **first ancestor whose name looks player-owned** --
  `eurocube*`, `*_BALLISTIC_*`, `Root_Joint`, the three patterns this file has actually
  seen in EFT. A hit carrying one of those in its chain that `classify_hit_transform`
  returned `none` for is the walk **provably** failing, with the name attached:
  `VERDICT=WALK-FAILED`. This is the evidence the removed chain dump could not produce,
  because selecting samples by "unattributed hit" can only ever find things that are not
  attributed. It is circular, and that is why ten static-geometry samples settled nothing.
- **`vis_diag_miss`** (the `ray_miss` arm, 1.611%). Re-casts the identical ray with all
  layers. A hit means the occlusion mask is too **narrow** and the ESP is drawing a bone
  as visible that is actually behind something on an excluded layer:
  `VERDICT=FALSE-VISIBLE`.

So the two together test both directions of the mask, and the walk itself. The pen walk's
own log is already evidence for Q1 -- `L0 go='eurocube_skeleton_01_BALLISTIC_metalthin'`
walked as a penetrable layer where a working classify returns `hit_owner::target` -- and
Q1 is that observation turned into a measurement.

**Safety.** Every managed call is gated on `eft_api::is_readable_address_cached`, checked
**per hop** rather than once per chain, because an ancestor can be freed while a deeper
node is still mapped; an unreadable node prints `<unreadable>` and stops the walk rather
than being handed to the game. The re-cast is `g_linecast`, already called ~2.5 M times
per raid, so no new kind of surface. The 5.7f lesson is the reason this is stated rather
than assumed: a fault inside a managed method reads as "outside this module", which is
exactly how a probe got blamed for a pen-check crash.

**Steady-state cost is one relaxed atomic load per call.** The budget check is first, so
once the 12 are spent there is no clock read and no extra raycast. Between samples it is
a budget check, a `steady_clock` read and (for Q2) one raycast. Logged at INFO so a
one-shot capture does not need the debug toggle.

**Tail: every region in `gameworld_update`'s post-loop half now carries a zone.** The
209-214 us-per-ms remainder has been stable across three sessions and was unattributable
because the candidates had no zones at all. Added: `esp_scan::quest_items_scan`,
`esp_scan::keypanel_scan`, `esp_scan::publish_group`, and `miscScan` / `corpseScan` /
`publish` buckets on the slow-frame line.

**`esp_scan::publish_group` is the one to watch, and for a reason the others are not: it
is the only block in that half which takes a CROSS-THREAD lock.** `data_mutex` is the
same mutex the render thread takes to read its snapshot, so a stall there is
contention rather than work -- and contention would look exactly like the stable
remainder. The bucket is stamped immediately before the lock so it measures the **wait**,
not the publishes. If it shows ~200 ms with almost no self time, the answer is the lock.

Two mistakes made and caught while wiring this, both of which would have produced a
misleading log line rather than a crash:

- `t_publish` was aliased to `t_corpse`, which made `us_publish` span the corpse scan as
  well, so the two buckets overlapped.
- Declaring it `const auto` **inside** the publish block scoped it there, and the
  accumulation sits after the closing brace -- `C2065: t_publish: undeclared identifier`.
  Declared in function scope, assigned immediately before the lock.

Verified: timers strictly monotonic 5316 -> 6566, **no bare `return` between `begin` and
`report`** so every bucket always closes, `t_publish` stamped before it is read, and both
consumers of `skeleton_visibility.h` compile clean with **0 errors and 0 warnings** in both
`Prod|x64` and `Prod no aimbot|x64`. `tools/tests` 155 passed.

Still not answered, and not answerable without a run: whether the walk fails on
player-owned colliders (Q1) or the mask simply omits the target layer (structural), and
whether any of the 1.6% "visible" verdicts are false (Q2).

### 5.7i The occluder probe answered with a false positive of its own, and the question closes

`next_next_day+7+crash.tracy` (224 MB). The log holds three sessions; the relevant one is
**pid=25656** (22:39:59 -> 22:57:09, clean exfil). `vis-diag-occluder` returned all
**12 of 12** samples.

**THE INSTRUMENT WAS WRONG, AND IT WAS WRONG CONFIDENTLY.** Every sample read:

```
vis-diag-occluder[12/12]: VERDICT=WALK-FAILED | dist=3.18 layer=12 mask=0xe4441ac9
  inMask=1 boneDist=85.6m | rigLookingAncestor=Old_Control_Panel_A_BALLISTIC_metalthin
```

`Old_Control_Panel_A` is a **control panel** -- world geometry. `classify_hit_transform`
was right and the detector was wrong. The culprit is this file's own
`name_looks_player_owned`, which treated `_BALLISTIC_` as a player marker; it is only
EFT's **material suffix on any ballistic collider**, static geometry included. Removed;
the two surviving patterns (`eurocube*`, `Root_Joint`) are player-specific by
construction. Twelve confident wrong answers from one over-broad pattern is the whole
lesson, and it is the second time in this investigation that an instrument of mine
produced a confident answer I had to discard -- the first was reading "outside this
module" as exculpatory.

**What the twelve samples DID establish is the actual finding, and it is geometry:**

| | value |
|---|---|
| occluder distance | **3.13 - 3.29 m** |
| bone distance | **62.5 - 85.6 m** |
| occluder layer | 12, `inMask=1` |

A prop **three metres** from the camera, and a target **sixty to eighty-six metres**
away. That is correct occlusion, correctly reported. Combined with the earlier ten
chain-dump samples and the counters, the conclusion is now closed three ways:

- **Two full raids, 5,420,982 rays, `hit_target` = 0, `hit_shooter` = 0**, closed set
  verified on both. pid=25656 alone: 16 windows, 3,003,378 rays, 97.62% occluder,
  2.38% miss, max 13.5% miss in a single window.
- Ten chain-dump samples: genuine props, walk correct.
- Twelve new samples: a control panel at 3 m, a bone at 85 m, verdict correct.

**There is no visibility bug. The remaining finding is a cost one, and it is
configurable.** `skeleton_distance` defaults to **200 m** (range 50-1500), and the ESP is
building ~7.45 skeletons per game update with **~131 rays each frame** toward targets
60-90 m away, across a factory interior where a prop three metres out hides them. Almost
all of that work is spent establishing what the geometry already says. That is a product
decision, not a defect, and `skeleton_distance` is the lever.

**The tail is now fully attributed, and my lock-contention theory was wrong.**

```
esp-slow-frame[1/6]: total=516909us setup=12292us loop=17960us row=559us box=0us
  skel=14198us tail=486656us cacheStats=3us lootScan=73616us poiScan=214609us
  miscScan=193931us corpseScan=4371us publish=114us unaccounted=3203us | players=7
```

`poiScan` 214,609 + `miscScan` 193,931 + `lootScan` 73,616 + `corpseScan` 4,371 +
`publish` 114 + `cacheStats` 3 = **486,644 against a tail of 486,656** -- 12 us
residual, **99.998% attributed**. The 209-214 ms remainder that three sessions could not
place is `miscScan`: the grenade/tripwire/keypanel bracket. `refresh_passcode_labels`
under `data_mutex` is the suspect inside it -- there is now a zone on exactly that block
-- but **there is no CSV export for `+7`**, so the split between the three is not yet
measured.

**My cross-thread-lock hypothesis is dead, and it is worth recording as dead.**
5.7h predicted `esp_scan::publish_group` would show ~200 ms of contention if the
remainder were lock contention, because it is the only block in that half taking a
mutex the render thread also wants. It reads **114 us**. I named the mechanism precisely
and it was wrong; the zone stays because it cost nothing and the answer is worth having
recorded.

A second slow frame in the same session: `total=68841us` of which `lootScan=67465us` --
the loot/container scan spiking to 67 ms on its own.

**The exfil crash is not a crash the probe can see, for the second session running.**
pid=25656 ended with `Local Raid Ended` / `Insured Items: 0` / `Transfer Items: 1` and
**no fault of any kind** -- zero `ACCESS_VIOLATION`, zero `FATAL`. Same as `+6`. Two
sessions now, same shape: the process dies during or after raid teardown in a way the
vectored handler does not observe, most likely after the handler is detached at unload.
That is an instrument limit, and it should not be reported as "no crash occurred".

**The one real crash in this log belongs to a different session and a different
subsystem.** pid=10864, 109 lines, died seconds in:

```
crash probe: ACCESS_VIOLATION EXECUTE/other of 0x0000000000000000
  #0 frame 0  +0x124542  ->  dxhook::create_window  +0xE2
  #0 frame 1  +0x125046  ->  dxhook::dx11_setup     +0x2B6
```

Symbolized against build `6AC13F71`; the last log line before it is `Hooking Present`.
EXECUTE at `0x0` is a **call through a null function pointer** in the DX11 hook setup.
**Not ours and not this workstream's**: `dxhook.cpp` is unmodified in the working tree,
so it is pre-existing, and it is the graphics/chams area. Handing it on rather than
touching it.

**Probe state after this run.** `vis_diag_occluder` is **retired** -- its question is
answered and its verdict was a false positive -- so the still-open miss question gets the
whole 12-sample budget. At a 97.6% occluder rate the two probes shared one budget and
`vis_diag_miss` got **zero** samples, which is a design mistake worth recording: a budget
shared between a 97.6% path and a 2.4% path does not sample the 2.4% path. Only
`vis_diag_miss` remains, with the `_BALLISTIC_` false positive fixed at source.

### 5.7j A visibility-check distance cap, and the trap that makes it non-obvious

The ESP's per-bone occlusion rays are the largest leaf in every capture, and 5.7i closed
the correctness question: they are answering correctly, they are just being spent on
targets nothing can be seen through. 5,420,982 rays over two full raids, `hit_target` = 0,
`hit_shooter` = 0, 97.6% occluder -- and the twelve samples put the geometry at an
occluder **3.13-3.29 m** from the camera against a bone **62.5-85.6 m** away, on a
factory interior. So the cap is the lever, and it is a product decision rather than a
defect fix.

**What was added: `skeleton_vis_distance`** (`EspModule.h`), a `FloatSliderEditableValue`
defaulting to **75 m**, range 25-1500, with `skeleton_vis_distance_itm` added to
`lang/en.json` (694 keys, valid). It gates **only the physics**.

**Why it is a separate slider and not a lower `skeleton_distance`.** Lowering
`skeleton_distance` from its 200 m default would also stop the skeleton being *drawn*
past the limit. That is a larger change to what the user sees than the measurement
justifies, and it would conflate two different questions -- "how far do I want
silhouettes" and "how far do I want to pay ~10.9 us per bone to pick a colour".

**THE TRAP, and the reason this needed care rather than a two-line change.** The obvious
implementation is to skip the whole `if (check_visibility && ...)` block beyond the cap.
That is **wrong, and wrong in the dangerous direction.** The draw path decides visibility
at `EspModule.cpp:994`:

```cpp
const bool vis_on = skeleton_visibility->get_value() && link_index
    && *link_index < entry.link_visible.size();
const bool link_visible = vis_on && entry.link_visible[*link_index];
```

An **empty** `link_visible` makes `vis_on` false, which falls past every visibility branch
to plain `skeleton_color` -- a **full-colour silhouette**. Bailing out early would draw an
enemy behind a wall as though fully visible. So the cap is applied *after*
`entry.link_visible.assign(links.size(), false)` and before the ray loop, which keeps the
entry in the occluded branch. That is also why the cap is close to behaviour-preserving:
it lands on the same verdict 97.6% of the rays were already producing.

**And the number is a judgement, not a measurement, so the counters to replace it are in
the same commit.** `skeleton_vis::record_vis_distance()` counts per 30 s window how many
player-skeletons were inside the cap (rays cast) versus outside (rays skipped) and how
many bones that skipped, reported as:

```
vis-dist-cap: playersIn=N playersOut=N bonesSkipped=N
  | raysOut ~= playersOut*~17.6 bones*~10.9us per frame avoided
```

If `playersIn` is a small fraction, 75 m is doing nearly all the work and raising it would
cost the product of that expression per frame. If `playersIn` is most of them, 75 m is too
tight and is discarding real visibility information. One run replaces the judgement.

One wiring mistake, same class as the `t_loop_begin` one in 5.7d: the per-frame read of
the new slider was first placed beside `skel_max_dist`, which is in **`draw_overlay`**,
not `gameworld_update` -- two functions in this file carry near-identical tail blocks. The
call site is 400 lines away in the other function, and it gave
`C2065: vis_check_max_dist: undeclared identifier`. Declared in `gameworld_update` beside
`skeleton_vis_enabled` now, and read once per frame there rather than per player.

Verified: both consumers of `skeleton_visibility.h` compile clean, **0 errors and 0
warnings**, in `Prod|x64` and `Prod no aimbot|x64`; `lang/en.json` parses with 694 keys and
the new key present; no migration or registry references `skeleton_distance` or
`box_distance`, so a new slider needs none. `tools/tests` 155 passed.

**Still unmeasured: how much this actually saves.** The counters will say, but until a run
reports `vis-dist-cap:` the saving is an argument, not a number.

### 5.7k A hover tooltip for the cost knob, added without touching a single existing call site

5.7j added a slider whose number says nothing about what moving it does -- it is a CPU
knob wearing a distance label. It now explains itself on hover.

**Three shared files changed, all additively**, which is the point: `imgui_addons.h/.cpp`,
`config/FloatSliderEditableValue.h/.cpp`. None of them were touched by the parallel
session (`git status` clean on all four before starting), so there is no contention.

- `slider_float_editable` gains a trailing `const char* tooltip = nullptr`. Several
  hundred existing call sites compile unchanged.
- `FloatSliderEditableValue` gains `tooltip_` plus an optional trailing ctor argument and
  a `set_tooltip()` accessor. The string is resolved through `i18n::tr()` **at
  construction**, so `draw()` holds a plain `std::string` and performs no translation per
  frame -- the same lifetime the title gets from `ConfigValue`.
- The popup is hooked on the slider track's **existing** `hovered` variable rather than a
  new hit target, so it cannot change what the widget responds to. It is suppressed while
  `active`, because the value is moving under the cursor and a popup there is noise.

**The text states the mechanism, not a measurement**, deliberately. `skeleton_vis_distance_tip`
gives the per-player cost (~17-18 raycasts x ~10 us ~= **180 us of game-thread time per
extra player per frame**), then the shape that actually surprises people -- it scales with
*how many players fall inside the circle*, so doubling the radius roughly **quadruples**
the work in a populated map rather than doubling it -- then the measured context, then the
fact that skeletons are still drawn past the line in the occluded colour. Baking a
specific captured percentage into a shipped string would rot; the live number is one
`vis-dist-cap:` line away.

One editing hazard worth recording: `slider_int_editable` and `slider_float_editable` end
with a **byte-identical** `dl->AddCircleFilled(ImVec2(p.x + t * track_w, cy), kr,
ImGui::GetColorU32(ImVec4(1, 1, 1, 1)));` line, so a text-anchored edit matched twice and
refused. Inserted by verified line number instead, after asserting the target line really
was inside `slider_float_editable`.

Verified: `EspModule.cpp`, `AimbotModule.cpp`, `FloatSliderEditableValue.cpp` and
`imgui_addons.cpp` compile clean, **0 errors and 0 warnings**, in `Prod|x64` and
`Prod no aimbot|x64`; `lang/en.json` parses with 695 keys and both new keys present;
`tools/tests` 155 passed.

### 5.7l A view-cone cull: the ESP was building skeletons for players behind the camera

The question that prompted this -- "does the raycast go in every direction?" -- found the
largest remaining waste in the module, and it was not the distance cap.

**The asymmetry.** Every other ESP item projects and culls BEFORE doing its per-item work.
Exfils, transits, grenades, keycards, loot, quest POIs, bot corpses, and the **player
label** at `EspModule.cpp:5313` all do:

```cpp
unity::vector3 screen_pos = eft_api::world_to_screen(cam, pos3d, game_state::esp_draw_zoom);
if (!eft_api::is_visible(screen_pos)) continue;
```

The skeleton was the exception. Its gate was **3D distance only**
(`distance <= skeleton_distance`, default 200 m), so a skeleton -- ~17 bone resolutions
plus ~17.6 occlusion raycasts, **~0.22 ms** of game-thread time -- was built for every
player inside a 200 m *sphere*, including players directly behind the camera. The
screen-space cull happened afterwards and **per bone**, on the render thread, at
`EspModule.cpp:1188`. All of that work, for a figure that draws nothing.

**Now culled before any per-player skeleton work**, in `gameworld_update`, so it saves the
bone resolution as well as the rays.

**Yaw-only, deliberately.** A cone ignoring pitch keeps a target directly overhead or
underfoot whenever it is in front horizontally, which is the generous direction; pitch
would need the camera's full rotation and cull more for no measurable gain.

**Camera, not player body.** `my_pos` is the player transform, but the log shows the view
can be `cam='BaseOpticCamera(Clone)'` -- a different object from the player while scoped,
and the one that actually frames the shot. Using body yaw would be wrong precisely when
scoped.

**Fails OPEN.** No culling at all if the camera or its transform is unavailable, and none
for a target whose horizontal distance is under 1 cm, where the angle is undefined. A cull
that cannot prove the target is off-screen must not fire.

**70 degrees FULL cone** (`kSkeletonConeHalfAngleDeg = 35.f`), which is 19.4% of a circle
and therefore an **81% ceiling** on skeletons skipped. Verified in isolation: at yaw 0 a
target dead ahead is kept, 45 degrees off-axis is culled, 90 and 180 are culled; at yaw 90
the axis correctly rotates to +X.

**The cost is pop-in at the cone edge, and that is a real trade, not a free win.** 70
degrees full is +/-35 degrees, which is at or slightly inside a typical 70-90 degree
horizontal game FOV -- so a skeleton right at the screen edge can pop in as you turn. The
symptom is skeletons flickering on-screen while rotating, and the fix is one constant:
`kSkeletonConeHalfAngleDeg`. At 50 (100 degrees full) the saving is ~72% instead of ~81%
and the edge sits outside any plausible FOV. **That is the number to change if it flickers**,
and it was left at 35 because 70 degrees was the figure asked for.

**Measured, not assumed:** `vis-cone:` in the 30 s report gives built / culled / total and
the culled percentage, plus the per-frame saving. A ratio near 81% means the arithmetic is
working; near zero means the cone is far wider than the view and the work was mostly
needed anyway.

Verified: both consumers of `skeleton_visibility.h` compile clean, **0 errors and 0
warnings**, in `Prod|x64` and `Prod no aimbot|x64`; cone arithmetic checked in isolation
above; `tools/tests` 155 passed. **The saving is still an argument until a run prints
`vis-cone:`** -- as with 5.7j's distance cap, both numbers arrive on the same report line.

**Note on the cap from 5.7j.** The two interact and the interaction is not additive: a
player outside the cone is skipped before the distance cap is consulted, so raising the cap
buys less once the cone is in place, and the `vis-cone` and `vis-dist-cap` lines should be
read together rather than as separate wins.

### 5.7m The cone widened to the whole player store, and where a global limiter would NOT help

Answering the question that prompted it: **5.7l's cull was skeleton-only.** It now covers
the **whole player-facing ESP** -- box, label and skeleton -- from one place.

**One filter before the store is published.** `temp_players` is filtered by the same cone
immediately before `player_store = publish(...)`, which covers both render-side
iterations: boxes at `EspModule.cpp:5199` and labels at `:5273`. Skeletons were already
gated at build.

**WHY HERE RATHER THAN PER DRAW SITE, because this is what fixes the reported artifact.**
Both draw sites already cull with `eft_api::is_visible` -- but `is_visible` accepts a
**100 px margin outside the viewport on every side**:

```cpp
if (!(screen_point.z > 0.01f
        && screen_point.x > -100.0f && screen_point.y > -100.0f
        && screen_point.x < menu::get_width() + 100.0f
        && screen_point.y < menu::get_height() + 100.0f))
    return false;
```

So a player just off-screen passes `z > 0.01f` (in front of the camera) and the bounds
test by up to 100 px, and is built, projected and drawn anyway. That margin is a
deliberate anti-pop choice, but it is also the mechanism behind "skeleton lines getting all
over screen". One store-side filter is cheaper than any number of draw-side tests and
cannot drift out of agreement with them. The `z > 0.01f` test already handles
**behind-camera**, so this is not about the back of your head -- it is about the margin.

Fails open exactly as the skeleton gate does: no camera, no filter; and the same
directly-overhead carve-out, where the horizontal angle is undefined.

**WHAT A TRULY GLOBAL CONE WOULD AND WOULD NOT BUY -- the reason this stops at players.**

- **Would not help the single largest tail item.** `esp_scan::quest_poi_scan` is
  **214 ms of a 508 ms tail (44%)** and is **enumeration-bound**: it runs
  `quest_esp::start_collect_cycle()` and then `quest_esp::advance_collect(game_world_obj,
  512)` in a `while (... && guard++ < 400)` drain loop. It must walk the world to find
  anything at all, so no amount of view filtering reduces it. A cone on the *store* would
  only stop it being drawn, not being found.
- **Would barely help loot.** The loot and container scans are registry-filtered by
  `dist_sq > max_dist_sq` already, and comment at `EspModule.cpp:3576` records the
  deliberate choice of "controller registry (already discovered terminals) - no
  FindObjectsOfType". So the per-item saving is small, and culling loot removes peripheral
  awareness of things at your feet.
- **Would help exfils / transits / grenades / tripwires / keycards / corpses / containers**,
  all of which are few per frame (tens, not thousands) and already distance-gated. The
  saving there is noise; the visual consistency is the only argument.

So the honest split: **players are where the volume is** (7.45 skeletons/update x ~17.6
rays, ~0.22 ms each), and players are also where the artifact is. Everything else is either
enumeration-bound, already cheap, or valuable peripheral awareness. Extending to the rest is
one `erase(remove_if(...))` per vector with the same `pos3d` test, and the structs all carry
`pos3d` -- but it should be a deliberate choice per vector, not a blanket sweep.

**Verified:** both consumers of `skeleton_visibility.h` clean, **0 errors and 0 warnings**,
in `Prod|x64` and `Prod no aimbot|x64`. `tools/tests` 155 passed. The CPU effect is still
unmeasured -- `vis-cone:` now counts SKELETONS built/culled only, and this store-side
filter is not yet counted, so the next run will under-report the total. Noted rather than
papered over.

### 5.7n The cone needed an origin that is not `my_pos` -- a hole caught before it shipped

`my_pos` is `unity::transform_get_pos(main_player_transform)`, and that returns **exactly
{0,0,0}** for three cases the caller cannot tell apart (`unity.h:760`): a null transform, an
unresolved `get_position`, and a rig still being placed. The third is real and is raid start
-- the same window CHANGELOG 0.9 records `Camera.current` being independently reported to
belong to a **bot**.

Left unguarded, 5.7l/5.7m would have centred the cone on the **world origin**: every
player's angle measured from (0,0,0) somewhere arbitrary in the map, so legitimate players
get culled and illegitimate ones survive. A cull that cannot establish where the viewer is
must not fire.

**The fireport is the fallback, and it is the right one** -- resolved from
`main_player.get_Fireport()`, so it is anchored to the local player BY CONSTRUCTION, which
is the property that matters rather than mere proximity. `try_get_fireport_position` already
rejects a degenerate muzzle itself, so a `true` return is a real position. If both the rig and
the fireport fail, the cone is **disabled for the frame** (fail open) rather than guessing.

Two details that matter:

- **It is called only on the degenerate path.** `try_get_fireport_position` performs an
  UNCACHED `resolve_method` -- `il2utils::resolve_method` has no cache, unlike
  `resolve_field` -- so paying it every frame would be a poor trade for a raid-start
  transient that almost never happens.
- **`main_player_` is already an `Il2CppObject*`,** assigned from
  `main_player.get_instance()` at the top of the function. The first attempt wrote
  `main_player_.get_instance()` and got
  `C2228: expression to the left of '.get_instance' must be a class...`.

`cone_origin` now feeds **both** cone sites -- the skeleton gate and the store-side player
filter -- and `my_pos` appears in the cone path only as the value being tested for
degeneracy.

Verified: both consumers clean, **0 errors and 0 warnings**, in `Prod|x64` and
`Prod no aimbot|x64`; `tools/tests` 155 passed.

### 5.7o REGRESSION: the cone pointed at the wrong object and hid every skeleton for 90 s

**Symptom (user-reported):** skeletons stopped rendering while ESP labels kept drawing.
**Cause, from the log:** the raid started 06:56:21 and the first three 30 s windows were

```
06:57:30  vis-cone: built=0 culled=29544 of=29544 culledPct=100%
06:58:00  vis-cone: built=0 culled=28800 of=28800 culledPct=100%
06:58:30  vis-cone: built=0 culled=29132 of=29132 culledPct=100%
06:59:00  vis-cone: built=4956 culled=15698 of=20654 culledPct=76%
```

Every skeleton culled, in every direction, for ~90 s. Then it settled to 59-88%, which is
the arithmetic working. Two defects, both mine, both in the same cull.

**1. THE DIRECTION CAME FROM THE WRONG OBJECT.** 5.7l/5.7m took the yaw from
`unity::get_current_camera()` -- `Camera.current`. This module does **not** draw with
`Camera.current`: it resolves its own camera, and the 30 s report shows that succeeding
every time (`cam-choice: resolves=25696 named=25696 fallback=0 none=0`). `Camera.current` is
a different object, is not guaranteed to be the one framing the shot, and its rotation is
therefore not the view direction. `unity::get_current_camera()` in `EspModule.cpp` was
**my** call, added for this cull, and it was the only one in the file.

**Fixed: the direction is the player's own forward.** The body faces where the player aims,
which is what "in front of the player" actually means, and it comes from
`main_player_transform` -- already resolved and already proven good, since it is the
transform `my_pos` was read from. No camera, no second object to disagree with, and when
scoped the body still faces the optic. (`Camera.current` is still legitimately used by
`try_get_visibility_origin`, which needs only a POSITION and has a whole fallback ladder
behind it.)

**2. A FAILED READ WAS INDISTINGUISHABLE FROM A GENUINE 0 DEGREES.** `get_transform_yaw_y`
returns `0.f` for a null transform, for an unresolved `get_eulerAngles`, **and** for a real
0 degrees. A cull that gates on that value cannot tell "I could not read it" from "facing
north", so a failed read becomes a *confidently wrong direction* -- the worst possible
failure for something whose whole job is to decide what is off-screen.

**Fixed: `try_get_transform_yaw_y(transform, float&)` returning `bool`.** `false` on null
transform, unresolved method, or a non-finite result. The old float form is kept and now
delegates to it, so the minimap's existing use is unchanged. `cone_active` requires
**both** a valid direction and a valid origin, so a failure disables the cull for the frame
(fail open) instead of defaulting to +Z.

**3. THE MISSING INSTRUMENT, which is the part that would have made this obvious in one
line instead of one minute.** A one-shot `esp-cone-init:` now logs
`dirOk / originOk / active / yaw / fwd / origin / halfAngle` on the first frame of the
first session. Had that existed, the 06:56 bug would have been self-evident immediately
rather than inferred from `culledPct=100%`.

**The generalisable lesson, and it is the repo's own:** an unchecked call site is a shape,
not a fault -- rank by whether it can happen. This one could happen on the very first
frame of every raid, and the number that proved it (`built=0`) was already being reported
and simply had not been read as an alarm.

Verified: both consumers clean, **0 errors and 0 warnings**, in `Prod|x64` and
`Prod no aimbot|x64`; no remaining code use of `get_current_camera` in `EspModule.cpp`
(two hits are the explanatory comment); `tools/tests` 155 passed.

### 5.7p The 06:56 regression is fixed and verified, and the bounded diagnostic is retired

Session pid=3560, build `0x6AC1D894`, 07:46 -> 07:54.

**The fix works, and the one-shot instrument proves it in a single line:**

```
esp-cone-init: dirOk=true originOk=true active=true yaw=127.1deg fwd=(0.80,-0.60)
  origin=(-46.3,0.3,7.0) halfAngle=35deg source=player-transform
```

`dirOk=true` (the yaw read succeeded), `originOk=true` (`my_pos` was a real position, not
degenerate), `active=true`, and **`yaw=127.1`** is a genuine non-trivial facing -- which is
what `Camera.current` was not giving us. `fwd=(0.80,-0.60)` is consistent with 127.1
degrees, and `origin=(-46.3,0.3,7.0)` is a real factory coordinate.

**`vis-cone:` now varies with where the player looks, which is what a correct cone does:**

| window | built | culled | culled% |
|---|---|---|---|
| 1 | 14,684 | 6,862 | **31%** |
| 2 | 12,837 | 8,555 | **39%** |
| 3 | 5,167 | 16,244 | **75%** |
| 4 | 5,938 | 16,755 | **73%** |

No 100% window, and `built` substantial in every one. Skeletons render. **No crash**: the
session's closing histogram is 6,536 exceptions, all `DBG_PRINTEXCEPTION_C` and C++
throws, **zero `0xC0000005` and zero `FATAL`**. (The five `CRASH|FATAL` grep hits in that
pid are the crash probe's own startup banner, which contains both words.)

`vis-breakdown` over four windows: 531,741 rays, 97.80% `hit_occluder`, 2.20%
`ray_miss`, `hit_target` = 0, `hit_shooter` = 0, closed set verified.

**Q2 ANSWERED -- AND ITS VERDICT LABEL WAS WRONG 13 TIMES OUT OF 13.**

All twelve `vis-diag-miss` samples printed `FALSE-VISIBLE`. Split by distance to the bone:

| cluster | n | blocked at | ratio | what it is |
|---|---|---|---|---|
| A | 10 | **0.01 - 0.05 m** | ~0.001 | the **shooter's own collider** -- the camera is inside their own head |
| B | 3 | 11.34 / 13.39 / 26.53 m | 0.68 / 0.99 / 0.99 | essentially **at the bone** -- the **target's own collider** |

**Neither cluster is a false visible.** Ignoring your own body is what makes the check work
at all -- treating a 2 cm self-hit as an occluder would make nothing ever visible -- and
reaching the target is the definition of visible. So the probe labelled "an all-layer ray
hit something" as "false visible", which is not what it had established.

**What it DID establish, and it is the answer to a question open since 5.7c: THE
OCCLUSION MASK IS WORLD-GEOMETRY-ONLY BY CONSTRUCTION, and that is why `hit_target` is
structurally unreachable rather than broken.** The target's own collider layer is not in
`0xe4441ac9`, so the ray passes through and exits as `ray_miss`, which the feature reports
as visible -- correctly. Identically for the shooter, which is why `hit_shooter` is also
always 0. That confirms the "structural" branch of the two-explanation split in 5.7c and
refutes the "the walk fails on player colliders" branch, which 5.7d had already refuted
from the other direction.

**The consequence worth keeping:** because the mask never lets a player collider reach
`classify_hit_transform`, that walk's behaviour ON a player collider has never been
observed at all. Not shown correct, not shown broken -- **unreachable** while the mask is
built this way. It would only start to matter if someone widened the mask to include player
layers, and that is the moment to remember the walk has never been exercised there.

**Diagnostic retired.** `vis_diag_miss`, the shared budget, `vis_diag_due`,
`name_looks_player_owned` and `vis_diag_layer_of` are all gone, with the reasoning left in
place as a comment so the next person does not re-add a name-based player-rig heuristic.
Two of my three instruments have now reported a confident conclusion they had not earned;
the pattern is consistent enough to be worth stating -- a heuristic that cannot fail is not
a heuristic, and a verdict token is an assertion that needs the same evidence as the code
around it.

**Surgery hazard, self-inflicted.** Removing that block by line range took out an orphaned
`}` from a function deleted in an earlier step, which closed `namespace skeleton_vis` early
and produced four errors (`C3861: classify_hit_transform: identifier not found`,
`C2653: hit_owner is not a class...`) pointing at a line 120 away from the cause. A
symbol-set diff against HEAD is what proved nothing had actually been lost. Line-range
edits in a header other people are working in are risky; assert on the anchor, and when the
error points somewhere unrelated, check brace balance before believing the line number.

Verified: both consumers clean, **0 errors and 0 warnings**, in `Prod|x64` and
`Prod no aimbot|x64`; `tools/tests` **179 passed** (the parallel session has added cases
since the last count of 155).

### 5.7q Cone pop-in: hysteresis, a wider default, and a latent two-site bug

Reported on 2026-10-04, after the 5.7p fix landed: **"while a real facing, it is kinda
misleading at times. When looking at one direction, the ESP-drawn skeletons can drastically
change their draw-status."** That is the pop-in 5.7l predicted as the cost of the cone, and
the prediction understated it. At 31-75% culled, targets were sitting near the edge, and a
bare instantaneous angle test has NO MEMORY -- a player a few degrees outside the edge flips
on and off with every mouse movement.

**Three changes, and one of them is a bug that was there regardless of pop-in.**

**1. The two cone sites could disagree, and now cannot.** The skeleton build gate and the
store-side player filter each recomputed the angle independently, from the same inputs but
as separate expressions. An entry could therefore be *built and then dropped*, or *dropped
and then built* -- and because the build gate runs per-player inside the loop while the
filter runs over the finished vector, they were not even guaranteed to see the same inputs.
The decision is now made **once per player per frame** and carried on the entry as
`player::in_view_cone`; both consumers read the flag. This also happens to be what makes
hysteresis possible at all: the grace state is per-player and must be looked up by identity,
and the store-side filter only ever sees the finished struct.

**2. Two independent mechanisms remove the pop, because they cover different motions.**

| mechanism | covers | effect |
|---|---|---|
| half-angle **35 -> 50 deg** (70 -> 100 deg full) | **slow** rotation | the edge now sits outside a typical 70-90 deg horizontal game FOV, so the boundary crossing happens off-screen where it cannot be seen |
| **frame grace**, `kConeGraceFrames = 30` (~0.25 s) | **quick** flicks and momentary corrections | a target that leaves the cone keeps being processed for 30 consecutive ticks before it is dropped |

Angle widening alone does not fix a flick, and a grace window alone does not stop the edge
from sitting on-screen during a slow sweep. Both are needed.

**The cost is arithmetic and it is stated here so it is not a surprise:** the culling ceiling
falls from ~81% to ~72%, and the measured 31-75% band will fall with it. That is the trade
the report asks for, and the constants are named so it is tunable.

**3. `cone_memo_` had an unbounded-growth bug, and the stale sweep is a CORRECTNESS fix.**

The first version used `auto& memo = cone_memo_[key];` **before** the angle test. That
inserts an entry for **every player entity on every tick**, including the ones comfortably
inside the cone whose only state is `outside_frames = 0`, and never releases one -- so the
map grows for the whole raid and holds nothing useful. `operator[]` now appears on the
**outside path only**; the inside path does a `find` and erases, because a player back
inside the cone has spent its grace and has no state worth keeping.

Even bounded, keying on the pointer alone is not sufficient: **an entity that is freed and a
new one allocated at the same address inherits the previous occupant's grace** and renders
with someone else's hysteresis for up to 0.25 s. Only a sweep prevents that, so
`cone_memo_entry` carries `seen` (a cone-local tick) and every 240 ticks (~2 s) entries older
than 4,800 ticks are dropped.

`kConeStaleTicks` is deliberately ~160x `kConeGraceFrames`. Dropping a memo early means the
player gets a **fresh full grace** next time it crosses the edge, which *delays* a cull by
0.25 s and never causes a pop; dropping it late costs only map space. So the threshold is set
to be cheap rather than tight.

`cone_tick` is a plain function-local static, advanced only in `gameworld_update`, and is
deliberately **not** `vis_frame_serial_` -- that one is the visibility draw-gate's clock and
borrowing it would couple two unrelated things under one name. (While checking this, note that
the header comment on `vis_frame_serial_` says "bumped once per drawn frame in draw_overlay",
but the increment is in the update hook and the note at 5.7-era line 4673-4679 says it is a
**tick** clock that runs 1.67x per drawn frame. The two comments contradict each other and
the increment is the authority; **left alone, it is not mine and the parallel session owns
that line.**)

Both new constants are reported in `esp-cone-init:` as `halfAngle=50deg graceFrames=30`, so a
retune shows up in the log rather than having to be inferred from `culledPct`.

**Interim geometry for the next run** -- 50 deg was chosen because a 70-90 deg FOV puts the
100 deg full cone's edge outside the visible area. If skeletons still flicker at the screen
edge, the next step is a larger grace rather than a wider cone, because a wider cone costs
directly and the grace only costs the 30 ticks that have already been spent.

Verified: both consumers clean, **0 errors and 0 warnings**, in `Prod|x64` and
`Prod no aimbot|x64` (one `C1083` on the PCH on the way, which cleared on retry and which
`AimbotModule.cpp` -- same headers, same config -- compiled through; contention, not code).
`tools/tests` **179 passed**.

### 5.7r Handed over from the parallel session: the camera guard that guarded the wrong thing

The parallel session sent a precise chain and left it alone because "the fix is in the ESP
agent's file". **Independently verified -- all four claims hold.**

1. `camera_is_enabled` (`eft_api.h:3201`) began `if (!camera || !camera->klass) return false;`
   and then **immediately made a managed call** -- `get_enabled`, then
   `component_get_game_object` -> `get_activeInHierarchy`. Both confirmed in source. Every
   managed call on a `UnityEngine.Object` dereferences `m_CachedPtr` at `this+0x10` first, so
   on a destroyed object the wrapper is alive and `klass` is valid and **the call is what
   faults**. This is Unity's fake null: `Object.Destroy()` zeroes `m_CachedPtr` and leaves the
   managed wrapper standing.
2. Reachability confirmed: `EspModule::draw_overlay` (`EspModule.cpp:4660`, render thread)
   calls `resolve_esp_camera` twice, at :4734 and :4739.
3. `camera_is_enabled` is reached only from `resolve_esp_camera`'s optic branch
   (`eft_api.h:3458`), guarded by `if (!optic || optic == fps || ...)`.
4. **A helper for this already existed and was simply not used here.**
   `unity::is_unity_object_alive` (`unity.h:1084`) resolves `m_CachedPtr` **by name** rather
   than hardcoding `+0x10`, returns false when it is null, and additionally `VirtualQuery`s the
   native pointer under a TTL memo. It has **9 existing call sites** -- `asset_bundles.h`,
   `ChamsModule.cpp`, `optics_lens_pipeline.h`, `skeleton_visibility.h:1232`. The camera path
   was the one place still carrying the old wrapper-level guard. **So this is not "add a
   guard", it is "use the guard the codebase already has".**

**The 0.16 link is tighter than "same defect class".** 0.16's signature was, verbatim from the
changelog, **"fault offset `...E798`, read at `+0x10`"** -- and `+0x10` is exactly
`m_CachedPtr`. 0.16's fix was `is_unity_object_alive` at `skeleton_visibility.h:1232`. So the
crash we already fixed once, and this unguarded door, are the **same read of the same field**,
and 0.16's fix never covered this path. That is worth more than a defect-class resemblance.

**What I found that the handover did not mention: the exposure is WIDER than reported.**
`pick_esp_fps_camera` (`eft_api.h:3342`) is the **unconditional** path -- it runs on every
frame for both `prefer_optic` values -- and it had **no liveness check anywhere**. It was
making managed calls (`name_equals`, `camera_world_position`) on **every candidate** during
enumeration, and falling back to `unity::get_current_camera()` at :3367, which never passes
through the predicate at all. The report named the guarded-but-wrong site; the unguarded one
was next to it.

**Fixed, three places, all using the existing helper:**

- `camera_is_enabled` -- now `if (!unity::is_unity_object_alive(camera)) return false;`
- `pick_esp_fps_camera`'s **predicate** -- liveness first, so a destroyed camera is never
  touched during enumeration. The enumeration calls are the EARLIER fault site; a check on the
  winner alone cannot help there. Affordable because `is_unity_object_alive` memoises on the
  native pointer, so the `VirtualQuery` is once per TTL window per camera, not once per frame.
- `pick_esp_fps_camera`'s **selection** -- one check on the winner, which is the only cover for
  the `get_current_camera()` fallback. Records `cam_source::none` rather than the attempt, so
  the source histogram stays truthful.

**Recorded limit, so this is not over-trusted later:** `is_unity_object_alive` reads
`obj->klass`, so it guards a **destroyed-but-alive wrapper**, not a wrapper whose own memory
was freed. It answers exactly the question the old check got wrong, and no more.

**NOT PROVEN: reachability during teardown.** `draw_overlay` returns at `EspModule.cpp:4667`
on `if (!game_state::is_in_raid) return;`, so the whole path is dead once that flips. Whether
`is_in_raid` goes false **before** the cameras are destroyed, or after, is unestablished --
and it is the difference between a live crash and a latent one. This is also a candidate for
the unexplained post-exfil crashes, but the crash probe is detached at teardown (established on
two sessions), so there is no capture that could confirm it. **Treating this as fixed is not
the same as having shown it was the cause.**

A side effect worth naming: a destroyed camera no longer counts toward `named_matches`, so
`g_cam_named_multi` stops reporting a dead camera as a name collision. That is the more
correct reading of the counter.

Verified: `EspModule.cpp` and `AimbotModule.cpp` clean, **0 errors and 0 warnings**, in
`Prod|x64` and `Prod no aimbot|x64`. `tools/tests` **179 passed**.

#### 5.7r-a Follow-up: the boundary measurement, and what it did NOT settle

The `raid-boundary` lines were checked, since that is what they are for.

**THE PRESUMPTION IS CONFIRMED for the one boundary the log can show.** `pid=16740`:
the poll cleared `is_in_raid` at **06:51:32** (raid 1 over), and there is **zero ESP camera
activity between then and the next raid**. `esp-path` resumes at 06:56:27 and `vis-cone` /
`vis-breakdown` at 06:57:30, but those belong to **raid 2**, which began at 06:56:21.782
(`hk_local_raid_started`) -- the flag was legitimately re-armed by
`common_hooks.cpp:296`. The gate held.

**WITHDRAWN: the "580 `esp-path` lines after the boundary contradict the gate" claim made
minutes earlier in this same investigation.** Those lines are raid 2, correctly gated. A
timestamp filter alone does not separate "after the flag dropped" from "after the next raid
started", and I read the first as the second.

**The flood is already fixed by the parallel session**, so nothing was done about it.
`common_hooks.cpp:286` gates on `const bool moved = game_state::set_in_raid(false);` and logs
only when the flag actually moved, and `game_state.h:67-73` documents this exact
16,964-lines / 59%-of-log measurement as the old build's defect. The new session (`pid=3560`)
has **zero** `raid-boundary` lines, which is exactly what the fix predicts. Re-measuring it
would have been duplicate work.

**AND THE OPEN QUESTION IS NOW MUCH NARROWER, by static reachability rather than by
measurement.** `resolve_esp_camera` has exactly **two** call sites -- `EspModule.cpp:4788` and
`:5354` -- both inside `draw_overlay`, both after the `if (!game_state::is_in_raid) return;`
at `:4667`. So `!is_in_raid` **cannot** reach the camera path. That is stronger than a runtime
counter would have been.

**What remains open, and the log cannot answer it: the boundary we can see is not the boundary
that matters.** 06:51:32 was a raid end **into a live menu** -- raid 2 followed, so no scene
teardown occurred. The exfil teardown boundaries are exactly the ones the crash probe does not
cover (handler detached at teardown, established on two sessions). So there is **no evidence
either way** about camera liveness during teardown.

**The remaining question is one fact: does `InGameStatus.InRaid` go false BEFORE or AFTER the
camera is destroyed?** Before => a window exists where the flag is true and the camera is gone,
and that is the crash. After => no window, and the 0.30 guard is cheap insurance.

**NOT YET BUILT:** a one-shot probe at the exact `set_in_raid(false)` transition that resolves
the ESP camera once and reports `alive=` through `unity::is_unity_object_alive`. One line, once
per raid, same pattern as `esp-cone-init:`. It retires cleanly either way -- a negative result
means the guard stays as insurance and the probe comes out. Left unbuilt pending a decision,
because it is a diagnostic and the last two instruments in this file both reported conclusions
they had not earned.

### 5.7s The camera guard backfired, measured, and the per-candidate half was removed

Session `pid=21812`, build `0x6AC1E40D`, 08:37 -> 08:49, capture
`next_next_next_day+1+crash.tracy`. The 0.30 guard is in this build, and the measurement says
**most of it was a mistake.**

**THE CALL COUNT TRIPLED AND IT IS MINE.** `unity::is_unity_object_alive`, inclusive:

| capture | calls | total ms | mean us |
|---|---|---|---|
| `next_next_next_day+crash` (07:07, pre-guard) | 36,547 | 1,457 | 39.87 |
| `next_next_next_day+1+crash` (08:37, post-guard) | **140,875** | 64,866 | 460.45 |

The arithmetic pins the source beyond doubt: `eft_api::resolve_esp_camera_frame` ran **14,198**
times, and 140,875 / 14,198 = **9.92 calls per resolution** -- the per-candidate predicate over
~9 enumerated cameras, plus the selection check, plus `camera_is_enabled`. Essentially every
one of those calls came from the guard added minutes earlier.

**AND IT BACKFIRED, which is the part worth keeping.** `is_unity_object_alive` memoises on the
native pointer, and its TTL is counted in **CALLS** (`kNativeMemoTtlCalls`). Quadrupling the
call volume therefore quadruples how fast the memo expires. The log's own report --
`unity-memo: hit/miss=...` -- fell from **98% to 55%** in the same session, which is verbatim
the symptom its report text warns about ("a rising miss rate means the TTL is too long for how
fast pointers change"). **The guard destroyed the caching it was relying on.** A check whose
own memo is invalidated by being called more often is not a cheap check.

**REMOVED:** the per-candidate guard in `pick_esp_fps_camera`'s predicate. It was ~9 of the 10
calls per resolution and it protected the least -- those enumeration calls were already running
unguarded for the whole project without faulting. **KEPT:** the `camera_is_enabled` guard
(`eft_api.h:3222`, the defect actually reported) and the single selection check
(`eft_api.h:3413`, the only cover for the `get_current_camera()` fallback). That is **2 calls
per resolution instead of ~10**.

**THE RESIDUAL IS RECORDED IN THE SOURCE, not hidden:** the enumeration still makes managed
calls on every candidate, so a camera destroyed *mid-enumeration* is not caught. If a
per-candidate check is ever wanted it must be a **pointer comparison against last frame's
camera**, not a syscall.

**WHAT I AM NOT CLAIMING FROM TRACY.** The 460 us mean and the 64.9 s total are **not
quotable**, and the reason is structural rather than a caveat: `is_unity_object_alive` is called
from **two threads** -- render via `draw_overlay`, game via the aimbot pen-check -- so that CSV
row aggregates two independent per-thread trees and cannot be compared against either parent.
The inconsistency is visible and unarguable: `resolve_esp_camera_frame` (35.5 s) **exceeds**
`draw_overlay` (30.3 s), which is its only caller, and `is_unity_object_alive` (64.9 s)
**exceeds** `Aimbot` (58.5 s) entirely. A child cannot exceed its parent.

Capture-to-capture timing is confounded as well: `ModuleManager::apply` went from 90,985 calls
to 52,223 while its total time *rose*, so this was simply a heavier raid. **What survives as
evidence is the call count** -- it is arithmetic from the code, not a timing -- **and the log's
hit rate**, which is independent of tracy entirely.

**What a per-thread split would need, and does not exist:** tracy-csvexport aggregates by zone
name and `-u` unwraps events but does not separate threads, so this would require a distinct
zone name per calling thread. Not built.

**Incidental corrections from this session's own tooling, both of which had been documented
already and were re-learned the hard way:**

- `tracy-csvexport` has **no `-o`**; it writes to stdout. `-RedirectStandardOutput` is required.
- There is **no `extract` subcommand** -- `tools/tracy/README.md` says so explicitly, and
  passing `extract` prints usage and exits 1. The correct form is `[OPTION...] <file>`, file
  last, via `Start-Process -ArgumentList` because the capture names contain `+`.
- CSV columns are `name, src_file, src_line, total_ns, total_perc, counts, mean_ns, min_ns,
  max_ns, std_ns, percentile_ns, truncated_mean_ns` -- `mean_ns` is **[6]**, `percentile_ns`
  is **[10]**. `percentile_ns` is NOT the echoed `-t` value.

**This session's other findings, for the record.** The cone fix is confirmed live in this build:
`esp-cone-init: dirOk=true originOk=true active=true yaw=0.0deg fwd=(0.00,1.00)`. Note
`yaw=0.0` with `dirOk=true` -- the exact ambiguity that made the original
`get_transform_yaw_y` unusable, now disambiguated by the separate flag, which is precisely why
`try_get_transform_yaw_y` returns `bool` rather than a float.

The capture is named `+crash` and the session ends with **no closing exception histogram** and
**no `raid-boundary` line at all** -- last `vis-cone` at 08:49:50.743, last log line 08:49:55.436.
The flag never visibly cleared, so this is not the exfil-teardown boundary 5.7r-a was after; it
is consistent with a death/teardown path instead. `raid-boundary` produced zero lines, exactly
as the parallel session's `moved` gate predicts.

Verified: `EspModule.cpp` and `AimbotModule.cpp` clean, **0 errors and 0 warnings**, in
`Prod|x64` and `Prod no aimbot|x64`. `tools/tests` **179 passed**.

### 5.7t Handler-ownership probe: who takes the two single-slot report doors at teardown

Asked for directly, with the standing guess being "Unity's own Crash Handler".

**FIRST: A CORRECTION TO THE PREVIOUS SECTION, because I got it wrong twice over.**

1. **"No closing histogram" was MY BUG, not an absent crash.** The crash-probe block's
   *continuation* lines do not repeat the `[timestamp] pid=` prefix. Every check I made this
   session filtered on `pid=`, which silently discarded the entire block. There *was* a FATAL in
   that log the whole time. **Any earlier conclusion of mine that rested on "no FATAL / no AV /
   no histogram" after a `pid=` filter is unsafe and should be re-derived** -- notably 5.7r-a,
   which concluded from this log that the boundary was "the wrong one".

2. **The 5.7s denominator was wrong.** `aimbot::candidate_pick` and
   `eft_api::resolve_esp_camera_frame` have *identical* counts in both captures (14,198/14,198
   and 961/961) -- both are per-frame counters, so "calls per resolution" silently became
   "calls per aimbot candidate". The correct denominator is `frame::EspModule::draw_overlay`,
   which is render-thread only and so isolates the camera path's contribution:

| capture | liveness calls | render frames | per render frame |
|---|---|---|---|
| 07:07 pre-guard | 36,547 | 34,016 | **1.07** |
| 08:37 predicate guard IN | 140,875 | 18,796 | **7.49** |
| 10:05 predicate guard OUT | 9,096 | 8,014 | **1.14** |

   **The 5.7s conclusion survives and the fix is confirmed** -- back to baseline, with the memo
   hit rate recovering 55-57% -> **95-98%**. But the published figure was wrong, and against a
   per-frame baseline it reads 7.5, not 9.9. Two ratio mistakes in one thread is the record
   worth keeping: *check whether two "independent" counters are actually equal before dividing
   by one of them.*

**The crash that was in the log, unfiltered:**

```
REPAIRED: terminate handler had been taken (0x7FFC030B5230, not our 0x7FFB26BE48C0)
REPAIRED: unhandled-exception filter had been taken (0x7FFB26C926E0, not our 0x7FFB26BE4A60)
===== FATAL (unhandled exception filter) =====
code=0xE06D7363 flags=0x00000081 NONCONTINUABLE tid=26332
faulting rva=<outside this module>
thrown type: UNRESOLVED  ExceptionInformation = 0x19930520 0x2997CFBE00 ...
```

- `0x19930520` is MSVC's C++ exception magic in `ExceptionInformation[0]` -- a genuine `throw`,
  via `KERNELBASE!RaiseException`, first frame above it `UnityPlayer.dll+0x2144E6`.
- **`TarkovAddons.dll` appears in NO frame.** Only in the probe's own identity lines.
- After `Local Raid Ended` / `Insured Items: 0` / `Transfer Items: 1`.
- Tid **26332** for the throw; tid **16028** for the pinned bulk of captured exceptions.
- Frames are explicitly a **word scan, not a symbolised unwind** ("frames=9 (scan of stack
  words, not code)"), so single frames are unreliable -- one names `amdxx64.dll`, almost
  certainly a misattributed stack word rather than a call. The exception TYPE was never
  resolved, so what was thrown is still unknown.

**The camera guard is EXONERATED for this crash, by ordering.** The raid ended through the
`LocalRaidEnded` **event**, so `set_in_raid(false)` fired and `draw_overlay` was gated off
before the throw. The camera path was unreachable. That is an ordering fact, NOT evidence that
the guard was unnecessary.

**THE PROBE, and the constraint that shaped it.** `verify_handlers` already holds the taker's
address at the exact moment of detection (`g_prev_uef` / `g_prev_terminate`) -- an address is
not an answer, so the new work is attribution:

- `module_owner_of(void*, char*, size_t, unsigned& rva)` -- resolves an address to a module
  basename plus RVA. Uses **`GetModuleHandleExW(FROM_ADDRESS | UNCHANGED_REFCOUNT)`**, which is
  the same mechanism `install()` already uses to identify our own image, so nothing new is
  relied on. **Our own base is checked FIRST**, because this module is MANUAL-MAPPED and may be
  absent from the loader lists (the boot banner says so outright) and because a displacement
  *by us* must read as ours rather than as a mystery.
- `report_handler_owners(const char*)` -- calls `verify_handlers` (re-assert + record), then
  reports `intact=` plus both owners. `intact=false` means a slot was TAKEN, and the named
  owner is then the taker rather than the install-time chain.

**WHY IT IS NOT INSIDE `verify_handlers`, which is the real design point:** `verify_handlers` is
reachable from the **vectored handler** (`crash_probe.h:1459`) and `GetModuleHandleExW` takes
the **loader lock**. The crash under investigation happens at **teardown**, which is exactly
when that lock may already be held -- so asking from a VEH risks deadlocking on the very event
being investigated. `verify_handlers` therefore still only RECORDS, and resolution is deferred.

**Call site:** `module/common_hooks.cpp:311`, `crash_probe::report_handler_owners("raid-boundary")`,
immediately after the `set_in_raid(false)` transition block -- deliberately OUTSIDE `if (moved)`,
so it reports on every false read rather than only when something changed, because the whole
question is what changed *without* our flag moving. Both raid-end doors (the event and the
poll) land there, so either way a raid ends, the taker gets named. One line per menu frame.

**WHAT WOULD SETTLE THE PRESUMPTION:** a `handler-owner` line showing
`UnityPlayer.dll+0x...` confirms Unity's CrashReportModule. `(not in the loader lists)` would
mean a manual-mapped injector, which is a different and more interesting answer. Either is a
real result; the current note is a guess and this replaces it.

Verified: `common_hooks.cpp`, `EspModule.cpp`, `AimbotModule.cpp` clean, **0 errors and 0
warnings**, in `Prod|x64` and `Prod no aimbot|x64`. `tools/tests` **185 passed**.

### 5.7t-a The gap in 5.7t, closed: attribution has to work at the CRASH, not at the boundary

Asked whether the next run would answer the question. **It would not have, and the reason is
worth recording.** The 2026-10-04 `REPAIRED` lines arrived in the SAME BREATH as the `FATAL` --
the slots were taken **at teardown**, which is AFTER the raid boundary. A process that dies there
never reaches another boundary to be asked. So the boundary call would have printed `intact=yes`
and the TAKER WOULD NEVER BE NAMED: an address from the REPAIRED line, and nothing more.

**So there are now TWO paths, because they fail in different circumstances:**

1. **At the boundary** (`module/common_hooks.cpp:311`) -- ordinary thread, refreshes the table and
   reports `intact=` plus both owners. Covers a take-over that happens *before* the flag drops, and
   gives the baseline.
2. **At the crash** (inside `verify_handlers`, which the vectored handler reaches at `:1459`) --
   both `REPAIRED` emits now carry `taken by <module>+0x<rva>`. This is the one that matters,
   because it is the same instant as the `FATAL`.

**The constraint that shaped path 2, and it is not a style preference.** Path 1 can use
`GetModuleHandleExW(FROM_ADDRESS)`, which is safe from an ordinary thread. Path 2 cannot:
`verify_handlers` is reachable from the **vectored handler**, `GetModuleHandleExW` takes the
**loader lock**, and the crash under investigation happens at **teardown** -- exactly when that
lock may already be held. Asking there could deadlock on the very event being investigated.

So the names are resolved ONCE from a safe context into a **static module table**, and the
VEH-side lookup is a linear scan over it: no API call, no lock, no allocation, nothing that can
block.

- `refresh_module_table()` -- **SAFE CONTEXTS ONLY.** Populates up to 256 `{base, size, name}`
  records via `K32EnumProcessModules` (kernel32, Win7+), falling back to the psapi export.
  Resolved with `GetProcAddress` rather than linked, so no import library is needed. Called from
  `install()` and from `report_handler_owners()`. The count is published with
  `memory_order_release` **after** the records are written, so a concurrent reader sees either the
  old count or the new one against fully-written records, never a half-written one.
- `module_owner_lockfree()` -- the VEH-safe lookup. Checks **our own `g_base`/`g_size` first**, so
  a displacement *by us* can never be misattributed (this module is MANUAL-MAPPED and may be
  absent from the loader lists -- the boot banner says so outright). On no match it prints
  `(not in the table; region base 0x...; table has N modules and may be stale)` -- **an unknown is
  reported as unknown, never guessed at.**

**The staleness trade, stated rather than hidden:** the table is a cache, so a module loaded after
the last refresh is unknown until the next one. That is deliberate -- a stale answer that cannot
deadlock beats a fresh one that can. The boundary call refreshes it every menu frame, so in
practice it is current well before any teardown.

**ONE resolver, not two.** A first attempt kept `GetModuleHandleExW` for the boundary path and
added the table for the VEH path. That was two resolvers with two different failure modes for one
question, so the `GetModuleHandleExW` one was deleted and everything uses the lock-free lookup.
The boundary path loses nothing by this -- the table is refreshed there anyway.

**Surgery hazard, self-inflicted, twice, and both are the same mistake.** Deleting the old
resolver by "first line whose `strip()` is `}`" matched an **inner** brace and left an orphaned
function tail, which surfaced as `error C2059: syntax error: if` pointing at innocent-looking
code 170 lines away. Separately, two `find()` calls for "the `context ? context` line" both
matched the **first** occurrence, so the second overwrote the first and the UEF emit ended up
passing the terminate handler's variables. Both were found by reading the region, not by trusting
the error line. **Match closers on exact indentation, and make `find` assert on a UNIQUE match --
`assert len(matches) == 1` -- rather than silently taking the first.**

Verified: `dllmain.cpp`, `common_hooks.cpp`, `EspModule.cpp`, `AimbotModule.cpp` clean,
**0 errors and 0 warnings**, in `Prod|x64` and `Prod no aimbot|x64`. `tools/tests` **190 passed**.

**What to look for, and what each outcome means:**

- `handler-owner (...): intact=NO, a slot was TAKEN and re-asserted | UEF slot -> UnityPlayer.dll+0x...`
  -- **the standing guess is confirmed**: Unity's CrashReportModule takes the slot.
- `... -> (not in the table; region base 0x...)` -- a **manual-mapped injector**, which is a
  different and more interesting answer than the one on record.
- `intact=yes` at every boundary **and** a `REPAIRED` line naming a module at crash time -- the
  take-over happens strictly between the two, which is itself the finding.
- `intact=NO` at a boundary with **no** module named -- then the table was stale, and the fix
  belongs in the refresh cadence, not in the lookup.

### 5.7t-b It DID link-fail, and the per-TU verification habit is what hid it

Asked "it doesn't compile?" -- it did not COMPILE, it failed to **LINK**, and the difference
matters.

```
common_hooks.obj : error LNK2005: "struct std::atomic<bool> crash_probe::g_warned_uef"
  (?g_warned_uef@crash_probe@@3U?$atomic@_N@std@@A) already defined
common_hooks.obj : error LNK2005: ... crash_probe::g_warned_terminate ... already defined
```

**Cause.** `util/crash_probe.h` declares

```cpp
std::atomic<bool> g_warned_uef{ false };
std::atomic<bool> g_warned_terminate{ false };
```

as plain namespace-scope objects. That is fine in a header that exactly ONE translation unit
includes -- and that was true until 5.7t added `module/common_hooks.cpp` as a second includer, to
call `report_handler_owners()` at the raid boundary. Two translation units then each emitted a
definition. **These two symbols are pre-existing, not new**; the second includer is mine, so this
is my defect, but it was latent in the header rather than introduced by the probe logic.

**Fixed** by marking both `inline` (C++17 inline variables -- one definition, merged across TUs).
The linker named exactly those two and no others, which is the complete set of ODR violations here;
`g_base`, `g_size`, `g_prev_uef`, `g_prev_terminate`, `g_modules` and `g_module_count` were already
`inline`, which is why the new code linked cleanly on its own.

**THE HABIT THAT HID IT, which is the part worth keeping.** Every verification in this session has
been per-TU:

```
$t:ClCompile /p:SelectedFiles=module\impl\EspModule.cpp
```

That compiles one translation unit and **stops before the link**. It was the right call for most of
this session -- it is fast, and it sidesteps the PCH/PDB contention a full build suffers -- but it
is structurally incapable of seeing an `LNK2005`, an unresolved external, or a duplicate symbol.
I reported "clean, 0 errors and 0 warnings" eight times across four TUs while the project did not
link. **A header change that adds a second includer cannot be validated that way at all**, because
the defect exists only across translation units.

**Rule from here: any change to a header's INCLUDE SET gets a full build with link before it is
reported as verified. Per-TU compile remains the fast path for logic changes inside one .cpp.**

**Why this failure mode is nonetheless the good one:** an ODR violation cannot pass silently. It
is a loud link error naming both symbols, on the first full build. The dangerous version of this
bug would have been a static local or a template instantiated differently per TU -- silent, and
wrong only in one configuration.

**Full verification, both configurations, compile AND link:**

| configuration | result |
|---|---|
| `Prod|x64` | exit 0, **0 errors, 0 warnings** |
| `Prod no aimbot|x64` | exit 0, **0 errors, 0 warnings** |

`tools/tests` **190 passed**. Note this is also the first **whole-project** clean build recorded in
this session -- including the parallel session's `QuestModule.cpp` / `QuestResetModule.cpp` /
`quest_objectives.h`, which were mutually incompatible earlier today (5.7-era note) and evidently
reconciled since. That is their work, not mine, and worth acknowledging rather than re-verifying.

### 5.7t-c I crashed the game with the probe, and the cause is worth more than the fix

Build `0x6AC207E5` (pid 24172) died within seconds of launch. **My defect, introduced by the
0.34 attribution work.**

**The evidence, and it was enough on its own:**

| source | what it said |
|---|---|
| the log | ends at `Menu Key: Insert`; boot had otherwise progressed normally through the probe install and module init |
| the crash probe | **nothing at all** -- no block, no histogram, no FATAL, despite the probe being armed |
| the user | "crashes immediately", then "event log says ucrtbase" |
| WER | `ucrtbase.dll` / `c0000005` / `+0x65655`, **the same site twice in one report** |

**THE MECHANISM.** `ucrtbase` is the CRT, and the fault was a **recursive fault inside the vectored
exception handler**, caused by my own code:

1. EFT throws C++ exceptions constantly, including during startup.
2. The VEH fires and calls `verify_handlers_throttled`, whose **first call is immediate** --
   `last == 0` means "never checked", so `kVerifyIntervalMs` does not delay it.
3. A slot reads as displaced, so `module_owner_lockfree` runs -- **inside the VEH**.
4. It called `std::snprintf` to copy the name and format the "not found" text.
5. `snprintf` re-entered the CRT at the point the process was already unhappy, faulted, and the
   **VEH fired again from inside the first one**.
6. Recursive fault in a VEH is terminal, and the probe's own report path was already mid-fault --
   **which is exactly why it printed nothing.** The silence was the tell.

The duplicated `+0x65655` in one WER report is the recursion, not two independent faults.

**THE FIX: `module_owner_lockfree` is now CRT-FREE.** `put_bounded` / `put_hex_bounded` do bounded
copies and hand-rolled hex by hand. No printf, no CRT, no allocation, nothing that can block. The
RVA is *returned* to the caller and formatted by `emit()`, which already runs in that context
safely. `VirtualQuery` is kept -- a syscall with no lock -- and hand-hexed, because dropping the
region base would drop the diagnosis with it.

**Scope corrected:** this is NOT "no CRT anywhere in the file" -- `emit()` and friends already
format in the reporting path and always have, and `refresh_module_table()` keeps `snprintf`
because it runs on the **init thread** (`dllmain.cpp`'s `init(LPVOID)`, verified NOT `DllMain`,
which is at :344), where no loader lock is held. The rule is narrower and sharper: **nothing that
re-enters the CRT may run from the vectored handler.**

**A correction to my own reasoning last section:** I attributed the risk to
`GetModuleHandleExW` taking the loader lock. That was real but it was not what bit. The actual
trap was calling *any* CRT function from a fault context, which is a different failure and would
have bitten the `GetModuleHandleExW` version too.

**Also fixed:** `using enum_modules_fn = BOOL(WINAPI*)(..., LPDWORD*)` -- `LPDWORD*` is not a type;
`EnumProcessModules` takes `LPDWORD`.

**HOW THIS WAS REPAIRED, because the process matters.** The first repair attempt deleted the wrong
function: `find("inline bool module_owner_lockfree(")` matched the **forward declaration** I had
added minutes earlier, so the "replace the body" step deleted from the declaration down to the next
4-space `}`, which swallowed `verify_handlers()` -- the whole function, both REPAIRED arms and all
-- plus `struct module_rec`, `g_modules`, `g_module_count` and `refresh_module_table()`. The
resulting `C2065: g_module_count undeclared` was the only symptom and it pointed nowhere near the
cause. Positional patching of this file had failed **four separate times** today (orphaned brace,
first-match `find`, `strip()`-matched inner brace, now the forward declaration), so I stopped
patching: **restored `crash_probe.h` from the last known-good copy and re-applied every change in
ONE script with an assertion after each step plus a verification pass.** It applied first try
after fixing the script's own bugs, which were all in the assertions rather than the edits:

- a two-line signature means `"...rva_out) {"` is never on the signature's own line;
- an inserted declaration contains the anchor it was searched by, so `find` matched it too --
  fixed by anchoring on `context ? context`, which only an `emit` argument list contains;
- a forward declaration's `);` is on its *second* line, so an endswith filter counted it as a
  definition.

**The transferable lesson: after N positional edits fail on one file, the correct move is to
restore and re-apply, not to attempt edit N+1.** And when an anchor is a substring that your own
inserted text also contains, `assert len(matches) == 1` will not save you -- the inserted text
becomes a legitimate second match.

Verified: **full build with link**, `Prod|x64` and `Prod no aimbot|x64`, **exit 0, 0 errors, 0
warnings** in both. `tools/tests` **190 passed**.

**Next run is the real test of the fix:** boot must survive. If it does, `handler-owner` /
`REPAIRED` lines carry a module NAME rather than a bare address. If it still dies, the next
candidate is the same class -- something else in the VEH path re-entering the CRT -- and
`install()`'s `refresh_module_table()` would then be the thing to suspect, since it is the only
remaining new call on an early path.

### 5.7t-d The reporter was crashing while it reported -- and it was my varargs

Still crashing, "but not with Unity crash, EFT crash now ... the logo on the crash that appears
for split second changed". **Both clues were load-bearing, and the second one meant the process
was dying somewhere new.**

**WHAT THE MINIDUMPS SAY.** `tools/minidump_read.py` against `%LOCALAPPDATA%\CrashDumps`:

| dump | time | build | exception |
|---|---|---|---|
| `3560` | 07:54 | `0x6AC1D894` | `0xE06D7363` at `KERNELBASE+0x241CA` (RaiseException) |
| `24172` | 11:05 | `0x6AC207E5` | `0xC0000005` at `ucrtbase+0x65655`, **read at `0xA5230`** |
| `19516` | 11:59 | `0x6AC21084` | `0xC0000005` at `ucrtbase+0x65655`, **read at `0xA5230`** |

**THE FIRST IS THE REAL FAULT AND IT IS UNCHANGED** -- an unhandled C++ exception thrown from
GameAssembly, identical in shape to the one in 5.7t-c. The other two are new, and they are MY
REPORTER CRASHING. `ucrtbase+0x65655` is **`_itoa+0x1C5`** (dumpbin /exports against
`C:\Windows\System32\ucrtbase.dll`, nearest export below is `_itoa` at `0x65490`), the decimal
integer formatter, reading from `0xA5230`.

**`0xA5230` IS NOT RANDOM AND NOT A CASCADE.** It is the **RVA of the foreign handler**, and it
is byte-for-byte identical in both dumps because it is the same handler both times.

`tools/symbolize.py` against the PDB gives the chain, in order:

```
crash_probe::handler    +0x631    (the vectored handler)
crash_probe::emit       +0xFE
crash_probe::emit_ring  +0x3AF
crash_probe::image_name +0x124
```

So the original `0xE06D7363` arrives, the VEH reports it, and **the report faults**.

**THE CAUSE, and a compiler could never have caught it.** `emit()` is printf-style varargs. The
format reads

```
"...REPAIRED (%s): ... taken by %s+0x%x (0x%p, not our 0x%p)..."
```

and I passed `(owner, rva, context, prev, ours)` -- see 5.7t-b's arg order. So the **second `%s`
received `uef_rva`, an `unsigned`**, and the CRT read a string from it. `0xA5230` is exactly
that integer reinterpreted as an address. **Both** arms were wrong the same way.

It faulted INSIDE the vectored handler, so the handler re-entered, and a recursive fault in a
VEH is terminal. **That is the actual reason these crashes have been invisible** -- and it means
the explanation recorded in 5.7t-c and 5.7r-a was WRONG. It was never "the handler detaches at
teardown". It is *a reporter that dies mid-report*. The changed logo follows: once the probe
kills the process, a different component's crash UI gets there first.

**CORRECTION TO 5.7t-c / 0.36.** That section blamed `std::snprintf` inside
`module_owner_lockfree`, on the reasoning that calling the CRT from a fault context recursed.
The CRT-free lookup is still correct and stays -- but it **was not the cause**: `REPAIRED`
appears **zero** times in both crashing runs, so that function never executed. I had the right
file and the wrong function, and the 0.36 note claiming "`emit()` already runs in that context
safely" was simply false: `emit()` was the thing crashing. It does now.

**`image_name` IS STILL WORTH HARDENING, and is NOT this bug.** It calls
`GetModuleFileNameA`, which walks the PEB loader lists -- which this file's own boot comment
says are unreliable here precisely because the image is manual-mapped. That is a PEB walk from
a reporting path that runs after a fault. It is not what killed these two runs, and it is the
next thing to harden rather than a finding.

**THE GENERAL LESSON, which is the fourth time this session.** A printf-style call is
**unverified by every tool I have**: the compiler does not check it, a full build with link
does not check it, and 190 unit tests do not check it. The only thing that caught it was
symbolising a stack I had previously looked at and found "unreliable". So:

- **verify varargs format/argument agreement mechanically**, the way the fix does -- parse the
  format, assert the argument order matches. That is now what the fix's own verification does,
  and it is cheap.
- **The post-exfil `0xE06D7363` is still unexplained and is still the real bug.** What changed is
  that the probe can now survive reporting it, so the next occurrence should finally produce a
  FATAL block with a thrown type and frames instead of silence.

Verified: full build AND link, `Prod|x64` and `Prod no aimbot|x64`, exit 0, **0 errors, 0
warnings**. `tools/tests` **190 passed**. Committed `1146a6ec`.

**STILL UNCOMMITTED, and it is mine: `module/common_hooks.cpp:311`, the
`crash_probe::report_handler_owners("raid-boundary")` call.** It cannot be committed
independently -- it sits inside the parallel session's uncommitted raid-boundary rewrite, and
HEAD's `game_state.h` still has no `set_in_raid`, so committing it would break the build at
HEAD. It needs their `game_state.h` to land first. **This is the last piece of the handler-owner
probe**: without it the probe names the taker only when a REPAIRED happens, which -- now that
REPAIRED works -- is evidence the question may already be answerable without it.

### 5.7u The parallel session found a real cause in MY code, and here are my premises about THEIR code

Two separate things, and the first one is a correction I owe.

#### 5.7u-a They found why the 460 us was real, and I had written it off

CHANGELOG 0.59 (theirs) reports `unity::is_unity_object_alive` at **64.87 s / 460 us mean / 98%
memo hit rate** -- the same three numbers I measured from `next_next_next_day+1+crash.tracy`.

**I declined to quote them.** My reasoning was that `is_unity_object_alive` runs on two threads,
so the CSV row merges two per-thread trees, and the giveaway was a child exceeding its parent:
`resolve_esp_camera_frame` 35.5 s > `draw_overlay` 30.3 s (its only caller), and
`is_unity_object_alive` 64.9 s > `Aimbot` 58.5 s entirely.

**That reasoning was wrong.** The number is real and it has a cause, and they found it:
`maybe_report_native_object_memo()` early-returns unless 30 s have passed -- but
**`std::format`'s arguments are evaluated at the call site**, so the formatting work happened on
all 140,875 calls rather than the ~9 that print. The guard looks correct and is not.

That is a genuine defect in `il2cpp/unity.h`, in code that predates my work. What I did was
multiply the call count that reaches it (5.7s), so I made a latent bug expensive. **My 0.32
commit message and 5.7s both say the tracy timings are "not quotable"; that is wrong and should
be read as "the number is right and I did not know why".** They resolved it by measuring self
time (`-e`: 0.19 s / 13.5 us over 14,198 calls), which is the technique the README names and
which I did not reach for. The cross-thread observation was real; my conclusion from it was not.

Two things follow that are still worth checking: `maybe_report_native_object_memo` should be
gated on the cheap counter **before** the `std::format` call site, and the fix must not be gated
on `TA_ZONE_IS_ACTIVE` (that would tie a correctness fix to whether a profiler is attached).

#### 5.7u-b MY PREMISES ABOUT THEIR CODE, so they can be checked rather than trusted

Every line below is something I assumed while working next to code I do not own. Each is marked
VERIFIED (I read it in source), MEASURED (I have the number), or ASSUMED (nothing backs it but
me).

**P1 -- `game_state::set_in_raid(bool)` returns `bool` meaning "the flag actually moved".**
VERIFIED in their `game_state.h` comment. *My dependence:* `common_hooks.cpp:311`, which is my
last uncommitted line. *Deliberately NOT dependent on it:* my `report_handler_owners` call sits
outside `if (moved)`, because the question is what changed while our flag did **not** move. So
the bool's semantics can change without breaking my call -- but if `set_in_raid` is ever removed
or renamed, `:311` will not compile and that is the only coupling.

**P2 -- in the raid-boundary block, `is_in_raid` is the resolved `InGameStatus` CLASS, not the
bool.** VERIFIED at `common_hooks.cpp:63`. So the outer `if (is_in_raid)` means "is the class
resolved yet" and the inner `get_static_field<bool>(..., "InRaid")` is the actual flag. My
placement assumes only that it stays inside the class-resolved branch. If the poll is ever moved
or hoisted, my call moves with it.

**P3 -- `tracy::CrashFilter` takes our unhandled-exception filter slot; it was TEMPORARY and it is now standing state.**
VERIFIED, and this is the most useful of the set:

- `TracyProfiler.cpp:1633` -- `InstallCrashHandler()` does
  `SetUnhandledExceptionFilter(CrashFilter)`, called from `:2043`.
- `TRACY_NO_CRASH_HANDLER` and `TRACY_WIN32_NO_DESKTOP` are defined **nowhere** in the tree, so
  the `#if` at `:1630` is true and the install is live.
- `TRACY_ENABLE` **is** defined in all four x64 configs -- `TarkovAddons.vcxproj:139,169,211,304`
  -- and `tracy_bridge.h:5` says so. The "temporary" era ended twice: dropped from the two
  Prod configs 2026-10-08, restored 2026-10-10 on request (the vcxproj comment has the history).
- `RemoveCrashHandler()` at `:1642` reads
  `auto prev = SetUnhandledExceptionFilter(m_prevHandler); if (prev != CrashFilter)
  SetUnhandledExceptionFilter(prev);` -- so if my probe has already re-asserted itself, Tracy
  finds **mine** in the slot and puts it back rather than clearing it.

**So the REPAIRED churn is a consequence of `TRACY_ENABLE` being enabled in Prod -- and it is
back: the defines were dropped 2026-10-08, restored 2026-10-10, so treat the churn as expected
standing behaviour, not a closing window.** That is why the 0.37 conclusion ("nothing external
is disarming the probe") was right in direction but I never found the mechanism: it is our own
profiler. **No defence is needed beyond the existing re-assert, and no one should spend time
hunting an injector.**

**P4 -- `frame::AimbotModule::gameworld_update` has ~63 ms per call of UNINSTRUMENTED work.**
MEASURED, from `next_next_next_day+3+stuck.tracy`: **175,130 ms total over 2,753 calls, mean
63.6 ms**, which is **60.1% of the whole `hk_game_world_update` cost** (291,568 ms). Its own
child zones account for ~520 ms (`aimbot::candidate_pick` 241 ms, `project_to_screen` 236 ms),
leaving **~174,600 ms unattributed**. *Premise:* the zone wraps the whole function and no
`TA_ZONE` covers the expensive part. *NOT verified:* which statement. It is their file, I have
not touched it, and I have not read the function.
*Not a child>parent artefact*, which I checked because of 0.32: Aimbot ran on 2,753 of 14,544
ticks, so 175 s of the 291 s total is arithmetically consistent.

**P5 -- `find_camera_if_best` allocates a managed array per call.** VERIFIED,
`il2cpp/unity.h:907` -- `if (camera_get_all_internal) { scan(camera_get_all_internal()); ... }`,
which is Unity's `Camera.all`; and the fallback at `:915` calls `il2cpp_array_new` explicitly.
This confirms their 0.60 claim ("a fresh managed array allocation per call plus a `GetName` per
camera") from the other side. *My own premise, now retired:* "~9 cameras enumerated per call",
which I inferred from 140,875 / 14,198 = 9.92 and never counted. Their independent finding is
consistent with it.

**P6 -- `skeleton_visibility.h`'s ballistics model (`preset_id`, `material_type`, `fp_state`) is
theirs.** Committed in 33dfd2c4 wholesale, because `EspModule.cpp` calls symbols in that file
and a partial commit would not build. *Premise:* they will not be surprised, and the
`hit_target`-is-structurally-zero note in `name_looks_player_owned`'s replacement is about THEIR
mask design, not mine -- I only established that the walk never sees a player collider.

**P7 -- 18 of the 19 changed `lang/*.json` are their translation sync.** ASSUMED. Basis: the
`en.json` diff contained only `quest_*` keys, and my three `skeleton_*` keys were already
committed. I did not inspect the other 18.

**AND A LEDGER DEFECT, which is mine to flag and not mine to unilaterally fix:**
**CHANGELOG section numbers have collided.** `0.21` and `0.22` each appear TWICE -- theirs at
lines 2123 and 2198, mine at 2506 and 2571. Both agents started from 0.21. The earlier note
said the parallel session owns 0.20 and earlier and that I should renumber on collision; I did
not, because my 0.21-0.37 blocks were already written by the time their 0.21 landed. **The
ledger is ambiguous for those two numbers until someone renumbers.** My series is 0.21 through
0.37 and is contiguous; theirs is 0.20-0.22. Renumbering mine to 0.38+ is the cheaper fix and I
will do it on request rather than unilaterally, because it is 17 headings in a file both of us
are editing.

> **RESOLVED 2026-10-06 — renumbered, and the prediction above turned out to be wrong.**
> The two colliding entries are the ones that moved, not 17. When the collision was
> filed, each series still ran to 0.37; by the time this was fixed only **two** entries
> carried the duplicate numbers (the liveness-memo and aimbot-camera pair), while
> `0.23+` had long since merged into the single contiguous run that continues from the
> `0.20-0.22` side. So the "cheaper fix" reasoning was right and its arithmetic was not.
>
> Those two are now **§0.59** and **§0.60** — the two free numbers at the end of the run —
> and the pair also read in the right order now, which they did not before: the file had
> `0.22` *before* `0.21`, so it was both ambiguous and reversed. Every citation to the old
> numbers was re-pointed (4 of them, in this file and in
> `tools/handoff_exfil_overlay_and_probe_memo.md`), each attributed by matching the
> cited text against the entry's own content rather than by guessing. Nothing else was
> renumbered, so no other citation changed meaning.
>
> **The out-of-order entries at 0.17 and 0.41/0.42/0.44/0.47/0.49 are NOT fixed and are a
> separate problem.** They were inserted later into the middle of an earlier run and are
> unambiguous — a number appears once, so nothing cites them wrongly — but the file no
> longer reads in numeric order. Worth a pass; not worth doing as part of this one.

### 5.7v The aimbot memo corrected my exfil timing, and here are my premises about THEIR code

Answering 5.7u directly: **yes, they found something that was mine.** Not the exfil throw --
they never claimed that -- but they read `dxhook.cpp` correctly, quoted my "does not claim to
know which call throws" comment back at me accurately, and their item 2 is about a table in
`eft_api.h` that I have been treating as someone else's problem. Their premise 1 (Tracy holds
our UEF slot) is **VERIFIED below**, and it is load-bearing for my probe.

They also corrected me, and they are right. Details in 5.7v-a. My premises in 5.7v-b, each
marked VERIFIED / MEASURED / ASSUMED so they can be checked rather than trusted.

#### 5.7v-a I had the exfil timing wrong, and the correction changes the bug

I told the user the throw window "brackets local-player creation", because
`hk_local_game_create` at 13:06:45 falls inside the 13:05:41-13:06:53 throw window.

**`tools/handoff_exfil_overlay_and_probe_memo.md` section 1 has the ordering I never read:**

    [13:05:40.556] Local Raid Ended
    [13:05:41.584] ERROR overlay: draw threw at stage 'menu::draw' ... occurrence 1
    [13:05:42.542] DEBUG [transitdbg] OnGameEnd shape: ...

The raid ends first, the first throw is **1.028 s later**, `OnGameEnd` 0.96 s after that. So
this is the **first frame after the raid has ended**, not a race during the transition.
`hk_local_game_create` sits inside the window because it is a *consequence* of the transition,
not its cause. A stale-object read in a menu card is a different bug with a different fix, and
their memo names the next step (per-card stage markers).

The methodological half matters more than the conclusion. **My method could not have produced
that number.** I inferred from event *positions*; they read the log and measured a *gap*. An
event landing inside a window is not evidence of causation, and the first event in the window
is usually the meaningful one.

#### 5.7v-b MY PREMISES ABOUT THEIR CODE

**1. VERIFIED -- Tracy's crash handler is live and does take our UEF slot.** 5.7u-b premise 1 is
correct as stated. `TRACY_ENABLE` appears 11x in `TarkovAddons.vcxproj` (count re-measured
2026-10-10, after the Prod restore); `TRACY_NO_CRASH_HANDLER`
and `TRACY_WIN32_NO_DESKTOP` appear **0 times**, so the install is not compiled out.
`external/tracy/client/TracyProfiler.cpp:1633` calls `SetUnhandledExceptionFilter(CrashFilter)`
inside its install path, with `RemoveCrashHandler` at :1642 restoring via the saved
`m_prevHandler` and called from :1709 and :2151.

**The part that matters for my probe, which 5.7u-b could not know: we already handle it.**
`util/crash_probe.h:2080` re-asserts with `g_prev_uef = SetUnhandledExceptionFilter(on_unhandled)`,
and `verify_handlers()` returns false when it had to re-assert a slot, in which case it has
just refreshed `g_prev_uef`/`g_prev_terminate` to whoever DID hold it -- so the
`report_handler_owners` diagnostic names **Tracy's `CrashFilter` as the taker** rather than
guessing. Our filter chains to the previous handler *after* writing its report, so Tracy
filtering first and us second still produces our report. **No change needed; this is already
the designed behaviour.** Flagging it so nobody "fixes" the chaining on the assumption the slot
is uncontested.

**2. VERIFIED -- `is_in_raid` is cleared before any destruction.** This is the entire
justification for gating `resolve_esp_camera` on it instead of on object liveness, so I needed
it to be a fact rather than my reading. `module/impl/ItemModule.h:313` `hk_local_raid_ended`
calls `game_state::on_local_raid_ended_event()` FIRST -- before its own logging and before
`o_local_raid_ended` runs -- and the owner's own comment states the same reasoning I had, with
a measurement I did not have (2026-10-03 22:57:09.841, build `6AC13F71`), including that the
*polled* flag stayed TRUE through teardown. That last part is worth flagging to whoever owns
the polling path: it is precisely the hole the event-driven edge closes.

**3. VERIFIED -- `nullptr` was already a legal return from `resolve_esp_camera`.** My gate
returns null when `!is_in_raid`, so this is what keeps the gate from introducing a new
contract. `pick_esp_fps_camera` already returned null on the `cam_source::none` path and the
log shows `none=N` occurring, so callers were already handling it.

**4. VERIFIED, and this is the one that could have turned my fix into the bug -- no menu card
projects world points.** If any card reached the projection path, my null-camera gate would hand
it null every frame outside a raid and a card projecting without checking would fault *because
of the gate*. Checked against the 12:07 build: every caller of `world_to_screen`,
`world_to_screen_prefer_optic` and `world_to_screen_with_frame` is in `EspModule.cpp` or
`AimbotModule.cpp`, both `is_in_raid`-gated before they get there.
`world_to_screen_aim_marker` (`eft_api.h:3998`) has **no callers at all**. **This is the first
premise to re-check if `menu::draw` keeps throwing once someone adds a map or radar card.**

**5. ASSUMED -- `menu::draw` is the only render-thread path into the object's model** besides
`minimap::process_pending_map_load`. My four `try` blocks cover `init_imgui` (both present
hooks), the minimap call, and `menu::draw`, and they are what turned a process-killing throw
into 138 counted log lines. `WndProc` calls only `oWndProc` and
`ImGui_ImplWin32_WndProcHandler`; no other `dxhook::` entry point touches the object model.
**Falsified by** a card that spawns or drains a worker queue on the render thread, or work
posted from `WndProc`. Easy to add, and then the fatal is reachable again.

**6. ASSUMED -- another workstream's in-flight edits are not my build.** `common_hooks.cpp`
(16 errors), `QuestModule.cpp` (11) and `dllmain.cpp` (3) were each uncompilable at various
points on 2026-10-04, rotating between owners. I adapted to none of it, staged none of it, and
committed one file at a time. **Consequence stated plainly: `dxhook.cpp` and the
`resolve_esp_camera` gate have never been verified by a full link** -- `dxhook.cpp` was verified
to compile with zero diagnostics and that is the whole of the evidence. Anything expecting my
commits to build against a working tree will be disappointed.

**7. MEASURED -- AGENTS_TODO 5.17 needs splitting by exception code, not deleting.** "WER local
dumps are not a reliable artefact" is directionally right but stated too broadly to act on.
Correlating every WER 1000 for `EscapeFromTarkov.exe` against `%LOCALAPPDATA%\CrashDumps` over
two days, counting a dump as written if it lands within 120 s of the event:

    0xC0000005    8 of 12 dumped    (67%)
    0xE06D7363    1 of  7 dumped    (14%)

So: **plan around a dump for an access violation -- you will probably get one -- and never for
a C++ exception, where you will probably not.** The blanket "treat dumps as a bonus" is what
cost the exfil diagnosis its evidence; `tools/minidump_read.py` naming
`UnityEngine.Component.get_gameObject` came from that single lucky 1-of-7 dump. This also
settles 5.17's "no pattern established" hedge -- there is a pattern, and it is the exception
code -- and it resolves a live contradiction, since `WORKFLOW.md:447` says the dumps "are the
only evidence available for what the game actually does". Both cannot be the guidance.

**8. ASSUMED -- the `TarkovAddons.dll` words in the 11:59 `0xC0000005` dump are not live
frames.** Symbolized, they are `crash_probe::g_ring`, `crash_probe::image_name` and a string
literal: the probe's own bookkeeping and stale stack words. `tools/minidump_read.py frames
--ours` will list them as ours and that is a false positive. **Falsified by** any of those RVAs
turning out to be a return address in a live frame; `tools/pe_disasm.py` settles it by showing
a preceding `call`. **Risk if I am wrong:** an unexamined frame of ours during an access
violation that is otherwise unexplained -- `read` at `0xA5230`, near-null, in
`ucrtbase.dll+0x65655`.

**Ledger note, on top of 5.7u's:** their memo cites `kOverlayPoisonedAfter` at
`dxhook.cpp:1140`; it is at `dxhook.cpp:68`, and `menu::draw()` is at `:1142`. Harmless, but the
repo's cross-references are load-bearing enough to be worth a fix on next touch. And a CHANGELOG
collision is now three-deep -- 5.7u flagged 0.21/0.22 appearing twice; if 5.7v gets a CHANGELOG
section it needs a number that is actually free.

> **RESOLVED 2026-10-06.** The collision this warned about is fixed: the duplicated pair moved
> to §0.59/§0.60 and no number appears twice. The advice standing here is now obsolete --
> §0.59 through §0.58 are free, and the check is one command:
>
> ```sh
> grep -oE '^### 0\.[0-9]+' CHANGELOG.md | sort | uniq -d   # empty == no collision
> ```
>
> Left in place rather than deleted, because the collision it describes was real and the
> warning about how it happened is the useful part. The `kOverlayPoisonedAfter` line
> reference above is a separate matter and is still open.

### 5.7w `Unity init failed` on 2 launches in 4, and it is a race inside IL2CPP, not our pattern

Asked to look at the appended log. The whole thing is 45 ms and the failure is one line:

    14:17:29.030 Loading Unity
    14:17:29.041 ERROR Unity init failed: required UnityEngine classes missing

The aimbot memo had already flagged this once and written it off as "a previous launch failed
cleanly and is unrelated" (`tools/handoff_exfil_overlay_and_probe_memo.md:100`, pid 3616 at
12:59:08). **It is not unrelated.** Same line, same cause, six minutes and then three hours
apart. That memo's instinct was wrong on this item and the reason is worth recording: it read
one line that named no class and no cause, so there was nothing to connect it to.

#### 5.7w-a What the log does NOT say, which is most of why this took two launches

**No `resolve_image FAILED` line is present**, so `resolve_image("UnityEngine.CoreModule.dll")`
*succeeded*. Only `il2cpp_class_from_name` returned null. That narrows it to one function
before any disassembly is needed, and it is worth stating that the log makes it look like five
independent lookups failed when it is one image's lookup failing five times.

**Ruled out by measurement, not argument.** Offline against the shipped
`D:\Games\Tarkov\GameAssembly.dll` (scripts left in `%LOCALAPPDATA%\Temp\opencode\`, mapping
the PE the way the injected module does):

| check | result |
|---|---|
| manifest identity vs on-disk DLL | **exact**: `SizeOfImage=0x66ED000`, `pe_timestamp=0x6AAD381A` |
| manifest `.text_sha256` vs **`.text` raw bytes** | **match** for GameAssembly *and* UnityPlayer |
| deployed manifest vs repo manifest | byte-identical (`A32FE31C…`) |
| real matches per pattern, whole mapped image | **exactly 1**, for all 8 pattern symbols |

So: not a stale profile, not an ambiguous pattern, not `GetProcAddress` (that launch logged
`0 of 14 ... The loader listed the module for all of them`).

**And the pattern-vs-export split is deliberate, not a bug.** For `il2cpp_domain_get`,
`il2cpp_field_static_set_value` and `il2cpp_type_get_object` the pattern hit *is* the function the
export thunk jumps to (export `0xB3AA0` is `E9` -> `0x43C40` = pattern hit), which is what
`exports.h`'s "Unwrapped body" comments say the patterns are for. For `il2cpp_class_from_name`
the export (`0x175C10`, a **4-arg** function -- `mov rdi, r9` / `test r9, r9`) is a different
entry point from the pattern hit (`0x7CF90`, 3-arg). Pattern-first order is correct.

#### 5.7w-b The mechanism, from the disassembly

`il2cpp_class_from_name` keeps a **per-image class hash map at `image + 0x30`** and builds it
lazily, in this order:

```
cmp qword ptr [rcx+0x30], 0 / jne reader      ; is it there already?
...
mov qword ptr [rdi+0x30], rbx                 ; PUBLISH -- map still EMPTY
cmp dword ptr [rdi+0x18], 0                   ; fill starts (type count)
...
mov rbx, qword ptr [rdi+0x30]                 ; re-read, PER ITERATION
```

A reader arriving while the counts are still zero falls through to `xor eax, eax`: **null for
EVERY name**, not just absent ones. **There is no lock in that function** -- the only atomics in
it are CRT scaffolding (`lock xadd` on an init refcount, `lock cmpxchg` on a container-growth
counter). `image+0x18` is the type count because the fill loop's `call 0x2DDAA0` is the same
`image+index -> type` helper the exported `il2cpp_image_get_class` calls; `image+0x00` is `name`
and `image+0x10` is `assembly` per `il2cpp_image_get_name` / `_get_assembly`, so the argument is
genuinely an `Il2CppImage*` and the offset arithmetic is right.

**How we get there.** `unity::init()` runs on the thread `DllMain` creates (`dllmain.cpp:360` ->
`:182` -> `:277`), *not* Unity's main thread, and the boot gate returned on its first poll --
`boot: Unity window present after 0 ms, 0 poll(s)`. So this runs inside Unity's own startup,
which is when the game's main thread is doing the first CoreModule lookups itself. Either thread
can read the other's half-built map.

**What I have NOT established:** which thread loses. I cannot run the game, so the final link is
inference from the disassembly plus the `0 poll(s)` gate. The retry below is what settles it.

#### 5.7w-c Fixed: a bounded retry, and a report that names the class

`unity::init()` now resolves the five required classes from **one table** inside a loop, 3
attempts / 150 ms apart -- deliberately the same numbers `resolve_pattern_with_retry()` already
uses in `il2cpp_offsets.h`. This is **5.9's defect class, in the one place 5.9 did not reach**:
a cold-start lookup that is transient, with no retry on the path. §5.9's own table ("pattern: 3
attempts / export: 1 attempt") is the precedent, and `unity::init()` was the third such path with
zero.

Two outcomes are now distinguishable in the log instead of one line that distinguishes nothing:

- **recovered** -- `null on the first attempt and resolved on attempt N of 3 -- this is a race on
  il2cpp_class_from_name's per-image cache`. That is the proof 5.7w-b predicts, from the log.
- **not recovered** -- one ERROR per missing class naming it, plus `N of 5 ... resolved`.

**Bounded, and that is load-bearing.** The guard is `if ([image+0x30] != 0) use as-is`, so if
*this* thread is the one that published an empty map, **no number of retries will populate it.**
That case now says "still null after 3 attempts" instead of masquerading as a missing class, which
is the honest signal and the whole reason the loop logs rather than retrying silently.

Retry cost is bounded too: `resolve_class` memoises SUCCESSES only, so a later attempt re-runs
only the lookups that failed.

#### 5.7w-d Two bugs I introduced in the fix, both caught by writing the test

Recorded because both are the *same* mistake (a statement about a value that has already been
incremented, sitting in the wrong branch), and both read as correct:

1. I first put the "resolved on attempt N" WARN **inside the failure branch**. There,
   `attempts_used > 0` means the **opposite** -- retries ran and *still* returned null, the
   unrecoverable case -- so the one line that should prove the race would have fired exactly when
   it was false. It is now gated on `classes_ok && attempts_used > 0`, outside the branch.
2. I first passed `attempts_used + 1` to the failure report. The `for` increments on its way
   out, so that prints **"4 of 3"**.

`tools/tests/test_unity_class_resolve_retry.py` (7 tests) pins both, plus the substantive one:
**the lookups must be inside the loop.** A retry that does not re-run the failing lookups is not
a retry, and the loop's exit condition would be testing a value that never changes -- which is
`test_unity_liveness_throttle.py`'s PART 1 defect one level up. All four negative controls were
checked to fail **on their intended assertion**; the repo has a recorded instance (§5.8) of a
control passing on the fix's own explanatory comment.

The test itself failed first for a reason worth keeping: `code_only()` blanks string literals, so
matching the member names `"Object"` can never work. It matches on structure now and extracts the
names from raw lines.

#### 5.7w-e Flagged, not concluded: a bad build here poisons the GAME's cache

If *we* publish the empty map, `[image+0x30]` stays wrong for the rest of the process and the
game reads it too. That is a worse failure than ours and I have **not** established that it
happens -- I cannot run the game. It is also, on the timing above, the outcome least likely to be
ours (the game's own main thread reaches CoreModule first). Recorded because if it is ours it
belongs to whoever owns the post-exfil staleness in the aimbot memo, and nobody should rule that
out on the grounds that this section found a different cause.

### 5.7x The overlay throw is in EspModule::draw_overlay, and is_in_raid cannot cover it

Session 21872, build `0x6AC243A2`. 14 throws at ~50 ms intervals, all after
`Local Raid Ended` / `Insured Items: 0` / `Transfer Items: 1`.

**THE OFFENDER, from instrumentation the parallel session already had:**
call-site **`ESP::draw_overlay`**, i.e. `set_draw_stage_overlay`. The minimap stage sat at
`0/0` and exonerated itself, so **it was never the minimap** -- the second guess was right.

**MY PER-WIDGET INSTRUMENTATION PRODUCED ZERO HITS** (`ESP / ` appears 0 times in the log) and
has been REVERTED. It cost one `std::string` construction per visible widget per card draw on
a path measured at 313 us per ESP card draw, and it named nothing, because the throw is not in
any `ConfigValue::draw()`. `set_draw_stage_overlay` answered it without help. I proposed it as
"the decisive next step" and it was not: the decisive step was reading the label that was
already there.

**THE ACTUAL FINDING: the raid can be over while `is_in_raid` is still true.** The flag only
drops on the `LocalRaidEnded` event or the `InRaid` poll, and there is a window between the
raid ending and that landing. `draw_overlay`'s `if (!game_state::is_in_raid) return;` does not
fire, and we go on to `find_camera_if_best` -> `camera_get_all_internal()` -- Unity's
`Camera.all`, a managed call -- while the camera subsystem is tearing down.

**ISIL CHECKED, per the question asked. What it gave:**

| symbol | verdict |
|---|---|
| `InGameStatus.InRaid` | **CONFIRMED as the game's own gate.** `TarkovApplication.txt:5865` does `typeof(EFT.InGameStatus)`, a null-check, then reads `v33.InRaid` -- the same class and static field our poll reads. So it is not a proxy we invented; it is simply too coarse for a teardown window. |
| `EFT.HealthSystem.IHealthController.get_IsAlive()` | **CONFIRMED**, `System.Boolean get_IsAlive()`. **We already resolve it** -- `eft_api::try_get_health_controller` (:664) and `try_get_player_health` (:961, resolving `get_IsAlive` at :968). No new interop needed. |
| `EFT.Player.get_HealthController()` / `get_ActiveHealthController()` | confirmed; both already used by `try_get_health_controller` |
| `EFT.MovementContext.get_PhysicalCondition()` | exists, returns `EFT.EPhysicalCondition`; not needed |
| **`GameStarted`** | **FALSE LEAD.** Looks like a second flag and is not -- it is a `System.Single` metrics DURATION on `ClientMetricsEvents`, 8 reads, all timings. Reporting it as a state predicate would have been the fourth wrong conclusion in this thread. |

**So ISIL gave a usable answer, and option 3 was not needed as a narrowing of `is_in_raid`.
What it gave instead is a predicate we already had, plus the knowledge that the flag we use is
the game's own.**

**BOTH CHANGES ARE IN `draw_overlay`, and the second one is the one that matters:**

1. `scene_objects_live` -- `main_player_` resolves AND `try_get_health_controller()` returns
   non-null. **Fails OPEN**: an unresolvable health controller does not mean the scene is dead,
   and concluding that wrongly costs the whole overlay. **NOT `IsAlive` alone, deliberately** --
   a dead player is still in a raid with a perfectly working camera, so gating on `IsAlive`
   would drop the ESP for corpses and for anyone spectating a death.

2. **Both `resolve_esp_camera` calls now sit inside `catch (...)`.** `menu::draw` already
   caught the throw, so it was never fatal -- but the poison pill stops calling `menu::draw`
   after 120 consecutive throws, which means an exception from **one** subsystem costs the
   **entire** overlay: skeletons, boxes and labels all stop. Catching locally means no cameras
   this frame and everything else drawn, and it lets the poison pill's counter reset because
   `menu::draw` then completes cleanly. `catch (...)` not `catch (const std::exception&)`
   because a managed exception is not a `std::exception` and sails past the typed arm.

Both diagnostics are one-shot (5 lines max) rather than per-frame -- an unconditional line
here is 20 lines/second of exactly the flood this repo already has a problem with.

**PROCESS NOTE, because it cost three build cycles.** I applied this as THREE chained scripts
(`scene_gate` -> `fmt_fix` -> `fmt2`), each restoring from a backup first, and the failures
were all in the chain's ordering rather than in any one edit: a declaration inserted *inside* a
`std::format` argument list, and a `count()` that missed because every line carries a trailing
`\r`. **Consolidated into one script that starts from the pristine backup and verifies
use-before-declare -- and it applied first try.** The rule from 5.7t-c ("after N positional
edits fail, restore and re-apply") extends to *chained* patch scripts: do not compose them.

Verified: **Prod|x64 full build + link**, exit 0, **0 errors, 0 warnings**. `tools/tests`
**210 passed**.

**BUILD SCOPE CHANGED, at the user's instruction: Prod only.** `Prod no aimbot` is no longer
built -- it is not the delivered configuration and it doubles the cycle. **Honest caveat:** that
config had a REAL break earlier today from the parallel session's uncommitted fireport work in
`skeleton_visibility.h` (`:217` a 6-argument `logger::debug`, `:1526` `fp_win_scope`'s
destructor). That file is still modified beyond HEAD, so **`Prod no aimbot` is currently
unverified, not known-good** -- and single-config verification cannot see a defect that only
one config exposes, which is the same class of blind spot as per-TU builds hiding `LNK2005`.

**Renumbered at commit time.** This went in as `5.7v` and collided with `5.7v The aimbot memo
corrected my exfil timing` -- again **my own** section, one commit earlier. Same cause as
`CHANGELOG` `0.43`: the guard compared whole titles while the reader navigates by the short
key. **Check the short key, not the title.** `5.7t` / `5.7t-a..d` are a letter plus
sub-letters and are not duplicates.

### 5.7y Two runs measured the fix, and one of them says the gate is not earning its place

Runs `pid 30432` (stuck) and `pid 26280` (exfil success), 2026-10-04.

**Confirmed: containment.** `menu::draw` throws went 14 / 8 / 16 across the three pre-change
sessions to **0 / 0** across the two post-change ones. The catch is the entire benefit.

**Refuted, and it is my own predicate:** at the moment of the throw,
`scene_objects_live=true is_in_raid=true`. The player and its health controller both still
resolve while `Camera.all` throws. **This is 5.7r repeating one level out** -- there the guard
tested a managed wrapper instead of the object behind it; here the scene gate tests a managed
player instead of whether calling Unity is safe. It fails open, which is the right default, and
the catch does the work. **Recorded rather than deleted: the gate is not earning its place, and
the next person should not spend another run rediscovering that.**

The throw persists, 641 ms after `Local Raid Ended`, now contained locally.

**Cost of the change: none measurable.** `resolve_esp_camera_frame` 10.5 us mean / 0.3 ms max
on the stuck run vs 11.7 us on the control.

**The freeze is `always_on::hk_on_game_end` at 7479 ms in ONE call**, against 29.6 ms in the
control, with `hk_comeback_to_main_menu` at 7460 ms against 2655 ms. No child zone accounts for
it, and the *successful* run also spends 2.66 s in `hk_comeback_to_main_menu`, so the zone is
inherently multi-second rather than newly broken. `hk_prepare_game_job` is ~1.2 s in **both**.
Our worst in the same window is `EspModule::gameworld_update` at 853 ms max -- an order of
magnitude below the block.

**Also fixed: my own reporter was the measurement defect.** Both diagnostics capped at 5 lines,
so the runs log exactly 5 and 500 is indistinguishable from 5. Now first 3 then every 256th,
carrying the running total.

**Method note.** The console renders thousands with U+00A0 in this locale, which made the first
Tracy table unreadable and I was reading magnitudes by eye. Re-parsed to integers: the
`hk_on_game_end` 7479 ms was not a formatting artefact, and I would not have trusted it if I
had guessed. Also checked rather than assumed: `hk_game_world_update` logs zero times in a whole
session, so its absence after teardown is not evidence of anything -- a conclusion I was about
to draw.

Prod|x64 full build + link: exit 0, 0 errors, 0 warnings. `tools/tests` 210 passed.

### 5.7z Two follow-ups from the two-run measurement, one of which was a hazard I introduced

**The scene gate is cut to its free half.** Dropped `try_get_health_controller` from
`scene_objects_live`; kept `main_player_ && main_player_->klass`, which fired on both runs.

Why, and the second reason is the one worth remembering: it is two managed calls per
`draw_overlay` on the render thread, **and it sat outside the `try` block**. The whole point of
the local `catch (...)` is that a managed throw must not escape to `menu::draw`, and my gate
had put a managed call into the only path without protection -- on a dying player. It never
threw in either run, so the protection was untested and the exposure was real. A guard that
cannot see the failure it was added for, and which reintroduces the risk it was added beside,
is worse than nothing.

**The 7.5 s gets a zone.** `::orig` on the three `always_on` transit hooks, to split the game's
`MoveNext` from our per-iteration `resolve_field` and `transitdbg` logging.

Worth noting for whoever owns that file: `il2utils::resolve_field` takes
`metadata_cache_mutex`, the same non-recursive lock as `resolve_method` / `resolve_image` /
`resolve_class`, and these hooks call it **every iteration** while the hook itself "spins" during
a transit. That is a plausible multi-second stall and it would be ours. `hk_prepare_game_job`
is ~1.2 s in **both** runs, so it is normal game-save work -- but `hk_comeback_to_main_menu` is
2.66 s even in the run that **succeeded**, which is the more alarming half of that pair.

Three one-line scopes, no restructure: another session is in `always_on.h`. The pre-work zone
needs locals hoisted, so it waits for `orig` to point at a side.

**Housekeeping.** `EspModule.cpp` normalised to CRLF (110 bare-LF lines from my own scripted
writes). `autocrlf=true` meant the committed blob was already right, but the mixed working file
made the `edit` tool fail three times on the same region.

**Two process lessons, both from today.** Another process on this box writes to `$env:TEMP` and
corrupted the output of two of my script runs -- scratch now lives in `Temp\opencode\esp`.
And twice a verification assertion failed while the edit was correct (a brace walk with too
narrow a window; an assertion string I mis-specified). Both times the tempting move was to
"fix" working code because my check was wrong. **A failing assertion is a claim about the code;
read it before touching anything.**

### 5.7aa The ::orig zones paid off immediately, and the number they exposed was 6,913

`pid 27460`, capture `next_next_next_day+8+transit+crash`. Two answers, one of them closing a
question and one of them opening a bigger one.

**CLOSED: the freeze is the game's, measured.** With the three `::orig` zones from 5.7y:

| zone | hook max | orig max | ours |
|---|---|---|---|
| `hk_on_game_end` | 4122.1 ms | 4115.1 ms | 7.0 ms (**0.17%**) |
| `hk_comeback_to_main_menu` | 4113.2 ms | 4104.8 ms | 8.4 ms (**0.20%**) |
| `hk_prepare_game_job` | 3323.8 ms | 3321.5 ms | 2.4 ms (**0.07%**) |

So **the `resolve_field` mutex hypothesis is refuted** -- our per-iteration field resolution and
transitdbg logging are 0.1-0.2% of a four-second stall. No lock convoy, no reason to restructure
`always_on.h`. It is `o_*_move_next`, the game's coroutine step. And it is variable: 4122 ms here
vs 7479 ms last run, same path.

**OPENED: 6,913 throws, not 5.** The reporter fix from 5.7y is what made this visible at all:

    18:34:19.969  throw #1 so far
    18:38:33.301  throw #6913 so far   scene_objects_live=true is_in_raid=true

27.3/second for 253 s, starting **99 s after `Local Raid Ended`**. Every sample says
`is_in_raid=true`, and `on_local_raid_ended_event()` runs *before* its own log line -- so the
event fired, the flag went false, and something set it back. That is a real defect in the
ratchet's revoke, and it is **not mine to fix from here**: `is_in_raid` is read by 18 files and
the right re-arm condition is a design question, not a clear-cut bug. Flagged for the owner of
`common_hooks.cpp`, with the measurement.

**They are cheap**, which is what stopped this becoming a performance thread:
`resolve_esp_camera_frame` totals 22.6 ms over 2,107 calls, mean 10.7 us. ~6,900 caught managed
exceptions cost tens of milliseconds.

**So: a circuit breaker.** Trips at 8 consecutive throws, logs once, **keyed on the player
pointer** so a new raid re-arms it, and re-arms on any successful resolve. `EspModule.cpp` only.

**Two things worth keeping from this exchange.** First, the discipline paid: 0.45 refuted my own
gate on two runs, 0.46 cut it, and the `::orig` zones answered the freeze question on their first
 outing -- three measurements, and the one that mattered most was the one that stopped me from
changing code. Second, **no crash despite the filename**: no minidump, `menu::draw` throws still
0, log ends on a normal `hk_local_game_create`. `+transit+crash` is what it was called, not what
happened, and I checked rather than assumed.

Build: my file is clean per-TU. **Full link blocked by the other session's in-flight
`QuestModule` refactor** -- `QuestModule.h` dropped `all_quests` / `detail_id` / `detail_ready`
from `quest_objectives_snapshot` at 18:52:47, `QuestModule.cpp` still used them and was being
written at 19:00:12. Nothing of mine references it.

### 5.7ab I swept another session's line into my commit by staging a whole file

Asked directly whether I introduced an infinite loop. **No** -- the breaker block is 37
straight-line code lines with no `while` / `for` / `do` / `goto`; the two `for` hits a grep finds
are the English word in comments.

But asking the question made me look at what I actually committed, and that is where the fault
is. `git add TarkovAddons/module/impl/EspModule.cpp` staged the **whole file**, and the other
session had an uncommitted line in it:

    FIREPORT_SITE("esp/view_cone_origin");    // EspModule.cpp:5764

Not in `c7d0a02f` (checked by reading the blob), so `c0962a80` absorbed it. **The numstat said 49
added where my breaker is 21 -- I did not reconcile those two numbers, which is the whole tell.**

`FIREPORT_SITE` writes the shared non-atomic global `skeleton_vis::g_fireport_site`
(`skeleton_visibility.h:193`), read by `TA_ZONE_SITE` at `:355`. They added it to label their four
`try_get_fireport_position` sites; mine is a fifth in another subsystem, so their attribution
would mislabel fireport time -- and the next reader would have no idea a second session's
instrumentation got in.

Reverted, one line, theirs to re-add.

**Not claiming it fixed the hang.** WER: `AppHangTransient` 20:11:50 and 20:21:41, plus an
`APPCRASH` cluster at 20:00:43-44 that **predates my 19:09 commit**, so one failure mode is not
mine. The macro is a scoped guard, not a loop. What is measured: no session since the breaker
build has logged a single `camera resolution threw`, so that path is not being exercised at all.

**The transferable lesson, because I have done the narrow-staging dance backwards.** Earlier today
I hand-composed index blobs specifically to avoid absorbing another session's prose -- and it was
still wrong, because hand-composing is error-prone in a different way (I corrupted both ledgers
on disk doing it). Then later I reverted to plain `git add <file>` and absorbed 28 lines of
someone else's code. **Neither approach is safe on a shared tree.** The check that actually works
is one line: *does the numstat match what I wrote?* 49 vs 21 was visible in the output I already
had and I read past it.

### 5.7ac Every check I wrote for these two label fixes asked the wrong question

Follows `5.7ab`, and is the same shape of mistake at a larger scale.

The two defects from `CHANGELOG` 0.55 -- container labels printing a MongoID, and exfils reading
open when the player cannot use them -- took **four commits**, and three of the four were me
breaking my own working fix:

| commit | what it broke |
|---|---|
| `c6704e99` | shipped a **crash** (`EligiblePoints` called with garbage in `rdx`) |
| `c6704e99` | shipped a **stray `}`** in `TeleportModule.cpp` |
| `c6704e99` | shipped a **truncated line** (`EspModule.cpp:6048`, lost `instance());`) |
| `558581ee` | fixed my own ordering error (`C3861`, predicate defined 1400 lines later) |

**The pattern is the finding, not the individual faults.** Every assertion in every patch script
asked *"is the new thing present?"* A truncated line, an unbalanced brace and a wrong-arity
method pointer all pass that question. Nothing I wrote asked *"is anything else still intact?"* --
which is the only question that catches a regression, and it is the one thing a presence check
structurally cannot do.

**What would have caught them, and did not exist:**

1. `tools/tests/test_brace_balance.py` -- 95 files, all balanced. Negative control reinserts the
   exact stray brace it was written for. Took two corrections to get right, both recorded in the
   file: an apostrophe in a `//` comment read as a character literal (59 such lines in
   `crash_probe.h`), then the same carve-out applied to double quotes, so `"favorite##" + x +
   "##" + y` swallowed four functions. **A checker that reports a confident wrong answer is worse
   than no checker** -- the first version did exactly that, on a valid header.

2. `tools/tests/test_diff_truncation.py` -- an added line that is a strict prefix of the line
   it replaced. A prefix match alone is **not** sufficient: a two-line reflow has that shape with
   nothing wrong. The discriminator is whether the lost text reappears elsewhere in the added
   lines. Its known limitation is written in the docstring: a lost single-character tail is
   invisible to it, since a lone `;` occurs throughout any diff.

3. **Declaration vs definition comparison.** The build rejected my change with
   `C2511: no overloaded member takes 4 arguments` because I edited a definition and not the
   declaration. Every signature I touched -- `collect_exits`, `collect_exit_array`,
   `exit_status_active` -- is now compared against its declaration as text, which is cheap and
   needs no compiler.

**Two standing rules this produced, for whoever writes the next patch script:**

- **Never build a search anchor or a replacement from a truncated rendering of a line.** Both
  truncations came from a 104-character print width leaking into what was actually written. If a
  line must be displayed shortened, print from a separate variable that is never written back.
- **Every method resolve through `get_method` sets `allow_any_argc = false`.** The "any arity"
  fallback returns the first overload's pointer regardless of its real signature, which is a
  silent wrong-function-pointer rather than a null. It cost a crash here. Correct-arity calls
  cost nothing to verify.

**Not done, and deliberately:** none of this is a compile. `tools/harness` and `tools/tests` both
run without building the project by design, so all three checks above are invisible to a
type error -- the build is still the only thing that verifies arity, and it did so only after
four attempts.

### 5.7ad The call-through-null fix converted three crashes into silent no-ops, and 87 sites remain

Follows from `5.7ac`. Asked to check whether the null-guard work broke something else, it did --
twice, in opposite directions.

**1. THE FIX IS INCOMPLETE: 87 SITES REMAIN.** `6c8435ff` (10-04 21:41) fixed four
call-through-null resolvers after one killed the process at `operation 8, execute at 0x0`, and
`6b35fe8b` (10-05 09:39) guarded nine more. `tools/tests/test_call_through_null_scan.py` counts what
is left: **87 across 8 files, all in `module/impl/`** -- `ItemModule.cpp` 22, `QuestModule.cpp` 20,
`PlayerModule.cpp` 13, `ChamsModule.cpp` 11, `ItemModule.h` 9, `WeaponModule.cpp` 8,
`PlayerModule.h` 3, `EspModule.cpp` 1. The low-level resolvers got fixed; the modules that call
them did not.

`EspModule.cpp:6108` is the one in my own file: `get_Nickname` resolved and invoked inline, in
the **player-label** path -- so a miss is a call to address 0 while building the very label this
thread started from.

**NOT MINE TO FIX.** 85 of the 87 are in modules other sessions own, and 87 sites is not a
change to make blind from here. The scanner exists so the count is visible and cannot silently
drift upward as code moves.

**2. THE THREE GUARDS CONVERTED A LOUD FAILURE INTO A QUIET ONE.** This is the part worth
carrying. Each resolver now returns a plausible value on a miss, and in three places that value
is indistinguishable from a real answer:

| resolver | miss returns | consumer | consequence |
|---|---|---|---|
| `get_childCount` | `0` | `unity::transform_apply_to_all_children` (`unity.h:1120`), called from `ChamsModule.cpp:817` | a resolver miss is **identical to a leaf node**: the loop body never runs, `renderers` stays empty, and weapon chams silently stop applying. No log, no counter. |
| `get_childCount` / `get_Root` | `0` / `nullptr` | `try_is_btr_by_weapon` (`eft_api.h:4967`, `4994`) | `return false` = "not a BTR", so a miss **misclassifies the player** rather than degrading. Wrong answer, silently, where the other two only lose data. |
| `get_Hands` / `get_Item` | `false` | `try_read_weapon_ammo` (`eft_api.h:6980`, `6995`) | ammo readouts vanish with no diagnostic. |

Before `6c8435ff` all three were a crash at address 0 -- impossible to miss. They are now
**silent**, which is a worse failure mode for a feature nobody is watching, and it is exactly the
"a checker/test that cannot fail is worse than none" shape applied to runtime code: the code no
longer announces that it did nothing.

`camera_fov` returning `0.f` was checked and is **clean**: both consumers guard it
(`o_fov > 0.1f`, `fov_e > 1.0f`) and fall back to `k = 1.f` / `mag = 0.0`, so a degenerate
projection matrix never reaches the matrix.

**THE GENERAL RULE.** A null guard converts a crash into a value, and the value then has to be
distinguishable from a legitimate one. `if (!fn) return 0;` is only safe where the caller can
tell "zero" from "unknown". Where it cannot, the guard should log once and count, the way the
camera circuit breaker in `CHANGELOG` 0.48 does -- one line, then silence, because the feature
failing quietly is worse than it failing loudly.

**3. TWO BUGS IN THE SCANNER ITSELF, both found by running it rather than reading it.** Recorded
because they are the same shape as everything else in this thread:

- It used `os.listdir()` on `TarkovAddons/module`, which **skips `module/impl/`** -- the directory
  holding 84 of the 87. A scanner that misses a whole subtree reports a clean result.
- It matched **6c8435ff's own documentation**, which quotes the pattern verbatim to explain the
  fix. Comments are stripped first, comment-first, for the same reason
  `test_brace_balance.py` strips them.
- Then a third: the lazy match ran across `); if (x = other.get_method<...>(` and paired one
  resolver's close paren with the next call's open paren, inventing two `EspModule.cpp` hits.
  Fixed by excluding `;{}` from the argument span. 88 -> 87, and the one that survived is real.

It carries a three-case self-test (the unguarded shape is found; the guarded shape and the
documentation stay quiet), so it cannot pass by scanning nothing.

### 5.7ae `is_plausible_localized_result` is strict, and the key that misses is the wrong one

Follows `5.7ad`, and closes the container-name thread from `CHANGELOG` 0.55 that 0.56 finishes.

The useful thing here is not the fix, it is the shape of the mistake: **a resolver that looks
careful, is careful, and still returns garbage because it was handed the wrong argument.**

`try_localize_game_key` has a 30-line plausibility filter -- it rejects `Name/<id>`,
`<id>/Name`, `<id> Name`, path-only ASCII, the whole family of ways a failed lookup echoes the
key back. It is good work and it is not the problem. It was handed a **bare** MongoID, and the
key the game uses is `<id> Name` with a **space**; `try_localize_with_suffix` builds
`id + "/Name"` with a **slash**. So the lookup missed a real key, the filter correctly rejected
the echoes, and the caller treated "correctly rejected" as "no such key" and fell through to
`klass->name`.

Two readings worth keeping:

- **A defensive filter cannot detect a wrong argument.** `is_plausible_localized_result` got
  exactly the input it was designed for -- a real key that returned a real answer -- and the
  answer was wrong upstream. Any amount of validation downstream of the argument is wasted.
- **The file already documented the answer, 200 lines above the bug.** The separator is written
  out in `try_get_item_name_for_template_id`'s comment, and the item db's 56-unlocalized tail is
  the same defect in a different caller. The knowledge existed; it just was not on the path that
  needed it.

So when a lookup "fails", the question worth asking first is not "is my filter too permissive"
but "is this the key the game actually uses" -- and the cheapest way to answer that is to find a
caller in the same file that gets it right, rather than to reason about the filter.

### 5.7af Two static-analysis tools, and what the CMake switch was actually for

2026-10-10. The reason this project moved to CMake was to reach tooling like this, so it is
worth separating what that switch bought from what it was hoped to buy.

**CMake cannot detect duplicated code.** It builds a dependency graph; it has no notion of code
content. What it gave is `compile_commands.json`, which Ninja exports and the Visual Studio
generator does not, and that is the input every clang-based tool needs. That is the whole of
the benefit and it is real.

**clang-tidy works here, and it is cheap.** 79 first-party TUs, 16 jobs, **253 diagnostics in
216 s**, LLVM 23.1.3. Two blockers had to be cleared first, both measured:

- clang cannot read a cl.exe-produced PCH (`file doesn't start with precompiled file magic`), so
  there is now `-DTA_NO_PCH=ON` (default **OFF**) and a separate `build/analysis/x64/tidy` tree.
  **Never point this at `build/Prod`.**
- the SDK include paths come from `INCLUDE` via `vcvars64.bat`, not from `-I` in the database, so
  the runner has to live inside a vcvars shell.

Unfiltered, clang-tidy emits **1067 warnings on a 2 KB file** -- essentially all imgui and SDK.
So `HeaderFilterRegex` is doing the real work, and it needs negative lookaheads: a header
reached from `module/impl` prints as
`.../TarkovAddons/module/impl/../../il2cpp/libil2cpp/il2cpp-api-types.h`, and a plain allow-list
for `.../TarkovAddons/module/...` accepts the whole Unity-generated tree two `..` away. 45 of 64
diagnostics in the first probe run were exactly that.

Six checks are disabled, each carrying its measured justification in `.clang-tidy`. The two that
matter are the ones firing on deliberate design:

- `clang-analyzer-security.ArrayBound` -- every hit is `&loot_array->data[i]` bounded by
  `loot_array->max_length`, i.e. the extra trailing `void* data;` on `Il2CppArray` that "Do not
  touch" says must not be removed. The analyzer cannot see that the bound and the length come
  from the same object.
- `performance-no-int-to-ptr` -- the IL2CPP field idiom `*(T**)(uintptr_t + field->offset)`, used
  ~70 times. The offset genuinely is a runtime integer.

`tools/dup_scan.py` covers the other half: a token-level clone detector. **177 first-party files
(167 comparable at the default window), 405,481 tokens, 5.9 s, 72 code clones, 6 data tables
and 9 mass-duplication buckets declined**, at `--min-lines 10`. The largest is 44 lines in
`QuestModule.cpp`, two near-identical quest-condition blocks at 1279 and 1549.

#### Not triaged. A finding from a fresh tool on a fresh report is not a claim yet

Worth one look each, none examined:

| where | what |
|---|---|
| `AimbotModule.cpp:554` | `DeadStores`: `main_player_transform` written, never read |
| `dllmain.cpp:159` | `DeadStores`: value stored to `_` during its initialization is never read |
| one site | `bugprone-use-after-move` |
| one site | `bugprone-unchecked-string-to-number-conversion` |
| one site | `bugprone-switch-missing-default-case` |
| one site | `bugprone-unhandled-code-paths` |
| `dxhook.cpp:156,186` | `bugprone-empty-catch` x2 |
| `menu.cpp:430,432` | `FloatLoopCounter` -- `float` as a loop induction variable |
| `compatibility_profile.h:15` | `performance-enum-size` on `LoadResult` |

`deadcode.DeadStores` and `use-after-move` are the two that would change behaviour if true.
`empty-catch` in a DirectX hook wrapper is probably deliberate.

**74 `clang-analyzer-security.ArrayBound` hits are the `Il2CppArray::data` divergence** and are
not findings at all. That ratio -- 74 false against roughly 8 unexamined -- is the argument for
curating the check list per-tree rather than enabling a family and reading the output.

#### Two things that were true and cost time

- **The collision test was a green stub.** `test_dup_scan.py`'s first version asserted that a
  hash-collided run equals the clean run. It **passed with the exact-comparison deleted** --
  every spurious clone was absorbed by the overlap filter, so the output was identical anyway.
  Rewritten to assert the property that distinguishes the two implementations
  (`_recheck`, which does not call the tool's own comparator) and re-negative-controlled by
  deleting the comparison again. It now fails with
  `a clone invented by a hash collision was reported as a finding`.
- **A test helper scanned the wrong tree.** `run(tmp_path, *args)` built its command line from
  `*args` alone and silently dropped `tmp_path`, so every case scanned the repository instead of
  its fixture -- and three still passed, including `test_exit_2_when_nothing_was_checked`, which
  was checking "exit 2 means I looked at nothing" against a run that had looked at 174 files and
  found 365 clones. Same shape as the three tools in `tools/verify/README.md`.

Also fixed on the way: `configure_cmake.bat` hardcoded the build-tree slot and could never
receive a `Debug` configuration, so `$env:SLOT` did nothing on the CMake path and
`configure_cmake.ps1 -Configuration Debug` had never built Debug. See `WORKFLOW.md`.

#### Three pre-existing `tools/tests` failures, not from this work

Still red on `21a13849a`, recorded here so the next person does not re-diagnose them:

- `test_brace_balance.py::test_negative_control_detects_stray_brace` -- the anchor it injects,
  `return status == 2 || status == 4 || status == 5;`, no longer exists in `TeleportModule.cpp`,
  so the control cannot demonstrate anything.
- `test_call_through_null_scan.py::test_scanner_recurses_into_module_impl` -- `targets()` returns
  `[]` for `TarkovAddons/module/impl/`. **That scanner is currently reporting a clean result
  while examining nothing**, which is exactly what 5.7ad was about; it needs the same exit-2
  treatment `audit_config_pointers.py` has.
- `test_manifest_tool.py::IsilTests::test_shipped_patterns_cfg_exposes_hwid_check_slot`.

### 5.7ag clang-tidy triage: one real bug, and it belongs to someone else

2026-10-10. `tools/run_tidy.ps1` over all 79 first-party TUs, 253 diagnostics, every one
triaged by hand. **One is a real bug. It is in `[CLEANUP-PENDING:OPTICS]`, so it is written
down here rather than fixed.** The table is the whole result; read it as "which checks are
worth having on this tree", not as a worklist.

**Handed off, because another workstream owns the file**

| where | what | why not fixed here |
|---|---|---|
| `EspModule.cpp:2462` | `bugprone-use-after-move` | **THE REAL BUG** -- see below |
| `AimbotModule.cpp:554` | `DeadStores` on `main_player_transform` | already documented in place as a known dead read, deliberately left so the next Tracy capture stays comparable |
| `HideoutModule.cpp:613` | `bugprone-unchecked-string-to-number-conversion` on `std::atoi` | hideout workstream -- `handoff_hideout_premises.md` is from them |
| `HideoutModule.cpp:152,153` | `DeadStores` on `in_raid`, `sf` | same; both are dead locals in a zoned per-frame function |
| `esp_text.cpp:172,182` | `bugprone-narrowing-conversions` (`size_t` to `difference_type`) | optics |

#### `EspModule.cpp:2462` is the one that matters

```cpp
std::string name = eft_api::try_get_item_localized_name(item_obj, localized_short_name, localized_name);
if (name.empty() || name == "item_mod")
    name = eft_api::try_get_item_display_name(item_obj);

if (!template_id.empty())
    template_name_cache_[template_id] = std::move(name);   // 2460

return name;                                               // 2462 -- moved-from
```

`return name` returns a **moved-from** `std::string`. Under MSVC's STL the moved-from
string is left empty, so the function returns an **empty item name on every call where
`template_id` is non-empty** -- while the cache is correctly populated one line above. The
symptom is blank ESP labels for templated items, and the cache looks healthy, so nothing
points here.

The one-line fix is `return template_name_cache_[template_id];` inside the branch, or
`return name.empty() ? name : template_name_cache_.at(template_id);` -- but **not** reached
by me: `EspModule.cpp` carries `[CLEANUP-PENDING:OPTICS]` and the optics rework is live on
another machine. **Worth checking first whether the blank-name symptom has been seen at
all**, because if it has, the caller's empty-string handling is a second site.

Note the sibling path at 2441-2451 is written correctly -- it assigns *through* a reference
and returns the reference -- so this is one branch, not a pattern.

#### Triaged and deliberately NOT changed

Worth recording, because "clang-tidy says X" is not a reason to change code.

- **False positives.** `injector.cpp:85` `bugprone-sizeof-expression` is a false positive:
  the parameter is `const T&`, a reference, so `sizeof(object)` **is** `sizeof(T)`. All 11
  `bugprone-incorrect-roundings` are round-half-up on non-negative operands, which is
  correct -- `(int)(x + 0.5f)` on a texture width or a slot count is right, and the check
  is objecting to UB-on-negative, which cannot occur.
- **The `&local` passed to a `void*` API, which is 7 of the
  `bugprone-multi-level-implicit-pointer-conversion` hits** (4 of them in `injector.cpp`'s
  `read`/`write` wrappers, plus `InventoryEditorModule.cpp:578,627` and
  `PlayerModule.cpp:895`). The address is correct; the check wants an explicit `(void*)&buf`
  for type safety that this code does not otherwise rely on.
- **Deliberate, and documented in place.** `dxhook.cpp` empty-catch x2 -- *"A failure to log
  must not become the crash"*, and they are inside catch-reporting functions where
  rethrowing is strictly worse. `logger.cpp` empty-catch x2 (`logger.cpp:178,230`) --
  swallowed on purpose, and `logger.cpp:186` really does do what its comment says
  (`if (!*f) drop_log_stream();`). `assignment-in-if-condition` x6 -- the standard
  `if ((h = GetModuleHandle(...)) == nullptr)` idiom, already carrying `// NOLINT`.
  `menu.cpp` `FloatLoopCounter` -- those are grid *positions*, not counts; `float` is the
  point.
- **Negligible.** `Bypass/dllmain.cpp:49` for-range-copy (once per injection),
  `vk_swiftshader/dllmain.cpp:71` missing `default:` on a `DWORD` DllMain reason,
  `compatibility_profile.cpp:198` string concat (a handful of calls at manifest load),
  `dxhook.cpp` int-to-widening (bounded by D3D12's 16384 max width).

**No check was added to the `.clang-tidy` suppression list for any of these.** Two of them
are checks working *correctly* and code working *correctly* that happen to agree -- an
empty-catch that is documented and followed by a state check, four times over. Turning such
a check off would hide the next empty-catch that is a real defect, which is the "it is
noisy" answer `.clang-tidy` explicitly refuses. 4 and 7 hits are readable; a thousand is not.

The ratio is the finding: **74 ArrayBound hits that are all the `Il2CppArray::data`
divergence, and exactly one real bug in 253 diagnostics.** That is the argument for
per-tree curation over enabling a check family and reading the output.

#### Fixed in this workstream (2 of 253)

`svg_raster_map.cpp:165` and `dllmain.cpp:159`, both `DeadStores`, both real and both in
files nothing else claims. The `dllmain` one is the interesting shape: `console` is
genuinely write-only, so the discarded errno was the only thing worth keeping, and
`AllocConsole()` succeeding does not guarantee `CONOUT$` opens. That failure presents as
"the console is there but nothing prints" with nothing in the log. Now logged.

#### One thing clang-tidy did NOT report, in the file it pointed at

`injector.cpp:76`:

```cpp
template <typename T>
T* read(HANDLE h, PVOID address, size_t size) {
    T* buffer[size];                              // VLA, not standard C++
    ReadProcessMemory(h, address, &buffer, size, nullptr);
    return buffer;                                // pointer to a dead stack array
}
```

`size` is `sizeof(T)` at all six call sites, so the read under-fills a `size`-**pointer**
array -- safe, and correct on the wire. The real problem is the return type: it hands back a
pointer to a stack array. Every current caller (`injector.cpp:115,121,126,198,199,222`)
copy-constructs within the same full-expression, so it happens to be safe **today**; one
caller that stores the pointer reads dead stack.

Not fixed, deliberately. `AGENTS.md` §3.1 records that this file has already been through
one investigation which was **retracted**, with `static_assert`s now pinning the offsets, and
it says to read `AGENTS_TODO.md` §3.1 before repeating a claim about it. This is a
different defect from the retracted one and the retract does not cover it -- but "different
from the one we retracted" is exactly the reasoning that produced the retraction. **Someone
who owns the file should decide.**

### 5.7ah The severity ranking, and the two findings it turned up

5.7ag triaged every check family but ranked nothing, and it only sampled the two largest
non-`ArrayBound` families. Ranking them required reading all nine `narrowing-conversions`,
all twelve `unnecessary-value-param`, both `integer-division` and the `branch-clone`. Two
findings are new and neither was in 5.7ag.

#### NEW, and the most actionable unowned finding in the whole report

**RETRACTED 2026-10-10, one turn after it was written. See the correction below
before acting on any of this.**

`logger.cpp:210, 212, 213, 214, 253` -- `performance-move-const-arg`, five sites, and it is
only visible because it **interacts with** `performance-unnecessary-value-param`:

```cpp
void info(std::string msg) { write_line("INFO", 3, std::move(msg)); }   // 212
```

`logger::info` takes `std::string` **by value** -- which is right, it exists so a caller can
move in -- and then moves into `write_line`, which takes **`const std::string&`**. So the move
is a no-op and **every log line pays an extra string copy**. The `std::move` reads as if it is
avoiding one; it is not.

Neither check is wrong on its own: the by-value parameter is a false positive (it is the
by-value-then-move idiom, and the same six `unnecessary-value-param` hits in
`logger.cpp` + four in `Bypass/util/logger.cpp` are that, not sloppiness), and the
`move-const-arg` is a real missed move. **It took reading both to see that the by-value
parameter is currently paying for itself by copying.**

The fix is small -- make `write_line` take `std::string` by value; it formats into a local
buffer anyway. Not done here: `util/logger.h` carries a written contract and
`WORKFLOW.md` treats per-frame logging cost as a standing concern, so this wants the change
and a re-read of that contract in the same commit, not a drive-by.

#### NEW, and the worst *kind* of failure at low probability

Six heap-allocating globals with static storage duration, which
`bugprone-throwing-static-initialization` reports and which are all genuinely able to throw:

    i18n.cpp:25          std::string active_locale = "en";
    i18n.cpp:27          std::unordered_map<std::string, std::string> translations;
    i18n.cpp:30          const std::vector<language_entry> k_languages = { 19 entries };
    svg_raster_map.cpp:68  std::unordered_map<std::string, std::shared_ptr<...>> g_svg_jobs;
    svg_raster_map.cpp:76  std::deque<std::shared_ptr<svg_raster_job>> g_svg_job_queue;
    tile_raster_map.cpp:54,58  the same pair

If one throws, `std::terminate` -- **and static initialisation runs before `DllMain`, so
`crash_probe::install()` has not been called yet.** The failure mode is the one this project
can least afford: a process death with no probe report, no WER attribution and no log line.
Probability is very low (it needs an allocation failure at startup) and the consequence is
total, which is exactly the ratio worth writing down rather than suppressing.

The other four `throwing-static-initialization` hits -- `spoofer.cpp:310,311` and
`vk_swiftshader/dllmain.cpp:5` -- are `const char*` and **cannot** throw. False positives.

#### Two "do not fix this" notes, which are the ones most likely to be lost

**`WorldModule.cpp:782,783` `bugprone-incorrect-roundings` -- the integer division is
REQUIRED, and converting it to `lround` breaks the bot layout.** This is the one finding in
the whole report where "fixing" it would introduce a bug:

```cpp
const float side = (moved % 2 == 0 ? 1.f : -1.f)
    * static_cast<float>((moved + 1) / 2) * bot_spacing;      // 782
const float row = static_cast<float>(moved / 6) * 0.6f;        // 783
```

`(moved + 1) / 2` over `moved = 0,1,2,3,4` gives **0, 1, 1, 2, 2** with integer division --
so the spread is symmetric about the centre: `0, -s, +s, -2s, +2s`. In floating point it
would give 0, 1, 1.5, 2, 2.5 and **destroy the pairing.** Same for `moved / 6`, which is a
row index, not a distance. The check is objecting to the *cast*, not the division.

**`WorldModule.cpp:741` `bugprone-branch-clone` -- the redundant `case` is documentation.**

```cpp
case eft_api::npc_kind::civilian: return tp_scav->get_value(); // peaceful map to scav filter
case eft_api::npc_kind::btr:      return false;                 // <- identical to default
default:                         return false;
```

`btr` returning `false` next to `default` returning `false` looks like a copy-paste slip and
is not. The author enumerated every `npc_kind` on purpose and annotated the non-obvious
mappings -- the line above it is the same move. **`case btr:` records "BTR was considered and
is not teleportable."** Deleting it as a clone loses that, and the next reader re-adds it.

#### RETRACTION: the logger finding was wrong, and it was wrong in the expensive direction

I wrote "every log line pays an extra string copy" in the ranked table, in the commit message,
and in the paragraph above. **All three are false, and I asserted it twice without measuring
it.** Measured with an instrumented `operator new` and a heap-allocated (>16 char) string so
SSO could not hide a copy:

```
const&  callee : allocs inside call = 0, caller left moved-from = no
by-value callee: allocs inside call = 0, caller left moved-from = yes
control (1 bind + 1 real copy): allocs = 1
```

**Binding an rvalue to a `const&` does not copy.** The current shape costs zero allocations
inside the call, and the proposed by-value shape costs zero too -- the move transfers the
buffer. The only difference between them is whether the caller's local is left empty, and that
local is destroyed on the next line. **The change would save nothing.**

So the `performance-move-const-arg` diagnostic is *technically true and practically
irrelevant*, `write_line` is correct as written, and **`logger.cpp` was not modified.** The
six `unnecessary-value-param` hits in `logger.cpp` and the four in `Bypass/util/logger.cpp`
are likewise the by-value-then-move idiom working correctly.

This is the fourth time in this project's history that a plausible number in prose became a
claim before anyone measured it, and the second one in this section alone. The rule that
caught it is the only one that ever catches it: **write the number down, then go and produce
the number.** Two small probes did it -- one of them corrected my reasoning in the opposite
direction too, below.

#### The static-initialisation finding, measured

`bugprone-throwing-static-initialization` reports 10 sites. An instrumented `operator new`
decides which can actually allocate, which is the only question that matters -- a
default-constructed object that never allocates cannot throw, wherever it lives:

| site | allocations | can throw |
|---|---|---|
| `i18n.cpp:30` `k_languages` (21 entries) | 8 | **yes** |
| `i18n.cpp:27` `translations` | 2 | **yes** |
| `svg_raster_map.cpp:68` `g_svg_jobs` | 2 | **yes** |
| `svg_raster_map.cpp:76` `g_svg_job_queue` | 1 | **yes** |
| `tile_raster_map.cpp:54` `g_jobs` | 2 | **yes** |
| `tile_raster_map.cpp:58` `g_job_queue` | 1 | **yes** |
| `i18n.cpp:25` `active_locale` (`"en"`) | 0 | no -- small-string |
| `spoofer.cpp:310,311`, `vk_swiftshader/dllmain.cpp:5` | 0 | no -- `const char*` |

**6 of the 10 can throw, and the other 4 are false positives.** This corrected me in the
opposite direction too: I assumed an empty `std::unordered_map` and an empty `std::deque`
allocate lazily and cost nothing. On this toolchain both allocate on default construction --
2 and 1 respectively.

If one throws, `std::terminate` -- **and static initialisation runs before `DllMain`, so
`crash_probe::install()` (dllmain.cpp:266) has not been called.** The failure mode is the one
this project can least afford: a process death with no probe report, no WER attribution and
no log line. Probability is very low; consequence is total.

**Fixed in `i18n.cpp` (2026-10-10).** The four namespace-scope objects became function-local
statics, which moves the allocation to first use. Every use is at or after
`ModuleManager::init()` (`dllmain.cpp:359`), so the probe is armed by then. `embedded_locale_resource_id`
in the same file already used this idiom, so the shape is not new. C++11 magic statics are
thread-safe, so the `locale_mutex` discipline is unchanged; destruction order moves from
namespace-scope reverse-order to first-use reverse-order, and nothing here has a destructor
that observes another.

**Still open, and NOT done:** the same conversion for `svg_raster_map.cpp` (12 + 5 references)
and `tile_raster_map.cpp` (8 + 5). Left alone deliberately -- 51 references across three
files, all of it mutex-guarded, with no compiler available. **These are the higher-numbered
ones, not the first place an allocation failure would show up.**

#### Also characterised, so nobody re-derives it

- **`bugprone-signed-bitwise` -- 75 of 263, 30% of the report.** 26 in `EspModule.cpp`, 14 in
  `PlayerModule.cpp`, 6 in `IcebreakerScenarioModule.cpp`, the rest in the raster/menu/chams
  files. All are `&`/`|`/`^` on values that are non-negative (RGBA packing, IL2CPP flag
  masks, the `0x00007FFFFFFFFFFF` pointer masks). **There is no shift in any of them**, and
  the UB this check exists for is shift-of-negative. Benign in bulk, and by far the cheapest
  check on the list to leave enabled and ignore.
- **Remaining `performance-move-const-arg`:** `QuestModule.cpp:228` (`std::move` of a
  `const`), `svg_raster_map.cpp:297` and `tile_raster_map.cpp:854` (`std::move` of the
  trivially-copyable `raster_layer`). All no-ops, all zero behaviour, all misleading.
- **Remaining `narrowing-conversions`:** `ItemSearchValue.cpp:53`, `menu.cpp:387,388,455,456,538`
  are `g * 2.0f` / `10 * sf` -- an `int` operand in a float expression, which is promotion
  and not narrowing in any harmful sense. `EspModule.cpp:1413` is `ImU32` to `float`
  (optics-owned). Only the two `esp_text.cpp` sites are a real `size_t` to `difference_type`.
- **`performance-enum-size` x3** -- `compatibility_profile.h:15` `LoadResult : int`,
  `svg_raster_map.cpp:46` `svg_job_state : int`, and one in a Bypass header. Changing an
  enum's base type is an ABI-visible edit for a few bytes in a DLL nobody links against.
  Not worth it.

#### The ranking itself, for whoever picks this up

Ordered by consequence, not by check severity:

| | finding | owner |
|---|---|---|
| 1 | `EspModule.cpp:2462` use-after-move -- empty item names | optics (5.7ag) |
| 2 | `injector.cpp:76` returns a pointer into a stack VLA | unclaimed (5.7ag) |
| 3 | 4 more heap-allocating statics in the two raster files -- `std::terminate` before the probe | **unclaimed, open** |
| 4 | `HideoutModule.cpp:613` `atoi` -> silent 0 | hideout (5.7ag) |
| 5 | dead stores and no-op moves (4 sites) | aimbot / hideout / unclaimed |
| 6 | ~150 diagnostics where a correct check meets correct code | nobody -- leave them |
| 7 | 83 `ArrayBound` -- the `Il2CppArray::data` divergence | nobody -- by design |

**The logger item that was at #3 here has been RETRACTED -- it was never a cost.** And the
static-initialisation item that was at #4 is now split: `i18n.cpp` is fixed, the two raster
files are open and are what row 3 is.

**One bug, one latent hazard, two silent-failure paths, and roughly 150 diagnostics that
are a tool working correctly meeting code working correctly.** That ratio is the finding
about the tool, and it is the argument for the per-tree curation in `.clang-tidy` over
enabling a family and reading the output.
